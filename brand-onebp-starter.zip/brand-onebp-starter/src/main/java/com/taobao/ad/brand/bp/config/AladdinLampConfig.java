package com.taobao.ad.brand.bp.config;

import com.alibaba.aladdin.lamp.client.AladdinLampClient;
import com.alibaba.aladdin.lamp.client.config.Config;
import com.google.common.collect.Lists;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @Author: PhilipFry
 * @createTime: 2024年12月03日 14:53:46
 * @Description:
 */
@Configuration
public class AladdinLampConfig {
    @Bean(initMethod = "init")
    public AladdinLampClient initAladdinLampClient() {
        Config config = new Config();
        // 非网关类业务（请求的业务身份可穷举）可传入 bizId 范围来精简启动（101、102 为猫超示例，切勿直接拷贝）
        config.setBizScope(Lists.newArrayList(20200102L));
        AladdinLampClient lampClient = new AladdinLampClient(config);
        try {
            lampClient.init();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return lampClient;
    }
}
