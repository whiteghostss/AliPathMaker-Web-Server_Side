package com.taobao.ad.brand.bp.exception;

import com.alibaba.ad.nb.tpp.exception.TppException;
import com.alibaba.hermes.framework.error.BaseErrorCode;
import com.alibaba.hermes.framework.error.ErrorCodeAware;
import com.alibaba.hermes.framework.ext.exception.ExceptionConsumer;
import com.alibaba.solar.common.exception.SystemException;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.hsf.exception.HSFException;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.MissingServletRequestParameterException;

import java.util.Objects;

@Primary
@Component
public class BrandOneBPExceptionHandler implements ExceptionConsumer {

    private static final String BROKEN_PIPE = "Broken pipe";

    @Override
    public Boolean match(Throwable e) {
        return true;
    }

    @Override
    public ErrorCodeAware parseErrorCode(Throwable e) {
        RogerLogger.error("unknown error {}", e.getMessage(), e);
        if (e instanceof NullPointerException) {
            return BrandOneBPBaseErrorCode.INTERNAL_ERROR;
        }
        if (e instanceof BrandOneBPException) {
            return ((BrandOneBPException)e).getErrorCodeAware();
        }
        if (e instanceof TppException) {
            if (e.getCause() != null && e.getCause() instanceof BrandOneBPException) {
                return ((BrandOneBPException) e.getCause()).getErrorCodeAware();
            }
        }
        if(e.getCause() != null && e.getCause().getCause() != null){
            if(e.getCause().getCause() instanceof BrandOneBPException){
                return ((BrandOneBPException)e.getCause().getCause()).getErrorCodeAware();
            }
        }
        if (e instanceof SystemException) {
            SystemException systemException = (SystemException)e;
            if(Objects.equals(BaseErrorCode.REQ_LOCK_ERROR.getErrCode(),systemException.getErrorCode().getCodeValue())){
                return BrandOneBPBaseErrorCode.DISTLOCK;
            }
        }
        if (e instanceof IllegalArgumentException || e instanceof MissingServletRequestParameterException) {
            return BrandOneBPBaseErrorCode.PARAM_ILLEGAL.of(e.getMessage());
        }
        if (StringUtils.containsIgnoreCase(ExceptionUtils.getRootCauseMessage(e), BROKEN_PIPE)) {
            return BrandOneBPBaseErrorCode.INTERNAL_ERROR;
        }
        if (e instanceof HSFException) {
            return BrandOneBPBaseErrorCode.RPC_ERROR;
        }
        return BrandOneBPBaseErrorCode.INTERNAL_ERROR;
    }
}
