package com.taobao.ad.brand.bp.config;

import com.alibaba.abf.isolation.spec.annotation.AbilityInject;
import com.alibaba.abf.isolation.spec.common.ReduceType;
import com.taobao.ad.brand.bp.domain.sdk.account.atomability.*;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.*;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.frequency.IAdgroupFrequencyDateUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.frequency.IAdgroupFrequencyRefSaveAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.frequency.IAdgroupFrequencyValidateForBindAdgroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.query.IAdgroupBindCreativeQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.query.IAdgroupStructurePageQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.query.IAdgroupStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.realtime.*;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.targets.IAdgroupAlgoTaCrowdInitForAddAdgroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.targets.IAdgroupCrowdTargetInitForAddAdgroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.targets.IAdgroupCrowdTargetSupportJudgeAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.targets.IAdgroupCrowdTargetValidateForAddAdgroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.thirdmonitor.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.calculate.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.consistency.ICampaignBudgetConsistencyCheckAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.consistency.ICampaignCastDateConsistencyCheckAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.consistency.ICampaignCrowdConsistencyCheckAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.consistency.ICampaignPriceConsistencyCheckAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.frequency.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.inventory.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.keyword.ICampaignKeywordAccessValidateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.keyword.ICampaignKeywordInitAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.keyword.ICampaignKeywordNormalValidateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.keyword.ICampaignKeywordValidateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.keyword.ICampaignKeywordSaveAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.keyword.ICampaignKeywordValidateForUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.keyword.ICampaignRealTimeOptimizeKeywordInitForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignCrowdMapQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructurePageQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.realtime.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.showconfig.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.subcampaign.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.targets.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.thirdmonitor.ICampaignThirdMonitorClearAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.thirdmonitor.ICampaignThirdMonitorFillForQueryCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.thirdmonitor.ICampaignThirdMonitorNeedClearGetForSyncSaleGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.thirdmonitor.ICampaignThirdMonitorValidateForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.*;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.*;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.consistency.ICartItemCampaignCrowdConsistencyCheckAbility;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.consistency.ICartItemCampaignPriceConsistencyCheckAbility;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.orderjudge.*;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.*;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.query.ICreativeQueryParamResetAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.query.ICreativeStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.*;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.calculate.*;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.delivery.*;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.thirdmonitor.*;
import com.taobao.ad.brand.bp.domain.sdk.shopwindow.atomability.ISkuSspProductLineAuthJudgeAbility;
import com.taobao.ad.brand.bp.domain.sdk.solution.atomability.ISolutionCommandBaseValidateForSaveCartItemSolutionAbility;
import com.taobao.ad.brand.bp.domain.sdk.solution.atomability.ISolutionCommandInitForAddCartItemSolutionAbility;
import com.taobao.ad.brand.bp.domain.sdk.solution.atomability.ISolutionCommandInitForUpdateCartItemSolutionAbility;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.IMessageAsyncSendAbility;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.IMessageSyncSendAbility;
import org.springframework.context.annotation.Configuration;

/**
 * 原子能力统一注册（避免多Bean生成）
 */
@Configuration
public class AtomAbilityConfig {
    @AbilityInject(reduce = ReduceType.FIRST)
    IAccountAdcRoleGetAbility accountAdcRoleGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAccountJoinBizCodeGetAbility accountJoinBizCodeGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAccountMenuPermissionFlatAbility accountMenuPermissionFlatAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAccountMenuPermissionMergeAbility accountMenuPermissionMergeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAccountShopExistJudgeAbility accountShopExistJudgeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupAddAbility adgroupAddAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupAlgoControlCrowdAddAbility adgroupAlgoControlCrowdAddAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupAlgoControlCrowdDeleteAbility adgroupAlgoControlCrowdDeleteAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupAlgoTaCrowdInitForAddAdgroupAbility adgroupAlgoTaCrowdInitForAddAdgroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupBaseInfoInitForAddOrUpdateAbility adgroupBaseInfoInitForAddOrUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupBaseInitForAddBottomAdgroupAbility adgroupBaseInitForAddBottomAdgroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupBaseInitForUpdateBottomAdgroupAbility adgroupBaseInitForUpdateBottomAdgroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupBatchDeleteAbility adgroupBatchDeleteAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupBindCreativeQueryAbility adgroupBindCreativeQueryAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupBottomCrowdInitAbility adgroupBottomCrowdInitAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupBottomJudgeAbility adgroupBottomJudgeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupBottomTitleInitAbility adgroupBottomTitleInitAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupCountValidateForAddOrUpdateAbility adgroupCountValidateForAddOrUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupCreateRuleValidateForAddOrUpdateAbility adgroupCreateRuleValidateForAddOrUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupCrowdTargetInitForAddAdgroupAbility adgroupCrowdTargetInitForAddAdgroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupCrowdTargetSupportJudgeAbility adgroupCrowdTargetSupportJudgeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupCrowdTargetValidateForAddAdgroupAbility adgroupCrowdTargetValidateForAddAdgroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupDirectCreativeGenerateValidateAbility adgroupDirectCreativeGenerateValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupDirectCreativeJudgeAbility adgroupDirectCreativeJudgeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupFrequencyDateUpdateAbility adgroupFrequencyDateUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupFrequencyRefSaveAbility adgroupFrequencyRefSaveAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupFrequencyValidateForBindAdgroupAbility adgroupFrequencyValidateForBindAdgroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupInitForAddNReachAdgroupAbility adgroupInitForAddNReachAdgroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupInitForUpdateAbility adgroupInitForUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupInitForUpdateNReachAdgroupAbility adgroupInitForUpdateNReachAdgroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupNReachJudgeAbility adgroupNReachJudgeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupOnlineStatusUpdateValidateAbility adgroupOnlineStatusUpdateValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupPermissionDeleteValidateAbility adgroupPermissionDeleteValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupRealTimeOptimizeAlgoCrowdDeleteAbility adgroupRealTimeOptimizeAlgoCrowdDeleteAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupRealTimeOptimizeAlgoCrowdParamBuildAbility adgroupRealTimeOptimizeAlgoCrowdParamBuildAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupRealTimeOptimizeAlgoCrowdSaveAbility adgroupRealTimeOptimizeAlgoCrowdSaveAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupRealTimeOptimizeCrowdDeleteAbility adgroupRealTimeOptimizeCrowdDeleteAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupRealTimeOptimizeCrowdInitForAddOrUpdateAdgroupAbility adgroupRealTimeOptimizeCrowdInitForAddOrUpdateAdgroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupRealTimeOptimizeCrowdSaveAbility adgroupRealTimeOptimizeCrowdSaveAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupStatusOnlineValidateForAddOrUpdateAbility adgroupStatusOnlineValidateForAddOrUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupStructurePageQueryAbility adgroupStructurePageQueryAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupStructureQueryAbility adgroupStructureQueryAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupThirdMonitorClearAbility adgroupThirdMonitorClearAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupThirdMonitorInitForAddAdgroupAbility adgroupThirdMonitorInitForAddAdgroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupThirdMonitorNeedClearGetForSyncSaleGroupAbility adgroupThirdMonitorNeedClearGetForSyncSaleGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupThirdMonitorUpdateAbility adgroupThirdMonitorUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupThirdMonitorValidateForAddAdgroupAbility adgroupThirdMonitorValidateForAddAdgroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupTitleValidateAbility adgroupTitleValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupUpdateAbility adgroupUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupWakeUpInitAbility adgroupWakeUpInitAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupWakeUpValidateForAddAbility adgroupWakeUpValidateForAddAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IAdgroupWakeUpValidateForUpdateAbility adgroupWakeUpValidateForUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignAddAbility campaignAddAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignAddPermissionJudgeAbility campaignAddPermissionJudgeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignAdvBalanceValidateAbility campaignAdvBalanceValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignAdvEffectiveValidateForBindAbility campaignAdvEffectiveValidateForBindAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignAdvUniqueValidateForBindAbility campaignAdvUniqueValidateForBindAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignAdvUpdateForBindAbility campaignAdvUpdateForBindAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignAdvUpdateForUnBindAbility campaignAdvUpdateForUnBindAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignAdzoneBatchAddAbility campaignAdzoneBatchAddAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignAdzoneBatchUpdateAllAbility campaignAdzoneBatchUpdateAllAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignAdzoneInitForAddCampaignAbility campaignAdzoneInitForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignAdzoneInitForCrossSplitSubCampaignAbility campaignAdzoneInitForCrossSplitSubCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignAdzoneInitForUpdateCampaignAbility campaignAdzoneInitForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignAdzoneValidateForAddCampaignAbility campaignAdzoneValidateForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignAgeTargetBuildForShowConfigGetAbility campaignAgeTargetBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignAlgoControlCrowdAddAbility campaignAlgoControlCrowdAddAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignAlgoControlCrowdDeleteAbility campaignAlgoControlCrowdDeleteAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignAlgoControlCrowdInitForAddCrowdAbility campaignAlgoControlCrowdInitForAddCrowdAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignAlgoControlCrowdJudgeForAddOrUpdateCampaignAbility campaignAlgoControlCrowdJudgeForAddOrUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignAlgoTaCrowdInitForAddCampaignAbility campaignAlgoTaCrowdInitForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignAmountValidateForCampaignInventoryOperateAbility campaignAmountValidateForCampaignInventoryOperateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignAppVersionTargetBuildForShowConfigGetAbility campaignAppVersionTargetBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignAreaTargetBuildForShowConfigGetAbility campaignAreaTargetBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignAutoBuildForAutoAddCampaignAbility campaignAutoBuildForAutoAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignAutoSaveJudgeForAutoSaveCampaignAbility campaignAutoSaveJudgeForAutoSaveCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignAutoSaveAsyncNoticeJudgeForAutoSaveCampaignAbility campaignAutoSaveAsyncNoticeJudgeForAutoSaveCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignAutoLockJudgeForLockCampaignAbility campaignAutoLockJudgeForLockCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignBaseInitForAddCampaignAbility campaignBaseInitForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignBaseInitForCrossSplitSubCampaignAbility campaignBaseInitForCrossSplitSubCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignBaseInitForPricePeriodSplitSubCampaignAbility campaignBaseInitForPricePeriodSplitSubCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignBaseInitForUpdateCampaignAbility campaignBaseInitForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignBaseValidateForAddCampaignAbility campaignBaseValidateForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignBaseValidateForUpdateCampaignAbility campaignBaseValidateForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignBatchSwitchAbility campaignBatchSwitchAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignBindCampaignGroupAbility campaignBindCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignBoostCampaignDeleteValidateAbility campaignBoostCampaignDeleteValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignBoostInitForUpdateCampaignAbility campaignBoostInitForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignBoostUpdateForCampaignInventoryCallbackAbility campaignBoostUpdateForCampaignInventoryCallbackAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignBoostValidateForAddCampaignAbility campaignBoostValidateForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignBottomDateGetAbility campaignBottomDateGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignBottomDirectCreativeBuildAbility campaignBottomDirectCreativeBuildAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignBottomDirectCreativeRefBuildAbility campaignBottomDirectCreativeRefBuildAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignBottomSubCampaignGetAbility campaignBottomSubCampaignGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignBudgetAssignForCalculateAbility campaignBudgetAssignForCalculateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignBudgetConsistencyCheckAbility campaignBudgetConsistencyCheckAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignBudgetInitForAddCampaignAbility campaignBudgetInitForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignBudgetInitForCrossSplitSubCampaignAbility campaignBudgetInitForCrossSplitSubCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignBudgetInitForPricePeriodSplitSubCampaignAbility campaignBudgetInitForPricePeriodSplitSubCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignBudgetInitForUpdateCampaignAbility campaignBudgetInitForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignBudgetRatioInitForCalculateAbility campaignBudgetRatioInitForCalculateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignBudgetRatioResetForCalculateAbility campaignBudgetRatioResetForCalculateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignOperateDistLockGetAbility campaignOperateDistLockGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignBudgetResetForCalculateAbility campaignBudgetResetForCalculateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignBudgetValidateForAddCampaignAbility campaignBudgetValidateForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignBudgetValidateForResetCampaignBudgetAbility campaignBudgetValidateForResetCampaignBudgetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignBuildBPMSParamsForAutoReleaseDelayLockAbility campaignBuildBPMSParamsForAutoReleaseDelayLockAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignCalculateInfoResetAbility campaignCalculateInfoResetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignCastDateConsistencyCheckAbility campaignCastDateConsistencyCheckAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignCastDateUpdateAbility campaignCastDateUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignCastDateValidateForUpdateCastDateAbility campaignCastDateValidateForUpdateCastDateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignCastExpandBuildForShowConfigGetAbility campaignCastExpandBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignCastTypeQueryForShowConfigGetAbility campaignCastTypeQueryForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignCategoryTargetBuildForShowConfigGetAbility campaignCategoryTargetBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignCategoryTargetValidateForUpdateCampaignAbility campaignCategoryTargetValidateForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignCommandDiffForAutoSaveCampaignAbility campaignCommandDiffForAutoSaveCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignCopyForSplitSubCampaignAbility campaignCopyForSplitSubCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignCopyOtherPubDealBuildForShowConfigGetAbility campaignCopyOtherPubDealBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignCopyPubDealBuildForShowConfigGetAbility campaignCopyPubDealBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignCreativeControllerInitForAddCampaignAbility campaignCreativeControllerInitForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignCreativeControllerInitForUpdateCampaignAbility campaignCreativeControllerInitForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignCrossPriceValidateForCalculateCampaignAbility campaignCrossPriceValidateForCalculateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignCrowdConsistencyCheckAbility campaignCrowdConsistencyCheckAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignCrowdEstimateForCampaignInventoryOperateAbility campaignCrowdEstimateForCampaignInventoryOperateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignCrowdInitForCrossSplitSubCampaignAbility campaignCrowdInitForCrossSplitSubCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignCrowdInitForPricePeriodSplitSubCampaignAbility campaignCrowdInitForPricePeriodSplitSubCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignCrowdScoreTargetBuildForShowConfigGetAbility campaignCrowdScoreTargetBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignCrowdTargetBuildForShowConfigGetAbility campaignCrowdTargetBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignRecommendCrowdTargetBuildForShowConfigGetAbility campaignRecommendCrowdTargetBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignCrowdTargetInitForAddCampaignAbility campaignCrowdTargetInitForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignCrowdTargetInitForUpdateCampaignAbility campaignCrowdTargetInitForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignCrowdTargetValidateForAddCampaignAbility campaignCrowdTargetValidateForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignCrowdTargetValidateForOrderCampaignGroupAbility campaignCrowdTargetValidateForOrderCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignCrowdTargetValidateForUpdateCampaignAbility campaignCrowdTargetValidateForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignDeleteAbility campaignDeleteAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignDeviceTargetBuildForShowConfigGetAbility campaignDeviceTargetBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignDiscountResetForCalculateAbility campaignDiscountResetForCalculateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignDoohInitForUpdateCampaignAbility campaignDoohInitForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignDoohJsdDeviceTypeTargetBuildForShowConfigGetAbility campaignDoohJsdDeviceTypeTargetBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignDoohJsdStrategyMethodBuildForShowConfigGetAbility campaignDoohJsdStrategyMethodBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignDoohPushForAddCampaignAbility campaignDoohPushForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignDoohReleaseForCampaignInventoryOperateAbility campaignDoohReleaseForCampaignInventoryOperateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignDoohStrategyBuildForShowConfigGetAbility campaignDoohStrategyBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignDoohValidateAbility campaignDoohValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignDoohValidateForAddCampaignAbility campaignDoohValidateForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignDoohValidateForCampaignInventoryOperateAbility campaignDoohValidateForCampaignInventoryOperateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignDspBuildForShowConfigGetAbility campaignDspBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignErrorMsgBuildForCampaignInventoryCallbackAbility campaignErrorMsgBuildForCampaignInventoryCallbackAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignErrorMsgBuildForCampaignInventoryOperateAbility campaignErrorMsgBuildForCampaignInventoryOperateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignExtInitForAddCampaignAbility campaignExtInitForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignExtInitForUpdateCampaignAbility campaignExtInitForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignFilterForAutoReleaseDelayLockAbility campaignFilterForAutoReleaseDelayLockAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignFrequencyBuildForShowConfigGetAbility campaignFrequencyBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignFrequencyDateUpdateAbility campaignFrequencyDateUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignFrequencyFillForQueryCampaignAbility campaignFrequencyFillForQueryCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignFrequencyInitForAddCampaignAbility campaignFrequencyInitForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignFrequencyInitForUpdateCampaignAbility campaignFrequencyInitForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignFrequencyRefSaveAbility campaignFrequencyRefSaveAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignFrequencyValidateForAddCampaignAbility campaignFrequencyValidateForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignFrequencyValidateForBindCampaignAbility campaignFrequencyValidateForBindCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignFrequencyValidateForOrderCampaignGroupAbility campaignFrequencyValidateForOrderCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignFrequencyValidateForUpdateCampaignAbility campaignFrequencyValidateForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignFutureAmountAssignForCalculateCampaignAbility campaignFutureAmountAssignForCalculateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignFutureAmountCalculateAbility campaignFutureAmountCalculateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignFutureInquiryAssignForCalculateCampaignAbility campaignFutureInquiryAssignForCalculateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGenderTargetBuildForShowConfigGetAbility campaignGenderTargetBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupAddAbility campaignGroupAddAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupAddPurchaseOrderAbility campaignGroupAddPurchaseOrderAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupAutoEstimateSaleGroupGetForOrderAbility campaignGroupAutoEstimateSaleGroupGetForOrderAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupBaseInitForAddCampaignGroupAbility campaignGroupBaseInitForAddCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupBaseInitForOrderCampaignGroupAbility campaignGroupBaseInitForOrderCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupBaseInitForUpdateCampaignGroupAbility campaignGroupBaseInitForUpdateCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupBaseValidateForUpdateCampaignGroupAbility campaignGroupBaseValidateForUpdateCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupBoostStatusUpdateAbility campaignGroupBoostStatusUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupCalAutoCancelExpireTimeAbility campaignGroupCalAutoCancelExpireTimeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupCancelSendNoticeAbility campaignGroupCancelSendNoticeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupCancelWarningSendNoticeAbility campaignGroupCancelWarningSendNoticeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupCheckedSaleGroupRebuildForOrderCampaignGroupAbility campaignGroupCheckedSaleGroupRebuildForOrderCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupCompleteConfigInitForAddCampaignGroupAbility campaignGroupCompleteConfigInitForAddCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupCompleteConfigSaveAbility campaignGroupCompleteConfigSaveAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupCompleteConfigValidateForSaveCompleteConfigAbility campaignGroupCompleteConfigValidateForSaveCompleteConfigAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupContractCompleteBrandSyncForOrderAbility campaignGroupContractCompleteBrandSyncForOrderAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupContractInitForAddCampaignGroupAbility campaignGroupContractInitForAddCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupContractInitForOrderCampaignGroupAbility campaignGroupContractInitForOrderCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupContractInitForUpdateCampaignGroupAbility campaignGroupContractInitForUpdateCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupContractUpdateForCompleteCampaignGroupAbility campaignGroupContractUpdateForCompleteCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupContractUpdateForNoticeBriefEventAbility campaignGroupContractUpdateForNoticeBriefEventAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupContractUpdateForOnlineContractAbility campaignGroupContractUpdateForOnlineContractAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupContractUpdateForOrderCampaignGroupAbility campaignGroupContractUpdateForOrderCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupContractValidateForAddCampaignGroupAbility campaignGroupContractValidateForAddCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupContractWaitPaymentSendNoticeAbility campaignGroupContractWaitPaymentSendNoticeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupContractWaitSignSendNoticeAbility campaignGroupContractWaitSignSendNoticeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupCustomerInitForAddCampaignGroupAbility campaignGroupCustomerInitForAddCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupCustomerInitForOrderCampaignGroupAbility campaignGroupCustomerInitForOrderCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupCustomerValidateForAddCampaignGroupAbility campaignGroupCustomerValidateForAddCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupDateValidateForCompleteCampaignGroupAbility campaignGroupDateValidateForCompleteCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupDeleteAbility campaignGroupDeleteAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupEstimateResultWarningSendNoticeAbility campaignGroupEstimateResultWarningSendNoticeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupExtInitForAddCampaignGroupAbility campaignGroupExtInitForAddCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupGiveStatusUpdateAbility campaignGroupGiveStatusUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupInitForCancelAbility campaignGroupInitForCancelAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupInitForCartItemSolutionAddOrUpdateAbility campaignGroupInitForCartItemSolutionAddOrUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupInitForGenerateMainAbility campaignGroupInitForGenerateMainAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupInitForPreOrderCampaignGroupAbility campaignGroupInitForPreOrderCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupInitForSplitSubCampaignGroupAbility campaignGroupInitForSplitSubCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupInquiryInfoUpdateAbility campaignGroupInquiryInfoUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupInquiryInitForAddCampaignGroupAbility campaignGroupInquiryInitForAddCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupInquiryPurchaseOrderUpdateAbility campaignGroupInquiryPurchaseOrderUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupJudgeForFinishCampaignGroupAbility campaignGroupJudgeForFinishCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupJudgeForFinishRevertCampaignGroupAbility campaignGroupJudgeForFinishRevertCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupJudgeForOrderCampaignGroupAbility campaignGroupJudgeForOrderCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupJudgeForResourceConfirmAbility campaignGroupJudgeForResourceConfirmAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupMediaInquiryOrderUpdateAbility campaignGroupMediaInquiryOrderUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupMessageAsyncSendAbility campaignGroupMessageAsyncSendAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupModifyBriefAbility campaignGroupModifyBriefAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupNameValidateAbility campaignGroupNameValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupOrderInitForAddCampaignGroupAbility campaignGroupOrderInitForAddCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupOrderInitForOrderCampaignGroupAbility campaignGroupOrderInitForOrderCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupOrderSendNoticeAbility campaignGroupOrderSendNoticeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupParentUpdateAbility campaignGroupParentUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupPurchaseOrderJudgeAbility campaignGroupPurchaseOrderJudgeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupPurchaseOrderUpdateAbility campaignGroupPurchaseOrderUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupRealSettleApplyProcessInstanceForSaveAbility campaignGroupRealSettleApplyProcessInstanceForSaveAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupRealSettleInitForSaveAbility campaignGroupRealSettleInitForSaveAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupRealSettleSaveAbility campaignGroupRealSettleSaveAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupRealSettleValidateForSaveAbility campaignGroupRealSettleValidateForSaveAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupSaleGroupBuildForSyncSubCampaignGroupAbility campaignGroupSaleGroupBuildForSyncSubCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupSaleGroupEstimateValidateForOrderAbility campaignGroupSaleGroupEstimateValidateForOrderAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupSaleGroupInitForModifyAbility campaignGroupSaleGroupInitForModifyAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupSaleGroupInitForUpdateCampaignGroupAbility campaignGroupSaleGroupInitForUpdateCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupSaleGroupInitForUpdateCheckedResourceAbility campaignGroupSaleGroupInitForUpdateCheckedResourceAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupSaleGroupValidateForAddOrUpdateCampaignGroupAbility campaignGroupSaleGroupValidateForAddOrUpdateCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupSaleInitForAddCampaignGroupAbility campaignGroupSaleInitForAddCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupSaleInitForUpdateCampaignGroupAbility campaignGroupSaleInitForUpdateCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupSaleValidateForAddOrUpdateCampaignGroupAbility campaignGroupSaleValidateForAddOrUpdateCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupStartApplyModifyProcessAbility campaignGroupStartApplyModifyProcessAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupStatusRebuildForOrderCampaignGroupAbility campaignGroupStatusRebuildForOrderCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupStatusUpdateAbility campaignGroupStatusUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupStatusValidateForApplyModifyAbility campaignGroupStatusValidateForApplyModifyAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupStatusValidateForBindAdvAbility campaignGroupStatusValidateForBindAdvAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupStatusValidateForUnBindAdvAbility campaignGroupStatusValidateForUnBindAdvAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupStopTimeUpdateForStopCastCampaignGroupAbility campaignGroupStopTimeUpdateForStopCastCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupSyncBriefForFinishCampaignGroupAbility campaignGroupSyncBriefForFinishCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupSyncBriefForFinishRevertCampaignGroupAbility campaignGroupSyncBriefForFinishRevertCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupSyncBriefForOrderCampaignGroupAbility campaignGroupSyncBriefForOrderCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupUnlockInitForApplyModifyAbility campaignGroupUnlockInitForApplyModifyAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupUnlockUpdateAbility campaignGroupUnlockUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupUpdateAbility campaignGroupUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupUpdateCheckedResourceAbility campaignGroupUpdateCheckedResourceAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupUpdateForUnlockRevertAbility campaignGroupUpdateForUnlockRevertAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupValidateForApplyModifyAbility campaignGroupValidateForApplyModifyAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupValidateForCancelAbility campaignGroupValidateForCancelAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupValidateForDeleteAbility campaignGroupValidateForDeleteAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupValidateForFinishCampaignGroupAbility campaignGroupValidateForFinishCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupValidateForFinishRevertCampaignGroupAbility campaignGroupValidateForFinishRevertCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupValidateForUnlockRevertAbility campaignGroupValidateForUnlockRevertAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupWakeupInitForAddCampaignGroupAbility campaignGroupWakeupInitForAddCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupWakeupInitForUpdateCheckedResourceAbility campaignGroupWakeupInitForUpdateCheckedResourceAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGroupWakeupValidateForUpdateCheckedResourceAbility campaignGroupWakeupValidateForUpdateCheckedResourceAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGuaranteeInitForAddCampaignAbility campaignGuaranteeInitForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGuaranteeInitForCopySplitSubCampaignAbility campaignGuaranteeInitForCopySplitSubCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGuaranteeInitForCrossSplitSubCampaignAbility campaignGuaranteeInitForCrossSplitSubCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGuaranteeInitForPricePeriodSplitSubCampaignAbility campaignGuaranteeInitForPricePeriodSplitSubCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGuaranteeInitForUpdateCampaignAbility campaignGuaranteeInitForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGuaranteeValidateForAddCampaignAbility campaignGuaranteeValidateForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignGuaranteeValidateForUpdateCampaignAbility campaignGuaranteeValidateForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignHistoryBudgetResetForCalculateAbility campaignHistoryBudgetResetForCalculateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignHistoryBudgetResetValidateForCalculateAbility campaignHistoryBudgetResetValidateForCalculateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignHistoryBudgetValidateForCalculateCampaignAbility campaignHistoryBudgetValidateForCalculateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignIllegalFilterForCampaignInventoryOperateAbility campaignIllegalFilterForCampaignInventoryOperateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignInitForCalculateCampaignAbility campaignInitForCalculateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignInitForOnlineCampaignAbility campaignInitForOnlineCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignInitForUpdateCastDateAbility campaignInitForUpdateCastDateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignInquiryAmountAutoAssignForCalculateCampaignAbility campaignInquiryAmountAutoAssignForCalculateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignInquiryAmountEqualsValidateAbility campaignInquiryAmountEqualsValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignInquiryAmountValidateForCalculateCampaignAbility campaignInquiryAmountValidateForCalculateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignInquiryChannelGetForCampaignInventoryOperateAbility campaignInquiryChannelGetForCampaignInventoryOperateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignInquiryLockBatchUpdateAbility campaignInquiryLockBatchUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignInquiryLockBuildForUpdateCampaignScheduleAbility campaignInquiryLockBuildForUpdateCampaignScheduleAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignInquiryLockDeleteValidateAbility campaignInquiryLockDeleteValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignInquiryLockInitForAddCampaignAbility campaignInquiryLockInitForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignInquiryLockInitForCrossSplitSubCampaignAbility campaignInquiryLockInitForCrossSplitSubCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignInquiryLockInitForPricePeriodSplitSubCampaignAbility campaignInquiryLockInitForPricePeriodSplitSubCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignInquiryLockInitForUpdateCampaignAbility campaignInquiryLockInitForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignInventoryAutoReleaseWarningBuildAbility campaignInventoryAutoReleaseWarningBuildAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignInventoryBottomGetAbility campaignInventoryBottomGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignInventoryMandatoryLockProcessParamBuildAbility campaignInventoryMandatoryLockProcessParamBuildAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignInventoryResponseDealForCampaignInventoryCallbackAbility campaignInventoryResponseDealForCampaignInventoryCallbackAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignInventoryResponseParentSummaryForCampaignInventoryCallbackAbility campaignInventoryResponseParentSummaryForCampaignInventoryCallbackAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignInventoryResponseParseForCampaignInventoryCallbackAbility campaignInventoryResponseParseForCampaignInventoryCallbackAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignInventoryResponseValidateForCampaignInventoryCallbackAbility campaignInventoryResponseValidateForCampaignInventoryCallbackAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignInventoryRpcInvokeAbility campaignInventoryRpcInvokeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignItemIdValidateForUpdateCampaignAbility campaignItemIdValidateForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignKeywordAccessValidateAbility campaignKeywordAccessValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignKeywordInitAbility campaignKeywordInitAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignKeywordNormalValidateAbility campaignKeywordNormalValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignKeywordValidateAbility campaignKeywordValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignKeywordSaveAbility campaignKeywordSaveAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignKeywordTargetBuildForShowConfigGetAbility campaignKeywordTargetBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignKeywordValidateForUpdateAbility campaignKeywordValidateForUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignLockExpireTimeCalculateAbility campaignLockExpireTimeCalculateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignLockExpireTimeRecalculateAbility campaignLockExpireTimeRecalculateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignMediaAreaTargetBuildForShowConfigGetAbility campaignMediaAreaTargetBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignMediaCrowdTargetBuildForShowConfigGetAbility campaignMediaCrowdTargetBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignMediaDeviceTargetBuildForShowConfigGetAbility campaignMediaDeviceTargetBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignMediaFrequencyBuildForShowConfigGetAbility campaignMediaFrequencyBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignMediaInterestLabelTargetBuildForShowConfigGetAbility campaignMediaInterestLabelTargetBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignMediaInventoryLockExpireTimeCalculateAbility campaignMediaInventoryLockExpireTimeCalculateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignMediaPositionTargetBuildForShowConfigGetAbility campaignMediaPositionTargetBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignMediaTimePeriodTargetBuildForShowConfigGetAbility campaignMediaTimePeriodTargetBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignMediaTimePlusTargetValidateForUpdateCampaignAbility campaignMediaTimePlusTargetValidateForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignModelTargetBuildForShowConfigGetAbility campaignModelTargetBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignMonitorInitForAddCampaignAbility campaignMonitorInitForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignMonitorInitForUpdateCampaignAbility campaignMonitorInitForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignMultiMediaTargetBuildForShowConfigGetAbility campaignMultiMediaTargetBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignMultiMediaTargetInitForUpdateCampaignAbility campaignMultiMediaTargetInitForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignMultiMediaTargetValidateForAddCampaignAbility campaignMultiMediaTargetValidateForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignMultiMediaTargetValidateForUpdateCampaignAbility campaignMultiMediaTargetValidateForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignNoInventoryScheduleResultSetForCampaignInventoryOperateAbility campaignNoInventoryScheduleResultSetForCampaignInventoryOperateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignOnlineStatusUpdateAbility campaignOnlineStatusUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignOohJsdIndustryTargetBuildForShowConfigGetAbility campaignOohJsdIndustryTargetBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignOohJsdOptimizedTargetBuildForShowConfigGetAbility campaignOohJsdOptimizedTargetBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignOptimizeTargetTypeBuildForShowConfigGetAbility campaignOptimizeTargetTypeBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignPdCastTypeBuildForShowConfigGetAbility campaignPdCastTypeBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignPdbCastTypeBuildForShowConfigGetAbility campaignPdbCastTypeBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignPermissionBatchDeleteValidateAbility campaignPermissionBatchDeleteValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignPermissionDeleteValidateAbility campaignPermissionDeleteValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignPrecedenceTargetBuildForShowConfigGetAbility campaignPrecedenceTargetBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignPriceBuildForCalculateCampaignAbility campaignPriceBuildForCalculateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignPriceConsistencyCheckAbility campaignPriceConsistencyCheckAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignPriceInitForAddCampaignAbility campaignPriceInitForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignPriceInitForAssignBudgetAbility campaignPriceInitForAssignBudgetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignPriceInitForCalculateCampaignAbility campaignPriceInitForCalculateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignPriceInitForCrossSplitSubCampaignAbility campaignPriceInitForCrossSplitSubCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignPriceInitForPricePeriodSplitSubCampaignAbility campaignPriceInitForPricePeriodSplitSubCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignPriceInitForUpdateCampaignAbility campaignPriceInitForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignPriceResetForCalculateAbility campaignPriceResetForCalculateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignPriceRuleValidateForCalculateAbility campaignPriceRuleValidateForCalculateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignPvAssignForCalculateAbility campaignPvAssignForCalculateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignPvBudgetAndAmountAssignForCalculateAbility campaignPvBudgetAndAmountAssignForCalculateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignReAssignParentScheduleJudgeForUpdateCampaignSchemaAbility campaignReAssignParentScheduleJudgeForUpdateCampaignSchemaAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignRealTimeAlgoControlCrowdJudgeForAddOrUpdateCampaignAbility campaignRealTimeAlgoControlCrowdJudgeForAddOrUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignRealTimeOptimizeAlgoCrowdDeleteAbility campaignRealTimeOptimizeAlgoCrowdDeleteAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignRealTimeOptimizeAlgoCrowdSaveAbility campaignRealTimeOptimizeAlgoCrowdSaveAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignRealTimeOptimizeCategoryInitAbility campaignRealTimeOptimizeCategoryInitAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignRealTimeOptimizeCategoryInitForUpdateCampaignAbility campaignRealTimeOptimizeCategoryInitForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignRealTimeOptimizeCategorySaveAbility campaignRealTimeOptimizeCategorySaveAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignRealTimeOptimizeCategoryValidateAbility campaignRealTimeOptimizeCategoryValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignRealTimeOptimizeConfigInitAbility campaignRealTimeOptimizeConfigInitAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignRealTimeOptimizeConfigInitForAddCampaignAbility campaignRealTimeOptimizeConfigInitForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignRealTimeOptimizeConfigInitForUpdateCampaignAbility campaignRealTimeOptimizeConfigInitForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignRealTimeOptimizeConfigSaveAbility campaignRealTimeOptimizeConfigSaveAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignRealTimeOptimizeConfigValidateAbility campaignRealTimeOptimizeConfigValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignRealTimeOptimizeCrowdInitForUpdateCampaignAbility campaignRealTimeOptimizeCrowdInitForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignRealTimeOptimizeCrowdSaveAbility campaignRealTimeOptimizeCrowdSaveAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignRealTimeOptimizeKeywordInitForUpdateCampaignAbility campaignRealTimeOptimizeKeywordInitForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignRealTimeOptimizeSwitchInitForAddCampaignAbility campaignRealTimeOptimizeSwitchInitForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignRealTimeOptimizeSwitchInitForUpdateCampaignAbility campaignRealTimeOptimizeSwitchInitForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignRealTimeOptimizeSwitchValidateForSaveOptimizeAbility campaignRealTimeOptimizeSwitchValidateForSaveOptimizeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignRealTimeOptimizeValidateForAddBlockCrowdAbility campaignRealTimeOptimizeValidateForAddBlockCrowdAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignRealTimeOptimizeValidateForAddCrowdAbility campaignRealTimeOptimizeValidateForAddCrowdAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignRebuildParentCampaignScheduleAbility campaignRebuildParentCampaignScheduleAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignResourceInitForAddCampaignAbility campaignResourceInitForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignResourceInitForCrossSplitSubCampaignAbility campaignResourceInitForCrossSplitSubCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignResourceInitForUpdateCampaignAbility campaignResourceInitForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignRightsValidateForAddOrUpdateCampaignAbility campaignRightsValidateForAddOrUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignResourcePriceValidateForCalculateCampaignAbility campaignResourcePriceValidateForCalculateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignSafeIpInitAbility campaignSafeIpInitAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignSaleInitForAddCampaignAbility campaignSaleInitForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignSaleInitForCrossSplitSubCampaignAbility campaignSaleInitForCrossSplitSubCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignSaleInitForUpdateCampaignAbility campaignSaleInitForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignSaleUnitBuildForShowConfigGetAbility campaignSaleUnitBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignSaleValidateForAddCampaignAbility campaignSaleValidateForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignScheduleBuildForCampaignInventoryCallbackAbility campaignScheduleBuildForCampaignInventoryCallbackAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignScheduleBuildForCampaignInventoryOperateAbility campaignScheduleBuildForCampaignInventoryOperateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignScheduleCalculateAbility campaignScheduleCalculateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignScheduleFutureInquiryAssignAbility campaignScheduleFutureInquiryAssignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignScheduleResetAbility campaignScheduleResetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignScheduleScrollBuildAbility campaignScheduleScrollBuildAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignScheduleScrollUpdateAbility campaignScheduleScrollUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignScheduleUpdateAbility campaignScheduleUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignScheduleValidateAbility campaignScheduleValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignScrollInitForAddCampaignAbility campaignScrollInitForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignScrollInitForCrossSplitSubCampaignAbility campaignScrollInitForCrossSplitSubCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignScrollInitForPricePeriodSplitSubCampaignAbility campaignScrollInitForPricePeriodSplitSubCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignScrollInitForUpdateCampaignAbility campaignScrollInitForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignSelfServiceInitForUpdateCampaignAbility campaignSelfServiceInitForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignSelfServiceValidateForAddCampaignAbility campaignSelfServiceValidateForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignSellerValidateForCalculateCampaignAbility campaignSellerValidateForCalculateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignSessionFilterInitForCampaignAbility campaignSessionFilterInitForCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignShowmaxCrowdGetAbility campaignShowmaxCrowdGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignShowmaxCrowdTagGetAbility campaignShowmaxCrowdTagGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignSingleMediaMarkingBoostBudgetValidateForCalculateCampaignAbility campaignSingleMediaMarkingBoostBudgetValidateForCalculateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignSmartReservedDeleteValidateAbility campaignSmartReservedDeleteValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignSmartReservedInitForAddCampaignAbility campaignSmartReservedInitForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignSmartReservedInitForUpdateCampaignAbility campaignSmartReservedInitForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignSmartReservedValidateForAddCampaignAbility campaignSmartReservedValidateForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignSmartReservedValidateForUpdateCampaignAbility campaignSmartReservedValidateForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignSmoothInitForAddCampaignAbility campaignSmoothInitForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignSmoothInitForUpdateCampaignAbility campaignSmoothInitForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignSplashAdSeqTargetBuildForShowConfigGetAbility campaignSplashAdSeqTargetBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignSplitSubCheckForUpdateCastDateAbility campaignSplitSubCheckForUpdateCastDateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignStatusConvertForCampaignInventoryOperateAbility campaignStatusConvertForCampaignInventoryOperateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignStatusDeleteValidateAbility campaignStatusDeleteValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignStatusResetForCalculateAbility campaignStatusResetForCalculateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignStatusValidateForCampaignInventoryOperateAbility campaignStatusValidateForCampaignInventoryOperateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignStatusValidateForUpdateCampaignAbility campaignStatusValidateForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignStopForInventoryReleaseAbility campaignStopForInventoryReleaseAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignStructurePageQueryAbility campaignStructurePageQueryAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignStructureQueryAbility campaignStructureQueryAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignCrowdMapQueryAbility campaignCrowdMapQueryAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignTaCrowdValidateForAddCampaignAbility campaignTaCrowdValidateForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignTaoOutCptBuildForShowConfigGetAbility campaignTaoOutCptBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignCompetExcludeBuildForShowConfigGetAbility campaignCompetExcludeBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignTargetInitForCrossSplitSubCampaignAbility campaignTargetInitForCrossSplitSubCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignTargetValidateForUpdateCampaignTargetAbility campaignTargetValidateForUpdateCampaignTargetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignThirdMonitorBuildForShowConfigGetAbility campaignThirdMonitorBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignThirdMonitorClearAbility campaignThirdMonitorClearAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignThirdMonitorFillForQueryCampaignAbility campaignThirdMonitorFillForQueryCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignThirdMonitorNeedClearGetForSyncSaleGroupAbility campaignThirdMonitorNeedClearGetForSyncSaleGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignThirdMonitorValidateForAddCampaignAbility campaignThirdMonitorValidateForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignTimeLengthTargetBuildForShowConfigGetAbility campaignTimeLengthTargetBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignTimePeriodTargetBuildForShowConfigGetAbility campaignTimePeriodTargetBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignTimePlusTargetValidateForUpdateCampaignAbility campaignTimePlusTargetValidateForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignTitleInitAbility campaignTitleInitAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignTitleValidateAbility campaignTitleValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignTwoCptBudgetValidateForCalculateCampaignAbility campaignTwoCptBudgetValidateForCalculateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignUaTargetBuildForShowConfigGetAbility campaignUaTargetBuildForShowConfigGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignUnbindForCartItemSolutionDeleteAbility campaignUnbindForCartItemSolutionDeleteAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignUnionControlFlowInitForAddCampaignAbility campaignUnionControlFlowInitForAddCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignUnionControlForOnlineCampaignAbility campaignUnionControlForOnlineCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignUnionSettlePriceValidateForCalculateCampaignAbility campaignUnionSettlePriceValidateForCalculateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignUpdateAllAbility campaignUpdateAllAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignUpdateForAutoReleaseDelayLockProcessAbility campaignUpdateForAutoReleaseDelayLockProcessAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignUpdateForCampaignInventoryOperateAbility campaignUpdateForCampaignInventoryOperateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignUpdateJudgeForUpdateCampaignAbility campaignUpdateJudgeForUpdateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignUpdatePartAbility campaignUpdatePartAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignValidateForAutoReleaseDelayLockAbility campaignValidateForAutoReleaseDelayLockAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignValidateForAutoReleaseDelayLockProcessAbility campaignValidateForAutoReleaseDelayLockProcessAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignValidateForBindAdvAbility campaignValidateForBindAdvAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignValidateForCalculateCampaignAbility campaignValidateForCalculateCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignValidateForDeleteCampaignGroupAbility campaignValidateForDeleteCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignValidateForOrderCampaignGroupAbility campaignValidateForOrderCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignValidateForPreOrderCampaignGroupAbility campaignValidateForPreOrderCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignValidateForSwitchCampaignAbility campaignValidateForSwitchCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICampaignValidateForUnBindAdvAbility campaignValidateForUnBindAdvAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICartItemAdDateJudgeAbility cartItemAdDateJudgeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICartItemAdTotalBudgetJudgeAbility cartItemAdTotalBudgetJudgeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICartItemBaseValidateForAddCartItemAbility cartItemBaseValidateForAddCartItemAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICartItemBindCampaignGroupAbility cartItemBindCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICartItemCampaignCrowdConsistencyCheckAbility cartItemCampaignCrowdConsistencyCheckAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICartItemCampaignInquiryTimeCheckForCartItemOrderAbility cartItemCampaignInquiryTimeCheckForCartItemOrderAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICartItemCampaignPriceConsistencyCheckAbility cartItemCampaignPriceConsistencyCheckAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICartItemCampaignStatusCheckForCartItemOrderAbility cartItemCampaignStatusCheckForCartItemOrderAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICartItemConsistencyCheckForCartItemOrderAbility cartItemConsistencyCheckForCartItemOrderAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICartItemCustomerJudgeAbility cartItemCustomerJudgeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICartItemDeleteJudgeAbility cartItemDeleteJudgeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICartItemInitForAddCartItemAbility cartItemInitForAddCartItemAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICartItemSkuOnlineCheckForCartItemOrderAbility cartItemSkuOnlineCheckForCartItemOrderAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICartItemSkuStatusValidateForAddCartItemAbility cartItemSkuStatusValidateForAddCartItemAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICartItemStartBudgetCheckForCartItemOrderAbility cartItemStartBudgetCheckForCartItemOrderAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICartItemUniqueValidateForAddCartItemAbility cartItemUniqueValidateForAddCartItemAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeCustomerCategoryFillAbility creativeCustomerCategoryFillAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeElementSecondProcessAbilityForAddCreative creativeElementSecondProcessAbilityForAddCreative;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeLandingPageValidateAbility creativeLandingPageValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeMalusBaseConvertForConvertCreativeAbility creativeMalusBaseConvertForConvertCreativeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeMalusConvergeElementConvertForConvertCreativeAbility creativeMalusConvergeElementConvertForConvertCreativeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeMalusConvergeElementGetForConvertCreativeAbility creativeMalusConvergeElementGetForConvertCreativeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeMalusInitForConvertCreativeAbility creativeMalusInitForConvertCreativeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeMalusTemplateElementDefaultValueInitForConvertCreativeAbility creativeMalusTemplateElementDefaultValueInitForConvertCreativeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeMalusTemplateElementMaterialGroupConvertAbility creativeMalusTemplateElementMaterialGroupConvertAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeMalusTemplateStaticElementConvertForConvertCreativeAbility creativeMalusTemplateStaticElementConvertForConvertCreativeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeMalusTemplateValidateForConvertCreativeAbility creativeMalusTemplateValidateForConvertCreativeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeNameInitAbility creativeNameInitAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeOfflineValidateAbility creativeOfflineValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeQueryParamResetAbility creativeQueryParamResetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeRefAdgroupMixDateValidateAbility creativeRefAdgroupMixDateValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeRefBatchOperateValidateAbility creativeRefBatchOperateValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeRefCreativeBottomDateValidateAbility creativeRefCreativeBottomDateValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeRefCreativeCastDateValidateAbility creativeRefCreativeCastDateValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeRefCreativeCountValidateAbility creativeRefCreativeCountValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeRefCreativeDealValidateAbility creativeRefCreativeDealValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeRefCreativeDurationValidateAbility creativeRefCreativeDurationValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeRefCreativeSchemaValidateAbility creativeRefCreativeSchemaValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeRefCreativeStatusValidateAbility creativeRefCreativeStatusValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeRefCreativeTemplateValidateAbility creativeRefCreativeTemplateValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeRefCrossOpaqueCreativeBindValidateAbility creativeRefCrossOpaqueCreativeBindValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeRefDoohCreativeValidateAbility creativeRefDoohCreativeValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeRefTopCreativeValidateAbility creativeRefTopCreativeValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeRejectMessageSendAbility creativeRejectMessageSendAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeRejectMessageSendJudgeAbility creativeRejectMessageSendJudgeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeSmartItemGetAbility creativeSmartItemGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeSmartMaterialCropAbility creativeSmartMaterialCropAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeSmartMaterialCropCallbackValidateAbility creativeSmartMaterialCropCallbackValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeSmartMaterialCropSuccessJudgeAbility creativeSmartMaterialCropSuccessJudgeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeSmartMaterialCropValidateAbility creativeSmartMaterialCropValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeSmartMaterialMainImageGetAbility creativeSmartMaterialMainImageGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeSmartSubCreativeGenerateJudgeAbility creativeSmartSubCreativeGenerateJudgeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeStructureQueryAbility creativeStructureQueryAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeTemplateValidateAbility creativeTemplateValidateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ICreativeUpdateElementGetAbility creativeUpdateElementGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IDoohCreativeBindForAdgroupUpdateAbility doohCreativeBindForAdgroupUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IDoohCreativeInitForAdgroupUpdateAbility doohCreativeInitForAdgroupUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IMessageAsyncSendAbility messageAsyncSendAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IMessageSyncSendAbility messageSyncSendAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    IResourcePackageSaleGroupGoalSceneGetAbility resourcePackageSaleGroupGoalSceneGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupApplyInfoInitForApplySaleGroupAbility saleGroupApplyInfoInitForApplySaleGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupApplyInfoInitForUpdateSaleGroupAbility saleGroupApplyInfoInitForUpdateSaleGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupApplyInfoSaveForApplySaleGroupAbility saleGroupApplyInfoSaveForApplySaleGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupApplyInfoSaveForDeleteSaleGroupAbility saleGroupApplyInfoSaveForDeleteSaleGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupApplyInfoValidateForApplySaleGroupAbility saleGroupApplyInfoValidateForApplySaleGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupApplyInfoValidateForDeleteSaleGroupAbility saleGroupApplyInfoValidateForDeleteSaleGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupApplyInfoValidateForUpdateSaleGroupAbility saleGroupApplyInfoValidateForUpdateSaleGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupAssignForCalculateAbility saleGroupAssignForCalculateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupBudgetSettingTypeForUpdateAbility saleGroupBudgetSettingTypeForUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupCrowdInitForUpdateSaleGroupAbility saleGroupCrowdInitForUpdateSaleGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupCrowdQueryAbility saleGroupCrowdQueryAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupDeleteAbility saleGroupDeleteAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupDeliveryTargetInitForAddSaleGroupAbility saleGroupDeliveryTargetInitForAddSaleGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupDeliveryTargetInitForSyncSaleGroupAbility saleGroupDeliveryTargetInitForSyncSaleGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupDeliveryTargetUpdateJudgeAbility saleGroupDeliveryTargetUpdateJudgeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupDiffForNoticeSaleGroupAbility saleGroupDiffForNoticeSaleGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupDiffForUpdateCampaignGroupAbility saleGroupDiffForUpdateCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupEstimateCampaignValidateForSaleGroupEstimateAbility saleGroupEstimateCampaignValidateForSaleGroupEstimateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupEstimateInvokeForSaleGroupEstimateAbility saleGroupEstimateInvokeForSaleGroupEstimateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupEstimateJudgeForCartItemSolutionPreOrderAbility saleGroupEstimateJudgeForCartItemSolutionPreOrderAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupEstimateParamBuildForSaleGroupEstimateAbility saleGroupEstimateParamBuildForSaleGroupEstimateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupEstimateParamValidateForSaleGroupEstimateAbility saleGroupEstimateParamValidateForSaleGroupEstimateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupEstimateResultClearForSaleGroupEstimateAbility saleGroupEstimateResultClearForSaleGroupEstimateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupEstimateResultProcessForSaleGroupEstimateAbility saleGroupEstimateResultProcessForSaleGroupEstimateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupEstimateResultRebuildAbility saleGroupEstimateResultRebuildAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupEstimateResultSaveForSaleGroupEstimateAbility saleGroupEstimateResultSaveForSaleGroupEstimateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupEstimateResultWarnSendMessageAbility saleGroupEstimateResultWarnSendMessageAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupGetForDiffCampaignAbility saleGroupGetForDiffCampaignAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupGoalSceneGetAbility saleGroupGoalSceneGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupGoalSettingFillForUpdateGoalSettingAbility saleGroupGoalSettingFillForUpdateGoalSettingAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupGoalSettingInitForUpdateGoalSettingAbility saleGroupGoalSettingInitForUpdateGoalSettingAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupGoalSettingValidateForUpdateGoalSettingAbility saleGroupGoalSettingValidateForUpdateGoalSettingAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupInitForAddAbility saleGroupInitForAddAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupInitForDeleteAbility saleGroupInitForDeleteAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupInitForOrderCampaignGroupAbility saleGroupInitForOrderCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupInitForUpdateAbility saleGroupInitForUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupInquiryInfoUpdateForNoticeSaleGroupAbility saleGroupInquiryInfoUpdateForNoticeSaleGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupOperateDistLockGetAbility saleGroupOperateDistLockGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupOptimizeTargetInitForSyncSaleGroupAbility saleGroupOptimizeTargetInitForSyncSaleGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupOptimizeTargetUpdateJudgeAbility saleGroupOptimizeTargetUpdateJudgeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupPackageProductCalculateInfoInitAbility saleGroupPackageProductCalculateInfoInitAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupPriceUpdatedSaleGroupIdGetAbility saleGroupPriceUpdatedSaleGroupIdGetAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupProductBudgetAssignForCalculateAbility saleGroupProductBudgetAssignForCalculateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupProductBudgetAssignValidateForCalculateAbility saleGroupProductBudgetAssignValidateForCalculateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupProductValidateForCalculateAbility saleGroupProductValidateForCalculateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupProductValidateForOrderCampaignGroupAbility saleGroupProductValidateForOrderCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupPvAssignForCalculateAbility saleGroupPvAssignForCalculateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupPvBudgetForCalculateUpdateSaleGroupAbility saleGroupPvBudgetForCalculateUpdateSaleGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupResourceCategoryBudgetAssignForCalculateAbility saleGroupResourceCategoryBudgetAssignForCalculateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupSelectJudgeForApplyModifyCampaignGroupAbility saleGroupSelectJudgeForApplyModifyCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupSelectJudgeForOrderCampaignGroupAbility saleGroupSelectJudgeForOrderCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupStatusUpdateAbility saleGroupStatusUpdateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupStatusValidateForUpdateSaleGroupAbility saleGroupStatusValidateForUpdateSaleGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupSubContractBindAbility saleGroupSubContractBindAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupSubmitForApplySaleGroupAbility saleGroupSubmitForApplySaleGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupThirdMonitorClearAbility saleGroupThirdMonitorClearAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupThirdMonitorNeedClearGetForSyncSaleGroupAbility saleGroupThirdMonitorNeedClearGetForSyncSaleGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupThirdMonitorSaveForUpdateThirdMonitorAbility saleGroupThirdMonitorSaveForUpdateThirdMonitorAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupThirdMonitorUpdateValidateForSyncSaleGroupAbility saleGroupThirdMonitorUpdateValidateForSyncSaleGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupThirdMonitorValidateForUpdateThirdMonitorAbility saleGroupThirdMonitorValidateForUpdateThirdMonitorAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupValidateForApplyModifyCampaignGroupAbility saleGroupValidateForApplyModifyCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupValidateForCalculateAbility saleGroupValidateForCalculateAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupValidateForDeleteAbility saleGroupValidateForDeleteAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupValidateForOrderCampaignGroupAbility saleGroupValidateForOrderCampaignGroupAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISaleGroupValidateForUpdateCheckedResourceAbility saleGroupValidateForUpdateCheckedResourceAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISkuSspProductLineAuthJudgeAbility skuSspProductLineAuthJudgeAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISolutionCommandBaseValidateForSaveCartItemSolutionAbility solutionCommandBaseValidateForSaveCartItemSolutionAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISolutionCommandInitForAddCartItemSolutionAbility solutionCommandInitForAddCartItemSolutionAbility;
    @AbilityInject(reduce = ReduceType.FIRST)
    ISolutionCommandInitForUpdateCartItemSolutionAbility solutionCommandInitForUpdateCartItemSolutionAbility;
}
