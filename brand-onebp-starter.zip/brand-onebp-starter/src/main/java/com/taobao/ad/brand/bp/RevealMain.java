package com.taobao.ad.brand.bp;

/**
 * @author home3k (sk153869@alibaba-inc.com)
 * @date 2020/03/05
 */
public class RevealMain {

//    public static void main(String[] args) {
//        PandoraBootstrap.run(args);
//        RevealTool.main(args);
//        PandoraBootstrap.markStartupAndWait();
//    }
}
