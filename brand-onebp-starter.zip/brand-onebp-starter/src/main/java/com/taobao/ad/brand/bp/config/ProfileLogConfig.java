package com.taobao.ad.brand.bp.config;

import com.alibaba.abf.governance.logger.ProfileConfigBean;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author ximu.cly
 * @date 2020/4/17
 */
@Configuration
public class ProfileLogConfig {

    @Bean
    public ProfileConfigBean profileConfigBean() {
        ProfileConfigBean profileConfigBean = new ProfileConfigBean();
        profileConfigBean.setExcludeClassRegx("**.DmpScenarioQueryServiceImpl.getTagById,com.alibaba.ad.failover.sdk.**");
        profileConfigBean.setExcludeResultPropertyRegx("**.MultiResponse.result");
        return profileConfigBean;
    }
}
