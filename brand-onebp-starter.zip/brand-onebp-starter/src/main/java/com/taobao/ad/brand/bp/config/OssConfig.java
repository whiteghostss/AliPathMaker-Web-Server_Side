package com.taobao.ad.brand.bp.config;

import com.alibaba.normandy.credential.Credential;
import com.alibaba.normandy.credential.CredentialProvider;
import com.alibaba.normandy.credential.ResourceNames;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.annotation.Resource;

/**
 * @author jixiu.lj
 * @date 2023/3/20 20:23
 */
@Configuration
public class OssConfig {

    @Value("${oss.onebp.accountid:1179791013160477}")
    private String accountId;

    @Value("${oss.onebo.ramuser:aone-brand-onebp-oss-service-prod}")
    private String ramUserName;

    @Value("${oss.onebp.endpoint:http://oss-cn-zhangjiakou-internal.aliyuncs.com}")
    private String ossEndPoint;

    @Resource
    private CredentialProvider credentialProvider;


    @Bean(destroyMethod = "shutdown")
    public OSS getOssClient() {
        RogerLogger.info("托管配置获取.......................\n");
        String rn = ResourceNames.ofInternalAliyunAccessPackage(accountId, ramUserName);

        Credential credential = credentialProvider.getCredential(rn);
        RogerLogger.info("托管配置获取成功.......................\n");
        return new OSSClientBuilder()
            .build(
                ossEndPoint,
                credential.getAccessKeyId(),
                credential.getAccessKeySecret()
            );
    }
}
