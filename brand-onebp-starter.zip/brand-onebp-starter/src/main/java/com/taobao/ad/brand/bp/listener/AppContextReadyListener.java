package com.taobao.ad.brand.bp.listener;

import com.alibaba.hermes.framework.tool.lock.common.TairLockContext;
import com.taobao.tair.TairManager;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor(onConstructor_ = @Autowired)
public class AppContextReadyListener implements ApplicationListener<ApplicationReadyEvent> {

    private final TairManager tairManager;

    @Override
    public void onApplicationEvent(ApplicationReadyEvent applicationReadyEvent) {
        TairLockContext.getInstance().namespace(175);
        // 失败1次便刷新tair服务器列表
        tairManager.setMaxFailCount(1);
        // 连接超时时间设置为500ms
        tairManager.setConfigServerConnectTimeout(500);
    }
}
