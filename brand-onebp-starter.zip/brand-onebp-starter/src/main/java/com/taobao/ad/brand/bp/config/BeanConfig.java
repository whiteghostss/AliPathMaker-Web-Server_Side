package com.taobao.ad.brand.bp.config;

import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.alibaba.ad.brand.sdk.constant.demand.field.ContentDemandStatusEnum;
import com.alibaba.cola.statemachine.builder.StateMachineBuilder;
import com.taobao.ad.brand.bp.client.context.CampaignGroupStateContext;
import com.taobao.ad.brand.bp.client.context.DemandStateContext;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupEventEnum;
import com.taobao.ad.brand.bp.client.enums.demand.DemandEventEnum;
import com.taobao.ad.brand.bp.common.statemachine.BrandStateMachineBuilderFactory;
import com.taobao.ad.simba.user.helper.SimbaUicBeanHelper;
import com.taobao.hsf.app.api.util.HSFApiConsumerBean;
import com.taobao.hsf.remoting.service.GenericService;
import com.taobao.promotioncenter.core.service.impl.CouponSearchReadServiceClient;
import com.taobao.uic.context.UicCommonContext;
import com.youku.java.yks.service.YksPlayService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Collections;

/**
 * @author ximu.cly
 * @date 2020/3/4
 */
@Configuration
public class BeanConfig {
//    @Primary
//    @Bean
//    public ExceptionConsumer exceptionHandler(){
//        return new BrandOneBPExceptionHandler();
//    }
    @Bean(name = "campaignGroupStateMachineBuilder")
    public StateMachineBuilder<BrandCampaignGroupStatusEnum, CampaignGroupEventEnum, CampaignGroupStateContext> createCampaignGroupStateMachineBuilder() {
        return BrandStateMachineBuilderFactory.create();
    }

    @Bean(name = "demandStateMachineBuilder")
    public StateMachineBuilder<ContentDemandStatusEnum, DemandEventEnum, DemandStateContext> createDemandStateMachineBuilder() {
        return BrandStateMachineBuilderFactory.create();
    }

    @Bean(initMethod = "init")
    public static SimbaUicBeanHelper simbaUicBean(
        @Value("${uicsimba.service.version}") String version,
        @Value("${uicsimba.service.timeout:5000}") String timeout) {
        final SimbaUicBeanHelper simbaUicBeanHelper = new SimbaUicBeanHelper();
        simbaUicBeanHelper.setHsfServiceGroup("HSF");
        simbaUicBeanHelper.setHsfServiceVersion(version);
        simbaUicBeanHelper.setHsfServiceTimeout(timeout);
        return simbaUicBeanHelper;
    }

    @Bean(name = "yksPlayService")
    public YksPlayService yksPlayServiceBean(@Value("${yks.service.version}") String version,
                                             @Value("${yks.service.group}") String group,
                                             @Value("${yks.service.configserverCenter}") String configserverCenter)
            throws Exception {
        HSFApiConsumerBean hsfApiConsumerBean = new HSFApiConsumerBean();
        // [设置] 订阅服务的接口
        hsfApiConsumerBean.setInterfaceName(YksPlayService.class.getName());
        // [设置] 服务的版本
        hsfApiConsumerBean.setVersion(version);
        // [设置] 服务的归组
        hsfApiConsumerBean.setGroup(group);

        hsfApiConsumerBean.setConfigserverCenter(Collections.singletonList(configserverCenter));
        // ---------------------- 订阅 -----------------------//
        // [订阅] HSF服务，同步等待地址推送，默认false(异步)，同步默认超时时间3000毫秒
        hsfApiConsumerBean.init(true);

        // ---------------------- 代理 -----------------------//
        // [代理] 获取HSF代理
        YksPlayService yksPlayService = (YksPlayService) hsfApiConsumerBean.getObject();
        return yksPlayService;
    }
    @Bean(name = "couponSearchReadServiceClient")
    public CouponSearchReadServiceClient couponSearchReadServiceClientBean(){
        return new CouponSearchReadServiceClient();
    }

    @Bean
    public GenericService templateServer() {
        HSFApiConsumerBean hsfApiConsumerBean = new HSFApiConsumerBean();
        hsfApiConsumerBean.setInterfaceName("com.taobao.agi.TemplateServer");
        hsfApiConsumerBean.setVersion("1.0.0");
        hsfApiConsumerBean.setGroup("HSF");
        hsfApiConsumerBean.setClientTimeout(5000);
        // [设置] 泛化配置
        hsfApiConsumerBean.setGeneric("true");
        try {
            hsfApiConsumerBean.init(true);
            return (GenericService)hsfApiConsumerBean.getObject();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Bean(name = "uicCommonContext")
    public UicCommonContext uicCommonContext() {
        UicCommonContext uicCommonContext = new UicCommonContext();
        uicCommonContext.setInitMembership(true);
        uicCommonContext.setInitUserTag(true);
        uicCommonContext.setInitUser(true);
        uicCommonContext.setInitUcc(true);
        uicCommonContext.setInitRealName(true);
        uicCommonContext.setAppName("brand-onebp");
        return uicCommonContext;
    }
}
