package com.taobao.ad.brand.bp.config;

import com.alibaba.hermes.framework.tool.lock.TairDLock;
import com.taobao.tair.TairManager;
import com.taobao.tair.impl.mc.MultiClusterTairManager;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author 虫洞 <liuming.liu@alibaba-inc.com>
 * @date 2023/6/5
 */
@Configuration
public class TairConfig {
    /**
     * http://tiddo.alibaba-inc.com/saas-tair/#/InstanceDetail?username=94defa57981b4aec
     */
    @Value("${tair.username}")
    private String username;
    @Value("${tair.ldb.username}")
    private String ldbUsername;

    @Bean(name = "tairManager", initMethod = "init")
    public TairManager tairManager() {
        MultiClusterTairManager tairManager = new MultiClusterTairManager();
        tairManager.setUserName(ldbUsername);
        return tairManager;
    }

    /**
     * 分布式锁
     * @param tairManager
     * @return
     */
    @Bean(name = "tairDLock")
    public TairDLock disLock(@Qualifier("tairManager") TairManager tairManager) {
        TairDLock tairDLock = new TairDLock();
        tairDLock.init(tairManager);
        return tairDLock;
    }
}
