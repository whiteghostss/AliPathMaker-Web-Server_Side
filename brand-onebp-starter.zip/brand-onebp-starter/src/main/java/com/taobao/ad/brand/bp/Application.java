package com.taobao.ad.brand.bp;

import com.alibaba.abf.bootstrap.ABFBootstrap;
import com.taobao.pandora.boot.PandoraBootstrap;
import com.taobao.pandora.boot.spring.diamond.DiamondProfiles;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.ImportResource;

/**
 * 入口程序
 *
 */
@ImportResource(locations = {"classpath*:spring/spring*.xml"})
@SpringBootApplication(
    scanBasePackages = {
        "com.taobao.ad.brand.bp",
        "com.alibaba.abf",
        "com.alibaba.ad.nb",
        "com.alibaba.ad.universal",
        "com.alibaba.ad.oplog.aop",
        "com.taobao.uic",
    },
    exclude = {
        DataSourceAutoConfiguration.class,
        DataSourceTransactionManagerAutoConfiguration.class,
        MongoAutoConfiguration.class
    }
)
@EnableCaching
public class Application {

    public static void main(String[] args) {
        ABFBootstrap.load();
        PandoraBootstrap.run(args);
        new SpringApplicationBuilder(Application.class).profiles(DiamondProfiles.load()).run(args);
        // abf start
        ABFBootstrap.run(args);
        PandoraBootstrap.markStartupAndWait();
    }

}