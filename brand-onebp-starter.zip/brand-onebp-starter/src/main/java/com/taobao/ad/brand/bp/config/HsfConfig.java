package com.taobao.ad.brand.bp.config;

import com.alibaba.ad.audience.api.*;
import com.alibaba.ad.audience.api.label.LabelQueryService;
import com.alibaba.ad.audience.api.tool.TargetToolQueryService;
import com.alibaba.ad.brand.ai.client.api.LlmAgentDirectCallService;
import com.alibaba.ad.creative.api.*;
import com.alibaba.ad.creative.api.biz.MediaTmlCreativeCommandService;
import com.alibaba.ad.creative.api.biz.MediaTmlCreativeQueryService;
import com.alibaba.ad.feed.api.feedoutentity.CatQueryService;
import com.alibaba.ad.feed.api.feedoutentity.FeedOutEntityQueryService;
import com.alibaba.ad.feed.api.feedoutentity.ItemQueryService;
import com.alibaba.ad.feed.api.feedoutentity.ShopQueryService;
import com.alibaba.ad.nb.basic.client.api.monitor.MonitorCommandService;
import com.alibaba.ad.nb.basic.client.api.monitor.MonitorQueryService;
import com.alibaba.ad.nb.crm.api.dsp.DspMemberQueryService;
import com.alibaba.ad.nb.crm.api.schema.SchemaInfoQueryService;
import com.alibaba.ad.nb.direct.client.api.advertiser.DirectAdvertiserCommandService;
import com.alibaba.ad.nb.direct.client.api.advertiser.DirectAdvertiserQueryService;
import com.alibaba.ad.nb.order.api.creative.CreativeCommandService;
import com.alibaba.ad.nb.order.api.user.BucUserQueryService;
import com.alibaba.ad.nb.packages.api.project.NbProjectQueryService;
import com.alibaba.ad.nb.packages.v2.client.api.customer.CustomerTemplateCommandService;
import com.alibaba.ad.nb.packages.v2.client.api.motion.IntelligentMotionCommandService;
import com.alibaba.ad.nb.packages.v2.client.api.motion.IntelligentMotionQueryService;
import com.alibaba.ad.nb.packages.v2.client.api.motion.IntelligentStrategyCommandService;
import com.alibaba.ad.nb.packages.v2.client.api.motion.IntelligentStrategyQueryService;
import com.alibaba.ad.nb.packages.v2.client.api.salegroup.SaleGroupCommandService;
import com.alibaba.ad.nb.packages.v2.client.api.salegroup.SaleGroupQueryService;
import com.alibaba.ad.nb.packages.v2.client.api.template.TemplateQueryService;
import com.alibaba.ad.nb.price.api.engine.PriceEngineService;
import com.alibaba.ad.nb.sales.api.brief.BriefCommandService;
import com.alibaba.ad.nb.sales.api.brief.BriefQueryService;
import com.alibaba.ad.nb.sales.api.contract.ContractCommandService;
import com.alibaba.ad.nb.sales.api.contract.ContractQueryService;
import com.alibaba.ad.nb.sales.api.face.BriefService;
import com.alibaba.ad.nb.sales.api.face.CustomerService;
import com.alibaba.ad.nb.sales.api.face.ProjectService;
import com.alibaba.ad.nb.sales.api.retail.OneBpRetailService;
import com.alibaba.ad.nb.sales.api.zhubajie.ContractCompleteCommandService;
import com.alibaba.ad.nb.sales.api.zhubajie.ContractCompleteQueryService;
import com.alibaba.ad.nb.ssp.api.category.CategoryQueryService;
import com.alibaba.ad.nb.ssp.api.dict.DictionaryQueryService;
import com.alibaba.ad.nb.ssp.api.material.MaterialRuleQueryService;
import com.alibaba.ad.nb.ssp.api.newadzone.AdzoneQueryService;
import com.alibaba.ad.nb.ssp.api.newproduct.ProductQueryService;
import com.alibaba.ad.nb.ssp.api.site.SiteQueryService;
import com.alibaba.ad.nb.ssp.api.tag.TagTargetDataQueryService;
import com.alibaba.ad.nb.ssp.api.template.NbTemplateQueryService;
import com.alibaba.ad.nb.task.client.api.async.AsyncTaskCommandService;
import com.alibaba.ad.nb.task.client.api.async.AsyncTaskQueryService;
import com.alibaba.ad.nb.wto.content.client.api.common.DictQueryService;
import com.alibaba.ad.nb.wto.content.client.api.order.OrderCommandService;
import com.alibaba.ad.nb.wto.content.client.api.order.OrderQueryService;
import com.alibaba.ad.nb.wto.content.client.api.solution.SolutionGroupQueryService;
import com.alibaba.ad.oplog.sdk.OpLogQueryService;
import com.alibaba.ad.organizer.api.*;
import com.alibaba.ad.organizer.api.media.*;
import com.alibaba.ad.settle.billing.api.gateway.accounting.StlAccountingDetailService;
import com.alibaba.ad.uic.api.AccessControlQueryService;
import com.alibaba.ad.uic.api.LoginQueryService;
import com.alibaba.ad.uic.api.auth.AuthUserAssetRangeQueryService;
import com.alibaba.ad.uic.api.rolepermission.PermissionGroupQueryService;
import com.alibaba.alipmc.api.ProcessInstanceService;
import com.alibaba.boot.hsf.annotation.HSFConsumer;
import com.alibaba.simba.report.client.service.ReportService;
import com.alibaba.solar.jupiter.client.sdk.FeedOutEntityService;
import com.alibaba.solar.sirius.client.sdk.BidwordNormalizeService;
import com.alibaba.solar.sirius.client.sdk.BidwordService;
import com.alibaba.solar.sirius.client.sdk.BrandWordPackageService;
import com.alibaba.uad.wto.api.purchase.PurchaseOrderCommandService;
import com.alibaba.uad.wto.api.purchase.PurchaseOrderQueryService;
import com.alibaba.uad.wto.api.resource.MediaQueryService;
import com.alibaba.uad.wto.api.resource.MediaResourceQueryService;
import com.alibaba.uad.wto.hsf.service.InquiryService;
import com.alibaba.uad.wto.hsf.service.PurchaseOrderService;
import com.alibaba.uad.wto.hsf.service.ResourceScheduleService;
import com.alimama.cara.CreationServer;
import com.alimama.inventory.api.NbInventoryUdService;
import com.alimama.inventory.api.universal.UniInventoryService;
import com.alimama.rcp.shield.api.sync.sdk.ShieldSyncRuleService;
import com.taobao.ad.brand.perform.client.api.campaign.PerfCampaignCommandService;
import com.taobao.ad.brand.perform.client.api.globaltag.PerfGlobalTagQueryService;
import com.taobao.ad.brand.perform.client.api.shopwindow.spu.PerfBundleQueryService;
import com.taobao.ad.brand.perform.client.api.shopwindow.spu.PerfSkuQueryService;
import com.taobao.ad.brand.perform.client.api.shopwindow.spu.PerfSpuCommandService;
import com.taobao.ad.brand.perform.client.api.shopwindow.spu.PerfSpuQueryService;
import com.taobao.ad.dmp.argus.sdk.interfaces.ServiceGateway;
import com.taobao.ad.dmp.client.sdk2.AnalysisService;
import com.taobao.ad.dmp.client.sdk2.CrowdService;
import com.taobao.ad.dmp.client.sdk2.CrowdTemplateService;
import com.taobao.ad.dmp.client.sdk2.TagService;
import com.taobao.ad.dmp.site.sdk.interfaces.GoodsItemService;
import com.taobao.ad.mm.crm.service.sdk.adv.AdvInfoService;
import com.taobao.ad.mm.crm.service.sdk.customer.CustomerContactService;
import com.taobao.ad.simba.user.newservice.MemberService;
import com.taobao.brand.service.tolong.StandardBrandService;
import com.taobao.guangguang.ce.api.service.mission.BailingMissionService;
import com.taobao.inventoryscheduler.client.dump.ISearchDataDumpService;
import com.taobao.simba.qualification.api.QualificationBizService;
import com.taobao.simba.saber.api.RuleServiceBasedMiku;
import com.taobao.taojimu.AlpPage;
import com.umeng.oplus.openapi.service.dsp.DspScheme4ApiService;
import org.springframework.context.annotation.Configuration;

@Configuration
public class HsfConfig {

    @HSFConsumer(serviceVersion = "${adgroup.service.version}", clientTimeout = 30000)
    AdgroupCommandService adgroupCommandService;
    @HSFConsumer(serviceVersion = "${campaign.service.version}", clientTimeout = 30000)
    CampaignGroupCommandService campaignGroupCommandService;
    @HSFConsumer(serviceVersion = "${campaign.service.version}", clientTimeout = 30000)
    CampaignGroupQueryService campaignGroupQueryService;

    @HSFConsumer(serviceVersion = "${campaign.service.version}", clientTimeout = 30000)
    CampaignQueryService campaignQueryService;
    @HSFConsumer(serviceVersion = "${campaign.service.version}", clientTimeout = 30000)
    CampaignDealRefQueryService campaignDealRefQueryService;
    @HSFConsumer(serviceVersion = "${campaign.service.version}", clientTimeout = 30000)
    CampaignCommandService campaignCommandService;

    @HSFConsumer(serviceVersion = "${campaign.service.version}", clientTimeout = 30000)
    MediaProtectRuleCommandService mediaProtectRuleCommandService;
    @HSFConsumer(serviceVersion = "${campaign.service.version}", clientTimeout = 30000)
    MediaProtectRuleQueryService mediaProtectRuleQueryService;
    @HSFConsumer(serviceVersion = "${campaign.service.version}", clientTimeout = 30000)
    MediaMutexRuleCommandService mediaMutexRuleCommandService;
    @HSFConsumer(serviceVersion = "${campaign.service.version}", clientTimeout = 30000)
    MediaMutexRuleQueryService mediaMutexRuleQueryService;
    @HSFConsumer(serviceVersion = "${campaign.service.version}", clientTimeout = 30000)
    MediaFrequencyCommandService mediaFrequencyCommandService;
    @HSFConsumer(serviceVersion = "${campaign.service.version}", clientTimeout = 30000)
    MediaFrequencyQueryService mediaFrequencyQueryService;


    @HSFConsumer(serviceVersion = "${target.service.version}", clientTimeout = 30000)
    CampaignBindAdzoneQueryService campaignBindAdzoneQueryService;

    @HSFConsumer(serviceVersion = "${target.service.version}", clientTimeout = 30000)
    CampaignBindCrowdQueryService campaignBindCrowdQueryService;
    @HSFConsumer(serviceVersion = "${target.service.version}", clientTimeout = 30000)
    BindCrowdCommandService bindCrowdCommandService;
    @HSFConsumer(serviceVersion = "${target.service.version}", clientTimeout = 30000)
    AdgroupBindCrowdQueryService adgroupBindCrowdQueryService;
    @HSFConsumer(serviceVersion = "${target.service.version}", clientTimeout = 30000)
    BindAdzoneCommandService bindAdzoneCommandService;
    @HSFConsumer(serviceVersion = "${target.service.version}", clientTimeout = 30000)
    TargetToolQueryService targetToolQueryService;

    @HSFConsumer(serviceVersion = "${target.service.version}", clientTimeout = 30000)
    LabelQueryService labelQueryService;

    @HSFConsumer(serviceVersion = "${campaign.service.version}", clientTimeout = 30000)
    FrequencyCommandService frequencyCommandService;
    @HSFConsumer(serviceVersion = "${campaign.service.version}", clientTimeout = 30000)
    FrequencyRefCommandService frequencyRefCommandService;
    @HSFConsumer(serviceVersion = "${campaign.service.version}", clientTimeout = 30000)
    FrequencyQueryService frequencyQueryService;
    @HSFConsumer(serviceVersion = "${campaign.service.version}", clientTimeout = 30000)
    FrequencyRefQueryService frequencyRefQueryService;
    @HSFConsumer(serviceVersion = "${campaign.service.version}", clientTimeout = 30000)
    CartQueryService cartQueryService;
    @HSFConsumer(serviceVersion = "${campaign.service.version}", clientTimeout = 30000)
    CartCommandService cartCommandService;

    @HSFConsumer(serviceVersion = "${creative.service.version}", clientTimeout = 30000)
    MediaTmlCreativeCommandService mediaTmlCreativeCommandService;
    @HSFConsumer(serviceVersion = "${creative.service.version}", clientTimeout = 30000)
    CreativeBindCommandService creativeBindCommandService;
    @HSFConsumer(serviceVersion = "${creative.service.version}", clientTimeout = 30000)
    CreativeTagCommandService creativeTagCommandService;
    @HSFConsumer(serviceVersion = "${creative.service.version}", clientTimeout = 30000)
    CreativeTagQueryService creativeTagQueryService;
    @HSFConsumer(serviceVersion = "${creative.service.version}", clientTimeout = 30000)
    CreativeBindQueryService creativeBindQueryService;
    @HSFConsumer(serviceVersion = "${creative.service.version}", clientTimeout = 30000)
    QualityCommandService qualityCommandService;
    @HSFConsumer(serviceVersion = "${creative.service.version}", clientTimeout = 30000)
    ContentVersionCommandService contentVersionCommandService;
    @HSFConsumer(serviceVersion = "${creative.service.version}", clientTimeout = 30000)
    ContentVersionQueryService contentVersionQueryService;

    @HSFConsumer(serviceVersion = "${item.inventory.service.version}", clientTimeout = 30000)
    ISearchDataDumpService iSearchDataDumpService;

    @HSFConsumer(serviceVersion = "${creative.service.version}", clientTimeout = 30000)
    MediaTmlCreativeQueryService mediaTmlCreativeQueryService;
    @HSFConsumer(serviceVersion = "${creative.service.version}", clientTimeout = 30000)
    ClickUrlAnalysisQueryService clickUrlAnalysisQueryService;
    @HSFConsumer(serviceVersion = "${creative.service.version}", clientTimeout = 30000)
    MaterialGroupQueryService materialGroupQueryService;
    @HSFConsumer(serviceVersion = "${creative.service.version}", clientTimeout = 30000)
    MaterialGroupCommandService materialGroupCommandService;
    @HSFConsumer(serviceVersion = "${creative.service.version}", clientTimeout = 30000)
    MaterialCommandService materialCommandService;

    @HSFConsumer(serviceVersion = "${nb.package.service.version}", clientTimeout = 30000)
    TemplateQueryService templateQueryService;
    @HSFConsumer(serviceVersion = "${nb.package.service.version}", clientTimeout = 30000)
    CustomerTemplateCommandService customerTemplateCommandService;
    @HSFConsumer(serviceVersion = "${nb.package.service.version}", clientTimeout = 30000)
    SaleGroupQueryService saleGroupQueryService;
    @HSFConsumer(serviceVersion = "${nb.package.service.version}", clientTimeout = 30000)
    SaleGroupCommandService saleGroupCommandService;
    @HSFConsumer(serviceVersion = "${nb.package.service.version}", clientTimeout = 30000)
    NbProjectQueryService nbProjectQueryService;
    @HSFConsumer(serviceVersion = "${nb.package.service.version}", clientTimeout = 30000)
    IntelligentMotionCommandService intelligentMotionCommandService;
    @HSFConsumer(serviceVersion = "${nb.package.service.version}", clientTimeout = 30000)
    IntelligentMotionQueryService intelligentMotionQueryService;
    @HSFConsumer(serviceVersion = "${nb.package.service.version}", clientTimeout = 30000)
    IntelligentStrategyCommandService intelligentStrategyCommandService;
    @HSFConsumer(serviceVersion = "${nb.package.service.version}", clientTimeout = 30000)
    IntelligentStrategyQueryService intelligentStrategyQueryService;

    @HSFConsumer(serviceVersion = "${simba.report.service.version}", clientTimeout = 40000)
    ReportService reportService;
    /**
     * 模板中心查询服务
     */
    @HSFConsumer(serviceVersion = "${nb.ssp.hsf.version}", clientTimeout = 30000)
    private NbTemplateQueryService nbTemplateQueryService;
    @HSFConsumer(serviceVersion = "${nb.ssp.hsf.version}", clientTimeout = 30000)
    private TagTargetDataQueryService tagTargetDataQueryService;

    @HSFConsumer(serviceVersion = "${nb.ssp.hsf.version}", clientTimeout = 30000)
    private MaterialRuleQueryService materialRuleQueryService;
    @HSFConsumer(serviceVersion = "${nb.ssp.hsf.version}", clientTimeout = 30000)
    private ProductQueryService productQueryService;
    @HSFConsumer(serviceVersion = "${nb.ssp.hsf.version}", clientTimeout = 30000)
    private SiteQueryService siteQueryService;
    @HSFConsumer(serviceVersion = "${nb.ssp.hsf.version}", clientTimeout = 30000)
    private AdzoneQueryService adzoneQueryService;

    @HSFConsumer(serviceVersion = "${nb.ssp.hsf.version}", clientTimeout = 30000)
    private DictionaryQueryService dictionaryQueryService;

    @HSFConsumer(serviceVersion = "${nb.ssp.hsf.version}", clientTimeout = 30000)
    private CategoryQueryService categoryQueryService;

    @HSFConsumer(serviceVersion = "${nb.ssp.hsf.version}", clientTimeout = 30000)
    private PurchaseOrderService purchaseOrderService;

    @HSFConsumer(serviceVersion = "${nb.price.hsf.version}", clientTimeout = 30000)
    PriceEngineService priceEngineService;

    @HSFConsumer(serviceVersion = "${nb.inventory.service.version}", clientTimeout = 30000)
    private UniInventoryService uniInventoryService;


    @HSFConsumer(serviceVersion = "${nb.inventory.service.version}", clientTimeout = 30000)
    private NbInventoryUdService nbInventoryUdService;

    @HSFConsumer(serviceVersion = "${dmp.service.version}", clientTimeout = 30000)
    private CrowdService crowdService;

    @HSFConsumer(serviceVersion = "${dmp.service.version}", clientTimeout = 30000)
    private TagService tagService;
    @HSFConsumer(serviceVersion = "${dmp-site.service.version}", clientTimeout = 30000)
    private GoodsItemService goodsItemService;

    @HSFConsumer(serviceVersion = "${dmp.service.version}", clientTimeout = 30000)
    private AnalysisService analysisService;

    @HSFConsumer(serviceVersion = "${dmp.service.version}", clientTimeout = 30000)
    private CrowdTemplateService crowdTemplateService;



    @HSFConsumer(serviceVersion = "${bpms.service.version}", clientTimeout = 30000)
    private ProcessInstanceService processInstanceService;


    @HSFConsumer(serviceVersion = "${campaign.service.version}", clientTimeout = 30000)
    private AdgroupQueryService adgroupQueryService;

    @HSFConsumer(serviceVersion = "${mm.sales.service.version}", clientTimeout = 30000)
    private ContractQueryService contractQueryService;
    @HSFConsumer(serviceVersion = "${mm.sales.service.version}", clientTimeout = 30000)
    private ContractCompleteQueryService contractCompleteQueryService;
    @HSFConsumer(serviceVersion = "${mm.sales.service.version}", clientTimeout = 30000)
    private ContractCompleteCommandService contractCompleteCommandService;
    @HSFConsumer(serviceVersion = "${mm.sales.service.version}", clientTimeout = 30000)
    private ContractCommandService contractCommandService;
    @HSFConsumer(serviceVersion = "${mm.sales.service.version}", clientTimeout = 30000)
    private OneBpRetailService oneBpRetailService;

    @HSFConsumer(serviceVersion = "${mm.sales.service.version}", clientTimeout = 30000)
    private BriefCommandService briefCommandService;

    @HSFConsumer(serviceVersion = "${mm.sales.service.version}", clientTimeout = 30000)
    private BriefQueryService briefQueryService;

    @HSFConsumer(serviceVersion = "${mm.sales.service.version}", clientTimeout = 30000)
    private BriefService briefService;

    @HSFConsumer(serviceVersion = "${mm.sales.service.version}", clientTimeout = 30000)
    private CustomerService customerService;

    @HSFConsumer(serviceVersion = "${mm.sales.service.version}", clientTimeout = 30000)
    private ProjectService projectService;


    @HSFConsumer(serviceVersion = "${mmcrm.service.version}", clientTimeout = 30000)
    private AdvInfoService advInfoService;
    @HSFConsumer(serviceVersion = "${mmcrm.service.version}", clientTimeout = 30000)
    private CustomerContactService customerContactService;

    @HSFConsumer(serviceVersion = "${nb.ssp.hsf.version}", clientTimeout = 30000)
    private InquiryService inquiryService;

    @HSFConsumer(serviceVersion = "${nb.wto.version}")
    private MediaResourceQueryService mediaResourceQueryService;
    @HSFConsumer(serviceVersion = "${nb.wto.version}")
    private MediaQueryService mediaQueryService;
    @HSFConsumer(serviceVersion = "${nb.wto.version}")
    private ResourceScheduleService resourceScheduleService;
    @HSFConsumer(serviceVersion = "${nb.wto.version}", clientTimeout = 30000)
    private PurchaseOrderCommandService purchaseOrderCommandService;
    @HSFConsumer(serviceVersion = "${nb.wto.version}", clientTimeout = 30000)
    private PurchaseOrderQueryService purchaseOrderQueryService;

    @HSFConsumer(serviceVersion = "${brand.service.version}", clientTimeout = 30000)
    private StandardBrandService standardBrandService;

    @HSFConsumer(serviceVersion = "${settle.billing.service.version}", clientTimeout = 30000)
    private StlAccountingDetailService stlAccountingDetailService;

    @HSFConsumer(serviceVersion = "${perform.service.version}", clientTimeout = 30000)
    private PerfCampaignCommandService perfCampaignCommandService;

    @HSFConsumer(serviceVersion = "${perform.service.version}", clientTimeout = 30000)
    private PerfGlobalTagQueryService perfGlobalTagQueryService;

    @HSFConsumer(serviceVersion = "${perform.service.version}", clientTimeout = 30000)
    private PerfSpuQueryService perfSpuQueryService;

    @HSFConsumer(serviceVersion = "${perform.service.version}", clientTimeout = 30000)
    private PerfSkuQueryService perfSkuQueryService;

    @HSFConsumer(serviceVersion = "${perform.service.version}", clientTimeout = 30000)
    private PerfSpuCommandService perfSpuCommandService;

    @HSFConsumer(serviceVersion = "${perform.service.version}", clientTimeout = 30000)
    private PerfBundleQueryService perfBundleQueryService;

    @HSFConsumer(serviceVersion = "${nb.order.version}", clientTimeout = 30000)
    private CreativeCommandService creativeCommandService;
    /**
     * 监测服务
     * */
    @HSFConsumer(serviceVersion = "${nb.direct.service.version}", clientTimeout = 30000)
    private MonitorQueryService monitorQueryService;
    /**
     * 达人服务
     */
    @HSFConsumer(serviceVersion = "${nb.direct.service.version}", clientTimeout = 30000)
    private com.alibaba.ad.nb.content.client.api.talent.TalentQueryService nbTalentQueryService;
    /**
     * 监测服务
     * */
    @HSFConsumer(serviceVersion = "${nb.direct.service.version}", clientTimeout = 30000)
    private MonitorCommandService monitorCommandService;
    /**
     * 广告主服务
     * */
    @HSFConsumer(serviceVersion = "${nb.direct.service.version}", clientTimeout = 30000)
    DirectAdvertiserQueryService directAdvertiserQueryService;
    /**
     * 广告主服务
     * */
    @HSFConsumer(serviceVersion = "${nb.direct.service.version}", clientTimeout = 30000)
    DirectAdvertiserCommandService directAdvertiserCommandService;

    @HSFConsumer(serviceVersion = "${nb.direct.service.version}", clientTimeout = 30000)
    AsyncTaskQueryService asyncTaskQueryService;
    @HSFConsumer(serviceVersion = "${nb.direct.service.version}", clientTimeout = 30000)
    AsyncTaskCommandService asyncTaskCommandService;

    @HSFConsumer(serviceVersion = "${nb.direct.service.version}", clientTimeout = 30000)
    com.alibaba.ad.nb.basic.client.api.creative.BizCreativeCommandService udCreativeCommandService;
    @HSFConsumer(serviceVersion = "${nb.direct.service.version}", clientTimeout = 30000)
    com.alibaba.ad.nb.basic.client.api.creative.BizCreativeQueryService udCreativeQueryService;
    @HSFConsumer(serviceVersion = "${nb.direct.service.version}", clientTimeout = 30000)
    com.alibaba.ad.nb.basic.client.api.creative.BizCreativeTemplateQueryService  udCreativeTemplateQueryService;
    @HSFConsumer(serviceVersion = "${nb.tanxcrm.hsf.version}", clientTimeout = 30000)
    private SchemaInfoQueryService schemaInfoQueryService;

    @HSFConsumer(serviceVersion = "${nborder.service.version}", clientTimeout = 5000)
    private BucUserQueryService bucUserQueryService;

    @HSFConsumer(serviceVersion = "${aduic.service.version}")
    private LoginQueryService loginQueryService;

    @HSFConsumer(serviceVersion = "${aduic.service.version}")
    private PermissionGroupQueryService permissionGroupQueryService;

    @HSFConsumer(serviceVersion = "${aduic.service.version}")
    private AccessControlQueryService accessControlQueryService;

    @HSFConsumer(serviceVersion = "${aduic.service.version}")
    private AuthUserAssetRangeQueryService authUserAssetRangeQueryService;

    @HSFConsumer(serviceVersion = "${simba.user.interface.version}", clientTimeout = 30000)
    private MemberService memberService;

    @HSFConsumer(serviceVersion = "${adoss.service.version}", clientTimeout = 30000)
    private com.taobao.ad.adoss.nautilus.service.CustomerService adossCustomerService;
    @HSFConsumer(serviceVersion = "${dmp.argus.version}", clientTimeout = 60000)
    private ServiceGateway serviceGateway;
    @HSFConsumer(serviceVersion = "${ad.feed.client.version}", clientTimeout = 5000)
    private ShopQueryService shopQueryService;
    @HSFConsumer(serviceVersion = "${ad.feed.client.version}", clientTimeout = 5000)
    private CatQueryService catQueryService;
    @HSFConsumer(serviceVersion = "${ad.feed.client.version}", clientTimeout = 30000)
    private ItemQueryService itemQueryService;
    @HSFConsumer(serviceVersion = "${ad.feed.client.version}", clientTimeout = 30000)
    private FeedOutEntityQueryService feedOutEntityQueryService;
    @HSFConsumer(serviceVersion = "${solar.jupiter.service.version}", clientTimeout = 30000)
    private FeedOutEntityService feedOutEntityService;
    @HSFConsumer(serviceVersion = "${nb.wto.content.client.version}", clientTimeout = 30000)
    private OrderQueryService orderQueryService;

    @HSFConsumer(serviceVersion = "${nb.wto.content.client.version}", clientTimeout = 30000)
    private OrderCommandService orderCommandService;

    @HSFConsumer(serviceVersion = "${demand.service.version}", clientTimeout = 30000)
    private BusinessDemandCommandService businessDemandCommandService;
    @HSFConsumer(serviceVersion = "${demand.service.version}", clientTimeout = 30000)
    private BusinessDemandQueryService businessDemandQueryService;

    @HSFConsumer(serviceVersion = "${nb.wto.content.client.version}", clientTimeout = 30000)
    private DictQueryService dictQueryService;

    @HSFConsumer(serviceVersion = "${nb.tanxcrm.hsf.version}", clientTimeout = 30000)
    private DspMemberQueryService dspMemberQueryService;

    /**
     * 风控规则
     */
    @HSFConsumer(serviceVersion = "${shield.access.hsf.version}", clientTimeout = 30000)
    private ShieldSyncRuleService shieldSyncRuleService;

    @HSFConsumer(serviceVersion = "${saber.hsf.version}", clientTimeout = 30000)
    private RuleServiceBasedMiku ruleServiceBasedMiku;

    @HSFConsumer(serviceVersion = "${nb.wto.content.client.version}", clientTimeout = 30000)
    private SolutionGroupQueryService solutionGroupQueryService;

    /**
     * 海棠创意中心
     */
    @HSFConsumer(serviceVersion = "${kb.facade.hsf.version}", clientTimeout = 30000)
    private CreationServer creationServer;
    /**
     * 日志中心
     */
    @HSFConsumer(serviceVersion = "${ad.oplog.service.version}", clientTimeout = 30000)
    private OpLogQueryService opLogQueryService;

    @HSFConsumer(serviceVersion = "${umeng.oplus.dsp.version}", clientTimeout = 30000)
    private DspScheme4ApiService dspScheme4ApiService;

    @HSFConsumer(serviceVersion = "${simba.qualification.api.version}", clientTimeout = 30000)
    private QualificationBizService qualificationBizService;

    @HSFConsumer(serviceVersion = "${guangguang.content.hsf.version}", clientTimeout = 30000)
    private BailingMissionService missionService;
    @HSFConsumer(serviceVersion = "${taojimu.api.service.version}", clientTimeout = 30000)
    private AlpPage alpPage;
    @HSFConsumer(serviceVersion = "${solar.sirius.service.version}", clientTimeout = 30000)
    private BidwordService bidWordService;
    @HSFConsumer(serviceVersion = "${solar.sirius.service.version}", clientTimeout = 30000)
    private BidwordNormalizeService bidWordNormalizeService;
    @HSFConsumer(serviceVersion = "${brand.ai.service.version}", clientTimeout = 600000)
    private LlmAgentDirectCallService llmAgentDirectCallService;
    @HSFConsumer(serviceVersion = "${solar.sirius.service.version}", clientTimeout = 30000)
    private BrandWordPackageService brandWordPackageService;
}
