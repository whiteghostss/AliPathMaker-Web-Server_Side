package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupMediaInquiryOrderUpdateAbilityParam;

@AbilityDefinition(desc = "订单-更新媒体询量单id")
public interface ICampaignGroupMediaInquiryOrderUpdateAbility
        extends AtomAbility<CampaignGroupMediaInquiryOrderUpdateAbilityParam, Void> {
}
