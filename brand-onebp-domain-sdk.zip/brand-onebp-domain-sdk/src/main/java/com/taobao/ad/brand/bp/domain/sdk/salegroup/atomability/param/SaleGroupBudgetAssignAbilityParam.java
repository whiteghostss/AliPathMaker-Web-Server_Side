package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.calculate.CampaignCalViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

import java.util.List;
import java.util.Map;

@Data
@SuperBuilder
public class SaleGroupBudgetAssignAbilityParam extends AtomAbilitySingleTargetParam<ResourcePackageSaleGroupViewDTO> {

    /**
     * 产品关联计划计算配置
     */
    private Map<Long, List<CampaignCalViewDTO>> calcCampaignMap;

    private List<ResourcePackageProductViewDTO> resourcePackageProductViewDTOList;
    private CampaignGroupViewDTO campaignGroupViewDTO;
    private List<CampaignViewDTO> campaignViewDTOList;
    private Long resourceCategoryBudget;
}
