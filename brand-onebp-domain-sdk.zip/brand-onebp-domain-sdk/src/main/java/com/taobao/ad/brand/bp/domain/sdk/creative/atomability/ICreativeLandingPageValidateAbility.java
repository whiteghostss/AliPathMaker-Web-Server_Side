package com.taobao.ad.brand.bp.domain.sdk.creative.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeLandingPageValidateAbilityParam;

@AbilityDefinition(desc = "创意落地页-校验")
public interface ICreativeLandingPageValidateAbility extends AtomAbility<CreativeLandingPageValidateAbilityParam, Void> {

}
