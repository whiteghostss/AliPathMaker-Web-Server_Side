package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupPriceUpdatedIdGetAbilityParam;

import java.util.List;

@AbilityDefinition(desc = "分组-获取价格更新的分组")
public interface ISaleGroupPriceUpdatedSaleGroupIdGetAbility extends AtomAbility<SaleGroupPriceUpdatedIdGetAbilityParam, List<Long>> {

}
