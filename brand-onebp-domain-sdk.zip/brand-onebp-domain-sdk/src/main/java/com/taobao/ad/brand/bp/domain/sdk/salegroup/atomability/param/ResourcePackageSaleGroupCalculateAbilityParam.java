package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Data
@SuperBuilder
public class ResourcePackageSaleGroupCalculateAbilityParam extends AtomAbilitySingleTargetParam<ResourcePackageSaleGroupViewDTO> {

    /**
     * 计划树
     */
    private List<CampaignViewDTO> campaignTreeList;
}
