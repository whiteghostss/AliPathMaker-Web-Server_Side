package com.taobao.ad.brand.bp.domain.sdk.campaign.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignAdvValidateAbilityParam;

@AbilityDefinition(desc = "计划adv-余额校验")
public interface ICampaignAdvBalanceValidateAbility extends AtomAbility<CampaignAdvValidateAbilityParam, Void> {

}
