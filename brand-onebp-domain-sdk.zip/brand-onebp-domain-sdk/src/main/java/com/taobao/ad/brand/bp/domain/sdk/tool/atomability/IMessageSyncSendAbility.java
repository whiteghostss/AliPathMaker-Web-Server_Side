package com.taobao.ad.brand.bp.domain.sdk.tool.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.param.MessageSyncSendAbilityParam;

@AbilityDefinition(desc = "消息-同步事件发送")
public interface IMessageSyncSendAbility extends AtomAbility<MessageSyncSendAbilityParam, Void> {

}
