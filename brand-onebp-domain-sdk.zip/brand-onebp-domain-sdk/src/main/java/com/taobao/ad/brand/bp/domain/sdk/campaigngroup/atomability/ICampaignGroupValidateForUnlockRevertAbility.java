package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupUnlockRevertAbilityParam;

@AbilityDefinition(desc = "订单-订单校验-撤销改单流程")
public interface ICampaignGroupValidateForUnlockRevertAbility extends AtomAbility<CampaignGroupUnlockRevertAbilityParam, Void> {

}
