package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupGoalSettingViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * 订单分组-目标设定填充-更新目标设定-能力参数
 */
@Data
@SuperBuilder
public class SaleGroupGoalSettingFillForUpdateGoalSettingAbilityParam
        extends AtomAbilitySingleTargetParam<CampaignGroupSaleGroupGoalSettingViewDTO> {

    /**
     * 售卖分组目标设定基础参数
     */
    private BaseSaleGroupGoalSettingParam baseSaleGroupGoalSettingParam;

}
