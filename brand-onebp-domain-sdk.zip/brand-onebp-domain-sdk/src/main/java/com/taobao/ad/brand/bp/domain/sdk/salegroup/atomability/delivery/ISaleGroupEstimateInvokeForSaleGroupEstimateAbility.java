package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.delivery;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupEstimateInfoViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupEstimateInvokeForSaleGroupEstimateAbilityParam;

import java.util.List;

@AbilityDefinition(desc = "订单分组-执行分组预估-分组预估")
public interface ISaleGroupEstimateInvokeForSaleGroupEstimateAbility
        extends AtomAbility<SaleGroupEstimateInvokeForSaleGroupEstimateAbilityParam, List<CampaignGroupSaleGroupEstimateInfoViewDTO>> {
}
