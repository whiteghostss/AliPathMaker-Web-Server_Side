package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param;

import com.alibaba.ad.brand.dto.adgroup.crowd.AdgroupCrowdScenarioViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * 单元-打底单元人群初始化
 */
@Data
@SuperBuilder
public class AdgroupBottomCrowdInitAbilityParam extends AtomAbilitySingleTargetParam<AdgroupCrowdScenarioViewDTO> {

}
