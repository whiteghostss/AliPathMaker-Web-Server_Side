package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupInitForCancelAbilityParam;

@AbilityDefinition(desc = "订单-初始化-订单撤单流程")
public interface ICampaignGroupInitForCancelAbility extends AtomAbility<CampaignGroupInitForCancelAbilityParam, Void> {

}
