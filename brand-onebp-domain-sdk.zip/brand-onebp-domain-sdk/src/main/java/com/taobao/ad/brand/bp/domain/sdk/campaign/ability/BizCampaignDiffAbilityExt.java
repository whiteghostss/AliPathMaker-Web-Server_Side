package com.taobao.ad.brand.bp.domain.sdk.campaign.ability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.ability.GenericIsoBaseAbility;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignDiffViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.campaign.ability.param.BizCampaignDiffAbilityParam;

@AbilityDefinition(desc = "计划diff能力扩展点")
public interface BizCampaignDiffAbilityExt extends GenericIsoBaseAbility<BaseViewDTO> {

    default CampaignDiffViewDTO diffCampaign(ServiceContext serviceContext, BizCampaignDiffAbilityParam paramDefinition){
        return null;
    }
}
