package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupStatusValidateForBindOrUnBindAdvAbilityParam;

@AbilityDefinition(desc = "订单adv-订单状态校验-adv解绑流程")
public interface ICampaignGroupStatusValidateForUnBindAdvAbility extends AtomAbility<CampaignGroupStatusValidateForBindOrUnBindAdvAbilityParam, Void> {

}
