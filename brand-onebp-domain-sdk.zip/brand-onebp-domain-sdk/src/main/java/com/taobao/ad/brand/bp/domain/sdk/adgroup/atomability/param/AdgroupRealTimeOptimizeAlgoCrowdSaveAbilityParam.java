package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param;

import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

import java.util.List;
import java.util.Map;

/**
 * 保存单元黑盒人群
 */
@Data
@SuperBuilder
public class AdgroupRealTimeOptimizeAlgoCrowdSaveAbilityParam extends AtomAbilitySingleTargetParam<AdgroupViewDTO> {
    /**
     * 人群id-计划人群对象
     */
    private Map<Long, CampaignCrowdViewDTO> dbCampaignCrowdMap;
    /**
     * 实时优选人群
     */
    private List<CampaignCrowdViewDTO> optimizeCrowdViewDTOList;
}
