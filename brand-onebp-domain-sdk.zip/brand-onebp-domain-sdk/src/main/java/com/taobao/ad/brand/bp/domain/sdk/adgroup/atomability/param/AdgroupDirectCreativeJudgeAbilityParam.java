package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param;

import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * 单元-生成媒体直投创意判断
 */
@Data
@SuperBuilder
public class AdgroupDirectCreativeJudgeAbilityParam extends AtomAbilitySingleTargetParam<AdgroupViewDTO> {

}
