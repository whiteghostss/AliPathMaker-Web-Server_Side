package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param;

import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.common.WakeupViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

import java.util.List;

/**
 * 单元唤端修改校验
 */
@Data
@SuperBuilder
public class AdgroupWakeUpValidateForUpdateAbilityParam extends AtomAbilitySingleTargetParam<WakeupViewDTO> {
    /**
     * 数据库单元
     */
    private AdgroupViewDTO dbAdgroupViewDTO;
    /**
     * 创意
     */
    private List<CreativeViewDTO> creativeViewDTOList;
}
