package com.taobao.ad.brand.bp.domain.sdk.salegroup.businessability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.abf.isolation.spec.common.IsoLevel;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupGoalSettingViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbility;

@AbilityDefinition(desc = "售卖分组交付优化目标设置流程-商业能力挂载点定义", level = IsoLevel.workflow)
public interface ISaleGroupGoalSettingUpdateBusinessAbilityPoint extends BusinessAbility {
    /**
     * 商业能力执行器
     *
     * @param serviceContext
     * @param saleGroupGoalSettingViewDTO
     * @return
     */
    default Void invokeForSaleGroupGoalSetting(ServiceContext serviceContext, CampaignGroupSaleGroupGoalSettingViewDTO saleGroupGoalSettingViewDTO) {
        return null;
    }
}
