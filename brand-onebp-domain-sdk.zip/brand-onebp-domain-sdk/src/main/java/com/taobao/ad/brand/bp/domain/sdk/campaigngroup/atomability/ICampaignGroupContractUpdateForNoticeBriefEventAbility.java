package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupContractUpdateForNoticeBriefEventAbilityParam;

@AbilityDefinition(desc = "订单-合同信息更新-brief消息通知流程")
public interface ICampaignGroupContractUpdateForNoticeBriefEventAbility extends AtomAbility<CampaignGroupContractUpdateForNoticeBriefEventAbilityParam, Void> {

}
