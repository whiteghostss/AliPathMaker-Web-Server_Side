package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupStopTimeUpdateForStopCastCampaignGroupAbilityParam;

@AbilityDefinition(desc = "订单-初始化-订单停投流程")
public interface ICampaignGroupStopTimeUpdateForStopCastCampaignGroupAbility extends AtomAbility<CampaignGroupStopTimeUpdateForStopCastCampaignGroupAbilityParam, Void> {

}
