package com.taobao.ad.brand.bp.domain.sdk.shopwindow.atomability.param;

import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSkuViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilityMultiTargetsParam;
import lombok.experimental.SuperBuilder;

/**
 * sku-ssp产品线准入判断
 */
@SuperBuilder
public class SkuSspProductLineAuthJudgeAbilityParam extends AtomAbilityMultiTargetsParam<BrandSkuViewDTO> {
}
