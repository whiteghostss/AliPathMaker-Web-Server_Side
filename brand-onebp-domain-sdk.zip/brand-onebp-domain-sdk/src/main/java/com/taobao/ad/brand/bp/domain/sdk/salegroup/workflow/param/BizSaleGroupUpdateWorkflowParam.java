package com.taobao.ad.brand.bp.domain.sdk.salegroup.workflow.param;

import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Description:订单参数定义
 * <p>
 * date: 2024/2/26
 * @author yanjingang
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BizSaleGroupUpdateWorkflowParam {
    /**
     * 订单
     */
    private CampaignGroupViewDTO campaignGroupViewDTO;
    /**
     * 售卖分组
     */
    private SaleGroupInfoViewDTO saleGroupInfoViewDTO;
    /**
     * 资源包售卖分组
     */
    private ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO;
}
