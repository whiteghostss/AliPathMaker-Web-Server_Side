package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupDirectCreativeJudgeAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;

@AbilityDefinition(desc = "单元-生成媒体直投创意判断")
public interface IAdgroupDirectCreativeJudgeAbility extends AtomAbility<AdgroupDirectCreativeJudgeAbilityParam, Boolean> {

}
