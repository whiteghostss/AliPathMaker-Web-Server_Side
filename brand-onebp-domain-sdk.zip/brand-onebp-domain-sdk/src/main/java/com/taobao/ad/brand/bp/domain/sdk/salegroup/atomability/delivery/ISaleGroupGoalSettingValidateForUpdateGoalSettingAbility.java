package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.delivery;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupGoalSettingValidateForUpdateGoalSettingAbilityParam;

@AbilityDefinition(desc = "订单分组-交付优化目标校验-更新交付优化目标")
public interface ISaleGroupGoalSettingValidateForUpdateGoalSettingAbility
        extends AtomAbility<SaleGroupGoalSettingValidateForUpdateGoalSettingAbilityParam, Void> {
}
