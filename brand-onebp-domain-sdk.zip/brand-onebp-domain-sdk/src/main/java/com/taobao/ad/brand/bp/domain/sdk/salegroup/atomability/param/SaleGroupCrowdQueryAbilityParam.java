package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.experimental.SuperBuilder;

/**
 * 订单分组-分组人群获取-能力参数
 */
@SuperBuilder
public class SaleGroupCrowdQueryAbilityParam extends AtomAbilitySingleTargetParam<SaleGroupInfoViewDTO> {
}
