package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.salegroup.SaleGroupSelectJudgeViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupOrderAbilityParam;

import java.util.Map;

@AbilityDefinition(desc = "订单-分组是否支持选择-订单下单流程")
public interface ISaleGroupSelectJudgeForOrderCampaignGroupAbility extends AtomAbility<SaleGroupOrderAbilityParam, Map<Long, SaleGroupSelectJudgeViewDTO>> {

}
