package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.targets;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupCrowdTargetSupportJudgeAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;

@AbilityDefinition(desc = "单元人群定向-支持判断")
public interface IAdgroupCrowdTargetSupportJudgeAbility extends AtomAbility<AdgroupCrowdTargetSupportJudgeAbilityParam, Boolean> {

}
