package com.taobao.ad.brand.bp.domain.sdk.base.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.ability.GenericIsoBaseAbility;
import com.alibaba.abf.isolation.spec.annotation.AbilityPoint;

/**
 * 原子能力接口定义抽象
 */
public interface AtomAbility<AbilityParam extends AtomAbilityParam, AbilityResult> extends GenericIsoBaseAbility<AtomAbilityParam> {

    @AbilityPoint
    AbilityResult handle(ServiceContext serviceContext, AbilityParam abilityParam);

}
