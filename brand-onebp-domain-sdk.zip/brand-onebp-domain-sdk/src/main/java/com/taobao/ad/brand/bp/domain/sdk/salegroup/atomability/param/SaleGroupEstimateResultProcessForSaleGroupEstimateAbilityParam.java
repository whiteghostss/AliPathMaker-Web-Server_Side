package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupEstimateInfoViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilityMultiTargetsParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * 订单分组-分组预估结果处理-分组预估-能力参数
 */
@Data
@SuperBuilder
public class SaleGroupEstimateResultProcessForSaleGroupEstimateAbilityParam
        extends AtomAbilityMultiTargetsParam<CampaignGroupSaleGroupEstimateInfoViewDTO> {

    /**
     * 售卖分组预估基础参数
     */
    private BaseSaleGroupEstimateParam baseSaleGroupEstimateParam;

}
