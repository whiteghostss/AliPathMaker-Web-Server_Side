package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.salegroup.SaleGroupCheckedRebuildResultViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupCheckedSaleGroupRebuildForOrderAbilityParam;

@AbilityDefinition(desc = "订单-勾选的分组重新构建-下单流程")
public interface ICampaignGroupCheckedSaleGroupRebuildForOrderCampaignGroupAbility
        extends AtomAbility<CampaignGroupCheckedSaleGroupRebuildForOrderAbilityParam, SaleGroupCheckedRebuildResultViewDTO> {

}
