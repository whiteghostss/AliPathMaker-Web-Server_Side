package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupGetForDiffCampaignAbilityParam;

import java.util.List;

@AbilityDefinition(desc = "订单分组获取-计划对比流程")
public interface ISaleGroupGetForDiffCampaignAbility extends AtomAbility<SaleGroupGetForDiffCampaignAbilityParam, List<Long>> {

}
