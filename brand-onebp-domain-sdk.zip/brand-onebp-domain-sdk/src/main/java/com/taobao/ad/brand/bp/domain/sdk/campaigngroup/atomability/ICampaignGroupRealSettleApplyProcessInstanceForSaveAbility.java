package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.ad.brand.dto.campaigngroup.process.ProcessRecordViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupRealSettleApplyProcessInstanceForSaveAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupStopTimeUpdateForStopCastCampaignGroupAbilityParam;

import java.util.List;

@AbilityDefinition(desc = "订单-实结信息-申请工作流")
public interface ICampaignGroupRealSettleApplyProcessInstanceForSaveAbility extends AtomAbility<CampaignGroupRealSettleApplyProcessInstanceForSaveAbilityParam, Void> {

}
