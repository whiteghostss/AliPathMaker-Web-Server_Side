package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupStartApplyModifyProcessAbilityParam;

@AbilityDefinition(desc = "订单-发起改单工作流")
public interface ICampaignGroupStartApplyModifyProcessAbility extends AtomAbility<CampaignGroupStartApplyModifyProcessAbilityParam, Void> {

}
