package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupRealSettleValidateForSaveAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupStopTimeUpdateForStopCastCampaignGroupAbilityParam;

@AbilityDefinition(desc = "订单-实结信息-保存校验")
public interface ICampaignGroupRealSettleValidateForSaveAbility extends AtomAbility<CampaignGroupRealSettleValidateForSaveAbilityParam, Void> {

}
