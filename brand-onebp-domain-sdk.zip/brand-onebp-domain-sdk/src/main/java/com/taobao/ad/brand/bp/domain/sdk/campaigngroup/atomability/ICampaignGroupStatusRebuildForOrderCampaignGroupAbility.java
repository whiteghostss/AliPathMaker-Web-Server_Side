package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupAbilityParam;

@AbilityDefinition(desc = "订单-重新计算")
public interface ICampaignGroupStatusRebuildForOrderCampaignGroupAbility extends AtomAbility<CampaignGroupAbilityParam, Integer> {

}
