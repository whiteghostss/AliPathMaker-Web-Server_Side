package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupCalAutoCancelExpireTimeAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupValidateForCancelAbilityParam;

import java.util.Date;

@AbilityDefinition(desc = "订单-校验-订单撤单流程")
public interface ICampaignGroupValidateForCancelAbility extends AtomAbility<CampaignGroupValidateForCancelAbilityParam, Void> {

}
