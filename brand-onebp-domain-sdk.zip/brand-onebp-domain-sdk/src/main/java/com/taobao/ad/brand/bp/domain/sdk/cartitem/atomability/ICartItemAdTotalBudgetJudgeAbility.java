package com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.client.dto.rule.RuleCheckResultViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.param.CartItemAdDateJudgeAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.param.CartItemAdTotalBudgetJudgeAbilityParam;

@AbilityDefinition(desc = "加购行-广告投放金额判断")
public interface ICartItemAdTotalBudgetJudgeAbility extends AtomAbility<CartItemAdTotalBudgetJudgeAbilityParam, RuleCheckResultViewDTO> {

}
