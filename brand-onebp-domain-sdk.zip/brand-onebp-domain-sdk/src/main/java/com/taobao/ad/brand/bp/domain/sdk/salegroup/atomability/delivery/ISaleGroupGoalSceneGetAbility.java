package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.delivery;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupGoalSceneGetAbilityParam;

@AbilityDefinition(desc = "订单分组-交付场景获取")
public interface ISaleGroupGoalSceneGetAbility
        extends AtomAbility<SaleGroupGoalSceneGetAbilityParam, Integer> {
}
