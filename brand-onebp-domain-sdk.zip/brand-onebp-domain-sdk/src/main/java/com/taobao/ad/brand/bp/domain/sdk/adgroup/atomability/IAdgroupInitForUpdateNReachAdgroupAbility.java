package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupInitForUpdateNReachAdgroupAbilityParam;

@AbilityDefinition(desc = "单元-初始化-修改NReach单元")
public interface IAdgroupInitForUpdateNReachAdgroupAbility
        extends AtomAbility<AdgroupInitForUpdateNReachAdgroupAbilityParam, Void> {
}
