package com.taobao.ad.brand.bp.domain.sdk.campaign.businessability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.abf.isolation.spec.annotation.AbilityPoint;
import com.alibaba.abf.isolation.spec.common.IsoLevel;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbility;

@AbilityDefinition(desc = "计划算法调控通投人群添加流程-商业能力挂载点定义", level = IsoLevel.workflow)
public interface ICampaignAlgoControlCrowdAddBusinessAbilityPoint extends BusinessAbility {
    /**
     * “算法调控通投人群”添加流程-商业能力调用
     *
     * @param serviceContext
     * @param campaignViewDTO
     * @return
     */
    @AbilityPoint
    default Void invokeForCampaignAlgoControlCrowdAdd(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {
        return null;
    }
}
