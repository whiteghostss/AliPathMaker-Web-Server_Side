package com.taobao.ad.brand.bp.domain.sdk.creative.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.DoohCreativeInitForAdgroupUpdateAbilityParam;

import java.util.List;

@AbilityDefinition(desc = "天攻创意-初始化-单元更新")
public interface IDoohCreativeInitForAdgroupUpdateAbility extends AtomAbility<DoohCreativeInitForAdgroupUpdateAbilityParam, Void> {

}
