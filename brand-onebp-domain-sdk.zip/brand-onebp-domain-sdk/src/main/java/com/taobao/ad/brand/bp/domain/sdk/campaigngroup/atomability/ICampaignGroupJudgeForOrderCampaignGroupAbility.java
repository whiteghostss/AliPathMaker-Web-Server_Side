package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupTransitAbilityParam;

@AbilityDefinition(desc = "订单-判断是否支持-订单下单流程")
public interface ICampaignGroupJudgeForOrderCampaignGroupAbility extends AtomAbility<CampaignGroupTransitAbilityParam, Boolean> {

}
