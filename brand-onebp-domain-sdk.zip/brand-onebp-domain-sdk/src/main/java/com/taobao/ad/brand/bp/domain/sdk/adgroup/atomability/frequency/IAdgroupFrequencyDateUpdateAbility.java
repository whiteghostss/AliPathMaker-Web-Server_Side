package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.frequency;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupFrequencyAbilityParam;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/10/16
 **/
@AbilityDefinition(desc = "单元频控-更新频控周期-绑定单元")
public interface IAdgroupFrequencyDateUpdateAbility
        extends AtomAbility<AdgroupFrequencyAbilityParam, Void> {
}
