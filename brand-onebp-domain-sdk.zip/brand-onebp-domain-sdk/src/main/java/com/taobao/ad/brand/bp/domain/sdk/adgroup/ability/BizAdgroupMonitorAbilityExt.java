package com.taobao.ad.brand.bp.domain.sdk.adgroup.ability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.ability.GenericIsoBaseAbility;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.adgroup.ExportMonitorCodeViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.ability.param.BizAdgroupMonitorAbilityParam;

import java.util.List;
import java.util.Map;

@AbilityDefinition(desc = "单元监测能力扩展点")
public interface BizAdgroupMonitorAbilityExt extends GenericIsoBaseAbility<BaseViewDTO> {

    /**
     * 监测excel头信息
     * @param context
     * @return
     */
    default Map<String, String> getAdgroupMonitorExcelHeader(ServiceContext context){
        return null;
    }

    /**
     * 校验单元监测
     * @param serviceContext
     * @param adgroupViewDTO
     * @param abilityParam
     * @return
     */
    default Void validateAdgroupMonitor(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, BizAdgroupMonitorAbilityParam abilityParam){
        return null;
    }

    /**
     * 生成单元监测代码
     * @param serviceContext
     * @param adgroupViewDTO
     * @param abilityParam
     * @return
     */
    default List<ExportMonitorCodeViewDTO> generateAdgroupMonitor(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, BizAdgroupMonitorAbilityParam abilityParam){
        return null;
    }
}
