package com.taobao.ad.brand.bp.domain.sdk.creative.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeCustomerCategoryFillAbilityParam;

@AbilityDefinition(desc = "创意客户行业信息-填充设置")
public interface ICreativeCustomerCategoryFillAbility extends AtomAbility<CreativeCustomerCategoryFillAbilityParam, Void> {

}
