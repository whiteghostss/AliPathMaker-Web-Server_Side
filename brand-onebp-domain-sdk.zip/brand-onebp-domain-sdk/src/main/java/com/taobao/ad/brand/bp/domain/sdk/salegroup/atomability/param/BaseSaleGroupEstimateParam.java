package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * 订单分组-预估能力参数Base定义
 */
@Data
@Builder
public class BaseSaleGroupEstimateParam {

    /**
     * 订单
     */
    private CampaignGroupViewDTO campaignGroupViewDTO;
    /**
     * 售卖分组
     */
    private List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList;
    /**
     * 资源包售卖分组
     */
    private List<ResourcePackageSaleGroupViewDTO> packageSaleGroupViewDTOList;
    /**
     * 计划树列表
     */
    private List<CampaignViewDTO> campaignTreeViewDTOList;
    /**
     * 是否保存逻辑（区分展示）
     */
    private boolean isSave;
    /**
     * 是否忽略小二登陆，isIgnoreAliLogin=true:小二登陆数据展示不做拦截处理
     */
    private boolean isIgnoreAliLogin;

}
