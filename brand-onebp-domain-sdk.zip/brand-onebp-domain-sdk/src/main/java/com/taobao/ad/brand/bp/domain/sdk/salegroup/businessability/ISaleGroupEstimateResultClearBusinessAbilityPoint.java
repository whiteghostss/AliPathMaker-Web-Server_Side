package com.taobao.ad.brand.bp.domain.sdk.salegroup.businessability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.abf.isolation.spec.common.IsoLevel;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbility;

import java.util.List;

@AbilityDefinition(desc = "售卖分组预估结果清空流程-商业能力定义挂载点定义", level = IsoLevel.workflow)
public interface ISaleGroupEstimateResultClearBusinessAbilityPoint extends BusinessAbility {
    /**
     * 商业能力执行器
     *
     * @param serviceContext
     * @param campaignGroupId
     * @param saleGroupIds
     * @return
     */
    default Void invokeForClearSaleGroupEstimateResult(ServiceContext serviceContext, Long campaignGroupId, List<Long> saleGroupIds) {
        return null;
    }
}
