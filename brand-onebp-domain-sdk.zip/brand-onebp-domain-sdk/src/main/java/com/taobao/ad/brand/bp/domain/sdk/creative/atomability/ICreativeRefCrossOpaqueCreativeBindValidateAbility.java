package com.taobao.ad.brand.bp.domain.sdk.creative.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeRefCrossOpaqueCreativeBindValidateAbilityParam;

@AbilityDefinition(desc = "创意-全域通黑盒创意绑定-校验")
public interface ICreativeRefCrossOpaqueCreativeBindValidateAbility extends AtomAbility<CreativeRefCrossOpaqueCreativeBindValidateAbilityParam, Void> {

}
