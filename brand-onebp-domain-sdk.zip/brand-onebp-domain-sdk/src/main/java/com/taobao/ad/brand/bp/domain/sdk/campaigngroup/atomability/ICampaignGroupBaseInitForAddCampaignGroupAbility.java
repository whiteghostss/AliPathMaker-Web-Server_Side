package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupBaseAbilityParam;

@AbilityDefinition(desc = "订单-基础信息初始化-新建流程")
public interface ICampaignGroupBaseInitForAddCampaignGroupAbility extends AtomAbility<CampaignGroupBaseAbilityParam, Void> {

}
