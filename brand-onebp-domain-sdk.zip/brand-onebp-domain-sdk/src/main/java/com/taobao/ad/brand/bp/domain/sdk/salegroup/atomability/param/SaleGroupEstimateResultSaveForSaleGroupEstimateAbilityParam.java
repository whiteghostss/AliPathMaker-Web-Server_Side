package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;


import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupEstimateInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.CampaignGroupSaleGroupEstimateQueryViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

import java.util.List;

/**
 * 订单分组-分组预估结果保存-分组预估-能力参数
 */
@Data
@SuperBuilder
public class SaleGroupEstimateResultSaveForSaleGroupEstimateAbilityParam
        extends AtomAbilitySingleTargetParam<CampaignGroupSaleGroupEstimateQueryViewDTO> {

    /**
     * 售卖分组预估信息列表
     */
    private List<CampaignGroupSaleGroupEstimateInfoViewDTO> saleGroupEstimateInfoViewDTOList;

}
