package com.taobao.ad.brand.bp.domain.sdk.motion.workflow.param;

import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.taobao.ad.brand.bp.client.dto.motion.IntelligentMotionViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSkuViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.workflow.WorkflowParam;
import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * Description:计划command场景扩展参数定义
 * <p>
 * date: 2023/10/24 11:49 AM
 *
 * @author shiyan
 * @version 1.0
 */
@Data
public class BizIntelligentStrategyWorkflowParam extends WorkflowParam {
    /**
     * 加购行列表
     */
    private List<CartItemViewDTO> cartItemViewDTOList;
    /**
     * 加购行和sku Map映射(key:cartId,value:skuId)
     */
    private Map<Long, Long> cartAndSkuMap;
    /**
     * sku列表
     */
    private List<BrandSkuViewDTO> brandSkuViewDTOList;
    /**
     * sku和打包平台二级产品 Map映射(key:skuId, value:resourcePackageProductId)
     */
    private Map<Long, Long> skuAndResourceProductMap;
    /**
     * 分组-售卖产品线映射关系
     */
    private Map<Long, Integer> saleGroupSaleProductLineMap;
    /**
     * 打包平台二级产品Map
     */
    Map<Long, ResourcePackageProductViewDTO> resourcePackageProductViewDTOMap;
}
