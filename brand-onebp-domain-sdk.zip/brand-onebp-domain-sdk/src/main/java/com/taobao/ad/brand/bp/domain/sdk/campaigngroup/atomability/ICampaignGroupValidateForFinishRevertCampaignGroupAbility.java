package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupValidateForFinishCampaignGroupAbilityParam;

@AbilityDefinition(desc = "订单-校验-订单完成打回流程")
public interface ICampaignGroupValidateForFinishRevertCampaignGroupAbility extends AtomAbility<CampaignGroupValidateForFinishCampaignGroupAbilityParam, Void> {

}
