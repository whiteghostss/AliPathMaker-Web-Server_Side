package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupCreateRuleValidateForAddOrUpdateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupStatusOnlineValidateForAddOrUpdateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;

@AbilityDefinition(desc = "单元-新建规则校验")
public interface IAdgroupCreateRuleValidateForAddOrUpdateAbility extends AtomAbility<AdgroupCreateRuleValidateForAddOrUpdateAbilityParam, Void> {

}
