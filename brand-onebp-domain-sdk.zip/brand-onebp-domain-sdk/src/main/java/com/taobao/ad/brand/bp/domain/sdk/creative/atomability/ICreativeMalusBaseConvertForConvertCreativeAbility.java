package com.taobao.ad.brand.bp.domain.sdk.creative.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeMalusBaseConvertAbilityParam;

@AbilityDefinition(desc = "创意数据-基础构建-转换创意")
public interface ICreativeMalusBaseConvertForConvertCreativeAbility extends AtomAbility<CreativeMalusBaseConvertAbilityParam, CreativeViewDTO> {

}
