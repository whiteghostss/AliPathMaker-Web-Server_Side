package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param;

import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * 单元-生成NReach单元判断能力参数
 */
@Data
@SuperBuilder
public class AdgroupNReachJudgeAbilityParam extends AtomAbilitySingleTargetParam<CampaignViewDTO> {

    /**
     * 单元信息
     */
    private SaleGroupInfoViewDTO saleGroupInfoViewDTO;

}
