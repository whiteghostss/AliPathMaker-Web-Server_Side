package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupSaleGroupEstimateValidateForOrderAbilityParam;

@AbilityDefinition(desc = "订单-分组预估校验-下单")
public interface ICampaignGroupSaleGroupEstimateValidateForOrderAbility
        extends AtomAbility<CampaignGroupSaleGroupEstimateValidateForOrderAbilityParam, Void> {
}
