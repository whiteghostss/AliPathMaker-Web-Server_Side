package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupSaleGroupAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupInquiryInfoUpdateForNoticeSaleGroupAbilityParam;

@AbilityDefinition(desc = "订单分组-盘量信息更新-同步分组")
public interface ISaleGroupInquiryInfoUpdateForNoticeSaleGroupAbility extends AtomAbility<SaleGroupInquiryInfoUpdateForNoticeSaleGroupAbilityParam, Void> {

}
