package com.taobao.ad.brand.bp.domain.sdk.creative.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeRefCreativeDealValidateAbilityParam;

@AbilityDefinition(desc = "创意绑定-deal-校验")
public interface ICreativeRefCreativeDealValidateAbility extends AtomAbility<CreativeRefCreativeDealValidateAbilityParam, Void> {

}
