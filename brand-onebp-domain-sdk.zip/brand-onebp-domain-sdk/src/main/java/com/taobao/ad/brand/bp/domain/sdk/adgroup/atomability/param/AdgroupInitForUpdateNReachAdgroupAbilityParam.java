package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param;

import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * 单元-初始化-修改NReach单元-能力参数
 */
@Data
@SuperBuilder
public class AdgroupInitForUpdateNReachAdgroupAbilityParam extends AtomAbilitySingleTargetParam<AdgroupViewDTO> {

    /**
     * 计划信息
     */
    private CampaignViewDTO campaignViewDTO;

}
