package com.taobao.ad.brand.bp.domain.sdk.campaign.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignUpdateCastDateAbilityParam;

@AbilityDefinition(desc = "计划-投放时间-修改")
public interface ICampaignCastDateUpdateAbility extends AtomAbility<CampaignUpdateCastDateAbilityParam, Boolean> {

}
