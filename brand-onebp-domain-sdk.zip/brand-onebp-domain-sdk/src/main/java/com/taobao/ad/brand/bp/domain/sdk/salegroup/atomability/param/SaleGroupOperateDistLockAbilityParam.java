package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilityMultiTargetsParam;
import lombok.experimental.SuperBuilder;

/**
 * 订单分组操作分布式锁参数
 */
@SuperBuilder
public class SaleGroupOperateDistLockAbilityParam extends AtomAbilityMultiTargetsParam<Long> {
}
