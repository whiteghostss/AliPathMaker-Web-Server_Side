package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

import java.util.List;

/**
 * 订单分组-分组pv预算信息-计算参数
 */
@Data
@SuperBuilder
public class SaleGroupPvBudgetForCalculateUpdateSaleGroupAbilityParam extends AtomAbilitySingleTargetParam<SaleGroupInfoViewDTO> {
    /**
     * 资源包售卖分组信息
     */
    private ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO;
    /**
     * 一级计划预算信息
     */
    private List<CampaignViewDTO> levelOneCampaignViewDTOList;
}
