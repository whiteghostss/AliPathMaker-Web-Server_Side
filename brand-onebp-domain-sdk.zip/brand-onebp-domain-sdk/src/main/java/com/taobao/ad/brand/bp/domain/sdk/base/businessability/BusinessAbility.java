package com.taobao.ad.brand.bp.domain.sdk.base.businessability;

import com.alibaba.abf.isolation.ability.GenericIsoRouteAbility;
import com.alibaba.ad.brand.dto.base.BaseViewDTO;

/**
 * Description:百灵BP商业能力抽象
 * <p>
 * date: 2023/10/24 2:51 PM
 *
 * @author shiyan
 * @version 1.0
 */
public interface BusinessAbility extends GenericIsoRouteAbility<BaseViewDTO, BusinessAbilityRouteContext> {
    @Override
    default boolean routeChecking(String bizCode, BaseViewDTO baseViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        return false;
    }
}