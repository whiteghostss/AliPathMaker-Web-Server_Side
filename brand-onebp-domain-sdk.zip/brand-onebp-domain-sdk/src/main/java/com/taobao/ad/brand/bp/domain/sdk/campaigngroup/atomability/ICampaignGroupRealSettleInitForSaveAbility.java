package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupRealSettleInitForSaveAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupStopTimeUpdateForStopCastCampaignGroupAbilityParam;

@AbilityDefinition(desc = "订单-实结信息-初始化")
public interface ICampaignGroupRealSettleInitForSaveAbility extends AtomAbility<CampaignGroupRealSettleInitForSaveAbilityParam, Void> {

}
