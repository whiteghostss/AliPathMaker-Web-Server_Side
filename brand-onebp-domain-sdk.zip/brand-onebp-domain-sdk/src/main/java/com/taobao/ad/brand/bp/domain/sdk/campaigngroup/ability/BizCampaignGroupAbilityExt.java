package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.ability;

import com.alibaba.abf.isolation.ability.GenericIsoBaseAbility;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.ad.brand.dto.base.BaseViewDTO;

@AbilityDefinition(desc = "订单能力扩展点")
public interface BizCampaignGroupAbilityExt extends GenericIsoBaseAbility<BaseViewDTO> {
//    void initSaleGroupPackageProductCalculateInfo(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, Map<Long, ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupMap, Map<Long, List<CampaignViewDTO>> saleGroupCampaignMap);
}
