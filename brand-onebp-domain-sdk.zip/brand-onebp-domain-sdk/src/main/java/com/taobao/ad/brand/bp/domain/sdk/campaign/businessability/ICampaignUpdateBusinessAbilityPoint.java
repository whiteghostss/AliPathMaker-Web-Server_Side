package com.taobao.ad.brand.bp.domain.sdk.campaign.businessability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.abf.isolation.spec.annotation.AbilityPoint;
import com.alibaba.abf.isolation.spec.common.IsoLevel;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbility;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbilityRouteContext;

import java.util.List;

@AbilityDefinition(desc = "计划修改流程-商业能力挂载点定义", level = IsoLevel.workflow)
public interface ICampaignUpdateBusinessAbilityPoint extends BusinessAbility {
    /**
     * 修改流程-商业能力调用
     * @param serviceContext
     * @param pageCampaignViewDTO 接口传入的计划
     * @param campaignViewDTOForUpdate 进行更新的计划
     * @param dbLevelOneCampaignTreeViewDTO db存储的计划
     * @param businessAbilityRouteContext
     * @return
     */
    @AbilityPoint
    default Void invokeForCampaignUpdate(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, CampaignViewDTO dbLevelOneCampaignTreeViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        return null;
    }

    /**
     * 修改流程-商业能力调用
     *
     * @param serviceContext
     * @param campaignViewDTOList
     * @param businessAbilityRouteContext
     * @return
     */
    @AbilityPoint
    default Void invokeForAfterCampaignUpdate(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList, BusinessAbilityRouteContext businessAbilityRouteContext) {
        return null;
    }

    /**
     * 部分更新计划定向配置
     * @param serviceContext
     * @param pageCampaignViewDTO
     * @param dbCampaignTreeViewDTO
     * @param updateSubCampaign
     * @return
     */
    @AbilityPoint
    default Void invokeForCampaignTargetUpdatePart(ServiceContext serviceContext, CampaignViewDTO pageCampaignViewDTO, CampaignViewDTO dbCampaignTreeViewDTO, boolean updateSubCampaign) {
        return null;
    }
}
