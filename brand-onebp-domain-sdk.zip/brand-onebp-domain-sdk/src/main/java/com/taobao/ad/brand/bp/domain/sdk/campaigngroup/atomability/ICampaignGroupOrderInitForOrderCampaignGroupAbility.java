package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupBaseAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupOrderInitForOrderAbilityParam;

@AbilityDefinition(desc = "订单-下单信息初始化-下单流程")
public interface ICampaignGroupOrderInitForOrderCampaignGroupAbility extends AtomAbility<CampaignGroupOrderInitForOrderAbilityParam, Void> {

}
