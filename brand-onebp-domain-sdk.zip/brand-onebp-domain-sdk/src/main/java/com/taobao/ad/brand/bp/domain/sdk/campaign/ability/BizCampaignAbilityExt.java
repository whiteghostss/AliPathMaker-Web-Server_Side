package com.taobao.ad.brand.bp.domain.sdk.campaign.ability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.ability.GenericIsoBaseAbility;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.domain.sdk.campaign.ability.param.BizCampaignAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.ability.param.BizCampaignSplitAbilityParam;

import java.util.List;

@Deprecated
@AbilityDefinition(desc = "计划能力扩展点")
public interface BizCampaignAbilityExt extends GenericIsoBaseAbility<BaseViewDTO> {

    default List<CampaignViewDTO> splitCampaign(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, BizCampaignSplitAbilityParam paramDefinition){
        return Lists.newArrayList(campaignViewDTO);
    }

    default List<CampaignViewDTO> splitSubCampaign (ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, BizCampaignAbilityParam paramDefinition){
        return null;
    }

    default Void addCampaign(ServiceContext serviceContext, Long campaignGroupId, List<CampaignViewDTO> campaignViewDTOList){
        return null;
    }

    default Void updateCampaign(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList){
        return null;
    }

    default Void physicsDelCampaign(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO){
        return null;
    }
}
