package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import lombok.Builder;
import lombok.Data;

/**
 * Description:售卖分组-交付优化目标设置
 * <p>
 * date: 2024/3/19
 * @author shiyan
 * @version 1.0
 */
@Data
@Builder
public class BaseSaleGroupGoalSettingParam {
    /**
     * 订单
     */
    private CampaignGroupViewDTO campaignGroupViewDTO;
    /**
     * 售卖分组
     */
    private SaleGroupInfoViewDTO saleGroupInfoViewDTO;
    /**
     * 资源包售卖分组
     */
    private ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO;
}
