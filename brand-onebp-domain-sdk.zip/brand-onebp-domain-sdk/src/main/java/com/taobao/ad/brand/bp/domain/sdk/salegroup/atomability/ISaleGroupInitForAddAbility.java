package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupInitAbilityParam;

@AbilityDefinition(desc = "订单-订单分组新建初始化-新建或更新订单流程")
public interface ISaleGroupInitForAddAbility extends AtomAbility<SaleGroupInitAbilityParam, Void> {

}
