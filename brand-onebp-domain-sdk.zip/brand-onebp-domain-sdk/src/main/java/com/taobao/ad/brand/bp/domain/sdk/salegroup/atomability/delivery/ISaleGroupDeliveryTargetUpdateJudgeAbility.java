package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.delivery;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupDeliveryTargetUpdateJudgeAbilityParam;

@AbilityDefinition(desc = "订单分组-校验资源包交付目标是否更新")
public interface ISaleGroupDeliveryTargetUpdateJudgeAbility
        extends AtomAbility<SaleGroupDeliveryTargetUpdateJudgeAbilityParam, Boolean> {
}
