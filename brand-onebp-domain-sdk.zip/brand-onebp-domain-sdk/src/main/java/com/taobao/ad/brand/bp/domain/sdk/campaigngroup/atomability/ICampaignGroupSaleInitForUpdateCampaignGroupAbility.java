package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupSaleAbilityParam;

@AbilityDefinition(desc = "订单-售卖初始化-更新订单流程")
public interface ICampaignGroupSaleInitForUpdateCampaignGroupAbility extends AtomAbility<CampaignGroupSaleAbilityParam, Void> {

}
