package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param;

import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryOption;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * 单元结构-查询-能力参数
 */
@Data
@SuperBuilder
public class AdgroupStructureQueryAbilityParam extends AtomAbilitySingleTargetParam<AdgroupQueryViewDTO> {

    /**
     * 查询选项
     */
    private AdgroupQueryOption queryOption;

}
