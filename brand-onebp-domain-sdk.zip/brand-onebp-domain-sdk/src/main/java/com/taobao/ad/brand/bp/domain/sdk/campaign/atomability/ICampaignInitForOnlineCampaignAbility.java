package com.taobao.ad.brand.bp.domain.sdk.campaign.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignForOnlineAbilityParam;

import java.util.List;
// 更新上线计划的合同id、子合同id、状态、首次上线时间信息
@AbilityDefinition(desc = "计划信息-更新-上线计划")
public interface ICampaignInitForOnlineCampaignAbility extends AtomAbility<CampaignForOnlineAbilityParam, List<CampaignViewDTO>> {
}
