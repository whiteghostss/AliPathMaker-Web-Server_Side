package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupStatusValidateForUpdateSaleGroupAbilityParam;

@AbilityDefinition(desc = "订单分组-状态校验-更新订单分组")
public interface ISaleGroupStatusValidateForUpdateSaleGroupAbility
        extends AtomAbility<SaleGroupStatusValidateForUpdateSaleGroupAbilityParam, Void> {
}
