package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupInitForAddNReachAdgroupAbilityParam;

@AbilityDefinition(desc = "单元-初始化-新建NReach单元")
public interface IAdgroupInitForAddNReachAdgroupAbility
        extends AtomAbility<AdgroupInitForAddNReachAdgroupAbilityParam, Void> {
}
