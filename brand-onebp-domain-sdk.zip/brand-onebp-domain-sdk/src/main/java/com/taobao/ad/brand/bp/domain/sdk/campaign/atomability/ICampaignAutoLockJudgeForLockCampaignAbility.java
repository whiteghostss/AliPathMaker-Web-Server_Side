package com.taobao.ad.brand.bp.domain.sdk.campaign.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignAutoLockAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignAutoSaveAbilityParam;

@AbilityDefinition(desc = "计划-自动锁量判断-自动锁量计划流程")
public interface ICampaignAutoLockJudgeForLockCampaignAbility extends AtomAbility<CampaignAutoLockAbilityParam, Boolean> {

}
