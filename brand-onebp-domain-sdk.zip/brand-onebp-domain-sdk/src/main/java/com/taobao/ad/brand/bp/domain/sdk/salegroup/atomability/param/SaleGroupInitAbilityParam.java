package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleGroupSourceEnum;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilityMultiTargetsParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

import java.util.List;
import java.util.Map;

/**
 * 订单-合同
 */
@Data
@SuperBuilder
public class SaleGroupInitAbilityParam extends AtomAbilityMultiTargetsParam<SaleGroupInfoViewDTO> {
    /**
     * 来源
     */
    private BrandSaleGroupSourceEnum saleGroupSourceEnum;
    /**
     * 操作的分组id
     */
    private List<Long> operateSaleGroupIds;
    /**
     * 资源包分组信息
     */
    private Map<Long, ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupMap;

    /**
     * 售卖产品线-子合同列表
     */
    Map<Integer, Long> saleProductLine2SubContractIdMap;
}
