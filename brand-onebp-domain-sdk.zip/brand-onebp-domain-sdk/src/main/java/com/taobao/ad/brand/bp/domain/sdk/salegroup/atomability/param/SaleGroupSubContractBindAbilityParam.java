package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSubContractViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilityMultiTargetsParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

import java.util.List;

/**
 * 分组下单状态更新
 */
@Data
@SuperBuilder
public class SaleGroupSubContractBindAbilityParam extends AtomAbilityMultiTargetsParam<SaleGroupInfoViewDTO> {
    /**
     * 订单
     */
    private CampaignGroupViewDTO campaignGroupViewDTO;

    private List<Long> targetSaleGroupIds;

    private List<CampaignGroupSubContractViewDTO> subContractViewDTOList;

}
