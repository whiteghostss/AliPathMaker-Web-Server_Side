package com.taobao.ad.brand.bp.domain.sdk.salegroup.businessability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.abf.isolation.spec.common.IsoLevel;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupPageViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbility;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbilityRouteContext;

import java.util.List;

@AbilityDefinition(desc = "订单分组查询可选择的售卖分组流程-商业能力挂载点定义", level = IsoLevel.workflow)
public interface ISaleGroupCanSelectStatusQueryBusinessAbilityPoint extends BusinessAbility {

    /**
     * 商业能力执行器
     *
     * @param context
     * @param campaignGroupSaleGroupPageViewDTO
     * @param dbSaleGroupInfoViewDTO
     * @param campaignViewDTOList
     * @param businessAbilityRouteContext
     * @return
     */
    Void invokeForFindCanSelectStatusSaleGroup(ServiceContext context, CampaignGroupSaleGroupPageViewDTO campaignGroupSaleGroupPageViewDTO, SaleGroupInfoViewDTO dbSaleGroupInfoViewDTO, List<CampaignViewDTO> campaignViewDTOList, BusinessAbilityRouteContext businessAbilityRouteContext);
}
