package com.taobao.ad.brand.bp.domain.sdk.campaign.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignTitleInitAbilityParam;

@AbilityDefinition(desc = "计划-标题-初始化")
public interface ICampaignTitleInitAbility extends AtomAbility<CampaignTitleInitAbilityParam, String> {

}
