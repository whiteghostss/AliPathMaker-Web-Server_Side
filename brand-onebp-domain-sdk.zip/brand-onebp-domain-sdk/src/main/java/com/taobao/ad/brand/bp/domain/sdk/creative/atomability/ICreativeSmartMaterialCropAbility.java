package com.taobao.ad.brand.bp.domain.sdk.creative.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.ad.brand.dto.creative.materialgroup.MaterialViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeSmartMaterialCropAbilityParam;

import java.util.List;

@AbilityDefinition(desc = "创意-智能元素拓版")
public interface ICreativeSmartMaterialCropAbility extends AtomAbility<CreativeSmartMaterialCropAbilityParam, String> {

}
