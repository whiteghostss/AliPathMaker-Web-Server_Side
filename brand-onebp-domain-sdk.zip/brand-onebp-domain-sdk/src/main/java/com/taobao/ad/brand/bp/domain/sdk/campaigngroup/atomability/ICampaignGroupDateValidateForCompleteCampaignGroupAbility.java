package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupDateValidateForCompleteCampaignGroupAbilityParam;

@AbilityDefinition(desc = "订单-日期校验-订单结案流程")
public interface ICampaignGroupDateValidateForCompleteCampaignGroupAbility extends AtomAbility<CampaignGroupDateValidateForCompleteCampaignGroupAbilityParam, Void> {

}
