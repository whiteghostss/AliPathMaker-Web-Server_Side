package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.workflow;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.ability.GenericIsoBaseAbility;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupPageViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSettleInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SaleGroupCanDeleteViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;

import java.util.List;
import java.util.Map;

/**
 * Description:订单查询workflow扩展点
 *
 * @author yanjingang
 */
@AbilityDefinition(desc = "订单查询业务流程扩展点")
public interface BizCampaignGroupQueryWorkflowExt extends GenericIsoBaseAbility<BaseViewDTO> {

    /**
     * 校验分组是否可以删除
     *
     * @param subContext
     * @param subCampaignGroup
     * @param saleGroupIds
     * @return
     */
    Map<Long, SaleGroupCanDeleteViewDTO> checkSaleGroupCanDelete(ServiceContext subContext, CampaignGroupViewDTO subCampaignGroup, List<Long> saleGroupIds);

    /**
     * 获取订单结算信息
     * @param context
     * @param campaignGroupViewDTO
     * @param saleGroupList
     * @return
     */
    CampaignGroupSettleInfoViewDTO getCampaignGroupRealSettleInfos(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, List<ResourcePackageSaleGroupViewDTO> saleGroupList);

    /**
     * 补充分组信息
     * @param serviceContext
     * @param campaignGroupSaleGroupList - 订单分组
     * @return
     */
    Void fillOtherInfo(ServiceContext serviceContext, List<CampaignGroupSaleGroupPageViewDTO> campaignGroupSaleGroupList, List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupList);

}