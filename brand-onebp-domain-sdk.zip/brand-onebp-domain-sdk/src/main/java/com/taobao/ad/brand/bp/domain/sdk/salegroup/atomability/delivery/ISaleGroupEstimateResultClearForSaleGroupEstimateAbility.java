package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.delivery;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupEstimateResultClearForSaleGroupEstimateAbilityParam;

@AbilityDefinition(desc = "订单分组-交付预估结果清空-分组预估")
public interface ISaleGroupEstimateResultClearForSaleGroupEstimateAbility
        extends AtomAbility<SaleGroupEstimateResultClearForSaleGroupEstimateAbilityParam, Void> {
}
