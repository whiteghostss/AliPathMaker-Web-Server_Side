package com.taobao.ad.brand.bp.domain.sdk.base.workflow;

/**
 * 流程扩展参数
 */
public class WorkflowParam {

}
