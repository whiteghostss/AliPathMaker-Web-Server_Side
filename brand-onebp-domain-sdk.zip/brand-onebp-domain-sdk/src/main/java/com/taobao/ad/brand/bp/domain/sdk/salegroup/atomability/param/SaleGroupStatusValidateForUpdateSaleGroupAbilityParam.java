package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * 订单分组-状态校验-更新订单分组-能力参数
 */
@Data
@SuperBuilder
public class SaleGroupStatusValidateForUpdateSaleGroupAbilityParam
        extends AtomAbilitySingleTargetParam<CampaignGroupViewDTO> {

    /**
     * 订单分组信息
     */
    private SaleGroupInfoViewDTO saleGroupInfoViewDTO;
}
