package com.taobao.ad.brand.bp.domain.sdk.creative.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.ad.brand.dto.creative.materialgroup.MaterialViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeSmartMaterialCropAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeSmartMaterialMainImageGetAbilityParam;

import java.util.List;

@AbilityDefinition(desc = "智能创意-获取素材主图")
public interface ICreativeSmartMaterialMainImageGetAbility extends AtomAbility<CreativeSmartMaterialMainImageGetAbilityParam, List<MaterialViewDTO>> {

}
