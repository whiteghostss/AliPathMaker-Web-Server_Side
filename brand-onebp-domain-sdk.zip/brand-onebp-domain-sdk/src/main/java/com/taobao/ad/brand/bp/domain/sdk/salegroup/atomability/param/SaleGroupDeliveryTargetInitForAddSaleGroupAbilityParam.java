package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * 订单分组-交付目标初始化-添加订单分组-能力参数
 */
@Data
@SuperBuilder
public class SaleGroupDeliveryTargetInitForAddSaleGroupAbilityParam extends AtomAbilitySingleTargetParam<SaleGroupInfoViewDTO> {

    /**
     * 资源包售卖分组
     */
    private ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO;

}
