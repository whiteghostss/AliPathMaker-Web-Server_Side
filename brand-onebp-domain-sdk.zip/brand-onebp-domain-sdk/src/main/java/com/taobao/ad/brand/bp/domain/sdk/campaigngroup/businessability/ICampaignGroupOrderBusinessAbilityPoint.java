package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.businessability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.abf.isolation.spec.annotation.AbilityPoint;
import com.alibaba.abf.isolation.spec.common.IsoLevel;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupOrderCommandViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbility;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbilityRouteContext;

import java.util.List;

@AbilityDefinition(desc = "订单下单流程-商业能力挂载点定义", level = IsoLevel.workflow)
public interface ICampaignGroupOrderBusinessAbilityPoint extends BusinessAbility {
    /**
     * 下单流程-商业能力调用
     *
     * @param serviceContext
     * @param campaignGroupOrderCommandViewDTO
     * @param campaignGroupViewDTO
     * @param campaignList
     * @param resourcePackageSaleGroupList
     * @param businessAbilityRouteContext
     * @return
     */
    @AbilityPoint
    default Void invokeForCampaignGroupOrder(ServiceContext serviceContext, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO,
                                             CampaignGroupViewDTO campaignGroupViewDTO, List<CampaignViewDTO> campaignList,
                                             List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupList, BusinessAbilityRouteContext businessAbilityRouteContext) {
        return null;
    }
}
