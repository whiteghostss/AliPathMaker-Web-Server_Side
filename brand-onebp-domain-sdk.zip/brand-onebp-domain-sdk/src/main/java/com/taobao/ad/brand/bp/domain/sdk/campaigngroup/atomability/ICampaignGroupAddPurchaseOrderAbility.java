package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupPurchaseProcessViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupPurchaseOrderAbilityParam;

@AbilityDefinition(desc = "订单-发起采购")
public interface ICampaignGroupAddPurchaseOrderAbility extends AtomAbility<CampaignGroupPurchaseOrderAbilityParam, CampaignGroupPurchaseProcessViewDTO> {

}
