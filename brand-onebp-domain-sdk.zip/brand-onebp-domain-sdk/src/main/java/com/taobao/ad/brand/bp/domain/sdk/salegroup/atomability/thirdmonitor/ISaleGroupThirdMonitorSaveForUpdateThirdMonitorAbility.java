package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.thirdmonitor;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupThirdMonitorSaveForUpdateThirdMonitorAbilityParam;

@AbilityDefinition(desc = "订单分组-第三方监测保存-更新第三方监测")
public interface ISaleGroupThirdMonitorSaveForUpdateThirdMonitorAbility
        extends AtomAbility<SaleGroupThirdMonitorSaveForUpdateThirdMonitorAbilityParam, Void> {
}
