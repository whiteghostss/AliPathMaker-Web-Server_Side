package com.taobao.ad.brand.bp.domain.sdk.campaign.workflow;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.ability.GenericIsoBaseAbility;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignDelayLockApplyViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignInquiryOperateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignInventoryAutoReleaseMsgViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignScheduleViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignScheduleOperateTypeEnum;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignAutoReleaseWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignInventoryWorkflowParam;

import java.util.List;

/**
 * Description:计划库存流程切入点接口
 * <p>
 * date: 2023/10/13 12:03 AM
 *
 * @author shiyan
 * @version 1.0
 */
@AbilityDefinition(desc = "计划库存业务流程扩展点")
public interface BizCampaignInventoryWorkflowExt extends GenericIsoBaseAbility<BaseViewDTO> {
    /**
     * 构建扩展参数
     * @param serviceContext
     * @param inquiryOperateViewDTO
     * @return
     */
    default BizCampaignInventoryWorkflowParam buildParamForInventory(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO) {

        return null;
    }

    /**
     * 库存询缩量回调，后置链路处理
     *
     * @param serviceContext
     * @param inventoryCallbackViewDTO
     * @param inventoryWorkflowParam
     * @param campaignScheduleViewDTOList
     * @return
     */
    default Void afterInventoryCallback(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inventoryCallbackViewDTO, BizCampaignInventoryWorkflowParam inventoryWorkflowParam, List<CampaignScheduleViewDTO> campaignScheduleViewDTOList){
        return null;
    }

    /**
     * 库存自动释量预警校验
     *
     * @param context
     * @param inventoryAutoReleaseMsgViewDTOList
     * @return
     */
    default Void beforeInventoryAutoReleaseWarning(ServiceContext context, List<CampaignInventoryAutoReleaseMsgViewDTO> inventoryAutoReleaseMsgViewDTOList){
        return null;
    }

    default void afterInventoryInquiryOrLock(ServiceContext serviceContext, BizCampaignInventoryWorkflowParam inventoryWorkflowParam, CampaignScheduleOperateTypeEnum operateTypeEnum) {

    }

    default List<BizCampaignAutoReleaseWorkflowParam> buildAutoReleaseDelayLockParamExt(ServiceContext serviceContext,
                                                                                        CampaignDelayLockApplyViewDTO campaignDelayLockApplyViewDTO) {
        return null;
    }

}