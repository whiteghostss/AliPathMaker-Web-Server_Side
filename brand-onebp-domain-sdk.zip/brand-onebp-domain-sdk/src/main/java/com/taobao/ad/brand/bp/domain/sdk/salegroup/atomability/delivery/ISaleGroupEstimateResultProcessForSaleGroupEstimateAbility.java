package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.delivery;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupEstimateResultProcessForSaleGroupEstimateAbilityParam;

@AbilityDefinition(desc = "订单分组-分组预估结果处理-分组预估")
public interface ISaleGroupEstimateResultProcessForSaleGroupEstimateAbility
        extends AtomAbility<SaleGroupEstimateResultProcessForSaleGroupEstimateAbilityParam, Void> {
}
