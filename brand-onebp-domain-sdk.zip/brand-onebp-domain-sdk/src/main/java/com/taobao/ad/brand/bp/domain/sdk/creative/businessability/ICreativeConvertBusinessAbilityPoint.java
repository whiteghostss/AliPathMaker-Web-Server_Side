package com.taobao.ad.brand.bp.domain.sdk.creative.businessability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.abf.isolation.spec.annotation.AbilityPoint;
import com.alibaba.abf.isolation.spec.common.IsoLevel;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeMalusTemplateViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeSaveViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbility;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbilityRouteContext;

@AbilityDefinition(desc = "海棠模板数据转百灵创意-商业能力挂载点定义", level = IsoLevel.workflow)
public interface ICreativeConvertBusinessAbilityPoint extends BusinessAbility {
    /**
     * 执行商业能力调用
     * @param serviceContext
     * @param creativeViewDTO
     * @param malusTemplateViewDTO
     * @return
     */
    @AbilityPoint
    Void invokeForCreativeConvert(ServiceContext serviceContext, CreativeViewDTO creativeViewDTO, CreativeMalusTemplateViewDTO malusTemplateViewDTO);
}
