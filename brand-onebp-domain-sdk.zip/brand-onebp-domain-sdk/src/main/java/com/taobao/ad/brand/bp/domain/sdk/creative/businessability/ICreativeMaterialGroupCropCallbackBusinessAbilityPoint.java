package com.taobao.ad.brand.bp.domain.sdk.creative.businessability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.abf.isolation.spec.annotation.AbilityPoint;
import com.alibaba.abf.isolation.spec.common.IsoLevel;
import com.taobao.ad.brand.bp.client.dto.creative.crop.MalusCropResultViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbility;

@AbilityDefinition(desc = "创意素材异步组拓版回调流程-商业能力挂载点定义", level = IsoLevel.workflow)
public interface ICreativeMaterialGroupCropCallbackBusinessAbilityPoint extends BusinessAbility {
    /**
     * 执行商业能力调用
     * @param serviceContext
     * @param malusCropResultViewDTO
     * @return
     */
    @AbilityPoint
    Void invokeForMaterialGroupCropCallback(ServiceContext serviceContext, MalusCropResultViewDTO malusCropResultViewDTO);
}
