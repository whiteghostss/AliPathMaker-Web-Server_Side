package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupCompleteConfigAbilityParam;

@AbilityDefinition(desc = "订单-结案账号初始化-新建订单流程")
public interface ICampaignGroupCompleteConfigInitForAddCampaignGroupAbility extends AtomAbility<CampaignGroupCompleteConfigAbilityParam, Void> {

}
