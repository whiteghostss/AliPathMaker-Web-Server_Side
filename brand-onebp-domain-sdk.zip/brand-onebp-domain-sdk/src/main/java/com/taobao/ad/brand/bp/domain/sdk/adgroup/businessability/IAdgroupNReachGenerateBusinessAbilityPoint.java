package com.taobao.ad.brand.bp.domain.sdk.adgroup.businessability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.abf.isolation.spec.annotation.AbilityPoint;
import com.alibaba.abf.isolation.spec.common.IsoLevel;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbility;

@AbilityDefinition(desc = "生成N+Reach单元流程-商业能力挂载点定义", level = IsoLevel.workflow)
public interface IAdgroupNReachGenerateBusinessAbilityPoint extends BusinessAbility {
    /**
     * 执行商业能力调用
     *
     * @param serviceContext
     * @param campaignViewDTO
     * @return
     */
    @AbilityPoint
    default AdgroupViewDTO invokeForGenerateNReachAdgroup(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {
        return null;
    }
}
