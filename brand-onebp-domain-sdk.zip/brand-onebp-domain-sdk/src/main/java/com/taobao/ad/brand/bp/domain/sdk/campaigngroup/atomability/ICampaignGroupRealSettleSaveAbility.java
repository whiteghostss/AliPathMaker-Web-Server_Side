package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupRealSettleSaveAbilityParam;

@AbilityDefinition(desc = "订单-实结信息-保存")
public interface ICampaignGroupRealSettleSaveAbility extends AtomAbility<CampaignGroupRealSettleSaveAbilityParam, Integer> {

}
