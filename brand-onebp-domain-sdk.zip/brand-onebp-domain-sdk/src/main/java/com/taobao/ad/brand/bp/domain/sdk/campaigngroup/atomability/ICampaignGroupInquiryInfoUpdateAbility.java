package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupInquiryInfoUpdateAbilityParam;

@AbilityDefinition(desc = "订单-盘量信息更新-分组同步")
public interface ICampaignGroupInquiryInfoUpdateAbility extends AtomAbility<CampaignGroupInquiryInfoUpdateAbilityParam, Void> {
}
