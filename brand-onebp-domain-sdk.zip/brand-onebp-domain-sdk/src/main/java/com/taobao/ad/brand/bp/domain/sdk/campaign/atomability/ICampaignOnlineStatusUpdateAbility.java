package com.taobao.ad.brand.bp.domain.sdk.campaign.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignOnlineStatusUpdateAbilityParam;

@AbilityDefinition(desc = "计划OnlineStatus-修改-自助极简版下单流程")
public interface ICampaignOnlineStatusUpdateAbility extends AtomAbility<CampaignOnlineStatusUpdateAbilityParam, Void> {

}
