package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param;

import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilityMultiTargetsParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * 单元上下线校验
 */
@Data
@SuperBuilder
public class AdgroupOnlineValidateAbilityParam extends AtomAbilityMultiTargetsParam<AdgroupViewDTO> {

}
