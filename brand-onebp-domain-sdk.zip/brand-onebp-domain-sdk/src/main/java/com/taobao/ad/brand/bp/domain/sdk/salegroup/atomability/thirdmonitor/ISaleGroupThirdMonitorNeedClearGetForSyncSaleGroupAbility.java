package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.thirdmonitor;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupThirdMonitorSyncAbilityParam;

import java.util.List;

@AbilityDefinition(desc = "订单分组第三方监测-查询需要清除监测的订单分组-同步更新资源包分组配置")
public interface ISaleGroupThirdMonitorNeedClearGetForSyncSaleGroupAbility
        extends AtomAbility<SaleGroupThirdMonitorSyncAbilityParam, List<SaleGroupInfoViewDTO>> {
}
