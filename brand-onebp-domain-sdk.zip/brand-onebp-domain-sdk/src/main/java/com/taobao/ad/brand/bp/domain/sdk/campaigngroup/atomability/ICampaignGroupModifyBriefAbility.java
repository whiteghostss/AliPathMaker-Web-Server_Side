package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupTransitAbilityParam;

@AbilityDefinition(desc = "订单-更新Brief")
public interface ICampaignGroupModifyBriefAbility extends AtomAbility<CampaignGroupTransitAbilityParam, Void> {

}
