package com.taobao.ad.brand.bp.domain.sdk.campaign.ability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.ability.GenericIsoBaseAbility;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;

import com.taobao.ad.brand.bp.domain.sdk.campaign.ability.param.BizCampaignAbilityParam;

import java.util.Optional;

@Deprecated
@AbilityDefinition(desc = "计划初始化能力扩展点")
public interface BizCampaignInitAbilityExt extends GenericIsoBaseAbility<BaseViewDTO> {
    /**
     * 新增场景数据初始化扩展点
     * @param serviceContext
     * @param campaignViewDTO
     * @param paramDefinition
     * @return
     */
    default Void initCampaignViewDTOForAdd(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, BizCampaignAbilityParam paramDefinition){
        return null;
    }
    /**
     * 编辑场景数据初始化扩展点
     *
     * @param serviceContext
     * @param updateCampaignViewDTO 要更新的
     * @param campaignViewDTO       界面传入的
     * @param paramDefinition
     * @return
     */
    default Void initCampaignViewDTOForUpdate(ServiceContext serviceContext, CampaignViewDTO updateCampaignViewDTO, CampaignViewDTO campaignViewDTO, BizCampaignAbilityParam paramDefinition){
        return null;
    }
}
