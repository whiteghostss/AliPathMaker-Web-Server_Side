package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageNoticeSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilityMultiTargetsParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

import java.util.List;

/**
 * 订单-合同
 */
@Data
@SuperBuilder
public class SaleGroupDiffAbilityParam extends AtomAbilityMultiTargetsParam<SaleGroupInfoViewDTO> {

    /**
     * 资源包全量分组信息
     */
    private List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupList;
    /**
     * DB订单绑定的分组
     */
    private List<SaleGroupInfoViewDTO> dbSaleGroupInfoViewDTOList;

    /**
     * 打包平台同步的修改分组（增删改）
     */
    private List<ResourcePackageNoticeSaleGroupViewDTO> filterNoticeSaleGroupViewList;

    private CampaignGroupViewDTO campaignGroupViewDTO;
}
