package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupSaleGroupAbilityParam;

@AbilityDefinition(desc = "订单-订单分组初始化-更新订单流程")
public interface ICampaignGroupSaleGroupInitForUpdateCampaignGroupAbility extends AtomAbility<CampaignGroupSaleGroupAbilityParam, Void> {

}
