package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupPvBudgetForCalculateUpdateSaleGroupAbilityParam;


@AbilityDefinition(desc = "订单分组-pv预算-计算重新设置")
public interface ISaleGroupPvBudgetForCalculateUpdateSaleGroupAbility extends AtomAbility<SaleGroupPvBudgetForCalculateUpdateSaleGroupAbilityParam,Void> {
}
