package com.taobao.ad.brand.bp.domain.sdk.campaign.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignSelfServiceAbilityParam;

@AbilityDefinition(desc = "自助计划-校验-新增计划流程")
public interface ICampaignSelfServiceValidateForAddCampaignAbility extends AtomAbility<CampaignSelfServiceAbilityParam, Void> {

}
