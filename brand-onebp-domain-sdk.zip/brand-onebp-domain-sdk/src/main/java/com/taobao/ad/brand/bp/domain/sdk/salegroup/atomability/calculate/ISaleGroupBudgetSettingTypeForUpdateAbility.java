package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.calculate;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignCalculateAbilityParam;

@AbilityDefinition(desc = "分组-预算设置-更新分组")
public interface ISaleGroupBudgetSettingTypeForUpdateAbility extends AtomAbility<CampaignCalculateAbilityParam, Void> {
}
