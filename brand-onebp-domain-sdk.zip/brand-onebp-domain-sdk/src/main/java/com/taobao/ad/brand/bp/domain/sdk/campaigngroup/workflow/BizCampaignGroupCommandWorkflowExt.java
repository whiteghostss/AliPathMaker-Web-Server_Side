package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.workflow;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.ability.GenericIsoBaseAbility;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupProcessStatusEnum;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupOrderCommandViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.calculate.CampaignGroupSaleGroupCalViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.CampaignGroupSaleGroupEstimateQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.settle.CampaignGroupRealSettleSaveViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.workflow.param.BizCampaignGroupCalculateWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.workflow.param.BizCampaignGroupProcessOrderWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.workflow.param.BizCampaignGroupPurchaseOrderWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.workflow.param.BizCampaignGroupRealSettleWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.workflow.param.BizCampaignGroupTransitWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.workflow.param.BizCampaignGroupWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.workflow.param.BizSaleGroupEstimateWorkflowParam;

/**
 * Description:计划库存流程切入点接口
 * <p>
 * date: 2023/10/13 12:03 AM
 *
 * @author shiyan
 * @version 1.0
 */
@AbilityDefinition(desc = "订单业务流程扩展点")
public interface BizCampaignGroupCommandWorkflowExt extends GenericIsoBaseAbility<BaseViewDTO> {
    /**
     * 新增订单-前置链路处理
     *
     * @param context
     * @param campaignGroupViewDTO
     * @param bizCampaignGroupWorkflowParam
     */
    void beforeExecuteAddCampaignGroup(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, BizCampaignGroupWorkflowParam bizCampaignGroupWorkflowParam);
    /**
     * 新增订单-后置链路处理
     * @param serviceContext
     * @param campaignGroupViewDTO
     * @return
     */
    Void afterExecuteAddCampaignGroup(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO);
    /**
     * 更新订单-前置链路处理
     *
     * @param context
     * @param campaignGroupViewDTO
     * @param bizCampaignGroupWorkflowParam
     */
    void beforeExecuteUpdateCampaignGroup(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, BizCampaignGroupWorkflowParam bizCampaignGroupWorkflowParam);
    /**
     * 修改订单-后置链路处理
     * @param serviceContext
     * @param campaignGroupViewDTO
     * @return
     */
    Void afterExecuteUpdateCampaignGroup(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO);

    /**
     * 计算场景-构建扩展参数
     * @param serviceContext
     * @param saleGroupCalViewDTO
     * @return
     */
    BizCampaignGroupCalculateWorkflowParam buildParamForCalculate(ServiceContext serviceContext, CampaignGroupSaleGroupCalViewDTO saleGroupCalViewDTO);

   /**
     * 迁移完成后置处理
     * @param serviceContext
     * @param campaignGroupViewDTO
     * @param transitWorkflowParam
     */
    void afterTransitCompleted(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, BizCampaignGroupTransitWorkflowParam transitWorkflowParam);

    /**
     * 构建下单参数
     * @param context
     * @param campaignGroupOrderCommandViewDTO
     * @param campaignGroupViewDTO
     * @return
     */
    BizCampaignGroupProcessOrderWorkflowParam buildParamForOrder(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO, CampaignGroupViewDTO campaignGroupViewDTO);

    /**
     * 下单校验
     * @param context
     * @param campaignGroupOrderCommandViewDTO
     * @param processWorkflowParam
     */
    void validateForOrder(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO, BizCampaignGroupProcessOrderWorkflowParam processWorkflowParam);

    /**
     * 下单前置处理
     *
     * @param context
     * @param campaignGroupOrderCommandViewDTO
     * @param processWorkflowParam
     */
    void beforeOrder(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO, BizCampaignGroupProcessOrderWorkflowParam processWorkflowParam);

    /**
     * 下单后置处理
     * @param context
     * @param campaignGroupOrderCommandViewDTO
     * @param processWorkflowParam
     */
    void afterOrder(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO, BizCampaignGroupProcessOrderWorkflowParam processWorkflowParam);

    /**
     * 构建分组预估流程参数
     * @param context
     * @param campaignGroupSaleGroupEstimateQueryViewDTO
     * @return
     */
    BizSaleGroupEstimateWorkflowParam buildWorkflowParamForEstimate(ServiceContext context, CampaignGroupSaleGroupEstimateQueryViewDTO campaignGroupSaleGroupEstimateQueryViewDTO);

    /**
     * 构建实结流程参数
     * @param context
     * @param campaignGroupRealSettleSaveViewDTO
     * @return
     */
    BizCampaignGroupRealSettleWorkflowParam buildWorkflowParamForSaveRealSettleInfo(ServiceContext context, CampaignGroupRealSettleSaveViewDTO campaignGroupRealSettleSaveViewDTO);
    /**
     * 构建改单参数
     * @param context
     * @param campaignGroupOrderCommandViewDTO
     * @param campaignGroupViewDTO
     * @return
     */
    BizCampaignGroupProcessOrderWorkflowParam buildParamForModify(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO, CampaignGroupViewDTO campaignGroupViewDTO);

    /**
     * 改单后置处理
     * @param context
     * @param campaignGroupOrderCommandViewDTO
     * @param processWorkflowParam
     */
    void afterModify(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO, BizCampaignGroupProcessOrderWorkflowParam processWorkflowParam);

    void afterFinishSubCampaignGroupRealSettleProcess(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, BrandCampaignGroupProcessStatusEnum processStatusEnum);

    void beforePreOrder(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, BizCampaignGroupProcessOrderWorkflowParam processWorkflowParam);

//    /**
//     * 预下单参数构建
//     *
//     * @param serviceContext
//     * @param campaignGroupViewDTO
//     * @return
//     */
//    BizCampaignGroupProcessOrderWorkflowParam buildWorkflowParamForPreOrder(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO);

    void afterAdd(ServiceContext context, CampaignGroupViewDTO campaignGroup);

    BizCampaignGroupPurchaseOrderWorkflowParam buildParamForPurchaseOrder(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO);
}