package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * 资源包订单分组-交付场景获取-能力参数
 */
@Data
@SuperBuilder
public class ResourcePackageSaleGroupGoalSceneGetAbilityParam extends AtomAbilitySingleTargetParam<ResourcePackageSaleGroupViewDTO> {

    /**
     * 是否查询真实场景
     */
    private boolean needReal;

}
