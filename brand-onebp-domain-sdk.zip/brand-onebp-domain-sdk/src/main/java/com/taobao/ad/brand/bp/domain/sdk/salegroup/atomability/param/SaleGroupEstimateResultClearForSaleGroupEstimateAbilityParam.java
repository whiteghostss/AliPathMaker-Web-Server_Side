package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;


import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

import java.util.List;

/**
 * 订单分组-交付预估结果清空-分组预估-能力参数
 * 注：AbilityTarget为campaignGroupId
 */

@Data
@SuperBuilder
public class SaleGroupEstimateResultClearForSaleGroupEstimateAbilityParam
        extends AtomAbilitySingleTargetParam<Long> {

    /**
     * 售卖分组id列表
     */
    private List<Long> saleGroupIds;

}
