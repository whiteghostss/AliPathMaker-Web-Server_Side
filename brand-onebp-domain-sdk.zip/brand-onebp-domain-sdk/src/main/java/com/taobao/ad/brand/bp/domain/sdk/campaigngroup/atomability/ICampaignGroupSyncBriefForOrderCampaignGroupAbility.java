package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupTransitAbilityParam;

@AbilityDefinition(desc = "订单-同步信息至Brief-下单流程")
public interface ICampaignGroupSyncBriefForOrderCampaignGroupAbility extends AtomAbility<CampaignGroupTransitAbilityParam, Void> {

}
