package com.taobao.ad.brand.bp.domain.sdk.cartitem.businessability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.abf.isolation.spec.annotation.AbilityPoint;
import com.alibaba.abf.isolation.spec.common.IsoLevel;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupEstimateInfoViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbility;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbilityRouteContext;

import java.util.List;

@AbilityDefinition(desc = "极简版预下单流程-商业能力挂载点定义", level = IsoLevel.workflow)
public interface ICartItemSolutionPreOrderBusinessAbilityPoint extends BusinessAbility {
    /**
     * 下单流程-商业能力调用
     *
     * @param serviceContext
     * @param cartItemViewDTO
     * @param campaignGroupViewDTO
     * @param campaignViewDTOList
     * @param businessAbilityRouteContext
     * @return
     */
    @AbilityPoint
    default List<CampaignGroupSaleGroupEstimateInfoViewDTO> invokeForCartItemSolutionPreOrder(ServiceContext serviceContext,
                                                                                              CartItemViewDTO cartItemViewDTO,
                                                                                              CampaignGroupViewDTO campaignGroupViewDTO,
                                                                                              List<CampaignViewDTO> campaignViewDTOList,
                                                                                              BusinessAbilityRouteContext businessAbilityRouteContext) {
        return null;
    }
}
