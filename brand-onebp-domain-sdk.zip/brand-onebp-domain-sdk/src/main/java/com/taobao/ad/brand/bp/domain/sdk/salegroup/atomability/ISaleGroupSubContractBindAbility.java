package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupSubContractBindAbilityParam;

import java.util.Set;

@AbilityDefinition(desc = "分组-分组绑定子合同")
public interface ISaleGroupSubContractBindAbility extends AtomAbility<SaleGroupSubContractBindAbilityParam, Set<Long>> {

}
