package com.taobao.ad.brand.bp.domain.sdk.campaign.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignAdvValidateAbilityParam;

@AbilityDefinition(desc = "计划adv-adv唯一性校验-adv绑定流程")
public interface ICampaignAdvUniqueValidateForBindAbility extends AtomAbility<CampaignAdvValidateAbilityParam, Void> {

}
