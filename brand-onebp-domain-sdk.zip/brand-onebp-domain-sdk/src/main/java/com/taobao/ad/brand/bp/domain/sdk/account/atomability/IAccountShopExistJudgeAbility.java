package com.taobao.ad.brand.bp.domain.sdk.account.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.account.atomability.param.AccountShopExistJudgeAbilityParam;

@AbilityDefinition(desc = "用户店铺-是否存在判断能力")
public interface IAccountShopExistJudgeAbility extends AtomAbility<AccountShopExistJudgeAbilityParam, Boolean> {

}
