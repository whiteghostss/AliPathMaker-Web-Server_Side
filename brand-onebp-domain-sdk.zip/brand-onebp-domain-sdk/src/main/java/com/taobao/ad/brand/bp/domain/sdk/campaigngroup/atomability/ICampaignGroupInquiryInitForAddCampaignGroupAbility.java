package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupInquiryAbilityParam;

@AbilityDefinition(desc = "订单-盘量信息初始化-新建订单流程")
public interface ICampaignGroupInquiryInitForAddCampaignGroupAbility extends AtomAbility<CampaignGroupInquiryAbilityParam, Void> {

}
