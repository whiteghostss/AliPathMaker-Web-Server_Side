package com.taobao.ad.brand.bp.domain.sdk.account.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.client.dto.account.permission.AdcMenuModulePermissionViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.account.atomability.param.AccountMenuPermissionFlatAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;

import java.util.List;

@AbilityDefinition(desc = "账户菜单权限-打平")
public interface IAccountMenuPermissionFlatAbility extends AtomAbility<AccountMenuPermissionFlatAbilityParam, List<AdcMenuModulePermissionViewDTO>> {

}
