package com.taobao.ad.brand.bp.domain.sdk.campaign.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignValidateForBindOrUnBindAdvAbilityParam;

@AbilityDefinition(desc = "计划adv-计划校验-adv绑定流程")
public interface ICampaignValidateForBindAdvAbility extends AtomAbility<CampaignValidateForBindOrUnBindAdvAbilityParam, Void> {

}
