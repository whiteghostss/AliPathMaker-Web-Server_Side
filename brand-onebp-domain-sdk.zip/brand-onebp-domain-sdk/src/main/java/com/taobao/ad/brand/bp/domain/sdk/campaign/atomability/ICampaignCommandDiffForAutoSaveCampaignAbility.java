package com.taobao.ad.brand.bp.domain.sdk.campaign.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignDiffViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignAutoSaveAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignCommandDiffForAutoSaveCampaignAbilityParam;

@AbilityDefinition(desc = "计划操作-对比场景（新增、修改、删除）-自动生成计划流程")
public interface ICampaignCommandDiffForAutoSaveCampaignAbility extends AtomAbility<CampaignCommandDiffForAutoSaveCampaignAbilityParam, CampaignDiffViewDTO> {

}
