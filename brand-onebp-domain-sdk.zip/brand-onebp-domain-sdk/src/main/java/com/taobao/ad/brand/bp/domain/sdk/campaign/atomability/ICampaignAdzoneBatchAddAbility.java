package com.taobao.ad.brand.bp.domain.sdk.campaign.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignAdzoneBatchAbilityParam;

@AbilityDefinition(desc = "计划广告位信息-新增")
public interface ICampaignAdzoneBatchAddAbility extends AtomAbility<CampaignAdzoneBatchAbilityParam, Void> {

}
