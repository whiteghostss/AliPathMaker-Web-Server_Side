package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupUpdateCheckedResourceAbilityParam;

/**
 * @author yanjingang
 * @date 2025/3/13
 */
@AbilityDefinition(desc = "订单-分组校验-勾选分组资源流程")
public interface ISaleGroupValidateForUpdateCheckedResourceAbility extends AtomAbility<CampaignGroupUpdateCheckedResourceAbilityParam, Void> {
}
