package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param;

import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignCrowdSceneEnum;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilityMultiTargetsParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * 保存单元黑盒人群
 */
@Data
@SuperBuilder
public class AdgroupAlgoControlCrowdAddAbilityParam extends AtomAbilityMultiTargetsParam<AdgroupViewDTO> {
    /**
     * 计划信息
     */
    private CampaignViewDTO campaignViewDTO;
    /**
     * 是否投中人群
     */
    private CampaignCrowdSceneEnum campaignCrowdSceneEnum;
}
