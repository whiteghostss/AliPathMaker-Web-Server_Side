package com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.client.dto.rule.RuleCheckResultViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.param.CartItemAdDateJudgeAbilityParam;

@AbilityDefinition(desc = "加购行-广告投放周期判断")
public interface ICartItemAdDateJudgeAbility extends AtomAbility<CartItemAdDateJudgeAbilityParam, RuleCheckResultViewDTO> {

}
