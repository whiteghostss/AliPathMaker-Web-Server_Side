package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupOperateDistLockAbilityParam;

@AbilityDefinition(desc = "订单分组操作-获取分布式锁")
public interface ISaleGroupOperateDistLockGetAbility extends AtomAbility<SaleGroupOperateDistLockAbilityParam,Void> {

}
