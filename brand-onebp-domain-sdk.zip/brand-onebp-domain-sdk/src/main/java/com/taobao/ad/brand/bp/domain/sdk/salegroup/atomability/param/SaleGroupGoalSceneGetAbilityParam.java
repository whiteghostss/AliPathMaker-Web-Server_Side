package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * 订单分组-交付场景获取-能力参数
 */
@Data
@SuperBuilder
public class SaleGroupGoalSceneGetAbilityParam extends AtomAbilitySingleTargetParam<SaleGroupInfoViewDTO> {

    /**
     * 是否查询真实场景
     */
    private boolean needReal;

}
