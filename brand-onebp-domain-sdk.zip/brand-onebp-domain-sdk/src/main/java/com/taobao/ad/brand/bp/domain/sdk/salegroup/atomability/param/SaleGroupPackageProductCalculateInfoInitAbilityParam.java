package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilityMultiTargetsParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

import java.util.List;
import java.util.Map;

/**
 * 分组产品初始化
 */
@Data
@SuperBuilder
public class SaleGroupPackageProductCalculateInfoInitAbilityParam extends AtomAbilityMultiTargetsParam<SaleGroupInfoViewDTO> {
    /**
     * 订单
     */
    private CampaignGroupViewDTO campaignGroupViewDTO;
    /**
     * 资源包分组信息
     */
    private Map<Long, ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupMap;
    /**
     * 计划
     * key: saleGroupId
     */
    private Map<Long, List<CampaignViewDTO>> saleGroupCampaignMap;
}
