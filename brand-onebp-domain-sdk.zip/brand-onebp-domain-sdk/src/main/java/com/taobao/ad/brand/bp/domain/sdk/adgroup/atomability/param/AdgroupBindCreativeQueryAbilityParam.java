package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param;

import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilityMultiTargetsParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * 单元绑定创意查询
 */
@Data
@SuperBuilder
public class AdgroupBindCreativeQueryAbilityParam extends AtomAbilityMultiTargetsParam<AdgroupViewDTO> {

}
