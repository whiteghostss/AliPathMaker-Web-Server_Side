package com.taobao.ad.brand.bp.domain.sdk.account.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.account.atomability.param.AccountAdcRoleGetAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;

import java.util.Set;

@AbilityDefinition(desc = "账户ADC角色-查询")
public interface IAccountAdcRoleGetAbility extends AtomAbility<AccountAdcRoleGetAbilityParam, Set<String>> {

}
