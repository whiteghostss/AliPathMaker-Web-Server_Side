package com.taobao.ad.brand.bp.domain.sdk.campaign.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignPriceAbilityParam;

@AbilityDefinition(desc = "计划单价信息-初始化-新增计划流程")
public interface ICampaignPriceInitForAddCampaignAbility extends AtomAbility<CampaignPriceAbilityParam, Void> {

}
