package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupCrowdViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 *
 */
@Data
@SuperBuilder
public class SaleGroupCrowdInitForUpdateSaleGroupAbilityParam extends AtomAbilitySingleTargetParam<SaleGroupInfoViewDTO> {
    private CampaignGroupSaleGroupCrowdViewDTO saleGroupCrowdViewDTO;
}
