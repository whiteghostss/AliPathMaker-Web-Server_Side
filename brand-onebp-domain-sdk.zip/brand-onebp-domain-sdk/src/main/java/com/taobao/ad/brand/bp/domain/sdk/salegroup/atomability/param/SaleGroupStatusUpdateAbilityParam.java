package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSaleOrderStatusEnum;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilityMultiTargetsParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * 分组下单状态更新
 */
@Data
@SuperBuilder
public class SaleGroupStatusUpdateAbilityParam extends AtomAbilityMultiTargetsParam<Long> {
    /**
     * 订单
     */
    private CampaignGroupViewDTO campaignGroupViewDTO;
    /**
     * 下单状态
     */
    private BrandCampaignGroupSaleOrderStatusEnum saleGroupOrderStatusEnum;

}
