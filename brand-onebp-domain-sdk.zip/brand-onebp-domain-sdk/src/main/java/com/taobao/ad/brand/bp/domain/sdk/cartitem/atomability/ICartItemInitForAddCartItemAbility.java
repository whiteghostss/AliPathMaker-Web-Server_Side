package com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.param.CartItemAddInitAbilityParam;

@AbilityDefinition(desc = "加购行-初始化-新增加购行")
public interface ICartItemInitForAddCartItemAbility extends AtomAbility<CartItemAddInitAbilityParam,Void> {

}
