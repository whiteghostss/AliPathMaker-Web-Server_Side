package com.taobao.ad.brand.bp.domain.sdk.campaign.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignBottomDateViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBottomDateGetAbilityParam;

import java.util.List;

@AbilityDefinition(desc = "计划-打底周期获取")
public interface ICampaignBottomDateGetAbility extends AtomAbility<CampaignBottomDateGetAbilityParam, List<CampaignBottomDateViewDTO>> {

}
