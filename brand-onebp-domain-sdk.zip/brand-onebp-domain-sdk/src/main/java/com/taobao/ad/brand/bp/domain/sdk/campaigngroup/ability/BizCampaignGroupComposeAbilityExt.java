package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.ability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.ability.GenericIsoBaseAbility;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.keyword.CampaignKeywordViewDTO;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.context.ScheduleExportContext;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignTemplateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@AbilityDefinition(desc = "计划初始化能力扩展点")
public interface BizCampaignGroupComposeAbilityExt extends GenericIsoBaseAbility<BaseViewDTO> {

    default CampaignQueryViewDTO buildCampaignList(ServiceContext serviceContext, ScheduleExportContext scheduleExportContext, Map<Long, CampaignTemplateViewDTO> initCampaignTemplateMap){
        return null;
    }

    default Map<Long, Set<String>> buildInventoryUdImprecisionDTOMap(ServiceContext serviceContext,
                                                                    ScheduleExportContext scheduleExportContext,
                                                                    List<CampaignViewDTO> campaignModelList) {
        return Maps.newHashMap();
    }

    default Map<Long, CampaignKeywordViewDTO> buildKeywordMap(ServiceContext serviceContext,
                                                              ScheduleExportContext scheduleExportContext,
                                                              List<CampaignViewDTO> campaignModelList){
        return Maps.newHashMap();
    }
}
