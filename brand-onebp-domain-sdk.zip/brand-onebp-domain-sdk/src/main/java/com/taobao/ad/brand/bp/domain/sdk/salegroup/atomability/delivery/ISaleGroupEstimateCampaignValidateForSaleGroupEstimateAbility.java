package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.delivery;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupEstimateCampaignValidateForSaleGroupEstimateAbilityParam;

@AbilityDefinition(desc = "订单分组-分组计划校验-分组预估")
public interface ISaleGroupEstimateCampaignValidateForSaleGroupEstimateAbility
        extends AtomAbility<SaleGroupEstimateCampaignValidateForSaleGroupEstimateAbilityParam, Void> {
}
