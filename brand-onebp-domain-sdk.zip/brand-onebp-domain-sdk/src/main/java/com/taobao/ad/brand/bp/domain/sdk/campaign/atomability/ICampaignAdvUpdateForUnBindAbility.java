package com.taobao.ad.brand.bp.domain.sdk.campaign.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignAdvUpdateAbilityParam;

@AbilityDefinition(desc = "计划adv-adv更新-adv解绑流程")
public interface ICampaignAdvUpdateForUnBindAbility extends AtomAbility<CampaignAdvUpdateAbilityParam, Void> {

}
