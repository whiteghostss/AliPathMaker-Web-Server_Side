package com.taobao.ad.brand.bp.domain.sdk.campaign.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBudgetAbilityParam;

@AbilityDefinition(desc = "计划预算-校验-新增计划流程")
public interface ICampaignBudgetValidateForAddCampaignAbility extends AtomAbility<CampaignBudgetAbilityParam, Void> {

}
