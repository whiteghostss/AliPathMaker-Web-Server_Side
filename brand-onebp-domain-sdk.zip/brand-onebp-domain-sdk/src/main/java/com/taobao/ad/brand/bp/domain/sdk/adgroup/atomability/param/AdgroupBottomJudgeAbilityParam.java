package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param;

import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * 单元-生成打底单元判断能力参数
 */
@Data
@SuperBuilder
public class AdgroupBottomJudgeAbilityParam extends AtomAbilitySingleTargetParam<CampaignViewDTO> {

}
