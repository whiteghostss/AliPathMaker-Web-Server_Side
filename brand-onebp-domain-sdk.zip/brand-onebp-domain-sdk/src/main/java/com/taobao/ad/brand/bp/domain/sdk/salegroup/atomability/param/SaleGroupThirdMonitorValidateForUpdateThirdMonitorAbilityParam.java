package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupPageViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilityMultiTargetsParam;
import lombok.experimental.SuperBuilder;

/**
 * 订单分组-第三方监测校验-更新第三方监测-能力参数
 */
@SuperBuilder
public class SaleGroupThirdMonitorValidateForUpdateThirdMonitorAbilityParam
        extends AtomAbilityMultiTargetsParam<CampaignGroupSaleGroupPageViewDTO> {
}
