package com.taobao.ad.brand.bp.domain.sdk.campaign.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.client.dto.rule.RuleCheckResultViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignAddPermissionJudgeAbilityParam;
@Deprecated
@AbilityDefinition(desc = "计划-新增权限判断")
public interface ICampaignAddPermissionJudgeAbility extends AtomAbility<CampaignAddPermissionJudgeAbilityParam, RuleCheckResultViewDTO> {

}
