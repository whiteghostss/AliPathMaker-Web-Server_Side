package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupContractUpdateForTransitCampaignGroupAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupPurchaseOrderUpdateAbilityParam;

@AbilityDefinition(desc = "订单-采购信息更新")
public interface ICampaignGroupPurchaseOrderUpdateAbility extends AtomAbility<CampaignGroupPurchaseOrderUpdateAbilityParam, Void> {

}
