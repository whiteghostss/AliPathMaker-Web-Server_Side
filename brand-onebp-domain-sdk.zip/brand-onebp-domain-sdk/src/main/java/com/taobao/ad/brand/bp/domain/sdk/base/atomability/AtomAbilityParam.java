package com.taobao.ad.brand.bp.domain.sdk.base.atomability;

/**
 * 原子能力参数抽象
 */
public interface AtomAbilityParam {

}
