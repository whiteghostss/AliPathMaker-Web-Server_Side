package com.taobao.ad.brand.bp.domain.sdk.base.bizcode;

import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.google.common.collect.Sets;

import java.util.Set;

/**
 * 百灵BP站点场景
 */
public class BrandOneBP {
    public static final Set<String> BIZ_CODES = Sets.newHashSet(BizCodeEnum.BRANDONEBP.getBizCode());

}
