package com.taobao.ad.brand.bp.domain.sdk.campaign.businessability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.abf.isolation.spec.annotation.AbilityPoint;
import com.alibaba.abf.isolation.spec.common.IsoLevel;
import com.alibaba.ad.brand.dto.campaign.realtime.CampaignRealTimeOptimizeViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignRealTimeBatchOperateResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignRealTimeOptimizeInfoViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbility;

import java.util.List;

@AbilityDefinition(desc = "保存实时优选信息流程-商业能力挂载点定义", level = IsoLevel.workflow)
public interface ICampaignRealTimeOptimizeSaveBusinessAbilityPoint extends BusinessAbility {
    /**
     * 保存实时优选信息流程-商业能力调用
     *
     * @param serviceContext
     * @param realTimeOptimizeInfoViewDTO
     * @return
     */
    @AbilityPoint
    default Void invokeForRealTimeOptimizeSave(ServiceContext serviceContext, CampaignRealTimeOptimizeInfoViewDTO realTimeOptimizeInfoViewDTO) {
        return null;
    }

    /**
     * 保存实时优选信息流程-商业能力调用
     *
     * @param serviceContext
     * @param campaignIds
     * @param campaignRealTimeOptimizeViewDTO
     * @return
     */
    @AbilityPoint
    default CampaignRealTimeBatchOperateResultViewDTO invokeForRealTimeOptimizeBatchSave(ServiceContext serviceContext, List<Long> campaignIds, CampaignRealTimeOptimizeViewDTO campaignRealTimeOptimizeViewDTO) {
        return null;
    }
}
