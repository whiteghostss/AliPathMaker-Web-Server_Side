package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param;

import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * Description:单元人群定向支持判断参数
 * <p>
 * date: 2023/10/24 11:49 AM
 *
 * @author shiyan
 * @version 1.0
 */
@Data
@SuperBuilder
public class AdgroupCrowdTargetSupportJudgeAbilityParam extends AtomAbilitySingleTargetParam<AdgroupViewDTO> {

}
