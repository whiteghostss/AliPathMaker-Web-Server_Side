package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupAutoEstimateSaleGroupGetForOrderAbilityParam;

import java.util.List;

@AbilityDefinition(desc = "订单-获取自动预估分组-下单")
public interface ICampaignGroupAutoEstimateSaleGroupGetForOrderAbility
        extends AtomAbility<CampaignGroupAutoEstimateSaleGroupGetForOrderAbilityParam, List<Long>> {
}
