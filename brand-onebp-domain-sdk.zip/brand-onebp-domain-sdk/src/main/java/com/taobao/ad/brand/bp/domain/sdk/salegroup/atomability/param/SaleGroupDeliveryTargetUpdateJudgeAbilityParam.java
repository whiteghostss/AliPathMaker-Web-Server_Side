package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupDeliveryTargetViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignSaleGroupResourceDeliveryTargetViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilityMultiTargetsParam;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.SuperBuilder;

import java.util.List;

/**
 * 售卖分组-交付目标更新判断-能力参数
 */
@Data
@SuperBuilder
@EqualsAndHashCode(callSuper=false)
public class SaleGroupDeliveryTargetUpdateJudgeAbilityParam
        extends AtomAbilityMultiTargetsParam<SaleGroupDeliveryTargetViewDTO> {

    /**
     * 资源交付目标列表
     */
    private List<CampaignSaleGroupResourceDeliveryTargetViewDTO> resourceDeliveryTargetList;

}
