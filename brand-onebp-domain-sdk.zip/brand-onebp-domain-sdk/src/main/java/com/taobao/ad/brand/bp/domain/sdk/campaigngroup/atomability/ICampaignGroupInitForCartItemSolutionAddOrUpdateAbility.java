package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupInitForCartItemSolutionAddOrUpdateAbilityParam;

@AbilityDefinition(desc = "订单-数据初始化-自助化onepage新增or更新链路")
public interface ICampaignGroupInitForCartItemSolutionAddOrUpdateAbility
        extends AtomAbility<CampaignGroupInitForCartItemSolutionAddOrUpdateAbilityParam, CampaignGroupViewDTO> {
}
