package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.calculate;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.calculate.SaleGroupProductBudgetViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupBudgetAssignAbilityParam;

@AbilityDefinition(desc = "分组-产品预算分配-计算")
public interface ISaleGroupProductBudgetAssignForCalculateAbility extends AtomAbility<SaleGroupBudgetAssignAbilityParam, SaleGroupProductBudgetViewDTO> {
}
