package com.taobao.ad.brand.bp.domain.sdk.salegroup.workflow.param;

import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageTemplateViewDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Description:订单流程参数定义
 * <p>
 * date: 2024/2/26
 * @author yanjingang
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BizSaleGroupNoticeWorkflowParam {

    /**
     * 客户模板
     */
    private ResourcePackageTemplateViewDTO resourcePackageTemplateViewDTO;
    /**
     * 主订单
     */
    private List<CampaignGroupViewDTO> mainCampaignGroupViewList;

    /**
     * 资源包分组
     */
    private List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupList;

}
