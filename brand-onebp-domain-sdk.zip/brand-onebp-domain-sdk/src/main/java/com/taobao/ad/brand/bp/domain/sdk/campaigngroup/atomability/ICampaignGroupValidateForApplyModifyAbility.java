package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupUnlockAbilityParam;

@AbilityDefinition(desc = "订单-改单校验-申请改单流程")
public interface ICampaignGroupValidateForApplyModifyAbility extends AtomAbility<CampaignGroupUnlockAbilityParam, Void> {

}
