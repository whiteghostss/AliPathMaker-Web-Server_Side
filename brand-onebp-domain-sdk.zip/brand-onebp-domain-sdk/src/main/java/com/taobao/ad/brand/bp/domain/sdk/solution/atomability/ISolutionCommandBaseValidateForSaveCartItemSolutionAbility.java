package com.taobao.ad.brand.bp.domain.sdk.solution.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.solution.atomability.param.CartItemSolutionCommandAbilityParam;

@AbilityDefinition(desc = "解决方案-基础数据校验-onePage保存场景")
public interface ISolutionCommandBaseValidateForSaveCartItemSolutionAbility extends AtomAbility<CartItemSolutionCommandAbilityParam, Void> {

}
