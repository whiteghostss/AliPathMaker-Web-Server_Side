package com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.param.CartItemValidateAbilityParam;

@AbilityDefinition(desc = "加购行-删除判断")
public interface ICartItemDeleteJudgeAbility extends AtomAbility<CartItemValidateAbilityParam,Boolean> {

}
