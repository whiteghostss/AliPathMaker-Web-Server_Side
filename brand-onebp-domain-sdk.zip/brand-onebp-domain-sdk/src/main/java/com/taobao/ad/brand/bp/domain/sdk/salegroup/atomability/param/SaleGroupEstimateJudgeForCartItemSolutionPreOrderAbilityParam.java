package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

import java.util.List;

/**
 *
 */
@Data
@SuperBuilder
public class SaleGroupEstimateJudgeForCartItemSolutionPreOrderAbilityParam extends AtomAbilitySingleTargetParam<CartItemViewDTO> {

    private CampaignGroupViewDTO campaignGroupViewDTO;

    /**
     * 计划List
     */
    private List<CampaignViewDTO> campaignViewDTOList;

}
