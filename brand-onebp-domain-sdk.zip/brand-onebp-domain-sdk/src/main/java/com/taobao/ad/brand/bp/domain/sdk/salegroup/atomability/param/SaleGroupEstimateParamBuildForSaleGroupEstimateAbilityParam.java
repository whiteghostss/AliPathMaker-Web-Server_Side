package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.CampaignGroupSaleGroupEstimateQueryViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.experimental.SuperBuilder;

/**
 * 订单分组-预估参数构建-分组预估-能力参数
 */
@SuperBuilder
public class SaleGroupEstimateParamBuildForSaleGroupEstimateAbilityParam
        extends AtomAbilitySingleTargetParam<CampaignGroupSaleGroupEstimateQueryViewDTO> {
}
