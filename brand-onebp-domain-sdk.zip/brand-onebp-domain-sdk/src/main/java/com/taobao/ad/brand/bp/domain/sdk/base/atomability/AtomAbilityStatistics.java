package com.taobao.ad.brand.bp.domain.sdk.base.atomability;

import org.reflections.Reflections;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * 原子能力数据统计，包含原子能力数量
 */
public class AtomAbilityStatistics {

    public static void main(String[] args) {
        Reflections reflections = new Reflections("com.taobao.ad.brand.bp"); // 指定包名
        Set<Class<? extends AtomAbility>> implementations = reflections.getSubTypesOf(AtomAbility.class);

        List<String> interfaceList = implementations.stream().filter(Class::isInterface)
                .map(Class::getSimpleName).sorted().collect(Collectors.toList());

        System.out.println("百灵原子能力数量统计："+interfaceList.size());

        for (String simpleName : interfaceList) {
            System.out.println("    @AbilityInject(reduce = ReduceType.FIRST)\n" +
                    "    " + simpleName + " "+getName(simpleName)+";");
        }
    }

    private static String getName(String serviceName){
        return serviceName.substring(1, 2).toLowerCase() + serviceName.substring(2);
    }
}
