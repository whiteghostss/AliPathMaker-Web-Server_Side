package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.client.dto.dmp.CrowdViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupCrowdQueryAbilityParam;

import java.util.List;

@AbilityDefinition(desc = "订单分组-分组人群获取")
public interface ISaleGroupCrowdQueryAbility
        extends AtomAbility<SaleGroupCrowdQueryAbilityParam, List<CrowdViewDTO>> {
}
