package com.taobao.ad.brand.bp.domain.sdk.campaign.businessability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.abf.isolation.spec.annotation.AbilityPoint;
import com.alibaba.abf.isolation.spec.common.IsoLevel;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignShowConfigViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbility;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbilityRouteContext;

import java.util.List;

@AbilityDefinition(desc = "计划查询流程-商业能力挂载点定义", level = IsoLevel.workflow)
public interface ICampaignQueryBusinessAbilityPoint extends BusinessAbility {

    /**
     * 查询计划支持客户配置维度-商业能力调用
     * @param serviceContext
     * @param showConfigViewDTOList
     * @param businessAbilityRouteContext
     * @return
     */
    @AbilityPoint
    default Void invokeForCampaignShowConfigGet(ServiceContext serviceContext, List<CampaignShowConfigViewDTO> showConfigViewDTOList,BusinessAbilityRouteContext businessAbilityRouteContext) {
        return null;
    }
}
