package com.taobao.ad.brand.bp.domain.sdk.campaign.businessability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.abf.isolation.spec.annotation.AbilityPoint;
import com.alibaba.abf.isolation.spec.common.IsoLevel;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbility;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbilityRouteContext;

@AbilityDefinition(desc = "子计划拆分流程-商业能力挂载点定义", level = IsoLevel.workflow)
public interface ICampaignSplitSubCampaignBusinessAbilityPoint extends BusinessAbility {
    /**
     * 子计划拆分商业能力挂载点
     *
     * @param serviceContext
     * @param campaignTreeViewDTO
     * @param businessAbilityRouteContext
     * @return
     */
    @AbilityPoint
    default Void invokeForSubCampaignSplit(ServiceContext serviceContext, CampaignViewDTO campaignTreeViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        return null;
    }
}
