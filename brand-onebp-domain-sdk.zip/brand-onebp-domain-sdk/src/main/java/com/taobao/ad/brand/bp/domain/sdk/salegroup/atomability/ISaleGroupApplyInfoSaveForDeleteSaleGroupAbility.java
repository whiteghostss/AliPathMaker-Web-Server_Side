package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupApplyInfoAbilityParam;

@AbilityDefinition(desc = "订单分组-申请信息保存-删除补/配分组")
public interface ISaleGroupApplyInfoSaveForDeleteSaleGroupAbility extends AtomAbility<SaleGroupApplyInfoAbilityParam, Void> {
}
