package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupBatchDeleteAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;

@AbilityDefinition(desc = "单元-批量删除")
public interface IAdgroupBatchDeleteAbility extends AtomAbility<AdgroupBatchDeleteAbilityParam, Void> {

}
