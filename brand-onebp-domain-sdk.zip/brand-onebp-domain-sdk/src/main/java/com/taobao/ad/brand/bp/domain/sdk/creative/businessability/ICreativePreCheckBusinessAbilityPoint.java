package com.taobao.ad.brand.bp.domain.sdk.creative.businessability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.abf.isolation.spec.annotation.AbilityPoint;
import com.alibaba.abf.isolation.spec.common.IsoLevel;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.taobao.ad.brand.bp.client.dto.template.ErrorMessageViewDTO;
import com.taobao.ad.brand.bp.client.dto.template.TemplateViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbility;

import java.util.List;

@AbilityDefinition(desc = "创意前置校验流程-商业能力挂载点定义", level = IsoLevel.workflow)
public interface ICreativePreCheckBusinessAbilityPoint extends BusinessAbility {
    /**
     * 执行商业能力调用
     * @param serviceContext
     * @param creativeViewDTO
     * @param creativeTemplate
     * @param errorMessageViewDTOList
     * @return
     */
    @AbilityPoint
    Void invokeForCreativePreCheck(ServiceContext serviceContext, CreativeViewDTO creativeViewDTO, TemplateViewDTO creativeTemplate, List<ErrorMessageViewDTO> errorMessageViewDTOList);
}
