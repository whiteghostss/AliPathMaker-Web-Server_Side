package com.taobao.ad.brand.bp.domain.sdk.campaign.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignSmartReservedAbilityParam;

@AbilityDefinition(desc = "计划智能预留-校验-新增计划流程")
public interface ICampaignSmartReservedValidateForAddCampaignAbility extends AtomAbility<CampaignSmartReservedAbilityParam, Void> {

}
