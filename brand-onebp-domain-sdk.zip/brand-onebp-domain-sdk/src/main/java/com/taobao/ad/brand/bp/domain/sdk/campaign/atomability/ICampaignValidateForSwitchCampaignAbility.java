package com.taobao.ad.brand.bp.domain.sdk.campaign.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignValidateForSwitchCampaignAbilityParam;

@AbilityDefinition(desc = "计划状态-校验-开启/暂停")
public interface ICampaignValidateForSwitchCampaignAbility extends AtomAbility<CampaignValidateForSwitchCampaignAbilityParam, Void> {

}
