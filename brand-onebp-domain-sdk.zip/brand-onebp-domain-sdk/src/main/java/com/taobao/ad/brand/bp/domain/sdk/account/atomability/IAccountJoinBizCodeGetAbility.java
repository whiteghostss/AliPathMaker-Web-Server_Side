package com.taobao.ad.brand.bp.domain.sdk.account.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.account.atomability.param.AccountJoinBizCodeGetAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;

import java.util.List;

@AbilityDefinition(desc = "账户准入业务场景-查询")
public interface IAccountJoinBizCodeGetAbility extends AtomAbility<AccountJoinBizCodeGetAbilityParam, List<String>> {

}
