package com.taobao.ad.brand.bp.domain.sdk.campaign.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignAdzoneAbilityParam;

@AbilityDefinition(desc = "计划广告位-校验-新增计划流程")
public interface ICampaignAdzoneValidateForAddCampaignAbility extends AtomAbility<CampaignAdzoneAbilityParam, Void> {

}
