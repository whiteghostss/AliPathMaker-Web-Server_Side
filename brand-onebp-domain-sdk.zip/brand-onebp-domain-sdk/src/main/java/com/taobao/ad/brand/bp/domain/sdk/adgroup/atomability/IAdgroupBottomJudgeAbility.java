package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupBottomJudgeAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;

@AbilityDefinition(desc = "单元-生成打底单元判断")
public interface IAdgroupBottomJudgeAbility extends AtomAbility<AdgroupBottomJudgeAbilityParam,Boolean> {

}
