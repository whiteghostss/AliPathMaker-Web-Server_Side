package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupTitleValidateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;

@AbilityDefinition(desc = "单元-标题校验")
public interface IAdgroupTitleValidateAbility extends AtomAbility<AdgroupTitleValidateAbilityParam, Void> {

}
