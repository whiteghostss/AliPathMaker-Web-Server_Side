package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param;

import com.alibaba.ad.brand.dto.adgroup.crowd.AdgroupCrowdScenarioViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * 投中白盒人群
 */
@Data
@SuperBuilder
public class AdgroupRealTimeOptimizeCrowdInitForAddOrUpdateAdgroupAbilityParam extends AtomAbilitySingleTargetParam<AdgroupCrowdScenarioViewDTO> {
    /**
     * 计划信息
     */
    private CampaignViewDTO campaignViewDTO;
}
