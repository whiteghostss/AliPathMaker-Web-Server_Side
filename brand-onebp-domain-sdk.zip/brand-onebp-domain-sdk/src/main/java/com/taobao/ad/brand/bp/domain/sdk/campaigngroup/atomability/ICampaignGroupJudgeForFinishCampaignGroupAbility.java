package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupTransitAbilityParam;

@AbilityDefinition(desc = "订单-判断是否支持-订单完成流程")
public interface ICampaignGroupJudgeForFinishCampaignGroupAbility extends AtomAbility<CampaignGroupTransitAbilityParam, Boolean> {

}
