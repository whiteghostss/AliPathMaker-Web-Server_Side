package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupUpdateCheckedResourceAbilityParam;

@AbilityDefinition(desc = "订单-订单分组初始化-更新订单和勾选分组资源流程")
public interface ICampaignGroupSaleGroupInitForUpdateCheckedResourceAbility extends AtomAbility<CampaignGroupUpdateCheckedResourceAbilityParam, Void> {

}
