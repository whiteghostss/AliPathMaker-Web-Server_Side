package com.taobao.ad.brand.bp.domain.sdk.creative.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeSmartItemGetAbilityParam;

@AbilityDefinition(desc = "创意智能-获取商品id")
public interface ICreativeSmartItemGetAbility extends AtomAbility<CreativeSmartItemGetAbilityParam, Long> {

}
