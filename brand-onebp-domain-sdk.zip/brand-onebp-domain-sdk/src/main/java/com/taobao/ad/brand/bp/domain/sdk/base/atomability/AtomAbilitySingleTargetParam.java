package com.taobao.ad.brand.bp.domain.sdk.base.atomability;

import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * 原子能力参数定义(单目标对象实体场景)
 */
@Data
@SuperBuilder
public class AtomAbilitySingleTargetParam<AbilityTarget> implements AtomAbilityParam {

    /**
     * 原子能力目标对象实体
     */
    private AbilityTarget abilityTarget;

}
