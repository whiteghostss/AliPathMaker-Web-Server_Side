package com.taobao.ad.brand.bp.domain.sdk.campaign.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.client.dto.dmp.CrowdViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignShowmaxCrowdGetAbilityParam;

@AbilityDefinition(desc = "计划showmax人群-获取")
public interface ICampaignShowmaxCrowdGetAbility extends AtomAbility<CampaignShowmaxCrowdGetAbilityParam, CrowdViewDTO> {

}
