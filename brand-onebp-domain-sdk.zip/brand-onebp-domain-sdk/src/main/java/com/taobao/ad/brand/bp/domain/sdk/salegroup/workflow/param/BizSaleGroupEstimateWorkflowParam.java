package com.taobao.ad.brand.bp.domain.sdk.salegroup.workflow.param;

import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Description:售卖分组预估
 * <p>
 * date: 2024/3/19
 * @author shiyan
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BizSaleGroupEstimateWorkflowParam {
    /**
     * 订单
     */
    private CampaignGroupViewDTO campaignGroupViewDTO;
    /**
     * 售卖分组
     */
    private List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList;
    /**
     * 资源包售卖分组
     */
    private List<ResourcePackageSaleGroupViewDTO> packageSaleGroupViewDTOList;
}
