package com.taobao.ad.brand.bp.domain.sdk.solution.atomability.param;

import com.taobao.ad.brand.bp.client.dto.solution.CartItemSolutionViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * 自助化onePage场景参数定义
 */
@Data
@SuperBuilder
public class CartItemSolutionCommandAbilityParam extends AtomAbilitySingleTargetParam<CartItemSolutionViewDTO> {

}
