package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupUpdateCheckedResourceAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupWakeupAbilityParam;

@AbilityDefinition(desc = "订单-唤端校验-更新订单和勾选分组资源流程")
public interface ICampaignGroupWakeupValidateForUpdateCheckedResourceAbility extends AtomAbility<CampaignGroupUpdateCheckedResourceAbilityParam, Void> {

}
