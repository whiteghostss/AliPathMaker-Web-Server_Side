package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.calculate;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignCalculateAbilityParam;

@AbilityDefinition(desc = "资源包分组-资源校验-计算")
public interface ISaleGroupProductValidateForCalculateAbility extends AtomAbility<CampaignCalculateAbilityParam, Void> {
}
