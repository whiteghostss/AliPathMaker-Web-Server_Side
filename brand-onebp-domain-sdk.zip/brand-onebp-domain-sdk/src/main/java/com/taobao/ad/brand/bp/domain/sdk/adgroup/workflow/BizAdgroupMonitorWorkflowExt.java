package com.taobao.ad.brand.bp.domain.sdk.adgroup.workflow;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.ability.GenericIsoBaseAbility;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.creative.ContentVersionViewDTO;
import com.taobao.ad.brand.bp.client.dto.adgroup.ExportMonitorCodeViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.workflow.param.BizAdgroupMonitorWorkflowParam;

import java.util.List;

/**
 * Description:单元监测流程切入点接口
 * <p>
 * date: 2023/10/13 12:03 AM
 *
 * @author shiyan
 * @version 1.0
 */
@AbilityDefinition(desc = "单元监测流程切入点接口")
public interface BizAdgroupMonitorWorkflowExt extends GenericIsoBaseAbility<BaseViewDTO> {
    /**
     * 单元监测-构建扩展参数
     * @param serviceContext
     * @param adgroupViewDTO
     * @return
     */
    default BizAdgroupMonitorWorkflowParam buildParamForMonitor(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO) {

        return null;
    }

    /**
     * 单元监测-发送监测邮件
     * @param serviceContext
     * @param adgroupViewDTO
     * @param contentVersionViewDTO
     * @param monitorCodeViewDTOList
     * @return
     */
    default Void sendAdgroupMonitorEmail(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, ContentVersionViewDTO contentVersionViewDTO,List<ExportMonitorCodeViewDTO> monitorCodeViewDTOList){
        return null;
    }
    /**
     * 单元监测-发送监测邮件
     * @param serviceContext
     * @param adgroupViewDTO
     * @param monitorCodeViewDTOList
     * @return
     */
    default List<Long> getNeedToSendEmailSubCampaignIds(ServiceContext serviceContext,AdgroupViewDTO adgroupViewDTO, List<ExportMonitorCodeViewDTO> monitorCodeViewDTOList){
        return null;
    }
}