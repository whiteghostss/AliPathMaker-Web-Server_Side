package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.calculate;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupBudgetAssignAbilityParam;

@AbilityDefinition(desc = "分组-产品预算分配校验-计算")
public interface ISaleGroupProductBudgetAssignValidateForCalculateAbility extends AtomAbility<SaleGroupBudgetAssignAbilityParam, Void> {
}
