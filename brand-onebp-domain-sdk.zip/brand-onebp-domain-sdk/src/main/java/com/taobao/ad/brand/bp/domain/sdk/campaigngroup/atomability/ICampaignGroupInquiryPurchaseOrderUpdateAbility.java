package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupInquiryPurchaseOrderUpdateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupMediaInquiryOrderUpdateAbilityParam;

@AbilityDefinition(desc = "订单-更新询量和采购单")
public interface ICampaignGroupInquiryPurchaseOrderUpdateAbility
        extends AtomAbility<CampaignGroupInquiryPurchaseOrderUpdateAbilityParam, Integer> {
}
