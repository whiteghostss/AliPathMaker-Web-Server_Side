package com.taobao.ad.brand.bp.domain.sdk.salegroup.businessability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.abf.isolation.spec.common.IsoLevel;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbility;

import java.util.List;

@AbilityDefinition(desc = "订单分组同步资源包分组配置流程-商业能力挂载点定义", level = IsoLevel.workflow)
public interface ISaleGroupSyncBusinessAbilityPoint extends BusinessAbility {
    /**
     * 商业能力执行器
     *
     * @param serviceContext
     * @param updateSaleGroupList
     * @return
     */
    default Void invokeForSyncSaleGroup(ServiceContext serviceContext, List<ResourcePackageSaleGroupViewDTO> updateSaleGroupList) {
        return null;
    }
}
