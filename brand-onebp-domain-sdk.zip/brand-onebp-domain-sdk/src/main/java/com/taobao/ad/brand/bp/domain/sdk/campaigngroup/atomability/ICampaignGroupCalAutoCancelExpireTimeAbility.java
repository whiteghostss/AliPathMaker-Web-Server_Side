package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupCalAutoCancelExpireTimeAbilityParam;

import java.util.Date;

@AbilityDefinition(desc = "订单-计算自动撤单时间")
public interface ICampaignGroupCalAutoCancelExpireTimeAbility extends AtomAbility<CampaignGroupCalAutoCancelExpireTimeAbilityParam, Date> {

}
