package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

import java.util.List;

/**
 * Description:订单分组获取-计划对比流程
 * <p>
 * date: 2023/10/24 11:49 AM
 *
 * @author shiyan
 * @version 1.0
 */
@Data
@SuperBuilder
public class SaleGroupGetForDiffCampaignAbilityParam extends AtomAbilitySingleTargetParam<CampaignGroupViewDTO> {
    /**
     * db计划
     */
    private List<CampaignViewDTO> dbCampaignViewDTOList;
}
