package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupCompleteConfigAbilityParam;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2025/3/31
 **/
@AbilityDefinition(desc = "订单-结案配置信息保存")
public interface ICampaignGroupCompleteConfigSaveAbility extends AtomAbility<CampaignGroupCompleteConfigAbilityParam, Void> {
}
