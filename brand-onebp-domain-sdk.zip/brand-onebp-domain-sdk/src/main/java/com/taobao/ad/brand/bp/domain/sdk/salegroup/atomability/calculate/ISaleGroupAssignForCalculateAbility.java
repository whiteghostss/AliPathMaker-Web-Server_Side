package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.calculate;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.calculate.ProductCampaignCalViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignCalculateAbilityParam;

import java.util.List;

@AbilityDefinition(desc = "计划-一级计划预算分配-计算计划")
public interface ISaleGroupAssignForCalculateAbility extends AtomAbility<CampaignCalculateAbilityParam, List<ProductCampaignCalViewDTO>> {
}
