package com.taobao.ad.brand.bp.domain.sdk.account.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.client.dto.account.permission.AdcMenuModulePermissionViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.account.atomability.param.AccountMenuPermissionMergeAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;

import java.util.List;

@AbilityDefinition(desc = "账户菜单权限-打平合并")
public interface IAccountMenuPermissionMergeAbility extends AtomAbility<AccountMenuPermissionMergeAbilityParam, List<AdcMenuModulePermissionViewDTO>> {

}
