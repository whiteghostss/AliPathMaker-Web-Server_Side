package com.taobao.ad.brand.bp.domain.sdk.creative.businessability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.abf.isolation.spec.annotation.AbilityPoint;
import com.alibaba.abf.isolation.spec.common.IsoLevel;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.brand.dto.creative.materialgroup.MaterialGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.template.TemplateContextViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbility;

import java.util.List;

@AbilityDefinition(desc = "创意生成子创意流程-商业能力挂载点定义", level = IsoLevel.workflow)
public interface ICreativeGenerateSubCreativeBusinessAbilityPoint extends BusinessAbility {
    /**
     * 执行商业能力调用
     * @param serviceContext
     * @param creativeViewDTO
     * @param materialGroup
     * @param templateContextViewDTOList
     * @return
     */
    @AbilityPoint
    List<CreativeViewDTO> invokeForGenerateSubCreative(ServiceContext serviceContext, CreativeViewDTO creativeViewDTO, MaterialGroupViewDTO materialGroup, List<TemplateContextViewDTO> templateContextViewDTOList);
}
