package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupContractAbilityParam;

@AbilityDefinition(desc = "订单-合同校验-新建订单流程")
public interface ICampaignGroupContractValidateForAddCampaignGroupAbility extends AtomAbility<CampaignGroupContractAbilityParam, Void> {

}
