package com.taobao.ad.brand.bp.domain.sdk.base.bizcode;

import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.google.common.collect.Sets;

import java.util.Set;

/**
 * 自助营销业务场景
 */
public class SelfService {
    public static final Set<String> BIZ_CODES = Sets.newHashSet(BizCodeEnum.SELFSERVICEAD.getBizCode());
}
