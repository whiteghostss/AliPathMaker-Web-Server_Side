package com.taobao.ad.brand.bp.domain.sdk.creative.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeRejectMessageSendAbilityParam;

@AbilityDefinition(desc = "创意-判断是否发送拒绝通知消息")
public interface ICreativeRejectMessageSendJudgeAbility extends AtomAbility<CreativeRejectMessageSendAbilityParam, Boolean> {

}
