package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupUnlockInitForApplyModifyAbilityParam;

@AbilityDefinition(desc = "订单-改单初始化-改单流程")
public interface ICampaignGroupUnlockInitForApplyModifyAbility extends AtomAbility<CampaignGroupUnlockInitForApplyModifyAbilityParam, Void> {

}
