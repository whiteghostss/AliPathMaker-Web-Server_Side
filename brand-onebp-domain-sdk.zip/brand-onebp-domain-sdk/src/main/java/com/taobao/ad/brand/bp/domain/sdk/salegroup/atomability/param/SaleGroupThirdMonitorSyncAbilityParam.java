package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

import java.util.List;

/**
 * 订单分组-第三方监控-同步订单分组-能力参数
 */
@Data
@SuperBuilder
public class SaleGroupThirdMonitorSyncAbilityParam
        extends AtomAbilitySingleTargetParam<ResourcePackageSaleGroupViewDTO> {

    /**
     * 计划列表
     */
    private List<CampaignViewDTO> campaignViewDTOList;
}
