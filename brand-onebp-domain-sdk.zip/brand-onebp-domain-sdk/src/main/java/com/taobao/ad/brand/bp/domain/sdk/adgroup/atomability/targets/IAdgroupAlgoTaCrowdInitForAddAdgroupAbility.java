package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.targets;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupAlgoTaCrowdInitForAddAdgroupAbilityParam;

@AbilityDefinition(desc = "单元-算法TA人群初始化-新建单元")
public interface IAdgroupAlgoTaCrowdInitForAddAdgroupAbility
        extends AtomAbility<AdgroupAlgoTaCrowdInitForAddAdgroupAbilityParam, Void> {
}
