package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param;

import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.monitor.ThirdMonitorUrlViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

import java.util.List;

/**
 * 单元第三方监测-更新-能力参数
 */
@Data
@SuperBuilder
public class AdgroupThirdMonitorUpdateAbilityParam extends AtomAbilitySingleTargetParam<AdgroupViewDTO> {

    /**
     * 单元第三方监测列表
     */
    private List<ThirdMonitorUrlViewDTO> thirdMonitorUrlList;

}
