package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.thirdmonitor;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupThirdMonitorSyncAbilityParam;

@AbilityDefinition(desc = "订单分组第三方监测-修改校验-同步更新资源包分组配置")
public interface ISaleGroupThirdMonitorUpdateValidateForSyncSaleGroupAbility
        extends AtomAbility<SaleGroupThirdMonitorSyncAbilityParam, Void> {
}
