package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.salegroup.SaleGroupDiffResultViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupDiffAbilityParam;

@AbilityDefinition(desc = "订单-分组Diff")
public interface ISaleGroupDiffForUpdateCampaignGroupAbility
        extends AtomAbility<SaleGroupDiffAbilityParam, SaleGroupDiffResultViewDTO> {

}
