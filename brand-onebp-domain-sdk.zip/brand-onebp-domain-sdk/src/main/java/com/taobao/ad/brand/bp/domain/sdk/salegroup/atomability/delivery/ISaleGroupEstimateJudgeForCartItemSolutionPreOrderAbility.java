package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.delivery;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupEstimateJudgeForCartItemSolutionPreOrderAbilityParam;

@AbilityDefinition(desc = "订单分组-分组检查-极简方案下单")
public interface ISaleGroupEstimateJudgeForCartItemSolutionPreOrderAbility
        extends AtomAbility<SaleGroupEstimateJudgeForCartItemSolutionPreOrderAbilityParam, Boolean> {
}
