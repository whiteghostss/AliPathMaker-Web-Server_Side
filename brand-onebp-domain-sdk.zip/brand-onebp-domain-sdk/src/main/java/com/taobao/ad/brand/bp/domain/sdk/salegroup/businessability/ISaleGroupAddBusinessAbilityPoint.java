package com.taobao.ad.brand.bp.domain.sdk.salegroup.businessability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.abf.isolation.spec.common.IsoLevel;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbility;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbilityRouteContext;

@AbilityDefinition(desc = "订单分组新增流程-商业能力挂载点定义", level = IsoLevel.workflow)
public interface ISaleGroupAddBusinessAbilityPoint extends BusinessAbility {
    /**
     * 商业能力执行器
     *
     * @param serviceContext
     * @param saleGroupViewDTO
     * @param businessAbilityRouteContext
     * @return
     */
    default Void invokeForAddSaleGroup(ServiceContext serviceContext, SaleGroupInfoViewDTO saleGroupViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        return null;
    }
}
