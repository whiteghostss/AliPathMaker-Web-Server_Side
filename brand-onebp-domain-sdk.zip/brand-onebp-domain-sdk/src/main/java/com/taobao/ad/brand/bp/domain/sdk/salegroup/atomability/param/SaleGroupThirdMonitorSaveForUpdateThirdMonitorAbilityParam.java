package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupPageViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilityMultiTargetsParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * 订单分组-第三方监测保存-更新第三方监测-能力参数
 */
@Data
@SuperBuilder
public class SaleGroupThirdMonitorSaveForUpdateThirdMonitorAbilityParam
        extends AtomAbilityMultiTargetsParam<CampaignGroupSaleGroupPageViewDTO> {

    /**
     * 计划组id
     */
    private Long campaignGroupId;

}
