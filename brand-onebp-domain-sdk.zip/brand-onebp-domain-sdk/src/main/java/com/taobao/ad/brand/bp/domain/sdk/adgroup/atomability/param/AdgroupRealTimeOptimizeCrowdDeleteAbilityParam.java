package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param;

import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

import java.util.List;

/**
 * 智能推荐人群
 */
@Data
@SuperBuilder
public class AdgroupRealTimeOptimizeCrowdDeleteAbilityParam extends AtomAbilitySingleTargetParam<CampaignViewDTO> {
    /**
     * 单元列表
     */
    private List<AdgroupViewDTO> adgroupViewDTOList;

}
