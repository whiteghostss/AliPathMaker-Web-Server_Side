package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupExtAbilityParam;

@AbilityDefinition(desc = "订单-扩展初始化-新建订单流程")
public interface ICampaignGroupExtInitForAddCampaignGroupAbility extends AtomAbility<CampaignGroupExtAbilityParam, Void> {

}
