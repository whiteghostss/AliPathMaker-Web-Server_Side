package com.taobao.ad.brand.bp.domain.sdk.creative.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeRefValidateAbilityParam;

@AbilityDefinition(desc = "创意绑定-TOP创意-校验")
public interface ICreativeRefTopCreativeValidateAbility extends AtomAbility<CreativeRefValidateAbilityParam, Void> {

}
