package com.taobao.ad.brand.bp.domain.sdk.shopwindow.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.shopwindow.atomability.param.SkuSspProductLineAuthJudgeAbilityParam;

import java.util.Map;

@AbilityDefinition(desc = "SKU-SSP产品线准入判断")
public interface ISkuSspProductLineAuthJudgeAbility extends AtomAbility<SkuSspProductLineAuthJudgeAbilityParam, Map<Long, Boolean>> {

}
