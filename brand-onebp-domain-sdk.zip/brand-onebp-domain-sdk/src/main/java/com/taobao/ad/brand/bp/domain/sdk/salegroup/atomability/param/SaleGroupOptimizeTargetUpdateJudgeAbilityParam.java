package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignSaleGroupResourceOptimizeTargetViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilityMultiTargetsParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

import java.util.List;

/**
 * 订单分组-判断资源包优化目标是否更新-能力参数
 * 注：AbilityTarget为优化目标列表
 */
@Data
@SuperBuilder
public class SaleGroupOptimizeTargetUpdateJudgeAbilityParam
        extends AtomAbilityMultiTargetsParam<Integer> {

    /**
     * 资源包优化目标列表
     */
    private List<CampaignSaleGroupResourceOptimizeTargetViewDTO> resourceOptimizeTargetList;

}
