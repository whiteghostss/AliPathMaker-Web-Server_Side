package com.taobao.ad.brand.bp.domain.sdk.creative.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.ad.brand.dto.creative.element.ElementViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeUpdateElementGetAbilityParam;

import java.util.List;

@AbilityDefinition(desc = "创意-获取要修改的创意元素")
public interface ICreativeUpdateElementGetAbility extends AtomAbility<CreativeUpdateElementGetAbilityParam, List<ElementViewDTO>> {

}
