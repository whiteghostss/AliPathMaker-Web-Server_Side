package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupWakeUpValidateForAddAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;

@AbilityDefinition(desc = "单元唤端-校验-新增场景")
public interface IAdgroupWakeUpValidateForAddAbility extends AtomAbility<AdgroupWakeUpValidateForAddAbilityParam, Void> {

}
