package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupContractInitForOrderAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupCustomerInitForOrderAbilityParam;

@AbilityDefinition(desc = "订单-客户信息初始化-下单流程")
public interface ICampaignGroupCustomerInitForOrderCampaignGroupAbility extends AtomAbility<CampaignGroupCustomerInitForOrderAbilityParam, Void> {

}
