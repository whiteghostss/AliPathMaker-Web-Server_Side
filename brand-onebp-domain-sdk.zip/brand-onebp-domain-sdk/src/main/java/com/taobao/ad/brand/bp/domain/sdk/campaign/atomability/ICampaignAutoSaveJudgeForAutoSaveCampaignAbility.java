package com.taobao.ad.brand.bp.domain.sdk.campaign.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignAutoSaveAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignUpdateAbilityParam;

@AbilityDefinition(desc = "计划-自动生成判断-自动生成计划流程")
public interface ICampaignAutoSaveJudgeForAutoSaveCampaignAbility extends AtomAbility<CampaignAutoSaveAbilityParam, Boolean> {

}
