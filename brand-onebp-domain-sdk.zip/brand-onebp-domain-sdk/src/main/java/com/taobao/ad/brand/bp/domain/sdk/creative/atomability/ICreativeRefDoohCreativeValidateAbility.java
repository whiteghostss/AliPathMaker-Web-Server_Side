package com.taobao.ad.brand.bp.domain.sdk.creative.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeRefDoohCreativeValidateAbilityParam;

@AbilityDefinition(desc = "创意绑定-天攻创意-校验")
public interface ICreativeRefDoohCreativeValidateAbility extends AtomAbility<CreativeRefDoohCreativeValidateAbilityParam, Void> {

}
