package com.taobao.ad.brand.bp.domain.sdk.campaign.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignForOnlineAbilityParam;

import java.util.List;

@AbilityDefinition(desc = "计划联合控量-更新-上线计划")
public interface ICampaignUnionControlForOnlineCampaignAbility extends AtomAbility<CampaignForOnlineAbilityParam, List<CampaignViewDTO>> {
}
