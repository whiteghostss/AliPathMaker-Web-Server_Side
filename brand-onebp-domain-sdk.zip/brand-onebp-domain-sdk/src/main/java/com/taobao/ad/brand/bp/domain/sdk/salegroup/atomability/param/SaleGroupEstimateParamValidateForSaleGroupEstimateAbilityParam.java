package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.CampaignGroupSaleGroupEstimateQueryViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * 订单分组-预估参数校验-分组预估-能力参数
 */
@Data
@SuperBuilder
public class SaleGroupEstimateParamValidateForSaleGroupEstimateAbilityParam
        extends AtomAbilitySingleTargetParam<CampaignGroupSaleGroupEstimateQueryViewDTO> {

    /**
     * 售卖分组预估基础参数
     */
    private BaseSaleGroupEstimateParam baseSaleGroupEstimateParam;

}
