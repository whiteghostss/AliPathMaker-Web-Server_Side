package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupCompleteConfigAbilityParam;

@AbilityDefinition(desc = "订单-结案配置信息校验-保存结案信息")
public interface ICampaignGroupCompleteConfigValidateForSaveCompleteConfigAbility extends AtomAbility<CampaignGroupCompleteConfigAbilityParam, Void> {

}
