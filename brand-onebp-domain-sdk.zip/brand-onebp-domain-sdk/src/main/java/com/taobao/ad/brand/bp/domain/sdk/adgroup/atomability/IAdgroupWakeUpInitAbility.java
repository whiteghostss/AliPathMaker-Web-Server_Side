package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupWakeUpInitAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;

@AbilityDefinition(desc = "单元-上线校验")
public interface IAdgroupWakeUpInitAbility extends AtomAbility<AdgroupWakeUpInitAbilityParam, Void> {

}
