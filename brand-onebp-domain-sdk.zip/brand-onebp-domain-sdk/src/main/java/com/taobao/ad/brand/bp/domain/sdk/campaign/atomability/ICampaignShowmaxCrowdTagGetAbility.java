package com.taobao.ad.brand.bp.domain.sdk.campaign.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignShowmaxCrowdTagGetAbilityParam;

import java.util.List;

@AbilityDefinition(desc = "计划showmax人群标签-获取")
public interface ICampaignShowmaxCrowdTagGetAbility extends AtomAbility<CampaignShowmaxCrowdTagGetAbilityParam, List<CommonViewDTO>> {

}
