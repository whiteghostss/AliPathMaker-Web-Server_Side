package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupCustomerAbilityParam;

@AbilityDefinition(desc = "订单-客户初始化-新建流程")
public interface ICampaignGroupCustomerInitForAddCampaignGroupAbility extends AtomAbility<CampaignGroupCustomerAbilityParam, Void> {

}
