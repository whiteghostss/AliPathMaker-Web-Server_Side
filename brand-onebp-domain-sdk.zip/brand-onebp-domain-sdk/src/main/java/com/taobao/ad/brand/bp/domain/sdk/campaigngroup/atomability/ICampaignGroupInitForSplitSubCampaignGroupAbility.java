package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupSplitAbilityParam;

@AbilityDefinition(desc = "订单-子订单初始化-拆分子订单流程")
public interface ICampaignGroupInitForSplitSubCampaignGroupAbility extends AtomAbility<CampaignGroupSplitAbilityParam, Void> {

}
