package com.taobao.ad.brand.bp.domain.sdk.tool.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.client.context.DomainMetaqMessageBodyContext;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeCustomerCategoryFillAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.param.MessageAsyncSendAbilityParam;

@AbilityDefinition(desc = "消息-异步发送MQ")
public interface IMessageAsyncSendAbility extends AtomAbility<MessageAsyncSendAbilityParam, Void> {

}
