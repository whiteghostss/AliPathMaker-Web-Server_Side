package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.delivery;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupEstimateInfoViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupEstimateResultRebuildAbilityParam;

@AbilityDefinition(desc = "订单分组-重新预估交付结果")
public interface ISaleGroupEstimateResultRebuildAbility
        extends AtomAbility<SaleGroupEstimateResultRebuildAbilityParam, CampaignGroupSaleGroupEstimateInfoViewDTO> {
}
