package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.targets;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupCrowdTargetForAddAdgroupAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;

@AbilityDefinition(desc = "单元人群定向-初始化-新建单元")
public interface IAdgroupCrowdTargetInitForAddAdgroupAbility extends AtomAbility<AdgroupCrowdTargetForAddAdgroupAbilityParam, Void> {

}
