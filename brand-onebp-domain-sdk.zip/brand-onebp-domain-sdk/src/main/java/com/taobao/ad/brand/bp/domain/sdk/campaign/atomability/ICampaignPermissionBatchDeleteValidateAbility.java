package com.taobao.ad.brand.bp.domain.sdk.campaign.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignDeleteValidateAbilityParam;

@AbilityDefinition(desc = "计划-批量删除权限校验")
public interface ICampaignPermissionBatchDeleteValidateAbility extends AtomAbility<CampaignDeleteValidateAbilityParam, Void> {

}
