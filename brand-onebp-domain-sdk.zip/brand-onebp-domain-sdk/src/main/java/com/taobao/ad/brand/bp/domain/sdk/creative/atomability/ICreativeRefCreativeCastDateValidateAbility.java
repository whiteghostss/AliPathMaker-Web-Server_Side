package com.taobao.ad.brand.bp.domain.sdk.creative.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeRefValidateAbilityParam;

@AbilityDefinition(desc = "创意绑定-创意有效期-校验")
public interface ICreativeRefCreativeCastDateValidateAbility extends AtomAbility<CreativeRefValidateAbilityParam, Void> {

}
