package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupDeleteAbilityParam;

@AbilityDefinition(desc = "订单-删除校验")
public interface ICampaignGroupValidateForDeleteAbility extends AtomAbility<CampaignGroupDeleteAbilityParam, Void> {

}
