package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupBoostGiveApplyInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 *
 */
@Data
@SuperBuilder
public class SaleGroupApplyInfoAbilityParam extends AtomAbilitySingleTargetParam<SaleGroupBoostGiveApplyInfoViewDTO> {
    private CampaignGroupViewDTO campaignGroup;
    private SaleGroupInfoViewDTO mainSaleGroupInfoViewDTO;
}
