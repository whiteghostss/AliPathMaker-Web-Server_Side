package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.delivery;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupDeliveryTargetInitForSyncSaleGroupAbilityParam;

@AbilityDefinition(desc = "订单分组-多目标交付初始化-同步更新资源包分组配置")
public interface ISaleGroupDeliveryTargetInitForSyncSaleGroupAbility
        extends AtomAbility<SaleGroupDeliveryTargetInitForSyncSaleGroupAbilityParam, Void> {
}
