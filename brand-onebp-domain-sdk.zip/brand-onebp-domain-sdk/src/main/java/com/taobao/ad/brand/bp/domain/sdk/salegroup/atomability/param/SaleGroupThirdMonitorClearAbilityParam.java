package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilityMultiTargetsParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * 订单分组第三方监测清除定义参数
 */
@Data
@SuperBuilder
public class SaleGroupThirdMonitorClearAbilityParam extends AtomAbilityMultiTargetsParam<SaleGroupInfoViewDTO> {

}
