package com.taobao.ad.brand.bp.domain.sdk.campaign.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.ad.brand.dto.adgroup.CreativeRefViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBottomDirectCreativeBuildAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBottomDirectCreativeRefBuildAbilityParam;

import java.util.List;

@AbilityDefinition(desc = "计划-构建打底媒体直投创意Ref")
public interface ICampaignBottomDirectCreativeRefBuildAbility extends AtomAbility<CampaignBottomDirectCreativeRefBuildAbilityParam, List<CreativeRefViewDTO>> {

}
