package com.taobao.ad.brand.bp.domain.sdk.adgroup.workflow;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.ability.GenericIsoBaseAbility;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.ability.param.BizAdgroupAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.workflow.param.BizAdgroupBindWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.workflow.param.BizAdgroupDirectCreativeGenerateWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.workflow.param.BizAdgroupWorkflowParam;

/**
 * Description:计划command流程切入点接口
 * <p>
 * date: 2023/10/13 12:03 AM
 *
 * @author shiyan
 * @version 1.0
 */
@AbilityDefinition(desc = "业务流程扩展点")
public interface BizAdgroupCommandWorkflowExt extends GenericIsoBaseAbility<BaseViewDTO> {

    /**
     * 业务新增数据初始化
     *
     * @param serviceContext
     * @param adgroupViewDTO
     * @return
     */
    default BizAdgroupWorkflowParam buildParamForAddOrUpdate(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO) {
        return null;
    }

    default BizAdgroupBindWorkflowParam buildParamForAdgroupBind(ServiceContext serviceContext,
                                                                 AdgroupViewDTO adgroupViewDTO){
        return null;
    }

    default Void beforeAdgroupUpdate(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO,
                                     BizAdgroupWorkflowParam paramDefinition) {
        return null;
    }

    default Void afterAdgroupUpdate(ServiceContext context, AdgroupViewDTO adgroupViewDTO, BizAdgroupAbilityParam bizAdgroupAbilityParam) {
        return null;
    }

    /**
     * 业务新增数据初始化
     *
     * @param serviceContext
     * @param adgroupViewDTO
     * @return
     */
    default BizAdgroupDirectCreativeGenerateWorkflowParam buildParamForGenerateDirectCreative(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO) {
        return null;
    }

    /**
     * 单元上线前置链路处理
     * @param serviceContext
     * @param adgroupViewDTO
     * @param workflowParam
     * @return
     */
    default Void beforeSetAdgroupOnline(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, BizAdgroupWorkflowParam workflowParam) {

        return null;
    }



    default Void beforeAdgroupAdd(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO,
                                  BizAdgroupWorkflowParam paramDefinition) {
        return null;
    }

    default Void afterAdgroupAdd(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO,
                                 BizAdgroupWorkflowParam paramDefinition) {
        return null;
    }
}
