package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupBoostStatusUpdateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupGiveStatusUpdateAbilityParam;

@AbilityDefinition(desc = "订单-订单配送状态更新")
public interface ICampaignGroupGiveStatusUpdateAbility extends AtomAbility<CampaignGroupGiveStatusUpdateAbilityParam, Void> {

}
