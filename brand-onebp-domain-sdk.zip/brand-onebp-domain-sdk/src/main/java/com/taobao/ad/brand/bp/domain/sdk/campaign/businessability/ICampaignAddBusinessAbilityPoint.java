package com.taobao.ad.brand.bp.domain.sdk.campaign.businessability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.abf.isolation.spec.annotation.AbilityPoint;
import com.alibaba.abf.isolation.spec.common.IsoLevel;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbility;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbilityRouteContext;

import java.util.List;

@AbilityDefinition(desc = "计划新建流程-商业能力挂载点定义", level = IsoLevel.workflow)
public interface ICampaignAddBusinessAbilityPoint extends BusinessAbility {
    /**
     * 新增流程-商业能力调用
     *
     * @param serviceContext
     * @param campaignViewDTO
     * @param businessAbilityRouteContext
     * @return
     */
    @AbilityPoint
    default Void invokeForCampaignAdd(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        return null;
    }

    /**
     * 新建流程-商业能力调用
     *
     * @param serviceContext
     * @param campaignViewDTOList
     * @param businessAbilityRouteContext
     * @return
     */
    @AbilityPoint
    default Void invokeForAfterCampaignAdd(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList, BusinessAbilityRouteContext businessAbilityRouteContext) {
        return null;
    }
}
