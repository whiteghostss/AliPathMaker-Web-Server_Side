package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupOrderAbilityParam;

@AbilityDefinition(desc = "订单-订单分组初始化-订单下单流程")
public interface ISaleGroupInitForOrderCampaignGroupAbility extends AtomAbility<SaleGroupOrderAbilityParam, Void> {

}
