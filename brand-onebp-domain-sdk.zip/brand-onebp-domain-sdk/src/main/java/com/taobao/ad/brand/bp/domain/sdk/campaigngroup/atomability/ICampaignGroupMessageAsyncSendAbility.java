package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupMessageAsyncSendAbilityParam;

@AbilityDefinition(desc = "订单-异步消息发送")
public interface ICampaignGroupMessageAsyncSendAbility extends AtomAbility<CampaignGroupMessageAsyncSendAbilityParam, Void> {

}
