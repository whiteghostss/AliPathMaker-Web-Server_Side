package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupNReachJudgeAbilityParam;

@AbilityDefinition(desc = "单元-生成NReach单元判断")
public interface IAdgroupNReachJudgeAbility
        extends AtomAbility<AdgroupNReachJudgeAbilityParam, Boolean> {
}
