package com.taobao.ad.brand.bp.domain.sdk.creative.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeMalusConvergeElementGetAbilityParam;

import java.util.Map;

@AbilityDefinition(desc = "海棠创意-聚合元素获取-转换创意")
public interface ICreativeMalusConvergeElementGetForConvertCreativeAbility extends AtomAbility<CreativeMalusConvergeElementGetAbilityParam, Map<String, Object>> {

}
