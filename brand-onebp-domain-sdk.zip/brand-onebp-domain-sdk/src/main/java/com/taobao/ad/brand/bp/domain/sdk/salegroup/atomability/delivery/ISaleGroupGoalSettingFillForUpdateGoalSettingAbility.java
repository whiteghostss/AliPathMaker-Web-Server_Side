package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.delivery;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupGoalSettingFillForUpdateGoalSettingAbilityParam;

@AbilityDefinition(desc = "订单分组-交付优化目标数据填充-更新交付优化目标")
public interface ISaleGroupGoalSettingFillForUpdateGoalSettingAbility
        extends AtomAbility<SaleGroupGoalSettingFillForUpdateGoalSettingAbilityParam, SaleGroupInfoViewDTO> {
}
