package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param;

import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * 单元第三方监测-初始化-新建单元-能力参数
 */
@Data
@SuperBuilder
public class AdgroupThirdMonitorInitForAddAdgroupAbilityParam extends AtomAbilitySingleTargetParam<AdgroupViewDTO> {
}
