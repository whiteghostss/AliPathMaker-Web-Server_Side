package com.taobao.ad.brand.bp.domain.sdk.base.workflow;

/**
 * 流程定义
 */
public class Workflow {

}
