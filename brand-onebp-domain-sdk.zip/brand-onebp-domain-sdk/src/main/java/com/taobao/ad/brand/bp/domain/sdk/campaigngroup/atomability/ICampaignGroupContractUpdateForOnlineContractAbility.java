package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupContractUpdateForTransitCampaignGroupAbilityParam;

@AbilityDefinition(desc = "订单-合同信息更新-合同上线流程")
public interface ICampaignGroupContractUpdateForOnlineContractAbility extends AtomAbility<CampaignGroupContractUpdateForTransitCampaignGroupAbilityParam, Void> {

}
