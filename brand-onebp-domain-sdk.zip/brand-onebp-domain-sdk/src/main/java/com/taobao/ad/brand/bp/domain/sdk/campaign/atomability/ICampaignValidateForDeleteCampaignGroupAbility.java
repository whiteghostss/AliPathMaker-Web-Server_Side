package com.taobao.ad.brand.bp.domain.sdk.campaign.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignValidateForDeleteCampaignGroupAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignValidateForSwitchCampaignAbilityParam;

@AbilityDefinition(desc = "计划状态-校验-删除订单流程")
public interface ICampaignValidateForDeleteCampaignGroupAbility extends AtomAbility<CampaignValidateForDeleteCampaignGroupAbilityParam, Void> {

}
