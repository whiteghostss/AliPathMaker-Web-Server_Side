package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupCrowdInitForUpdateSaleGroupAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupStatusValidateForUpdateSaleGroupAbilityParam;

@AbilityDefinition(desc = "订单分组-人群初始化-更新订单分组")
public interface ISaleGroupCrowdInitForUpdateSaleGroupAbility extends AtomAbility<SaleGroupCrowdInitForUpdateSaleGroupAbilityParam, Void> {
}
