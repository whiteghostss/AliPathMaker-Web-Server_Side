package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupAbilityParam;

@AbilityDefinition(desc = "订单-物理删除")
public interface ICampaignGroupDeleteAbility extends AtomAbility<CampaignGroupAbilityParam, Integer> {

}
