package com.taobao.ad.brand.bp.domain.sdk.campaign.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignRightsAbilityParam;

@AbilityDefinition(desc = "计划权益-校验-新增或编辑计划流程")
public interface ICampaignRightsValidateForAddOrUpdateCampaignAbility extends AtomAbility<CampaignRightsAbilityParam, Void> {

}
