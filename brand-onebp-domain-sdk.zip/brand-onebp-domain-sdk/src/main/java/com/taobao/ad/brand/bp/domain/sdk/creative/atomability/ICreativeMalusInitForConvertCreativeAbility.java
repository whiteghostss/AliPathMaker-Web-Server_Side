package com.taobao.ad.brand.bp.domain.sdk.creative.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeMalusInitAbilityParam;

@AbilityDefinition(desc = "海棠创意-数据初始化-转换创意")
public interface ICreativeMalusInitForConvertCreativeAbility extends AtomAbility<CreativeMalusInitAbilityParam, Void> {

}
