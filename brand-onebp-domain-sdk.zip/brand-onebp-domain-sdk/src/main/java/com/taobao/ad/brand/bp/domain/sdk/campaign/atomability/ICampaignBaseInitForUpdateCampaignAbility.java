package com.taobao.ad.brand.bp.domain.sdk.campaign.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBaseAbilityParam;

@AbilityDefinition(desc = "计划基础信息-初始化-修改计划流程")
public interface ICampaignBaseInitForUpdateCampaignAbility extends AtomAbility<CampaignBaseAbilityParam, Void> {

}
