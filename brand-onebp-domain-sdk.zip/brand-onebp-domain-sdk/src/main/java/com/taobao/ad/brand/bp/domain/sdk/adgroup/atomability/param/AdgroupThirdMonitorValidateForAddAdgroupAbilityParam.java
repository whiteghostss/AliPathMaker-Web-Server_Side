package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param;

import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 *
 */
@Data
@SuperBuilder
public class AdgroupThirdMonitorValidateForAddAdgroupAbilityParam extends AtomAbilitySingleTargetParam<AdgroupViewDTO> {

    /**
     * 计划信息
     */
    private CampaignViewDTO campaignViewDTO;

    /**
     * 资源包售卖分组信息
     */
    private ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO;

}
