package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.ability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.ability.GenericIsoBaseAbility;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;

@AbilityDefinition(desc = "订单PROCESS能力扩展点")
public interface BizCampaignGroupProcessAbilityExt extends GenericIsoBaseAbility<BaseViewDTO> {
    void validateForQueryRealSettleInfo(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO);
}
