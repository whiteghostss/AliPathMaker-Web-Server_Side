package com.taobao.ad.brand.bp.domain.sdk.creative.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeRefAdgroupMixDateValidateAbilityParam;

@AbilityDefinition(desc = "创意绑定-周期-校验")
public interface ICreativeRefAdgroupMixDateValidateAbility extends AtomAbility<CreativeRefAdgroupMixDateValidateAbilityParam, Void> {

}
