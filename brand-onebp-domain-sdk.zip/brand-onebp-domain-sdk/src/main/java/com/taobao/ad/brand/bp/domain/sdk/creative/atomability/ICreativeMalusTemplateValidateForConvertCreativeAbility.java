package com.taobao.ad.brand.bp.domain.sdk.creative.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeMalusTemplateValidateAbilityParam;

@AbilityDefinition(desc = "海棠创意-模板校验-转换创意")
public interface ICreativeMalusTemplateValidateForConvertCreativeAbility extends AtomAbility<CreativeMalusTemplateValidateAbilityParam,Void> {

}
