package com.taobao.ad.brand.bp.domain.sdk.campaign.ability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.ability.GenericIsoBaseAbility;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.campaign.ability.param.BizCampaignAbilityParam;

@Deprecated
@AbilityDefinition(desc = "计划校验能力扩展点")
public interface BizCampaignValidateAbilityExt extends GenericIsoBaseAbility<BaseViewDTO> {

    default Void validateCampaignForAdd(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, BizCampaignAbilityParam paramDefinition){
        return null;
    }

    default Void validateCampaignForUpdate(ServiceContext context, CampaignViewDTO dbCampaignViewDTO, CampaignViewDTO campaignViewDTO, BizCampaignAbilityParam paramDefinition) {
        return null;
    }

    /**
     * 计划是否允许修改
     *
     * @param serviceContext
     * @param dbCampaignViewDTO
     * @param campaignViewDTO
     * @return
     */
    default Boolean isCanUpdateCampaignDate(ServiceContext serviceContext, CampaignViewDTO dbCampaignViewDTO, CampaignViewDTO campaignViewDTO){
        return false;
    }

}
