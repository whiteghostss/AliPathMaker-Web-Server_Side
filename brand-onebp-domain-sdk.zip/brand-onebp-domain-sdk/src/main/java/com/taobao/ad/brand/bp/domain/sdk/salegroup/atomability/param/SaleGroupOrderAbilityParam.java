package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilityMultiTargetsParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

import java.util.List;

/**
 * 分组下单
 */
@Data
@SuperBuilder
public class SaleGroupOrderAbilityParam extends AtomAbilityMultiTargetsParam<SaleGroupInfoViewDTO> {
    /**
     * 订单
     */
    private CampaignGroupViewDTO campaignGroupViewDTO;
    /**
     * 下单的分组ID
     */
    private List<Long> saleGroupIds;

    /**
     * 资源包全量分组信息
     */
    private List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupList;
    /**
     * 计划
     */
    private List<CampaignViewDTO> campaignViewDTOList;

    private List<CampaignGroupViewDTO> subCampaignGroupList;
}
