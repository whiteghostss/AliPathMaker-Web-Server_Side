package com.taobao.ad.brand.bp.domain.sdk.creative.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.DoohCreativeBindForAdgroupUpdateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.DoohCreativeInitForAdgroupUpdateAbilityParam;

@AbilityDefinition(desc = "天攻创意-初始化-单元更新")
public interface IDoohCreativeBindForAdgroupUpdateAbility extends AtomAbility<DoohCreativeBindForAdgroupUpdateAbilityParam, Void> {

}
