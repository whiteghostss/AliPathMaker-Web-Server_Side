package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param;

import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilityMultiTargetsParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

import java.util.List;

/**
 * 订单-分组
 */
@Data
@SuperBuilder
public class SaleGroupDeleteAbilityParam extends AtomAbilityMultiTargetsParam<Long> {
    /**
     * 订单
     */
    private CampaignGroupViewDTO campaignGroupViewDTO;

}
