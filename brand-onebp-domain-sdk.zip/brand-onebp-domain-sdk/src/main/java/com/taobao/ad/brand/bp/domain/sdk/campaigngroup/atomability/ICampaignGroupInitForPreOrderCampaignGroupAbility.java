package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupPreOrderAbilityParam;

@AbilityDefinition(desc = "订单-订单初始化-订单预下单流程")
public interface ICampaignGroupInitForPreOrderCampaignGroupAbility extends AtomAbility<CampaignGroupPreOrderAbilityParam, Void> {

}
