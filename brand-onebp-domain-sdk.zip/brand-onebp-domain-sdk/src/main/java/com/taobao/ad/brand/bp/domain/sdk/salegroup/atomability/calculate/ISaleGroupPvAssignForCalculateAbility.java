package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.calculate;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignCalculateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.ResourcePackageSaleGroupCalculateAbilityParam;

@AbilityDefinition(desc = "分组-pv分配-计算")
public interface ISaleGroupPvAssignForCalculateAbility extends AtomAbility<ResourcePackageSaleGroupCalculateAbilityParam, Long> {
}
