package com.taobao.ad.brand.bp.domain.sdk.base.businessability;

import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * 商业能力路由上下文定义
 */
@Data
@Builder
public class BusinessAbilityRouteContext {
    /**
     * 资源包售卖分组
     */
    private ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO;

    /**
     * 资源包分组产品
     */
    private ResourcePackageProductViewDTO resourcePackageProductViewDTO;
    /**
     * SSP二级产品
     */
    private ProductViewDTO productViewDTO;

    /**
     * 指定具体商业能力Code集合
     * BusinessAbilityCode
     */
    private List<String> specifiedBusinessAbilityCodes;
}
