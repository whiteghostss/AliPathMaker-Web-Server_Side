package com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.param.CartItemCustomerCheckAbilityParam;

@AbilityDefinition(desc = "加购行-客户类型-新增加购行/下单")
public interface ICartItemCustomerJudgeAbility extends AtomAbility<CartItemCustomerCheckAbilityParam, Void> {

}
