package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param;

import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilityMultiTargetsParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * 批量删除单元参数
 */
@Data
@SuperBuilder
public class AdgroupBatchDeleteAbilityParam extends AtomAbilityMultiTargetsParam<Long> {

}
