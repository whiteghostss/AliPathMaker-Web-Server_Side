package com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param;

import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbilitySingleTargetParam;
import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * 单元-数量-校验参数
 */
@Data
@SuperBuilder
public class AdgroupCountValidateForAddOrUpdateAbilityParam extends AtomAbilitySingleTargetParam<AdgroupViewDTO> {
    /**
     * 数据库单元信息
     */
    private AdgroupViewDTO dbAdgroupViewDTO;
    /**
     * 计划信息
     */
    private CampaignViewDTO campaignViewDTO;
    /**
     * 订单信息
     */
    private CampaignGroupViewDTO campaignGroupViewDTO;
}
