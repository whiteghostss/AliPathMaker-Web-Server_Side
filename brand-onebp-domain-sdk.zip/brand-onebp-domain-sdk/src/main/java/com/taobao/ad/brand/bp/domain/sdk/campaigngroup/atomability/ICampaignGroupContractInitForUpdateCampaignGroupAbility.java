package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupContractAbilityParam;

@AbilityDefinition(desc = "订单-合同初始化-新建订单流程")
public interface ICampaignGroupContractInitForUpdateCampaignGroupAbility extends AtomAbility<CampaignGroupContractAbilityParam, Void> {

}
