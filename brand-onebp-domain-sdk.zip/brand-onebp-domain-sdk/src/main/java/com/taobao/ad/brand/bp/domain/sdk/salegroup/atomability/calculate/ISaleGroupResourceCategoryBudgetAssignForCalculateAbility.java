package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.calculate;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignCalculateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupBudgetAssignAbilityParam;

import java.util.Map;

@AbilityDefinition(desc = "分组-资源分类预算分配-计算")
public interface ISaleGroupResourceCategoryBudgetAssignForCalculateAbility extends AtomAbility<SaleGroupBudgetAssignAbilityParam, Map<String, Long>> {
}
