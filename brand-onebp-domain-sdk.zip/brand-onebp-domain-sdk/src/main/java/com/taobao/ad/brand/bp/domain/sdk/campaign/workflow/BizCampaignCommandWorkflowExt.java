package com.taobao.ad.brand.bp.domain.sdk.campaign.workflow;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.ability.GenericIsoBaseAbility;
import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignBatchDeleteViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignDelayLockApplyViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignAutoReleaseWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignBudgetWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignCalculateWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignWorkflowParam;

import java.util.List;

/**
 * Description:计划command流程切入点接口
 * <p>
 * date: 2023/10/13 12:03 AM
 *
 * @author shiyan
 * @version 1.0
 */
@AbilityDefinition(desc = "业务流程扩展点")
public interface BizCampaignCommandWorkflowExt extends GenericIsoBaseAbility<BaseViewDTO> {

    /**
     * 构建扩展参数
     *
     * @param serviceContext
     * @param campaignViewDTO
     * @return
     */
    default BizCampaignWorkflowParam buildParamForAddOrUpdate(ServiceContext serviceContext,
                                                              CampaignViewDTO campaignViewDTO) {

        return null;
    }

    /**
     * 新增流程：前置业务流程扩展点
     * @param serviceContext
     * @param campaignViewDTO
     * @param workflowParam
     * @return
     */
    default Void beforeForAdd(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, BizCampaignWorkflowParam workflowParam) {

        return null;
    }

    /**
     * 修改流程：前置业务流程扩展点
     * @param serviceContext
     * @param campaignViewDTO
     * @param workflowParam
     * @return
     */
    default Void beforeForUpdate(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO,CampaignViewDTO dbCampaignViewDTO, BizCampaignWorkflowParam workflowParam) {

        return null;
    }

    /**
     * 新增场景后置处理逻辑
     *
     * @param serviceContext
     * @param campaignViewDTO
     * @return
     */
    default Void afterAddCampaign(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, BizCampaignWorkflowParam bizCampaignWorkflowParam) {

        return null;
    }

    /**
     * 新增异常处理
     *
     * @param serviceContext
     * @param campaignIdList
     * @return
     */
    default Void throwingAddCampaign(ServiceContext serviceContext, List<Long> campaignIdList) {

        return null;
    }

    /**
     * 修改场景后置处理逻辑
     *
     * @param serviceContext
     * @param campaignViewDTO
     * @param dbCampaignViewDTO
     * @param bizCampaignWorkflowParam
     * @return
     */
    default Void afterUpdateCampaign(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, CampaignViewDTO dbCampaignViewDTO, BizCampaignWorkflowParam bizCampaignWorkflowParam) {

        return null;
    }

    /**
     * 业务前置删除处理
     * @param serviceContext
     * @param campaignViewDTO
     * @return
     */
    default Void beforeForDelete(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {

        return null;
    }

    /**
     * 删除场景后置处理逻辑
     *
     * @param serviceContext
     * @param delCampaignViewDTOList
     * @return
     */
    default Void afterBatchDeleteCampaign(ServiceContext serviceContext, List<CampaignViewDTO> delCampaignViewDTOList) {

        return null;
    }

    /**
     * 业务批量删除校验
     *
     * @param serviceContext
     * @param batchDeleteViewDTO
     * @return
     */
    default Void beforeBatchDeleteCampaign(ServiceContext serviceContext, CampaignBatchDeleteViewDTO batchDeleteViewDTO) {

        return null;
    }

    default BizCampaignCalculateWorkflowParam buildParamForCalculate(ServiceContext serviceContext,
                                                                     CampaignViewDTO campaignViewDTO) {
        return null;
    }


    /**
     * 构建扩展参数
     *
     * @param serviceContext
     * @param campaignViewDTO
     * @return
     */
    default BizCampaignBudgetWorkflowParam buildParamForAssignBudget(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {

        return null;
    }


    default Void rebuildCalSaleGroupInfo(ServiceContext serviceContext, ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO, SaleGroupInfoViewDTO saleGroupInfoViewDTO, List<CampaignViewDTO> campaignViewDTOList) {
        return null;
    }

//    default Void batchSwitchCampaign(ServiceContext serviceContext, List<CampaignViewDTO> operateList,
//                                     SwitchEnum switchEnum){
//        return null;
//    }

//    default List<BizCampaignAutoReleaseWorkflowParam> buildAutoReleaseDelayLockParamExt(ServiceContext serviceContext,
//                                                                                CampaignDelayLockApplyViewDTO campaignDelayLockApplyViewDTO){
//        return null;
//    }

    /**
     * 投放时间更新后
     *
     * @param serviceContext
     * @param campaignViewDTO
     * @return
     */
    default Void afterForUpdateCastDate(ServiceContext serviceContext, CampaignViewDTO dbCampaignViewDTO, CampaignViewDTO campaignViewDTO) {

        return null;
    }

    default Void handleAfterCancelCampaignGroup(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, List<CampaignViewDTO> campaignTreeList) {
        return null;
    }

    default Void handleAfterStopCampaignGroup(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO) {
        return null;
    }

    default Void beforeAutoAddCampaign(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, List<CampaignViewDTO> campaignViewDTOList) {
        return null;
    }

    default Void afterAutoAddCampaign(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, List<Long> campaignIds) {
        return null;
    }

    default Void afterAutoUpdateCampaign(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, List<Long> addCampaignIds) {
        return null;
    }
}
