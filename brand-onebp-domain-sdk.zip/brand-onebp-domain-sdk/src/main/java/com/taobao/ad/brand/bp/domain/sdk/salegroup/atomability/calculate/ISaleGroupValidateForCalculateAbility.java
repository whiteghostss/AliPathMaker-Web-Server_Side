package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.calculate;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignCalculateAbilityParam;

@AbilityDefinition(desc = "分组-下单状态校验-计算")
public interface ISaleGroupValidateForCalculateAbility extends AtomAbility<CampaignCalculateAbilityParam, Void> {

}
