package com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupCustomerAbilityParam;

@AbilityDefinition(desc = "订单-客户校验-新建流程")
public interface ICampaignGroupCustomerValidateForAddCampaignGroupAbility extends AtomAbility<CampaignGroupCustomerAbilityParam, Void> {

}
