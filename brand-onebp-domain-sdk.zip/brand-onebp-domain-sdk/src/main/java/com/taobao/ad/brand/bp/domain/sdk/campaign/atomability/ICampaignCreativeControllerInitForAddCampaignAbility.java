package com.taobao.ad.brand.bp.domain.sdk.campaign.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.alibaba.ad.brand.dto.campaign.creative.CampaignCreativeControllerViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignCreativeControllerAbilityParam;

@AbilityDefinition(desc = "计划创意控制-初始化-新增计划流程")
public interface ICampaignCreativeControllerInitForAddCampaignAbility extends AtomAbility<CampaignCreativeControllerAbilityParam, CampaignCreativeControllerViewDTO> {

}
