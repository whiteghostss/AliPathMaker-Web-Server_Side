package com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupPackageProductCalculateInfoInitAbilityParam;

@AbilityDefinition(desc = "订单-分组产品计算信息初始化")
public interface ISaleGroupPackageProductCalculateInfoInitAbility extends AtomAbility<SaleGroupPackageProductCalculateInfoInitAbilityParam, Void> {

}
