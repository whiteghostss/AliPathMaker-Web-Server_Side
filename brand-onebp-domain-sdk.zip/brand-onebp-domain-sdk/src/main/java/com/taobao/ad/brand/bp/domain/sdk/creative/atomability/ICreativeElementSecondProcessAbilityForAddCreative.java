package com.taobao.ad.brand.bp.domain.sdk.creative.atomability;

import com.alibaba.abf.isolation.spec.annotation.AbilityDefinition;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.AtomAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeElementSecondProcessAbilityParam;

@AbilityDefinition(desc = "创意元素-二次处理-新增创意")
public interface ICreativeElementSecondProcessAbilityForAddCreative extends AtomAbility<CreativeElementSecondProcessAbilityParam, Void> {

}
