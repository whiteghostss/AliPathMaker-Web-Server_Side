package com.taobao.ad.brand.bp.domain.sdk.base.atomability;

import lombok.Data;
import lombok.experimental.SuperBuilder;

import java.util.List;

/**
 * 原子能力参数定义(多目标对象实体场景)
 */
@Data
@SuperBuilder
public class AtomAbilityMultiTargetsParam<AbilityTarget> implements AtomAbilityParam {

    /**
     * 原子能力目标对象实体
     */
    private List<AbilityTarget> abilityTargets;

}
