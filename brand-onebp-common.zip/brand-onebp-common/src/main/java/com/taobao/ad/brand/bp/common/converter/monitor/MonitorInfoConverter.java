package com.taobao.ad.brand.bp.common.converter.monitor;

import com.alibaba.ad.brand.dto.monitor.ThirdMonitorUrlViewDTO;
import com.taobao.ad.brand.bp.common.converter.monitor.mapstruct.MonitorInfoMapStruct;
import com.taobao.ad.brand.bp.client.dto.monitor.MonitorInfoDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.springframework.stereotype.Component;

@Component
public class MonitorInfoConverter extends BaseViewDTOConverter<MonitorInfoDTO, ThirdMonitorUrlViewDTO> {
    @Override
    public BaseMapStructMapper<MonitorInfoDTO, ThirdMonitorUrlViewDTO> getBaseMapStructMapper() {
        return MonitorInfoMapStruct.INSTANCE;
    }

}
