package com.taobao.ad.brand.bp.common.constant.talent;

import com.taobao.ad.brand.bp.common.constant.ReportConstant;

public class FinalDataQueryConstant extends ReportConstant {
    /**
     * 订单ID
     */
    public static final String ORDER_ID_EQUAL = "orderIdEqual";
    /**
     * 达人唯一ID
     */
    public static final String USER_ID_IN = "userIdIn";
    /**
     * 媒体ID
     */
    public static final String MEDIA_ID_IN = "mediaIdIn";
    /**
     * 作品链接
     */
    public static final String WORK_URL_IN = "workUrlIn";
    /**
     * 最小日期，通常取订单开始日期
     */
    public static final String DATE_GREATER_THAN_OR_EQUAL_TO = "dateGreaterThanOrEqualTo";
}
