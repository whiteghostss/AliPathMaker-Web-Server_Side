package com.taobao.ad.brand.bp.common.util;

import com.alimama.checkchain.client.internal.util.RogerLogger;
import org.apache.velocity.runtime.RuntimeServices;
import org.apache.velocity.runtime.log.LogChute;

/**
 * 自定义日志
 *
 * @author duxiaokang
 * @date 2019/7/16
 */
public class CustomLogChute implements LogChute {

    public CustomLogChute() {
        RogerLogger.info("LogChute开始切换为RogerLogger...");
    }

    @Override
    public void init(RuntimeServices runtimeServices) throws Exception {

    }

    @Override
    public void log(int level, String message) {
        switch (level) {
            case TRACE_ID:
                RogerLogger.debug(message);
                break;
            case DEBUG_ID:
                RogerLogger.debug(message);
                break;
            case INFO_ID:
                RogerLogger.info(message);
                break;
            case WARN_ID:
                RogerLogger.warn(message);
                break;
            case ERROR_ID:
                RogerLogger.error(message);
                break;
            default:
        }
    }

    @Override
    public void log(int level, String message, Throwable t) {
        switch (level) {
            case TRACE_ID:
                RogerLogger.debug(message, t);
                break;
            case DEBUG_ID:
                RogerLogger.debug(message, t);
                break;
            case INFO_ID:
                RogerLogger.info(message, t);
                break;
            case WARN_ID:
                RogerLogger.warn(message, t);
                break;
            case ERROR_ID:
                RogerLogger.error(message, t);
                break;
            default:
        }
    }

    @Override
    public boolean isLevelEnabled(int level) {
        switch (level) {
            case INFO_ID:
                return true;
            case WARN_ID:
                return true;
            case ERROR_ID:
                return true;
            default:
                return false;
        }
    }
}
