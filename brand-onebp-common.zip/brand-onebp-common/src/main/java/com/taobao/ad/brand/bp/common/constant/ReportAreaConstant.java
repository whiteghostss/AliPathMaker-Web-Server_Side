package com.taobao.ad.brand.bp.common.constant;

/**
 * 地域常量类
 */
public class ReportAreaConstant extends ReportConstant {

    /**
     * 查询地域数据接口
     */
    public static final String PROVINCE_CITY_TRANSFER_API = "brand_onebp.common.common.rptAreaDataApi";

    /**
     * 省份idList
     */
    public static final String PROVINCE_ID_IN = "provinceIdIn";

    /**
     * 城市idList
     */
    public static final String CITY_ID_IN = "cityIdIn";

    /**
     * 国家idList
     */
    public static final String COUNTRY_ID_IN = "countryIdIn";
}
