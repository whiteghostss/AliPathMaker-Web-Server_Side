package com.taobao.ad.brand.bp.common.statemachine;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.alibaba.cola.statemachine.State;
import com.alibaba.cola.statemachine.StateMachine;
import com.alibaba.cola.statemachine.StateMachineFactory;
import com.alibaba.cola.statemachine.builder.ExternalTransitionBuilder;
import com.alibaba.cola.statemachine.builder.ExternalTransitionsBuilder;
import com.alibaba.cola.statemachine.builder.InternalTransitionBuilder;
import com.alibaba.cola.statemachine.builder.StateMachineBuilder;
import com.alibaba.cola.statemachine.builder.TransitionsBuilderImpl;
import com.alibaba.cola.statemachine.impl.TransitionType;

/**
 * @author yanjingang
 * @date 2023/3/7
 */
public class BrandStateMachineBuilderImpl<S, E, C> implements StateMachineBuilder<S, E, C> {

    /**
     * Key: from and to state
     * value：
     */
    private final Map<S, State<S, E, C>> stateMap = new ConcurrentHashMap<>();
    private final BrandStateMachineImpl<S, E, C> stateMachine = new BrandStateMachineImpl<>(stateMap);

    @Override
    public ExternalTransitionBuilder<S, E, C> externalTransition() {
        return new BrandTransitionBuilderImpl<>(stateMap, TransitionType.EXTERNAL);
    }

    @Override
    public ExternalTransitionsBuilder<S, E, C> externalTransitions() {
        return new TransitionsBuilderImpl<>(stateMap, TransitionType.EXTERNAL);
    }

    @Override
    public InternalTransitionBuilder<S, E, C> internalTransition() {
        return new BrandTransitionBuilderImpl<>(stateMap, TransitionType.INTERNAL);
    }

    @Override
    public BrandStateMachine<S, E, C> build(String machineId) {
        stateMachine.setMachineId(machineId);
        stateMachine.setReady(true);
        StateMachineFactory.register(stateMachine);
        return stateMachine;
    }


}
