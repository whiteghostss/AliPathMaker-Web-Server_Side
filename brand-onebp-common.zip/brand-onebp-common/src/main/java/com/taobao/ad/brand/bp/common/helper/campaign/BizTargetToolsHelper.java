package com.taobao.ad.brand.bp.common.helper.campaign;

import com.alibaba.ad.brand.sdk.constant.audience.field.BrandTargetTypeEnum;

import java.util.Arrays;

/**
 * Description:定向工具类
 * <p>
 * date: 2023/11/9 7:53 PM
 *
 * @author shiyan
 * @version 1.0
 */
public class BizTargetToolsHelper {
    /**
     *
     * @param code
     * @param labelId
     * @return
     */
    public static BrandTargetTypeEnum getByCode(Integer code, Long labelId) {
        if (code == null) {
            return null;
        }
        if (code == BrandTargetTypeEnum.BLOCK_CROWD.getCode().intValue()) {
            return BrandTargetTypeEnum.BLOCK_CROWD_ID.getLabelId().equals(labelId) ?
                        BrandTargetTypeEnum.BLOCK_CROWD_ID : BrandTargetTypeEnum.BLOCK_CROWD;
        }
        return Arrays.stream(BrandTargetTypeEnum.values())
                .filter(targetType -> targetType.getCode().equals(code)).findFirst().orElse(null);
    }

    public static BrandTargetTypeEnum getByCode(Integer code) {
        if (code == null) {
            return null;
        }
        if (code == BrandTargetTypeEnum.BLOCK_CROWD.getCode().intValue()) {
            return BrandTargetTypeEnum.BLOCK_CROWD;
        }
        return Arrays.stream(BrandTargetTypeEnum.values())
                .filter(targetType -> targetType.getCode().equals(code)).findFirst().orElse(null);
    }

}
