package com.taobao.ad.brand.bp.common.threadpooltask;


import com.alibaba.ad.nb.tpp.core.task.TaskIdentifier;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * @author jixiu.lj
 * @date 2024/3/7 20:20
 */
@Component
public class CampaignGetBottomInfoTaskIdentifier extends TaskIdentifier {

    @Resource
    CampaignUpdateTaskIdentifier campaignUpdateTaskIdentifier;

    @Override
    protected String applyThreadPoolTag() {
        return campaignUpdateTaskIdentifier.getThreadPoolTag();
    }



    @Override
    public Integer applyTaskTimeoutInSec() {
        return 10;
    }
}
