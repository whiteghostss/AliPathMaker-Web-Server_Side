package com.taobao.ad.brand.bp.common.constant;

/**
 * 报表接口常量
 */
public class ReportApiConstant {
    /**
     * 查询结案数据（供应商）
     */
    public static final String SUPPLIER_FINAL_DATA_API = "brand_onebp.common.common.rptContentTalentSupplierDataApi";
}
