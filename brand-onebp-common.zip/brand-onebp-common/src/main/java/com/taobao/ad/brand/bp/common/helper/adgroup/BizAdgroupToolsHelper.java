package com.taobao.ad.brand.bp.common.helper.adgroup;

import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.adgroup.ExportMonitorCodeViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.PubDealViewDTO;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Description:单元业务域工具类
 * <p>
 * date: 2023/11/9 7:53 PM
 *
 * @author shiyan
 * @version 1.0
 */
public class BizAdgroupToolsHelper {

    public static String adgroupMessage(List<AdgroupViewDTO> adgroupViewDTOList){
        String formatString = "(%s:%s)";
        List<String> messageList = Lists.newArrayList();
        adgroupViewDTOList.forEach(t->{
            messageList.add(String.format(formatString, t.getId(), t.getTitle()));
        });
        return StringUtils.join(messageList, ",");
    }
    /**
     * 格式化打底信息
     * @param exportMonitorCodeViewDTO
     * @param br
     * @return
     */
    public static String formatMonitorBottomInfo(ExportMonitorCodeViewDTO exportMonitorCodeViewDTO, String br){
        StringBuilder stringBuilder = new StringBuilder();
        for (PubDealViewDTO pubDealViewDTO : exportMonitorCodeViewDTO.getPubDealViewList()) {
            if(StringUtils.isNotBlank(pubDealViewDTO.getPubDealId())){
                stringBuilder.append(String.format("媒体DealId:%s</br>",pubDealViewDTO.getPubDealId()));
            }
            if(CollectionUtils.isNotEmpty(pubDealViewDTO.getBottomDays())){
                String bottomDays = pubDealViewDTO.getBottomDays().stream().sorted().map(BrandDateUtil::date2String)
                        .collect(Collectors.joining(","));
                stringBuilder.append(String.format("打底时间:%s</br>",bottomDays));
            }
        }
        stringBuilder.append(String.format("创意ID:%s</br>",exportMonitorCodeViewDTO.getCreativeId()));
        stringBuilder.append(String.format("创意名称:%s</br>",exportMonitorCodeViewDTO.getCreativeName()));
        return stringBuilder.toString().replaceAll("</br>",br);
    }

}
