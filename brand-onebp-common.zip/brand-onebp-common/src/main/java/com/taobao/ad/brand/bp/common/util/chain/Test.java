package com.taobao.ad.brand.bp.common.util.chain;

public class Test {
    public static void main(String[] args) {
        EnhancedChainBuilder.of(1L).execute();
    }
}
