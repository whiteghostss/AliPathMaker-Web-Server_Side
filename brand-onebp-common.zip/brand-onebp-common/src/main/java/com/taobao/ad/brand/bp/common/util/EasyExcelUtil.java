package com.taobao.ad.brand.bp.common.util;

import com.alibaba.excel.EasyExcel;
import com.alibaba.fastjson.JSONObject;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignPageViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author jixiu.lj
 * @date 2023/9/1 11:48
 * 搬运自ad-brandOnebp/common/EasyExcelUtil
 */
public class EasyExcelUtil {

    /**
     * 同步解析Excel文件
     *
     * @param data
     * @param clazz        解析目标类
     * @param metaFieldMap columnName-filedName
     * @param sheetNo
     * @param headRowNumber 第一行数据所在行
     * @param <T>
     * @return
     * @throws Exception
     */
    public static <T> List<T> parse(byte[] data, Class<T> clazz, Map<String, String> metaFieldMap, int sheetNo, int headRowNumber) throws Exception {
        List<T> result = Lists.newArrayList();
        Map<String, Field> fieldMap = buildFieldMap(clazz);
        if (CollectionUtils.isEmpty(fieldMap) || MapUtils.isEmpty(metaFieldMap)) {
            throw new RuntimeException("无效的Excel Metadata");
        }
        // map结构是 colNum-cellValue
        List<LinkedHashMap<Integer, Object>> rawData = EasyExcel.read(new ByteArrayInputStream(data))
                .sheet(sheetNo)
                .headRowNumber(0)
                .doReadSync();
        if (CollectionUtils.isEmpty(rawData)) {
            throw new RuntimeException("导入文件读取数据为空");
        }
        // 读取表头数据进行列对齐
        LinkedHashMap<Integer, Field> columnIndexFieldMap = columnAlignment(rawData.get(0), (LinkedHashMap<String, String>) metaFieldMap, fieldMap);
        if (MapUtils.isEmpty(columnIndexFieldMap)) {
            throw new RuntimeException("文件解析元数据不匹配");
        }
        for (int i = headRowNumber; i < rawData.size(); i++) {
            // 每一行的数据
            LinkedHashMap<Integer, Object> dataByRow = rawData.get(i);
            if (MapUtils.isEmpty(dataByRow)) {
                continue;
            }
            T instance = clazz.newInstance();
            for (Map.Entry<Integer, Object> entry : dataByRow.entrySet()) {
                // 每一列的数据
                Integer columnIndex = entry.getKey();
                Object cellValue = entry.getValue();
                Field field = columnIndexFieldMap.get(columnIndex);
                if (Objects.nonNull(field) && Objects.nonNull(cellValue)) {
                    setFieldValueByName(field, cellValue, instance);
                }
            }
            result.add(instance);
        }
        return result;
    }

    /**
     * columnIndex-columnName-filedName-field
     *
     * @param headMap
     * @param metaFieldMap
     * @return
     */
    private static LinkedHashMap<Integer, Field> columnAlignment(LinkedHashMap<Integer, Object> headMap, LinkedHashMap<String, String> metaFieldMap, Map<String, Field> fieldMap) {

        LinkedHashMap<Integer, Field> result = Maps.newLinkedHashMap();
        if (CollectionUtils.isEmpty(headMap)) {
            throw new RuntimeException("文件表头为空");
        }
        for (Map.Entry<Integer, Object> entry : headMap.entrySet()) {
            Integer columnIndex = entry.getKey();
            Object headName = entry.getValue();
            Optional.ofNullable(metaFieldMap.get((String) headName))
                    .map(fieldMap::get)
                    .ifPresent(field -> {
                        result.put(columnIndex, field);
                    });
        }
        return result;
    }

    /**
     * 待解析结构类的字段名map
     *
     * @param clazz
     * @return
     */
    private static Map<String, Field> buildFieldMap(Class clazz) {
        Map<String, Field> result = Maps.newHashMap();
        Field[] declaredFields = clazz.getDeclaredFields();
        for (Field field : declaredFields) {
            result.put(field.getName(), field);
        }
        return result;
    }

    private static void setFieldValueByName(Field field, Object fieldValue, Object o) {
        field.setAccessible(true);
        Class<?> fieldType = field.getType();
        try {
            if (fieldValue == null || StringUtils.isEmpty(fieldValue.toString())) {
                return;
            }
            if (String.class == fieldType) {
                field.set(o, String.valueOf(fieldValue));
            } else if ((Integer.TYPE == fieldType) || (Integer.class == fieldType)) {
                field.set(o, Integer.parseInt(fieldValue.toString()));
            } else if ((Byte.TYPE == fieldType) || (Byte.class == fieldType)) {
                field.set(o, Byte.parseByte(fieldValue.toString()));
            } else if ((Long.TYPE == fieldType) || (Long.class == fieldType)) {
                field.set(o, Long.valueOf(fieldValue.toString()));
            } else if ((Float.TYPE == fieldType) || (Float.class == fieldType)) {
                field.set(o, Float.valueOf(fieldValue.toString()));
            } else if (BigDecimal.class == fieldType) {
                field.set(o, new BigDecimal(fieldValue.toString()));
            } else if ((Double.TYPE == fieldType) || (Double.class == fieldType)) {
                field.set(o, Double.valueOf(fieldValue.toString()));
            } else if (Date.class == fieldType) {
                field.set(o, BrandDateUtil.string2Date(fieldValue.toString(), "yyyy-MM-dd"));
            } else {
                field.set(o, fieldValue.toString());
            }
        } catch (Exception e) {
            RogerLogger.error(e.getMessage(), e);
            throw new RuntimeException("Excel解析注入实体失败");
        }
    }

    public static <T> List<T> parse(String filePath, Class<T> clazz, Map<String, String> metaFieldMap, int sheetNo) throws Exception {
        List<T> result = Lists.newArrayList();
        Map<String, Field> fieldMap = buildFieldMap(clazz);
        if (CollectionUtils.isEmpty(fieldMap) || MapUtils.isEmpty(metaFieldMap)) {
            throw new RuntimeException("无效的Excel Metadata");
        }
        // map结构是 colNum-cellValue
        List<LinkedHashMap<Integer, Object>> rawData = EasyExcel.read(filePath)
                .sheet(sheetNo)
                .headRowNumber(0)
                .doReadSync();
        if (CollectionUtils.isEmpty(rawData)) {
            throw new RuntimeException("导入文件读取数据为空");
        }
        // 读取表头数据进行列对齐
        LinkedHashMap<Integer, Field> columnIndexFieldMap = columnAlignment(rawData.get(0), (LinkedHashMap<String, String>) metaFieldMap, fieldMap);
        if (MapUtils.isEmpty(columnIndexFieldMap)) {
            throw new RuntimeException("文件解析元数据不匹配");
        }
        // 跳过表头的解析
        for (int i = 1; i < rawData.size(); i++) {
            // 每一行的数据
            LinkedHashMap<Integer, Object> dataByRow = rawData.get(i);
            if (MapUtils.isEmpty(dataByRow)) {
                continue;
            }
            T instance = clazz.newInstance();
            for (Map.Entry<Integer, Object> entry : dataByRow.entrySet()) {
                // 每一列的数据
                Integer columnIndex = entry.getKey();
                Object cellValue = entry.getValue();
                Field field = columnIndexFieldMap.get(columnIndex);
                if (Objects.nonNull(field) && Objects.nonNull(cellValue)) {
                    setFieldValueByName(field, cellValue, instance);
                }
            }
            result.add(instance);
        }
        return result;
    }

    public static byte[] listToExcel(String sheetName, Map<String, String> fieldMap, List<Map<String, Object>> dataList) {
        List<String> keyList = Lists.newArrayList(fieldMap.keySet());
        List<String> nameList = Lists.newArrayList(fieldMap.values());
        List<List<Object>> excelDataList = Lists.newArrayList();
        dataList.forEach(map -> {
            List<Object> list = Lists.newArrayList();
            keyList.forEach(key -> list.add(map.get(key)));
            excelDataList.add(list);
        });

        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            EasyExcel.write(byteArrayOutputStream)
                    .head(nameList.stream().map(Lists::newArrayList).collect(Collectors.toList()))
                    .sheet(sheetName)
                    .doWrite(excelDataList);
            return byteArrayOutputStream.toByteArray();
        } catch (Exception e) {
            RogerLogger.error("listToExcel error {} ", JSONObject.toJSONString(e));
            throw new BrandOneBPException("生成excel失败 " + e.getMessage());
        }
    }

    public static void main(String[] args) throws Exception {
        LinkedHashMap<String, String> metaFieldMap = Maps.newLinkedHashMap();
        metaFieldMap.put("订单ID", "id");
        metaFieldMap.put("订单名称", "name");
        System.out.println(parse("/Users/leo/Downloads/执行结果2.xlsx", CampaignPageViewDTO.class, metaFieldMap, 0));
    }
}
