package com.taobao.ad.brand.bp.common.task;


import com.taobao.eagleeye.EagleEye;
import com.taobao.eagleeye.RpcContext_inner;

/**
 * 任务生成器
 */
public abstract class CreateTask implements Runnable {
    private RpcContext_inner rpcContext;


    public CreateTask() {
        rpcContext = EagleEye.getRpcContext();
    }

    @Override
    public void run() {
        EagleEye.setRpcContext(rpcContext);
        doRun();
    }

    public abstract void doRun();
}
