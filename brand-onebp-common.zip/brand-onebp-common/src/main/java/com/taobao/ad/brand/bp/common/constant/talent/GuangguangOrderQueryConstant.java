package com.taobao.ad.brand.bp.common.constant.talent;

import com.taobao.ad.brand.bp.common.constant.ReportConstant;

public class GuangguangOrderQueryConstant extends ReportConstant {

    public static final String CONTENT_ID_EQUAL = "contentIdEqual";

    public static final String CONTENT_ID_IN = "contentIdIn";

    public static final String SALE_GROUP_ID_EQUAL = "saleGroupIdEqual";

    public static final String SALE_GROUP_ID_IN = "saleGroupIdIn";

    public static final String KEYWORD = "keyword";
}
