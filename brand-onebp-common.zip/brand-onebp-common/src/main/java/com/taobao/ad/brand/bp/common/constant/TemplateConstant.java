package com.taobao.ad.brand.bp.common.constant;

import com.google.common.collect.Lists;

import java.util.List;

/**
 * 模板中心新定义的常量类
 *
 * @author duxiaokang
 */
public interface TemplateConstant {
    String CONSTANT_KEY_TEMPLATE_NAME = "templateName";
    String CONSTANT_KEY_COLUMNS = "columns";
    String CONSTANT_KEY_TYPE = "type";
    String DEVICE_TYPE = "device_type";
    String KEY = "key";
    String CONSTANT_KEY_LABEL = "label";
    String CONSTANT_KEY_TEXT = "text";
    String CONSTANT_KEY_BIZ_MAP = "$bizMap";
    String CONSTANT_KEY_EXTENDS_NAME_MAP = "$extendsNameMap";
    String CONSTANT_KEY_PROPERTIES = "properties";

    String CONSTANT_KEY_SIZE_LIST = "$sizeList";

    String CONSTANT_KEY_WIDTH = "width";

    String CONSTANT_KEY_HEIGHT = "height";

    String CONSTANT_KEY_ENGINE_NAME = "engineName";
    String FORM_MALUS_ELEMENT_KEY = "formMalusElementKey";
    String CONSTANT_KEY_DURATION = "duration";

    String CONSTANT_KEY_DEVICE = "device";

    String CONSTANT_KEY_IS_MAIN = "isMain";

    String CONSTANT_KEY_SITES = "sites";

    String CONSTANT_KEY_SITE_ID = "site_id";

    String CONSTANT_KEY_TEMPLATE_ID = "template_id";

    String IS_INTERACT = "is_interact";

    String SELECTED_OPTION = "selectedOption";
    String ITEM = "item";
    String SHOP = "shop";
    String URL = "url";
    String ITEM_ID = "itemId";
    String SHOP_ID = "shopId";
    String SHOP_LOGO = "shopLogo";
    String SHOP_TITLE = "shopTitle";
    String CLICK_URL = "clickurl";
    String CLICK_URL_TYPE = "clickurl_type";
    String CLICK_URL_SHOP_AVATAR = "clickurl_shop_avatar";
    String CLICK_URL_SHOP_NAME = "clickurl_shop_name";
    String CLICK_URL_SHOP_ID = "clickUrlShopId";
    String CLICK_URL_ITEM_ID = "clickUrlItemId";
    String SKUID = "skuId";
    String SKU_ID = "sku_id";
    String SKU = "sku";
    String VIDEO = "video";
    String FROZEN_FRAME = "frozen_frame";
    String IMG_URL = "img_url";
    String ACT_PIC = "act_pic";
    String SHOW_COUPON = "showCoupon";
    String ZERO = "0";
    String ONE = "1";

    String CONSTANT_KEY_CHECK_LIST = "$check";
    String CONSTANT_KEY_RELATION = "$relation";
    String CONSTANT_KEY_EXTENDS = "$extendsMap";
    String PROPERTY = "property";
    String RELATION_ELEMENT_KEY = "relationElementKey";
    String PROXY_MEMBER_ID = "proxyMemberId";
    String MEDIA_SCOPE = "MEDIA_SCOPE";
    String IMAGE_EXTEND = "imageExtend";
    /**
     * 视觉拓展
     */
    String VISUAL_IMAGE_EXTEND = "visualImageExtend";
    String VISUAL_IMAGES = "visualImages";
    String MAIN_IMAGE = "mainImage";
    String EXTEND_IMAGES = "extendImages";
    String SUB_TEMPLATE_IDS = "subTemplateIds";
    String EXTEND_VIDEOS = "extendVideos";
    String EXTENDS_NAMES = "extendsNames";
    String EXTENDS_KEYS = "extendsKeys";
    String CLICK_RUL = "click_url";
    String LANDING_PAGE = "landingPage";
    String FRAME = "frame";
    Long TWO_THREE_FRAME_TEMPLATE = 9999999L;
    Long OLD_TE_XIU_TEMPLATE_ID = 10010000L;
    /**
     * topShow模板 广告样式   popView-998 && 底纹词-999
     */
    List<String> sspAdTypeList = Lists.newArrayList("998", "999");
    String ITEM_ID_INPUT = "itemIdInput";

    String ORDER_BY_TAG = "tag";
    String BENEFIT_SELECT = "benefit-select";
    String DEFAULT_BENEFIT_STYLE_KEY = "defaultBenefitStyleKey";
    String BENEFIT_STYLE_KEY = "BenefitStyleKey";
    String CUSTOM_BENEFIT_TIPS_KEY = "customBenefitTipsKey";
    String BENEFIT_TEXT = "benefitText";

    /**
     * 元素默认值
     */
    String ELEMENT_DEFAULT_VALUE_KEY = "defaultValue";
    /**
     * 模板业务参数定义前缀
     */
    String PREFIX = "$";

    String WRAP = "[n]";

    String FILE_SIZE = "fileSize";
}