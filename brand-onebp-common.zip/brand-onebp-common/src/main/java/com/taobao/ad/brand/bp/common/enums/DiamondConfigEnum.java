package com.taobao.ad.brand.bp.common.enums;

public enum DiamondConfigEnum {
    TOPSHOW_CAMPAIGN_LOCK_CAMPAIGN_IDS("topshow.lock.campaign.whitelist", "topShow锁量计划白名单")


    ;
    private String code;
    private String desc;

    DiamondConfigEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
