package com.taobao.ad.brand.bp.common.util;

import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.apache.commons.lang.StringUtils;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * md5工具类
 *
 * @author duxiaokang
 * @date 2020/6/18
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class Md5Encrypt {

    public static String md5(String text, String charset) {
        MessageDigest msgDigest;

        try {
            msgDigest = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException var12) {
            RogerLogger.error("创建MD5加密对象MessageDigest失败!", var12);
            throw new BrandOneBPException("创建MD5加密对象MessageDigest失败!", var12);
        }

        byte[] input;
        try {
            if (StringUtils.isNotEmpty(charset)) {
                input = text.getBytes(charset);
            } else {
                input = text.getBytes();
            }
        } catch (UnsupportedEncodingException var11) {
            RogerLogger.error("不支持的字符编码，将字符串转为byte数组失败!", var11);
            throw new BrandOneBPException("不支持的字符编码，将字符串转为byte数组失败!", var11);
        }

        msgDigest.update(input);
        byte[] bytes = msgDigest.digest();
        StringBuffer md5Str = new StringBuffer();

        for (byte tb : bytes) {
            char tmpChar = (char) (tb >>> 4 & 15);
            char high;
            if (tmpChar >= '\n') {
                high = (char) (97 + tmpChar - 10);
            } else {
                high = (char) (48 + tmpChar);
            }

            md5Str.append(high);
            tmpChar = (char) (tb & 15);
            char low;
            if (tmpChar >= '\n') {
                low = (char) (97 + tmpChar - 10);
            } else {
                low = (char) (48 + tmpChar);
            }

            md5Str.append(low);
        }

        return md5Str.toString();
    }
}
