package com.taobao.ad.brand.bp.common.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @date 2023年03月31日
 */
@Component
public class MailUtils {

//    private static JavaMailSender mailSender;
//    private static String from;
    public static String rdRecipients;

//    @Value("${spring.mail.username}")
//    void setFrom(String f) {
//        from = f;
//    }

    @Value("${mail.to.rdRecipients}")
    void setRdRecipients(String rd) {
        rdRecipients = rd;
    }

//    @Autowired
//    void setMailSender(JavaMailSender javaMailSender) {
//        mailSender = javaMailSender;
//    }
//
//    @Deprecated
//    public static void sendMail(String to, String subject, String content) {
//        sendMail(to, null, subject, content);
//    }
//
//    @Deprecated
//    public static void sendMail(String to, String cc, String subject, String content) {
//        System.setProperty("mail.mime.charset", "UTF-8");
//        MimeMessage mailMessage = mailSender.createMimeMessage();
//        try {
//            MimeMessageHelper messageHelper = new MimeMessageHelper(mailMessage, true, "utf-8");
//            messageHelper.setFrom(from);
//            if (Env.isDaily() || Env.isPre()) {
//                subject = "[日常测试]" + subject;
//                content = getOriginalUserInfo(to, cc) + content;
//                to = rdRecipients;
//                cc = null;
//            }
//            messageHelper.setTo(to.split(","));
//            if (cc != null) {
//                messageHelper.setCc(cc);
//            }
//            messageHelper.setSubject(subject);
//            messageHelper.setText(content, true);
//            mailSender.send(mailMessage);
//        } catch (Exception e) {
//            RogerLogger.error("sendMail error, msg=" + e.getMessage(), e);
//        }
//    }
//
//    private static String getOriginalUserInfo(String to, String cc) {
//        StringBuilder sb = new StringBuilder();
//        sb.append("<div>本应发往To：").append(to);
//        if (StringUtils.isNotBlank(cc)) {
//            sb.append("，Cc：").append(cc);
//        }
//        sb.append(" </div>");
//        return sb.toString();
//    }

}
