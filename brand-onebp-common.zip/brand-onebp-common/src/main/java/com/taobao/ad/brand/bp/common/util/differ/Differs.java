package com.taobao.ad.brand.bp.common.util.differ;


import com.google.common.base.Joiner;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import org.apache.commons.collections4.CollectionUtils;

/**
 * @author ximu.cly
 * @date 2020/6/4
 */
public class Differs {
    public static final String SPLITTER = "^";
    public static final String SPLITTER_REG = "\\^";
    public static final Joiner ON = Joiner.on(SPLITTER);

    /**
     * 获取在left但不在right中的元素
     * @param left
     * @param right
     * @param differKey
     * @param <T>
     * @return
     */
    public static <T> List<T> differ(List<T> left, List<T> right, DifferKeyGenerator<T> differKey) {
        if(right == null || right.isEmpty()) {
            return left;
        }

        List<T> result = new ArrayList<>();
        if(left == null || left.isEmpty()) {
            return result;
        }

        for (T l : left) {
            String lKey = differKey.gen(l);
            boolean exists = false;
            for (T r : right) {
                String rKey = differKey.gen(r);
                if (Objects.equals(lKey, rKey)) {
                    exists = true;
                    break;
                }
            }
            if (!exists) {
                result.add(l);
            }
        }

        return result;
    }

    /**
     * 获取left和right差集元素
     * @param left
     * @param right
     * @param differKey
     * @return
     * @param <T>
     */
    public static <T> List<T> diff(List<T> left, List<T> right, DifferKeyGenerator<T> differKey) {
        if (right == null || right.isEmpty()) {
            return left;
        }
        if (left == null || left.isEmpty()) {
            return right;
        }
        List<T> allElements = new ArrayList<>(left);
        allElements.addAll(right);
        List<T> result = new ArrayList<>();
        Map<String, Integer> leftKeyMap = left.stream().collect(Collectors.toMap(differKey::gen, e -> 1, Integer::sum));
        Map<String, Integer> rightKeyMap = right.stream().collect(Collectors.toMap(differKey::gen, e -> 1, Integer::sum));
        for (T e : allElements) {
            String key = differKey.gen(e);
            int leftKey = leftKeyMap.getOrDefault(key, 0);
            int rightKey = rightKeyMap.getOrDefault(key, 0);
            if (Math.abs(leftKey - rightKey) > 0) {
                result.add(e);
            }
        }
        return result;
    }
}