package com.taobao.ad.brand.bp.common.util;


import com.google.common.collect.Lists;
import org.apache.commons.collections4.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class DiffUtil {

    /**
     * 交集
     * @param left
     * @param right
     * @param differKey
     * @param <T>
     * @return
     */
    public static <T> List<T> differ(List<T> left, List<T> right, DifferKeyGenerator<T> differKey) {
        if(right == null || right.isEmpty()) {
            return left;
        }

        List<T> result = new ArrayList<>();
        if(left == null || left.isEmpty()) {
            return result;
        }

        for (T l : left) {
            String lKey = differKey.gen(l);
            boolean exists = false;
            for (T r : right) {
                String rKey = differKey.gen(r);
                if (Objects.equals(lKey, rKey)) {
                    exists = true;
                    break;
                }
            }
            if (!exists) {
                result.add(l);
            }
        }

        return result;
    }
    public static <T> List<T> getDiff(List<T> left, List<T> right){
        
        List<T> diffIds = new ArrayList<>(CollectionUtils.disjunction(left, right));
        return diffIds;
    }

}
