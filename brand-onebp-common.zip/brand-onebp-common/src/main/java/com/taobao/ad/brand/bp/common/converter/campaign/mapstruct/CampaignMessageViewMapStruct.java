package com.taobao.ad.brand.bp.common.converter.campaign.mapstruct;

import com.taobao.ad.brand.bp.client.dto.campaign.CampaignDealMsgViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignDealNoticeViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/23
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface CampaignMessageViewMapStruct extends BaseMapStructMapper<CampaignDealNoticeViewDTO, CampaignDealMsgViewDTO> {

    CampaignMessageViewMapStruct INSTANCE = Mappers.getMapper(CampaignMessageViewMapStruct.class);
}