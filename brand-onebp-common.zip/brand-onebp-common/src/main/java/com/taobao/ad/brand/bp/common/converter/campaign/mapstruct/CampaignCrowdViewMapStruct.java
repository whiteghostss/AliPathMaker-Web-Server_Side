package com.taobao.ad.brand.bp.common.converter.campaign.mapstruct;

import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdViewDTO;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.control.DeepClone;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * Description:ViewDTO到ViewDTO转换
 * <p>
 * date: 2023/3/1 1:23 PM
 *
 * @author shiyan
 * @version 1.0
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, mappingControl=DeepClone.class)
public interface CampaignCrowdViewMapStruct {

    CampaignCrowdViewMapStruct INSTANCE = Mappers.getMapper(CampaignCrowdViewMapStruct.class);

    CampaignCrowdViewDTO copySelf(CampaignCrowdViewDTO source);
    List<CampaignCrowdViewDTO> copySelf(List<CampaignCrowdViewDTO> sourceList);
}
