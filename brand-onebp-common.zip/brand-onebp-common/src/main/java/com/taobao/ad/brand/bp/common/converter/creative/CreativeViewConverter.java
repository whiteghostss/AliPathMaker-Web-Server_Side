package com.taobao.ad.brand.bp.common.converter.creative;

import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativePageViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import com.taobao.ad.brand.bp.common.converter.creative.mapstruct.CreativeViewMapStruct;
import org.springframework.stereotype.Component;

/**
 * @author shiyan
 * @date 2024/1/8
 */
@Component
public class CreativeViewConverter extends BaseViewDTOConverter<CreativeViewDTO, CreativePageViewDTO> {

    @Override
    public BaseMapStructMapper<CreativeViewDTO, CreativePageViewDTO> getBaseMapStructMapper() {
        return CreativeViewMapStruct.INSTANCE;
    }
}
