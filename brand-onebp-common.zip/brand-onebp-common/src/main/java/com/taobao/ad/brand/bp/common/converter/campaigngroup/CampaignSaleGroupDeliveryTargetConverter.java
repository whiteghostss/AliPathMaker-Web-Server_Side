package com.taobao.ad.brand.bp.common.converter.campaigngroup;

import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupDeliveryTargetViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignSaleGroupDeliveryTargetViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import com.taobao.ad.brand.bp.common.converter.campaigngroup.mapstruct.CampaignSaleGroupDeliveryTargetMapStruct;
import org.springframework.stereotype.Component;

@Component
public class CampaignSaleGroupDeliveryTargetConverter extends BaseViewDTOConverter<CampaignSaleGroupDeliveryTargetViewDTO, SaleGroupDeliveryTargetViewDTO> {
    @Override
    public BaseMapStructMapper<CampaignSaleGroupDeliveryTargetViewDTO, SaleGroupDeliveryTargetViewDTO> getBaseMapStructMapper() {
        return CampaignSaleGroupDeliveryTargetMapStruct.INSTANCE;
    }

}
