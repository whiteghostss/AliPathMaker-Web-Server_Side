package com.taobao.ad.brand.bp.common.constant.talent;

public class TalentMediaReportConstant {

    public static final String TALENT_USER_ID = "talentUserId";

    public static final String NEW_CUST_ACTION_UV = "newCustActionUv";

    public static final String PVS_UV = "pvsUv";

    public static final String CART_UV = "cartUv";

    public static final String COL_UV = "colUv";

    public static final String ALIPAY_UV = "alipayUv";

    public static final String CVR = "cvr";



}
