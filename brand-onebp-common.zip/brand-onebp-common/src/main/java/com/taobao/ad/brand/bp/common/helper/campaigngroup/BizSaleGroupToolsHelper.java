package com.taobao.ad.brand.bp.common.helper.campaigngroup;

import com.alibaba.ad.brand.dto.campaign.price.DayPriceViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleGroupSourceEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupAuditStatusEnum;
import com.alibaba.ad.nb.ssp.constant.newproduct.DeliveryTargetEnum;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupPageViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourceDistributionRuleViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.SaleGroupGoalSceneEnum;
import org.apache.commons.collections4.CollectionUtils;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author yanjingang
 * @date 2024/3/14
 */
public class BizSaleGroupToolsHelper {

    public static List<String> getSaleGroupNames(List<ResourcePackageSaleGroupViewDTO> saleGroupViewDTOList, List<Long> saleGroupIds) {
        if (CollectionUtils.isEmpty(saleGroupIds)) {
            return Lists.newArrayList();
        }
        Map<Long, ResourcePackageSaleGroupViewDTO> saleGroupViewDTOMap = saleGroupViewDTOList.stream().collect(Collectors.toMap(ResourcePackageSaleGroupViewDTO::getId, Function.identity()));
        return saleGroupIds.stream().map(saleGroupId -> {
            if (saleGroupViewDTOMap.containsKey(saleGroupId)) {
                return saleGroupViewDTOMap.get(saleGroupId).getName();
            }
            return String.valueOf(saleGroupId);
        }).collect(Collectors.toList());
    }

    /**
     * 获取售卖中心的分组
     *
     * @param campaignGroupViewDTO
     * @param saleGroupIds
     * @return
     */
    public static List<Long> getSalePlatformSaleGroupIds(CampaignGroupViewDTO campaignGroupViewDTO, List<Long> saleGroupIds) {
        Map<Long, Integer> saleGroupSourceMap = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList()
                .stream().collect(Collectors.toMap(SaleGroupInfoViewDTO::getSaleGroupId, SaleGroupInfoViewDTO::getSource));
        return saleGroupIds.stream()
                .filter(saleGroupId -> BrandSaleGroupSourceEnum.SALE_PLATFORM.getCode().equals(saleGroupSourceMap.get(saleGroupId)))
                .collect(Collectors.toList());
    }

    /**
     * 获取分组预估状态
     * @param campaignGroupSaleGroupPageViewDTO
     * @return
     */
    public static Integer getAlgoEstimateStatus(CampaignGroupSaleGroupPageViewDTO campaignGroupSaleGroupPageViewDTO){
        if (null != campaignGroupSaleGroupPageViewDTO.getEstimateResult()){
            return BrandBoolEnum.BRAND_TRUE.getCode();
        }
        return BrandBoolEnum.BRAND_FALSE.getCode();
    }

    /**
     * 获取分组预估状态
     * @param saleGroupInfoViewDTO
     * @return
     */
    public static Integer getAlgoEstimateStatus(SaleGroupInfoViewDTO saleGroupInfoViewDTO){
        if (saleGroupInfoViewDTO.getBudget() == 0) {
            return null;
        }
        if (null != saleGroupInfoViewDTO.getSaleGroupEstimateInfoViewDTO()){
            return BrandBoolEnum.BRAND_TRUE.getCode();
        }
        return BrandBoolEnum.BRAND_FALSE.getCode();

    }

    /**
     * 获取订单分组交付场景
     * @param deliveryTargetList
     * @param optimizeTargetList
     * @return
     */
    public static Integer getGoalScene(List<Integer> deliveryTargetList,List<Integer> optimizeTargetList){
        if (CollectionUtils.isNotEmpty(deliveryTargetList)){
            if (deliveryTargetList.contains(DeliveryTargetEnum.N_REACH.getValue())){
                return SaleGroupGoalSceneEnum.N_REACH.getValue();
            }else{
                return SaleGroupGoalSceneEnum.NO_REACH.getValue();
            }
        }else if(CollectionUtils.isNotEmpty(optimizeTargetList)){
            return SaleGroupGoalSceneEnum.OPTIMIZE_TARGET.getValue();
        }
        return SaleGroupGoalSceneEnum.NORMAL.getValue();
    }

    public static Map<Long, List<DayPriceViewDTO>> getProductDayPriceViewDTOMap(ResourcePackageSaleGroupViewDTO saleGroupViewDTO) {
        Map<Long, List<DayPriceViewDTO>> productDayPriceViewDTOMap = Maps.newHashMap();
        for (ResourceDistributionRuleViewDTO ruleViewDTO : saleGroupViewDTO.getDistributionRuleList()) {
            for (ResourcePackageProductViewDTO resourcePackageProductViewDTO : ruleViewDTO.getResourcePackageProductList()) {
                List<DayPriceViewDTO> dayPriceViewDTOList = resourcePackageProductViewDTO.getBandPriceList().stream().map(v -> {
                    DayPriceViewDTO dayPriceViewDTO = new DayPriceViewDTO();
                    dayPriceViewDTO.setStartDate(v.getStartDate());
                    dayPriceViewDTO.setEndDate(v.getEndDate());
                    dayPriceViewDTO.setPrice(v.getPrice());
                    dayPriceViewDTO.setDiscountRatio(v.getPriceRatio());
                    return dayPriceViewDTO;
                }).collect(Collectors.toList());
                productDayPriceViewDTOMap.put(resourcePackageProductViewDTO.getId(), dayPriceViewDTOList);
            }
        }
        return productDayPriceViewDTOMap;
    }

    /**
     * 是否是百灵申请的补配分组
     *
     * @param saleGroup
     * @param dbSaleGroupMap 订单下的分组
     * @return
     */
    public static boolean isBpApplyBoostGiveSaleGroup(CampaignGroupSaleGroupPageViewDTO saleGroup, Map<Long, SaleGroupInfoViewDTO> dbSaleGroupMap) {
        return dbSaleGroupMap.containsKey(saleGroup.getMainGroupId())
                && Objects.nonNull(Optional.of(Optional.ofNullable(dbSaleGroupMap.get(saleGroup.getMainGroupId()).getBoostGiveApplyInfoList()).orElse(Lists.newArrayList()).stream()
                .filter(x -> saleGroup.getSaleGroupId().equals(x.getSaleGroupId())).findFirst()).get().orElse(null));
    }

    /**
     * 是否非审批中的补配分组
     *
     * @param saleGroup
     * @return
     */
    public static boolean boostGiveSaleGroupIsNotAuditIng(CampaignGroupSaleGroupPageViewDTO saleGroup) {
        return (BrandSaleTypeEnum.BOOST.getCode().equals(saleGroup.getSaleType()) || BrandSaleTypeEnum.PRESENT.getCode().equals(saleGroup.getSaleType()))
                && !Lists.newArrayList(SaleGroupAuditStatusEnum.WAIT_AUDIT.getValue(), SaleGroupAuditStatusEnum.AUDIT_ING.getValue()).contains(saleGroup.getProcessAuditInfo().getAuditStatus());
    }
}
