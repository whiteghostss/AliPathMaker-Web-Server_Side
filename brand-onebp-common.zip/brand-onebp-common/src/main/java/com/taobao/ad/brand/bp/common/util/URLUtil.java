package com.taobao.ad.brand.bp.common.util;

import com.alibaba.security.util.UrlUtil;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import org.apache.commons.lang3.StringUtils;

import java.net.*;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * url处理工具类
 */
public class URLUtil {
    public static String parseLandingFromDp(String url) {
        Map<String, String> result = parseUrlParam(url);
        if (result.isEmpty()) {
            return null;
        }
        String h5Url = result.get("h5Url");
        if (StringUtils.isBlank(h5Url)) {
            return null;
        }
        Map<String, String> h5urlParam = null;
        try {
            h5urlParam = parseUrlParam(URLDecoder.decode(h5Url, "UTF-8"));
        } catch (Exception e) {
            return null;
        }
        String u = h5urlParam.get("u");
        if (u == null) {
            return null;
        }
        try {
            return URLDecoder.decode(u, "UTF-8");
        } catch (Exception e) {
            return null;
        }
    }

    public static String parseLandingFromH5(String url) {
        Map<String, String> h5urlParam = parseUrlParam(url);
        if (h5urlParam.isEmpty()) {
            return null;
        }
        String u = h5urlParam.get("u");
        if (u == null) {
            return null;
        }
        try {
            return URLDecoder.decode(u, "UTF-8");
        } catch (Exception e) {
            return null;
        }
    }

    public static Map<String, String> parseUrlParam(String url) {
        Map<String, String> result = new HashMap<>();
        if (StringUtils.isBlank(url) || !url.contains("&")) {
            return result;
        }

        for (String pair : url.split("&")) {
            if (!pair.contains("=")) {
                continue;
            }
            String[] kv = pair.split("=");
            if (kv.length == 2) {
                result.put(kv[0], kv[1]);
            }
        }
        return result;
    }

    public static String rewriteHttps(String url) {
        if (url == null) {
            return url;
        }
        if (url.startsWith("http:")) {
            return url.replaceFirst("http:", "https:");
        }
        return url;
    }

    public static String getUrlFullDomain(String url){
        try {
            return UrlUtil.getHost(url);
        } catch (URISyntaxException e) {
            return "";
        }
    }
    /**
     * 获取顶级域名中的域 “名”
     * www.alimama.com -> alimama
     * */
    public static String getTopDomainName(String url){
        String domain = getTopDomain(url);
        if (StringUtils.isNotBlank(domain)){

            return domain.split("\\.")[0];
        }
        return "";

    }


    public static String getTopDomain(String uriString){
        if (StringUtils.isBlank(uriString)){
            return "";
        }
        if  (!uriString.startsWith("http://") && !uriString.startsWith("https://")){
            uriString = "https://"+uriString;
        }
        try{
            //获取值转换为小写
            String host = new URL(uriString).getHost().toLowerCase();//news.hexun.com
            Pattern pattern = Pattern.compile("[^\\.]+(\\.com\\.cn|\\.net\\.cn|\\.org\\.cn|\\.gov\\.cn|\\.com|\\.net|\\.cn|\\.org|\\.cc|\\.me|\\.tel|\\.mobi|\\.asia|\\.biz|\\.info|\\.name|\\.tv|\\.hk|\\.公司|\\.中国|\\.网络)");
            Matcher matcher = pattern.matcher(host);
            while(matcher.find()){
                return matcher.group();
            }
        }catch(Exception e){
            RogerLogger.error("getTopDomain error:"+uriString, e);
            return "";
        }
        return "";
    }


    /**
     * 获取url协议scheme
     * @param url
     * @return
     */
    public static String getUrlScheme(String url){
        return UrlUtil.getScheme(url);
    }

    /**
     * domain不带http或者https
     * 转化为lowerCase
     **/
    public static String getUrlOtherPart(String url){
        String fullDomain = getUrlFullDomain(url);
        String startWith = "";
        if (url.startsWith("https://")){
            startWith = "https//";
        }else if(url.startsWith("http://")){
            startWith = "http://";
        }
        fullDomain = startWith + fullDomain;
        String  urlOtherPart = "";
        if (url.length() > fullDomain.length()){
            urlOtherPart = url.substring(fullDomain.length(), url.length());
        }
        return urlOtherPart.toLowerCase();
    }

    /**
     * decode花括号
     * %7B、%7b -> {
     * %7D、%7d -> }
     */
    public static String decodeBraces(String url) {
        if (url == null) {
            return null;
        }
        return url.replaceAll("%7B", "{")
                .replaceAll("%7b", "{")
                .replaceAll("%7D", "}")
                .replaceAll("%7d", "}");
    }

    /**
     * 是否是h5落地页
     * 转化为lowerCase
     **/
    public static boolean isH5Selef(String url){
        if (url.startsWith("https://")){
            return true;
        }else if(url.startsWith("http://")){
            return true;
        }else{
            return false;
        }
    }
}
