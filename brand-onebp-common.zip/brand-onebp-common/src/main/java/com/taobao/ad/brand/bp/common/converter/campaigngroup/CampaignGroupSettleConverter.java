package com.taobao.ad.brand.bp.common.converter.campaigngroup;

import com.alibaba.ad.biz.definition.constants.UniversalCampaignType;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.realsettle.RealSettleInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignProgrammaticEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignRegisterUnitEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.client.dto.campaign.settle.CampaignSettleBaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.settle.CampaignSettleViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.settle.SaleGroupSettleTempViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupSettleInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSettleInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignGroupSettleQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import com.taobao.ad.brand.bp.common.converter.campaigngroup.mapstruct.CampaignGroupSettleMapStruct;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author yanjingang
 * @date 2023/02/25
 */
@Component
public class CampaignGroupSettleConverter extends BaseViewDTOConverter<RealSettleInfoViewDTO, CampaignGroupSaleGroupSettleInfoViewDTO> {

    @Override
    public BaseMapStructMapper<RealSettleInfoViewDTO, CampaignGroupSaleGroupSettleInfoViewDTO> getBaseMapStructMapper() {
        return CampaignGroupSettleMapStruct.INSTANCE;
    }


    public CampaignGroupSettleInfoViewDTO convertRealSettleViewDTOFromCampaignGroup(CampaignGroupViewDTO campaignGroupViewDTO, List<ResourcePackageSaleGroupViewDTO> saleGroupList) {
        List<RealSettleInfoViewDTO> realSettleInfoViewDTOList = campaignGroupViewDTO.getCampaignGroupRealSettleViewDTO().getRealSettleInfoViewDTOList();
        List<CampaignGroupSaleGroupSettleInfoViewDTO> saleGroupSettleInfoViewDTOList = CampaignGroupSettleMapStruct.INSTANCE.sourceToTarget(realSettleInfoViewDTOList);
        return buildCampaignGroupSettleInfo(campaignGroupViewDTO, saleGroupSettleInfoViewDTOList, saleGroupList);
    }

    public CampaignGroupSettleInfoViewDTO buildCampaignGroupSettleInfo(CampaignGroupViewDTO campaignGroupViewDTO,
                                                                       List<CampaignGroupSaleGroupSettleInfoViewDTO> campaignGroupSaleGroupSettleInfoViewDTOList,
                                                                       List<ResourcePackageSaleGroupViewDTO> saleGroupList) {
        CampaignGroupSettleInfoViewDTO campaignGroupSettleInfoViewDTO = new CampaignGroupSettleInfoViewDTO();
        campaignGroupSettleInfoViewDTO.setId(campaignGroupViewDTO.getId());
        campaignGroupSettleInfoViewDTO.setStatus(campaignGroupViewDTO.getStatus());
        campaignGroupSettleInfoViewDTO.setMemberId(campaignGroupViewDTO.getMemberId());
        if (campaignGroupViewDTO.getCampaignGroupContractViewDTO() != null) {
            campaignGroupSettleInfoViewDTO.setContractId(campaignGroupViewDTO.getCampaignGroupContractViewDTO().getContractId());
        }
        if (campaignGroupViewDTO.getCampaignGroupRealSettleViewDTO() != null) {
            campaignGroupSettleInfoViewDTO.setRealSettleProcessStatus(campaignGroupViewDTO.getCampaignGroupRealSettleViewDTO().getRealSettleProcessStatus());
        }
        Map<Long, ResourcePackageSaleGroupViewDTO> resourceSaleGroupMap;
        if (CollectionUtils.isNotEmpty(saleGroupList)) {
            resourceSaleGroupMap = saleGroupList.stream().collect(Collectors.toMap(ResourcePackageSaleGroupViewDTO::getId, Function.identity()));
        } else {
            resourceSaleGroupMap = Maps.newHashMap();
        }
        Map<Long, SaleGroupInfoViewDTO> campaignGroupSaleGroupMap = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream()
                .collect(Collectors.toMap(SaleGroupInfoViewDTO::getSaleGroupId, Function.identity()));

        campaignGroupSaleGroupSettleInfoViewDTOList.forEach(t -> {
            if (resourceSaleGroupMap.containsKey(t.getSaleGroupId())) {
                t.setSaleGroupName(resourceSaleGroupMap.get(t.getSaleGroupId()).getName());
            }
            if (campaignGroupSaleGroupMap.containsKey(t.getSaleGroupId())) {
                SaleGroupInfoViewDTO campaignGroupSaleGroup = campaignGroupSaleGroupMap.get(t.getSaleGroupId());
                t.setSaleProductLine(campaignGroupSaleGroup.getSaleProductLine());
                t.setSaleBusinessLine(campaignGroupSaleGroup.getSaleBusinessLine());
            }
        });

        // 实结信息
        campaignGroupSettleInfoViewDTO.setSaleGroupSettleInfoViewDTOList(campaignGroupSaleGroupSettleInfoViewDTOList);

        return campaignGroupSettleInfoViewDTO;
    }

    /**
     * 转换结算数据结构
     *
     * @param campaignGroupViewDTO
     * @param campaignList
     * @param campaignSettleViewDTOList
     * @return
     */
    public List<CampaignGroupSaleGroupSettleInfoViewDTO> convertRealSettleViewDTOFromSettle(CampaignGroupViewDTO campaignGroupViewDTO,
                                                                                            List<CampaignViewDTO> campaignList,
                                                                                            List<CampaignSettleViewDTO> campaignSettleViewDTOList) {
        // 补全计划基本信息
        fillCampaignInfoInSettleViewDTO(campaignList, campaignSettleViewDTOList);
        // 计划维度汇总，key: saleGroupId
        Map<Long, List<CampaignSettleViewDTO>> campaignSettleMap = campaignSettleViewDTOList.stream().collect(Collectors.groupingBy(CampaignSettleViewDTO::getSaleGroupId));
        // 本期先不考虑此场景了，因为业务尚未明确规则 汇总结算维度【分组 x 结算单位 x 是否系统投放】维度
        // List<SaleGroupSettleViewDTO> groupSettleViewDTOList = groupSettle2SplitSaleGroupSettleViewDTOList(campaignGroupViewDTO, campaignSettleViewDTOList);
        // 进一步汇总到分组维度
        List<SaleGroupSettleTempViewDTO> saleGroupSettleTempViewDTOList = collectSettle2SaleGroupSettleViewDTOList(campaignGroupViewDTO, campaignSettleMap);
        // 汇总最终的实结信息
        List<CampaignGroupSaleGroupSettleInfoViewDTO> realSettleInfoViewDTOList = collectAndComputeSettleInfo(saleGroupSettleTempViewDTOList, campaignSettleViewDTOList);

        return realSettleInfoViewDTOList;
    }

    private List<CampaignGroupSaleGroupSettleInfoViewDTO> collectAndComputeSettleInfo(List<SaleGroupSettleTempViewDTO> saleGroupSettleTempViewDTOList, List<CampaignSettleViewDTO> campaignSettleViewDTOList) {
        List<CampaignGroupSaleGroupSettleInfoViewDTO> realSettleInfoViewDTOList = Lists.newArrayList();
        Map<Long, CampaignSettleViewDTO> campaignInfoMap = campaignSettleViewDTOList.stream().collect(Collectors.toMap(CampaignSettleViewDTO::getCampaignId, Function.identity()));
        // 构建补量分组和主分组的映射
        Map<Long, Long> saleGroupBoost2MainMap = campaignSettleViewDTOList.stream()
                .filter(t -> BrandSaleTypeEnum.BOOST.getCode().equals(t.getSaleType()))
                .collect(Collectors.toMap(CampaignSettleViewDTO::getSaleGroupId, t -> campaignInfoMap.get(t.getSourceCampaignId()).getSaleGroupId(), (a1, a2) -> a1));
        // 构建主分组和补量分组的映射
        Map<Long, List<Long>> saleGroupMain2BoostMap = Maps.newHashMap();
        saleGroupBoost2MainMap.forEach((boostSaleGroupId, mainSaleGroupId) -> {
            saleGroupMain2BoostMap.computeIfAbsent(mainSaleGroupId, k -> new ArrayList<>()).add(boostSaleGroupId);
        });

        Map<Long, SaleGroupSettleTempViewDTO> saleGroupSettleMap = saleGroupSettleTempViewDTOList.stream().collect(Collectors.toMap(SaleGroupSettleTempViewDTO::getSaleGroupId, Function.identity()));
        for (SaleGroupSettleTempViewDTO saleGroupSettleTempViewDTO : saleGroupSettleTempViewDTOList) {
            // 查找补量
            List<SaleGroupSettleTempViewDTO> boostSaleGroupSettleList = Lists.newArrayList();
            if (saleGroupMain2BoostMap.containsKey(saleGroupSettleTempViewDTO.getSaleGroupId())) {
                boostSaleGroupSettleList = saleGroupMain2BoostMap.get(saleGroupSettleTempViewDTO.getSaleGroupId()).stream().map(saleGroupSettleMap::get).collect(Collectors.toList());
            }
            // 构建并最终的实结信息
            realSettleInfoViewDTOList.add(convertRealSettleInfoViewDTO(saleGroupSettleTempViewDTO, boostSaleGroupSettleList));
        }

        return realSettleInfoViewDTOList;
    }

    /**
     * 转换最终实结数据
     * 分组金额：
     * 主：主
     * 补：0
     * 赠：0
     *
     * 计收金额：
     * 主：主+补
     * 补：补
     * 赠：0
     *
     * 实际历史曝光：
     * 主：主+补
     * 补：补
     * 赠：0
     *
     * 实际流量金额：
     * 主：（主+补）实际曝光 * CPM平均单价
     * 补：0
     * 赠：0
     *
     * @param saleGroupSettleTempViewDTO
     * @param boostSaleGroupSettleList
     * @return
     */
    private CampaignGroupSaleGroupSettleInfoViewDTO convertRealSettleInfoViewDTO(SaleGroupSettleTempViewDTO saleGroupSettleTempViewDTO, List<SaleGroupSettleTempViewDTO> boostSaleGroupSettleList) {
        // 基本信息
        CampaignGroupSaleGroupSettleInfoViewDTO realSettleInfoViewDTO = convertSettleTemp2RealSettleViewDTO(saleGroupSettleTempViewDTO);
        // 结算信息
        if (BrandSaleTypeEnum.BUY.getCode().equals(saleGroupSettleTempViewDTO.getSaleType())) {
            // 合并补量结算信息
            mergeBoostSaleGroupSettleInfo(saleGroupSettleTempViewDTO, boostSaleGroupSettleList);
            // 设置结算信息
            realSettleInfoViewDTO.setIncomePrice(saleGroupSettleTempViewDTO.getIncomePrice());
            realSettleInfoViewDTO.setRealCastPrice(saleGroupSettleTempViewDTO.getRealCastPrice());
            // 计算最终实结金额
            Long realSettlePrice = calculateRealSettlePrice(saleGroupSettleTempViewDTO);
            realSettleInfoViewDTO.setRealSettlePrice(realSettlePrice);
        } else if (BrandSaleTypeEnum.BOOST.getCode().equals(saleGroupSettleTempViewDTO.getSaleType())) {
            realSettleInfoViewDTO.setBudget(0L);
            realSettleInfoViewDTO.setIncomePrice(saleGroupSettleTempViewDTO.getIncomePrice());
            realSettleInfoViewDTO.setRealCastPrice(saleGroupSettleTempViewDTO.getRealCastPrice());
            realSettleInfoViewDTO.setRealSettlePrice(0L);
        } else if (BrandSaleTypeEnum.PRESENT.getCode().equals(saleGroupSettleTempViewDTO.getSaleType())) {
            realSettleInfoViewDTO.setBudget(0L);
            realSettleInfoViewDTO.setIncomePrice(0L);
            realSettleInfoViewDTO.setRealCastPrice(0L);
            realSettleInfoViewDTO.setRealSettlePrice(0L);
        }

        return realSettleInfoViewDTO;
    }

    private CampaignGroupSaleGroupSettleInfoViewDTO convertSettleTemp2RealSettleViewDTO(SaleGroupSettleTempViewDTO settleTempViewDTO) {
        CampaignGroupSaleGroupSettleInfoViewDTO campaignGroupSettleInfoViewDTO = new CampaignGroupSaleGroupSettleInfoViewDTO();
        campaignGroupSettleInfoViewDTO.setSaleGroupId(settleTempViewDTO.getSaleGroupId());
        campaignGroupSettleInfoViewDTO.setSubContractId(settleTempViewDTO.getSubContractId());
//        campaignGroupSettleInfoViewDTO.setContractFlag(settleTempViewDTO.getContractFlag());
        campaignGroupSettleInfoViewDTO.setBudget(settleTempViewDTO.getBudget());
        campaignGroupSettleInfoViewDTO.setSaleType(settleTempViewDTO.getSaleType());
        campaignGroupSettleInfoViewDTO.setSource(settleTempViewDTO.getSource());
        campaignGroupSettleInfoViewDTO.setSaleProductLine(settleTempViewDTO.getSaleProductLine());
        return campaignGroupSettleInfoViewDTO;
    }

    private Long calculateRealSettlePrice(SaleGroupSettleTempViewDTO saleGroupSettleTempViewDTO) {
        return new BigDecimal(saleGroupSettleTempViewDTO.getHistCastNum())
                .multiply(new BigDecimal(Optional.ofNullable(saleGroupSettleTempViewDTO.getUnitPrice()).orElse(0L)))
                .divide(new BigDecimal(1000), 0, RoundingMode.HALF_UP)
                .longValue();
    }

    private void mergeBoostSaleGroupSettleInfo(SaleGroupSettleTempViewDTO saleGroupSettleTempViewDTO, List<SaleGroupSettleTempViewDTO> boostSaleGroupSettleList) {
        if (CollectionUtils.isEmpty(boostSaleGroupSettleList)) {
            return;
        }
        // 汇总计收数据(主+补)
        Long boostIncomePrice = 0L;
        Long boostHistCastNum = 0L;
        Long boostRealCastPrice = 0L;
        for (SaleGroupSettleTempViewDTO boostSettleViewDTO : boostSaleGroupSettleList) {
            boostIncomePrice += boostSettleViewDTO.getIncomePrice();
            boostHistCastNum += boostSettleViewDTO.getHistCastNum();
            boostRealCastPrice += boostSettleViewDTO.getRealCastPrice();
        }
        saleGroupSettleTempViewDTO.setIncomePrice(Optional.of(saleGroupSettleTempViewDTO.getIncomePrice()).orElse(0L) + boostIncomePrice);
        saleGroupSettleTempViewDTO.setHistCastNum(Optional.of(saleGroupSettleTempViewDTO.getHistCastNum()).orElse(0L) + boostHistCastNum);
        saleGroupSettleTempViewDTO.setRealCastPrice(Optional.of(saleGroupSettleTempViewDTO.getRealCastPrice()).orElse(0L) + boostRealCastPrice);
    }

//    /**
//     * 汇总到分组 x 结算单位 x 是否系统投放 维度
//     *
//     * @param campaignGroupViewDTO
//     * @param campaignSettleViewDTOList
//     * @return
//     */
//    private List<SaleGroupSettleViewDTO> groupSettle2SplitSaleGroupSettleViewDTOList(CampaignGroupViewDTO campaignGroupViewDTO, List<CampaignSettleViewDTO> campaignSettleViewDTOList) {
//        List<SaleGroupSettleViewDTO> saleGroupSettleViewDTOList = Lists.newArrayList();
//        // key: saleGroupId
//        Map<Long, List<CampaignSettleViewDTO>> campaignSettleMap = campaignSettleViewDTOList.stream().collect(Collectors.groupingBy(CampaignSettleViewDTO::getSaleGroupId));
//        for (SaleGroupInfoViewDTO saleGroupInfoViewDTO : campaignGroupViewDTO.getGroupSaleViewDTO().getSaleGroupInfoViewDTOList()) {
//            // 分组下的计划结算信息
//            List<CampaignSettleViewDTO> saleGroupCampaignSettleList = campaignSettleMap.getOrDefault(saleGroupInfoViewDTO.getSaleGroupId(), Lists.newArrayList());
//            Map<String, List<CampaignSettleViewDTO>> saleGroupCampaignSettleMap = saleGroupCampaignSettleList.stream()
//                .collect(Collectors.groupingBy(t -> JoinerUtil.JOINER.join(t.getSaleGroupId(), t.getSettleRegisterUnit(), t.getSspProgrammatic())));
//            saleGroupCampaignSettleMap.forEach((key, campaignSettleList) -> {
//                // 设置分组维度基本信息
//                SaleGroupSettleViewDTO saleGroupSettleViewDTO = convertSaleGroupSettleBaseInfo(saleGroupInfoViewDTO);
//                // 设置split主key
//                CampaignSettleViewDTO campaignSettleViewDTO = campaignSettleList.get(0);
//                saleGroupSettleViewDTO.setSaleGroupId(campaignSettleViewDTO.getSaleGroupId());
//                saleGroupSettleViewDTO.setSettleRegisterUnit(campaignSettleViewDTO.getSettleRegisterUnit());
//                saleGroupSettleViewDTO.setSspProgrammatic(campaignSettleViewDTO.getSspProgrammatic());
//                // 设置结算信息
//                groupCampaignSettle2SaleGroupInfo(saleGroupSettleViewDTO, campaignSettleList);
//                // 添加返回
//                saleGroupSettleViewDTOList.add(saleGroupSettleViewDTO);
//            });
//        }
//
//        return saleGroupSettleViewDTOList;
//    }

    /**
     * 汇总到分组维度
     *
     * @param campaignGroupViewDTO
     * @param campaignSettleMap
     * @return
     */
    private List<SaleGroupSettleTempViewDTO> collectSettle2SaleGroupSettleViewDTOList(CampaignGroupViewDTO campaignGroupViewDTO, Map<Long, List<CampaignSettleViewDTO>> campaignSettleMap) {
        List<SaleGroupSettleTempViewDTO> saleGroupSettleTempViewDTOList = Lists.newArrayList();
        for (SaleGroupInfoViewDTO saleGroupInfoViewDTO : campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList()) {
            // 设置分组维度基本信息
            SaleGroupSettleTempViewDTO saleGroupSettleTempViewDTO = convertSaleGroupInfo2SettleTempViewDTO(saleGroupInfoViewDTO);
            // 设置结算信息
            List<CampaignSettleViewDTO> saleGroupCampaignSettleList = campaignSettleMap.getOrDefault(saleGroupInfoViewDTO.getSaleGroupId(), Lists.newArrayList());
            collectCampaignSettle2SaleGroupInfo(saleGroupSettleTempViewDTO, saleGroupCampaignSettleList);
            // 添加返回
            saleGroupSettleTempViewDTOList.add(saleGroupSettleTempViewDTO);
        }

        return saleGroupSettleTempViewDTOList;
    }

    private SaleGroupSettleTempViewDTO convertSaleGroupInfo2SettleTempViewDTO(SaleGroupInfoViewDTO saleGroupInfoViewDTO) {
        SaleGroupSettleTempViewDTO settleTempViewDTO = new SaleGroupSettleTempViewDTO();
        settleTempViewDTO.setSaleGroupId(saleGroupInfoViewDTO.getSaleGroupId());
        settleTempViewDTO.setSubContractId(saleGroupInfoViewDTO.getSubContractId());
        settleTempViewDTO.setSaleProductLine(saleGroupInfoViewDTO.getSaleProductLine());
        settleTempViewDTO.setSaleBusinessLine(saleGroupInfoViewDTO.getSaleBusinessLine());
        settleTempViewDTO.setBudget(saleGroupInfoViewDTO.getBudget());
        settleTempViewDTO.setUnitPrice(saleGroupInfoViewDTO.getUnitPrice());
        settleTempViewDTO.setSaleType(saleGroupInfoViewDTO.getSaleType());
        settleTempViewDTO.setSource(saleGroupInfoViewDTO.getSource());
        return settleTempViewDTO;
    }

    /**
     * 汇总结算信息
     * 计划维度 -> 【分组 x 结算单位 x 是否系统投放】维度
     *
     * @param saleGroupSettleTempViewDTO
     * @param campaignSettleViewDTOList
     */
    private void collectCampaignSettle2SaleGroupInfo(SaleGroupSettleTempViewDTO saleGroupSettleTempViewDTO, List<CampaignSettleViewDTO> campaignSettleViewDTOList) {
        // 汇总计收金额
        Long totalIncomePrice = 0L;
        // 计划历史实际投放量(曝光个数)
        Long histCastNum = 0L;
        // 实际流量金额
        Long realCastPrice = 0L;
        for (CampaignSettleViewDTO campaignSettleViewDTO : campaignSettleViewDTOList) {
            totalIncomePrice += campaignSettleViewDTO.getHistAccountingAmount();
            realCastPrice += campaignSettleViewDTO.getHistCastCost();
            // 与结算约定，非系统投放的cpt，返回的该字段单位为cpt的单位，其他场景为pv
            if (campaignSettleViewDTO.getHistCastNum() != null && campaignSettleViewDTO.getHistCastNum() != 0L) {
                if (BrandCampaignProgrammaticEnum.UN_SYSTEM_CAST.getCode().equals(campaignSettleViewDTO.getSspProgrammatic())
                        && isCpt(campaignSettleViewDTO.getSspRegisterUnit())
                        && campaignSettleViewDTO.getCampaignType() != null && UniversalCampaignType.BRAND_CPD.getId() == campaignSettleViewDTO.getCampaignType()
                        && campaignSettleViewDTO.getUnitExposure() != null
                ) {
                    histCastNum += campaignSettleViewDTO.getHistCastNum() * campaignSettleViewDTO.getUnitExposure();
                } else {
                    histCastNum += campaignSettleViewDTO.getHistCastNum();
                }
            }
        }
        saleGroupSettleTempViewDTO.setIncomePrice(totalIncomePrice);
        saleGroupSettleTempViewDTO.setHistCastNum(histCastNum);
        saleGroupSettleTempViewDTO.setRealCastPrice(realCastPrice);
    }

    private void fillCampaignInfoInSettleViewDTO(List<CampaignViewDTO> campaignList, List<CampaignSettleViewDTO> campaignSettleViewDTOList) {
        Map<Long, CampaignViewDTO> campaignMap = campaignList.stream().collect(Collectors.toMap(item -> item.getId(), Function.identity()));
        campaignSettleViewDTOList.forEach(campaignSettleViewDTO -> {
            if (!campaignMap.containsKey(campaignSettleViewDTO.getCampaignId())) {
                return;
            }
            CampaignViewDTO campaignViewDTO = campaignMap.get(campaignSettleViewDTO.getCampaignId());
            campaignSettleViewDTO.setSaleGroupId(campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId());
            campaignSettleViewDTO.setSaleType(campaignViewDTO.getCampaignSaleViewDTO().getSaleType());
            campaignSettleViewDTO.setSourceCampaignId(campaignViewDTO.getCampaignBoostViewDTO().getSourceCampaignId());
            campaignSettleViewDTO.setSspProgrammatic(campaignViewDTO.getSspProgrammatic());
            campaignSettleViewDTO.setSspRegisterUnit(campaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterUnit());
            campaignSettleViewDTO.setCampaignType(campaignViewDTO.getCampaignType());
            campaignSettleViewDTO.setCampaignModel(campaignViewDTO.getCampaignModel());
            // CPT时，设置单位cpm量
            if (isCpt(campaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterUnit())
                    && campaignViewDTO.getCampaignGuaranteeViewDTO().getAmount() != null
                    && campaignViewDTO.getCampaignGuaranteeViewDTO().getCptAmount() != null
                    && campaignViewDTO.getCampaignGuaranteeViewDTO().getCptAmount() != 0L) {
                campaignSettleViewDTO.setUnitExposure((int)(campaignViewDTO.getCampaignGuaranteeViewDTO().getAmount() / campaignViewDTO.getCampaignGuaranteeViewDTO().getCptAmount()));
            }
        });
    }

    private boolean isCpt(Integer sspRegisterUnit) {
        return BrandCampaignRegisterUnitEnum.ROUND.getCode().equals(sspRegisterUnit)
                || BrandCampaignRegisterUnitEnum.DAY.getCode().equals(sspRegisterUnit);
    }

    /**
     * 转换For结算结案数据
     *
     * @param campaignGroupViewDTO
     * @param campaignList
     * @param settleQueryViewDTO
     * @return
     */
    public CampaignGroupSettleInfoViewDTO convertCampaignGroupSettleInfoViewDTO(CampaignGroupViewDTO campaignGroupViewDTO, List<CampaignViewDTO> campaignList, CampaignGroupSettleQueryViewDTO settleQueryViewDTO) {
        CampaignGroupSettleInfoViewDTO settleInfoViewDTO = new CampaignGroupSettleInfoViewDTO();
        settleInfoViewDTO.setId(campaignGroupViewDTO.getId());
        settleInfoViewDTO.setStatus(campaignGroupViewDTO.getStatus());
        settleInfoViewDTO.setMemberId(campaignGroupViewDTO.getMemberId());
        settleInfoViewDTO.setContractId(campaignGroupViewDTO.getCampaignGroupContractViewDTO().getContractId());
        // 纯赠送的子合同ID列表
        List<Long> giveSubContractIds = getOnlyGiveSubContractIds(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList(), settleQueryViewDTO);
        settleInfoViewDTO.setGiveSubContractIds(giveSubContractIds);

        Map<Long, RealSettleInfoViewDTO> dbRealSettleInfoMap = Maps.newHashMap();
        List<RealSettleInfoViewDTO> dbRealSettleInfoViewList = campaignGroupViewDTO.getCampaignGroupRealSettleViewDTO().getRealSettleInfoViewDTOList();
        if (CollectionUtils.isNotEmpty(dbRealSettleInfoViewList)) {
            dbRealSettleInfoMap = dbRealSettleInfoViewList.stream().collect(Collectors.toMap(t -> t.getGroupInfoViewDTO().getSaleGroupId(), Function.identity()));
        }
        // 实结信息
        List<CampaignGroupSaleGroupSettleInfoViewDTO> saleGroupSettleInfoViewDTOList = Lists.newArrayList();

        Map<Long, List<CampaignViewDTO>> campaignSaleGroupMap = campaignList.stream().collect(Collectors.groupingBy(t -> t.getCampaignSaleViewDTO().getSaleGroupId()));
        // 过滤掉赠送的分组
        List<SaleGroupInfoViewDTO> filterSaleGroupInfoList = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream()
                .filter(t -> !BrandSaleTypeEnum.PRESENT.getCode().equals(t.getSaleType()))
                .filter(t -> settleQueryViewDTO.getSubContractId() == null || settleQueryViewDTO.getSubContractId().equals(t.getSubContractId()))
                .collect(Collectors.toList());
        for (SaleGroupInfoViewDTO saleGroupInfoViewDTO : filterSaleGroupInfoList) {
            CampaignGroupSaleGroupSettleInfoViewDTO retSaleGroupSettleInfoViewDTO = new CampaignGroupSaleGroupSettleInfoViewDTO();
            retSaleGroupSettleInfoViewDTO.setSaleGroupId(saleGroupInfoViewDTO.getSaleGroupId());
            retSaleGroupSettleInfoViewDTO.setSaleType(saleGroupInfoViewDTO.getSaleType());
            retSaleGroupSettleInfoViewDTO.setBudget(saleGroupInfoViewDTO.getBudget());
            retSaleGroupSettleInfoViewDTO.setSubContractId(saleGroupInfoViewDTO.getSubContractId());
            retSaleGroupSettleInfoViewDTO.setSource(saleGroupInfoViewDTO.getSource());
            retSaleGroupSettleInfoViewDTO.setMainSaleGroupId(saleGroupInfoViewDTO.getMainSaleGroupId());
            // 实结金额
            if (dbRealSettleInfoMap.containsKey(saleGroupInfoViewDTO.getSaleGroupId())) {
                RealSettleInfoViewDTO dbRealSettleInfoViewDTO = dbRealSettleInfoMap.get(saleGroupInfoViewDTO.getSaleGroupId());
                retSaleGroupSettleInfoViewDTO.setIncomePrice(dbRealSettleInfoViewDTO.getIncomePrice());
                retSaleGroupSettleInfoViewDTO.setRealCastPrice(dbRealSettleInfoViewDTO.getRealCastPrice());
                retSaleGroupSettleInfoViewDTO.setRealSettlePrice(dbRealSettleInfoViewDTO.getRealSettlePrice());
            }
            // 计划列表
            List<CampaignSettleBaseViewDTO> campaignSettleList = convertCampaignSettleList(campaignSaleGroupMap.get(saleGroupInfoViewDTO.getSaleGroupId()));
            retSaleGroupSettleInfoViewDTO.setCampaignList(campaignSettleList);

            saleGroupSettleInfoViewDTOList.add(retSaleGroupSettleInfoViewDTO);
        }
        settleInfoViewDTO.setSaleGroupSettleInfoViewDTOList(saleGroupSettleInfoViewDTOList);

        return settleInfoViewDTO;
    }

    private List<Long> getOnlyGiveSubContractIds(List<SaleGroupInfoViewDTO> saleGroupInfoList, CampaignGroupSettleQueryViewDTO settleQueryViewDTO) {
        // 包含赠送分组的子合同Id
        List<Long> includeGiveSubContractIds = saleGroupInfoList.stream()
                .filter(t -> BrandSaleTypeEnum.PRESENT.getCode().equals(t.getSaleType()))
                .filter(t -> t.getSubContractId() != null && (settleQueryViewDTO.getSubContractId() == null || settleQueryViewDTO.getSubContractId().equals(t.getSubContractId())))
                .map(SaleGroupInfoViewDTO::getSubContractId)
                .distinct()
                .collect(Collectors.toList());
        if (CollectionUtils.isEmpty(includeGiveSubContractIds)) {
            return includeGiveSubContractIds;
        }
        Map<Long, List<SaleGroupInfoViewDTO>> includeGiveSubContractMap = saleGroupInfoList.stream()
                .filter(t -> includeGiveSubContractIds.contains(t.getSubContractId()))
                .collect(Collectors.groupingBy(SaleGroupInfoViewDTO::getSubContractId));
        List<Long> onlyGiveSubContractIds = Lists.newArrayList();
        includeGiveSubContractMap.forEach((subContractId, subContractSaleGroupList) -> {
            Set<Integer> saleTypeSet = subContractSaleGroupList.stream().map(SaleGroupInfoViewDTO::getSaleType).collect(Collectors.toSet());
            if (saleTypeSet.size() == 1) {
                onlyGiveSubContractIds.add(subContractId);
            }
        });

        return onlyGiveSubContractIds;
    }

    private List<CampaignSettleBaseViewDTO> convertCampaignSettleList(List<CampaignViewDTO> campaignViewDTOS) {
        if (CollectionUtils.isEmpty(campaignViewDTOS)) {
            return Lists.newArrayList();
        }
        return campaignViewDTOS.stream().map(item -> {
            CampaignSettleBaseViewDTO settleBaseViewDTO = new CampaignSettleBaseViewDTO();
            settleBaseViewDTO.setCampaignId(item.getId());
            settleBaseViewDTO.setSourceCampaignId(item.getCampaignBoostViewDTO().getSourceCampaignId());
            settleBaseViewDTO.setBudgetCampaignId(item.getCampaignGuaranteeViewDTO().getBudgetCampaignId());
            if (item.getCampaignGuaranteeViewDTO() != null) {
                settleBaseViewDTO.setIsUnionControlFlow(item.getCampaignGuaranteeViewDTO().getIsUnionControlFlow());
            }

            return settleBaseViewDTO;
        }).collect(Collectors.toList());
    }

    public List<CampaignGroupSaleGroupSettleInfoViewDTO> sortCampaignGroupSaleGroupSettleInfoList(List<CampaignGroupSaleGroupSettleInfoViewDTO> settleInfoViewList,
                                                                                                  List<ResourcePackageSaleGroupViewDTO> saleGroupList) {
        if (CollectionUtils.isEmpty(settleInfoViewList) || settleInfoViewList.size() == 1) {
            return settleInfoViewList;
        }
        // 排序
        settleInfoViewList.sort(Comparator.comparing(CampaignGroupSaleGroupSettleInfoViewDTO::getSaleType)
                .thenComparing(CampaignGroupSaleGroupSettleInfoViewDTO::getSource));
        Map<Long, CampaignGroupSaleGroupSettleInfoViewDTO> settleInfoViewMap = settleInfoViewList.stream()
                .collect(Collectors.toMap(CampaignGroupSaleGroupSettleInfoViewDTO::getSaleGroupId, Function.identity()));
        // 构建主分组和补量分组的映射
        Map<Long, List<Long>> mainSaleGroupIdMap = Maps.newHashMap();
        saleGroupList.forEach(t -> {
            if (BrandSaleTypeEnum.BUY.getCode().equals(t.getSaleType())) {
                return;
            }
            mainSaleGroupIdMap.computeIfAbsent(t.getMainGroupId(), k -> new ArrayList<>()).add(t.getId());

        });

        Set<Long> sortedSaleGroupIdSet = Sets.newHashSet();
        List<CampaignGroupSaleGroupSettleInfoViewDTO> sortedSettleInfoViewDTOList = Lists.newArrayList();
        for (CampaignGroupSaleGroupSettleInfoViewDTO settleInfoViewDTO : settleInfoViewList) {
            if (sortedSaleGroupIdSet.contains(settleInfoViewDTO.getSaleGroupId())) {
                continue;
            }
            sortedSettleInfoViewDTOList.add(settleInfoViewDTO);
            sortedSaleGroupIdSet.add(settleInfoViewDTO.getSaleGroupId());

            if (BrandSaleTypeEnum.BUY.getCode().equals(settleInfoViewDTO.getSaleType())) {
                if (!mainSaleGroupIdMap.containsKey(settleInfoViewDTO.getSaleGroupId())) {
                    continue;
                }
                List<Long> notBuySaleGroupIds = mainSaleGroupIdMap.get(settleInfoViewDTO.getSaleGroupId());
                for (Long notBuySaleGroupId : notBuySaleGroupIds) {
                    if (!settleInfoViewMap.containsKey(notBuySaleGroupId)) {
                        continue;
                    }
                    sortedSettleInfoViewDTOList.add(settleInfoViewMap.get(notBuySaleGroupId));
                    sortedSaleGroupIdSet.add(notBuySaleGroupId);
                }
            }
        }

        return sortedSettleInfoViewDTOList;
    }
}
