package com.taobao.ad.brand.bp.common.converter.campaigngroup.mapstruct;

import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupDeliveryTargetViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignSaleGroupDeliveryTargetViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.*;
import org.mapstruct.control.DeepClone;
import org.mapstruct.factory.Mappers;

/**
 * 分组优化部分MapStruct
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/23
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, mappingControl= DeepClone.class)
public interface CampaignSaleGroupDeliveryTargetMapStruct extends BaseMapStructMapper<CampaignSaleGroupDeliveryTargetViewDTO, SaleGroupDeliveryTargetViewDTO> {

    CampaignSaleGroupDeliveryTargetMapStruct INSTANCE = Mappers.getMapper(CampaignSaleGroupDeliveryTargetMapStruct.class);


}