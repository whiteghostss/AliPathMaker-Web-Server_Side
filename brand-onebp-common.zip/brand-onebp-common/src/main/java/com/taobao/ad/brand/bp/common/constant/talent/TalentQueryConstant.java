package com.taobao.ad.brand.bp.common.constant.talent;

import com.taobao.ad.brand.bp.common.constant.ReportConstant;

public class TalentQueryConstant extends ReportConstant {

    public static final String USER_ID_EQUAL = "userIdEqual";

    public static final String USER_ID_IN = "userIdIn";

    public static final String TALENT_ID_EQUAL = "talentIdEqual";

    public static final String TALENT_ID_IN = "talentIdIn";

    public static final String MEDIA_ID_EQUAL = "mediaIdEqual";

    public static final String MEDIA_ID_IN = "mediaIdIn";

    public static final String KEYWORD = "keyword";

    public static final String WORK_TYPE = "workTypeEqual";
}
