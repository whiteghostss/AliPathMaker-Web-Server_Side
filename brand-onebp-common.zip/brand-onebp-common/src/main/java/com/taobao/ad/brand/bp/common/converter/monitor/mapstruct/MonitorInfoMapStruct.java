package com.taobao.ad.brand.bp.common.converter.monitor.mapstruct;

import com.alibaba.ad.brand.dto.monitor.ThirdMonitorUrlViewDTO;
import com.taobao.ad.brand.bp.client.dto.monitor.MonitorInfoDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/23
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface MonitorInfoMapStruct extends BaseMapStructMapper<MonitorInfoDTO, ThirdMonitorUrlViewDTO> {

    MonitorInfoMapStruct INSTANCE = Mappers.getMapper(MonitorInfoMapStruct.class);
}