package com.taobao.ad.brand.bp.common.constant;


import com.google.common.collect.Sets;

import java.util.Set;

/**
 * adc角色常量类
 *
 * @author yuncheng.lyc
 */
public class AdcRoleConstant {
    /**
     * 内部小二角色
     */
    public static final String INNER_WAITER_ADC_ROLE = "inner_waiter_role";

    /**
     * 基础角色
     */
    public static final String BASE_ADC_ROLE = "basic_role";

    /**
     * 高阶客户角色
     */
    public static final String HIGH_LEVEL_ADC_ROLE = "high_level_role";

    /**
     * 投前策略代理角色
     */
    public static final String INTELLIGENT_STRATEGY_PROXY_WHITE = "Intelligent_strategy_proxy_white";

    /**
     * 特秀/showmax 客户自操白名单
     */
    public static final String TX_CUSTOMER_SELF_OPERATION_LIST = "tx_customer_self_operation_list";

    /**
     * topshow自建创意客户白名单
     */
    public static final String TOPSHOW_CREATE_CREATIVE_WHITE_CODE = "topshow_create_creative_white_code";

    /**
     * 百灵流量宝监测客户白名单
     */
    public static final String LIULIANGBAO_WHITE_CODE = "liuliangbao_white_code";

    /**
     * 获取基础角色集合
     * @return
     */
    public static Set<String> getBasicRoleList(){
        return Sets.newHashSet(BASE_ADC_ROLE,INNER_WAITER_ADC_ROLE);
    }
}