package com.taobao.ad.brand.bp.common.util.chain;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * 链式调用工具类
 * @param <T>
 */
public class EnhancedChainBuilder<T> {
    private T data;
    private List<Consumer<T>> operations = new ArrayList<>();
    private List<Predicate<T>> validations = new ArrayList<>();
    private List<Function<T, ?>> transformations = new ArrayList<>();

    private EnhancedChainBuilder(T initialData) {
        this.data = initialData;
    }

    // 创建实例的静态方法
    public static <T> EnhancedChainBuilder<T> of(T initialData) {
        return new EnhancedChainBuilder<>(initialData);
    }

    // 添加操作
    public EnhancedChainBuilder<T> apply(Consumer<T> operation) {
        operations.add(operation);
        return this;
    }

    // 添加条件验证
    public EnhancedChainBuilder<T> validate(Predicate<T> validation) {
        validations.add(validation);
        return this;
    }

    // 添加转换操作
    public <R> EnhancedChainBuilder<R> transform(Function<T, R> transformation) {
        EnhancedChainBuilder<R> newBuilder = new EnhancedChainBuilder<>(null);
        newBuilder.operations = new ArrayList<>();
        newBuilder.validations = new ArrayList<>();
        newBuilder.transformations = new ArrayList<>();

        // 添加当前的转换操作
        transformations.add(transformation);

        // 执行所有操作并传递结果
        R result = executeTransformation();
        newBuilder.data = result;

        return newBuilder;
    }

    // 条件执行
    public EnhancedChainBuilder<T> ifThen(Predicate<T> condition, Consumer<T> action) {
        operations.add(data -> {
            if (condition.test(data)) {
                action.accept(data);
            }
        });
        return this;
    }

    // 异常处理
    public EnhancedChainBuilder<T> onError(Consumer<Exception> errorHandler) {
        try {
            execute();
        } catch (Exception e) {
            errorHandler.accept(e);
        }
        return this;
    }

    // 执行所有操作
    public T execute() {
        // 执行验证
        for (Predicate<T> validation : validations) {
            if (!validation.test(data)) {
                throw new IllegalStateException("Validation failed");
            }
        }
        // 执行操作
        for (Consumer<T> operation : operations) {
            operation.accept(data);
        }
        return data;
    }

    //执行转换
    private <R> R executeTransformation() {
        Object result = data;
        for (Function<?, ?> transformation : transformations) {
            result = ((Function<Object, Object>) transformation).apply(result);
        }
        return (R) result;
    }

    // 获取当前值
    public T get() {
        return data;
    }
}
