package com.taobao.ad.brand.bp.common.helper.product;

import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import org.apache.commons.collections.CollectionUtils;

import java.util.Objects;
import java.util.Set;

/**
 * Description:二级产品业务域工具类
 * <p>
 * date: 2023/11/9 7:53 PM
 *
 * @author shiyan
 * @version 1.0
 */
public class BizProductToolsHelper {
    /**
     * 获取二级产品所有定向类型
     * @param productViewDTO
     * @return
     */
    public static Set<String> getProductAllDirectType(ProductViewDTO productViewDTO) {
        Set<String> directTypeList = Sets.newHashSet();
        if(org.apache.commons.collections.CollectionUtils.isNotEmpty(productViewDTO.getDirectionList())){
            productViewDTO.getDirectionList().stream().filter(item-> Objects.nonNull(item.getValue())).forEach(item->{
                directTypeList.add(item.getValue());
                if(CollectionUtils.isNotEmpty(item.getSubDirectionList())){
                    item.getSubDirectionList().stream().filter(subItem->Objects.nonNull(subItem.getType())).forEach(subItem->directTypeList.add(subItem.getType()));
                }
            });
        }
        return directTypeList;
    }

}
