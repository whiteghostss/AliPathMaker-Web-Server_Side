package com.taobao.ad.brand.bp.common.util;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.RemovalListener;

import java.util.concurrent.TimeUnit;

/**
 * 描述:
 *
 * @author lvzheng
 * @create 2021-05-12 5:28 下午
 */
public class GuavaCacheHelper {


    public static <K, V> Cache<K, V> createCache(long durationSeconds, long size) {
        return CacheBuilder.newBuilder()
            .expireAfterWrite(durationSeconds, TimeUnit.SECONDS)
            .maximumSize(size)
            .build();
    }

    public static <K, V> Cache<K, V> createCache(long durationSeconds,long expireAfterSeconds, long size,
        RemovalListener<K, V> easRemovalListener) {
        return CacheBuilder.newBuilder()
            .expireAfterWrite(durationSeconds, TimeUnit.SECONDS)
            //一周不访问过期
            .expireAfterAccess(expireAfterSeconds,TimeUnit.SECONDS)
            .maximumSize(size)
            .removalListener(easRemovalListener)
            .build();
    }
}
