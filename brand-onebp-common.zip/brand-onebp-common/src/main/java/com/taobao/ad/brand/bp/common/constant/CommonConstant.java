package com.taobao.ad.brand.bp.common.constant;

public class CommonConstant {

    public static final Integer YES=1;

    public static final Integer NO=0;
}
