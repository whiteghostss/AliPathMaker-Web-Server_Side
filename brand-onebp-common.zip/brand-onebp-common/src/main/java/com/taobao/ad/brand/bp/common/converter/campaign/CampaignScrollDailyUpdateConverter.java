package com.taobao.ad.brand.bp.common.converter.campaign;

import java.util.List;
import java.util.Map;

import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;

import com.alibaba.ad.brand.dto.campaign.inquiry.DayAmountViewDTO;
import com.alibaba.ad.brand.dto.campaign.scroll.CampaignScrollViewDTO;
import com.alibaba.fastjson.JSON;

import com.alibaba.fastjson.JSONObject;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import static com.taobao.ad.brand.bp.common.util.BrandDateUtil.DATE_FORMAT_YYYYMMDD_TYPE_2;

/**
 * @author yanjingang
 * @date 2023/02/25
 */
@Component
public class CampaignScrollDailyUpdateConverter {

    private static final String MEMBER_ID_KEY = "memberid";
    private static final String CAMPAIGN_ID_KEY = "campaignid";
    private static final String CAMPAIGN_LEVEL_KEY = "campaignlevel";
    private static final String CAST_INFO_KEY = "castinfo";

    public List<CampaignViewDTO> convertFrom(List<Map<String, Object>> scrollDailyUpdateList) {
        if (CollectionUtils.isEmpty(scrollDailyUpdateList)) {
            return Lists.newArrayList();
        }
        List<CampaignViewDTO> campaignViewDTOList = Lists.newArrayList();
        for (Map<String, Object> map : scrollDailyUpdateList) {
            Long memberId = getVal(MEMBER_ID_KEY, map, Long.class);
            Long campaignId = getVal(CAMPAIGN_ID_KEY, map, Long.class);
            Integer campaignLevel = getVal(CAMPAIGN_LEVEL_KEY, map, Integer.class);
            String castInfo = getVal(CAST_INFO_KEY, map, String.class);
            List<DayAmountViewDTO> castInfoList = Lists.newArrayList();
            if (StringUtils.isNotBlank(castInfo)) {
                String[] dayAmountList = StringUtils.split(castInfo, ";");
                for (String key : dayAmountList) {
                    String[] dayAmount = StringUtils.split(key, ":");
                    DayAmountViewDTO dto = new DayAmountViewDTO();
                    dto.setDay(BrandDateUtil.string2Date(dayAmount[0], DATE_FORMAT_YYYYMMDD_TYPE_2));
                    dto.setAmount(Long.valueOf(dayAmount[1]));
                    castInfoList.add(dto);
                }
            }
            if (memberId == null || campaignId == null || campaignLevel == null || CollectionUtils.isEmpty(castInfoList)) {
                RogerLogger.info("scrollDailyUpdate missing data:{}", JSON.toJSONString(map));
                continue;
            }
            CampaignScrollViewDTO campaignScrollViewDTO = new CampaignScrollViewDTO();
            campaignScrollViewDTO.setCastInfoList(castInfoList);

            CampaignViewDTO campaignViewDTO = new CampaignViewDTO();
            campaignViewDTO.setId(campaignId);
            campaignViewDTO.setCampaignLevel(campaignLevel);
            campaignViewDTO.setMemberId(memberId);
            campaignViewDTO.setCampaignScrollViewDTO(campaignScrollViewDTO);

            campaignViewDTOList.add(campaignViewDTO);
        }
        RogerLogger.info("过滤后待滚量数据: {}", JSONObject.toJSONString(campaignViewDTOList));

        return campaignViewDTOList;
    }

    public <T> T getVal(String key, Map<String, Object> map, Class<T> clazz) {
        if (map.get(key) != null) {
            String json = JSON.toJSONString(map.get(key));
            return JSON.parseObject(json, clazz);
        }
        return null;
    }
}
