package com.taobao.ad.brand.bp.common.constant;


/**
 * 报表常量类
 *
 * @author yuncheng.lyc
 */
public class ReportConstant {
    public static final String ADR_UNIQUE_KEY = "uniqueKey";

    public static final String PAGE_SIZE = "pageSize";

    public static final String PAGE_OFFSET = "offset";

    public static final String SORT_FIELD = "sortField";

    public static final String SORT_RULE = "sortRule";

    public static final String DS_EQUAL = "dsEqual";

    public static final String NEED_TOTAL_COUNT = "needTotalCount";

    public static final String TOTAL_COUNT_API_SUFFIX = "Total";

    public static final String CASTING_DMP_CROWD_PREFIX = "-100_";

    //百灵临时兜底方案,后续dmp升级接口后可去除
    public static final String DMP_CROWD_DEFAULT_NAME = "该人群已过期/已删除,如需查询人群名称,请钉钉群联系:68170006906";

}