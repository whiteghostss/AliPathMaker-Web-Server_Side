package com.taobao.ad.brand.bp.common.helper.schema;

import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.common.WakeupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.common.SchemaConfigViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupWakeupTypeEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.google.common.collect.Lists;

import java.util.List;
import java.util.Objects;

/**
 * @author yanjingang
 * @date 2024/3/6
 */
public class BizSchemaToolsHelper {

    /**
     * 获取唤端配置，
     * 优先获取单元配置，单元不存在时获取订单唤端配置
     * @param campaignGroupViewDTO
     * @param adgroupViewDTO
     * @return
     */
    public static WakeupViewDTO getWakeupConfig(CampaignGroupViewDTO campaignGroupViewDTO, AdgroupViewDTO adgroupViewDTO) {
        // 单元配置
        if (hasWakeupConfig(adgroupViewDTO.getWakeupViewDTO())) {
            return adgroupViewDTO.getWakeupViewDTO();
        }
        // 订单配置
        return getCampaignGroupWakeupConfig(campaignGroupViewDTO);
    }

    /**
     * 获取订单唤端配置
     *
     * @param campaignGroupViewDTO
     * @return
     */
    public static WakeupViewDTO getCampaignGroupWakeupConfig(CampaignGroupViewDTO campaignGroupViewDTO) {
        WakeupViewDTO wakeupConfigResult = new WakeupViewDTO();
        if (campaignGroupViewDTO.getWakeupViewDTO().getWakeupType() != null) {
            wakeupConfigResult.setIsOpenWakeup(BrandBoolEnum.BRAND_TRUE.getCode());
            wakeupConfigResult.setWakeupType(campaignGroupViewDTO.getWakeupViewDTO().getWakeupType());
            List<SchemaConfigViewDTO> schemaConfigResultList = Lists.newArrayList();
            campaignGroupViewDTO.getWakeupViewDTO().getSchemaConfigViewDTOList().forEach(campaignGroupSchemaConfig -> {
                SchemaConfigViewDTO schemaConfigResult = new SchemaConfigViewDTO();
                if (Objects.nonNull(campaignGroupSchemaConfig.getSchemaId())) {
                    schemaConfigResult.setSchemaId(campaignGroupSchemaConfig.getSchemaId());
                }
//                else if (CollectionUtils.isNotEmpty(campaignGroupViewDTO.getExtViewDTO().getSchemaIds())) {
//                    schemaConfigResult.setSchemaId(campaignGroupViewDTO.getExtViewDTO().getSchemaIds().get(0));
//                }
                schemaConfigResult.setOpenType(campaignGroupSchemaConfig.getOpenType());
                schemaConfigResult.setSchemaConfigDetailViewDTO(campaignGroupSchemaConfig.getSchemaConfigDetailViewDTO());
                schemaConfigResultList.add(schemaConfigResult);
            });
            wakeupConfigResult.setSchemaConfigViewDTOList(schemaConfigResultList);
        } else {
            wakeupConfigResult.setIsOpenWakeup(BrandBoolEnum.BRAND_FALSE.getCode());
        }

        return wakeupConfigResult;
    }

    public static boolean hasWakeupConfig(WakeupViewDTO wakeupViewDTO) {
        return wakeupViewDTO != null && BrandBoolEnum.BRAND_TRUE.getCode().equals(wakeupViewDTO.getIsOpenWakeup());
    }

    public static Long getSchemaId(WakeupViewDTO wakeupViewDTO) {
        if (!hasWakeupConfig(wakeupViewDTO) || BrandCampaignGroupWakeupTypeEnum.NON_WAKEUP.getCode().equals(wakeupViewDTO.getWakeupType())) {
            return null;
        }
        return wakeupViewDTO.getSchemaConfigViewDTOList().get(0).getSchemaId();
    }

    public static boolean isEqual(WakeupViewDTO wakeupConfig1, WakeupViewDTO wakeupConfig2) {
        if (wakeupConfig1 == null) {
            if (wakeupConfig2 == null || !BrandBoolEnum.BRAND_TRUE.getCode().equals(wakeupConfig2.getIsOpenWakeup())) {
                return true;
            }
            return false;
        }
        if (wakeupConfig2 == null) {
            if (!BrandBoolEnum.BRAND_TRUE.getCode().equals(wakeupConfig1.getIsOpenWakeup())) {
                return true;
            }
            return false;
        }
        Long schemaId1 = getSchemaId(wakeupConfig1);
        Long schemaId2 = getSchemaId(wakeupConfig2);
        return schemaId1 == null && schemaId2 == null || schemaId1 != null && schemaId1.equals(schemaId2);
    }
}
