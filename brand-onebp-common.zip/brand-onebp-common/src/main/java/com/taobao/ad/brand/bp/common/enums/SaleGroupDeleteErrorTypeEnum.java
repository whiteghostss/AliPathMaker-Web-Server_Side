package com.taobao.ad.brand.bp.common.enums;

/**
 * 删除分组错误类型
 *
 * @author yanjingang
 * @date 2023/9/20
 */
public enum SaleGroupDeleteErrorTypeEnum {

    SALE_GROUP_ORDER_STATUS_ERROR(1, "分组已下单"),
    HAS_CAMPAIGN_ERROR(2, "分组下有计划"),
    NO_OTHER_SALE_GROUP_ERROR(3, "订单下不存在其他分组"),
    SALE_GROUP_DATE_ERROR(4, "分组已进入投放期"),
    CAMPAIGN_ADV_BALANCE_GT_ZERO_ERROR(5, "计划绑定的adv余额不为0"),


    ;
    public final int value;
    public final String desc;

    SaleGroupDeleteErrorTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public int getValue() {
        return value;
    }

    public String getDesc() {
        return desc;
    }

    public static SaleGroupDeleteErrorTypeEnum getByValue(Integer value) {
        SaleGroupDeleteErrorTypeEnum[] sourceEnums = SaleGroupDeleteErrorTypeEnum.values();
        for (SaleGroupDeleteErrorTypeEnum source : sourceEnums) {
            if (source.getValue() == value) {
                return source;
            }
        }
        return null;
    }

}
