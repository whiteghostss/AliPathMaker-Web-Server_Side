package com.taobao.ad.brand.bp.common.threadpooltask;


import com.alibaba.ad.nb.tpp.core.task.TaskIdentifier;
import com.alibaba.ad.nb.tpp.core.threadpool.ThreadPoolBuilder;
import com.alibaba.ad.nb.tpp.dataobject.RunMode;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import org.springframework.stereotype.Component;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * 计划自动分配预定量
 * @author jixiu.lj
 * @date 2024/3/7 20:20
 */
@Component
public class CampaignAutoAssignScheduleTaskIdentifier extends TaskIdentifier {
    @Override
    public ThreadPoolBuilder applyThreadPoolBuilder() {
        return ThreadPoolBuilder.builder()
                .corePoolSize(Runtime.getRuntime().availableProcessors())
                .maximumPoolSize(Runtime.getRuntime().availableProcessors())
                .workQueue(new LinkedBlockingQueue<>(2048));
    }

    @Override
    protected Integer applyTaskTimeoutInSec() {
        return 60;
    }
}
