package com.taobao.ad.brand.bp.common.util;

import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.eagleeye.EagleEye;
import com.taobao.eagleeye.RpcContext_inner;

import java.util.concurrent.Callable;

public abstract class CallTask<V> implements Callable {
    private RpcContext_inner rpcContext;


    public CallTask() {
        rpcContext = EagleEye.getRpcContext();
    }

    @Override
    public V call() {
        EagleEye.setRpcContext(rpcContext);
        try {
            return doCall();
        } catch (Throwable e) {
            RogerLogger.error("task call error",e);
            throw e;
        }
    }

    public abstract V doCall();
}