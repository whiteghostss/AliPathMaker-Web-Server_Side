package com.taobao.ad.brand.bp.common.threadpooltask;


import com.alibaba.ad.nb.tpp.core.task.TaskIdentifier;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * @author jixiu.lj
 * @date 2024/3/7 20:20
 * 单元批量保存为正式任务
 */
@Component
public class AdgroupUpdteMonitorTaskIdentifier extends TaskIdentifier {

    // 复用线程池
    @Resource
    AdgroupBatchOnlineTaskIdentifier adgroupBatchOnlineTaskIdentifier;

    @Override
    public String applyThreadPoolTag() {
        return adgroupBatchOnlineTaskIdentifier.getThreadPoolTag();
    }

    @Override
    public Integer applyTaskTimeoutInSec() {
        return 10;
    }
}
