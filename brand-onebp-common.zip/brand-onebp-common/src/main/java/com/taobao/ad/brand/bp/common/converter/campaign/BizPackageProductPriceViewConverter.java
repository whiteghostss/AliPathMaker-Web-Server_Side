package com.taobao.ad.brand.bp.common.converter.campaign;

import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaign.BizPackageProductPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignDayPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.common.converter.campaign.mapstruct.BizPackageProductPriceViewMapStruct;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author yuanxinxi
 */
@Component
public class BizPackageProductPriceViewConverter {

    @Resource
    private CampaignViewPageConverter campaignViewPageConverter;

    public CampaignPriceViewDTO convertSelf(BizPackageProductPriceViewDTO source){
        return  BizPackageProductPriceViewMapStruct.INSTANCE.copySelf(source);
    }

    /**
     * 资源包产品配置
     * @param resourcePackageProductViewDTO
     * @return
     */
    public BizPackageProductPriceViewDTO convertToPackageProductPrice(ResourcePackageProductViewDTO resourcePackageProductViewDTO, Boolean isCpt) {
        BizPackageProductPriceViewDTO priceViewDTO = new BizPackageProductPriceViewDTO();
        List<CampaignDayPriceViewDTO> priceInfoList = Lists.newArrayList();
        Long totalCptAmount = 0L;
        for (ResourcePackageProductPriceViewDTO resourcePackageProductPriceViewDTO : resourcePackageProductViewDTO.getBandPriceList()) {
            Long cptAmount = null;
            if (isCpt) {
                cptAmount = resourcePackageProductPriceViewDTO.getBookingAmount();
                totalCptAmount += cptAmount;
            }
            CampaignDayPriceViewDTO dayPriceViewDTO = campaignViewPageConverter.convertProductPrice2DayPriceViewDTO(resourcePackageProductPriceViewDTO);
            dayPriceViewDTO.setCptAmount(cptAmount);
            dayPriceViewDTO.setDiscountPrice(resourcePackageProductPriceViewDTO.getPrice());
            dayPriceViewDTO.setPublishPrice(resourcePackageProductPriceViewDTO.getPublishPrice());
            priceInfoList.add(dayPriceViewDTO);
        }
        priceViewDTO.setCptAmount(totalCptAmount);
        priceViewDTO.setPriceInfos(priceInfoList);
        priceViewDTO.setMediaFlowRatio(resourcePackageProductViewDTO.getBookingAmountRatio());
        priceViewDTO.setStartDate(resourcePackageProductViewDTO.getStartTime());
        priceViewDTO.setEndDate(resourcePackageProductViewDTO.getEndTime());
        return priceViewDTO;
    }


    /**
     * 资源包产品配置
     * @param resourcePackageProductViewDTO
     * @return
     */
    public BizPackageProductPriceViewDTO convertToPackageProductPrice(ResourcePackageProductViewDTO resourcePackageProductViewDTO) {
        BizPackageProductPriceViewDTO priceViewDTO = new BizPackageProductPriceViewDTO();
        List<CampaignDayPriceViewDTO> priceInfoList = Lists.newArrayList();
        Long totalCptAmount = 0L;
        for (ResourcePackageProductPriceViewDTO resourcePackageProductPriceViewDTO : resourcePackageProductViewDTO.getBandPriceList()) {
            Long cptAmount = null;
            if (BizCampaignToolsHelper.isCPT(resourcePackageProductViewDTO.getSaleUnit())) {
                cptAmount = resourcePackageProductPriceViewDTO.getBookingAmount();
                totalCptAmount += cptAmount;
            }
            CampaignDayPriceViewDTO dayPriceViewDTO = campaignViewPageConverter.convertProductPrice2DayPriceViewDTO(resourcePackageProductPriceViewDTO);
            dayPriceViewDTO.setCptAmount(cptAmount);
            dayPriceViewDTO.setDiscountPrice(resourcePackageProductPriceViewDTO.getPrice());
            dayPriceViewDTO.setPublishPrice(resourcePackageProductPriceViewDTO.getPublishPrice());
            priceInfoList.add(dayPriceViewDTO);
        }
        priceViewDTO.setCptAmount(totalCptAmount);
        priceViewDTO.setPriceInfos(priceInfoList);
        priceViewDTO.setMediaFlowRatio(resourcePackageProductViewDTO.getBookingAmountRatio());
        priceViewDTO.setStartDate(resourcePackageProductViewDTO.getStartTime());
        priceViewDTO.setEndDate(resourcePackageProductViewDTO.getEndTime());
        return priceViewDTO;
    }
}

