package com.taobao.ad.brand.bp.common.constant;

public enum MemberStatus {
    /** **/
    REPAYING(Integer.valueOf(0), "清退"),
    VALID(Integer.valueOf(1), "正常"),
    FREEZE(Integer.valueOf(2), "冻结投放"),
    NOTACCESS(Integer.valueOf(-1), "准入未通过"),
    ACCESS_NOTJOIN(Integer.valueOf(-2), "准入但未加入"),

    /** 信息流新状态 **/
    /** 索引为int8，因此更改为非二进制 **/
    PUNISH_BAN(20, "封闭客户"),
    PUNISH_MONITOR(21,"高危客户"),
    PUNISH_BLOCK_OFFLINE(22,"客户屏蔽下线"),
    PUNISH_BLOCK(23,"客户屏蔽不下线"),
    PUNISH_CC(24,"CC客户"),
    PUNISH_FLOW_CONTROL(25,"降权客户"),
    PUNISH_WARN(26,"警告客户");

    private Integer value;
    private String description;

    private MemberStatus(Integer value, String description) {
        this.value = value;
        this.description = description;
    }

    public Integer getValue() {
        return this.value;
    }

    public String getDescription() {
        return this.description;
    }

    public static boolean contains(Integer status) {
        boolean isContain = false;
        MemberStatus[] arr$ = values();
        int len$ = arr$.length;

        for(int i$ = 0; i$ < len$; ++i$) {
            MemberStatus memberStatus = arr$[i$];
            if (memberStatus.getValue().equals(status)) {
                isContain = true;
                break;
            }
        }

        return isContain;
    }

    public static MemberStatus getByValue(Integer value) {
        MemberStatus[] arr$ = values();
        int len$ = arr$.length;

        for(int i$ = 0; i$ < len$; ++i$) {
            MemberStatus status = arr$[i$];
            if (status.getValue().equals(value)) {
                return status;
            }
        }

        throw new IllegalArgumentException("Member status :" + value + " is illage!");
    }
}

