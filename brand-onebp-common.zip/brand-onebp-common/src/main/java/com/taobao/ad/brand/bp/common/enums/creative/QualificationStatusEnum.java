package com.taobao.ad.brand.bp.common.enums.creative;

import lombok.Getter;

@Getter
public enum QualificationStatusEnum {
    NO_UPLOAD(-3, "未上传"),
    EXPIRED(-2, "已过期"),
    REFUSED(-1, "拒绝"),
    TODO_AUDIT(0, "待审核"),
    PASS(1, "通过"),
    EXPIRES_SOON(2, "即将过期"),
    DRAFT(3, "草稿");

    private Integer code;
    private String desc;

    QualificationStatusEnum(Integer code, String desc){
        this.code = code;
        this.desc = desc;
    }
}
