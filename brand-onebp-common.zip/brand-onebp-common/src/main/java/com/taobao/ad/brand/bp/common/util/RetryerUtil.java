package com.taobao.ad.brand.bp.common.util;

import com.github.rholder.retry.Attempt;
import com.github.rholder.retry.RetryListener;
import com.github.rholder.retry.Retryer;
import com.github.rholder.retry.RetryerBuilder;
import com.github.rholder.retry.StopStrategies;
import com.github.rholder.retry.WaitStrategies;
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * 重试设置Util
 * @author wumian
 * @since 2020/11/15 2:24 PM
 */
public class RetryerUtil<T> {

    private static Logger logger = LoggerFactory.getLogger(RetryerUtil.class);

    public static<T> Retryer<T> buildDefaultRetryer() {
        return buildRetryer(Predicates.isNull(), 1000, 3);
    }

    public static<T> Retryer<T> buildRetryer(Predicate resultPredicate, Integer waitStrategy, Integer stopStrategy) {
        return buildRetryer(resultPredicate, waitStrategy, stopStrategy, null);
    }

    public static <T> Retryer<T> buildRetryer(Predicate resultPredicate, Integer waitStrategy, Integer stopStrategy,
        List<? extends RuntimeException> runtimeExceptions) {

        RetryerBuilder retryerBuilder = RetryerBuilder.<T>newBuilder();
        retryerBuilder.retryIfException()
            .retryIfResult(resultPredicate)
            .withWaitStrategy(WaitStrategies.fixedWait(waitStrategy, TimeUnit.MILLISECONDS))
            .withStopStrategy(StopStrategies.stopAfterAttempt(stopStrategy))
            .withRetryListener(new RetryListener() {
                @Override
                public <V> void onRetry(Attempt<V> attempt) {
                    logger.error(String.format(
                        "第[%s/3]次重试, delay=%s, success=%s" + (attempt.hasException() ? ", exception=%s"
                            : ", result=%s"),
                        attempt.getAttemptNumber(), attempt.getDelaySinceFirstAttempt(), !attempt.hasException(),
                        (attempt.hasException() ? attempt.getExceptionCause().toString() : attempt.getResult())));
                }
            });

        //异常重试设置
        if (CollectionUtils.isNotEmpty(runtimeExceptions)) {
            for (RuntimeException ex : runtimeExceptions) {
                retryerBuilder.retryIfExceptionOfType(ex.getClass());
            }
        } else {
            retryerBuilder.retryIfException();
        }

        return retryerBuilder.build();
    }

}
