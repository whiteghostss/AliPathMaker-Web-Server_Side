package com.taobao.ad.brand.bp.common.converter.campaigngroup.mapstruct;

import com.alibaba.ad.nb.packages.v2.client.constant.product.CastTypeEnum;

import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageCastTypeViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.common.converter.campaigngroup.mapstruct.CampaignGroupProductMapStruct;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/23
 */
public abstract class CampaignGroupProductMapStructDecorator implements CampaignGroupProductMapStruct {

    private final CampaignGroupProductMapStruct campaignGroupProductMapStruct;

    public CampaignGroupProductMapStructDecorator(CampaignGroupProductMapStruct campaignGroupProductMapStruct) {
        this.campaignGroupProductMapStruct = campaignGroupProductMapStruct;
    }

    @Override
    public CampaignGroupProductViewDTO sourceToTarget(ResourcePackageProductViewDTO resourcePackageProductViewDTO) {
        CampaignGroupProductViewDTO campaignGroupProductViewDTO = campaignGroupProductMapStruct.sourceToTarget(resourcePackageProductViewDTO);
        ResourcePackageCastTypeViewDTO castType = resourcePackageProductViewDTO.getCastType();
        Integer sspRegisterManner = castType == null ? CastTypeEnum.GUARANTEE.getValue() : castType.getType();
        campaignGroupProductViewDTO.setSspRegisterManner(sspRegisterManner);
        return campaignGroupProductViewDTO;
    }

    @Override
    public ResourcePackageProductViewDTO targetToSource(CampaignGroupProductViewDTO campaignGroupProductViewDTO) {
        return campaignGroupProductMapStruct.targetToSource(campaignGroupProductViewDTO);
    }
}