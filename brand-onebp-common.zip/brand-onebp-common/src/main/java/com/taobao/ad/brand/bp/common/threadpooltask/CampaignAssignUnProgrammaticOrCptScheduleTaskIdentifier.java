package com.taobao.ad.brand.bp.common.threadpooltask;


import com.alibaba.ad.nb.tpp.core.task.TaskIdentifier;
import com.alibaba.ad.nb.tpp.core.threadpool.ThreadPoolBuilder;
import org.springframework.stereotype.Component;

/**
 * @author jixiu.lj
 * @date 2024/3/7 20:20
 * 单元批量保存为正式任务
 */
@Component
public class CampaignAssignUnProgrammaticOrCptScheduleTaskIdentifier extends TaskIdentifier {

    @Override
    public ThreadPoolBuilder applyThreadPoolBuilder() {
        return ThreadPoolBuilder.builder().corePoolSize(20).maximumPoolSize(20);
    }

    @Override
    public Integer applyTaskTimeoutInSec() {
        return 10;
    }
}
