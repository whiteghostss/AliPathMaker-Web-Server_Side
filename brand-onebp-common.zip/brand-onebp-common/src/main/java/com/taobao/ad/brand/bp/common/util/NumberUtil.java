package com.taobao.ad.brand.bp.common.util;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/03/30
 */
public class NumberUtil {

    public static boolean greaterThanZero(Integer number) {
        return number != null && number > 0;
    }

    public static boolean greaterThan(Long o1, Long o2) {
        return o1 != null && o2 != null && o1 > o2;
    }
    public static boolean checkIsNum(String num){
        return NumberUtils.isCreatable(num);
    }
    public static boolean isZero(Integer number) {
        return number != null && number == 0;
    }

    public static boolean isZero(Long number) {
        return number != null && number == 0;
    }

    /**
     * 判断是否为0（整数或浮点数）
     * @param num
     * @return
     */
    public static boolean isZero(BigDecimal num) {
        // 用 compareTo 方法比较是否为 0
        return num.compareTo(BigDecimal.ZERO) == 0;
    }

    public static boolean greaterThanZero(Long number) {
        return number != null && number > 0;
    }

    public static Long getCpmAmount(Long pv) {
        AssertUtil.notNull(pv);
        return pv / 1000;
    }

    public static Long getOrDefaultZero(Long amount) {
        return Optional.ofNullable(amount).orElse(0L);
    }

    /**
     * 获取范围内全部数字
     * @param start eg：1
     * @param end eg：4
     * @return eg：1,2,3,4
     */
    public static List<Integer> getRangeNums(Integer start, Integer end) {
        List<Integer> result = new ArrayList<>();
        if (end == null || start == null || start > end) {
            return result;
        }
        for (int i = start; i <= end; i++) {
            result.add(i);
        }
        return result;
    }

    /**
     * 获取范围内全部数字
     * @param rangeNum eg："1-4"
     * @param split eg："-"
     * @return eg：1,2,3,4
     */
    public static List<Integer> getRangeNums(String rangeNum, String split) {
        String[] numbers = StringUtils.split(rangeNum, split);
        if (numbers.length != 2) {
            return new ArrayList<>();
        }
        Integer start = Integer.parseInt(numbers[0]);
        Integer end = Integer.parseInt(numbers[1]);
        return getRangeNums(start, end);
    }

    /**
     * 取中位数
     */
    public static Long median(List<Long> list) {
        long s = 0;
        if (CollectionUtils.isEmpty(list)){
            return s;
        }
        Collections.sort(list);
        int size = list.size();
        if(size % 2 == 1){
            s = list.get((size-1)/2);
        }else {
            s = (list.get(size/2-1) + list.get(size/2))/2;
        }
        return s;
    }

    /**
     * double扩大指定倍数四舍五入转化成long
     * @param num
     * @return
     */
    public static Long getLongNumber(Double num, Integer multiple){
        if(num == null){
            return 0L;
        }
        return new BigDecimal(num*multiple).setScale(0, BigDecimal.ROUND_HALF_UP).longValue();
    }

}
