package com.taobao.ad.brand.bp.common.util;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.client.dto.base.DateViewDTO;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.text.ParseException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

public abstract class BrandLocalDateTimeUtil {
    public static final String DATE_FORMAT_YYYYMMDD_TYPE_1 = "yyyy-MM-dd";
    public static final String DATE_FORMAT_YYYYMMDD_TYPE_2 = "yyyyMMdd";
    public static final String DATE_FORMAT_YYYYMMDD_TYPE_3 = "yyyy.MM.dd";
    public static final String DATE_FORMAT_YYYYMM_TYPE_1 = "yyyyMM";
    public static final String DATE_FORMAT_YYYYMMDD_TYPE_4 = "yyyy/MM/dd";
    public static final String DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_1 = "yyyy-MM-dd HH:mm:ss";
    public static final String DATE_FORMAT_YYYYMMDDHHMM_TYPE_1 = "yyyy-MM-dd HH:mm";
    public static final String DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_2 = "yyyy/MM/dd HH:mm:ss";
    private static final long ONE_DAY = 24 * 60 * 60 * 1000L;

    private static final String TIME_SCOPE_SPLT_KEY = "-";
    private static final String TIME_SPLT_KEY = ":";


    /**
     * 获取时间区间
     *
     * @param start
     * @param end
     * @return
     */
    public static Set<Date> getBetweenDatesDateResult(Date start, Date end) {

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_FORMAT_YYYYMMDD_TYPE_1);
        start = localDate2Date(LocalDate.parse(date2LocalDate(start).format(formatter), formatter));
        end = localDate2Date(LocalDate.parse(date2LocalDate(end).format(formatter), formatter));

        Set<Date> result = new LinkedHashSet<>();
        Calendar tempStart = Calendar.getInstance();
        tempStart.setTime(start);
        Calendar tempEnd = Calendar.getInstance();
        tempEnd.setTime(end);
        while (tempStart.before(tempEnd)) {
            result.add(tempStart.getTime());
            tempStart.add(Calendar.DAY_OF_YEAR, 1);
        }
        result.add(end);
        return result;
    }

    /**
     *
     * @param timeStrList 00:00-00:59
     * @param needPlusOne 采购和价格中心00:00-00:59认为是1点需要加1，询锁量认为是0点不需要加1
     * @return
     */
    public static List<String> getBetweenHourResult(List<String> timeStrList,Boolean needPlusOne){
        Set<Integer> timeSet = Sets.newHashSet();
        for(String timStr : timeStrList){
            String[] timeSplit = StringUtils.split(timStr,TIME_SCOPE_SPLT_KEY);
            AssertUtil.assertTrue(timeSplit!=null && timeSplit.length == 2,"时间格式不正确");
            Calendar calendar = getCurrentCalendarDate();
            String[] hourMinuteStart = StringUtils.split(timeSplit[0],TIME_SPLT_KEY);
            AssertUtil.assertTrue(hourMinuteStart!=null && hourMinuteStart.length == 2,"时间格式不正确");
            String[] hourMinuteEnd = StringUtils.split(timeSplit[1],TIME_SPLT_KEY);
            AssertUtil.assertTrue(hourMinuteEnd!=null && hourMinuteEnd.length == 2,"时间格式不正确");
            Calendar start = Calendar.getInstance();
            start.set(calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_YEAR),Integer.parseInt(hourMinuteStart[0]),Integer.parseInt(hourMinuteStart[1]));
            Calendar end = Calendar.getInstance();
            end.set(calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_YEAR),Integer.parseInt(hourMinuteEnd[0]),Integer.parseInt(hourMinuteEnd[1]));

            timeSet.add(start.get(Calendar.HOUR_OF_DAY));
            while (start.before(end)){
                start.add(Calendar.HOUR_OF_DAY,1);
                if(start.after(end)){
                    break;
                }
                timeSet.add(start.get(Calendar.HOUR_OF_DAY));
            }
        }
        if(CollectionUtils.isEmpty(timeSet)){
            return  Lists.newArrayList();
        }
        List<String>  resultList = Lists.newArrayList();
        for(Integer i : timeSet){

            resultList.add(needPlusOne ? String.valueOf(i+1) : String.valueOf(i));
        }
        return resultList;
    }

    public static  Set<String> getIntervaSublHours(int start,int end,int minHour){
        Set<String> hourString = Sets.newHashSet();
        if(start >= end || end - start < minHour){
            return hourString;
        }
        while(start  < end ){
            int[] time = new int[2];
            time[0] = start;
            end-= minHour;
            time[1] = end;
            if(end <= start){
                continue;
            }
            String x = time[0]+"-"+time[1];
            hourString.add(x);
        }
        return hourString;
    }

    /**
     * 是否是零点
     *
     * @param date
     * @return
     */
    public static Boolean isZeroTime(Date date) {
        Boolean result = false;
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);
        int second = calendar.get(Calendar.SECOND);
        int milliSecond = calendar.get(Calendar.MILLISECOND);
        if (hour == 0 && minute == 0 && second == 0 && milliSecond == 0) {
            result = true;
        }
        return result;
    }

    /**
     * 修改日期时间
     *
     * @param date     日期
     * @param dateType 日期类型，年、月、日等，eg：Calendar.DAY_OF_MONTH
     * @param num      日期变动值
     * @return
     */
    public static Date modifyDate(Date date, Integer dateType, Integer num) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(dateType, num);
        return calendar.getTime();
    }

    /**
     * 功能描述：取得日期段拆分成每天
     *
     * @param startDate
     * @param endDate
     * @return
     * @throws Exception
     */
    public static List<String> getYyyyMmDdDayList(Date startDate, Date endDate) {
        List<String> dayList = Lists.newArrayList();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_FORMAT_YYYYMMDD_TYPE_2);

        Calendar c = Calendar.getInstance();
        c.setTime(startDate);
        while (c.getTime().compareTo(endDate) <= 0) {
            dayList.add(date2LocalDateTime(c.getTime()).format(formatter));
            c.add(Calendar.DAY_OF_YEAR, 1);
        }
        return dayList;
    }

    /**
     * 功能描述：取得日期段拆分成每天
     *
     * @param startDate
     * @param endDate
     * @return
     * @throws Exception
     */
    public static List<Date> getDayList(Date startDate, Date endDate) {
        List<Date> dayList = Lists.newArrayList();
        Calendar c = Calendar.getInstance();
        c.setTime(startDate);
        while (c.getTime().compareTo(endDate) <= 0) {
            dayList.add(c.getTime());
            c.add(Calendar.DAY_OF_YEAR, 1);

        }
        return dayList;
    }

    /**
     * 计算日期相差天数
     *
     * @param startDate
     * @param endDate
     * @return
     */
    public static int getNumOfDaysBetweenDate(Date startDate, Date endDate) {
        if (startDate != null && endDate != null) {
            Calendar tempStart = Calendar.getInstance();
            tempStart.setTime(startDate);
            Calendar tempEnd = Calendar.getInstance();
            tempEnd.setTime(endDate);

            int result = 0;
            while (tempStart.before(tempEnd)) {
                result++;
                tempStart.add(Calendar.DAY_OF_YEAR, 1);
            }
            return result;
        }
        return -1;
    }

    public static Date getMaxDate(Date date) {
        String dateStr = date2String(date, DATE_FORMAT_YYYYMMDD_TYPE_1);
        Date dateResult = string2Date(dateStr + " 23:59:59", DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_1);
        return dateResult;
    }

    public static Date getMinDate(Date date) {
        String dateStr = date2String(date, DATE_FORMAT_YYYYMMDD_TYPE_1);
        Date dateResult = string2Date(dateStr + " 00:00:00", DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_1);
        return dateResult;
    }


    /**
     * 判断2个时间段是否有重叠（交集）
     *
     * @param startDate        时间段1开始时间戳
     * @param endDate          时间段1结束时间戳
     * @param compareStartDate 时间段2开始时间戳
     * @param compareEndDate   时间段2结束时间戳
     * @return 返回是否重叠
     */
    public static boolean isMixed(Date startDate, Date endDate, Date compareStartDate, Date compareEndDate) {
        Set<Date> dates = getBetweenDatesDateResult(startDate, endDate);
        Set<Date> compareDates = getBetweenDatesDateResult(compareStartDate, compareEndDate);
        dates.retainAll(compareDates);
        if (CollectionUtils.isNotEmpty(dates)) {
            return true;
        }
        return false;
    }

    /**
     * 判断2个时间段是否有重叠（交集）
     *
     * @param startDate        时间段1开始时间戳
     * @param endDate          时间段1结束时间戳
     * @param compareStartDate 时间段2开始时间戳
     * @param compareEndDate   时间段2结束时间戳
     * @return 返回重叠日期
     */
    public static List<Date> getMixedDate(Date startDate, Date endDate, Date compareStartDate, Date compareEndDate) {
        Set<Date> dates = getBetweenDatesDateResult(startDate, endDate);
        Set<Date> compareDates = getBetweenDatesDateResult(compareStartDate, compareEndDate);
        dates.retainAll(compareDates);
        if (CollectionUtils.isNotEmpty(dates)) {
            return Lists.newArrayList(dates);
        }
        return Lists.newArrayList();
    }

    /**
     * 判断2个时间段是否有重叠（交集）
     *
     * @param left  左时间段
     * @param right 由时间段
     * @return 返回是否重叠
     */
    public static List<Date> getMixedDate(List<DateViewDTO> left, List<DateViewDTO> right) {
        Set<Date> setResult = Sets.newHashSet();
        for (DateViewDTO l : left) {
            for (DateViewDTO r : right) {

                List<Date> mixedDateList = getMixedDate(l.getStartDate(), l.getEndDate(), r.getStartDate(), r.getEndDate());
                setResult.addAll(mixedDateList);
            }
        }
        return CollectionUtils.isNotEmpty(setResult) ? Lists.newArrayList(setResult) : Lists.newArrayList();

    }

    /**
     * 是否历史时间
     *
     * @param currentTimestamp
     * @return
     */
    public static boolean isHistoryTime(long currentTimestamp) {
        long historyTime = LocalDateTime.of(LocalDate.now(), LocalTime.MIN).atZone(ZoneId.systemDefault()).toInstant()
                .toEpochMilli();
        return currentTimestamp < historyTime;
    }

    /**
     * 是否历史时间
     *
     * @param currentDate
     * @return
     */
    public static boolean isHistoryTime(Date currentDate) {
        return isHistoryTime(currentDate.getTime());
    }


    public static String date2String(Date date) {
        return date2String(date, DATE_FORMAT_YYYYMMDD_TYPE_1);
    }

    /**
     * 日期转字符串
     *
     * @param date   日期
     * @param format 格式
     * @return string
     */
    public static String date2String(Date date, String format) {
        if (date == null) {
            return StringUtils.EMPTY;
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);

        return date2LocalDateTime(date).format(formatter);
    }

    public static Date string2Date(String date, String format) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
        try {
            return localDateTime2Date(LocalDateTime.parse(date, formatter));
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 当前时间的 00：00：00
     */
    public static Date getCurrentDate() {
        Calendar calendar = getCurrentCalendarDate();
        return calendar.getTime();
    }

    /**
     * 获取明天日期 00:00:00
     *
     * @return
     */
    public static Date getTomorrowDate() {
        Calendar calendar = getCurrentCalendarDate();
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        return calendar.getTime();
    }

    /**
     * 获取昨天日期00:00:00
     *
     * @return
     */
    public static Date getYesterdayDate() {
        Calendar calendar = getCurrentCalendarDate();
        calendar.add(Calendar.DAY_OF_MONTH, -1);
        return calendar.getTime();
    }


    /**
     * 获取当前日期的calendar对象
     * 00:00:00
     *
     * @return
     */
    private static Calendar getCurrentCalendarDate() {
        return getCalendarDate(new Date());
    }

    /**
     * 获取当前日期的calendar对象
     * 00:00:00
     *
     * @param date
     * @return
     */
    private static Calendar getCalendarDate(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar;
    }

    /**
     * 判断startTime不在endTime后面
     *
     * @param startTime
     * @param endTime
     * @return
     */
    public static boolean notAfter(Date startTime, Date endTime) {
        AssertUtil.notNull(startTime);
        AssertUtil.notNull(endTime);
        if (startTime.before(endTime) || startTime.equals(endTime)) {
            return true;
        }
        return false;
    }


    /**
     * 判断startTime不在endTime前面
     *
     * @param date1
     * @param date2
     * @return
     */
    public static boolean isBeforeAndEqual(Date date1, Date date2) {
        AssertUtil.notNull(date1);
        AssertUtil.notNull(date2);
        if (date1.before(date2) || date1.equals(date2)) {
            return true;
        }
        return false;
    }

    /**
     * 判断startTime不在endTime后面
     *
     * @param date1
     * @param date2
     * @return
     */
    public static boolean isAfterAndEqual(Date date1, Date date2) {
        AssertUtil.notNull(date1);
        AssertUtil.notNull(date2);
        if (date1.after(date2) || date1.equals(date2)) {
            return true;
        }
        return false;
    }

    public static boolean isBefore(Date startTime, Date endTime) {
        AssertUtil.notNull(startTime);
        AssertUtil.notNull(endTime);
        return startTime.before(endTime);
    }

    public static boolean isAfter(Date startTime, Date endTime) {
        AssertUtil.notNull(startTime);
        AssertUtil.notNull(endTime);
        return startTime.after(endTime);
    }

    public static Date maxDate(Date date1, Date date2) {
        if (isBefore(date1, date2)) {
            return date2;
        }
        return date1;
    }

    public static Date minDate(Date date1, Date date2) {
        if (isBefore(date1, date2)) {
            return date1;
        }
        return date2;
    }

    /**
     * 获取代表某日期的date，时间是23:59:59
     *
     * @return
     */
    public static Date getDateFullMidnight(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTime();
    }

    /**
     * 获取代表某日期的date，时间是00:00:00
     *
     * @return
     */
    public static Date getDateMidnight(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTime();
    }

    /**
     * 获取时间间隔<br/>
     *
     * @param startTime (include)
     * @param endTime   (include)
     * @return
     */
    public static Integer getDateRange(Date startTime, Date endTime) {
        AssertUtil.notNull(startTime);
        AssertUtil.notNull(endTime);
        startTime = getDateMidnight(startTime);
        endTime = getDateMidnight(endTime);
        Long diff = endTime.getTime() - startTime.getTime();
        return (int) (diff / (1000 * 60 * 60 * 24));
    }

    public static List<DateViewDTO> formatDateQuantum(List<Date> dateList) {
        if (dateList == null || dateList.isEmpty()) {
            return Collections.emptyList();
        }
        dateList = dateList.stream().sorted().collect(Collectors.toList());
        List<DateViewDTO> dataModels = new ArrayList<>();
        Date nowDate = dateList.get(0);
        Date startDate = nowDate;
        int index = 1;
        while (index < dateList.size()) {
            Date endDate = dateList.get(index);
            //时间相邻
            if (endDate.getTime() - startDate.getTime() == ONE_DAY) {
                startDate = endDate;
                index++;
                continue;
            }
            DateViewDTO dateModel = new DateViewDTO();
            dateModel.setStartDate(nowDate);
            dateModel.setEndDate(startDate);
            dataModels.add(dateModel);

            nowDate = endDate;
            startDate = endDate;
            index++;
        }

        DateViewDTO dateModel = new DateViewDTO();
        dateModel.setStartDate(nowDate);
        dateModel.setEndDate(startDate);
        dataModels.add(dateModel);

        return dataModels.stream().sorted(Comparator.comparing(DateViewDTO::getStartDate)).collect(Collectors.toList());
    }

    /**
     * 年月日 判断是否一天
     */
    public static boolean isSameDay(Date date1, Date date2) {
        if (date1 != null && date2 != null) {
            Calendar cal1 = Calendar.getInstance();
            cal1.setTime(date1);
            Calendar cal2 = Calendar.getInstance();
            cal2.setTime(date2);
            return isSameDay(cal1, cal2);
        } else {
            throw new IllegalArgumentException("The date must not be null");
        }
    }

    /**
     * 年月日 判断是否一天
     */
    public static boolean isSameDay(Calendar cal1, Calendar cal2) {
        if (cal1 != null && cal2 != null) {
            return cal1.get(Calendar.ERA) == cal2.get(Calendar.ERA) && cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) && cal1.get(
                    Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR);
        } else {
            throw new IllegalArgumentException("The date must not be null");
        }
    }

    /**
     * 判断targetTime时间是否在range中，
     *
     * @return 如果在range前，则返回 <0 <br/>
     * 如果在range中,则返回 ==0 <br/>
     * 如果在range后，则返回 >0 <br/>
     */
    public static int timeRange(Date targetTime, Date startTime, Date endTime) {
        if (targetTime.before(startTime)) {
            return -1;
        } else if (targetTime.after(endTime)) {
            return 1;
        }
        return 0;
    }

    public static Date getAfterDate(Date date, int day) {
        return getAfterDate(date, day, 0, 0);
    }

    public static Date getAfterDate(Date date, int day, int hour, int min) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        if (0 != day) {
            cal.add(Calendar.DATE, day);
        }
        if (0 != hour) {
            cal.add(Calendar.HOUR_OF_DAY, hour);
        }
        if (0 != min) {
            cal.add(Calendar.MINUTE, min);
        }
        return cal.getTime();
    }

    public static Date localDateTime2Date(LocalDateTime localDateTime) {
        return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
    }

    public static LocalDateTime date2LocalDateTime(Date date) {
        return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
    }

    public static Date localDate2Date(LocalDate localDate) {
        return Date.from(localDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
    }

    public static LocalDate date2LocalDate(Date date) {
        return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }
}

