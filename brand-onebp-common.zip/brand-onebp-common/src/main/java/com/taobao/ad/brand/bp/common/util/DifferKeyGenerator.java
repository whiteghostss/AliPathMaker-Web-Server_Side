package com.taobao.ad.brand.bp.common.util;

@FunctionalInterface
public interface DifferKeyGenerator<T> {

    String gen(T t);
}