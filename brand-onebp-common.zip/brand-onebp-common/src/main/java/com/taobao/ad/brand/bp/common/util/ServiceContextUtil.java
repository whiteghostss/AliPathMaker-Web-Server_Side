package com.taobao.ad.brand.bp.common.util;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.biz.app.AbfAppUtil;
import com.alibaba.ad.biz.app.domain.AppDO;
import com.alibaba.ad.biz.definition.constants.ProductLine;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.hermes.framework.context.BizSessionContextHolder;
import com.alibaba.solar.common.dto.BaseServiceContext;
import com.google.common.collect.Maps;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.BeanUtils;

import java.util.Optional;

public class ServiceContextUtil {
    /**
     * 阿里小二的buc用户id
     */
    public static final String ALI_STAFF_BUC_USER_ID = "aliStaffBucUserId";

    public static Integer getSceneId(ServiceContext serviceContext) {
        if(serviceContext == null){
            return  null;
        }
        if(serviceContext.getAppId() != null){
            return serviceContext.getAppId();
        }
        //如果获取不到则取本身的appid,按照bizCode来转换获取
        if(StringUtils.isNotBlank(serviceContext.getBizCode())){
            return getSceneId(serviceContext.getBizCode());
        }

        return  null;
    }

    public static Integer getSceneId(String bizCode) {
        if(StringUtils.isBlank(bizCode)){
            return null;
        }
        AppDO appDO = AbfAppUtil.getByBizCode(bizCode);
        if(appDO != null && appDO.getAppId() != null){
            return appDO.getAppId();
        }
        return null;
    }

    public static Integer getProductId(String bizCode) {
        if(StringUtils.isBlank(bizCode)){
            return null;
        }
        AppDO appDO = AbfAppUtil.getByBizCode(bizCode);
        if(appDO != null){
            return appDO.getProductId();
        }
        return null;
    }

    public static String getBizCode(Integer sceneId) {
        if(sceneId == null){
            return null;
        }
        AppDO appDO = AbfAppUtil.getByAppId(sceneId);
        if(appDO != null){
            return appDO.getBizCode();
        }
        return null;
    }

    /**
     * 当前操作人是否是阿里小二
     *
     * @param serviceContext
     * @return
     */
    public static boolean isAliStaff(ServiceContext serviceContext) {
        if (MapUtils.isEmpty(serviceContext.getExt())) {
            return false;
        }
        Object aliStaffBucUserId = serviceContext.getExt().get(ALI_STAFF_BUC_USER_ID);
        return aliStaffBucUserId != null && NumberUtils.isDigits(aliStaffBucUserId.toString());
    }

    public static Long getAliStaffBucUserId(ServiceContext serviceContext) {
        if (MapUtils.isEmpty(serviceContext.getExt())) {
            return null;
        }
        Object aliStaffBucUserId = serviceContext.getExt().get(ALI_STAFF_BUC_USER_ID);
        if (aliStaffBucUserId == null) {
            return null;
        }
        if (!NumberUtils.isDigits(aliStaffBucUserId.toString())) {
            return null;
        }
        return Long.parseLong(String.valueOf(aliStaffBucUserId));
    }

    public static ServiceContext buildServiceContextForBizCode(Long memberId, String bizCode) {
        AppDO appDO = Optional.ofNullable(bizCode).map(AbfAppUtil::getByBizCode).orElse(null);
        return buildServiceContext(memberId,appDO);
    }

    public static ServiceContext buildServiceContextForSceneId(Long memberId, Integer sceneId) {
        AppDO appDO = Optional.ofNullable(sceneId).map(AbfAppUtil::getByAppId).orElse(null);
        return buildServiceContext(memberId,appDO);
    }

    public static ServiceContext getNewServiceContext(ServiceContext serviceContext, Integer sceneId) {
        ServiceContext newServiceContext = new ServiceContext();
        BeanUtils.copyProperties(serviceContext, newServiceContext);
        reAssignServiceContext(newServiceContext,sceneId);
        return newServiceContext;
    }

    public static void reAssignServiceContext(ServiceContext serviceContext, Integer sceneId) {
        AppDO appDO = AbfAppUtil.getByAppId(sceneId);
        if (appDO != null) {
            serviceContext.setProductLineId(appDO.getProductLineId());
            serviceContext.setProductId(appDO.getProductId());
            serviceContext.setBizCode(appDO.getBizCode());
            serviceContext.setAppId(sceneId);
        }
        //允许并发调用
        if(serviceContext.getExt() == null){
            serviceContext.setExt(Maps.newHashMap());
        }
        serviceContext.getExt().put("allowConcurrency", BrandBoolEnum.BRAND_TRUE.getCode());
        BizSessionContextHolder.setServiceContext(serviceContext);
    }

    private static ServiceContext buildServiceContext(Long memberId, AppDO appDO) {
        ServiceContext context = buildServiceContextNoSession(memberId, appDO);
        BizSessionContextHolder.setServiceContext(context);
        return context;
    }

    public static ServiceContext buildServiceContextForBizCodeNoSession(Long memberId, String bizCode) {
        AppDO appDO = Optional.ofNullable(bizCode).map(AbfAppUtil::getByBizCode).orElse(null);
        return buildServiceContextNoSession(memberId,appDO);
    }

    public static ServiceContext buildServiceContextForSceneIdNoSession(Long memberId, Integer sceneId) {
        AppDO appDO = Optional.ofNullable(sceneId).map(AbfAppUtil::getByAppId).orElse(null);
        return buildServiceContextNoSession(memberId,appDO);
    }

    private static ServiceContext buildServiceContextNoSession(Long memberId, AppDO appDO) {
        ServiceContext context = buildServiceContext(memberId);
        if(appDO != null){
            context.setAppId(appDO.getAppId());
            context.setBizCode(appDO.getBizCode());
            context.setProductId(appDO.getProductId());
            context.setProductLineId(appDO.getProductLineId());
        }
        return context;
    }

    private static ServiceContext buildServiceContext(Long memberId) {
        ServiceContext context = new ServiceContext();
        context.setOperType(BaseServiceContext.OPERTYPE_INNER_OPT);
        context.setProductLineId(ProductLine.BRAND_ONEBP.getId());
        context.setMemberId(memberId);
        //允许并发调用
        if(context.getExt() == null){
            context.setExt(Maps.newHashMap());
        }
        context.getExt().put("allowConcurrency", BrandBoolEnum.BRAND_TRUE.getCode());
        return context;
    }

    public static void reSetServiceContextMemberId(ServiceContext context, Long memberId) {
        context.setMemberId(memberId);
        buildServiceContextSession(context);
    }

    public static void reAssignServiceContext(ServiceContext context, String bizCode) {
        AppDO appDO = Optional.ofNullable(bizCode).map(AbfAppUtil::getByBizCode).orElse(null);
        if(appDO != null){
            context.setAppId(appDO.getAppId());
            context.setBizCode(appDO.getBizCode());
            context.setProductId(appDO.getProductId());
            context.setProductLineId(appDO.getProductLineId());
        }
        //允许并发调用
        if(context.getExt() == null){
            context.setExt(Maps.newHashMap());
        }
        context.getExt().put("allowConcurrency", BrandBoolEnum.BRAND_TRUE.getCode());
        buildServiceContextSession(context);
    }

    public static void buildServiceContextSession(ServiceContext context) {
        BizSessionContextHolder.setServiceContext(context);
    }
}
