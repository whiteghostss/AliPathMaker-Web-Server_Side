package com.taobao.ad.brand.bp.common.util;

import java.text.NumberFormat;
import java.util.Locale;
import java.util.Objects;

/**
 * @author yanjingang
 * @date 2023/3/11
 */
public class CurrencyUtil {

    public static char[] NUMBER_CHAR = "零壹贰叁肆伍陆柒捌玖".toCharArray();
    public static char[] UNIT_CHAR = "元拾佰仟万拾佰仟亿拾佰仟".toCharArray();

    /**
     * 加千分位
     */
    public static String thousands(String str) {
        if (str == null || str.isEmpty()) {
            return "";
        }
        NumberFormat st = NumberFormat.getIntegerInstance(Locale.US);
        st.setMinimumFractionDigits(2);
        return st.format(Double.valueOf(str));
    }
    /**
     * 分转换成元的字符串形式，比如1分转换成“0.01”， 170转换成“1.70”
     * @param fen 分
     * @return 元的字符串形式
     */
    public static String f2y(Long fen) {
        if(fen == null) {
            return "0.00";
        }
        boolean isLessThanZero = false;
        if (fen < 0L) {
            isLessThanZero = true;
            fen = Math.abs(fen);
        }
        StringBuffer sb = new StringBuffer();
        sb.append(fen/100);
        sb.append(".");
        fen %= 100;
        if(fen < 10) {
            sb.append("0");
        }
        sb.append(fen);

        if (isLessThanZero) {
            sb.insert(0, "-");
        }

        return sb.toString();
    }

    public static Long y2f(String yuan) {
        if(yuan == null) {
            return 0L;
        }
        String[] parts = yuan.split("\\.");
        if(parts.length > 2) {
            return 0L;
        }
        Long fen = Long.valueOf(parts[0]) * 100;
        if(parts.length == 2) {
            String frac = parts[1];
            int len = frac.length();
            if (len == 1) {
                fen += Long.valueOf(frac) * 10;
            } else if (len == 2) {
                fen += Long.valueOf(frac);
            } else {
                frac = frac.substring(0, 3);
                Long tmp = Long.valueOf(frac);
                tmp = (tmp + 5 / 10);
                fen += tmp;
            }
        }
        return fen;
    }

    /**
     * 将小写金额转换成大写金额(以分为单位)
     *
     * @param amount 小写金额
     * @return 大写金额
     */
    public static String amount2RMB(Long amount) {
        try {
            StringBuffer retSb = new StringBuffer();
            String retStr = "";

            Long yuan = amount/100;
            Integer fen = Long.valueOf(amount % 100).intValue();

            int length = String.valueOf(yuan).length() - 1;//长度
            int pos = length;//当前位置
            Long posValue = 0L;//当前位置对应的值
            int dividend = (int) Math.pow(10, length);//被除数
            boolean flag = false;

            if (yuan < 10) {
                if(fen == 0 || yuan > 0) {
                    retSb.append(NUMBER_CHAR[yuan.intValue()]);
                    retSb.append(UNIT_CHAR[pos]);
                }
            } else {
                while (pos > 0) {
                    posValue = yuan / dividend;
                    yuan = yuan % dividend;
                    if (posValue > 0) {
                        if (flag && (pos != 3 && pos != 7)) {
                            retSb.append(NUMBER_CHAR[0]);
                        }
                        flag = false;
                        retSb.append(NUMBER_CHAR[posValue.intValue()]);
                        retSb.append(UNIT_CHAR[pos]);
                    }
                    if (posValue == 0) {
                        flag = true;
                        if (pos == 4 || pos == 8) {
                            retSb.append(UNIT_CHAR[pos]);
                        }
                    }
                    pos--;
                    dividend = dividend / 10;
                }
                if (yuan > 0) {
                    if (flag && (pos != 3 && pos != 7)) {
                        retSb.append(NUMBER_CHAR[0]);
                    }
                    retSb.append(NUMBER_CHAR[yuan.intValue()]);
                }
                retSb.append(UNIT_CHAR[0]);
            }
            if(fen >= 10) {
                retSb.append(NUMBER_CHAR[fen/10]);
                retSb.append("角");
                fen = fen % 10;
            } else if(fen > 0) {
                if(retSb.length() > 0) {
                    retSb.append("零");
                }
            } else {
                if(retSb.length() > 0) {
                    retSb.append("整");
                }
            }
            if(fen > 0) {
                retSb.append(NUMBER_CHAR[fen]);
                retSb.append("分");
            }

            retStr = retSb.toString().replaceAll("亿万", "亿");

            System.out.println(retStr);
            return retStr;
        } catch (Exception e) {
            //RogerLogger.error(e.getMessage(), e);
        }
        return f2y(amount);
    }

    /**
     * [支持负数] 分转换成元的字符串形式，比如1分转换成“0.01”， 170转换成“1.70”
     * @param fen 分
     * @return 元的字符串形式
     */
    public static String f2ySupportNegative(Long fen) {
        if (Objects.isNull(fen)) {
            return "0.00";
        }
        StringBuffer sb = new StringBuffer();
        boolean negative = false;

        if (fen < 0L) {
            fen = Math.abs(fen);
            negative = true;
        }

        sb.append(fen/100);
        sb.append(".");
        fen %= 100;
        if(fen < 10) {
            sb.append("0");
        }
        sb.append(fen);

        if (negative) {
            sb.insert(0, "-");
        }

        return sb.toString();
    }

}
