package com.taobao.ad.brand.bp.common.util;

import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.collect.Lists;
import org.apache.commons.collections.CollectionUtils;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * @author yuncheng.lyc
 * @date 2023/11/1
 **/
public class MapBeanUtil {
    /**
     * map转对象
     * @param dataList
     * @param clazz
     * @return
     * @param <T>
     * @throws InstantiationException
     * @throws IllegalAccessException
     */
    public static <T> List<T> convert2Bean(List<Map<String, Object>> dataList, Class<T> clazz){
        try {
            List<T> result = Lists.newArrayList();
            if (CollectionUtils.isEmpty(dataList)) {
                return result;
            }
            for (Map<String, Object> data : dataList) {
                Object obj = clazz.newInstance();
                Field[] fields = obj.getClass().getDeclaredFields();
                for (Field field : fields) {
                    if(Objects.isNull(field)){
                        continue;
                    }
                    Annotation annotation = field.getAnnotation(JsonProperty.class);
                    if(Objects.isNull(annotation)){
                        continue;
                    }
                    String fieldName = field.getAnnotation(JsonProperty.class).value();
                    if (data.containsKey(fieldName)) {
                        Object v = data.get(fieldName);
                        field.setAccessible(true);
                        if (obj == null) {
                            continue;
                        }
                        field.set(obj, v);
                    }
                }
                result.add((T) obj);
            }
            return result;
        }catch (Exception e){
            RogerLogger.error("convert2Bean error", e);
            throw new RuntimeException(e);
        }
    }
}
