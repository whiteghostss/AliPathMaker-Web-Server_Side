package com.taobao.ad.brand.bp.common.util;

import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.diamond.client.Diamond;
import com.taobao.diamond.manager.ManagerListener;
import org.apache.commons.collections4.CollectionUtils;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.function.BiFunction;
import java.util.function.Consumer;

/**
 * 废弃，统一使用 BaseDiamondConfig
 * @author 虫洞 <liuming.liu@alibaba-inc.com>
 * @date 2021/7/6
 */
@Deprecated
public class DiamondUtils {

    private static final String DEFAULT_GROUP = "com.taobao.ad.brand.bp";
    private static final long DEFAULT_TIMEOUT_SECONDS = 5L;

    /**
     * @see #DIAMOND_PROPERTY_KEY_FUNCTION
     */
    private static final Map<String, List<Consumer<String>>> DIAMOND_PROPERTY_CONSUMER_MAP = new ConcurrentHashMap<>();

    private static final BiFunction<String, String, String> DIAMOND_PROPERTY_KEY_FUNCTION = (group, dataId) -> group + "#" + dataId;

    private static String getConfig(String dataId) {
        return getConfig(dataId, DEFAULT_GROUP);
    }

    private static String getConfig(String dataId, String group) {
        try {
            return Diamond.getConfig(dataId, group, TimeUnit.SECONDS.toMillis(DEFAULT_TIMEOUT_SECONDS));
        } catch (IOException e) {
            throw new RuntimeException(String.format("get diamond config error, dataId: %s, group: %s", dataId, group), e);
        }
    }

    public static void subscribeConfig(String dataId, Consumer<String> configConsumer) {
        subscribeConfig(dataId, DEFAULT_GROUP, configConsumer);
    }

    /**
     * 订阅Diamond配置变更
     * <p>
     * 首先从Diamond同步拉取一次配置，调用configConsumer处理配置，
     * 然后设置Diamond配置变更订阅，当收到配置变更推送时，调用configConsumer处理配置
     * <p>
     * 方法保证configConsumer不会收到值为null的字符串
     *
     * @param dataId
     * @param group
     * @param configConsumer
     * @return
     */
    public synchronized static void subscribeConfig(String dataId, String group, Consumer<String> configConsumer) {
        try {
            String configInfo = Diamond.getConfig(dataId, group, TimeUnit.SECONDS.toMillis(DEFAULT_TIMEOUT_SECONDS));
            RogerLogger.info("get diamond config, dataId={}, group={}, configInfo={}", dataId, group, configInfo);
            Optional.ofNullable(configInfo).ifPresent(configConsumer);
        } catch (IOException e) {
            RogerLogger.error("get diamond config error, dataId: {}, group: {}", dataId, group, e);
        }

        String diamondPropertyKey = DIAMOND_PROPERTY_KEY_FUNCTION.apply(group, dataId);
        DIAMOND_PROPERTY_CONSUMER_MAP.putIfAbsent(diamondPropertyKey, new CopyOnWriteArrayList<>());
        List<Consumer<String>> configConsumerList = DIAMOND_PROPERTY_CONSUMER_MAP.get(diamondPropertyKey);
        // 同一个 group+dataId 只订阅监听一次
        if (CollectionUtils.isEmpty(configConsumerList)) {
            Diamond.addListener(dataId, group, new DefaultDiamondConfigSubscriber(dataId, group));
        }
        configConsumerList.add(configConsumer);
    }

    private static class DefaultDiamondConfigSubscriber implements ManagerListener {
        private final String dataId;
        private final String group;

        public DefaultDiamondConfigSubscriber(String dataId, String group) {
            this.dataId = dataId;
            this.group = group;
        }

        @Override
        public Executor getExecutor() {
            return null;
        }

        @Override
        public void receiveConfigInfo(String configInfo) {
            RogerLogger.info("[diamond subscribe]receive diamond config, dataId={}, group={}, configInfo={}", dataId, group, configInfo);
            String diamondPropertyKey = DIAMOND_PROPERTY_KEY_FUNCTION.apply(group, dataId);
            List<Consumer<String>> configConsumerList = DIAMOND_PROPERTY_CONSUMER_MAP.getOrDefault(diamondPropertyKey, Collections.emptyList());
            configConsumerList.forEach(configConsumer -> {
                try {
                    Optional.ofNullable(configInfo).ifPresent(configConsumer);
                } catch (Exception e) {
                    RogerLogger.error("process diamond config error", e);
                }
            });
        }
    }

}
