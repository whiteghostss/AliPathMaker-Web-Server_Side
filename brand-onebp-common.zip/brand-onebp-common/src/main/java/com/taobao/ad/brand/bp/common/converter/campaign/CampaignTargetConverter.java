package com.taobao.ad.brand.bp.common.converter.campaign;

import com.alibaba.ad.nb.ssp.constant.newproduct.ProductDirectionEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.TreeNodeViewDTO;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author yanjingang
 * @date 2024/11/5
 */
@Component
public class CampaignTargetConverter {

    /**
     * 位置位序列表
     * @param directionList
     */
    public List<TreeNodeViewDTO> convertToPositionTree(List<CommonViewDTO> directionList) {
        if (CollectionUtils.isEmpty(directionList)) {
            return Lists.newArrayList();
        }
        //父级节点
        List<TreeNodeViewDTO> parentDictionaryList = directionList.stream()
                .filter(dictionaryDTO -> !dictionaryDTO.getValue().contains("_"))
                .map(dictionaryDTO -> TreeNodeViewDTO.builder().name(dictionaryDTO.getName())
                        .value(dictionaryDTO.getValue()).children(Lists.newArrayList()).build())
                .collect(Collectors.toList());
        //子级节点
        List<TreeNodeViewDTO> childrenDictionaryList = directionList.stream()
                .filter(dictionaryDTO -> dictionaryDTO.getValue().contains("_"))
                .map(dictionaryDTO -> TreeNodeViewDTO.builder().name(dictionaryDTO.getName())
                        .value(dictionaryDTO.getValue()).build())
                .collect(Collectors.toList());

        for (TreeNodeViewDTO treeViewDTO : parentDictionaryList) {
            for (TreeNodeViewDTO children : childrenDictionaryList) {
                if(children.getValue().startsWith(treeViewDTO.getValue()+"_")){
                    treeViewDTO.getChildren().add(children);
                }
            }
        }
        return parentDictionaryList;
    }

    public List<TreeNodeViewDTO> convertToMediaInterestLabelTree(List<CommonViewDTO> firstMediaInterestLabelList, List<CommonViewDTO> mediaInterestLabelList) {
        //父级节点
        List<TreeNodeViewDTO> parentDictionaryList = Lists.newArrayList();
        for (CommonViewDTO firstMediaInterestLabel : firstMediaInterestLabelList) {
            TreeNodeViewDTO parentTreeNodeVO = TreeNodeViewDTO.builder().name(firstMediaInterestLabel.getName())
                    .value(firstMediaInterestLabel.getValue()).children(Lists.newArrayList()).build();
            for (CommonViewDTO dictionaryDTO : mediaInterestLabelList) {
                if(dictionaryDTO.getParentValue().equals(firstMediaInterestLabel.getValue())){
                    parentTreeNodeVO.getChildren().add(TreeNodeViewDTO.builder().name(dictionaryDTO.getName()).value(dictionaryDTO.getValue()).build());
                }
            }
            parentDictionaryList.add(parentTreeNodeVO);
        }
        return parentDictionaryList;
    }

    public List<TreeNodeViewDTO> buildTreeNode(String type, List<CommonViewDTO> dictionaryDTOList) {
        List<TreeNodeViewDTO> result = Lists.newArrayList();
        // 终端特殊处理
        if (ProductDirectionEnum.DEVICE.getType().equals(type) || ProductDirectionEnum.DEVICE_MEDIA.getType().equals(type)) {
            return buildDeviceNode(dictionaryDTOList);
        }
        for (CommonViewDTO dictionaryDTO : dictionaryDTOList) {
            TreeNodeViewDTO nodeModel = new TreeNodeViewDTO();
            nodeModel.setName(dictionaryDTO.getName());
            nodeModel.setValue(dictionaryDTO.getValue());
            nodeModel.setId(dictionaryDTO.getId());
            result.add(nodeModel);
        }
        return result;
    }

    public List<TreeNodeViewDTO> buildDeviceNode(List<CommonViewDTO> dictionaryDTOList) {
        List<TreeNodeViewDTO> result = Lists.newArrayList();
        Map<String, TreeNodeViewDTO> terminalModelMap = new HashMap<>();
        for (CommonViewDTO dictionaryDTO : dictionaryDTOList) {
            String[] valueArr = dictionaryDTO.getValue().split("[_]");
            String[] nameArr = dictionaryDTO.getName().split("[_]");
            // 设备
            if (!terminalModelMap.containsKey(valueArr[0])) {
                TreeNodeViewDTO nodeModel = new TreeNodeViewDTO();
                nodeModel.setValue(valueArr[0]);
                nodeModel.setName(nameArr[0]);
                result.add(nodeModel);
                terminalModelMap.put(nodeModel.getValue(), nodeModel);
            }
            // 操作系统
            if (org.apache.commons.collections.CollectionUtils.isEmpty(terminalModelMap.get(valueArr[0]).getChildren())) {
                terminalModelMap.get(valueArr[0]).setChildren(new ArrayList<>());
            }
            Map<String, TreeNodeViewDTO> osModelMap = terminalModelMap.get(valueArr[0]).getChildren()
                    .stream().collect(Collectors.toMap(TreeNodeViewDTO::getValue, Function.identity()));
            if (!osModelMap.containsKey(valueArr[0] + "_" + valueArr[1])) {
                TreeNodeViewDTO nodeModel = new TreeNodeViewDTO();
                nodeModel.setValue(valueArr[0] + "_" + valueArr[1]);
                nodeModel.setName(nameArr[1]);
                terminalModelMap.get(valueArr[0]).getChildren().add(nodeModel);
                osModelMap.put(nodeModel.getValue(), nodeModel);
            }
            // 应用
            if (org.apache.commons.collections.CollectionUtils.isEmpty(osModelMap.get(valueArr[0] + "_" + valueArr[1]).getChildren())) {
                osModelMap.get(valueArr[0] + "_" + valueArr[1]).setChildren(new ArrayList<>());
            }
            Map<String, TreeNodeViewDTO> appModelMap = osModelMap.get(valueArr[0] + "_" + valueArr[1]).getChildren()
                    .stream().collect(Collectors.toMap(TreeNodeViewDTO::getValue, Function.identity()));
            if (!appModelMap.containsKey(valueArr[0] + "_" + valueArr[1] + "_" + valueArr[2])) {
                TreeNodeViewDTO nodeModel = new TreeNodeViewDTO();
                nodeModel.setValue(valueArr[0] + "_" + valueArr[1] + "_" + valueArr[2]);
                nodeModel.setName(nameArr[2]);
                osModelMap.get(valueArr[0] + "_" + valueArr[1]).getChildren().add(nodeModel);
            }
        }
        return result;
    }
}
