package com.taobao.ad.brand.bp.common.constant;

/**
 * 模板中心新定义的常量类
 *
 * @author duxiaokang
 */
public interface GenerateImageConstant {
    String ITEM_KEY_PRE = "yinheItem.";
    String RESOURCE_ID = "36229252";
    String[] ITEM_KEY = new String[]{"sc_item_img_800_800", "itemDeclaration", "itemTitle8"
            , "sc_item_guide_10"
            , "sc_item_img_brand_logo"
            , "sc_item_title_10"
            , "sc_item_img_800_1200"
            , "sc_item_img_800_800_scene"
            , "sc_item_img_800_800_transparent"
            , "sellPoint2"
            , "sellPoint1"
            , "itemWhiteImg"
    };

    String ENTITYTYPE = "entityType";
    String ITEM = "ITEM";
    String FIELDS = "fields";
    String IDS = "ids";
    Integer BIZ_ID = 20200102;
    String TEMPLATE_KEY = "templates";
    String CHANNEL_KEY = "channelId";
    String METHOD_NAME = "getBpTemplateByItemId";
    String INTERFACE_NAME = "com.taobao.agi.service.openapi.IGetTemplateByItemIdQuery";
    String SILL_YVG_TEMPLATE_ID = "sillyvgTemplateId";
    String ID = "id";
    String AI_GENERATE = "ai_generate";
    String SC_ITEM_IMG = "sc_item_img_800_800_transparent";
    String SC_ITEM_IMG_BRAND_LOGO = "sc_item_img_brand_logo";
    String DISTINCT_ID = "distinctId";
    String SCENE_ID = "scene_id";
    String SCENE_ID_NUM = "0001";
    String PRODUCT_ID = "product_id";
    String ENTITY_TYPE = "entity_type";
    String ENTITY_ID = "entity_id";
    String IMAGES = "images";
    String AI_ITEM_IMAGE_KEY = "新-AI商品图";
    String AI_ITEM_LOGO_KEY = "新-logo图";
    String AI_ITEM_TITLE_KEY = "新-单行商品标题";
    String AI_ITEM_SELL_POINT_KEY = "新-单行长卖点";
    String TEXT = "text";
    String CHANNEL = "channel";
    String TEMPLATE_ID_LIST = "template_id_list";
    String MAIGC_TEMPLATE_ID_LIST = "maigc_template_id_list";
    String EXTRA_INFO = "extra_info";
    String CREATIVES = "creatives";
    String CREATIVE_URL = "creative_url";
    Integer CHANNEL_ID = 261;
}