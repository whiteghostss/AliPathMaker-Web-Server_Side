package com.taobao.ad.brand.bp.common.constant;


/**
 * dmp常量类
 *
 * @author yuncheng.lyc
 */
public class DmpConstant {
    /**
     * dmp分配，租户id
     */
    public static final Long APP_ID = 0L;
    /**
     * dmp分配 跨租户的渠道
     * */
    public static final Long APP_ID_NEW = 151L;

    /**
     * 投放推送渠道id - 品牌1BP（dmp自定义）
     */
    public static final Long DELIVER_APP_ID_BRAND_DMP = 155L;

    /**
     * 投放推送渠道id - 品牌1BP(平台精选)
     * 后续会下线
     */
    public static final Long DELIVER_APP_ID_BRAND_RECOMMEND = 161L;

//    /**
//     * dmp分配，渠道id,品牌1BP渠道
//     */
//    public static final Long ALGO_APP_DELIVER_ID = 155L;

    /**
     * dmp分配，showmax bussinessType
     */
    public static final Integer SHOWMAX_BUSINESS_TYPE = 137;

    /**
     * dmp分配，showmax appId
     */
    public static final Long BRAND_HUB_DMP_APP_ID = 140L;

    /**
     * dmp分配 黑盒算法人群
     */
    public static final Long BRAND_ALGO_DMP_APP_ID = 38L;
    /**
     * dmp分配，品牌tagId (NEW)
     */
    public static final Long BRAND_TAG_ID = 273541L;
    /**
     * dmp分配，品牌optionGroupId (NEW)
     */
    public static final Long BRAND_OPTION_GROUP_ID = 270812L;
//    /**
//     * dmp分配，品牌tagId
//     */
//    public static final Long OLD_BRAND_TAG_ID = 157512L;
//    /**
//     * dmp分配，品牌optionGroupId
//     */
//    public static final Long OLD_BRAND_OPTION_GROUP_ID = 37660L;
    /**
     * dmp分配，行业tagId
     */
    public static final Long CATEGORY_TAG_ID = 157511L;
    /**
     * dmp分配，行业optionGroupId
     */
    public static final Long CATEGORY_OPTION_GROUP_ID = 37659L;
    /**
     * dmp分配，平台精选 appId
     */
    public static final Long RECOMMEND_APP_ID = 19L;

    /**
     * 品牌OB-达摩盘-屏蔽人群
     */
    public static final Long CREATIVE_PREVIEW_DMP_MASK_APP_ID = 172L;
}