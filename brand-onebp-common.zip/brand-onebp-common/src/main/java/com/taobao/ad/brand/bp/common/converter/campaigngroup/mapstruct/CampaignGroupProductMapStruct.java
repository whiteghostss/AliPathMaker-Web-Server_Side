package com.taobao.ad.brand.bp.common.converter.campaigngroup.mapstruct;

import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.DecoratedWith;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/23
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
@DecoratedWith(CampaignGroupProductMapStructDecorator.class)
public interface CampaignGroupProductMapStruct extends BaseMapStructMapper<ResourcePackageProductViewDTO, CampaignGroupProductViewDTO> {
    CampaignGroupProductMapStruct INSTANCE = Mappers.getMapper(CampaignGroupProductMapStruct.class);

    @Mappings({
        @Mapping(source = "id", target = "resourcePackageProductId"),
        @Mapping(source = "saleUnit", target = "registerUnit"),
        @Mapping(source = "castType", target = "."),
    })
    @Override
    CampaignGroupProductViewDTO sourceToTarget(ResourcePackageProductViewDTO resourcePackageProductViewDTO);

    @Mappings({
        @Mapping(source = "resourcePackageProductId", target = "id"),
        @Mapping(source = "registerUnit", target = "saleUnit"),
        @Mapping(source = ".", target = "castType"),
    })
    @Override
    ResourcePackageProductViewDTO targetToSource(CampaignGroupProductViewDTO campaignGroupProductViewDTO);

}