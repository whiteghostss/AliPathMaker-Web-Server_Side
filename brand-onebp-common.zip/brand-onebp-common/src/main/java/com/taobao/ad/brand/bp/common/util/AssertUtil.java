package com.taobao.ad.brand.bp.common.util;

import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.error.ErrorCodeAware;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import java.util.Collection;
import java.util.Map;

public abstract class AssertUtil {

    /**
     * 非空判断
     * @param object
     * @param message
     */
    public static void notNull(Object object, String message) {
        if (object == null) {
            throw new BrandOneBPException(BrandOneBPBaseErrorCode.PARAM_REQUIRED.of(message));
        }
    }

    public static void notNull(Object object) {
        if (object == null) {
            throw new BrandOneBPException(BrandOneBPBaseErrorCode.PARAM_REQUIRED);
        }
    }

    public static void notNull(Object object, ErrorCodeAware errorCodeAware, String message) {
        if (object == null) {
            throw new BrandOneBPException(errorCodeAware,message);
        }
    }

    /**
     * 非空判断
     * @param text    the String to check
     * @param message name
     * @see StringUtils#hasLength
     */
    public static void hasLength(String text, String message) {
        if (!StringUtils.hasLength(text)) {
            throw new BrandOneBPException(BrandOneBPBaseErrorCode.PARAM_REQUIRED.of(message));
        }
    }


    /**
     * 非空判断
     * @param text    the String to check
     * @param message name
     * @see StringUtils#hasText
     */
    public static void hasText(String text, String message) {
        if (!StringUtils.hasText(text)) {
            throw new BrandOneBPException(BrandOneBPBaseErrorCode.PARAM_REQUIRED.of(message));
        }
    }

    /**
     * 文本最大长度判断
     * @param text
     * @param maxLength 最大长度
     * @param message
     */
    public static void maxLength(String text,int maxLength, String message) {
        if (text != null && text.length() > maxLength) {
            throw new BrandOneBPException(BrandOneBPBaseErrorCode.PARAM_BREAK_RULE.of(message));
        }
    }


    /**
     * Assert that an array has elements; that is, it must not be
     * {@code null} and must have at least one element.
     * <pre class="code">Assert.notEmpty(array, "The array must have elements");</pre>
     *
     * @param array   the array to check
     * @param message name
     * @throws BrandOneBPException if the object array is {@code null} or has no elements
     */
    public static void notEmpty(Object[] array, String message) {
        if (ObjectUtils.isEmpty(array)) {
            throw new BrandOneBPException(BrandOneBPBaseErrorCode.PARAM_REQUIRED.of(message));
        }
    }

    /**
     * Assert that an array has no null elements.
     * Note: Does not complain if the array is empty!
     * <pre class="code">Assert.noNullElements(array, "The array must have non-null elements");</pre>
     *
     * @param array   the array to check
     * @param message name
     * @throws BrandOneBPException if the object array contains a {@code null} element
     */
    public static void noNullElements(Object[] array, String message) {
        if (array != null) {
            for (int i = 0; i < array.length; i++) {
                if (array[i] == null) {
                    throw new BrandOneBPException(BrandOneBPBaseErrorCode.PARAM_REQUIRED.of(message));
                }
            }
        }
    }

    /**
     * Assert that a collection has elements; that is, it must not be
     * {@code null} and must have at least one element.
     * <pre class="code">Assert.notEmpty(collection, "Collection must have elements");</pre>
     *
     * @param collection the collection to check
     * @param message    name
     * @throws BrandOneBPException if the collection is {@code null} or has no elements
     */
    public static void notEmpty(Collection collection, String message) {
        if (CollectionUtils.isEmpty(collection)) {
            throw new BrandOneBPException(BrandOneBPBaseErrorCode.PARAM_REQUIRED.of(message));
        }
    }
    public static void isEmpty(Collection collection, String message) {
        if (!CollectionUtils.isEmpty(collection)) {
            throw new BrandOneBPException(BrandOneBPBaseErrorCode.PARAM_REQUIRED.of(message));
        }
    }

    public static void isEmpty(Collection collection, ErrorCodeAware errorCodeAware, String message) {
        if (!CollectionUtils.isEmpty(collection)) {
            throw new BrandOneBPException(errorCodeAware, (message));
        }
    }
    public static void notEmpty(Collection collection,ErrorCodeAware errorCodeAware, String message) {
        if (CollectionUtils.isEmpty(collection)) {
            throw new BrandOneBPException(errorCodeAware,message);
        }
    }

    /**
     * Assert that a Map has entries; that is, it must not be {@code null}
     * and must have at least one entry.
     * <pre class="code">Assert.notEmpty(map, "Map must have entries");</pre>
     *
     * @param map     the map to check
     * @param message name
     * @throws BrandOneBPException if the map is {@code null} or has no entries
     */
    public static void notEmpty(Map map, String message) {
        if (CollectionUtils.isEmpty(map)) {
            throw new BrandOneBPException(BrandOneBPBaseErrorCode.PARAM_REQUIRED.of(message));
        }
    }

    public static void notEmpty(Map map,ErrorCodeAware errorCodeAware, String message) {
        if (CollectionUtils.isEmpty(map)) {
            throw new BrandOneBPException(errorCodeAware,message);
        }
    }

    /**
     * 判断是否为true
     *
     * @param expr
     * @param brandOneBPErrorCode
     * @param extMsg
     */
    public static void assertTrue(boolean expr, BrandOneBPBaseErrorCode brandOneBPErrorCode, String extMsg) {
        if (!expr) {
            throw new BrandOneBPException(brandOneBPErrorCode.of(extMsg));
        }
    }

    /**
     * 判断是否为true
     * @param expr
     * @param codeAware
     */
    public static void assertTrue(boolean expr, ErrorCodeAware codeAware) {
        if (!expr) {
            throw new BrandOneBPException(codeAware);
        }
    }

    /**
     * 判断是否为true
     * @param expr
     * @param codeAware
     * @param message
     */
    public static void assertTrue(boolean expr, ErrorCodeAware codeAware, String message) {
        if (!expr) {
            throw new BrandOneBPException(codeAware, message);
        }
    }

    /**
     * 判断是否为true
     * @param expr
     * @param message
     */
    public static void assertTrue(boolean expr, String message) {
        if (!expr) {
            throw new BrandOneBPException(message);
        }
    }

    /**
     * 判断是否为true
     * @param expr
     * @param args
     */
    public static void assertTrue(boolean expr, String format, Object... args) {
        if (!expr) {
            throw new BrandOneBPException(String.format(format, args));
        }
    }


    /**
     * 判断是否为true
     * @param response
     */
    public static void assertTrue(Response response) {
        if (!response.isSuccess()) {
            throw new BrandOneBPException(response.getErrorCode(), response.getErrorMsg());
        }
    }
}

