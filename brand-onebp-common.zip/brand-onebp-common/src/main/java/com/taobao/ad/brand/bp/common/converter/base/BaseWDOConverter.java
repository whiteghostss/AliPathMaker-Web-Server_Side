package com.taobao.ad.brand.bp.common.converter.base;

import com.alibaba.ad.brand.business.sdk.wdo.base.BaseScenarioWDO;
import com.alibaba.ad.brand.dto.base.BaseViewDTO;

import java.util.List;

/**
 * viewDTO到WDO转换
 * @param <ViewDTO>
 * @param <WDO>
 */
public abstract class BaseWDOConverter<ViewDTO extends BaseViewDTO, WDO extends BaseScenarioWDO> {
    public abstract BaseMapStructMapper<ViewDTO, WDO> getBaseMapStructMapper();

    public WDO convertViewDTO2WDO(ViewDTO source){
        return getBaseMapStructMapper().sourceToTarget(source);
    }

    public ViewDTO convertWDO2ViewDTO(WDO source){
        return getBaseMapStructMapper().targetToSource(source);
    }

    public List<ViewDTO> convertWDOList2ViewDTOList(List<WDO> domainList) {
        return getBaseMapStructMapper().targetToSource(domainList);
    }

    public List<WDO> convertViewDTOList2WDOList(List<ViewDTO> voList) {
        return getBaseMapStructMapper().sourceToTarget(voList);
    }

}