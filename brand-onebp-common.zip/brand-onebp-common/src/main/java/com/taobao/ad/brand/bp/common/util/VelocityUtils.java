package com.taobao.ad.brand.bp.common.util;

import com.alimama.checkchain.client.internal.util.RogerLogger;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.tools.generic.MathTool;
import org.apache.velocity.tools.generic.NumberTool;

import java.io.BufferedWriter;
import java.io.StringWriter;
import java.util.Map;
import java.util.Properties;

/**
 * Created by yeshujun on 2020/04/03.
 */
public class VelocityUtils {

    static {
        try {
            Properties p = new Properties();
            p.put("file.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
            p.setProperty(Velocity.INPUT_ENCODING, "UTF-8");
            p.setProperty(VelocityEngine.RUNTIME_LOG_LOGSYSTEM_CLASS, CustomLogChute.class.getCanonicalName());

            Velocity.init(p);
        } catch (Exception e) {
            RogerLogger.error(e.getMessage(), e);
        }
    }

    public static String merge(String tpl, Map<String, ?> data) {
        try {
            Template template = Velocity.getTemplate(tpl);
            VelocityContext context = new VelocityContext();
            context.put("number", new NumberTool());
            context.put("math", new MathTool());
            if (data != null && !data.isEmpty()) {
                for (Map.Entry<String, ?> entry : data.entrySet()) {
                    context.put(entry.getKey(), entry.getValue());
                }
            }
            StringWriter sw = new StringWriter(1024 * 64);
            BufferedWriter writer = new BufferedWriter(sw);
            template.merge(context, writer);
            writer.close();
            return sw.toString();
        } catch (Exception e) {
            RogerLogger.error(e.getMessage(), e);
            return null;
        }
    }
}

