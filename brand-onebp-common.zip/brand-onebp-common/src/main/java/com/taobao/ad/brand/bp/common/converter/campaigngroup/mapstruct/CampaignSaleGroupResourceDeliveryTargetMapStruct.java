package com.taobao.ad.brand.bp.common.converter.campaigngroup.mapstruct;

import com.alibaba.ad.nb.packages.v2.client.dto.salegroup.SaleGroupDeliveryTargetDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignSaleGroupResourceDeliveryTargetViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.control.DeepClone;
import org.mapstruct.factory.Mappers;

/**
 * 分组资源包优化设置
 * 资源包DTO <-->brand-onebp的viewDTO
 * @author yunhu.myh@taobao.com
 * @date 2023年08月13日
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, mappingControl= DeepClone.class)
public interface CampaignSaleGroupResourceDeliveryTargetMapStruct extends BaseMapStructMapper<CampaignSaleGroupResourceDeliveryTargetViewDTO, SaleGroupDeliveryTargetDTO> {

    CampaignSaleGroupResourceDeliveryTargetMapStruct INSTANCE = Mappers.getMapper(CampaignSaleGroupResourceDeliveryTargetMapStruct.class);


}