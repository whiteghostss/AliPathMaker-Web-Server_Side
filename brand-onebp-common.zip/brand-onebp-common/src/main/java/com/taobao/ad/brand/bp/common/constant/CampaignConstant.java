package com.taobao.ad.brand.bp.common.constant;

import com.alibaba.ad.brand.sdk.constant.audience.field.BrandTargetTypeEnum;
import com.google.common.collect.Lists;

import java.util.List;

/**
 * @author ziying
 */
public class CampaignConstant {

    public static final String MULTI_CROWD = "多人群";

    /**
     * 集采-DSP
     */
    public static final Long JC_DSP = 121507994L;

    /**
     * 集采专属监测 : 同步点击监测、DP监测、ULK监测
     */
    public static List<Integer> JC_PDB_MONITOR= Lists.newArrayList(3,4,5);
    /**
     * 自助场景，单计划金额上限50W
     */
    public static final Long SELF_BUDGET_TOP = 50000000L;

    public static final List<BrandTargetTypeEnum> TX_OPTIMIZE_CROWD_TYPE= Lists.newArrayList(BrandTargetTypeEnum.VISITOR,BrandTargetTypeEnum.SIMILAR_SHOP,BrandTargetTypeEnum.BLACK_TA_CONTROL,BrandTargetTypeEnum.SIMILAR_ITEM,BrandTargetTypeEnum.PREFERENCE_ITEM);
}
