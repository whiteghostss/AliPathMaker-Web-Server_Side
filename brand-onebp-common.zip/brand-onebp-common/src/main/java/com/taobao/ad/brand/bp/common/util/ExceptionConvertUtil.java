package com.taobao.ad.brand.bp.common.util;

import com.alibaba.hermes.framework.business.validator.exception.ValidatorException;
import com.alibaba.hermes.framework.error.ErrorCodeAware;
import com.alibaba.hermes.framework.error.ErrorDetail;
import com.alibaba.solar.common.constants.ErrorCode;
import com.alibaba.solar.common.dto.ErrorDTO;
import com.alibaba.solar.common.exception.BOException;
import com.alibaba.solar.common.exception.SystemException;
import com.google.common.collect.Lists;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import java.util.List;

/**
 * @author wumian
 * @since 2020/11/15 2:21 PM
 */
public class ExceptionConvertUtil {

    public static BOException convert2BOException(Exception e) {

        if(e.getCause() instanceof BOException){

            return  (BOException)e.getCause();
        } else if (e instanceof BOException) {

            return (BOException)e;
        } else if (e instanceof SystemException) {

            ErrorCodeAware errorCodeAware = parseErrorCode((SystemException)e);
            return new BOException(getErrorCode(errorCodeAware.getErrCode()), errorCodeAware.getErrMsg());

        } else if (e instanceof ValidatorException) {

            //抛BO异常给前端展示错误信息
            return new BOException(ErrorCode.INTERNAL_ERROR,
                ((ValidatorException)e).getValidatorError() == null ? "系统异常"
                    : ((ValidatorException)e).getValidatorError().getErrMsg());
        } else {

            //抛BO异常给前端展示错误信息
            return new BOException(ErrorCode.INTERNAL_ERROR, e.getMessage() == null ? "系统异常" : e.getMessage());
        }
    }

    public static ErrorCode getErrorCode(String errorCode) {
        for (ErrorCode code : ErrorCode.values()) {
            if (code.name().equalsIgnoreCase(errorCode)) {
                return code;
            }
        }
        return ErrorCode.INTERNAL_ERROR;
    }

    public static List<ErrorDetail> build(List<ErrorCodeAware> errorCodeAwareList) {
        if (CollectionUtils.isEmpty(errorCodeAwareList)) {
            return null;
        }
        List<ErrorDetail> errorDetailList = Lists.newArrayList();
        errorCodeAwareList.forEach(aware -> {
            errorDetailList.add(ErrorDetail.of(aware.getExtraErrMsg(), aware.getErrCode(), aware.getErrMsg()));
        });
        return errorDetailList;
    }

    public static List<ErrorDetail> convertErrorDTO2ErrorDetail(List<ErrorDTO> errorDTOList) {
        if (CollectionUtils.isEmpty(errorDTOList)) {
            return null;
        }
        List<ErrorDetail> errorDetailList = Lists.newArrayList();
        errorDTOList.forEach(aware -> {
            errorDetailList.add(ErrorDetail.of(aware.getRequest(), aware.getErrorCode().getCodeValue(), aware.getMsg()));
        });
        return errorDetailList;
    }


    private final static String emptyMsgTag = "[]";
    /**
     * 分隔符，隔开messageResource.properties里定义的内部使用的innerMsg和对外透出的msg
     **/
    private final static String MSG_SPLIT_CHAR = "◆";

    public static ErrorCodeAware parseErrorCode(SystemException exception) {
        ErrorCode errorCode = exception.getErrorCode();
        String message;
        if (StringUtils.isNotBlank(exception.getErrorKey())) {
            message = exception.getErrorKey();
        } else {
            message = exception.getMessage();
        }
        if (message.startsWith(errorCode.name())) {
            message = message.substring(errorCode.name().length() + 1);
        }
        if (message.startsWith(errorCode.getCodeValue())) {
            message = message.substring(errorCode.getCodeValue().length() + 1);
        }

        if(message.endsWith(emptyMsgTag)){
            message = message.substring(0,message.length() -2);
        }

        String extraErrMsg = null;
        // messageResource.properties里定义了内部使用的innerMsg和对外透出的msg，
        // Response当前只有一个msg，且对前端透出，先用ResultDTO里的 msg 逻辑，
        // 但是这样会导致 innerMsg 丢失，排查问题不方便
        if (message.contains(MSG_SPLIT_CHAR)) {
            String[] msgs = message.split(MSG_SPLIT_CHAR);
            if (msgs.length == 2) {
                message = msgs[1];
                extraErrMsg = msgs[0];
            }
        }

        return ErrorCodeAware.Builder.build(
            errorCode.name(), message, extraErrMsg
        );
    }


}
