package com.taobao.ad.brand.bp.common.util;

import org.apache.commons.lang.StringUtils;

/**
 * @author yanjingang
 * @date 2023/3/20
 */
public class EmpUtil {

    /**
     * 工号长度小于6位数，补零
     * @param empId 原工号
     * @return 标准化工号
     */
    public static String standardizeEmpNo(String empId) {
        try {
            return  String.format("%06d", Integer.parseInt(empId));
        } catch (NumberFormatException e) {
            //外包工号
            return empId;
        }
    }

    /**
     * 根据审批工作流返回的用户员工号格式化：<br>
     * 员工号为6位并且首位为0时，删除前面的0，返回首位非0的员工号
     * @param empId
     * @return
     */
    public static String getShortEmpId(String empId) {
        if (StringUtils.isBlank(empId)) {
            return "";
        }

        if(empId.length() == 6 && empId.startsWith("0")) {
            char[] empIdArray = empId.toCharArray();
            int len = empIdArray.length;
            int st = 0;
            while ((st < len) && (empIdArray[st] <= '0')) {
                st++;
            }
            empId = empId.substring(st, len);
        }
        return empId;
    }
}
