package com.taobao.ad.brand.bp.common.statemachine;

import com.alibaba.cola.statemachine.StateMachine;

/**
 * @author yanjingang
 * @date 2023/3/7
 */
public interface BrandStateMachine<S, E, C> extends StateMachine<S, E, C> {

    boolean canAccept(S s, E e, C c);
}
