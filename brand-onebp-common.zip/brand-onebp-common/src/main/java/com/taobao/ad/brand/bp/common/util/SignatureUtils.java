package com.taobao.ad.brand.bp.common.util;

import com.alimama.checkchain.client.internal.util.RogerLogger;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;

import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * 加解密工具类
 */
public class SignatureUtils {

    /**
     * AES加密时的秘钥
     */
    private final static String AES_KEY = "8200a90fbea24f1e";

    public final static String salt = "s230sdflx*&(^xx";


    /**
     * 用来将字节转换成 16 进制表示的字符
     */
    private static final char hexDigits[] = {
            '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e',
            'f'};

    /**
     * AES 128 ECB加密
     *
     * @param content
     * @return
     */
    public static final String encryptAes128EcbSafeBase64String(String content) {
        if (StringUtils.isBlank(content)) {
            return null;
        }

        try {
            // 生成一个秘钥
            SecretKey secretKey = new SecretKeySpec(AES_KEY.getBytes(StandardCharsets.UTF_8), "AES");
            // 创建AES密码器
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            // 将文本进行utf-8的编码
            byte[] byteContent = content.getBytes(StandardCharsets.UTF_8);
            // 初始化AES密码器为加密器
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            // 进行AES加密
            byte[] result = cipher.doFinal(byteContent);
            return Base64.encodeBase64URLSafeString(result);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | IllegalBlockSizeException |
                 BadPaddingException e) {
            RogerLogger.error("ase 128 ecb hex error {}", e.getMessage(), e);
        }
        return null;
    }

    /**
     * AES 128 ECB解密
     *
     * @param content
     * @return
     */
    public static final String decryptAes128EcbSafeBase64String(String content) {
        if (StringUtils.isBlank(content)) {
            return null;
        }

        try {
            // 生成一个秘钥
            SecretKey secretKey = new SecretKeySpec(AES_KEY.getBytes(StandardCharsets.UTF_8), "AES");
            // 创建AES密码器
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            // 将文本进行utf-8的编码
            byte[] byteContent = Base64.decodeBase64(content.getBytes(StandardCharsets.UTF_8));
            // 初始化AES密码器为加密器
            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            // 进行AES加密
            byte[] result = cipher.doFinal(byteContent);
            return new String(result, StandardCharsets.UTF_8);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | IllegalBlockSizeException |
                 BadPaddingException e) {
            RogerLogger.error("ase 128 ecb hex error {}", e.getMessage(), e);
        }
        return null;
    }

    public static String getMD5(byte[] source) {
        String result = null;
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(source);
            // MD5 的计算结果是一个 128 位的长整数，
            byte tmp[] = md.digest();
            // 用字节表示就是 16 个字节
            // 每个字节用 16 进制表示的话，使用两个字符，
            char str[] = new char[16 * 2];
            // 所以表示成 16 进制需要 32 个字符 // 表示转换结果中对应的字符位置
            int k = 0;
            for (int i = 0; i < 16; i++) {
                // 从第一个字节开始，对 MD5 的每一个字节
                // 转换成 16 进制字符的转换
                // 取第 i 个字节
                byte byte0 = tmp[i];
                // 取字节中高 4 位的数字转换,
                // >>>
                // 为逻辑右移，将符号位一起右移
                str[k++] = hexDigits[byte0 >>> 4 & 0xf];
                // 取字节中低 4 位的数字转换
                str[k++] = hexDigits[byte0 & 0xf];
            }
            // 换后的结果转换为字符串
            result = new String(str);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    public static String getMd5Hex(String buf) {
        try {
            MessageDigest digist = MessageDigest.getInstance("MD5");
            byte[] rs = digist.digest(buf.getBytes("UTF-8"));
            StringBuffer digestHexStr = new StringBuffer();
            for (int i = 0; i < 16; i++) {
                digestHexStr.append(byteHEX(rs[i]));
            }
            return digestHexStr.toString();
        } catch (Exception e) {
        }
        return null;

    }

    private static String byteHEX(byte ib) {
        char[] ob = new char[2];
        ob[0] = hexDigits[(ib >>> 4) & 0X0F];
        ob[1] = hexDigits[ib & 0X0F];
        String s = new String(ob);
        return s;
    }

    public static void main(String[] args) {
        System.out.println(encryptAes128EcbSafeBase64String("11111111"));
        System.out.println(decryptAes128EcbSafeBase64String("O_PX0uaur9Gwy_ZCaDf9Kg"));
    }

}
