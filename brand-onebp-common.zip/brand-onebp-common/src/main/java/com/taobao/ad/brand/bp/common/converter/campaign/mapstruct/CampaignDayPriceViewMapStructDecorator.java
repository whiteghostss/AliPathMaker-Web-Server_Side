package com.taobao.ad.brand.bp.common.converter.campaign.mapstruct;

import com.taobao.ad.brand.bp.client.dto.campaign.CampaignDayPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductPriceViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignProductPriceTypeEnum;

/**
 * @author ximu.cly
 * @date 2021/4/17
 */
public abstract class CampaignDayPriceViewMapStructDecorator implements CampaignDayPriceViewMapStruct {

    private final CampaignDayPriceViewMapStruct campaignDayPriceViewMapStruct;

    public CampaignDayPriceViewMapStructDecorator(CampaignDayPriceViewMapStruct campaignDayPriceViewMapStruct) {
        this.campaignDayPriceViewMapStruct = campaignDayPriceViewMapStruct;
    }

    @Override
    public CampaignDayPriceViewDTO sourceToTarget(ResourcePackageProductPriceViewDTO resourcePackageProductPriceViewDTO) {
        CampaignDayPriceViewDTO campaignDayPriceViewDTO = campaignDayPriceViewMapStruct.sourceToTarget(resourcePackageProductPriceViewDTO);
        if (CampaignProductPriceTypeEnum.MIN_RATE.isSelf(resourcePackageProductPriceViewDTO.getType())) {
            campaignDayPriceViewDTO.setMinBudgetRatio(resourcePackageProductPriceViewDTO.getMinRatio());
        } else if (CampaignProductPriceTypeEnum.FIXED_AMOUNT.isSelf(resourcePackageProductPriceViewDTO.getType())) {
            campaignDayPriceViewDTO.setFixedBudget(resourcePackageProductPriceViewDTO.getCastAmount());
        } else if (CampaignProductPriceTypeEnum.START_AMOUNT.isSelf(resourcePackageProductPriceViewDTO.getType())) {
            campaignDayPriceViewDTO.setMinCastBudget(resourcePackageProductPriceViewDTO.getCastAmount());
        }
        return campaignDayPriceViewDTO;
    }

    @Override
    public ResourcePackageProductPriceViewDTO targetToSource(CampaignDayPriceViewDTO campaignDayPriceViewDTO) {
        ResourcePackageProductPriceViewDTO resourcePackageProductPriceViewDTO = campaignDayPriceViewMapStruct.targetToSource(campaignDayPriceViewDTO);
        if (CampaignProductPriceTypeEnum.MIN_RATE.isSelf(campaignDayPriceViewDTO.getBudgetAssignMode())) {
            resourcePackageProductPriceViewDTO.setMinRatio(campaignDayPriceViewDTO.getMinBudgetRatio());
        } else if (CampaignProductPriceTypeEnum.FIXED_AMOUNT.isSelf(campaignDayPriceViewDTO.getBudgetAssignMode())) {
            resourcePackageProductPriceViewDTO.setCastAmount(campaignDayPriceViewDTO.getFixedBudget());
        } else if (CampaignProductPriceTypeEnum.START_AMOUNT.isSelf(campaignDayPriceViewDTO.getBudgetAssignMode())) {
            resourcePackageProductPriceViewDTO.setCastAmount(campaignDayPriceViewDTO.getMinCastBudget());
        }
        return resourcePackageProductPriceViewDTO;
    }
}
