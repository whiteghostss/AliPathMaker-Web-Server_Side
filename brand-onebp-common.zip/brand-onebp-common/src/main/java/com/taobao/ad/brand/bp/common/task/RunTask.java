package com.taobao.ad.brand.bp.common.task;

import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.eagleeye.EagleEye;
import com.taobao.eagleeye.RpcContext_inner;

public abstract class RunTask implements Runnable {
    private RpcContext_inner rpcContext;

    public RunTask() {
        rpcContext = EagleEye.getRpcContext();
    }

    @Override
    public void run() {
        EagleEye.setRpcContext(rpcContext);
        try {
            doRun();
        } catch (Throwable e) {
            RogerLogger.error("task run error",e);
            throw e;
        }
    }

    public abstract void doRun();
}