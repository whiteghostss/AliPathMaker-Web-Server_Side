package com.taobao.ad.brand.bp.common.converter.base;

import org.mapstruct.InheritConfiguration;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.MapperConfig;
import org.mapstruct.Mappings;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Description: mapstruct类型转换基类
 */
@MapperConfig
public interface TestMapStructMapper<SOURCE, TARGET> {

    /**
     * 映射同名属性
     */
    @Mappings({})
    TARGET sourceToTarget(SOURCE source);

    /**
     * 反向，映射同名属性
     */
    @InheritInverseConfiguration(name = "sourceToTarget")
    SOURCE targetToSource(TARGET target);

    /**
     * 映射同名属性，集合形式
     */
    @InheritConfiguration(name = "sourceToTarget")
    default List<TARGET> sourceToTarget(List<SOURCE> sources){
        if(sources == null){
            return new ArrayList<>();
        }
        return sources.stream().map(this::sourceToTarget).collect(Collectors.toList());
    }

    /**
     * 反向，映射同名属性，集合形式
     */
    @InheritInverseConfiguration(name = "targetToSource")
    default List<SOURCE> targetToSource(List<TARGET> targets){
        if(targets == null){
            return Collections.emptyList();
        }

        return targets.stream().map(this::targetToSource).collect(Collectors.toList());
    }
}
