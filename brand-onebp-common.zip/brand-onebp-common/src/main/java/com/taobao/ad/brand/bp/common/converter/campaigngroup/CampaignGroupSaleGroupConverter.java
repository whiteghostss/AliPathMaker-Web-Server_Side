package com.taobao.ad.brand.bp.common.converter.campaigngroup;

import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupPageViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import com.taobao.ad.brand.bp.common.converter.campaigngroup.mapstruct.CampaignGroupSaleGroupMapStruct;
import org.springframework.stereotype.Component;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/25
 */
@Component
public class CampaignGroupSaleGroupConverter extends BaseViewDTOConverter<ResourcePackageSaleGroupViewDTO, CampaignGroupSaleGroupPageViewDTO> {

    @Override
    public BaseMapStructMapper<ResourcePackageSaleGroupViewDTO, CampaignGroupSaleGroupPageViewDTO> getBaseMapStructMapper() {
        return CampaignGroupSaleGroupMapStruct.INSTANCE;
    }

}
