package com.taobao.ad.brand.bp.common.enums.creative;

import lombok.Getter;

import java.util.Arrays;

/**
 * Description:审核媒体memberId
 * <p>
 * date: 2022/1/12 12:15 上午
 * @author shiyan
 * @version 1.0
 */
@Getter
public enum CreativeAuditMediaEnum {
    WEIBO(26632537L,"微博"),
    VIVO(26632438L,"vivo"),
    HUAWEI(26632846L,"华为"),
    OPPO(26632523L,"oppo"),
    KUAISHOU(26632557L,"快手"),
    TENCENT(26632356L,"腾讯"),
    BILIBILI(26632801L,"bilibili哔哩哔哩"),
    DOOH(6284269215L, "天攻")


    ;
    Long value;
    String name;

    CreativeAuditMediaEnum(Long value, String name) {
        this.value = value;
        this.name = name;
    }

    public static CreativeAuditMediaEnum getByValue(Long memberId){
        if(memberId == null){
            return null;
        }
        return Arrays.stream(CreativeAuditMediaEnum.values()).filter(mediaEnum -> mediaEnum.getValue().equals(memberId))
                .findFirst().orElse(null);
    }
}
