package com.taobao.ad.brand.bp.common.util;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2023/6/20
 **/
public class CalculateUtil {

    /**
     * 加法计算
     * @param price
     * @param amount
     * @return
     */
    public static Long addCalculate(Long price, Long amount) {
        BigDecimal retAmount = new BigDecimal(price).add(new BigDecimal(amount));
        return retAmount.longValue();
    }

    /**
     * 乘法计算
     *
     * @param left
     * @param right
     * @param roundingMode
     * @return
     */
    public static Long multiplyCalculate(Long left, Long right, Long scale, RoundingMode roundingMode) {
        BigDecimal retAmount = new BigDecimal(left).multiply(new BigDecimal(right)).divide(new BigDecimal(scale), 0, roundingMode);
        return retAmount.longValue();
    }

    /**
     * 除法计算
     * @param dividend
     * @param divisor
     * @return
     */
    public static Long divideCalculate(Long dividend, Long divisor, Long scale) {
        BigDecimal retAmount = new BigDecimal(dividend).divide(new BigDecimal(divisor), 4, RoundingMode.DOWN).multiply(new BigDecimal(scale));;
        return retAmount.longValue();
    }
}
