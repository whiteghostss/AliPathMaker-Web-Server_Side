package com.taobao.ad.brand.bp.common.enums.distlock;

/**
 * @author 虫洞 <liuming.liu@alibaba-inc.com>
 * @date 2023/3/6
 */
public enum DistLockEnum {
    SALE_GROUP_CALCULATE_KEY("CALCULATE_SALE_GROUP_%s", "%s_%s",300,"订单计算场景_saleGroupId"),
    CAMPAIGN_BATCH_IMPORT_KEY("CAMPAIGN_BATCH_IMPORT-%s-%s", "%s",600,"计划批量导入-saleGroupId-campaignGroupId"),
    ADGROUP_BATCH_IMPORT_MONITOR_KEY("ADGROUP_BATCH_IMPORT_MONITOR-%s", "%s",600,"单元批量导入-campaignGroupId"),
    CREATIVE_BATCH_UPDATE_KEY("CREATIVE_BATCH_UPDATE-%s", "%s",600,"创意批量编辑-memberId"),
    CAMPAIGN_BOOKING_AMOUNT_BATCH_IMPORT_KEY("CAMPAIGN_BOOKING_AMOUNT_BATCH_IMPORT-%s", "%s",600,"计划预订量批量导入-campaignGroupId"),
    CAMPAIGN_LOCKING_KEY("CAMPAIGN_LOCKING-%s", "%s",120,"计划锁量-campaignId"),
    ;

    private final String key;
    private final String value;
    private final Integer expireTime;
    private final String desc;

    DistLockEnum(String key, String value, Integer expireTime, String desc) {
        this.key = key;
        this.value = value;
        this.expireTime = expireTime;
        this.desc = desc;
    }

    public String getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }

    public Integer getExpireTime() {
        return expireTime;
    }

    public String getDesc() {
        return desc;
    }

    /**
     * 格式化key
     * @param args
     * @return
     */
    public String formatLockKey(Object... args){
        return String.format(getKey(),args);
    }

    /**
     * 格式化值
     * @param args
     * @return
     */
    public String formatLockValue(Object... args){
        return String.format(getValue(),args);
    }
}