package com.taobao.ad.brand.bp.common.helper.creative;

import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.brand.sdk.constant.creative.field.*;
import com.alibaba.ad.nb.ssp.constant.template.ElementTypeEnum;
import com.alibaba.ad.nb.ssp.constant.template.TemplateApprovalTypeEnum;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import org.apache.commons.lang.StringUtils;

import java.util.*;

/**
 * Description:创意业务域工具类
 * <p>
 * date: 2023/11/9 7:53 PM
 *
 * @author shiyan
 * @version 1.0
 */
public class BizCreativeToolsHelper {
    /**
     * 创意单次查询最大数量
     */
    public final static int MAX_PAGE_COUNT = 2000;
    /**
     * 拓版聚合元素类型
     */
    private final static Set<String> EXTEND_ELEMENT_TYPE_ENUMS = Sets.newHashSet(ElementTypeEnum.VISUAL_IMAGE_EXTEND.getCode(),
            ElementTypeEnum.IMAGE_EXTEND.getCode(), ElementTypeEnum.VIDEO_EXTEND.getCode());

    public final static List<Integer> templateNeedApprovalTypeList =
            Lists.newArrayList(TemplateApprovalTypeEnum.APPROVAL_TYPE_DONG_HAI.getCode(), TemplateApprovalTypeEnum.APPROVAL_TYPE_API.getCode());

    /**
     * 创意是否推审媒体
     * @param showAuditStatus
     * @return
     */
    public static boolean hasPushMedia(Integer showAuditStatus){
        Set<Integer> creativeMediaAuditStatus = Sets.newHashSet(BrandCreativeShowAuditStatusEnum.CREATIVE_MEDIA_AUDIT_WAITING.getCode(),
                BrandCreativeShowAuditStatusEnum.CREATIVE_MEDIA_AUDIT_REFUSE.getCode(),
                BrandCreativeShowAuditStatusEnum.AUDIT_PASS.getCode());
        return creativeMediaAuditStatus.contains(showAuditStatus);
    }

    /**
     * 是否媒体直投子创意
     * @param creativeViewDTO
     * @return
     */
    public static boolean isCrossDirectSubCreative(CreativeViewDTO creativeViewDTO){
        return BrandCreativePackageTypeEnum.COMMON.getValue().equals(creativeViewDTO.getPackageType())
            && !Objects.equals(creativeViewDTO.getId(),creativeViewDTO.getCreativePackageId())
            && Objects.equals(BrandCreativeTargetTypeEnum.DIRECT.getCode(),creativeViewDTO.getTargetType());
    }

    public static String creativeMessage(List<CreativeViewDTO> creativeViewDTOList){
        String formatString = "(%s:%s)";
        List<String> messageList = Lists.newArrayList();
        creativeViewDTOList.stream().forEach(t->{
            messageList.add(String.format(formatString,t.getId(),t.getName()));
        });
        return StringUtils.join(messageList,",");
    }

    public static String dateCreateMessage(Map<Date,List<CreativeViewDTO>> map){
        String formatString = "%s日期，创意%s";
        List<String> messageList = Lists.newArrayList();
        map.entrySet().forEach(t->{

            messageList.add(String.format(formatString, BrandDateUtil.date2String(t.getKey()), BizCreativeToolsHelper.creativeMessage(t.getValue())));

        });
        return StringUtils.join(messageList,",");
    }

    /**
     * 是否子创意
     * @param creativeViewDTO
     * @return
     */
    public static Boolean isSubCreative(CreativeViewDTO creativeViewDTO) {
        if (Objects.isNull(creativeViewDTO.getId())) {
            return Objects.nonNull(creativeViewDTO.getCreativePackageId());
        } else {
            return Objects.nonNull(creativeViewDTO.getCreativePackageId()) &&
                    !creativeViewDTO.getCreativePackageId().equals(creativeViewDTO.getId());
        }
    }

    /**
     * 是否静态创意
     * @param creativeViewDTO
     * @return
     */
    public static Boolean isStaticCreative(CreativeViewDTO creativeViewDTO){
        Integer creativeSource = Optional.ofNullable(creativeViewDTO.getCreativeSource()).orElse(BrandCreativeSourceEnum.STATIC_CREATIVE.getCode());
        return BrandCreativeSourceEnum.STATIC_CREATIVE.getCode().equals(creativeSource);
    }

    /**
     * 是否是拓版元素
     * @param elementType
     * @return
     */
    public static boolean isExtendElement(String elementType){
        return EXTEND_ELEMENT_TYPE_ENUMS.contains(elementType);
    }
}
