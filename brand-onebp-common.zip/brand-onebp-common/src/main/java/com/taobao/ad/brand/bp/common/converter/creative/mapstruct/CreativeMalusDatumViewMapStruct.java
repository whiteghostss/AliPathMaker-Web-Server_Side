package com.taobao.ad.brand.bp.common.converter.creative.mapstruct;

import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeSaveViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface CreativeMalusDatumViewMapStruct extends BaseMapStructMapper<CreativeViewDTO, CreativeSaveViewDTO> {

    CreativeMalusDatumViewMapStruct INSTANCE = Mappers.getMapper(CreativeMalusDatumViewMapStruct.class);

}
