package com.taobao.ad.brand.bp.common.util;

import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;

/**
 * @author ximu.cly
 * @date 2020/12/5
 */
public class PageRequestUtil {

    /**
     * 分页执行
     * @param func 执行方法
     * @param hasNext 分页判断
     * @param consumer 消费
     * @param <R>
     */
    public static <R> void execute(Function<Integer, R> func, BiFunction<Integer, R, Boolean> hasNext, Consumer<R> consumer) {
        R r;
        int idx = 1;
        do {
            r = func.apply(idx);
            consumer.accept(r);
            idx++;
        } while (hasNext.apply(idx, r));
    }

    /**
     * 分页执行
     * @param func 执行方法
     * @param hasNext 分页判断
     * @param consumer 消费
     * @param <R>
     */
    public static <R> void execute(Function<Integer, R> func, BiFunction<Integer, R, Boolean> hasNext, Function<R, Boolean> canConsumer, Consumer<R> consumer) {
        R r;
        int idx = 1;
        do {
            r = func.apply(idx);
            if (canConsumer.apply(r)) {
                consumer.accept(r);
            }
            idx++;
        } while (hasNext.apply(idx, r));
    }

    /**
     * 分页请求
     * @param func
     * @param page
     * @param consumer
     * @param <R>
     */
    public static <R> void execute(Function<Integer, R> func, Function<R, Integer> page, Consumer<R> consumer) {
        R r;
        int idx = 1;
        do {
            try {
                r = func.apply(idx);
            } catch (Throwable e) {
                break;
            }
            int totalPage = page.apply(r);
            consumer.accept(r);
            if (idx >= totalPage) {
                break;
            }
            idx++;
        } while (true);
    }

    public static int getTotalPage(int total, int pageSize) {
        return total / pageSize + (total % pageSize == 0 ? 0 : 1);
    }
}
