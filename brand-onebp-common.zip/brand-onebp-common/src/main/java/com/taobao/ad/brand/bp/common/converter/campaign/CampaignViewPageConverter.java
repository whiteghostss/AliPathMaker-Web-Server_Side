package com.taobao.ad.brand.bp.common.converter.campaign;

import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.budget.CampaignBudgetViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryLockViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryViewDTO;
import com.alibaba.ad.brand.dto.campaign.price.CampaignPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignDayPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignPageViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignScheduleViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductPriceViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import com.taobao.ad.brand.bp.common.converter.campaign.mapstruct.*;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author yuanxinxi
 */
@Component
public class CampaignViewPageConverter extends BaseViewDTOConverter<CampaignViewDTO, CampaignPageViewDTO> {

    @Override
    public BaseMapStructMapper<CampaignViewDTO, CampaignPageViewDTO> getBaseMapStructMapper() {
        return CampaignViewPageMapStruct.INSTANCE;
    }

    public CampaignViewDTO convertSelf(CampaignViewDTO source){
        return  CampaignViewMapStruct.INSTANCE.copySelf(source);
    }

    public List<CampaignViewDTO> convertCampaignSelf(List<CampaignViewDTO> sourceList) {
        return sourceList.stream().map(this::convertSelf).collect(Collectors.toList());
    }

    public CampaignCrowdViewDTO convertCampaignCrowdSelf(CampaignCrowdViewDTO source){
        return  CampaignCrowdViewMapStruct.INSTANCE.copySelf(source);
    }

    public List<CampaignCrowdViewDTO> convertCampaignCrowdSelf(List<CampaignCrowdViewDTO> sourceList) {
        return CampaignCrowdViewMapStruct.INSTANCE.copySelf(sourceList);
    }

    public List<CampaignInquiryViewDTO> convertInquiryView2InquiryViewDTO(List<CampaignInquiryViewDTO> inquiryViewDTOList) {
        return CampaignInquiryViewMapStruct.INSTANCE.sourceToTarget(inquiryViewDTOList);
    }

    public List<CampaignScheduleViewDTO> convertView2ScheduleViewDTOList(List<CampaignViewDTO> campaignViewDTOList) {
        return CampaignScheduleViewMapStruct.INSTANCE.sourceToTarget(campaignViewDTOList);
    }

    public CampaignViewDTO convertScheduleViewDTO2View(CampaignScheduleViewDTO campaignScheduleViewDTOList) {
        return CampaignScheduleViewMapStruct.INSTANCE.targetToSource(campaignScheduleViewDTOList);
    }

    public CampaignScheduleViewDTO convertView2ScheduleViewDTO(CampaignViewDTO campaignViewDTO) {
        return CampaignScheduleViewMapStruct.INSTANCE.sourceToTarget(campaignViewDTO);
    }

    public CampaignDayPriceViewDTO convertProductPrice2DayPriceViewDTO(ResourcePackageProductPriceViewDTO resourcePackageProductPriceViewDTO) {
        return CampaignDayPriceViewMapStruct.INSTANCE.sourceToTarget(resourcePackageProductPriceViewDTO);
    }

    public CampaignPriceViewDTO convertPriceView2PriceViewDTO(CampaignPriceViewDTO campaignPriceViewDTO) {
        return CampaignPriceViewMapStruct.INSTANCE.copySelf(campaignPriceViewDTO);
    }

    public CampaignBudgetViewDTO convertBudgetView2BudgetViewDTO(CampaignBudgetViewDTO campaignBudgetViewDTO) {
        return CampaignBudgetViewMapStruct.INSTANCE.copySelf(campaignBudgetViewDTO);
    }

    public CampaignInquiryLockViewDTO convertInquiryLockView2InquiryLockViewDTO(CampaignInquiryLockViewDTO campaignInquiryLockViewDTO) {
        return CampaignInquiryLockViewMapStruct.INSTANCE.sourceToTarget(campaignInquiryLockViewDTO);
    }
}

