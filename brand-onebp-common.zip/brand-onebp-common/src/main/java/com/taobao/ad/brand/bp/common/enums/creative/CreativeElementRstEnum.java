package com.taobao.ad.brand.bp.common.enums.creative;

import com.google.common.collect.Maps;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Map;

/**
 * 元素类型枚举值(引擎使用)
 *
 * @author duxiaokang
 */
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@Getter
public enum CreativeElementRstEnum {

    IMAGE("image", "1", "图片"),

    VIDEO("video", "2", "视频"),

    H5("h5", "3", "H5"),

    ZIP("zip", "4", "ZIP"),

    ;

    /**
     * BP侧的枚举值
     */
    private final String type;

    /**
     * BYE侧的枚举值
     */
    private final String engineValue;

    /**
     * 描述
     */
    private final String desc;

    private static final Map<String, String> TYPE_MAP = Maps.newHashMap();

    static {
        for (CreativeElementRstEnum e : CreativeElementRstEnum.values()) {
            TYPE_MAP.put(e.getType(), e.getEngineValue());
        }
    }

    /**
     * 查询引擎的类型你给值
     *
     * @param type bp的值
     * @return 结果
     */
    public static String getEngineValue(String type) {
        return TYPE_MAP.get(type);
    }
}
