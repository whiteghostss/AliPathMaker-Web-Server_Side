package com.taobao.ad.brand.bp.common.converter.creative;

import com.alibaba.ad.brand.dto.creative.preview.CreativePreviewViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.brand.dto.creative.audit.AuditViewDTO;
import com.alibaba.ad.brand.dto.creative.audit.MamaAuditViewDTO;
import com.alibaba.ad.brand.dto.creative.ext.CreativeExtViewDTO;
import com.alibaba.ad.brand.dto.creative.template.CreativeTemplateViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandAdReviewTypeEnum;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativeShowAuditStatusEnum;
import com.alibaba.fastjson.JSON;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeSaveViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import com.taobao.ad.brand.bp.common.converter.creative.mapstruct.CreativeMalusDatumViewMapStruct;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Objects;

/**
 * @author shiyan
 * @date 2024/1/8
 */
@Component
public class CreativeMalusDatumViewConverter extends BaseViewDTOConverter<CreativeViewDTO, CreativeSaveViewDTO> {

    @Override
    public BaseMapStructMapper<CreativeViewDTO, CreativeSaveViewDTO> getBaseMapStructMapper() {
        return CreativeMalusDatumViewMapStruct.INSTANCE;
    }

    @Override
    public CreativeViewDTO convertViewDTO2DTO(CreativeSaveViewDTO malusDatumViewDTO) {
        CreativeViewDTO creativeViewDTO = super.convertViewDTO2DTO(malusDatumViewDTO);
        creativeViewDTO.setCreativeTemplate(new CreativeTemplateViewDTO());
        if (StringUtils.isNotBlank(malusDatumViewDTO.getPreviewSettings())) {
            creativeViewDTO.setCreativePreviewView(JSON.parseObject(malusDatumViewDTO.getPreviewSettings(), CreativePreviewViewDTO.class));
        }
        if (!BrandBoolEnum.BRAND_TRUE.getCode().equals(malusDatumViewDTO.getAccurateTime()) && Objects.nonNull(creativeViewDTO.getEndTime())) {
            creativeViewDTO.setEndTime(BrandDateUtil.getDateFullMidnight(creativeViewDTO.getEndTime()));
        }
        AuditViewDTO auditViewDTO = new AuditViewDTO();
        auditViewDTO.setShowAuditStatus(BrandCreativeShowAuditStatusEnum.CREATIVE_CENTER_WAITING.getCode());
        MamaAuditViewDTO mamaAuditViewDTO = new MamaAuditViewDTO();
        mamaAuditViewDTO.setIsTop(malusDatumViewDTO.getIsTop());
        mamaAuditViewDTO.setIsTopShowWhiteCustomer(malusDatumViewDTO.getIsTopShowWhiteCustomer());
        mamaAuditViewDTO.setAdReviewType(malusDatumViewDTO.getAdReviewType());
        boolean isWhiteCustomerTopShow = BrandBoolEnum.BRAND_TRUE.getCode().equals(malusDatumViewDTO.getIsTopShowWhiteCustomer())
                && BrandAdReviewTypeEnum.TOPSHOW.getValue().equals(malusDatumViewDTO.getAdReviewType());
        if (BrandBoolEnum.BRAND_TRUE.getCode().equals(malusDatumViewDTO.getIsTop()) || isWhiteCustomerTopShow) {
            auditViewDTO.setShowAuditStatus(BrandCreativeShowAuditStatusEnum.OM_WAITING.getCode());
        }
        auditViewDTO.setMamaAudit(mamaAuditViewDTO);
        creativeViewDTO.setCreativeAudit(auditViewDTO);
        CreativeExtViewDTO extViewDTO = new CreativeExtViewDTO();
        if (Objects.nonNull(malusDatumViewDTO.getTagId())) {
            extViewDTO.setCreativeTagId(malusDatumViewDTO.getTagId());
        }
        if(CollectionUtils.isNotEmpty(malusDatumViewDTO.getQualificationTypeList())){
            auditViewDTO.setQualificationTypeList(malusDatumViewDTO.getQualificationTypeList());
        }
        creativeViewDTO.setExtViewDTO(extViewDTO);
        return creativeViewDTO;
    }
}
