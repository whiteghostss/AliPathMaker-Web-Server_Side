package com.taobao.ad.brand.bp.common.enums;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/03/21
 */
public enum InquiryErrorTypeEnum {

    RELEASE_CAMPAIGN_GROUP_STATUS_ERROR(1, "订单非草稿、非改单配置状态不可释量"),
    RELEASE_CAMPAIGN_STATUS_ERROR(2, "计划未锁量不可释量"),
    RELEASE_SALE_GROUP_STATUS_ERROR(3, "订单分组不可改不可释量"),
    RELEASE_CAMPAIGN_DEFAULT_TIP(4, "释量后，计划(%s)锁定预定量将会被释放，您是否确认要对计划进行释量？"),
    INQUIRY_CAMPAIGN_DEFAULT_TIP(5, "计划(%s)已开始询量中"),
    LOCK_CAMPAIGN_DEFAULT_TIP(6, "计划(%s)已开始锁量中"),
    INQUIRY_CAMPAIGN_BUDGET_ERROR(7, "计划预定量不足,需重新计算分配预算"),

    INQUIRY_CAMPAIGN_STATUS_ERROR(8, "计划状态不允许操作"),
    MEDIA_INQUIRY_CAMPAIGN_STATUS_ERROR(9, "只有询锁量失败的计划才可媒体询量"),
    MEDIA_INQUIRY_CAMPAIGN_SCOPE_ERROR(10, "只有三环子计划才可媒体询量"),
    MANDATORY_LOCK_CAMPAIGN_STATUS_ERROR(11, "只有询锁量失败的计划才可超接"),
    MANDATORY_LOCK_CAMPAIGN_SCOPE_ERROR(12, "只有二环子计划才可超接"),
    OPERATE_CAMPAIGN_DATE_ERROR(13, "仅未来日期才可询锁释量"),
    CAMPAIGN_AMOUNT_LACK_ERROR(14, "计划预定量不足以分到每一天，需指定具体每天的量"),
    CAMPAIGN_CPT_ROUND_ERROR(15, "CPT计划需指定预定量"),
    TAO_OUT_CAMPAIGN_CPT_NOT_SUPPORT_ERROR(16, "二环暂不支持CPT"),
    CAMPAIGN_NOT_FUTURE_INQUIRY_ERROR(17, "勾选的计划中没有可以释放的库存"),
    CAMPAIGN_HISTORY_UNLOCK_BOOKING_AMOUNT_ERROR(18, "计划存在历史未锁预定量，请重新分配该预定量"),
    MANDATORY_LOCK_NOT_SUPPORT_BOOST_ERROR(19, "媒体询量不支持补量计划"),
    MANDATORY_LOCK_NOT_SUPPORT_HOLDER_ERROR(20, "品牌占位计划不支持媒体询量"),

    INQUIRY_OR_LOCK_CAMPAIGN_GROUP_STATUS_ERROR(21, "订单状态不支持该操作"),

    RELEASE_CAMPAIGN_GROUP_STATUS_ERROR_FOR_SITE_OUT(22, "订单非草稿、非改单配置、非正在下单状态不可释量"),
    INQUIRY_CAMPAIGN_ASSIGN_BUDGET_ERROR(23, "修改计划后请点击“计算”，系统重新分配预算后再锁量"),
    INQUIRY_CAMPAIGN_ASSIGN_AMOUNT_ERROR(24, "计划预定量分配有误，请计算重新分配预算"),
    LOCK_CAMPAIGN_ASSIGN_NOT_INQUIRY(25, "计划未询量成功，不可锁量，请先完成询量")

    ;
    public final int value;
    public final String desc;

    InquiryErrorTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public int getValue() {
        return value;
    }

    public String getDesc() {
        return desc;
    }

    public static InquiryErrorTypeEnum getByValue(Integer value) {
        InquiryErrorTypeEnum[] sourceEnums = InquiryErrorTypeEnum.values();
        for (InquiryErrorTypeEnum source : sourceEnums) {
            if (source.getValue() == value) {
                return source;
            }
        }
        return null;
    }

}
