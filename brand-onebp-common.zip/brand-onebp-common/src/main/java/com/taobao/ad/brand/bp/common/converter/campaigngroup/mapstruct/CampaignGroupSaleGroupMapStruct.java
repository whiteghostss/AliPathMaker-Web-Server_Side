package com.taobao.ad.brand.bp.common.converter.campaigngroup.mapstruct;

import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupPageViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/23
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, uses = {CampaignGroupDistributionRuleMapStruct.class})
public interface CampaignGroupSaleGroupMapStruct extends BaseMapStructMapper<ResourcePackageSaleGroupViewDTO, CampaignGroupSaleGroupPageViewDTO> {
    CampaignGroupSaleGroupMapStruct INSTANCE = Mappers.getMapper(CampaignGroupSaleGroupMapStruct.class);

    @Mappings({
            @Mapping(source = "id", target = "saleGroupId"),
            @Mapping(source = "name", target = "saleGroupName"),
            @Mapping(source = "startDate", target = "startTime"),
            @Mapping(source = "endDate", target = "endTime"),
            @Mapping(source = "status", target = "saleGroupStatus"),
            @Mapping(source = "cpmUnitPrice", target = "unitPrice"),
            @Mapping(source = "monitorConfig", target = "."),


    })
    @Override
    CampaignGroupSaleGroupPageViewDTO sourceToTarget(ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO);

    @Mappings({
            @Mapping(source = "saleGroupId", target = "id"),
            @Mapping(source = "saleGroupName", target = "name"),
            @Mapping(source = "startTime", target = "startDate"),
            @Mapping(source = "endTime", target = "endDate"),
            @Mapping(source = "saleGroupStatus", target = "status"),
            @Mapping(source = "unitPrice", target = "cpmUnitPrice"),
            @Mapping(source = ".", target = "monitorConfig"),

    })
    @Override
    ResourcePackageSaleGroupViewDTO targetToSource(CampaignGroupSaleGroupPageViewDTO campaignGroupSaleGroupPageViewDTO);

}