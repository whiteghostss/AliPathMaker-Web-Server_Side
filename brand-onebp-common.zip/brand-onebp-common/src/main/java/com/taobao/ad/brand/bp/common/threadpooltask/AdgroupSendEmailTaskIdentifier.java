package com.taobao.ad.brand.bp.common.threadpooltask;


import com.alibaba.ad.nb.tpp.core.task.TaskIdentifier;
import com.alibaba.ad.nb.tpp.core.threadpool.ThreadPoolBuilder;
import com.alibaba.ad.nb.tpp.dataobject.RunMode;
import org.springframework.stereotype.Component;

import java.util.concurrent.LinkedBlockingQueue;

/**
 * @author jixiu.lj
 * @date 2024/3/7 20:20
 * 单元批量保存为正式任务
 */
@Component
public class AdgroupSendEmailTaskIdentifier extends TaskIdentifier {

    @Override
    public ThreadPoolBuilder applyThreadPoolBuilder() {
        return ThreadPoolBuilder.builder()
                .corePoolSize(Runtime.getRuntime().availableProcessors())
                .maximumPoolSize(Runtime.getRuntime().availableProcessors())
                .workQueue(new LinkedBlockingQueue<>(2048));
    }

    @Override
    public RunMode applyRunMode() {
        return RunMode.ASYNC;
    }

    @Override
    protected Integer applyTaskTimeoutInSec() {
        return 60;
    }
}
