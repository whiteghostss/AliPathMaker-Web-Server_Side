package com.taobao.ad.brand.bp.common.enums.creative;

import com.google.common.collect.Maps;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Map;

/**
 * 元素类型枚举值(引擎使用)
 *
 * @author duxiaokang
 */
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@Getter
public enum CreativeTypeEnum {
    TEXT("text", 1, "图片"),
    IMAGE("image", 2, "图片"),
    FLASH("flash", 3, "flash"),
    VIDEO("video", 4, "视频"),
    H5("h5", 8, "H5"),
    ;

    /**
     * BP侧的枚举值
     */
    private final String type;

    /**
     * 枚举值
     */
    private final Integer value;

    /**
     * 描述
     */
    private final String desc;

    private static final Map<Integer, String> TYPE_MAP = Maps.newHashMap();

    static {
        for (CreativeTypeEnum e : CreativeTypeEnum.values()) {
            TYPE_MAP.put(e.getValue(), e.getType());
        }
    }

    /**
     * @param value bp的值
     * @return 结果
     */
    public static String getCreativeType(Integer value) {
        return TYPE_MAP.get(value);
    }
}
