package com.taobao.ad.brand.bp.common.constant;

import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleProductLineEnum;
import com.alibaba.ad.nb.ssp.constant.newproduct.ProductLineEnum;
import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.client.dto.base.SellerShieldProductlineViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;

import java.util.List;
import java.util.Set;

/**
 * @author ximu.cly
 * @date 2020/5/28
 */
public class Constant {

    /**
     * 逗号分隔符
     */
    public static final String CHAR_SPLIT_KEY_DOT = ",";

    /**
     * 逗号分隔符
     */
    public static final String CHAR_SPLIT_KEY_X = "x";

    /**
     * 分号分隔符
     */
    public static final String CHAR_SPLIT_KEY_SEMICOLON = ";";

    /**
     * 换行符
     */
    public static final String NEW_LINE = "\n";

    /**
     * 特殊分隔符^
     */
    public static final char CHAR_SPLIT_KEY = '^';

    public static final Joiner JOINER = Joiner.on(CHAR_SPLIT_KEY);

    /**
     * utf8字符集
     */
    public static final String DEFAULT_CHARSET = "UTF-8";

    /**
     * operation
     */
    public static final String ACTION_RESPONSE = "action_response";
    public final static String FOLLOW_ACTION_RESPONSE_VALUE = "103";


    public static final String COUPON_ELEMENT_KEY = "coupons_optional";

    public static final String ARRIVAL_TIME_ELEMENT_KEY = "arrival_time";

    /**
     * 横杠
     */
    public static final String SEPARATOR_LINE = "-";

    /**
     * 下划线
     */
    public static final String UNDERLINE = "_";

    /**
     * 空字符串
     */
    public static final String STRING_EMPTY = "";

    /**
     * 逗号分隔符
     */
    public static final String CHAR_SPLIT_KEY_COLON = ":";
    /**
     * 比例扩大倍数
     */
    public static final long RATIO_EXPAND_MULTIPLE = 10000L;
    /**
     * 百分百比例
     */
    public static final long RATIO_100 = 10000L;

    /**
     * 百分百比例
     */
    public static final int RATIO_100_INT = 10000;


    public static final long  DEFAULT_CPM_PV_RATIO = 1000L;

    public static final Integer MAX_PAGE_COUNT = 2000;

    public static final String CLIENT_APP_NAME = "brand-onebp";



    /**
     * 父计划状态优先级,保证顺序
     */
    public static final List<Integer> CAMPAIGN_STATUS_PRIORITY_LIST = Lists.newArrayList(
        BrandCampaignStatusEnum.NEW.getCode(), BrandCampaignStatusEnum.INQUIRY_FAIL.getCode(),
        BrandCampaignStatusEnum.LOCK_FAIL.getCode(), BrandCampaignStatusEnum.INQUIRING.getCode(),
        BrandCampaignStatusEnum.INQUIRY_SUCCESS.getCode(), BrandCampaignStatusEnum.LOCKING.getCode(),
        BrandCampaignStatusEnum.RELEASING.getCode(), BrandCampaignStatusEnum.LOCK_SUCCESS.getCode(),
        BrandCampaignStatusEnum.WAITING.getCode(), BrandCampaignStatusEnum.CASTING.getCode(),
        BrandCampaignStatusEnum.PAUSING.getCode(), BrandCampaignStatusEnum.DELETE.getCode());

    /**
     * 可进行询锁计划的状态
     */
    public static final Set<Integer> CAN_INQUIRY_LOCK_STATUS = Sets.newHashSet(
        BrandCampaignStatusEnum.NEW.getCode(), BrandCampaignStatusEnum.INQUIRY_SUCCESS.getCode(),
        BrandCampaignStatusEnum.INQUIRY_FAIL.getCode(), BrandCampaignStatusEnum.LOCK_FAIL.getCode());

    /**
     * 可进行重新分配预算的计划状态
     */
    public static final Set<Integer> CAN_ASSIGN_BUDGET_STATUS = Sets.newHashSet(
            BrandCampaignStatusEnum.NEW.getCode(), BrandCampaignStatusEnum.INQUIRING.getCode(),BrandCampaignStatusEnum.INQUIRY_SUCCESS.getCode(),
            BrandCampaignStatusEnum.INQUIRY_FAIL.getCode(), BrandCampaignStatusEnum.LOCK_FAIL.getCode());


    public static final Set<Integer> CAN_AVAILAMOUNT_LOCK_LOCK_STATUS = Sets.newHashSet(
        BrandCampaignStatusEnum.INQUIRY_FAIL.getCode());
    /**
     * 锁量和锁量中的计划状态
     */
    public static final List<Integer> LOCK_AND_ING_CAMPAIGN_STATUS_LIST = Lists.newArrayList(BrandCampaignStatusEnum.LOCKING.getCode(),
        BrandCampaignStatusEnum.LOCK_SUCCESS.getCode(), BrandCampaignStatusEnum.WAITING.getCode(),
        BrandCampaignStatusEnum.CASTING.getCode(), BrandCampaignStatusEnum.PAUSING.getCode(),
        BrandCampaignStatusEnum.ENDING.getCode());
    /**
     * 锁量和锁量中的计划状态
     */
    public static final List<Integer> LOCKED_CAMPAIGN_STATUS_LIST = Lists.newArrayList(
        BrandCampaignStatusEnum.LOCK_SUCCESS.getCode(), BrandCampaignStatusEnum.WAITING.getCode(),
        BrandCampaignStatusEnum.CASTING.getCode(), BrandCampaignStatusEnum.PAUSING.getCode(),
        BrandCampaignStatusEnum.ENDING.getCode());
    /**
     * 不更新父计划询锁量信息的状态
     */
    public static final List<Integer> UN_UPDATE_PARENT_CAMPAIGN_INQUIRY_STATUS_LIST = Lists.newArrayList(
        BrandCampaignStatusEnum.NEW.getCode(), BrandCampaignStatusEnum.INQUIRING.getCode(),
        BrandCampaignStatusEnum.LOCKING.getCode(), BrandCampaignStatusEnum.RELEASING.getCode());
    /**
     * 可进行释量计划的状态
     */
    public static final Set<Integer> CAN_RELEASE_STATUS = Sets.newHashSet(BrandCampaignStatusEnum.LOCK_SUCCESS.getCode(),
            BrandCampaignStatusEnum.LOCKING.getCode(),BrandCampaignStatusEnum.WAITING.getCode(),
            BrandCampaignStatusEnum.PAUSING.getCode(),BrandCampaignStatusEnum.CASTING.getCode());

    public static final Set<Integer> CAN_MEDIA_INQUIRY_STATUS = Sets.newHashSet(
        BrandCampaignStatusEnum.LOCK_FAIL.getCode(), BrandCampaignStatusEnum.INQUIRY_FAIL.getCode());

    public static final Set<Integer> CAN_MANDATORY_LOCK_STATUS = Sets.newHashSet(
        BrandCampaignStatusEnum.LOCK_FAIL.getCode(), BrandCampaignStatusEnum.INQUIRY_FAIL.getCode());


    /**
     * 可进行询锁计划的状态
     */
    public static final Set<Integer> CAN_CHANGE_NEW_STATUS = Sets.newHashSet(BrandCampaignStatusEnum.INQUIRY_SUCCESS.getCode(), BrandCampaignStatusEnum.INQUIRY_FAIL.getCode(), BrandCampaignStatusEnum.LOCK_FAIL.getCode());
    /**
     * 客户登录部分产品线不允许操作
     * 特秀、
     * showmax、
     * 手淘topshow
     */
//    public static List<Integer> SELLER_SHIELD_LINE = Lists.newArrayList(SaleProductLineEnum.TE_XIU.getValue()
//            , SaleProductLineEnum.TOP_SHOW.getValue(), SaleProductLineEnum.SHOW_MAX.getValue()
//            , SaleProductLineEnum.IP_MARKETING_AD.getValue(), SaleProductLineEnum.TMALL_SUPER_NEW_IP.getValue()
//            , SaleProductLineEnum.PURCHASE_APPEAR.getValue(), SaleProductLineEnum.GROUP_CAST.getValue(),
//            SaleProductLineEnum.SEARCH_APPEAR.getValue());


    /**
     * ssp产品线topshow、售卖产品线品牌定制，权限对齐topshow
     */
    public static List<SellerShieldProductlineViewDTO> SELLER_SHIELD_PRODUCTLINE = Lists.newArrayList(new SellerShieldProductlineViewDTO(ProductLineEnum.TOP_SHOW.getValue(),SaleProductLineEnum.UNIDESK_BRAND.getValue()));


    public static String CALCULATE_TAIR_KEY_PREFIX = "CALCULATE_SALE_GROUP_";

    // 该列表将异常类型分类，主要用于询锁量接口，因为询锁量接口抛出异常涉及到AMB重试和业务报警，故将异常类型分类进行差异性处理
    // 参数异常
    public static final Set<String> PARAM_ERROR_CODE_SET = Sets.newHashSet(BrandOneBPBaseErrorCode.PARAM_REQUIRED.getErrCode(), BrandOneBPBaseErrorCode.PARAM_ILLEGAL.getErrCode(), BrandOneBPBaseErrorCode.PARAM_DUPLICATED.getErrCode(), BrandOneBPBaseErrorCode.PARAM_BREAK_RULE.getErrCode());
    // 操作异常
    public static final Set<String> OPERATION_ERROR_CODE_SET = Sets.newHashSet(BrandOneBPBaseErrorCode.OPERATION_DENIED.getErrCode(), BrandOneBPBaseErrorCode.OPERATION_FAILED.getErrCode(),BrandOneBPBaseErrorCode.DISTLOCK.getErrCode());
    // 系统异常
    public static final Set<String> SYSTEM_ERROR_CODE_SET = Sets.newHashSet(BrandOneBPBaseErrorCode.DB_ERROR.getErrCode(), BrandOneBPBaseErrorCode.INTERNAL_ERROR.getErrCode());
    // 外部调用异常
    public static final Set<String> EXTERNAL_ERROR_CODE_SET = Sets.newHashSet(BrandOneBPBaseErrorCode.EXTERNAL_ERROR.getErrCode(), BrandOneBPBaseErrorCode.RPC_ERROR.getErrCode(), BrandOneBPBaseErrorCode.MAPI_ERROR.getErrCode());

    public static final Set<String> BIZ_UN_SUPPORT_ERROR_CODE_SET = Sets.newHashSet(BrandOneBPBaseErrorCode.BIZ_UN_SUPPORT_ERROR.getErrCode(), BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR.getErrCode(), BrandOneBPBaseErrorCode.BIZ_DATA_EMPTY_ERROR.getErrCode());

    /**
     * 置信度预估结果算法邮件组
     */
    public static final String ESTIMATE_WARN_SHOW_MAX_EMAIL="showmax@list.alibaba-inc.com";

}
