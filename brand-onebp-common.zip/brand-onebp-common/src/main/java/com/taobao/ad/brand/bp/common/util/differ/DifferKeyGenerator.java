package com.taobao.ad.brand.bp.common.util.differ;

/**
 * @author ximu.cly
 * @date 2020/6/4
 */
@FunctionalInterface
public interface DifferKeyGenerator<T> {

    String gen(T t);
}
