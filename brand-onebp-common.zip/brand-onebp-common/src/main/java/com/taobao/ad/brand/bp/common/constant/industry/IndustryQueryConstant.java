package com.taobao.ad.brand.bp.common.constant.industry;

import com.taobao.ad.brand.bp.common.constant.ReportConstant;

public class IndustryQueryConstant extends ReportConstant {

    public static final String SHOP_ID_EQUAL = "shopIdEqual";
}
