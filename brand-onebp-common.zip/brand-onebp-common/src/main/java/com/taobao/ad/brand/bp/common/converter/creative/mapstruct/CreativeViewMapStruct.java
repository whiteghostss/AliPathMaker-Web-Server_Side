package com.taobao.ad.brand.bp.common.converter.creative.mapstruct;

import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativePageViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface CreativeViewMapStruct extends BaseMapStructMapper<CreativeViewDTO, CreativePageViewDTO> {
    CreativeViewMapStruct INSTANCE = Mappers.getMapper(CreativeViewMapStruct.class);

    @Mappings({
            @Mapping(source = "extViewDTO",target = "."),
            @Mapping(source = "creativeAudit",target = "."),
            @Mapping(source = "creativeTemplate",target = "."),
    })
    @Override
    CreativePageViewDTO sourceToTarget(CreativeViewDTO creativeViewDTO);

}
