package com.taobao.ad.brand.bp.common.converter.campaigngroup;

import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupEstimateInfoViewDTO;
import com.taobao.ad.brand.bp.common.converter.campaigngroup.mapstruct.SaleGroupEstimateResultMapStruct;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupEstimateInfoViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.springframework.stereotype.Component;

@Component
public class SaleGroupEstimateResultConverter extends BaseViewDTOConverter<SaleGroupEstimateInfoViewDTO, CampaignGroupSaleGroupEstimateInfoViewDTO> {

    @Override
    public BaseMapStructMapper<SaleGroupEstimateInfoViewDTO, CampaignGroupSaleGroupEstimateInfoViewDTO> getBaseMapStructMapper() {
        return SaleGroupEstimateResultMapStruct.INSTANCE;
    }

}
