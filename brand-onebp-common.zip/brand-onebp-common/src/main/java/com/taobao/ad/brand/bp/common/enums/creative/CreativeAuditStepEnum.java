package com.taobao.ad.brand.bp.common.enums.creative;

public enum CreativeAuditStepEnum {
    /**
     * 运营审核
     */
    OM_AUDIT,
    /**
     * 风控审核
     */
    FENG_KONG_AUDIT
}
