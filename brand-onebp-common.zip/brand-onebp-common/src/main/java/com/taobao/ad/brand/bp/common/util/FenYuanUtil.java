package com.taobao.ad.brand.bp.common.util;

import java.math.BigDecimal;

/**
 * @author yuhui.sl
 * @since 2020/1/16 10:18
 */
public class FenYuanUtil {



    public static Long getFenFromYuan(BigDecimal yuan) {
        if (yuan == null) {
            return null;
        }
        return yuan.movePointRight(2).longValue();
    }

    public static BigDecimal getYuanFromFen(Long fen) {
        if (fen == null) {
            return null;
        }
        return new BigDecimal(fen.toString()).movePointLeft(2).setScale(2, BigDecimal.ROUND_HALF_UP);
    }

    public static Long parseDiscountFromVO(Long discountInVO) {
        if (discountInVO == null) {
            return null;
        }
        return discountInVO + 100;
    }

    public static Long parseDiscountFromDomain(Long discountInDomain) {
        if (discountInDomain == null) {
            return null;
        }
        return discountInDomain - 100;
    }

    public static double multiplyRatio(BigDecimal price, BigDecimal ratio, int scale) {
        return price.multiply(ratio).setScale(scale, BigDecimal.ROUND_HALF_UP).doubleValue();
    }
}
