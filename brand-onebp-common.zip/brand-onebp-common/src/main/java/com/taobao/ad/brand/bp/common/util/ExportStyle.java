package com.taobao.ad.brand.bp.common.util;

import com.google.common.collect.Maps;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.RegionUtil;

import java.util.Map;

/**
 * @author jixiu.lj
 * @date 2023/3/21 10:06
 */
public class ExportStyle {
    /**
     * 工作簿
     */
    private final Workbook wb;
    /**
     * 通用样式
     */
    private final Map<String, CellStyle> commonStyle;

    /**
     * 通用字体
     */
    private final Map<String, Font> commonFont;

    public ExportStyle(Workbook wb) {
        this.wb = wb;
        this.commonStyle = createCommonStyle(wb);
        this.commonFont = createCommonFont(wb);
    }

    public synchronized Font getFont(String fontName) {
        return this.commonFont.get(fontName);
    }

    /**
     * 获取通用样式
     *
     * @param styleName
     * @return
     */
    public synchronized CellStyle getStyle(String styleName) {
        return this.commonStyle.get(styleName);
    }


    /**
     * 获取自定义组合样式
     *
     * @param styleName
     * @param fontName
     * @return
     */
    public synchronized CellStyle getStyle(String styleName, String fontName) {
        return getStyle(styleName, fontName, null);
    }

    /**
     * 获取自定义组合样式
     *
     * @param styleName  样式名称
     * @param fontName   字体名称
     * @param colorIndex 背景色
     * @return
     */
    public synchronized CellStyle getStyle(String styleName, String fontName, Short colorIndex) {
        String key = styleName + "-" + fontName + "-bg_" + colorIndex;
        CellStyle style = commonStyle.get(key);
        if (style != null) {
            return style;
        }
        style = commonStyle.get(styleName);
        CellStyle newStyle = wb.createCellStyle();
        newStyle.cloneStyleFrom(style);
        if (colorIndex != null) {
            newStyle.setFillForegroundColor(colorIndex);
            newStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        }
        Font font = commonFont.get(fontName);
        newStyle.setFont(font);
        commonStyle.put(key, newStyle);
        return newStyle;
    }

    /**
     * 为合并后的单元设置边框样式
     * 非线程安全
     * @param borderStyle
     * @param cellRangeAddress
     * @param sheet
     */
    public synchronized void renderRegion(BorderStyle borderStyle, CellRangeAddress cellRangeAddress, Sheet sheet) {
        // 合并后需要重新设置样式
        RegionUtil.setBorderBottom(borderStyle, cellRangeAddress, sheet);
        RegionUtil.setBorderLeft(borderStyle, cellRangeAddress, sheet);
        RegionUtil.setBorderRight(borderStyle, cellRangeAddress, sheet);
        RegionUtil.setBorderTop(borderStyle, cellRangeAddress, sheet);
    }

    /**
     * 创建通用字体集
     *
     * @param wb
     * @return
     */
    private Map<String, Font> createCommonFont(Workbook wb) {
        Map<String, Font> retMap = Maps.newHashMap();
        Font font = wb.createFont();
        font.setFontName("微软雅黑");
        font.setFontHeightInPoints((short) 10);
        font.setColor(IndexedColors.BLACK.index);
        retMap.put("font", font);

        font = wb.createFont();
        font.setFontName("微软雅黑");
        font.setFontHeightInPoints((short) 10);
        font.setBold(true);
        font.setColor(IndexedColors.BLACK.index);
        retMap.put("font-bold", font);

        font = wb.createFont();
        font.setFontName("微软雅黑");
        font.setFontHeightInPoints((short) 10);
        font.setBold(true);
        font.setColor(IndexedColors.BLACK.index);
        font.setUnderline(Font.U_SINGLE);
        retMap.put("font-bold-underline", font);

        font = wb.createFont();
        font.setFontName("微软雅黑");
        font.setFontHeightInPoints((short) 10);
        font.setColor(IndexedColors.RED.index);
        retMap.put("font-red", font);

        font = wb.createFont();
        font.setFontName("微软雅黑");
        font.setFontHeightInPoints((short) 10);
        font.setBold(true);
        font.setColor(IndexedColors.RED.index);
        retMap.put("font-bold-red", font);

        font = wb.createFont();
        font.setFontName("微软雅黑");
        font.setFontHeightInPoints((short) 10);
        font.setBold(true);
        font.setColor(IndexedColors.GREEN.index);
        retMap.put("font-bold-green", font);

        font = wb.createFont();
        font.setFontName("微软雅黑");
        font.setFontHeightInPoints((short) 10);
        font.setBold(true);
        font.setColor(IndexedColors.LIGHT_GREEN.index);
        retMap.put("font-bold-light-green", font);

        font = wb.createFont();
        font.setFontName("微软雅黑");
        font.setFontHeightInPoints((short) 10);
        font.setBold(true);
        font.setColor(IndexedColors.LIGHT_BLUE.index);
        retMap.put("font-bold-light-blue", font);

        font = wb.createFont();
        font.setFontName("微软雅黑");
        font.setFontHeightInPoints((short) 10);
        font.setBold(true);
        font.setColor(IndexedColors.YELLOW.index);
        retMap.put("font-bold-yellow", font);

        font = wb.createFont();
        font.setFontName("微软雅黑");
        font.setFontHeightInPoints((short) 10);
        font.setColor(IndexedColors.GREY_50_PERCENT.index);
        retMap.put("font-grey-50", font);

        font = wb.createFont();
        font.setFontName("微软雅黑");
        font.setFontHeightInPoints((short) 10);
        font.setBold(true);
        font.setColor(IndexedColors.GREY_25_PERCENT.index);
        font.setStrikeout(true);
        retMap.put("font-bold-grey", font);

        font = wb.createFont();
        font.setFontName("微软雅黑");
        font.setFontHeightInPoints((short) 10);
        font.setColor(IndexedColors.WHITE.index);
        retMap.put("font-white", font);

        font = wb.createFont();
        font.setFontName("微软雅黑");
        font.setFontHeightInPoints((short) 10);
        font.setColor(IndexedColors.WHITE.index);
        font.setBold(true);
        retMap.put("font-bold-white", font);

        return retMap;
    }

    /**
     * 创建通用样式集
     *
     * @param wb
     * @return
     */
    private Map<String, CellStyle> createCommonStyle(Workbook wb) {
        Map<String, CellStyle> retMap = Maps.newHashMap();
        // 初始格式
        CellStyle style = wb.createCellStyle();
        style.setWrapText(true); // 自动换行
        DataFormat format = wb.createDataFormat();
        style.setDataFormat(format.getFormat("yyyy/MM/dd"));
        style.setAlignment(HorizontalAlignment.RIGHT); // 水平靠右
        style.setVerticalAlignment(VerticalAlignment.CENTER); // 垂直居中
        style.setBorderBottom(BorderStyle.THIN); // 下边框
        style.setBorderLeft(BorderStyle.THIN);// 左边框
        style.setBorderTop(BorderStyle.THIN);// 上边框
        style.setBorderRight(BorderStyle.THIN);// 右边框
        retMap.put("date", style);

        // 非日期格式
        style = wb.createCellStyle();
//        style.setWrapText(true); // 自动换行
        style.setAlignment(HorizontalAlignment.LEFT); // 水平靠左
        style.setVerticalAlignment(VerticalAlignment.CENTER); // 垂直居中
        style.setBorderBottom(BorderStyle.THIN); // 下边框
        style.setBorderLeft(BorderStyle.THIN);// 左边框
        style.setBorderTop(BorderStyle.THIN);// 上边框
        style.setBorderRight(BorderStyle.THIN);// 右边框
        retMap.put("text", style);

        style = wb.createCellStyle();
        style.setAlignment(HorizontalAlignment.LEFT); // 水平靠左
        style.setVerticalAlignment(VerticalAlignment.CENTER); // 垂直居中
        style.setWrapText(false);
        retMap.put("text-without-border", style);

        style = wb.createCellStyle();
//        style.setWrapText(true); // 自动换行
        style.setAlignment(HorizontalAlignment.CENTER); // 水平靠左
        style.setVerticalAlignment(VerticalAlignment.CENTER); // 垂直居中
        style.setBorderBottom(BorderStyle.THIN); // 下边框
        style.setBorderLeft(BorderStyle.THIN);// 左边框
        style.setBorderTop(BorderStyle.THIN);// 上边框
        style.setBorderRight(BorderStyle.THIN);// 右边框
        retMap.put("text-center", style);

        style = wb.createCellStyle();
        style.setWrapText(true); // 自动换行
        style.setAlignment(HorizontalAlignment.CENTER); // 水平靠左
        style.setVerticalAlignment(VerticalAlignment.CENTER); // 垂直居中
        style.setBorderBottom(BorderStyle.THIN); // 下边框
        style.setBorderLeft(BorderStyle.THIN);// 左边框
        style.setBorderTop(BorderStyle.THIN);// 上边框
        style.setBorderRight(BorderStyle.THIN);// 右边框
        retMap.put("text-center-autoWarp", style);

        style = wb.createCellStyle();
//        style.setWrapText(true); // 自动换行
        style.setAlignment(HorizontalAlignment.RIGHT); // 水平靠右
        style.setVerticalAlignment(VerticalAlignment.CENTER); // 垂直居中
        style.setBorderBottom(BorderStyle.THIN); // 下边框
        style.setBorderLeft(BorderStyle.THIN);// 左边框
        style.setBorderTop(BorderStyle.THIN);// 上边框
        style.setBorderRight(BorderStyle.THIN);// 右边框
        retMap.put("text-right", style);

        // 数字格式
        DataFormat format2 = wb.createDataFormat();
        style = wb.createCellStyle();// 设置精确到2为小数
        style.setWrapText(true); // 自动换行
        style.setAlignment(HorizontalAlignment.RIGHT); // 水平靠右
        style.setVerticalAlignment(VerticalAlignment.CENTER); // 垂直居中
        style.setBorderBottom(BorderStyle.THIN); // 下边框
        style.setBorderLeft(BorderStyle.THIN);// 左边框
        style.setBorderTop(BorderStyle.THIN);// 上边框
        style.setBorderRight(BorderStyle.THIN);// 右边框
        style.setDataFormat(format2.getFormat("#,##0.00"));
        retMap.put("number", style);

        DataFormat format3 = wb.createDataFormat();
        style = wb.createCellStyle();// 设置精确到2为小数
        style.setWrapText(true); // 自动换行
        style.setAlignment(HorizontalAlignment.RIGHT); // 水平靠右
        style.setVerticalAlignment(VerticalAlignment.CENTER); // 垂直居中
        style.setBorderBottom(BorderStyle.THIN); // 下边框
        style.setBorderLeft(BorderStyle.THIN);// 左边框
        style.setBorderTop(BorderStyle.THIN);// 上边框
        style.setBorderRight(BorderStyle.THIN);// 右边框
        style.setDataFormat(format3.getFormat("0.00"));
        retMap.put("numeric", style);

        DataFormat integerFormat = wb.createDataFormat();
        style = wb.createCellStyle();// 设置精确到2为小数
        style.setWrapText(true); // 自动换行
        style.setAlignment(HorizontalAlignment.RIGHT); // 水平靠右
        style.setVerticalAlignment(VerticalAlignment.CENTER); // 垂直居中
        style.setBorderBottom(BorderStyle.THIN); // 下边框
        style.setBorderLeft(BorderStyle.THIN);// 左边框
        style.setBorderTop(BorderStyle.THIN);// 上边框
        style.setBorderRight(BorderStyle.THIN);// 右边框
        style.setDataFormat(integerFormat.getFormat("#,##0"));
        retMap.put("integer", style);

        // ID格式
        DataFormat idFormat = wb.createDataFormat();
        style = wb.createCellStyle();// 设置精确到2为小数
        style.setWrapText(true); // 自动换行
        style.setAlignment(HorizontalAlignment.RIGHT); // 水平靠右
        style.setVerticalAlignment(VerticalAlignment.CENTER); // 垂直居中
        style.setBorderBottom(BorderStyle.THIN); // 下边框
        style.setBorderLeft(BorderStyle.THIN);// 左边框
        style.setBorderTop(BorderStyle.THIN);// 上边框
        style.setBorderRight(BorderStyle.THIN);// 右边框
        style.setDataFormat(idFormat.getFormat("###"));
        retMap.put("id", style);

        // 货币格式
        DataFormat moneyFormat = wb.createDataFormat();
        style = wb.createCellStyle();// 设置精确到2为小数
        style.setWrapText(true); // 自动换行
        style.setAlignment(HorizontalAlignment.RIGHT); // 水平靠右
        style.setVerticalAlignment(VerticalAlignment.CENTER); // 垂直居中
        style.setBorderBottom(BorderStyle.THIN); // 下边框
        style.setBorderLeft(BorderStyle.THIN);// 左边框
        style.setBorderTop(BorderStyle.THIN);// 上边框
        style.setBorderRight(BorderStyle.THIN);// 右边框
        style.setDataFormat(moneyFormat.getFormat("￥#,##0.00"));
        retMap.put("money", style);

        // 比率格式
        DataFormat rateFormat = wb.createDataFormat();
        style = wb.createCellStyle();// 设置精确到2为小数
        style.setWrapText(true); // 自动换行
        style.setAlignment(HorizontalAlignment.RIGHT); // 水平靠右
        style.setVerticalAlignment(VerticalAlignment.CENTER); // 垂直居中
        style.setBorderBottom(BorderStyle.THIN); // 下边框
        style.setBorderLeft(BorderStyle.THIN);// 左边框
        style.setBorderTop(BorderStyle.THIN);// 上边框
        style.setBorderRight(BorderStyle.THIN);// 右边框
        style.setDataFormat(rateFormat.getFormat("##0%"));
        retMap.put("rate", style);
        return retMap;
    }
}
