package com.taobao.ad.brand.bp.common.util;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

/**
 * @Author: boxer.zyf@alibaba-inc.com
 * @Date: 2020/4/7
 * @Version 1.0
 */
public class EncodeUtil {
    /**
     * Base64编码
     * @return
     */
    public static String encodeBase64(String plainText){
        String cipherText= Base64.getUrlEncoder().encodeToString(plainText.getBytes(StandardCharsets.UTF_8));
        return cipherText;
    }

    /**
     * Base64解码
     * @return
     */
    public static String decodeBase64(String cipherText){
        String plainText = new String(Base64.getUrlDecoder().decode(cipherText),StandardCharsets.UTF_8);
        return plainText;
    }
}
