package com.taobao.ad.brand.bp.common.util;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/5/11 20:47
 * @description ：
 * @modified By：
 */
public class ProtocolUtil {
    public static final String CONTENT = "content";
    public static final String ITEMS = "items";
    public static final String KEY = "key";
    public static final String VALUE = "value";
    public static final String NAME = "name";
    public static final String ATTR = "attr";
    public static final String CLICK_URL = "click_url";
    public static final String DEEPLINK_URL = "deeplink_url";
    public static final String DURATION = "duration";

    public static Map<String, Map<String, String>> creativeAttrMap(String protocol) {
        JSONObject jsonObject = JSON.parseObject(protocol);
        JSONArray content = jsonObject.getJSONArray(CONTENT);
        return content.stream().filter(Objects::nonNull).map(json -> (JSONObject) json).collect(Collectors.toMap(json -> json.get(NAME).toString(), json -> {
            String attrs = json.get(ATTR).toString();
            return JSON.parseArray(attrs).stream().filter(Objects::nonNull).map(attr ->
                    (JSONObject) attr).collect(Collectors.toMap(attr -> attr.get(KEY).toString(), attr -> attr.get(VALUE).toString(), (v1, v2) -> v1));
        }, (v1, v2) -> v1));
    }

    public static Map<String, String> creativeContentMap(String protocol) {
        JSONObject jsonObject = JSON.parseObject(protocol);
        JSONArray content = jsonObject.getJSONArray(CONTENT);
        return content.stream().filter(Objects::nonNull).map(json -> (JSONObject) json).collect(Collectors.toMap(json -> json.get(KEY).toString(), json -> json.get(VALUE).toString(), (v1, v2) -> v1));
    }

    public static Map<String, String> creativeItemMap(String protocol) {
        JSONObject jsonObject = JSON.parseObject(protocol);
        JSONArray content = jsonObject.getJSONArray(ITEMS);
        Map<String, String> result = new HashMap<>();
        content.stream().filter(Objects::nonNull).map(json -> (JSONObject) json).forEach(json -> {
            Iterator it = json.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<String, Object> entry = (Map.Entry<String, Object>) it.next();
                if (CLICK_URL.equals(entry.getKey()) || DEEPLINK_URL.equals(entry.getKey())) continue;
                result.put(entry.getKey(), entry.getValue() == null ? "" : entry.getValue().toString());
            }
        });
        return result;
    }

    public static void assertMap(Map<String, String> left, Map<String, String> right) {
        AssertUtil.assertTrue(left.size() == right.size(), "协议对比不符合");
        for (Map.Entry<String, String> entry : left.entrySet()) {
            AssertUtil.notNull(right.get(entry.getKey()), "协议中对比不符合的KEY为" + entry.getKey() + "历史协议中不存在该KEY");
            if(DURATION.equals(entry.getKey())) continue;
            AssertUtil.assertTrue(right.get(entry.getKey()).equalsIgnoreCase(entry.getValue()), "协议中对比不符合的KEY为" + entry.getKey()
                    + ", leftValue为:" + entry.getValue() + ";rightValue为:" + right.get(entry.getKey()));
        }
    }

    public static void assertContentMap(Map<String, Map<String, String>> left, Map<String, Map<String, String>> right) {
        AssertUtil.assertTrue(left.size() == right.size(), "协议对比不符合");
        for (Map.Entry<String, Map<String, String>> entry : left.entrySet()) {
            AssertUtil.notEmpty(right.get(entry.getKey()), "协议中对比不符合的KEY为" + entry.getKey() + "历史协议中不存在该KEY");
            try {
                assertMap(entry.getValue(), right.get(entry.getKey()));
            } catch (BrandOneBPException e) {
                throw new BrandOneBPException("协议中对比不符合的KEY为" + entry.getKey() + "下级协议问题:" + "[" + e.getMessage() + "]");
            }

        }
    }
}
