package com.taobao.ad.brand.bp.common.converter.report.mapstruct;

import com.taobao.ad.brand.bp.client.dto.report.query.ReportQueryViewDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.control.DeepClone;
import org.mapstruct.factory.Mappers;

/**
 * @author yuncheng.lyc
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, mappingControl=DeepClone.class)
public interface ReportQueryViewDTOMapStruct {

    ReportQueryViewDTOMapStruct INSTANCE = Mappers.getMapper(ReportQueryViewDTOMapStruct.class);

    @Mappings({
//            @Mapping(target = "conditions", ignore = true),
            @Mapping(target = "fileViewDTO", ignore = true)
    })
    ReportQueryViewDTO copySelf(ReportQueryViewDTO source);
}
