package com.taobao.ad.brand.bp.common.constant;


/**
 * 智能提案常数类
 *
 * @author yuncheng.lyc
 */
public class ProposalConstant {
    /**————————————————————策略总览/产品粒度预估数据的key——————————————————**/
    /**
     * 预估曝光量
     */
    public static final String IMP_PV = "impPv";

    /**
     * 预估点击量
     */
    public static final String CLK_PV = "clkPv";

    /**
     * CPM单价
     */
    public static final String CPM_PRICE = "cpmPrice";

    /**
     * 预估点击率
     */
    public static final String CLK_RATE = "clkRate";

    /**
     * 预估到达率
     */
    public static final String LAND_PV_RATE = "landPvRate";

    /**
     * 预估互动率
     */
    public static final String PAGE_SIZE = "pageSize";

    /**————————————————————媒体/资源类型预算曝光分配的key——————————————————**/

    public static final String BUDGET = "budget";

    /**————————————————————————————媒体洞察数据的key————————————————————————**/

    public static final String TA_MEDIA_POTENCY = "taMediaPotency";

    public static final String TA_MEDIA_COVER = "taMediaCover";

}