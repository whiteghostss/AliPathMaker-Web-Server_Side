package com.taobao.ad.brand.bp.common.enums;

import com.taobao.ad.brand.bp.client.enums.common.BizDomainTypeEnum;

import java.util.Arrays;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author yanjingang
 * @date 2023/3/20
 */
public enum BpmsProcessCodeEnum {

    CAMPAIGN_GROUP_MODIFY_APPLY("PROC-CAMPAIGN-GROUP-MODIFY-APPLY-AUDIT-1", "订单申请改单流程", BizDomainTypeEnum.SUB_CAMPAIGN_GROUP),

    CAMPAIGN_GROUP_REAL_SETTLE_APPLY("PROC-CAMPAIGN-GROUP-REAL-SETTLE-1", "订单实结申请流程", BizDomainTypeEnum.SUB_CAMPAIGN_GROUP),

    CAMPAIGN_MANDATORY_LOCK_APPLY("PROC-CAMPAIGN-MANDATORY_LOCK-APPLY-AUDIT-1", "计划强制占量流程", BizDomainTypeEnum.CAMPAIGN),
    CAMPAIGN_DELAY_LOCK_APPLY("PROC-CAMPAIGN-DELAY-LOCK-1", "计划锁量延期申请流程", BizDomainTypeEnum.CAMPAIGN),

    ;
    private String code;
    private String desc;
    private BizDomainTypeEnum domainType;

    BpmsProcessCodeEnum(String code, String desc, BizDomainTypeEnum domainType) {
        this.code = code;
        this.desc = desc;
        this.domainType = domainType;
    }

    private static Map<String, BpmsProcessCodeEnum> MAP;
    static {
        MAP = Arrays.stream(values()).collect(Collectors.toMap(BpmsProcessCodeEnum::getCode, Function.identity(), (v1, v2) -> v2));
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public BizDomainTypeEnum getDomainType() {
        return domainType;
    }

    public static BpmsProcessCodeEnum getByCode(String code) {
        return Optional.ofNullable(code).map(MAP::get).orElse(null);
    }

    public static boolean isCampaignGroupProcess(String processCode) {
        BpmsProcessCodeEnum processCodeEnum = getByCode(processCode);
        return processCodeEnum != null && (processCodeEnum.getDomainType() == BizDomainTypeEnum.MAIN_CAMPAIGN_GROUP || processCodeEnum.getDomainType() == BizDomainTypeEnum.SUB_CAMPAIGN_GROUP);
    }

    public static boolean isCampaignProcess(String processCode) {
        BpmsProcessCodeEnum processCodeEnum = getByCode(processCode);
        return processCodeEnum != null && (processCodeEnum.getDomainType() == BizDomainTypeEnum.CAMPAIGN);
    }
}
