package com.taobao.ad.brand.bp.common.spi;

import com.alibaba.ad.nb.framework.core.AbilityFactory;
import com.alibaba.ad.nb.framework.core.AbilitySpi;
import com.alibaba.ad.nb.framework.core.AbilitySpiCallback;
import com.google.common.collect.Lists;

import java.util.List;
import java.util.Set;

/**
 * @author ximu.cly
 * @date 2020/7/16
 */
public class ExtensionPointsFactory {
    private ExtensionPointsFactory() {}

    public static <T extends AbilitySpi, R> R runAbilitySpi(Class<T> clazz, AbilitySpiCallback<T, R> callback,String bizCode) {
        return callback.apply(AbilityFactory.getInstance().getSpi(clazz, bizCode));
    }

    public static <T extends AbilitySpi, R> List<R> runAbilitySpi(Class<T> clazz, AbilitySpiCallback<T, R> callback, Set<String> bizCodes) {
        List<T> abilitySpiList = AbilityFactory.getInstance().getSpi(clazz,bizCodes != null ? Lists.newArrayList(bizCodes) : Lists.newArrayList());
        List<R> resultList = Lists.newArrayList();
        abilitySpiList.forEach(abilitySpi -> {
            resultList.add(callback.apply(abilitySpi));
        });
        return resultList;
    }

    public static <T extends AbilitySpi, R> R runAbilitySpiFirstMatched(Class<T> clazz, AbilitySpiCallback<T, R> callback, Set<String> bizCodes) {
        List<T> abilitySpiList = AbilityFactory.getInstance().getSpi(clazz, bizCodes != null ? Lists.newArrayList(bizCodes) : Lists.newArrayList());
        return callback.apply(abilitySpiList.get(0));
    }

    public static <T extends AbilitySpi, R> R runAbilitySpi(Class<T> clazz, AbilitySpiCallback<T, R> callback,String bizCode, String subBizCode) {
        return callback.apply(AbilityFactory.getInstance().getSpi(clazz, bizCode, subBizCode));
    }
}
