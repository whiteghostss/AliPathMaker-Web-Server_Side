package com.taobao.ad.brand.bp.common.converter.base;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;

import java.util.List;

/**
 * 外部依赖数据到viewDTO转换
 * @param <DTO>
 * @param <ViewDTO>
 */
public abstract class BaseViewDTOConverter<DTO,ViewDTO extends BaseViewDTO> {
    public abstract BaseMapStructMapper<DTO,ViewDTO> getBaseMapStructMapper();

    public ViewDTO convertDTO2ViewDTO(DTO source){
        return getBaseMapStructMapper().sourceToTarget(source);
    }

    public DTO convertViewDTO2DTO(ViewDTO source){
        return getBaseMapStructMapper().targetToSource(source);
    }

    public List<ViewDTO> convertDTO2ViewDTOList(List<DTO> dtoList) {
        return getBaseMapStructMapper().sourceToTarget(dtoList);
    }
    public List<DTO> convertViewDTO2DTOList(List<ViewDTO> viewDTOList) {
        return getBaseMapStructMapper().targetToSource(viewDTOList);
    }

}