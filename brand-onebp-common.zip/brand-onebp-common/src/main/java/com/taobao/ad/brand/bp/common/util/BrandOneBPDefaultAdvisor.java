package com.taobao.ad.brand.bp.common.util;

/**
 * @author jixiu.lj
 * @date 2024/1/7 23:01
 */


import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.nb.tpp.core.stream.Advisor;
import com.alibaba.hermes.framework.context.BizSessionContextHolder;
import com.taobao.eagleeye.EagleEye;
import com.taobao.eagleeye.RpcContext_inner;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author jixiu.lj
 * @date 2023/12/4 21:26
 * 应用级别的默认实现，一般用于业务上下文、鹰眼上下文的注册
 * 每一个任务定义都需要创建唯一实例，不能多个任务共享，有线程安全问题，因此定义为prototype
 * TPP框架会自动扫描
 */
@Component
@Scope("prototype")
public class BrandOneBPDefaultAdvisor<T, K> implements Advisor<T, K> {

    // 调用方 eagleEye context
    private RpcContext_inner rpcContext;
    // 调用方 abf context
    private ServiceContext serviceContext;
    // 调用方 classLoader
    private ClassLoader classLoader;

    // 子线程abf context存档
    private final ThreadLocal<ServiceContext> oldServiceContextThreadLocal = new ThreadLocal<>();
    // 子线程classLoader存档
    private final ThreadLocal<ClassLoader> oldClassLoaderThreadLocal = new ThreadLocal<>();
    // 是否由调用者处理异常
    private final ThreadLocal<Boolean> callerRunsPolicyThreadLocal = ThreadLocal.withInitial(() -> false);

    @Override
    public void before(List<T> list) {
        rpcContext = EagleEye.getRpcContext();
        serviceContext = BizSessionContextHolder.getServiceContext();
        classLoader = Thread.currentThread().getContextClassLoader();
    }

    /**
     * 在子线程内调用，注意线程安全
     *
     * @param o1 子任务参数
     * @param o2 子任务索引 有序
     */
    @Override
    public void beforeExecute(T o1, Integer o2) {
        oldServiceContextThreadLocal.set(BizSessionContextHolder.getServiceContext());
        oldClassLoaderThreadLocal.set(Thread.currentThread().getContextClassLoader());
        if (rpcContext == EagleEye.getRpcContext()) {
            callerRunsPolicyThreadLocal.set(true);
        }
        EagleEye.setRpcContext(rpcContext);
        BizSessionContextHolder.setServiceContext(serviceContext);
        Thread.currentThread().setContextClassLoader(classLoader);
    }

    /**
     * 注意线程安全
     *
     * @param o1 子任务参数
     * @param o2 子任务索引 有序
     */
    @Override
    public void afterExecute(T o1, Integer o2) {
        Thread.currentThread().setContextClassLoader(oldClassLoaderThreadLocal.get());
        if(!callerRunsPolicyThreadLocal.get()) {
            EagleEye.clearRpcContext();
            BizSessionContextHolder.INSTANCE.clear();
        } else {
            BizSessionContextHolder.setServiceContext(oldServiceContextThreadLocal.get());
        }
        oldServiceContextThreadLocal.remove();
        oldClassLoaderThreadLocal.remove();
        callerRunsPolicyThreadLocal.remove();
    }
}
