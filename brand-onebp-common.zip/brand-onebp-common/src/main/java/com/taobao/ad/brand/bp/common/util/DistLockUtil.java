package com.taobao.ad.brand.bp.common.util;

import com.alibaba.hermes.framework.context.SpringContextHolder;
import com.alibaba.hermes.framework.tool.common.StorageResult;
import com.alibaba.hermes.framework.tool.lock.BaseDLock;
import com.alibaba.hermes.framework.tool.lock.DLock;
import com.alibaba.hermes.framework.tool.lock.common.LockConstants;
import com.alibaba.hermes.framework.tool.lock.common.TairLockContext;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.Callable;
import java.util.function.Consumer;
import java.util.function.Function;

/**
 * 分布式锁工具类
 * <p>
 * date: 2024/03/07 19:40
 * @author shiyan
 * @version 1.0
 */
public class DistLockUtil {
    /**
     * 分布式执行调用
     * @param lockKey 分布式key
     * @param invokeFunction 执行函数
     * @return <R>
     */
    public static <R> R execute(String lockKey, Callable<R> invokeFunction){
        DLock lock = SpringContextHolder.getBean(DLock.class);
        //reqValue自动生成
        boolean result = lock.tryLock(lockKey,null, LockConstants.EXPIRE_TIME);
        if (result) {
            try {
                try {
                    // get lock!.
                    return invokeFunction.call();
                } catch (Exception e) {
                    if(e instanceof BrandOneBPException){
                        throw (BrandOneBPException)e;
                    } else if (e.getCause() != null && e.getCause() instanceof BrandOneBPException) {
                        throw (BrandOneBPException) e.getCause();
                    }else{
                        throw new BrandOneBPException(e);
                    }
                }
            } finally {
                // let's unlock.
                lock.unlock(lockKey);
            }
        } else {
            throw new BrandOneBPException(BrandOneBPBaseErrorCode.DISTLOCK);
        }
    }

    /**
     * 分布式执行调用
     * @param lockKey 分布式key
     * @param lockReqValue 分布式值
     * @param invokeFunction 执行函数
     * @param tryLockFailConsumer 锁获取失败处理函数
     * @return <R>
     */
    public static <R> R execute(String lockKey, String lockReqValue,Callable<R> invokeFunction, Consumer<String> tryLockFailConsumer){
        return execute(lockKey,lockReqValue,LockConstants.EXPIRE_TIME,invokeFunction,tryLockFailConsumer);
    }

    /**
     * 分布式执行调用
     * @param lockKey 分布式key
     * @param lockReqValue 分布式值
     * @param expireTime 锁过期时间（秒）
     * @param invokeFunction 执行函数
     * @param tryLockFailConsumer 锁获取失败处理函数
     * @return <R>
     */
    public static <R> R execute(String lockKey, String lockReqValue,Integer expireTime,Callable<R> invokeFunction, Consumer<String> tryLockFailConsumer){
        AssertUtil.notNull(lockReqValue,BrandOneBPBaseErrorCode.PARAM_REQUIRED,"参数不允许为空");
        DLock lock = SpringContextHolder.getBean(DLock.class);
        boolean result = lock.tryLock(lockKey,lockReqValue, Optional.ofNullable(expireTime).orElse(LockConstants.EXPIRE_TIME));
        if (result) {
            try {
                // get lock!.
                return invokeFunction.call();
            } catch (Exception e) {
                if(e instanceof BrandOneBPException){
                    throw (BrandOneBPException)e;
                } else if (e.getCause() != null && e.getCause() instanceof BrandOneBPException) {
                    throw (BrandOneBPException) e.getCause();
                }else{
                    RogerLogger.error("execute error:{}",e.getMessage(), e);
                    throw new BrandOneBPException(e);
                }
            } finally {
                // let's unlock.
                lock.unlock(lockKey);
            }
        } else {
            //锁获取失败，从tair存储数据获取当前数据值
            StorageResult<String> dataResult = ((BaseDLock) lock).getStorage().getByKey(lockKey);
            String curValue = Optional.ofNullable(dataResult).filter(StorageResult::isResultPresent).map(StorageResult::getResult).orElse(null);
            tryLockFailConsumer.accept(curValue);
            return null;
        }
    }

    public static <R> R execute(List<String> lockKeyList, String lockReqValue, Integer expireTime, Callable<R> invokeFunction, Consumer<String> tryLockFailConsumer){
        AssertUtil.notNull(lockReqValue,BrandOneBPBaseErrorCode.PARAM_REQUIRED,"参数不允许为空");
        DLock lock = SpringContextHolder.getBean(DLock.class);
        String failureLockKey = null;
        List<String> successLockKeyList = Lists.newArrayList();
        try {
            for (String lockKey : lockKeyList) {
                if (lock.tryLock(lockKey, lockReqValue, Optional.ofNullable(expireTime).orElse(LockConstants.EXPIRE_TIME))) {
                    successLockKeyList.add(lockKey);
                } else {
                    failureLockKey = lockKey;
                    break;
                }
            }
            if (Objects.isNull(failureLockKey)) {
                return invokeFunction.call();
            } else {
                tryLockFailConsumer.accept(failureLockKey);
                return null;
            }
        } catch (Exception e) {
            if(e instanceof BrandOneBPException){
                throw (BrandOneBPException)e;
            } else if (e.getCause() != null && e.getCause() instanceof BrandOneBPException) {
                throw (BrandOneBPException) e.getCause();
            }else{
                RogerLogger.error("execute error:{}",e.getMessage(), e);
                throw new BrandOneBPException(e);
            }
        } finally {
            for (String lockKey : successLockKeyList) {
                lock.unlock(lockKey);
            }
        }
    }

    /**
     * 获取分布式锁,获取不到抛异常
     * @param lockKey 分布式key
     * @param tipFunction 提示函数
     */
    public static void getLock(String lockKey, Function<String,String> tipFunction){
        DLock lock = SpringContextHolder.getBean(DLock.class);
        int retries = 0;
        StorageResult<String> dataResult = null;
        while (retries++ < TairLockContext.getInstance().getRetryTimesWhenGet() && (dataResult == null || dataResult.isUnknow())) {
            dataResult = ((BaseDLock) lock).getStorage().getByKey(lockKey);
        }
//        StorageResult<String> dataResult = ((BaseDLock) lock).getStorage().getByKey(lockKey);
        String curValue = Optional.ofNullable(dataResult).filter(StorageResult::isResultPresent).map(StorageResult::getResult).orElse(null);
        if(curValue != null && !curValue.isEmpty()){
            throw new BrandOneBPException(BrandOneBPBaseErrorCode.DISTLOCK.of(tipFunction.apply(curValue)));
        }
    }
}
