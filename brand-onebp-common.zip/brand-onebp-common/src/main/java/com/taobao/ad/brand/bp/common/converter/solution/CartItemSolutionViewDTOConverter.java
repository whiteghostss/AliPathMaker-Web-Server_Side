package com.taobao.ad.brand.bp.common.converter.solution;


import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.taobao.ad.brand.bp.common.converter.solution.mapstruct.CartItemSolutionMapStruct;
import com.taobao.ad.brand.bp.client.dto.solution.CartItemSolutionViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.springframework.stereotype.Component;

@Component
public class CartItemSolutionViewDTOConverter extends BaseViewDTOConverter<CartItemSolutionViewDTO, CartItemViewDTO> {

    @Override
    public BaseMapStructMapper<CartItemSolutionViewDTO, CartItemViewDTO> getBaseMapStructMapper() {
        return CartItemSolutionMapStruct.INSTANCE;
    }
}
