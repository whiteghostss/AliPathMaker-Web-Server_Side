package com.taobao.ad.brand.bp.common.converter.campaign.mapstruct;

import com.alibaba.ad.biz.definition.constants.UniversalCampaignType;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignProgrammaticEnum;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignScheduleViewDTO;

import java.util.List;
import java.util.Objects;

/**
 * @author ximu.cly
 * @date 2021/4/17
 */
public abstract class CampaignScheduleViewMapStructDecorator implements CampaignScheduleViewMapStruct {

    private final CampaignScheduleViewMapStruct campaignScheduleViewMapStruct;

    public CampaignScheduleViewMapStructDecorator(CampaignScheduleViewMapStruct campaignScheduleViewMapStruct) {
        this.campaignScheduleViewMapStruct = campaignScheduleViewMapStruct;
    }

    @Override
    public CampaignScheduleViewDTO sourceToTarget(CampaignViewDTO campaignViewDTO) {
        CampaignScheduleViewDTO campaignScheduleViewDTO = campaignScheduleViewMapStruct.sourceToTarget(campaignViewDTO);
        Boolean isUnProgrammatic = isUnProgrammatic(campaignViewDTO.getSspProgrammatic(), campaignViewDTO.getCampaignType());
        if(isUnProgrammatic){
            campaignScheduleViewDTO.setSspProgrammatic(BrandCampaignProgrammaticEnum.UN_SYSTEM_CAST.getCode());
        }else{
            campaignScheduleViewDTO.setSspProgrammatic(BrandCampaignProgrammaticEnum.SYSTEM_CAST.getCode());
        }
        List<CampaignScheduleViewDTO> campaignScheduleViewDTOList = campaignScheduleViewMapStruct.sourceToTarget(
            campaignViewDTO.getSubCampaignViewDTOList());
        campaignScheduleViewDTO.setSubCampaignList(campaignScheduleViewDTOList);
        return campaignScheduleViewDTO;
    }

    @Override
    public CampaignViewDTO targetToSource(CampaignScheduleViewDTO campaignScheduleViewDTO) {
        CampaignViewDTO campaignViewDTO = campaignScheduleViewMapStruct.targetToSource(campaignScheduleViewDTO);
        List<CampaignViewDTO> campaignViewDTOS = campaignScheduleViewMapStruct.targetToSource(campaignScheduleViewDTO.getSubCampaignList());
        campaignViewDTO.setSubCampaignViewDTOList(campaignViewDTOS);
        return campaignViewDTO;
    }

    /**
     * 是否非系统投放
     * @param sspProgrammatic
     * @param campaignType
     * @return
     */
    private Boolean isUnProgrammatic(Integer sspProgrammatic, Integer campaignType) {
        return BrandCampaignProgrammaticEnum.UN_SYSTEM_CAST.getCode().equals(sspProgrammatic)
                && campaignType != null && UniversalCampaignType.BRAND_CPD.getId() == campaignType;
    }
}
