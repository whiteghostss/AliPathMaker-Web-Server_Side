package com.taobao.ad.brand.bp.common.util;

import java.util.Arrays;
import java.util.List;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;

import org.apache.commons.lang3.StringUtils;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * @author yanjingang
 * @date 2023/4/6
 */
public class JoinerUtil {
    public static final char SPLITTER_CHAR_1 = '^';
    public static final Joiner JOINER = Joiner.on(SPLITTER_CHAR_1);

    public static List<String> split(String joins) {
        if (StringUtils.isBlank(joins)) {
            return Lists.newArrayList();
        }
        return Arrays.asList(StringUtils.split(joins, SPLITTER_CHAR_1));
    }

    /**
     * 底层要求非null，
     * 自行封装一层，null转成String的null
     *
     * @param rest
     * @return
     */
    public static String joinNull2StringNull(Object... rest) {
        checkNotNull(rest);
        List<Object> parts = Lists.newArrayList();
        for (Object obj : rest) {
            if (obj == null) {
                parts.add("null");
            } else {
                parts.add(obj);
            }
        }

        return JOINER.join(parts);
    }
}
