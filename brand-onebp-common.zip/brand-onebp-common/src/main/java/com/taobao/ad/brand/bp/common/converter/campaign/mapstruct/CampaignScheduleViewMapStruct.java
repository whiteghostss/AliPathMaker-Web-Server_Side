package com.taobao.ad.brand.bp.common.converter.campaign.mapstruct;

import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;

import com.taobao.ad.brand.bp.client.dto.campaign.CampaignScheduleViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.DecoratedWith;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.control.DeepClone;
import org.mapstruct.factory.Mappers;

/**
 * Description:ViewDTO到ViewDTO转换
 * <p>
 * date: 2023/3/1 1:23 PM
 *
 * @author shiyan
 * @version 1.0
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, mappingControl = DeepClone.class)
@DecoratedWith(CampaignScheduleViewMapStructDecorator.class)
public interface CampaignScheduleViewMapStruct extends BaseMapStructMapper<CampaignViewDTO, CampaignScheduleViewDTO> {

    CampaignScheduleViewMapStruct INSTANCE = Mappers.getMapper(CampaignScheduleViewMapStruct.class);

    @Mappings({
        @Mapping(source = "campaignSaleViewDTO", target = "."),
        @Mapping(source = "campaignResourceViewDTO", target = "."),
        @Mapping(source = "campaignPriceViewDTO", target = "."),
        @Mapping(source = "campaignBudgetViewDTO", target = "."),
        @Mapping(source = "campaignGuaranteeViewDTO", target = "."),
        @Mapping(source = "campaignInquiryLockViewDTO", target = "."),
        @Mapping(source = "campaignInquiryLockViewDTO.campaignInquiryPolicyViewDTO", target = "."),
        @Mapping(source = "campaignInquiryLockViewDTO.campaignMediaInquiryViewDTO", target = "."),
        @Mapping(source = "campaignInquiryLockViewDTO.campaignInquiryViewDTOList", target = "inquiryViewDTOList"),
    })
    @Override
    CampaignScheduleViewDTO sourceToTarget(CampaignViewDTO campaignViewDTO);

    @Mappings({
        @Mapping(source = ".", target = "campaignSaleViewDTO"),
        @Mapping(source = ".", target = "campaignResourceViewDTO"),
        @Mapping(source = ".", target = "campaignPriceViewDTO"),
        @Mapping(source = ".", target = "campaignBudgetViewDTO"),
        @Mapping(source = ".", target = "campaignGuaranteeViewDTO"),
        @Mapping(source = ".", target = "campaignInquiryLockViewDTO"),
        @Mapping(source = ".", target = "campaignInquiryLockViewDTO.campaignInquiryPolicyViewDTO"),
        @Mapping(source = ".", target = "campaignInquiryLockViewDTO.campaignMediaInquiryViewDTO"),
        @Mapping(source = "inquiryViewDTOList", target = "campaignInquiryLockViewDTO.campaignInquiryViewDTOList"),
    })
    @Override
    CampaignViewDTO targetToSource(CampaignScheduleViewDTO campaignScheduleViewDTO);
}
