package com.taobao.ad.brand.bp.common.converter.report;

import com.taobao.ad.brand.bp.client.dto.report.query.ReportQueryViewDTO;
import com.taobao.ad.brand.bp.common.converter.report.mapstruct.ReportQueryViewDTOMapStruct;
import org.springframework.stereotype.Component;

/**
 * @author yuncheng.lyc
 */
@Component
public class ReportQueryViewDTOConverter {

    public ReportQueryViewDTO convertSelf(ReportQueryViewDTO source){
        return  ReportQueryViewDTOMapStruct.INSTANCE.copySelf(source);
    }

}

