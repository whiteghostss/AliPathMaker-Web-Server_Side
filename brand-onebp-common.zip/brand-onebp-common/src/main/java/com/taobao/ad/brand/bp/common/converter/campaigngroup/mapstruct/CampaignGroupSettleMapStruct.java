package com.taobao.ad.brand.bp.common.converter.campaigngroup.mapstruct;

import com.alibaba.ad.brand.dto.campaigngroup.realsettle.RealSettleInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupSettleInfoViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/23
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, uses = {CampaignGroupDistributionRuleMapStruct.class})
public interface CampaignGroupSettleMapStruct extends BaseMapStructMapper<RealSettleInfoViewDTO, CampaignGroupSaleGroupSettleInfoViewDTO> {
    CampaignGroupSettleMapStruct INSTANCE = Mappers.getMapper(CampaignGroupSettleMapStruct.class);

    @Mappings({
            @Mapping(source = "groupInfoViewDTO", target = "."),
    })
    @Override
    CampaignGroupSaleGroupSettleInfoViewDTO sourceToTarget(RealSettleInfoViewDTO realSettleInfoViewDTO);

    @Mappings({
            @Mapping(source = ".", target = "groupInfoViewDTO"),
    })
    @Override
    RealSettleInfoViewDTO targetToSource(CampaignGroupSaleGroupSettleInfoViewDTO saleGroupSettleViewDTO);

}