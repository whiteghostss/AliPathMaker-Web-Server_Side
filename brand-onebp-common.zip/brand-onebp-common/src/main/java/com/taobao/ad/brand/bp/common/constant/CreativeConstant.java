package com.taobao.ad.brand.bp.common.constant;

import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativeShowAuditStatusEnum;
import com.google.common.collect.Lists;

import java.util.List;

public class CreativeConstant {
    public static final Long TWO_THREE_FRAME_TEMPLATE = 9999999L;
    public static final Long OLD_TE_XIU_TEMPLATE_ID = 10010000L;
    public static final String EFFECT_TYPE = "effect_type";
    public static final String SUB_TYPE = "sub_type";
    public static final String FRAME = "frame";
    public static final String MALUS_TEMPLATE_ID = "malus_template_id";
    public static final String CONSTANT_KEY_BIZ_MAP = "$bizMap";
    public static final String CONSTANT_KEY_PROPERTIES = "properties";
    public static final String SERVER = "server";
    public static final String SERVER_CODE = "SERVERCODE";
    public static final String REGEX_CHINESE = "[^0-9a-zA-Z\u4e00-\u9fa5]";

    public static final String ZERO = "0";
    public static final String ONE = "1";

    public static final String ELEMENT_KEY = "brand_creative_protocol";
    public static final String ELEMENT_TEMPLATE_ID = "template_id";
    public static final String TEMPLATE_SIZE = "template_size";
    public static final String ELEMENT_DURATION = "duration";
    public static final String ELEMENT_WIDTH = "width";
    public static final String ELEMENT_HEIGHT = "height";
    /**
     * 审核标识
     */
    public static final String NEED_AUDIT = "needAudit";
    /**
     * 创意中台素材唯一key占位替换标识
     */
    public static final String MATERIAL_UNIQUE_PLACE_HOLDER = "${mg_id}";




    public static List<Integer> CREATIVE_REFUSE_STATUS = Lists.newArrayList();

    static {
        CREATIVE_REFUSE_STATUS.add(BrandCreativeShowAuditStatusEnum.OM_REFUSE.getCode());
        CREATIVE_REFUSE_STATUS.add(BrandCreativeShowAuditStatusEnum.CREATIVE_CENTER_REFUSE.getCode());
        CREATIVE_REFUSE_STATUS.add(BrandCreativeShowAuditStatusEnum.CREATIVE_MEDIA_AUDIT_REFUSE.getCode());
    }

    public static List<Integer> CREATIVE_NOT_YET_DELIVER_TO_MEDIA_STATUS_LIST = Lists.newArrayList();

    static {
        CREATIVE_NOT_YET_DELIVER_TO_MEDIA_STATUS_LIST.add(BrandCreativeShowAuditStatusEnum.OM_WAITING.getCode());
        CREATIVE_NOT_YET_DELIVER_TO_MEDIA_STATUS_LIST.add(BrandCreativeShowAuditStatusEnum.OM_REFUSE.getCode());
        CREATIVE_NOT_YET_DELIVER_TO_MEDIA_STATUS_LIST.add(BrandCreativeShowAuditStatusEnum.CREATIVE_CENTER_WAITING.getCode());
        CREATIVE_NOT_YET_DELIVER_TO_MEDIA_STATUS_LIST.add(BrandCreativeShowAuditStatusEnum.CREATIVE_CENTER_REFUSE.getCode());
        CREATIVE_NOT_YET_DELIVER_TO_MEDIA_STATUS_LIST.add(BrandCreativeShowAuditStatusEnum.CREATIVE_MEDIA_AUDIT_UNABLE.getCode());
    }

}
