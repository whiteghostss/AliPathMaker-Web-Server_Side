package com.taobao.ad.brand.bp.common.converter.campaign;

import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;

import com.taobao.ad.brand.bp.common.converter.campaign.mapstruct.CampaignMessageViewMapStruct;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignDealMsgViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignDealNoticeViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.springframework.stereotype.Component;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/05/15
 */
@Component
public class CampaignMessageViewConverter extends BaseViewDTOConverter<CampaignDealNoticeViewDTO, CampaignDealMsgViewDTO> {

    @Override
    public BaseMapStructMapper<CampaignDealNoticeViewDTO, CampaignDealMsgViewDTO> getBaseMapStructMapper() {
        return CampaignMessageViewMapStruct.INSTANCE;
    }

    public CampaignDealMsgViewDTO converterFrom(CampaignDealNoticeViewDTO noticeViewDTO, CampaignGroupViewDTO campaignGroup,
        CampaignViewDTO campaignViewDTO) {
        CampaignDealMsgViewDTO campaignDealMsgViewDTO = super.convertDTO2ViewDTO(noticeViewDTO);
        campaignDealMsgViewDTO.setCampaignViewDTO(campaignViewDTO);
        campaignDealMsgViewDTO.setCampaignGroupViewDTO(campaignGroup);
        return campaignDealMsgViewDTO;
    }
}