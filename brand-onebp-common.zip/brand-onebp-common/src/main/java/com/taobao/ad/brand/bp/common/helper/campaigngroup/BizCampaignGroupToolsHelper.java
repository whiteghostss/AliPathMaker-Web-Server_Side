package com.taobao.ad.brand.bp.common.helper.campaigngroup;

import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSourceEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupProcessStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupTypeEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleProductLineEnum;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupEventEnum;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import org.apache.commons.collections4.CollectionUtils;

import java.util.Date;
import java.util.List;

import static com.taobao.ad.brand.bp.common.constant.campaigngroup.CampaignGroupConstant.*;

/**
 * @author yanjingang
 * @date 2024/2/29
 */
public class BizCampaignGroupToolsHelper {

    public static boolean allCampaignGroupStatusAccepted(List<CampaignGroupViewDTO> campaignGroupList, BrandCampaignGroupStatusEnum targetStatusEnum) {
        if (CollectionUtils.isEmpty(campaignGroupList) || targetStatusEnum == null) {
            return false;
        }
        return campaignGroupList.stream().allMatch(campaignGroup -> campaignGroupStatusAccepted(campaignGroup, targetStatusEnum));
    }

    public static boolean campaignGroupStatusAccepted(CampaignGroupViewDTO campaignGroup, BrandCampaignGroupStatusEnum targetStatusEnum) {
        if (campaignGroup == null || targetStatusEnum == null) {
            return false;
        }
        return campaignGroup.getStatus().equals(targetStatusEnum.getCode());
    }

    /**
     * 获取计划总预算
     *
     * @param campaignViewDTOList
     * @return
     */
    public static Long getBuyCampaignBudgetTotal(List<CampaignViewDTO> campaignViewDTOList) {
        if (CollectionUtils.isEmpty(campaignViewDTOList)) {
            return 0L;
        }
        return campaignViewDTOList.stream()
                .filter(campaign -> BrandSaleTypeEnum.BUY.getCode().equals(campaign.getCampaignSaleViewDTO().getSaleType()))
                .filter(campaign -> campaign.getCampaignBudgetViewDTO().getDiscountTotalMoney() != null)
                .mapToLong(campaign -> campaign.getCampaignBudgetViewDTO().getDiscountTotalMoney())
                .sum();
    }

    /**
     * 获取售卖分组总预算
     *
     * @param saleGroupInfoViewDTOList
     * @return
     */
    public static Long getBuySaleGroupBudgetTotal(List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList) {
        if (CollectionUtils.isEmpty(saleGroupInfoViewDTOList)) {
            return 0L;
        }
        return saleGroupInfoViewDTOList.stream()
                .filter(saleGroup -> BrandSaleTypeEnum.BUY.getCode().equals(saleGroup.getSaleType()))
                .filter(saleGroup -> saleGroup.getBudget() != null)
                .mapToLong(SaleGroupInfoViewDTO::getBudget)
                .sum();
    }

    /**
     * 获取售卖分组总预算
     *
     * @param saleGroupInfoViewDTOList
     * @return
     */
    public static Long getSaleGroupBudgetTotal(List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList) {
        if (CollectionUtils.isEmpty(saleGroupInfoViewDTOList)) {
            return 0L;
        }
        return saleGroupInfoViewDTOList.stream()
                .filter(saleGroup -> saleGroup.getBudget() != null)
                .mapToLong(SaleGroupInfoViewDTO::getBudget)
                .sum();
    }

    /**
     * 获取售卖分组最大时间
     * @param saleGroupInfoViewDTOList
     * @return
     */
    public static Date getSaleGroupMaxDate(List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList) {
        Date maxDate = null;
        for (SaleGroupInfoViewDTO saleGroupInfoViewDTO : saleGroupInfoViewDTOList) {
            if (maxDate == null || BrandDateUtil.isBefore(maxDate, saleGroupInfoViewDTO.getEndDate())) {
                maxDate = saleGroupInfoViewDTO.getEndDate();
            }
        }

        return maxDate;
    }
    /**
     * 获取售卖分组最小时间
     * @param saleGroupInfoViewDTOList
     * @return
     */
    public static Date getSaleGroupMinDate(List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList) {
        Date minDate = null;
        for (SaleGroupInfoViewDTO saleGroupInfoViewDTO : saleGroupInfoViewDTOList) {
            if (minDate == null || BrandDateUtil.isAfter(minDate, saleGroupInfoViewDTO.getStartDate())) {
                minDate = saleGroupInfoViewDTO.getStartDate();
            }
        }

        return minDate;
    }

    /**
     * 获取计划最大时间
     * @param campaignViewDTOList
     * @return
     */
    public static Date getCampaignMaxTime(List<CampaignViewDTO> campaignViewDTOList) {
        Date maxTime = null;
        for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
            if (maxTime == null || BrandDateUtil.isBefore(maxTime, campaignViewDTO.getEndTime())) {
                maxTime = campaignViewDTO.getEndTime();
            }
        }

        return maxTime;
    }

    /**
     * 获取计划最小时间
     * @param campaignViewDTOList
     * @return
     */
    public static Date getCampaignMinTime(List<CampaignViewDTO> campaignViewDTOList) {
        Date minTime = null;
        for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
            if (minTime == null || BrandDateUtil.isAfter(minTime, campaignViewDTO.getStartTime())) {
                minTime = campaignViewDTO.getStartTime();
            }
        }

        return minTime;
    }

    public static boolean isSlimOrderCampaignGroup(CampaignGroupViewDTO campaignGroupViewDTO) {
        return campaignGroupViewDTO != null && BrandCampaignGroupSourceEnum.SLIM_ORDER.getCode().equals(campaignGroupViewDTO.getSource());
    }

    public static boolean isMainCampaignGroup(CampaignGroupViewDTO campaignGroupViewDTO) {
        return BrandCampaignGroupLevelEnum.LEVEL_ONE.getCode().equals(campaignGroupViewDTO.getCampaignGroupLevel());
    }

    public static boolean isSubCampaignGroup(CampaignGroupViewDTO campaignGroupViewDTO) {
        return !isMainCampaignGroup(campaignGroupViewDTO);
    }

    public static boolean isSubSelfServiceCampaignGroup(CampaignGroupViewDTO campaignGroupViewDTO) {
        return isSubCampaignGroup(campaignGroupViewDTO) && BrandCampaignGroupTypeEnum.SELF.getCode().equals(campaignGroupViewDTO.getType());
    }

    /**
     * 是否销售订单
     *
     * @param campaignGroupViewDTO
     * @return
     */
    public static boolean isSaleCampaignGroup(CampaignGroupViewDTO campaignGroupViewDTO) {
        return campaignGroupViewDTO != null && BrandCampaignGroupTypeEnum.SALES.getCode().equals(campaignGroupViewDTO.getType());
    }

    public static Long getCustomerMemberId(CampaignGroupViewDTO campaignGroupViewDTO) {
        if (campaignGroupViewDTO == null || campaignGroupViewDTO.getCampaignGroupExtViewDTO() == null) {
            return null;
        }
        return campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getCustomerMemberId() != null ? campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getCustomerMemberId() : campaignGroupViewDTO.getMemberId();
    }

    /**
     * 订单分组是特秀或ShowMax或TopShow
     */
    public static boolean isTopShowOrTxOrShowMaxCampaignGroup(Integer saleProductLineId) {
        return SaleProductLineEnum.TOP_SHOW.getValue().equals(saleProductLineId)
                || SaleProductLineEnum.TE_XIU.getValue().equals(saleProductLineId)
                || SaleProductLineEnum.PURCHASE_APPEAR.getValue().equals(saleProductLineId)
                || SaleProductLineEnum.GROUP_CAST.getValue().equals(saleProductLineId)
                || SaleProductLineEnum.TMALL_SUPER_NEW_IP.getValue().equals(saleProductLineId)
                || SaleProductLineEnum.SHOW_MAX.getValue().equals(saleProductLineId)
                || SaleProductLineEnum.SEARCH_APPEAR.getValue().equals(saleProductLineId);
    }

    /**
     * 是否需要消费主->子 或 子->主 领域事件
     * @param campaignGroupViewDTO
     * @param eventEnum
     * @return
     */
    public static boolean isNeedConsumeCampaignGroupSyncDomainEvent(CampaignGroupViewDTO campaignGroupViewDTO, CampaignGroupEventEnum eventEnum) {
        if (isMainCampaignGroup(campaignGroupViewDTO)) {
            return BrandCampaignGroupTypeEnum.SELF.getCode().equals(campaignGroupViewDTO.getType())
                    ? SELF_CAMPAIGN_GROUP_MAIN_2_SUB_EVENT_MAP.containsKey(eventEnum)
                    : CAMPAIGN_GROUP_MAIN_2_SUB_EVENT_MAP.containsKey(eventEnum);
        }
        return BrandCampaignGroupTypeEnum.SELF.getCode().equals(campaignGroupViewDTO.getType())
                ? SELF_CAMPAIGN_GROUP_SUB_2_MAIN_EVENT_MAP.containsKey(eventEnum)
                : CAMPAIGN_GROUP_SUB_2_MAIN_EVENT_MAP.containsKey(eventEnum);
    }

    /**
     * 需要忽略的来自Brief侧的订单Event
     * @param campaignGroupViewDTO
     * @param eventEnum
     * @return
     */
    public static boolean ignoreBriefEventForSelfService(CampaignGroupViewDTO campaignGroupViewDTO, CampaignGroupEventEnum eventEnum) {
        if (!BrandCampaignGroupTypeEnum.SELF.getCode().equals(campaignGroupViewDTO.getType())) {
            return false;
        }
        return IGNORE_EVENT_LIST_FOR_SELF_SERVICE_FROM_BRIEF.contains(eventEnum);
    }

    public static CampaignGroupEventEnum getTargetCampaignGroupEvent(CampaignGroupViewDTO campaignGroupViewDTO, CampaignGroupEventEnum eventEnum) {
        if (isMainCampaignGroup(campaignGroupViewDTO)) {
            return BrandCampaignGroupTypeEnum.SELF.getCode().equals(campaignGroupViewDTO.getType())
                    ? SELF_CAMPAIGN_GROUP_MAIN_2_SUB_EVENT_MAP.get(eventEnum)
                    : CAMPAIGN_GROUP_MAIN_2_SUB_EVENT_MAP.get(eventEnum);
        }
        return BrandCampaignGroupTypeEnum.SELF.getCode().equals(campaignGroupViewDTO.getType())
                ? SELF_CAMPAIGN_GROUP_SUB_2_MAIN_EVENT_MAP.get(eventEnum)
                : CAMPAIGN_GROUP_SUB_2_MAIN_EVENT_MAP.get(eventEnum);
    }

    public static boolean isFinish(Integer code) {
        if (code == null) {
            return false;
        }
        return BrandCampaignGroupProcessStatusEnum.AGREED.getCode().equals(code)
                    || BrandCampaignGroupProcessStatusEnum.REFUSED.getCode().equals(code);
    }

    public static boolean isAgree(Integer code) {
        if (code == null) {
            return false;
        }
        return BrandCampaignGroupProcessStatusEnum.AGREED.getCode().equals(code);
    }

    public static boolean isRefuse(Integer code) {
        if (code == null) {
            return false;
        }
        return BrandCampaignGroupProcessStatusEnum.REFUSED.getCode().equals(code);
    }
}
