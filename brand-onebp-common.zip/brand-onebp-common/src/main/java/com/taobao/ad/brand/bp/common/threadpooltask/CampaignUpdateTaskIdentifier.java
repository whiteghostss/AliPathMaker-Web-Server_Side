package com.taobao.ad.brand.bp.common.threadpooltask;


import com.alibaba.ad.nb.tpp.core.task.TaskIdentifier;
import com.alibaba.ad.nb.tpp.core.threadpool.ThreadPoolBuilder;
import org.springframework.stereotype.Component;

import java.util.concurrent.ArrayBlockingQueue;

/**
 * @author jixiu.lj
 * @date 2024/3/7 20:20
 */
@Component
public class CampaignUpdateTaskIdentifier extends TaskIdentifier {

    @Override
    public ThreadPoolBuilder applyThreadPoolBuilder() {
        return ThreadPoolBuilder.builder().corePoolSize(30).maximumPoolSize(30).workQueue(new ArrayBlockingQueue<>(4096));
    }

    @Override
    public Integer applyTaskTimeoutInSec() {
        return 3;
    }
}
