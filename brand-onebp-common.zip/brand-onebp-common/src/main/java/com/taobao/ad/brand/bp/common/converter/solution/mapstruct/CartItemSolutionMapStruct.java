
package com.taobao.ad.brand.bp.common.converter.solution.mapstruct;

import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.taobao.ad.brand.bp.client.dto.solution.CartItemSolutionViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * DTO与领域模型实体映射
 * @author ddd-coder-init
 * @date 2020/12/12
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface CartItemSolutionMapStruct extends BaseMapStructMapper<CartItemSolutionViewDTO, CartItemViewDTO> {

	CartItemSolutionMapStruct INSTANCE = Mappers.getMapper(CartItemSolutionMapStruct.class);

}

