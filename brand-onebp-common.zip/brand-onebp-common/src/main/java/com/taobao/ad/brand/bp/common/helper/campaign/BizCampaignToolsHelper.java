package com.taobao.ad.brand.bp.common.helper.campaign;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.biz.definition.constants.UniversalCampaignType;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.adzone.CampaignAdzoneViewDTO;
import com.alibaba.ad.brand.dto.campaign.audience.CampaignTargetScenarioViewDTO;
import com.alibaba.ad.brand.dto.campaign.audience.CampaignTargetViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdViewDTO;
import com.alibaba.ad.brand.dto.campaign.guarantee.CampaignGuaranteeViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryLockViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquirySchedulePolicyViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryViewDTO;
import com.alibaba.ad.brand.dto.campaign.price.DayPriceViewDTO;
import com.alibaba.ad.brand.dto.campaign.selfservice.CampaignSelfServiceViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.audience.field.BrandTargetTypeEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.*;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.alibaba.ad.nb.framework.core.AbilityFactory;
import com.alibaba.ad.nb.packages.v2.client.constant.product.CastTypeEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleProductLineEnum;
import com.alibaba.ad.nb.ssp.constant.common.BooleanEnum;
import com.alibaba.ad.nb.ssp.constant.common.CrossSceneEnum;
import com.alibaba.ad.nb.ssp.constant.common.MediaScopeEnum;
import com.alibaba.ad.nb.ssp.constant.newproduct.ProductDirectionEnum;
import com.alibaba.ad.nb.ssp.constant.newproduct.ProductLineEnum;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.base.SelectedViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignDayPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignScheduleViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.calculate.CampaignCalViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignPVAssignSceneEnum;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignScheduleOperateTypeEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.NumberUtil;
import org.apache.commons.collections.CollectionUtils;
import org.jetbrains.annotations.NotNull;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Description:计划业务域工具类
 * <p>
 * date: 2023/11/9 7:53 PM
 *
 * @author shiyan
 * @version 1.0
 */
public class BizCampaignToolsHelper {
    /**
     * 计划是特秀或showmax
     * @param mediaScope
     * @param sspProductLineId
     * @return
     */
    public static boolean isTXorShowmaxCampaign(Integer mediaScope, Integer sspProductLineId){
        return (MediaScopeEnum.TAO_INNER.getCode().equals(mediaScope) && ProductLineEnum.TE_XIU.getValue().equals(sspProductLineId))
                || (MediaScopeEnum.CROSS_SCOPE.getCode().equals(mediaScope) && ProductLineEnum.TE_XIU.getValue().equals(sspProductLineId))
                || (MediaScopeEnum.TAO_INNER.getCode().equals(mediaScope) && ProductLineEnum.SHOW_MAX.getValue().equals(sspProductLineId))
                || (MediaScopeEnum.CROSS_SCOPE.getCode().equals(mediaScope) && ProductLineEnum.SHOW_MAX.getValue().equals(sspProductLineId));
    }

    /**
     * 计算单价
     * @param mediaScope
     * @param sspProductLineId
     * @param discountTotalMoney
     * @param price
     * @param campaignPVAssignSceneModel
     * @return
     */
    public static Long calPV(Integer mediaScope, Integer sspProductLineId, Long discountTotalMoney, Long price,
                             CampaignPVAssignSceneEnum campaignPVAssignSceneModel) {
        AssertUtil.assertTrue(campaignPVAssignSceneModel != null,"需要设定预定量计算模式！");
        AssertUtil.assertTrue(NumberUtil.greaterThanZero(price),"单价为0，请点击计算获取最新价格！");
        Integer roundModel = 0;
        switch (campaignPVAssignSceneModel) {
            case LAST_SUB_ROUND_UP: roundModel = BigDecimal.ROUND_UP;break;
            case NORMAL_ROWND_DOWN: roundModel = BigDecimal.ROUND_DOWN;break;
            default:roundModel = BigDecimal.ROUND_HALF_UP;break;
        }
        Long amount = 0L;
        if(isTXorShowmaxCampaign(mediaScope,sspProductLineId)){
            amount = new BigDecimal(discountTotalMoney.longValue()*1000).divide(new BigDecimal(price),0, roundModel).longValue();
            AssertUtil.assertTrue(amount >= 1,"分配预定量不足1PV，请检查设置！");
        }else{
            amount = new BigDecimal(discountTotalMoney.longValue()*1000).divide(new BigDecimal(price),-3, roundModel).longValue();
            AssertUtil.assertTrue(amount >= 1000,"分配预定量不足1CPM，请检查设置！");
        }
        return  amount;
    }

    /**
     * 计划是showmax
     * @param mediaScope
     * @param sspProductLineId
     * @return
     */
    public static boolean isShowmaxCampaign(Integer mediaScope, Integer sspProductLineId, Integer crossScene){
        return (MediaScopeEnum.TAO_INNER.getCode().equals(mediaScope)
                && ProductLineEnum.SHOW_MAX.getValue().equals(sspProductLineId)) || (MediaScopeEnum.CROSS_SCOPE.getCode().equals(mediaScope) && Objects.equals(crossScene, CrossSceneEnum.TAOBAO_INNER_SCENE.getValue()) && ProductLineEnum.SHOW_MAX.getValue().equals(sspProductLineId));
    }
    /**
     * 计划是特秀
     * @param mediaScope
     * @param sspProductLineId
     * @return
     */
    public static boolean isTXCampaign(Integer mediaScope, Integer sspProductLineId){
        return (MediaScopeEnum.TAO_INNER.getCode().equals(mediaScope) && ProductLineEnum.TE_XIU.getValue().equals(sspProductLineId))
                || (MediaScopeEnum.CROSS_SCOPE.getCode().equals(mediaScope) && ProductLineEnum.TE_XIU.getValue().equals(sspProductLineId));
    }

    /**
     * 计划是否是CPT
     * @param sspRegisterUnit
     * @return
     */
    public static Boolean isCPT(Integer sspRegisterUnit) {
        return BrandCampaignRegisterUnitEnum.ROUND.getCode().equals(sspRegisterUnit) || BrandCampaignRegisterUnitEnum.DAY.getCode().equals(
                sspRegisterUnit);
    }
    /**
     * 计划是否是二环CPT
     * @param mediaScope
     * @param sspRegisterUnit
     * @return
     */
    public static Boolean isTwoCPT(Integer mediaScope, Integer sspRegisterUnit) {
        return MediaScopeEnum.TAO_OUT.getCode().equals(mediaScope) && BrandCampaignRegisterUnitEnum.ROUND.getCode().equals(sspRegisterUnit);
    }

    /**
     * 计划是否是二环PDB
     * @param mediaScope
     * @param castType
     * @return
     */
    public static Boolean isTwoPDB(Integer mediaScope, Integer castType) {
        return MediaScopeEnum.TAO_OUT.getCode().equals(mediaScope) && CastTypeEnum.PDB.getValue().equals(castType);
    }

    /**
     * 计划是否是三环PDB
     * @param mediaScope
     * @param castType
     * @return
     */
    public static Boolean isThreePDB(Integer mediaScope, Integer castType) {
        return MediaScopeEnum.SITE_OUT.getCode().equals(mediaScope) && CastTypeEnum.PDB.getValue().equals(castType);
    }


    /**
     * 非系统投放
     * 为了兼容历史，暂时用这两个属性判断计划是否品牌占位计划
     *
     * @param sspProgrammatic
     * @param campaignType
     */
    public static Boolean isUnProgrammatic(Integer sspProgrammatic, Integer campaignType) {
        return BrandCampaignProgrammaticEnum.UN_SYSTEM_CAST.getCode().equals(sspProgrammatic);
    }

    /**
     * 计划是否包含历史日期
     * @param campaignViewDTO
     * @return
     */
    public static boolean isHavaHistoryDate(CampaignViewDTO campaignViewDTO) {
        boolean hasHistory = false;
        if(isBoostOrPresent(campaignViewDTO.getCampaignSaleViewDTO().getSaleType())){
            if(BrandDateUtil.isBefore(campaignViewDTO.getStartTime(),BrandDateUtil.getCurrentDate())){
                hasHistory = true;
            }
        }else {
            //正式今天算历史
            if(BrandDateUtil.isBefore(campaignViewDTO.getStartTime(),BrandDateUtil.getTomorrowDate())){
                hasHistory = true;
            }
        }
        return hasHistory;
    }

    /**
     * 是否补量或配送
     * @param saleType
     * @return
     */
    public static boolean isBoostOrPresent(Integer saleType) {
        return Lists.newArrayList(BrandSaleTypeEnum.BOOST.getCode(), BrandSaleTypeEnum.PRESENT.getCode()).contains(saleType);
    }


    public static boolean isAllHistory(CampaignViewDTO subCampaignViewDTO) {
       return isAllHistory(subCampaignViewDTO.getCampaignSaleViewDTO().getSaleType(),subCampaignViewDTO.getEndTime());
    }


    public static boolean isAllHistory(Integer saleType, Date endTime) {
        boolean isAllHistory = false;
        if(isBoostOrPresent(saleType)){
            if(BrandDateUtil.isBefore(endTime,BrandDateUtil.getCurrentDate())){
                isAllHistory = true;
            }
        }else {
            //正式今天算历史
            if(BrandDateUtil.isBefore(endTime,BrandDateUtil.getTomorrowDate())){
                isAllHistory = true;
            }
        }
        return isAllHistory;
    }

    /**
     * 计算预定PV
     * @param mediaScope
     * @param sspProductLineId
     * @param price
     * @return
     */
    public static Long reCalCpmTotalMoney(Integer mediaScope, Integer sspProductLineId, Long amount, Long price){
        Long totalMoney = 0L;
        if(isTXorShowmaxCampaign(mediaScope,sspProductLineId)){
            totalMoney = BigDecimal.valueOf(price).multiply(BigDecimal.valueOf(amount)).divide(BigDecimal.valueOf(1000),0,BigDecimal.ROUND_DOWN).longValue();
        }else{
            totalMoney = BigDecimal.valueOf(price).multiply(BigDecimal.valueOf(amount/1000)).longValue();
        }
        return  totalMoney;
    }

    /**
     * 计算cpt预定金额
     * @param price
     * @return
     */
    public static Long reCalCptTotalMoney( Long amount, Long price){
        return  BigDecimal.valueOf(price).multiply(BigDecimal.valueOf(amount)).longValue();
    }

    /**
     * 子计划是否为复制计划
     */
    public static boolean isCopyParentCampaign(CampaignViewDTO campaignViewDTO) {
        //父计划没有subSplitCode
        if (campaignViewDTO.getCampaignExtViewDTO() != null && campaignViewDTO.getCampaignExtViewDTO().getSubSplitCode() != null) {
            // DEFAULT_BIZ_CODE：兼容历史数据
            return AbilityFactory.DEFAULT_BIZ_CODE.equals(campaignViewDTO.getCampaignExtViewDTO().getSubSplitCode()) ||
                    BrandSubCampaignSplitCodeEnum.CAMPAIGN_COPY.getCode().equals(campaignViewDTO.getCampaignExtViewDTO().getSubSplitCode());
        }
        return true;
    }

    /**
     * 获取允许锁量的开始时间，补量场景：允许询锁今天的量；其他场景：允许询锁明天的量
     * @param campaignViewDTO
     * @return
     */
    public static Date inquiryDeadline(CampaignViewDTO campaignViewDTO) {
        List<CampaignInquiryViewDTO> campaignInquiryViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignInquiryLockViewDTO()).map(CampaignInquiryLockViewDTO::getCampaignInquiryViewDTOList).orElse(Lists.newArrayList());
        Date deadlineDate = inquiryDeadline(campaignViewDTO.getCampaignSaleViewDTO().getSaleType(), campaignInquiryViewDTOList,
                campaignViewDTO.getCampaignInquiryLockViewDTO().getFirstOnlineTime());
        return BrandDateUtil.maxDate(deadlineDate, campaignViewDTO.getStartTime());
    }

    /**
     * 查询询量开始时间，获取允许锁量的开始时间，补量配送场景：允许询锁今天的量；其他场景：允许询锁明天的量
     * @param saleType
     * @param inquiryViewDTOList
     * @param firstOnlineTime
     * @return
     */
    public static Date inquiryDeadline(Integer saleType, List<CampaignInquiryViewDTO> inquiryViewDTOList, Date firstOnlineTime) {
        //补量计划在投放中不能释当天
        inquiryViewDTOList = inquiryViewDTOList == null ? Lists.newArrayList() : inquiryViewDTOList;
        long count = inquiryViewDTOList.stream().filter(
                v -> v.getDate().equals(BrandDateUtil.getCurrentDate()) && BrandInquiryStatusEnum.SUCCESS.getCode().equals(v.getStatus())).count();
        boolean online = firstOnlineTime != null;
        Date deadlineDate = (!NumberUtil.greaterThanZero(count) || !online)
                && isBoostOrPresent(saleType)
                ? BrandDateUtil.getCurrentDate() : BrandDateUtil.getTomorrowDate();
        return deadlineDate;
    }

    /**
     * 获取计划PV分配方式
     * @param saleProductline
     * @return
     */
    public static CampaignPVAssignSceneEnum getCampaignPVAssignSceneEnum(Integer saleProductline){
        if(saleProductline.equals(SaleProductLineEnum.TOP_SHOW.getValue())
                ||saleProductline.equals(SaleProductLineEnum.SHOW_MAX.getValue())
                ||saleProductline.equals(SaleProductLineEnum.TE_XIU.getValue())
                ||saleProductline.equals(SaleProductLineEnum.PURCHASE_APPEAR.getValue())
                ||saleProductline.equals(SaleProductLineEnum.GROUP_CAST.getValue())
                ||saleProductline.equals(SaleProductLineEnum.TMALL_SUPER_NEW_IP.getValue())
                ||saleProductline.equals(SaleProductLineEnum.SINGLE_MEDIA_MARKING.getValue())
                ||saleProductline.equals(SaleProductLineEnum.SEARCH_APPEAR.getValue())){
            return CampaignPVAssignSceneEnum.LAST_SUB_ROUND_UP;
        }
        return CampaignPVAssignSceneEnum.NORMAL_ROWND_DOWN;
    }


    /**
     * 获取资源包给的刊例价格信息和折后价信息和计划的价格信息取交集
     */
    public static  boolean isHasHistoryLockDay(CampaignViewDTO campaignViewDTO) {
        List<CampaignInquiryViewDTO> campaignInquiryViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignInquiryLockViewDTO())
                .map(CampaignInquiryLockViewDTO::getCampaignInquiryViewDTOList).orElse(Lists.newArrayList());
        if (CollectionUtils.isEmpty(campaignInquiryViewDTOList)) {
            return false;
        }
        Date inquiryDeadline = inquiryDeadline(campaignViewDTO);
        boolean hasLock = campaignInquiryViewDTOList.stream()
                .anyMatch(item->BrandDateUtil.isBefore(item.getDate(),inquiryDeadline)
                        && BooleanEnum.TRUE.getCode().equals(item.getStatus()));
        return hasLock;
    }



    /**
     * 根据子计划判断父计划是否锁量（包含锁量中计划的状态以及询量表的状态）
     *
     * @param campaignViewDTO
     * @return
     */
    public static boolean isLockBySubList(CampaignViewDTO campaignViewDTO, boolean containHistory) {
        return containHistory ? isCampaignTreeLockedByAllInquiry(campaignViewDTO) : isCampaignTreeLockedByFuture(campaignViewDTO);
    }

    /**
     * 改单下存在历史已锁量情况，区分是否包含历史数据：计算锁量
     * 未来存在锁量天或正在锁量：算锁量
     */
    private static boolean isCampaignTreeLockedByAllInquiry(CampaignViewDTO campaignViewTreeDTO) {
        if (CollectionUtils.isEmpty(campaignViewTreeDTO.getSubCampaignViewDTOList())) {
            return false;
        }
        for (CampaignViewDTO sub : campaignViewTreeDTO.getSubCampaignViewDTOList()) {
            if (sub.getCampaignInquiryLockViewDTO() ==null || CollectionUtils.isEmpty(sub.getCampaignInquiryLockViewDTO().getCampaignInquiryViewDTOList())) {
                continue;
            }
            if (hasLockDate(sub)) {return true;}
        }
        return false;
    }

    public static boolean hasLockDate(CampaignViewDTO campaignViewDTO) {
        List<CampaignInquiryViewDTO> campaignInquiryViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignInquiryLockViewDTO())
                .map(CampaignInquiryLockViewDTO::getCampaignInquiryViewDTOList).orElse(Lists.newArrayList());
        if(CollectionUtils.isEmpty(campaignInquiryViewDTOList)){
            return false;
        }
        long lockCount = campaignInquiryViewDTOList.stream().filter(v -> BrandInquiryStatusEnum.SUCCESS.getCode().equals(v.getStatus())).count();
        if (NumberUtil.greaterThanZero(lockCount)
                || BrandCampaignStatusEnum.LOCKING.getCode().equals(campaignViewDTO.getStatus())) {
            return true;
        }
        return false;
    }

    /**
     * 计划是否含有锁量成功记录
     * @param dbCampaignViewDTO
     * @return
     */
    public static boolean hasLockedSuccess(CampaignViewDTO dbCampaignViewDTO){
        //主子计划打平
        List<CampaignViewDTO> allCampaignViewDTOList = flatCampaignList(dbCampaignViewDTO);
        for (CampaignViewDTO campaignViewDTO : allCampaignViewDTOList) {
            List<CampaignInquiryViewDTO> inquiryViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignInquiryLockViewDTO())
                    .map(CampaignInquiryLockViewDTO::getCampaignInquiryViewDTOList).orElse(Lists.newArrayList());
            if(CollectionUtils.isNotEmpty(inquiryViewDTOList)){
                boolean hasLockedSuccess = inquiryViewDTOList.stream().anyMatch(e -> BrandInquiryStatusEnum.SUCCESS.getCode().equals(e.getStatus()));
                if(hasLockedSuccess){
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 打平计划
     * @param campaignTreeViewDTO
     * @return
     */
    public static List<CampaignViewDTO> flatCampaignList(CampaignViewDTO campaignTreeViewDTO){
        List<CampaignViewDTO> allCampaignViewDTOList = Lists.newArrayList(campaignTreeViewDTO);
        Optional.ofNullable(campaignTreeViewDTO.getSubCampaignViewDTOList()).ifPresent(allCampaignViewDTOList::addAll);
        return allCampaignViewDTOList;
    }

    /**
     * 改单下存在历史已锁量情况，区分是否包含历史数据：计算锁量
     * 未来存在锁量天或正在锁量：算锁量
     */
    public static boolean isCampaignTreeLockedByFuture(CampaignViewDTO campaignViewTreeDTO) {
        if (CollectionUtils.isEmpty(campaignViewTreeDTO.getSubCampaignViewDTOList())) {
            return false;
        }
        Date deadline = inquiryDeadline(campaignViewTreeDTO);
        for (CampaignViewDTO sub : campaignViewTreeDTO.getSubCampaignViewDTOList()) {
            if (sub.getCampaignInquiryLockViewDTO() == null || CollectionUtils.isEmpty(sub.getCampaignInquiryLockViewDTO().getCampaignInquiryViewDTOList())) {
                continue;
            }
            long lockCount = sub.getCampaignInquiryLockViewDTO().getCampaignInquiryViewDTOList().stream()
                    .filter(v-> BrandDateUtil.isAfterAndEqual(v.getDate(), deadline)
                            && BrandInquiryStatusEnum.SUCCESS.getCode().equals(v.getStatus()))
                    .count();
            if (NumberUtil.greaterThanZero(lockCount)
                    || BrandCampaignStatusEnum.LOCKING.getCode().equals(sub.getStatus())) {
                return true;
            }
        }
        return false;
    }

    /**
     * 判断改单下是否有历史锁量成功
     * @param subScheduleViewDTO
     * @return
     */
    public static boolean isAllHistoryLockSuccess(CampaignScheduleViewDTO subScheduleViewDTO) {
        if(BizCampaignToolsHelper.isAllHistory(subScheduleViewDTO.getSaleType(),subScheduleViewDTO.getEndTime())){
            if(org.apache.commons.collections4.CollectionUtils.isEmpty(subScheduleViewDTO.getFutureInquiryList()) && org.apache.commons.collections4.CollectionUtils.isNotEmpty(
                subScheduleViewDTO.getHistoryInquiryList())){
                Optional<CampaignInquiryViewDTO>
                    optional = subScheduleViewDTO.getHistoryInquiryList().stream().filter(item->BrandInquiryStatusEnum.FAIL.getCode().equals( item.getStatus())).findAny();
                if(!optional.isPresent()){
                    return true;
                }
            };
        }
        return false;
    }

    /**
     * 判断是否是天攻计划
     * @param sspProductLineId
     * @return
     */
    public static boolean isDoohCampaign(Integer sspProductLineId){
        return ProductLineEnum.OFFLINE_SCREEN_MEDIA.getValue().equals(sspProductLineId);
    }

    /**
     * 是否临时存储的计划
     * @param campaignViewDTO
     * @return
     */
    public static boolean isDraftCampaign(CampaignViewDTO campaignViewDTO){
        return BrandCampaignOnlineStatusEnum.DRAFT.getCode().equals(campaignViewDTO.getOnlineStatus());
    }

    /**
     * 获取计划的上线状态枚举值
     * @return
     */
    public static List<Integer> getCampaignOnlineStatusList(){
        return Arrays.stream(BrandCampaignOnlineStatusEnum.values()).map(BrandCampaignOnlineStatusEnum::getCode).collect(Collectors.toList());
    }

    public static Integer getCampaignCastType(CampaignViewDTO campaignViewDTO, ResourcePackageProductViewDTO resourcePackageProductViewDTO) {
        // 投放方式
        Integer castType = resourcePackageProductViewDTO.getCastType() != null ? resourcePackageProductViewDTO.getCastType().getType() : CastTypeEnum.GUARANTEE.getValue();
        //兼容资源包逻辑
        if(MediaScopeEnum.CROSS_SCOPE.getCode().equals(resourcePackageProductViewDTO.getMediaScope())){
            castType = CastTypeEnum.GUARANTEE.getValue();
        }
        if (CastTypeEnum.PD_OR_PDB.getValue().equals(castType)) {
            CampaignInquiryLockViewDTO campaignInquiryLockViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignInquiryLockViewDTO()).orElse(new CampaignInquiryLockViewDTO());
            CampaignGuaranteeViewDTO campaignGuaranteeViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignGuaranteeViewDTO()).orElse(new CampaignGuaranteeViewDTO());
            AssertUtil.assertTrue(!(Objects.isNull(campaignInquiryLockViewDTO.getPdType()) && Objects.isNull(campaignGuaranteeViewDTO.getSspPushSendRatio())), "PD/PDB必须二选一");
            if (Objects.nonNull(campaignInquiryLockViewDTO.getPdType())) {
                castType = CastTypeEnum.PD.getValue();
                AssertUtil.assertTrue(Objects.isNull(campaignGuaranteeViewDTO.getSspPushSendRatio()), "不能同时设置PDB/PD");
            } else if (Objects.nonNull(campaignGuaranteeViewDTO.getSspPushSendRatio())) {
                castType = CastTypeEnum.PDB.getValue();
            } else {
                throw new BrandOneBPException("未设置投放方式");
            }
        }
        return castType;
    }

    public static Map<Long, Long> getSubPackageProductBookingAmountRatioMap(CampaignViewDTO levelOneCampaignViewDTO, ResourcePackageProductViewDTO parentResourcePackageProduct, List<ProductViewDTO> subProductViewDTOList) {
        AssertUtil.assertTrue(MediaScopeEnum.CROSS_SCOPE.getCode().equals(parentResourcePackageProduct.getMediaScope()) && CollectionUtils.isNotEmpty(parentResourcePackageProduct.getSubResourcePackageProductList()), "非跨域产品或者无子产品，无法获取子产品预定量占比");
        // 获取SSP产品ID和List<SiteId>的映射, 目前只有二环是List,一三环都只对应一个SiteId
        Map<Long, List<Long>> subProductSiteIdMap = subProductViewDTOList.stream().collect(Collectors.toMap(ProductViewDTO::getId, it -> it.getAdzoneList().stream().map(CampaignAdzoneViewDTO::getSiteId).distinct().collect(Collectors.toList())));
        Map<Long, Long> bookingAmountRatioMap = parentResourcePackageProduct.getSubResourcePackageProductList().stream().collect(Collectors.toMap(ResourcePackageProductViewDTO::getId, ResourcePackageProductViewDTO::getBookingAmountRatio));
        AssertUtil.assertTrue(bookingAmountRatioMap.values().stream().reduce(0L, Long::sum).equals(10000L) && bookingAmountRatioMap.values().stream().allMatch(it -> it >= 0L), "从打包平台读取的初始预定量占比需大于0且和必须等于10000");
        RogerLogger.info("BizCampaignToolsHelper getSubPackageProductBookingAmountRatioMap parentResourcePackageProduct id:{}, source map:{}", parentResourcePackageProduct.getId(), JSONObject.toJSONString(bookingAmountRatioMap));
        // 只有在打包侧的跨域产品上设置了媒体定向，才需要重新计算预定量占比
        if (Optional.ofNullable(parentResourcePackageProduct.getTargetList()).orElse(Lists.newArrayList()).stream().anyMatch(it -> ProductDirectionEnum.MULTI_MEDIA.getType().equals(it.getValue()) && Boolean.TRUE.equals(it.getSelected()))) {
            // 页面传入的媒体定向列表
            Optional<CampaignTargetViewDTO> levelOneCampaignMultiMediaTarget = Optional.ofNullable(levelOneCampaignViewDTO.getCampaignTargetScenarioViewDTO()).map(CampaignTargetScenarioViewDTO::getCampaignTargetViewDTOList).orElse(Lists.newArrayList())
                    .stream().filter(it -> BrandTargetTypeEnum.MULTI_MEDIA.getCode().toString().equals(it.getType())).collect(Collectors.toList()).stream().findFirst();
            AssertUtil.assertTrue(levelOneCampaignMultiMediaTarget.isPresent(), "跨域产品设置媒体定向后，必需勾选媒体");
            List<Long> levelOneCampaignMultiMediaTargetList = levelOneCampaignMultiMediaTarget.get().getTargetValues().stream().map(Long::valueOf).collect(Collectors.toList());
            // 判断子产品列表中无效的子产品
            // 1、bookingAmountRatio在打包侧即设置为0，则该子产品无效
            // 2、对于bookingAmountRatio!=0的子产品，如果是三环子产品，因为在打包侧没有记录SiteId这个字段，所以要用从SSP查到的SiteId和levelOneCampaignMultiMediaTargetList做交集，无交集则该子产品无效；
            // 如果是一二环子产品，因为在打包侧记录SiteId这个字段unionMediaList，所以要用从该字段和levelOneCampaignMultiMediaTargetList做交集，无交集则该子产品无效；
            List<ResourcePackageProductViewDTO> invalidResourcePackageProductList = parentResourcePackageProduct.getSubResourcePackageProductList()
                    .stream()
                    .filter(it -> Optional.ofNullable(it.getBookingAmountRatio()).orElse(0L) == 0 ||
                            (MediaScopeEnum.SITE_OUT.getCode().equals(it.getMediaScope()) ? Collections.disjoint(subProductSiteIdMap.get(it.getSspProductId()), levelOneCampaignMultiMediaTargetList) : Collections.disjoint(it.getUnionMediaList().stream().filter(item -> Boolean.TRUE.equals(item.getSelected())).map(SelectedViewDTO::getId).collect(Collectors.toList()), levelOneCampaignMultiMediaTargetList)))
                    .collect(Collectors.toList());
            // 对于无效的产品，将其bookingAmountRatio之和平均分配给有效的子产品，最后的倒减放到第一个有效的子产品上
            Long invalidBookingAmountTotalRatio = invalidResourcePackageProductList.stream().map(ResourcePackageProductViewDTO::getBookingAmountRatio).reduce(0L, Long::sum);
            Integer validSubProductCount = parentResourcePackageProduct.getSubResourcePackageProductList().size() - invalidResourcePackageProductList.size();
            RogerLogger.info("BizCampaignToolsHelper getSubPackageProductBookingAmountRatioMap parentResourcePackageProduct id:{}, invalidResourcePackageProductList:{}, invalidBookingAmountTotalRatio:{}", parentResourcePackageProduct.getId(), JSONObject.toJSONString(invalidResourcePackageProductList.stream().map(ResourcePackageProductViewDTO::getId).collect(Collectors.toList())), invalidBookingAmountTotalRatio);
            for (ResourcePackageProductViewDTO resourcePackageProductViewDTO : parentResourcePackageProduct.getSubResourcePackageProductList()) {
                if (invalidResourcePackageProductList.stream().noneMatch(it -> it.getId().equals(resourcePackageProductViewDTO.getId()))) {
                    bookingAmountRatioMap.put(resourcePackageProductViewDTO.getId(), bookingAmountRatioMap.get(resourcePackageProductViewDTO.getId()) + invalidBookingAmountTotalRatio / validSubProductCount);
                } else {
                    bookingAmountRatioMap.put(resourcePackageProductViewDTO.getId(), 0L);
                }
            }
            for (Long subResourceProductId : bookingAmountRatioMap.keySet()) {
                if (bookingAmountRatioMap.get(subResourceProductId) > 0L) {
                    bookingAmountRatioMap.put(subResourceProductId, bookingAmountRatioMap.get(subResourceProductId) + (10000L - bookingAmountRatioMap.values().stream().reduce(0L, Long::sum)));
                    break;
                }
            }
        }
        RogerLogger.info("BizCampaignToolsHelper getSubPackageProductBookingAmountRatioMap parentResourcePackageProduct id:{}, result map:{}", parentResourcePackageProduct.getId(), JSONObject.toJSONString(bookingAmountRatioMap));
        AssertUtil.assertTrue(bookingAmountRatioMap.values().stream().reduce(0L, Long::sum).equals(10000L) && bookingAmountRatioMap.values().stream().allMatch(it -> it >= 0L), "经过媒体占比定向计算后的预定量占比需大于等于0且和必须等于10000");
        return bookingAmountRatioMap;
    }

    /**
     * 是否跨域多波段计划
     * @param campaignViewDTO
     * @return
     */
    public static boolean isCrossPricePeriodCampaign(CampaignViewDTO campaignViewDTO) {
        return MediaScopeEnum.CROSS_SCOPE.getCode().equals(campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope())
                && campaignViewDTO.getCampaignPriceViewDTO().getDiscountPriceInfoList().stream().map(DayPriceViewDTO::getPrice).distinct().count() > 1;
    }

    public static boolean realTimeOptimizeCrowdsAreEqual(CampaignCrowdViewDTO dbCrowd, CampaignCrowdViewDTO crowdViewDTO) {
        if (dbCrowd == null || crowdViewDTO == null) {
            return false;
        }
        return Objects.equals(dbCrowd.getTargetType(), crowdViewDTO.getTargetType())
                && Objects.equals(dbCrowd.getShopId(), crowdViewDTO.getShopId())
                && Objects.equals(dbCrowd.getGenderLabel(), crowdViewDTO.getGenderLabel())
                && Objects.equals(dbCrowd.getAgeLabels(), crowdViewDTO.getAgeLabels())
                && Objects.equals(dbCrowd.getItemId(), crowdViewDTO.getItemId());
    }

    /**
     * 是否极简版计划
     * @param campaignViewDTO
     * @return
     */
    public static boolean isSlimOrderCampaign(CampaignViewDTO campaignViewDTO){
        Long bundleId = Optional.ofNullable(campaignViewDTO.getCampaignSelfServiceViewDTO())
                .map(CampaignSelfServiceViewDTO::getBundleId).orElse(null);
        return Objects.nonNull(bundleId);
    }

    public static Date inquiryDeadline(Integer saleType) {
        return BizCampaignToolsHelper.isBoostOrPresent(saleType) ? BrandDateUtil.getCurrentDate() : BrandDateUtil.getTomorrowDate();
    }

    public static boolean isCampaignSubLockedByFuture(Date deadline, CampaignViewDTO sub) {
        long lockCount = sub.getCampaignInquiryLockViewDTO().getCampaignInquiryViewDTOList().stream().filter(v-> BrandDateUtil.isAfterAndEqual(v.getDate(),
                deadline)).filter(v -> BrandInquiryStatusEnum.SUCCESS.getCode().equals(v.getStatus())).count();
        if (NumberUtil.greaterThanZero(lockCount) ||  BrandCampaignStatusEnum.LOCKING.getCode().equals(
                sub.getStatus())) {
            return true;
        }
        return false;
    }

    /**
     * 获取可用的预定量周期
     *
     * @param inquirySchedulePolicyList
     * @param startTime
     * @param endTime
     * @return
     */
    public static List<CampaignInquirySchedulePolicyViewDTO> getInquiryAvailableSchedulePolicy(List<CampaignInquirySchedulePolicyViewDTO> inquirySchedulePolicyList, Date startTime, Date endTime) {
        if(org.apache.commons.collections4.CollectionUtils.isEmpty(inquirySchedulePolicyList)){
            return Lists.newArrayList();
        }
        //计划有效的周期范围
        List<Date> availableDayList = BrandDateUtil.getDayList(startTime, endTime);
        //计划预定量周期范围
        for (CampaignInquirySchedulePolicyViewDTO policyViewDTO : inquirySchedulePolicyList) {
            List<Date> policyDateList = BrandDateUtil.getDayList(policyViewDTO.getStartTime(), policyViewDTO.getEndTime());
            //取交集，计划有效周期，至少有一天在预定量周期比例范围内
            policyDateList.retainAll(availableDayList);
            if(policyDateList.isEmpty()){
                RogerLogger.info(String.format("计划预定量周期比例设置=%s，不能涵盖计划的有效周期范围(startTime=%s,endTime=%s)",
                        JSON.toJSONString(inquirySchedulePolicyList), BrandDateUtil.date2String(startTime), BrandDateUtil.date2String(endTime)));
                return Lists.newArrayList();
            }
        }
        List<CampaignInquirySchedulePolicyViewDTO> availableSchedulePolicyList = Lists.newArrayList();
        for (CampaignInquirySchedulePolicyViewDTO policyViewDTO : inquirySchedulePolicyList) {
            //已结束
            if (policyViewDTO.getEndTime().compareTo(startTime) < 0) {
                continue;
            }
            if (policyViewDTO.getStartTime().compareTo(startTime) <= 0) {
                CampaignInquirySchedulePolicyViewDTO availablePolicyViewDTO = new CampaignInquirySchedulePolicyViewDTO();
                availablePolicyViewDTO.setAmountRatio(policyViewDTO.getAmountRatio());
                availablePolicyViewDTO.setStartTime(startTime);
                availablePolicyViewDTO.setEndTime(BrandDateUtil.minDate(policyViewDTO.getEndTime(), endTime));
                availableSchedulePolicyList.add(availablePolicyViewDTO);
            } else {
                CampaignInquirySchedulePolicyViewDTO availablePolicyViewDTO = new CampaignInquirySchedulePolicyViewDTO();
                availablePolicyViewDTO.setAmountRatio(policyViewDTO.getAmountRatio());
                availablePolicyViewDTO.setStartTime(policyViewDTO.getStartTime());
                availablePolicyViewDTO.setEndTime(BrandDateUtil.minDate(policyViewDTO.getEndTime(), endTime));
                availableSchedulePolicyList.add(availablePolicyViewDTO);
            }
        }
        RogerLogger.info(String.format("有效周期范围(startTime=%s,endTime=%s)匹配到的历史预定量周期比例=%s，",
                BrandDateUtil.date2String(startTime), BrandDateUtil.date2String(endTime), JSON.toJSONString(availableSchedulePolicyList)));
        return availableSchedulePolicyList;
    }

    /**
     * 为了兼容历史，暂时用这两个属性判断计划是否品牌占位计划
     *
     * @param sspProgrammatic
     * @param campaignType
     */
    public static boolean isProgrammatic(Integer sspProgrammatic, Integer campaignType) {
        return !BrandCampaignProgrammaticEnum.UN_SYSTEM_CAST.getCode().equals(sspProgrammatic)
                || UniversalCampaignType.BRAND_CPD.getId() != campaignType;
    }

    /**
     * 为了兼容历史数据，非系统的条件：UN_SYSTEM_CAST && BRAND_CPD
     * @param resourceProductCampaignList
     * @param campaignList
     * @return
     */
    public static boolean isProgrammatic(List<CampaignCalViewDTO> resourceProductCampaignList, List<CampaignViewDTO> campaignList) {
        if (org.apache.commons.collections4.CollectionUtils.isEmpty(resourceProductCampaignList) || org.apache.commons.collections4.CollectionUtils.isEmpty(campaignList)) {
            return true;
        }
        List<Long> resourceProductCampaignIds = resourceProductCampaignList.stream().map(CampaignCalViewDTO::getCampaignId).collect(Collectors.toList());
        return campaignList.stream().filter(campaign -> resourceProductCampaignIds.contains(campaign.getId()))
                .anyMatch(campaign -> !BrandCampaignProgrammaticEnum.UN_SYSTEM_CAST.getCode().equals(campaign.getSspProgrammatic())
                        || campaign.getCampaignType() != UniversalCampaignType.BRAND_CPD.getId());
    }

    @NotNull
    public static Long getCptTransferCpmAmount(Integer unitExposure,Long cptAmount) {
        //单位CPM
        AssertUtil.assertTrue(unitExposure!=null &&  unitExposure>=0 ,"CPT对应单位CPM小于0");
        return new BigDecimal(unitExposure * 1000).multiply(new BigDecimal(cptAmount)).longValue();
    }

    public static List<DayPriceViewDTO> initDayPriceViewDTOList(CampaignDayPriceViewDTO campaignDayPriceViewDTO, List<DayPriceViewDTO> campaignDiscountPriceInfoList) {
        List<DayPriceViewDTO> newDayPriceViewDTOList  = Lists.newArrayList();
        for(DayPriceViewDTO dayPriceViewDTO : campaignDiscountPriceInfoList){
            if(BrandDateUtil.isMixed(dayPriceViewDTO.getStartDate(),dayPriceViewDTO.getEndDate(), campaignDayPriceViewDTO.getStartDate(), campaignDayPriceViewDTO.getEndDate())){
                newDayPriceViewDTOList.add(dayPriceViewDTO);
            }
        }
        return newDayPriceViewDTOList;
    }

    /**
     * 是否是已下过单的自助计划
     * @param context
     * @param campaignGroupViewDTO
     * @return
     */
    public static boolean isSelfOrdered(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO){
        return BizCodeEnum.SELFSERVICEAD.getBizCode().equals(context.getBizCode())
                && Objects.nonNull(campaignGroupViewDTO)
                && !BrandCampaignGroupStatusEnum.DRAFT.getCode().equals(campaignGroupViewDTO.getStatus());
    }

    @NotNull
    public static Long getCptTransferCpmPrice(Integer unitExposure, Long cptPrice) {
        //单位CPM
        AssertUtil.assertTrue(unitExposure!=null &&  unitExposure>=0 ,"CPT对应单位CPM小于0");
        return new BigDecimal(cptPrice ).divide(BigDecimal.valueOf(unitExposure),0, RoundingMode.DOWN).longValue();
    }

    /**
     * 查询要操作的计划，可能为父计划可能为子计划
     */
    public static CampaignViewDTO getOperateCampaign(CampaignViewDTO parentCampaignViewDTO, Long campaignId) {
        CampaignViewDTO campaignViewDTO = null;
        if (parentCampaignViewDTO.getId().equals(campaignId)) {
            campaignViewDTO = parentCampaignViewDTO;
        } else {
            campaignViewDTO = parentCampaignViewDTO.getSubCampaignViewDTOList().stream().filter(
                    v -> v.getId().equals(campaignId)).findFirst().orElse(null);
        }
        return campaignViewDTO;
    }

    public static boolean onlyTeXiuCampaign(List<CampaignViewDTO> campaignViewDTOList) {
        if (org.apache.commons.collections4.CollectionUtils.isEmpty(campaignViewDTOList)) {
            return false;
        }
        for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
            if(!isTXorShowmaxCampaign(campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope(),
                    campaignViewDTO.getCampaignResourceViewDTO().getSspProductLineId())){
                return false;
            }
        }
        return true;
    }

    public static List<CampaignViewDTO> getMandatoryLockCampaign(List<CampaignViewDTO> campaignTreeViewDTOs, List<Long> inquiryOperateCampaignIdList) {
        //流程信息统一放在子计划上
        return campaignTreeViewDTOs.stream().map(campaignViewDTO -> {
            List<CampaignViewDTO> campaigns = Lists.newArrayList();
            if (inquiryOperateCampaignIdList.contains(campaignViewDTO.getId())) {
                campaigns.addAll(campaignViewDTO.getSubCampaignViewDTOList());
                return campaigns;
            }
            if (org.apache.commons.collections4.CollectionUtils.isNotEmpty(campaignViewDTO.getSubCampaignViewDTOList())) {
                campaigns.addAll(campaignViewDTO.getSubCampaignViewDTOList()
                        .stream().filter(v -> inquiryOperateCampaignIdList.contains(v.getId())).collect(Collectors.toList()));
            }
            return campaigns;
        }).flatMap(Collection::stream).collect(Collectors.toList());
    }

    /**
     * 根据对计划的询锁操作判断是否需要增加分布式锁
     * @param operateType
     * @return
     */
    public static boolean needDistLockCampaign(Integer operateType){
        return CampaignScheduleOperateTypeEnum.LOCK.getValue() == operateType
                || CampaignScheduleOperateTypeEnum.CANCEL.getValue() == operateType
                || CampaignScheduleOperateTypeEnum.RELEASE.getValue() == operateType
                || CampaignScheduleOperateTypeEnum.MANDATORY_LOCK.getValue() == operateType;
    }
}
