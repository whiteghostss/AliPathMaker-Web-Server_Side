package com.taobao.ad.brand.bp.common.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * 环境标识
 * */
@Component
public class Env {
    public static String env;

    @Value("${env}")
    void setEnv(String v) {
        env = v;
    }

    public static boolean isProd() {
        return "prod".equals(env);
    }

    public static boolean isPre() {
        return env.contains("pre");
    }

    public static boolean isDaily() {
        return "daily".equals(env) || "dev".equals(env) || "project".equals(env);
    }
}
