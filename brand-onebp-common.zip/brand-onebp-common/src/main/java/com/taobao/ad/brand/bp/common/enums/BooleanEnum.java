package com.taobao.ad.brand.bp.common.enums;

/**
 * @author 虫洞 <liuming.liu@alibaba-inc.com>
 * @date 2023/3/6
 */
public enum BooleanEnum {
    FALSE(0, "否"),
    TRUE(1, "是");

    private final Integer value;
    private final String name;

    BooleanEnum(Integer value, String desc) {
        this.value = value;
        this.name = desc;
    }

    public Integer getValue() {
        return this.value;
    }

    public String getName() {
        return this.name;
    }
}