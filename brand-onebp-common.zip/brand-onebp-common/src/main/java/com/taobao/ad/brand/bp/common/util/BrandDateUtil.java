package com.taobao.ad.brand.bp.common.util;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.solar.common.utils.DateUtil;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.client.dto.base.DateViewDTO;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

public abstract class BrandDateUtil {
    public static final String DATE_FORMAT_YYYYMMDD_TYPE_1 = "yyyy-MM-dd";
    public static final String DATE_FORMAT_YYYYMMDD_TYPE_2 = "yyyyMMdd";
    public static final String DATE_FORMAT_YYYYMMDD_TYPE_3 = "yyyy.MM.dd";
    public static final String DATE_FORMAT_YYYYMM_TYPE_1 = "yyyyMM";
    public static final String DATE_FORMAT_MMDD_TYPE_1 = "MMdd";
    public static final String DATE_FORMAT_YYYYMMDD_TYPE_4 = "yyyy/MM/dd";
    public static final String DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_1 = "yyyy-MM-dd HH:mm:ss";
    public static final String DATE_FORMAT_YYYYMMDDHHMM_TYPE_1 = "yyyy-MM-dd HH:mm";
    public static final String DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_2 = "yyyy/MM/dd HH:mm:ss";
    public static final String DATE_FORMAT_YYYYMMDDHHMMSS= "yyyyMMddHHmmss";
    public static final String DATE_FORMAT_HHMMSS = "HHmmss";

    private static final long ONE_DAY = 24 * 60 * 60 * 1000L;


    public static void main(String[] args) throws ParseException {
        //String a = "2025-05-13 00:00:00";
        //String b = "2025-05-19 23:59:59";
        //String c = "2025-05-13 00:00:00";
        //String d = "2025-05-19 00:00:00";
        //Date aa = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(a);
        //Date bb = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(b);
        //Date cc = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(c);
        //Date dd = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(d);
        //Integer num = getNumOfDaysBetweenDate(aa,bb);
        //Integer num1 = getNumOfDaysBetweenDate(cc,dd);
        //System.out.println(num);
        //System.out.println(num1);
////        System.out.println(notAfter(aa,bb));
//
//        System.out.println(isMixed(cc,dd,aa,bb));

//        String sss = "https://bdlog.tanx.com/imp_n?pb=I65uV7HdHoMvS8mcGmD5JdYmhaex8SYX91UA4pzdTR2ph6O-f8Tqc3fEBBzlwH_UjR6N_UVUcmRHjaM7zbtutajCPAbyFfe4pBpl6ykV6DORsiRV4-JeT57EnjFSSQ_Bz_YzUfkEqejUvT-KHI6RbE61YBsMh8pkJoTCUKkZzmzGlROLqs5B6w&k=183&a1=__IP__&a2=__OS__&a3=__IDFA__&a4=__IMEI__&a5=__IMEI_MD5__&a6=__OAID__&a7=__MAC__&a8=__UA__&a9=__TS__&a17=__ANDROIDID__&a26=__ALI_AAID__&a27=__CAID__";
//        System.out.println(sss.getBytes().length);
//        System.out.println(sss.length());

        String d = "2024-11-11 00:00:00";
        Date dd = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(d);
        String s = "2024-11-01 00:00:00";
        Date ss = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(s);
        Pair<Date, Date> dto = getCycleDateViewDTO(ss, dd);
        System.out.println(dto);
    }

    /**
     * 获取时间区间
     *
     * @param start
     * @param end
     * @return
     */
    public static Set<Date> getBetweenDatesDateResult(Date start, Date end) {
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            start = dateFormat.parse(dateFormat.format(start));
            end = dateFormat.parse(dateFormat.format(end));
        } catch (Exception e) {
            RogerLogger.error("date format error", e);
        }
        Set<Date> result = new LinkedHashSet<>();
        Calendar tempStart = Calendar.getInstance();
        tempStart.setTime(start);
        Calendar tempEnd = Calendar.getInstance();
        tempEnd.setTime(end);
        while (tempStart.before(tempEnd)) {
            result.add(tempStart.getTime());
            tempStart.add(Calendar.DAY_OF_YEAR, 1);
        }
        result.add(end);
        return result;
    }

    /**
     * 是否是零点
     *
     * @param date
     * @return
     */
    public static Boolean isZeroTime(Date date) {
        Boolean result = false;
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);
        int second = calendar.get(Calendar.SECOND);
        int milliSecond = calendar.get(Calendar.MILLISECOND);
        if (hour == 0 && minute == 0 && second == 0 && milliSecond == 0) {
            result = true;
        }
        return result;
    }

    /**
     * 修改日期时间
     *
     * @param date     日期
     * @param dateType 日期类型，年、月、日等，eg：Calendar.DAY_OF_MONTH
     * @param num      日期变动值
     * @return
     */
    public static Date modifyDate(Date date, Integer dateType, Integer num) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(dateType, num);
        return calendar.getTime();
    }

    /**
     * 功能描述：取得日期段拆分成每天
     *
     * @param startDate
     * @param endDate
     * @return
     * @throws Exception
     */
    public static List<String> getYyyyMmDdDayList(Date startDate, Date endDate) {
        List<String> dayList = Lists.newArrayList();
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");

        Calendar c = Calendar.getInstance();
        c.setTime(startDate);
        while (c.getTime().compareTo(endDate) <= 0) {
            dayList.add(dateFormat.format(c.getTime()));
            c.add(Calendar.DAY_OF_YEAR, 1);
        }
        return dayList;
    }

    /**
     * 功能描述：取得日期段拆分成每天
     *
     * @param startDate
     * @param endDate
     * @return
     * @throws Exception
     */
    public static List<Date> getDayList(Date startDate, Date endDate) {
        List<Date> dayList = Lists.newArrayList();
        Calendar c = Calendar.getInstance();
        c.setTime(startDate);
        while (c.getTime().compareTo(endDate) <= 0) {
            dayList.add(c.getTime());
            c.add(Calendar.DAY_OF_YEAR, 1);

        }
        return dayList;
    }
    /**
     * 功能描述：取得日期段拆分成每天
     * @param dateViewDTOList
     * @return
     * @throws Exception
     */
    public static List<Date> getDayList(List<DateViewDTO> dateViewDTOList) {
        Set<Date> setDays = Sets.newHashSet();
        for (DateViewDTO dateViewDTO : dateViewDTOList){
            if (dateViewDTO.getStartDate() != null && dateViewDTO.getEndDate() != null) {
                List<Date> dayList = getDayList(dateViewDTO.getStartDate(), dateViewDTO.getEndDate());
                setDays.addAll(dayList);
            }
        }
        return Lists.newArrayList(setDays);

    }

    /**
     * 计算日期相差天数
     *
     * @param startDate
     * @param endDate
     * @return
     */
    public static int getNumOfDaysBetweenDate(Date startDate, Date endDate) {
        if (startDate != null && endDate != null) {
            Calendar tempStart = Calendar.getInstance();
            tempStart.setTime(startDate);
            Calendar tempEnd = Calendar.getInstance();
            tempEnd.setTime(endDate);

            int result = 0;
            while (tempStart.before(tempEnd)) {
                result++;
                tempStart.add(Calendar.DAY_OF_YEAR, 1);
            }
            return result;
        }
        return -1;
    }

    public static Date getMaxDate(Date date) {
        String dateStr = date2String(date, DATE_FORMAT_YYYYMMDD_TYPE_1);
        Date dateResult = string2Date(dateStr + " 23:59:59", DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_1);
        return dateResult;
    }

    public static Date getMinDate(Date date) {
        String dateStr = date2String(date, DATE_FORMAT_YYYYMMDD_TYPE_1);
        Date dateResult = string2Date(dateStr + " 00:00:00", DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_1);
        return dateResult;
    }

    public static Date getMinDate(Date date1, Date date2) {
        if (date1 == null || date2 == null) {
            return null;
        }
        return date1.before(date2) ? date1 : date2;
    }

    public static Date getMaxDate(Date date1, Date date2) {
        if (date1 == null || date2 == null) {
            return null;
        }
        return date1.after(date2) ? date1 : date2;
    }


    /**
     * 判断2个时间段是否有重叠（交集）
     *
     * @param startDate        时间段1开始时间戳
     * @param endDate          时间段1结束时间戳
     * @param compareStartDate 时间段2开始时间戳
     * @param compareEndDate   时间段2结束时间戳
     * @return 返回是否重叠
     */
    public static boolean isMixed(Date startDate, Date endDate, Date compareStartDate, Date compareEndDate) {
        Set<Date> dates = getBetweenDatesDateResult(startDate, endDate);
        Set<Date> compareDates = getBetweenDatesDateResult(compareStartDate, compareEndDate);
        dates.retainAll(compareDates);
        if (CollectionUtils.isNotEmpty(dates)) {
            return true;
        }
        return false;
    }

    /**
     * 判断时间段2是否是时间段1的子集
     *
     * @param startDate        时间段1开始时间戳
     * @param endDate          时间段1结束时间戳
     * @param compareStartDate 时间段2开始时间戳
     * @param compareEndDate   时间段2结束时间戳
     * @return 返回间段2是否是时间段1的子集
     */
    public static boolean isOverlap(Date startDate, Date endDate, Date compareStartDate, Date compareEndDate) {
        Set<Date> dates = getBetweenDatesDateResult(startDate, endDate);
        Set<Date> compareDates = getBetweenDatesDateResult(compareStartDate, compareEndDate);
        dates.retainAll(compareDates);
        if (CollectionUtils.isNotEmpty(dates) && dates.size() == compareDates.size()) {
            return true;
        }
        return false;
    }

    /**
     * 判断2个时间段是否有重叠（交集）
     *
     * @param startDate        时间段1开始时间戳
     * @param endDate          时间段1结束时间戳
     * @param compareStartDate 时间段2开始时间戳
     * @param compareEndDate   时间段2结束时间戳
     * @return 返回重叠日期
     */
    public static List<Date> getMixedDate(Date startDate, Date endDate, Date compareStartDate, Date compareEndDate) {
        Set<Date> dates = getBetweenDatesDateResult(startDate, endDate);
        Set<Date> compareDates = getBetweenDatesDateResult(compareStartDate, compareEndDate);
        dates.retainAll(compareDates);
        if (CollectionUtils.isNotEmpty(dates)) {
            return Lists.newArrayList(dates);
        }
        return Lists.newArrayList();
    }

    /**
     * 判断2个时间段是否有重叠（交集）
     *
     * @param left  左时间段
     * @param right 由时间段
     * @return 返回是否重叠
     */
    public static List<Date> getMixedDate(List<DateViewDTO> left, List<DateViewDTO> right) {
        Set<Date> setResult = Sets.newHashSet();
        for (DateViewDTO l : left) {
            for (DateViewDTO r : right) {

                List<Date> mixedDateList = getMixedDate(l.getStartDate(), l.getEndDate(), r.getStartDate(), r.getEndDate());
                setResult.addAll(mixedDateList);
            }
        }
        return CollectionUtils.isNotEmpty(setResult) ? Lists.newArrayList(setResult) : Lists.newArrayList();

    }

    /**
     * 是否历史时间
     *
     * @param currentTimestamp
     * @return
     */
    public static boolean isHistoryTime(long currentTimestamp) {
        long historyTime = LocalDateTime.of(LocalDate.now(), LocalTime.MIN).atZone(ZoneId.systemDefault()).toInstant()
                .toEpochMilli();
        return currentTimestamp < historyTime;
    }

    /**
     * 是否历史时间
     *
     * @param currentDate
     * @return
     */
    public static boolean isHistoryTime(Date currentDate) {
        return isHistoryTime(currentDate.getTime());
    }


    public static String date2String(Date date) {
        return date2String(date, DATE_FORMAT_YYYYMMDD_TYPE_1);
    }

    /**
     * 日期转字符串
     *
     * @param date   日期
     * @param format 格式
     * @return string
     */
    public static String date2String(Date date, String format) {
        if (date == null) {
            return StringUtils.EMPTY;
        }
        SimpleDateFormat dateFormat = new SimpleDateFormat(format);
        return dateFormat.format(date);
    }

    public static Date string2Date(String date, String format) {
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        try {
            return sdf.parse(date);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 当前时间的 00：00：00
     */
    public static Date getCurrentDate() {
        Calendar calendar = getCurrentCalendarDate();
        return calendar.getTime();
    }

    public static Integer getCurrentDiffMonth(int diff) {
        Calendar calendar = getCurrentCalendarDate();
        calendar.add(Calendar.MONTH, diff);
        return calendar.get(Calendar.MONTH) + 1;
    }

    public static Integer getDiffMonth(int diff, Date date) {
        Calendar calendar = getCalendarDate(date);
        calendar.add(Calendar.MONTH, diff);
        return calendar.get(Calendar.MONTH) + 1;
    }

    public static String getCurrentMonthFirstDay() {
        Calendar calendar = getCurrentCalendarDate();
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        return date2String(calendar.getTime(), DATE_FORMAT_YYYYMMDD_TYPE_2);
    }

    public static String getMonthFirstDay(Date date) {
        Calendar calendar = getCalendarDate(date);
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        return date2String(calendar.getTime(), DATE_FORMAT_YYYYMMDD_TYPE_2);
    }

    public static String getCurrentDiffMonthFirstDay(int diffMonth) {
        Calendar calendar = getCurrentCalendarDate();
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        calendar.add(Calendar.MONTH, diffMonth);
        return date2String(calendar.getTime(), DATE_FORMAT_YYYYMMDD_TYPE_2);
    }

    public static String getDiffMonthFirstDay(int diffMonth, Date date) {
        Calendar calendar = getCalendarDate(date);
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        calendar.add(Calendar.MONTH, diffMonth);
        return date2String(calendar.getTime(), DATE_FORMAT_YYYYMMDD_TYPE_2);
    }

    public static String getCurrentDiffMonthEndDay(int diffMonth) {
        Calendar calendar = getCurrentCalendarDate();
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        calendar.add(Calendar.MONTH, diffMonth);
        return date2String(calendar.getTime(), DATE_FORMAT_YYYYMMDD_TYPE_2);
    }

    public static String getDiffMonthEndDay(int diffMonth, Date date) {
        Calendar calendar = getCalendarDate(date);
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        calendar.add(Calendar.MONTH, diffMonth);
        return date2String(calendar.getTime(), DATE_FORMAT_YYYYMMDD_TYPE_2);
    }

    /**
     * 当前日期 yyyyMMdd
     */
    public static String getCurrentDateStr() {
        Calendar calendar = getCurrentCalendarDate();
        return date2String(calendar.getTime(), DATE_FORMAT_YYYYMMDD_TYPE_2);
    }

    /**
     * 获取明天日期 00:00:00
     *
     * @return
     */
    public static Date getTomorrowDate() {
        Calendar calendar = getCurrentCalendarDate();
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        return calendar.getTime();
    }

    /**
     * 获取昨天日期00:00:00
     *
     * @return
     */
    public static Date getYesterdayDate() {
        Calendar calendar = getCurrentCalendarDate();
        calendar.add(Calendar.DAY_OF_MONTH, -1);
        return calendar.getTime();
    }


    /**
     * 获取当前日期的calendar对象
     * 00:00:00
     *
     * @return
     */
    private static Calendar getCurrentCalendarDate() {
        return getCalendarDate(new Date());
    }

    /**
     * 获取当前日期的calendar对象
     * 00:00:00
     *
     * @param date
     * @return
     */
    private static Calendar getCalendarDate(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar;
    }

    /**
     * 判断startTime不在endTime后面
     *
     * @param startTime
     * @param endTime
     * @return
     */
    public static boolean notAfter(Date startTime, Date endTime) {
        AssertUtil.notNull(startTime);
        AssertUtil.notNull(endTime);
        if (startTime.before(endTime) || startTime.equals(endTime)) {
            return true;
        }
        return false;
    }


    /**
     * 判断startTime不在endTime前面
     *
     * @param date1
     * @param date2
     * @return
     */
    public static boolean isBeforeAndEqual(Date date1, Date date2) {
        AssertUtil.notNull(date1);
        AssertUtil.notNull(date2);
        if (date1.before(date2) || date1.equals(date2)) {
            return true;
        }
        return false;
    }

    /**
     * 判断startTime不在endTime后面
     *
     * @param date1
     * @param date2
     * @return
     */
    public static boolean isAfterAndEqual(Date date1, Date date2) {
        AssertUtil.notNull(date1);
        AssertUtil.notNull(date2);
        if (date1.after(date2) || date1.equals(date2)) {
            return true;
        }
        return false;
    }

    public static boolean isBefore(Date startTime, Date endTime) {
        AssertUtil.notNull(startTime);
        AssertUtil.notNull(endTime);
        return startTime.before(endTime);
    }

    public static boolean isAfter(Date startTime, Date endTime) {
        AssertUtil.notNull(startTime);
        AssertUtil.notNull(endTime);
        return startTime.after(endTime);
    }

    public static Date maxDate(Date date1, Date date2) {
        if (isBefore(date1, date2)) {
            return date2;
        }
        return date1;
    }

    public static Date minDate(Date date1, Date date2) {
        if (isBefore(date1, date2)) {
            return date1;
        }
        return date2;
    }

    /**
     * 获取代表某日期的date，时间是23:59:59
     *
     * @return
     */
    public static Date getDateFullMidnight(Date date) {
        if (date == null) {
            return null;
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTime();
    }

    /**
     * 获取代表某日期的date，时间是00:00:00
     *
     * @return
     */
    public static Date getDateMidnight(Date date) {
        if (date == null) {
            return null;
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTime();
    }

    /**
     * 获取时间间隔<br/>
     *
     * @param startTime (include)
     * @param endTime   (include)
     * @return
     */
    public static Integer getDateRange(Date startTime, Date endTime) {
        AssertUtil.notNull(startTime);
        AssertUtil.notNull(endTime);
        startTime = getDateMidnight(startTime);
        endTime = getDateMidnight(endTime);
        Long diff = endTime.getTime() - startTime.getTime();
        return (int) (diff / (1000 * 60 * 60 * 24));
    }

    public static List<DateViewDTO> formatDateQuantum(List<Date> dateList) {
        if (dateList == null || dateList.isEmpty()) {
            return Collections.emptyList();
        }
        dateList = dateList.stream().sorted().collect(Collectors.toList());
        List<DateViewDTO> dataModels = new ArrayList<>();
        Date nowDate = dateList.get(0);
        Date startDate = nowDate;
        int index = 1;
        while (index < dateList.size()) {
            Date endDate = dateList.get(index);
            //时间相邻
            if (endDate.getTime() - startDate.getTime() == ONE_DAY) {
                startDate = endDate;
                index++;
                continue;
            }
            DateViewDTO dateModel = new DateViewDTO();
            dateModel.setStartDate(nowDate);
            dateModel.setEndDate(startDate);
            dataModels.add(dateModel);

            nowDate = endDate;
            startDate = endDate;
            index++;
        }

        DateViewDTO dateModel = new DateViewDTO();
        dateModel.setStartDate(nowDate);
        dateModel.setEndDate(startDate);
        dataModels.add(dateModel);

        return dataModels.stream().sorted(Comparator.comparing(DateViewDTO::getStartDate)).collect(Collectors.toList());
    }

    /**
     * 年月日 判断是否一天
     */
    public static boolean isSameDay(Date date1, Date date2) {
        if (date1 != null && date2 != null) {
            Calendar cal1 = Calendar.getInstance();
            cal1.setTime(date1);
            Calendar cal2 = Calendar.getInstance();
            cal2.setTime(date2);
            return isSameDay(cal1, cal2);
        } else {
            throw new IllegalArgumentException("The date must not be null");
        }
    }

    /**
     * 年月日 判断是否一天
     */
    public static boolean isSameDay(Calendar cal1, Calendar cal2) {
        if (cal1 != null && cal2 != null) {
            return cal1.get(Calendar.ERA) == cal2.get(Calendar.ERA) && cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) && cal1.get(
                    Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR);
        } else {
            throw new IllegalArgumentException("The date must not be null");
        }
    }

    /**
     * 判断targetTime时间是否在range中，
     *
     * @return 如果在range前，则返回 <0 <br/>
     * 如果在range中,则返回 ==0 <br/>
     * 如果在range后，则返回 >0 <br/>
     */
    public static int timeRange(Date targetTime, Date startTime, Date endTime) {
        if (targetTime.before(startTime)) {
            return -1;
        } else if (targetTime.after(endTime)) {
            return 1;
        }
        return 0;
    }

    public static Date getAfterDate(Date date, int day) {
        return getAfterDate(date, day, 0, 0);
    }

    public static Date getAfterDate(Date date, int day, int hour, int min) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        if (0 != day) {
            cal.add(Calendar.DATE, day);
        }
        if (0 != hour) {
            cal.add(Calendar.HOUR_OF_DAY, hour);
        }
        if (0 != min) {
            cal.add(Calendar.MINUTE, min);
        }
        return cal.getTime();
    }


    /**
     * 日期转化成时间戳
     */
    public static long getSecondTimestamp(Date date) {
        if (null == date) {
            return 0;
        }
        String timestamp = String.valueOf(date.getTime() / 1000);
        return Long.parseLong(timestamp);
    }

    /**
     * 获取当前时间13位时间戳
     *
     * @return
     */
    public static long getTimestampInMillis() {
        return Calendar.getInstance().getTimeInMillis();
    }

    /**
     * 获取当前时间
     *
     * @return
     */
    public static Date getCurrentTime() {
        return Calendar.getInstance().getTime();
    }

    public static boolean isStringDateValid(String dateString, String dateFormat) {
        if (Objects.isNull(dateString) || Objects.isNull(dateFormat)) {
            return false;
        }
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
        try {
            sdf.parse(dateString);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    /**
     * 判断时间段列表是否完全覆盖指定时间段
     * 支持时分秒
     *
     * @param unionPeriods 时间段列表
     * @param dateViewDTO  指定时间段
     * @return 是否覆盖
     */
    public static boolean isFullyCovered(List<DateViewDTO> unionPeriods, DateViewDTO dateViewDTO) {
        if (CollectionUtils.isEmpty(unionPeriods) || dateViewDTO == null) {
            return false;
        }
        List<DateViewDTO> sortDateViewDTOS = getUnionTimeSort(unionPeriods);
        if (CollectionUtils.isEmpty(sortDateViewDTOS)) {
            return false;
        }
        Date coveredTill = dateViewDTO.getStartDate();
        for (DateViewDTO sortDateViewDTO : sortDateViewDTOS) {
            //判断是否存在间断
            if (coveredTill.before(sortDateViewDTO.getStartDate())) {
                return false;
            } else if (coveredTill.before(sortDateViewDTO.getEndDate())) {
                //扩展覆盖范围 增加容差值 1s  防止 2024-01-01 23:59:59  和 2024-01-02 00:00:00 被认为不连续
                coveredTill = Date.from(sortDateViewDTO.getEndDate().toInstant().atZone(ZoneId.systemDefault()).plusSeconds(1).toInstant());
            }
            //如果覆盖范围已经超过给定时间段的结束时间或者等于结束时间 表示完全覆盖
            if (!coveredTill.before(dateViewDTO.getEndDate())) {
                return true;
            }
        }

        return false;
    }

    /**
     * 合并时间段 10-15 12-13 16-17 -> 10-17
     * @param dateViewDTOS 待合并列表
     * @return
     */
    public static List<DateViewDTO> getUnionTimeSort(List<DateViewDTO> dateViewDTOS) {
        if (CollectionUtils.isEmpty(dateViewDTOS)) {
            return null;
        }
        //时间段排序
        dateViewDTOS.sort(Comparator.comparing(DateViewDTO::getStartDate));
        List<DateViewDTO> result = Lists.newArrayList();
        DateViewDTO current = dateViewDTOS.get(0);
        for (int i = 1; i < dateViewDTOS.size(); i++) {
            DateViewDTO next = dateViewDTOS.get(i);
            if (current.getStartDate().before(next.getEndDate()) && next.getStartDate().before(current.getEndDate())) {
                Date start = current.getStartDate().before(next.getStartDate()) ? current.getStartDate() : next.getStartDate();
                Date end = current.getEndDate().before(next.getEndDate()) ? next.getEndDate() : current.getEndDate();
                DateViewDTO dateViewDTO = new DateViewDTO();
                dateViewDTO.setStartDate(start);
                dateViewDTO.setEndDate(end);
                current = dateViewDTO;
            } else {
                result.add(current);
                current = next;
            }
        }
        result.add(current);
        RogerLogger.info("getUnionTimeSort 合并后时间段 {}", JSONObject.toJSONStringWithDateFormat(result, DateUtil.DEFAULT_FORMAT));
        return result;
    }

    public static boolean isBetweenDate(Date startDate, Date endDate,Date date) {

        Set<Date> dayList = getBetweenDatesDateResult(startDate,endDate);
        return  dayList.contains(date);

    }

    public static DateViewDTO findIntersection(DateViewDTO period1, DateViewDTO period2) {
        Date start1 = period1.getStartDate();
        Date end1 = period1.getEndDate();
        Date start2 = period2.getStartDate();
        Date end2 = period2.getEndDate();
        if (start1 == null || start2 == null || end1 == null || end2 == null) {
            return null;
        }
        Date intersectionStart = start1.after(start2) ? start1 : start2;
        Date intersectionEnd = end1.before(end2) ? end1 : end2;

        if (intersectionStart.before(intersectionEnd) || intersectionStart.equals(intersectionEnd)) {
            DateViewDTO dateViewDTO = new DateViewDTO();
            dateViewDTO.setStartDate(intersectionStart);
            dateViewDTO.setEndDate(intersectionEnd);
            return dateViewDTO;
        } else {
            // 无交集
            return null;
        }
    }

    /**
     * 获取指定时间位移指定天数后的日期
     *
     * @param date 时间
     * @param daysToAdd
     * @return
     */
    public static Date getPlusDate(Date date, Integer daysToAdd) {
        LocalDate localDate = fromDate(date);
        localDate = localDate.plusDays(daysToAdd);
        return Date.from(localDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
    }

    public static LocalDate fromDate(Date date) {
        Instant instant = date.toInstant();
        ZoneId zone = ZoneId.systemDefault();
        LocalDateTime localDateTime = LocalDateTime.ofInstant(instant, zone);
        LocalDate localDate = localDateTime.toLocalDate();
        return localDate;
    }

    public static List<String> getTimeList(List<Integer> hourList, int minHour){
        //小时列表分成多个连续区间
        Set<String> timeSet = Sets.newHashSet();
        int start = hourList.get(0);
        for (int i = 0; i < hourList.size(); i++) {
            if (i+1 >= hourList.size() || hourList.get(i+1) > hourList.get(i) + 1) {
                for (int j = hourList.get(i); j >= start; j--) {
                    //一个连续区间中符合最小小时数的所有时段
                    timeSet.addAll(getIntervalHours(start, j, minHour - 1));
                }
                if (i+1 < hourList.size()) {
                    start = hourList.get(i+1);
                }
            }
        }
        return timeSet.stream().sorted().collect(Collectors.toList());
    }

    public static Set<String> getIntervalHours(int start,int end,int minHour){
        Set<String> hourString = Sets.newHashSet();
        while(start <= end - minHour){
            String x = String.format("%02d", start) + ":00" + "-" + String.format("%02d", end) + ":59";
            hourString.add(x);
            start ++;
        }
        return hourString;
    }

    // 计算环比时间段
    public static Pair<Date, Date> getCycleDateViewDTO(Date startDate, Date endDate) {
        int step = getNumOfDaysBetweenDate(startDate, endDate) + 1;
        return Pair.of(getAfterDate(startDate, -step), getAfterDate(endDate, -step));
    }

}

