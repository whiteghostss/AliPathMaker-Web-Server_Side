package com.taobao.ad.brand.bp.common.constant.campaigngroup;

import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupEventEnum;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.SalesContractStateEnum;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author yanjingang
 * @date 2023/7/15
 */
public class CampaignGroupConstant {

    /**
     * 主订单状态迁移事件 到 主->子联动事件的映射
     */
    public static final Map<CampaignGroupEventEnum, CampaignGroupEventEnum> CAMPAIGN_GROUP_MAIN_2_SUB_EVENT_MAP = Maps.newHashMap();
    static {
        CAMPAIGN_GROUP_MAIN_2_SUB_EVENT_MAP.put(CampaignGroupEventEnum.CONTRACT_PAY, CampaignGroupEventEnum.CONTRACT_PAY);
        CAMPAIGN_GROUP_MAIN_2_SUB_EVENT_MAP.put(CampaignGroupEventEnum.STOP_CAST, CampaignGroupEventEnum.STOP_CAST);
        CAMPAIGN_GROUP_MAIN_2_SUB_EVENT_MAP.put(CampaignGroupEventEnum.REAL_SETTLE, CampaignGroupEventEnum.REAL_SETTLE);
        CAMPAIGN_GROUP_MAIN_2_SUB_EVENT_MAP.put(CampaignGroupEventEnum.REAL_SETTLE_APPROVE, CampaignGroupEventEnum.REAL_SETTLE_APPROVE);
        CAMPAIGN_GROUP_MAIN_2_SUB_EVENT_MAP.put(CampaignGroupEventEnum.REAL_SETTLE_REFUSE, CampaignGroupEventEnum.REAL_SETTLE_REFUSE);
        CAMPAIGN_GROUP_MAIN_2_SUB_EVENT_MAP.put(CampaignGroupEventEnum.COMPLETE, CampaignGroupEventEnum.COMPLETE);
        CAMPAIGN_GROUP_MAIN_2_SUB_EVENT_MAP.put(CampaignGroupEventEnum.COMPLETE_REVERT, CampaignGroupEventEnum.COMPLETE_REVERT);
        CAMPAIGN_GROUP_MAIN_2_SUB_EVENT_MAP.put(CampaignGroupEventEnum.CANCEL, CampaignGroupEventEnum.CANCEL);
    }

    public static final Map<CampaignGroupEventEnum, CampaignGroupEventEnum> SELF_CAMPAIGN_GROUP_MAIN_2_SUB_EVENT_MAP = Maps.newHashMap();
    static {
        SELF_CAMPAIGN_GROUP_MAIN_2_SUB_EVENT_MAP.put(CampaignGroupEventEnum.CONTRACT_PAY, CampaignGroupEventEnum.CONTRACT_PAY);
    }

    public static final List<CampaignGroupEventEnum> IGNORE_EVENT_LIST_FOR_SELF_SERVICE_FROM_BRIEF = Lists.newArrayList(
            CampaignGroupEventEnum.REAL_SETTLE,
            CampaignGroupEventEnum.REAL_SETTLE_APPROVE,
            CampaignGroupEventEnum.REAL_SETTLE_REFUSE,
            CampaignGroupEventEnum.CANCEL,
            CampaignGroupEventEnum.COMPLETE,
            CampaignGroupEventEnum.COMPLETE_REVERT
    );


    /**
     * 子订单状态迁移事件 到 子->主联动事件的映射
     */
    public static final Map<CampaignGroupEventEnum, CampaignGroupEventEnum> CAMPAIGN_GROUP_SUB_2_MAIN_EVENT_MAP = Maps.newHashMap();
    static {
        CAMPAIGN_GROUP_SUB_2_MAIN_EVENT_MAP.put(CampaignGroupEventEnum.ORDER, CampaignGroupEventEnum.ORDER);
        CAMPAIGN_GROUP_SUB_2_MAIN_EVENT_MAP.put(CampaignGroupEventEnum.BOOST_OR_GIVE_ORDER, CampaignGroupEventEnum.BOOST_OR_GIVE_ORDER);
        CAMPAIGN_GROUP_SUB_2_MAIN_EVENT_MAP.put(CampaignGroupEventEnum.MODIFY_ORDER, CampaignGroupEventEnum.MODIFY_ORDER);
        CAMPAIGN_GROUP_SUB_2_MAIN_EVENT_MAP.put(CampaignGroupEventEnum.FINISH, CampaignGroupEventEnum.FINISH);
        CAMPAIGN_GROUP_SUB_2_MAIN_EVENT_MAP.put(CampaignGroupEventEnum.FINISH_REVERT, CampaignGroupEventEnum.FINISH_REVERT);
        CAMPAIGN_GROUP_SUB_2_MAIN_EVENT_MAP.put(CampaignGroupEventEnum.REAL_SETTLE_CONFIG, CampaignGroupEventEnum.REAL_SETTLE_CONFIG);
    }

    public static final Set<CampaignGroupEventEnum> SUB_CAMPAIGN_GROUP_INNER_EVENT_SET = Sets.newHashSet();
    static {
        SUB_CAMPAIGN_GROUP_INNER_EVENT_SET.add(CampaignGroupEventEnum.COMPLETE);
    }

    public static final Map<CampaignGroupEventEnum, CampaignGroupEventEnum> SELF_CAMPAIGN_GROUP_SUB_2_MAIN_EVENT_MAP = Maps.newHashMap();
    static {
        SELF_CAMPAIGN_GROUP_SUB_2_MAIN_EVENT_MAP.put(CampaignGroupEventEnum.PRE_ORDER, CampaignGroupEventEnum.PRE_ORDER);
        SELF_CAMPAIGN_GROUP_SUB_2_MAIN_EVENT_MAP.put(CampaignGroupEventEnum.ORDER, CampaignGroupEventEnum.ORDER);
        SELF_CAMPAIGN_GROUP_SUB_2_MAIN_EVENT_MAP.put(CampaignGroupEventEnum.FINISH, CampaignGroupEventEnum.FINISH);
        SELF_CAMPAIGN_GROUP_SUB_2_MAIN_EVENT_MAP.put(CampaignGroupEventEnum.FINISH_REVERT, CampaignGroupEventEnum.FINISH_REVERT);
        SELF_CAMPAIGN_GROUP_SUB_2_MAIN_EVENT_MAP.put(CampaignGroupEventEnum.CANCEL, CampaignGroupEventEnum.CANCEL);
        SELF_CAMPAIGN_GROUP_SUB_2_MAIN_EVENT_MAP.put(CampaignGroupEventEnum.COMPLETE, CampaignGroupEventEnum.COMPLETE);
        SELF_CAMPAIGN_GROUP_SUB_2_MAIN_EVENT_MAP.put(CampaignGroupEventEnum.REAL_SETTLE_CONFIG, CampaignGroupEventEnum.REAL_SETTLE_CONFIG);
        SELF_CAMPAIGN_GROUP_SUB_2_MAIN_EVENT_MAP.put(CampaignGroupEventEnum.REAL_SETTLE_APPROVE, CampaignGroupEventEnum.REAL_SETTLE_APPROVE);
    }


    public static final List<Integer> EFFECT_ADV_CAN_UNBIND_STATUS = Lists.newArrayList();
    static {
        EFFECT_ADV_CAN_UNBIND_STATUS.add(BrandCampaignGroupStatusEnum.EDITED.getCode());
    }
    public static final List<Integer> EFFECT_ADV_CAN_BIND_STATUS = Lists.newArrayList();
    static {
        EFFECT_ADV_CAN_BIND_STATUS.add(BrandCampaignGroupStatusEnum.EDITED.getCode());
        EFFECT_ADV_CAN_BIND_STATUS.add(BrandCampaignGroupStatusEnum.ORDER_ING.getCode());
        EFFECT_ADV_CAN_BIND_STATUS.add(BrandCampaignGroupStatusEnum.UNLOCKED.getCode());

        EFFECT_ADV_CAN_BIND_STATUS.add(BrandCampaignGroupStatusEnum.CONTRACT_PROCESS_ING.getCode());
        EFFECT_ADV_CAN_BIND_STATUS.add(BrandCampaignGroupStatusEnum.WAIT_CAST.getCode());
        EFFECT_ADV_CAN_BIND_STATUS.add(BrandCampaignGroupStatusEnum.CAST_ING.getCode());

    }

//    /**
//     * 主订单-下单时有效的主订单状态
//     */
//    public static final List<Integer> validMainCampaignGroupStatusOnOrder = Lists.newArrayList(
//            BrandCampaignGroupStatusEnum.EDITED.getCode(),
//            BrandCampaignGroupStatusEnum.UNLOCKED.getCode()
//    );
//
//    /**
//     * 主订单-下单时无效的子订单状态
//     */
//    public static final List<Integer> inValidSubCampaignGroupStatusOnOrder = Lists.newArrayList(
//            BrandCampaignGroupStatusEnum.EDITED.getCode(),
//            BrandCampaignGroupStatusEnum.UNLOCKED.getCode()
//    );

    /**
     * 下单时有效的计划状态
     */
    public static final List<Integer> validCampaignStatusOnOrder = Lists.newArrayList(
            BrandCampaignStatusEnum.LOCK_SUCCESS.getCode(),
            BrandCampaignStatusEnum.WAITING.getCode(),
            BrandCampaignStatusEnum.CASTING.getCode(),
            BrandCampaignStatusEnum.PAUSING.getCode(),
            BrandCampaignStatusEnum.ENDING.getCode()
    );

    /**
     * 订单投放状态
     */
    public static final List<Integer> campaignGroupCastStatusList = Lists.newArrayList(
            BrandCampaignGroupStatusEnum.WAIT_CAST.getCode(),
            BrandCampaignGroupStatusEnum.CAST_ING.getCode(),
            BrandCampaignGroupStatusEnum.CAST_FINISH.getCode()
    );

    public static final List<Integer> validSubSaleCampaignGroupUnlockRevertStatusList = Lists.newArrayList(
            BrandCampaignGroupStatusEnum.RESOURCE_CONFIRM_ING.getCode(),
            BrandCampaignGroupStatusEnum.WAIT_CAST.getCode(),
            BrandCampaignGroupStatusEnum.CAST_ING.getCode(),
            BrandCampaignGroupStatusEnum.CAST_FINISH.getCode(),
            BrandCampaignGroupStatusEnum.FINISHED.getCode()
    );

    /**
     * 需要处理的合同状态
     */
    public static final List<Integer> validContractStatusList = Lists.newArrayList(
            SalesContractStateEnum.WAIT_APPROVE_AFTER_CREATE.getValue(),
            SalesContractStateEnum.WAIT_APPROVE_MODIFY.getValue(),
            SalesContractStateEnum.WAIT_APPROVE_MODIFY_AFTER_LAUNCH.getValue(),
            SalesContractStateEnum.WAIT_PAYMENT_AFTER_CREATE.getValue(),
            SalesContractStateEnum.WAIT_PAYMENT_AFTER_PAYED.getValue(),
            SalesContractStateEnum.WAIT_PAYMENT_AFTER_LAUNCH.getValue(),
            SalesContractStateEnum.WAIT_ONLINE_CONFIRM.getValue(),
            SalesContractStateEnum.WAIT_RECEIPT_APPROVAL.getValue()
    );

    public static final List<Integer> validUpdateSubSaleCampaignGroupStatusList = Lists.newArrayList(
            BrandCampaignGroupStatusEnum.EDITED.getCode(),
            BrandCampaignGroupStatusEnum.UNLOCKED.getCode()
    );

    public static final String MAIN_CAMPAIGN_GROUP_ID_KEY = "mainCampaignGroupId";

    public static final String CUSTOMER_PRIORITY_DEFAULT = "C";


    public static final String INQUIRY_MAX_DATE="2099-01-01 00:00:00";

    public static final String INQUIRY_MIN_DATE="2000-01-01 00:00:00";

}
