package com.taobao.ad.brand.bp.common.util;

import com.taobao.ad.brand.bp.common.constant.Constant;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.util.Map;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class CheckSumUtil {

    /**
     * 获取md5值
     *
     * @param paramMap 参数map
     * @param key      md5的salt
     * @return md5值
     */
    public static String getMd5SimpleCheckSum(Map<String, Object> paramMap, String key) {
        StringBuffer buffer = new StringBuffer();
        for (Map.Entry<String, Object> entry : paramMap.entrySet()) {
            buffer.append(entry.getValue());
        }

        buffer.append(key);
        return Md5Encrypt.md5(buffer.toString(), Constant.DEFAULT_CHARSET);
    }

    /**
     * 获取md5值(标准版)
     *
     * @param paramMap 参数map
     * @param key      md5的salt
     * @return md5值
     */
    public static String getMd5CheckSum(Map<String, Object> paramMap, String key) {
        StringBuffer buffer = new StringBuffer();

        for (Map.Entry<String, Object> entry : paramMap.entrySet()) {
            buffer.append(entry.getKey()).append("=")
                    .append(entry.getValue()).append("&");
        }

        if (buffer.length() > 0) {
            buffer.deleteCharAt(buffer.length() - 1);
        }

        buffer.append(key);
        return Md5Encrypt.md5(buffer.toString(), Constant.DEFAULT_CHARSET);
    }

    public static String getMd5(String content) {
        return Md5Encrypt.md5(content, Constant.DEFAULT_CHARSET);

    }
}
