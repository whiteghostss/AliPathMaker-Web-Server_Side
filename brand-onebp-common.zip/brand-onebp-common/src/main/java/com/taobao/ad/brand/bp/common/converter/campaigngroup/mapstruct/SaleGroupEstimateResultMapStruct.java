package com.taobao.ad.brand.bp.common.converter.campaigngroup.mapstruct;

import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupEstimateInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupEstimateInfoViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.control.DeepClone;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, mappingControl= DeepClone.class)
public interface SaleGroupEstimateResultMapStruct extends BaseMapStructMapper<SaleGroupEstimateInfoViewDTO, CampaignGroupSaleGroupEstimateInfoViewDTO> {
    SaleGroupEstimateResultMapStruct INSTANCE = Mappers.getMapper(SaleGroupEstimateResultMapStruct.class);
    @Mappings(
            @Mapping(source = "estimateDeliverResult", target = "estimateResult")
    )
    @Override
    CampaignGroupSaleGroupEstimateInfoViewDTO sourceToTarget(SaleGroupEstimateInfoViewDTO saleGroupEstimateInfoViewDTO);
    //,
    //
    @Mappings(
            @Mapping(source = "estimateResult", target = "estimateDeliverResult")
    )
    @Override
    SaleGroupEstimateInfoViewDTO targetToSource(CampaignGroupSaleGroupEstimateInfoViewDTO campaignGroupSaleGroupEstimateInfoViewDTO);

}
