package com.taobao.ad.brand.bp.common.converter.campaigngroup;

import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.common.converter.campaigngroup.mapstruct.CampaignGroupViewMapStruct;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author yanjingang
 * @date 2023/7/9
 */
@Component
public class CampaignGroupViewConverter {

    public CampaignGroupViewDTO convertSelf(CampaignGroupViewDTO source){
        return  CampaignGroupViewMapStruct.INSTANCE.copySelf(source);
    }

    public List<SaleGroupInfoViewDTO> convertSaleGroupInfoSelfList(List<SaleGroupInfoViewDTO> sourceList){
        return  CampaignGroupViewMapStruct.INSTANCE.copyCampaignGroupSaleGroupInfoSelfList(sourceList);
    }

}
