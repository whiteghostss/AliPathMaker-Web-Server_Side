package com.taobao.ad.brand.bp.common.util;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * @author yuncheng.lyc
 * @date 2023/3/13
 **/
public class PageUtil {
    public final static int MAX_PAGE_COUNT = 200;
    /**
     * 分页请求
     * @param func
     * @param page
     * @param consumer
     * @param <R>
     */
    public static <R> void execute(Function<Integer, R> func, Function<R, Integer> page, Consumer<R> consumer) {
        R r;
        int idx = 1;
        do {
            try {
                r = func.apply(idx);
            } catch (Throwable e) {
                break;
            }
            int totalPage = page.apply(r);
            consumer.accept(r);
            if (idx >= totalPage) {
                break;
            }
            idx++;
        } while (true);
    }

    public static <R> void execute2(Function<Integer, R> func, Predicate<R> breakFunc, Consumer<R> consumer) {
        R r;
        int idx = 1;
        do {
            try {
                r = func.apply(idx);
            } catch (Throwable e) {
                break;
            }
            consumer.accept(r);
            if (breakFunc.test(r)) {
                break;
            }
            idx++;
        } while (true);
    }

    public static int getTotalPage(int total, int pageSize) {
        return total / pageSize + (total % pageSize == 0 ? 0 : 1);
    }
}
