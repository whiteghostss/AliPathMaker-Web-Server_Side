package com.taobao.ad.brand.bp.common.converter.campaigngroup;

import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.common.SchemaConfigDetailViewDTO;
import com.alibaba.ad.brand.dto.common.SchemaConfigViewDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupResourcePackageViewDTO;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.stream.Collectors;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/25
 */
@Component
public class CampaignGroupConverter {

    public CampaignGroupResourcePackageViewDTO convertBaseInfo(CampaignGroupViewDTO campaignGroup) {
        CampaignGroupResourcePackageViewDTO result = new CampaignGroupResourcePackageViewDTO();
        result.setId(campaignGroup.getId());
        result.setName(campaignGroup.getName());
        result.setStartTime(campaignGroup.getStartTime());
        result.setEndTime(campaignGroup.getEndTime());
        result.setBudget(campaignGroup.getBudget());
        result.setStatus(campaignGroup.getStatus());
        result.setGmtCreate(campaignGroup.getGmtCreate());
        result.setGmtModified(campaignGroup.getGmtModified());
        result.setCustomerTemplateId(campaignGroup.getCampaignGroupSaleViewDTO().getCustomerTemplateId());
        result.setWakeupType(campaignGroup.getWakeupViewDTO().getWakeupType());
        result.setMemberId(campaignGroup.getMemberId());
        result.setCustomerId(campaignGroup.getCampaignGroupCustomerViewDTO().getCustomerId());
        result.setCusMemberId(campaignGroup.getCampaignGroupCustomerViewDTO().getCustomerMemberId());
//        result.setSchemaIdList(campaignGroup.getExtViewDTO().getSchemaIds());
        if (CollectionUtils.isNotEmpty(campaignGroup.getWakeupViewDTO().getSchemaConfigViewDTOList())){

            result.setSchemaConfigList(campaignGroup.getWakeupViewDTO().getSchemaConfigViewDTOList().stream().map(item->{
                SchemaConfigViewDTO schemaConfigViewDTO = new SchemaConfigViewDTO();

                schemaConfigViewDTO.setSchemaId(item.getSchemaId());
                schemaConfigViewDTO.setOpenType(item.getOpenType());
                SchemaConfigDetailViewDTO schemaConfigDetailViewDTO = new SchemaConfigDetailViewDTO();
                if (null != item.getSchemaConfigDetailViewDTO()){
                    schemaConfigDetailViewDTO.setAppPath(item.getSchemaConfigDetailViewDTO().getAppPath());
                    schemaConfigDetailViewDTO.setAppId(item.getSchemaConfigDetailViewDTO().getAppId());
                    schemaConfigDetailViewDTO.setHostApp(item.getSchemaConfigDetailViewDTO().getHostApp());
                }
                schemaConfigViewDTO.setSchemaConfigDetailViewDTO(schemaConfigDetailViewDTO);


                return schemaConfigViewDTO;

            }).collect(Collectors.toList()));
        }else{
            result.setSchemaConfigList(Lists.newArrayList());
        }


        return result;
    }
}
