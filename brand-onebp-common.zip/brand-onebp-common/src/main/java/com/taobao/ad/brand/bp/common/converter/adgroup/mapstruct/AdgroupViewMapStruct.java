package com.taobao.ad.brand.bp.common.converter.adgroup.mapstruct;

import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.control.DeepClone;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, mappingControl= DeepClone.class)
public interface AdgroupViewMapStruct  extends BaseMapStructMapper<AdgroupViewDTO, AdgroupViewDTO> {
    AdgroupViewMapStruct INSTANCE = Mappers.getMapper(AdgroupViewMapStruct.class);
}