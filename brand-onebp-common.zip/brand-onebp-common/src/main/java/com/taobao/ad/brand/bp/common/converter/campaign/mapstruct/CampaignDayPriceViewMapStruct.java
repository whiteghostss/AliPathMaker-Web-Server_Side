package com.taobao.ad.brand.bp.common.converter.campaign.mapstruct;

import com.taobao.ad.brand.bp.client.dto.campaign.CampaignDayPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductPriceViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.DecoratedWith;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.control.DeepClone;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, mappingControl = DeepClone.class)
@DecoratedWith(CampaignDayPriceViewMapStructDecorator.class)
public interface CampaignDayPriceViewMapStruct extends BaseMapStructMapper<ResourcePackageProductPriceViewDTO, CampaignDayPriceViewDTO> {

    CampaignDayPriceViewMapStruct INSTANCE = Mappers.getMapper(CampaignDayPriceViewMapStruct.class);

    @Mappings({
        @Mapping(source = "priceRatio", target = "discountRatio"),
        @Mapping(source = "type", target = "budgetAssignMode"),
    })
    @Override
    CampaignDayPriceViewDTO sourceToTarget(ResourcePackageProductPriceViewDTO resourcePackageProductPriceViewDTO);

    @Mappings({
        @Mapping(source = "discountRatio", target = "priceRatio"),
        @Mapping(source = "budgetAssignMode", target = "type"),
    })
    @Override
    ResourcePackageProductPriceViewDTO targetToSource(CampaignDayPriceViewDTO campaignDayPriceViewDTO);

}
