package com.taobao.ad.brand.bp.common.converter.campaigngroup.mapstruct;

import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;

import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.control.DeepClone;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/23
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, mappingControl= DeepClone.class)
public interface CampaignGroupViewMapStruct {
    CampaignGroupViewMapStruct INSTANCE = Mappers.getMapper(CampaignGroupViewMapStruct.class);

    CampaignGroupViewDTO copySelf(CampaignGroupViewDTO source);

    List<SaleGroupInfoViewDTO> copyCampaignGroupSaleGroupInfoSelfList(List<SaleGroupInfoViewDTO> sourceList);

}