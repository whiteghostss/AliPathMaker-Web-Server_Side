package com.taobao.ad.brand.bp.common.converter.campaign.mapstruct;

import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignPageViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.control.DeepClone;
import org.mapstruct.factory.Mappers;

/**
 * Description:ViewDTO到ViewDTO转换
 * <p>
 * date: 2023/3/1 1:23 PM
 *
 * @author shiyan
 * @version 1.0
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, mappingControl = DeepClone.class)
public interface CampaignViewPageMapStruct extends BaseMapStructMapper<CampaignViewDTO, CampaignPageViewDTO> {

    CampaignViewPageMapStruct INSTANCE = Mappers.getMapper(CampaignViewPageMapStruct.class);
    @Mappings({
            @Mapping(source = "title",target = "name"),
            @Mapping(source = "campaignSaleViewDTO",target = "."),
            @Mapping(source = "campaignResourceViewDTO",target = "."),
            @Mapping(source = "campaignPriceViewDTO",target = "."),
            @Mapping(source = "campaignPriceViewDTO.publishPriceInfoList",target = "publishDayPriceViewDTOList"),
            @Mapping(source = "campaignPriceViewDTO.discountPriceInfoList",target = "discountDayPriceViewDTOList"),
            @Mapping(source = "campaignBudgetViewDTO",target = "."),
            @Mapping(source = "campaignBoostViewDTO",target = "."),
            @Mapping(source = "campaignGuaranteeViewDTO",target = "."),
            @Mapping(source = "campaignSmartReservedViewDTO",target = "."),
            @Mapping(source = "campaignSafeIpViewDTO",target = "."),
            @Mapping(source = "campaignCreativeControllerViewDTO",target = "."),
            @Mapping(source = "campaignSelfServiceViewDTO",target = "."),
            @Mapping(source = "campaignTargetScenarioViewDTO",target = "."),
            @Mapping(source = "campaignCrowdScenarioViewDTO",target = "."),
            @Mapping(source = "campaignRealTimeOptimizeViewDTO",target = "."),
            @Mapping(source = "campaignMonitorViewDTO",target = "."),
            @Mapping(source = "campaignFrequencyViewDTO",target = "."),

            @Mapping(source = "campaignInquiryLockViewDTO",target = "."),
            @Mapping(source = "campaignInquiryLockViewDTO.campaignInquiryPolicyViewDTO",target = "."),
            @Mapping(source = "campaignExtViewDTO",target = "."),

    })
    @Override
    CampaignPageViewDTO sourceToTarget(CampaignViewDTO campaignViewDTO);

    @Mappings({
            @Mapping(source = "name",target = "title"),
            @Mapping(source = ".",target = "campaignSaleViewDTO"),
            @Mapping(source = ".",target = "campaignResourceViewDTO"),
            @Mapping(source = ".",target = "campaignPriceViewDTO"),
            @Mapping(source = "publishDayPriceViewDTOList",target = "campaignPriceViewDTO.publishPriceInfoList"),
            @Mapping(source = "discountDayPriceViewDTOList",target = "campaignPriceViewDTO.discountPriceInfoList"),
            @Mapping(source = ".",target = "campaignBudgetViewDTO"),
            @Mapping(source = ".",target = "campaignBoostViewDTO"),
            @Mapping(source = ".",target = "campaignGuaranteeViewDTO"),
            @Mapping(source = ".",target = "campaignSmartReservedViewDTO"),
            @Mapping(source = ".",target = "campaignSafeIpViewDTO"),
            @Mapping(source = ".",target = "campaignCreativeControllerViewDTO"),
            @Mapping(source = ".",target = "campaignSelfServiceViewDTO"),
            @Mapping(source = ".",target = "campaignTargetScenarioViewDTO"),
            @Mapping(source = ".",target = "campaignCrowdScenarioViewDTO"),
            @Mapping(source = ".",target = "campaignRealTimeOptimizeViewDTO"),
            @Mapping(source = ".",target = "campaignMonitorViewDTO"),
            @Mapping(source = ".",target = "campaignFrequencyViewDTO"),
            @Mapping(source = ".",target = "campaignInquiryLockViewDTO"),
            @Mapping(source = ".",target = "campaignInquiryLockViewDTO.campaignInquiryPolicyViewDTO"),
            @Mapping(source = ".",target = "campaignExtViewDTO"),
    })
    @Override
    CampaignViewDTO targetToSource(CampaignPageViewDTO campaignPageViewDTO) ;

}
