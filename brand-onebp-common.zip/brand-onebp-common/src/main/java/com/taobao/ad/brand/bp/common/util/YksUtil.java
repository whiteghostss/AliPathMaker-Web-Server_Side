package com.taobao.ad.brand.bp.common.util;


import org.apache.commons.codec.binary.Base64;

import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 工具类
 */
public class YksUtil {
    public static final Pattern REGEX_VID = Pattern.compile("\\w+X(.+).html?");
    public static final String PREFFIX_PLAYURL = "https://v.youku.com/v_show/id_";
    public static final int[] seeds = new int[]{9, 7, 5};

    public static String getVid64ByUrl(String urlString) {
        Matcher m = REGEX_VID.matcher(urlString);
        if (m.find()) {
            String id = m.group(1);
            return "X" + id;
        }
        return null;
    }

    public static String getVidByUrl(String urlString) {
        String id = urlString.substring(1);
        id = new String(java.util.Base64.getDecoder().decode(id));
        if (!isPositiveInteger(id)) {
            return "";
        }
        long idd = Long.parseLong(id) >> 2;
        return idd + "";
    }

    public static String getVid64ByVid(Long vid) {
        String idStr = String.valueOf(vid << 2);
        idStr = new String(Base64.encodeBase64(idStr.getBytes()));
        return "X" + idStr;
    }

    public static String getPlayUrlByVid(Long vid) {
        return PREFFIX_PLAYURL + getVid64ByVid(vid) + ".html";
    }

    public static String genSec(String filePath, String host) {
        StringBuilder sb = new StringBuilder(filePath);
        Random rand = new Random();
        int idx = rand.nextInt(seeds.length);
        int seed = seeds[idx];
        // current timestamp in seconds
        long now = System.currentTimeMillis() / 1000;

        int flvIdx = atoi(sb.substring(9, 11), 16);
        int plus = atoi(sb.substring(50, 54), 16);
        int ts = atoi(sb.substring(11, 19), 16);
        long timestamp = (now - ts) * 2 / 7200 + plus;
        long i = timestamp * (seed + flvIdx - 1);
        String tmpKey = String.format("%x", i);
        String key = "6" + seed + (tmpKey.length() + 2);

        int ip;
        String[] tmpIp = host.split("\\.", 4);
        int four = 4;
        if (tmpIp.length < four) {
            ip = 0;
        } else {
            int[] ipNum = new int[tmpIp.length];
            for (int j = 1; j < tmpIp.length; j++) {
                ipNum[j] = atoi(tmpIp[j], 10);
            }
            ip = ipNum[3] + ipNum[2] << 8 + ipNum[1] << 16;
        }
        //ip = 0;

        /**
         * payload format
         * [RAND][$seed+1][$len][($ip + $now/3600)*$seed] [RAND]
         * [3B]  [2B]      [1B] [XB]                      [4B]
         */
        int payloadSeed = rand.nextInt(30) + 48;
        String payloadSeedStr = String.format("%x", payloadSeed);
        double payload = ip + now / 3600.0;
        String payloadStr = String.format("%x", (int) (payload * (payloadSeed - 1)));
        String rand1 = String.format("%x", rand.nextInt(4095 - 1023) + 1023);
        String rand2 = String.format("%x", rand.nextInt(28671 - 8191) + 8191);
        String res = String.format("%s%s%s%s%d%s%s", key, tmpKey, rand1, payloadSeedStr, payloadStr.length(),
                payloadStr, rand2);
        return res.toUpperCase();
    }

    private static int atoi(String s, int radix) {
        try {
            return Integer.parseInt(s, radix);
        } catch (Exception e) {
            return 0;
        }
    }

    private static boolean isPositiveInteger(String str) {
        if (str == null || str.length() == 0) {
            return false;
        }
        char ch = str.charAt(0);
        if (ch < '1' || ch > '9') {
            return false;
        }
        for (int i = 1; i < str.length(); i++) {
            ch = str.charAt(i);
            if (ch < '0' || ch > '9') {
                return false;
            }
        }
        return true;
    }

//    public static String requestGet(String url) throws Exception {
//        return requestGet(url, null);
//    }
//
//    public static String requestGet(String url, Map<String, String> headers) throws Exception {
//        RogerLogger.info("HttpRequestGet,url:{},header:{}", url, JSON.toJSONString(headers));
//
//        CloseableHttpClient closeHttpClient = HttpClients.createDefault();
//        HttpClient httpClient = new TracedHttpClient(closeHttpClient, EagleEye.TYPE_HTTP_CLIENT, true);
//        HttpGet httpGet = new HttpGet(url);
//        if (headers != null) {
//            for (Map.Entry<String, String> entry : headers.entrySet()) {
//                httpGet.addHeader(entry.getKey(), entry.getValue());
//            }
//        }
//        HttpResponse httpResponse = httpClient.execute(httpGet);
//        try {
//            RogerLogger.info("HttpRequestGet,返回状态:{}", httpResponse.getStatusLine());
//            HttpEntity entity = httpResponse.getEntity();
//            String s = EntityUtils.toString(entity);
//            RogerLogger.info("HttpRequestGet,返回内容:{}", s);
//            return s;
//        } finally {
//            closeHttpClient.close();
//        }
//    }

}
