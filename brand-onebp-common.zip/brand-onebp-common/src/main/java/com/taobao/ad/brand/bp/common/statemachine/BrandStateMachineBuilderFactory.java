package com.taobao.ad.brand.bp.common.statemachine;

import com.alibaba.cola.statemachine.builder.StateMachineBuilder;

/**
 * @author yanjingang
 * @date 2023/3/7
 */
public class BrandStateMachineBuilderFactory {

    public static <S, E, C> StateMachineBuilder<S, E, C> create(){
        return new BrandStateMachineBuilderImpl<>();
    }
}
