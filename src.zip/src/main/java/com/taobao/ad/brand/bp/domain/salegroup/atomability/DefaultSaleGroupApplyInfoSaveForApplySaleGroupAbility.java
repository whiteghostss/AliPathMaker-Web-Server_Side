package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupBoostGiveApplyInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupApplyInfoSaveForApplySaleGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupApplyInfoAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultSaleGroupApplyInfoSaveForApplySaleGroupAbility implements ISaleGroupApplyInfoSaveForApplySaleGroupAbility {
    private final CampaignGroupRepository campaignGroupRepository;
    @Override
    public Void handle(ServiceContext serviceContext, SaleGroupApplyInfoAbilityParam abilityParam) {
        SaleGroupBoostGiveApplyInfoViewDTO applyInfoViewDTO = abilityParam.getAbilityTarget();
        SaleGroupInfoViewDTO mainSaleGroupInfoViewDTO = abilityParam.getMainSaleGroupInfoViewDTO();

        // 新增/更新 主分组上的补量配送信息
        if (CollectionUtils.isEmpty(mainSaleGroupInfoViewDTO.getBoostGiveApplyInfoList())) {
            mainSaleGroupInfoViewDTO.setBoostGiveApplyInfoList(Lists.newArrayList(applyInfoViewDTO));
        } else {
            List<SaleGroupBoostGiveApplyInfoViewDTO> existSaleGroupBoostGiveApplyInfo = mainSaleGroupInfoViewDTO.getBoostGiveApplyInfoList()
                    .stream()
                    .filter(x -> x.getSaleGroupId().equals(applyInfoViewDTO.getSaleGroupId())).collect(Collectors.toList());
            if (CollectionUtils.isNotEmpty(existSaleGroupBoostGiveApplyInfo)) {
                // 编辑补量/配送分组时，更新补量原因和绑定的主计划
                mainSaleGroupInfoViewDTO.getBoostGiveApplyInfoList().forEach(x -> {
                    if (x.getSaleGroupId().equals(applyInfoViewDTO.getSaleGroupId())) {
                        x.setReasonType(applyInfoViewDTO.getReasonType());
                        x.setCampaignDetailList(applyInfoViewDTO.getCampaignDetailList());
                    }
                });
            } else {
                mainSaleGroupInfoViewDTO.getBoostGiveApplyInfoList().add(applyInfoViewDTO);
            }
        }
        // 保存
        AssertUtil.notNull(mainSaleGroupInfoViewDTO.getId(), "订单分组ID不能为空");
        SaleGroupInfoViewDTO updateSaleGroup = new SaleGroupInfoViewDTO();
        updateSaleGroup.setId(mainSaleGroupInfoViewDTO.getId());
        updateSaleGroup.setCampaignGroupId(mainSaleGroupInfoViewDTO.getCampaignGroupId());
        updateSaleGroup.setSaleGroupId(mainSaleGroupInfoViewDTO.getSaleGroupId());
        updateSaleGroup.setBoostGiveApplyInfoList(mainSaleGroupInfoViewDTO.getBoostGiveApplyInfoList());
        campaignGroupRepository.updateSaleGroupPart(serviceContext, Lists.newArrayList(updateSaleGroup));
        return null;
    }
}
