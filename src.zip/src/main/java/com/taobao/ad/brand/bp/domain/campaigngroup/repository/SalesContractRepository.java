package com.taobao.ad.brand.bp.domain.campaigngroup.repository;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupCustomerMemberViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesContractAmountViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesContractBrandViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesContractViewDTO;
import com.taobao.ad.brand.bp.client.dto.shop.ShopBrandViewDTO;

import java.util.List;
import java.util.Map;

/**
 * @author yanjingang
 * @date 2023/3/16
 */
public interface SalesContractRepository {

    /**
     * 获取合同基础信息
     * @param contractId
     */
    SalesContractViewDTO getSimpleContractInfo(Long contractId);

    String createChargeUrl(ServiceContext context, SalesContractViewDTO salesContractViewDTO);

    List<SalesContractViewDTO> getSimpleContractInfo(List<Long> contractIds);

    /**
     * 获取合同绑定品牌信息
     * @param contractId
     */
    List<SalesContractBrandViewDTO> getContractBrandList(Long contractId);

    /**
     * 获取合同绑定品牌信息
     * @param contractIds
     */
    List<SalesContractBrandViewDTO> getContractBrandList(List<Long> contractIds);

    /**
     * 获取合同绑定活动信息
     * @param contractIds
     */
    Map<Long, List<SalesContractBrandViewDTO>> getContractBrandMap(List<Long> contractIds);

    List<SalesContractBrandViewDTO> findBrandList(Long shopId);

    List<Long> getSubContractIds(Long contractId);

    /**
     * 获取合同付款信息
     *
     * @param contractIds
     * @return
     */
    List<SalesContractAmountViewDTO> getContractPayments(List<Long> contractIds);

    void checkMemberForSelfContract(ServiceContext context, CampaignGroupCustomerMemberViewDTO campaignGroupCustomerMemberViewDTO);

    boolean checkMemberEnableCredit(ServiceContext context, CampaignGroupCustomerMemberViewDTO campaignGroupCustomerMemberViewDTO);

    /**
     * 创建自助合同
     * @param context
     * @param campaignGroupViewDTO
     * @return
     */
    Long createSelfContract(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO);

    /**
     * 添加合同结案账号关联的品牌
     * @param context
     * @param shopBrandViewDTO
     */
    void addContractCompleteBrand(ServiceContext context, ShopBrandViewDTO shopBrandViewDTO);
}
