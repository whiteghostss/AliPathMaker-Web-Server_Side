package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupValidateForFinishCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupValidateForFinishCampaignGroupAbilityParam;
import org.springframework.stereotype.Component;

import java.util.Date;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR;

@Component
@BusinessAbility
public class DefaultCampaignGroupValidateForFinishCampaignGroupAbility implements ICampaignGroupValidateForFinishCampaignGroupAbility {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupValidateForFinishCampaignGroupAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.assertTrue(new Date().after(campaignGroupViewDTO.getEndTime()), BIZ_BREAK_RULE_ERROR, "订单尚未执行完成，不支持该操作");
        return null;
    }
}
