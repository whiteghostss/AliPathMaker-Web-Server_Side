package com.taobao.ad.brand.bp.domain.dmpargus;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alimama.faas.brand.engine.entity.response.AICreativePredictResponse;
import com.alimama.faas.brand.engine.entity.response.PreStrategyRcmdResponse;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.DmpArgusEstimateViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeScoreUnitViewDTO;

import java.util.List;

/**
 * @Description B端引擎Repository
 * @Author xiaoduo
 * @Date 2024/4/24
 **/
public interface DmpArgusRepository {

    /**
     * 异步计算智能提案（策略）
     * @param serviceContext
     * @param dmpArgusEstimateViewDTO
     * @return
     */
    void calculateIntelligentMotionAndStrategy(ServiceContext serviceContext, DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO);

    /**
     * 同步更新智能策略数据
     * @param serviceContext
     * @param dmpArgusEstimateViewDTO
     * @return
     */
    PreStrategyRcmdResponse updateIntelligentStrategy(ServiceContext serviceContext, DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO);


    /**
     * 创意AI打分
     * @param serviceContext
     * @param creativeScoreUnitViewDTOList
     * @return
     */
    AICreativePredictResponse predictCreativeScore(ServiceContext serviceContext, List<CreativeScoreUnitViewDTO> creativeScoreUnitViewDTOList);

}
