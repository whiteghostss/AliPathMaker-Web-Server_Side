package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.salegroup.CampaignGroupSaleGroupViewDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupSaleGroupInitForUpdateCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupSaleGroupAbilityParam;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
@BusinessAbility
public class DefaultCampaignGroupSaleGroupInitForUpdateCampaignGroupAbility implements ICampaignGroupSaleGroupInitForUpdateCampaignGroupAbility {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupSaleGroupAbilityParam abilityParam) {
        CampaignGroupViewDTO dbCampaignGroupViewDTO = abilityParam.getDbCampaignGroupViewDTO();
        if (!BizCampaignGroupToolsHelper.isSaleCampaignGroup(dbCampaignGroupViewDTO) || !BizCampaignGroupToolsHelper.isSubCampaignGroup(dbCampaignGroupViewDTO)) {
            return null;
        }
        CampaignGroupSaleGroupViewDTO campaignGroupSaleGroupViewDTO = abilityParam.getAbilityTarget();
        Map<Long, SaleGroupInfoViewDTO> dbSubSaleGroupInfoMap = dbCampaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList()
                .stream().collect(Collectors.toMap(SaleGroupInfoViewDTO::getSaleGroupId, t -> t, (a1, a2) -> a1));

        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        List<SaleGroupInfoViewDTO> finalSaveSaleGroupList = Lists.newArrayList();
        // DB存在时仅更新部分属性信息
        campaignGroupSaleGroupViewDTO.getSaleGroupInfoViewDTOList().forEach(saleGroupInfoViewDTO -> {
            saleGroupInfoViewDTO.setCampaignGroupId(campaignGroupViewDTO.getId());
            if (dbSubSaleGroupInfoMap.containsKey(saleGroupInfoViewDTO.getSaleGroupId())) {
                SaleGroupInfoViewDTO dbSaleGroupInfo = dbSubSaleGroupInfoMap.get(saleGroupInfoViewDTO.getSaleGroupId());
                dbSaleGroupInfo.setBudget(saleGroupInfoViewDTO.getBudget());
                finalSaveSaleGroupList.add(dbSaleGroupInfo);
            } else {
                finalSaveSaleGroupList.add(saleGroupInfoViewDTO);
            }
        });
        campaignGroupSaleGroupViewDTO.setSaleGroupInfoViewDTOList(finalSaveSaleGroupList);
        campaignGroupViewDTO.setCampaignGroupSaleGroupViewDTO(campaignGroupSaleGroupViewDTO);

        return null;
    }
}
