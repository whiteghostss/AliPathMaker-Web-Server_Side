package com.taobao.ad.brand.bp.domain.ssp;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.TreeNodeViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.AreaViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductQueryOption;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;

import java.util.List;
import java.util.Map;

/**
 * @Description: SSP产品服务
 * @Author: dongyang
 * @Date: 2023/3/4
 */
public interface ProductRepository {
    /**
     * 获取产品
     * @param id
     * @return
     */
    ProductViewDTO getProductWithTargetValue(Long id);

    /**
     * 获取产品（不返回定向value值）
     * @param id
     * @return
     */
    ProductViewDTO getProductById(Long id);

    /**
     * 获取产品（不返回定向value值）
     * @param ids
     * @return
     */
    List<ProductViewDTO> getProductByIds( List<Long> ids);

    /**
     * 获取产品
     * @param ids
     * @return
     */
    List<ProductViewDTO> getProductByIdsOption( List<Long> ids, ProductQueryOption productQueryOption);

    /**
     * 获取产品
     * @param ids
     * @return
     */
    Map<Long, ProductViewDTO> getProductMapByIds( List<Long> ids);

    /**
     * 通过uuid获取产品
     * @param ids
     * @return
     */
    List<ProductViewDTO> getProductByUuids( List<Long> ids);

    /**
     * 通过uuid获取产品
     * @param ids
     * @return
     */
    List<ProductViewDTO> getProductByUuidOption(List<Long> uuids, ProductQueryOption productQueryOption);

    List<CommonViewDTO> getAreaList(ServiceContext serviceContext);
    List<AreaViewDTO> getAreaList(ServiceContext serviceContext, List<Integer> areaIdList);

    List<TreeNodeViewDTO> getAreaTreeList(ServiceContext serviceContext, List<Integer> areaIdList);

    List<CommonViewDTO> getSSPDict(String type);

    List<TreeNodeViewDTO> getDicTreeByType(String type, List<String> values);

    List<CommonViewDTO> getSSPMedia(List<String> ids);

    List<CommonViewDTO> getSSPChannel();

    Map<String, CommonViewDTO> getSSPTerminalMap();

    List<CommonViewDTO> getSSPDict(String type, List<String> ids);

    List<CommonViewDTO> getDspList(ServiceContext serviceContext);

    List<CommonViewDTO> getShowPositionList(String type, List<String> positionValueList);
}
