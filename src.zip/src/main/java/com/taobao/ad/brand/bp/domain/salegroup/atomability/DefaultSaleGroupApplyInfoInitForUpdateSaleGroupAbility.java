package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupBoostGiveApplyCampaignDetailViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupBoostGiveApplyInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupAuditStatusEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleProductLineEnum;
import com.alibaba.ad.nb.packages.v2.client.error.ResourcePackageBaseErrorCode;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupApplyInfoInitForUpdateSaleGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupApplyInfoAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultSaleGroupApplyInfoInitForUpdateSaleGroupAbility implements ISaleGroupApplyInfoInitForUpdateSaleGroupAbility {

    private final ResourcePackageRepository resourcePackageRepository;
    @Override
    public Void handle(ServiceContext serviceContext, SaleGroupApplyInfoAbilityParam abilityParam) {
        SaleGroupBoostGiveApplyInfoViewDTO applyInfoViewDTO = abilityParam.getAbilityTarget();
        SaleGroupInfoViewDTO mainSaleGroupInfoViewDTO = abilityParam.getMainSaleGroupInfoViewDTO();

        // 单媒体营销补量分组初始化方式
        if (BrandSaleTypeEnum.BOOST.getCode().equals(applyInfoViewDTO.getSaleType()) && SaleProductLineEnum.SINGLE_MEDIA_MARKING.getValue().equals(mainSaleGroupInfoViewDTO.getSaleProductLine())) {
            applyInfoViewDTO.setBudget(applyInfoViewDTO.getCampaignDetailList().stream().mapToLong(SaleGroupBoostGiveApplyCampaignDetailViewDTO::getBudget).sum());
            applyInfoViewDTO.setAmount(applyInfoViewDTO.getCampaignDetailList().stream().mapToLong(SaleGroupBoostGiveApplyCampaignDetailViewDTO::getAmount).sum());
        // 非单媒体营销的补量分组初始化方式
        } else {
            applyInfoViewDTO.setAmount(0L);
        }

        SaleGroupBoostGiveApplyInfoViewDTO oldSaleGroupBoostGiveApplyInfoViewDTO = Optional.of(mainSaleGroupInfoViewDTO.getBoostGiveApplyInfoList().stream()
                .filter(saleGroup -> applyInfoViewDTO.getSaleGroupId().equals(saleGroup.getSaleGroupId()))
                .findFirst()).get().orElse(null);
        //是否走审批
        AtomicBoolean approval = new AtomicBoolean(false);
        ResourcePackageSaleGroupViewDTO oldResourcePackageSaleGroupDTO = resourcePackageRepository.getSaleGroupWithEditMode(serviceContext, applyInfoViewDTO.getSaleGroupId());
        BrandSaleTypeEnum saleTypeEnum = BrandSaleTypeEnum.getByCode(applyInfoViewDTO.getSaleType());
        // 修改配送分组业务类型校验
        if (saleTypeEnum == BrandSaleTypeEnum.PRESENT) {
            if (!applyInfoViewDTO.getDistributionType().equals(oldResourcePackageSaleGroupDTO.getDistributionType())) {
                approval.set(true);
            }
        }
        if (!(applyInfoViewDTO.getStartDate().equals(oldResourcePackageSaleGroupDTO.getStartDate())) || !(applyInfoViewDTO.getEndDate().equals(oldResourcePackageSaleGroupDTO.getEndDate()))) {
            approval.set(true);
        }
        if (saleTypeEnum == BrandSaleTypeEnum.BOOST && SaleProductLineEnum.SINGLE_MEDIA_MARKING.getValue().equals(mainSaleGroupInfoViewDTO.getSaleProductLine())) {
            if (CollectionUtils.isNotEmpty(oldSaleGroupBoostGiveApplyInfoViewDTO.getCampaignDetailList()) || CollectionUtils.isNotEmpty(applyInfoViewDTO.getCampaignDetailList())) {
                if (!CollectionUtils.isEqualCollection(Optional.ofNullable(oldSaleGroupBoostGiveApplyInfoViewDTO.getCampaignDetailList()).orElse(Lists.newArrayList()).stream().map(SaleGroupBoostGiveApplyCampaignDetailViewDTO::getCampaignId).collect(Collectors.toList()),
                        Optional.ofNullable(applyInfoViewDTO.getCampaignDetailList()).orElse(Lists.newArrayList()).stream().map(SaleGroupBoostGiveApplyCampaignDetailViewDTO::getCampaignId).collect(Collectors.toList()))) {
                    approval.set(true);
                }
                if (CollectionUtils.isNotEmpty(oldSaleGroupBoostGiveApplyInfoViewDTO.getCampaignDetailList())) {
                    oldSaleGroupBoostGiveApplyInfoViewDTO.getCampaignDetailList().forEach(campaign -> {
                        SaleGroupBoostGiveApplyCampaignDetailViewDTO dto = Optional.of(Optional.ofNullable(applyInfoViewDTO.getCampaignDetailList()).orElse(Lists.newArrayList())
                                .stream().filter(x -> x.getCampaignId().equals(campaign.getCampaignId())).findFirst()).get().orElse(null);
                        if (Objects.nonNull(dto) && !campaign.getBudget().equals(dto.getBudget())) {
                            approval.set(true);
                        }
                    });
                }
            }
        } else {
            // 修改分组金额校验(此时单媒体营销补量applyViewDTO.getBudget()为null，只校验计划的budget即可)
            if (Objects.nonNull(applyInfoViewDTO.getBudget()) && !applyInfoViewDTO.getBudget().equals(oldResourcePackageSaleGroupDTO.getAmountConfigure().getAmount())) {
                approval.set(true);
            }
        }
        //设置是否走审批
        applyInfoViewDTO.setApproval(approval.get());
        return null;
    }
}
