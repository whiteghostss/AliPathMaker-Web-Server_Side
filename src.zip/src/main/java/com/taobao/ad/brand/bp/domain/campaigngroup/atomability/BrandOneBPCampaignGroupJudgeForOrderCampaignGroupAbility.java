package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSaleOrderStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleGroupSourceEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupTransitAbilityParam;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

@Component
@BusinessAbility
public class BrandOneBPCampaignGroupJudgeForOrderCampaignGroupAbility
        extends DefaultCampaignGroupJudgeForOrderCampaignGroupAbility implements BrandOneBPAtomAbilityRouter {
    @Resource
    private CampaignGroupRepository campaignGroupRepository;

    /**
     * 主订单-下单时有效的主订单状态
     */
    public static final List<Integer> validSaleMainCampaignGroupStatusOnOrder = Lists.newArrayList(
            BrandCampaignGroupStatusEnum.EDITED.getCode(),
            BrandCampaignGroupStatusEnum.UNLOCKED.getCode()
    );
    /**
     * 主订单-下单时有效的主订单状态
     */
    public static final List<Integer> validSelfMainCampaignGroupStatusOnOrder = Lists.newArrayList(
            BrandCampaignGroupStatusEnum.EDITED.getCode(),
            BrandCampaignGroupStatusEnum.ORDER_ING.getCode()
    );

    /**
     * 主订单-下单时无效的子订单状态
     */
    public static final List<Integer> inValidSubCampaignGroupStatusOnOrder = Lists.newArrayList(
            BrandCampaignGroupStatusEnum.EDITED.getCode(),
            BrandCampaignGroupStatusEnum.UNLOCKED.getCode()
    );

    @Override
    public Boolean handle(ServiceContext serviceContext, CampaignGroupTransitAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        // 1. 校验主订单有效状态
        if (BizCampaignGroupToolsHelper.isSaleCampaignGroup(campaignGroupViewDTO)) {
            if (!validSaleMainCampaignGroupStatusOnOrder.contains(campaignGroupViewDTO.getStatus())) {
                return false;
            }
        } else {
            if (!validSelfMainCampaignGroupStatusOnOrder.contains(campaignGroupViewDTO.getStatus())) {
                return false;
            }
        }

        // 2. 校验子订单无效状态：草稿、改单配置
        List<CampaignGroupViewDTO> subCampaignGroupList = campaignGroupRepository.findSubCampaignGroupList(serviceContext, campaignGroupViewDTO.getId());
        boolean subCampaignGroupHasInvalidStatus = subCampaignGroupList.stream().anyMatch(suCampaignGroup -> inValidSubCampaignGroupStatusOnOrder.contains(suCampaignGroup.getStatus()));
        if (subCampaignGroupHasInvalidStatus) {
            return false;
        }
        // 3. 校验子订单source=1的分组状态，包含未下单分组时，不进行状态流转
        List<SaleGroupInfoViewDTO> salePlatformSaleGroupList = subCampaignGroupList.stream()
                .flatMap(campaignGroup -> campaignGroup.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream())
                .filter(t -> BrandSaleGroupSourceEnum.SALE_PLATFORM.getCode().equals(t.getSource()))
                .collect(Collectors.toList());
        boolean hasWaitOrderSaleGroup = salePlatformSaleGroupList.stream().anyMatch(saleGroupInfo -> BrandCampaignGroupSaleOrderStatusEnum.WAIT_ORDER.getCode().equals(saleGroupInfo.getSaleGroupStatus()));
        if (hasWaitOrderSaleGroup) {
            return false;
        }

        return true;
    }
}
