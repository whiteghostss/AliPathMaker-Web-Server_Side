package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.salegroup.CampaignGroupSaleGroupViewDTO;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupUpdateForUnlockRevertAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupUnlockRevertAbilityParam;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

@Component
@BusinessAbility
public class BrandOneBPCampaignGroupUpdateForUnlockRevertAbility implements ICampaignGroupUpdateForUnlockRevertAbility, BrandOneBPAtomAbilityRouter {

    @Resource
    private CampaignGroupRepository campaignGroupRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupUnlockRevertAbilityParam abilityParam) {
        CampaignGroupViewDTO mainCampaignGroup = abilityParam.getAbilityTarget();
        List<CampaignGroupViewDTO> subCampaignGroupList = abilityParam.getSubCampaignGroupList();
        // 1. 汇总主订单售卖分组信息和预算信息
        List<SaleGroupInfoViewDTO> saleGroupInfoList = subCampaignGroupList.stream()
                .flatMap(item -> item.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream())
                .peek(saleGroup -> {
                    saleGroup.setId(null);
                    saleGroup.setCampaignGroupId(mainCampaignGroup.getId());
                }).collect(Collectors.toList());
        mainCampaignGroup.getCampaignGroupSaleGroupViewDTO().setSaleGroupInfoViewDTOList(saleGroupInfoList);
        // 预算信息
        Long budget = BizCampaignGroupToolsHelper.getBuySaleGroupBudgetTotal(saleGroupInfoList);
        mainCampaignGroup.setBudget(budget);

        // 2. 执行更新
        CampaignGroupViewDTO updateCampaignGroup = new CampaignGroupViewDTO();
        updateCampaignGroup.setId(mainCampaignGroup.getId());
        updateCampaignGroup.setBudget(mainCampaignGroup.getBudget());
        campaignGroupRepository.updateCampaignGroupPart(serviceContext, updateCampaignGroup);
        // 更新分组
        CampaignGroupSaleGroupViewDTO saleGroupViewDTO = new CampaignGroupSaleGroupViewDTO();
        saleGroupViewDTO.setSaleGroupInfoViewDTOList(mainCampaignGroup.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList());
        updateCampaignGroup.setCampaignGroupSaleGroupViewDTO(saleGroupViewDTO);
        campaignGroupRepository.addOrUpdateSaleGroupPart(serviceContext, mainCampaignGroup.getId(), saleGroupInfoList);

        return null;
    }
}
