package com.taobao.ad.brand.bp.domain.dmp.spi;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.nb.framework.core.AbilityFactory;
import com.alibaba.ad.nb.framework.core.AbilitySpi;
import com.alibaba.ad.nb.framework.core.annotation.Ability;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaign.RecommendCrowdTypeEnum;

import java.util.List;
/**
 * @author fengbo
 * @date 2023年09月08日
 * showmax人群能力SPI
 * */
@Ability(desc = "showmax人群能力SPI")
public interface ShowmaxCrowdSpi extends AbilitySpi {
//    /**
//     * 品牌精选
//     */
//    static String SHOWMAX_CROWD_BRAND = "showmaxCrowdBrand";
//    /**
//     * 行业精选
//     */
//    static String SHOWMAX_CROWD_CATEGORY = "showmaxCrowdCategory";
//    /**
//     * 全域追投
//     */
//    static String SHOWMAX_CROWD_GLOBAL = "showmaxCrowdGlobal";
//    /**
//     * 小二推荐
//     */
//    static  String SHOWMAX_CROWD_RECOMMEND = "showmaxCrowdRecommend";
//    /**
//     * 入会
//     */
//    static  String SHOWMAX_CROWD_MEMBER = "showmaxCrowdMember";
//    /**
//     * 场景推荐
//     */
//    static  String SHOWMAX_CROWD_SCENE_RECOMMEND = "showmaxCrowdSceneRecommend";
//
//    /**
//     * 查询标签
//     */
//    List<CommonViewDTO> queryShowmaxCrowdTagList(ServiceContext serviceContext, Long memberId,  List<Long> brandIds);

//    static String getShowmaxCrowdSpiBizCode(Integer showmaxType) {
//        if (RecommendCrowdTypeEnum.BRAND.getCode().equals(showmaxType) || RecommendCrowdTypeEnum.BRAND_ADDITION.getCode().equals(showmaxType)) {
//            return ShowmaxCrowdSpi.SHOWMAX_CROWD_BRAND;
//        }
//        if (RecommendCrowdTypeEnum.CATEGORY.getCode().equals(showmaxType) || RecommendCrowdTypeEnum.CATEGORY_ADDITION.getCode().equals(showmaxType)) {
//            return ShowmaxCrowdSpi.SHOWMAX_CROWD_CATEGORY;
//        }
//        if (RecommendCrowdTypeEnum.GLOBAL.getCode().equals(showmaxType)) {
//            return ShowmaxCrowdSpi.SHOWMAX_CROWD_GLOBAL;
//        }
//        if (RecommendCrowdTypeEnum.RECOMMEND.getCode().equals(showmaxType)) {
//            return ShowmaxCrowdSpi.SHOWMAX_CROWD_RECOMMEND;
//        }
//        if (RecommendCrowdTypeEnum.MEMBER.getCode().equals(showmaxType)) {
//            return ShowmaxCrowdSpi.SHOWMAX_CROWD_MEMBER;
//        }
//        if (RecommendCrowdTypeEnum.SCENE_RECOMMEND.getCode().equals(showmaxType)) {
//            return ShowmaxCrowdSpi.SHOWMAX_CROWD_SCENE_RECOMMEND;
//        }
//        return AbilityFactory.DEFAULT_BIZ_CODE;
//    }
}
