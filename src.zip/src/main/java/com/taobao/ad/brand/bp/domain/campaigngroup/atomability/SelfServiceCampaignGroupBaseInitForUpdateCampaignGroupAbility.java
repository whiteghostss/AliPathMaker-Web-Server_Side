package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupBaseAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
public class SelfServiceCampaignGroupBaseInitForUpdateCampaignGroupAbility extends DefaultCampaignGroupBaseInitForUpdateCampaignGroupAbility
        implements SelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupBaseAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        CampaignGroupViewDTO dbCampaignGroupViewDTO = abilityParam.getDbCampaignGroupViewDTO();
        campaignGroupViewDTO.setGiveStatus(dbCampaignGroupViewDTO.getGiveStatus());
        campaignGroupViewDTO.setBoostStatus(dbCampaignGroupViewDTO.getBoostStatus());
        if (CollectionUtils.isNotEmpty(campaignGroupViewDTO.getOperators())) {
            campaignGroupViewDTO.setRelevantOperators(campaignGroupViewDTO.getOperators());
        }
        campaignGroupViewDTO.setName(null);
        campaignGroupViewDTO.setStatus(null);
        campaignGroupViewDTO.setStartTime(null);
        campaignGroupViewDTO.setEndTime(null);
        campaignGroupViewDTO.setType(null);
        campaignGroupViewDTO.setParentId(null);
        campaignGroupViewDTO.setSource(null);
        campaignGroupViewDTO.setSourceIds(null);
        campaignGroupViewDTO.setPreviousStatus(null);

        return null;
    }
}
