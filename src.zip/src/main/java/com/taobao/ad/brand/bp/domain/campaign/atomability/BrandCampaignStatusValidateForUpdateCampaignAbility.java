package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignStatusValidateForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignStatusValidateForUpdateCampaignAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandCampaignStatusValidateForUpdateCampaignAbility implements ICampaignStatusValidateForUpdateCampaignAbility, BrandAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignStatusValidateForUpdateCampaignAbilityParam abilityParam) {
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        AssertUtil.notNull(dbCampaignViewDTO,"计划不存在");
        List<CampaignViewDTO> allCampaignViewDTOList = Lists.newArrayList();
        allCampaignViewDTOList.add(dbCampaignViewDTO);
        allCampaignViewDTOList.addAll(dbCampaignViewDTO.getSubCampaignViewDTOList());
        for (CampaignViewDTO viewDTO : allCampaignViewDTOList) {
            BrandCampaignStatusEnum campaignStatusEnum = BrandCampaignStatusEnum.getByCode(viewDTO.getStatus());
            if (BrandCampaignStatusEnum.INQUIRING == campaignStatusEnum || BrandCampaignStatusEnum.LOCKING == campaignStatusEnum
                    || BrandCampaignStatusEnum.RELEASING == campaignStatusEnum){
                throw new BrandOneBPException("锁量中、询量中、释量中的计划，不允许修改");
            }
        }
        return null;
    }
}
