package com.taobao.ad.brand.bp.domain.adgroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.config.AutoTestMemberDiamondConfig;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupPermissionDeleteValidateAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupPermissionDeleteValidateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultAdgroupPermissionDeleteValidateAbility implements IAdgroupPermissionDeleteValidateAbility {

    private final AutoTestMemberDiamondConfig autoTestMemberDiamondConfig;

    @Override
    public Void handle(ServiceContext serviceContext, AdgroupPermissionDeleteValidateAbilityParam abilityParam) {
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(autoTestMemberDiamondConfig.getInnerMemberList()), "未配置白名单，不可物理操作");
        AssertUtil.assertTrue(autoTestMemberDiamondConfig.getInnerMemberList().contains(serviceContext.getMemberId()), "未命中白名单，不可物理操作");
        return null;
    }
}
