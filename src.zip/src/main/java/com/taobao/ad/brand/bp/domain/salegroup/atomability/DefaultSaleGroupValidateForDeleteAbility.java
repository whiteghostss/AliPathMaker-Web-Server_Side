package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupValidateForDeleteAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupValidateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_ILLEGAL;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultSaleGroupValidateForDeleteAbility implements ISaleGroupValidateForDeleteAbility {

    private final CampaignRepository campaignRepository;

    @Override
    public Void handle(ServiceContext serviceContext, SaleGroupValidateAbilityParam abilityParam) {
        if (CollectionUtils.isEmpty(abilityParam.getAbilityTargets()) || CollectionUtils.isEmpty(abilityParam.getDbSaleGroupInfoViewDTOList())) {
            return null;
        }
        List<Long> addOrUpdateSaleGroupIds = abilityParam.getAbilityTargets().stream().map(SaleGroupInfoViewDTO::getSaleGroupId).collect(Collectors.toList());
        // 校验删除的售卖分组下是否有计划
        List<SaleGroupInfoViewDTO> deletedSaleGroupList = abilityParam.getDbSaleGroupInfoViewDTOList().stream()
                .filter(t -> abilityParam.getSaleGroupSourceEnum().getCode().equals(t.getSource()))
                .filter(t -> !addOrUpdateSaleGroupIds.contains(t.getSaleGroupId()))
                .collect(Collectors.toList());
        if (CollectionUtils.isEmpty(deletedSaleGroupList)) {
            return null;
        }

        // 删除分组时校验是否有计划
        CampaignQueryViewDTO queryViewDTO = new CampaignQueryViewDTO();
        queryViewDTO.setCampaignGroupIds(deletedSaleGroupList.stream().map(SaleGroupInfoViewDTO::getCampaignGroupId).distinct().collect(Collectors.toList()));
        queryViewDTO.setSaleGroupIds(deletedSaleGroupList.stream().map(SaleGroupInfoViewDTO::getSaleGroupId).collect(Collectors.toList()));
        queryViewDTO.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
        // 跨场景查询，此处使用brandOneBPContext
        ServiceContext newContext = ServiceContextUtil.buildServiceContextForBizCodeNoSession(serviceContext.getMemberId(), BizCodeEnum.BRANDONEBP.getBizCode());
        int campaignCount = campaignRepository.queryCampaignCount(newContext, queryViewDTO);
        AssertUtil.assertTrue(campaignCount == 0, PARAM_ILLEGAL, "分组下存在计划，不支持删除分组");

        return null;
    }
}
