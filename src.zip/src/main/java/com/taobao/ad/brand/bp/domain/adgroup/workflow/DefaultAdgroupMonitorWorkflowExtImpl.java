package com.taobao.ad.brand.bp.domain.adgroup.workflow;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.creative.ContentVersionViewDTO;
import com.taobao.ad.brand.bp.client.dto.adgroup.ExportMonitorCodeViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.workflow.BizAdgroupMonitorWorkflowExt;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.workflow.param.BizAdgroupMonitorWorkflowParam;

import java.util.List;

/**
 * Description:默认监测业务流程扩展
 * <p>
 * date: 2023/10/24 2:51 PM
 *
 * @author shiyan
 * @version 1.0
 */
@BusinessAbility
public class DefaultAdgroupMonitorWorkflowExtImpl implements BizAdgroupMonitorWorkflowExt {
    /**
     * 单元监测-构建扩展参数
     * @param serviceContext
     * @param adgroupViewDTO
     * @return
     */
    @Override
    public BizAdgroupMonitorWorkflowParam buildParamForMonitor(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO) {

        return null;
    }

    /**
     * 单元监测-发送监测邮件
     * @param serviceContext
     * @param adgroupViewDTO
     * @param contentVersionViewDTO
     * @param monitorCodeViewDTOList
     * @return
     */
    @Override
    public Void sendAdgroupMonitorEmail(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, ContentVersionViewDTO contentVersionViewDTO,List<ExportMonitorCodeViewDTO> monitorCodeViewDTOList){
        return null;
    }
    /**
     * 单元监测-发送监测邮件
     * @param serviceContext
     * @param adgroupViewDTO
     * @param monitorCodeViewDTOList
     * @return
     */
    @Override
    public List<Long> getNeedToSendEmailSubCampaignIds(ServiceContext serviceContext,AdgroupViewDTO adgroupViewDTO, List<ExportMonitorCodeViewDTO> monitorCodeViewDTOList){
        return null;
    }
}