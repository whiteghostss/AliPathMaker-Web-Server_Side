package com.taobao.ad.brand.bp.domain.adgroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryLockViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignRegisterMannerEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandStockTypeEnum;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupBottomJudgeAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupBottomJudgeAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Component
@BusinessAbility
public class BrandAdgroupBottomJudgeAbility implements IAdgroupBottomJudgeAbility, BrandAtomAbilityRouter {

    @Override
    public Boolean handle(ServiceContext context, AdgroupBottomJudgeAbilityParam bottomJudgeAbilityParam) {
        CampaignViewDTO campaignViewDTO = bottomJudgeAbilityParam.getAbilityTarget();
        //非PD的计划自动生成一个打底单元，单元为草稿
        Integer sspRegisterManner = campaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterManner();
        if (Objects.equals(sspRegisterManner,BrandCampaignRegisterMannerEnum.PD.getCode())){
            RogerLogger.info("计划ID:{}是PD计划，无需创建打底单元",campaignViewDTO.getId());
            return false;
        }
        //计划库存预定量
        List<CampaignInquiryViewDTO> campaignInquiryViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignInquiryLockViewDTO())
                .map(CampaignInquiryLockViewDTO::getCampaignInquiryViewDTOList).orElse(Lists.newArrayList());
        //非程序化计划不创建
        Optional<CampaignInquiryViewDTO> any;
        if(BizCampaignToolsHelper.isDoohCampaign(campaignViewDTO.getCampaignResourceViewDTO().getSspProductLineId())){
            any = campaignInquiryViewDTOList.stream().findAny();
        }else{
            any = campaignInquiryViewDTOList.stream().filter(v -> BrandStockTypeEnum.PRECISION.getCode().equals(v.getStockType())).findAny();
        }
        if (!any.isPresent()) {
            RogerLogger.info("计划ID:{}没有精准库存，无需创建打底单元",campaignViewDTO.getId());
            return false;
        }
        return true;
    }
}
