package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupValidateForFinishCampaignGroupAbilityParam;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
public class BrandOneBPCampaignGroupValidateForFinishCampaignGroupAbility
        extends DefaultCampaignGroupValidateForFinishCampaignGroupAbility implements BrandOneBPAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupValidateForFinishCampaignGroupAbilityParam abilityParam) {
        return null;
    }
}
