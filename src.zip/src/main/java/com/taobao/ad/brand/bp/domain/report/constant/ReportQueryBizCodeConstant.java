package com.taobao.ad.brand.bp.domain.report.constant;

/**
 * @author yuncheng.lyc
 */
public interface ReportQueryBizCodeConstant {

    /**
     * 常规报表查询
     */
    String RPT_QUERY_BASIC = "";


}
