package com.taobao.ad.brand.bp.domain.cart.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSkuViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.ICartItemSkuStatusValidateForAddCartItemAbility;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.param.CartItemValidateAbilityParam;
import com.taobao.ad.brand.perform.client.enums.shopwindow.SkuStatusEnum;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCartItemSkuStatusValidateForAddCartItemAbility implements ICartItemSkuStatusValidateForAddCartItemAbility, SelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext context, CartItemValidateAbilityParam validateAbilityParam) {
        BrandSkuViewDTO skuViewDTO = validateAbilityParam.getSkuViewDTO();
        AssertUtil.assertTrue(Objects.equals(SkuStatusEnum.ONLINE.getCode(),skuViewDTO.getStatus()),
                String.format("skuId=%s当前状态不可用",skuViewDTO.getId()));
        return null;
    }
}
