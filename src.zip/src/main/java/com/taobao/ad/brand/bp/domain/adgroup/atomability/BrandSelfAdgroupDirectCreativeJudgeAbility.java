package com.taobao.ad.brand.bp.domain.adgroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.adgroup.resource.AdgroupResourceViewDTO;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupBottomTypeEnum;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupOnlineStatusEnum;
import com.alibaba.ad.nb.ssp.constant.common.CrossSceneEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupDirectCreativeJudgeAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupDirectCreativeJudgeAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Optional;

@Component
@BusinessAbility
public class BrandSelfAdgroupDirectCreativeJudgeAbility implements IAdgroupDirectCreativeJudgeAbility, BrandSelfServiceAtomAbilityRouter {

    @Override
    public Boolean handle(ServiceContext serviceContext, AdgroupDirectCreativeJudgeAbilityParam abilityParam) {
        AdgroupViewDTO adgroupViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(adgroupViewDTO,"单元不存在");

        AssertUtil.assertTrue(Objects.equals(BrandAdgroupOnlineStatusEnum.ONLINE.getCode(),adgroupViewDTO.getOnlineStatus()),
                String.format("非正式状态单元，不支持生成媒体直投创意，id=%s",adgroupViewDTO.getId()));
        Integer sspCrossScene = Optional.ofNullable(adgroupViewDTO.getAdgroupResourceViewDTO()).map(AdgroupResourceViewDTO::getSspCrossScene).orElse(null);
        AssertUtil.assertTrue(Objects.equals(CrossSceneEnum.CROSS_OPAQUE_SCENE.getValue(),sspCrossScene),
                String.format("非全域通黑盒单元，不支持生成媒体直投创意，id=%s",adgroupViewDTO.getId()));
        AssertUtil.assertTrue(Objects.equals(BrandAdgroupBottomTypeEnum.BOTTOM.getCode(),adgroupViewDTO.getBottomType()),
                String.format("非打底单元，不支持生成媒体直投创意，id=%s",adgroupViewDTO.getId()));

        return true;
    }
}
