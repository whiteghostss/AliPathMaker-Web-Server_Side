package com.taobao.ad.brand.bp.domain.config;

import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.domain.config.base.BaseDiamondPropertiesConfig;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class EffectAdAgencyMasterDiamondConfig extends BaseDiamondPropertiesConfig {

    private static volatile String config;

    @Override
    protected String getDataId() {
        return "effect.agency.master.ids";
    }

    @Override
    protected String getGroupId() {
        return "com.taobao.ad.brand.bp";
    }

    @Override
    protected void initDiamond(String diamondConfig) {
        RogerLogger.info("DiamondConfig.initDiamond EffectAdAgencyMasterDiamondConfig param: {}", diamondConfig);
        config = diamondConfig;
    }

    public List<Long> getWhiteMasterIds() {
        if(StringUtils.isBlank(config)){
            return Lists.newArrayList();
        }
        return JSON.parseArray(config,Long.class);
    }
}
