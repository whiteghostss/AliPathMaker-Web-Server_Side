package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.resource.CampaignResourceViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignResourceInitForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignResourceAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultCampaignResourceInitForUpdateCampaignAbility implements ICampaignResourceInitForUpdateCampaignAbility {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignResourceAbilityParam abilityParam) {
        CampaignResourceViewDTO campaignResourceViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        AssertUtil.notNull(campaignResourceViewDTO, "计划资源不能为空");
        AssertUtil.notNull(dbCampaignViewDTO, "计划不存在");

        CampaignResourceViewDTO dbCampaignResourceViewDTO = dbCampaignViewDTO.getCampaignResourceViewDTO();

        campaignResourceViewDTO.setSspProductId(dbCampaignResourceViewDTO.getSspProductId());
        campaignResourceViewDTO.setSspProductUuid(dbCampaignResourceViewDTO.getSspProductUuid());
        campaignResourceViewDTO.setSspResourceTypes(dbCampaignResourceViewDTO.getSspResourceTypes());
        campaignResourceViewDTO.setSspMediaId(dbCampaignResourceViewDTO.getSspMediaId());
        campaignResourceViewDTO.setSspResourceIds(dbCampaignResourceViewDTO.getSspResourceIds());
        campaignResourceViewDTO.setSspMediaScope(dbCampaignResourceViewDTO.getSspMediaScope());
        campaignResourceViewDTO.setSspProductLineId(dbCampaignResourceViewDTO.getSspProductLineId());
        campaignResourceViewDTO.setSspCrossScene(dbCampaignResourceViewDTO.getSspCrossScene());
        return null;
    }
}
