package com.taobao.ad.brand.bp.domain.oss;

import java.net.URL;

import com.aliyun.oss.model.CannedAccessControlList;

/**
 * @author jixiu.lj
 * @date 2023/3/30 14:15
 */
public interface OssRepository {
    /**
     * 90天
     */
    Long EXPIRE_TIME_THREE_MONTH = 3 * 30 * 24 * 60 * 60 * 1000L;

    /**
     * 上传并获取CDN链接
     *
     * @param path 文件路径
     * @param fileByte 数据
     * @return
     */
    String uploadWithCDN(String path, byte[] fileByte);


    /**
     * 上传
     *
     * @param ossPath
     * @param fileByte
     */
    void upload(String ossPath, byte[] fileByte);

    /**
     * 上传
     * @param originalFileName - 文件名称
     * @param ossPath - oss文件路径
     * @param fileByte - 文件内容
     */
    void upload(String originalFileName, String ossPath, byte[] fileByte);

    /**
     * 上传
     * @param ossPath
     * @param fileByte
     * @param accessControl
     */
    void upload(String ossPath, byte[] fileByte, CannedAccessControlList accessControl);

    /**
     * 下载
     *
     * @param fileName
     * @return
     */
    byte[] download(String fileName);

    /**
     * 下载
     * @param url
     * @return
     */
    byte[] download(URL url);

    /**
     * 文件是否存在
     *
     * @param fileName
     * @return
     */
    boolean exists(String fileName);

    /**
     * 删除文件
     *
     * @param fileName
     * @return
     */
    boolean delete(String fileName);

    /**
     * 生成OSS可访问的短期公共链接（签名所需授权ak是业务方自行申请的oss bucket）
     *
     * @param fileName
     * @return
     */
    String getTemporaryDownloadUrl(String fileName);
    /**
     * 生成OSS可访问的短期公共链接（签名所需授权ak是业务方自行申请的oss bucket）
     *
     * @param fileName
     * @return
     */
    String getTemporaryDownloadUrl(String fileName,Long expireTime);

}