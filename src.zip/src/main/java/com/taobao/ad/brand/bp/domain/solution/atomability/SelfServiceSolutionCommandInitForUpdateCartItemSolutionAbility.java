package com.taobao.ad.brand.bp.domain.solution.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryLockViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignOnlineStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.solution.CartItemSolutionViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.solution.atomability.ISolutionCommandInitForUpdateCartItemSolutionAbility;
import com.taobao.ad.brand.bp.domain.sdk.solution.atomability.param.CartItemSolutionCommandUpdateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceSolutionCommandInitForUpdateCartItemSolutionAbility implements ISolutionCommandInitForUpdateCartItemSolutionAbility, SelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CartItemSolutionCommandUpdateAbilityParam abilityParam) {
        CartItemSolutionViewDTO solutionCommandViewDTO = abilityParam.getAbilityTarget();
        CartItemSolutionViewDTO dbSolutionCommandViewDTO = abilityParam.getDbCartItemSolutionViewDTO();

        //加购行状态设置未下单
        solutionCommandViewDTO.setStatus(dbSolutionCommandViewDTO.getStatus());
        solutionCommandViewDTO.setCartSource(dbSolutionCommandViewDTO.getCartSource());
        solutionCommandViewDTO.setType(dbSolutionCommandViewDTO.getType());
        solutionCommandViewDTO.setSkuId(dbSolutionCommandViewDTO.getSkuId());
        solutionCommandViewDTO.setBundleId(dbSolutionCommandViewDTO.getBundleId());

        //计划状态设置为草稿，并清空询量数据
        CampaignViewDTO campaignViewDTO = solutionCommandViewDTO.getCampaignViewDTO();
        CampaignViewDTO dbCampaignViewDTO = dbSolutionCommandViewDTO.getCampaignViewDTO();
        campaignViewDTO.setId(dbCampaignViewDTO.getId());
        campaignViewDTO.setStatus(BrandCampaignStatusEnum.NEW.getCode());

        CampaignInquiryLockViewDTO campaignInquiryLockViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignInquiryLockViewDTO()).orElse(new CampaignInquiryLockViewDTO());
        campaignInquiryLockViewDTO.setCampaignInquiryViewDTOList(Lists.newArrayList());
        campaignViewDTO.setCampaignInquiryLockViewDTO(campaignInquiryLockViewDTO);
        return null;
    }
}
