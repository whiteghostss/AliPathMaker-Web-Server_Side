package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.realsettle.CampaignGroupRealSettleViewDTO;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupStopTimeUpdateForStopCastCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupStopTimeUpdateForStopCastCampaignGroupAbilityParam;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
@BusinessAbility
public class DefaultCampaignGroupStopTimeUpdateForStopCastCampaignGroupAbility
    implements ICampaignGroupStopTimeUpdateForStopCastCampaignGroupAbility {

    @Resource
    private CampaignGroupRepository campaignGroupRepository;
    @Override
    public Void handle(ServiceContext serviceContext,
                       CampaignGroupStopTimeUpdateForStopCastCampaignGroupAbilityParam abilityParam) {
        // 子订单
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        // 主订单
        CampaignGroupViewDTO mainCampaignGroupViewDTO = abilityParam.getMainCampaignGroup();

        // 更新停投时间（子订单使用主订单停投时间）
        CampaignGroupViewDTO updateCampaignGroupViewDTO = new CampaignGroupViewDTO();
        updateCampaignGroupViewDTO.setId(campaignGroupViewDTO.getId());
        CampaignGroupRealSettleViewDTO realSettleViewDTO = new CampaignGroupRealSettleViewDTO();
        realSettleViewDTO.setStopCastTime(mainCampaignGroupViewDTO.getCampaignGroupRealSettleViewDTO().getStopCastTime());
        updateCampaignGroupViewDTO.setCampaignGroupRealSettleViewDTO(realSettleViewDTO);
        campaignGroupRepository.updateCampaignGroupPart(serviceContext, updateCampaignGroupViewDTO);
        return null;
    }
}
