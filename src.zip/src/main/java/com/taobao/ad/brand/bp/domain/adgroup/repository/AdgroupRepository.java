package com.taobao.ad.brand.bp.domain.adgroup.repository;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.adgroup.crowd.AdgroupCrowdViewDTO;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdViewDTO;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;

import java.util.List;
import java.util.Map;

public interface AdgroupRepository {
    /**
     * 分页查询单元列表
     * @param serviceContext
     * @param query
     * @return
     */
    PageResultViewDTO<AdgroupViewDTO> queryAdgroupPageList(ServiceContext serviceContext, AdgroupQueryViewDTO query);
    /**
     * 只包含基础信息， 不包含定向信息
     * @param serviceContext
     * @param adgroupQueryViewDTO
     * */
    List<AdgroupViewDTO> queryAdgroupListNoPage(ServiceContext serviceContext,AdgroupQueryViewDTO adgroupQueryViewDTO);

    /**
     * 只包含基础信息， 不包含定向信息
     * @param serviceContext
     * @param adgroupQueryViewDTO
     * */
    List<AdgroupViewDTO> queryAdgroupBasicListNoPage(ServiceContext serviceContext,AdgroupQueryViewDTO adgroupQueryViewDTO);

    /**
     * 只包含基础信息， 不包含定向信息
     * @param serviceContext
     * @param adgroupQueryViewDTO
     * */
    Integer count(ServiceContext serviceContext,AdgroupQueryViewDTO adgroupQueryViewDTO);


    /**
     * 根据名称查询单元名称
     *
     * @param serviceContext
     * @param excludeAdgroupId
     * @param title
     */
    AdgroupViewDTO queryAdgroupTopOneByName(ServiceContext serviceContext, Long excludeAdgroupId, String title);

    /**
     * 添加单元
     * @param serviceContext
     * @param adgroupViewDTO
     */
    Long addAdgroup(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO);
    /**
     * 添加人群定向
     */
    void addAdgroupCrowdTarget(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO);
    /**
     * 更新adgroup的人群定向
     * @param serviceContext
     * @param adgroupViewDTO
     * */
    void updateAdgroupCrowdTarget(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO);

    /**
     * 更新adgroup人群定向标识
     * @param serviceContext
     * @param adgroupIdList
     */
    void batchUpdateAdgroupCrowdTag(ServiceContext serviceContext, List<Long> adgroupIdList);

    /**
     * 添加creativeref
     * @param serviceContext
     * @param adgroupViewDTO
     * */
    void updateCreativeRef(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO);

    void addCreativeRef(ServiceContext serviceContext,AdgroupViewDTO adgroupViewDTO);

    /**
    * 更新单元
     * @param serviceContext
     * @param adgroupViewDTO
    * */
    Long updateAdgroup(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO);

    Long updateAdgroupLastSendTime(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO);

    /**
     * 根据单元ID删除单元setting
     * @param serviceContext
     * @param adgroupId
     * @param settingKeyList
     * @return
     */
    Integer deleteAdgroupSettingBatch(ServiceContext serviceContext, Long adgroupId, List<String> settingKeyList);


    /**
     * 更新单元状态
     * @param serviceContext
     * @param ids 单元IDS
     * @param status @see BrandAdgroupOnlineStatus
     *
     * */
    void batchUpdateAdgroupStatus(ServiceContext serviceContext, List<Long> ids, Integer status);

    /**
     * 批量部分更新单元
     * @param serviceContext
     * @param AdgroupViewDTOList
     */
    void batchUpdateAdgroupPart(ServiceContext serviceContext, List<AdgroupViewDTO> AdgroupViewDTOList);

    /**
     * 删除单元（by 计划ID）
     * */
    void deleteAdgroupByCampaignId(ServiceContext serviceContext, Long campaignId);

    /**
     * 批量删除单元（by 计划ID）
     * */
    void deleteAdgroupByCampaignIds(ServiceContext serviceContext, List<Long> campaignIds);
    /**
     * 删除单元
     * */
    void deleteAdgroup(ServiceContext serviceContext, Long id);
    /**
     * 批量删除单元
     * */
    void batchDeleteAdgroup(ServiceContext serviceContext, List<Long> id);

    /**
     * 获取单个单元
     * @param serviceContext
     * @param adgroupId
     * @return adgroupViewDTO
     */
    AdgroupViewDTO getAdgroupById(ServiceContext serviceContext, Long adgroupId);
    /**
     * 获取单个单元
     * 无人群无创意
     * 只有基础信息
     * @param serviceContext
     * @param adgroupId
     * @return adgroupViewDTO
     */
    AdgroupViewDTO getBaseAdgroupById(ServiceContext serviceContext, Long adgroupId);

    /**
     * 多个adgroup获取人群定向map
     * @param serviceContext
     * @param adgroupIds
     * @return map
     */
    Map<Long,List<AdgroupCrowdViewDTO>> getCrowdTargetMapByAdgroupIds(ServiceContext serviceContext, List<Long> adgroupIds);

    /**
     * 根据adgroupId获取人群的list
     * @param serviceContext
     * @param adgroupId
     * @return list
     * */
    List<AdgroupCrowdViewDTO> getCrowdTargetByAdgroupId(ServiceContext serviceContext, Long adgroupId);
    /**
     * 部分更新adgroup，目前只有名称
     * @param serviceContext
     * @param adgroupViewDTO
     * @return list
     * */
    void updateAdgroupPart(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO);

    void deleteAdgroupSettingBatch(ServiceContext serviceContext, List<Long> adgroupIdList, List<String> settingKeyList);

    /**
     * 删除单元部分定向
     * @param serviceContext
     * @param adgroupId
     * @param targetType
     */
    void deleteAdgroupTargetPart(ServiceContext serviceContext, Long adgroupId, Long targetType);
    void deleteAdgroupCrowdByAudienceCrowdIds(ServiceContext serviceContext, Long adgroupId, List<Long> audienceCrowdIds);
    void addAdgroupCastingCrowdTarget(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, List<CampaignCrowdViewDTO> crowdViewDTOList);

    void addOrUpdateAdgroupTargetPart(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO);

    /**
     * 增加计划单元标
     * @param serviceContext
     * @param adgroupViewDTOList
     */
     void batchUpdateAdgroupViewDTOCrowdTag(ServiceContext serviceContext, List<AdgroupViewDTO> adgroupViewDTOList) ;
}
