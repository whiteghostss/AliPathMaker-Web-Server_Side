package com.taobao.ad.brand.bp.domain.solution.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;

import com.alibaba.ad.brand.dto.campaign.budget.CampaignBudgetViewDTO;
import com.alibaba.ad.brand.dto.campaign.price.CampaignPriceViewDTO;
import com.alibaba.ad.brand.sdk.constant.cartitem.BrandCartItemTypeEnum;
import com.taobao.ad.brand.bp.client.dto.solution.CartItemSolutionViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.solution.atomability.param.CartItemSolutionCommandAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceSolutionCommandBaseValidateForSaveCartItemSolutionAbility extends DefaultSolutionCommandBaseValidateForSaveCartItemSolutionAbility implements SelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CartItemSolutionCommandAbilityParam abilityParam) {
        CartItemSolutionViewDTO solutionCommandViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(solutionCommandViewDTO,"参数不允许为空");

        if(solutionCommandViewDTO.getId() != null){
            AssertUtil.notNull(solutionCommandViewDTO.getOperate(),"操作路径不能为空");
        }
        AssertUtil.notNull(solutionCommandViewDTO.getCartSource(),"加购数据源不允许为空");
        AssertUtil.notNull(solutionCommandViewDTO.getType(),"加购行类型不允许为空");
        AssertUtil.notNull(solutionCommandViewDTO.getSkuId(),"sku不允许为空");
        AssertUtil.notNull(solutionCommandViewDTO.getBundleId(),"套餐包不允许为空");

        AssertUtil.assertTrue(BrandCartItemTypeEnum.SLIM_ORDER.getCode().equals(solutionCommandViewDTO.getType()),"非极简版不支持该功能操作");

        CampaignViewDTO campaignViewDTO = solutionCommandViewDTO.getCampaignViewDTO();
        Long discountTotalMoney = Optional.ofNullable(solutionCommandViewDTO.getCampaignViewDTO())
                .map(CampaignViewDTO::getCampaignBudgetViewDTO).map(CampaignBudgetViewDTO::getDiscountTotalMoney).orElse(null);
        AssertUtil.notNull(discountTotalMoney,"投放预算不能为空");
        AssertUtil.notNull(campaignViewDTO.getStartTime(),"投放开始时间不能为空");
        AssertUtil.notNull(campaignViewDTO.getEndTime(),"投放结束时间不能为空");
        AssertUtil.assertTrue(BrandDateUtil.isBeforeAndEqual(campaignViewDTO.getStartTime(), campaignViewDTO.getEndTime())
                , "计划开始时间小于等于结束时间");

        AssertUtil.notEmpty(solutionCommandViewDTO.getCreativeViewDTOList(),"投放创意不能为空");
        AssertUtil.notNull(solutionCommandViewDTO.getPayMode(),"支付方式不能为空");
        return null;
    }
}
