package com.taobao.ad.brand.bp.domain.dmp;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.CrowdViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.query.CrowdQueryViewDTO;

import java.util.List;

/**
 * 人群相关服务
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
public interface CrowdRepository {

    PageResultViewDTO<CrowdViewDTO> findCrowdPageList(ServiceContext context, CrowdQueryViewDTO queryViewDTO);

    /**
     * 根据crowdIds查询人群
     *
     * @param context
     * @param ids
     * @return
     */
    List<CrowdViewDTO> queryCrowdByIds(ServiceContext context, List<Long> ids);

    /**
     * 查询人群覆盖数
     * @param context
     * @param crowdIds
     * @return
     */
    Long getCrowdCoverage(ServiceContext context, List<Long> crowdIds);

    /**
     * 查询人群新增覆盖数
     *
     * @param serviceContext
     * @param newCrowdIdList
     * @param oldCrowdIdList
     * @return
     */
    Long increaseCalculate(ServiceContext serviceContext, List<Long> newCrowdIdList, List<Long> oldCrowdIdList);

    /**
     * 查询showmax标签 for回显和计划导入
     * @param serviceContext
     * @param memberId
     * @param showmaxCrowdType
     * @return
     */
    List<CommonViewDTO> queryShowmaxCrowdTagList(ServiceContext serviceContext, Long memberId, Integer showmaxCrowdType);

    /**
     * DMP的模板人群，for计划导入
     * */
    List<CrowdViewDTO> findRecommendCrowd(ServiceContext serviceContext,Long memberId, Integer showmaxType, String labelIdList, String brandIds);

    PageResultViewDTO<CrowdViewDTO> findCreativePreviewCrowdPageList(ServiceContext context, CrowdQueryViewDTO queryViewDTO);

}
