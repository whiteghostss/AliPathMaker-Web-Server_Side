package com.taobao.ad.brand.bp.domain.adgroup.constant;

import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.google.common.collect.Lists;
import org.apache.commons.lang3.tuple.Pair;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
/**
 *
 * 单元是否可以新建相关状态常量
 *  /**
 *      * 1. 主计划：
 *      *   1.1订单状态=（正在下单、正在下单资源确认中、下单完成合同流程中、等待推广、正在推广、改单配置）
 *      *    &计划状态=（等待推广、正在推广）
 *      *   2.2订单状态 =（正在下单、正在下单资源确认中、下单完成合同流程中）& 计划状态 = 锁量成功。
 *      * 2. 计划是补量、配送计划：计划状态 =（等待推广、正在推广）
 *      * */
public class AdgroupCreateValidateConstant {


    
   /**
    * 主计划相关的订单状态list
    * */
   public static List<Integer> MAIN_CAMPAIGN_X_CAMPAIGN_GROUP_STATUS_LIST_GROUP1 = Lists.newArrayList(
           BrandCampaignGroupStatusEnum.ORDER_ING.getCode(),
           BrandCampaignGroupStatusEnum.RESOURCE_CONFIRM_ING.getCode(),
           BrandCampaignGroupStatusEnum.CONTRACT_PROCESS_ING.getCode(),
           BrandCampaignGroupStatusEnum.WAIT_CAST.getCode(),
           BrandCampaignGroupStatusEnum.CAST_ING.getCode(),
           BrandCampaignGroupStatusEnum.UNLOCKED.getCode());
   /**
    * 主计划相关的订单状态list
    *  WAITING(7, "等待推广"),
    *     CASTING(8, "正在推广"),
    * */
   public static List<Integer> MAIN_CAMPAIGN_STATUS_LIST_GROUP1 = Lists.newArrayList(
           BrandCampaignStatusEnum.WAITING.getCode(),
           BrandCampaignStatusEnum.PAUSING.getCode(),

           BrandCampaignStatusEnum.CASTING.getCode());


   public static List<Integer> MAIN_CAMPAIGN_X_CAMPAIGN_GROUP_STATUS_LIST_GROUP2 = Lists.newArrayList(
           BrandCampaignGroupStatusEnum.ORDER_ING.getCode(),
           BrandCampaignGroupStatusEnum.RESOURCE_CONFIRM_ING.getCode(),
           BrandCampaignGroupStatusEnum.CONTRACT_PROCESS_ING.getCode()
          );
   /**
    * 订单状态 =（正在下单、正在下单资源确认中、下单完成合同流程中）& 计划状态 = 锁量成功。
    * */
   public static List<Integer> MAIN_CAMPAIGN_STATUS_LIST_GROUP2 = Lists.newArrayList(
           BrandCampaignStatusEnum.LOCK_SUCCESS.getCode());
//
//   /**
//    * 补量配送计划相关的订单状态list
//    * 订单状态 =（正在下单、正在下单资源确认中、下单完成合同流程中）
//    * */
//   public static List<Integer> OTHER_CAMPAIGN_X_CAMPAIGN_GROUP_STATUS_LIST = Lists.newArrayList(
//           BrandCampaignGroupStatusEnum.ORDER_ING.getCode(),
//           BrandCampaignGroupStatusEnum.RESOURCE_CONFIRM_ING.getCode(),
//           BrandCampaignGroupStatusEnum.CONTRACT_PROCESS_ING.getCode());

   /**
    * 补量配送计划相关的计划状态list
    * */
   public static List<Integer> OTHER_CAMPAIGN_STATUS_LIST = Lists.newArrayList(
           BrandCampaignStatusEnum.CASTING.getCode(),
           BrandCampaignStatusEnum.PAUSING.getCode(),


           BrandCampaignStatusEnum.WAITING.getCode());


}
