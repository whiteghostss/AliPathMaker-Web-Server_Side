package com.taobao.ad.brand.bp.domain.campaign.workflow;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.sale.CampaignSaleViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignOnlineStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.setting.BrandCampaignSettingKeyEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.context.DomainMetaqMessageBodyContext;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.DateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignBatchDeleteViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.dto.rule.RuleCheckResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandBundleViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSkuViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSpuViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignEventEnum;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignPVAssignSceneEnum;
import com.taobao.ad.brand.bp.client.enums.message.DomainMessageTypeEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPCustomErrorCode;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.campaign.spi.BizCampaignSplitSpi;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.event.DomainMetaqMessageEvent;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.workflow.router.SelfServiceExtensionRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.calculate.ICampaignPriceInitForAssignBudgetAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.consistency.ICampaignBudgetConsistencyCheckAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.consistency.ICampaignCastDateConsistencyCheckAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.consistency.ICampaignCrowdConsistencyCheckAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.consistency.ICampaignPriceConsistencyCheckAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignBudgetWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.ICartItemAdDateJudgeAbility;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.param.CartItemAdDateJudgeAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.calculate.ISaleGroupPvAssignForCalculateAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.ResourcePackageSaleGroupCalculateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.IMessageAsyncSendAbility;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.param.MessageAsyncSendAbilityParam;
import com.taobao.ad.brand.bp.domain.shopwindow.repository.BrandSkuRepository;
import com.taobao.ad.brand.bp.domain.shopwindow.repository.BrandSpuRepository;
import com.taobao.ad.brand.bp.domain.ssp.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.common.spi.ExtensionPointsFactory.runAbilitySpi;

/**
 * Description:
 * <p>
 * date: 2023/10/24 2:51 PM
 *
 * @author shiyan
 * @version 1.0
 */
@Service
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCampaignCommandWorkflowExtImpl extends DefaultCampaignCommandWorkflowExtImpl implements SelfServiceExtensionRouter {

    private final ProductRepository productRepository;
    private final CampaignRepository campaignRepository;
    private final CampaignGroupRepository campaignGroupRepository;
    private final ResourcePackageRepository resourcePackageRepository;
    private final BrandSkuRepository brandSkuRepository;
    private final BrandSpuRepository brandSpuRepository;

    private final ICampaignStructureQueryAbility campaignStructureQueryAbility;
    private final ICartItemAdDateJudgeAbility cartItemAdDateJudgeAbility;

    private final ICampaignPriceConsistencyCheckAbility campaignPriceConsistencyCheckAbility;
    private final ICampaignCastDateConsistencyCheckAbility campaignCastDateConsistencyCheckAbility;
    private final ICampaignBudgetConsistencyCheckAbility campaignBudgetConsistencyCheckAbility;
    private final ICampaignCrowdConsistencyCheckAbility campaignCrowdConsistencyCheckAbility;

    private final ICampaignBaseValidateForAddCampaignAbility campaignBaseValidateForAddCampaignAbility;
    private final ICampaignTitleValidateAbility campaignTitleValidateAbility;
    private final ICampaignAdzoneValidateForAddCampaignAbility campaignAdzoneValidateForAddCampaignAbility;
    private final ICampaignBudgetValidateForAddCampaignAbility campaignBudgetValidateForAddCampaignAbility;
    private final ICampaignSelfServiceValidateForAddCampaignAbility campaignSelfServiceValidateForAddCampaignAbility;
    private final ICampaignStatusValidateForUpdateCampaignAbility campaignStatusValidateForUpdateCampaignAbility;
    private final ICampaignUpdateJudgeForUpdateCampaignAbility campaignUpdateJudgeForUpdateCampaignAbility;
    private final ICampaignBaseInitForAddCampaignAbility campaignBaseInitForAddCampaignAbility;
    private final ICampaignResourceInitForAddCampaignAbility campaignResourceInitForAddCampaignAbility;
    private final ICampaignCreativeControllerInitForAddCampaignAbility campaignCreativeControllerInitForAddCampaignAbility;
    private final ICampaignSaleInitForAddCampaignAbility campaignSaleInitForAddCampaignAbility;
    private final ICampaignGuaranteeInitForAddCampaignAbility campaignGuaranteeInitForAddCampaignAbility;
    private final ICampaignInquiryLockInitForAddCampaignAbility campaignInquiryLockInitForAddCampaignAbility;
    private final ICampaignSmoothInitForAddCampaignAbility campaignSmoothInitForAddCampaignAbility;
    private final ICampaignPriceInitForAddCampaignAbility campaignPriceInitForAddCampaignAbility;
    private final ICampaignScrollInitForAddCampaignAbility campaignScrollInitForAddCampaignAbility;
    private final ICampaignAdzoneInitForAddCampaignAbility campaignAdzoneInitForAddCampaignAbility;
    private final ICampaignMonitorInitForAddCampaignAbility campaignMonitorInitForAddCampaignAbility;
    private final ICampaignTitleInitAbility campaignTitleInitAbility;

    private final ICampaignBaseInitForUpdateCampaignAbility campaignBaseInitForUpdateCampaignAbility;
    private final ICampaignSaleInitForUpdateCampaignAbility campaignSaleInitForUpdateCampaignAbility;
    private final ICampaignResourceInitForUpdateCampaignAbility campaignResourceInitForUpdateCampaignAbility;
    private final ICampaignCreativeControllerInitForUpdateCampaignAbility campaignCreativeControllerInitForUpdateCampaignAbility;
    private final ICampaignPriceInitForUpdateCampaignAbility campaignPriceInitForUpdateCampaignAbility;
    private final ICampaignBudgetInitForUpdateCampaignAbility campaignBudgetInitForUpdateCampaignAbility;
    private final ICampaignSmoothInitForUpdateCampaignAbility campaignSmoothInitForUpdateCampaignAbility;
    private final ICampaignGuaranteeInitForUpdateCampaignAbility campaignGuaranteeInitForUpdateCampaignAbility;
    private final ICampaignBoostInitForUpdateCampaignAbility campaignBoostInitForUpdateCampaignAbility;
    private final ICampaignScrollInitForUpdateCampaignAbility campaignScrollInitForUpdateCampaignAbility;
    private final ICampaignAdzoneInitForUpdateCampaignAbility campaignAdzoneInitForUpdateCampaignAbility;
    private final ICampaignMonitorInitForUpdateCampaignAbility campaignMonitorInitForUpdateCampaignAbility;
    private final ICampaignInquiryLockInitForUpdateCampaignAbility campaignInquiryLockInitForUpdateCampaignAbility;
    private final ICampaignSelfServiceInitForUpdateCampaignAbility campaignSelfServiceInitForUpdateCampaignAbility;
    private final ICampaignPermissionDeleteValidateAbility campaignPermissionDeleteValidateAbility;
    private final ICampaignStatusDeleteValidateAbility campaignStatusDeleteValidateAbility;
    private final ICampaignInquiryLockDeleteValidateAbility campaignInquiryLockDeleteValidateAbility;
    private final ICampaignUnionControlFlowInitForAddCampaignAbility campaignUnionControlFlowInitForAddCampaignAbility;
    private final ICampaignUpdatePartAbility campaignUpdatePartAbility;
    private final ICampaignPriceInitForAssignBudgetAbility campaignPriceInitForAssignBudgetAbility;

    private final ISaleGroupPvAssignForCalculateAbility saleGroupPvAssignForCalculateAbility;
    private final IMessageAsyncSendAbility messageAsyncSendAbility;

    private final ICampaignExtInitForUpdateCampaignAbility campaignExtInitForUpdateCampaignAbility;

    @Override
    public BizCampaignWorkflowParam buildParamForAddOrUpdate(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {
        AssertUtil.notNull(campaignViewDTO,"计划不允许为空");

        AssertUtil.notNull(campaignViewDTO.getCampaignSelfServiceViewDTO().getSkuId(),"商品id不为空");

        BrandSkuViewDTO skuViewDTO = brandSkuRepository.get(serviceContext,campaignViewDTO.getCampaignSelfServiceViewDTO().getSkuId());
        AssertUtil.notNull(skuViewDTO, "SKU不存在或者已被删除");
        // SPU\SKU id
        Long resourcePackageSaleGroupId = skuViewDTO.getResourcePackageSaleGroupId();
        AssertUtil.notNull(resourcePackageSaleGroupId,"招商分组ID不允许为空");
        Long  resourcePackageProductId =  skuViewDTO.getResourcePackageProductId();
        AssertUtil.notNull(resourcePackageSaleGroupId, "售卖分组资源位ID不存在");

        BrandSpuViewDTO spuViewDTO = brandSpuRepository.get(serviceContext, skuViewDTO.getSpuId());
        AssertUtil.notNull(spuViewDTO, "SPU不存在或者已被删除");

        //套餐包
        BrandBundleViewDTO bundleViewDTO = null;
        if(campaignViewDTO.getCampaignSelfServiceViewDTO().getBundleId() != null){
            bundleViewDTO = brandSkuRepository.getBundleDetail(serviceContext, campaignViewDTO.getCampaignSelfServiceViewDTO().getBundleId());
            AssertUtil.notNull(bundleViewDTO,"套餐包不存在");
        }
        ResourcePackageQueryOption packageQueryOption = ResourcePackageQueryOption.builder().needProduct(true).needSetting(true).build();
        ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO = resourcePackageRepository.getSaleGroupById(serviceContext, resourcePackageSaleGroupId, packageQueryOption);
        AssertUtil.notNull(packageSaleGroupViewDTO,"招商分组不存在");

        ResourcePackageProductViewDTO packageProductViewDTO = packageSaleGroupViewDTO.getDistributionRuleList().stream().flatMap(e -> e.getResourcePackageProductList().stream())
            .filter(e -> e.getId().equals(resourcePackageProductId)).findFirst().orElse(null);
        AssertUtil.notNull(packageProductViewDTO, "招商资源产品不存在");

        AssertUtil.notNull(packageProductViewDTO.getSspProductId(),"二级产品ID不允许为空");
        ProductViewDTO productViewDTO = productRepository.getProductById(packageProductViewDTO.getSspProductId());
        AssertUtil.notNull(productViewDTO, "二级产品不存在");

        CampaignGroupViewDTO campaignGroupViewDTO = null;
        if(Objects.nonNull(campaignViewDTO.getCampaignGroupId())){
            campaignGroupViewDTO =  campaignGroupRepository.getCampaignGroup(serviceContext,campaignViewDTO.getCampaignGroupId());
        }

        BizCampaignWorkflowParam campaignWorkflowParam = new BizCampaignWorkflowParam();
        campaignWorkflowParam.setPackageSaleGroupViewDTO(packageSaleGroupViewDTO);
        campaignWorkflowParam.setPackageProductViewDTO(packageProductViewDTO);
        campaignWorkflowParam.setProductViewDTO(productViewDTO);
        campaignWorkflowParam.setCampaignGroupViewDTO(campaignGroupViewDTO);
        campaignWorkflowParam.setSkuViewDTO(skuViewDTO);
        campaignWorkflowParam.setSpuViewDTO(spuViewDTO);
        campaignWorkflowParam.setBundleViewDTO(bundleViewDTO);

        return campaignWorkflowParam;
    }

    @Override
    public Void beforeForAdd(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, BizCampaignWorkflowParam workflowParam) {
        resetCampaignDefaultObject(campaignViewDTO);
        this.validateForAdd(serviceContext, campaignViewDTO, workflowParam);
        this.initForAdd(serviceContext,campaignViewDTO,workflowParam);
        return null;
    }

    @Override
    public Void beforeForUpdate(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO,CampaignViewDTO dbCampaignViewDTO, BizCampaignWorkflowParam workflowParam) {
        resetCampaignDefaultObject(campaignViewDTO);
        if(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode().equals(dbCampaignViewDTO.getCampaignLevel())){
            this.validateForAdd(serviceContext, campaignViewDTO, workflowParam);
            this.validateForUpdate(serviceContext, campaignViewDTO,dbCampaignViewDTO, workflowParam);
        }
        this.initForUpdate(serviceContext,campaignViewDTO,dbCampaignViewDTO,workflowParam);
        return null;
    }

    private void validateForUpdate(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, CampaignViewDTO dbCampaignViewDTO, BizCampaignWorkflowParam workflowParam) {
        //状态校验
        campaignStatusValidateForUpdateCampaignAbility.handle(serviceContext, CampaignStatusValidateForUpdateCampaignAbilityParam.builder().abilityTarget(campaignViewDTO)
                .campaignGroupViewDTO(workflowParam.getCampaignGroupViewDTO()).dbCampaignViewDTO(dbCampaignViewDTO).build());
        //修改校验
        campaignUpdateJudgeForUpdateCampaignAbility.handle(serviceContext, CampaignUpdateAbilityParam.builder().abilityTarget(campaignViewDTO)
                .dbCampaignViewDTO(dbCampaignViewDTO).build());
    }

    private void validateForAdd(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, BizCampaignWorkflowParam workflowParam) {
        campaignBaseValidateForAddCampaignAbility.handle(serviceContext, CampaignBaseAbilityParam.builder().abilityTarget(campaignViewDTO)
                .resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        campaignTitleValidateAbility.handle(serviceContext, CampaignTitleValidateAbilityParam.builder().abilityTarget(campaignViewDTO).build());

        campaignSelfServiceValidateForAddCampaignAbility.handle(serviceContext, CampaignSelfServiceAbilityParam.builder()
                .abilityTarget(campaignViewDTO.getCampaignSelfServiceViewDTO()).build());

        campaignBudgetValidateForAddCampaignAbility.handle(serviceContext, CampaignBudgetAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignBudgetViewDTO())
                .campaignViewDTO(campaignViewDTO).build());

        campaignAdzoneValidateForAddCampaignAbility.handle(serviceContext, CampaignAdzoneAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignTargetScenarioViewDTO())
                .productViewDTO(workflowParam.getProductViewDTO()).resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        //计划草稿场景，校验投放周期
        if(BrandCampaignOnlineStatusEnum.DRAFT.getCode().equals(campaignViewDTO.getOnlineStatus())){
            DateViewDTO dateViewDTO = DateViewDTO.build(campaignViewDTO.getStartTime(), campaignViewDTO.getEndTime());
            RuleCheckResultViewDTO checkResultViewDTO = cartItemAdDateJudgeAbility.handle(serviceContext, CartItemAdDateJudgeAbilityParam.builder().abilityTarget(dateViewDTO)
                    .resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO())
                    .spuViewDTO(workflowParam.getSpuViewDTO()).bundleViewDTO(workflowParam.getBundleViewDTO()).build());
            AssertUtil.assertTrue(BrandBoolEnum.BRAND_TRUE.getCode().equals(checkResultViewDTO.getIsPass()),checkResultViewDTO.getReason());
        }
    }

    private void initForAdd(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, BizCampaignWorkflowParam workflowParam){

        campaignBaseInitForAddCampaignAbility.handle(serviceContext,CampaignBaseAbilityParam.builder().abilityTarget(campaignViewDTO)
                .resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).productViewDTO(workflowParam.getProductViewDTO()).build());

        String campaignTitle = campaignTitleInitAbility.handle(serviceContext, CampaignTitleInitAbilityParam.builder().abilityTarget(campaignViewDTO)
                .productViewDTO(workflowParam.getProductViewDTO()).showmaxCrowdList(workflowParam.getShowmaxCrowdList())
                .skuViewDTO(workflowParam.getSkuViewDTO()).spuViewDTO(workflowParam.getSpuViewDTO()).bundleViewDTO(workflowParam.getBundleViewDTO()).build());
        campaignViewDTO.setTitle(campaignTitle);

        campaignResourceInitForAddCampaignAbility.handle(serviceContext,CampaignResourceAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignResourceViewDTO())
                .productViewDTO(workflowParam.getProductViewDTO()).build());

        campaignCreativeControllerInitForAddCampaignAbility.handle(serviceContext,CampaignCreativeControllerAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignCreativeControllerViewDTO())
                .productViewDTO(workflowParam.getProductViewDTO()).resourcePackageSaleGroupViewDTO(workflowParam.getPackageSaleGroupViewDTO()).build());

        campaignSaleInitForAddCampaignAbility.handle(serviceContext,CampaignSaleAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignSaleViewDTO())
                .campaignGroupViewDTO(workflowParam.getCampaignGroupViewDTO())
                .resourcePackageSaleGroupViewDTO(workflowParam.getPackageSaleGroupViewDTO()).saleGroupInfoViewDTO(workflowParam.getSaleGroupInfoViewDTO())
                .productViewDTO(workflowParam.getProductViewDTO()).resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        campaignGuaranteeInitForAddCampaignAbility.handle(serviceContext,CampaignGuaranteeAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignGuaranteeViewDTO())
                .campaignViewDTO(campaignViewDTO).productViewDTO(workflowParam.getProductViewDTO()).resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        campaignInquiryLockInitForAddCampaignAbility.handle(serviceContext,CampaignInquiryLockAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignInquiryLockViewDTO())
                .campaignGroupViewDTO(workflowParam.getCampaignGroupViewDTO()).productViewDTO(workflowParam.getProductViewDTO()).resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        campaignSmoothInitForAddCampaignAbility.handle(serviceContext,CampaignSmoothAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignSmoothViewDTO())
                .productViewDTO(workflowParam.getProductViewDTO()).build());

        campaignPriceInitForAddCampaignAbility.handle(serviceContext,CampaignPriceAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignPriceViewDTO())
                .campaignViewDTO(campaignViewDTO).productViewDTO(workflowParam.getProductViewDTO()).resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        campaignScrollInitForAddCampaignAbility.handle(serviceContext,CampaignScrollAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignScrollViewDTO())
                .campaignViewDTO(campaignViewDTO).build());

        campaignAdzoneInitForAddCampaignAbility.handle(serviceContext,CampaignAdzoneAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignTargetScenarioViewDTO())
                .productViewDTO(workflowParam.getProductViewDTO()).resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        campaignMonitorInitForAddCampaignAbility.handle(serviceContext,CampaignMonitorAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignMonitorViewDTO())
                .resourcePackageSaleGroupViewDTO(workflowParam.getPackageSaleGroupViewDTO()).build());
    }

    private void initForUpdate(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, CampaignViewDTO dbCampaignViewDTO, BizCampaignWorkflowParam workflowParam){

        campaignBaseInitForUpdateCampaignAbility.handle(serviceContext,CampaignBaseAbilityParam.builder().abilityTarget(campaignViewDTO)
                .dbCampaignViewDTO(dbCampaignViewDTO).build());

        String campaignTitle = campaignTitleInitAbility.handle(serviceContext, CampaignTitleInitAbilityParam.builder().abilityTarget(campaignViewDTO)
                .productViewDTO(workflowParam.getProductViewDTO()).showmaxCrowdList(workflowParam.getShowmaxCrowdList())
                .skuViewDTO(workflowParam.getSkuViewDTO()).spuViewDTO(workflowParam.getSpuViewDTO()).bundleViewDTO(workflowParam.getBundleViewDTO()).build());
        campaignViewDTO.setTitle(campaignTitle);

        campaignSaleInitForUpdateCampaignAbility.handle(serviceContext,CampaignSaleAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignSaleViewDTO())
                .dbCampaignViewDTO(dbCampaignViewDTO).build());

        campaignResourceInitForUpdateCampaignAbility.handle(serviceContext,CampaignResourceAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignResourceViewDTO())
                .dbCampaignViewDTO(dbCampaignViewDTO).build());

        campaignCreativeControllerInitForUpdateCampaignAbility.handle(serviceContext,CampaignCreativeControllerAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignCreativeControllerViewDTO())
                .dbCampaignViewDTO(dbCampaignViewDTO).build());

        campaignPriceInitForUpdateCampaignAbility.handle(serviceContext,CampaignPriceAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignPriceViewDTO())
                .campaignViewDTO(campaignViewDTO).dbCampaignViewDTO(dbCampaignViewDTO).build());

        campaignBudgetInitForUpdateCampaignAbility.handle(serviceContext,CampaignBudgetAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignBudgetViewDTO())
                .campaignViewDTO(campaignViewDTO).dbCampaignViewDTO(dbCampaignViewDTO).resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        campaignSmoothInitForUpdateCampaignAbility.handle(serviceContext,CampaignSmoothAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignSmoothViewDTO())
                .campaignViewDTO(campaignViewDTO).dbCampaignViewDTO(dbCampaignViewDTO).build());

        campaignBoostInitForUpdateCampaignAbility.handle(serviceContext,CampaignBoostAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignBoostViewDTO())
                .campaignViewDTO(campaignViewDTO).dbCampaignViewDTO(dbCampaignViewDTO).build());

        campaignGuaranteeInitForUpdateCampaignAbility.handle(serviceContext,CampaignGuaranteeAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignGuaranteeViewDTO())
                .campaignViewDTO(campaignViewDTO).dbCampaignViewDTO(dbCampaignViewDTO).productViewDTO(workflowParam.getProductViewDTO()).build());

        campaignScrollInitForUpdateCampaignAbility.handle(serviceContext,CampaignScrollAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignScrollViewDTO())
                .campaignViewDTO(campaignViewDTO).dbCampaignViewDTO(dbCampaignViewDTO).build());

        campaignInquiryLockInitForUpdateCampaignAbility.handle(serviceContext,CampaignInquiryLockAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignInquiryLockViewDTO())
                .campaignViewDTO(campaignViewDTO).dbCampaignViewDTO(dbCampaignViewDTO).build());

        campaignAdzoneInitForUpdateCampaignAbility.handle(serviceContext,CampaignAdzoneAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignTargetScenarioViewDTO())
                .dbCampaignViewDTO(dbCampaignViewDTO).build());

        campaignMonitorInitForUpdateCampaignAbility.handle(serviceContext, CampaignMonitorAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignMonitorViewDTO())
                .dbCampaignViewDTO(dbCampaignViewDTO).build());

        campaignSelfServiceInitForUpdateCampaignAbility.handle(serviceContext,CampaignSelfServiceAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignSelfServiceViewDTO())
                .dbCampaignViewDTO(dbCampaignViewDTO).build());

        campaignExtInitForUpdateCampaignAbility.handle(serviceContext, CampaignExtAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignExtViewDTO())
                .dbCampaignViewDTO(dbCampaignViewDTO).build());
    }

    @Override
    public Void afterAddCampaign(ServiceContext serviceContext, CampaignViewDTO campaignTreeViewDTO, BizCampaignWorkflowParam bizCampaignWorkflowParam) {
        //主补联合控量初始化
        campaignUnionControlFlowInitForAddCampaignAbility.handle(serviceContext,
                CampaignUnionControlFlowAbilityParam.builder().abilityTarget(campaignTreeViewDTO).build());
        //更新计划
        List<CampaignViewDTO> updatePartCampaignList = BizCampaignToolsHelper.flatCampaignList(campaignTreeViewDTO).stream().map(campaignViewDTO -> {
            CampaignViewDTO newCampaignViewDTO = new CampaignViewDTO();
            newCampaignViewDTO.setId(campaignViewDTO.getId());
            newCampaignViewDTO.setCampaignGuaranteeViewDTO(campaignViewDTO.getCampaignGuaranteeViewDTO());
            newCampaignViewDTO.setCampaignBoostViewDTO(campaignViewDTO.getCampaignBoostViewDTO());
            newCampaignViewDTO.setCampaignSmartReservedViewDTO(campaignViewDTO.getCampaignSmartReservedViewDTO());
            return newCampaignViewDTO;
        }).collect(Collectors.toList());
        campaignUpdatePartAbility.handle(serviceContext,CampaignBatchAbilityParam.builder().abilityTargets(updatePartCampaignList).build());

        reAssignBudgetAndInquiry(serviceContext, Lists.newArrayList(campaignTreeViewDTO), bizCampaignWorkflowParam);

        DomainMetaqMessageBodyContext msgBodyContext = DomainMetaqMessageBodyContext.builder()
                .bizCode(serviceContext.getBizCode())
                .domainType(DomainMessageTypeEnum.MAIN_CAMPAIGN)
                .domainEvent(CampaignEventEnum.CREATE.name())
                .entityId(campaignTreeViewDTO.getId())
                .memberId(serviceContext.getMemberId())
                .build();
        messageAsyncSendAbility.handle(serviceContext, MessageAsyncSendAbilityParam.builder().abilityTarget(msgBodyContext).build());

        return null;
    }

    @NotNull
    private CampaignViewDTO reAssignBudgetAndInquiry(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList, BizCampaignWorkflowParam bizCampaignWorkflowParam) {
        CampaignViewDTO campaignViewDTO = campaignViewDTOList.stream().filter(item->BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode().equals(item.getCampaignLevel())).findAny().get();
        CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder().onlineStatusList(Lists.newArrayList(BrandCampaignOnlineStatusEnum.DRAFT.getCode())).campaignIds(Lists.newArrayList(campaignViewDTO.getId())).build();
        CampaignQueryOption queryOption = CampaignQueryOption.builder().needTarget(true).needFrequency(true).needChildren(true).build();
        CampaignViewDTO campaignTree = campaignStructureQueryAbility.handle(serviceContext, CampaignStructureQueryAbilityParam.builder().abilityTarget(campaignQueryViewDTO).queryOption(queryOption).build()).get(0);
        campaignTree.getCampaignSelfServiceViewDTO().setCustomScheduleViewDTOList(campaignViewDTO.getCampaignSelfServiceViewDTO().getCustomScheduleViewDTOList());
//        CampaignPriceViewDTO resetCampaignPriceViewDTO = initCampaignPriceViewDTO(campaignTree, bizCampaignWorkflowParam.getPackageProductViewDTO());
        CampaignPriceViewDTO resetCampaignPriceViewDTO = campaignPriceInitForAssignBudgetAbility.handle(serviceContext,CampaignPriceInitForAssignBudgetParam.builder()
                .abilityTarget(campaignTree).resourcePackageProductViewDTO(bizCampaignWorkflowParam.getPackageProductViewDTO()).build());


        //重新分配二级计划金额
        assignSubCampaignBudget(serviceContext, campaignTree, null, resetCampaignPriceViewDTO);
        List<CampaignViewDTO> updateList = Lists.newArrayList(campaignTree);
        updateList.addAll(campaignTree.getSubCampaignViewDTOList());
        for(CampaignViewDTO update : updateList){
            update.getCampaignInquiryLockViewDTO().setCampaignInquiryViewDTOList(Lists.newArrayList());
            campaignRepository.updateCampaignInquiryAll(serviceContext,update.getId(),Lists.newArrayList());
        }
        campaignUpdatePartAbility.handle(serviceContext,CampaignBatchAbilityParam.builder().abilityTargets(updateList).build());

        return campaignTree;
    }


    @Override
    public Void afterUpdateCampaign(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, CampaignViewDTO dbCampaignViewDTO, BizCampaignWorkflowParam bizCampaignWorkflowParam) {
        if(checkCampaignConsistency(serviceContext,bizCampaignWorkflowParam.getPackageProductViewDTO(),campaignViewDTO,dbCampaignViewDTO)){
            return null;
        }
        if(Objects.nonNull(campaignViewDTO.getCampaignGroupId())){
            reAssignBudgetAndNoticeLock(serviceContext, campaignViewDTO, bizCampaignWorkflowParam);
        }else{
            reAssignBudgetAndInquiry(serviceContext,Lists.newArrayList(campaignViewDTO),bizCampaignWorkflowParam);
        }
        // 计划更新消息
        DomainMetaqMessageBodyContext msgBodyContext = DomainMetaqMessageBodyContext.builder()
                .bizCode(serviceContext.getBizCode())
                .domainType(DomainMessageTypeEnum.MAIN_CAMPAIGN)
                .domainEvent(CampaignEventEnum.UPDATE.name())
                .entityId(campaignViewDTO.getId())
                .memberId(serviceContext.getMemberId())
                .build();
        messageAsyncSendAbility.handle(serviceContext, MessageAsyncSendAbilityParam.builder().abilityTarget(msgBodyContext).build());
        return null;
    }

    /**
     * 校验计划数据一致性
     * @param serviceContext
     * @param packageProductViewDTO
     * @param campaignViewDTO
     * @param dbCampaignViewDTO
     * @return true:一致，false:不一致
     */
    private boolean checkCampaignConsistency(ServiceContext serviceContext,com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO packageProductViewDTO,
                                             CampaignViewDTO campaignViewDTO, CampaignViewDTO dbCampaignViewDTO) {
        CampaignConsistencyCheckAbilityParam checkAbilityParam = CampaignConsistencyCheckAbilityParam.builder()
                .abilityTarget(campaignViewDTO).dbCampaignViewDTO(dbCampaignViewDTO).packageProductViewDTO(packageProductViewDTO).build();
        RuleCheckResultViewDTO priceCheckResultViewDTO = campaignPriceConsistencyCheckAbility.handle(serviceContext, checkAbilityParam);
        if(priceCheckResultViewDTO != null && BrandBoolEnum.BRAND_FALSE.getCode().equals(priceCheckResultViewDTO.getIsPass())){
            return false;
        }
        RuleCheckResultViewDTO castDateCheckResultViewDTO = campaignCastDateConsistencyCheckAbility.handle(serviceContext, checkAbilityParam);
        if(castDateCheckResultViewDTO != null && BrandBoolEnum.BRAND_FALSE.getCode().equals(castDateCheckResultViewDTO.getIsPass())){
            return false;
        }
        RuleCheckResultViewDTO budgetCheckResultViewDTO = campaignBudgetConsistencyCheckAbility.handle(serviceContext, checkAbilityParam);
        if(budgetCheckResultViewDTO != null && BrandBoolEnum.BRAND_FALSE.getCode().equals(budgetCheckResultViewDTO.getIsPass())){
            return false;
        }
        RuleCheckResultViewDTO crowdCheckResultViewDTO = campaignCrowdConsistencyCheckAbility.handle(serviceContext, checkAbilityParam);
        if(crowdCheckResultViewDTO != null && BrandBoolEnum.BRAND_FALSE.getCode().equals(crowdCheckResultViewDTO.getIsPass())){
            return false;
        }
        return true;
    }

    private void reAssignBudgetAndNoticeLock(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, BizCampaignWorkflowParam bizCampaignWorkflowParam) {

        CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder().campaignIds(Lists.newArrayList(campaignViewDTO.getId())).build();
        CampaignQueryOption queryOption = CampaignQueryOption.builder().needTarget(true).needFrequency(true).needCampaignTree(true).build();
        CampaignViewDTO campaignTree = campaignStructureQueryAbility.handle(serviceContext,CampaignStructureQueryAbilityParam.builder().abilityTarget(campaignQueryViewDTO).queryOption(queryOption).build()).get(0);

        campaignTree.setStatus(BrandCampaignStatusEnum.NEW.getCode());
        for(CampaignViewDTO update : campaignTree.getSubCampaignViewDTOList()){
            update.setStatus(BrandCampaignStatusEnum.NEW.getCode());
        }
        campaignTree.getCampaignSelfServiceViewDTO().setCustomScheduleViewDTOList(campaignViewDTO.getCampaignSelfServiceViewDTO().getCustomScheduleViewDTOList());
//        CampaignPriceViewDTO resetCampaignPriceViewDTO = initCampaignPriceViewDTO(campaignTree, bizCampaignWorkflowParam.getPackageProductViewDTO());
        CampaignPriceViewDTO resetCampaignPriceViewDTO = campaignPriceInitForAssignBudgetAbility.handle(serviceContext,CampaignPriceInitForAssignBudgetParam.builder()
                .abilityTarget(campaignTree).resourcePackageProductViewDTO(bizCampaignWorkflowParam.getPackageProductViewDTO()).build());
        //重新分配二级计划金额
        assignSubCampaignBudget(serviceContext, campaignTree, null, resetCampaignPriceViewDTO);


        List<CampaignViewDTO> updateList = Lists.newArrayList();
        updateList.add(campaignTree);
        updateList.addAll(campaignTree.getSubCampaignViewDTOList());
        for(CampaignViewDTO update : updateList){
            update.getCampaignInquiryLockViewDTO().setCampaignInquiryViewDTOList(Lists.newArrayList());
            campaignRepository.updateCampaignInquiryAll(serviceContext,update.getId(),Lists.newArrayList());
        }
        campaignUpdatePartAbility.handle(serviceContext,CampaignBatchAbilityParam.builder().abilityTargets(updateList).build());

    }

    @Override
    public Void throwingAddCampaign(ServiceContext serviceContext, List<Long> campaignIdList) {
        if(CollectionUtils.isNotEmpty(campaignIdList)){
            List<CampaignViewDTO> deleteCampaignList = campaignIdList.stream().map(id -> {
                CampaignViewDTO campaignViewDTO = new CampaignViewDTO();
                campaignViewDTO.setId(id);
                campaignViewDTO.setStatus(BrandCampaignStatusEnum.DELETE.getCode());
                return campaignViewDTO;
            }).collect(Collectors.toList());
            campaignUpdatePartAbility.handle(serviceContext,CampaignBatchAbilityParam.builder().abilityTargets(deleteCampaignList).build());
        }
        return null;
    }

    @Override
    public Void beforeForDelete(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {
        campaignPermissionDeleteValidateAbility.handle(serviceContext,
                CampaignDeleteValidateAbilityParam.builder().abilityTarget(campaignViewDTO).build());
        campaignStatusDeleteValidateAbility.handle(serviceContext,
                CampaignDeleteValidateAbilityParam.builder().abilityTarget(campaignViewDTO).build());
        campaignInquiryLockDeleteValidateAbility.handle(serviceContext,
                CampaignDeleteValidateAbilityParam.builder().abilityTarget(campaignViewDTO).build());
        return null;
    }

    @Override
    public Void beforeBatchDeleteCampaign(ServiceContext serviceContext, CampaignBatchDeleteViewDTO batchDeleteViewDTO) {
        StringBuilder errorMessageBuilder = new StringBuilder();
        List<CampaignViewDTO> illegalCampaignViewDTOList = Lists.newArrayList();
        // 遍历校验
        for(CampaignViewDTO campaignViewDTO : batchDeleteViewDTO.getDeleteCampaignViewDTOList()) {
            try {
                campaignStatusDeleteValidateAbility.handle(serviceContext,
                        CampaignDeleteValidateAbilityParam.builder().abilityTarget(campaignViewDTO).build());
                campaignInquiryLockDeleteValidateAbility.handle(serviceContext,
                        CampaignDeleteValidateAbilityParam.builder().abilityTarget(campaignViewDTO).build());
            } catch (BrandOneBPException e) {
                illegalCampaignViewDTOList.add(campaignViewDTO);
                errorMessageBuilder.append(campaignViewDTO.getId());
                errorMessageBuilder.append(": ");
                errorMessageBuilder.append(e.getMessage());
            }
        }
        // 全部计划不符合要求
        AssertUtil.assertTrue(illegalCampaignViewDTOList.size() != batchDeleteViewDTO.getDeleteCampaignViewDTOList().size(),
            BrandOneBPCustomErrorCode.BIZ_UN_SUPPORT_INQUIRY_ALL_ERROR_ERROR, errorMessageBuilder.toString());
        // 如果不是二次确认即第一次请求需要以errCode形式返回校验信息
        if (BrandBoolEnum.BRAND_FALSE.getCode().equals(batchDeleteViewDTO.getConfirm())) {
            // 全部计划符合要求
            AssertUtil.assertTrue(CollectionUtils.isNotEmpty(illegalCampaignViewDTOList), BrandOneBPCustomErrorCode.BIZ_UN_SUPPORT_INQUIRY_DEFAULT_ERROR_ERROR, "确认是否删除已勾选计划");
        }
        if(CollectionUtils.isNotEmpty(illegalCampaignViewDTOList)) {
            // 部分计划不符合要求
            throw new BrandOneBPException(BrandOneBPCustomErrorCode.BIZ_UN_SUPPORT_INQUIRY_PART_ERROR_ERROR, errorMessageBuilder.toString());
        }
        return null;
    }

    @Override
    public Void afterBatchDeleteCampaign(ServiceContext serviceContext, List<CampaignViewDTO> delCampaignViewDTOList) {
        for(CampaignViewDTO campaignViewDTO : delCampaignViewDTOList){
            Map<String, String> properties = Maps.newHashMap();
            properties.put(BrandCampaignSettingKeyEnum.STATUS.getKey(), String.valueOf(campaignViewDTO.getStatus()));
            if (campaignViewDTO.getCampaignGroupId() != null && campaignViewDTO.getCampaignGroupId() != 0L) {
                properties.put(BrandCampaignSettingKeyEnum.CAMPAIGN_GROUP_ID.getKey(), String.valueOf(campaignViewDTO.getCampaignGroupId()));
            }
            DomainMetaqMessageBodyContext msgBodyContext = DomainMetaqMessageBodyContext.builder()
                    .bizCode(serviceContext.getBizCode())
                    .domainType(DomainMessageTypeEnum.MAIN_CAMPAIGN)
                    .domainEvent(CampaignEventEnum.DELETE.name())
                    .entityId(campaignViewDTO.getId())
                    .memberId(campaignViewDTO.getMemberId())
                    .properties(properties)
                    .build();
            messageAsyncSendAbility.handle(serviceContext, MessageAsyncSendAbilityParam.builder().abilityTarget(msgBodyContext).build());
        }
       return null;
    }

    @Override
    public BizCampaignBudgetWorkflowParam buildParamForAssignBudget(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {
        AssertUtil.notNull(campaignViewDTO,"计划不允许为空");
        Long campaignGroupId = campaignViewDTO.getCampaignGroupId();
        Long packageSaleGroupId = Optional.ofNullable(campaignViewDTO.getCampaignSaleViewDTO()).map(CampaignSaleViewDTO::getSaleGroupId).orElse(null);
        AssertUtil.notNull(campaignGroupId,"订单ID不允许为空");
        AssertUtil.notNull(packageSaleGroupId,"售卖分组ID不允许为空");

        // 业务数据获取
        ResourcePackageQueryOption packageQueryOption = ResourcePackageQueryOption.builder().needProduct(true).needSetting(true).build();
        ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO = resourcePackageRepository.getSaleGroupById(serviceContext, packageSaleGroupId, packageQueryOption);
        AssertUtil.notNull(packageSaleGroupViewDTO,"资源包售卖分组不存在");

        SaleGroupInfoViewDTO saleGroupInfoViewDTO = campaignGroupRepository.getSaleGroup(serviceContext,campaignGroupId, packageSaleGroupId);
        AssertUtil.notNull(saleGroupInfoViewDTO, "订单售卖分组不存在");

        BizCampaignBudgetWorkflowParam budgetWorkflowParam = new BizCampaignBudgetWorkflowParam();
        budgetWorkflowParam.setPackageSaleGroupViewDTO(packageSaleGroupViewDTO);
        budgetWorkflowParam.setSaleGroupInfoViewDTO(saleGroupInfoViewDTO);

        return budgetWorkflowParam;
    }

    private Void assignSubCampaignBudget(ServiceContext serviceContext, CampaignViewDTO campaignTree,
                                        CampaignGroupViewDTO campaignGroupViewDTO, CampaignPriceViewDTO campaignPriceViewDTO) {
        CampaignPVAssignSceneEnum campaignPVAssignSceneEnum = BizCampaignToolsHelper.getCampaignPVAssignSceneEnum(campaignTree.getCampaignSaleViewDTO().getSaleProductLine());
        campaignTree.getCampaignBudgetViewDTO().setIsCustomResetBudget(BrandBoolEnum.BRAND_FALSE.getCode());
        campaignTree.getSubCampaignViewDTOList().forEach(item->item.getCampaignBudgetViewDTO().setIsCustomResetBudget(BrandBoolEnum.BRAND_FALSE.getCode()));

        //客户自定义预分配预算：查询价格中心获取计划刊例价，ssp拿到加收后的刊例价 / 资源包给的刊例价×资源包给的净价
        AssertUtil.assertTrue(campaignPriceViewDTO.getDiscountTotalMoney() != null && campaignPriceViewDTO.getDiscountTotalMoney() >0,
                campaignPriceViewDTO.getCampaignId()+"计算后计划价格为0");

        RogerLogger.info("assignSubCampaignBudget.campaignTree:{}, campaignPriceViewDTO:{}", JSON.toJSONString(campaignTree), JSON.toJSONString(campaignPriceViewDTO));
        runAbilitySpi(BizCampaignSplitSpi.class,
                extension -> extension.assignSubCampaignBudget(serviceContext, campaignGroupViewDTO, campaignPriceViewDTO, campaignTree, campaignPVAssignSceneEnum),
                BizCampaignSplitSpi.getSplitSpiCode(campaignTree, campaignPriceViewDTO));
        return null;
    }


    @Override
    public Void rebuildCalSaleGroupInfo(ServiceContext serviceContext, ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO,SaleGroupInfoViewDTO saleGroupInfoViewDTO,List<CampaignViewDTO> campaignViewDTOList) {
        //计算分组PV和单价
        Long pv = saleGroupPvAssignForCalculateAbility.handle(serviceContext, ResourcePackageSaleGroupCalculateAbilityParam.builder().abilityTarget(packageSaleGroupViewDTO).campaignTreeList(campaignViewDTOList).build());
        Long calcBudget = campaignViewDTOList.stream().mapToLong(item->item.getCampaignBudgetViewDTO().getDiscountTotalMoney()).sum();
        Long pvPrice = BigDecimal.valueOf(calcBudget).multiply(BigDecimal.valueOf(Constant.DEFAULT_CPM_PV_RATIO)).divide(BigDecimal.valueOf(pv), 0, RoundingMode.HALF_UP).longValue();
        saleGroupInfoViewDTO.setUnitPrice(pvPrice);
        saleGroupInfoViewDTO.setAmount(pv);
        saleGroupInfoViewDTO.setCalcBudget(calcBudget);
        return null;
    }

    @Override
    public Void afterForUpdateCastDate(ServiceContext serviceContext, CampaignViewDTO dbCampaignViewDTO,
                                       CampaignViewDTO campaignViewDTO) {

        DomainMetaqMessageBodyContext msgBodyContext = DomainMetaqMessageBodyContext.builder()
            .bizCode(serviceContext.getBizCode())
            .domainType(DomainMessageTypeEnum.MAIN_CAMPAIGN)
            .domainEvent(CampaignEventEnum.UPDATE.name())
            .entityId(dbCampaignViewDTO.getId())
            .memberId(serviceContext.getMemberId())
            .build();
        messageAsyncSendAbility.handle(serviceContext, MessageAsyncSendAbilityParam.builder().abilityTarget(msgBodyContext).build());
        return null;
    }
}