package com.taobao.ad.brand.bp.domain.creative.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.brand.dto.creative.element.ElementViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativeElementTypeEnum;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohCampaignViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohCreativeMaterialViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.dooh.repository.DoohRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.ICreativeRefDoohCreativeValidateAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeRefDoohCreativeValidateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSelfCreativeRefDoohCreativeValidateAbility implements ICreativeRefDoohCreativeValidateAbility, BrandSelfServiceAtomAbilityRouter {

    private final DoohRepository doohRepository;
    @Override
    public Void handle(ServiceContext serviceContext, CreativeRefDoohCreativeValidateAbilityParam abilityParam) {
        List<CreativeViewDTO> creativeViewDTOList = abilityParam.getAbilityTargets();
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        if(CollectionUtils.isEmpty(creativeViewDTOList)){
            return null;
        }
        RogerLogger.info("creativeViewDTOList:{}", JSON.toJSONString(creativeViewDTOList));
        if(BizCampaignToolsHelper.isDoohCampaign(campaignViewDTO.getCampaignResourceViewDTO().getSspProductLineId())){
            //1. 天攻单元只能绑定一个创意
            AssertUtil.assertTrue(creativeViewDTOList.size() == 1, "天攻仅允许绑定一个创意");
            //2. 订单下单后才能绑定创意
            List<Integer> campaignGroupStatusList = Lists.newArrayList(BrandCampaignGroupStatusEnum.ORDER_ING.getCode(), BrandCampaignGroupStatusEnum.RESOURCE_CONFIRM_ING.getCode(), BrandCampaignGroupStatusEnum.CONTRACT_PROCESS_ING.getCode(), BrandCampaignGroupStatusEnum.WAIT_CAST.getCode(), BrandCampaignGroupStatusEnum.CAST_ING.getCode(), BrandCampaignGroupStatusEnum.UNLOCKED.getCode());
            AssertUtil.assertTrue(campaignGroupStatusList.contains(campaignGroupViewDTO.getStatus()), "订单未下单或已完成推广，不允许绑定创意");
            //3. 创意mr必须满足天攻的要求
            DoohCampaignViewDTO doohCampaignViewDTO = doohRepository.getCampaignById(campaignViewDTO.getCampaignDoohViewDTO().getDoohCampaignId());
            AssertUtil.assertTrue(doohCampaignViewDTO != null, "天攻计划不存在");
            List<DoohCreativeMaterialViewDTO> materials = doohCampaignViewDTO.getMaterials();
            if(CollectionUtils.isEmpty(materials)){
                return null;
            }
            //如果天攻返回了创意要求的具体格式，需要保证绑定的创意符合要求
            Map<String, Boolean> doohMrMap = buildDoohMrMap(materials);
            for(CreativeViewDTO creativeViewDTO : creativeViewDTOList){
                Map<String, Boolean> currMrMap = doohMrMap;
                List<ElementViewDTO> elementViewDTOS = creativeViewDTO.getElementList();
                for(ElementViewDTO elementViewDTO:elementViewDTOS){
                    if(!(BrandCreativeElementTypeEnum.IMAGE.getCode().equals(elementViewDTO.getElementType()) || BrandCreativeElementTypeEnum.VIDEO.getCode().equals(elementViewDTO.getElementType()))){
                        continue;
                    }
                    String key = getMrKey(elementViewDTO.getWidth(), elementViewDTO.getHeight());
                    if(currMrMap.containsKey(key)){
                        currMrMap.put(key, true);
                    }else{
                        throw new BrandOneBPException("创意素材不满足要求，请更换后重试");
                    }
                }
                List<Boolean> mrResultList = currMrMap.values().stream().collect(Collectors.toList());
                if(mrResultList.contains(false)){
                    throw new BrandOneBPException("创意素材部分缺失，请更换后重试");
                }
            }
        }
        return  null;
    }
    private Map<String, Boolean> buildDoohMrMap(List<DoohCreativeMaterialViewDTO> materials){
        Map<String, Boolean> doohMrMap = Maps.newHashMap();
        for(DoohCreativeMaterialViewDTO mrViewDTO:materials){
            String mrKey = getMrKey(String.valueOf(mrViewDTO.getWidth()), String.valueOf(mrViewDTO.getHeight()));
            doohMrMap.put(mrKey, false);
        }
        return doohMrMap;
    }


    private String getMrKey(String width, String height){
        StringBuilder str = new StringBuilder();
        str.append(width).append("_")
                .append(height);
        RogerLogger.info("getMrKey:{}", str.toString());
        return str.toString();
    }
}
