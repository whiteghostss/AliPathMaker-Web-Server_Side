package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.process.ProcessRecordViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.unlock.CampaignGroupUnlockViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.unlock.UnlockApplyInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupProcessStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupProcessTypeEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupUnlockUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupUnlockAbilityParam;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Component
@BusinessAbility
public class DefaultCampaignGroupUnlockUpdateAbility implements ICampaignGroupUnlockUpdateAbility {
    @Resource
    private CampaignGroupRepository campaignGroupRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupUnlockAbilityParam abilityParam) {
        CampaignGroupUnlockViewDTO campaignGroupUnlockViewDTO = abilityParam.getAbilityTarget();
        if (campaignGroupUnlockViewDTO == null || campaignGroupUnlockViewDTO.getUnlockApplyInfoViewDTO() == null) {
            return null;
        }
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        BrandCampaignGroupProcessStatusEnum processStatusEnum = abilityParam.getProcessStatusEnum();

        // 设置审核结果
        UnlockApplyInfoViewDTO unlockApplyInfoViewDTO = campaignGroupUnlockViewDTO.getUnlockApplyInfoViewDTO();
        if (processStatusEnum != null) {
            unlockApplyInfoViewDTO.setStatus(processStatusEnum.getCode());
            if (BizCampaignGroupToolsHelper.isFinish(processStatusEnum.getCode())) {
                unlockApplyInfoViewDTO.setFinishTime(new Date());
            }
        }
        // 执行更新
        CampaignGroupViewDTO updateCampaignGroupViewDTO = new CampaignGroupViewDTO();
        updateCampaignGroupViewDTO.setId(campaignGroupViewDTO.getId());
        updateCampaignGroupViewDTO.setCampaignGroupUnlockViewDTO(campaignGroupViewDTO.getCampaignGroupUnlockViewDTO());
        updateCampaignGroupViewDTO.setProcessRecordViewDTOList(campaignGroupViewDTO.getProcessRecordViewDTOList());
        campaignGroupRepository.updateCampaignGroupPart(serviceContext, updateCampaignGroupViewDTO);

        return null;
    }

    /**
     * 备份申请流程记录
     * @param unlockApplyInfoViewDTO
     * @param campaignGroupViewDTO
     */
    private void backupFinishedProcessRecord(UnlockApplyInfoViewDTO unlockApplyInfoViewDTO, CampaignGroupViewDTO campaignGroupViewDTO) {
        if (unlockApplyInfoViewDTO == null || !BizCampaignGroupToolsHelper.isFinish(unlockApplyInfoViewDTO.getStatus())) {
            return;
        }
        ProcessRecordViewDTO processRecordViewDTO = buildProcessRecordViewDTO(unlockApplyInfoViewDTO);
        List<ProcessRecordViewDTO> processRecordViewDTOList = Optional.ofNullable(campaignGroupViewDTO.getProcessRecordViewDTOList()).orElse(Lists.newArrayList());
        processRecordViewDTOList.add(processRecordViewDTO);

        campaignGroupViewDTO.setProcessRecordViewDTOList(processRecordViewDTOList);
    }
    private ProcessRecordViewDTO buildProcessRecordViewDTO(UnlockApplyInfoViewDTO unlockApplyInfoViewDTO) {
        ProcessRecordViewDTO recordViewDTO = new ProcessRecordViewDTO();
        recordViewDTO.setStatus(unlockApplyInfoViewDTO.getStatus());
        recordViewDTO.setApplyTime(unlockApplyInfoViewDTO.getApplyTime());
        recordViewDTO.setFinishTime(unlockApplyInfoViewDTO.getFinishTime());
        recordViewDTO.setProcInstId(unlockApplyInfoViewDTO.getProcInstId());
        recordViewDTO.setApplyContent(StringUtils.join(unlockApplyInfoViewDTO.getSaleGroupIds(), ","));
        recordViewDTO.setType(BrandCampaignGroupProcessTypeEnum.UNLOCK.getCode());
        return recordViewDTO;
    }
}
