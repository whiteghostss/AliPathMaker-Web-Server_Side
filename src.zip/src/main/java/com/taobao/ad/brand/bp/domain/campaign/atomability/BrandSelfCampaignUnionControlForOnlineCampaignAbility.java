package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.boost.CampaignBoostViewDTO;
import com.alibaba.ad.brand.dto.campaign.boost.InquiryInfoViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryLockViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.DayAmountViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandInquiryStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.alibaba.fastjson.JSONObject;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignUnionControlForOnlineCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignForOnlineAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSelfCampaignUnionControlForOnlineCampaignAbility implements ICampaignUnionControlForOnlineCampaignAbility, BrandSelfServiceAtomAbilityRouter {

    private final CampaignRepository campaignRepository;

    @Override
    public List<CampaignViewDTO> handle(ServiceContext serviceContext, CampaignForOnlineAbilityParam abilityParam) {
        List<CampaignViewDTO> parentCampaignViewDTOList = abilityParam.getAbilityTargets();
        CampaignQueryViewDTO querySub = CampaignQueryViewDTO.builder().budgetCampaignIds(parentCampaignViewDTOList.stream().map(it -> it.getId()).collect(Collectors.toList()))
                .campaignLevel(BrandCampaignLevelEnum.LEVEL_TWO_CAMPAIGN.getCode())
                .saleTypes(Lists.newArrayList(BrandSaleTypeEnum.BOOST.getCode()))
                .build();
        List<CampaignViewDTO> subList = campaignRepository.queryCampaignList(serviceContext, querySub);
        if (CollectionUtils.isEmpty(subList)) {
            RogerLogger.info("cant find resetSubUnionControlInfo  {}", JSONObject.toJSONString(parentCampaignViewDTOList.stream().map(it -> it.getId()).collect(Collectors.toList())));
            return Lists.newArrayList();
        }
        List<CampaignViewDTO> updateCampaignViewDTOList = Lists.newArrayList();
        for (CampaignViewDTO campaignViewDTO : parentCampaignViewDTOList) {
            List<InquiryInfoViewDTO> unionInquiryList = Lists.newArrayList();

            for (CampaignViewDTO subCampaignViewDTO : subList) {
                if (!campaignViewDTO.getId().equals(subCampaignViewDTO.getCampaignGuaranteeViewDTO().getBudgetCampaignId())) {
                    continue;
                }
                if (CollectionUtils.isEmpty(subCampaignViewDTO.getCampaignInquiryLockViewDTO().getCampaignInquiryViewDTOList())) {
                    continue;
                }
                List<CampaignInquiryViewDTO> campaignInquiryViewDTOList = Optional.ofNullable(subCampaignViewDTO.getCampaignInquiryLockViewDTO())
                        .map(CampaignInquiryLockViewDTO::getCampaignInquiryViewDTOList).orElse(Lists.newArrayList());
                if (CollectionUtils.isEmpty(campaignInquiryViewDTOList)) {
                    continue;
                }
                InquiryInfoViewDTO inquiryInfoViewDTO = new InquiryInfoViewDTO();
                inquiryInfoViewDTO.setCampaignId(subCampaignViewDTO.getId());
                List<DayAmountViewDTO> dayAmountViewDTOS = Lists.newArrayList();
                for (CampaignInquiryViewDTO campaignInquiryViewDTO : campaignInquiryViewDTOList) {
                    if (BrandInquiryStatusEnum.SUCCESS.getCode().equals(campaignInquiryViewDTO.getStatus())) {
                        DayAmountViewDTO dayAmountViewDTO = new DayAmountViewDTO();
                        dayAmountViewDTO.setDay(campaignInquiryViewDTO.getDate());
                        dayAmountViewDTO.setAmount(campaignInquiryViewDTO.getBookAmount());
                        dayAmountViewDTOS.add(dayAmountViewDTO);
                    }
                }
                inquiryInfoViewDTO.setInquiryInfoList(dayAmountViewDTOS);
                if (CollectionUtils.isNotEmpty(dayAmountViewDTOS)) {
                    unionInquiryList.add(inquiryInfoViewDTO);
                }
            }

            CampaignBoostViewDTO campaignBoostViewDTO = campaignViewDTO.getCampaignBoostViewDTO();
            campaignBoostViewDTO.setUnionInquiryInfoList(unionInquiryList);
            CampaignViewDTO updateCampaignViewDTO = new CampaignViewDTO();
            updateCampaignViewDTO.setId(campaignViewDTO.getId());
            updateCampaignViewDTO.setCampaignBoostViewDTO(campaignBoostViewDTO);
            updateCampaignViewDTOList.add(updateCampaignViewDTO);
        }
        return updateCampaignViewDTOList;
    }
}
