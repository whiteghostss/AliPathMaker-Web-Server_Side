package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesContractBrandViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.CrowdViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaign.RecommendCrowdTypeEnum;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.SalesContractRepository;
import com.taobao.ad.brand.bp.domain.dmp.CrowdRepository;
import com.taobao.ad.brand.bp.domain.feed.FeedRepository;
import com.taobao.ad.brand.bp.domain.memeber.MemberRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignShowmaxCrowdTagGetAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignShowmaxCrowdTagGetAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultCampaignShowmaxCrowdTagGetAbility implements ICampaignShowmaxCrowdTagGetAbility {

    private final CampaignGroupRepository campaignGroupRepository;
    private final FeedRepository feedRepository;
    private final SalesContractRepository salesContractRepository;
    private final MemberRepository memberRepository;
    private final CrowdRepository crowdRepository;

    @Override
    public List<CommonViewDTO> handle(ServiceContext serviceContext, CampaignShowmaxCrowdTagGetAbilityParam abilityParam) {
        Integer showmaxCrowdType = abilityParam.getAbilityTarget();
        Long customerMemberId = abilityParam.getCustomerMemberId();
        // 客户memberId
        if (customerMemberId == null) {
            customerMemberId = getCustomerMemberId(serviceContext, abilityParam.getCampaignGroupId());
        }
        // 查询标签
        if (RecommendCrowdTypeEnum.needLabelForQueryTemplateCrowd(showmaxCrowdType)) {
            return crowdRepository.queryShowmaxCrowdTagList(serviceContext, customerMemberId, showmaxCrowdType);
        }
        // 查询人群
        List<Long> brandIds = getShowmaxBrandIds(customerMemberId,showmaxCrowdType);
        List<CrowdViewDTO> crowdViewDTOList = crowdRepository.findRecommendCrowd(serviceContext, customerMemberId, showmaxCrowdType, null, StringUtils.join(brandIds, ","));
        return crowdViewDTOList.stream().map(crowdViewDTO -> {
            CommonViewDTO commonViewDTO = new CommonViewDTO();
            commonViewDTO.setId(crowdViewDTO.getCrowdId());
            commonViewDTO.setName(crowdViewDTO.getCrowdName());
            return commonViewDTO;
        }).collect(Collectors.toList());

    }

    private Long getCustomerMemberId(ServiceContext serviceContext, Long campaignGroupId) {
        Long customerMemberId = null;
        if (campaignGroupId != null) {
            CampaignGroupViewDTO campaignGroup = campaignGroupRepository.getCampaignGroup(serviceContext, campaignGroupId);
            customerMemberId = BizCampaignGroupToolsHelper.getCustomerMemberId(campaignGroup);
        }
        if (customerMemberId == null) {
            customerMemberId = memberRepository.getTargetMemberIdByMemberId(serviceContext.getMemberId());
        }

        return customerMemberId;
    }

    private List<Long> getShowmaxBrandIds(Long customerMemberId,Integer showmaxCrowdType) {
        List<Long> brandIds = Lists.newArrayList();
        if (RecommendCrowdTypeEnum.needBrandForQueryTemplateCrowd(showmaxCrowdType)) {
            brandIds = getCustomerMemberBrandIds(customerMemberId);
        }
        return brandIds;
    }

    private List<Long> getCustomerMemberBrandIds(Long customerMemberId) {
        Long shopId = feedRepository.getShopIdByMemberId(customerMemberId);
        List<SalesContractBrandViewDTO> salesContractBrandViewDTOS = salesContractRepository.findBrandList(shopId);
        return salesContractBrandViewDTOS.stream().map(SalesContractBrandViewDTO::getBrandId).distinct().collect(Collectors.toList());
    }
}
