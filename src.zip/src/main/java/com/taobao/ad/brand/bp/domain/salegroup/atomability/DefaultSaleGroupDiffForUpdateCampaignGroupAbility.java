package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleGroupSourceEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.salegroup.SaleGroupDiffResultViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupDiffForUpdateCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupDiffAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
@BusinessAbility
public class DefaultSaleGroupDiffForUpdateCampaignGroupAbility implements ISaleGroupDiffForUpdateCampaignGroupAbility {

    @Override
    public SaleGroupDiffResultViewDTO handle(ServiceContext serviceContext, SaleGroupDiffAbilityParam abilityParam) {
        // 本次的订单分组
        List<SaleGroupInfoViewDTO> currentSaleGroupInfoViewDTOList = abilityParam.getAbilityTargets();
        List<SaleGroupInfoViewDTO> dbSaleGroupInfoViewDTOList = Optional.of(abilityParam.getDbSaleGroupInfoViewDTOList()).orElse(Lists.newArrayList());
        // 返回结果
        SaleGroupDiffResultViewDTO resultViewDTO = new SaleGroupDiffResultViewDTO();
        List<Long> addSaleGroupIds = Lists.newArrayList();
        List<Long> updateSaleGroupIds = Lists.newArrayList();
        List<Long> deleteSaleGroupIds = Lists.newArrayList();

        Map<Long, SaleGroupInfoViewDTO> dbGroupSaleViewMap = dbSaleGroupInfoViewDTOList
                .stream().collect(Collectors.toMap(SaleGroupInfoViewDTO::getSaleGroupId, Function.identity(), (v1, v2) -> v1));
        // 新增 or 更新
        for (SaleGroupInfoViewDTO saleGroupInfoViewDTO : currentSaleGroupInfoViewDTOList) {
            SaleGroupInfoViewDTO dbSaleGroupInfoViewDTO = dbGroupSaleViewMap.get(saleGroupInfoViewDTO.getSaleGroupId());
            if (dbSaleGroupInfoViewDTO == null) {
                addSaleGroupIds.add(saleGroupInfoViewDTO.getSaleGroupId());
            } else {
                updateSaleGroupIds.add(saleGroupInfoViewDTO.getSaleGroupId());
            }
        }
        // 删除
        List<Long> salesSaleGroupIds = currentSaleGroupInfoViewDTOList.stream().map(SaleGroupInfoViewDTO::getSaleGroupId).collect(Collectors.toList());
        for (SaleGroupInfoViewDTO dbSaleGroupInfoViewDTO : dbSaleGroupInfoViewDTOList) {
            // 在上面已经处理过了
            if (salesSaleGroupIds.contains(dbSaleGroupInfoViewDTO.getSaleGroupId())) {
                continue;
            }
            // DB出现了本次不存在的source=1的分组，代表删除
            if (BrandSaleGroupSourceEnum.SALE_PLATFORM.getCode().equals(dbSaleGroupInfoViewDTO.getSource())) {
                deleteSaleGroupIds.add(dbSaleGroupInfoViewDTO.getSaleGroupId());
            }
        }
        // 删除 本次已经删除的主分组下的补量配送分组
        if (CollectionUtils.isNotEmpty(deleteSaleGroupIds)) {
            List<Long> deletePackagePlatformSaleGroupIds = dbSaleGroupInfoViewDTOList.stream()
                    .filter(t -> BrandSaleGroupSourceEnum.PACKAGE_PLATFORM.getCode().equals(t.getSource()))
                    .filter(t -> t.getMainSaleGroupId() != null && deleteSaleGroupIds.contains(t.getMainSaleGroupId()))
                    .map(SaleGroupInfoViewDTO::getSaleGroupId)
                    .collect(Collectors.toList());
            deleteSaleGroupIds.addAll(deletePackagePlatformSaleGroupIds);
        }
        resultViewDTO.setAddSaleGroupIds(addSaleGroupIds);
        resultViewDTO.setUpdateSaleGroupIds(updateSaleGroupIds);
        resultViewDTO.setDeleteSaleGroupIds(deleteSaleGroupIds);

        return resultViewDTO;
    }
}
