package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.budget.CampaignBudgetViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignProductConfigTypeEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleProductLineEnum;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignBudgetValidateForResetCampaignBudgetAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBudgetValidateForResetAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSelfServiceCampaignBudgetValidateForResetCampaignBudgetAbility
    implements ICampaignBudgetValidateForResetCampaignBudgetAbility, BrandSelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignBudgetValidateForResetAbilityParam abilityParam) {
        CampaignBudgetViewDTO campaignBudgetViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO campaignViewDTO = abilityParam.getDbCampaignViewDTO();
        ResourcePackageSaleGroupViewDTO saleGroup = abilityParam.getSaleGroup();
        AssertUtil.notNull(campaignViewDTO, "计划信息不能为空");
        AssertUtil.notNull(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode().equals(campaignViewDTO.getCampaignLevel()), "只允许在一级计划上调整预算");
        AssertUtil.assertTrue(BrandCampaignStatusEnum.NEW.getCode().equals(campaignViewDTO.getStatus())
            ||BrandCampaignStatusEnum.LOCK_FAIL.getCode().equals(campaignViewDTO.getStatus())
            ||BrandCampaignStatusEnum.INQUIRY_FAIL.getCode().equals(campaignViewDTO.getStatus())
            ||BrandCampaignStatusEnum.INQUIRY_SUCCESS.getCode().equals(campaignViewDTO.getStatus()),"计划状态不允许");
        if(CollectionUtils.isNotEmpty(campaignViewDTO.getSubCampaignViewDTOList())){
            for(CampaignViewDTO sub : campaignViewDTO.getSubCampaignViewDTOList()){
                AssertUtil.assertTrue(BrandCampaignStatusEnum.NEW.getCode().equals(sub.getStatus())
                    ||BrandCampaignStatusEnum.LOCK_FAIL.getCode().equals(sub.getStatus())
                    ||BrandCampaignStatusEnum.INQUIRY_FAIL.getCode().equals(sub.getStatus())
                    ||BrandCampaignStatusEnum.INQUIRY_SUCCESS.getCode().equals(sub.getStatus()),"计划状态不允许");
            }
        }
        AssertUtil.assertTrue(BrandCampaignProductConfigTypeEnum.CUSTOM.getCode().equals(saleGroup.getProductConfigType()),"非自定义分组计划不可单独调整金额。");
        // 特秀客户自操要求设置单计划金额必须<=分组金额
        if (!ServiceContextUtil.isAliStaff(serviceContext) && (SaleProductLineEnum.TE_XIU.getValue().equals(saleGroup.getSaleProductLine()) || SaleProductLineEnum.SHOW_MAX.getValue().equals(saleGroup.getSaleProductLine()))) {
            AssertUtil.assertTrue(campaignBudgetViewDTO.getDiscountTotalMoney() <= saleGroup.getBudget(), "单计划金额不能大于其所属分组的金额");
        }
        return null;
    }
}
