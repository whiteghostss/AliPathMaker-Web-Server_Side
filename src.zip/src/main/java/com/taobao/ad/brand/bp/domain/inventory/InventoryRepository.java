package com.taobao.ad.brand.bp.domain.inventory;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alimama.inventory.dto.ud.InventoryUdImprecisionDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignScheduleViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupPurchaseProcessViewDTO;
import com.taobao.ad.brand.bp.client.dto.inventory.InventoryDetailsViewDTO;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/03/08
 */
public interface InventoryRepository {
    /**
     * 询量
     */
    void search(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, CampaignScheduleViewDTO scheduleViewDTO,List<Long> templateIds);

    /**
     * 锁量
     */
    void book(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO,CampaignScheduleViewDTO scheduleViewDTO,List<Long> templateIds);

    /**
     * 释量
     */
    void release(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO);

    /**
     * 取消询锁量
     *
     * @param serviceContext
     * @param campaignViewDTO
     */
    void cancel(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO);

    /**
     * 日更操作，日更结果同步返回
     */
    void dailyUpdate(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, CampaignScheduleViewDTO scheduleViewDTO,List<Long> templateIds);

    /**
     * 媒体询量
     * 询量单ID
     */
    Long mediaInquiry(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList, List<CampaignScheduleViewDTO> campaignScheduleViewDTOList);
    InventoryUdImprecisionDTO getBottomPurchaseOrder(Long subCampaignId);

    /**
     * 采购状态是否完毕
     * @param serviceContext
     * @param campaignViewDTOList
     * @return
     */
    CampaignGroupPurchaseProcessViewDTO needPurchaseOrder(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList);

    /**
     * 发起采购单
     * @param context
     * @param campaignGroupViewDTO
     * @param campaignViewDTOList
     * @return
     */
    CampaignGroupPurchaseProcessViewDTO addPurchaseOrder(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, List<CampaignViewDTO> campaignViewDTOList) ;

    /**
     * 三环库存下单
     * @param serviceContext
     * @param subCampaignViewDTOList
     */
    void confirmOrder(ServiceContext serviceContext, List<CampaignViewDTO> subCampaignViewDTOList);

    /**
     * 查询三环媒体询量有效期
     * @param serviceContext
     * @param subCampaignViewDTOList
     * @return
     */
    Map<String, Date> getInventoryExpireTime(ServiceContext serviceContext, List<CampaignViewDTO> subCampaignViewDTOList);

    /**
     * 查询库存详情
     * @param serviceContext
     * @param subCampaignViewDTOList
     * @return
     */
    List<InventoryDetailsViewDTO> getInventoryDetailsViewDTOList(ServiceContext serviceContext, List<CampaignViewDTO> subCampaignViewDTOList);


    /**
     * 查询库存判断一级计划是否精准投放，二级计划也会填充到结果中
     * @param serviceContext
     * @param campaignModelList 一级计划List
     * @return
     */
    Map<Long, BrandBoolEnum> buildCampaignInventoryDetailsMap(ServiceContext serviceContext, List<CampaignViewDTO> campaignModelList);
    /**
     * 查询库存判断一级计划是否精准投放，二级计划也会填充到结果中
     * @param serviceContext
     * @param campaignViewDTOList 一级计划
     * @return
     */
    Map<Long, BrandBoolEnum> getCampaignNeedBottom(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList);


//    /**
//     * 内容-发起采购单
//     * @param context
//     * @param campaignGroupViewDTO
//     * @param subCampaignViewDTOList
//     * @return
//     */
//    CampaignGroupPurchaseProcessViewDTO addPurchaseOrderContent(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, List<CampaignViewDTO> subCampaignViewDTOList);
//
//    /**
//     * 内容-查询采购单状态
//     *
//     * @param serviceContext
//     * @param campaignGroupViewDTO
//     * @return
//     */
//    CampaignGroupPurchaseProcessViewDTO needPurchaseOrderContent(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO);

}
