package com.taobao.ad.brand.bp.domain.cart.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCustomerOrderTypeEnum;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupCustomerMemberViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupContractMemberTypeEnum;
import com.taobao.ad.brand.bp.client.enums.cart.CartActionEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CustomerRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.SalesContractRepository;
import com.taobao.ad.brand.bp.domain.memeber.MemberRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.ICartItemCustomerJudgeAbility;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.param.CartItemCustomerCheckAbilityParam;
import com.taobao.ad.simba.user.consts.RelMemberType;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCartItemCustomerJudgeAbility implements ICartItemCustomerJudgeAbility, SelfServiceAtomAbilityRouter {

    private final MemberRepository memberRepository;
    private final CustomerRepository customerRepository;
    private final SalesContractRepository salesContractRepository;

    @Override
    public Void handle(ServiceContext context, CartItemCustomerCheckAbilityParam abilityPara) {
        Long memberId = abilityPara.getAbilityTarget();
        // 设置账号类型
        Integer relType = memberRepository.getRelMemberType(memberId);
        Long customerMemberId = memberRepository.getTargetMemberIdByMemberId(memberId, relType);
        Integer customerOrderType = customerRepository.getCustomerType(customerMemberId);
        RogerLogger.info("memberId {} customer类型 {}", customerMemberId, BrandCustomerOrderTypeEnum.getByCode(customerOrderType));
        // 老客下单，记录日志供产运分析
        if(BrandCustomerOrderTypeEnum.OLD_CUSTOMER.getCode().equals(customerOrderType)){
            RogerLogger.info("old customer order memberId {} customer类型 {}", customerMemberId, BrandCustomerOrderTypeEnum.getByCode(customerOrderType));
        }
        AssertUtil.assertTrue(BrandCustomerOrderTypeEnum.NEW_CUSTOMER_FIRST.getCode().equals(customerOrderType),
                BrandOneBPBaseErrorCode.PARAM_BREAK_RULE,
                "本次复购下单阿里妈妈将为您提供专人服务，并享受定制人群包，专人盘量锁量等权益，请联系您的专属小二。");
        if (abilityPara.getActionEnum() != null && abilityPara.getActionEnum() == CartActionEnum.ORDER) {
            CampaignGroupCustomerMemberViewDTO customerMemberViewDTO = new CampaignGroupCustomerMemberViewDTO();
            customerMemberViewDTO.setMemberId(memberId);
            customerMemberViewDTO.setCustomerMemberId(customerMemberId);
            if (Objects.isNull(relType)) {
                customerMemberViewDTO.setMemberType(CampaignGroupContractMemberTypeEnum.CUSTOMER.getCode());
            } else if (RelMemberType.AGENCY.getValue().equals(relType)) {
                customerMemberViewDTO.setMemberType(CampaignGroupContractMemberTypeEnum.XMEMBER.getCode());
            }
            salesContractRepository.checkMemberForSelfContract(context, customerMemberViewDTO);
        }
        return null;
    }
}
