package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.customer.CampaignGroupCustomerViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupCustomerValidateForAddCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupCustomerAbilityParam;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
public class BrandOneBPCampaignGroupCustomerValidateForAddCampaignGroupAbility implements ICampaignGroupCustomerValidateForAddCampaignGroupAbility, BrandOneBPAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupCustomerAbilityParam abilityParam) {
        if (!BizCampaignGroupToolsHelper.isSaleCampaignGroup(abilityParam.getCampaignGroupViewDTO())) {
            return null;
        }
        CampaignGroupCustomerViewDTO customerViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(customerViewDTO, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "客户信息不能为空");
        AssertUtil.assertTrue(customerViewDTO.getCustomerId() != null, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "客户ID不能为空");
        AssertUtil.assertTrue(customerViewDTO.getContractMemberType() != null, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "下单客户类型不能为空");
        AssertUtil.assertTrue(customerViewDTO.getCustomerMemberId() != null, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "客户投放账号不能为空");

        return null;
    }
}
