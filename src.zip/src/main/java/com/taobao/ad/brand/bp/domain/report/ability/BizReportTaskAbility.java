package com.taobao.ad.brand.bp.domain.report.ability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.dmp.CrowdViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportFileViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportTaskViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.query.ReportQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.query.ReportTaskQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.CommonEnum;
import com.taobao.ad.brand.bp.client.enums.report.ReportTaskStatusEnum;
import com.taobao.ad.brand.bp.common.spi.ExtensionPointsFactory;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.dmp.CrowdRepository;
import com.taobao.ad.brand.bp.domain.report.repository.ReportSyncTaskRepository;
import com.taobao.ad.brand.bp.domain.report.spi.task.BizReportTaskSpi;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * 报表数据任务能力定义
 * @author yuncheng.lyc
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizReportTaskAbility {

    @Resource
    private CrowdRepository crowdRepository;
    @Resource
    private ReportSyncTaskRepository reportSyncTaskRepository;

    public void validateReportTask(ServiceContext context, ReportTaskViewDTO taskViewDTO, Boolean modify){
        //对查询进行预处理
        ExtensionPointsFactory.runAbilitySpi(BizReportTaskSpi.class, extension -> extension.initParams(context, taskViewDTO, modify), taskViewDTO.getFunctionCode());
        //校验任务查询数据参数
        ExtensionPointsFactory.runAbilitySpi(BizReportTaskSpi.class, extension -> extension.validateParams(context, taskViewDTO, modify), taskViewDTO.getFunctionCode());
    }

    public void validateReportTaskListQuery(ServiceContext context, ReportTaskQueryViewDTO taskQueryViewDTO){
        AssertUtil.notNull(taskQueryViewDTO, "查询参数不能为空");
        if(Objects.isNull(taskQueryViewDTO.getMemberId())){
            taskQueryViewDTO.setMemberId(context.getMemberId());
        }
        AssertUtil.notNull(taskQueryViewDTO.getMemberId(), "参数中memberId不能为空");
        AssertUtil.assertTrue(StringUtils.isNotBlank(taskQueryViewDTO.getFunctionCode()), "查询参数中任务类型不能为空");
    }

    public void validateReportTaskQuery(ServiceContext context, ReportTaskQueryViewDTO taskQueryViewDTO){
        AssertUtil.notNull(taskQueryViewDTO, "查询参数不能为空");
        AssertUtil.notNull(taskQueryViewDTO.getTaskId(), "查询参数中任务id不能为空");
        ReportTaskQueryViewDTO queryViewDTO = new ReportTaskQueryViewDTO();
        queryViewDTO.setTaskId(taskQueryViewDTO.getTaskId());
        queryViewDTO.setFunctionCode(taskQueryViewDTO.getFunctionCode());

        if(Objects.isNull(taskQueryViewDTO.getMemberId())){
            taskQueryViewDTO.setMemberId(context.getMemberId());
        }
        AssertUtil.notNull(taskQueryViewDTO.getMemberId(), "参数中memberId不能为空");
        AssertUtil.assertTrue(StringUtils.isNotBlank(taskQueryViewDTO.getFunctionCode()), "查询参数中任务类型不能为空");

    }

    public void validateReportTaskQueryForDelete(ServiceContext context, ReportTaskQueryViewDTO taskQueryViewDTO, ReportTaskViewDTO dbTaskViewDTO){
        AssertUtil.notNull(dbTaskViewDTO, "没有找到对应的异步任务信息");
        AssertUtil.notNull(dbTaskViewDTO.getStatus(), "任务状态不能为空");
        ReportTaskStatusEnum statusEnum = CommonEnum.of(dbTaskViewDTO.getStatus(), ReportTaskStatusEnum.class);
        AssertUtil.notNull(statusEnum, "任务状态错误");
        AssertUtil.assertTrue(ReportTaskStatusEnum.RUNNING.getValue() != dbTaskViewDTO.getStatus(), "执行中的任务不能删除");
    }

    public void validateReportTaskQueryForRun(ServiceContext context, ReportTaskQueryViewDTO taskQueryViewDTO, ReportTaskViewDTO dbTaskViewDTO){
        AssertUtil.notNull(dbTaskViewDTO, "没有找到对应的异步任务信息");
        AssertUtil.notNull(dbTaskViewDTO.getStatus(), "任务状态不能为空");
        ReportTaskStatusEnum statusEnum = CommonEnum.of(dbTaskViewDTO.getStatus(), ReportTaskStatusEnum.class);
        AssertUtil.notNull(statusEnum, "任务状态错误");
        AssertUtil.assertTrue(ReportTaskStatusEnum.RUNNING.getValue() != dbTaskViewDTO.getStatus(), "执行中的任务不能再次运行");
        AssertUtil.assertTrue(MapUtils.isNotEmpty(dbTaskViewDTO.getTaskParams()), "异步任务查询参数不能为空");
        //历史任务未归属某一个业务场景，在下载、重新运行动作时候需要校验提醒客户删除并新建
        AssertUtil.assertTrue(!BizCodeEnum.BRANDONEBP.getBizCode().equals(dbTaskViewDTO.getBizCode()), "暂不支持该任务重新编辑运行，请创建新任务查看数据");
    }

    public void validateReportTaskForExport(ServiceContext context, ReportTaskQueryViewDTO taskQueryViewDTO, ReportTaskViewDTO dbTaskViewDTO){
        AssertUtil.notNull(dbTaskViewDTO, "没有找到对应的异步任务信息");
        AssertUtil.notNull(dbTaskViewDTO.getStatus(), "任务状态不能为空");
        ReportTaskStatusEnum statusEnum = CommonEnum.of(dbTaskViewDTO.getStatus(), ReportTaskStatusEnum.class);
        AssertUtil.notNull(statusEnum, "任务状态错误");
        AssertUtil.assertTrue(ReportTaskStatusEnum.SUCCEED.getValue() == dbTaskViewDTO.getStatus(), "只有运行成功才能下载");
    }

    /**
     * 构造导出excel参数
     * @param context
     * @param taskViewDTO
     * @return
     */
    public ReportQueryViewDTO buildReportQueryViewDTO(ServiceContext context, ReportTaskViewDTO taskViewDTO){
        ReportQueryViewDTO queryViewDTO = new ReportQueryViewDTO();
        queryViewDTO.setBizCode(context.getBizCode());
        queryViewDTO.setFunctionCode(taskViewDTO.getFunctionCode());
        queryViewDTO.setConditions(taskViewDTO.getTaskParams());
        queryViewDTO.setDimensionCodes(taskViewDTO.getDimensionCodes());
        queryViewDTO.setTotalTypes(Lists.newArrayList(Integer.valueOf(taskViewDTO.getTaskParams().get("totalType").toString())));
        //如果是自定义差乘的维度
        String cartesianDimensionStr = "cartesianDimension";
        if(taskViewDTO.getTaskParams().containsKey(cartesianDimensionStr)) {
            queryViewDTO.setCartesianDimension(Integer.valueOf(taskViewDTO.getTaskParams().get(cartesianDimensionStr).toString()));
        }
        //如果存在filterMap参数
        String filterMapStr = "filterMap";
        AssertUtil.assertTrue(taskViewDTO.getTaskParams().containsKey(filterMapStr) && Objects.nonNull(taskViewDTO.getTaskParams().get(filterMapStr)) && StringUtils.isNotBlank(taskViewDTO.getTaskParams().get(filterMapStr).toString()), "请编辑，重新运行");
        Map<String, Object> filterMap = JSON.parseObject(taskViewDTO.getTaskParams().get(filterMapStr).toString(), new TypeReference<HashMap<String, Object>>() {});
        queryViewDTO.setFilterMap(filterMap);

        queryViewDTO.setFileViewDTO(taskViewDTO.getFileViewDTO());
        return queryViewDTO;
    }

    public String crowdViewDTOMessage(List<CrowdViewDTO> crowdBaseViewDTOList){
        String formatString = "(%s:%s)";
        List<String> messageList = Lists.newArrayList();
        crowdBaseViewDTOList.forEach(t->{
            messageList.add(String.format(formatString,t.getCrowdId(),t.getCrowdName()));
        });
        return StringUtils.join(messageList,",");
    }

    /**
     * 获取任务运行结果
     * @param context
     * @param taskViewDTO
     * @param modify
     */
    public void getResult(ServiceContext context, ReportTaskViewDTO taskViewDTO, Boolean modify){
        ExtensionPointsFactory.runAbilitySpi(BizReportTaskSpi.class, extension -> extension.getResult(context, taskViewDTO,modify), taskViewDTO.getFunctionCode());
    }

    public static void main(String[] args) {
        String json = "{\"needDimensionHyperlink\":1,\"fileName\":\"多维分析_自定义分析_2023041816-101_多价格波段带补量计划\",\"needMetricsInfo\":1,\"homePageList\":[{\"type\":1,\"content\":\"订单报告\"},{\"type\":2,\"content\":\"归因品牌ID：181428847\"},{\"type\":2,\"content\":\"归因品牌：天猫测试品牌11\"},{\"type\":2,\"content\":\"订单ID：24155011\"},{\"type\":2,\"content\":\"订单名称：多价格波段带补量计划\"},{\"type\":2,\"content\":\"转化周期：30天\"},{\"type\":2,\"content\":\"投放周期：2023-04-01～2023-06-30\"},{\"type\":2,\"content\":\"数据周期：2023-04-01～2023-04-17\"}],\"needDimensionInfo\":1}";
        ReportFileViewDTO dto = JSON.parseObject(json, ReportFileViewDTO.class);

        System.out.println(JSON.toJSONString(dto));
    }



}
