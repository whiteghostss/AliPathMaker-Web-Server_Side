package com.taobao.ad.brand.bp.domain.campaigngroup.repository;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CrmAdvInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesCustomerViewDTO;
import com.taobao.ad.brand.bp.client.dto.cartitem.CustomerContactViewDTO;

/**
 * @author yanjingang
 * @date 2023/3/20
 */
public interface CustomerRepository {

    /**
     * 查询客户详情
     *
     * @param customerId
     * @return
     */
    SalesCustomerViewDTO getCustomerById(Long customerId);

    /**
     * 查询新老客标识
     *
     * @param customerMemberId
     * @return
     */
    Integer getCustomerType(Long customerMemberId);

    /**
     * 获取客户member优先级
     *
     * @param context
     * @param customerMemberId
     * @return
     */
    String getMemberPriority(ServiceContext context, Long customerMemberId);

    /**
     * 获取客户店铺主营类目id
     *
     * @param customerMemberId 客户memberId
     * @return
     */
    Long getCustomerMainCateId(Long customerMemberId);

    /**
     *
     *
     * @param memberId
     * @return
     */
    CrmAdvInfoViewDTO getCustomer(Long memberId);

    /**
     * 保存客户联系方式
     * @param context
     * @param customerContactViewDTO
     * @return
     */
    Integer saveCustomerContact(ServiceContext context, CustomerContactViewDTO customerContactViewDTO);

}
