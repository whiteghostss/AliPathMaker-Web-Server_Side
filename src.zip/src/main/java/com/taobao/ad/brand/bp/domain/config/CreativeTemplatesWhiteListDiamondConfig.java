package com.taobao.ad.brand.bp.domain.config;

import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.domain.config.base.BaseDiamondConfig;
import org.springframework.stereotype.Component;

@Component
public class CreativeTemplatesWhiteListDiamondConfig extends BaseDiamondConfig {

    private static volatile String templatesWhiteList;

    @Override
    protected String getDataId() {
        return "creative.template.manager.list";
    }
    @Override
    protected String getGroupId() { return "com.taobao.ad.brand.bp"; }

    @Override
    protected void initDiamond(String diamondConfig) {
        RogerLogger.info("DiamondConfig.initDiamond CreativeTemplatesWhiteListDiamondConfig param: {}", diamondConfig);
        templatesWhiteList = diamondConfig;
    }

    public String getTemplatesWhiteList() {
        return templatesWhiteList;
    }
}
