package com.taobao.ad.brand.bp.domain.creative.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.creative.materialgroup.MaterialGroupViewDTO;
import com.alibaba.ad.brand.dto.creative.materialgroup.MaterialViewDTO;
import com.alibaba.ad.brand.dto.creative.materialgroup.crop.MaterialCropResultViewDTO;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCropStatusEnum;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandMamaMaterialTypeEnum;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandMaterialGroupTypeEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.ICreativeSmartMaterialMainImageGetAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeSmartMaterialMainImageGetAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultCreativeSmartMaterialMainImageGetAbility implements ICreativeSmartMaterialMainImageGetAbility {

    @Override
    public List<MaterialViewDTO> handle(ServiceContext serviceContext, CreativeSmartMaterialMainImageGetAbilityParam abilityParam) {
        MaterialGroupViewDTO materialGroupViewDTO = abilityParam.getAbilityTarget();
        if(!BrandMaterialGroupTypeEnum.VISUAL.getCode().equals(materialGroupViewDTO.getGroupType())){
            return Lists.newArrayList();
        }
        List<MaterialViewDTO> materialViewDTOList = Optional.ofNullable(materialGroupViewDTO.getMaterialViewDTOList()).orElse(Lists.newArrayList())
                .stream().filter(materialViewDTO -> BrandMamaMaterialTypeEnum.IMAGE_AUTH_PASS.getCode().equals(materialViewDTO.getType()))
                .filter(materialViewDTO -> {
                    if(abilityParam.isIgnoreCropSuccess()){
                        //拓版成功后，不在重复进行拓版
                        MaterialCropResultViewDTO materialCropResult = Optional.ofNullable(materialViewDTO.getMaterialCropResultViewDTO()).orElse(null);
                        if (materialCropResult != null) {
                            if(BrandCropStatusEnum.SUCCESS.getCode().equals(materialCropResult.getStatus())){
                                return false;
                            }
//                            if(BrandMamaMaterialCropStatusEnum.WAITING.getCode().equals(materialCropResult.getStatus())){
//                                //TODO 后续要看拓版时间（如果超过1小时还没有结果，要不要重新触发）
//                                return false;
//                            }
                        }
                    }
                    return true;
                }).collect(Collectors.toList());

        return materialViewDTOList;
    }
}
