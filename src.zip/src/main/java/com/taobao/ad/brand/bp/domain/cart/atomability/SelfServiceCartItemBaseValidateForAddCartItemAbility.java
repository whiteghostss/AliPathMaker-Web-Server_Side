package com.taobao.ad.brand.bp.domain.cart.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.alibaba.ad.brand.sdk.constant.cartitem.BrandCartItemTypeEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.ICartItemBaseValidateForAddCartItemAbility;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.param.CartItemValidateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
public class SelfServiceCartItemBaseValidateForAddCartItemAbility extends DefaultCartItemBaseValidateForAddCartItemAbility implements SelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext context, CartItemValidateAbilityParam abilityParam) {
        CartItemViewDTO cartItemViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(cartItemViewDTO,"参数不允许为空");
        AssertUtil.notNull(cartItemViewDTO.getType(),"加购行类型不允许为空");
        AssertUtil.notNull(cartItemViewDTO.getSkuId(),"SKU不允许为空");
        //极简自助化
        if(BrandCartItemTypeEnum.SLIM_ORDER.getCode().equals(cartItemViewDTO.getType())){
            AssertUtil.notNull(cartItemViewDTO.getBundleId(),"套餐包不允许为空");
            AssertUtil.notNull(cartItemViewDTO.getCreativeViewDTOList(),"极简模式下创意不允许为空");
        }
        return null;
    }
}
