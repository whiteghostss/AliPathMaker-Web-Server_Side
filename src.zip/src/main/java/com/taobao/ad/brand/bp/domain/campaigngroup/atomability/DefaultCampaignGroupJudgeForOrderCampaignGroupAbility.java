package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupJudgeForFinishCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupJudgeForOrderCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupTransitAbilityParam;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
public class DefaultCampaignGroupJudgeForOrderCampaignGroupAbility implements ICampaignGroupJudgeForOrderCampaignGroupAbility {

    @Override
    public Boolean handle(ServiceContext serviceContext, CampaignGroupTransitAbilityParam abilityParam) {
        return true;
    }
}
