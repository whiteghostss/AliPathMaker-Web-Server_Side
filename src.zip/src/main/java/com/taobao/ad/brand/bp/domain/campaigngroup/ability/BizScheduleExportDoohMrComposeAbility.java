package com.taobao.ad.brand.bp.domain.campaigngroup.ability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.dooh.CampaignDoohViewDTO;
import com.alibaba.ad.brand.dto.campaign.sale.CampaignSaleViewDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.context.ScheduleExportContext;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohCampaignViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohCreativeMaterialViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.export.MaterialRuleExportEnum;
import com.taobao.ad.brand.bp.domain.dooh.repository.DoohRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author jixiu.lj
 * @date 2023/3/29 13:34
 * MR全量数据组装
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizScheduleExportDoohMrComposeAbility extends BizScheduleExportBaseComposeAbility {

    private final DoohRepository doohRepository;


    /**
     * @return filedName-value
     * @see MaterialRuleExportEnum
     */
    public List<Map<MaterialRuleExportEnum, String>> compose(ServiceContext serviceContext,
                                                             ScheduleExportContext scheduleExportContext) {

        List<CampaignViewDTO> campaignViewDTOList = scheduleExportContext.getCampaignViewDTOList();
        if (CollectionUtils.isEmpty(campaignViewDTOList)) {
            return Collections.emptyList();
        }
        //获取所有的天攻计划ID
        List<Long> doohCampaignIds = campaignViewDTOList.stream().map(CampaignViewDTO::getCampaignDoohViewDTO)
                .map(CampaignDoohViewDTO::getDoohCampaignId)
                .filter(Objects::nonNull)
                .distinct().collect(Collectors.toList());
        if (CollectionUtils.isEmpty(doohCampaignIds)) {
            return Collections.emptyList();
        }

        List<DoohCampaignViewDTO> doohCampaignViewDTOList = doohCampaignIds.stream().map(doohCampaignId -> {
            DoohCampaignViewDTO doohCampaignViewDTO = doohRepository.getCampaignById(doohCampaignId);
            return Objects.isNull(doohCampaignViewDTO) ? null : doohCampaignViewDTO;
        }).filter(Objects::nonNull).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(doohCampaignViewDTOList)) {
            return Collections.emptyList();
        }
        List<Map<MaterialRuleExportEnum, String>> results = Lists.newArrayList();


        doohCampaignViewDTOList.forEach(doohCampaignViewDTO -> {
            if (CollectionUtils.isEmpty(doohCampaignViewDTO.getMaterials())) {
                return;
            }
            for (int i = 0; i < doohCampaignViewDTO.getMaterials().size(); i++) {
                Map<MaterialRuleExportEnum, String> result = new HashMap<>();
                DoohCreativeMaterialViewDTO material = doohCampaignViewDTO.getMaterials().get(i);
                result.put(MaterialRuleExportEnum.MATERIAL_NAME, "素材" + (i + 1) );
                result.put(MaterialRuleExportEnum.MATERIAL_TYPE, material.getFileType());
                result.put(MaterialRuleExportEnum.MATERIAL_SIZE, material.getWidth() + " * " + material.getHeight());
                result.put(MaterialRuleExportEnum.MATERIAL_TIME,
                        Objects.nonNull(material.getDuration()) ?
                                material.getDuration().equals(0) ? "" : material.getDuration() + "s"
                                : "-");
                result.put(MaterialRuleExportEnum.MATERIAL_DESC, doohCampaignViewDTO.getMrOssUrl());
                results.add(result);
            }


        });
        return results;
    }

}
