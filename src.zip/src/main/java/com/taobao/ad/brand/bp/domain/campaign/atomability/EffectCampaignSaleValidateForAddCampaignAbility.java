package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.sale.CampaignSaleViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.EffectAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignSaleValidateForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignSaleAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_REQUIRED;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EffectCampaignSaleValidateForAddCampaignAbility implements ICampaignSaleValidateForAddCampaignAbility, EffectAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignSaleAbilityParam abilityParam) {
        CampaignSaleViewDTO campaignSaleViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(campaignSaleViewDTO, PARAM_REQUIRED, "售卖信息必填");
        AssertUtil.notNull(campaignSaleViewDTO.getSaleGroupId(), PARAM_REQUIRED, "售卖分组ID必填");
        AssertUtil.notNull(campaignSaleViewDTO.getResourcePackageProductId(), PARAM_REQUIRED, "资源包产品ID必填");
        return null;
    }
}
