package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupStatusUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupStatusUpdateAbilityParam;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
@BusinessAbility
public class DefaultCampaignGroupStatusUpdateAbility implements ICampaignGroupStatusUpdateAbility {
    @Resource
    private CampaignGroupRepository campaignGroupRepository;

    @Override
    public Integer handle(ServiceContext serviceContext, CampaignGroupStatusUpdateAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        Integer targetStatus = abilityParam.getTargetStatus();
        if (targetStatus == null || targetStatus.equals(campaignGroupViewDTO.getStatus())) {
            return 0;
        }
        campaignGroupViewDTO.setPreviousStatus(campaignGroupViewDTO.getStatus());
        campaignGroupViewDTO.setStatus(targetStatus);

        CampaignGroupViewDTO updateCampaignGroup = new CampaignGroupViewDTO();
        updateCampaignGroup.setId(campaignGroupViewDTO.getId());
        updateCampaignGroup.setStatus(campaignGroupViewDTO.getStatus());
        updateCampaignGroup.setPreviousStatus(campaignGroupViewDTO.getPreviousStatus());

        return campaignGroupRepository.updateCampaignGroupPart(serviceContext, updateCampaignGroup);
    }
}
