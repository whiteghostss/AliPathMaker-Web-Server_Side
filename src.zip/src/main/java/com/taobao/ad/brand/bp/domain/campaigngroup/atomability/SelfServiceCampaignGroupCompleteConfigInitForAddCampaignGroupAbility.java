package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.complete.CampaignGroupCompleteConfigViewDTO;
import com.alibaba.ad.brand.dto.common.ShopViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSourceEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.domain.feed.FeedRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupCompleteConfigInitForAddCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupCompleteConfigAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCampaignGroupCompleteConfigInitForAddCampaignGroupAbility
        implements ICampaignGroupCompleteConfigInitForAddCampaignGroupAbility, SelfServiceAtomAbilityRouter {

    private final FeedRepository feedRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupCompleteConfigAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        // 对极简版进行初始化
        if (BrandCampaignGroupSourceEnum.SLIM_ORDER.getCode().equals(campaignGroupViewDTO.getSource())) {
            CampaignGroupCompleteConfigViewDTO completeConfigViewDTO = Optional.ofNullable(abilityParam.getAbilityTarget()).orElse(new CampaignGroupCompleteConfigViewDTO());
            if (CollectionUtils.isNotEmpty(completeConfigViewDTO.getBrandViewDTOList())) {
                completeConfigViewDTO.setNeedExportDataBank(BrandBoolEnum.BRAND_TRUE.getCode());
            } else {
                completeConfigViewDTO.setNeedExportDataBank(BrandBoolEnum.BRAND_FALSE.getCode());
            }
            completeConfigViewDTO.setShopViewDTO(getShop(serviceContext, campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getCustomerMemberId()));

            campaignGroupViewDTO.setCampaignGroupCompleteConfigViewDTO(completeConfigViewDTO);
        }

        return null;
    }

    private ShopViewDTO getShop(ServiceContext serviceContext, Long customerMemberId) {
        try {
            com.taobao.ad.brand.bp.client.dto.shop.ShopViewDTO shopViewDTO = feedRepository.getShopInfoByMemberId(customerMemberId);
            if (shopViewDTO != null) {
                ShopViewDTO completeShopViewDTO = new ShopViewDTO();
                completeShopViewDTO.setShopId(shopViewDTO.getId());
                completeShopViewDTO.setShopName(shopViewDTO.getName());
                return completeShopViewDTO;
            }
        } catch (Exception e) {
            RogerLogger.error("查询店铺发生错误: {}", e);
        }
        return null;
    }
}
