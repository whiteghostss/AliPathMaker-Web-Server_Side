package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.biz.definition.constants.UniversalCampaignModel;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.scroll.CampaignScrollViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignRegisterMannerEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignScrollTypeEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignUnionControlFlowEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignScrollInitForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignScrollAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Objects;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandCampaignScrollInitForAddCampaignAbility implements ICampaignScrollInitForAddCampaignAbility, BrandAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignScrollAbilityParam abilityParam) {
        CampaignScrollViewDTO campaignScrollViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();
        AssertUtil.notNull(campaignScrollViewDTO, "计划滚量信息不能为空");
        AssertUtil.notNull(campaignViewDTO, "计划信息不能为空");

        campaignScrollViewDTO.setScrollOpTime(new Date());
        //主补联合控量 -> 补量的主计划不设置滚量
        if (Objects.equals(campaignViewDTO.getCampaignGuaranteeViewDTO().getIsUnionControlFlow(), BrandCampaignUnionControlFlowEnum.UNION.getCode())
                && Objects.equals(campaignViewDTO.getCampaignSaleViewDTO().getSaleType(), BrandSaleTypeEnum.BOOST.getCode())) {
            campaignScrollViewDTO.setScrollType(BrandCampaignScrollTypeEnum.CLOSE.getCode());
            campaignScrollViewDTO.setInitScrollType(BrandCampaignScrollTypeEnum.CLOSE.getCode());
        }
        // 全域通黑盒支持滚量
        if (Objects.equals(UniversalCampaignModel.TAO_CROSS_BLACK.getId(),campaignViewDTO.getCampaignModel())) {
            campaignScrollViewDTO.setScrollType(BrandCampaignScrollTypeEnum.PERIOD_SCROLL.getCode());
            campaignScrollViewDTO.setInitScrollType(BrandCampaignScrollTypeEnum.PERIOD_SCROLL.getCode());
        } else if (Objects.equals(UniversalCampaignModel.TAO_CROSS_TX_SHOWMAX_PACKAGE.getId(),campaignViewDTO.getCampaignModel())) {
            // showmax支持滚量
            campaignScrollViewDTO.setScrollType(BrandCampaignScrollTypeEnum.PERIOD_SCROLL.getCode());
            campaignScrollViewDTO.setInitScrollType(BrandCampaignScrollTypeEnum.PERIOD_SCROLL.getCode());
        }
        //二环PDB支持滚量
        else if(Objects.equals(UniversalCampaignModel.TAO_ECOLOGY_TWO_PDB.getId(),campaignViewDTO.getCampaignModel())){
            campaignScrollViewDTO.setScrollType(BrandCampaignScrollTypeEnum.PERIOD_SCROLL.getCode());
            campaignScrollViewDTO.setInitScrollType(BrandCampaignScrollTypeEnum.PERIOD_SCROLL.getCode());
            campaignScrollViewDTO.setScrollStartTime(campaignViewDTO.getStartTime());
        }
        //二环CPT不滚量
        else if (BizCampaignToolsHelper.isTwoCPT(campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope(),campaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterUnit())){
            campaignScrollViewDTO.setScrollType(BrandCampaignScrollTypeEnum.CLOSE.getCode());
            campaignScrollViewDTO.setInitScrollType(BrandCampaignScrollTypeEnum.CLOSE.getCode());
        }
        //非PDB默认设置自动滚量  -主补联合控量的，补量的主计划也不能设置
        else if (Objects.equals(campaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterManner(), BrandCampaignRegisterMannerEnum.PDB.getCode())) {
            campaignScrollViewDTO.setScrollType(BrandCampaignScrollTypeEnum.CLOSE.getCode());
            campaignScrollViewDTO.setInitScrollType(BrandCampaignScrollTypeEnum.CLOSE.getCode());
        }
        else{
            campaignScrollViewDTO.setScrollType(BrandCampaignScrollTypeEnum.PERIOD_SCROLL.getCode());
            campaignScrollViewDTO.setInitScrollType(BrandCampaignScrollTypeEnum.PERIOD_SCROLL.getCode());
            campaignScrollViewDTO.setScrollStartTime(campaignViewDTO.getStartTime());
        }
        // 跨域产品支持多价格波段
        if (BizCampaignToolsHelper.isCrossPricePeriodCampaign(campaignViewDTO)) {
            campaignScrollViewDTO.setScrollType(BrandCampaignScrollTypeEnum.BAND_PRICE_SCROLL.getCode());
            campaignScrollViewDTO.setInitScrollType(BrandCampaignScrollTypeEnum.BAND_PRICE_SCROLL.getCode());
        }
        return null;
    }
}
