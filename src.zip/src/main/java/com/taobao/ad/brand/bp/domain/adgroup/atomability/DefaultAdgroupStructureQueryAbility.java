package com.taobao.ad.brand.bp.domain.adgroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.adgroup.CreativeRefViewDTO;
import com.alibaba.ad.brand.dto.adgroup.crowd.AdgroupCrowdScenarioViewDTO;
import com.alibaba.ad.brand.dto.adgroup.crowd.AdgroupCrowdViewDTO;
import com.alibaba.ad.brand.dto.adgroup.frequence.AdgroupFrequencyViewDTO;
import com.alibaba.ad.brand.dto.frequency.FrequencyViewDTO;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupTargetTypeEnum;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryOption;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeQueryViewDTO;
import com.taobao.ad.brand.bp.common.constant.ReportConstant;
import com.taobao.ad.brand.bp.common.threadpooltask.AdgroupCreativeQueryTaskIdentifier;
import com.taobao.ad.brand.bp.common.threadpooltask.AdgroupFrequencyQueryTaskIdentifier;
import com.taobao.ad.brand.bp.domain.adgroup.repository.AdgroupRepository;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeRepository;
import com.taobao.ad.brand.bp.domain.frequency.repository.FrequencyRepository;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.query.IAdgroupStructureQueryAbility;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author yanjingang
 * @date 2024/9/12
 */
@Component
@BusinessAbility
public class DefaultAdgroupStructureQueryAbility implements IAdgroupStructureQueryAbility {

    @Resource
    private AdgroupRepository adgroupRepository;
    @Resource
    private CreativeRepository creativeRepository;
    @Resource
    private FrequencyRepository frequencyRepository;
    @Resource
    private AdgroupCreativeQueryTaskIdentifier adgroupCreativeQueryTaskIdentifier;
    @Resource
    private AdgroupFrequencyQueryTaskIdentifier adgroupFrequencyQueryTaskIdentifier;

    @Override
    public List<AdgroupViewDTO> handle(ServiceContext serviceContext, AdgroupStructureQueryAbilityParam abilityParam) {
        AdgroupQueryViewDTO query = abilityParam.getAbilityTarget();
        AdgroupQueryOption option = Optional.ofNullable(abilityParam.getQueryOption()).orElse(new AdgroupQueryOption());
        List<AdgroupViewDTO> adgroupViewDTOList = adgroupRepository.queryAdgroupListNoPage(serviceContext, query);
        if  (CollectionUtils.isEmpty(adgroupViewDTOList)) {
            return Lists.newArrayList();
        }
        // 填充单元信息
        processAdgroupInfo(serviceContext, adgroupViewDTOList, option);

        return adgroupViewDTOList;
    }

    /**
     * 填充单元查询扩展信息
     * @param serviceContext
     * @param adgroupViewDTOList
     * @param option
     */
    protected void processAdgroupInfo(ServiceContext serviceContext,List<AdgroupViewDTO> adgroupViewDTOList, AdgroupQueryOption option) {
        // 填充人群定向
        if (option.isNeedTarget()) {
            fillCrowdTarget(serviceContext, adgroupViewDTOList);
        }
        if (option.isNeedCreative()){
            fillCreative(serviceContext, adgroupViewDTOList);
        }
        if (option.isNeedFrequency()) {
            fillFrequency(serviceContext, adgroupViewDTOList);
        }
    }

    /**
     * adgroupViewDTOList填充人群定向信息
     */
    private void fillCrowdTarget(ServiceContext context, List<AdgroupViewDTO> adgroupViewDTOList) {
        List<Long> adgroupIds = adgroupViewDTOList.stream().filter(t -> t.getTargetType().equals(BrandAdgroupTargetTypeEnum.PROGRAM.getCode())).map(AdgroupViewDTO::getId).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(adgroupIds)) {
            return;
        }
        Map<Long, List<AdgroupCrowdViewDTO>> mapCrowdTarget = adgroupRepository.getCrowdTargetMapByAdgroupIds(context, adgroupIds);
        if (MapUtils.isEmpty(mapCrowdTarget)) {
            return;
        }
        adgroupViewDTOList.forEach(adgroupViewDTO -> {
            List<AdgroupCrowdViewDTO> crowdBaseViewDTOS = mapCrowdTarget.getOrDefault(adgroupViewDTO.getId(), Lists.newArrayList());
            //百灵临时兜底方案,后续dmp升级接口后可去除
            crowdBaseViewDTOS.forEach(crowdBaseViewDTO -> {
                if (crowdBaseViewDTO.getCrowdId() != null && StringUtils.isBlank(crowdBaseViewDTO.getCrowdName())) {
                    crowdBaseViewDTO.setCrowdName(ReportConstant.DMP_CROWD_DEFAULT_NAME);
                }
            });
            AdgroupCrowdScenarioViewDTO adgroupCrowdScenarioViewDTO =
                    Optional.ofNullable(adgroupViewDTO.getAdgroupCrowdScenarioViewDTO()).orElse(new AdgroupCrowdScenarioViewDTO());
            adgroupCrowdScenarioViewDTO.setAdgroupCrowdViewDTOList(crowdBaseViewDTOS);
            adgroupViewDTO.setAdgroupCrowdScenarioViewDTO(adgroupCrowdScenarioViewDTO);
        });
    }

    /**
     * 填充单元创意（不关系绑定状态）
     * @param context
     * @param adgroupViewDTOList
     */
    private void fillCreative(ServiceContext context, List<AdgroupViewDTO> adgroupViewDTOList) {
        fillCreativeRef(context,adgroupViewDTOList,null,true);
    }

    /**
     * adgroupViewDTOList填充创意信息
     * @param context
     * @param adgroupViewDTOList
     * @param onlineStatus BrandBoolEnum 绑定状态，默认查询全部状态
     * @param isNeedSetting creativeRef-Setting，默认查询全部状态
     */
    private void fillCreativeRef(ServiceContext context, List<AdgroupViewDTO> adgroupViewDTOList, Integer onlineStatus, boolean isNeedSetting) {
        if (CollectionUtils.isEmpty(adgroupViewDTOList)) {
            return;
        }
        List<Long> adgroupIds = adgroupViewDTOList.stream().map(AdgroupViewDTO::getId).collect(Collectors.toList());
        List<List<Long>> adgroupIdPartitionList = Lists.partition(adgroupIds, 50);
        List<List<CreativeRefViewDTO>> batchedOperate =
                TaskStream.execute(adgroupCreativeQueryTaskIdentifier, adgroupIdPartitionList, (adgroupIdList, index) -> {
                            CreativeQueryViewDTO creativeQueryViewDTO = new CreativeQueryViewDTO();
                            creativeQueryViewDTO.setAdgroupIds(adgroupIdList);
                            creativeQueryViewDTO.setOnlineStatus(onlineStatus);
                            return creativeRepository.findCreativeRefList(context, creativeQueryViewDTO, isNeedSetting);
                        })
                        .commit()
                        .getResultList();

        if (CollectionUtils.isNotEmpty(batchedOperate)) {
            Map<Long, List<CreativeRefViewDTO>> mapCreativeRef = batchedOperate.stream().flatMap(Collection::stream).collect(Collectors.toList())
                    .stream().collect(Collectors.groupingBy(CreativeRefViewDTO::getAdgroupId));
            adgroupViewDTOList.forEach(adgroupViewDTO -> adgroupViewDTO.setCreativeRefViewDTOList(mapCreativeRef.getOrDefault(adgroupViewDTO.getId(), Lists.newArrayList())));
        }
    }

    /**
     * 填充频控信息
     */
    private void fillFrequency(ServiceContext serviceContext, List<AdgroupViewDTO> adgroupViewDTOList) {
        if (CollectionUtils.isEmpty(adgroupViewDTOList)) {
            return;
        }
        List<Long> adgroupIds = adgroupViewDTOList.stream().map(AdgroupViewDTO::getId).collect(Collectors.toList());
        List<List<Long>> adgroupIdPartition = Lists.partition(adgroupIds, 50);
        Map<Long, FrequencyViewDTO> adgroupFrequencyMap = Maps.newConcurrentMap();
        TaskStream.consume(adgroupFrequencyQueryTaskIdentifier, adgroupIdPartition, (adgroupIdList, index) -> {
                    Map<Long, FrequencyViewDTO> frequencyMap = frequencyRepository.getAdgroupFrequency(serviceContext, adgroupIdList);
                    RogerLogger.info("adgroupIdList {}, adgroupFrequency {}", JSON.toJSONString(adgroupIdList), JSON.toJSONString(frequencyMap));
                    adgroupFrequencyMap.putAll(frequencyMap);
                })
                .commit()
                .handle();
        for (AdgroupViewDTO adgroupViewDTO : adgroupViewDTOList) {
            AdgroupFrequencyViewDTO adgroupFrequencyViewDTO = Optional.ofNullable(adgroupViewDTO.getAdgroupFrequencyViewDTO()).orElse(new AdgroupFrequencyViewDTO());
            adgroupFrequencyViewDTO.setFrequencyViewDTO(adgroupFrequencyMap.get(adgroupViewDTO.getId()));
            adgroupViewDTO.setAdgroupFrequencyViewDTO(adgroupFrequencyViewDTO);
        }
    }
}
