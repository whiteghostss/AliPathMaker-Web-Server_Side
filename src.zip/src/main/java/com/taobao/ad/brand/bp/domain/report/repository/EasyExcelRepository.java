package com.taobao.ad.brand.bp.domain.report.repository;

import com.taobao.ad.brand.bp.client.dto.report.excel.ExcelCatalogueViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.excel.ExcelOutputViewDTO;

import java.util.List;
import java.util.Map;

/**
 * @author yuncheng.lyc
 * @date 2023/3/23
 **/
public interface EasyExcelRepository {

    /**
     * 导出excel，单个sheet
     * @param fileName 文件名称
     * @param sheetName sheet的名称
     * @param fieldMap header 字段和汉字对应关系
     * @param dataList 数据对象
     */
    ExcelOutputViewDTO listToExcel (String fileName, String sheetName, List<ExcelCatalogueViewDTO> homePageList, Map<String, String> fieldMap, List<Map<String, Object>> dataList);

    /**
     * 导出excel，多个sheet
     * @param fileName 文件名称
     * @param homePageList
     * @param sheetNameMap sheet的名称
     * @param fieldMap header 字段和汉字对应关系
     * @param dataMap 数据对象
     */
    ExcelOutputViewDTO listToExcel (String fileName, Map<String, String> sheetNameMap, List<ExcelCatalogueViewDTO> homePageList, Map<String, Map<String, String>> fieldMap, Map<String, List<Map<String, Object>>> dataMap);


}
