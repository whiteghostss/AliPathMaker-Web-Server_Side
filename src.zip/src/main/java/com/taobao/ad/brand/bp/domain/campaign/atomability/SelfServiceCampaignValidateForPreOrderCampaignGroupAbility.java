package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.common.constant.campaigngroup.CampaignGroupConstant;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignValidateForPreOrderCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignValidateForPreOrderCampaignGroupAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCampaignValidateForPreOrderCampaignGroupAbility implements ICampaignValidateForPreOrderCampaignGroupAbility, SelfServiceAtomAbilityRouter {


    @Override
    public Void handle(ServiceContext serviceContext, CampaignValidateForPreOrderCampaignGroupAbilityParam abilityParam) {
        List<CampaignViewDTO> campaignViewDTOList = abilityParam.getAbilityTargets();
        // 计划校验
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(campaignViewDTOList), BIZ_BREAK_RULE_ERROR, "订单下无计划");
        // 计划状态
        List<Long> inValidCampaignIds = campaignViewDTOList.stream()
                .filter(item -> !CampaignGroupConstant.validCampaignStatusOnOrder.contains(item.getStatus()))
                .map(CampaignViewDTO::getId)
                .collect(Collectors.toList());
        AssertUtil.assertTrue(CollectionUtils.isEmpty(inValidCampaignIds), BIZ_BREAK_RULE_ERROR, String.format("计划(%s)的状态不满足下单条件", StringUtils.join(inValidCampaignIds, ",")));

        return null;
    }
}
