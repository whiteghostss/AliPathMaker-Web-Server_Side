package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignOnlineStatusUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignOnlineStatusUpdateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCampaignOnlineStatusUpdateAbility
        implements ICampaignOnlineStatusUpdateAbility, SelfServiceAtomAbilityRouter {

    private final CampaignRepository campaignRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignOnlineStatusUpdateAbilityParam abilityParam) {
        Integer targetOnlineStatus = abilityParam.getTargetOnlineStatus();
        List<CampaignViewDTO> updateList = Lists.newArrayList();
        // 一级
        for (CampaignViewDTO campaignViewDTO : abilityParam.getAbilityTargets()) {
            CampaignViewDTO updateCampaign = buildUpdateCampaignViewDTO(campaignViewDTO, targetOnlineStatus);
            Optional.ofNullable(updateCampaign).ifPresent(updateList::add);
            // 二级
            if (CollectionUtils.isNotEmpty(campaignViewDTO.getSubCampaignViewDTOList())) {
                for (CampaignViewDTO subCampaign : campaignViewDTO.getSubCampaignViewDTOList()) {
                    CampaignViewDTO subUpdateCampaign = buildUpdateCampaignViewDTO(subCampaign, targetOnlineStatus);
                    Optional.ofNullable(subUpdateCampaign).ifPresent(updateList::add);
                }
            }
        }
        if (CollectionUtils.isNotEmpty(updateList)) {
            campaignRepository.updateCampaignPart(serviceContext, updateList);
        }
        return null;
    }

    private CampaignViewDTO buildUpdateCampaignViewDTO(CampaignViewDTO campaignViewDTO, Integer targetOnlineStatus) {
        if (targetOnlineStatus.equals(campaignViewDTO.getOnlineStatus())) {
            return null;
        }
        campaignViewDTO.setOnlineStatus(targetOnlineStatus);
        CampaignViewDTO updateCampaign = new CampaignViewDTO();
        updateCampaign.setId(campaignViewDTO.getId());
        updateCampaign.setOnlineStatus(targetOnlineStatus);
        return updateCampaign;
    }
}
