package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.adzone.CampaignAdzoneViewDTO;
import com.alibaba.ad.brand.dto.campaign.audience.CampaignTargetScenarioViewDTO;
import com.alibaba.ad.brand.dto.campaign.audience.CampaignTargetViewDTO;
import com.alibaba.ad.brand.sdk.constant.audience.field.BrandTargetTypeEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignRegisterUnitEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.product.CastTypeEnum;
import com.alibaba.ad.nb.ssp.constant.common.CrossSceneEnum;
import com.alibaba.ad.nb.ssp.constant.common.MediaScopeEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignAdzoneValidateForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignAdzoneAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_ILLEGAL;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandCampaignAdzoneValidateForAddCampaignAbility implements ICampaignAdzoneValidateForAddCampaignAbility, BrandAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignAdzoneAbilityParam abilityParam) {
        ProductViewDTO productViewDTO = abilityParam.getProductViewDTO();
        AssertUtil.notNull(productViewDTO,"计划产品不允许为空");
        ResourcePackageProductViewDTO packageProductViewDTO = abilityParam.getResourcePackageProductViewDTO();
        AssertUtil.notNull(packageProductViewDTO,"计划资源位位不允许为空");
        CampaignTargetScenarioViewDTO campaignTargetScenarioViewDTO = abilityParam.getAbilityTarget();
        // 【推广位】资源关联产品推广位不能为空，跨域场景下需要判断其关联的子产品推广位是否为空
        if (MediaScopeEnum.CROSS_SCOPE.getCode().equals(productViewDTO.getMediaScope())) {
            AssertUtil.notEmpty(productViewDTO.getAssociationProductList(),  "跨域场景下资源关联产品" + productViewDTO.getUuid() + "的子产品不能为空");
            AssertUtil.assertTrue(BrandCampaignRegisterUnitEnum.CPM.getCode().equals(productViewDTO.getRegisterUnit()) || BrandCampaignRegisterUnitEnum.CPM.getCode().equals(productViewDTO.getSellUnit()),"跨域产品目前不支持CPT");
            for (ProductViewDTO viewDTO : productViewDTO.getAssociationProductList()) {
                AssertUtil.notEmpty(viewDTO.getAdzoneIdList(), PARAM_ILLEGAL, "跨域场景下资源关联产品" + viewDTO.getUuid() + "的推广位不能为空");
            }
            // 跨域场景为“全域通”，不支持含三环PDB/CPM的二级产品
            if (productViewDTO.getCrossScene() != null && productViewDTO.getCrossScene() == CrossSceneEnum.CROSS_SCENE.getValue()) {
                for (ResourcePackageProductViewDTO subPackageProductViewDTO : packageProductViewDTO.getSubResourcePackageProductList()) {
                    AssertUtil.assertTrue(!(Objects.equals(subPackageProductViewDTO.getMediaScope(), MediaScopeEnum.SITE_OUT.getCode())
                            // 跨域场景下，打包平台投放方式不会是「PD or PDB」这种选项
                            && (CastTypeEnum.PDB.getValue().equals(subPackageProductViewDTO.getCastType().getType())
                            || StringUtils.isNotBlank(subPackageProductViewDTO.getCastType().getReturnRatio()))), "跨域场景为“全域通”，不支持含三环PDB/CPM的二级产品");
                }
            }
        } else {
            AssertUtil.notEmpty(productViewDTO.getAdzoneIdList(), "资源关联产品" + productViewDTO.getUuid() + "的推广位不能为空");
        }
        //贴片推广位校验
        validatePrecedenceAdzone(campaignTargetScenarioViewDTO,productViewDTO);
        return null;
    }

    /**
     * 校验贴片广告位
     * @param campaignTargetScenarioViewDTO
     * @param productViewDTO
     */
    private void validatePrecedenceAdzone(CampaignTargetScenarioViewDTO campaignTargetScenarioViewDTO,ProductViewDTO productViewDTO){
        //贴片定向
        Optional<CampaignTargetViewDTO> optional = Optional.ofNullable(campaignTargetScenarioViewDTO)
                .map(CampaignTargetScenarioViewDTO::getCampaignTargetViewDTOList).orElse(Lists.newArrayList())
                .stream().filter(targetViewDTO -> Objects.equals(BrandTargetTypeEnum.PRECEDENCE.getCode().toString(),targetViewDTO.getType())).findFirst();
        if(optional.isPresent()){
            List<Integer> pidPatchList = Optional.ofNullable(productViewDTO.getAdzoneList()).orElse(Lists.newArrayList())
                    .stream().map(CampaignAdzoneViewDTO::getPidPatch).distinct().collect(Collectors.toList());
            //判断选择的贴片定向，至少有一个推广位满足
            List<String> targetValues = optional.get().getTargetValues();
            boolean hasMatch = false;
            for (String targetValue : targetValues) {
                Integer pidPatch = Integer.parseInt(targetValue.split("_")[0]);
                if(pidPatchList.contains(pidPatch)){
                    hasMatch = true;
                    break;
                }
            }
            AssertUtil.assertTrue(hasMatch,"计划上无满足该贴片定向的广告位");
        }
    }
}
