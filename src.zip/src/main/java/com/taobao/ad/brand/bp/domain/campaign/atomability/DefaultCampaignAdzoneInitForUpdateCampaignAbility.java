package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.adzone.CampaignAdzoneViewDTO;
import com.alibaba.ad.brand.dto.campaign.audience.CampaignTargetScenarioViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignAdzoneInitForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignAdzoneAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultCampaignAdzoneInitForUpdateCampaignAbility implements ICampaignAdzoneInitForUpdateCampaignAbility {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignAdzoneAbilityParam abilityParam) {
        CampaignTargetScenarioViewDTO campaignTargetScenarioViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(campaignTargetScenarioViewDTO,"计划广告位信息不允许为空");
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        AssertUtil.notNull(dbCampaignViewDTO,"计划不存在");

        List<CampaignAdzoneViewDTO> dbCampaignAdzoneViewDTOList = Optional.ofNullable(dbCampaignViewDTO.getCampaignTargetScenarioViewDTO())
                .map(CampaignTargetScenarioViewDTO::getCampaignAdzoneViewDTOList).orElse(null);
        if(CollectionUtils.isNotEmpty(dbCampaignAdzoneViewDTOList)){
            campaignTargetScenarioViewDTO.setCampaignAdzoneViewDTOList(dbCampaignAdzoneViewDTOList);
        }
        return null;
    }
}
