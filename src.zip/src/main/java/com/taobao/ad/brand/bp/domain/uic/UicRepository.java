package com.taobao.ad.brand.bp.domain.uic;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.dto.creative.MemberPageCheckViewDTO;

public interface UicRepository {
    MemberPageCheckViewDTO memberPageCheck(ServiceContext serviceContext, Long sellerId);

    boolean checkTag( Long sellerId, String tagCode);
}
