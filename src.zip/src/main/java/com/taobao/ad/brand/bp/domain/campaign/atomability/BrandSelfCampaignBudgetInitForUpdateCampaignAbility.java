package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.budget.CampaignBudgetViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignBudgetInitForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBudgetAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Optional;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_REQUIRED;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSelfCampaignBudgetInitForUpdateCampaignAbility implements ICampaignBudgetInitForUpdateCampaignAbility, BrandSelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignBudgetAbilityParam abilityParam) {
        CampaignBudgetViewDTO campaignBudgetViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        AssertUtil.notNull(campaignBudgetViewDTO, PARAM_REQUIRED, "预算不能为空");
        AssertUtil.notNull(campaignViewDTO, PARAM_REQUIRED, "计划不能为空");
        AssertUtil.notNull(dbCampaignViewDTO, PARAM_REQUIRED, "计划不存在");

        CampaignBudgetViewDTO dbCampaignBudgetViewDTO = Optional.ofNullable(dbCampaignViewDTO.getCampaignBudgetViewDTO()).orElse(new CampaignBudgetViewDTO());
        campaignBudgetViewDTO.setIsCustomResetBudget(dbCampaignBudgetViewDTO.getIsCustomResetBudget());
        campaignBudgetViewDTO.setBudgetRatio(dbCampaignBudgetViewDTO.getBudgetRatio());
        campaignBudgetViewDTO.setPublishTotalMoney(dbCampaignBudgetViewDTO.getPublishTotalMoney());
        //二环CPT：预定量变更，需要清空金额、预定量 、以及询锁量信息
        Integer mediaScope = dbCampaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope();
        Integer registerUnit = dbCampaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterUnit();
        boolean isNeedClearBudget = false;
        if(BizCampaignToolsHelper.isTwoCPT(mediaScope,registerUnit)){
            Long cptAmount = campaignViewDTO.getCampaignGuaranteeViewDTO().getCptAmount();
            Long dbCptAmount = dbCampaignViewDTO.getCampaignGuaranteeViewDTO().getCptAmount();
            isNeedClearBudget = !Objects.equals(dbCptAmount, cptAmount);
        }
        if(isNeedClearBudget){
            campaignBudgetViewDTO.setDiscountTotalMoney(0L);
            campaignBudgetViewDTO.setPublishTotalMoney(0L);
            campaignBudgetViewDTO.setBudgetRatio(0);
        }
        // 批量导入场景下，一级计划的金额可以编辑存储，仅做展示使用，后续计算逻辑不变，计划编辑页面不支持
        if(campaignBudgetViewDTO.getDiscountTotalMoney() != null
                && BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode().equals(dbCampaignViewDTO.getCampaignLevel())){
            campaignBudgetViewDTO.setDiscountTotalMoney(campaignBudgetViewDTO.getDiscountTotalMoney());
        }else{
            campaignBudgetViewDTO.setDiscountTotalMoney(dbCampaignBudgetViewDTO.getDiscountTotalMoney());
        }
        return null;
    }
}
