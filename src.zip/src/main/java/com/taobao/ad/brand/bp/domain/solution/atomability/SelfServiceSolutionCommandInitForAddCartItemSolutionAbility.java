package com.taobao.ad.brand.bp.domain.solution.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.selfservice.CampaignSelfServiceViewDTO;
import com.alibaba.ad.brand.sdk.constant.cartitem.BrandCartItemSourceEnum;
import com.alibaba.ad.brand.sdk.constant.cartitem.BrandCartItemStatusEnum;
import com.taobao.ad.brand.bp.client.dto.solution.CartItemSolutionViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.solution.atomability.ISolutionCommandInitForAddCartItemSolutionAbility;
import com.taobao.ad.brand.bp.domain.sdk.solution.atomability.param.CartItemSolutionCommandAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceSolutionCommandInitForAddCartItemSolutionAbility implements ISolutionCommandInitForAddCartItemSolutionAbility, SelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CartItemSolutionCommandAbilityParam abilityParam) {
        CartItemSolutionViewDTO solutionCommandViewDTO = abilityParam.getAbilityTarget();
        if(solutionCommandViewDTO.getCartSource() == null){
            solutionCommandViewDTO.setCartSource(BrandCartItemSourceEnum.BAILING.getCode());
        }
        solutionCommandViewDTO.setStatus(BrandCartItemStatusEnum.ORDER_WAIT.getCode());

        CampaignViewDTO campaignViewDTO = solutionCommandViewDTO.getCampaignViewDTO();
        campaignViewDTO.setId(null);
        CampaignSelfServiceViewDTO campaignSelfServiceViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignSelfServiceViewDTO()).orElse(new CampaignSelfServiceViewDTO());
        campaignSelfServiceViewDTO.setSkuId(solutionCommandViewDTO.getSkuId());
        campaignSelfServiceViewDTO.setBundleId(solutionCommandViewDTO.getBundleId());
        campaignSelfServiceViewDTO.setCartItemId(solutionCommandViewDTO.getId());
        campaignViewDTO.setCampaignSelfServiceViewDTO(campaignSelfServiceViewDTO);
        return null;
    }
}
