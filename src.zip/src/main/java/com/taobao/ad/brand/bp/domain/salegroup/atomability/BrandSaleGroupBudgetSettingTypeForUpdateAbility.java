package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignProductConfigTypeEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleGroupBudgetSettingTypeEnum;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.calculate.CampaignGroupSaleGroupCalViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.calculate.ISaleGroupBudgetSettingTypeForUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignCalculateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSaleGroupBudgetSettingTypeForUpdateAbility implements ISaleGroupBudgetSettingTypeForUpdateAbility, BrandAtomAbilityRouter {
    @Override
    public Void handle(ServiceContext serviceContext, CampaignCalculateAbilityParam abilityParam) {
        CampaignGroupSaleGroupCalViewDTO calViewDTO = abilityParam.getAbilityTarget();
        ResourcePackageSaleGroupViewDTO saleGroup = abilityParam.getPackageSaleGroupViewDTO();
        //自定义分组只能按金额设置预算
        if (BrandCampaignProductConfigTypeEnum.CUSTOM.getCode().equals(saleGroup.getProductConfigType())) {
            calViewDTO.setBudgetSettingType(BrandSaleGroupBudgetSettingTypeEnum.BUDGET.getCode());
        }else if (calViewDTO.getBudgetSettingType() == null) {
            calViewDTO.setBudgetSettingType(BrandSaleGroupBudgetSettingTypeEnum.RATIO.getCode());
        }
        return null;
    }
}
