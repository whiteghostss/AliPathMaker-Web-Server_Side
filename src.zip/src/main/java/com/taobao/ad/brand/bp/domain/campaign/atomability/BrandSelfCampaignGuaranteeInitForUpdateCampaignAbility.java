package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.guarantee.CampaignGuaranteeViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignGuaranteeInitForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignGuaranteeAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSelfCampaignGuaranteeInitForUpdateCampaignAbility implements ICampaignGuaranteeInitForUpdateCampaignAbility, BrandSelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGuaranteeAbilityParam abilityParam) {
        CampaignGuaranteeViewDTO campaignGuaranteeViewDTO = abilityParam.getAbilityTarget();
        ProductViewDTO productViewDTO = abilityParam.getProductViewDTO();
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        AssertUtil.notNull(campaignGuaranteeViewDTO, "计划保量信息不能为空");
        AssertUtil.notNull(productViewDTO, "产品不能为空");
        AssertUtil.notNull(campaignViewDTO, "计划不能为空");
        AssertUtil.notNull(dbCampaignViewDTO, "计划不存在");

        CampaignGuaranteeViewDTO dbCampaignGuaranteeViewDTO = dbCampaignViewDTO.getCampaignGuaranteeViewDTO();
        campaignGuaranteeViewDTO.setSspRegisterUnit(dbCampaignGuaranteeViewDTO.getSspRegisterUnit());
        campaignGuaranteeViewDTO.setBudgetCampaignId(dbCampaignGuaranteeViewDTO.getBudgetCampaignId());
        campaignGuaranteeViewDTO.setSspControlFlow(dbCampaignGuaranteeViewDTO.getSspControlFlow());
        campaignGuaranteeViewDTO.setIsSettleControl(dbCampaignGuaranteeViewDTO.getIsSettleControl());
        campaignGuaranteeViewDTO.setSspRegisterManner(dbCampaignGuaranteeViewDTO.getSspRegisterManner());
        campaignGuaranteeViewDTO.setCptMaxAmount(dbCampaignGuaranteeViewDTO.getCptMaxAmount());
        if(campaignGuaranteeViewDTO.getSspPushSendRatio() == null){
            campaignGuaranteeViewDTO.setSspPushSendRatio(dbCampaignGuaranteeViewDTO.getSspPushSendRatio());
        }
        if(campaignGuaranteeViewDTO.getIsUnionControlFlow() == null){
            campaignGuaranteeViewDTO.setIsUnionControlFlow(dbCampaignGuaranteeViewDTO.getIsUnionControlFlow());
        }
        //二环CPT：设置预定量
        Integer mediaScope = dbCampaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope();
        Integer registerUnit = dbCampaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterUnit();
        if(BizCampaignToolsHelper.isTwoCPT(mediaScope,registerUnit)){
            //预定量变更，需要清空金额、预定量 、以及询锁量信息
            Long cptAmount = campaignViewDTO.getCampaignGuaranteeViewDTO().getCptAmount();
            Integer unitExposure = productViewDTO.getUnitExposure();
            AssertUtil.assertTrue(unitExposure != null &&  unitExposure>=0 ,"CPT对应保底CPM小于0");
            // 预定量
            campaignGuaranteeViewDTO.setCptAmount(cptAmount);
            campaignGuaranteeViewDTO.setAmount(BigDecimal.valueOf(unitExposure * 1000).multiply(BigDecimal.valueOf(cptAmount)).longValue());
        }else{
            campaignGuaranteeViewDTO.setAmount(dbCampaignGuaranteeViewDTO.getAmount());
            campaignGuaranteeViewDTO.setCptAmount(dbCampaignGuaranteeViewDTO.getCptAmount());
        }
        return null;
    }
}
