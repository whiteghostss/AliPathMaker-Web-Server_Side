package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.unlock.UnlockApplyInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupProcessStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSaleOrderStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleGroupSourceEnum;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.salegroup.SaleGroupSelectJudgeViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.SaleGroupSelectReasonTypeEnum;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupSelectJudgeForOrderCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupOrderAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultSaleGroupSelectJudgeForOrderCampaignGroupAbility implements ISaleGroupSelectJudgeForOrderCampaignGroupAbility {

    private final CampaignGroupRepository campaignGroupRepository;

    private static final List<Integer> contractLockedCampaignGroupStatusList = Lists.newArrayList(
            BrandCampaignGroupStatusEnum.WAIT_CAST.getCode(),
            BrandCampaignGroupStatusEnum.CAST_ING.getCode(),
            BrandCampaignGroupStatusEnum.CAST_FINISH.getCode(),
            BrandCampaignGroupStatusEnum.FINISHED.getCode(),
            BrandCampaignGroupStatusEnum.REAL_SETTLE_ING.getCode(),
            BrandCampaignGroupStatusEnum.REAL_SETTLED.getCode(),
            BrandCampaignGroupStatusEnum.COMPLETED.getCode()
    );

    @Override
    public Map<Long, SaleGroupSelectJudgeViewDTO> handle(ServiceContext serviceContext, SaleGroupOrderAbilityParam abilityParam) {
        List<SaleGroupInfoViewDTO> orderSaleGroupInfoViewDTOList = abilityParam.getAbilityTargets();
        CampaignGroupViewDTO subCampaignGroup = abilityParam.getCampaignGroupViewDTO();
        CampaignGroupViewDTO mainCampaignGroup = null;
        boolean hasSalePlatformSaleGroupIds = orderSaleGroupInfoViewDTOList.stream().anyMatch(saleGroup -> BrandSaleGroupSourceEnum.SALE_PLATFORM.getCode().equals(saleGroup.getSource()));
        if (hasSalePlatformSaleGroupIds) {
            mainCampaignGroup = campaignGroupRepository.getCampaignGroup(serviceContext, subCampaignGroup.getParentId());
        }
        Map<Long, SaleGroupSelectJudgeViewDTO> resultMap = Maps.newHashMap();
        for (SaleGroupInfoViewDTO saleGroup : orderSaleGroupInfoViewDTOList) {
            // 1. 校验分组来源&订单状态
            if (BrandSaleGroupSourceEnum.SALE_PLATFORM.getCode().equals(saleGroup.getSource())) {
                Integer campaignGroupStatus = Optional.ofNullable(mainCampaignGroup).map(CampaignGroupViewDTO::getStatus).orElse(null);
                if (contractLockedCampaignGroupStatusList.contains(campaignGroupStatus)) {
                    buildResultMap(saleGroup.getSaleGroupId(), BrandBoolEnum.BRAND_FALSE.getCode(), SaleGroupSelectReasonTypeEnum.CAST_ING.getCode(), resultMap);
                    continue;
                }
            }
            // 2. 校验分组状态
            if (!BrandCampaignGroupSaleOrderStatusEnum.WAIT_ORDER.getCode().equals(saleGroup.getSaleGroupStatus())) {
                // 1-2 分组是否被拒绝过 > 分组投放状态
                UnlockApplyInfoViewDTO lastUnlockApply = subCampaignGroup.getCampaignGroupUnlockViewDTO().getUnlockApplyInfoViewDTO();
                Integer selectReasonType = null;
                if (lastUnlockApply != null && lastUnlockApply.getSaleGroupIds().contains(saleGroup.getSaleGroupId())
                        && BizCampaignGroupToolsHelper.isRefuse(lastUnlockApply.getStatus())) {
                    selectReasonType = SaleGroupSelectReasonTypeEnum.MODIFY_LAST_REFUSE.getCode();
                } else if (BrandCampaignGroupSaleOrderStatusEnum.ORDER_ING.getCode().equals(saleGroup.getSaleGroupStatus())) {
                    selectReasonType = SaleGroupSelectReasonTypeEnum.ORDER_ING_OR_FINISHED.getCode();
                } else if (BrandCampaignGroupSaleOrderStatusEnum.ORDER_FINISH.getCode().equals(saleGroup.getSaleGroupStatus())) {
                    selectReasonType = SaleGroupSelectReasonTypeEnum.CAST_ING.getCode();
                }
                buildResultMap(saleGroup.getSaleGroupId(), BrandBoolEnum.BRAND_FALSE.getCode(), selectReasonType, resultMap);
                continue;
            }
            // 3. 盘量时间校验
            if (BrandBoolEnum.BRAND_TRUE.getCode().equals(saleGroup.getHasInquiryPriority())
                    && (saleGroup.getInquiryDate() == null || saleGroup.getInquiryDate().after(new Date()))) {
                buildResultMap(saleGroup.getSaleGroupId(), BrandBoolEnum.BRAND_FALSE.getCode(), null, resultMap);
                continue;
            }
            // 可选择
            buildResultMap(saleGroup.getSaleGroupId(), BrandBoolEnum.BRAND_TRUE.getCode(), SaleGroupSelectReasonTypeEnum.WAIT_ORDER.getCode(), resultMap);
        }

        return resultMap;
    }

    private void buildResultMap(Long saleGroupId, Integer canSelect, Integer selectReasonType, Map<Long, SaleGroupSelectJudgeViewDTO> resultMap) {
        SaleGroupSelectJudgeViewDTO selectJudgeViewDTO = new SaleGroupSelectJudgeViewDTO();
        selectJudgeViewDTO.setSaleGroupId(saleGroupId);
        selectJudgeViewDTO.setCanSelect(canSelect);
        selectJudgeViewDTO.setSelectReasonType(selectReasonType);

        resultMap.put(saleGroupId, selectJudgeViewDTO);
    }
}
