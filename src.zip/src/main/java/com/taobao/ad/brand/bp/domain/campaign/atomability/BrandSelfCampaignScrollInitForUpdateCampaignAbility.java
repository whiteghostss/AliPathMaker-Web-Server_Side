package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.scroll.CampaignScrollViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignScrollTypeEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignScrollInitForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignScrollAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSelfCampaignScrollInitForUpdateCampaignAbility implements ICampaignScrollInitForUpdateCampaignAbility, BrandSelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignScrollAbilityParam abilityParam) {
        CampaignScrollViewDTO campaignScrollViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        AssertUtil.notNull(campaignScrollViewDTO, "计划滚量信息不能为空");
        AssertUtil.notNull(campaignViewDTO, "计划信息不能为空");
        AssertUtil.notNull(dbCampaignViewDTO, "计划不存在");

        CampaignScrollViewDTO dbCampaignScrollViewDTO = Optional.ofNullable(dbCampaignViewDTO.getCampaignScrollViewDTO()).orElse(new CampaignScrollViewDTO());
        campaignScrollViewDTO.setScrollOpTime(dbCampaignScrollViewDTO.getScrollOpTime());
        campaignScrollViewDTO.setScrollStartTime(dbCampaignScrollViewDTO.getScrollStartTime());
        campaignScrollViewDTO.setScrollEndTime(dbCampaignScrollViewDTO.getScrollEndTime());
        campaignScrollViewDTO.setScrollType(dbCampaignScrollViewDTO.getScrollType());
        campaignScrollViewDTO.setInitScrollType(dbCampaignScrollViewDTO.getInitScrollType());
        campaignScrollViewDTO.setCastInfoList(dbCampaignScrollViewDTO.getCastInfoList());

        // 如果是周期内滚量，将滚量开始结束时间设置为计划的开始时间 （一期不设置结束时间，一期结算不用）
        if (BrandCampaignScrollTypeEnum.PERIOD_SCROLL.getCode().equals(dbCampaignScrollViewDTO.getScrollType())) {
            campaignScrollViewDTO.setScrollStartTime(campaignViewDTO.getStartTime());
        }
        return null;
    }
}
