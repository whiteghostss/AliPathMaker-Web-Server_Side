package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.unlock.CampaignGroupUnlockViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.unlock.UnlockApplyInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupProcessStatusEnum;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupValidateForApplyModifyAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupUnlockAbilityParam;
import org.springframework.stereotype.Component;

import java.util.Optional;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR;

@Component
@BusinessAbility
public class DefaultCampaignGroupValidateForApplyModifyAbility implements ICampaignGroupValidateForApplyModifyAbility {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupUnlockAbilityParam abilityParam) {
        CampaignGroupUnlockViewDTO campaignGroupUnlockViewDTO = Optional.ofNullable(abilityParam.getAbilityTarget()).orElse(new CampaignGroupUnlockViewDTO());
        UnlockApplyInfoViewDTO unlockApplyInfoViewDTO = campaignGroupUnlockViewDTO.getUnlockApplyInfoViewDTO();
        AssertUtil.assertTrue(unlockApplyInfoViewDTO == null || BizCampaignGroupToolsHelper.isFinish(unlockApplyInfoViewDTO.getStatus()), BIZ_BREAK_RULE_ERROR, "存在审核中的改单申请流程，请审核完成后再申请");

        return null;
    }
}
