package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.customer.CampaignGroupCustomerViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.order.CampaignGroupOrderViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupOrderCommandViewDTO;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CustomerRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupOrderInitForAddCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupOrderInitForOrderCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupOrderAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupOrderInitForOrderAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultCampaignGroupOrderInitForOrderCampaignGroupAbility implements ICampaignGroupOrderInitForOrderCampaignGroupAbility {


    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupOrderInitForOrderAbilityParam abilityParam) {
        CampaignGroupOrderViewDTO campaignGroupOrderViewDTO = Optional.ofNullable(abilityParam.getAbilityTarget()).orElse(new CampaignGroupOrderViewDTO());
        CampaignGroupOrderCommandViewDTO orderCommandViewDTO = new CampaignGroupOrderCommandViewDTO();
        // 初始化下单协议
        if (orderCommandViewDTO.getConfirmedAgreementInfoViewDTO() != null) {
            if (campaignGroupOrderViewDTO.getConfirmedAgreementInfoViewDTOList() == null) {
                campaignGroupOrderViewDTO.setConfirmedAgreementInfoViewDTOList(Lists.newArrayList());
            }
            campaignGroupOrderViewDTO.getConfirmedAgreementInfoViewDTOList().add(orderCommandViewDTO.getConfirmedAgreementInfoViewDTO());
        }
        abilityParam.getCampaignGroupViewDTO().setCampaignGroupOrderViewDTO(campaignGroupOrderViewDTO);

        return null;
    }
}
