package com.taobao.ad.brand.bp.domain.ssp;

import com.taobao.ad.brand.bp.client.dto.site.SiteViewDTO;

import java.util.List;
import java.util.Map;

/**
 * site相关服务
 * @author yuncheng.lyc
 */
public interface SiteRepository {


    /**
     * 获取siteList
     * @param siteIds
     * @return
     */
    List<SiteViewDTO> findBySiteIds(List<Long> siteIds);

    /**
     * 获取siteMap
     * @param siteIds
     * @return
     */
    Map<Long, SiteViewDTO> findMapBySiteIds(List<Long> siteIds);
}
