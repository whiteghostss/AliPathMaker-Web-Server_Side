package com.taobao.ad.brand.bp.domain.adgroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.adgroup.CreativeRefViewDTO;
import com.alibaba.ad.brand.dto.adgroup.resource.AdgroupResourceViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupBottomTypeEnum;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupOnlineStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.nb.ssp.constant.common.CrossSceneEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupDirectCreativeGenerateValidateAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupDirectCreativeGenerateValidateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupDirectCreativeJudgeAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@BusinessAbility
public class BrandSelfAdgroupDirectCreativeGenerateValidateAbility implements IAdgroupDirectCreativeGenerateValidateAbility, BrandSelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, AdgroupDirectCreativeGenerateValidateAbilityParam abilityParam) {
        AdgroupViewDTO adgroupViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(adgroupViewDTO,"单元不存在");
        CampaignViewDTO campaignTreeViewDTO = abilityParam.getCampaignTreeViewDTO();
        AssertUtil.notNull(campaignTreeViewDTO,"计划不存在");
        List<CreativeViewDTO> creativeViewDTOList = abilityParam.getCreativeViewDTOList();
        AssertUtil.notEmpty(creativeViewDTOList, BrandOneBPBaseErrorCode.PARAM_ILLEGAL,"当前计划下没有可使用的创意");

        AssertUtil.notEmpty(adgroupViewDTO.getCreativeRefViewDTOList(), String.format("单元未绑定创意，不支持生成媒体直投创意，id=%s",adgroupViewDTO.getId()));
        List<Long> creativeIdList = adgroupViewDTO.getCreativeRefViewDTOList().stream().filter(creativeRefViewDTO -> BrandBoolEnum.BRAND_TRUE.getCode().equals(creativeRefViewDTO.getOnlineStatus()))
                .map(CreativeRefViewDTO::getCreativeId).distinct().collect(Collectors.toList());
        AssertUtil.notEmpty(creativeIdList, String.format("单元绑定创意已下线，不支持生成媒体直投创意，id=%s",adgroupViewDTO.getId()));

        AssertUtil.assertTrue(Objects.equals(CrossSceneEnum.CROSS_OPAQUE_SCENE.getValue(),campaignTreeViewDTO.getCampaignResourceViewDTO().getSspCrossScene()),
                "非全域通黑盒模式不支持生成媒体直投创意");
        AssertUtil.notEmpty(campaignTreeViewDTO.getSubCampaignViewDTOList(),String.format("主计划关联计划未生成，不做处理，计划id=%s,单元id=%s",adgroupViewDTO.getCampaignId(),adgroupViewDTO.getId()));

        return null;
    }
}
