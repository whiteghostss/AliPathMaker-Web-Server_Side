package com.taobao.ad.brand.bp.domain.creative.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.creative.materialgroup.MaterialGroupViewDTO;
import com.alibaba.ad.brand.dto.creative.materialgroup.MaterialViewDTO;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandMaterialGroupTypeEnum;
import com.alibaba.ad.nb.ssp.constant.template.ElementTypeEnum;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeMalusTemplateViewDTO;
import com.taobao.ad.brand.bp.common.constant.TemplateConstant;
import com.taobao.ad.brand.bp.domain.creative.spi.BizCreativeMaterialGroupSpi;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.ICreativeMalusTemplateElementMaterialGroupConvertAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeMalusTemplateElementMaterialGroupConvertAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.common.spi.ExtensionPointsFactory.runAbilitySpi;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultCreativeMalusTemplateElementMaterialGroupConvertAbility implements ICreativeMalusTemplateElementMaterialGroupConvertAbility {

    @Override
    public List<MaterialGroupViewDTO> handle(ServiceContext serviceContext, CreativeMalusTemplateElementMaterialGroupConvertAbilityParam abilityParam) {
        CreativeMalusTemplateViewDTO malusTemplateViewDTO = abilityParam.getAbilityTarget();
        Map<String, Object> malusConvergeElementMap = abilityParam.getMalusConvergeElementMap();

        //获取模板业务数据
        Map<String, Map<String, Object>> templateBizMap = getTemplateBizMap(malusTemplateViewDTO);

        List<MaterialGroupViewDTO> resultMaterialGroupViewDTOList = Lists.newArrayList();
        for (Map.Entry<String, Object> convergeElementEntry : malusConvergeElementMap.entrySet()) {
            Map<String, Object> elementMap = templateBizMap.get(convergeElementEntry.getKey());
            if (elementMap == null) {
                continue;
            }
            ElementTypeEnum elementTypeEnum = ElementTypeEnum.getEnum(elementMap.get(TemplateConstant.CONSTANT_KEY_TYPE).toString());
            String spiBizCode = Objects.isNull(elementTypeEnum) ? ElementTypeEnum.TXT.getCode() : elementTypeEnum.getCode();
            List<MaterialGroupViewDTO> materialGroupViewDTOList = runAbilitySpi(BizCreativeMaterialGroupSpi.class,
                    extension -> extension.malusConvertToMaterialGroup(serviceContext, convergeElementEntry), spiBizCode);
            Optional.ofNullable(materialGroupViewDTOList).ifPresent(resultMaterialGroupViewDTOList::addAll);
        }

        //多个视觉生成多个素材组，多个共享元素生成一个素材组
        List<MaterialGroupViewDTO> materialGroupList = resultMaterialGroupViewDTOList.stream()
                .filter(materialGroupViewDTO -> BrandMaterialGroupTypeEnum.VISUAL.getCode().equals(materialGroupViewDTO.getGroupType()))
                .collect(Collectors.toList());

        List<MaterialViewDTO> otherMaterialList = resultMaterialGroupViewDTOList.stream()
                .filter(materialGroupViewDTO -> BrandMaterialGroupTypeEnum.OTHER.getCode().equals(materialGroupViewDTO.getGroupType()))
                .flatMap(materialGroupViewDTO -> materialGroupViewDTO.getMaterialViewDTOList().stream()).collect(Collectors.toList());
        if(CollectionUtils.isNotEmpty(otherMaterialList)){
            MaterialGroupViewDTO otherMaterialGroupViewDTO = new MaterialGroupViewDTO();
            otherMaterialGroupViewDTO.setGroupType(BrandMaterialGroupTypeEnum.OTHER.getCode());
            otherMaterialGroupViewDTO.setMaterialViewDTOList(otherMaterialList);
            materialGroupList.add(otherMaterialGroupViewDTO);
        }
        return materialGroupList;
    }

    /**
     * 获取海棠模板业务map定义
     * @param malusTemplateViewDTO
     * @return
     */
    private Map<String, Map<String, Object>> getTemplateBizMap(CreativeMalusTemplateViewDTO malusTemplateViewDTO){
        JSONObject jsonObject = JSON.parseObject(malusTemplateViewDTO.getTemplateData());
        Map<String, Map<String, Object>> bizMap = (Map<String, Map<String, Object>>) jsonObject.get(TemplateConstant.CONSTANT_KEY_BIZ_MAP);
        return bizMap;
    }
}
