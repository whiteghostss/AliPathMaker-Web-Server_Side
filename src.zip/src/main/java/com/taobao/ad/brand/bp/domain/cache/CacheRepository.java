package com.taobao.ad.brand.bp.domain.cache;

import java.io.Serializable;

/**
 * @author 虫洞 <liuming.liu@alibaba-inc.com>
 * @date 2023/6/5
 */
public interface CacheRepository {
    /**
     * 新增缓存
     *
     * @param key
     * @param value
     */
    void put(String key, Serializable value);

    /**
     * 新增缓存
     *
     * @param key
     * @param value
     * @param expire
     */
    void put(String key, Serializable value, int expire);

    /**
     * 失效缓存
     *
     * @param key
     */
    void delete(String key);

    /**
     * 查询缓存
     *
     * @param key
     * @return
     */
    Object get(String key);
}
