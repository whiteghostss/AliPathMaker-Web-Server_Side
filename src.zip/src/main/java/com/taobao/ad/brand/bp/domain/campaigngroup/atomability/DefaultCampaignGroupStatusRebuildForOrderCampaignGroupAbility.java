package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.taobao.ad.brand.bp.common.constant.campaigngroup.CampaignGroupConstant;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupStatusRebuildForOrderCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupAbilityParam;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
@BusinessAbility
public class DefaultCampaignGroupStatusRebuildForOrderCampaignGroupAbility implements ICampaignGroupStatusRebuildForOrderCampaignGroupAbility {

    @Override
    public Integer handle(ServiceContext serviceContext, CampaignGroupAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        Integer currentStatus = campaignGroupViewDTO.getStatus();
        Integer targetStatus = null;
        if (CampaignGroupConstant.campaignGroupCastStatusList.contains(currentStatus)) {
            Date now = new Date();
            if (BrandDateUtil.isAfterAndEqual(now, campaignGroupViewDTO.getStartTime())
                    && BrandDateUtil.isBeforeAndEqual(now, campaignGroupViewDTO.getEndTime())) {
                targetStatus = BrandCampaignGroupStatusEnum.CAST_ING.getCode();
            } else if (BrandDateUtil.isBefore(now, campaignGroupViewDTO.getStartTime())) {
                targetStatus = BrandCampaignGroupStatusEnum.WAIT_CAST.getCode();
            } else if (BrandDateUtil.isAfter(now, campaignGroupViewDTO.getEndTime())) {
                targetStatus = BrandCampaignGroupStatusEnum.CAST_FINISH.getCode();
            }
        }

        return targetStatus;
    }
}
