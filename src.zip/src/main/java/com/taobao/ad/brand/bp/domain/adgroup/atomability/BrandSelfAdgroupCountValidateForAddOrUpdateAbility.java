package com.taobao.ad.brand.bp.domain.adgroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.adgroup.resource.AdgroupResourceViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupBottomTypeEnum;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupPriorityEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.alibaba.ad.nb.ssp.constant.common.CrossSceneEnum;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.pub.DimensionConfigRuleViewDTO;
import com.taobao.ad.brand.bp.client.enums.DimensionTypeEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.adgroup.constant.AdgroupCreateValidateConstant;
import com.taobao.ad.brand.bp.domain.adgroup.repository.AdgroupRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.config.SaleProductLineDimensionConfig;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupCountValidateForAddOrUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupInitForUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupCountValidateForAddOrUpdateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupInitForUpdateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Objects;
import java.util.Optional;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR;

@Component
@BusinessAbility
public class BrandSelfAdgroupCountValidateForAddOrUpdateAbility implements IAdgroupCountValidateForAddOrUpdateAbility,
    BrandSelfServiceAtomAbilityRouter {
    @Resource
    private  AdgroupRepository adgroupRepository;
    @Resource
    private  SaleProductLineDimensionConfig saleProductLineDimensionConfig;
    @Override
    public Void handle(ServiceContext serviceContext, AdgroupCountValidateForAddOrUpdateAbilityParam abilityParam) {
        AdgroupViewDTO adgroupViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();

        //全域通黑盒只能有一个打底单元
        if (Objects.isNull(adgroupViewDTO.getId()) && adgroupViewDTO.getBottomType().equals(BrandAdgroupBottomTypeEnum.BOTTOM.getCode())){
            Integer sspCrossScene = Optional.ofNullable(adgroupViewDTO.getAdgroupResourceViewDTO()).map(AdgroupResourceViewDTO::getSspCrossScene).orElse(null);
            if (Objects.equals(sspCrossScene, CrossSceneEnum.CROSS_OPAQUE_SCENE.getValue())){
                AdgroupQueryViewDTO adgroupQueryViewDTO = new AdgroupQueryViewDTO();
                adgroupQueryViewDTO.setCampaignId(campaignViewDTO.getId());
                adgroupQueryViewDTO.setBottomType(BrandAdgroupBottomTypeEnum.BOTTOM.getCode());
                Integer count = adgroupRepository.count(serviceContext,adgroupQueryViewDTO);
                AssertUtil.assertTrue(count <= 0,"计划%s下的打底单元数量数量最大为1个，请检查",campaignViewDTO.getTitle());
            }
        }

        //校验程序化单元的最大数量
        if (adgroupViewDTO.getBottomType().equals(BrandAdgroupBottomTypeEnum.NORMAL.getCode())){

            DimensionConfigRuleViewDTO dimensionConfigRuleViewDTO = saleProductLineDimensionConfig.getDimensionConfigRuleViewDTO(campaignViewDTO.getCampaignSaleViewDTO().getSaleProductLine(), DimensionTypeEnum.ADGROUP.getValue());
            if (Objects.nonNull(dimensionConfigRuleViewDTO)){
                AdgroupQueryViewDTO adgroupQueryViewDTO = new AdgroupQueryViewDTO();
                adgroupQueryViewDTO.setCampaignId(campaignViewDTO.getId());
                Integer count = adgroupRepository.count(serviceContext,adgroupQueryViewDTO);
                Long maxCount = dimensionConfigRuleViewDTO.getMaxCount();
                if (!Objects.equals(null,maxCount) && !Objects.equals(-1L,maxCount)){
                    AssertUtil.assertTrue(count <= maxCount,"计划%s下的程序化单元数量数量最大为%s个，请检查",campaignViewDTO.getTitle(),maxCount);
                }
            }
        }
        return null;
    }
}
