package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.CampaignGroupSaleViewDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupSaleAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@BusinessAbility
public class SelfServiceCampaignGroupSaleInitForUpdateCampaignGroupAbility extends DefaultCampaignGroupSaleInitForUpdateCampaignGroupAbility
        implements SelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupSaleAbilityParam abilityParam) {
        CampaignGroupSaleViewDTO campaignGroupSaleViewDTO = abilityParam.getAbilityTarget();
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        if (campaignGroupSaleViewDTO != null) {
            // 销售信息
            List<String> relevantSales = Lists.newArrayList();
            if (CollectionUtils.isNotEmpty(campaignGroupSaleViewDTO.getDirectSales())) {
                relevantSales.addAll(campaignGroupSaleViewDTO.getDirectSales());
            }
            if (CollectionUtils.isNotEmpty(campaignGroupSaleViewDTO.getChannelSales())) {
                relevantSales.addAll(campaignGroupSaleViewDTO.getChannelSales());
            }
            campaignGroupSaleViewDTO.setRelevantSales(relevantSales);
        }
        campaignGroupViewDTO.setCampaignGroupSaleViewDTO(campaignGroupSaleViewDTO);

        return null;
    }
}
