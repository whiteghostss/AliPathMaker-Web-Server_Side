package com.taobao.ad.brand.bp.domain.dmp;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.dto.dmp.ItemMetricsViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.query.GoodsItemQueryViewDTO;

import java.util.List;

/**
 * 商品相关查询服务
 **/
public interface GoodsItemRepository {

    List<ItemMetricsViewDTO> findGoodsItemList(ServiceContext context, GoodsItemQueryViewDTO queryViewDTO);


    List<ItemMetricsViewDTO> findItemMetrics(ServiceContext context, GoodsItemQueryViewDTO queryViewDTO);
}
