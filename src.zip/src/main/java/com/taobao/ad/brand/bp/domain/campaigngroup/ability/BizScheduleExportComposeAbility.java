package com.taobao.ad.brand.bp.domain.campaigngroup.ability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.context.ScheduleExportContext;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.export.ComposeResultViewDTO;
import com.taobao.ad.brand.bp.common.spi.ExtensionPointsFactory;
import com.taobao.ad.brand.bp.domain.campaigngroup.spi.export.BizScheduleExportComposeSpi;
import org.springframework.stereotype.Service;


/**
 * @author jixiu.lj
 * @date 2023/3/29 15:33
 */
@Service
public class BizScheduleExportComposeAbility {

    /**
     * MR数据过滤
     *
     * @param scheduleExportContext
     * @param spiCode
     */
    public ComposeResultViewDTO compose(ServiceContext serviceContext, ScheduleExportContext scheduleExportContext, String spiCode) {
        return ExtensionPointsFactory.runAbilitySpi(BizScheduleExportComposeSpi.class, extension -> extension.compose(serviceContext, scheduleExportContext), spiCode);
    }

}
