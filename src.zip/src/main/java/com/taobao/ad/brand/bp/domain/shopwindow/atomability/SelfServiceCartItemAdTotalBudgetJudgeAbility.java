package com.taobao.ad.brand.bp.domain.shopwindow.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.taobao.ad.brand.bp.client.dto.rule.RuleCheckResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandBundleViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.ICartItemAdTotalBudgetJudgeAbility;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.param.CartItemAdTotalBudgetJudgeAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCartItemAdTotalBudgetJudgeAbility implements ICartItemAdTotalBudgetJudgeAbility, SelfServiceAtomAbilityRouter {

    @Override
    public RuleCheckResultViewDTO handle(ServiceContext serviceContext, CartItemAdTotalBudgetJudgeAbilityParam abilityParam) {
        Long totalBudget = abilityParam.getAbilityTarget();
        AssertUtil.notNull(totalBudget,"投放金额不能为空");
        BrandBundleViewDTO bundleViewDTO = abilityParam.getBundleViewDTO();
        if(bundleViewDTO != null){
            if(totalBudget < bundleViewDTO.getMinTotalBudget() || totalBudget > bundleViewDTO.getMaxTotalBudget()){
                return RuleCheckResultViewDTO.builder().isPass(BrandBoolEnum.BRAND_FALSE.getCode())
                        .reason("您设置的投放金额不满足套餐包要求的投放金额，请调整投放金额").build();
            }
        }
        return RuleCheckResultViewDTO.builder().isPass(BrandBoolEnum.BRAND_TRUE.getCode()).build();
    }
}
