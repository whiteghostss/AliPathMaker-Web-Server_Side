package com.taobao.ad.brand.bp.domain.promotion;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.sellercoupons.SellerCouponViewDTO;
import com.taobao.ad.brand.bp.client.dto.sellercoupons.SellerCouponsQueryViewDTO;

import java.util.List;

/**
 * @Author: PhilipFry
 * @createTime: 2023年09月14日 14:51:24
 * @Description:
 */
public interface PromotionRepository {
    /**
     * 查询商家券
     */
    PageResultViewDTO<SellerCouponViewDTO> querySellerCouponsList(ServiceContext context, SellerCouponsQueryViewDTO queryViewDTO);
}
