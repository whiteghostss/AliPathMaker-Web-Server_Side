package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;


import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.complete.CampaignGroupCompleteConfigViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.setting.BrandCampaignGroupSettingKeyEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.SalesContractRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupCompleteConfigSaveAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupCompleteConfigAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2025/3/31
 **/
@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultCampaignGroupCompleteConfigSaveAbility implements ICampaignGroupCompleteConfigSaveAbility {

    private final CampaignGroupRepository campaignGroupRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupCompleteConfigAbilityParam abilityParam) {
        CampaignGroupCompleteConfigViewDTO campaignGroupCompleteConfigViewDTO = abilityParam.getAbilityTarget();
        CampaignGroupViewDTO campaignGroup = abilityParam.getCampaignGroupViewDTO();

        CampaignGroupViewDTO updateCampaignGroup = new CampaignGroupViewDTO();
        updateCampaignGroup.setId(campaignGroup.getId());

        updateCampaignGroup.setCampaignGroupCompleteConfigViewDTO(campaignGroupCompleteConfigViewDTO);
        campaignGroupRepository.updateCampaignGroupPart(serviceContext, updateCampaignGroup);
        // 品牌信息支持清空
        if (CollectionUtils.isEmpty(campaignGroupCompleteConfigViewDTO.getBrandViewDTOList())) {
            campaignGroupRepository.deleteCampaignGroupSettingBatch(serviceContext, campaignGroup.getId(), Lists.newArrayList(BrandCampaignGroupSettingKeyEnum.BRAND_INFO_LIST.getKey()));
        }
        return null;
    }
}
