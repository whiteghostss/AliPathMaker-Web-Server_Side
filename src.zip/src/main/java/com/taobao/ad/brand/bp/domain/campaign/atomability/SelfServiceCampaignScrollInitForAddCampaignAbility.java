package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.scroll.CampaignScrollViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignScrollTypeEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignScrollInitForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignScrollAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCampaignScrollInitForAddCampaignAbility implements ICampaignScrollInitForAddCampaignAbility, SelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignScrollAbilityParam abilityParam) {
        CampaignScrollViewDTO campaignScrollViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();
        AssertUtil.notNull(campaignScrollViewDTO, "计划滚量信息不能为空");
        AssertUtil.notNull(campaignViewDTO, "计划信息不能为空");

        campaignScrollViewDTO.setScrollOpTime(new Date());
        campaignScrollViewDTO.setScrollType(BrandCampaignScrollTypeEnum.PERIOD_SCROLL.getCode());
        campaignScrollViewDTO.setInitScrollType(BrandCampaignScrollTypeEnum.PERIOD_SCROLL.getCode());
        campaignScrollViewDTO.setScrollStartTime(campaignViewDTO.getStartTime());
        campaignViewDTO.setCampaignScrollViewDTO(campaignScrollViewDTO);
        return null;
    }
}
