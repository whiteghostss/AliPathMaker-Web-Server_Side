package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.biz.definition.constants.Product;
import com.alibaba.ad.biz.definition.constants.UniversalCampaignModel;
import com.alibaba.ad.biz.definition.constants.UniversalCampaignType;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.*;
import com.alibaba.ad.nb.packages.v2.client.constant.product.CastTypeEnum;
import com.alibaba.ad.nb.ssp.constant.common.CrossSceneEnum;
import com.alibaba.ad.nb.ssp.constant.common.MediaScopeEnum;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignBaseInitForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBaseAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_REQUIRED;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandCampaignBaseInitForAddCampaignAbility implements ICampaignBaseInitForAddCampaignAbility, BrandAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignBaseAbilityParam abilityParam) {
        CampaignViewDTO campaignViewDTO = abilityParam.getAbilityTarget();
        ResourcePackageProductViewDTO resourcePackageProductViewDTO = abilityParam.getResourcePackageProductViewDTO();
        ProductViewDTO productViewDTO = abilityParam.getProductViewDTO();
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        AssertUtil.notNull(campaignViewDTO, PARAM_REQUIRED, "计划不能为空");
        AssertUtil.notNull(resourcePackageProductViewDTO, PARAM_REQUIRED, "资源产品不能为空");
        AssertUtil.notNull(productViewDTO, PARAM_REQUIRED, "产品不能为空");
        AssertUtil.notNull(campaignGroupViewDTO, PARAM_REQUIRED, "订单不能为空");

        campaignViewDTO.setMemberId(campaignGroupViewDTO.getMemberId());
        campaignViewDTO.setProductLineId(Product.BRAND_ONEBP_BRAND.getProductLineId());
        campaignViewDTO.setSceneId(ServiceContextUtil.getSceneId(serviceContext));

        campaignViewDTO.setCampaignGroupId(campaignGroupViewDTO.getId());
        campaignViewDTO.setMainCampaignGroupId(campaignGroupViewDTO.getParentId());
        if (campaignViewDTO.getStatus() == null ){
            campaignViewDTO.setStatus(BrandCampaignStatusEnum.NEW.getCode());
        }
        // 默认在线
        campaignViewDTO.setOnlineStatus(BrandCampaignOnlineStatusEnum.ONLINE.getCode());
        // 一级计划
        campaignViewDTO.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
        // 计费类型
        Integer saleUnit = resourcePackageProductViewDTO.getSaleUnit() == null ?  productViewDTO.getSellUnit() : resourcePackageProductViewDTO.getSaleUnit();
        UniversalCampaignType campaignType = getCampaignType(saleUnit,productViewDTO.getMediaScope(), productViewDTO.getProgrammatic());
        AssertUtil.notNull(campaignType, "计费类型不能为空");
        campaignViewDTO.setCampaignType(campaignType.getId());
        // 投放方式
        Integer castType = BizCampaignToolsHelper.getCampaignCastType(campaignViewDTO, resourcePackageProductViewDTO);
        Integer pushRatio = campaignViewDTO.getCampaignGuaranteeViewDTO() != null ? campaignViewDTO.getCampaignGuaranteeViewDTO().getSspPushSendRatio() : null;
        UniversalCampaignModel campaignModel = getCampaignModel(productViewDTO.getMediaScope(), castType, pushRatio,saleUnit,productViewDTO.getProductLineId(), productViewDTO.getProgrammatic(), productViewDTO.getCrossScene());
        AssertUtil.notNull(campaignModel, "投放方式不能为空");
        campaignViewDTO.setCampaignModel(campaignModel.getId());

        // 是否系统投放
        campaignViewDTO.setSspProgrammatic(productViewDTO.getProgrammatic() == null ? BrandCampaignProgrammaticEnum.SYSTEM_CAST.getCode() : productViewDTO.getProgrammatic());

        return null;
    }

    /**
     * 获取计费类型
     *
     * @param registerUnit SSP产品预定单位
     * @param programmatic 是否系统投放
     */
    private UniversalCampaignType getCampaignType(Integer registerUnit, Integer mediaScope, Integer programmatic) {
        if (BrandCampaignProgrammaticEnum.UN_SYSTEM_CAST.getCode().equals(programmatic)) {
            return UniversalCampaignType.BRAND_CPD;
        }
        BrandCampaignRegisterUnitEnum registerUnitEnum = BrandCampaignRegisterUnitEnum.getByCode(registerUnit);
        AssertUtil.notNull(registerUnitEnum, "预定单位不存在");
        switch (registerUnitEnum) {
            case CPM:
                return UniversalCampaignType.BRAND_CPM;
            case CPC:
                return UniversalCampaignType.BRAND_CPC;
            case JUMP:
                return UniversalCampaignType.BRAND_LANDING;
            case ROUND:
            case DAY:
            case SECTION:
            case COLLECTION:
                if(MediaScopeEnum.SITE_OUT.getCode().equals(mediaScope)){
                    return UniversalCampaignType.BRAND_CPM;
                }else{
                    return UniversalCampaignType.BRAND_CPT;
                }
            default:
                return null;
        }
    }

    /**
     * 获取投放方式
     *
     * @param mediaScope   SSP媒体流量域
     * @param castType     资源包二级产品投放方式
     * @param programmatic
     */
    private UniversalCampaignModel getCampaignModel(Integer mediaScope, Integer castType, Integer pushSendRatio,Integer registerUnit,Integer sspProductLineId, Integer programmatic, Integer sspCrossScene) {
        if (BrandCampaignProgrammaticEnum.UN_SYSTEM_CAST.getCode().equals(programmatic)) {
            return UniversalCampaignModel.TAO_BRAND_PLACE_HOLDER;
        }
        CastTypeEnum castTypeEnum = CastTypeEnum.getEnum(castType);
        AssertUtil.notNull(castTypeEnum, "资源产品投放方式不能为空");
        // 跨域 && GD
        if (MediaScopeEnum.CROSS_SCOPE.getCode().equals(mediaScope)) {
            if (sspCrossScene == null || sspCrossScene == CrossSceneEnum.CROSS_SCENE.getValue()) {
                return UniversalCampaignModel.TAO_CROSS_GD;
            } else if (sspCrossScene == CrossSceneEnum.CROSS_OPAQUE_SCENE.getValue()) {
                return UniversalCampaignModel.TAO_CROSS_BLACK;
            } else if (sspCrossScene == CrossSceneEnum.TAOBAO_INNER_SCENE.getValue() || sspCrossScene == CrossSceneEnum.TAOBAO_INNER_LITE_SCENE.getValue()) {
                return UniversalCampaignModel.TAO_CROSS_TX_SHOWMAX_PACKAGE;
            }
        }
        // 二环
        if (MediaScopeEnum.TAO_OUT.getCode().equals(mediaScope)) {
            //PDB投放使用新的CampaignModel，CPT投放复用TAO_ECOLOGY_TWO_GD
            if(CastTypeEnum.PDB.equals(castTypeEnum)){
                return UniversalCampaignModel.TAO_ECOLOGY_TWO_PDB;
            }
            return UniversalCampaignModel.TAO_ECOLOGY_TWO_GD;
        }

        // 三环 && PDB && 有退返
        if (MediaScopeEnum.SITE_OUT.getCode().equals(mediaScope) && CastTypeEnum.PDB.equals(castTypeEnum)
                && Objects.nonNull(pushSendRatio)) {
            return UniversalCampaignModel.TAO_OUT_THREE_PDB;
        }
        // 三环 && PDB && 无退返
        if (MediaScopeEnum.SITE_OUT.getCode().equals(mediaScope) && CastTypeEnum.PDB.equals(castTypeEnum)) {
            return UniversalCampaignModel.TAO_OUT_THREE_GD;
        }
        // 三环 && PD
        if (MediaScopeEnum.SITE_OUT.getCode().equals(mediaScope) && CastTypeEnum.PD.equals(castTypeEnum)) {
            return UniversalCampaignModel.TAO_OUT_THREE_PD;
        }
        if (MediaScopeEnum.SITE_OUT.getCode().equals(mediaScope)&& CastTypeEnum.GUARANTEE.equals(castTypeEnum)) {
            return UniversalCampaignModel.TAO_OUT_THREE_GD;
        }

        if (BizCampaignToolsHelper.isTXorShowmaxCampaign(mediaScope,sspProductLineId)) {
            return UniversalCampaignModel.TAO_IN_ONE_TX_GD;
        }

        //CPT特殊逻辑
        BrandCampaignRegisterUnitEnum registerUnitEnum = BrandCampaignRegisterUnitEnum.getByCode(registerUnit);
        AssertUtil.notNull(registerUnitEnum, "预定单位不存在");
        if(registerUnitEnum.equals(BrandCampaignRegisterUnitEnum.ROUND)
                || registerUnitEnum.equals(BrandCampaignRegisterUnitEnum.DAY)
                || registerUnitEnum.equals(BrandCampaignRegisterUnitEnum.SECTION)
                ||registerUnitEnum.equals(BrandCampaignRegisterUnitEnum.COLLECTION)){
            if(MediaScopeEnum.SITE_OUT.getCode().equals(mediaScope)){
                return UniversalCampaignModel.TAO_OUT_THREE_GD;
            }
        }
        return null;
    }
}
