package com.taobao.ad.brand.bp.domain.adgroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryOption;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.domain.adgroup.repository.AdgroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.query.IAdgroupStructurePageQueryAbility;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Optional;

@Component
@BusinessAbility
public class DefaultAdgroupStructurePageQueryAbility implements IAdgroupStructurePageQueryAbility {
    @Resource
    private AdgroupRepository adgroupRepository;
    @Resource
    private DefaultAdgroupStructureQueryAbility defaultAdgroupStructureQueryAbility;

    @Override
    public PageResultViewDTO<AdgroupViewDTO> handle(ServiceContext serviceContext, AdgroupStructureQueryAbilityParam abilityParam) {
        AdgroupQueryViewDTO query = abilityParam.getAbilityTarget();
        AdgroupQueryOption option = Optional.ofNullable(abilityParam.getQueryOption()).orElse(new AdgroupQueryOption());
        //查询单元
        PageResultViewDTO<AdgroupViewDTO> pageResultViewDTO =  adgroupRepository.queryAdgroupPageList(serviceContext,query);
        if (CollectionUtils.isEmpty(pageResultViewDTO.getList())) {
            return pageResultViewDTO;
        }
        defaultAdgroupStructureQueryAbility.processAdgroupInfo(serviceContext, pageResultViewDTO.getList(), option);
        return pageResultViewDTO;
    }
}
