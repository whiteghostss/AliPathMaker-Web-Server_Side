package com.taobao.ad.brand.bp.domain.mediarule;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.media.mutex.MediaMutexRuleViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.mediarule.query.MediaMutexRuleQueryViewDTO;

import java.util.List;

/**
 * 互斥规则
 * @author linhua.deng
 * @date 2023/7/20
 */
public interface MediaMutexRuleRepository {
    /**
     * 新增
     *
     * @param serviceContext
     * @param viewDTO
     * @return
     */
    Long addMutexRule(ServiceContext serviceContext, MediaMutexRuleViewDTO viewDTO);

    /**
     * 编辑
     *
     * @param serviceContext
     * @param viewDTO
     * @return
     */
    Integer updateMutexRule(ServiceContext serviceContext, MediaMutexRuleViewDTO viewDTO);

    /**
     * 频控状态修改
     *
     * @param serviceContext
     * @param ids
     * @param status
     * @return
     */
    Integer updateMutexRuleStatus(ServiceContext serviceContext, List<Long> ids, Integer status);

    /**
     * 查询单条数据
     *
     * @param serviceContext
     * @param id
     * @return
     */
    MediaMutexRuleViewDTO getMutexRule(ServiceContext serviceContext, Long id);

    /**
     * 分页查询数据
     *
     * @param serviceContext
     * @param queryViewDTO
     * @return
     */
    PageResultViewDTO<MediaMutexRuleViewDTO> findMutexRuleList(ServiceContext serviceContext, MediaMutexRuleQueryViewDTO queryViewDTO);

    /**
     * 查询匹配的全部数据
     * @param serviceContext
     * @param queryViewDTO
     * @return
     */
    List<MediaMutexRuleViewDTO> findList(ServiceContext serviceContext, MediaMutexRuleQueryViewDTO queryViewDTO);
    /**
     * 根据名称查询互斥规则
     * @param serviceContext
     * @param uniqueName
     * @return
     */
    MediaMutexRuleViewDTO getTopOneByName(ServiceContext serviceContext, String uniqueName);
}
