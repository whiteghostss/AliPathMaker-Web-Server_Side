package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.SalesBriefRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupModifyBriefAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupTransitAbilityParam;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
@BusinessAbility
public class BrandOneBPCampaignGroupModifyBriefAbility implements ICampaignGroupModifyBriefAbility, BrandOneBPAtomAbilityRouter {

    @Resource
    private SalesBriefRepository salesBriefRepository;


    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupTransitAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        if (!BizCampaignGroupToolsHelper.isSaleCampaignGroup(campaignGroupViewDTO)) {
            return null;
        }
        salesBriefRepository.modifyBrief(campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getBriefId());
        return null;
    }

}
