package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleGroupSourceEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupOrderCommandViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.salegroup.SaleGroupCheckedRebuildResultViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupCheckedSaleGroupRebuildForOrderCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupCheckedSaleGroupRebuildForOrderAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
@BusinessAbility
public class BrandOneBPCampaignGroupCheckedSaleGroupRebuildForOrderCampaignGroupAbility
        extends DefaultCampaignGroupCheckedSaleGroupRebuildForOrderCampaignGroupAbility implements BrandOneBPAtomAbilityRouter {

    @Override
    public SaleGroupCheckedRebuildResultViewDTO handle(ServiceContext serviceContext, CampaignGroupCheckedSaleGroupRebuildForOrderAbilityParam abilityParam) {
        SaleGroupCheckedRebuildResultViewDTO rebuildResultViewDTO = new SaleGroupCheckedRebuildResultViewDTO();
        List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList = abilityParam.getSubCampaignGroupList().stream()
                .flatMap(subCampaignGroup -> subCampaignGroup.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream())
                .collect(Collectors.toList());

        rebuildResultViewDTO.setSalePlatformSaleGroupIds(saleGroupInfoViewDTOList.stream()
                .filter(t -> BrandSaleGroupSourceEnum.SALE_PLATFORM.getCode().equals(t.getSource()))
                .map(SaleGroupInfoViewDTO::getSaleGroupId).collect(Collectors.toList()));
        rebuildResultViewDTO.setCalOrderSaleGroupIds(rebuildResultViewDTO.getSalePlatformSaleGroupIds());

        return rebuildResultViewDTO;
    }
}
