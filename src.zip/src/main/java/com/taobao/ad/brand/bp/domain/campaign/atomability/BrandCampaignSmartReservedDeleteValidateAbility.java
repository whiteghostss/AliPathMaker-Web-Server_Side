package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignModelEnum;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignSmartReservedDeleteValidateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignDeleteValidateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandCampaignSmartReservedDeleteValidateAbility implements ICampaignSmartReservedDeleteValidateAbility, BrandAtomAbilityRouter {

    private final CampaignRepository campaignRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignDeleteValidateAbilityParam abilityParam) {
        CampaignViewDTO dbCampaign = abilityParam.getAbilityTarget();
        AssertUtil.notNull(dbCampaign, BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR,"未找到对应计划");
        // 校验该计划也没有被别的配送计划关联（当前订单）
        CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder()
                .campaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode())
                .campaignGroupId(dbCampaign.getCampaignGroupId())
                .campaignModel(BrandCampaignModelEnum.TAO_ECOLOGY_TWO_PDB.getCode()).build();
        List<CampaignViewDTO> campaignViewDTOS = campaignRepository.queryCampaignList(serviceContext, campaignQueryViewDTO);
        List<Long> refCampaignIdList = campaignViewDTOS.stream()
                .filter(it -> dbCampaign.getId().equals(it.getCampaignSmartReservedViewDTO().getCopyOtherCampaignId()))
                .map(it -> it.getId()).collect(Collectors.toList());
        AssertUtil.assertTrue(CollectionUtils.isEmpty(refCampaignIdList), BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR,
                "该计划已经被计划"+ StringUtils.join(refCampaignIdList, ",")  +"复用了pubDeal，需先删除复用关系，再进行删除。");
        return null;
    }
}
