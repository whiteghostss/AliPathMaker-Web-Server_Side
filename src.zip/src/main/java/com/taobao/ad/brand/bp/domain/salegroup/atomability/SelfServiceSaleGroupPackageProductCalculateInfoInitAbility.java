package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.price.DayPriceViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.ResourcePackageProductViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizSaleGroupToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupPackageProductCalculateInfoInitAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupPackageProductCalculateInfoInitAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceSaleGroupPackageProductCalculateInfoInitAbility
        implements ISaleGroupPackageProductCalculateInfoInitAbility, SelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, SaleGroupPackageProductCalculateInfoInitAbilityParam abilityParam) {
        List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList = abilityParam.getAbilityTargets();
        if (CollectionUtils.isEmpty(saleGroupInfoViewDTOList)) {
            return null;
        }
        Map<Long, List<CampaignViewDTO>> saleGroupCampaignMap = abilityParam.getSaleGroupCampaignMap();
        Map<Long, ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupMap = abilityParam.getResourcePackageSaleGroupMap();
        saleGroupInfoViewDTOList.forEach(saleGroupInfoViewDTO -> {
            List<CampaignViewDTO> saleGroupCampaignList = saleGroupCampaignMap.getOrDefault(saleGroupInfoViewDTO.getSaleGroupId(), Lists.newArrayList());
            Map<Long, List<CampaignViewDTO>> resourceProductCampaignMap = saleGroupCampaignList.stream().collect(Collectors.groupingBy(item -> item.getCampaignSaleViewDTO().getResourcePackageProductId()));
            List<ResourcePackageProductViewDTO> campaignGroupResourcePackageProductViewDTOList = Lists.newArrayList();
            // 资源包分组
            ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO = resourcePackageSaleGroupMap.get(saleGroupInfoViewDTO.getSaleGroupId());
            Map<Long, List<DayPriceViewDTO>> productDayPriceViewDTOMap = BizSaleGroupToolsHelper.getProductDayPriceViewDTOMap(resourcePackageSaleGroupViewDTO);
            // 资源包分组二级产品List
            List<com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO> resourcePackageProductList = resourcePackageSaleGroupViewDTO.getDistributionRuleList().stream().flatMap(item -> item.getResourcePackageProductList().stream()).collect(Collectors.toList());
            for (com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO resourcePackageProductViewDTO : resourcePackageProductList) {
                if (!resourceProductCampaignMap.containsKey(resourcePackageProductViewDTO.getId())) {
                    continue;
                }

                List<CampaignViewDTO> resourcePackageCampaignList = resourceProductCampaignMap.get(resourcePackageProductViewDTO.getId());
                ResourcePackageProductViewDTO campaignGroupResourcePackageProductViewDTO = new ResourcePackageProductViewDTO();
                campaignGroupResourcePackageProductViewDTO.setResourcePackageProductId(resourcePackageProductViewDTO.getId());
                Long resourceCalBudget =  resourcePackageCampaignList.stream().mapToLong(item->item.getCampaignBudgetViewDTO().getDiscountTotalMoney()).sum();
                campaignGroupResourcePackageProductViewDTO.setBudget(resourceCalBudget);
                campaignGroupResourcePackageProductViewDTO.setDiscountDayPriceInfoViewDTOList(productDayPriceViewDTOMap.get(resourcePackageProductViewDTO.getId()));
                campaignGroupResourcePackageProductViewDTOList.add(campaignGroupResourcePackageProductViewDTO);
            }
            saleGroupInfoViewDTO.setResourcePackageProductViewDTOList(campaignGroupResourcePackageProductViewDTOList);
        });

        return null;
    }
}
