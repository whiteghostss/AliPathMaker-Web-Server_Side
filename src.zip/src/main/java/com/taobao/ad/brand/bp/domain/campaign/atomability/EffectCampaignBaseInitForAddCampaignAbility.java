package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.biz.definition.constants.Product;
import com.alibaba.ad.biz.definition.constants.UniversalCampaignModel;
import com.alibaba.ad.biz.definition.constants.UniversalCampaignType;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignOnlineStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.EffectAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignBaseInitForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBaseAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_REQUIRED;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EffectCampaignBaseInitForAddCampaignAbility implements ICampaignBaseInitForAddCampaignAbility, EffectAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignBaseAbilityParam abilityParam) {
        CampaignViewDTO campaignViewDTO = abilityParam.getAbilityTarget();
        ResourcePackageProductViewDTO resourcePackageProductViewDTO = abilityParam.getResourcePackageProductViewDTO();
        ProductViewDTO productViewDTO = abilityParam.getProductViewDTO();
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        AssertUtil.notNull(campaignViewDTO, PARAM_REQUIRED, "计划不能为空");
        AssertUtil.notNull(resourcePackageProductViewDTO, PARAM_REQUIRED, "资源产品不能为空");
        AssertUtil.notNull(productViewDTO, PARAM_REQUIRED, "产品不能为空");
        AssertUtil.notNull(campaignGroupViewDTO, PARAM_REQUIRED, "订单不能为空");

        campaignViewDTO.setMemberId(campaignGroupViewDTO.getMemberId());
        campaignViewDTO.setProductLineId(Product.BRAND_ONEBP_EFFECT.getProductLineId());
        campaignViewDTO.setSceneId(ServiceContextUtil.getSceneId(serviceContext));

        campaignViewDTO.setCampaignGroupId(campaignGroupViewDTO.getId());
        campaignViewDTO.setMainCampaignGroupId(campaignGroupViewDTO.getParentId());

        if(BrandDateUtil.isBefore(BrandDateUtil.getCurrentDate(), resourcePackageProductViewDTO.getStartTime())){
            campaignViewDTO.setStartTime(resourcePackageProductViewDTO.getStartTime());
        }else{
            campaignViewDTO.setStartTime(BrandDateUtil.getTomorrowDate());
        }
        campaignViewDTO.setEndTime(BrandDateUtil.getDateFullMidnight(resourcePackageProductViewDTO.getEndTime()));

        // 默认在线
        campaignViewDTO.setOnlineStatus(BrandCampaignOnlineStatusEnum.ONLINE.getCode());
        // 计费类型
        campaignViewDTO.setCampaignType(UniversalCampaignType.BRAND_RTA.getId());
        // 计划模型
        campaignViewDTO.setCampaignModel(UniversalCampaignModel.TAO_OUT_EFFECT_AGENCY.getId());
        // 品牌产品线
        campaignViewDTO.setProductLineId(Product.BRAND_ONEBP_EFFECT.getProductLineId());
        // 新建状态，默认锁量成功
        campaignViewDTO.setStatus(BrandCampaignStatusEnum.LOCK_SUCCESS.getCode());
        // 一级计划
        campaignViewDTO.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
        // 是否系统投放
        campaignViewDTO.setSspProgrammatic(productViewDTO.getProgrammatic());

        return null;
    }
}
