package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.CrowdViewDTO;
import com.taobao.ad.brand.bp.domain.dmp.CrowdRepository;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupCrowdQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupCrowdQueryAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultSaleGroupCrowdQueryAbility implements ISaleGroupCrowdQueryAbility {

    private final CrowdRepository crowdRepository;

    @Override
    public List<CrowdViewDTO> handle(ServiceContext context, SaleGroupCrowdQueryAbilityParam abilityParam) {
        SaleGroupInfoViewDTO saleGroupInfoViewDTO = abilityParam.getAbilityTarget();
        return crowdRepository.queryCrowdByIds(context, saleGroupInfoViewDTO.getCrowdIds());
    }
}
