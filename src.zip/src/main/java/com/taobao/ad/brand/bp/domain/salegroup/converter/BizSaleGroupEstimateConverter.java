package com.taobao.ad.brand.bp.domain.salegroup.converter;

import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupEstimateInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleProductLineEnum;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupEstimateInfoViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import com.taobao.ad.brand.bp.domain.salegroup.converter.mapstruct.BizSaleGroupEstimateMapStruct;
import org.springframework.stereotype.Component;


/**
 * @author yunhu.myh@taobao.com
 * @date 2023年07月28日
 */
@Component
public class BizSaleGroupEstimateConverter extends BaseViewDTOConverter<SaleGroupEstimateInfoViewDTO, CampaignGroupSaleGroupEstimateInfoViewDTO> {

    @Override
    public BaseMapStructMapper<SaleGroupEstimateInfoViewDTO, CampaignGroupSaleGroupEstimateInfoViewDTO> getBaseMapStructMapper() {
        return BizSaleGroupEstimateMapStruct.INSTANCE;
    }

    public CampaignGroupSaleGroupEstimateInfoViewDTO convertDTO2ViewDTO(SaleGroupInfoViewDTO saleGroupInfoViewDTO) {
        CampaignGroupSaleGroupEstimateInfoViewDTO estimateInfoViewDTO = super.convertDTO2ViewDTO(saleGroupInfoViewDTO.getSaleGroupEstimateInfoViewDTO());
        if(estimateInfoViewDTO != null){
            estimateInfoViewDTO.setSaleGroupId(saleGroupInfoViewDTO.getSaleGroupId());
            if (saleGroupInfoViewDTO.getSaleProductLine().equals(SaleProductLineEnum.SHOW_MAX.getValue())){
                estimateInfoViewDTO.setIsShowMax(BrandBoolEnum.BRAND_TRUE.getCode());
            }else{
                estimateInfoViewDTO.setIsShowMax(BrandBoolEnum.BRAND_FALSE.getCode());
            }
        }
        return estimateInfoViewDTO;
    }
}
