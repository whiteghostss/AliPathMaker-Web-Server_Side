package com.taobao.ad.brand.bp.domain.campaign.util;

import com.taobao.ad.brand.bp.common.constant.Constant;
import lombok.Builder;

import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * 自助场景spu
 */
@Builder
public class SelfCampaignTitleBuilder {
    private Long id;
    private String spuName;
    private String skuName;
    private String bundleName;
    private String cartItemId;
    private String startTime;
    private String endTime;
    private String distinctValue;
    final int MAX_LENGTH = 100;

    /**
     * Campaign Title最大长度为100
     * 名字过长的情况下按照 SKU -> 套餐包 -> SPU 的顺序删减
     * */
    public String getNormalizedName() {
        init();
        String result = generateTitle();
        if (result.length() <= MAX_LENGTH) {
            return result;
        }
        // 尝试删减SKU字段
        if (skuName != null && result.length() - skuName.length() + 2 <= MAX_LENGTH) {
            int gap = result.length() - MAX_LENGTH;
            skuName = skuName.substring(0, skuName.length() - gap);
        } else {
            skuName = null;
        }
        result = generateTitle();
        if (result.length() <= MAX_LENGTH) {
            return result;
        }
        // 尝试删减套餐包字段
        if (bundleName != null && result.length() - bundleName.length() + 2 <= MAX_LENGTH) {
            int gap = result.length() - MAX_LENGTH;
            bundleName = bundleName.substring(0, bundleName.length() - gap);
        } else {
            bundleName = null;
        }
        result = generateTitle();
        if (result.length() <= MAX_LENGTH) {
            return result;
        }
        // 尝试删减SPU字段
        if (spuName != null && result.length() - spuName.length() + 2 <= MAX_LENGTH) {
            int gap = result.length() - MAX_LENGTH;
            spuName = spuName.substring(0, spuName.length() - gap);
        } else {
            spuName = null;
        }
        return generateTitle();
    }

    private void init() {
        // 初始化 distinctValue
        String idStr = (id != null) ? id.toString() : "";
        distinctValue = !idStr.isEmpty() && idStr.length() >= 6 ? idStr.substring(idStr.length() - 6)
                : String.format("%06d", (this.hashCode() & Integer.MAX_VALUE) % 1000000);
        // 去除特殊符号
        spuName = removeSpecialCharacters(spuName);
        skuName = removeSpecialCharacters(skuName);
        bundleName = removeSpecialCharacters(bundleName);
    }

    public String removeSpecialCharacters(String input) {
        // 使用正则表达式匹配并替换非数字、字母、汉字、下划线、中划线的字符
        String result = Optional.ofNullable(input)
                .map(str -> str.replaceAll("[^\\w\u4e00-\u9fa5-\\s]", ""))
                .orElse(null);
        return result;
    }

    private String generateTitle() {
        return Stream.of(spuName, skuName, bundleName,startTime, endTime,cartItemId, distinctValue)
                .filter(value -> value != null && !value.isEmpty())
                .collect(Collectors.joining(Constant.UNDERLINE));
    }
}


