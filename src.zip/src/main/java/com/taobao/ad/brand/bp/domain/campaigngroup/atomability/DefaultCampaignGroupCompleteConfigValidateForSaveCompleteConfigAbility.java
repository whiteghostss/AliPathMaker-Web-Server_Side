package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;


import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.complete.CampaignGroupCompleteConfigViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupTypeEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.enums.BooleanEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupCompleteConfigValidateForSaveCompleteConfigAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupCompleteConfigAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2025/3/31
 **/
@Component
@BusinessAbility
public class DefaultCampaignGroupCompleteConfigValidateForSaveCompleteConfigAbility implements ICampaignGroupCompleteConfigValidateForSaveCompleteConfigAbility {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupCompleteConfigAbilityParam abilityParam) {
        CampaignGroupCompleteConfigViewDTO campaignGroupCompleteConfigViewDTO = abilityParam.getAbilityTarget();
        CampaignGroupViewDTO dbCampaignGroup = abilityParam.getCampaignGroupViewDTO();
        AssertUtil.notNull(campaignGroupCompleteConfigViewDTO, "参数不能为空");

        AssertUtil.notNull(campaignGroupCompleteConfigViewDTO.getNeedExportDataBank(), "是否需要回流不能为空");
        AssertUtil.notNull(campaignGroupCompleteConfigViewDTO.getShopViewDTO(), "店铺不能为空");
        if (BooleanEnum.TRUE.getValue().equals(campaignGroupCompleteConfigViewDTO.getNeedExportDataBank())) {
            AssertUtil.assertTrue(CollectionUtils.isNotEmpty(campaignGroupCompleteConfigViewDTO.getBrandViewDTOList()), "回流时品牌不能为空");
        }

        AssertUtil.assertTrue(BrandCampaignGroupTypeEnum.SELF.getCode().equals(dbCampaignGroup.getType()), "非“自助营销”订单不支持该操作");
        // 订单状态
        AssertUtil.assertTrue(Lists.newArrayList(
                BrandCampaignGroupStatusEnum.ORDER_ING.getCode(),
                BrandCampaignGroupStatusEnum.RESOURCE_CONFIRM_ING.getCode(),
                BrandCampaignGroupStatusEnum.CONTRACT_PROCESS_ING.getCode(),
                BrandCampaignGroupStatusEnum.WAIT_CAST.getCode()
        ).contains(dbCampaignGroup.getStatus()), "当前订单状态不支持该操作");
        return null;
    }
}
