package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignValidateForDeleteCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignValidateForDeleteCampaignGroupAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultCampaignValidateForDeleteCampaignGroupAbility implements ICampaignValidateForDeleteCampaignGroupAbility {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignValidateForDeleteCampaignGroupAbilityParam abilityParam) {
        if (CollectionUtils.isEmpty(abilityParam.getAbilityTargets())) {
            return null;
        }
        AssertUtil.assertTrue(false, "当前营销场景不允许删除订单");
        return null;
    }
}
