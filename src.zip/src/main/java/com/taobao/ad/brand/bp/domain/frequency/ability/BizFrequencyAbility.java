package com.taobao.ad.brand.bp.domain.frequency.ability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.frequency.FrequencyRuleViewDTO;
import com.alibaba.ad.brand.dto.frequency.FrequencyViewDTO;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupTargetTypeEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignFrequencyTargetEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignOnlineStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.frequency.field.BrandFrequencyBizTypeEnum;
import com.alibaba.ad.brand.sdk.constant.frequency.field.BrandFrequencyTargetEnum;
import com.alibaba.hermes.framework.utils.BeanUtils;
import com.alibaba.hermes.framework.utils.DateUtils;
import com.alibaba.solar.common.utils.DateUtil;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.FrequencyQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.FrequencyRefViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.adgroup.repository.AdgroupRepository;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.frequency.repository.FrequencyRepository;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_ILLEGAL;


@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizFrequencyAbility {
    private final ResourcePackageRepository resourcePackageRepository;
    private final FrequencyRepository frequencyRepository;
    private final CampaignRepository campaignRepository;
//    private final AdgroupRepository adgroupRepository;

    public void initFrequencyForAdd(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO, List<CampaignViewDTO> campaignViewDTOList, List<AdgroupViewDTO> adgroupViewDTOList) {
        frequencyViewDTO.setProductId(serviceContext.getProductId());
        frequencyViewDTO.setMemberId(serviceContext.getMemberId());
        // 上线状态
        frequencyViewDTO.setOnlineStatus(BrandBoolEnum.BRAND_TRUE.getCode());
        // 频控日期
        frequencyViewDTO.setStartTime(BrandDateUtil.getCurrentDate());
        frequencyViewDTO.setEndTime(BrandDateUtil.getCurrentDate());
        if (CollectionUtils.isNotEmpty(campaignViewDTOList)) {
            Date startTime = campaignViewDTOList.stream().min(Comparator.comparing(it -> it.getStartTime())).get().getStartTime();
            Date endTime = campaignViewDTOList.stream().max(Comparator.comparing(it -> it.getEndTime())).get().getEndTime();
            frequencyViewDTO.setStartTime(startTime);
            frequencyViewDTO.setEndTime(endTime);
        }
        if (CollectionUtils.isNotEmpty(adgroupViewDTOList)) {
            Date startTime = adgroupViewDTOList.stream().min(Comparator.comparing(AdgroupViewDTO::getStartTime)).get().getStartTime();
            Date endTime = adgroupViewDTOList.stream().max(Comparator.comparing(AdgroupViewDTO::getEndTime)).get().getEndTime();
            frequencyViewDTO.setStartTime(startTime);
            frequencyViewDTO.setEndTime(endTime);
        }
        if (CollectionUtils.isNotEmpty(frequencyViewDTO.getFrequencyRuleViewDTOList())) {
            for (FrequencyRuleViewDTO ruleViewDTO : frequencyViewDTO.getFrequencyRuleViewDTOList()) {
                ruleViewDTO.setProductId(serviceContext.getProductId());
                ruleViewDTO.setMemberId(serviceContext.getMemberId());
                ruleViewDTO.setStatus(BrandCampaignOnlineStatusEnum.ONLINE.getCode());
            }
        }
    }

    public void initFrequencyForUpdate(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO, FrequencyViewDTO dbFrequency, List<CampaignViewDTO> campaignViewDTOList, List<AdgroupViewDTO> adgroupViewDTOList) {
        if (CollectionUtils.isNotEmpty(frequencyViewDTO.getFrequencyRuleViewDTOList())) {
            for (FrequencyRuleViewDTO ruleViewDTO : frequencyViewDTO.getFrequencyRuleViewDTOList()) {
                ruleViewDTO.setProductId(serviceContext.getProductId());
                ruleViewDTO.setMemberId(serviceContext.getMemberId());
                ruleViewDTO.setStatus(BrandCampaignOnlineStatusEnum.ONLINE.getCode());
                ruleViewDTO.setFreqId(frequencyViewDTO.getId());
            }
        }
        dbFrequency.setFrequencyTarget(frequencyViewDTO.getFrequencyTarget());
        dbFrequency.setFreqName(frequencyViewDTO.getFreqName());
        dbFrequency.setFrequencyRuleViewDTOList(frequencyViewDTO.getFrequencyRuleViewDTOList());
        // 频控日期
        dbFrequency.setStartTime(BrandDateUtil.getCurrentDate());
        dbFrequency.setEndTime(BrandDateUtil.getCurrentDate());
        if (CollectionUtils.isNotEmpty(campaignViewDTOList)) {
            Date startTime = campaignViewDTOList.stream().min(Comparator.comparing(it -> it.getStartTime())).get().getStartTime();
            Date endTime = campaignViewDTOList.stream().max(Comparator.comparing(it -> it.getEndTime())).get().getEndTime();
            dbFrequency.setStartTime(startTime);
            dbFrequency.setEndTime(endTime);
        }
        if (CollectionUtils.isNotEmpty(adgroupViewDTOList)) {
            Date startTime = adgroupViewDTOList.stream().min(Comparator.comparing(AdgroupViewDTO::getStartTime)).get().getStartTime();
            Date endTime = adgroupViewDTOList.stream().max(Comparator.comparing(AdgroupViewDTO::getEndTime)).get().getEndTime();
            dbFrequency.setStartTime(startTime);
            dbFrequency.setEndTime(endTime);
        }

    }

    /**
     * 新增联合频控
     * @param serviceContext
     * @param frequencyViewDTO
     * @param campaignViewDTOList
     * @return
     */
    public Long addFrequency(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO, List<CampaignViewDTO> campaignViewDTOList, List<AdgroupViewDTO> adgroupViewDTOList) {
        // 初始化
        initFrequencyForAdd(serviceContext, frequencyViewDTO, campaignViewDTOList, adgroupViewDTOList);
        // 执行
        return doAddFrequency(serviceContext, frequencyViewDTO, campaignViewDTOList, adgroupViewDTOList);
    }

    public Long doAddFrequency(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO, List<CampaignViewDTO> campaignViewDTOList, List<AdgroupViewDTO> adgroupViewDTOList) {
        Long frequencyId = frequencyRepository.addFrequency(serviceContext, frequencyViewDTO);
        frequencyViewDTO.setId(frequencyId);
        // 保存ref
        if (CollectionUtils.isNotEmpty(campaignViewDTOList)) {
            saveCampaignFreqRef(serviceContext, frequencyViewDTO, campaignViewDTOList);
        }
        if (CollectionUtils.isNotEmpty(adgroupViewDTOList)) {
            saveAdgroupFreqRef(serviceContext, frequencyViewDTO, adgroupViewDTOList.stream().map(AdgroupViewDTO::getId).collect(Collectors.toList()));
        }
        return frequencyId;
    }

    /**
     * 更新联合频控
     *
     * @param serviceContext
     * @param frequencyViewDTO
     * @param dbFrequency
     * @param campaignTreeViewDTOList
     * @return
     */
    public Integer updateFrequency(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO, FrequencyViewDTO dbFrequency, List<CampaignViewDTO> campaignTreeViewDTOList, List<AdgroupViewDTO> adgroupViewDTOList) {
        // 初始化
        initFrequencyForUpdate(serviceContext, frequencyViewDTO, dbFrequency, campaignTreeViewDTOList, adgroupViewDTOList);
        // 执行更新
        frequencyRepository.updateFrequencyAll(serviceContext, dbFrequency);
        // 保存关联关系
        if (CollectionUtils.isNotEmpty(adgroupViewDTOList)) {
            saveAdgroupFreqRef(serviceContext, dbFrequency, adgroupViewDTOList.stream().map(AdgroupViewDTO::getId).collect(Collectors.toList()));
        }
        if (CollectionUtils.isNotEmpty(campaignTreeViewDTOList)) {
            saveCampaignFreqRef(serviceContext, dbFrequency, campaignTreeViewDTOList);
        }
        return 1;
    }



    public void saveCampaignFreqRef(ServiceContext serviceContext, FrequencyViewDTO dbFrequency, List<CampaignViewDTO> campaignTreeViewDTOList) {
        if (CollectionUtils.isEmpty(campaignTreeViewDTOList)) {
            return;
        }
        List<Long> parentCampaignIdList = campaignTreeViewDTOList.stream().map(campaignViewDTO -> campaignViewDTO.getId()).collect(Collectors.toList());
        //新增ref
        if (CollectionUtils.isNotEmpty(parentCampaignIdList)) {
            //一级计划
            frequencyRepository.deleteCampaignFreqRef(serviceContext, parentCampaignIdList);
            frequencyRepository.saveCampaignFreqRef(serviceContext, dbFrequency.getId(), parentCampaignIdList);
            Map<Long, CampaignViewDTO> map = campaignTreeViewDTOList.stream().collect(
                    Collectors.toMap(m -> m.getId(), v -> v, (o1, o2) -> o1));
            for (Long parentCampaignId: parentCampaignIdList) {
                //二级计划
                if (map.containsKey(parentCampaignId) && CollectionUtils.isNotEmpty(map.get(parentCampaignId).getSubCampaignViewDTOList())) {
                    List<Long> subCampaignIds = map.get(parentCampaignId).getSubCampaignViewDTOList().stream().map(e-> e.getId()).collect(Collectors.toList());
                    frequencyRepository.deleteCampaignFreqRef(serviceContext, subCampaignIds);
                    frequencyRepository.saveCampaignFreqRef(serviceContext, dbFrequency.getId(), subCampaignIds);
                }
            }
        }
    }

    public void saveAdgroupFreqRef(ServiceContext serviceContext, FrequencyViewDTO dbFrequency, List<Long> adgroupIdList) {
        //新增ref
        if (CollectionUtils.isNotEmpty(adgroupIdList)) {
            frequencyRepository.deleteAdgroupFreqRef(serviceContext, adgroupIdList);
            frequencyRepository.saveAdgroupFreqRef(serviceContext, dbFrequency.getId(), adgroupIdList);
        }
    }

//    public void deleteCampaignFreqRef(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList) {
//        if (CollectionUtils.isEmpty(campaignViewDTOList)) {
//            return;
//        }
//        List<Long> campaignIdList = campaignViewDTOList.stream().map(campaignViewDTO -> campaignViewDTO.getId()).collect(Collectors.toList());
//        //新增ref
//        if (CollectionUtils.isNotEmpty(campaignIdList)) {
//            //一级计划
//            frequencyRepository.deleteCampaignFreqRef(serviceContext, campaignIdList);
//            Map<Long, CampaignViewDTO> map = campaignViewDTOList.stream().collect(
//                    Collectors.toMap(m -> m.getId(), v -> v, (o1, o2) -> o1));
//            for (Long campaignId: campaignIdList) {
//                //二级计划
//                List<Long> subCampaignIds = map.get(campaignId).getSubCampaignViewDTOList().stream().map(e-> e.getId()).collect(Collectors.toList());
//                frequencyRepository.deleteCampaignFreqRef(serviceContext, subCampaignIds);
//            }
//        }
//    }


//    public Long saveUnionFrequency(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO, List<CampaignViewDTO> campaignViewDTOList){
//        List<Long> campaignIdList = campaignViewDTOList.stream().map(campaignViewDTO -> campaignViewDTO.getId()).collect(Collectors.toList());
//        // 新增
//        if (Objects.isNull(frequencyViewDTO.getId())) {
//            frequencyViewDTO.setProductId(serviceContext.getProductId());
//            frequencyViewDTO.setMemberId(serviceContext.getMemberId());
//            // 联合频控
//            Integer unionFreqType = BrandFrequencyUnionTypeEnum.UNION.getCode();
//            frequencyViewDTO.setFrequencyUnionType(unionFreqType);
//            // 上线状态
//            frequencyViewDTO.setOnlineStatus(BrandBoolEnum.BRAND_TRUE.getCode());
//            // 频控日期
//            frequencyViewDTO.setStartTime(BrandDateUtil.getCurrentDate());
//            frequencyViewDTO.setEndTime(BrandDateUtil.getCurrentDate());
//            if (CollectionUtils.isNotEmpty(campaignViewDTOList)) {
//                Date startTime = campaignViewDTOList.get(0).getStartTime();
//                Date endTime = campaignViewDTOList.get(0).getEndTime();
//                for (CampaignViewDTO campaignViewDTO: campaignViewDTOList) {
//                    startTime = BrandDateUtil.isBefore(campaignViewDTO.getStartTime(), startTime)? campaignViewDTO.getStartTime(): startTime;
//                    endTime = BrandDateUtil.isAfter(campaignViewDTO.getEndTime(), endTime)? campaignViewDTO.getEndTime(): endTime;
//                }
//                frequencyViewDTO.setStartTime(startTime);
//                frequencyViewDTO.setEndTime(endTime);
//            }
//            // 频控规则
//            if (CollectionUtils.isNotEmpty(frequencyViewDTO.getFrequencyRuleViewDTOList())) {
//                for (FrequencyRuleViewDTO ruleViewDTO : frequencyViewDTO.getFrequencyRuleViewDTOList()) {
//                    ruleViewDTO.setProductId(serviceContext.getProductId());
//                    ruleViewDTO.setMemberId(serviceContext.getMemberId());
//                    ruleViewDTO.setStatus(BrandCampaignOnlineStatusEnum.ONLINE.getCode());
//                }
//            }
//            Long frequencyId = frequencyRepository.addFrequency(serviceContext, frequencyViewDTO);
//            if (CollectionUtils.isNotEmpty(campaignViewDTOList)) {
//                //一级计划
//                frequencyRepository.deleteCampaignFreqRef(serviceContext, campaignIdList);
//                frequencyRepository.saveCampaignFreqRef(serviceContext, frequencyId, campaignIdList);
//                //二级计划
//                for (CampaignViewDTO campaignViewDTO: campaignViewDTOList) {
//                    if (CollectionUtils.isNotEmpty(campaignViewDTO.getSubCampaignViewDTOList())) {
//                        List<Long> subCampaignIds = campaignViewDTO.getSubCampaignViewDTOList().stream().map(e -> e.getId()).collect(Collectors.toList());
//                        frequencyRepository.deleteCampaignFreqRef(serviceContext, subCampaignIds);
//                        frequencyRepository.saveCampaignFreqRef(serviceContext, frequencyId, subCampaignIds);
//                    }
//                }
//            }
//            return frequencyId;
//        }
//        // 修改
//        else {
//            Long freqId = frequencyViewDTO.getId();
//            FrequencyViewDTO dbFrequency = frequencyRepository.getFrequencyById(serviceContext, freqId);
//            if (CollectionUtils.isNotEmpty(frequencyViewDTO.getFrequencyRuleViewDTOList())) {
//                for (FrequencyRuleViewDTO ruleViewDTO : frequencyViewDTO.getFrequencyRuleViewDTOList()) {
//                    ruleViewDTO.setProductId(serviceContext.getProductId());
//                    ruleViewDTO.setMemberId(serviceContext.getMemberId());
//                    ruleViewDTO.setStatus(BrandCampaignOnlineStatusEnum.ONLINE.getCode());
//                    ruleViewDTO.setFreqId(freqId);
//                }
//            }
//            dbFrequency.setFrequencyTarget(frequencyViewDTO.getFrequencyTarget());
//            dbFrequency.setFreqName(frequencyViewDTO.getFreqName());
//            dbFrequency.setFrequencyRuleViewDTOList(frequencyViewDTO.getFrequencyRuleViewDTOList());
//            // 频控日期
//            dbFrequency.setStartTime(BrandDateUtil.getCurrentDate());
//            dbFrequency.setEndTime(BrandDateUtil.getCurrentDate());
//            if (CollectionUtils.isNotEmpty(campaignViewDTOList)) {
//                Date startTime = campaignViewDTOList.get(0).getStartTime();
//                Date endTime = campaignViewDTOList.get(0).getEndTime();
//                for (CampaignViewDTO campaignViewDTO: campaignViewDTOList) {
//                    startTime = BrandDateUtil.isBefore(campaignViewDTO.getStartTime(), startTime)? campaignViewDTO.getStartTime(): startTime;
//                    endTime = BrandDateUtil.isAfter(campaignViewDTO.getEndTime(), endTime)? campaignViewDTO.getEndTime(): endTime;
//                }
//                dbFrequency.setStartTime(startTime);
//                dbFrequency.setEndTime(endTime);
//            }
//            frequencyRepository.updateFrequencyAll(serviceContext, dbFrequency);
//            Map<Long, CampaignViewDTO> map = campaignViewDTOList.stream().collect(
//                    Collectors.toMap(m -> m.getId(), v -> v, (o1, o2) -> o1));
//            //删除ref，交付型计划新建独立频控
//            FrequencyRefViewDTO frequencyRefViewDTO = frequencyRepository.findFrequencyRefByFreqId(serviceContext, freqId);
//            deleteCampaignRef(serviceContext, frequencyRefViewDTO, campaignIdList, campaignViewDTOList, dbFrequency);
//            //新增ref
//            if (CollectionUtils.isNotEmpty(campaignIdList)) {
//                //一级计划
//                frequencyRepository.deleteCampaignFreqRef(serviceContext, campaignIdList);
//                frequencyRepository.saveCampaignFreqRef(serviceContext, freqId, campaignIdList);
//                for (Long campaignId: campaignIdList) {
//                    //二级计划
//                    List<Long> subCampaignIds = map.get(campaignId).getSubCampaignViewDTOList().stream().map(e-> e.getId()).collect(Collectors.toList());
//                    frequencyRepository.deleteCampaignFreqRef(serviceContext, subCampaignIds);
//                    frequencyRepository.saveCampaignFreqRef(serviceContext, freqId, subCampaignIds);
//                }
//            }
//            return freqId;
//        }
//    }

//    public void addAntiUnionFrequency(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO, List<CampaignViewDTO> deleteCampaignViewDTOList) {
//        for (CampaignViewDTO deleteCampaign : deleteCampaignViewDTOList) {
//            // 解除关联的每个交付型计划新建一个独立频控
//            if (BrandCampaignFrequencyTargetEnum.PROMISE.getCode().equals(deleteCampaign.getCampaignExtViewDTO().getCampaignFrequencyTarget())) {
//                FrequencyViewDTO newFrequencyDTO = BeanUtils.copyIgnoreNull(frequencyViewDTO, new FrequencyViewDTO());
//                // 初始化
//                initAntiUnionFrequencyForAdd(newFrequencyDTO, deleteCampaign);
//                // 执行新增
//                doAddFrequency(serviceContext, newFrequencyDTO, Lists.newArrayList(deleteCampaign), null);
//            }
//        }
//    }

//    private void initAntiUnionFrequencyForAdd(FrequencyViewDTO newFrequencyDTO, CampaignViewDTO campaignViewDTO) {
//        StringBuilder name = new StringBuilder();
//        for (FrequencyRuleViewDTO frequencyRuleViewDTO : newFrequencyDTO.getFrequencyRuleViewDTOList()) {
//            name.append("_");
//            name.append(Integer.valueOf(-1).equals(frequencyRuleViewDTO.getFreqPeriod()) ? "投放期" : frequencyRuleViewDTO.getFreqPeriod() + "天");
//            name.append(frequencyRuleViewDTO.getFreqLimit() + "次");
//        }
//        newFrequencyDTO.setFreqName("新建频控" +  name + "_" + DateUtils.dateTimeOf(new Date()));
////        newFrequencyDTO.setFreqName(campaignViewDTO.getTitle() + "_计划频控");
//        newFrequencyDTO.setId(null);
//        newFrequencyDTO.setStartTime(campaignViewDTO.getStartTime());
//        newFrequencyDTO.setEndTime(campaignViewDTO.getEndTime());
//        newFrequencyDTO.setFrequencyTarget(BrandFrequencyTargetEnum.PROMISE.getCode());
//        newFrequencyDTO.getFrequencyRuleViewDTOList().forEach(e -> e.setFreqId(null));
//    }

    public List<Long> deleteOtherUnionFrequencyCampaignRef(ServiceContext serviceContext, FrequencyRefViewDTO dbFrequencyRefViewDTO, List<CampaignViewDTO> campaignTreeViewDTOList) {
        List<Long> deleteCampaignIds = Lists.newArrayList();
        if (Objects.nonNull(dbFrequencyRefViewDTO) && CollectionUtils.isNotEmpty(dbFrequencyRefViewDTO.getCampaignIdList())) {
            List<Long> frequencyCampaignIds = new ArrayList<>();
            for (CampaignViewDTO campaignViewDTO: campaignTreeViewDTOList) {
                frequencyCampaignIds.add(campaignViewDTO.getId());
                if (CollectionUtils.isNotEmpty(campaignViewDTO.getSubCampaignViewDTOList())) {
                    for (CampaignViewDTO subCampaignViewDTO: campaignViewDTO.getSubCampaignViewDTOList()) {
                        frequencyCampaignIds.add(subCampaignViewDTO.getId());
                    }
                }
            }
            //解除关联的计划id
            deleteCampaignIds = dbFrequencyRefViewDTO.getCampaignIdList().stream().filter(e -> !frequencyCampaignIds.contains(e)).collect(Collectors.toList());
            if (CollectionUtils.isNotEmpty(deleteCampaignIds)) {
                //删除计划联合频控ref
                frequencyRepository.deleteCampaignFreqRef(serviceContext, deleteCampaignIds);
            }
        }

        return deleteCampaignIds;
    }

    public List<Long> deleteOtherFrequencyAdgroupRef(ServiceContext serviceContext, FrequencyRefViewDTO dbFrequencyRefViewDTO, List<AdgroupViewDTO> adgroupViewDTOList) {
        List<Long> deleteAdgroupIds = Lists.newArrayList();
        if (Objects.nonNull(dbFrequencyRefViewDTO) && CollectionUtils.isNotEmpty(dbFrequencyRefViewDTO.getAdgroupIdList())) {
            List<Long> frequencyAdgroupIds = adgroupViewDTOList.stream().map(AdgroupViewDTO::getId).collect(Collectors.toList());
            //解除关联的计划id
            deleteAdgroupIds = dbFrequencyRefViewDTO.getAdgroupIdList().stream().filter(e -> !frequencyAdgroupIds.contains(e)).collect(Collectors.toList());
            frequencyRepository.deleteAdgroupFreqRef(serviceContext, deleteAdgroupIds);
        }
        return deleteAdgroupIds;
    }

    public FrequencyViewDTO getFrequencyById(ServiceContext serviceContext, Long id) {
        return frequencyRepository.getFrequencyById(serviceContext, id);
    }

    public FrequencyRefViewDTO findFrequencyRefByFreqId(ServiceContext serviceContext, Long frequencyId, BrandFrequencyBizTypeEnum frequencyBizTypeEnum) {
        return frequencyRepository.findFrequencyRefByFreqId(serviceContext, frequencyId, frequencyBizTypeEnum.getCode());
    }

    /**
     * 联合频控上线/下线
     *
     * @param serviceContext
     * @param frequencyViewDTO
     * @param dbFrequencyViewDTO
     */
    public void updateFrequencyOnlineStatus(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO, FrequencyViewDTO dbFrequencyViewDTO) {
        if (frequencyViewDTO.getOnlineStatus().equals(dbFrequencyViewDTO.getOnlineStatus())) {
            return;
        }
        dbFrequencyViewDTO.setOnlineStatus(frequencyViewDTO.getOnlineStatus());
        frequencyRepository.updateFrequencyAll(serviceContext, dbFrequencyViewDTO);
    }

    public void validateSaveDeliveredFrequency(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO, List<CampaignViewDTO> campaignViewDTOList, FrequencyRefViewDTO dbFrequencyRefViewDTO, FrequencyViewDTO dbFrequencyViewDTO) {
        long count = frequencyViewDTO.getFrequencyRuleViewDTOList().stream().map(FrequencyRuleViewDTO::getFreqPeriod).distinct().count();
        AssertUtil.assertTrue(frequencyViewDTO.getFrequencyRuleViewDTOList().size() == (int) count, PARAM_ILLEGAL, "计划频控周期类型不能重复");
        AssertUtil.assertTrue(campaignViewDTOList.size()<=30, PARAM_ILLEGAL, "关联计划数量不能超过30个");
        //重名校验
        FrequencyQueryViewDTO queryViewDTO = new FrequencyQueryViewDTO();
        queryViewDTO.setKeyword(frequencyViewDTO.getFreqName());
        queryViewDTO.setFrequencyId(frequencyViewDTO.getId());
        queryViewDTO.setFrequencyTarget(BrandFrequencyTargetEnum.PROMISE.getCode());
        AssertUtil.assertTrue(CollectionUtils.isEmpty(frequencyRepository.findFrequencyByName(serviceContext, queryViewDTO)) ,PARAM_ILLEGAL,"频控名称不能重复");

        //关联的计划日期跨度不能超过2个月
        if (CollectionUtils.isNotEmpty(campaignViewDTOList)) {
            Date startTime = campaignViewDTOList.stream().min(Comparator.comparing(it -> it.getStartTime())).get().getStartTime();
            Date endTime = campaignViewDTOList.stream().max(Comparator.comparing(it -> it.getEndTime())).get().getEndTime();
            AssertUtil.assertTrue(BrandDateUtil.isBeforeAndEqual(endTime, DateUtil.addDays(startTime, 60)), PARAM_ILLEGAL, "计划日期跨度不能超过2个月");
        }
        if (BrandFrequencyTargetEnum.PROMISE.getCode().equals(frequencyViewDTO.getFrequencyTarget()) && CollectionUtils.isNotEmpty(campaignViewDTOList)) {
            //交付型频控，只能关联交付型计划
            for (CampaignViewDTO campaignViewDTO: campaignViewDTOList) {
                AssertUtil.assertTrue (BrandCampaignFrequencyTargetEnum.PROMISE.getCode().equals(campaignViewDTO.getCampaignFrequencyViewDTO().getCampaignFrequencyTarget()), PARAM_ILLEGAL, "计划" + campaignViewDTO.getId() + "不能关联交付型频控");
            }
            List<Long> campaignIdList = campaignViewDTOList.stream().map(campaignViewDTO -> campaignViewDTO.getId()).collect(Collectors.toList());
            Map<Long, CampaignViewDTO> map = campaignViewDTOList.stream().collect(
                    Collectors.toMap(m -> m.getId(), v -> v, (o1, o2) -> o1));

            if (dbFrequencyRefViewDTO != null && CollectionUtils.isNotEmpty(dbFrequencyRefViewDTO.getCampaignIdList())) {
                List<Long> existCampaignIds = dbFrequencyRefViewDTO.getCampaignIdList().stream().filter(campaignIdList::contains).collect(Collectors.toList());
                campaignIdList.removeAll(existCampaignIds);
                //交付型频控如果已关联锁量后的计划，只能改大频次和名称
                for (Long campaignId : existCampaignIds) {
                    BrandCampaignStatusEnum campaignStatusEnum = BrandCampaignStatusEnum.getByCode(map.get(campaignId).getStatus());
                    if (BrandCampaignStatusEnum.INQUIRING == campaignStatusEnum || BrandCampaignStatusEnum.LOCKING == campaignStatusEnum || BrandCampaignStatusEnum.RELEASING == campaignStatusEnum
                            || BrandCampaignStatusEnum.LOCK_SUCCESS == campaignStatusEnum || BrandCampaignStatusEnum.WAITING == campaignStatusEnum
                            || BrandCampaignStatusEnum.CASTING == campaignStatusEnum || BrandCampaignStatusEnum.PAUSING == campaignStatusEnum
                            || BrandCampaignStatusEnum.ENDING == campaignStatusEnum) {
                        int dbFreqSize = dbFrequencyViewDTO.getFrequencyRuleViewDTOList().size();
                        int freqSize = frequencyViewDTO.getFrequencyRuleViewDTOList().size();
                        AssertUtil.assertTrue(dbFreqSize == freqSize, PARAM_ILLEGAL, "频控已关联在锁量中、锁量成功、待投放、投放中、投放结束、投放暂停状态计划的计划，频次不允许增加或删除");

                        String dbPeriodStr = dbFrequencyViewDTO.getFrequencyRuleViewDTOList().stream().map(e -> String.valueOf(e.getFreqPeriod())).sorted().collect(Collectors.joining(","));
                        String periodStr = frequencyViewDTO.getFrequencyRuleViewDTOList().stream().map(e -> String.valueOf(e.getFreqPeriod())).sorted().collect(Collectors.joining(","));
                        AssertUtil.assertTrue(dbPeriodStr.equals(periodStr), PARAM_ILLEGAL, "频控已关联在锁量中、锁量成功、待投放、投放中、投放结束、投放暂停状态计划的计划，频控周期类型不允许修改");
                        // 修改的频次map。key：周期，value：频控次数
                        Map<Integer, Long> freqMap = frequencyViewDTO.getFrequencyRuleViewDTOList().stream()
                                .collect(Collectors.toMap(FrequencyRuleViewDTO::getFreqPeriod, FrequencyRuleViewDTO::getFreqLimit));
                        for (FrequencyRuleViewDTO ruleViewDTO : dbFrequencyViewDTO.getFrequencyRuleViewDTOList()) {
                            Long freqLimit = freqMap.get(ruleViewDTO.getFreqPeriod());
                            AssertUtil.assertTrue(freqLimit >= ruleViewDTO.getFreqLimit(), PARAM_ILLEGAL, "频控已关联在锁量中、锁量成功、待投放、投放中、投放结束、投放暂停状态计划的计划，频次只允许改大");
                        }
                        break;
                    }
                }
            }

            if (CollectionUtils.isNotEmpty(campaignIdList)) {
                for (Long campaignId: campaignIdList) {
                    BrandCampaignStatusEnum campaignStatusEnum = BrandCampaignStatusEnum.getByCode(map.get(campaignId).getStatus());
                    AssertUtil.assertTrue(!(BrandCampaignStatusEnum.INQUIRING == campaignStatusEnum || BrandCampaignStatusEnum.LOCKING == campaignStatusEnum || BrandCampaignStatusEnum.RELEASING == campaignStatusEnum
                                    || BrandCampaignStatusEnum.LOCK_SUCCESS == campaignStatusEnum || BrandCampaignStatusEnum.WAITING == campaignStatusEnum
                                    || BrandCampaignStatusEnum.CASTING == campaignStatusEnum || BrandCampaignStatusEnum.PAUSING == campaignStatusEnum
                                    || BrandCampaignStatusEnum.ENDING == campaignStatusEnum),
                            BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR, "计划在锁量中、锁量成功、待投放、投放中、投放结束、投放暂停状态，不能关联交付型联合频控");
                }
            }
        }
    }

//    public void validateBindDeliveredFrequency(ServiceContext serviceContext, FrequencyViewDTO dbFrequency, List<CampaignViewDTO> campaignViewDTOList) {
//        AssertUtil.assertTrue(BrandFrequencyTargetEnum.PROMISE.getCode().equals(dbFrequency.getFrequencyTarget()), PARAM_ILLEGAL,"计划只允许绑定交付型频控");
//        if (CollectionUtils.isNotEmpty(campaignViewDTOList)) {
//            //交付型频控，只能关联交付型计划
//            for (CampaignViewDTO campaignViewDTO: campaignViewDTOList) {
//                AssertUtil.assertTrue (BrandCampaignFrequencyTargetEnum.PROMISE.getCode().equals(campaignViewDTO.getCampaignExtViewDTO().getCampaignFrequencyTarget()), PARAM_ILLEGAL, "非交付型计划" + campaignViewDTO.getId() + "不能关联交付型频控");
//            }
//            List<Long> campaignIdList = campaignViewDTOList.stream().map(campaignViewDTO -> campaignViewDTO.getId()).collect(Collectors.toList());
//            Map<Long, CampaignViewDTO> map = campaignViewDTOList.stream().collect(
//                    Collectors.toMap(m -> m.getId(), v -> v, (o1, o2) -> o1));
//            if (CollectionUtils.isNotEmpty(campaignIdList)) {
//                for (Long campaignId: campaignIdList) {
//                    BrandCampaignStatusEnum campaignStatusEnum = BrandCampaignStatusEnum.getByCode(map.get(campaignId).getStatus());
//                    AssertUtil.assertTrue(!(BrandCampaignStatusEnum.INQUIRING == campaignStatusEnum || BrandCampaignStatusEnum.LOCKING == campaignStatusEnum || BrandCampaignStatusEnum.RELEASING == campaignStatusEnum
//                                    || BrandCampaignStatusEnum.LOCK_SUCCESS == campaignStatusEnum || BrandCampaignStatusEnum.WAITING == campaignStatusEnum
//                                    || BrandCampaignStatusEnum.CASTING == campaignStatusEnum || BrandCampaignStatusEnum.PAUSING == campaignStatusEnum
//                                    || BrandCampaignStatusEnum.ENDING == campaignStatusEnum),
//                            BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR, "计划在锁量中、锁量成功、待投放、投放中、投放结束、投放暂停状态，不能关联交付型频控");
//                }
//            }
//        }
//    }


    public void validateSaveOptimizedFrequency(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO, List<AdgroupViewDTO> adgroupViewDTOList) {
        long count = frequencyViewDTO.getFrequencyRuleViewDTOList().stream().map(FrequencyRuleViewDTO::getFreqPeriod).distinct().count();
        AssertUtil.assertTrue(frequencyViewDTO.getFrequencyRuleViewDTOList().size() == (int) count, PARAM_ILLEGAL, "单元频控周期类型不能重复");
        AssertUtil.assertTrue(Optional.ofNullable(adgroupViewDTOList).orElse(Lists.newArrayList()).size()<=30, PARAM_ILLEGAL, "关联单元数量不能超过30个");
        List<Long> directAdgroupIdList = Optional.ofNullable(adgroupViewDTOList).orElse(Lists.newArrayList()).stream().filter(it -> BrandAdgroupTargetTypeEnum.DIRECT.getCode().equals(it.getTargetType())).map(AdgroupViewDTO::getId).collect(Collectors.toList());
        AssertUtil.assertTrue(directAdgroupIdList.size() == 0, PARAM_ILLEGAL, "频控不允许关联媒体直投单元");

        //重名校验
        FrequencyQueryViewDTO queryViewDTO = new FrequencyQueryViewDTO();
        queryViewDTO.setKeyword(frequencyViewDTO.getFreqName());
        queryViewDTO.setFrequencyId(frequencyViewDTO.getId());
        queryViewDTO.setFrequencyTarget(BrandFrequencyTargetEnum.IMPROVE.getCode());
        AssertUtil.assertTrue(CollectionUtils.isEmpty(frequencyRepository.findFrequencyByName(serviceContext, queryViewDTO)) ,PARAM_ILLEGAL,"频控名称不能重复");

        //关联的单元日期跨度不能超过2个月
        if (CollectionUtils.isNotEmpty(adgroupViewDTOList)) {
            Date startTime = adgroupViewDTOList.stream().min(Comparator.comparing(AdgroupViewDTO::getStartTime)).get().getStartTime();
            Date endTime = adgroupViewDTOList.stream().max(Comparator.comparing(AdgroupViewDTO::getEndTime)).get().getEndTime();
            AssertUtil.assertTrue(BrandDateUtil.isBeforeAndEqual(endTime, DateUtil.addDays(startTime, 60)), PARAM_ILLEGAL, "单元日期跨度不能超过2个月");
        }

        // 分组不支持优化型频控，不可关联
        if (CollectionUtils.isNotEmpty(adgroupViewDTOList)) {

            List<Long> campaignIds = adgroupViewDTOList.stream().map(AdgroupViewDTO::getCampaignId).distinct().collect(Collectors.toList());
            List<CampaignViewDTO> campaignViewDTOList = campaignRepository.queryCampaignList(serviceContext, CampaignQueryViewDTO.builder().campaignIds(campaignIds).build());
            List<Long> saleGroupIds = campaignViewDTOList.stream().map(it -> it.getCampaignSaleViewDTO().getSaleGroupId()).distinct().collect(Collectors.toList());
            Map<Long, ResourcePackageSaleGroupViewDTO> saleGroupViewDTOMap = resourcePackageRepository.getSaleGroupList(serviceContext,
                    ResourcePackageQueryViewDTO.builder().saleGroupIdList(saleGroupIds).build(),
                    ResourcePackageQueryOption.builder().needProduct(Boolean.FALSE).needInquiryPriority(Boolean.FALSE).needSetting(Boolean.TRUE).build())
                    .stream()
                    .collect(Collectors.toMap(ResourcePackageSaleGroupViewDTO::getId, v -> v, (o1, o2) -> o1));
            Map<Long, ResourcePackageSaleGroupViewDTO> campaignIdSaleGroupMap = campaignViewDTOList.stream().collect(Collectors.toMap(it -> it.getId(), it -> saleGroupViewDTOMap.get(it.getCampaignSaleViewDTO().getSaleGroupId())));

            for (AdgroupViewDTO adgroupViewDTO : adgroupViewDTOList) {
                AssertUtil.assertTrue(BrandBoolEnum.BRAND_TRUE.getCode().equals(campaignIdSaleGroupMap.get(adgroupViewDTO.getCampaignId()).getSupportOptimizedFrequency()), PARAM_ILLEGAL, "单元:" + adgroupViewDTO.getTitle() + "相关分组未设置优化型频控，无法关联");
            }
        }
    }

//    public void validateBindOptimizedFrequency(ServiceContext serviceContext, FrequencyViewDTO dbFrequency, List<AdgroupViewDTO> adgroupViewDTOList) {
//        AssertUtil.assertTrue(BrandFrequencyTargetEnum.IMPROVE.getCode().equals(dbFrequency.getFrequencyTarget()), PARAM_ILLEGAL,"单元只允许绑定优化型频控");
//        //关联的单元日期跨度不能超过2个月
//        if (CollectionUtils.isNotEmpty(adgroupViewDTOList)) {
//            Date startTime = adgroupViewDTOList.stream().min(Comparator.comparing(AdgroupViewDTO::getStartTime)).get().getStartTime();
//            Date endTime = adgroupViewDTOList.stream().max(Comparator.comparing(AdgroupViewDTO::getEndTime)).get().getEndTime();
//            FrequencyRefViewDTO frequencyRefViewDTO = frequencyRepository.findFrequencyRefByFreqId(serviceContext, dbFrequency.getId(), BrandFrequencyBizTypeEnum.ADGROUP.getCode());
//            AdgroupQueryViewDTO adgroupQueryViewDTO = new AdgroupQueryViewDTO();
//            adgroupQueryViewDTO.setIds(CollectionUtils.isNotEmpty(frequencyRefViewDTO.getAdgroupIdList()) ? frequencyRefViewDTO.getAdgroupIdList() : Lists.newArrayList(-1L));
//            List<AdgroupViewDTO> dbAdgroupViewDTOList = adgroupRepository.queryAdgroupBasicListNoPage(serviceContext, adgroupQueryViewDTO);
//            for (AdgroupViewDTO adgroupViewDTO : dbAdgroupViewDTOList) {
//                startTime = BrandDateUtil.isBefore(adgroupViewDTO.getStartTime(), startTime)? adgroupViewDTO.getStartTime(): startTime;
//                endTime = BrandDateUtil.isAfter(adgroupViewDTO.getEndTime(), endTime)? adgroupViewDTO.getEndTime(): endTime;
//            }
//            AssertUtil.assertTrue(BrandDateUtil.isBeforeAndEqual(endTime, DateUtil.addDays(startTime, 60)), PARAM_ILLEGAL, "单元日期跨度不能超过2个月");
//            dbFrequency.setStartTime(startTime);
//            dbFrequency.setEndTime(endTime);
//        }
//
//        // 单元已设置优化型频控（单元）或者分组不支持优化型频控，不可关联
//        if (CollectionUtils.isNotEmpty(adgroupViewDTOList)) {
//
//            List<Long> campaignIds = adgroupViewDTOList.stream().map(AdgroupViewDTO::getCampaignId).distinct().collect(Collectors.toList());
//            List<CampaignViewDTO> campaignViewDTOList = campaignRepository.queryCampaignList(serviceContext, CampaignQueryViewDTO.builder().campaignIds(campaignIds).build());
//            List<Long> saleGroupIds = campaignViewDTOList.stream().map(it -> it.getCampaignSaleViewDTO().getSaleGroupId()).distinct().collect(Collectors.toList());
//            Map<Long, ResourcePackageSaleGroupViewDTO> saleGroupViewDTOMap = resourcePackageRepository.getSaleGroupList(serviceContext,
//                            ResourcePackageQueryViewDTO.builder().saleGroupIdList(saleGroupIds).build(),
//                            ResourcePackageQueryOption.builder().needProduct(Boolean.FALSE).needInquiryPriority(Boolean.FALSE).needSetting(Boolean.TRUE).build())
//                    .stream()
//                    .collect(Collectors.toMap(ResourcePackageSaleGroupViewDTO::getId, v -> v, (o1, o2) -> o1));
//            Map<Long, ResourcePackageSaleGroupViewDTO> campaignIdSaleGroupMap = campaignViewDTOList.stream().collect(Collectors.toMap(it -> it.getId(), it -> saleGroupViewDTOMap.get(it.getCampaignSaleViewDTO().getSaleGroupId())));
//            adgroupViewDTOList.forEach(it -> AssertUtil.assertTrue(BrandBoolEnum.BRAND_TRUE.getCode().equals(campaignIdSaleGroupMap.get(it.getCampaignId()).getSupportOptimizedFrequency()), PARAM_ILLEGAL, "单元:" + it.getTitle() + "相关分组未设置优化型频控，无法关联"));
//        }
//    }

    /**
     * 校验频控是否支持上下线
     *
     * @param frequencyViewDTO
     * @param dbFrequencyViewDTO
     */
    public void validateFrequencySwitch(FrequencyViewDTO frequencyViewDTO, FrequencyViewDTO dbFrequencyViewDTO) {
        AssertUtil.assertTrue(!BrandFrequencyTargetEnum.PROMISE.getCode().equals(dbFrequencyViewDTO.getFrequencyTarget()),
                BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR,"交付型频控不能改变状态");
        AssertUtil.assertTrue(Objects.nonNull(frequencyViewDTO.getOnlineStatus()),
                BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR,"频控状态不能为空");
    }


//    /**
//     * 获取计划频控信息
//     * campaignViewDTOList为空说明说解绑，所以只需要更新当前传入频控的时间即可
//     */
//    public void updateDeliveredFrequencyTime(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList, FrequencyViewDTO dbFrequency) {
//        FrequencyRefViewDTO frequencyRefViewDTO = frequencyRepository.findFrequencyRefByFreqId(serviceContext, dbFrequency.getId(), BrandFrequencyBizTypeEnum.CAMPAIGN.getCode());
//        List<CampaignViewDTO> dbCampaignViewDTOList = campaignRepository.queryCampaignList(serviceContext, CampaignQueryViewDTO.builder()
//                .campaignIds(CollectionUtils.isNotEmpty(frequencyRefViewDTO.getCampaignIdList()) ? frequencyRefViewDTO.getCampaignIdList() : Lists.newArrayList(-1L))
//                .build());
//        //关联的计划日期跨度不能超过2个月
//        Map<Long, CampaignViewDTO> campaignViewDTOMap = CollectionUtils.isNotEmpty(campaignViewDTOList) ? campaignViewDTOList.stream().collect(Collectors.toMap(it -> it.getId(), it -> it, (o1, o2) -> o1)) : Maps.newHashMap();
//        dbCampaignViewDTOList.stream().filter(dbCampaignViewDTO -> !BrandCampaignStatusEnum.DELETE.getCode().equals(dbCampaignViewDTO.getStatus())).forEach(it -> {
//            if (!campaignViewDTOMap.containsKey(it.getId())) {
//                campaignViewDTOList.add(it);
//            }
//        });
//        if (CollectionUtils.isNotEmpty(campaignViewDTOList)) {
//            Date startTime = campaignViewDTOList.stream().min(Comparator.comparing(it -> it.getStartTime())).get().getStartTime();
//            Date endTime = campaignViewDTOList.stream().max(Comparator.comparing(it -> it.getEndTime())).get().getEndTime();
//            AssertUtil.assertTrue(BrandDateUtil.isBeforeAndEqual(endTime, DateUtil.addDays(startTime, 60)), PARAM_ILLEGAL, "计划日期跨度不能超过2个月");
//            // 更新频控时间
//            dbFrequency.setStartTime(startTime);
//            dbFrequency.setEndTime(endTime);
//            frequencyRepository.updateFrequencyPart(serviceContext, dbFrequency);
//        }
//    }
//
//    public void updateOptimizedFrequencyTime(ServiceContext serviceContext, List<AdgroupViewDTO> adgroupViewDTOList, FrequencyViewDTO dbFrequency) {
//        FrequencyRefViewDTO frequencyRefViewDTO = frequencyRepository.findFrequencyRefByFreqId(serviceContext, dbFrequency.getId(), BrandFrequencyBizTypeEnum.ADGROUP.getCode());
//        AdgroupQueryViewDTO adgroupQueryViewDTO = new AdgroupQueryViewDTO();
//        adgroupQueryViewDTO.setIds(CollectionUtils.isNotEmpty(frequencyRefViewDTO.getAdgroupIdList()) ? frequencyRefViewDTO.getAdgroupIdList() : Lists.newArrayList(-1L));
//        List<AdgroupViewDTO> dbAdgroupViewDTOList = adgroupRepository.queryAdgroupBasicListNoPage(serviceContext, adgroupQueryViewDTO);
//        //关联的计划日期跨度不能超过2个月
//        Map<Long, AdgroupViewDTO> adgroupViewDTOMap = CollectionUtils.isNotEmpty(adgroupViewDTOList) ? adgroupViewDTOList.stream().collect(Collectors.toMap(AdgroupViewDTO::getId, it -> it, (o1, o2) -> o1)) : Maps.newHashMap();
//        dbAdgroupViewDTOList.forEach(it -> {
//            if (!adgroupViewDTOMap.containsKey(it.getId())) {
//                adgroupViewDTOList.add(it);
//            }
//        });
//        if (CollectionUtils.isNotEmpty(adgroupViewDTOList)) {
//            Date startTime = adgroupViewDTOList.stream().min(Comparator.comparing(AdgroupViewDTO::getStartTime)).get().getStartTime();
//            Date endTime = adgroupViewDTOList.stream().max(Comparator.comparing(AdgroupViewDTO::getEndTime)).get().getEndTime();
//            AssertUtil.assertTrue(BrandDateUtil.isBeforeAndEqual(endTime, DateUtil.addDays(startTime, 60)), PARAM_ILLEGAL, "单元日期跨度不能超过2个月");
//            // 更新频控时间
//            dbFrequency.setStartTime(startTime);
//            dbFrequency.setEndTime(endTime);
//            frequencyRepository.updateFrequencyPart(serviceContext, dbFrequency);
//        }
//    }
}
