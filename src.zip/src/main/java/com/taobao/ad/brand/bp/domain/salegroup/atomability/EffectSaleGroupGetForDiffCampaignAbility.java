package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.salegroup.CampaignGroupSaleGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSaleOrderStatusEnum;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.util.differ.Differs;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.EffectAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupGetForDiffCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupGetForDiffCampaignAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EffectSaleGroupGetForDiffCampaignAbility implements ISaleGroupGetForDiffCampaignAbility, EffectAtomAbilityRouter {

    @Override
    public List<Long> handle(ServiceContext serviceContext, SaleGroupGetForDiffCampaignAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        List<CampaignViewDTO> dbCampaignViewDTOList = abilityParam.getDbCampaignViewDTOList();

        List<Long> saleGroupIdList = Optional.ofNullable(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO())
                .map(CampaignGroupSaleGroupViewDTO::getSaleGroupInfoViewDTOList).orElse(Lists.newArrayList())
                .stream().map(SaleGroupInfoViewDTO::getSaleGroupId).collect(Collectors.toList());

        List<Long> dbSaleGroupIdList = Optional.ofNullable(dbCampaignViewDTOList).orElse(Lists.newArrayList())
                .stream().map(e->e.getCampaignSaleViewDTO().getSaleGroupId()).collect(Collectors.toList());

        /*****      分组diff      ******/
        List<Long> addSaleGroupIdList = Differs.differ(saleGroupIdList, dbSaleGroupIdList, String::valueOf);
        List<Long> delSaleGroupIdList = Differs.differ(dbSaleGroupIdList, saleGroupIdList, String::valueOf);
        List<Long> updateSaleGroupIdList = Differs.differ(saleGroupIdList, addSaleGroupIdList, String::valueOf);

        //分组信息
        List<Long> resultSaleGroupIdList = Lists.newArrayList();
        Optional.ofNullable(addSaleGroupIdList).ifPresent(resultSaleGroupIdList::addAll);
        Optional.ofNullable(delSaleGroupIdList).ifPresent(resultSaleGroupIdList::addAll);

        //修改的分组，只获取“未下单”的分组
        if(CollectionUtils.isNotEmpty(updateSaleGroupIdList)){
            List<Long> needUpdateSaleGroupIdList = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList()
                    .stream().filter(e-> BrandCampaignGroupSaleOrderStatusEnum.WAIT_ORDER.getCode().equals(e.getSaleGroupStatus()))
                    .map(SaleGroupInfoViewDTO::getSaleGroupId).filter(updateSaleGroupIdList::contains).collect(Collectors.toList());

            Optional.of(needUpdateSaleGroupIdList).ifPresent(resultSaleGroupIdList::addAll);
        }
        RogerLogger.info("effectSaleGroupGetForDiffCampaignAbility resultSaleGroupIdList = {}", JSON.toJSONString(resultSaleGroupIdList));
        return resultSaleGroupIdList;
    }
}
