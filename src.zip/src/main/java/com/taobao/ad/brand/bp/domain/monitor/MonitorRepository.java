package com.taobao.ad.brand.bp.domain.monitor;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.nb.user.client.constant.bizspace.BizAbilityEnum;
import com.taobao.ad.brand.bp.client.dto.adgroup.ExportMonitorCodeViewDTO;
import com.taobao.ad.brand.bp.client.dto.monitor.MonitorRuleXMediaViewDTO;

import java.util.List;

/**
 * @author  弈云
 * @date 2023年04月03日
 */
public interface MonitorRepository {
    /**
     * 生成监测代码
     * */
    void  generateMonitor(ServiceContext context, AdgroupViewDTO adgroupViewDTO, CampaignViewDTO campaignViewDTO, CampaignGroupViewDTO campaignGroupViewDTO, List<ExportMonitorCodeViewDTO> exportMonitorCodeViewDTOList, List<CreativeViewDTO> creativeViewDTOList, BizAbilityEnum bizAbilityEnum);

    void addMonitorRuleXMedia(ServiceContext context, MonitorRuleXMediaViewDTO monitorRuleXMediaViewDTO);
}
