package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.guarantee.CampaignGuaranteeViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.EffectAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignGuaranteeInitForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignGuaranteeAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EffectCampaignGuaranteeInitForUpdateCampaignAbility implements ICampaignGuaranteeInitForUpdateCampaignAbility, EffectAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGuaranteeAbilityParam abilityParam) {
        CampaignGuaranteeViewDTO campaignGuaranteeViewDTO = abilityParam.getAbilityTarget();
        ResourcePackageProductViewDTO resourcePackageProductViewDTO = abilityParam.getResourcePackageProductViewDTO();
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        AssertUtil.notNull(campaignGuaranteeViewDTO, "计划保量信息不能为空");
        AssertUtil.notNull(resourcePackageProductViewDTO, "产品不能为空");
        AssertUtil.notNull(dbCampaignViewDTO, "计划不存在");

        CampaignGuaranteeViewDTO dbCampaignGuaranteeViewDTO = dbCampaignViewDTO.getCampaignGuaranteeViewDTO();
        campaignGuaranteeViewDTO.setSspRegisterUnit(dbCampaignGuaranteeViewDTO.getSspRegisterUnit());
        campaignGuaranteeViewDTO.setBudgetCampaignId(dbCampaignGuaranteeViewDTO.getBudgetCampaignId());
        campaignGuaranteeViewDTO.setSspControlFlow(dbCampaignGuaranteeViewDTO.getSspControlFlow());
        campaignGuaranteeViewDTO.setIsSettleControl(dbCampaignGuaranteeViewDTO.getIsSettleControl());
        campaignGuaranteeViewDTO.setSspRegisterManner(dbCampaignGuaranteeViewDTO.getSspRegisterManner());
        campaignGuaranteeViewDTO.setCptMaxAmount(dbCampaignGuaranteeViewDTO.getCptMaxAmount());
        campaignGuaranteeViewDTO.setSspPushSendRatio(dbCampaignGuaranteeViewDTO.getSspPushSendRatio());
        campaignGuaranteeViewDTO.setIsUnionControlFlow(dbCampaignGuaranteeViewDTO.getIsUnionControlFlow());

        //预定量
        List<ResourcePackageProductPriceViewDTO> bandPriceList = resourcePackageProductViewDTO.getBandPriceList();
        if(CollectionUtils.isNotEmpty(bandPriceList)) {
            //内容没有多波段，只取一个
            ResourcePackageProductPriceViewDTO resourcePackageProductPriceViewDTO = bandPriceList.get(0);
            campaignGuaranteeViewDTO.setAmount(new BigDecimal(resourcePackageProductPriceViewDTO.getBookingAmount())
                    .multiply(new BigDecimal(Constant.DEFAULT_CPM_PV_RATIO)).longValue());
        }
        return null;
    }
}
