package com.taobao.ad.brand.bp.domain.campaigngroup.workflow;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.cancel.CampaignGroupCancelViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.ext.CampaignGroupExtViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.order.CampaignGroupOrderViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.realsettle.CampaignGroupRealSettleViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.unlock.CampaignGroupUnlockViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupProcessStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSaleOrderStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleGroupSourceEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupBusinessLineEnum;
import com.taobao.ad.brand.bp.client.context.CampaignGroupStateContext;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupOrderCommandViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.salegroup.SaleGroupCheckedRebuildResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.settle.CampaignGroupRealSettleSaveViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.workflow.router.BrandOneBPExtensionRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.*;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.*;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.workflow.param.BizCampaignGroupProcessOrderWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.workflow.param.BizCampaignGroupRealSettleWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.workflow.param.BizCampaignGroupTransitWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.workflow.param.BizCampaignGroupWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupInitForOrderCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupValidateForDeleteAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupInitAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupOrderAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupValidateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_REQUIRED;

/**
 * Description:主订单扩展
 *
 * @author yanjingang
 * @version 1.0
 */
@Service
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandOneBPCampaignGroupCommandWorkflowExtImpl extends DefaultCampaignGroupCommandWorkflowExtImpl implements BrandOneBPExtensionRouter {
    private final CampaignGroupRepository campaignGroupRepository;

    private final ICampaignGroupCustomerValidateForAddCampaignGroupAbility campaignGroupCustomerValidateForAddCampaignGroupAbility;
    @Resource
    private ICampaignGroupSaleValidateForAddOrUpdateCampaignGroupAbility campaignGroupSaleValidateForAddOrUpdateCampaignGroupAbility;
    @Resource
    private ICampaignGroupContractValidateForAddCampaignGroupAbility campaignGroupContractValidateForAddCampaignGroupAbility;
    @Resource
    private ICampaignGroupSaleGroupValidateForAddOrUpdateCampaignGroupAbility campaignGroupSaleGroupValidateForAddOrUpdateAbility;
    @Resource
    private ICampaignGroupBaseValidateForUpdateCampaignGroupAbility campaignGroupBaseValidateForUpdateCampaignGroupAbility;
    @Resource
    private ICampaignGroupBaseInitForAddCampaignGroupAbility campaignGroupBaseInitForAddCampaignGroupAbility;
    @Resource
    private ICampaignGroupBaseInitForUpdateCampaignGroupAbility campaignGroupBaseInitForUpdateCampaignGroupAbility;
    @Resource
    private ICampaignGroupCustomerInitForAddCampaignGroupAbility campaignGroupCustomerInitForAddCampaignGroupAbility;
    @Resource
    private ICampaignGroupSaleInitForAddCampaignGroupAbility campaignGroupSaleInitForAddCampaignGroupAbility;
    @Resource
    private ICampaignGroupSaleInitForUpdateCampaignGroupAbility campaignGroupSaleInitForUpdateCampaignGroupAbility;
    @Resource
    private ISaleGroupInitForOrderCampaignGroupAbility saleGroupInitForOrderCampaignGroupAbility;
    @Resource
    private ICampaignGroupBaseInitForOrderCampaignGroupAbility campaignGroupBaseInitForOrderCampaignGroupAbility;
    @Resource
    private ICampaignGroupContractInitForOrderCampaignGroupAbility campaignGroupContractInitForOrderCampaignGroupAbility;
    @Resource
    private ICampaignGroupCheckedSaleGroupRebuildForOrderCampaignGroupAbility campaignGroupCheckedSaleGroupRebuildForOrderCampaignGroupAbility;

    private final ICampaignGroupWakeupInitForAddCampaignGroupAbility campaignGroupWakeupInitForAddCampaignGroupAbility;
    private final ICampaignGroupContractInitForUpdateCampaignGroupAbility campaignGroupContractInitForUpdateCampaignGroupAbility;
    private final ICampaignGroupExtInitForAddCampaignGroupAbility campaignGroupExtInitForAddCampaignGroupAbility;
    private final ICampaignGroupMessageAsyncSendAbility campaignGroupMessageAsyncSendAbility;
    private final ISaleGroupValidateForDeleteAbility saleGroupValidateForDeleteAbility;

    private final ICampaignGroupInitForPreOrderCampaignGroupAbility campaignGroupInitForPreOrderCampaignGroupAbility;


    @Override
    public void beforeExecuteAddCampaignGroup(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, BizCampaignGroupWorkflowParam bizCampaignGroupWorkflowParam) {
        // 校验
        this.validateForAdd(context, campaignGroupViewDTO, bizCampaignGroupWorkflowParam);
        // 初始化
        this.initForAdd(context, campaignGroupViewDTO, bizCampaignGroupWorkflowParam);
    }

    @Override
    public void beforeExecuteUpdateCampaignGroup(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, BizCampaignGroupWorkflowParam bizCampaignGroupWorkflowParam) {
        // 校验
        this.validateForUpdate(context, campaignGroupViewDTO, bizCampaignGroupWorkflowParam);
        // 初始化
        this.initForUpdate(context, campaignGroupViewDTO, bizCampaignGroupWorkflowParam);
    }

    @Override
    public void beforeOrder(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO, BizCampaignGroupProcessOrderWorkflowParam orderWorkflowParam) {
        // 初始化
        CampaignGroupViewDTO campaignGroupViewDTO = orderWorkflowParam.getCampaignGroupViewDTO();
        // 分组初始化(放在第一位，因为后面需要用到分组的初始化结果)
        saleGroupInitForOrderCampaignGroupAbility.handle(context, SaleGroupOrderAbilityParam.builder()
                .abilityTargets(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList())
                .campaignGroupViewDTO(campaignGroupViewDTO).subCampaignGroupList(orderWorkflowParam.getSubCampaignGroupList()).build());
        // 订单基础信息初始化
        campaignGroupBaseInitForOrderCampaignGroupAbility.handle(context, CampaignGroupBaseAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
        // 合同信息初始化
        campaignGroupContractInitForOrderCampaignGroupAbility.handle(context, CampaignGroupContractInitForOrderAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupContractViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO)
                .campaignGroupOrderCommandViewDTO(campaignGroupOrderCommandViewDTO).build());
    }

    @Override
    public void beforePreOrder(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, BizCampaignGroupProcessOrderWorkflowParam processWorkflowParam) {
        // 初始化
        campaignGroupInitForPreOrderCampaignGroupAbility.handle(serviceContext, CampaignGroupPreOrderAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO).subCampaignGroupList(processWorkflowParam.getSubCampaignGroupList()).build());
    }

    private void initForUpdate(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, BizCampaignGroupWorkflowParam bizCampaignGroupWorkflowParam) {
        CampaignGroupViewDTO dbCampaignGroupViewDTO = bizCampaignGroupWorkflowParam.getDbCampaignGroupViewDTO();
        // 基础信息
        campaignGroupBaseInitForUpdateCampaignGroupAbility.handle(context, CampaignGroupBaseAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO).dbCampaignGroupViewDTO(dbCampaignGroupViewDTO).build());
        // 售卖信息
        campaignGroupSaleInitForUpdateCampaignGroupAbility.handle(context, CampaignGroupSaleAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupSaleViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO).build());
        // 订单分组
        super.initSaleGroupInfoForUpdate(context, campaignGroupViewDTO, dbCampaignGroupViewDTO, bizCampaignGroupWorkflowParam.getResourcePackageSaleGroupList());
        // 合同信息
        campaignGroupContractInitForUpdateCampaignGroupAbility.handle(context, CampaignGroupContractAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupContractViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO).build());

        campaignGroupViewDTO.setCampaignGroupOrderViewDTO(new CampaignGroupOrderViewDTO());
        campaignGroupViewDTO.setCampaignGroupUnlockViewDTO(new CampaignGroupUnlockViewDTO());
        campaignGroupViewDTO.setCampaignGroupCancelViewDTO(new CampaignGroupCancelViewDTO());
        campaignGroupViewDTO.setCampaignGroupRealSettleViewDTO(new CampaignGroupRealSettleViewDTO());
        // 扩展属性
        campaignGroupViewDTO.setCampaignGroupExtViewDTO(new CampaignGroupExtViewDTO());
    }

    private void validateForUpdate(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, BizCampaignGroupWorkflowParam bizCampaignGroupWorkflowParam) {
        if (!BizCampaignGroupToolsHelper.isSaleCampaignGroup(campaignGroupViewDTO)) {
            return;
        }
        CampaignGroupViewDTO dbCampaignGroupViewDTO = bizCampaignGroupWorkflowParam.getDbCampaignGroupViewDTO();
        // 名称校验
        campaignGroupNameValidateAbility.handle(context, CampaignGroupNameValidateAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
        // 基础信息校验
        campaignGroupBaseValidateForUpdateCampaignGroupAbility.handle(context, CampaignGroupBaseAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO).dbCampaignGroupViewDTO(dbCampaignGroupViewDTO).build());
        // 校验售卖信息
        campaignGroupSaleValidateForAddOrUpdateCampaignGroupAbility.handle(context, CampaignGroupSaleAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupSaleViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO).build());
        // 校验订单分组信息
        campaignGroupSaleGroupValidateForAddOrUpdateAbility.handle(context, CampaignGroupSaleGroupAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO)
                .resourcePackageSaleGroupList(bizCampaignGroupWorkflowParam.getResourcePackageSaleGroupList()).build());
        // 校验品牌场景子订单删除的分组下是否有计划
        if (CollectionUtils.isNotEmpty(bizCampaignGroupWorkflowParam.getDbSubCampaignGroupList())) {
            List<CampaignGroupViewDTO> dbBrandSubCampaignGroupList = bizCampaignGroupWorkflowParam.getDbSubCampaignGroupList().stream().filter(subCampaignGroup -> {
                return SaleGroupBusinessLineEnum.BRAND_AD.getValue().equals(subCampaignGroup.getSceneId())
                        || SaleGroupBusinessLineEnum.TAO_BRAND_AD.getValue().equals(subCampaignGroup.getSceneId())
                        || SaleGroupBusinessLineEnum.IP_MARKETING_AD.getValue().equals(subCampaignGroup.getSceneId());
            }).collect(Collectors.toList());
            if (CollectionUtils.isNotEmpty(dbBrandSubCampaignGroupList)) {
                List<SaleGroupInfoViewDTO> dbSaleGroupInfoList = dbBrandSubCampaignGroupList.stream()
                        .map(CampaignGroupViewDTO::getCampaignGroupSaleGroupViewDTO)
                        .flatMap(campaignGroupSaleGroupViewDTO -> campaignGroupSaleGroupViewDTO.getSaleGroupInfoViewDTOList().stream())
                        .collect(Collectors.toList());
                saleGroupValidateForDeleteAbility.handle(context, SaleGroupValidateAbilityParam.builder()
                        .abilityTargets(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList())
                        .dbSaleGroupInfoViewDTOList(dbSaleGroupInfoList).saleGroupSourceEnum(BrandSaleGroupSourceEnum.SALE_PLATFORM).build());
            }
        }

    }

    private void initForAdd(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, BizCampaignGroupWorkflowParam bizCampaignGroupWorkflowParam) {
        if (!BizCampaignGroupToolsHelper.isSaleCampaignGroup(campaignGroupViewDTO)) {
            return;
        }
        // 基础信息
        campaignGroupBaseInitForAddCampaignGroupAbility.handle(context, CampaignGroupBaseAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
        // 客户信息
        campaignGroupCustomerInitForAddCampaignGroupAbility.handle(context, CampaignGroupCustomerAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupCustomerViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO).build());
        // 售卖信息
        campaignGroupSaleInitForAddCampaignGroupAbility.handle(context, CampaignGroupSaleAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupSaleViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO).build());
        // 订单分组信息
        List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList();
        List<Long> addSaleGroupIds = saleGroupInfoViewDTOList.stream().map(SaleGroupInfoViewDTO::getSaleGroupId).distinct().collect(Collectors.toList());
        Map<Long, ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupMap = bizCampaignGroupWorkflowParam.getResourcePackageSaleGroupList()
                .stream().collect(Collectors.toMap(ResourcePackageSaleGroupViewDTO::getId, Function.identity(), (v1, v2) -> v1));
        saleGroupInitForAddAbility.handle(context, SaleGroupInitAbilityParam.builder()
                .abilityTargets(saleGroupInfoViewDTOList).resourcePackageSaleGroupMap(resourcePackageSaleGroupMap)
                .operateSaleGroupIds(addSaleGroupIds).saleGroupSourceEnum(BrandSaleGroupSourceEnum.SALE_PLATFORM).build());
        // 唤端信息
        campaignGroupWakeupInitForAddCampaignGroupAbility.handle(context, CampaignGroupWakeupAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getWakeupViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO).build());
        // 扩展信息
        campaignGroupExtInitForAddCampaignGroupAbility.handle(context, CampaignGroupExtAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupExtViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO).build());
    }

    /**
     * 新增订单校验
     * @param context
     * @param campaignGroupViewDTO
     * @param bizCampaignGroupWorkflowParam
     */
    private void validateForAdd(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, BizCampaignGroupWorkflowParam bizCampaignGroupWorkflowParam) {
        if (!BizCampaignGroupToolsHelper.isSaleCampaignGroup(campaignGroupViewDTO)) {
            return;
        }
        // 校验名称
        campaignGroupNameValidateAbility.handle(context, CampaignGroupNameValidateAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
        // 校验客户
        campaignGroupCustomerValidateForAddCampaignGroupAbility.handle(context, CampaignGroupCustomerAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupCustomerViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO).build());
        // 校验售卖信息
        campaignGroupSaleValidateForAddOrUpdateCampaignGroupAbility.handle(context, CampaignGroupSaleAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupSaleViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO).build());
        // 校验合同信息
        campaignGroupContractValidateForAddCampaignGroupAbility.handle(context, CampaignGroupContractAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupContractViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO).build());
        // 校验订单分组信息
        campaignGroupSaleGroupValidateForAddOrUpdateAbility.handle(context, CampaignGroupSaleGroupAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO)
                .resourcePackageSaleGroupList(bizCampaignGroupWorkflowParam.getResourcePackageSaleGroupList()).build());
    }

    @Override
    public Void afterExecuteAddCampaignGroup(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO) {
        //主订单无后置处理逻辑
        return null;
    }

    @Override
    public Void afterExecuteUpdateCampaignGroup(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO) {
        //主订单无后置处理逻辑
        return null;
    }

    @Override
    public BizCampaignGroupRealSettleWorkflowParam buildWorkflowParamForSaveRealSettleInfo(ServiceContext context, CampaignGroupRealSettleSaveViewDTO campaignGroupRealSettleSaveViewDTO) {
        AssertUtil.notNull(campaignGroupRealSettleSaveViewDTO, PARAM_REQUIRED, "参数不能为空");
        AssertUtil.notNull(campaignGroupRealSettleSaveViewDTO.getId(), PARAM_REQUIRED, "订单ID不能为空");

        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(context, campaignGroupRealSettleSaveViewDTO.getId());
        AssertUtil.notNull(campaignGroupRealSettleSaveViewDTO.getId(), PARAM_REQUIRED, "订单不存在");
        // 子订单
        List<CampaignGroupViewDTO> subCampaignGroupList = campaignGroupRepository.findSubCampaignGroupList(context, campaignGroupViewDTO.getId());
        return BizCampaignGroupRealSettleWorkflowParam.builder().campaignGroupViewDTO(campaignGroupViewDTO).subCampaignGroupList(subCampaignGroupList).build();
    }

    @Override
    public void afterTransitCompleted(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, BizCampaignGroupTransitWorkflowParam transitWorkflowParam) {
        CampaignGroupStateContext stateContext = transitWorkflowParam.getStateContext();
        campaignGroupMessageAsyncSendAbility.handle(serviceContext, CampaignGroupMessageAsyncSendAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO).domainEvent(stateContext.getEventEnum().name()).build());
    }

    @Override
    public BizCampaignGroupProcessOrderWorkflowParam buildParamForOrder(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO, CampaignGroupViewDTO campaignGroupViewDTO) {
        BizCampaignGroupProcessOrderWorkflowParam workflowParam = new BizCampaignGroupProcessOrderWorkflowParam();
        // 子订单
        List<CampaignGroupViewDTO> subCampaignGroupList = campaignGroupRepository.findSubCampaignGroupList(context, campaignGroupViewDTO.getId());
        workflowParam.setSubCampaignGroupList(subCampaignGroupList);
        // 构建下单分组
        // 重新build所选的分组
        SaleGroupCheckedRebuildResultViewDTO rebuildResultViewDTO = campaignGroupCheckedSaleGroupRebuildForOrderCampaignGroupAbility.handle(context, CampaignGroupCheckedSaleGroupRebuildForOrderAbilityParam.builder()
                .abilityTarget(campaignGroupOrderCommandViewDTO).campaignGroupViewDTO(campaignGroupViewDTO).subCampaignGroupList(workflowParam.getSubCampaignGroupList()).build());
        workflowParam.setSalePlatformSaleGroupIds(rebuildResultViewDTO.getSalePlatformSaleGroupIds());
        workflowParam.setCalOrderSaleGroupIds(rebuildResultViewDTO.getCalOrderSaleGroupIds());

        // 设置主订单下单分组
        campaignGroupOrderCommandViewDTO.setSaleGroupIds(workflowParam.getCalOrderSaleGroupIds());

        return workflowParam;
    }

    @Override
    public void validateForOrder(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO, BizCampaignGroupProcessOrderWorkflowParam orderWorkflowParam) {
    }

    @Override
    public void afterOrder(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO, BizCampaignGroupProcessOrderWorkflowParam processWorkflowParam) {
    }

    @Override
    public BizCampaignGroupProcessOrderWorkflowParam buildParamForModify(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO, CampaignGroupViewDTO campaignGroupViewDTO) {
        BizCampaignGroupProcessOrderWorkflowParam processWorkflowParam = new BizCampaignGroupProcessOrderWorkflowParam();
        processWorkflowParam.setCampaignGroupViewDTO(campaignGroupViewDTO);
        // 子订单
        List<CampaignGroupViewDTO> subCampaignGroupList = campaignGroupRepository.findSubCampaignGroupList(context, campaignGroupViewDTO.getId());
        processWorkflowParam.setSubCampaignGroupList(subCampaignGroupList);

        // 分组
        List<Long> unlockSaleGroupIds = subCampaignGroupList.stream().flatMap(subCampaignGroup -> subCampaignGroup.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream())
                .filter(t -> BrandCampaignGroupSaleOrderStatusEnum.WAIT_ORDER.getCode().equals(t.getSaleGroupStatus()))
                .map(SaleGroupInfoViewDTO::getSaleGroupId)
                .collect(Collectors.toList());
        campaignGroupOrderCommandViewDTO.setSaleGroupIds(unlockSaleGroupIds);
        processWorkflowParam.setCalOrderSaleGroupIds(unlockSaleGroupIds);
        // 售卖中心平台分组
        List<Long> salePlatformSaleGroupIds = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream()
                .filter(saleGroupInfo -> unlockSaleGroupIds.contains(saleGroupInfo.getSaleGroupId()))
                .filter(saleGroupInfo -> BrandSaleGroupSourceEnum.SALE_PLATFORM.getCode().equals(saleGroupInfo.getSource()))
                .map(SaleGroupInfoViewDTO::getSaleGroupId)
                .collect(Collectors.toList());
        processWorkflowParam.setSalePlatformSaleGroupIds(salePlatformSaleGroupIds);
        // 无需处理资源包平台分组

        return processWorkflowParam;
    }

    @Override
    public void afterModify(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO, BizCampaignGroupProcessOrderWorkflowParam processWorkflowParam) {
    }

    @Override
    public void afterFinishSubCampaignGroupRealSettleProcess(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, BrandCampaignGroupProcessStatusEnum processStatusEnum) {
    }

//    @Override
//    public BizCampaignGroupProcessOrderWorkflowParam buildWorkflowParamForPreOrder(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO) {
//        BizCampaignGroupProcessOrderWorkflowParam workflowParam = new BizCampaignGroupProcessOrderWorkflowParam();
//        // 子订单
//        List<CampaignGroupViewDTO> subCampaignGroupList = campaignGroupRepository.findSubCampaignGroupList(serviceContext, campaignGroupViewDTO.getId());
//        workflowParam.setSubCampaignGroupList(subCampaignGroupList);
//
//        return workflowParam;
//    }

//    /**
//     * 主订单无需对资源包平台分组进行下单
//     *
//     * @param context
//     * @param campaignGroupOrderCommandViewDTO
//     * @param subCampaignGroupList
//     * @param workflowParam
//     */
//    private void buildSaleGroupIds(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO, List<CampaignGroupViewDTO> subCampaignGroupList, BizCampaignGroupProcessOrderWorkflowParam workflowParam) {
//        List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList = subCampaignGroupList.stream()
//                .flatMap(subCampaignGroup -> subCampaignGroup.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream())
//                .collect(Collectors.toList());
//        workflowParam.setSalePlatformSaleGroupIds(saleGroupInfoViewDTOList.stream()
//                .filter(t -> BrandSaleGroupSourceEnum.SALE_PLATFORM.getCode().equals(t.getSource()))
//                .map(SaleGroupInfoViewDTO::getSaleGroupId)
//                .collect(Collectors.toList())
//        );
//        workflowParam.setCalOrderSaleGroupIds(workflowParam.getSalePlatformSaleGroupIds());
//    }
}