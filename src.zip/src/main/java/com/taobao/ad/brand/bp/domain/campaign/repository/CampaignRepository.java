package com.taobao.ad.brand.bp.domain.campaign.repository;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdViewDTO;
import com.alibaba.ad.brand.dto.common.BottomDateViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.adzone.CampaignAdzoneViewDTO;
import com.alibaba.ad.brand.dto.campaign.realtime.CampaignRealTimeOptimizeViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryViewDTO;
import com.alibaba.ad.brand.sdk.constant.audience.field.BrandTargetTypeEnum;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignBottomDateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignImpressionViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignTemplateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.ItemViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;

import java.util.List;
import java.util.Map;

public interface CampaignRepository {
    /**
     * 分页查询计划列表
     * @param serviceContext
     * @param query
     * @return
     */
    PageResultViewDTO<CampaignViewDTO> queryCampaignPageList(ServiceContext serviceContext, CampaignQueryViewDTO query);

    /**
     * 查询计划count
     * @param serviceContext
     * @param query
     * @return
     */
    Integer queryCampaignCount(ServiceContext serviceContext, CampaignQueryViewDTO query);

    /**
     * 查询计划列表
     * @param serviceContext
     * @param query
     * @return
     */
    List<CampaignViewDTO> queryCampaignList(ServiceContext serviceContext, CampaignQueryViewDTO query);
    /**
     * 查询
     * @param serviceContext
     * @param crowdId
     * @return
     */
     boolean queryIsBindCampaignByCrowdId(ServiceContext serviceContext, Long crowdId);

    /**
     * 批量添加计划
     * @param serviceContext
     * @param campaignViewDTOList
     */
    void addCampaign(ServiceContext serviceContext, Long campaignGroupId, List<CampaignViewDTO> campaignViewDTOList);

    /**
     * 批量添加计划
     * @param serviceContext
     * @param campaignViewDTOList
     */
    void addCampaign(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList);

    /**
     * 批量更新计划
     * @param serviceContext
     * @param campaignViewDTOList
     */
    void updateCampaignPart(ServiceContext serviceContext,List<CampaignViewDTO> campaignViewDTOList);

    /**
     * 批量更新计划（不更新预定量）
     * @param serviceContext
     * @param campaignViewDTOList
     */
    void updateCampaignPartWithoutInquiry(ServiceContext serviceContext,List<CampaignViewDTO> campaignViewDTOList);


    /**
     * 批量更新计划预算比例
     * @param serviceContext
     * @param campaignViewDTOList
     */
    void updateCampaignBudgetRatio(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList);

    /**
     * 更新计划
     * @param serviceContext
     * @param campaignViewDTO
     */
    void updateCampaignPart(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO);

    /**
     * 全量更新计划(会全量更新，不在viewDTO中算法的key会被覆盖掉，不要轻易使用)
     * @param serviceContext
     * @param campaignViewDTOList
     */
    void updateCampaignAll(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList);

    /**
     * 批量添加计划定向
     * @param serviceContext
     * @param campaignViewDTOList
     */
    void addCampaignTarget(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList);

    /**
     * 批量添加计划广告位
     * @param serviceContext
     * @param campaignViewDTOList
     */
    void addCampaignAdzone(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList);

    /**
     * 批量更新计划全部广告位
     * @param serviceContext
     * @param campaignViewDTOList
     */
    void updateCampaignAdzoneAll(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList);

    /**
     * 修改计划定向
     * @param serviceContext
     * @param campaignViewDTOList
     */
    void updateCampaignTarget(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList);

    /**
     * 部分增加或修改定向
     */
    void addOrUpdateCampaignTargetPart(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO);

    /**
     * 删除定向-指定类型
     */
    void deleteCampaignCrowdPart(ServiceContext serviceContext, Long campaignId, BrandTargetTypeEnum targetTypeEnum);

    /**
     * 删除定向-指定定向中心ID
     */
    void deleteCampaignCrowdByAudienceCrowdIds(ServiceContext serviceContext, Long campaignId, List<Long> audienceCrowdIds);

    void deleteCampaignCrowdPart(ServiceContext serviceContext, List<Long> campaignIds, BrandTargetTypeEnum targetTypeEnum);


    /**
     * 根据计划ID获取计划信息
     * @param serviceContext
     * @param campaignId
     * @return
     */
    CampaignViewDTO getCampaignById(ServiceContext serviceContext, Long campaignId);
    /**
     * 获取子计划IDs获取打底信息
     * @param serviceContext
     * @param subCampaignIds
     * @return
     */
    List<BottomDateViewDTO> getCampaignBottomDateList(ServiceContext serviceContext, List<Long> subCampaignIds);
    /**
     * 获取子计划IDs获取打底信息
     * @param serviceContext
     * @param subCampaignIds
     * @return
     */
    List<CampaignBottomDateViewDTO> getSubCampaignBottomDateList(ServiceContext serviceContext, List<Long> subCampaignIds,List<CampaignImpressionViewDTO.CampaignImpressionStatusEnum> noReadyStatusList);

    List<CampaignImpressionViewDTO> getCampaignImpressionInfoList(ServiceContext serviceContext, List<Long> subCampaignIds);
    List<BottomDateViewDTO> convertToBottomDateViewDTO(List<CampaignImpressionViewDTO> dateList);
    /**
     * 根据计划id获取人群 & 定向
     * @param serviceContext
     * @param campaignIds
     * @return
     */
    Map<Long, CampaignViewDTO> getCampaignTarget(ServiceContext serviceContext, List<Long> campaignIds);

    /**
     * 根据计划ids获取adzone
     * @param serviceContext
     * @param campaignIds
     * @return
     */
    Map<Long, List<CampaignAdzoneViewDTO>> getCampaignAdzone(ServiceContext serviceContext, List<Long> campaignIds);

    /**
     * 根据计划ID获取adzone
     * @param serviceContext
     * @param campaignIds
     * @return
     */
    List<CampaignAdzoneViewDTO> getCampaignAdzoneByCampaignIds(ServiceContext serviceContext, List<Long> campaignIds);

    /**
     * update campaignSetting
     * @param serviceContext
     * @param settingKey
     * @param settingValue
     * @param campaignId
     */
     void updateCampaignSetting(ServiceContext serviceContext,String settingKey,String settingValue,Long campaignId);

    /**
     * 更新询锁量信息
     */
    void updateCampaignInquiryAll(ServiceContext serviceContext, Long campaignId, List<CampaignInquiryViewDTO> inquiryDTOList);


    /**
     * 批量删除同一批settingkey
     * @param serviceContext
     * @param campaignViewDTOList
     * @param settingKeyList
     */
    void deleteCampaignSettingBatch(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList, List<String> settingKeyList);

    /**
     * 根据计划id查询绑定的tanxdealids
     * @param serviceContext
     * @param campaignIds
     * @return
     */
    List<Long> getCampaignTanxDealIds(ServiceContext serviceContext, List<Long> campaignIds) ;

    Map<Long,List<Long>> getSubCampaignTanxDealIdsMap(ServiceContext serviceContext, List<Long> campaignIds);
    /**
     * 根据子计划IDs查询pubdealIds
     * */
    List<String> getCampaignPubdealDealIds(ServiceContext serviceContext, List<Long> campaignIds);

    /**
     * 物理删除计划
     * @param serviceContext
     * @param campaignViewDTO
     */
    void physicsDelCampaign(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO);

    /**
     * 获取计划上的非实时优选人群
     * @param campaignViewDTO
     * @return
     */
    List<CampaignCrowdViewDTO> getBeforeCastingCrowd(CampaignViewDTO campaignViewDTO);

    /**
     * 获取计划上的实时优选白盒人群
     * @param campaignCrowdViewDTOList
     * @return
     */
    List<CampaignCrowdViewDTO> getDmpBeforeCastingCrowd(List<CampaignCrowdViewDTO> campaignCrowdViewDTOList);
    /**
     * 获取计划上的实时优选白盒人群
     * @param campaignCrowdViewDTOList
     * @return
     */
    List<CampaignCrowdViewDTO> getDmpCastingCrowd(List<CampaignCrowdViewDTO> campaignCrowdViewDTOList);

    /**
     * 获取计划上的TA场景算法填充人群
     * @param campaignCrowdViewDTOList
     * @return
     */
    List<CampaignCrowdViewDTO> getDmpAlgoCrowd(List<CampaignCrowdViewDTO> campaignCrowdViewDTOList) ;

    /**
     * 获取人群
     * @param serviceContext
     * @param campaignId
     * @param targetTypeEnum
     * @return
     */
    List<CampaignCrowdViewDTO> findCrowdByType(ServiceContext serviceContext, Long campaignId, BrandTargetTypeEnum targetTypeEnum) ;
    /**
     * 查询宝贝详情
     * @param serviceContext
     * @param ids
     * @return
     */
    List<ItemViewDTO> getItemByIdList(ServiceContext serviceContext, List<Long> ids);


    /**
     * 特秀/showmax创建黑盒人群
     * @param serviceContext
     * @param campaignViewDTO
     * @param campaignRealTimeOptimizeViewDTO
     * @param itemIds
     * @param shopIds
     * @return
     */
    List<CampaignCrowdViewDTO> createOptimizeCrowdList (ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, CampaignRealTimeOptimizeViewDTO campaignRealTimeOptimizeViewDTO, List<Long> itemIds, List<Long> shopIds);
    /**
     * 计算预定PV
     * @param mediaScope
     * @param sspProductLineId
     * @param price
     * @return
     */
     Long reCalCpmTotalMoney(Integer mediaScope,Integer sspProductLineId,Long amount,Long price);

     List<CampaignTemplateViewDTO> getCampaignTemplateIds(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList);

    /**
     * 根据计划id删除所有定向
     * @param serviceContext
     * @param campaignIds
     */
    void deleteAllTargetByCampaignIds(ServiceContext serviceContext, List<Long> campaignIds);

}
