package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.sale.CampaignGroupSaleViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupSaleValidateForAddOrUpdateCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupSaleAbilityParam;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
public class SelfServiceCampaignGroupSaleValidateForUpdateCampaignGroupAbility implements ICampaignGroupSaleValidateForAddOrUpdateCampaignGroupAbility, SelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupSaleAbilityParam abilityParam) {
        CampaignGroupSaleViewDTO campaignGroupSaleViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(campaignGroupSaleViewDTO, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "售卖信息不能为空");
        AssertUtil.assertTrue(campaignGroupSaleViewDTO.getSalesProjectId() != null, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "售卖项目不能为空");
        AssertUtil.assertTrue(campaignGroupSaleViewDTO.getBriefId() != null, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "BriefId不能为空");
        // 资源包
        AssertUtil.assertTrue(campaignGroupSaleViewDTO.getCustomerTemplateId() != null, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "客户模板ID不能为空");

        return null;
    }
}
