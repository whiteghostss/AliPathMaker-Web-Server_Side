package com.taobao.ad.brand.bp.domain.feed;


import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.dto.cat.CategoryViewDTO;
import com.taobao.ad.brand.bp.client.dto.item.ItemInventoryViewDTO;
import com.taobao.ad.brand.bp.client.dto.rule.RuleCheckResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.shop.ShopViewDTO;

import java.util.List;
import java.util.Map;

/**
 * feed服务 目前只有店铺
 *
 * @author yunhu.myh@taobao.com
 * @date 2023年07月26日
 */
public interface FeedRepository {

    List<CategoryViewDTO> getCatByIds(List<Long> categoryIds);

    Long getShopIdByMemberId(Long memberId);

    ShopViewDTO getShopInfoByMemberId(Long memberId);

    List<ItemInventoryViewDTO> getItemInventory(Long itemId, Long skuId);

    /**
     * 根据店铺ID获取用户ID
     *
     * @param shopId
     * @return
     */
    Long getUserIdByShopId(Long shopId);

    Long getShopIdByUserId(Long userId);

    Long getUserIdByItemId(Long itemId);

    /**
     * 商品准入结果
     *
     * @param itemId
     * @return
     */
    RuleCheckResultViewDTO checkAccess(ServiceContext serviceContext, Long itemId);
}
