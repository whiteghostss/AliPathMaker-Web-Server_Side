package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.sale.CampaignRightsViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignRightsValidateForAddOrUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignRightsAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSelfCampaignRightsValidateForAddOrUpdateCampaignAbility implements ICampaignRightsValidateForAddOrUpdateCampaignAbility, BrandSelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignRightsAbilityParam abilityParam) {
        CampaignRightsViewDTO campaignRightsViewDTO = abilityParam.getAbilityTarget();
        if (campaignRightsViewDTO == null) {
            return null;
        }
        if (CollectionUtils.isNotEmpty(campaignRightsViewDTO.getExcludeBrandIds())) {
            AssertUtil.assertTrue(campaignRightsViewDTO.getExcludeBrandIds().size() <= 10, "竞争品牌最多可选10个");
        }
        return null;
    }
}
