package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.cancel.CampaignGroupCancelViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupCancelCommandViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupCancelWarningSendNoticeAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupInitForCancelAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupValidateForCancelAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupInitForCancelAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupValidateForCancelAbilityParam;
import org.springframework.stereotype.Component;

import java.util.List;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR;

@Component
@BusinessAbility
public class DefaultCampaignGroupInitForCancelAbility implements ICampaignGroupInitForCancelAbility {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupInitForCancelAbilityParam abilityParam) {
        CampaignGroupCancelViewDTO campaignGroupCancelViewDTO = abilityParam.getAbilityTarget();
        CampaignGroupCancelCommandViewDTO cancelViewDTO = abilityParam.getCancelViewDTO();
        campaignGroupCancelViewDTO.setCancelMode(cancelViewDTO.getOperateMode());
        return null;
    }
}
