package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.taobao.ad.brand.bp.client.dto.effect.EffectAdvertiserViewDTO;
import com.taobao.ad.brand.bp.common.enums.BooleanEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.differ.Differs;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.EffectAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignAdvEffectiveValidateForBindAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignAdvValidateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EffectCampaignAdvEffectiveValidateForBindAbility implements ICampaignAdvEffectiveValidateForBindAbility, EffectAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignAdvValidateAbilityParam abilityParam) {
        List<EffectAdvertiserViewDTO> advertiserViewDTOS = abilityParam.getAbilityTargets();
        List<Long> advIds = abilityParam.getAdvIds();
        // 1. 校验
        List<Long> selectIds = advertiserViewDTOS.stream().map(EffectAdvertiserViewDTO::getId).distinct().collect(Collectors.toList());
        List<Long> diffIds =  Differs.diff(advIds,selectIds,String::valueOf);
        AssertUtil.assertTrue(CollectionUtils.isEmpty(diffIds),"广告主：%s未查询到", StringUtils.join(diffIds,","));

        // 校验adv状态
        Map<Long, EffectAdvertiserViewDTO> advertiserViewDTOMap = advertiserViewDTOS.stream().collect(Collectors.toMap(EffectAdvertiserViewDTO::getId, Function.identity(), (a1, a2) -> a2));
        List<Long> unSupportAdvIds = abilityParam.getAdvIds().stream().filter(advId -> !advertiserViewDTOMap.containsKey(advId) || !BooleanEnum.TRUE.getValue().equals(advertiserViewDTOMap.get(advId).getStatus())).collect(Collectors.toList());
        AssertUtil.assertTrue(CollectionUtils.isEmpty(unSupportAdvIds),"关联adv失败，\"%s\"是无效状态", StringUtils.join(unSupportAdvIds,","));

        return null;
    }
}
