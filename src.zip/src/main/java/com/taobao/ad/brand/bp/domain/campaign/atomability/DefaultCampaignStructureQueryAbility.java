package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.adzone.CampaignAdzoneViewDTO;
import com.alibaba.ad.brand.dto.campaign.audience.CampaignTargetViewDTO;
import com.alibaba.ad.brand.dto.campaign.keyword.CampaignKeywordViewDTO;
import com.alibaba.ad.brand.dto.campaign.audience.CampaignTargetScenarioViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdScenarioViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdViewDTO;
import com.alibaba.ad.brand.dto.campaign.frequence.CampaignFrequencyViewDTO;
import com.alibaba.ad.brand.dto.frequency.FrequencyViewDTO;
import com.alibaba.ad.brand.sdk.constant.audience.field.BrandTargetTypeEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.common.threadpooltask.CampaignFrequencyQueryTaskIdentifier;
import com.taobao.ad.brand.bp.common.threadpooltask.CampaignTargetQueryTaskIdentifier;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.frequency.repository.FrequencyRepository;
import com.taobao.ad.brand.bp.domain.keywordcenter.repository.KeywordRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

@Component
@BusinessAbility
public class DefaultCampaignStructureQueryAbility implements ICampaignStructureQueryAbility {
    @Resource
    private CampaignRepository campaignRepository;
    @Resource
    private FrequencyRepository frequencyRepository;
    @Resource
    private KeywordRepository keywordRepository;
    @Resource
    private CampaignTargetQueryTaskIdentifier campaignTargetQueryTaskIdentifier;
    @Resource
    private CampaignFrequencyQueryTaskIdentifier campaignFrequencyQueryTaskIdentifier;

    @Override
    public List<CampaignViewDTO> handle(ServiceContext context, CampaignStructureQueryAbilityParam abilityParam) {
        CampaignQueryViewDTO query = abilityParam.getAbilityTarget();
        CampaignQueryOption option = abilityParam.getQueryOption();
        //查询计划
        List<CampaignViewDTO> campaignViewDTOList = campaignRepository.queryCampaignList(context, query);
        if (CollectionUtils.isEmpty(campaignViewDTOList)) {
            return Lists.newArrayList();
        }
        return processCampaignInfo(context, campaignViewDTOList, option);
    }

    /**
     * 根据条件，执行Campaign处理
     *
     * @param context
     * @param campaignViewDTOList
     * @param option
     */
    protected List<CampaignViewDTO> processCampaignInfo(ServiceContext context, List<CampaignViewDTO> campaignViewDTOList, CampaignQueryOption option) {
        //默认初始化
        List<CampaignViewDTO> otherCampaignViewDTOList = Lists.newArrayList(campaignViewDTOList);
        if (option.isNeedChildren()) {
            List<Long> parentCampaignIds = campaignViewDTOList.stream().filter(item -> BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode().equals(item.getCampaignLevel())).map(item -> item.getId()).collect(Collectors.toList());
            //说明传进来的没有一级计划，都是二级计划的话不需要查询children
            if (CollectionUtils.isNotEmpty(parentCampaignIds)) {
                CampaignQueryViewDTO subQuery = new CampaignQueryViewDTO();
                subQuery.setParentCampaignIds(parentCampaignIds);
                List<CampaignViewDTO> subCampaignViewDTOList = campaignRepository.queryCampaignList(context, subQuery);
                otherCampaignViewDTOList.addAll(subCampaignViewDTOList);
                for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
                    List<CampaignViewDTO> subList = Lists.newArrayList();
                    for (CampaignViewDTO subCampaignViewDTO : subCampaignViewDTOList) {
                        if (!subCampaignViewDTO.getParentCampaignId().equals(campaignViewDTO.getId())) {
                            continue;
                        }
                        subList.add(subCampaignViewDTO);
                    }
                    campaignViewDTO.setSubCampaignViewDTOList(subList);
                }
            }
        }
        if (option.isNeedCampaignTree()) {
            List<CampaignViewDTO> result = Lists.newArrayList();
            //取出第一次查询中的一级计划，直接作为结果 后续补全二级
            List<CampaignViewDTO> firstQueryParentResult = campaignViewDTOList.stream().filter(item -> BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode().equals(item.getCampaignLevel())).collect(Collectors.toList());
            Set<Long> firstParentSet = firstQueryParentResult.stream().map(v -> v.getId()).collect(Collectors.toSet());
            result.addAll(firstQueryParentResult);

            //获取第一次查询中的二级计划，取出对应的一级计划id补全到结果中
            List<Long> firstQuerySubLevelParentIds = campaignViewDTOList.stream().filter(item -> BrandCampaignLevelEnum.LEVEL_TWO_CAMPAIGN.getCode().equals(item.getCampaignLevel())).map(item -> item.getParentCampaignId()).collect(Collectors.toList());
            //如果没有二级计划则所有的都是一级计划
            if (CollectionUtils.isNotEmpty(firstQuerySubLevelParentIds)) {
                CampaignQueryViewDTO parentQuery = new CampaignQueryViewDTO();
                parentQuery.setCampaignIds(firstQuerySubLevelParentIds);
                parentQuery.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
                RogerLogger.info("query complete firstQuerySubLevelParentIds:{}", JSONObject.toJSONString(firstQuerySubLevelParentIds));
                //查询一级计划且补全结果集中的一级计划
                List<CampaignViewDTO> parentCampaignViewDTOList = campaignRepository.queryCampaignList(context, parentQuery);
                parentCampaignViewDTOList = parentCampaignViewDTOList.stream().filter(
                        v -> !firstParentSet.contains(v.getId())).collect(Collectors.toList());
                otherCampaignViewDTOList.addAll(parentCampaignViewDTOList);
                result.addAll(parentCampaignViewDTOList);
            }
            List<Long> allParentIds = result.stream().map(item -> item.getId()).collect(Collectors.toList());
            RogerLogger.info("query complete first parentIds:{}", JSONObject.toJSONString(allParentIds));
            //根据一级查询二级计划
            if (CollectionUtils.isNotEmpty(allParentIds)) {
                CampaignQueryViewDTO subQuery = new CampaignQueryViewDTO();
                subQuery.setParentCampaignIds(allParentIds);
                subQuery.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_TWO_CAMPAIGN.getCode());
                List<CampaignViewDTO> subCampaignViewDTOList = campaignRepository.queryCampaignList(context, subQuery);
                otherCampaignViewDTOList.addAll(subCampaignViewDTOList);
                //组装父子关系
                for (CampaignViewDTO campaignViewDTO : result) {
                    List<CampaignViewDTO> subList = Lists.newArrayList();
                    for (CampaignViewDTO subCampaignViewDTO : subCampaignViewDTOList) {
                        if (!subCampaignViewDTO.getParentCampaignId().equals(campaignViewDTO.getId())) {
                            continue;
                        }
                        subList.add(subCampaignViewDTO);
                    }
                    campaignViewDTO.setSubCampaignViewDTOList(subList);
                }
            }
            campaignViewDTOList = result;
        }

        List<CampaignViewDTO> allCampaignViewDTOList = Lists.newArrayList(campaignViewDTOList);
        allCampaignViewDTOList.addAll(otherCampaignViewDTOList);
        //查询定向
        if (option.isNeedTarget()) {
            fillCampaignTarget(context, allCampaignViewDTOList);
        }
        // 查询频控
        if (option.isNeedFrequency()) {
            fillCampaignFrequency(context, allCampaignViewDTOList);
        }
        return campaignViewDTOList;
    }

    /**
     * 填充定向信息
     */
    private void fillCampaignTarget(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList) {
        List<Long> campaignIds = campaignViewDTOList.stream().map(item -> item.getId()).collect(Collectors.toList());
        List<List<Long>> campaignIdPartition = Lists.partition(campaignIds, 50);
        Map<Long, CampaignViewDTO> campaignTargetMap = Maps.newConcurrentMap();
        Map<Long, List<CampaignAdzoneViewDTO>> campaignAdzoneMap = Maps.newConcurrentMap();
        Map<Long, CampaignKeywordViewDTO> campaignKeywordMap = Maps.newConcurrentMap();
        TaskStream.consume(campaignTargetQueryTaskIdentifier, campaignIdPartition, (campaignIdList, index) -> {
                    Map<Long, CampaignViewDTO> campaignTarget = campaignRepository.getCampaignTarget(serviceContext, campaignIdList);
                    RogerLogger.info("campaignIdList {}, campaignTarget {}", JSON.toJSONString(campaignIdList), JSON.toJSONString(campaignTarget));
                    campaignTargetMap.putAll(campaignTarget);
                    Map<Long, List<CampaignAdzoneViewDTO>> campaignAdzone = campaignRepository.getCampaignAdzone(serviceContext, campaignIdList);
                    RogerLogger.info("campaignIdList {}, campaignAdzone {}", JSON.toJSONString(campaignIdList), JSON.toJSONString(campaignAdzone));
                    campaignAdzoneMap.putAll(campaignAdzone);
                    //关键词
                    Map<Long, CampaignKeywordViewDTO> campaignKeyword = keywordRepository.selectByCampaignIds(serviceContext, campaignIdList);
                    campaignKeywordMap.putAll(campaignKeyword);
                })
                .commit()
                .handle();

        for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
            Long campaignId = campaignViewDTO.getId();
            if(campaignViewDTO.getCampaignTargetScenarioViewDTO() == null){
                campaignViewDTO.setCampaignTargetScenarioViewDTO(new CampaignTargetScenarioViewDTO());
            }
            if(campaignViewDTO.getCampaignCrowdScenarioViewDTO() == null){
                campaignViewDTO.setCampaignCrowdScenarioViewDTO(new CampaignCrowdScenarioViewDTO());
            }
            // 定向
            if (campaignTargetMap.containsKey(campaignId)) {
                CampaignViewDTO target = campaignTargetMap.get(campaignId);

                List<CampaignTargetViewDTO> campaignTargetViewDTOList = Optional.ofNullable(target.getCampaignTargetScenarioViewDTO())
                        .map(CampaignTargetScenarioViewDTO::getCampaignTargetViewDTOList).orElse(Lists.newArrayList());                 ;
                campaignViewDTO.getCampaignTargetScenarioViewDTO().setCampaignTargetViewDTOList(mergeCampaignTarget(campaignViewDTO, campaignTargetViewDTOList));

                List<CampaignCrowdViewDTO> campaignCrowdViewDTOList = Optional.ofNullable(target.getCampaignCrowdScenarioViewDTO())
                        .map(CampaignCrowdScenarioViewDTO::getCampaignCrowdViewDTOList).orElse(Lists.newArrayList());
                campaignViewDTO.getCampaignCrowdScenarioViewDTO().setCampaignCrowdViewDTOList(campaignCrowdViewDTOList);
            }
            // 推广位
            if (campaignAdzoneMap.containsKey(campaignId)) {
                campaignViewDTO.getCampaignTargetScenarioViewDTO().setCampaignAdzoneViewDTOList(campaignAdzoneMap.get(campaignId));
            }
            //关键词
            if (campaignKeywordMap.containsKey(campaignId)) {
                campaignViewDTO.setCampaignKeywordViewDTO(campaignKeywordMap.get(campaignId));
            }
        }
    }

    /**
     * 填充频控信息
     */
    private void fillCampaignFrequency(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList) {
        List<Long> campaignIds = campaignViewDTOList.stream().map(item -> item.getId()).collect(Collectors.toList());
        List<List<Long>> campaignIdPartition = Lists.partition(campaignIds, 50);

        Map<Long, FrequencyViewDTO> campaignFrequencyMap = Maps.newConcurrentMap();
        TaskStream
                .consume(campaignFrequencyQueryTaskIdentifier, campaignIdPartition, (campaignIdList, index) -> {
                    Map<Long, FrequencyViewDTO> campaignFrequency = frequencyRepository.getCampaignFrequency(serviceContext, campaignIdList);
                    RogerLogger.info("campaignIdList {}, campaignFrequency {}", JSON.toJSONString(campaignIdList), JSON.toJSONString(campaignFrequency));
                    campaignFrequencyMap.putAll(campaignFrequency);
                })
                .commit()
                .handle();

        for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
            Long campaignId = campaignViewDTO.getId();
            if (campaignFrequencyMap.containsKey(campaignId)) {
                FrequencyViewDTO frequencyViewDTO = campaignFrequencyMap.get(campaignId);

                CampaignFrequencyViewDTO campaignFrequencyViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignFrequencyViewDTO())
                        .orElse(new CampaignFrequencyViewDTO());
                campaignFrequencyViewDTO.setFrequencyViewDTO(frequencyViewDTO);
                campaignViewDTO.setCampaignFrequencyViewDTO(campaignFrequencyViewDTO);
            }
        }
    }

    /**
     * 兼容定向，目前双写（campaign_setting和定向中心），下游链路切完后，定向中心配置下线
     *
     * @param campaignViewDTO
     * @param campaignTargetViewDTOList
     */
    private List<CampaignTargetViewDTO> mergeCampaignTarget(CampaignViewDTO campaignViewDTO, List<CampaignTargetViewDTO> campaignTargetViewDTOList) {
        //兼容小时定向，目前双写（campaign_setting和定向中心），下游链路切完后，定向中心配置下线
        //小时定向-来源于campaign_setting
        CampaignTargetViewDTO timePlusTargetFromCampaignSetting = Optional.ofNullable(campaignViewDTO.getCampaignTargetScenarioViewDTO()).map(CampaignTargetScenarioViewDTO::getCampaignTargetViewDTOList).orElse(Lists.newArrayList()).stream()
                .filter(targetViewDTO -> Objects.equals(BrandTargetTypeEnum.TIME_PLUS.getCode().toString(), targetViewDTO.getType()))
                .findFirst().orElse(null);

        //小时定向-来源于定向中心
        CampaignTargetViewDTO timePlusTargetFromTargetCenter = Optional.ofNullable(campaignTargetViewDTOList).orElse(Lists.newArrayList()).stream()
                .filter(targetViewDTO -> Objects.equals(BrandTargetTypeEnum.TIME_PLUS.getCode().toString(), targetViewDTO.getType()))
                .findFirst().orElse(null);

        //优先使用计划setting-key中的小时定向
        CampaignTargetViewDTO timePlusCampaignTargetViewDTO = Optional.ofNullable(timePlusTargetFromCampaignSetting).orElse(timePlusTargetFromTargetCenter);
        //未设置小时定向，不做处理
        if (timePlusCampaignTargetViewDTO == null) {
            return campaignTargetViewDTOList;
        }
        //重新设置定向数据
        List<CampaignTargetViewDTO> realCampaignTargetViewDTOList = Optional.ofNullable(campaignTargetViewDTOList).orElse(Lists.newArrayList()).stream()
                .filter(targetViewDTO -> !Objects.equals(BrandTargetTypeEnum.TIME_PLUS.getCode().toString(), targetViewDTO.getType()))
                .collect(Collectors.toList());
        realCampaignTargetViewDTOList.add(timePlusCampaignTargetViewDTO);
        return realCampaignTargetViewDTOList;
    }
}
