package com.taobao.ad.brand.bp.domain.report.constant;

/**
 * @author yuncheng.lyc
 */
public interface ReportAdcBizCodeConstant {

    /**
     * 动态维度
     */
    String DIMENSION_AUTO = "DIMENSION_AUTO";

}
