package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSaleOrderStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.google.common.collect.ImmutableMap;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesBriefSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesBriefViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.SalesBriefStateEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.SalesBriefRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupSyncBriefForOrderCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupTransitAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum.EDITED;
import static com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum.UNLOCKED;

@Component
@BusinessAbility
public class BrandOneBPCampaignGroupSyncBriefForOrderCampaignGroupAbility
        implements ICampaignGroupSyncBriefForOrderCampaignGroupAbility, BrandOneBPAtomAbilityRouter {

    @Resource
    private SalesBriefRepository salesBriefRepository;

    public final Map<Integer, Integer> campaignGroup2BriefStatusMap = ImmutableMap.<Integer, Integer>builder()
            .put(EDITED.getCode(), SalesBriefStateEnum.CONFIRMED.getValue())
            .put(UNLOCKED.getCode(), SalesBriefStateEnum.UNLOCK_CONFIRMED.getValue())
            .build();

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupTransitAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        if (!BizCampaignGroupToolsHelper.isSaleCampaignGroup(campaignGroupViewDTO)) {
            return null;
        }
        BrandCampaignGroupStatusEnum statusEnum = BrandCampaignGroupStatusEnum.getByCode(campaignGroupViewDTO.getStatus());
        AssertUtil.assertTrue(campaignGroup2BriefStatusMap.containsKey(statusEnum.getCode()),
                BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR,
                String.format("当前订单状态[%s]不支持订单信息同步至Brief", statusEnum.getDesc()));
        // 数据转换
        SalesBriefViewDTO salesBriefViewDTO = convertCampaignGroupViewDTO2BriefViewDTO(campaignGroupViewDTO);
        // 同步信息至Brief
        salesBriefRepository.acceptStatusEvent(salesBriefViewDTO);
        return null;
    }

    /**
     *
     * @param campaignGroupViewDTO
     * @return
     */
    public SalesBriefViewDTO convertCampaignGroupViewDTO2BriefViewDTO(CampaignGroupViewDTO campaignGroupViewDTO) {
        // 转换
        SalesBriefViewDTO briefViewDTO = new SalesBriefViewDTO();
        briefViewDTO.setOrderId(campaignGroupViewDTO.getId());
        briefViewDTO.setBriefId(campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getBriefId());
        briefViewDTO.setName(campaignGroupViewDTO.getName());
        briefViewDTO.setStatus(campaignGroup2BriefStatusMap.get(campaignGroupViewDTO.getStatus()));
        briefViewDTO.setDiscountAmount(campaignGroupViewDTO.getBudget());
        briefViewDTO.setTotalAmount(campaignGroupViewDTO.getBudget());
        briefViewDTO.setStartDate(campaignGroupViewDTO.getCampaignGroupContractViewDTO().getContractStartTime());
        briefViewDTO.setEndDate(campaignGroupViewDTO.getCampaignGroupContractViewDTO().getContractEndTime());
        // 子合同信息
        List<SalesBriefSaleGroupViewDTO> briefSaleGroupViewDTOS = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList()
                .stream().filter(this::isValidSaleGroup)
                .map(saleGroupInfoViewDTO -> {
                    SalesBriefSaleGroupViewDTO briefSaleGroupViewDTO = new SalesBriefSaleGroupViewDTO();
                    briefSaleGroupViewDTO.setId(saleGroupInfoViewDTO.getSaleGroupId());
                    Optional.ofNullable(saleGroupInfoViewDTO.getSaleProductLine()).ifPresent(saleProductLine -> briefSaleGroupViewDTO.setGroupProductLine(String.valueOf(saleProductLine)));
                    briefSaleGroupViewDTO.setBudget(saleGroupInfoViewDTO.getBudget());
                    briefSaleGroupViewDTO.setStartDate(BrandDateUtil.getDateMidnight(saleGroupInfoViewDTO.getStartDate()));
                    briefSaleGroupViewDTO.setEndDate(BrandDateUtil.getDateMidnight(saleGroupInfoViewDTO.getEndDate()));
                    briefSaleGroupViewDTO.setSaleType(saleGroupInfoViewDTO.getSaleType());
                    briefSaleGroupViewDTO.setSource(saleGroupInfoViewDTO.getSource());
                    if (CollectionUtils.isNotEmpty(saleGroupInfoViewDTO.getResourcePackageProductViewDTOList())) {
                        briefSaleGroupViewDTO.setSignPv(saleGroupInfoViewDTO.getAmount());
                    }

                    return briefSaleGroupViewDTO;
                }).collect(Collectors.toList());
        briefViewDTO.setSaleGroupList(briefSaleGroupViewDTOS);

        return briefViewDTO;
    }

    /**
     * 有效的分组
     * 非补量 & 非待下单状态
     * @param saleGroupInfoViewDTO
     * @return
     */
    private boolean isValidSaleGroup(SaleGroupInfoViewDTO saleGroupInfoViewDTO) {
        return !BrandSaleTypeEnum.BOOST.getCode().equals(saleGroupInfoViewDTO.getSaleType())
                && !BrandCampaignGroupSaleOrderStatusEnum.WAIT_ORDER.getCode().equals(saleGroupInfoViewDTO.getSaleGroupStatus());
    }

}
