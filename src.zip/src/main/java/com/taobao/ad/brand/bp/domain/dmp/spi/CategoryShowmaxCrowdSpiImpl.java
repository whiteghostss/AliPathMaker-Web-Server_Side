package com.taobao.ad.brand.bp.domain.dmp.spi;

//@AbilitySpiInstance(bizCode = ShowmaxCrowdSpi.SHOWMAX_CROWD_CATEGORY, name = "CategoryShowmaxCrowd", desc = "showmax人群能力SPI")

public class CategoryShowmaxCrowdSpiImpl extends DefaultShowmaxCrowdSpiImpl{
//    @Resource
//    private CrowdRepository crowdRepository;
//
//    /**
//     * 查询标签
//     */
//    @Override
//    public List<CommonViewDTO> queryShowmaxCrowdTagList(ServiceContext serviceContext, Long memberId,  List<Long> brandIds){
//        List<CommonViewDTO> result = crowdRepository.queryShowmaxCrowdTagList(serviceContext, memberId, RecommendCrowdTypeEnum.CATEGORY.getCode());
//        return result;
//    }
}
