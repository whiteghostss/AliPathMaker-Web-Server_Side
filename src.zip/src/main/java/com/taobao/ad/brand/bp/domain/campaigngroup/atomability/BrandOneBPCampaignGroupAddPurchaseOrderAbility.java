package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupPurchaseProcessViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupPurchaseOrderAbilityParam;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
public class BrandOneBPCampaignGroupAddPurchaseOrderAbility extends DefaultCampaignGroupAddPurchaseOrderAbility implements BrandOneBPAtomAbilityRouter {

    @Override
    public CampaignGroupPurchaseProcessViewDTO handle(ServiceContext serviceContext, CampaignGroupPurchaseOrderAbilityParam abilityParam) {
        return null;
    }
}
