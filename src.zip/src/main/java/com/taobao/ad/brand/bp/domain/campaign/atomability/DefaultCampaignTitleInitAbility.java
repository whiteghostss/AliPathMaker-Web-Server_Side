package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignTitleInitAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignTitleInitAbilityParam;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
public class DefaultCampaignTitleInitAbility implements ICampaignTitleInitAbility {
    @Override
    public String handle(ServiceContext serviceContext, CampaignTitleInitAbilityParam abilityParam) {
        CampaignViewDTO campaignViewDTO = abilityParam.getAbilityTarget();
        return campaignViewDTO.getTitle();
    }
}
