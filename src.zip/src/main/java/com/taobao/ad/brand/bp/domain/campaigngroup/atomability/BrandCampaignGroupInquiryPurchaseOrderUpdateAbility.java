package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.purchase.CampaignGroupPurchaseViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.setting.BrandCampaignGroupSettingKeyEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupInquiryPurchaseOrderUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupInquiryPurchaseOrderUpdateAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component
@BusinessAbility
public class BrandCampaignGroupInquiryPurchaseOrderUpdateAbility
        implements ICampaignGroupInquiryPurchaseOrderUpdateAbility, BrandAtomAbilityRouter {
    @Resource
    private CampaignGroupRepository campaignGroupRepository;

    @Override
    public Integer handle(ServiceContext serviceContext, CampaignGroupInquiryPurchaseOrderUpdateAbilityParam abilityParam) {
        Long campaignGroupId = abilityParam.getAbilityTarget();
        if(campaignGroupId == null){
            return 0;
        }
        List<Long> inquiryOrderIds = abilityParam.getInquiryOrderIds();
        List<Long> purchaseOrderIds = abilityParam.getPurchaseOrderIds();

        CampaignGroupViewDTO newCampaignGroupViewDTO = new CampaignGroupViewDTO();
        newCampaignGroupViewDTO.setId(campaignGroupId);

        CampaignGroupPurchaseViewDTO purchaseViewDTO = new CampaignGroupPurchaseViewDTO();
        purchaseViewDTO.setInquiryOrderIds(inquiryOrderIds);
        purchaseViewDTO.setPurchaseOrderIds(purchaseOrderIds);
        newCampaignGroupViewDTO.setCampaignGroupPurchaseViewDTO(purchaseViewDTO);
        Integer count = campaignGroupRepository.updateCampaignGroupPart(serviceContext, newCampaignGroupViewDTO);

        List<String> settingKeyList = Lists.newArrayList();
        if (CollectionUtils.isEmpty(inquiryOrderIds)) {
            settingKeyList.add(BrandCampaignGroupSettingKeyEnum.INQUIRY_ORDER_IDS.getKey());
        }
        if (CollectionUtils.isEmpty(purchaseOrderIds)) {
            settingKeyList.add(BrandCampaignGroupSettingKeyEnum.PURCHASE_ORDER_IDS.getKey());
        }
        campaignGroupRepository.deleteCampaignGroupSettingBatch(serviceContext, campaignGroupId, settingKeyList);
        return count;
    }
}
