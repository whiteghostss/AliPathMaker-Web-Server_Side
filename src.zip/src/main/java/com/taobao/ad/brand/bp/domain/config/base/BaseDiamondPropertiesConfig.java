package com.taobao.ad.brand.bp.domain.config.base;

import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created by xiutai on 18/3/13.
 */

public abstract class BaseDiamondPropertiesConfig extends BaseDiamondConfig {

    protected Map<String, String> configMap = Maps.newHashMap();

    protected boolean isSuccess = false;

    @Override
    protected void initDiamond(String config) {
        RogerLogger.info("DiamondConfig.initDiamond BaseDiamondPropertiesConfig param: {}", config);

        Map<String, String> cfgMap = Maps.newHashMap();
        List<String> list = Lists.newArrayList(StringUtils.split(config, "\r\n"));

        for (String line : list) {
            if (StringUtils.isNotEmpty(line)) {
                int index = line.indexOf("=");
                if (index > 0) {
                    try {
                        String key = line.substring(0, index);
                        String value = line.substring(index + 1);
                        cfgMap.put(key, value);
                    } catch (Exception e) {
                        RogerLogger.error(getGroupId() + ":" + getDataId() + ":" + e.getMessage(), e);
                    }
                }
            }
        }
        configMap = cfgMap;
        isSuccess = true;

    }

    public String getPropertyValue(String propertyKey) {
        return configMap.get(propertyKey);
    }

    public <T> T getPropertyValueAsJSONObject(String propertyKey, Class<T> clazz) {
        String retVal = configMap.get(propertyKey);
        if (retVal == null) {
            return null;
        }
        try {
            return JSON.parseObject(retVal, clazz);
        } catch (Exception e) {
            RogerLogger.error(retVal + " to " + clazz.getName() + " error:" + e.getMessage(), e);
            return null;
        }
    }

    public boolean isTrue(String propertyKey) {
        return "true".equals(configMap.get(propertyKey));
    }

    public boolean noTrue(String propertyKey) {
        return !"true".equals(configMap.get(propertyKey));
    }

    public String getPropertyValue(String propertyKey, String defaultValue) {
        String retVal = getPropertyValue(propertyKey);
        if (retVal == null) {
            retVal = defaultValue;
        }
        return retVal;
    }

    public Integer getPropertyValueAsInteger(String propertyKey) {
        String value = configMap.get(propertyKey);
        if (StringUtils.isNotBlank(value)) {
            return Integer.parseInt(value);
        }
        return null;
    }

    public Integer getPropertyValueAsInteger(String propertyKey, Integer defaultValue) {
        String value = configMap.get(propertyKey);
        if (StringUtils.isNotBlank(value)) {
            return Integer.parseInt(value);
        }
        return defaultValue;
    }

    public Long getPropertyValueAsLong(String propertyKey) {
        String value = configMap.get(propertyKey);
        if (StringUtils.isNotBlank(value)) {
            return Long.parseLong(value);
        }
        return null;
    }


    public Long getPropertyValueAsLong(String propertyKey, Long defaultValue) {
        String value = configMap.get(propertyKey);
        if (StringUtils.isNotBlank(value)) {
            return Long.parseLong(value);
        }
        return defaultValue;
    }

    public List<Long> getPropertyValueAsList(String propertyKey) {
        String value = configMap.get(propertyKey);
        if (StringUtils.isBlank(value)) {
            return Lists.newArrayList();
        }
        return Splitter.on(',').splitToList(value).stream().map(Long::parseLong).collect(Collectors.toList());
    }

    public List<String> getPropertyValueAsStringList(String propertyKey) {
        String value = configMap.get(propertyKey);
        if (StringUtils.isBlank(value)) {
            return Lists.newArrayList();
        }
        return Splitter.on(',').splitToList(value);
    }

    public List<Integer> getPropertyValueIntegerAsList(String propertyKey) {
        String value = configMap.get(propertyKey);
        if (StringUtils.isBlank(value)) {
            return Lists.newArrayList();
        }
        return Splitter.on(',').splitToList(value).stream().map(Integer::parseInt).collect(Collectors.toList());
    }

    public List<Integer> getPropertyValueAsIntegerList(String propertyKey) {
        String value = configMap.get(propertyKey);
        if (StringUtils.isBlank(value)) {
            return Lists.newArrayList();
        }
        return Splitter.on(',').splitToList(value).stream().map(Integer::parseInt).collect(Collectors.toList());
    }

    public List<Long> getPropertyValueAsLongList(String propertyKey) {
        String value = configMap.get(propertyKey);
        if (StringUtils.isBlank(value)) {
            return Lists.newArrayList();
        }
        return Splitter.on(',').splitToList(value).stream().map(Long::parseLong).collect(Collectors.toList());
    }

    public Map<String, String> getPropertyValueAsMap(String propertyKey) {
        String value = configMap.get(propertyKey);
        Map<String, String> result = Maps.newHashMap();
        try {
            result = Splitter.on(",").withKeyValueSeparator(":").split(value);
        } catch (Exception e) {
            RogerLogger.error("[getPropertyValueAsMap] error, propertyKey:" + propertyKey + ",value:" + value);
        }
        return result;
    }
}
