package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupLevelEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupValidateForFinishRevertCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupValidateForUnlockRevertAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupUnlockRevertAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupValidateForFinishCampaignGroupAbilityParam;
import org.springframework.stereotype.Component;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR;
import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_BREAK_RULE;

@Component
@BusinessAbility
public class DefaultCampaignGroupValidateForUnlockRevertAbility implements ICampaignGroupValidateForUnlockRevertAbility {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupUnlockRevertAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.assertTrue(!BrandCampaignGroupLevelEnum.LEVEL_TWO.getCode().equals(campaignGroupViewDTO.getCampaignGroupLevel()),
                PARAM_BREAK_RULE, "订单不支持该操作");
        return null;
    }
}
