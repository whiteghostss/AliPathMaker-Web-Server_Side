package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.setting.BrandCampaignSettingKeyEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignUnbindForCartItemSolutionDeleteAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignUnbindForCartItemSolutionDeleteAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCampaignUnbindForCartItemSolutionDeleteAbility
        implements ICampaignUnbindForCartItemSolutionDeleteAbility, SelfServiceAtomAbilityRouter {

    private final CampaignRepository campaignRepository;

    private static final List<String> UN_BIND_SETTING_KET_LIST = Lists.newArrayList(
            BrandCampaignSettingKeyEnum.CAMPAIGN_GROUP_ID.getKey(),
            BrandCampaignSettingKeyEnum._CAMPAIGN_GROUP_ID.getKey(),
            BrandCampaignSettingKeyEnum.MAIN_CAMPAIGN_GROUP_ID.getKey(),
            BrandCampaignSettingKeyEnum.CUSTOMER_TEMPLATE_ID.getKey(),
            BrandCampaignSettingKeyEnum.RESOURCE_PACKAGE_PRODUCT_ID.getKey(),
            BrandCampaignSettingKeyEnum.SALE_GROUP_ID.getKey());


    @Override
    public Void handle(ServiceContext serviceContext, CampaignUnbindForCartItemSolutionDeleteAbilityParam abilityParam) {
        if (CollectionUtils.isEmpty(abilityParam.getAbilityTargets())) {
            return null;
        }
        List<CampaignViewDTO> flatCampaignList = Lists.newArrayList();
        for (CampaignViewDTO campaignViewDTO : abilityParam.getAbilityTargets()) {
            flatCampaignList.add(campaignViewDTO);
            if (CollectionUtils.isNotEmpty(campaignViewDTO.getSubCampaignViewDTOList())) {
                for (CampaignViewDTO subCampaignViewDTO : campaignViewDTO.getSubCampaignViewDTOList()) {
                    flatCampaignList.add(subCampaignViewDTO);
                }
            }
        }
        campaignRepository.deleteCampaignSettingBatch(serviceContext, flatCampaignList, UN_BIND_SETTING_KET_LIST);
        return null;
    }
}
