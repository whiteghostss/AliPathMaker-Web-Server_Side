package com.taobao.ad.brand.bp.domain.adgroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.brand.dto.common.SchemaConfigViewDTO;
import com.alibaba.ad.brand.dto.common.WakeupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupWakeupTypeEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.SchemaEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupWakeUpValidateForAddAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupWakeUpValidateForAddAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.List;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_ILLEGAL;
import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_REQUIRED;

@Component
@BusinessAbility
public class BrandSelfAdgroupWakeUpValidateForAddAbility implements IAdgroupWakeUpValidateForAddAbility, BrandSelfServiceAtomAbilityRouter {

    private static final List<Integer> WAKEUP_TYPE_LIST = Lists.newArrayList(
            BrandCampaignGroupWakeupTypeEnum.NON_WAKEUP.getCode(),
            BrandCampaignGroupWakeupTypeEnum.SINGLE_WAKEUP.getCode());

    @Override
    public Void handle(ServiceContext serviceContext, AdgroupWakeUpValidateForAddAbilityParam abilityParam) {
        WakeupViewDTO wakeupViewDTO = abilityParam.getAbilityTarget();
        if(wakeupViewDTO == null){
            return null;
        }
        if (BrandBoolEnum.BRAND_TRUE.getCode().equals(wakeupViewDTO.getIsOpenWakeup())) {
            AssertUtil.assertTrue(BizCodeEnum.BRANDAD.getBizCode().equals(serviceContext.getBizCode()), PARAM_ILLEGAL, "仅“UD全域品牌营销”业务场景支持单元自定义唤端配置");
            AssertUtil.notNull(wakeupViewDTO.getWakeupType(), PARAM_REQUIRED, "唤端类型不能为空");
            AssertUtil.assertTrue(WAKEUP_TYPE_LIST.contains(wakeupViewDTO.getWakeupType()), PARAM_ILLEGAL,"唤端类型不合法，请检查后重试");
            if (!BrandCampaignGroupWakeupTypeEnum.NON_WAKEUP.getCode().equals(wakeupViewDTO.getWakeupType())) {
                AssertUtil.assertTrue(CollectionUtils.isNotEmpty(wakeupViewDTO.getSchemaConfigViewDTOList()), PARAM_REQUIRED, "唤醒配置不能为空");
                SchemaConfigViewDTO schemaConfigViewDTO = wakeupViewDTO.getSchemaConfigViewDTOList().get(0);
                AssertUtil.notNull(schemaConfigViewDTO.getSchemaId(), PARAM_REQUIRED, "唤端APP不能为空");
                SchemaEnum schemaEnum = SchemaEnum.getByValue(schemaConfigViewDTO.getSchemaId().intValue());
                AssertUtil.notNull(schemaEnum, PARAM_ILLEGAL, "唤端APP不正确，请检查后重试");
                if (SchemaEnum.WEIXIN_XIAOCHENGXU == schemaEnum) {
                    AssertUtil.notNull(schemaConfigViewDTO.getSchemaConfigDetailViewDTO(), PARAM_REQUIRED, "小程序ID和小程序链接不能为空");
                    AssertUtil.assertTrue(StringUtils.isNotBlank(schemaConfigViewDTO.getSchemaConfigDetailViewDTO().getAppId()), PARAM_REQUIRED, "小程序ID不能为空");
                    AssertUtil.assertTrue(schemaConfigViewDTO.getSchemaConfigDetailViewDTO().getAppId().startsWith("gh_"),"小程序ID的格式不正确");
                    AssertUtil.assertTrue(StringUtils.isNotBlank(schemaConfigViewDTO.getSchemaConfigDetailViewDTO().getAppPath()), PARAM_REQUIRED, "小程序链接不能为空");
                }
            }
        }
        return null;
    }
}
