package com.taobao.ad.brand.bp.domain.shopwindow.repository;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandBundleViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSkuViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.query.BrandBundleQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.query.BrandSkuQueryViewDTO;

import java.util.List;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/6/26
 **/
public interface BrandSkuRepository {


    List<BrandSkuViewDTO> findSkuList(ServiceContext serviceContext, BrandSkuQueryViewDTO brandSkuQueryViewDTO);

    List<BrandSkuViewDTO> findSkuList(ServiceContext serviceContext, List<Long> skuIds);

    /**
     * 根据ID获取sku信息
     * @param serviceContext
     * @param id
     * @return
     */
    BrandSkuViewDTO get(ServiceContext serviceContext, Long id);

    /**
     * 查询套餐包信息
     * @param serviceContext
     * @param bundleId
     * @return
     */
    BrandBundleViewDTO getBundleDetail(ServiceContext serviceContext, Long bundleId);

    /**
     * 查询套餐包列表
     * @param serviceContext
     * @param queryViewDTO
     * @return
     */
    List<BrandBundleViewDTO> findBundleList(ServiceContext serviceContext, BrandBundleQueryViewDTO queryViewDTO);
}
