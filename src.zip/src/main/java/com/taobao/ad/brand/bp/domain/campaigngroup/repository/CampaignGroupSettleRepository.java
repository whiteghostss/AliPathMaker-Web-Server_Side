package com.taobao.ad.brand.bp.domain.campaigngroup.repository;

import java.util.List;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.dto.campaign.settle.CampaignSettleQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.settle.CampaignSettleViewDTO;

/**
 * @author yanjingang
 * @date 2023/4/6
 */
public interface CampaignGroupSettleRepository {


    List<CampaignSettleViewDTO> getCampaignSettleList(ServiceContext context, CampaignSettleQueryViewDTO campaignSettleQueryViewDTO);

}
