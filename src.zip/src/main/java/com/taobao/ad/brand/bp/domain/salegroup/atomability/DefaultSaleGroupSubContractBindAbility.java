package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSubContractViewDTO;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupSubContractBindAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupSubContractBindAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Component
@BusinessAbility
public class DefaultSaleGroupSubContractBindAbility implements ISaleGroupSubContractBindAbility {

    @Resource
    private CampaignGroupRepository campaignGroupRepository;

    @Override
    public Set<Long> handle(ServiceContext serviceContext, SaleGroupSubContractBindAbilityParam abilityParam) {
        // 参数
        List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList = abilityParam.getAbilityTargets();
        List<CampaignGroupSubContractViewDTO> subContractViewDTOList = abilityParam.getSubContractViewDTOList();
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        List<Long> targetSaleGroupIds = abilityParam.getTargetSaleGroupIds();
        // 返回结果
        Set<Long> updateSaleGroupIdSet = Sets.newHashSet();
        // 获取saleProductLine与子合同ID的关系
        Map<Integer, Long> saleProductLineSubContractMap = getSaleProductLineSubContractMap(campaignGroupViewDTO, subContractViewDTOList);
        if (MapUtils.isEmpty(saleProductLineSubContractMap)) {
            return updateSaleGroupIdSet;
        }
        for (SaleGroupInfoViewDTO saleGroupInfo : saleGroupInfoViewDTOList) {
            if (!saleProductLineSubContractMap.containsKey(saleGroupInfo.getSaleProductLine())) {
                continue;
            }
            if (CollectionUtils.isNotEmpty(targetSaleGroupIds)) {
                if (!targetSaleGroupIds.contains(saleGroupInfo.getSaleGroupId())) {
                    continue;
                }
            }
            Long subContractId = saleProductLineSubContractMap.get(saleGroupInfo.getSaleProductLine());
            if (saleGroupInfo.getSubContractId() == null || !saleGroupInfo.getSubContractId().equals(subContractId)) {
                saleGroupInfo.setSubContractId(subContractId);
                updateSaleGroupIdSet.add(saleGroupInfo.getSaleGroupId());
            }
        }
        // 执行更新
        if (CollectionUtils.isNotEmpty(updateSaleGroupIdSet)) {
            List<SaleGroupInfoViewDTO> updateSaleGroupList = saleGroupInfoViewDTOList.stream()
                    .filter(saleGroup -> updateSaleGroupIdSet.contains(saleGroup.getSaleGroupId()))
                    .map(saleGroup -> {
                        SaleGroupInfoViewDTO updateSaleGroup = new SaleGroupInfoViewDTO();
                        updateSaleGroup.setId(saleGroup.getId());
                        updateSaleGroup.setSaleGroupId(saleGroup.getSaleGroupId());
                        updateSaleGroup.setSubContractId(saleGroup.getSubContractId());
                        return updateSaleGroup;
                    }).collect(Collectors.toList());
            campaignGroupRepository.updateSaleGroupPart(serviceContext, updateSaleGroupList);
        }
        return updateSaleGroupIdSet;
    }

    /**
     * 以Brief入参子合同参数为准
     *
     * @param campaignGroupViewDTO
     * @param subContractViewDTOList
     * @return
     */
    private Map<Integer, Long> getSaleProductLineSubContractMap(CampaignGroupViewDTO campaignGroupViewDTO, List<CampaignGroupSubContractViewDTO> subContractViewDTOList) {
        if (CollectionUtils.isNotEmpty(subContractViewDTOList)) {
            return subContractViewDTOList.stream()
                    .collect(Collectors.toMap(CampaignGroupSubContractViewDTO::getSaleProductLine, CampaignGroupSubContractViewDTO::getSubContractId, (a1, a2) -> a1));
        }

        return campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream()
                .filter(t -> t.getSaleProductLine() != null && t.getSubContractId() != null)
                .collect(Collectors.toMap(SaleGroupInfoViewDTO::getSaleProductLine, SaleGroupInfoViewDTO::getSubContractId, (a1, a2) -> a1));
    }
}
