package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.salegroup.CampaignGroupSaleGroupViewDTO;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupBusinessLineEnum;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupSaleGroupValidateForAddOrUpdateCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupSaleGroupAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@BusinessAbility
public class BrandOneBPCampaignGroupSaleGroupValidateForAddOrUpdateCampaignGroupAbility
        implements ICampaignGroupSaleGroupValidateForAddOrUpdateCampaignGroupAbility, BrandOneBPAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupSaleGroupAbilityParam abilityParam) {
        if (!BizCampaignGroupToolsHelper.isSaleCampaignGroup(abilityParam.getCampaignGroupViewDTO())) {
            return null;
        }
        CampaignGroupSaleGroupViewDTO campaignGroupSaleGroupViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(campaignGroupSaleGroupViewDTO, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "订单分组信息不能为空");
        List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupList = abilityParam.getResourcePackageSaleGroupList();
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(campaignGroupSaleGroupViewDTO.getSaleGroupInfoViewDTOList()) && CollectionUtils.isNotEmpty(resourcePackageSaleGroupList), BrandOneBPBaseErrorCode.PARAM_REQUIRED, "售卖分组信息不能为空");

        // 校验分组-业务场景
        resourcePackageSaleGroupList.forEach(resourcePackageSaleGroup -> {
            AssertUtil.assertTrue(StringUtils.isNotBlank(SaleGroupBusinessLineEnum.getDesc(resourcePackageSaleGroup.getBusinessLine())), BrandOneBPBaseErrorCode.PARAM_REQUIRED, "售卖分组信息(业务场景)不正确");
        });

        return null;
    }
}
