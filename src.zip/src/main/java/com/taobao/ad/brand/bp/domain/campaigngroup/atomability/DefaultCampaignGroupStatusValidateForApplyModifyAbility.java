package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.SalesBriefRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupStatusValidateForApplyModifyAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupAbilityParam;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR;

/**
 * @author yanjingang
 * @date 2024/11/25
 */
@Component
@BusinessAbility
public class DefaultCampaignGroupStatusValidateForApplyModifyAbility implements ICampaignGroupStatusValidateForApplyModifyAbility {

    @Resource
    private SalesBriefRepository salesBriefRepository;

    /**
     * 主订单-申请修改售卖分组时的订单状态
     */
    private static final List<Integer> validMainCampaignGroupStatusOnApplyModify = Lists.newArrayList(
            BrandCampaignGroupStatusEnum.EDITED.getCode(),
            BrandCampaignGroupStatusEnum.UNLOCKED.getCode(),
            BrandCampaignGroupStatusEnum.ORDER_ING.getCode()
    );

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupAbilityParam abilityParam) {
        CampaignGroupViewDTO mainCampaignGroup = abilityParam.getAbilityTarget();
        // 1. 通用校验：主订单状态
        AssertUtil.assertTrue(validMainCampaignGroupStatusOnApplyModify.contains(mainCampaignGroup.getStatus()), BIZ_BREAK_RULE_ERROR, "当前订单状态不支持修改订单");
        // 2. 校验brief是否支持修改
        if (BrandCampaignGroupStatusEnum.ORDER_ING.getCode().equals(mainCampaignGroup.getStatus())) {
            boolean canModify = salesBriefRepository.canModify(mainCampaignGroup.getCampaignGroupSaleViewDTO().getBriefId());
            AssertUtil.assertTrue(canModify, BIZ_BREAK_RULE_ERROR, "当前合同状态不支持修改订单");
        }
        return null;
    }
}
