package com.taobao.ad.brand.bp.domain.shopwindow.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.base.DateViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.rule.RuleCheckResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandBundleViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSpuConfigViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSpuViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.ICartItemAdDateJudgeAbility;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.param.CartItemAdDateJudgeAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCartItemAdDateJudgeAbility implements ICartItemAdDateJudgeAbility, SelfServiceAtomAbilityRouter {

    @Override
    public RuleCheckResultViewDTO handle(ServiceContext serviceContext, CartItemAdDateJudgeAbilityParam abilityParam) {
        BrandSpuViewDTO spuViewDTO = abilityParam.getSpuViewDTO();
        AssertUtil.notNull(spuViewDTO,"spu不能为空");

        DateViewDTO dateViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(dateViewDTO,"投放周期不能为空");

        //套餐包时间
        BrandBundleViewDTO bundleViewDTO = abilityParam.getBundleViewDTO();

        //【日期】资源包产品日期的子集
        ResourcePackageProductViewDTO resourcePackageProductViewDTO = abilityParam.getResourcePackageProductViewDTO();
        AssertUtil.notNull(resourcePackageProductViewDTO, "资源位不存在");
        AssertUtil.notEmpty(resourcePackageProductViewDTO.getBandPriceList(), "资源位支持投放周期不存在");

        AssertUtil.notNull(dateViewDTO.getStartDate(),"投放开始时间不能为空");
        AssertUtil.notNull(dateViewDTO.getEndDate(),"投放结束时间不能为空");

        if(!BrandDateUtil.isBeforeAndEqual(dateViewDTO.getStartDate(), dateViewDTO.getEndDate())){
            return RuleCheckResultViewDTO.builder().isPass(BrandBoolEnum.BRAND_FALSE.getCode()).reason("投放开始时间小于等于结束时间").build();
        }
        //取最大开始投放周期
        Date minStartDate = resourcePackageProductViewDTO.getBandPriceList().stream().map(ResourcePackageProductPriceViewDTO::getStartDate).min(Date::compareTo).orElse(null);
        minStartDate = BrandDateUtil.maxDate(BrandDateUtil.getTomorrowDate(),minStartDate);
        //结束投放周期
        Date maxEndDate = resourcePackageProductViewDTO.getBandPriceList().stream().map(ResourcePackageProductPriceViewDTO::getEndDate).max(Date::compareTo).orElse(null);
        if(!BrandDateUtil.isBeforeAndEqual(minStartDate, dateViewDTO.getStartDate())){
            StringBuilder builder = new StringBuilder(String.format("投放开始时间需大于等于%s日，请调整投放日期",BrandDateUtil.date2String(minStartDate)));
            if(bundleViewDTO != null){
                builder.append(String.format("如整周期不足%s天，不能下单",bundleViewDTO.getMinDay()));
            }
            return RuleCheckResultViewDTO.builder().isPass(BrandBoolEnum.BRAND_FALSE.getCode()).reason(builder.toString()).build();
        }
        if(!BrandDateUtil.isAfterAndEqual(BrandDateUtil.getDateFullMidnight(maxEndDate), dateViewDTO.getEndDate())){
            StringBuilder builder = new StringBuilder(String.format("投放结束时间需小于等于%s日，请调整投放日期",BrandDateUtil.date2String(maxEndDate)));
            if(bundleViewDTO != null){
                builder.append(String.format("如整周期不足%s天，不能下单",bundleViewDTO.getMinDay()));
            }
            return RuleCheckResultViewDTO.builder().isPass(BrandBoolEnum.BRAND_FALSE.getCode()).reason(builder.toString()).build();
        }
        //SPU屏蔽周期判断
        List<DateViewDTO> blockDateList = Optional.ofNullable(spuViewDTO.getSpuConfig()).map(BrandSpuConfigViewDTO::getBlockDateList).orElse(Lists.newArrayList());
        if(CollectionUtils.isEmpty(blockDateList)){
            return RuleCheckResultViewDTO.builder().isPass(BrandBoolEnum.BRAND_TRUE.getCode()).build();
        }
        for (DateViewDTO blockDateViewDTO : blockDateList) {
            boolean mixed = BrandDateUtil.isMixed(blockDateViewDTO.getStartDate(), blockDateViewDTO.getEndDate(),
                    dateViewDTO.getStartDate(), dateViewDTO.getEndDate());
            if(mixed){
                RogerLogger.info("计划投放周期（%s）命中了SPU屏蔽周期（%s），不允许进行广告投放", JSON.toJSONString(dateViewDTO),JSON.toJSONString(blockDateViewDTO));
                return RuleCheckResultViewDTO.builder().isPass(BrandBoolEnum.BRAND_FALSE.getCode()).reason("您所选的投放周期中部分日期不能选择，请调整投放周期").build();
            }
        }
        if(bundleViewDTO != null){
            Integer maxDay = bundleViewDTO.getMaxDay();
            Integer minDay = bundleViewDTO.getMinDay();
            Integer dateRange = BrandDateUtil.getDateRange(dateViewDTO.getStartDate(), dateViewDTO.getEndDate())+1;
            if(dateRange < minDay || dateRange > maxDay){
                RogerLogger.info("计划投放周期（%s）不满足套餐包要求的投放天数（%s），不允许进行广告投放", JSON.toJSONString(dateViewDTO),JSON.toJSONString(bundleViewDTO));
                return RuleCheckResultViewDTO.builder().isPass(BrandBoolEnum.BRAND_FALSE.getCode()).reason("您所选的投放周期不满足套餐包要求的投放天数，请调整投放周期").build();
            }
        }
        return RuleCheckResultViewDTO.builder().isPass(BrandBoolEnum.BRAND_TRUE.getCode()).build();
    }
}
