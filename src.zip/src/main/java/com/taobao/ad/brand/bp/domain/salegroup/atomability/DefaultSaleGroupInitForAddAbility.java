package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSaleOrderStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupInitForAddAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupInitAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Objects;

@Component
@BusinessAbility
public class DefaultSaleGroupInitForAddAbility implements ISaleGroupInitForAddAbility {

    @Override
    public Void handle(ServiceContext serviceContext, SaleGroupInitAbilityParam abilityParam) {
        if (CollectionUtils.isEmpty(abilityParam.getAbilityTargets()) || CollectionUtils.isEmpty(abilityParam.getOperateSaleGroupIds())) {
            return null;
        }
        List<Long> addSaleGroupIds = abilityParam.getOperateSaleGroupIds();
        Map<Long, ResourcePackageSaleGroupViewDTO> packageSaleGroupMap = abilityParam.getResourcePackageSaleGroupMap();
        Map<Integer, Long> saleProductLine2SubContractIdMap = abilityParam.getSaleProductLine2SubContractIdMap();
        for (SaleGroupInfoViewDTO saleGroupInfoViewDTO : abilityParam.getAbilityTargets()) {
            if (!packageSaleGroupMap.containsKey(saleGroupInfoViewDTO.getSaleGroupId()) || !addSaleGroupIds.contains(saleGroupInfoViewDTO.getSaleGroupId())) {
                continue;
            }
            ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO = packageSaleGroupMap.get(saleGroupInfoViewDTO.getSaleGroupId());
            saleGroupInfoViewDTO.setMainSaleGroupId(resourcePackageSaleGroupViewDTO.getMainGroupId());
            saleGroupInfoViewDTO.setSaleType(resourcePackageSaleGroupViewDTO.getSaleType());
            saleGroupInfoViewDTO.setBudget(resourcePackageSaleGroupViewDTO.getBudget());
            saleGroupInfoViewDTO.setStartDate(resourcePackageSaleGroupViewDTO.getStartDate());
            saleGroupInfoViewDTO.setEndDate(resourcePackageSaleGroupViewDTO.getEndDate());
            saleGroupInfoViewDTO.setSource(abilityParam.getSaleGroupSourceEnum().getCode());
            saleGroupInfoViewDTO.setSaleProductLine(resourcePackageSaleGroupViewDTO.getSaleProductLine());
            saleGroupInfoViewDTO.setSaleBusinessLine(resourcePackageSaleGroupViewDTO.getBusinessLine());
            saleGroupInfoViewDTO.setSaleGroupStatus(BrandCampaignGroupSaleOrderStatusEnum.WAIT_ORDER.getCode());
            saleGroupInfoViewDTO.setHasInquiryPriority(resourcePackageSaleGroupViewDTO.getHasInquiryPriority() == null
                    ? BrandBoolEnum.BRAND_FALSE.getCode() : resourcePackageSaleGroupViewDTO.getHasInquiryPriority());
            saleGroupInfoViewDTO.setInquiryDate(resourcePackageSaleGroupViewDTO.getInquiryDate());
            saleGroupInfoViewDTO.setInquiryBatch(resourcePackageSaleGroupViewDTO.getInquiryBatch());
            saleGroupInfoViewDTO.setBusinessType(resourcePackageSaleGroupViewDTO.getBusinessType());
            if (Objects.nonNull(saleProductLine2SubContractIdMap) && saleProductLine2SubContractIdMap.containsKey(resourcePackageSaleGroupViewDTO.getSaleProductLine())) {
                saleGroupInfoViewDTO.setSubContractId(saleProductLine2SubContractIdMap.get(resourcePackageSaleGroupViewDTO.getSaleProductLine()));
            }
        }

        return null;
    }
}
