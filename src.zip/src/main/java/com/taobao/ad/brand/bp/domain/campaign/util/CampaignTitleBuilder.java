package com.taobao.ad.brand.bp.domain.campaign.util;

import com.taobao.ad.brand.bp.common.constant.Constant;
import lombok.Builder;

import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Builder
public class CampaignTitleBuilder {
    Long id;
    String customerOrientedResource;
    String customerOrientedMedia;
    String crowdDesc;
    String startTime;
    String endTime;
    String distinctValue;
    final int MAX_LENGTH = 100;

    /**
     * Campaign Title最大长度为100
     * 名字过长的情况下按照 人群 -> 资源 -> 媒体 的顺序删减
     * */
    public String getNormalizedName() {
        init();
        String result = generateTitle();

        if (result.length() <= MAX_LENGTH) {
            return result;
        }

        // 字段部分删减即可满足要求
        if (crowdDesc != null && result.length() - crowdDesc.length() + 2 <= MAX_LENGTH) {
            int gap = result.length() - MAX_LENGTH;
            crowdDesc = crowdDesc.substring(0, crowdDesc.length() - gap);
        } else {
            crowdDesc = null;
        }
        result = generateTitle();
        if (result.length() <= MAX_LENGTH) {
            return result;
        }

        // 尝试删减资源字段
        if (customerOrientedResource != null && result.length() - customerOrientedResource.length() + 2 <= MAX_LENGTH) {
            int gap = result.length() - MAX_LENGTH;
            customerOrientedResource = customerOrientedResource.substring(0, customerOrientedResource.length() - gap);
        } else {
            customerOrientedResource = null;
        }
        result = generateTitle();
        if (result.length() <= MAX_LENGTH) {
            return result;
        }

        // 尝试删减媒体字段
        if (customerOrientedMedia != null && result.length() - customerOrientedMedia.length() + 2 <= MAX_LENGTH) {
            int gap = result.length() - MAX_LENGTH;
            customerOrientedMedia = customerOrientedMedia.substring(0, customerOrientedMedia.length() - gap);
        } else {
            customerOrientedMedia = null;
        }
        result = generateTitle();

        return result;
    }

    private void init() {
        // 初始化 distinctValue
        String idStr = (id != null) ? id.toString() : "";
        distinctValue = !idStr.isEmpty() && idStr.length() >= 6 ? idStr.substring(idStr.length() - 6)
                : String.format("%06d", (this.hashCode() & Integer.MAX_VALUE) % 1000000);
        // 去除特殊符号
        customerOrientedResource = removeSpecialCharacters(customerOrientedResource);
        customerOrientedMedia = removeSpecialCharacters(customerOrientedMedia);
        crowdDesc = removeSpecialCharacters(crowdDesc);
    }

    public String removeSpecialCharacters(String input) {
        // 使用正则表达式匹配并替换非数字、字母、汉字、下划线、中划线的字符
        String result = Optional.ofNullable(input)
                .map(str -> str.replaceAll("[^\\w\u4e00-\u9fa5-]", ""))
                .orElse(null);
        return result;
    }

    private String generateTitle() {
        return Stream.of(customerOrientedResource, customerOrientedMedia, crowdDesc, startTime, endTime, distinctValue)
                .filter(value -> value != null && !value.isEmpty())
                .collect(Collectors.joining(Constant.UNDERLINE));
    }
}


