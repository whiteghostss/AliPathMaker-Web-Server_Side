package com.taobao.ad.brand.bp.domain.ssp;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.dto.mr.MaterialRuleDetailViewDTO;
import com.taobao.ad.brand.bp.client.dto.mr.MaterialRuleViewDTO;

import java.util.List;

/**
 * @author jixiu.lj
 * @date 2023/3/21 09:59
 */
public interface MaterialRuleRepository {

    /**
     * 根据ID查询MR 场景有限没有转ViewDTO
     * @param serviceContext
     * @param ruleIds
     * @return
     */
    List<MaterialRuleDetailViewDTO> getMaterialRuleDetailList(ServiceContext serviceContext, List<Long> ruleIds);

    /**
     * 根据ID查询MR 场景有限没有转ViewDTO
     * @param serviceContext
     * @param ruleIds
     * @return
     */
    List<MaterialRuleViewDTO> getMaterialRuleList(ServiceContext serviceContext, List<Long> ruleIds);
    /**
     * 根据ID查询MR 场景有限没有转ViewDTO
     * @param serviceContext
     */
    MaterialRuleViewDTO getMaterialRuleByMrId(ServiceContext serviceContext, Long ruleId);

}
