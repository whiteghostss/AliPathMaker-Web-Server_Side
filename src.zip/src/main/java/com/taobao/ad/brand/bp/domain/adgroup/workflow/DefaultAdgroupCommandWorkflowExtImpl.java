package com.taobao.ad.brand.bp.domain.adgroup.workflow;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.ability.param.BizAdgroupAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.workflow.BizAdgroupCommandWorkflowExt;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.workflow.param.BizAdgroupBindWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.workflow.param.BizAdgroupDirectCreativeGenerateWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.workflow.param.BizAdgroupWorkflowParam;

/**
 * Description:
 * <p>
 * date: 2023/10/24 2:51 PM
 *
 * @author shiyan
 * @version 1.0
 */
@BusinessAbility
public class DefaultAdgroupCommandWorkflowExtImpl implements BizAdgroupCommandWorkflowExt {
    /**
     * 业务新增数据初始化
     *
     * @param serviceContext
     * @param adgroupViewDTO
     * @return
     */
    @Override
    public BizAdgroupWorkflowParam buildParamForAddOrUpdate(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO) {
        return null;
    }

    @Override
    public BizAdgroupBindWorkflowParam buildParamForAdgroupBind(ServiceContext serviceContext,
                                                                 AdgroupViewDTO adgroupViewDTO){
        return null;
    }

    @Override
    public Void afterAdgroupUpdate(ServiceContext context, AdgroupViewDTO adgroupViewDTO, BizAdgroupAbilityParam bizAdgroupAbilityParam) {
        return null;
    }

    @Override
    public Void beforeAdgroupUpdate(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, BizAdgroupWorkflowParam paramDefinition) {
        return null;
    }

    @Override
    public BizAdgroupDirectCreativeGenerateWorkflowParam buildParamForGenerateDirectCreative(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO) {
        return null;
    }

    @Override
    public Void beforeSetAdgroupOnline(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, BizAdgroupWorkflowParam workflowParam) {
        return null;
    }

    @Override
    public Void beforeAdgroupAdd(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, BizAdgroupWorkflowParam paramDefinition) {
        return null;
    }

    @Override
    public Void afterAdgroupAdd(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, BizAdgroupWorkflowParam paramDefinition) {
        return null;
    }
}