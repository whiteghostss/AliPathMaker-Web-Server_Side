package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.abf.util.StringUtils;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.ConfidenceInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupEstimateResultViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.nb.ssp.constant.newproduct.DeliveryTargetEnum;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupEstimateMessageInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CrmAdvInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.message.MessageViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageEmpViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.message.MessageSendTypeEnum;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.Env;
import com.taobao.ad.brand.bp.common.util.MailUtils;
import com.taobao.ad.brand.bp.common.util.VelocityUtils;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CustomerRepository;
import com.taobao.ad.brand.bp.domain.config.SelfServiceTestMemberConfig;
import com.taobao.ad.brand.bp.domain.memeber.MemberRepository;
import com.taobao.ad.brand.bp.domain.message.MessageRepository;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupEstimateResultWarningSendNoticeAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupNoticeAbilityParam;
import com.taobao.ad.brand.bp.domain.uic.SimbaUicRepository;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@BusinessAbility
public class DefaultCampaignGroupEstimateResultWarningSendNoticeAbility implements ICampaignGroupEstimateResultWarningSendNoticeAbility {

    @Resource
    private ResourcePackageRepository resourcePackageRepository;
    @Resource
    private SimbaUicRepository simbaUicRepository;
    @Resource
    private CustomerRepository customerRepository;
    @Resource
    private MemberRepository memberRepository;
    @Resource
    private MessageRepository messageRepository;
    @Resource
    private SelfServiceTestMemberConfig selfServiceTestMemberConfig;
    private static final String ESTIMATE_DING_GROUP_TOKEN = "eaf37ab4185bf2a3e5fd2e17f1e9976d950936df3627a13cee8def821ece15cb";
    private static final List<Integer> DELIVERY_TARGET_RATE_VALUE = Lists.newArrayList(DeliveryTargetEnum.TA.getValue(), DeliveryTargetEnum.N_REACH.getValue()
            , DeliveryTargetEnum.NEW_CUSTOMER.getValue(), DeliveryTargetEnum.CLICK_RATE.getValue(), DeliveryTargetEnum.INTERACT_RATE.getValue());

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupNoticeAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        List<Long> saleGroupIds = abilityParam.getSaleGroupIds();
        if (campaignGroupViewDTO == null || CollectionUtils.isEmpty(saleGroupIds)) {
            return null;
        }
        //过滤测试订单的预警消息
        if (CollectionUtils.isNotEmpty(selfServiceTestMemberConfig.getFilterMemberIdList())
                && selfServiceTestMemberConfig.getFilterMemberIdList().contains(campaignGroupViewDTO.getMemberId())) {
            RogerLogger.info("过滤测试订单的预警消息 CampaignGroupId {} ", campaignGroupViewDTO.getMemberId());
            return null;
        }
        ResourcePackageQueryViewDTO queryViewDTO = new ResourcePackageQueryViewDTO();
        queryViewDTO.setSaleGroupIdList(saleGroupIds);
        queryViewDTO.setPageSize(saleGroupIds.size());
        List<ResourcePackageSaleGroupViewDTO> saleGroupViewDTOList = resourcePackageRepository.getSaleGroupList(serviceContext, queryViewDTO, ResourcePackageQueryOption.builder().needProduct(true).needSetting(false).build());
        CrmAdvInfoViewDTO advInfoViewDTO = customerRepository.getCustomer(campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getCustomerMemberId());
        String memberName = memberRepository.getMemberDisplayNameById(campaignGroupViewDTO.getMemberId());

        saleGroupViewDTOList.forEach(resourcePackageSaleGroupViewDTO -> {
            SaleGroupInfoViewDTO saleGroupInfoViewDTO = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList()
                    .stream().filter(item -> item.getSaleGroupId().equals(resourcePackageSaleGroupViewDTO.getId())).findFirst().orElse(null);
            if (saleGroupInfoViewDTO == null
                    || saleGroupInfoViewDTO.getSaleGroupEstimateInfoViewDTO() == null
                    || CollectionUtils.isEmpty(saleGroupInfoViewDTO.getSaleGroupEstimateInfoViewDTO().getEstimateDeliverResult())) {
                return;
            }
            List<SaleGroupEstimateResultViewDTO> estimateDeliverResult = saleGroupInfoViewDTO.getSaleGroupEstimateInfoViewDTO().getEstimateDeliverResult();
            if (estimateDeliverResult.stream().anyMatch(item -> item.getConfidenceInfoViewDTO() != null && Boolean.FALSE.equals(item.getConfidenceInfoViewDTO().getConfidence()))) {
                MessageViewDTO messageViewDTO = new MessageViewDTO();
                // 收件人
                List<String> sendTo = getSendTo(campaignGroupViewDTO, resourcePackageSaleGroupViewDTO);
                // 内容
                Map<String, Object> contentMap = buildContentMap(campaignGroupViewDTO, estimateDeliverResult, resourcePackageSaleGroupViewDTO, advInfoViewDTO, memberName);
                // title
                String subject = String.format("【交付预估置信度偏低预警】%s-%s-%s-%S", memberName, advInfoViewDTO.getAdvName(), campaignGroupViewDTO.getName(), BrandDateUtil.date2String(campaignGroupViewDTO.getStartTime()) + "至" + BrandDateUtil.date2String(campaignGroupViewDTO.getEndTime()));
                messageViewDTO.setMemberId(campaignGroupViewDTO.getMemberId());
                messageViewDTO.setSubject(subject);
                messageViewDTO.setContent(VelocityUtils.merge("vm/SaleGroupEstimateWarnNotice.vm", contentMap));
                messageViewDTO.setSendTo(sendTo);
                messageViewDTO.setSendType(Lists.newArrayList(MessageSendTypeEnum.EMAIL.getValue()));
                messageRepository.sendMessage(messageViewDTO);

                //发送钉钉群消息
                messageViewDTO.setDingGroupToken(ESTIMATE_DING_GROUP_TOKEN);
                //群消息不支持 html
                String dingContent = VelocityUtils.merge("vm/ding/SaleGroupEstimateWarnDingNotice.vm", contentMap);
                if (StringUtils.isNotBlank(dingContent)) {
                    messageViewDTO.setContent(dingContent);
                    messageViewDTO.setSendType(Lists.newArrayList(MessageSendTypeEnum.DING_GROUP.getValue()));
                    messageRepository.sendMessage(messageViewDTO);
                }
            }
        });

        return null;
    }

    private Map<String, Object> buildContentMap(CampaignGroupViewDTO campaignGroupViewDTO, List<SaleGroupEstimateResultViewDTO> estimateDeliverResult,
                                                ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO, CrmAdvInfoViewDTO adviceInfoViewDTO,
                                                String memberName) {
        List<CampaignGroupSaleGroupEstimateMessageInfoViewDTO> messageInfoViewDTOLists = estimateDeliverResult.stream().map(item -> {
            CampaignGroupSaleGroupEstimateMessageInfoViewDTO message = new CampaignGroupSaleGroupEstimateMessageInfoViewDTO();
            //控制率的展示
            message.setFinalValue(DELIVERY_TARGET_RATE_VALUE.contains(item.getDeliveryTarget())
                    ? item.getFinalValue() != null && item.getFinalValue() > 0 ? (item.getFinalValue() / 100.00) + "%" : item.getFinalValue() + "%"
                    : String.valueOf(item.getFinalValue()));
            message.setDeliveryTarget(DeliveryTargetEnum.getByValue(item.getDeliveryTarget()).getName());
            ConfidenceInfoViewDTO confidenceInfoViewDTO = item.getConfidenceInfoViewDTO();
            message.setConfidence(confidenceInfoViewDTO == null ? "未知"
                    : Boolean.TRUE.equals(confidenceInfoViewDTO.getConfidence()) ? "高" : "低");
            return message;
        }).collect(Collectors.toList());
        messageInfoViewDTOLists.get(0).setCampaignGroupName(campaignGroupViewDTO.getName());
        messageInfoViewDTOLists.get(0).setAdvName(adviceInfoViewDTO.getAdvName());
        messageInfoViewDTOLists.get(0).setMemberName(memberName);
        messageInfoViewDTOLists.get(0).setSaleGroupName(resourcePackageSaleGroupViewDTO.getName());

        Map<String, Object> model = new HashMap<>();
        model.put("dataList", messageInfoViewDTOLists);
        return model;
    }

    private List<String> getSendTo(CampaignGroupViewDTO campaignGroupViewDTO,ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO) {
        List<String> sendToIds = Lists.newArrayList();
        List<String> operatorEmails = Lists.newArrayList(MailUtils.rdRecipients);
        if (Env.isProd()) {
            //运营
            Optional.ofNullable(campaignGroupViewDTO.getOperators()).ifPresent(sendToIds::addAll);
            //运营相关人
            Optional.ofNullable(campaignGroupViewDTO.getRelevantOperators()).ifPresent(sendToIds::addAll);
            //分组负责人
            if (Objects.nonNull(resourcePackageSaleGroupViewDTO)) {
                if (CollectionUtils.isNotEmpty(resourcePackageSaleGroupViewDTO.getChargeEmpList())) {
                    sendToIds.addAll(resourcePackageSaleGroupViewDTO.getChargeEmpList().stream().map(ResourcePackageEmpViewDTO::getEmpId).distinct().collect(Collectors.toList()));
                }
            }
            //获取邮箱
            Map<String, String> empEmailMap = simbaUicRepository.getEmpEmails(sendToIds);
            RogerLogger.info("estimateResultWarning sendToIds={},empEmailMap={}", JSON.toJSONString(sendToIds), JSON.toJSONString(empEmailMap));
            operatorEmails.addAll(empEmailMap.values());
            operatorEmails.add(Constant.ESTIMATE_WARN_SHOW_MAX_EMAIL);
        }

        return operatorEmails;
    }
}
