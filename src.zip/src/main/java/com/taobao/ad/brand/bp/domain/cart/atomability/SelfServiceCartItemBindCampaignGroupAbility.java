package com.taobao.ad.brand.bp.domain.cart.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSourceEnum;
import com.alibaba.ad.brand.sdk.constant.cartitem.BrandCartItemStatusEnum;
import com.taobao.ad.brand.bp.domain.cart.repository.CartItemRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.ICartItemBindCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.param.CartItemBindCampaignGroupAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCartItemBindCampaignGroupAbility implements ICartItemBindCampaignGroupAbility, SelfServiceAtomAbilityRouter {

    private final CartItemRepository cartItemRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CartItemBindCampaignGroupAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroup = abilityParam.getCampaignGroupViewDTO();
        if (!BrandCampaignGroupSourceEnum.CART.getCode().equals(campaignGroup.getSource())
                && !BrandCampaignGroupSourceEnum.SLIM_ORDER.getCode().equals(campaignGroup.getSource())) {
            return null;
        }
        for (Long cartItemId : abilityParam.getAbilityTargets()) {
            CartItemViewDTO cartItemViewDTO = new CartItemViewDTO();
            cartItemViewDTO.setId(cartItemId);
            cartItemViewDTO.setCampaignGroupId(campaignGroup.getId());
            cartItemViewDTO.setMainCampaignGroupId(campaignGroup.getParentId());
            if (BrandCampaignGroupSourceEnum.CART.getCode().equals(campaignGroup.getSource())) {
                cartItemViewDTO.setStatus(BrandCartItemStatusEnum.ORDER_SUCCESS.getCode());
            }
            cartItemRepository.updateCartPart(serviceContext, cartItemViewDTO);
        }

        return null;
    }
}
