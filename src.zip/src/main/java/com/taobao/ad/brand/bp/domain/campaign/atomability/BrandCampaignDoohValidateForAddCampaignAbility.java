package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.audience.CampaignTargetScenarioViewDTO;
import com.alibaba.ad.brand.dto.campaign.audience.CampaignTargetViewDTO;
import com.alibaba.ad.brand.dto.campaign.dooh.CampaignDoohViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupProductCategoryEnum;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohStrategyViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignDoohValidateForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignDoohAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandCampaignDoohValidateForAddCampaignAbility implements ICampaignDoohValidateForAddCampaignAbility, BrandAtomAbilityRouter {

    private final CampaignRepository campaignRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignDoohAbilityParam abilityParam) {
        ProductViewDTO productViewDTO = abilityParam.getProductViewDTO();
        AssertUtil.notNull(productViewDTO,"二级产品不能为空");
        if(!BizCampaignToolsHelper.isDoohCampaign(productViewDTO.getProductLineId())){
            return null;
        }
        CampaignDoohViewDTO campaignDoohViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(campaignDoohViewDTO,"天攻配置不允许为空");

        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();
        AssertUtil.notNull(campaignViewDTO,"计划不能为空");

        DoohStrategyViewDTO strategyViewDTO = abilityParam.getDoohStrategyViewDTO();
        ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO = abilityParam.getResourcePackageSaleGroupViewDTO();
        AssertUtil.notNull(resourcePackageSaleGroupViewDTO,"售卖分组不能为空");
        //1.策略ID和定向二选一
        if (SaleGroupProductCategoryEnum.SMART_SCREEN.getValue().equals(resourcePackageSaleGroupViewDTO.getProductCategory())) {
            AssertUtil.assertTrue(campaignDoohViewDTO.getDoohStrategyId() != null && strategyViewDTO != null, "天攻户外定制计划策略不能为空");
        }
        if (SaleGroupProductCategoryEnum.SMART_SCREEN_SPEED.getValue().equals(resourcePackageSaleGroupViewDTO.getProductCategory())) {
            List<CampaignTargetViewDTO> campaignTargetViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignTargetScenarioViewDTO())
                    .map(CampaignTargetScenarioViewDTO::getCampaignTargetViewDTOList).orElse(Lists.newArrayList());
            AssertUtil.assertTrue(CollectionUtils.isNotEmpty(campaignTargetViewDTOList) || (campaignDoohViewDTO.getDoohStrategyId() != null && strategyViewDTO != null), "天攻极速达计划定向和策略不能同时为空");
            AssertUtil.assertTrue(campaignDoohViewDTO.getStrategyMethod() != null ,"天攻策略方式不允许为空");
        }
        //2. 开始和结束时间只能按照策略的时间按周平移
        if (campaignDoohViewDTO.getDoohStrategyId() != null && strategyViewDTO != null && !BrandDateUtil.isHistoryTime(campaignViewDTO.getStartTime())) {
            Date strategyStartDate = BrandDateUtil.getMinDate(strategyViewDTO.getStartDate());
            Date strategyEndDate = BrandDateUtil.getMaxDate(strategyViewDTO.getEndDate());
            Date startDate = BrandDateUtil.getMinDate(campaignViewDTO.getStartTime());
            Date endDate = BrandDateUtil.getMaxDate(campaignViewDTO.getEndTime());
            int betweenStartDateNum = BrandDateUtil.getNumOfDaysBetweenDate(strategyStartDate, startDate);
            if (betweenStartDateNum % 7 == 0) {
                int betweenCurrDateNum = BrandDateUtil.getNumOfDaysBetweenDate(startDate, endDate);
                int betweenStrategyDateNum = BrandDateUtil.getNumOfDaysBetweenDate(strategyStartDate, strategyEndDate);
                RogerLogger.info("betweenCurrDateNum:{}, betweenStrategyDateNum:{}", betweenCurrDateNum, betweenStrategyDateNum);
                AssertUtil.assertTrue(betweenCurrDateNum == betweenStrategyDateNum, "投放周期需要和策略一致，请调整结束时间后重试");
            } else {
                throw new BrandOneBPException("天攻计划的投放周期只允许根据策略周期按周平移，请调整开始时间后重试");
            }
        }
        //3. 二级产品下只能有一个计划
        if(campaignViewDTO.getId() == null){
            CampaignQueryViewDTO queryViewDTO = new CampaignQueryViewDTO();
            queryViewDTO.setCampaignGroupId(campaignViewDTO.getCampaignGroupId());
            queryViewDTO.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
            queryViewDTO.setSspProductId(campaignViewDTO.getCampaignResourceViewDTO().getSspProductId());
            List<CampaignViewDTO> campaignViewDTOList = campaignRepository.queryCampaignList(serviceContext, queryViewDTO);
            if(CollectionUtils.isNotEmpty(campaignViewDTOList)){
                campaignViewDTOList = campaignViewDTOList.stream().filter(e->BizCampaignToolsHelper.isDoohCampaign(e.getCampaignResourceViewDTO().getSspProductLineId())).collect(Collectors.toList());
                AssertUtil.assertTrue(CollectionUtils.isEmpty(campaignViewDTOList), "天攻二级产品已有计划，不允许重复创建");
            }
        }
        return null;
    }
}
