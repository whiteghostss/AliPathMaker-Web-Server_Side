package com.taobao.ad.brand.bp.domain.mediarule.ability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.media.protect.MediaProtectRuleBlackViewDTO;
import com.alibaba.ad.brand.dto.media.protect.MediaProtectRuleViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.media.field.BrandMediaProtectRuleBlackTypeEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.mediarule.MediaProtectRuleRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Optional;

/**
 * 保护规则扩展
 * @author linhua.deng
 */
@Component
@RequiredArgsConstructor
public class MediaProtectRuleAbility {
    private final MediaProtectRuleRepository mediaProtectRuleRepository;

    /**
     * 保护规则参数校验
     *
     * @param viewDTO
     */
    public void validateProtectRule(ServiceContext context, MediaProtectRuleViewDTO viewDTO, MediaProtectRuleViewDTO dbViewDTO){
        // 校验名称
        validateName(context,viewDTO);

        AssertUtil.notNull(viewDTO.getSiteId(),"媒体不允许为空");
        AssertUtil.notNull(viewDTO.getStartTime(),"开始时间不允许为空");
        AssertUtil.notNull(viewDTO.getEndTime(),"结束时间不允许为空");
        AssertUtil.assertTrue(viewDTO.getEndTime().compareTo(viewDTO.getStartTime()) >= 0,"结束时间不能小于开始时间");
        if (viewDTO.getTargetViewDTO() != null) {
            if (CollectionUtils.isNotEmpty(viewDTO.getTargetViewDTO().getIdentityIdList())) {
                AssertUtil.assertTrue(viewDTO.getTargetViewDTO().getIdentityIdList().size() <= 2000, "设备号/taoBaoId最多支持2000个请检查相关配置");
            }
            if (CollectionUtils.isNotEmpty(viewDTO.getTargetViewDTO().getMediaExpIdList())) {
                AssertUtil.assertTrue(viewDTO.getTargetViewDTO().getMediaExpIdList().size() <= 2000, "实验桶号最多支持2000个请检查相关配置");
            }
        }
        AssertUtil.notEmpty(viewDTO.getBlackViewDTOList(),"保护规则黑名单配置不允许为空");
        for (MediaProtectRuleBlackViewDTO blackViewDTO : viewDTO.getBlackViewDTOList()) {
            AssertUtil.notNull(blackViewDTO.getBizType(),"黑名单类型不允许为空");
            BrandMediaProtectRuleBlackTypeEnum blackTypeEnum = BrandMediaProtectRuleBlackTypeEnum.getByCode(blackViewDTO.getBizType());
            AssertUtil.notNull(blackTypeEnum,String.format("黑名单对象类型[%s]不正确", blackViewDTO.getBizType()));
            AssertUtil.assertTrue(StringUtils.isNotBlank(blackViewDTO.getValue()), String.format("黑名单对象[%s]的ID不允许为空", blackTypeEnum.getDesc()));
        }

        //新增-开始时间不能小于当前时间
        if(dbViewDTO == null){
            AssertUtil.assertTrue(BrandDateUtil.getCurrentDate().compareTo(viewDTO.getStartTime()) <= 0,"开始时间不能小于当前时间");
        }else{
            viewDTO.setCreateEmpId(dbViewDTO.getCreateEmpId());
        }
    }
    public void initProtectRule(MediaProtectRuleViewDTO viewDTO, MediaProtectRuleViewDTO dbVewDTO){
        viewDTO.setStartTime(BrandDateUtil.getDateMidnight(viewDTO.getStartTime()));
        viewDTO.setEndTime(BrandDateUtil.getDateFullMidnight(viewDTO.getEndTime()));
        //默认开启
        viewDTO.setStatus(Optional.ofNullable(dbVewDTO).map(MediaProtectRuleViewDTO::getStatus)
            .orElse(BrandBoolEnum.BRAND_TRUE.getCode()));
    }

    /**
     * 名称唯一性校验
     * @param context
     * @param viewDTO
     */
    private void validateName(ServiceContext context, MediaProtectRuleViewDTO viewDTO) {
        AssertUtil.hasText(viewDTO.getName(),"保护规则名称不能为空");
        AssertUtil.maxLength(viewDTO.getName(),20,"保护规则名称长度不能超过20");

        MediaProtectRuleViewDTO mediaProtectRuleViewDTO = mediaProtectRuleRepository.getTopOneByName(context, viewDTO.getName());
        if(mediaProtectRuleViewDTO != null){
            AssertUtil.assertTrue(Objects.equals(viewDTO.getId(),mediaProtectRuleViewDTO.getId()),
                    BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR,"保护规则名称不能允许重复");
        }
    }
}
