package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupRealSettleValidateForSaveAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupRealSettleValidateForSaveAbilityParam;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
@BusinessAbility
public class BrandOneBPCampaignGroupRealSettleValidateForSaveAbility
    extends DefaultCampaignGroupRealSettleValidateForSaveAbility implements BrandOneBPAtomAbilityRouter {
    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupRealSettleValidateForSaveAbilityParam abilityParam) {
        //主订单无需处理
        return null;
    }
}
