package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupPurchaseStatusEnum;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupPurchaseProcessViewDTO;
import com.taobao.ad.brand.bp.domain.inventory.InventoryRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupPurchaseOrderAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component
@BusinessAbility
public class BrandCampaignGroupAddPurchaseOrderAbility
        extends DefaultCampaignGroupAddPurchaseOrderAbility implements BrandAtomAbilityRouter {

    @Resource
    private InventoryRepository inventoryRepository;

    @Override
    public CampaignGroupPurchaseProcessViewDTO handle(ServiceContext serviceContext, CampaignGroupPurchaseOrderAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        List<CampaignViewDTO> subCampaignViewDTOList = abilityParam.getSubCampaignViewDTOList();
        if (CollectionUtils.isEmpty(subCampaignViewDTOList)) {
            CampaignGroupPurchaseProcessViewDTO purchaseProcessViewDTO = new CampaignGroupPurchaseProcessViewDTO();
            purchaseProcessViewDTO.setBrandCampaignGroupPurchaseStatusEnum(BrandCampaignGroupPurchaseStatusEnum.NON_PURCHASE);
            return purchaseProcessViewDTO;
        }
        return inventoryRepository.addPurchaseOrder(serviceContext, campaignGroupViewDTO, subCampaignViewDTOList);
    }
}
