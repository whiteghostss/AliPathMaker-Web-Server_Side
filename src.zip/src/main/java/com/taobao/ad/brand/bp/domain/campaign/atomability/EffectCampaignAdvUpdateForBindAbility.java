package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.client.dto.effect.DirectAdvertiserSettingViewDTO;
import com.taobao.ad.brand.bp.domain.effect.EffectAdvertiserRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.EffectAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignAdvUpdateForBindAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignAdvUpdateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EffectCampaignAdvUpdateForBindAbility implements ICampaignAdvUpdateForBindAbility, EffectAtomAbilityRouter {

    private final EffectAdvertiserRepository effectAdvertiserRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignAdvUpdateAbilityParam abilityParam) {
        List<CampaignViewDTO> subCampaignViewDTOList = abilityParam.getAbilityTargets();
        if (CollectionUtils.isEmpty(subCampaignViewDTOList)) {
            return null;
        }

        List<DirectAdvertiserSettingViewDTO> directAdvertiserSettingDTOList = subCampaignViewDTOList.stream().map(item -> {
                    DirectAdvertiserSettingViewDTO directAdvertiserSettingViewDTO = new DirectAdvertiserSettingViewDTO();
                    directAdvertiserSettingViewDTO.setId(item.getCampaignEffectProxyViewDTO().getEffectAdvId());
                    directAdvertiserSettingViewDTO.setCampaignId(item.getParentCampaignId());
                    directAdvertiserSettingViewDTO.setCustomMemberId(item.getMemberId());
                    directAdvertiserSettingViewDTO.setSubCampaignId(item.getId());
                    return directAdvertiserSettingViewDTO;
                }).collect(Collectors.toList());
        effectAdvertiserRepository.updateAdvertiserSetting(serviceContext, directAdvertiserSettingDTOList);
        return null;
    }
}
