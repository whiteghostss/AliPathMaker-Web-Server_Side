package com.taobao.ad.brand.bp.domain.adgroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupBottomTypeEnum;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupOnlineStatusEnum;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupPriorityEnum;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupTargetTypeEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupBaseInitForAddBottomAdgroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupBottomBaseInitAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultAdgroupBaseInitForAddBottomAdgroupAbility implements IAdgroupBaseInitForAddBottomAdgroupAbility {

    @Override
    public Void handle(ServiceContext serviceContext, AdgroupBottomBaseInitAbilityParam abilityParam) {
        AdgroupViewDTO adgroupViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();
        AssertUtil.notNull(adgroupViewDTO,"单元不能为空");
        AssertUtil.notNull(campaignViewDTO,"计划不能为空");

        adgroupViewDTO.setCampaignId(campaignViewDTO.getId());
        adgroupViewDTO.setCampaignGroupId(campaignViewDTO.getCampaignGroupId());
        adgroupViewDTO.setStartTime(campaignViewDTO.getStartTime());
        adgroupViewDTO.setEndTime(campaignViewDTO.getEndTime());
        adgroupViewDTO.setTargetType(BrandAdgroupTargetTypeEnum.PROGRAM.getCode());
        adgroupViewDTO.setOnlineStatus(BrandAdgroupOnlineStatusEnum.DRAFT.getCode());
        adgroupViewDTO.setBottomType(BrandAdgroupBottomTypeEnum.BOTTOM.getCode());
        adgroupViewDTO.setWeight(0);
        adgroupViewDTO.setPriority(BrandAdgroupPriorityEnum.BOTTOM.getCode());
        return null;
    }
}
