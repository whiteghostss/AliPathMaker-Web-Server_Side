package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.SaleGroupQueryViewDTO;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupDeleteAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupDeleteAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Component
@BusinessAbility
public class DefaultSaleGroupDeleteAbility implements ISaleGroupDeleteAbility {

    @Resource
    private CampaignGroupRepository campaignGroupRepository;

    @Override
    public Integer handle(ServiceContext serviceContext, SaleGroupDeleteAbilityParam abilityParam) {
        List<Long> deleteSaleGroupIds = abilityParam.getAbilityTargets();
        if (CollectionUtils.isEmpty(deleteSaleGroupIds)) {
            return 0;
        }
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        //查询数据表中已有的订单售卖分组
        SaleGroupQueryViewDTO saleGroupQueryViewDTO = new SaleGroupQueryViewDTO();
        saleGroupQueryViewDTO.setCampaignGroupIds(Collections.singletonList(campaignGroupViewDTO.getId()));
        saleGroupQueryViewDTO.setSaleGroupIds(deleteSaleGroupIds);
        List<SaleGroupInfoViewDTO> dbSaleGroupList = campaignGroupRepository.findSaleGroupList(serviceContext, saleGroupQueryViewDTO);
        if (CollectionUtils.isEmpty(dbSaleGroupList)) {
            return 0;
        }
        return campaignGroupRepository.deleteSaleGroup(serviceContext, dbSaleGroupList.stream().map(SaleGroupInfoViewDTO::getId).collect(Collectors.toList()));
    }
}
