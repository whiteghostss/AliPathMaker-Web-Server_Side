package com.taobao.ad.brand.bp.domain.config;

import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignInventoryAutoReleaseConfigViewDTO;
import com.taobao.ad.brand.bp.domain.config.base.BaseDiamondConfig;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

/**
 * 计划锁量自动释量
 */
@Component
public class CampaignInventoryAutoReleaseDiamondConfig extends BaseDiamondConfig {

    private static volatile String config;

    @Override
    protected String getDataId() {
        return "campaign.inventory.autorelease";
    }

    @Override
    protected String getGroupId() {
        return "com.taobao.ad.brand.bp";
    }

    @Override
    protected void initDiamond(String diamondConfig) {
        RogerLogger.info("DiamondConfig.initDiamond CampaignInventoryAutoReleaseDiamondConfig param: {}", diamondConfig);
        config = diamondConfig;
    }

    public CampaignInventoryAutoReleaseConfigViewDTO getCampaignInventoryAutoReleaseConfig(){
        if(StringUtils.isBlank(config)){
            return null;
        }
        return JSON.parseObject(config, CampaignInventoryAutoReleaseConfigViewDTO.class);
    }
}