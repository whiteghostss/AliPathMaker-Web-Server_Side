package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;

import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.EffectAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignTitleInitAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EffectCampaignTitleInitAbility extends DefaultCampaignTitleInitAbility implements EffectAtomAbilityRouter {

    @Override
    public String handle(ServiceContext context, CampaignTitleInitAbilityParam abilityParam) {
        CampaignViewDTO campaignViewDTO = abilityParam.getAbilityTarget();
        ProductViewDTO productViewDTO = abilityParam.getProductViewDTO();
        String title = campaignViewDTO.getTitle();
        if(StringUtils.isEmpty(title)){
            title = buildCampaignName(productViewDTO.getName());
        }
        return title;
    }

    private String buildCampaignName(String productName){
        StringBuilder builder = new StringBuilder();
        builder.append(productName)
                .append("_")
                .append(BrandDateUtil.date2String(new Date(), BrandDateUtil.DATE_FORMAT_YYYYMMDD_TYPE_2))
                .append("_")
                .append(BrandDateUtil.date2String(new Date(), BrandDateUtil.DATE_FORMAT_HHMMSS))
                .append("_").append(BrandDateUtil.getTimestampInMillis());
        return builder.toString();
    }
}
