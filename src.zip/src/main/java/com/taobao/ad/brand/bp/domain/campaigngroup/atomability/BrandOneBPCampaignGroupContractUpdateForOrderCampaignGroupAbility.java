package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.contract.CampaignGroupContractViewDTO;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupContractUpdateForOrderCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupContractUpdateForOrderCampaignGroupAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component
@BusinessAbility
public class BrandOneBPCampaignGroupContractUpdateForOrderCampaignGroupAbility
        implements ICampaignGroupContractUpdateForOrderCampaignGroupAbility, BrandOneBPAtomAbilityRouter {
    @Resource
    private CampaignGroupRepository campaignGroupRepository;


    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupContractUpdateForOrderCampaignGroupAbilityParam abilityParam) {
        List<CampaignGroupViewDTO> subCampaignGroupList = abilityParam.getSubCampaignGroupList();
        if (CollectionUtils.isEmpty(subCampaignGroupList)) {
            return null;
        }
        CampaignGroupContractViewDTO mainContractViewDTO = abilityParam.getAbilityTarget();
        for (CampaignGroupViewDTO subCampaignGroup : subCampaignGroupList) {
            boolean needUpdate = false;
            if (subCampaignGroup.getCampaignGroupContractViewDTO().getContractStartTime() == null || !subCampaignGroup.getCampaignGroupContractViewDTO().getContractStartTime().equals(mainContractViewDTO.getContractStartTime())) {
                subCampaignGroup.getCampaignGroupContractViewDTO().setContractStartTime(mainContractViewDTO.getContractStartTime());
                needUpdate = true;
            }
            if (subCampaignGroup.getCampaignGroupContractViewDTO().getContractEndTime() == null || !subCampaignGroup.getCampaignGroupContractViewDTO().getContractEndTime().equals(mainContractViewDTO.getContractEndTime())) {
                subCampaignGroup.getCampaignGroupContractViewDTO().setContractEndTime(mainContractViewDTO.getContractEndTime());
                needUpdate = true;
            }
            if (!needUpdate) {
                continue;
            }
            ServiceContext subServiceContext = ServiceContextUtil.buildServiceContextForSceneIdNoSession(subCampaignGroup.getMemberId(), subCampaignGroup.getSceneId());
            CampaignGroupViewDTO updateCampaignGroupViewDTO = new CampaignGroupViewDTO();
            updateCampaignGroupViewDTO.setId(subCampaignGroup.getId());
            updateCampaignGroupViewDTO.setCampaignGroupContractViewDTO(subCampaignGroup.getCampaignGroupContractViewDTO());
            campaignGroupRepository.updateCampaignGroupPart(subServiceContext, updateCampaignGroupViewDTO);
        }

        return null;
    }
}
