package com.taobao.ad.brand.bp.domain.cart.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.sdk.constant.cartitem.BrandCartItemStatusEnum;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.ICartItemDeleteJudgeAbility;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.param.CartItemValidateAbilityParam;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Component
@BusinessAbility
public class SelfServiceCartItemDeleteJudgeAbility implements ICartItemDeleteJudgeAbility, SelfServiceAtomAbilityRouter {

    @Override
    public Boolean handle(ServiceContext context, CartItemValidateAbilityParam abilityPara) {
        //只允许“未下单”状态加购行可以删除
        return Objects.equals(BrandCartItemStatusEnum.ORDER_WAIT.getCode(),abilityPara.getAbilityTarget().getStatus());
    }
}
