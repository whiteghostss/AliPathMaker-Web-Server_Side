package com.taobao.ad.brand.bp.domain.brand;

import com.alibaba.ad.brand.dto.common.BrandViewDTO;

import java.util.List;

/**
 * 品牌相关服务
 * @author yuncheng.lyc
 * @date 2023/3/26
 **/
public interface BrandRepository {
    /**
     * 关键词查询品牌信息
     * @param keyword
     * @return
     */
    List<BrandViewDTO> queryByKeyword(String keyword, Integer limit);

    /**
     * 品牌ids查询品牌信息
     * @param brandIds
     * @return
     */
    List<BrandViewDTO> queryBrand(List<Long> brandIds);

    /**
     * 查询品牌信息
     * @param brandId
     * @return
     */
    BrandViewDTO getBrand(Long brandId);

}
