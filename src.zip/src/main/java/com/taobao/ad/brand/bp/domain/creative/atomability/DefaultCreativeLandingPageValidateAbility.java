package com.taobao.ad.brand.bp.domain.creative.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.fastjson.JSONObject;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.constant.AdcRoleConstant;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.URLUtil;
import com.taobao.ad.brand.bp.domain.memeber.MemberRepository;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.ICreativeLandingPageValidateAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeLandingPageValidateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.validator.routines.UrlValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;
import java.util.Set;
import java.util.regex.Pattern;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultCreativeLandingPageValidateAbility implements ICreativeLandingPageValidateAbility {

    private final MemberRepository memberRepository;
    /**
     * url支持ali协议和http协议
     */
    private static Set<String> ALI_URL_PROTOCOL_SCHEME = Sets.newHashSet("alipays", "tvtaobao", "taobao", "eleme", "youku");
    private static Set<String> HTTP_URL_PROTOCOL_SCHEME = Sets.newHashSet("http", "https");
    /**
     * 流量宝域名
     */
    private static final Set<String> REAL_URL_DOMAIN = Sets.newHashSet("equity.tmall.com");
    /**
     * 校验url，校验规则：
     * a、不支持携带：引号、冒号、括号（包括全角和半角格式的）
     * 英文的冒号只有跟在http或https后面，才能加，其他的不允许添加
     * 中文的冒号无论在什么位置都禁止添加
     * c、不能自带ali_trackid字段
     * d、不支持chaoshi.detail.tmall.com域名
     *
     * @param url 落地页
     */
    private final static String URL_REG = "(?=.*?(\"|'|!|\\(|\\)|\\uff08|\\uff09|\\u201c|\\u201d|\\uff1a|" + "ali_trackid))";
    private final static Pattern URL_PATTERN = Pattern.compile(URL_REG);

    @Override
    public Void handle(ServiceContext serviceContext, CreativeLandingPageValidateAbilityParam abilityParam) {
        String landingPage = abilityParam.getAbilityTarget();
        RogerLogger.info("validatePageUrl,landingPage: {}", landingPage);
        AssertUtil.hasText(landingPage, "落地页不能为空");
        AssertUtil.maxLength(landingPage, 1000, String.format("落地页长度不能超过%s，url: %s", 1000, landingPage));

        String urlProtocolScheme = URLUtil.getUrlScheme(landingPage);
        AssertUtil.assertTrue(ALI_URL_PROTOCOL_SCHEME.contains(urlProtocolScheme) || HTTP_URL_PROTOCOL_SCHEME.contains(urlProtocolScheme),
                BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR.of("落地页协议不合法，目前仅支持以下协议: [alipays、tvtaobao、taobao、eleme、youku、http、https]"));
        String urlFullDomain = URLUtil.getUrlFullDomain(landingPage);
        if (!isWhiteCustomer(serviceContext)) {
            AssertUtil.assertTrue(!REAL_URL_DOMAIN.contains(urlFullDomain),
                    BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR.of("落地页不支持以下流量宝域名:[equity.tmall.com]"));
        }
        //http协议校验url合法性
        if (HTTP_URL_PROTOCOL_SCHEME.contains(urlProtocolScheme)) {
            AssertUtil.assertTrue(UrlValidator.getInstance().isValid(landingPage), BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR.of("落地页不合法"));
        }
        validateSpecialPageUrl(landingPage);
        return null;
    }

    /**
     * 特殊落地页格式校验
     *
     * @param url
     */
    private void validateSpecialPageUrl(String url) {
        AssertUtil.assertTrue(!URL_PATTERN.matcher(url).find(), "落地页不满足要求");
        int index = url.indexOf(":");
        if (index == -1) {
            return;
        }
        AssertUtil.assertTrue(!url.substring(index + 1).contains(":"), "落地页不满足要求");
    }

    /**
     * 判断是否是白名单客户
     * @param context
     * @return
     */
    public boolean isWhiteCustomer(ServiceContext context) {
        RogerLogger.info("isWhiteCustomer query memberId={}", context.getMemberId());
        // 查询拥有的白名单权限角色
        if (context.getMemberId() != null) {
            Set<String> uicRoleCodeSet = memberRepository.findRoleCodeByMemberId(context.getMemberId());
            return Optional.ofNullable(uicRoleCodeSet).orElse(Sets.newHashSet()).stream().anyMatch(AdcRoleConstant.LIULIANGBAO_WHITE_CODE::equals);
        }
        return false;
    }
}
