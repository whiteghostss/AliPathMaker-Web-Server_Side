package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupDeleteAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
@BusinessAbility
public class DefaultCampaignGroupDeleteAbility implements ICampaignGroupDeleteAbility {
    @Resource
    private CampaignGroupRepository campaignGroupRepository;

    @Override
    public Integer handle(ServiceContext serviceContext, CampaignGroupAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        // 分组
        if (CollectionUtils.isNotEmpty(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList())) {
            campaignGroupRepository.deleteSaleGroupByCampaignGroupId(serviceContext, campaignGroupViewDTO.getId());
        }

        return campaignGroupRepository.deleteCampaignGroup(serviceContext, campaignGroupViewDTO.getId());
    }
}
