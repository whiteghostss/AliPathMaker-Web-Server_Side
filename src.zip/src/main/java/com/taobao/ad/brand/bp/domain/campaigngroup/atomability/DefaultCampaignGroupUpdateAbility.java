package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.salegroup.CampaignGroupSaleGroupViewDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupUpdateAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Optional;

@Component
@BusinessAbility
public class DefaultCampaignGroupUpdateAbility implements ICampaignGroupUpdateAbility {
    @Resource
    private CampaignGroupRepository campaignGroupRepository;

    @Override
    public Integer handle(ServiceContext serviceContext, CampaignGroupUpdateAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        boolean updateSaleGroupAll = abilityParam.isNeedUpdateSaleGroupAll();
        //保存订单
        Integer count = campaignGroupRepository.updateCampaignGroupPart(serviceContext, campaignGroupViewDTO);
        // 更新分组(默认part更新)
        List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList = Optional.ofNullable(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO())
                .map(CampaignGroupSaleGroupViewDTO::getSaleGroupInfoViewDTOList).orElse(Lists.newArrayList());
        if (CollectionUtils.isNotEmpty(saleGroupInfoViewDTOList)) {
            if (updateSaleGroupAll) {
                campaignGroupRepository.bindAllSaleGroup(serviceContext, campaignGroupViewDTO.getId(), saleGroupInfoViewDTOList);
            } else {
                campaignGroupRepository.addOrUpdateSaleGroupPart(serviceContext, campaignGroupViewDTO.getId(), saleGroupInfoViewDTOList);
            }
        }

        return count;
    }
}
