package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.fastjson.JSONObject;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.IpMarketAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignAutoLockAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

import static com.taobao.ad.brand.bp.common.constant.Constant.CAN_INQUIRY_LOCK_STATUS;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class IpMarketCampaignAutoLockJudgeForLockCampaignAbility extends DefaultCampaignAutoLockJudgeForLockCampaignAbility implements IpMarketAtomAbilityRouter {

    @Override
    public Boolean handle(ServiceContext serviceContext, CampaignAutoLockAbilityParam abilityParam) {
        ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO = abilityParam.getResourcePackageSaleGroupViewDTO();
        List<CampaignViewDTO> campaignViewDTOList = abilityParam.getAbilityTargets();
        // 如果分组开始日期不是历史日期，且分组下存在任意一个计划处于「草稿、锁量失败、询量失败、询量成功」，则可以走后续预算分配、计算流程
        if (BrandDateUtil.isHistoryTime(resourcePackageSaleGroupViewDTO.getStartDate()) || CollectionUtils.isEmpty(campaignViewDTOList)
                || campaignViewDTOList.stream().noneMatch(it -> CAN_INQUIRY_LOCK_STATUS.contains(it.getStatus()))) {
            RogerLogger.info("该分组不符合发起自动计算及锁量的条件，分组名称:{},分组开始时间:{},分组计划列表:{}", resourcePackageSaleGroupViewDTO.getName(), resourcePackageSaleGroupViewDTO.getStartDate(), JSONObject.toJSONString(campaignViewDTOList));
            return false;
        }
        return true;
    }
}
