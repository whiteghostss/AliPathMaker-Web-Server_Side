package com.taobao.ad.brand.bp.domain.campaigngroup.repository;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignGroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.SaleGroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.shop.ShopViewDTO;

import java.util.List;
import java.util.Map;

/**
 * @author liqiang
 */
public interface CampaignGroupRepository {

    /**
     * 查询订单列表页
     *
     * @param context
     * @param campaignGroupQueryViewDTO
     * @return
     */
    PageResultViewDTO<CampaignGroupViewDTO> findCampaignGroupPageList(ServiceContext context, CampaignGroupQueryViewDTO campaignGroupQueryViewDTO);

    /**
     * 根据主订单查询子订单列表
     * @param context
     * @param mainCampaignGroupId
     * @return
     */
    List<CampaignGroupViewDTO> findSubCampaignGroupList(ServiceContext context, Long mainCampaignGroupId);

    /**
     * 根据主订单查询子订单列表
     *
     * @param context
     * @param mainCampaignGroupId
     * @param sceneIds
     * @return
     */
    List<CampaignGroupViewDTO> findSubCampaignGroupList(ServiceContext context, Long mainCampaignGroupId, List<Integer> sceneIds);

    List<CampaignGroupViewDTO> findCampaignGroupByIds(ServiceContext context, List<Long> ids);


    List<CampaignGroupViewDTO> findCampaignGroupList(ServiceContext context, CampaignGroupQueryViewDTO campaignGroupQueryViewDTO);

    /**
     * 查询订单详情
     */
    CampaignGroupViewDTO getCampaignGroup(ServiceContext serviceContext, Long id);

    /**
     * 更新订单详情
     */
    Integer updateCampaignGroupPart(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO);

    /**
     * 新建订单
     */
    Long addCampaignGroup(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO);

    /**
     * 更新订单部分setting信息
     *
     * @param serviceContext
     * @param campaignGroupId
     * @param settingMap
     * @return
     */
    Integer updateCampaignGroupSettingPartBatch(ServiceContext serviceContext, Long campaignGroupId, Map<String, String> settingMap);

    /**
     * 删除订单
     * @param serviceContext
     * @param id
     * @return
     */
    Integer deleteCampaignGroup(ServiceContext serviceContext, Long id);

    /**
     * 删除订单指定的setting信息
     *
     * @param serviceContext
     * @param campaignGroupId
     * @param settingKeyList
     * @return
     */
    Integer deleteCampaignGroupSettingBatch(ServiceContext serviceContext, Long campaignGroupId, List<String> settingKeyList);

    /**
     * 新增订单售卖分组
     * @param serviceContext
     * @param saleGroupViewDTOList
     * @return
     */
    Integer addSaleGroup(ServiceContext serviceContext,List<SaleGroupInfoViewDTO> saleGroupViewDTOList);
    /**
     * 部分更新订单售卖分组
     * @param serviceContext
     * @param campaignGroupId
     * @param saleGroupViewDTOList
     * @return
     */
    Integer addOrUpdateSaleGroupPart(ServiceContext serviceContext, Long campaignGroupId, List<SaleGroupInfoViewDTO> saleGroupViewDTOList);

    /**
     * 主键id必传
     *
     * @param serviceContext
     * @param saleGroupViewDTOList
     * @return
     */
    Integer updateSaleGroupPart(ServiceContext serviceContext, List<SaleGroupInfoViewDTO> saleGroupViewDTOList);
    /**
     * 全量覆盖订单id下的售卖分组（先删后加）
     * @param serviceContext
     * @param saleGroupViewDTOList
     * @return
     */
    Integer bindAllSaleGroup(ServiceContext serviceContext,Long campaignGroupId, List<SaleGroupInfoViewDTO> saleGroupViewDTOList);
    /**
     * 删除订单售卖分组
     * @param serviceContext
     * @param campaignGroupSaleGroupIdList 订单售卖分组主键id
     * @return
     */
    Integer deleteSaleGroup(ServiceContext serviceContext,List<Long> campaignGroupSaleGroupIdList);

    /**
     * 删除订单分组
     * @param serviceContext
     * @param campaignGroupId
     * @return
     */
    Integer deleteSaleGroupByCampaignGroupId(ServiceContext serviceContext,Long campaignGroupId);

    /**
     * 查询订单售卖分组
     * @param serviceContext
     * @param resourceSaleGroupId 资源包售卖分组id
     * @return
     */
    SaleGroupInfoViewDTO getSaleGroup(ServiceContext serviceContext,Long campaignGroupId,Long resourceSaleGroupId);
   
    /**
     * 查询订单售卖分组
     * @param serviceContext
     * @param saleGroupQueryViewDTO
     * @return
     */
    List<SaleGroupInfoViewDTO> findSaleGroupList(ServiceContext serviceContext, SaleGroupQueryViewDTO saleGroupQueryViewDTO);


    /**
     * 覆盖更新saleGroup
     * @param serviceContext
     * @param saleGroupInfoViewDTOList
     * @return
     */
    Integer updateSaleGroupAll(ServiceContext serviceContext,List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList);

    /**
     * 获取订单对应的店铺信息
     * @param serviceContext
     * @param campaignGroupId
     * @return
     */
    ShopViewDTO getShopInfoByCampaignGroupId(ServiceContext serviceContext,Long campaignGroupId);


}
