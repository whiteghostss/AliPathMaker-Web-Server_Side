package com.taobao.ad.brand.bp.domain.creative.repository;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.creative.materialgroup.MaterialGroupViewDTO;
import com.alibaba.ad.brand.dto.creative.materialgroup.MaterialViewDTO;

import java.util.List;

public interface MaterialGroupRepository {
    /**
     * 查询素材组
     * @param context
     * @param materialGroupId
     * @return
     */
    MaterialGroupViewDTO getMaterialGroupById(ServiceContext context, Long materialGroupId);

    /**
     * 局部更新素材（不重新推审核）
     * @param context
     * @param materialViewDTOList
     */
    void batchUpdateMaterialPartWithoutReAudit(ServiceContext context, List<MaterialViewDTO> materialViewDTOList);

    /**
     * 更新素材组拓版结果
     * @param context
     * @param materialGroupViewDTO
     */
    void updateMaterialGroupCropResult(ServiceContext context, MaterialGroupViewDTO materialGroupViewDTO);
}
