package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupJudgeForResourceConfirmAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupTransitAbilityParam;
import org.springframework.stereotype.Component;

import static com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupPurchaseStatusEnum.NON_PURCHASE;
import static com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupPurchaseStatusEnum.PURCHASE_FINISH;

@Component
@BusinessAbility
public class DefaultCampaignGroupJudgeForResourceConfirmAbility implements ICampaignGroupJudgeForResourceConfirmAbility {

    @Override
    public Boolean handle(ServiceContext serviceContext, CampaignGroupTransitAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        Integer purchaseStatus = campaignGroupViewDTO.getCampaignGroupPurchaseViewDTO().getPurchaseStatus();
        // 采购完成或无需采购时状态流转
        if (PURCHASE_FINISH.getCode().equals(purchaseStatus) || NON_PURCHASE.getCode().equals(purchaseStatus)) {
            return Boolean.TRUE;
        }

        return Boolean.FALSE;
    }
}
