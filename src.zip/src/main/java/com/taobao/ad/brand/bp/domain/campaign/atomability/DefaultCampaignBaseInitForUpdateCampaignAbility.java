package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignBaseInitForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBaseAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_REQUIRED;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultCampaignBaseInitForUpdateCampaignAbility implements ICampaignBaseInitForUpdateCampaignAbility {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignBaseAbilityParam abilityParam) {
        CampaignViewDTO campaignViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        AssertUtil.notNull(campaignViewDTO, PARAM_REQUIRED, "计划不能为空");
        AssertUtil.notNull(dbCampaignViewDTO, PARAM_REQUIRED, "计划不存在");

        campaignViewDTO.setId(dbCampaignViewDTO.getId());
        campaignViewDTO.setMemberId(dbCampaignViewDTO.getMemberId());
        campaignViewDTO.setProductLineId(dbCampaignViewDTO.getProductLineId());
        campaignViewDTO.setSceneId(dbCampaignViewDTO.getSceneId());
        campaignViewDTO.setCampaignGroupId(dbCampaignViewDTO.getCampaignGroupId());
        campaignViewDTO.setMainCampaignGroupId(dbCampaignViewDTO.getMainCampaignGroupId());
        campaignViewDTO.setParentCampaignId(dbCampaignViewDTO.getParentCampaignId());

        campaignViewDTO.setOnlineStatus(dbCampaignViewDTO.getOnlineStatus());
        campaignViewDTO.setCampaignLevel(dbCampaignViewDTO.getCampaignLevel());
        campaignViewDTO.setCampaignType(dbCampaignViewDTO.getCampaignType());
        campaignViewDTO.setCampaignModel(dbCampaignViewDTO.getCampaignModel());
        campaignViewDTO.setSspProgrammatic(dbCampaignViewDTO.getSspProgrammatic());
        campaignViewDTO.setGmtCreate(dbCampaignViewDTO.getGmtCreate());
        campaignViewDTO.setGmtModified(dbCampaignViewDTO.getGmtModified());
        //修改status
        if(Constant.CAN_CHANGE_NEW_STATUS.contains(dbCampaignViewDTO.getStatus())){
            campaignViewDTO.setStatus(BrandCampaignStatusEnum.NEW.getCode());
        }else{
            campaignViewDTO.setStatus(dbCampaignViewDTO.getStatus());
        }
        return null;
    }
}
