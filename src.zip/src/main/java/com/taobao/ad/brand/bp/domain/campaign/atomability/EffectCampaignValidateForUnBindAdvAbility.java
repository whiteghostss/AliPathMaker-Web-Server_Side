package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.EffectAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignValidateForUnBindAdvAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignValidateForBindOrUnBindAdvAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EffectCampaignValidateForUnBindAdvAbility implements ICampaignValidateForUnBindAdvAbility, EffectAtomAbilityRouter {

    private List<Integer> INVALID_UNBIND_CAMPAIGN_STATUS_LIST = Lists.newArrayList(
            BrandCampaignStatusEnum.WAITING.getCode(),
            BrandCampaignStatusEnum.CASTING.getCode(),
            BrandCampaignStatusEnum.PAUSING.getCode(),
            BrandCampaignStatusEnum.ENDING.getCode()
    );

    @Override
    public Void handle(ServiceContext serviceContext, CampaignValidateForBindOrUnBindAdvAbilityParam abilityParam) {
        CampaignViewDTO campaignViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.assertTrue(campaignViewDTO.getCampaignLevel().equals(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode()),"一级计划才可以解绑adv");

        if (!Objects.equals(BrandCampaignGroupStatusEnum.CANCELED.getCode(), abilityParam.getCampaignGroupViewDTO())) {
            AssertUtil.assertTrue(!INVALID_UNBIND_CAMPAIGN_STATUS_LIST.contains(campaignViewDTO.getStatus()), "当前计划状态不允许解绑。");
        }

        return null;
    }
}
