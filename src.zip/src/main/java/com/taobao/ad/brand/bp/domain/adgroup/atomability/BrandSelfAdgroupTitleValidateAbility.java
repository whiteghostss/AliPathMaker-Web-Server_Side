package com.taobao.ad.brand.bp.domain.adgroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.ValidatorUtil;
import com.taobao.ad.brand.bp.domain.adgroup.repository.AdgroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupTitleValidateAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupTitleValidateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.BIZ_DATA_EXIST_ERROR;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSelfAdgroupTitleValidateAbility implements IAdgroupTitleValidateAbility, BrandSelfServiceAtomAbilityRouter {

    private final AdgroupRepository adgroupRepository;

    @Override
    public Void handle(ServiceContext serviceContext, AdgroupTitleValidateAbilityParam abilityParam) {
        AdgroupViewDTO adgroupViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(adgroupViewDTO,"推广单元不能为空");
        AssertUtil.hasText(adgroupViewDTO.getTitle(),"推广单元标题不能为空");
        AssertUtil.maxLength(adgroupViewDTO.getTitle(),100,"推广单元标题长度不能超过100");
        AssertUtil.assertTrue(ValidatorUtil.isText(adgroupViewDTO.getTitle()),"推广单元标题仅支持数字、字母、汉字、下划线、中线");
        AdgroupViewDTO dbDTO  = adgroupRepository.queryAdgroupTopOneByName(serviceContext,adgroupViewDTO.getId(),adgroupViewDTO.getTitle());
        AssertUtil.assertTrue(Objects.isNull(dbDTO),BIZ_DATA_EXIST_ERROR,"单元名称不能重复");
        return null;
    }
}
