package com.taobao.ad.brand.bp.domain.adgroup.spi;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.nb.framework.core.AbilitySpi;
import com.alibaba.ad.nb.framework.core.annotation.Ability;
import com.taobao.ad.brand.bp.client.dto.adgroup.AdgroupWarnViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.ability.param.BizAdgroupAbilityParam;

import java.util.List;

/**
 * 推广单元相关SPI实现
 * */
@Ability(desc = "单元SPI")
public interface AdgroupAbilitySpi extends AbilitySpi {

    /**
     * 处理草稿状态
     * @param serviceContext
     * @param adgroupViewDTO
     * @return
     */
    Void validateDraftStatus(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, CampaignViewDTO campaignViewDTO);

    /**
     *======================================================================================================================================================================================
        新接口
     */


    /**
     * 校验是否可以创建单元
     * */
    Void validateCanCreate(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO,BizAdgroupAbilityParam bizAdgroupAbilityParam);



    /**
     * 处理人群定向
     * @param serviceContext
     * @param adgroupViewDTO
     * @return
     */
    Void validateCrowdTarget(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO,BizAdgroupAbilityParam bizAdgroupAbilityParam);




    /**
     * 处理创意
     * @param serviceContext
     * @param adgroupViewDTO
     * @return
     */
    Void validateCreative(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, BizAdgroupAbilityParam bizAdgroupAbilityParam);



    /**
     * 编辑的时候复写默认值，防止前端篡改
     * @param serviceContext
     * @param adgroupViewDTO
     * @return
     */

    Void initAddDefaultProperty(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO,BizAdgroupAbilityParam bizAdgroupAbilityParam) ;

    /**
     * 编辑的时候复写默认值，防止前端篡改
     * @param serviceContext
     * @param adgroupViewDTO
     * @return
     */

    Void initUpdateProperty(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO,BizAdgroupAbilityParam bizAdgroupAbilityParam);

    AdgroupWarnViewDTO getAdgroupWarnViewDTO(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, BizAdgroupAbilityParam bizAdgroupAbilityParam);
}
