package com.taobao.ad.brand.bp.domain.adgroup.constant;

import com.taobao.ad.brand.bp.client.dto.media.MediaBusinessManagerViewDTO;

/**
 * @author 弈云
 * @date 2023年03月13日
 */
public interface AdgroupMonitorConstant {
    public static MediaBusinessManagerViewDTO defaultContactUser(){
        MediaBusinessManagerViewDTO mediaBusinessManagerViewDTO = new MediaBusinessManagerViewDTO();
        mediaBusinessManagerViewDTO.setName("举铁");
        mediaBusinessManagerViewDTO.setEmail("xichun.nxc@alibaba-inc.com");
        return mediaBusinessManagerViewDTO;
    }
}
