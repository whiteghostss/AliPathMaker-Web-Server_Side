package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.CampaignGroupSaleViewDTO;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupSaleInitForUpdateCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupSaleAbilityParam;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
public class DefaultCampaignGroupSaleInitForUpdateCampaignGroupAbility implements ICampaignGroupSaleInitForUpdateCampaignGroupAbility {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupSaleAbilityParam abilityParam) {
        if (!BizCampaignGroupToolsHelper.isSaleCampaignGroup(abilityParam.getCampaignGroupViewDTO()) || !BizCampaignGroupToolsHelper.isSubCampaignGroup(abilityParam.getCampaignGroupViewDTO())) {
            return null;
        }
        if (abilityParam.getMainCampaignGroupViewDTO() == null || abilityParam.getMainCampaignGroupViewDTO().getCampaignGroupSaleViewDTO() == null) {
            return null;
        }
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        CampaignGroupSaleViewDTO mainCampaignGroupSaleViewDTO = abilityParam.getMainCampaignGroupViewDTO().getCampaignGroupSaleViewDTO();
        CampaignGroupSaleViewDTO updateSaleViewDTO = new CampaignGroupSaleViewDTO();
        updateSaleViewDTO.setDirectSales(mainCampaignGroupSaleViewDTO.getDirectSales());
        updateSaleViewDTO.setChannelSales(mainCampaignGroupSaleViewDTO.getChannelSales());
        updateSaleViewDTO.setRelevantSales(mainCampaignGroupSaleViewDTO.getRelevantSales());

        campaignGroupViewDTO.setCampaignGroupSaleViewDTO(updateSaleViewDTO);
        return null;
    }
}
