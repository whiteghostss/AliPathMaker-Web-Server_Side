package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignSplitSubCheckForUpdateCastDateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignSplitSubAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignUpdateCastDateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSelfCampaignSplitSubCheckForUpdateCastDateAbility
    implements ICampaignSplitSubCheckForUpdateCastDateAbility, BrandSelfServiceAtomAbilityRouter {

    @Resource
    ResourcePackageRepository resourcePackageRepository;
    @Override
    public Boolean handle(ServiceContext serviceContext, CampaignUpdateCastDateAbilityParam abilityParam) {
        CampaignViewDTO campaignViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        ResourcePackageProductViewDTO resourcePackageProductViewDTO  = resourcePackageRepository.getResourcePackageProduct(serviceContext,dbCampaignViewDTO.getCampaignSaleViewDTO().getResourcePackageProductId());
        if(CollectionUtils.isNotEmpty(resourcePackageProductViewDTO.getBandPriceList())
            && resourcePackageProductViewDTO.getBandPriceList().stream().map(
            ResourcePackageProductPriceViewDTO::getPrice).distinct().count() > 1) {
            return true;
        }
        return false;
    }

}
