package com.taobao.ad.brand.bp.domain.campaigngroup.workflow;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.cancel.CampaignGroupCancelViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.complete.CampaignGroupCompleteConfigViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.content.CampaignGroupContentViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.contract.CampaignGroupContractViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.ext.CampaignGroupExtViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.inquiry.CampaignGroupInquiryViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.order.CampaignGroupOrderViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.purchase.CampaignGroupPurchaseViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.realsettle.CampaignGroupRealSettleViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.unlock.CampaignGroupUnlockViewDTO;
import com.alibaba.ad.brand.dto.common.WakeupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupProcessStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleGroupSourceEnum;
import com.alibaba.hermes.framework.event.SimpleEventEngine;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.context.CampaignGroupStateContext;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupOrderCommandViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.calculate.CampaignGroupSaleGroupCalViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.CampaignGroupSaleGroupEstimateQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.salegroup.SaleGroupCheckedRebuildResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.salegroup.SaleGroupDiffResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.salegroup.SaleGroupSelectJudgeViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.settle.CampaignGroupRealSettleSaveViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProjectViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupEventEnum;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.settle.CampaignGroupRealSettleOpTypeEnum;
import com.taobao.ad.brand.bp.client.enums.message.DomainMessageSettingKeyEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizSaleGroupToolsHelper;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CustomerRepository;
import com.taobao.ad.brand.bp.domain.event.campaigngroup.CampaignGroupStatusTransitEvent;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignValidateForOrderCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignValidateForOrderCampaignGroupAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.*;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.*;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.workflow.BizCampaignGroupCommandWorkflowExt;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.workflow.param.BizCampaignGroupCalculateWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.workflow.param.BizCampaignGroupProcessOrderWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.workflow.param.BizCampaignGroupPurchaseOrderWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.workflow.param.BizCampaignGroupRealSettleWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.workflow.param.BizCampaignGroupTransitWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.workflow.param.BizCampaignGroupWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.*;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupDiffAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupInitAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupOrderAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupPriceUpdatedIdGetAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupSubContractBindAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.workflow.param.BizSaleGroupEstimateWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.IMessageSyncSendAbility;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.param.MessageSyncSendAbilityParam;
import com.taobao.mtop.commons.utils.CollectionUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_BREAK_RULE;
import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_REQUIRED;

/**
 * Description:品牌订单扩展
 * <p>
 * date: 2023/10/24 2:51 PM
 *
 * @author shiyan
 * @version 1.0
 */
@BusinessAbility
public class DefaultCampaignGroupCommandWorkflowExtImpl implements BizCampaignGroupCommandWorkflowExt {
    @Resource
    protected ResourcePackageRepository resourcePackageRepository;
    @Resource
    protected CampaignRepository campaignRepository;
    @Resource
    protected CampaignGroupRepository campaignGroupRepository;
    @Resource
    protected CustomerRepository customerRepository;
    @Resource
    protected SimpleEventEngine simpleEventEngine;
    @Resource
    private IMessageSyncSendAbility messageSyncSendAbility;
    @Resource
    protected ICampaignGroupNameValidateAbility campaignGroupNameValidateAbility;
    @Resource
    protected ICampaignGroupInquiryInfoUpdateAbility campaignGroupInquiryInfoUpdateAbility;
    @Resource
    protected ICampaignGroupGiveStatusUpdateAbility campaignGroupGiveStatusUpdateAbility;
    @Resource
    protected ICampaignGroupBoostStatusUpdateAbility campaignGroupBoostStatusUpdateAbility;
    @Resource
    private ICampaignGroupMessageAsyncSendAbility campaignGroupMessageAsyncSendAbility;
    @Resource
    private ICampaignGroupBaseInitForUpdateCampaignGroupAbility campaignGroupBaseInitForUpdateCampaignGroupAbility;
    @Resource
    private ICampaignGroupSaleInitForUpdateCampaignGroupAbility campaignGroupSaleInitForUpdateCampaignGroupAbility;
    @Resource
    private ICampaignGroupSaleGroupInitForUpdateCampaignGroupAbility campaignGroupSaleGroupInitForUpdateCampaignGroupAbility;
    @Resource
    protected ISaleGroupDiffForUpdateCampaignGroupAbility saleGroupDiffForUpdateCampaignGroupAbility;
    @Resource
    protected ISaleGroupInitForAddAbility saleGroupInitForAddAbility;
    @Resource
    protected ISaleGroupInitForUpdateAbility saleGroupInitForUpdateAbility;
    @Resource
    protected ISaleGroupInitForDeleteAbility saleGroupInitForDeleteAbility;
    @Resource
    protected ISaleGroupSubContractBindAbility saleGroupSubContractBindAbility;
    @Resource
    private ISaleGroupValidateForOrderCampaignGroupAbility saleGroupValidateForOrderCampaignGroupAbility;
    @Resource
    private ISaleGroupSelectJudgeForOrderCampaignGroupAbility saleGroupSelectJudgeForOrderCampaignGroupAbility;
    @Resource
    private ISaleGroupPriceUpdatedSaleGroupIdGetAbility saleGroupPriceUpdatedSaleGroupIdGetAbility;
    @Resource
    private ISaleGroupProductValidateForOrderCampaignGroupAbility saleGroupProductValidateForOrderCampaignGroupAbility;
    @Resource
    private ICampaignValidateForOrderCampaignGroupAbility campaignValidateForOrderCampaignGroupAbility;

    @Autowired
    private ISaleGroupInitForOrderCampaignGroupAbility saleGroupInitForOrderCampaignGroupAbility;
    @Resource
    private ICampaignGroupBaseInitForOrderCampaignGroupAbility campaignGroupBaseInitForOrderCampaignGroupAbility;
    @Resource
    private ICampaignGroupOrderInitForOrderCampaignGroupAbility campaignGroupOrderInitForOrderCampaignGroupAbility;
    @Resource
    private ICampaignGroupContractInitForOrderCampaignGroupAbility campaignGroupContractInitForOrderCampaignGroupAbility;
    @Resource
    private ICampaignGroupCustomerInitForOrderCampaignGroupAbility campaignGroupCustomerInitForOrderCampaignGroupAbility;
    @Resource
    private ICampaignGroupCheckedSaleGroupRebuildForOrderCampaignGroupAbility campaignGroupCheckedSaleGroupRebuildForOrderCampaignGroupAbility;

    @Override
    public void beforeExecuteAddCampaignGroup(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, BizCampaignGroupWorkflowParam bizCampaignGroupWorkflowParam) {
        // 默认子订单，什么都不做
    }

    @Override
    public Void afterExecuteAddCampaignGroup(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO) {
        // 5. 计算并设置盘量信息
        campaignGroupInquiryInfoUpdateAbility.handle(context, CampaignGroupInquiryInfoUpdateAbilityParam.builder().abilityTarget(campaignGroupViewDTO.getCampaignGroupInquiryViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO).build());

        // 6. 计算并设置配送状态
        campaignGroupGiveStatusUpdateAbility.handle(context, CampaignGroupGiveStatusUpdateAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
        return null;
    }

    @Override
    public void beforeExecuteUpdateCampaignGroup(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, BizCampaignGroupWorkflowParam bizCampaignGroupWorkflowParam) {
        // 仅处理销售子订单
        if (!BizCampaignGroupToolsHelper.isSaleCampaignGroup(campaignGroupViewDTO) || !BizCampaignGroupToolsHelper.isSubCampaignGroup(campaignGroupViewDTO)) {
            return;
        }
        this.initSubCampaignGroupForUpdate(context, campaignGroupViewDTO, bizCampaignGroupWorkflowParam);
    }

    private void initSubCampaignGroupForUpdate(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, BizCampaignGroupWorkflowParam bizCampaignGroupWorkflowParam) {
        CampaignGroupViewDTO dbCampaignGroupViewDTO = bizCampaignGroupWorkflowParam.getDbCampaignGroupViewDTO();
        // 基础信息
        campaignGroupBaseInitForUpdateCampaignGroupAbility.handle(context, CampaignGroupBaseAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO).dbCampaignGroupViewDTO(dbCampaignGroupViewDTO).build());
        // 售卖信息
        campaignGroupSaleInitForUpdateCampaignGroupAbility.handle(context, CampaignGroupSaleAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupSaleViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO)
                .mainCampaignGroupViewDTO(bizCampaignGroupWorkflowParam.getDbMainCampaignGroupViewDTO()).build());
        // 订单分组信息
        campaignGroupSaleGroupInitForUpdateCampaignGroupAbility.handle(context, CampaignGroupSaleGroupAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO)
                .dbCampaignGroupViewDTO(bizCampaignGroupWorkflowParam.getDbCampaignGroupViewDTO()).build());
        // 其他属性暂时不实现原子能力
        campaignGroupViewDTO.setCampaignGroupContractViewDTO(new CampaignGroupContractViewDTO());
        campaignGroupViewDTO.setCampaignGroupOrderViewDTO(new CampaignGroupOrderViewDTO());
        campaignGroupViewDTO.setCampaignGroupUnlockViewDTO(new CampaignGroupUnlockViewDTO());
        campaignGroupViewDTO.setCampaignGroupCancelViewDTO(new CampaignGroupCancelViewDTO());
        campaignGroupViewDTO.setCampaignGroupRealSettleViewDTO(new CampaignGroupRealSettleViewDTO());
        campaignGroupViewDTO.setCampaignGroupCompleteConfigViewDTO(new CampaignGroupCompleteConfigViewDTO());
        campaignGroupViewDTO.setCampaignGroupContentViewDTO(new CampaignGroupContentViewDTO());
        campaignGroupViewDTO.setProcessRecordViewDTOList(Lists.newArrayList());
        campaignGroupViewDTO.setCampaignGroupPurchaseViewDTO(new CampaignGroupPurchaseViewDTO());
        campaignGroupViewDTO.setCampaignGroupInquiryViewDTO(new CampaignGroupInquiryViewDTO());
        campaignGroupViewDTO.setWakeupViewDTO(new WakeupViewDTO());
        campaignGroupViewDTO.setCampaignGroupExtViewDTO(new CampaignGroupExtViewDTO());
    }

    @Override
    public Void afterExecuteUpdateCampaignGroup(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO) {
        return afterExecuteAddCampaignGroup(serviceContext, campaignGroupViewDTO);
    }

    @Override
    public BizCampaignGroupCalculateWorkflowParam buildParamForCalculate(ServiceContext serviceContext, CampaignGroupSaleGroupCalViewDTO saleGroupCalViewDTO) {
        return null;
    }

    @Override
    public void afterTransitCompleted(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, BizCampaignGroupTransitWorkflowParam transitWorkflowParam) {
        // 默认子订单
        CampaignGroupStateContext stateContext = transitWorkflowParam.getStateContext();
        // 1. 发送计划领域事件(同步)
        messageSyncSendAbility.handle(serviceContext, MessageSyncSendAbilityParam.builder().abilityTarget(CampaignGroupStatusTransitEvent.of(stateContext)).build());
        // 2. 发送订单领域消息（异步）
        if (BizCampaignGroupToolsHelper.isNeedConsumeCampaignGroupSyncDomainEvent(campaignGroupViewDTO, stateContext.getEventEnum())) {
            campaignGroupMessageAsyncSendAbility.handle(serviceContext, CampaignGroupMessageAsyncSendAbilityParam.builder()
                    .abilityTarget(campaignGroupViewDTO).domainEvent(stateContext.getEventEnum().name()).build());
        }
    }

    /**
     * 默认实现为子订单参数构建
     *
     * @param context
     * @param campaignGroupOrderCommandViewDTO
     * @param campaignGroupViewDTO
     * @return
     */
    @Override
    public BizCampaignGroupProcessOrderWorkflowParam buildParamForOrder(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO, CampaignGroupViewDTO campaignGroupViewDTO) {
        BizCampaignGroupProcessOrderWorkflowParam workflowParam = new BizCampaignGroupProcessOrderWorkflowParam();
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(campaignGroupOrderCommandViewDTO.getSaleGroupIds()), PARAM_REQUIRED, "勾选的分组不能为空");

        // 重新build所选的分组
        SaleGroupCheckedRebuildResultViewDTO rebuildResultViewDTO = campaignGroupCheckedSaleGroupRebuildForOrderCampaignGroupAbility.handle(context, CampaignGroupCheckedSaleGroupRebuildForOrderAbilityParam.builder()
                .abilityTarget(campaignGroupOrderCommandViewDTO).campaignGroupViewDTO(campaignGroupViewDTO).subCampaignGroupList(workflowParam.getSubCampaignGroupList()).build());
        workflowParam.setSalePlatformSaleGroupIds(rebuildResultViewDTO.getSalePlatformSaleGroupIds());
        workflowParam.setPackagePlatformSaleGroupIds(rebuildResultViewDTO.getPackagePlatformSaleGroupIds());
        workflowParam.setCalOrderSaleGroupIds(rebuildResultViewDTO.getCalOrderSaleGroupIds());

        // 分组信息
        List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupList = resourcePackageRepository.getSaleGroupList(context, workflowParam.getCalOrderSaleGroupIds(), new ResourcePackageQueryOption());
        workflowParam.setResourcePackageSaleGroupList(resourcePackageSaleGroupList);
        // 计划信息
        CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder()
                .campaignGroupId(campaignGroupViewDTO.getId())
                .saleGroupIds(workflowParam.getCalOrderSaleGroupIds())
                .campaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode())
                .build();
        List<CampaignViewDTO> campaignViewDTOList = campaignRepository.queryCampaignList(context, campaignQueryViewDTO);
        workflowParam.setCampaignList(campaignViewDTOList);

        return workflowParam;
    }

    @Override
    public void validateForOrder(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO, BizCampaignGroupProcessOrderWorkflowParam workflowParam) {
        // 默认子订单下单校验
        List<ResourcePackageSaleGroupViewDTO> budgetResourcePackageOrderSaleGroupList = workflowParam.getResourcePackageSaleGroupList().stream()
                .filter(it -> Optional.ofNullable(it.getBudget()).orElse(0L) > 0).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(budgetResourcePackageOrderSaleGroupList)) {
            return;
        }
        CampaignGroupViewDTO campaignGroupViewDTO = workflowParam.getCampaignGroupViewDTO();
        List<CampaignViewDTO> campaignViewDTOList = workflowParam.getCampaignList();
        List<Long> saleGroupIds = campaignGroupOrderCommandViewDTO.getSaleGroupIds();
        // 1. 校验分组
        // 1-1. 校验分组是否符合要求、是否有效
        List<SaleGroupInfoViewDTO> selectSaleGroupInfoList = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream()
                .filter(saleGroup -> saleGroupIds.contains(saleGroup.getSaleGroupId())).collect(Collectors.toList());
        saleGroupValidateForOrderCampaignGroupAbility.handle(context, SaleGroupOrderAbilityParam.builder().abilityTargets(selectSaleGroupInfoList).saleGroupIds(saleGroupIds)
                .campaignGroupViewDTO(campaignGroupViewDTO).resourcePackageSaleGroupList(budgetResourcePackageOrderSaleGroupList).build());
        // 1-2. 校验分组是否支持勾选
        Map<Long, SaleGroupSelectJudgeViewDTO> saleGroupSelectJudgeMap = saleGroupSelectJudgeForOrderCampaignGroupAbility.handle(context, SaleGroupOrderAbilityParam.builder().abilityTargets(selectSaleGroupInfoList)
                .campaignGroupViewDTO(campaignGroupViewDTO).resourcePackageSaleGroupList(budgetResourcePackageOrderSaleGroupList).build());
        List<Long> cannotOrderSaleGroupIds = saleGroupIds.stream()
                .filter(saleGroupId -> !saleGroupSelectJudgeMap.containsKey(saleGroupId) || BrandBoolEnum.BRAND_FALSE.getCode().equals(saleGroupSelectJudgeMap.get(saleGroupId).getCanSelect()))
                .collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(cannotOrderSaleGroupIds)) {
            List<String> saleGroupNameList = BizSaleGroupToolsHelper.getSaleGroupNames(budgetResourcePackageOrderSaleGroupList, cannotOrderSaleGroupIds);
            throw new BrandOneBPException(PARAM_BREAK_RULE.of(String.format("以下分组(%s)不支持下单", StringUtils.join(saleGroupNameList, ", "))));
        }
        // 1-3. 校验分组预算、单价是否有更新
        List<Long> updatedSaleGroupIds = saleGroupPriceUpdatedSaleGroupIdGetAbility.handle(context, SaleGroupPriceUpdatedIdGetAbilityParam.builder()
                .abilityTargets(selectSaleGroupInfoList).campaignGroupViewDTO(campaignGroupViewDTO).resourcePackageSaleGroupList(budgetResourcePackageOrderSaleGroupList).build());
        if (CollectionUtils.isNotEmpty(updatedSaleGroupIds)) {
            List<String> saleGroupNameList = BizSaleGroupToolsHelper.getSaleGroupNames(budgetResourcePackageOrderSaleGroupList, updatedSaleGroupIds);
            throw new BrandOneBPException(PARAM_BREAK_RULE, String.format("以下分组(%s)的分组金额或单价已更新，请先进行订单配置", StringUtils.join(saleGroupNameList, ", ")));
        }
        // 1-4. 校验分组产品（周期、必选资源等）
        saleGroupProductValidateForOrderCampaignGroupAbility.handle(context, SaleGroupOrderAbilityParam.builder()
                .abilityTargets(selectSaleGroupInfoList).saleGroupIds(saleGroupIds).campaignGroupViewDTO(campaignGroupViewDTO)
                .campaignViewDTOList(campaignViewDTOList).resourcePackageSaleGroupList(budgetResourcePackageOrderSaleGroupList).build());

        // 2. 校验计划
        campaignValidateForOrderCampaignGroupAbility.handle(context, CampaignValidateForOrderCampaignGroupAbilityParam.builder()
                .abilityTargets(campaignViewDTOList).campaignGroupViewDTO(campaignGroupViewDTO)
                .resourcePackageSaleGroupList(budgetResourcePackageOrderSaleGroupList).build());

    }

    /**
     * 默认子订单前置处理
     *
     * @param context
     * @param campaignGroupOrderCommandViewDTO
     * @param orderWorkflowParam
     */
    @Override
    public void beforeOrder(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO, BizCampaignGroupProcessOrderWorkflowParam orderWorkflowParam) {
        // 校验
        this.validateForOrder(context, campaignGroupOrderCommandViewDTO, orderWorkflowParam);
        // 初始化
        this.initForOrder(context, campaignGroupOrderCommandViewDTO, orderWorkflowParam);
    }

    protected void initForOrder(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO, BizCampaignGroupProcessOrderWorkflowParam orderWorkflowParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = orderWorkflowParam.getCampaignGroupViewDTO();
        // 分组初始化
        saleGroupInitForOrderCampaignGroupAbility.handle(context, SaleGroupOrderAbilityParam.builder()
                .abilityTargets(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList()).campaignGroupViewDTO(campaignGroupViewDTO)
                .saleGroupIds(campaignGroupOrderCommandViewDTO.getSaleGroupIds()).resourcePackageSaleGroupList(orderWorkflowParam.getResourcePackageSaleGroupList())
                .campaignViewDTOList(orderWorkflowParam.getCampaignList()).build());
        // 订单基础信息初始化
        campaignGroupBaseInitForOrderCampaignGroupAbility.handle(context, CampaignGroupBaseAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
        // 订单基础信息初始化
        campaignGroupOrderInitForOrderCampaignGroupAbility.handle(context, CampaignGroupOrderInitForOrderAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupOrderViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO)
                .campaignGroupOrderCommandViewDTO(campaignGroupOrderCommandViewDTO).build());
        // 合同信息初始化
        campaignGroupContractInitForOrderCampaignGroupAbility.handle(context, CampaignGroupContractInitForOrderAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupContractViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO)
                .campaignGroupOrderCommandViewDTO(campaignGroupOrderCommandViewDTO).build());
        // 客户信息初始化
        campaignGroupCustomerInitForOrderCampaignGroupAbility.handle(context, CampaignGroupCustomerInitForOrderAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupCustomerViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO)
                .campaignGroupOrderCommandViewDTO(campaignGroupOrderCommandViewDTO).build());
    }

    @Override
    public void afterOrder(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO, BizCampaignGroupProcessOrderWorkflowParam processWorkflowParam) {
        // 1. 计算补量、配送状态
        campaignGroupGiveStatusUpdateAbility.handle(context, CampaignGroupGiveStatusUpdateAbilityParam.builder().abilityTarget(processWorkflowParam.getCampaignGroupViewDTO()).build());
        campaignGroupBoostStatusUpdateAbility.handle(context, CampaignGroupBoostStatusUpdateAbilityParam.builder().abilityTarget(processWorkflowParam.getCampaignGroupViewDTO()).build());

        // 2. 处理资源包分组下单后置处理
        handlerPackageSaleGroupAfterOrder(context, campaignGroupOrderCommandViewDTO, processWorkflowParam);
        // 3. 发送下单通知消息事件
        sendCampaignGroupOrderMsgEvent(context, processWorkflowParam.getCampaignGroupViewDTO(), campaignGroupOrderCommandViewDTO.getSaleGroupIds());
    }

    @Override
    public BizSaleGroupEstimateWorkflowParam buildWorkflowParamForEstimate(ServiceContext context, CampaignGroupSaleGroupEstimateQueryViewDTO campaignGroupSaleGroupEstimateQueryViewDTO) {
        return null;
    }

    @Override
    public BizCampaignGroupRealSettleWorkflowParam buildWorkflowParamForSaveRealSettleInfo(ServiceContext context, CampaignGroupRealSettleSaveViewDTO campaignGroupRealSettleSaveViewDTO) {
        AssertUtil.notNull(campaignGroupRealSettleSaveViewDTO, PARAM_REQUIRED, "参数不能为空");
        AssertUtil.notNull(campaignGroupRealSettleSaveViewDTO.getId(), PARAM_REQUIRED, "订单ID不能为空");

        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(context, campaignGroupRealSettleSaveViewDTO.getId());
        AssertUtil.notNull(campaignGroupRealSettleSaveViewDTO.getId(), PARAM_REQUIRED, "订单不存在");

        BizCampaignGroupRealSettleWorkflowParam workflowParam = BizCampaignGroupRealSettleWorkflowParam.builder().campaignGroupViewDTO(campaignGroupViewDTO).build();
        if (campaignGroupRealSettleSaveViewDTO.getRealSettleOpTypeEnum() == CampaignGroupRealSettleOpTypeEnum.SUBMIT) {
            // 项目
            if (campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getMarketingProjectId() != null) {
                ResourcePackageProjectViewDTO resourcePackageProjectViewDTO = resourcePackageRepository.getResourcePackageProject(context, campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getMarketingProjectId());
                workflowParam.setResourcePackageProjectViewDTO(resourcePackageProjectViewDTO);
            }
        }
        return workflowParam;
    }

    @Override
    public BizCampaignGroupProcessOrderWorkflowParam buildParamForModify(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO, CampaignGroupViewDTO campaignGroupViewDTO) {
        BizCampaignGroupProcessOrderWorkflowParam processWorkflowParam = new BizCampaignGroupProcessOrderWorkflowParam();
        processWorkflowParam.setCampaignGroupViewDTO(campaignGroupViewDTO);
        // 分组
        List<Long> unlockSaleGroupIds = campaignGroupOrderCommandViewDTO.getSaleGroupIds();
        processWorkflowParam.setCalOrderSaleGroupIds(unlockSaleGroupIds);
        // 售卖中心平台分组
        List<Long> salePlatformSaleGroupIds = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream()
                .filter(saleGroupInfo -> unlockSaleGroupIds.contains(saleGroupInfo.getSaleGroupId()))
                .filter(saleGroupInfo -> BrandSaleGroupSourceEnum.SALE_PLATFORM.getCode().equals(saleGroupInfo.getSource()))
                .map(SaleGroupInfoViewDTO::getSaleGroupId)
                .collect(Collectors.toList());
        processWorkflowParam.setSalePlatformSaleGroupIds(salePlatformSaleGroupIds);
        // 资源包平台分组
        List<Long> packagePlatformSaleGroupIds = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream()
                .filter(saleGroupInfo -> unlockSaleGroupIds.contains(saleGroupInfo.getSaleGroupId()))
                .filter(saleGroupInfo -> BrandSaleGroupSourceEnum.PACKAGE_PLATFORM.getCode().equals(saleGroupInfo.getSource()))
                .map(SaleGroupInfoViewDTO::getSaleGroupId)
                .collect(Collectors.toList());
        processWorkflowParam.setPackagePlatformSaleGroupIds(packagePlatformSaleGroupIds);

        return processWorkflowParam;
    }

    @Override
    public void afterModify(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO, BizCampaignGroupProcessOrderWorkflowParam processWorkflowParam) {
        // 4-1. 计算补量、配送状态
        campaignGroupGiveStatusUpdateAbility.handle(context, CampaignGroupGiveStatusUpdateAbilityParam.builder().abilityTarget(processWorkflowParam.getCampaignGroupViewDTO()).build());
        campaignGroupBoostStatusUpdateAbility.handle(context, CampaignGroupBoostStatusUpdateAbilityParam.builder().abilityTarget(processWorkflowParam.getCampaignGroupViewDTO()).build());
    }

    @Override
    public void afterFinishSubCampaignGroupRealSettleProcess(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, BrandCampaignGroupProcessStatusEnum processStatusEnum) {
        // 发送子->主订单领域事件
        campaignGroupMessageAsyncSendAbility.handle(context, CampaignGroupMessageAsyncSendAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO).domainEvent(CampaignGroupEventEnum.REAL_SETTLE_CONFIG.name()).build());
    }

    @Override
    public void beforePreOrder(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, BizCampaignGroupProcessOrderWorkflowParam processWorkflowParam) {
//        // 初始化
//        initForPreOrder(serviceContext, campaignGroupViewDTO, processWorkflowParam);
    }

//    private void initForPreOrder(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, BizCampaignGroupProcessOrderWorkflowParam processWorkflowParam) {
//        BizCampaignGroupProcessAbilityParam abilityParam = BizCampaignGroupProcessAbilityParam.builder()
//                .subCampaignGroupList(processWorkflowParam.getSubCampaignGroupList())
//                .campaignList(processWorkflowParam.getCampaignList())
//                .build();
//        bizCampaignGroupProcessAbility.initForPreOrder(serviceContext, campaignGroupViewDTO, abilityParam);
//    }
//
//    @Override
//    public BizCampaignGroupProcessOrderWorkflowParam buildWorkflowParamForPreOrder(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO) {
//        return new BizCampaignGroupProcessOrderWorkflowParam();
//    }

    @Override
    public BizCampaignGroupPurchaseOrderWorkflowParam buildParamForPurchaseOrder(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO) {
        BizCampaignGroupPurchaseOrderWorkflowParam purchaseOrderWorkflowParam = new BizCampaignGroupPurchaseOrderWorkflowParam();
        return purchaseOrderWorkflowParam;
    }

    @Override
    public void afterAdd(ServiceContext context, CampaignGroupViewDTO campaignGroup) {
        // 1. 发送领域消息
        campaignGroupMessageAsyncSendAbility.handle(context, CampaignGroupMessageAsyncSendAbilityParam.builder()
                .abilityTarget(campaignGroup).domainEvent(CampaignGroupEventEnum.CREATE.name()).build());
    }

    private void handlerPackageSaleGroupAfterOrder(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO, BizCampaignGroupProcessOrderWorkflowParam processWorkflowParam) {
        List<Long> packageSaleGroupIds = processWorkflowParam.getPackagePlatformSaleGroupIds();
        if (CollectionUtils.isEmpty(packageSaleGroupIds)) {
            return;
        }
        CampaignGroupViewDTO campaignGroupViewDTO = processWorkflowParam.getCampaignGroupViewDTO();
        // 更新分组绑定的子合同ID
        Set<Long> updateSubContractSaleGroupIdSet = saleGroupSubContractBindAbility.handle(context, SaleGroupSubContractBindAbilityParam.builder()
                .abilityTargets(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList())
                .campaignGroupViewDTO(campaignGroupViewDTO).targetSaleGroupIds(packageSaleGroupIds)
                .subContractViewDTOList(Lists.newArrayList()).build());
        if (campaignGroupViewDTO.getCampaignGroupContractViewDTO().getContractFirstOnlineTime() == null) {
            if (CollectionUtils.isNotEmpty(updateSubContractSaleGroupIdSet)) {
                // 发送绑定子合同的领域事件（For计划）
                CampaignGroupStateContext stateContext = CampaignGroupStateContext.builder()
                        .serviceContext(context).saleGroupIds(Lists.newArrayList(updateSubContractSaleGroupIdSet))
                        .campaignGroupViewDTO(campaignGroupViewDTO).eventEnum(CampaignGroupEventEnum.SUB_CONTRACT_GENERATE).build();
                messageSyncSendAbility.handle(context,
                        MessageSyncSendAbilityParam.builder().abilityTarget(CampaignGroupStatusTransitEvent.of(stateContext)).build());
            }
        } else {
            // 发送上线的领域事件（For计划）
            CampaignGroupStateContext stateContext = CampaignGroupStateContext.builder()
                    .serviceContext(context).saleGroupIds(packageSaleGroupIds)
                    .campaignGroupViewDTO(campaignGroupViewDTO).eventEnum(CampaignGroupEventEnum.ONLINE).build();
            messageSyncSendAbility.handle(context,
                    MessageSyncSendAbilityParam.builder().abilityTarget(CampaignGroupStatusTransitEvent.of(stateContext)).build());
        }

        // 发送子主订单MetaQ消息
        if (CollectionUtils.isEmpty(processWorkflowParam.getSalePlatformSaleGroupIds())) {
            campaignGroupMessageAsyncSendAbility.handle(context, CampaignGroupMessageAsyncSendAbilityParam.builder()
                    .abilityTarget(campaignGroupViewDTO).domainEvent(CampaignGroupEventEnum.BOOST_OR_GIVE_ORDER.name()).build());
        }
    }

    protected void sendCampaignGroupOrderMsgEvent(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, List<Long> saleGroupIds) {
        Map<String, String> properties = Maps.newHashMap();
        properties.put(DomainMessageSettingKeyEnum.SALE_GROUPS.getKey(), CollectionUtil.join(saleGroupIds, Constant.CHAR_SPLIT_KEY_DOT));
        campaignGroupMessageAsyncSendAbility.handle(context, CampaignGroupMessageAsyncSendAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO).domainEvent(CampaignGroupEventEnum.ORDER_NOTICE_MSG.name()).properties(properties).build());
//        bizCampaignGroupProcessAbility.sendCampaignGroupOrderMsgEvent(context, campaignGroupViewDTO, DomainMessageTypeEnum.SUB_CAMPAIGN_GROUP, CampaignGroupEventEnum.ORDER_NOTICE_MSG.name(), properties);
    }

    /**
     * 更新订单初始化订单分组
     * for 主订单和自助子订单
     */
    protected void initSaleGroupInfoForUpdate(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO,
                                            CampaignGroupViewDTO dbCampaignGroupViewDTO,
                                            List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupList) {
        Map<Long, ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupMap = resourcePackageSaleGroupList
                .stream().collect(Collectors.toMap(ResourcePackageSaleGroupViewDTO::getId, Function.identity(), (v1, v2) -> v1));

        List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList();
        List<SaleGroupInfoViewDTO> dbSaleGroupInfoViewDTOList = Optional.ofNullable(dbCampaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList()).orElse(Lists.newArrayList());
        // diff
        SaleGroupDiffResultViewDTO saleGroupDiffResult = saleGroupDiffForUpdateCampaignGroupAbility.handle(context, SaleGroupDiffAbilityParam.builder()
                .abilityTargets(saleGroupInfoViewDTOList).dbSaleGroupInfoViewDTOList(dbSaleGroupInfoViewDTOList)
                .resourcePackageSaleGroupList(resourcePackageSaleGroupList).build());
        // 以DB分组为target
        if (CollectionUtils.isNotEmpty(saleGroupDiffResult.getDeleteSaleGroupIds())) {
            saleGroupInitForDeleteAbility.handle(context, SaleGroupInitAbilityParam.builder()
                    .abilityTargets(dbSaleGroupInfoViewDTOList).operateSaleGroupIds(saleGroupDiffResult.getDeleteSaleGroupIds()).build());
        }
        if (CollectionUtils.isNotEmpty(saleGroupDiffResult.getAddSaleGroupIds())) {
            dbSaleGroupInfoViewDTOList.addAll(saleGroupDiffResult.getAddSaleGroupIds().stream().map(saleGroupId-> {
                SaleGroupInfoViewDTO saleGroupInfoViewDTO = new SaleGroupInfoViewDTO();
                saleGroupInfoViewDTO.setSaleGroupId(saleGroupId);
                return saleGroupInfoViewDTO;
            }).collect(Collectors.toList()));
            saleGroupInitForAddAbility.handle(context, SaleGroupInitAbilityParam.builder()
                    .abilityTargets(dbSaleGroupInfoViewDTOList).resourcePackageSaleGroupMap(resourcePackageSaleGroupMap)
                    .operateSaleGroupIds(saleGroupDiffResult.getAddSaleGroupIds()).saleGroupSourceEnum(BrandSaleGroupSourceEnum.SALE_PLATFORM).build());
        }
        if (CollectionUtils.isNotEmpty(saleGroupDiffResult.getUpdateSaleGroupIds())) {
            saleGroupInitForUpdateAbility.handle(context, SaleGroupInitAbilityParam.builder()
                    .abilityTargets(dbSaleGroupInfoViewDTOList).resourcePackageSaleGroupMap(resourcePackageSaleGroupMap)
                    .operateSaleGroupIds(saleGroupDiffResult.getUpdateSaleGroupIds()).saleGroupSourceEnum(BrandSaleGroupSourceEnum.SALE_PLATFORM).build());
        }
        campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().setSaleGroupInfoViewDTOList(dbSaleGroupInfoViewDTOList);
    }
}