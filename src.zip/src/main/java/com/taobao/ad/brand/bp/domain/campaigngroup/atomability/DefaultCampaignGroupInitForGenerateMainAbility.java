package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.customer.CampaignGroupCustomerViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSourceEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupInitForGenerateMainAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupGenerateMainAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultCampaignGroupInitForGenerateMainAbility implements ICampaignGroupInitForGenerateMainAbility {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupGenerateMainAbilityParam abilityParam) {
        // 子订单
        CampaignGroupViewDTO mainCampaignGroupViewDTO = abilityParam.getAbilityTarget();
        // 从子订单复制
        CampaignGroupViewDTO subCampaignGroupViewDTO = abilityParam.getSubCampaignGroup();
        // 初始化基础信息
        initMainCampaignGroupBaseInfoForGenerate(serviceContext, subCampaignGroupViewDTO, mainCampaignGroupViewDTO);
        // 初始化分组信息
        initMainSaleGroupForGenerate(serviceContext, subCampaignGroupViewDTO, mainCampaignGroupViewDTO);
        // 重新设置客户信息
        initMainCustomerInfoForGenerate(serviceContext, subCampaignGroupViewDTO, mainCampaignGroupViewDTO);
        return null;
    }

    private void initMainCustomerInfoForGenerate(ServiceContext context, CampaignGroupViewDTO subCampaignGroupViewDTO, CampaignGroupViewDTO mainCampaignGroupViewDTO) {
        CampaignGroupCustomerViewDTO customerViewDTO = new CampaignGroupCustomerViewDTO();
        customerViewDTO.setCustomerMemberId(subCampaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getCustomerMemberId());
        customerViewDTO.setContractMemberType(subCampaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getContractMemberType());
        customerViewDTO.setCustomerPriority(subCampaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getCustomerPriority());
        mainCampaignGroupViewDTO.setCampaignGroupCustomerViewDTO(customerViewDTO);
    }

    private void initMainSaleGroupForGenerate(ServiceContext context, CampaignGroupViewDTO subCampaignGroupViewDTO, CampaignGroupViewDTO mainCampaignGroupViewDTO) {
        if (mainCampaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO() == null || CollectionUtils.isEmpty(mainCampaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList())) {
            return;
        }
        mainCampaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().forEach(saleGroupInfoViewDTO -> {
            saleGroupInfoViewDTO.setId(null);
            saleGroupInfoViewDTO.setCampaignGroupId(null);
        });
    }

    private void initMainCampaignGroupBaseInfoForGenerate(ServiceContext context, CampaignGroupViewDTO subCampaignGroupViewDTO, CampaignGroupViewDTO mainCampaignGroupViewDTO) {
        // 设置ID
        if (subCampaignGroupViewDTO.getParentId() != null && subCampaignGroupViewDTO.getParentId() != 0L) {
            mainCampaignGroupViewDTO.setId(subCampaignGroupViewDTO.getParentId());
        }
        if (BrandCampaignGroupSourceEnum.SLIM_ORDER.getCode().equals(subCampaignGroupViewDTO.getSource())
                && BrandCampaignGroupStatusEnum.DRAFT.getCode().equals(subCampaignGroupViewDTO.getStatus())) {
            mainCampaignGroupViewDTO.setStatus(BrandCampaignGroupStatusEnum.EDITED.getCode());
        }
        // 层级
        mainCampaignGroupViewDTO.setCampaignGroupLevel(BrandCampaignGroupLevelEnum.LEVEL_ONE.getCode());
        mainCampaignGroupViewDTO.setParentId(0L);

        // 业务场景
        mainCampaignGroupViewDTO.setSceneId(ServiceContextUtil.getSceneId(BizCodeEnum.BRANDONEBP.getBizCode()));

        // 清空不需要的属性
        mainCampaignGroupViewDTO.setGmtCreate(null);
        mainCampaignGroupViewDTO.setGmtModified(null);
        mainCampaignGroupViewDTO.setGiveStatus(null);
        mainCampaignGroupViewDTO.setBoostStatus(null);

    }
}
