package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleGroupSourceEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.salegroup.SaleGroupDiffResultViewDTO;
import com.taobao.ad.brand.bp.common.constant.campaigngroup.CampaignGroupConstant;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupDiffForNoticeSaleGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupDiffAbilityParam;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 子订单默认实现
 */
@Component
@BusinessAbility
public class DefaultSaleGroupDiffForNoticeSaleGroupAbility implements ISaleGroupDiffForNoticeSaleGroupAbility {

    @Override
    public SaleGroupDiffResultViewDTO handle(ServiceContext serviceContext, SaleGroupDiffAbilityParam abilityParam) {
        List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList = abilityParam.getAbilityTargets();
        List<SaleGroupInfoViewDTO> dbSaleGroupList = abilityParam.getDbSaleGroupInfoViewDTOList();
        CampaignGroupViewDTO subCampaignGroup = abilityParam.getCampaignGroupViewDTO();
        boolean canUpdateSalePlatformSaleGroup = CampaignGroupConstant.validUpdateSubSaleCampaignGroupStatusList.contains(subCampaignGroup.getStatus());

        // 新增 or 更新的分组
        List<Long> addSaleGroupIds = Lists.newArrayList();
        List<Long> updateSaleGroupIds = Lists.newArrayList();
        Map<Long, SaleGroupInfoViewDTO> dbSubSaleGroupInfoMap = dbSaleGroupList.stream().collect(Collectors.toMap(SaleGroupInfoViewDTO::getSaleGroupId, t -> t, (a1, a2) -> a1));
        saleGroupInfoViewDTOList.forEach(saleGroupInfoViewDTO -> {
            // 不支持更新售卖中心分组
            if (BrandSaleGroupSourceEnum.SALE_PLATFORM.getCode().equals(saleGroupInfoViewDTO.getSource())) {
                return;
            }
            if (!dbSubSaleGroupInfoMap.containsKey(saleGroupInfoViewDTO.getSaleGroupId())) {
                addSaleGroupIds.add(saleGroupInfoViewDTO.getSaleGroupId());
            } else {
                updateSaleGroupIds.add(saleGroupInfoViewDTO.getSaleGroupId());
            }
        });

        // 删除的分组（删除时有可能删除来自售卖中心的分组）
        List<Long> addOrUpdateSaleGroupIds = saleGroupInfoViewDTOList.stream().map(SaleGroupInfoViewDTO::getSaleGroupId).collect(Collectors.toList());
        List<Long> deleteSaleGroupIds = dbSaleGroupList.stream().filter(dbSaleGroup -> {
            if (BrandSaleGroupSourceEnum.SALE_PLATFORM.getCode().equals(dbSaleGroup.getSource())) {
                if (!canUpdateSalePlatformSaleGroup) {
                    return false;
                }
            }
            return !addOrUpdateSaleGroupIds.contains(dbSaleGroup.getSaleGroupId());
        }).map(SaleGroupInfoViewDTO::getSaleGroupId).collect(Collectors.toList());

        // 构建返回结果
        SaleGroupDiffResultViewDTO diffResultViewDTO = new SaleGroupDiffResultViewDTO();
        diffResultViewDTO.setAddSaleGroupIds(addSaleGroupIds);
        diffResultViewDTO.setUpdateSaleGroupIds(updateSaleGroupIds);
        diffResultViewDTO.setDeleteSaleGroupIds(deleteSaleGroupIds);

        return diffResultViewDTO;
    }
}
