package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupBoostGiveApplyInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupSubmitForApplySaleGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupApplyInfoAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultSaleGroupSubmitForApplySaleGroupAbility implements ISaleGroupSubmitForApplySaleGroupAbility {

    private final ResourcePackageRepository resourcePackageRepository;
    @Override
    public Void handle(ServiceContext serviceContext, SaleGroupApplyInfoAbilityParam abilityParam) {
        SaleGroupBoostGiveApplyInfoViewDTO applyInfoViewDTO = abilityParam.getAbilityTarget();
        SaleGroupInfoViewDTO mainSaleGroupInfoViewDTO = abilityParam.getMainSaleGroupInfoViewDTO();

        Long saleGroupId = resourcePackageRepository.applySaleGroup(serviceContext, applyInfoViewDTO, mainSaleGroupInfoViewDTO.getSaleGroupId());
        AssertUtil.notNull(saleGroupId, BrandOneBPBaseErrorCode.PARAM_BREAK_RULE, "分组保存失败");
        applyInfoViewDTO.setSaleGroupId(saleGroupId);
        return null;
    }
}
