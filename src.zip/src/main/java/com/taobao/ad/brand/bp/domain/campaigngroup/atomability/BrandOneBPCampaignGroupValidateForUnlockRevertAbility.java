package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.unlock.UnlockApplyInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupProcessStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.taobao.ad.brand.bp.common.constant.campaigngroup.CampaignGroupConstant;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupUnlockRevertAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_BREAK_RULE;

@Component
@BusinessAbility
public class BrandOneBPCampaignGroupValidateForUnlockRevertAbility
        extends DefaultCampaignGroupValidateForUnlockRevertAbility implements BrandOneBPAtomAbilityRouter {

    @Resource
    private CampaignGroupRepository campaignGroupRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupUnlockRevertAbilityParam abilityParam) {
        CampaignGroupViewDTO mainCampaignGroup = abilityParam.getAbilityTarget();
        AssertUtil.assertTrue(BrandCampaignGroupStatusEnum.UNLOCKED.getCode().equals(mainCampaignGroup.getStatus()),
                PARAM_BREAK_RULE,
                String.format("订单状态(%s)不支持该操作", BrandCampaignGroupStatusEnum.getByCode(mainCampaignGroup.getStatus()).getDesc()));
        // 校验子订单
        List<CampaignGroupViewDTO> subCampaignGroupList = abilityParam.getSubCampaignGroupList();
        if (CollectionUtils.isEmpty(subCampaignGroupList)) {
            subCampaignGroupList = campaignGroupRepository.findSubCampaignGroupList(serviceContext, mainCampaignGroup.getId());
        }
        for (CampaignGroupViewDTO subCampaignGroup : subCampaignGroupList) {
            // 校验子订单状态
            AssertUtil.assertTrue(CampaignGroupConstant.validSubSaleCampaignGroupUnlockRevertStatusList.contains(subCampaignGroup.getStatus()),
                    PARAM_BREAK_RULE, "订单已进入改单流程，不支持该操作");
            // 校验是否存在审核中的申请改单流程
            UnlockApplyInfoViewDTO unlockApplyInfoViewDTO = subCampaignGroup.getCampaignGroupUnlockViewDTO().getUnlockApplyInfoViewDTO();
            AssertUtil.assertTrue(unlockApplyInfoViewDTO == null || !BrandCampaignGroupProcessStatusEnum.APPROVE_ING.getCode().equals(unlockApplyInfoViewDTO.getStatus()),
                    PARAM_BREAK_RULE, "订单已进入改单流程，不支持该操作");
        }

        return null;
    }
}
