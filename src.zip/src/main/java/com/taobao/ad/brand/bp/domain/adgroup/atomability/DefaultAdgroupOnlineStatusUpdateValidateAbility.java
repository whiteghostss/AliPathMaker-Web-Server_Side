package com.taobao.ad.brand.bp.domain.adgroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupBottomTypeEnum;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupOnlineStatusEnum;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupTargetTypeEnum;
import com.alibaba.fastjson.JSON;
import com.taobao.ad.brand.bp.common.helper.adgroup.BizAdgroupToolsHelper;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupOnlineStatusUpdateValidateAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupOnlineValidateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultAdgroupOnlineStatusUpdateValidateAbility implements IAdgroupOnlineStatusUpdateValidateAbility {

    /**
     * 跨site的计划， 需要验证每个子计划至少有一个审核通过的创意，才可以上下线
     * @param serviceContext
     * @param abilityParam
     * @return
     */
    @Override
    public Void handle(ServiceContext serviceContext, AdgroupOnlineValidateAbilityParam abilityParam) {
        List<AdgroupViewDTO> adgroupList = abilityParam.getAbilityTargets();
        AssertUtil.notEmpty(adgroupList, "单元不存在");
        //草稿状态的单元
        List<Long> draftAdgroupIdList = adgroupList.stream()
                .filter(adgroup -> BrandAdgroupOnlineStatusEnum.DRAFT.getCode().equals(adgroup.getOnlineStatus()))
                .map(AdgroupViewDTO::getId).collect(Collectors.toList());
        AssertUtil.assertTrue(CollectionUtils.isEmpty(draftAdgroupIdList),
                String.format("草稿状态单元不允许上下线,ids=%s", JSON.toJSONString(draftAdgroupIdList)));

        //这里需要验证精准的单元
        List<AdgroupViewDTO> programAdgroupViewDTOList = adgroupList.stream()
                .filter(item -> BrandAdgroupTargetTypeEnum.PROGRAM.getCode().equals(item.getTargetType()))
                .collect(Collectors.toList());
        //验证优选单元必须先成为正式
        if (CollectionUtils.isNotEmpty(programAdgroupViewDTOList)) {
            List<AdgroupViewDTO> youxuanAdgroupList=  programAdgroupViewDTOList.stream()
                    .filter(adgroupViewDTO -> BrandAdgroupBottomTypeEnum.N_REACH.getCode().equals(adgroupViewDTO.getBottomType()))
                    .collect(Collectors.toList());
            AssertUtil.assertTrue(CollectionUtils.isEmpty(youxuanAdgroupList),"%s是优选单元，不允许上下线", BizAdgroupToolsHelper.adgroupMessage(youxuanAdgroupList));
        }
        return null;

    }
}
