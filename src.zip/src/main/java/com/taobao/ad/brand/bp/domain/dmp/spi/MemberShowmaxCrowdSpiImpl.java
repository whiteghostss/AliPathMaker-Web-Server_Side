package com.taobao.ad.brand.bp.domain.dmp.spi;

//@AbilitySpiInstance(bizCode = ShowmaxCrowdSpi.SHOWMAX_CROWD_MEMBER, name = "MemberShowmaxCrowd", desc = "入会实时showmax人群能力SPI")
public class MemberShowmaxCrowdSpiImpl extends DefaultShowmaxCrowdSpiImpl{
//    @Resource
//    private CrowdRepository crowdRepository;
//
//    /**
//     * 查询标签
//     */
//    @Override
//    public List<CommonViewDTO> queryShowmaxCrowdTagList(ServiceContext serviceContext, Long memberId, List<Long> brandIds){
//        List<CrowdViewDTO> crowdViewDTOList = crowdRepository.findRecommendCrowd(serviceContext,serviceContext.getMemberId(), RecommendCrowdTypeEnum.MEMBER.getCode(), null,  StringUtils.join(brandIds, ","));
//        return crowdViewDTOList.stream().map(crowdViewDTO -> {
//            CommonViewDTO commonViewDTO = new CommonViewDTO();
//            commonViewDTO.setId(crowdViewDTO.getCrowdId());
//            commonViewDTO.setName(crowdViewDTO.getCrowdName());
//            return commonViewDTO;
//        }).collect(Collectors.toList());
//    }

}
