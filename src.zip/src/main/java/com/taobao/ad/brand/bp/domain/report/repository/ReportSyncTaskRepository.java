package com.taobao.ad.brand.bp.domain.report.repository;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.taobao.ad.brand.bp.client.dto.report.ReportTaskViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.query.ReportTaskQueryViewDTO;

import java.util.List;

/**
 * @author yuncheng.lyc
 */
public interface ReportSyncTaskRepository {
    /**
     * 查询异步任务列表
     * @param context
     * @param queryViewDTO
     * @return
     */
    List<ReportTaskViewDTO> queryList(ServiceContext context, ReportTaskQueryViewDTO queryViewDTO);

    /**
     * 查询异步任务列表
     * @param context
     * @param queryViewDTO
     * @return
     */
    MultiResponse<ReportTaskViewDTO> queryListWithPage(ServiceContext context, ReportTaskQueryViewDTO queryViewDTO);

    /**
     * 获取单个异步任务信息
     * @param context
     * @param queryViewDTO
     * @return
     */
    ReportTaskViewDTO get(ServiceContext context, ReportTaskQueryViewDTO queryViewDTO);

    /**
     * 添加异步任务
     * @param context
     * @param taskViewDTO
     * @return
     */
    Long add(ServiceContext context, ReportTaskViewDTO taskViewDTO);

    /**
     * 修改异步任务
     * @param context
     * @param taskViewDTO
     * @return
     */
    Long modify(ServiceContext context, ReportTaskViewDTO taskViewDTO);

    /**
     * 删除异步任务
     * @param context
     * @param queryViewDTO
     * @return
     */
    Long delete(ServiceContext context, ReportTaskQueryViewDTO queryViewDTO);

    /**
     * 修改异步任务状态
     * @param context
     * @param taskViewDTO
     * @return
     */
    Long modifyStatus(ServiceContext context, ReportTaskViewDTO taskViewDTO);

    /**
     * 异步任务运行失败
     * @param context
     * @param taskViewDTO
     * @return
     */
    Long runFail(ServiceContext context, ReportTaskViewDTO taskViewDTO);

    /**
     * 异步任务运行失败
     * @param context
     * @param taskViewDTO
     * @return
     */
    Long runSucceed(ServiceContext context, ReportTaskViewDTO taskViewDTO);
}
