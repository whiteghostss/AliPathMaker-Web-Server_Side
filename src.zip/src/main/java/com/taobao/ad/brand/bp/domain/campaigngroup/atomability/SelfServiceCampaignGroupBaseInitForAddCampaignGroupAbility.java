package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupBoostStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupGiveStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupTypeEnum;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupBaseInitForAddCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupBaseAbilityParam;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

@Component
@BusinessAbility
public class SelfServiceCampaignGroupBaseInitForAddCampaignGroupAbility
        implements ICampaignGroupBaseInitForAddCampaignGroupAbility, SelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupBaseAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        campaignGroupViewDTO.setMemberId(serviceContext.getMemberId());
        campaignGroupViewDTO.setName("百灵自助订单" + BrandDateUtil.date2String(new Date(), BrandDateUtil.DATE_FORMAT_YYYYMMDDHHMMSS));
        campaignGroupViewDTO.setType(BrandCampaignGroupTypeEnum.SELF.getCode());
        if (campaignGroupViewDTO.getStatus() == null) {
            campaignGroupViewDTO.setStatus(BrandCampaignGroupStatusEnum.EDITED.getCode());
        }
        campaignGroupViewDTO.setParentId(0L);
        campaignGroupViewDTO.setCampaignGroupLevel(BrandCampaignGroupLevelEnum.LEVEL_TWO.getCode());
        campaignGroupViewDTO.setSceneId(ServiceContextUtil.getSceneId(serviceContext.getBizCode()));
        campaignGroupViewDTO.setBoostStatus(BrandCampaignGroupBoostStatusEnum.NON_BOOST.getCode());
        campaignGroupViewDTO.setGiveStatus(BrandCampaignGroupGiveStatusEnum.NON_GIVE.getCode());

        // cartItem
        List<CampaignViewDTO> campaignViewDTOList = abilityParam.getCampaignViewDTOList();
        campaignGroupViewDTO.setStartTime(BrandDateUtil.getDateMidnight(BizCampaignGroupToolsHelper.getCampaignMinTime(campaignViewDTOList)));
        campaignGroupViewDTO.setEndTime(BrandDateUtil.getDateFullMidnight(BizCampaignGroupToolsHelper.getCampaignMaxTime(campaignViewDTOList)));
        campaignGroupViewDTO.setBudget(BizCampaignGroupToolsHelper.getBuyCampaignBudgetTotal(campaignViewDTOList));

        return null;
    }
}
