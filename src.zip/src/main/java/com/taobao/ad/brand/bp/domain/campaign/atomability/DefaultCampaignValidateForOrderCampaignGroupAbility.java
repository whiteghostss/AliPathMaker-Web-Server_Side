package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleGroupSourceEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.constant.campaigngroup.CampaignGroupConstant;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.CurrencyUtil;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignValidateForOrderCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignValidateForOrderCampaignGroupAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultCampaignValidateForOrderCampaignGroupAbility  implements ICampaignValidateForOrderCampaignGroupAbility {


    @Override
    public Void handle(ServiceContext serviceContext, CampaignValidateForOrderCampaignGroupAbilityParam abilityParam) {
        List<CampaignViewDTO> campaignViewDTOList = abilityParam.getAbilityTargets();
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupList = abilityParam.getResourcePackageSaleGroupList();
        Map<Long, List<CampaignViewDTO>> saleGroupCampaignMap = campaignViewDTOList.stream().collect(
                Collectors.groupingBy(v -> v.getCampaignSaleViewDTO().getSaleGroupId()));
        // 1. 计划不能为空
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(campaignViewDTOList), BIZ_BREAK_RULE_ERROR, "所选分组不存在有效的计划");
        List<String> noCampaignSaleGroupNameList = resourcePackageSaleGroupList.stream()
                .filter(resourceSaleGroupViewDTO -> !saleGroupCampaignMap.containsKey(resourceSaleGroupViewDTO.getId()))
                .map(ResourcePackageSaleGroupViewDTO::getName).collect(Collectors.toList());
        AssertUtil.assertTrue(CollectionUtils.isEmpty(noCampaignSaleGroupNameList),
                String.format("分组(%s)下无有效计划", StringUtils.join(noCampaignSaleGroupNameList, ",")));

        // 2. 校验计划状态
        Long campaignTotalBudget = 0L;
        for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
            AssertUtil.assertTrue(CampaignGroupConstant.validCampaignStatusOnOrder.contains(campaignViewDTO.getStatus()), BIZ_BREAK_RULE_ERROR,
                    String.format("计划(%s)的状态(%s)不支持下单操作", campaignViewDTO.getId(), BrandCampaignStatusEnum.getByCode(campaignViewDTO.getStatus()).getDesc()));
            if (BrandSaleTypeEnum.BUY.getCode().equals(campaignViewDTO.getCampaignSaleViewDTO().getSaleType())) {
                campaignTotalBudget += campaignViewDTO.getCampaignBudgetViewDTO().getDiscountTotalMoney();
            }
        }
        // 3. 校验计划金额
        // 3-1. 计划金额与订单金额的一致性
        boolean hasSalesSaleGroup = resourcePackageSaleGroupList.stream().anyMatch(t -> BrandSaleGroupSourceEnum.SALE_PLATFORM.getCode().equals(t.getSource()));
        if (hasSalesSaleGroup) {
            AssertUtil.assertTrue(campaignGroupViewDTO.getBudget().equals(campaignTotalBudget), BIZ_BREAK_RULE_ERROR,
                    String.format("订单金额(%s元)与下单计划总金额(%s元)不一致", CurrencyUtil.f2y(campaignGroupViewDTO.getBudget()), CurrencyUtil.f2y(campaignTotalBudget)));
        }
        // 3-2. 计划金额与分组金额的一致性
        for (ResourcePackageSaleGroupViewDTO resourceSaleGroupViewDTO : resourcePackageSaleGroupList) {
            // 校验分组下是否有有效的计划
            List<CampaignViewDTO> saleGroupCampaignViewDTOList = saleGroupCampaignMap.get(resourceSaleGroupViewDTO.getId());
            // 校验分组预算和计划预算
            long discountTotalMoney = saleGroupCampaignViewDTOList.stream().filter(v -> v.getCampaignBudgetViewDTO().getDiscountTotalMoney() != null).mapToLong(
                    v -> v.getCampaignBudgetViewDTO().getDiscountTotalMoney()).sum();
            AssertUtil.assertTrue(resourceSaleGroupViewDTO.getBudget().equals(discountTotalMoney), BrandOneBPBaseErrorCode.PARAM_REQUIRED,
                    String.format("分组(%s)金额与计划总金额不一致", resourceSaleGroupViewDTO.getName()));
        }

        return null;
    }
}
