package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.customer.CampaignGroupCustomerViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.order.CampaignGroupOrderViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CustomerRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupOrderInitForAddCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupOrderAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCampaignGroupOrderInitForAddCampaignGroupAbility
        implements ICampaignGroupOrderInitForAddCampaignGroupAbility, SelfServiceAtomAbilityRouter {

    private final CustomerRepository customerRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupOrderAbilityParam abilityParam) {
        CampaignGroupOrderViewDTO campaignGroupOrderViewDTO = Optional.ofNullable(abilityParam.getAbilityTarget()).orElse(new CampaignGroupOrderViewDTO());
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        // 1. 设置新老客标识信息
        Long customerMemberId = Optional.ofNullable(campaignGroupViewDTO.getCampaignGroupCustomerViewDTO())
                .map(CampaignGroupCustomerViewDTO::getCustomerMemberId).orElse(serviceContext.getMemberId());
        Integer customerType = customerRepository.getCustomerType(customerMemberId);
        campaignGroupOrderViewDTO.setCustomerOrderType(customerType);
        // 是否支持自动下单
        campaignGroupOrderViewDTO.setCanAutoOrder(BrandBoolEnum.BRAND_TRUE.getCode());

        campaignGroupViewDTO.setCampaignGroupOrderViewDTO(campaignGroupOrderViewDTO);
        return null;
    }
}
