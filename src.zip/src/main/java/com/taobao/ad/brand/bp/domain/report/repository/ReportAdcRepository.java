package com.taobao.ad.brand.bp.domain.report.repository;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.dto.report.ReportDimensionConfigViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportFunctionConfigViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportMetricsConfigViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.query.ReportQueryViewDTO;

import java.util.List;
import java.util.Map;

/**
 * @author yuncheng.lyc
 */
public interface ReportAdcRepository {

    /**
     * 获取指定functionCode配置节点信息
     *
     * @param context
     * @param queryViewDTO
     * @return
     */
    ReportFunctionConfigViewDTO findFunctionConfig(ServiceContext context, ReportQueryViewDTO queryViewDTO);

    /**
     * 获取指定functionCode节点下维度配置节点
     * 1、返回functionCode节点下dimensionCode的dimension节点
     * 2、返回functionCode节点下dimensionCodes的dimension节点
     * @param context
     * @param queryViewDTO
     * @return
     */
    Map<String, ReportDimensionConfigViewDTO> findDimensionConfigMap(ServiceContext context, ReportQueryViewDTO queryViewDTO);

    /**
     * 获取指定functionCode节点下dimensionCode配置信息
     * @param context
     * @param queryViewDTO
     * @return
     */
    ReportDimensionConfigViewDTO findDimensionConfig(ServiceContext context, ReportQueryViewDTO queryViewDTO);

    /**
     * 获取指定functionCode下的dimensionCode下的指标信息
     * 1、返回functionCode节点下dimensionCode的指标信息
     * 2、返回functionCode节点下dimensionCodes的指标信息
     * 3、返回functionCode节点下所有的指标信息
     * @param context
     * @param queryViewDTO
     * @return
     */
    Map<String, List<ReportMetricsConfigViewDTO>> findMetricsConfigMap(ServiceContext context, ReportQueryViewDTO queryViewDTO);

    /**
     * 获取指定functionCode下的dimensionCode下的指标信息
     * @param context
     * @param queryViewDTO
     * @return
     */
    List<ReportMetricsConfigViewDTO> findMetricsConfig(ServiceContext context, ReportQueryViewDTO queryViewDTO);

    /**
     * 获取adc上配置的adr的api地址
     * @param context
     * @param queryViewDTO
     * @return
     */
    String findAdcAdrApiConfig(ServiceContext context, ReportQueryViewDTO queryViewDTO);
}
