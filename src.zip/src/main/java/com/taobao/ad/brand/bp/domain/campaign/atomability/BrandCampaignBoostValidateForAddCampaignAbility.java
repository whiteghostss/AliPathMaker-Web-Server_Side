package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.boost.CampaignBoostViewDTO;
import com.alibaba.ad.brand.dto.campaign.guarantee.CampaignGuaranteeViewDTO;
import com.alibaba.ad.brand.dto.campaign.price.DayPriceViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignUnionControlFlowEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.alibaba.ad.nb.ssp.constant.common.CrossSceneEnum;
import com.alibaba.ad.nb.ssp.constant.common.MediaScopeEnum;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignBoostValidateForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBoostAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Optional;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_ILLEGAL;
import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_REQUIRED;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandCampaignBoostValidateForAddCampaignAbility implements ICampaignBoostValidateForAddCampaignAbility, BrandAtomAbilityRouter {

    private final CampaignRepository campaignRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignBoostAbilityParam abilityParam) {
        CampaignBoostViewDTO campaignBoostViewDTO = abilityParam.getAbilityTarget();
        ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO = abilityParam.getResourcePackageSaleGroupViewDTO();
        ResourcePackageProductViewDTO packageProductViewDTO = abilityParam.getResourcePackageProductViewDTO();
        ProductViewDTO productViewDTO = abilityParam.getProductViewDTO();
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();
        AssertUtil.notNull(packageSaleGroupViewDTO, PARAM_REQUIRED, "售卖分组信息不能为空");
        AssertUtil.notNull(packageProductViewDTO, PARAM_REQUIRED, "资源产品信息不能为空");
        AssertUtil.notNull(productViewDTO, PARAM_REQUIRED, "产品信息不能为空");
        AssertUtil.notNull(campaignViewDTO, PARAM_REQUIRED, "计划信息不能为空");
        if (!BrandSaleTypeEnum.BOOST.getCode().equals(packageSaleGroupViewDTO.getSaleType())) {
            return null;
        }
        Integer castType = BizCampaignToolsHelper.getCampaignCastType(campaignViewDTO, packageProductViewDTO);
        // 【计划id】1、主计划id必填；2、补量计划所属分组关联的主分组id，需与关联主计划的分组id保持一致
        AssertUtil.notNull(campaignBoostViewDTO, PARAM_REQUIRED, "补量计划信息不能为空");
        AssertUtil.notNull(campaignBoostViewDTO.getSourceCampaignId(), PARAM_REQUIRED, "补量计划下主计划ID必填");
        CampaignViewDTO sourceCampaign = campaignRepository.getCampaignById(serviceContext, campaignBoostViewDTO.getSourceCampaignId());
        AssertUtil.assertTrue(packageSaleGroupViewDTO.getMainGroupId().equals(sourceCampaign.getCampaignSaleViewDTO().getSaleGroupId()), PARAM_REQUIRED, "补量计划关联的主分组id，需与关联主计划的分组id保持一致");
        // 【联合控量】1、主计划是三环&PDB投放，不能联合控量；2、主\补计划是拆分价格波段的，不能联合控量
        Integer isUnionControl = Optional.ofNullable(campaignViewDTO.getCampaignGuaranteeViewDTO()).map(CampaignGuaranteeViewDTO::getIsUnionControlFlow).orElse(null);
        if (BrandCampaignUnionControlFlowEnum.UNION.getCode().equals(isUnionControl)) {
            AssertUtil.assertTrue(!BizCampaignToolsHelper.isThreePDB(productViewDTO.getMediaScope(),castType), "主计划是三环PDB投放，不能联合控量");
            if (CollectionUtils.isNotEmpty(sourceCampaign.getCampaignPriceViewDTO().getPublishPriceInfoList())) {
                long distinctPriceCount = sourceCampaign.getCampaignPriceViewDTO().getPublishPriceInfoList().stream().map(DayPriceViewDTO::getPrice).distinct().count();
                AssertUtil.assertTrue(distinctPriceCount <= 1, PARAM_ILLEGAL, "主计划拆分价格波段，不能联合控量");
            }
            if (CollectionUtils.isNotEmpty(packageProductViewDTO.getBandPriceList())) {
                long distinctPriceCount = packageProductViewDTO.getBandPriceList().stream().map(ResourcePackageProductPriceViewDTO::getPrice).distinct().count();
                AssertUtil.assertTrue(distinctPriceCount <= 1, PARAM_ILLEGAL, "补量计划拆分价格波段，不能联合控量");
            }
            AssertUtil.assertTrue(Objects.nonNull(packageSaleGroupViewDTO.getSaleProductLine())
                    && packageSaleGroupViewDTO.getSaleProductLine().equals(sourceCampaign.getCampaignSaleViewDTO().getSaleProductLine()),"主补售卖产品线不一致，不能联合控量");
            AssertUtil.assertTrue(!(MediaScopeEnum.CROSS_SCOPE.getCode().equals(sourceCampaign.getCampaignResourceViewDTO().getSspMediaScope())
                    && Objects.equals(CrossSceneEnum.CROSS_OPAQUE_SCENE.getValue(), sourceCampaign.getCampaignResourceViewDTO().getSspCrossScene())), "全域通黑盒不支持联合控量");
        }
        return null;
    }
}
