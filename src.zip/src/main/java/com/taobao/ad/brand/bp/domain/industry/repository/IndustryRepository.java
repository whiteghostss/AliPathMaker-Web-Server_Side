package com.taobao.ad.brand.bp.domain.industry.repository;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.dto.industry.IndustryViewDTO;

public interface IndustryRepository {

    IndustryViewDTO getIndustryByShopId(ServiceContext serviceContext, Long shopId);
}
