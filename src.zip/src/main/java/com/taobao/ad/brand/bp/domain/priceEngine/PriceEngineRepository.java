package com.taobao.ad.brand.bp.domain.priceEngine;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;

import com.taobao.ad.brand.bp.client.dto.campaign.PriceEnginePublishPriceViewDTO;

import java.util.Date;
import java.util.List;


public interface PriceEngineRepository {
    /**
     * 获取ssp刊例价
     *
     * @param serviceContext
     * @param campaignViewDTO
     * @return
     */
    List<PriceEnginePublishPriceViewDTO> getPublishPrice(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO,
        CampaignGroupViewDTO campaignGroup);


    List<PriceEnginePublishPriceViewDTO> getAdditionPublishPrice(Long publicationProductId, Integer saleUnit, List<Integer> resourceTypeValueList, Date startDate, Date endDate);


}
