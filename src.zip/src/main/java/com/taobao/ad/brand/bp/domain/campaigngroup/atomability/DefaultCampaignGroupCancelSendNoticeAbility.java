package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupProductCategoryEnum;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignDealMsgViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignMsgNoticeViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CrmAdvInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesProjectViewDTO;
import com.taobao.ad.brand.bp.client.dto.message.MessageViewDTO;
import com.taobao.ad.brand.bp.client.enums.message.MessageSendTypeEnum;
import com.taobao.ad.brand.bp.common.util.*;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CustomerRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.SalesProjectRepository;
import com.taobao.ad.brand.bp.domain.memeber.MemberRepository;
import com.taobao.ad.brand.bp.domain.message.MessageRepository;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupCancelSendNoticeAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupOrderSendNoticeAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupNoticeAbilityParam;
import org.springframework.cglib.beans.BeanMap;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
@BusinessAbility
public class DefaultCampaignGroupCancelSendNoticeAbility implements ICampaignGroupCancelSendNoticeAbility {

    @Resource
    private MemberRepository memberRepository;
    @Resource
    private MessageRepository messageRepository;

    /**
     * 订单自动撤单通知
     */
    private static final String CAMPAIGN_GROUP_CANCELLED_NOTICE = "vm/campaignGroupCancelledNotice.vm";

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupNoticeAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        MessageViewDTO messageViewDTO = new MessageViewDTO();
        String subject = String.format("【自助营销订单自动撤单通知】投放账号：%s  订单：%s",
                memberRepository.getMemberDisplayNameById(campaignGroupViewDTO.getMemberId()),
                campaignGroupViewDTO.getName());
        messageViewDTO.setMemberId(campaignGroupViewDTO.getMemberId());
        messageViewDTO.setSubject(subject);
        messageViewDTO.setContent(buildAutoCancelledMessageContent(serviceContext, campaignGroupViewDTO));
        messageViewDTO.setSendType(Lists.newArrayList(MessageSendTypeEnum.STATION_LETTER.getValue()));
        messageRepository.sendMessage(messageViewDTO);

        return null;
    }

    private String buildAutoCancelledMessageContent(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO) {
        CampaignMsgNoticeViewDTO campaignMsgNoticeViewDTO = new CampaignMsgNoticeViewDTO();
        campaignMsgNoticeViewDTO.setCampaignGroupId(campaignGroupViewDTO.getId());
        campaignMsgNoticeViewDTO.setCampaignGroupName(campaignGroupViewDTO.getName());
        BeanMap beanMap = BeanMap.create(campaignMsgNoticeViewDTO);
        return VelocityUtils.merge(CAMPAIGN_GROUP_CANCELLED_NOTICE, beanMap);
    }
}
