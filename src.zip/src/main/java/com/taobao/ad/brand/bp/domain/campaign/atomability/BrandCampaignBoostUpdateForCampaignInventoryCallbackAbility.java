package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.boost.CampaignBoostViewDTO;
import com.alibaba.ad.brand.dto.campaign.boost.InquiryInfoViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryLockViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.DayAmountViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandInquiryStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.alibaba.fastjson.JSONObject;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignInquiryOperateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignScheduleOperateTypeEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.inventory.ICampaignBoostUpdateForCampaignInventoryCallbackAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignInventoryCallbackAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandCampaignBoostUpdateForCampaignInventoryCallbackAbility implements
        ICampaignBoostUpdateForCampaignInventoryCallbackAbility, BrandAtomAbilityRouter {

    private final CampaignRepository campaignRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignInventoryCallbackAbilityParam abilityParam) {
        CampaignInquiryOperateViewDTO inventoryCallbackViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO campaignTreeViewDTO = abilityParam.getCampaignTreeViewDTO();
        AssertUtil.notNull(inventoryCallbackViewDTO,"库存回调参数不能为空");
        AssertUtil.notNull(campaignTreeViewDTO,"计划不能为空");
        //联合控量补量计划释量后需更新控量计划
        if (CampaignScheduleOperateTypeEnum.RELEASE_CALLBACK.isSelf(inventoryCallbackViewDTO.getOperateType())) {
            List<Long> budgetCampaignIds = Optional.ofNullable(campaignTreeViewDTO.getSubCampaignViewDTOList()).orElse(Lists.newArrayList())
                    .stream().filter(v -> v.getId().equals(inventoryCallbackViewDTO.getCampaignIdList().get(0)))
                    .filter(v -> BrandBoolEnum.BRAND_TRUE.getCode().equals(v.getCampaignGuaranteeViewDTO().getIsUnionControlFlow()))
                    .filter(v -> BrandSaleTypeEnum.BOOST.getCode().equals(v.getCampaignSaleViewDTO().getSaleType()))
                    .map(v -> v.getCampaignGuaranteeViewDTO().getBudgetCampaignId()).distinct().collect(Collectors.toList());

            this.resetParentUnionControlInfo(serviceContext, budgetCampaignIds);
        }
        return null;
    }

    /**
     * 联合控量合并补量计划排期
     * @param context           上下文
     * @param budgetCampaignIds 控量计划
     */
    private void resetParentUnionControlInfo(ServiceContext context, List<Long> budgetCampaignIds) {
        RogerLogger.info("resetParentUnionControlInfo {}", JSONObject.toJSONString(budgetCampaignIds));
        if (CollectionUtils.isEmpty(budgetCampaignIds)) {
            return;
        }
        CampaignQueryViewDTO query = CampaignQueryViewDTO.builder().campaignIds(budgetCampaignIds)
                .campaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode()).build();
        List<CampaignViewDTO> campaignViewDTOList = campaignRepository.queryCampaignList(context, query);
        if (CollectionUtils.isEmpty(campaignViewDTOList)) {
            RogerLogger.info("cant find resetParentUnionControlInfo  {}", JSONObject.toJSONString(budgetCampaignIds));
            return;
        }
        CampaignQueryViewDTO querySub = CampaignQueryViewDTO.builder().budgetCampaignIds(budgetCampaignIds)
                .campaignLevel(BrandCampaignLevelEnum.LEVEL_TWO_CAMPAIGN.getCode())
                .saleTypes(Lists.newArrayList(BrandSaleTypeEnum.BOOST.getCode()))
                .build();
        List<CampaignViewDTO> subList = campaignRepository.queryCampaignList(context, querySub);
        if (CollectionUtils.isEmpty(subList)) {
            RogerLogger.info("cant find resetSubUnionControlInfo  {}", JSONObject.toJSONString(budgetCampaignIds));
            return;
        }
        List<CampaignViewDTO> updateCampaignViewDTOList = Lists.newArrayList();
        for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
            List<InquiryInfoViewDTO> unionInquiryList = Lists.newArrayList();

            for (CampaignViewDTO subCampaignViewDTO : subList) {
                if (!campaignViewDTO.getId().equals(subCampaignViewDTO.getCampaignGuaranteeViewDTO().getBudgetCampaignId())) {
                    continue;
                }
                List<CampaignInquiryViewDTO> campaignInquiryViewDTOList = Optional.ofNullable(subCampaignViewDTO.getCampaignInquiryLockViewDTO())
                        .map(CampaignInquiryLockViewDTO::getCampaignInquiryViewDTOList).orElse(Lists.newArrayList());
                if (CollectionUtils.isEmpty(campaignInquiryViewDTOList)) {
                    continue;
                }
                InquiryInfoViewDTO inquiryInfoViewDTO = new InquiryInfoViewDTO();
                inquiryInfoViewDTO.setCampaignId(subCampaignViewDTO.getId());
                List<DayAmountViewDTO> dayAmountViewDTOS = Lists.newArrayList();
                for (CampaignInquiryViewDTO campaignInquiryViewDTO : campaignInquiryViewDTOList) {
                    if (BrandInquiryStatusEnum.SUCCESS.getCode().equals(campaignInquiryViewDTO.getStatus())) {
                        DayAmountViewDTO dayAmountViewDTO = new DayAmountViewDTO();
                        dayAmountViewDTO.setDay(campaignInquiryViewDTO.getDate());
                        dayAmountViewDTO.setAmount(campaignInquiryViewDTO.getBookAmount());
                        dayAmountViewDTOS.add(dayAmountViewDTO);
                    }
                }
                inquiryInfoViewDTO.setInquiryInfoList(dayAmountViewDTOS);
                if (CollectionUtils.isNotEmpty(dayAmountViewDTOS)) {
                    unionInquiryList.add(inquiryInfoViewDTO);
                }
            }
            CampaignBoostViewDTO campaignBoostViewDTO = campaignViewDTO.getCampaignBoostViewDTO();
            campaignBoostViewDTO.setUnionInquiryInfoList(unionInquiryList);

            CampaignViewDTO updateCampaignViewDTO = new CampaignViewDTO();
            updateCampaignViewDTO.setId(campaignViewDTO.getId());
            updateCampaignViewDTO.setCampaignBoostViewDTO(campaignBoostViewDTO);
            updateCampaignViewDTOList.add(updateCampaignViewDTO);
        }
        campaignRepository.updateCampaignPart(context, updateCampaignViewDTOList);
    }
}
