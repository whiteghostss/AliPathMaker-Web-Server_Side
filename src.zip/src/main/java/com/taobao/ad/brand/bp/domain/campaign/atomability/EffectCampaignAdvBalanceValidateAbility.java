package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.taobao.ad.brand.bp.client.dto.effect.EffectAdvertiserViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.EffectAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignAdvBalanceValidateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignAdvValidateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EffectCampaignAdvBalanceValidateAbility implements ICampaignAdvBalanceValidateAbility, EffectAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignAdvValidateAbilityParam abilityParam) {
        List<EffectAdvertiserViewDTO> advertiserViewDTOS = abilityParam.getAbilityTargets();
        if (CollectionUtils.isEmpty(advertiserViewDTOS)) {
            return null;
        }
        List<EffectAdvertiserViewDTO> hasBalanceList =
                advertiserViewDTOS.stream().filter(item-> !Optional.ofNullable(item.getBalance()).orElse(0L).equals(0L)).collect(Collectors.toList());
        AssertUtil.assertTrue(CollectionUtils.isEmpty(hasBalanceList),"广告主：%s余额不为0", StringUtils.join(hasBalanceList.stream().map(EffectAdvertiserViewDTO::getId).collect(Collectors.toList()), ","));

        return null;
    }
}
