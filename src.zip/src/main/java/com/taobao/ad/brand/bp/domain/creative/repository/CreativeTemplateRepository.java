package com.taobao.ad.brand.bp.domain.creative.repository;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.nb.ssp.dto.template.NbTemplateContextDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeTemplateQueryDTO;
import com.taobao.ad.brand.bp.client.dto.product.AdzoneViewDTO;
import com.taobao.ad.brand.bp.client.dto.template.TemplateContextViewDTO;
import com.taobao.ad.brand.bp.client.dto.template.TemplateViewDTO;

import java.util.List;

public interface CreativeTemplateRepository {
    TemplateViewDTO getTemplateById(ServiceContext serviceContext, Long TemplateId);

    List<TemplateViewDTO> getTemplateByIds(ServiceContext serviceContext, List<Long> TemplateIds);
    /**
     * 根据模板中心的id查询模板所需要使用到的协议字段
     * @param nbTemplateIds
     * @return
     */
    List<TemplateContextViewDTO> getTemplateMetaData(ServiceContext serviceContext, List<Long> nbTemplateIds,boolean isSmart);
    TemplateContextViewDTO getTemplateMetaData(ServiceContext serviceContext, Long nbTemplateId,boolean isSmart);

    List<TemplateViewDTO> getTemplateList(ServiceContext serviceContext, CreativeTemplateQueryDTO templateQueryDTO);

    /**
     * 查询模板关联的adzone
     * @param templateId
     * @return
     */
    List<AdzoneViewDTO> findAdzoneByTemplateId(Long templateId);
}
