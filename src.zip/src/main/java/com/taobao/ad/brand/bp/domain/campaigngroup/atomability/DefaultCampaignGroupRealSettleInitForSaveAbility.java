package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.realsettle.RealSettleInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupProcessStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.settle.CampaignGroupRealSettleSaveViewDTO;
import com.taobao.ad.brand.bp.common.converter.campaigngroup.CampaignGroupSettleConverter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupRealSettleInitForSaveAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupRealSettleInitForSaveAbilityParam;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
@BusinessAbility
public class DefaultCampaignGroupRealSettleInitForSaveAbility
    implements ICampaignGroupRealSettleInitForSaveAbility {

    @Resource
    private CampaignGroupSettleConverter campaignGroupSettleConverter;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupRealSettleInitForSaveAbilityParam abilityParam) {
        //获取场景子订单
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        CampaignGroupRealSettleSaveViewDTO realSettleSaveViewDTO = abilityParam.getRealSettleSaveViewDTO();

        Map<Long, SaleGroupInfoViewDTO> saleGroupInfoMap = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList()
            .stream().collect(Collectors.toMap(SaleGroupInfoViewDTO::getSaleGroupId, Function.identity()));
        List<RealSettleInfoViewDTO> toSaveRealSettleInfoList = campaignGroupSettleConverter.getBaseMapStructMapper().targetToSource(realSettleSaveViewDTO.getRealSettleInfoViewDTOList());
        for (RealSettleInfoViewDTO realSettleInfoViewDTO : toSaveRealSettleInfoList) {
            SaleGroupInfoViewDTO saleGroupInfoViewDTO = saleGroupInfoMap.get(realSettleInfoViewDTO.getGroupInfoViewDTO().getSaleGroupId());
            realSettleInfoViewDTO.getGroupInfoViewDTO().setSaleType(saleGroupInfoViewDTO.getSaleType());
            realSettleInfoViewDTO.getGroupInfoViewDTO().setSaleProductLine(saleGroupInfoViewDTO.getSaleProductLine());
            realSettleInfoViewDTO.getGroupInfoViewDTO().setSaleBusinessLine(saleGroupInfoViewDTO.getSaleBusinessLine());
            realSettleInfoViewDTO.getGroupInfoViewDTO().setSubContractId(saleGroupInfoViewDTO.getSubContractId());
            if (BrandSaleTypeEnum.BUY.getCode().equals(saleGroupInfoViewDTO.getSaleType())) {
                realSettleInfoViewDTO.getGroupInfoViewDTO().setBudget(saleGroupInfoViewDTO.getBudget());
            } else {
                realSettleInfoViewDTO.getGroupInfoViewDTO().setBudget(0L);
            }
        }
        campaignGroupViewDTO.getCampaignGroupRealSettleViewDTO().setRealSettleInfoViewDTOList(toSaveRealSettleInfoList);
        // 状态
        campaignGroupViewDTO.getCampaignGroupRealSettleViewDTO().setRealSettleProcessStatus(
            BrandCampaignGroupProcessStatusEnum.EDITED.getCode());
        return null;
    }
}
