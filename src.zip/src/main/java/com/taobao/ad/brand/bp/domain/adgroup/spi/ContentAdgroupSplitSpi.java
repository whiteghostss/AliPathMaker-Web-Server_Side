package com.taobao.ad.brand.bp.domain.adgroup.spi;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.nb.framework.core.AbilitySpi;
import com.alibaba.ad.nb.framework.core.annotation.Ability;

import java.util.List;

/**
 * @author ximu
 * @date 2023/7/26
 */
@Ability(desc = "内容单元拆分扩展点")
public interface ContentAdgroupSplitSpi extends AbilitySpi {
    /**
     * 内容单元拆分
     * @param serviceContext
     * @param campaignViewDTO
     * @return
     */
    List<AdgroupViewDTO> split(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO);
}
