package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.smartreserved.CampaignSmartReservedViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignSmartReservedValidateForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignSmartReservedAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandCampaignSmartReservedValidateForAddCampaignAbility implements ICampaignSmartReservedValidateForAddCampaignAbility, BrandAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignSmartReservedAbilityParam abilityParam) {
        ProductViewDTO productViewDTO = abilityParam.getProductViewDTO();
        AssertUtil.notNull(productViewDTO, "二级产品不能为空");
        ResourcePackageProductViewDTO resourcePackageProductViewDTO = abilityParam.getResourcePackageProductViewDTO();
        AssertUtil.notNull(resourcePackageProductViewDTO, "资源产品不能为空");
        ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO = abilityParam.getResourcePackageSaleGroupViewDTO();
        AssertUtil.notNull(packageSaleGroupViewDTO, "资源包分组不能为空");
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();
        AssertUtil.notNull(campaignViewDTO, "计划不能为空");
        CampaignSmartReservedViewDTO smartReservedViewDTO = Optional.ofNullable(abilityParam.getAbilityTarget()).orElse(new CampaignSmartReservedViewDTO());
        //【智能预留场景】1、三方DSP必填
        if(BrandBoolEnum.BRAND_TRUE.getCode().equals(productViewDTO.getSmartreserved())){
            AssertUtil.notNull(smartReservedViewDTO.getDspId(),"计划三方DSP必填");
        }
        //二环PDB补量场景，补量计划需要设置"是否复用主计划deal"
        if (BrandSaleTypeEnum.BOOST.getCode().equals(packageSaleGroupViewDTO.getSaleType())) {
            Integer castType = BizCampaignToolsHelper.getCampaignCastType(campaignViewDTO, resourcePackageProductViewDTO);
            if(BizCampaignToolsHelper.isTwoPDB(productViewDTO.getMediaScope(),castType)){
                AssertUtil.notNull(BrandBoolEnum.getByCode(smartReservedViewDTO.getIsCopyMainDeal()),"补量计划场景，是否复用主计划deal必填");
            }
        }
        return null;
    }
}
