package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignMsgNoticeViewDTO;
import com.taobao.ad.brand.bp.client.dto.message.MessageViewDTO;
import com.taobao.ad.brand.bp.client.enums.message.MessageSendTypeEnum;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.VelocityUtils;
import com.taobao.ad.brand.bp.domain.memeber.MemberRepository;
import com.taobao.ad.brand.bp.domain.message.MessageRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupCancelWarningSendNoticeAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupNoticeAbilityParam;
import org.springframework.cglib.beans.BeanMap;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;

@Component
@BusinessAbility
public class DefaultCampaignGroupCancelWarngingSendNoticeAbility implements ICampaignGroupCancelWarningSendNoticeAbility {

    @Resource
    private MemberRepository memberRepository;
    @Resource
    private MessageRepository messageRepository;

    /**
     * 订单撤单预警通知
     */
    private static final String CAMPAIGN_GROUP_CANCEL_WARNING_NOTICE = "vm/campaignGroupCancelWarningNotice.vm";

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupNoticeAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        Date autoCancelExpireDate = abilityParam.getAutoCancelExpireDate();
        MessageViewDTO messageViewDTO = new MessageViewDTO();
        String subject = String.format("【自助营销订单自动撤单预警】投放账号：%s  订单：%s",
                memberRepository.getMemberDisplayNameById(campaignGroupViewDTO.getMemberId()),
                campaignGroupViewDTO.getName());
        messageViewDTO.setMemberId(campaignGroupViewDTO.getMemberId());
        messageViewDTO.setSubject(subject);
        messageViewDTO.setContent(buildAutoCancelWarningMessageContent(serviceContext, campaignGroupViewDTO, autoCancelExpireDate));
        messageViewDTO.setSendType(Lists.newArrayList(MessageSendTypeEnum.STATION_LETTER.getValue()));
        messageRepository.sendMessage(messageViewDTO);

        return null;
    }

    private String buildAutoCancelWarningMessageContent(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, Date autoCancelExpireTime) {
        CampaignMsgNoticeViewDTO campaignMsgNoticeViewDTO = new CampaignMsgNoticeViewDTO();
        campaignMsgNoticeViewDTO.setCampaignGroupId(campaignGroupViewDTO.getId());
        campaignMsgNoticeViewDTO.setCampaignGroupName(campaignGroupViewDTO.getName());
        campaignMsgNoticeViewDTO.setReleaseTime(BrandDateUtil.date2String(autoCancelExpireTime, BrandDateUtil.DATE_FORMAT_YYYYMMDDHHMM_TYPE_1));
        BeanMap beanMap = BeanMap.create(campaignMsgNoticeViewDTO);
        return VelocityUtils.merge(CAMPAIGN_GROUP_CANCEL_WARNING_NOTICE, beanMap);
    }
}
