package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignBoostCampaignDeleteValidateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBoostDeleteValidateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandCampaignBoostDeleteValidateAbility implements ICampaignBoostCampaignDeleteValidateAbility, BrandAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignBoostDeleteValidateAbilityParam abilityParam) {
        CampaignViewDTO dbCampaign = abilityParam.getAbilityTarget();
        AssertUtil.notNull(dbCampaign, BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR,"计划不存在");
        // 【补量】存在未删除的补量计划
        List<CampaignViewDTO> boostCampaignViewDTOList = abilityParam.getBoostCampaignViewDTOList();
        if(CollectionUtils.isEmpty(boostCampaignViewDTOList)){
            return null;
        }
        boostCampaignViewDTOList = boostCampaignViewDTOList.stream()
                .filter(e -> !e.getId().equals(e.getCampaignBoostViewDTO().getSourceCampaignId()))
                .filter(e -> BrandSaleTypeEnum.BOOST.getCode().equals(e.getCampaignSaleViewDTO().getSaleType()))
                .collect(Collectors.toList());
        AssertUtil.assertTrue(CollectionUtils.isEmpty(boostCampaignViewDTOList),
                BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR, "存在未删除的补量计划，不允许删除！");
        return null;
    }
}
