package com.taobao.ad.brand.bp.domain.config;

import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.pub.DimensionConfigRuleViewDTO;
import com.taobao.ad.brand.bp.client.dto.pub.SaleProductLineDimensionConfigViewDTO;
import com.taobao.ad.brand.bp.domain.config.base.BaseDiamondConfig;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

/**
 * 单元或者创意的绑定数量规则
 * */
@Component
public class SaleProductLineDimensionConfig extends BaseDiamondConfig {
    private static volatile String config;

    @Override
    protected String getDataId() {
        return "saleproductline.dimension.rule.config";
    }
    @Override
    protected String getGroupId() { return "com.taobao.ad.brand.bp"; }

    @Override
    protected void initDiamond(String diamondConfig) {
        RogerLogger.info("DiamondConfig.initDiamond SaleProductLineDimensionConfig param: {}", diamondConfig);
        config = diamondConfig;
    }

    /**
     * 查询领券模版列表
     * @return
     */
    public List<SaleProductLineDimensionConfigViewDTO> getSaleProductLineDimensionConfigList(){
        if (StringUtils.isBlank(config)) {
            return Lists.newArrayList();
        }
        return JSON.parseArray(config, SaleProductLineDimensionConfigViewDTO.class);
    }


    public DimensionConfigRuleViewDTO getDimensionConfigRuleViewDTO(Integer saleProductLine,Integer dimensionType){
        List<SaleProductLineDimensionConfigViewDTO> saleProductLineDimensionConfigViewDTOS = this.getSaleProductLineDimensionConfigList();
        if (CollectionUtils.isNotEmpty(saleProductLineDimensionConfigViewDTOS)) {

            Optional<SaleProductLineDimensionConfigViewDTO>
                optional = saleProductLineDimensionConfigViewDTOS.stream().filter(item -> item.getSaleProductLineId().equals(saleProductLine)).findFirst();
            if (optional.isPresent()) {
                SaleProductLineDimensionConfigViewDTO saleProductLineDimensionConfigViewDTO =
                    optional.get();
                //check
                if (CollectionUtils.isNotEmpty(saleProductLineDimensionConfigViewDTO.getDimensionConfigRules())) {
                    List<DimensionConfigRuleViewDTO> dimensionConfigRuleViewDTOList = saleProductLineDimensionConfigViewDTO.getDimensionConfigRules();
                    Optional<DimensionConfigRuleViewDTO> ruleOptional =
                        dimensionConfigRuleViewDTOList.stream().filter(rule -> rule.getDimensionType().equals(dimensionType)).findFirst();
                    if (ruleOptional.isPresent()) {
                        return ruleOptional.get();
                    }
                }
            }
        }
        return null;
    }
}
