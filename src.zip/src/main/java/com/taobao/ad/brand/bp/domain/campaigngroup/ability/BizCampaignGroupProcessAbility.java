package com.taobao.ad.brand.bp.domain.campaigngroup.ability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityInject;
import com.alibaba.abf.isolation.spec.common.ReduceType;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.ability.BizCampaignGroupProcessAbilityExt;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR;

/**
 * @author yanjingang
 * @date 2023/3/11
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizCampaignGroupProcessAbility {

    @AbilityInject(reduce = ReduceType.FIRST)
    private final BizCampaignGroupProcessAbilityExt bizCampaignGroupProcessAbilityExt;

    private static final List<Integer> validCampaignGroupRealSettleStatusList = Lists.newArrayList(
            BrandCampaignGroupStatusEnum.FINISHED.getCode(),
            BrandCampaignGroupStatusEnum.REAL_SETTLE_ING.getCode(),
            BrandCampaignGroupStatusEnum.REAL_SETTLED.getCode()
    );

    public void validateQueryRealSettleData(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO) {
        AssertUtil.notNull(campaignGroupViewDTO, "订单不存在");
        AssertUtil.assertTrue(validCampaignGroupRealSettleStatusList.contains(campaignGroupViewDTO.getStatus()), BIZ_BREAK_RULE_ERROR,
                String.format("订单状态(%s)不支持查询实结信息", BrandCampaignGroupStatusEnum.getByCode(campaignGroupViewDTO.getStatus()).getDesc()));
        // 个性化校验
        bizCampaignGroupProcessAbilityExt.validateForQueryRealSettleInfo(context, campaignGroupViewDTO);
    }
}
