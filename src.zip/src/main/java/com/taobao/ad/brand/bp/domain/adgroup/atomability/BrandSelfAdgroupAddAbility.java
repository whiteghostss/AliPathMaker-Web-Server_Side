package com.taobao.ad.brand.bp.domain.adgroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.taobao.ad.brand.bp.domain.adgroup.repository.AdgroupRepository;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeRepository;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupAddAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupAddAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;


@Component
@BusinessAbility
public class BrandSelfAdgroupAddAbility implements IAdgroupAddAbility, BrandSelfServiceAtomAbilityRouter {
    @Resource
    private  CreativeRepository creativeRepository;
    @Resource
    private  AdgroupRepository adgroupRepository;
    @Override
    public Long handle(ServiceContext context, AdgroupAddAbilityParam abilityParam) {
        AdgroupViewDTO adgroupViewDTO = abilityParam.getAbilityTarget();
        Long adgroupId =  adgroupRepository.addAdgroup(context,adgroupViewDTO);
        adgroupRepository.addCreativeRef(context,adgroupViewDTO);
        return adgroupId;
    }

}
