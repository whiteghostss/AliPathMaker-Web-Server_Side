package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.guarantee.CampaignGuaranteeViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignGuaranteeValidateForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignGuaranteeAbilityParam;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@BusinessAbility
public class BrandCampaignGuaranteeValidateForAddCampaignAbility implements ICampaignGuaranteeValidateForAddCampaignAbility, BrandAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGuaranteeAbilityParam abilityParam) {
        CampaignGuaranteeViewDTO campaignGuaranteeViewDTO = abilityParam.getAbilityTarget();
        ResourcePackageProductViewDTO resourcePackageProductViewDTO = abilityParam.getResourcePackageProductViewDTO();
        AssertUtil.notNull(resourcePackageProductViewDTO, "资源包二级产品不能为空");
        //【二环CPT场景】1、预定轮数不允许为空
        if(BizCampaignToolsHelper.isTwoCPT(resourcePackageProductViewDTO.getMediaScope(),resourcePackageProductViewDTO.getSaleUnit())){
            Long cptAmount = Optional.ofNullable(campaignGuaranteeViewDTO).map(CampaignGuaranteeViewDTO::getCptAmount).orElse(null);
            AssertUtil.notNull(cptAmount,"计划预定轮数必填");
        }
        return null;
    }
}
