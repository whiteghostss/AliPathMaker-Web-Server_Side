package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.realsettle.CampaignGroupRealSettleViewDTO;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupStopTimeUpdateForStopCastCampaignGroupAbilityParam;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;

@Component
@BusinessAbility
public class BrandOneBPCampaignGroupStopTimeUpdateForStopCastCampaignGroupAbility
        extends DefaultCampaignGroupStopTimeUpdateForStopCastCampaignGroupAbility implements BrandOneBPAtomAbilityRouter {
    @Resource
    private CampaignGroupRepository campaignGroupRepository;
    @Override
    public Void handle(ServiceContext serviceContext,
                       CampaignGroupStopTimeUpdateForStopCastCampaignGroupAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        // 更新停投时间（主订单使用当前时间作为停投时间）
        CampaignGroupViewDTO updateCampaignGroupViewDTO = new CampaignGroupViewDTO();
        updateCampaignGroupViewDTO.setId(campaignGroupViewDTO.getId());
        CampaignGroupRealSettleViewDTO realSettleViewDTO = new CampaignGroupRealSettleViewDTO();
        realSettleViewDTO.setStopCastTime(new Date());
        updateCampaignGroupViewDTO.setCampaignGroupRealSettleViewDTO(realSettleViewDTO);
        campaignGroupRepository.updateCampaignGroupPart(serviceContext, updateCampaignGroupViewDTO);
        return null;
    }
}
