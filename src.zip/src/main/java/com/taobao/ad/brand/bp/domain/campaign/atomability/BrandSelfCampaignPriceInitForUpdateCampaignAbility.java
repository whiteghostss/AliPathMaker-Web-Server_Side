package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.price.CampaignPriceViewDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignPriceInitForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignPriceAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSelfCampaignPriceInitForUpdateCampaignAbility implements ICampaignPriceInitForUpdateCampaignAbility, BrandSelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignPriceAbilityParam abilityParam) {
        CampaignPriceViewDTO campaignPriceViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        AssertUtil.notNull(campaignPriceViewDTO, "计划单价信息不能为空");
        AssertUtil.notNull(dbCampaignViewDTO, "计划不存在");

        CampaignPriceViewDTO dbCampaignPriceViewDTO = Optional.ofNullable(dbCampaignViewDTO.getCampaignPriceViewDTO()).orElse(new CampaignPriceViewDTO());
        campaignPriceViewDTO.setPublishProductId(dbCampaignPriceViewDTO.getPublishProductId());
        campaignPriceViewDTO.setPublishPriceInfoList(dbCampaignPriceViewDTO.getPublishPriceInfoList());
        campaignPriceViewDTO.setDiscountPriceInfoList(dbCampaignPriceViewDTO.getDiscountPriceInfoList());
        campaignPriceViewDTO.setSettlePrice(dbCampaignPriceViewDTO.getSettlePrice());

        //二环CPT：预定量变更，需要清空金额、预定量 、以及询锁量信息
        Integer mediaScope = dbCampaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope();
        Integer registerUnit = dbCampaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterUnit();
        boolean isNeedClearPrice = false;
        if(BizCampaignToolsHelper.isTwoCPT(mediaScope,registerUnit)){
            Long cptAmount = campaignViewDTO.getCampaignGuaranteeViewDTO().getCptAmount();
            Long dbCptAmount = dbCampaignViewDTO.getCampaignGuaranteeViewDTO().getCptAmount();
            isNeedClearPrice = !Objects.equals(dbCptAmount, cptAmount);
        }
        if(isNeedClearPrice){
            campaignPriceViewDTO.setDiscountPriceInfoList(Lists.newArrayList());
            campaignPriceViewDTO.setPublishPriceInfoList(Lists.newArrayList());
            campaignPriceViewDTO.setSettlePrice(0L);
        }
        return null;
    }
}
