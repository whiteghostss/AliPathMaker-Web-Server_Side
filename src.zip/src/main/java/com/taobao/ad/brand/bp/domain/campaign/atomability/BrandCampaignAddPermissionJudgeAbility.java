package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.taobao.ad.brand.bp.client.dto.rule.RuleCheckResultViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignAddPermissionJudgeAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Deprecated
@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))

public class BrandCampaignAddPermissionJudgeAbility extends DefaultCampaignAddPermissionJudgeAbility
        implements BrandAtomAbilityRouter {

    @Override
    public RuleCheckResultViewDTO handle(ServiceContext serviceContext, CampaignAddPermissionJudgeAbilityParam abilityParam) {
        return RuleCheckResultViewDTO.builder().isPass(BrandBoolEnum.BRAND_TRUE.getCode()).build();
    }
}
