package com.taobao.ad.brand.bp.domain.event;

import com.alibaba.hermes.framework.ddd.event.DomainEvent;
import com.taobao.ad.brand.bp.client.context.DomainMetaqMessageBodyContext;

/**
 * @author ximu
 * @date 2023/7/18
 */
public class DomainMetaqMessageEvent extends DomainEvent<DomainMetaqMessageBodyContext> {

    protected DomainMetaqMessageEvent(DomainMetaqMessageBodyContext domainMetaqMessageBodyContext) {
        super(domainMetaqMessageBodyContext);
    }

    public static DomainMetaqMessageEvent of(DomainMetaqMessageBodyContext domainMetaqMessageBodyContext) {
        return new DomainMetaqMessageEvent(domainMetaqMessageBodyContext);
    }
}
