package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.CampaignGroupSaleViewDTO;
import com.alibaba.ad.brand.dto.common.SchemaConfigViewDTO;
import com.alibaba.ad.brand.dto.common.WakeupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupWakeupTypeEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageTemplateViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.SchemaEnum;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupWakeupInitForAddCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupWakeupAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Optional;

@Component
@BusinessAbility
public class DefaultCampaignGroupWakeupInitForAddCampaignGroupAbility implements ICampaignGroupWakeupInitForAddCampaignGroupAbility {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupWakeupAbilityParam abilityParam) {
        WakeupViewDTO wakeupViewDTO = Optional.ofNullable(abilityParam.getAbilityTarget()).orElse(new WakeupViewDTO());

        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        // 设置默认唤端信息
        wakeupViewDTO.setWakeupType(BrandCampaignGroupWakeupTypeEnum.SINGLE_WAKEUP.getCode());
        SchemaConfigViewDTO schemaConfigViewDTO = new SchemaConfigViewDTO();
        schemaConfigViewDTO.setSchemaId(Long.parseLong(String.valueOf(SchemaEnum.TAOBAO.getValue())));
        schemaConfigViewDTO.setOpenType(SchemaEnum.TAOBAO.getOpenType());
        List<SchemaConfigViewDTO> schemaConfigViewDTOList = Lists.newArrayList(schemaConfigViewDTO);
        wakeupViewDTO.setSchemaConfigViewDTOList(schemaConfigViewDTOList);

        campaignGroupViewDTO.setWakeupViewDTO(wakeupViewDTO);

        return null;
    }
}
