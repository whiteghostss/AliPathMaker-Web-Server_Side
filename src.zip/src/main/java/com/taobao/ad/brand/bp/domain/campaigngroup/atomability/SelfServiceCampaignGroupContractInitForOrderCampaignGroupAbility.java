package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.contract.CampaignGroupContractViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupContractSignStatusEnum;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupOrderCommandViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupContractInitForOrderCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupContractInitForOrderAbilityParam;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Optional;

@Component
@BusinessAbility
public class SelfServiceCampaignGroupContractInitForOrderCampaignGroupAbility
        implements ICampaignGroupContractInitForOrderCampaignGroupAbility, SelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupContractInitForOrderAbilityParam abilityParam) {
        CampaignGroupContractViewDTO campaignGroupContractViewDTO = Optional.ofNullable(abilityParam.getAbilityTarget()).orElse(new CampaignGroupContractViewDTO());
        CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO = abilityParam.getCampaignGroupOrderCommandViewDTO();

        campaignGroupContractViewDTO.setSignScheduleUrl(campaignGroupOrderCommandViewDTO.getSignScheduleUrl());
        campaignGroupContractViewDTO.setContractSignStatus(BrandCampaignGroupContractSignStatusEnum.SIGNED.getCode());
        campaignGroupContractViewDTO.setSignTime(new Date());

        abilityParam.getCampaignGroupViewDTO().setCampaignGroupContractViewDTO(campaignGroupContractViewDTO);

        return null;
    }
}
