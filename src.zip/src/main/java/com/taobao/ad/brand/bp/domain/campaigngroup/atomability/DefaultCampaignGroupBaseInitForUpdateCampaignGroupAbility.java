package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupBaseInitForUpdateCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupBaseAbilityParam;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
public class DefaultCampaignGroupBaseInitForUpdateCampaignGroupAbility implements ICampaignGroupBaseInitForUpdateCampaignGroupAbility {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupBaseAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        if (!BizCampaignGroupToolsHelper.isSaleCampaignGroup(campaignGroupViewDTO)) {
            return null;
        }
        // 预算、sceneId在拆分时已经初始化，本次无需再次初始化
        CampaignGroupViewDTO dbCampaignGroupViewDTO = abilityParam.getDbCampaignGroupViewDTO();
        campaignGroupViewDTO.setId(dbCampaignGroupViewDTO.getId());
        campaignGroupViewDTO.setGiveStatus(dbCampaignGroupViewDTO.getGiveStatus());
        campaignGroupViewDTO.setBoostStatus(dbCampaignGroupViewDTO.getBoostStatus());
        campaignGroupViewDTO.setName(null);
        campaignGroupViewDTO.setStatus(null);
        campaignGroupViewDTO.setStartTime(null);
        campaignGroupViewDTO.setEndTime(null);
        campaignGroupViewDTO.setParentId(null);
        campaignGroupViewDTO.setSource(null);
        campaignGroupViewDTO.setSourceIds(null);
        campaignGroupViewDTO.setPreviousStatus(null);

        return null;
    }
}
