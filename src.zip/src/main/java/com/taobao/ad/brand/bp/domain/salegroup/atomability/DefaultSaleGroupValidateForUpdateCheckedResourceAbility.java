package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupCheckedResourceViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourceDistributionRuleViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.NumberUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupUpdateCheckedResourceAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupValidateForUpdateCheckedResourceAbility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultSaleGroupValidateForUpdateCheckedResourceAbility implements ISaleGroupValidateForUpdateCheckedResourceAbility {

    @Resource
    private CampaignRepository campaignRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupUpdateCheckedResourceAbilityParam abilityParam) {
        CampaignGroupCheckedResourceViewDTO checkedResourceViewDTO = abilityParam.getAbilityTarget();
        List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupList = abilityParam.getResourcePackageSaleGroupList();
        // 0元订单无需进行预算分配校验
        boolean allMatch = resourcePackageSaleGroupList.stream().filter(it -> BrandSaleTypeEnum.BUY.getCode().equals(it.getSaleType())).allMatch(it -> NumberUtil.greaterThanZero(it.getBudget()));
        if (!allMatch) {
            RogerLogger.info("0元订单无需进行预算分配校验");
            return null;
        }
        Map<Long, String> saleGroupNameMap = resourcePackageSaleGroupList.stream().collect(Collectors.toMap(ResourcePackageSaleGroupViewDTO::getId,
                ResourcePackageSaleGroupViewDTO::getName,(v1,v2) -> v2));
        Map<Long, String> productNameMap = this.getProductNameMap(resourcePackageSaleGroupList);

        CampaignQueryViewDTO campaignQuery = new CampaignQueryViewDTO();
        campaignQuery.setCampaignGroupId(checkedResourceViewDTO.getId());
        campaignQuery.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
        if (checkedResourceViewDTO.getSaleType() != null) {
            campaignQuery.setSaleTypes(Lists.newArrayList(checkedResourceViewDTO.getSaleType()));
        }
        List<CampaignViewDTO> campaignViewDTOList = campaignRepository.queryCampaignList(serviceContext, campaignQuery);
        for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
            String title = campaignViewDTO.getTitle();
            Long resourcePackageProductId = campaignViewDTO.getCampaignSaleViewDTO().getResourcePackageProductId();
            Long saleGroupId = campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId();
            AssertUtil.assertTrue(NumberUtil.greaterThanZero(campaignViewDTO.getCampaignBudgetViewDTO().getDiscountTotalMoney()), BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR,
                    String.format("分组(%s)下资源(%s)下计划(%s)预算未分配", saleGroupNameMap.get(saleGroupId), productNameMap.get(resourcePackageProductId), title));
        }

        return null;
    }

    /**
     * 获取资源产品及其名称
     */
    private Map<Long, String> getProductNameMap(List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupList) {
        if (CollectionUtils.isEmpty(resourcePackageSaleGroupList)) {
            return Maps.newHashMap();
        }
        Map<Long, String> productNameMap = Maps.newHashMap();
        for (ResourcePackageSaleGroupViewDTO saleGroupViewDTO : resourcePackageSaleGroupList) {
            if (CollectionUtils.isEmpty(saleGroupViewDTO.getDistributionRuleList())) {
                continue;
            }
            for (ResourceDistributionRuleViewDTO ruleViewDTO : saleGroupViewDTO.getDistributionRuleList()) {
                if (CollectionUtils.isEmpty(ruleViewDTO.getResourcePackageProductList())) {
                    continue;
                }
                ruleViewDTO.getResourcePackageProductList().forEach(v -> productNameMap.put(v.getId(), v.getCustomerOrientedProductName()));
            }
        }
        return productNameMap;
    }
}
