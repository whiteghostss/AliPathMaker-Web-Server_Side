package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.sale.CampaignSaleViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignSaleInitForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignSaleAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCampaignSaleInitForAddCampaignAbility implements ICampaignSaleInitForAddCampaignAbility, SelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignSaleAbilityParam abilityParam) {
        CampaignSaleViewDTO campaignSaleViewDTO = abilityParam.getAbilityTarget();
        ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO = abilityParam.getResourcePackageSaleGroupViewDTO();
        ResourcePackageProductViewDTO resourcePackageProductViewDTO = abilityParam.getResourcePackageProductViewDTO();
        ProductViewDTO productViewDTO = abilityParam.getProductViewDTO();

        AssertUtil.notNull(campaignSaleViewDTO,"售卖信息不能为空");
        AssertUtil.notNull(resourcePackageSaleGroupViewDTO,"售卖分组不能为空");
        AssertUtil.notNull(resourcePackageProductViewDTO,"分组产品不能为空");
        AssertUtil.notNull(productViewDTO,"产品不能为空");

        // 计划售卖类型：购买、赠送、补量
        campaignSaleViewDTO.setSaleType(resourcePackageSaleGroupViewDTO.getSaleType());
        campaignSaleViewDTO.setProductConfigType(resourcePackageSaleGroupViewDTO.getProductConfigType());
        campaignSaleViewDTO.setSaleUnit(resourcePackageProductViewDTO.getSaleUnit() == null
                ? productViewDTO.getSellUnit() : resourcePackageProductViewDTO.getSaleUnit());
        campaignSaleViewDTO.setSaleProductLine(resourcePackageSaleGroupViewDTO.getSaleProductLine());
        campaignSaleViewDTO.setSaleBusinessLine(resourcePackageSaleGroupViewDTO.getBusinessLine());

        return null;
    }
}
