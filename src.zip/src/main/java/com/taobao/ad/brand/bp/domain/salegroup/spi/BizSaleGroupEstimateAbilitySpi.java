package com.taobao.ad.brand.bp.domain.salegroup.spi;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.nb.framework.core.AbilitySpi;
import com.alibaba.ad.nb.framework.core.annotation.Ability;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupEstimateInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.CampaignGroupSaleGroupEstimateQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.DmpArgusEstimateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.SaleGroupProductCampaignViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;

import java.util.List;
import java.util.Map;

/**
 * @author yunhu.myh@taobao.com
 * @date 2023年08月09日
 * 分组预估能力SPI
 * */
@Ability(desc = "分组预估能力SPI")
public interface BizSaleGroupEstimateAbilitySpi extends AbilitySpi {


    /**
     * 预估
     * */
    CampaignGroupSaleGroupEstimateInfoViewDTO doEstimate(ServiceContext serviceContext, DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO, List<CampaignViewDTO>  campaignViewDTOList);
    /**
     * 构建预估的请求
     * 若有计算用计算的，
     * 若没有计算，则需要计算后再进行
     * TODO 弈云 一会儿检查下是否完成计算的标记问题。
     * @param serviceContext
     * @param campaignGroupViewDTO
     * @param saleGroupInfoViewDTOList
     * @param saleGroupProductCampaignViewDTOS
     * @param remoteResourcePackageSaleGroupViewDTOMap
     * @param estimateType
     * @param estimateDimensionType
     * @return
     */
    List<DmpArgusEstimateViewDTO> buildSaleGroupEstimateViewDTOList(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList, List<SaleGroupProductCampaignViewDTO> saleGroupProductCampaignViewDTOS, Map<Long, ResourcePackageSaleGroupViewDTO> remoteResourcePackageSaleGroupViewDTOMap, Integer estimateType, Integer estimateDimensionType);

    List<SaleGroupProductCampaignViewDTO> convertToSaleGroupProductCampaignViewDTOList(ServiceContext serviceContext,List<CampaignViewDTO> campaignViewDTOList);
    /**
     * 保存预估结果
     * */
    Void saveEstimateResult(ServiceContext serviceContext, CampaignGroupSaleGroupEstimateQueryViewDTO campaignGroupSaleGroupEstimateQueryViewDTO, List<CampaignGroupSaleGroupEstimateInfoViewDTO> campaignGroupSaleGroupEstimateInfoViewDTOList);

    /**
     * 发送指标置信度预警
     *
     * @param serviceContext                                上下文
     * @param campaignGroupSaleGroupEstimateQueryViewDTO    查询条件
     * @param campaignGroupSaleGroupEstimateInfoViewDTOList 处理结果
     * @return 空
     */
    Void sendWarnMessage(ServiceContext serviceContext, CampaignGroupSaleGroupEstimateQueryViewDTO campaignGroupSaleGroupEstimateQueryViewDTO, List<CampaignGroupSaleGroupEstimateInfoViewDTO> campaignGroupSaleGroupEstimateInfoViewDTOList);

    Void processFinalValue(ServiceContext serviceContext, CampaignGroupSaleGroupEstimateInfoViewDTO campaignGroupSaleGroupEstimateInfoViewDTOList,ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO,SaleGroupInfoViewDTO dbSaleGroupInfoViewDTO, boolean isSave,boolean isIgnoreAliLogin);

}
