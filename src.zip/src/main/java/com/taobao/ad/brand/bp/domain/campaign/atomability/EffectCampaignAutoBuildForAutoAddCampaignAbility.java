package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.resource.CampaignResourceViewDTO;
import com.alibaba.ad.brand.dto.campaign.sale.CampaignSaleViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.EffectAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignAutoBuildForAutoAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignAutoBuildForAutoAddCampaignAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EffectCampaignAutoBuildForAutoAddCampaignAbility implements ICampaignAutoBuildForAutoAddCampaignAbility, EffectAtomAbilityRouter {

    @Override
    public List<CampaignViewDTO> handle(ServiceContext serviceContext, CampaignAutoBuildForAutoAddCampaignAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(campaignGroupViewDTO,"订单不能为空");
        // 二级产品
        Map<Long, ResourcePackageProductViewDTO> packageProductViewMap = abilityParam.getPackageProductViewMap();
        AssertUtil.notEmpty(packageProductViewMap,"资源包产品不能为空");

        List<CampaignViewDTO> campaignViewDTOList = Lists.newArrayList();
        for(Map.Entry<Long, ResourcePackageProductViewDTO> entry : packageProductViewMap.entrySet()){
            ResourcePackageProductViewDTO resourcePackageProductViewDTO = entry.getValue();
            CampaignViewDTO addCampaign = buildAutoAddCampaignParam(campaignGroupViewDTO, resourcePackageProductViewDTO);
            campaignViewDTOList.add(addCampaign);
        }
        return campaignViewDTOList;
    }

    private CampaignViewDTO buildAutoAddCampaignParam(CampaignGroupViewDTO campaignGroupViewDTO,
                                                      ResourcePackageProductViewDTO resourcePackageProductViewDTO) {
        //拆分计划
        CampaignViewDTO campaignViewDTO = new CampaignViewDTO();
        //填充核心关联的ID信息
        campaignViewDTO.setMemberId(campaignGroupViewDTO.getMemberId());
        campaignViewDTO.setCampaignGroupId(campaignGroupViewDTO.getId());
        campaignViewDTO.setMainCampaignGroupId(campaignGroupViewDTO.getParentId());

        if(BrandDateUtil.isBefore(BrandDateUtil.getCurrentDate(), resourcePackageProductViewDTO.getStartTime())){
            campaignViewDTO.setStartTime(resourcePackageProductViewDTO.getStartTime());
        }else{
            campaignViewDTO.setStartTime(BrandDateUtil.getTomorrowDate());
        }
        campaignViewDTO.setEndTime(BrandDateUtil.getDateFullMidnight(resourcePackageProductViewDTO.getEndTime()));

        CampaignSaleViewDTO campaignSaleViewDTO = new CampaignSaleViewDTO();
        campaignSaleViewDTO.setCustomerId(campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getCustomerId());
        campaignSaleViewDTO.setSaleGroupId(resourcePackageProductViewDTO.getSaleGroupId());
        campaignSaleViewDTO.setResourcePackageProductId(resourcePackageProductViewDTO.getId());
        campaignViewDTO.setCampaignSaleViewDTO(campaignSaleViewDTO);

        CampaignResourceViewDTO sspResourceViewDTO = new CampaignResourceViewDTO();
        sspResourceViewDTO.setSspProductId(resourcePackageProductViewDTO.getSspProductId());
        campaignViewDTO.setCampaignResourceViewDTO(sspResourceViewDTO);

        return campaignViewDTO;
    }
}
