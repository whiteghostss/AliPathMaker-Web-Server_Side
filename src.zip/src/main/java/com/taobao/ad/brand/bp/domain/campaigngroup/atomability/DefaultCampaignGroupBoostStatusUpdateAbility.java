package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupBoostStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSaleOrderStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupBoostStatusUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupBoostStatusUpdateAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

@Component
@BusinessAbility
public class DefaultCampaignGroupBoostStatusUpdateAbility implements ICampaignGroupBoostStatusUpdateAbility {

    @Resource
    private CampaignGroupRepository campaignGroupRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupBoostStatusUpdateAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        if (BizCampaignGroupToolsHelper.isMainCampaignGroup(campaignGroupViewDTO) || campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO() == null || CollectionUtils.isEmpty(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList())) {
            return null;
        }
        Integer boostStatus = buildBoostStatus(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList());
        if (BrandCampaignGroupBoostStatusEnum.NON_BOOST.getCode().equals(boostStatus) && Objects.isNull(campaignGroupViewDTO.getBoostStatus())) {
            return null;
        }
        CampaignGroupViewDTO updateCampaignGroupViewDTO = new CampaignGroupViewDTO();
        updateCampaignGroupViewDTO.setId(campaignGroupViewDTO.getId());
        updateCampaignGroupViewDTO.setBoostStatus(boostStatus);
        campaignGroupRepository.updateCampaignGroupPart(serviceContext, updateCampaignGroupViewDTO);
        return null;
    }

    private Integer buildBoostStatus(List<SaleGroupInfoViewDTO> groupInfoViewDTOS) {
        Set<Integer> saleGroupOrderStatusSet = groupInfoViewDTOS.stream()
                .filter(t -> BrandSaleTypeEnum.BOOST.getCode().equals(t.getSaleType()) && t.getSaleGroupStatus() != null)
                .map(SaleGroupInfoViewDTO::getSaleGroupStatus)
                .collect(Collectors.toSet());
        if (CollectionUtils.isEmpty(saleGroupOrderStatusSet)) {
            return BrandCampaignGroupBoostStatusEnum.NON_BOOST.getCode();
        }
        if (saleGroupOrderStatusSet.contains(BrandCampaignGroupSaleOrderStatusEnum.ORDER_FINISH.getCode()) && saleGroupOrderStatusSet.size() == 1) {
            return judgeCompleteStatus(groupInfoViewDTOS) ? BrandCampaignGroupBoostStatusEnum.BOOST_COMPLETE.getCode() :
                    BrandCampaignGroupBoostStatusEnum.BOOST_ING.getCode();
        }
        return BrandCampaignGroupBoostStatusEnum.BOOST_CONFIGURE_ING.getCode();
    }

    private boolean judgeCompleteStatus(List<SaleGroupInfoViewDTO> groupInfoViewDTOS) {
        Date currentDate = BrandDateUtil.getCurrentDate();
        return groupInfoViewDTOS.stream().filter(dto -> BrandSaleTypeEnum.BOOST.getCode().equals(dto.getSaleType()))
                .map(SaleGroupInfoViewDTO::getEndDate).allMatch(endDate -> BrandDateUtil.isAfter(currentDate, endDate));
    }
}
