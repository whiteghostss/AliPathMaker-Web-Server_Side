package com.taobao.ad.brand.bp.domain.adgroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupBottomTypeEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.adgroup.constant.AdgroupCreateValidateConstant;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupCreateRuleValidateForAddOrUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupCreateRuleValidateForAddOrUpdateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR;

@Component
@BusinessAbility
public class BrandSelfAdgroupCreateRuleValidateForAddOrUpdateAbility implements IAdgroupCreateRuleValidateForAddOrUpdateAbility, BrandSelfServiceAtomAbilityRouter {
    @Resource
    private  CampaignGroupRepository campaignGroupRepository;
    @Override
    public Void handle(ServiceContext serviceContext, AdgroupCreateRuleValidateForAddOrUpdateAbilityParam abilityParam) {
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();
        AdgroupViewDTO adgroupViewDTO = abilityParam.getAbilityTarget();
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        //打底单元不校验
        if (!adgroupViewDTO.getBottomType().equals(BrandAdgroupBottomTypeEnum.NORMAL.getCode())){
            return null;
        }

        Integer campaignStatus = campaignViewDTO.getStatus();
        Integer campaignGroupStatus= campaignGroupViewDTO.getStatus();

        AssertUtil.notNull(campaignViewDTO.getCampaignSaleViewDTO().getSaleType(),BIZ_BREAK_RULE_ERROR,"计划信息不完整，不允许新建单元，请联系管理员");
        if (campaignViewDTO.getCampaignSaleViewDTO().getSaleType().equals(BrandSaleTypeEnum.BUY.getCode())){
            AssertUtil.assertTrue((AdgroupCreateValidateConstant.MAIN_CAMPAIGN_STATUS_LIST_GROUP1.contains(campaignStatus) &&
                    AdgroupCreateValidateConstant.MAIN_CAMPAIGN_X_CAMPAIGN_GROUP_STATUS_LIST_GROUP1.contains(campaignGroupStatus)) ||
                    (AdgroupCreateValidateConstant.MAIN_CAMPAIGN_STATUS_LIST_GROUP2.contains(campaignStatus) &&
                            AdgroupCreateValidateConstant.MAIN_CAMPAIGN_X_CAMPAIGN_GROUP_STATUS_LIST_GROUP2.contains(campaignGroupStatus)),BIZ_BREAK_RULE_ERROR,"订单和计划状态不正确，不允许新建单元，请检查后重试");

        }else{
            AssertUtil.assertTrue(AdgroupCreateValidateConstant.OTHER_CAMPAIGN_STATUS_LIST.contains(campaignStatus),BIZ_BREAK_RULE_ERROR,"计划状态不正确，不允许新建单元，请检查后重试");

        }
        return null;
    }
}
