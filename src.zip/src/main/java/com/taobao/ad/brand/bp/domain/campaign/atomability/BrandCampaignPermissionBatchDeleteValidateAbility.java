package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignPermissionBatchDeleteValidateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignDeleteValidateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandCampaignPermissionBatchDeleteValidateAbility implements ICampaignPermissionBatchDeleteValidateAbility, BrandAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignDeleteValidateAbilityParam abilityParam) {
        AssertUtil.assertTrue(ServiceContextUtil.isAliStaff(serviceContext), "当前功能暂不支持商家操作，请联系妈妈小二协助操作。");
        return null;
    }
}
