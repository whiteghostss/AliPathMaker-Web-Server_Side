package com.taobao.ad.brand.bp.domain.memeber;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.dto.shop.ShopViewDTO;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author jixiu.lj
 * @date 2023/3/21 09:49
 */
public interface MemberRepository {
    /**
     * 根据memberId获取名称
     *
     * @param memberId
     * @return
     */
    String getTbNickNameByMemberId(Long memberId);

    /**
     * 根据memberid查询关联的有哪些uic rolecode
     *
     * @param memberId
     * @return
     */
    Set<String> findRoleCodeByMemberId(Long memberId);

    /**
     * 根据tbUserId获取memberId
     * @param tbUserId
     * @return
     */
    Long getMemberIdByTbNumId(Long tbUserId);

    /**
     * 查询member名称
     */
    String getMemberNameById(Long memberId);

    /**
     * 查询member显示名称
     * @param memberId
     * @return
     */
    String getMemberDisplayNameById(Long memberId);

    /**
     * 查询叉乘账号显示名称
     * @param memberIds
     * @return
     */
    Map<Long, String> queryXMemberDisplayNameMap(List<Long> memberIds);

    /**
     * 查询member_id账户关联真实member_id
     * 商家账户：返回当前member_id
     * 代理叉乘账号：返回关联member_id
     * @param memberId
     * @return
     */
    Long getTargetMemberIdByMemberId(Long memberId);

    Long getTargetMemberIdByMemberId(Long memberId, Integer relMemberType);

    /**
     * 获取当前登录用户的客户类型
     * @param memberId
     * @return
     */
    Integer getRelMemberType(Long memberId);

    /**
     * member_id转入结果集
     *
     * @param context
     * @param memberId
     * @return 准入的场景bizCode
     */
    List<String> getJoinResult(ServiceContext context, Long memberId, List<String> supportScenceCodeList);

    /**
     * 查询ssp产品线准入结果
     * @param context
     * @param memberId
     * @param supportSspCodeList
     * @return
     */
    List<String> getSspJoinResult(ServiceContext context, Long memberId, List<String> supportSspCodeList);

    /**
     * 根据客户memberID查询店铺
     * @param cusMemberId
     * @return
     */
     ShopViewDTO getShopByMemberId(Long cusMemberId);

    Long getTbNumIdByMemberId(Long memberId);

    /**
     * 是否是叉乘账号
     * @param memberId 帐号
     * @return 是否
     */
     Boolean isAgencyX(Long memberId);

    /**
     * 查询代理商叉乘用户的代理用户
     * @param memberId 叉乘账号
     * @return 代理用户
     */
    Long queryAgencyMemberId(Long memberId);
}
