package com.taobao.ad.brand.bp.domain.config;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.domain.config.base.BaseDiamondConfig;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 自助订单授信合同账号配置
 * For测试
 * */
@Component
public class SelfServiceTestMemberConfig extends BaseDiamondConfig {
    /**
     * 自助合同授信白名单List
     */
    private static volatile List<Long> selfContractCreditMemberIds;
    /**
     * 自助订单SPU门槛白名单List
     */
    private static volatile List<Long> selfSpuMarketingRuleMemberIds;

    /**
     * 测试member账号
     */
    private static volatile List<Long> filterMemberIds;

    /**
     * 测试member账号
     */
    private static volatile List<Long> filterCustomerIds;

    private static final String SELF_CONTRACT_CREDIT_MEMBER_ID_KEY = "selfContractCreditMemberIds";
    private static final String SELF_SPU_MARKETING_RULE_MEMBER_ID_KEY = "selfSpuMarketingRuleMemberIds";

    private static final String FILTER_MEMBER_IDS_KEY = "filterMemberIds";

    private static final String FILTER_CUSTOMER_IDS_KEY = "filterCustomerIds";



    @Override
    protected String getDataId() {
        return "com.taobao.ad.brand.perform.diamond.FilterCustomerMemberDiamond";
    }
    @Override
    protected String getGroupId() { return "brand_perform_config"; }

    @Override
    protected void initDiamond(String diamondConfig) {
        RogerLogger.info("DiamondConfig.initDiamond SelfContractCreditPayTypeMemberConfig param: {}", diamondConfig);
        if (StringUtils.isNotBlank(diamondConfig)) {
            Map<String, List<Long>> configMap = JSONObject.parseObject(diamondConfig, new TypeReference<HashMap<String, List<Long>>>(){});
            if (configMap.containsKey(SELF_CONTRACT_CREDIT_MEMBER_ID_KEY)) {
                selfContractCreditMemberIds = configMap.getOrDefault(SELF_CONTRACT_CREDIT_MEMBER_ID_KEY, Lists.newArrayList());
            } else {
                selfContractCreditMemberIds = Lists.newArrayList();
            }
            if (configMap.containsKey(SELF_SPU_MARKETING_RULE_MEMBER_ID_KEY)) {
                selfSpuMarketingRuleMemberIds = configMap.getOrDefault(SELF_SPU_MARKETING_RULE_MEMBER_ID_KEY, Lists.newArrayList());
            } else {
                selfSpuMarketingRuleMemberIds = Lists.newArrayList();
            }
            if (configMap.containsKey(FILTER_MEMBER_IDS_KEY)) {
                filterMemberIds = configMap.getOrDefault(FILTER_MEMBER_IDS_KEY, Lists.newArrayList());
            } else {
                filterMemberIds = Lists.newArrayList();
            }
            if (configMap.containsKey(FILTER_CUSTOMER_IDS_KEY)) {
                filterCustomerIds = configMap.getOrDefault(FILTER_CUSTOMER_IDS_KEY, Lists.newArrayList());
            } else {
                filterCustomerIds = Lists.newArrayList();
            }
        } else {
            selfContractCreditMemberIds = Lists.newArrayList();
            selfSpuMarketingRuleMemberIds = Lists.newArrayList();
            filterMemberIds = Lists.newArrayList();
            filterCustomerIds = Lists.newArrayList();
        }
    }

    /**
     * 查询自助订单支持合同授信的账号
     * @return
     */
    public List<Long> getSelfContractCreditPayTypeMemberList() {
        return selfContractCreditMemberIds;
    }

    public List<Long> getSelfSpuMarketingRuleMemberList() {
        return selfSpuMarketingRuleMemberIds;
    }

    /**
     * 查询测试member
     */
    public List<Long> getFilterMemberIdList() {
        return filterMemberIds;
    }

    /**
     * 查询测试客户
     */
    public List<Long> getFilterCustomerIdList() {
        return filterCustomerIds;
    }
}
