package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.adzone.CampaignAdzoneViewDTO;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.threadpooltask.CampaignBatchAddTaskIdentifier;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignAdzoneBatchAddAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignAdzoneBatchAbilityParam;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component
@BusinessAbility
public class DefaultCampaignAdzoneBatchAddAbility implements ICampaignAdzoneBatchAddAbility {

    @Resource
    private  CampaignBatchAddTaskIdentifier campaignBatchAddTaskIdentifier;

    @Resource
    private CampaignRepository campaignRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignAdzoneBatchAbilityParam abilityParam) {
        List<CampaignAdzoneViewDTO> campaignAdzoneViewDTOList = abilityParam.getAbilityTargets();
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();
        AssertUtil.notNull(campaignViewDTO,"广告位新增异常，计划为空！");
        AssertUtil.notNull(campaignViewDTO.getId(),"广告位新增异常，计划ID为空！");
        AssertUtil.notEmpty(campaignAdzoneViewDTOList,"广告位为空！");
        TaskStream.execute(campaignBatchAddTaskIdentifier, Lists.newArrayList(campaignViewDTO), (item, index) -> addCampaignAdzone(serviceContext, item)).commit().getResultList();
        return null;
    }


    private Void addCampaignAdzone(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {
        try {
            //计划保存
            campaignRepository.addCampaignAdzone(serviceContext, Lists.newArrayList(campaignViewDTO));
        } catch (Exception e) {
            RogerLogger.error(String.format("计划广告位保存异常，计划=%s", JSON.toJSONString(campaignViewDTO)),e);
            throw new BrandOneBPException("计划保存异常",e);
        }
        return null;
    }


}
