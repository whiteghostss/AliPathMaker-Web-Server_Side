package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.biz.definition.constants.UniversalCampaignModel;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.guarantee.CampaignGuaranteeViewDTO;
import com.alibaba.ad.brand.dto.campaign.smartreserved.CampaignSmartReservedViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignSmartReservedInitForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignSmartReservedAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandCampaignSmartReservedInitForUpdateCampaignAbility implements ICampaignSmartReservedInitForUpdateCampaignAbility, BrandAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignSmartReservedAbilityParam abilityParam) {
        CampaignSmartReservedViewDTO smartReservedViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        AssertUtil.notNull(smartReservedViewDTO,"计划智能预留信息不能为空");
        AssertUtil.notNull(campaignViewDTO,"计划不能为空");
        AssertUtil.notNull(dbCampaignViewDTO,"计划不存在");
        //二环PDB一级计划更新场景
        if(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode().equals(dbCampaignViewDTO.getCampaignLevel())
                && Objects.equals(UniversalCampaignModel.TAO_ECOLOGY_TWO_PDB.getId(),dbCampaignViewDTO.getCampaignModel())){
            if(BrandBoolEnum.BRAND_TRUE.getCode().equals(smartReservedViewDTO.getIsCopyMainDeal())){
                smartReservedViewDTO.setPubDealId(campaignViewDTO.getCampaignBoostViewDTO().getSourceCampaignId());
            } else if (BrandBoolEnum.BRAND_TRUE.getCode().equals(smartReservedViewDTO.getIsCopyOtherDeal())) {
                smartReservedViewDTO.setPubDealId(smartReservedViewDTO.getPubDealId());
            } else{
                smartReservedViewDTO.setPubDealId(campaignViewDTO.getId());
            }
            //【二环PDB】是否启动打底素材（界面不展示，底层默认逻辑）：与推送比联动，推送比为100%，默认为“是” 且不可修改；推送比为非100%，默认为“否” 且不可修改
            smartReservedViewDTO.setIsSupportBottomMaterial(BrandBoolEnum.BRAND_FALSE.getCode());
            Long sspPushSendRatio = Optional.ofNullable(campaignViewDTO.getCampaignGuaranteeViewDTO())
                    .map(CampaignGuaranteeViewDTO::getSspPushSendRatio).map(Long::valueOf).orElse(0L);
            if(Objects.equals(sspPushSendRatio, Constant.RATIO_100)){
                smartReservedViewDTO.setIsSupportBottomMaterial(BrandBoolEnum.BRAND_TRUE.getCode());
            }
        }
        return null;
    }
}
