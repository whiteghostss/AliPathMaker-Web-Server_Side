package com.taobao.ad.brand.bp.domain.report.ability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.taobao.ad.brand.bp.client.dto.report.ReportDimensionInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportMetricsConfigViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.query.ReportQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.report.ReportMetricsTypeEnum;
import com.taobao.ad.brand.bp.common.spi.ExtensionPointsFactory;
import com.taobao.ad.brand.bp.common.util.CallTask;
import com.taobao.ad.brand.bp.domain.adr.ReportCenterRepository;
import com.taobao.ad.brand.bp.domain.report.repository.ReportAdcRepository;
import com.taobao.ad.brand.bp.domain.report.spi.report.calculate.BizReportCalculateRuleSpi;
import com.taobao.ad.brand.bp.domain.report.spi.report.dimensioninfo.BizReportDimensionInfoSpi;
import com.taobao.ad.brand.bp.domain.report.spi.report.metrics.BizReportMetricsFormatSpi;
import com.taobao.ad.brand.bp.domain.report.spi.report.process.BizReportValuePreProcessSpi;
import com.taobao.ad.brand.bp.domain.report.spi.report.query.BizReportQuerySpi;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * 报表数据查询能力定义
 * @author yuncheng.lyc
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizReportQueryAbility {
    private final ReportCenterRepository reportCenterRepository;

    private final ReportAdcRepository reportAdcRepository;

    private static final ThreadPoolExecutor EXCEL_THREAD_POOL = new ThreadPoolExecutor(
            Runtime.getRuntime().availableProcessors(), Runtime.getRuntime().availableProcessors(), 60L, TimeUnit.SECONDS, new ArrayBlockingQueue<>(200),
            new ThreadFactoryBuilder().setNameFormat("brandOneBP_report_task- %d").build());
    private static final int THREAD_TIMEOUT_SECOND = 600;

    /**
     * 获取当前查询条件数据明细
     * @param context
     * @param queryViewDTO
     * @return
     */
    public List<Map<String, Object>> findDataList(ServiceContext context, ReportQueryViewDTO queryViewDTO, List<ReportMetricsConfigViewDTO> metricsList){
        processAdrUniqueKey(context, queryViewDTO);
        processAdrSelectMetrics(context, queryViewDTO, metricsList);
        processAdrNotInMetrics(context, queryViewDTO, metricsList);
        return reportCenterRepository.findData(queryViewDTO.getConditions());
    }

    /**
     * 设置报表中心查询API，优先从参数中获取
     * 再次选择维度上配置的API
     * 最后看功能上配置的API
     * @param context
     * @param queryViewDTO
     */
    public void processAdrUniqueKey(ServiceContext context, ReportQueryViewDTO queryViewDTO){
        reportAdcRepository.findAdcAdrApiConfig(context, queryViewDTO);
    }

    /**
     * 设置报表中心查询参数
     * select 的指标
     * @param context
     * @param queryViewDTO
     */
    public void processAdrSelectMetrics(ServiceContext context, ReportQueryViewDTO queryViewDTO, List<ReportMetricsConfigViewDTO> metricsList){
        metricsList.forEach(m->queryViewDTO.addConditionVal(m.getCode(), true));
    }

    /**
     * 设置报表中心查询参数
     * where not in的参数
     * @param context
     * @param queryViewDTO
     */
    public void processAdrNotInMetrics(ServiceContext context, ReportQueryViewDTO queryViewDTO, List<ReportMetricsConfigViewDTO> metricsList){
        metricsList.forEach(m->{
            if(CollectionUtils.isEmpty(m.getIllegalValues())){
                return;
            }
            queryViewDTO.addConditionVal(m.getCode()+"NotIn", m.getIllegalValues());
        });
    }

    /**
     * 多线程获取数据(近期去掉并发请求，全部修改为顺序请求)
     * @param context
     * @param queryViewDTO
     * @param metricsMap
     * @param function
     * @return
     */
    public Map<String, List<Map<String, Object>>> findDataListMultiThread(ServiceContext context, ReportQueryViewDTO queryViewDTO, Map<String, List<ReportMetricsConfigViewDTO>> metricsMap,
            Function<String, List<Map<String, Object>>> function) {
        Map<String, List<Map<String, Object>>> result = Maps.newHashMap();
        try {
            List<Future<Map<String, List<Map<String, Object>>>>> futures = Lists.newArrayList();
            //long sleepTime = 1;
            for (Map.Entry<String, List<ReportMetricsConfigViewDTO>> entry : metricsMap.entrySet()) {
                //Thread.sleep(sleepTime);
                Future future = EXCEL_THREAD_POOL.submit(
                        new CallTask<Map<String, List<Map<String, Object>>>>() {
                            @Override
                            public Map<String, List<Map<String, Object>>> doCall() {
                                Map<String, List<Map<String, Object>>> map = Maps.newHashMap();
                                map.put(entry.getKey(), function.apply(entry.getKey()));
                                return map;
                            }
                        });
                //sleepTime = sleepTime+2000;
                futures.add(future);
            }
            for (Future<Map<String, List<Map<String, Object>>>> future : futures) {
                Map<String, List<Map<String, Object>>> dataListMap = future.get(THREAD_TIMEOUT_SECOND, TimeUnit.SECONDS);
                if(dataListMap == null){
                    continue;
                }
                result.putAll(dataListMap);
            }
            return result;
        } catch (Exception e) {
            RogerLogger.error("报表多线程获取数据失败", e);
            throw new RuntimeException(e);
        }
    }

    /**
     * 顺序获取数据
     * @param context
     * @param queryViewDTO
     * @param metricsMap
     * @param function
     * @return
     */
    public Map<String, List<Map<String, Object>>> findDataListSequence(ServiceContext context, ReportQueryViewDTO queryViewDTO, Map<String, List<ReportMetricsConfigViewDTO>> metricsMap,
                                                                          Function<String, List<Map<String, Object>>> function) {
        Map<String, List<Map<String, Object>>> result = Maps.newHashMap();
        try {
            for (Map.Entry<String, List<ReportMetricsConfigViewDTO>> entry : metricsMap.entrySet()) {
                result.put(entry.getKey(), function.apply(entry.getKey()));
            }
            return result;
        } catch (Exception e) {
            RogerLogger.error("报表顺序获取数据失败", e);
            throw new RuntimeException(e);
        }
    }

    /**
     * 获取当前查询条件数据明细
     * 直接查询报表中心sql
     * @param context
     * @param queryMap
     * @return
     */
    public List<Map<String, Object>> findDataList(ServiceContext context, Map<String, Object> queryMap){
        return reportCenterRepository.findData(queryMap);
    }

    /**
     * 对查询的数据进行数据处理
     * 1、数据预处理；2、违法数据过滤；3、据格式化；
     * 4、维度属性翻译；5、其他数据集合进行逻辑join；
     * 6、指标计算（不能在sql中计算的指标，按照adc的配置进行计算）
     * @param context
     * @param queryViewDTO
     * @param reportDataList
     * @param metricsList
     * @return
     */
    public List<Map<String, Object>> processDataList(ServiceContext context, ReportQueryViewDTO queryViewDTO, List<Map<String, Object>> reportDataList, List<ReportMetricsConfigViewDTO> metricsList){
        //对报表中心返回数据进行预处理
        List<Map<String, Object>> preProcessedDataList = preProcessDataList(context, queryViewDTO, reportDataList, metricsList);
        //对报表中心返回数据进行违法数据过滤
        List<Map<String, Object>> cleanedDataList = cleaningDataList(context, queryViewDTO, preProcessedDataList, metricsList);
        //对报表中心返回数据进数据格式化
        List<Map<String, Object>> formatDataList = formatDataList(context, queryViewDTO, cleanedDataList, metricsList);
        //对报表中心返回数据进行维度属性翻译
        List<Map<String, Object>> filledDataList = fillDataList(context, queryViewDTO, formatDataList, metricsList);
        //与其他数据集合进行逻辑join
        List<Map<String, Object>> joinDataList =  joinDataList(context, queryViewDTO, filledDataList);
        //指标计算（不能在sql中计算的指标，按照adc的配置进行计算）
        return calculateMetricsDataList(context, queryViewDTO, joinDataList, metricsList);
    }

    /**
     * 返回数据进行预处理
     * @param context
     * @param queryViewDTO
     * @param reportDataList
     * @param metricsList
     * @return
     */
    public List<Map<String, Object>> preProcessDataList(ServiceContext context, ReportQueryViewDTO queryViewDTO, List<Map<String, Object>> reportDataList, List<ReportMetricsConfigViewDTO> metricsList){
        if(CollectionUtils.isEmpty(reportDataList)){
            return Lists.newArrayList();
        }
        for(Map<String, Object> reportData: reportDataList){
            for (ReportMetricsConfigViewDTO metrics : metricsList) {
                if(Objects.nonNull(metrics.getDefaultValue()) && (!reportData.containsKey(metrics.getCode()) || Objects.isNull(reportData.get(metrics.getCode())))){
                    //如果配置了默认值，并且返回的值为空，补充默认值
                    reportData.put(metrics.getCode(), metrics.getDefaultValue());
                }else if(Objects.isNull(metrics.getDefaultValue()) && (!reportData.containsKey(metrics.getCode()) || Objects.isNull(reportData.get(metrics.getCode())))){
                    //如果没有配置默认值，并且返回的值为空，补充0
                    reportData.put(metrics.getCode(), 0);
                }
            }
        }
        return reportDataList;
    }

    /**
     * 返回数据进行违法数据过滤
     * @param context
     * @param queryViewDTO
     * @param reportDataList
     * @param metricsList
     * @return
     */
    public List<Map<String, Object>> cleaningDataList(ServiceContext context, ReportQueryViewDTO queryViewDTO, List<Map<String, Object>> reportDataList, List<ReportMetricsConfigViewDTO> metricsList){
        if(CollectionUtils.isEmpty(reportDataList)){
            return Lists.newArrayList();
        }
        List<Map<String, Object>> filterDataList = Lists.newArrayList();
        for (Map<String, Object> reportData : reportDataList) {
            //是否过滤标记
            boolean filter = false;
            for (ReportMetricsConfigViewDTO metrics : metricsList) {
                //违法数值没有配置，不进行过滤
                if (CollectionUtils.isEmpty(metrics.getIllegalValues())) {
                    continue;
                }
                List<String> illegalValues = metrics.getIllegalValues().stream().distinct().collect(Collectors.toList());
                //命中配置的过滤值，该数据会被过滤
                String value = reportData.get(metrics.getCode()).toString();
                if (illegalValues.contains(value)) {
                    filter = true;
                    RogerLogger.info("cleaningDataList：字段{}={}不合法，被过滤，字段过滤配置：{}", metrics.getCode(), value, metrics.getIllegalValues());
                    break;
                }
            }
            if (!filter) {
                filterDataList.add(reportData);
            }
        }
        return filterDataList;
    }

    /**
     * 返回数据进行违法数据格式化
     * @param context
     * @param queryViewDTO
     * @param reportDataList
     * @param metricsList
     * @return
     */
    public List<Map<String, Object>> formatDataList(ServiceContext context, ReportQueryViewDTO queryViewDTO, List<Map<String, Object>> reportDataList, List<ReportMetricsConfigViewDTO> metricsList){
        if(CollectionUtils.isEmpty(reportDataList)){
            return Lists.newArrayList();
        }
        for (Map<String, Object> reportData : reportDataList) {
            for (ReportMetricsConfigViewDTO metrics : metricsList) {
                if(!reportData.containsKey(metrics.getCode()) || StringUtils.isBlank(metrics.getFormat())){
                    continue;
                }
                //维表关联的属性值，不进行格式化
                if(StringUtils.isNotBlank(metrics.getRelationCode())){
                    continue;
                }
                Object formatValue = ExtensionPointsFactory.runAbilitySpi(BizReportMetricsFormatSpi.class, extension->extension.format(reportData.get(metrics.getCode()), queryViewDTO.getTotalType()), metrics.getFormat());
                reportData.put(metrics.getCode(), formatValue);
            }
        }
        return reportDataList;
    }

    /**
     * 返回数据进行维度属性翻译
     * @param context
     * @param queryViewDTO
     * @param reportDataList
     * @param metricsList
     * @return
     */
    public List<Map<String, Object>> fillDataList(ServiceContext context, ReportQueryViewDTO queryViewDTO, List<Map<String, Object>> reportDataList, List<ReportMetricsConfigViewDTO> metricsList){
        if(CollectionUtils.isEmpty(reportDataList)){
            return Lists.newArrayList();
        }
        Map<String, List<ReportMetricsConfigViewDTO>> relationCodeMap = parseFromMetricsConfig(metricsList);
        if(MapUtils.isEmpty(relationCodeMap)){
            return reportDataList;
        }
        List<Map<String, Object>> filterReportDataList = reportDataList;
        for(Map.Entry<String, List<ReportMetricsConfigViewDTO>> entry: relationCodeMap.entrySet()){
            List<ReportMetricsConfigViewDTO> relateCodeMetricsList = entry.getValue();
            //获取配置的relateCode对应的维度code，用于查询对应维度的实体
            queryViewDTO.setDimensionCode(relateCodeMetricsList.get(0).getDimension().getCode());
            Map<String, ReportDimensionInfoViewDTO> dimensionMap = ExtensionPointsFactory.runAbilitySpi(BizReportDimensionInfoSpi.class,
                    extension -> extension.dimensionInfoMap(context, queryViewDTO, entry.getKey(), reportDataList, metricsList), entry.getKey());

            //数据不为空，执行数据过滤
            if (MapUtils.isNotEmpty(dimensionMap)) {
                filterReportDataList = ExtensionPointsFactory.runAbilitySpi(BizReportDimensionInfoSpi.class,
                        extension -> extension.dimensionDataFilter(context, entry.getKey(), dimensionMap, reportDataList), entry.getKey());
            }else{
                RogerLogger.info("维度" + queryViewDTO.getDimensionCode() + "未找对应实体信息");
            }
            for (Map<String, Object> reportData : filterReportDataList) {
                for (ReportMetricsConfigViewDTO metrics : relateCodeMetricsList) {
                    String code = metrics.getCode();
                    if(!reportData.containsKey(entry.getKey())){
                        RogerLogger.info("BizReportQueryAbility.fillDataList.reportData" + JSON.toJSONString(reportData)+", key="+entry.getKey());
                        continue;
                    }
                    RogerLogger.info("BizReportQueryAbility.fillDataList.reportData" + JSON.toJSONString(reportData)+", key="+entry.getKey());
                    String id = reportData.get(entry.getKey()).toString();
                    if(dimensionMap == null || !dimensionMap.containsKey(id)){
                        RogerLogger.info("维度"+queryViewDTO.getDimensionCode()+"未找对应id="+id+"实体信息");
                        continue;
                    }
                    ReportDimensionInfoViewDTO model = dimensionMap.get(id);
                    Object value = model == null ? "" : model.getPropertyVal(code);
                    //如果，配置的计算列，将计算的字段key 也顺便加进map
                    if(StringUtils.isNotEmpty(metrics.getFirstMetricsKey())) {
                        Object firstMetricsVal = model.getPropertyVal(metrics.getFirstMetricsKey());
                        if (Objects.nonNull(firstMetricsVal)) {
                            reportData.put(metrics.getFirstMetricsKey(), firstMetricsVal);
                        }
                    }
                    if(StringUtils.isNotEmpty(metrics.getSecondMetricsKey())) {
                        Object secondMetricsVal = model.getPropertyVal(metrics.getSecondMetricsKey());
                        if (Objects.nonNull(secondMetricsVal)) {
                            reportData.put(metrics.getSecondMetricsKey(), model.getPropertyVal(metrics.getSecondMetricsKey()));
                        }
                    }
                    //对填充后的结果预处理
                    Object preProcessValue = ExtensionPointsFactory.runAbilitySpi(BizReportValuePreProcessSpi.class, extension -> extension.preProcess(queryViewDTO, reportData, value), code);
                    //对填充后的结果进行format
                    Object formatValue = ExtensionPointsFactory.runAbilitySpi(BizReportMetricsFormatSpi.class, extension->extension.format(preProcessValue, queryViewDTO.getTotalType()), metrics.getFormat());

                    reportData.put(code, formatValue);
                }
            }
        }
        return filterReportDataList;
    }

    /**
     * 返回adc上配置的维度字段管理关系
     * @param metricsList
     * @return Map<campaignId, List<campaignName, campaignModel>>
     */
    private Map<String, List<ReportMetricsConfigViewDTO>> parseFromMetricsConfig(List<ReportMetricsConfigViewDTO> metricsList){
        Map<String, List<ReportMetricsConfigViewDTO>> result = Maps.newHashMap();
        if(CollectionUtils.isEmpty(metricsList)){
            return result;
        }
        for(ReportMetricsConfigViewDTO metrics: metricsList){
            if(StringUtils.isBlank(metrics.getRelationCode())){
                continue;
            }
            if(result.containsKey(metrics.getRelationCode())){
                result.get(metrics.getRelationCode()).add(metrics);
            }else{
                result.put(metrics.getRelationCode(), Lists.newArrayList(metrics));
            }
        }
        return result;
    }

    /**
     * 对报表结果集就行额外的数据关联
     * 特别针对跨库的数据关联
     * @param context
     * @param queryViewDTO
     * @param reportDataList
     * @return
     */
    private List<Map<String, Object>> joinDataList(ServiceContext context, ReportQueryViewDTO queryViewDTO, List<Map<String, Object>> reportDataList){
        return ExtensionPointsFactory.runAbilitySpi(BizReportQuerySpi.class, extension->extension.joinDataList(context, queryViewDTO, reportDataList), queryViewDTO.getFunctionCode());
    }

    /**
     * 根据用户权限做数据指标权限过滤
     * @param context
     * @param dataList
     * @param metricsList
     * @return
     */
    public List<Map<String, Object>> metricsPermissionFilter(ServiceContext context, List<Map<String, Object>> dataList, List<ReportMetricsConfigViewDTO> metricsList){
        if(CollectionUtils.isEmpty(dataList)){
            return Lists.newArrayList();
        }
        List<Map<String, Object>> filterResult = Lists.newArrayList();
        Map<String, ReportMetricsConfigViewDTO> metricsMap = metricsList.stream().collect(Collectors.toMap(ReportMetricsConfigViewDTO::getCode, m->m, (v1, v2) -> v1));
        for(Map<String, Object> data: dataList){
            Map<String, Object> filterMap = Maps.newHashMap();
            for(Map.Entry<String, Object> entry: data.entrySet()){
                if(metricsMap.containsKey(entry.getKey())){
                    filterMap.put(entry.getKey(), entry.getValue());
                }
            }
            if(MapUtils.isEmpty(filterMap)){
                continue;
            }
            filterResult.add(filterMap);
        }
        return filterResult;
    }

    /**
     * 如果没有品牌id，需要将后链路指标处理成null
     * @param serviceContext
     * @param queryViewDTO
     * @param dataList
     * @param metricsList
     */
    public List<Map<String, Object>> processDataListNoBrandCondition(ServiceContext serviceContext, ReportQueryViewDTO queryViewDTO, List<Map<String, Object>> dataList, List<ReportMetricsConfigViewDTO> metricsList){
        if((queryViewDTO.getConditions().containsKey("brandIdEqual") && Objects.nonNull(queryViewDTO.getConditions().get("brandIdEqual")))
                || (queryViewDTO.getConditions().containsKey("brandIdIn") && Objects.nonNull(queryViewDTO.getConditions().get("brandIdIn")))) {
            return dataList;
        }
        Map<String, ReportMetricsConfigViewDTO> metricsConfigViewDTOMap = metricsList.stream().collect(Collectors.toMap(ReportMetricsConfigViewDTO::getCode, m->m, (v1, v2) -> v1));

        List<Map<String, Object>> handledDataList = Lists.newArrayList();
        for(Map<String, Object> data: dataList){
            Map<String, Object> copyData = Maps.newHashMap();
            for(String metricsCode: data.keySet()){
                if(!metricsConfigViewDTOMap.containsKey(metricsCode)){
                    continue;
                }
                String metricsType = metricsConfigViewDTOMap.get(metricsCode).getType();
                copyData.put(metricsCode, data.get(metricsCode));
                if(ReportMetricsTypeEnum.of(metricsType) == ReportMetricsTypeEnum.BACKEND){
                    copyData.put(metricsCode, null);
                }
            }
            handledDataList.add(copyData);
        }
        return handledDataList;
    }

    /**
     * 根据adc配置指标计算规则进行计算，并进行指标格式化
     * @param context
     * @param queryViewDTO
     * @param reportDataList
     * @param metricsList
     * @return
     */
    public List<Map<String, Object>> calculateMetricsDataList(ServiceContext context, ReportQueryViewDTO queryViewDTO, List<Map<String, Object>> reportDataList, List<ReportMetricsConfigViewDTO> metricsList) {
        if(CollectionUtils.isEmpty(reportDataList)){
            return Lists.newArrayList();
        }
        for (Map<String, Object> reportData : reportDataList) {
            for (ReportMetricsConfigViewDTO metrics : metricsList) {
                if(StringUtils.isBlank(metrics.getFirstMetricsKey()) || StringUtils.isBlank(metrics.getSecondMetricsKey()) || StringUtils.isBlank(metrics.getFlag())){
                    continue;
                }
                if(!reportData.containsKey(metrics.getFirstMetricsKey()) || !reportData.containsKey(metrics.getSecondMetricsKey())){
                    continue;
                }
                //计算指标
                Object calculatedValue = ExtensionPointsFactory.runAbilitySpi(BizReportCalculateRuleSpi.class, extension->extension.calculate(context, reportData, metrics.getFirstMetricsKey(), metrics.getSecondMetricsKey()), metrics.getFlag());
                //格式化计算后的指标
                Object formatValue = ExtensionPointsFactory.runAbilitySpi(BizReportMetricsFormatSpi.class, extension->extension.format(calculatedValue, queryViewDTO.getTotalType()), metrics.getFormat());

                reportData.put(metrics.getCode(), formatValue);
            }
        }
        return reportDataList;
    }

}
