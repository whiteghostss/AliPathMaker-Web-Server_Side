package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.threadpooltask.CampaignUpdateTaskIdentifier;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignUpdatePartAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBatchAbilityParam;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_REQUIRED;

@Component
@BusinessAbility
public class DefaultCampaignUpdatePartAbility implements ICampaignUpdatePartAbility {

    @Resource
    private CampaignUpdateTaskIdentifier campaignUpdateTaskIdentifier;

    @Resource
    private CampaignRepository campaignRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignBatchAbilityParam abilityParam) {
        List<CampaignViewDTO> campaignViewDTOList = abilityParam.getAbilityTargets();
        AssertUtil.notEmpty(campaignViewDTOList,"计划列表为空，不可更新");
        boolean hasAdd = campaignViewDTOList.stream().anyMatch(item -> item.getId() == null);
        AssertUtil.assertTrue(!hasAdd, PARAM_REQUIRED, "有计划id为空的数据");

        if(campaignViewDTOList.size() == 1){
            updateCampaignPart(serviceContext, campaignViewDTOList.get(0));
        }else{
            TaskStream.consume(campaignUpdateTaskIdentifier, campaignViewDTOList,
                            (campaignViewDTO, index) -> updateCampaignPart(serviceContext, campaignViewDTO))
                    .commit().getResultList();
        }
        return null;
    }


    private Void updateCampaignPart(ServiceContext serviceContext,  CampaignViewDTO campaignViewDTO) {

        try {
            // 修改计划基础信息
            campaignRepository.updateCampaignPart(serviceContext, campaignViewDTO);
        } catch (Exception e) {
            RogerLogger.error(String.format("计划部分更新异常，计划=%s", JSON.toJSONString(campaignViewDTO)),e);
            throw new BrandOneBPException("计划部分更新异常",e);
        }
        return null;
    }


}
