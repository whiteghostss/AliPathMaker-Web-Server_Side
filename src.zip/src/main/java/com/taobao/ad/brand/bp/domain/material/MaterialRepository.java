package com.taobao.ad.brand.bp.domain.material;

import com.taobao.ad.brand.bp.domain.creative.spi.impl.protocol.context.material.YkVideoDetail;

public interface MaterialRepository {
    YkVideoDetail getVideoFromYks(Long vid);
}
