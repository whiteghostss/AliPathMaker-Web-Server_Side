package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignStructureQueryAbilityParam;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
@BusinessAbility
public class BrandOneBPCampaignStructureQueryAbility
        extends DefaultCampaignStructureQueryAbility implements BrandOneBPAtomAbilityRouter {
    @Resource
    private CampaignRepository campaignRepository;

    @Override
    public List<CampaignViewDTO> handle(ServiceContext context, CampaignStructureQueryAbilityParam abilityParam) {
        CampaignQueryViewDTO query = abilityParam.getAbilityTarget();
        CampaignQueryOption option = abilityParam.getQueryOption();
        //查询计划
        List<CampaignViewDTO> campaignViewDTOList = campaignRepository.queryCampaignList(context, query);
        if (CollectionUtils.isEmpty(campaignViewDTOList)) {
            return Lists.newArrayList();
        }
        List<CampaignViewDTO> retCampaignList = Lists.newArrayList();
        Map<Integer, List<CampaignViewDTO>> campaignSceneMap = campaignViewDTOList.stream().collect(Collectors.groupingBy(CampaignViewDTO::getSceneId));
        for (Map.Entry<Integer, List<CampaignViewDTO>> map : campaignSceneMap.entrySet()) {
            ServiceContext sceneContext = ServiceContextUtil.getNewServiceContext(context, map.getKey());
            List<CampaignViewDTO> sceneCampaignList = processCampaignInfo(sceneContext, map.getValue(), option);
            retCampaignList.addAll(sceneCampaignList);
        }
        return retCampaignList;
    }
}
