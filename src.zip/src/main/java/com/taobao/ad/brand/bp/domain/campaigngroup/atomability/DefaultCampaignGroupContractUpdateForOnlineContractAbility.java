package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.contract.CampaignGroupContractViewDTO;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupContractUpdateForOnlineContractAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupContractUpdateForTransitCampaignGroupAbilityParam;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;

@Component
@BusinessAbility
public class DefaultCampaignGroupContractUpdateForOnlineContractAbility implements ICampaignGroupContractUpdateForOnlineContractAbility {
    @Resource
    private CampaignGroupRepository campaignGroupRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupContractUpdateForTransitCampaignGroupAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        if (!BizCampaignGroupToolsHelper.isSubCampaignGroup(campaignGroupViewDTO)) {
            return null;
        }
        CampaignGroupContractViewDTO campaignGroupContractViewDTO = abilityParam.getAbilityTarget();
        if (campaignGroupContractViewDTO.getContractFirstOnlineTime() != null) {
            return null;
        }
        campaignGroupContractViewDTO.setContractFirstOnlineTime(new Date());
        campaignGroupViewDTO.setCampaignGroupContractViewDTO(campaignGroupContractViewDTO);

        CampaignGroupViewDTO updateCampaignGroupViewDTO = new CampaignGroupViewDTO();
        updateCampaignGroupViewDTO.setId(campaignGroupViewDTO.getId());
        updateCampaignGroupViewDTO.setCampaignGroupContractViewDTO(new CampaignGroupContractViewDTO());
        updateCampaignGroupViewDTO.getCampaignGroupContractViewDTO().setContractFirstOnlineTime(campaignGroupContractViewDTO.getContractFirstOnlineTime());
        campaignGroupRepository.updateCampaignGroupPart(serviceContext, updateCampaignGroupViewDTO);

        return null;
    }
}
