package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupBoostGiveApplyCampaignDetailViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupBoostGiveApplyInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSaleOrderStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupAuditStatusEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleProductLineEnum;
import com.alibaba.ad.nb.packages.v2.client.error.ResourcePackageBaseErrorCode;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupApplyInfoValidateForUpdateSaleGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupApplyInfoAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.alibaba.ad.nb.packages.constant.common.EditModeConstant.SALE_GROUP_EDIT_MODE_BRAND_ALL_BEFORE_LOCKING;
import static com.alibaba.ad.nb.packages.constant.common.EditModeConstant.SALE_GROUP_EDIT_MODE_BRAND_NON_CAMPAIGNS;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultSaleGroupApplyInfoValidateForUpdateSaleGroupAbility implements ISaleGroupApplyInfoValidateForUpdateSaleGroupAbility {
    private final CampaignGroupRepository campaignGroupRepository;
    private final ResourcePackageRepository resourcePackageRepository;

    @Override
    public Void handle(ServiceContext serviceContext, SaleGroupApplyInfoAbilityParam abilityParam) {
        SaleGroupBoostGiveApplyInfoViewDTO applyInfoViewDTO = abilityParam.getAbilityTarget();
        CampaignGroupViewDTO campaignGroup = abilityParam.getCampaignGroup();
        SaleGroupInfoViewDTO mainSaleGroupInfoViewDTO = abilityParam.getMainSaleGroupInfoViewDTO();
        // 新建场景直接退出
        if (Objects.isNull(applyInfoViewDTO.getSaleGroupId())) {
            return null;
        }

        SaleGroupBoostGiveApplyInfoViewDTO oldSaleGroupBoostGiveApplyInfoViewDTO = Optional.of(mainSaleGroupInfoViewDTO.getBoostGiveApplyInfoList().stream()
                .filter(saleGroup -> applyInfoViewDTO.getSaleGroupId().equals(saleGroup.getSaleGroupId()))
                .findFirst()).get().orElse(null);
        AssertUtil.notNull(oldSaleGroupBoostGiveApplyInfoViewDTO, "非百灵申请的补量/配送分组，不允许编辑");

        SaleGroupInfoViewDTO oldSaleGroupInfoViewDTO = campaignGroupRepository.getSaleGroup(serviceContext, campaignGroup.getId(), applyInfoViewDTO.getSaleGroupId());
        ResourcePackageSaleGroupViewDTO oldResourcePackageSaleGroupDTO = resourcePackageRepository.getSaleGroupWithEditMode(serviceContext, applyInfoViewDTO.getSaleGroupId());

        AssertUtil.assertTrue(!Lists.newArrayList(SaleGroupAuditStatusEnum.AUDIT_ING.getValue(), SaleGroupAuditStatusEnum.WAIT_AUDIT.getValue()).contains(oldResourcePackageSaleGroupDTO.getAuditStatus()),
                ResourcePackageBaseErrorCode.BIZ_BREAK_RULE_ERROR, "当前分组在审核中，不允许编辑");

        BrandSaleTypeEnum saleTypeEnum = BrandSaleTypeEnum.getByCode(applyInfoViewDTO.getSaleType());
        if (saleTypeEnum == BrandSaleTypeEnum.BOOST) {
            AssertUtil.assertTrue(applyInfoViewDTO.getReasonType().equals(oldSaleGroupBoostGiveApplyInfoViewDTO.getReasonType()), "补量原因不可修改");
        }

        if (!(applyInfoViewDTO.getStartDate().equals(oldResourcePackageSaleGroupDTO.getStartDate())) || !(applyInfoViewDTO.getEndDate().equals(oldResourcePackageSaleGroupDTO.getEndDate()))) {
            AssertUtil.assertTrue(Objects.isNull(oldSaleGroupInfoViewDTO) || BrandCampaignGroupSaleOrderStatusEnum.WAIT_ORDER.getCode().equals(oldSaleGroupInfoViewDTO.getSaleGroupStatus()),
                    ResourcePackageBaseErrorCode.BIZ_BREAK_RULE_ERROR, "当前分组已下单，不允许修改分组周期，请检查并修改后重试");

            if (!SALE_GROUP_EDIT_MODE_BRAND_NON_CAMPAIGNS.equals(oldResourcePackageSaleGroupDTO.getEditMode())) {
                AssertUtil.assertTrue(BrandDateUtil.isBeforeAndEqual(applyInfoViewDTO.getStartDate(), oldResourcePackageSaleGroupDTO.getStartDate())
                                && BrandDateUtil.isAfterAndEqual(applyInfoViewDTO.getEndDate(), oldResourcePackageSaleGroupDTO.getEndDate()),
                        ResourcePackageBaseErrorCode.BIZ_BREAK_RULE_ERROR, "当分组有计划时，分组周期修改时必修包含原周期");
            }
        }

        if (saleTypeEnum == BrandSaleTypeEnum.BOOST && SaleProductLineEnum.SINGLE_MEDIA_MARKING.getValue().equals(mainSaleGroupInfoViewDTO.getSaleProductLine())) {
            if (CollectionUtils.isNotEmpty(oldSaleGroupBoostGiveApplyInfoViewDTO.getCampaignDetailList()) || CollectionUtils.isNotEmpty(applyInfoViewDTO.getCampaignDetailList())) {
                if (!CollectionUtils.isEqualCollection(Optional.ofNullable(oldSaleGroupBoostGiveApplyInfoViewDTO.getCampaignDetailList()).orElse(Lists.newArrayList()).stream().map(SaleGroupBoostGiveApplyCampaignDetailViewDTO::getCampaignId).collect(Collectors.toList()),
                        Optional.ofNullable(applyInfoViewDTO.getCampaignDetailList()).orElse(Lists.newArrayList()).stream().map(SaleGroupBoostGiveApplyCampaignDetailViewDTO::getCampaignId).collect(Collectors.toList()))) {

                    AssertUtil.assertTrue((Objects.isNull(oldSaleGroupInfoViewDTO) || BrandCampaignGroupSaleOrderStatusEnum.WAIT_ORDER.getCode().equals(oldSaleGroupInfoViewDTO.getSaleGroupStatus()))
                                    && SALE_GROUP_EDIT_MODE_BRAND_NON_CAMPAIGNS.equals(oldResourcePackageSaleGroupDTO.getEditMode()),
                            "当前分组已下单或分组中存在计划，不允许新增或删除主计划，请检查并修改后重试");
                }
                if (CollectionUtils.isNotEmpty(oldSaleGroupBoostGiveApplyInfoViewDTO.getCampaignDetailList())) {
                    oldSaleGroupBoostGiveApplyInfoViewDTO.getCampaignDetailList().forEach(campaign -> {
                        SaleGroupBoostGiveApplyCampaignDetailViewDTO dto = Optional.of(Optional.ofNullable(applyInfoViewDTO.getCampaignDetailList()).orElse(Lists.newArrayList())
                                .stream().filter(x -> x.getCampaignId().equals(campaign.getCampaignId())).findFirst()).get().orElse(null);

                        if (Objects.nonNull(dto) && !campaign.getBudget().equals(dto.getBudget())) {
                            AssertUtil.assertTrue((Objects.isNull(oldSaleGroupInfoViewDTO) || BrandCampaignGroupSaleOrderStatusEnum.WAIT_ORDER.getCode().equals(oldSaleGroupInfoViewDTO.getSaleGroupStatus()))
                                            && Lists.newArrayList(SALE_GROUP_EDIT_MODE_BRAND_NON_CAMPAIGNS, SALE_GROUP_EDIT_MODE_BRAND_ALL_BEFORE_LOCKING).contains(oldResourcePackageSaleGroupDTO.getEditMode()),
                                    "当前分组已下单或分组中存在锁量成功或已推广的计划，不允许修改分组主计划金额，请检查并修改后重试");
                        }
                    });
                }
            }
        } else {
            // 修改分组金额校验(此时单媒体营销补量applyViewDTO.getBudget()为null，只校验计划的budget即可)
            if (Objects.nonNull(applyInfoViewDTO.getBudget()) && !applyInfoViewDTO.getBudget().equals(oldResourcePackageSaleGroupDTO.getAmountConfigure().getAmount())) {
                AssertUtil.assertTrue((Objects.isNull(oldSaleGroupInfoViewDTO) || BrandCampaignGroupSaleOrderStatusEnum.WAIT_ORDER.getCode().equals(oldSaleGroupInfoViewDTO.getSaleGroupStatus()))
                                && Lists.newArrayList(SALE_GROUP_EDIT_MODE_BRAND_NON_CAMPAIGNS, SALE_GROUP_EDIT_MODE_BRAND_ALL_BEFORE_LOCKING).contains(oldResourcePackageSaleGroupDTO.getEditMode()),
                        ResourcePackageBaseErrorCode.BIZ_BREAK_RULE_ERROR, "当前分组已下单或分组中存在锁量成功或已推广的计划，不允许修改分组金额，请检查并修改后重试");
            }
        }
        return null;
    }
}
