package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.budget.CampaignBudgetViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.EffectAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignBudgetInitForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBudgetAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EffectCampaignBudgetInitForAddCampaignAbility implements ICampaignBudgetInitForAddCampaignAbility, EffectAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignBudgetAbilityParam abilityParam) {
        CampaignBudgetViewDTO campaignBudgetViewDTO = abilityParam.getAbilityTarget();
        ResourcePackageProductViewDTO resourcePackageProductViewDTO = abilityParam.getResourcePackageProductViewDTO();
        AssertUtil.notNull(campaignBudgetViewDTO, "计划预算信息不能为空");
        AssertUtil.notNull(resourcePackageProductViewDTO, "资源包二级产品不能为空");

        List<ResourcePackageProductPriceViewDTO> bandPriceList = resourcePackageProductViewDTO.getBandPriceList();
        if(CollectionUtils.isNotEmpty(bandPriceList)){
            ResourcePackageProductPriceViewDTO resourcePackageProductPriceViewDTO = bandPriceList.get(0);

            campaignBudgetViewDTO.setDiscountTotalMoney(resourcePackageProductPriceViewDTO.getActualAmount());
            campaignBudgetViewDTO.setBudgetRatio(Integer.parseInt(String.valueOf(Constant.RATIO_100)));

            Long publishTotalMoney = new BigDecimal(resourcePackageProductPriceViewDTO.getPublishPrice())
                    .multiply(new BigDecimal(resourcePackageProductPriceViewDTO.getBookingAmount())).longValue();
            campaignBudgetViewDTO.setPublishTotalMoney(publishTotalMoney);
        }
        return null;
    }
}
