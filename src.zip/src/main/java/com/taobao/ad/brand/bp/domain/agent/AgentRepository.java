package com.taobao.ad.brand.bp.domain.agent;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.dto.agent.LlmAgentDirectCallParamViewDTO;

/**
 * @author yanjingang
 * @date 2023/3/20
 */
public interface AgentRepository {
    String directCall(ServiceContext serviceContext, LlmAgentDirectCallParamViewDTO callParam);
}
