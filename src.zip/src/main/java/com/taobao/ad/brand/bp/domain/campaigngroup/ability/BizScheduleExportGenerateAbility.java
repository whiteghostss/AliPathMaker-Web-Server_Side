package com.taobao.ad.brand.bp.domain.campaigngroup.ability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.aliyun.oss.model.CannedAccessControlList;
import com.taobao.ad.brand.bp.client.context.ScheduleExportContext;
import com.taobao.ad.brand.bp.domain.oss.OssRepository;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author jixiu.lj
 * @date 2023/3/30 13:57
 */
@Service
public class BizScheduleExportGenerateAbility {

    @Resource
    private OssRepository ossRepository;

    public String generate(ServiceContext serviceContext, ScheduleExportContext scheduleExportContext, byte[] data) {
        String fileName = generateFileName(scheduleExportContext);
        fileName += scheduleExportContext.getExtension();
        String path = scheduleExportContext.getPrefix() + "/" + fileName;
        if (scheduleExportContext.isNeedPermanentExportUrl()) {
            return ossRepository.uploadWithCDN(path, data);
        } else {
            ossRepository.upload(path, data, CannedAccessControlList.Private);
            return ossRepository.getTemporaryDownloadUrl(path);
        }
    }


    /**
     *
     * @param campaignGroupContent
     * @param forEmployee
     * @return
     */
    protected String generateFileName(ScheduleExportContext scheduleExportContext) {
        String campaignGroupName = scheduleExportContext.getCampaignGroupViewDTO().getName();
        return String.format("%s_%s_%s", scheduleExportContext.getCampaignGroupId(), campaignGroupName,
                new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()));
    }
}
