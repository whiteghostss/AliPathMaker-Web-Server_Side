package com.taobao.ad.brand.bp.domain.config;

import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.domain.config.base.BaseDiamondConfig;
import lombok.Data;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 百灵支持的维度配置功能，包含业务场景、ssp产品线等
 */
@Component
public class BrandOneBPSupportDimensionDiamondConfig extends BaseDiamondConfig {

    private static volatile BrandOneBPSupportDimensionConfig supportDimensionConfig;

    @Override
    protected String getDataId() {
        return "brand.onebp.support.dimension.config";
    }

    @Override
    protected String getGroupId() {
        return "com.taobao.ad.brand.bp";
    }

    @Override
    protected void initDiamond(String diamondConfig) throws Exception {
        RogerLogger.info("DiamondConfig.initDiamond BrandOneBPSupportDimensionDiamondConfig param: {}", diamondConfig);
        if(StringUtils.isNotBlank(diamondConfig)){
            supportDimensionConfig = JSON.parseObject(diamondConfig,BrandOneBPSupportDimensionConfig.class);
        }
    }

    public List<String> getSupportSceneList(){
        List<String> supportSceneList = supportDimensionConfig.getSupportSceneList();
        //设置默认场景
        if(CollectionUtils.isEmpty(supportSceneList)){
            supportSceneList = Lists.newArrayList(BizCodeEnum.BRANDAD.getBizCode(), BizCodeEnum.TAOBRANDAD.getBizCode(),
                BizCodeEnum.IPMARKETINGAD.getBizCode(), BizCodeEnum.SELFSERVICEAD.getBizCode());
        }
        return supportSceneList;
    }

    public List<Integer> getSupportSspProductLineList(){
        return supportDimensionConfig.getSupportSspProductLineList();
    }



    /**
     * 百灵支持的维度配置
     */
    @Data
    static class BrandOneBPSupportDimensionConfig implements java.io.Serializable{
        /**
         * 百灵支持的业务场景
         * com.alibaba.ad.biz.definition.constants.BizCodeEnum
         */
        private List<String> supportSceneList;
        /**
         * 百灵支持的ssp产品线
         * com.alibaba.ad.nb.ssp.constant.newproduct.ProductLineEnum
         */
        private List<Integer> supportSspProductLineList;
    }
}
