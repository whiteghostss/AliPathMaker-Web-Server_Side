package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.resource.CampaignResourceViewDTO;
import com.alibaba.ad.brand.dto.campaign.sale.CampaignSaleViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSaleOrderStatusEnum;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignDiffViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.differ.Differs;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignCommandDiffForAutoSaveCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignCommandDiffForAutoSaveCampaignAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultCampaignCommandDiffForAutoSaveCampaignAbility implements ICampaignCommandDiffForAutoSaveCampaignAbility {

    private final ResourcePackageRepository resourcePackageRepository;

    @Override
    public CampaignDiffViewDTO handle(ServiceContext serviceContext, CampaignCommandDiffForAutoSaveCampaignAbilityParam abilityParam) {
        //订单数据为空不做数据处理
        if(abilityParam.getAbilityTarget() == null){
            return null;
        }
        List<CampaignViewDTO> addCampaignViewDTOList = Lists.newArrayList();
        List<CampaignViewDTO> updateCampaignViewDTOList = Lists.newArrayList();
        List<CampaignViewDTO> deleteCampaignViewDTOList = Lists.newArrayList();

        //获取售卖分组信息
        List<ResourcePackageSaleGroupViewDTO> saleGroups = abilityParam.getResourcePackageSaleGroupViewDTOList();
        //获取订单信息
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        //获取db计划信息
        List<CampaignViewDTO> campaignViewDTOList = abilityParam.getDbCampaignViewDTOList();
        AssertUtil.notEmpty(campaignViewDTOList, "订单中计划信息为空");

        List<Long> dbSaleGroupIdList = campaignViewDTOList.stream().map(e->e.getCampaignSaleViewDTO().getSaleGroupId()).collect(Collectors.toList());
        ResourcePackageQueryOption packageQueryOption = ResourcePackageQueryOption.builder().needProduct(true).needSetting(true).build();
        ResourcePackageQueryViewDTO queryViewDTO = new ResourcePackageQueryViewDTO();
        queryViewDTO.setSaleGroupIdList(dbSaleGroupIdList);
        List<ResourcePackageSaleGroupViewDTO> dbSaleGroups = resourcePackageRepository.getSaleGroupList(serviceContext, queryViewDTO, packageQueryOption);
        RogerLogger.info("dbSaleGroups:{}", JSON.toJSONString(dbSaleGroups));
        Map<Long, List<CampaignViewDTO>> dbCampaignSaleGroupMap = Maps.newHashMap();
        for(CampaignViewDTO campaignViewDTO : campaignViewDTOList){
            dbCampaignSaleGroupMap.computeIfAbsent(campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId(), e->Lists.newArrayList()).add(campaignViewDTO);
        }
        /*****      分组diff      ******/
        List<ResourcePackageSaleGroupViewDTO> addSaleGroupIdList = Differs.differ(saleGroups, dbSaleGroups, e->String.valueOf(e.getId()));
        List<ResourcePackageSaleGroupViewDTO> updateSaleGroupIdList = Differs.differ(saleGroups, addSaleGroupIdList, e->String.valueOf(e.getId()));
        List<ResourcePackageSaleGroupViewDTO> delSaleGroupIdList = Differs.differ(dbSaleGroups, saleGroups, e->String.valueOf(e.getId()));
        RogerLogger.info("addSaleGroupIdList:{}, updateSaleGroupIdList:{}, delSaleGroupIdList:{}", JSON.toJSONString(addSaleGroupIdList), JSON.toJSONString(updateSaleGroupIdList), JSON.toJSONString(delSaleGroupIdList));

        //分组增加----针对新的分组生成新的计划和单元
        if(CollectionUtils.isNotEmpty(addSaleGroupIdList)){
            List<CampaignViewDTO> addCampaignList = buildAddCampaignList(campaignGroupViewDTO, addSaleGroupIdList, null);
            addCampaignViewDTOList.addAll(addCampaignList);
        }
        //分组更新
        if(CollectionUtils.isNotEmpty(updateSaleGroupIdList)){
            List<Long> addProductIdSumList = Lists.newArrayList();
            List<CampaignViewDTO> updateCampaignSumList = Lists.newArrayList();
            List<Long> unOrderSaleGroupIdList = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList()
                    .stream().filter(e-> BrandCampaignGroupSaleOrderStatusEnum.WAIT_ORDER.getCode().equals(e.getSaleGroupStatus()))
                    .map(SaleGroupInfoViewDTO::getSaleGroupId).collect(Collectors.toList());

            for(ResourcePackageSaleGroupViewDTO updateSaleGroupViewDTO:updateSaleGroupIdList){
                if(!unOrderSaleGroupIdList.contains(updateSaleGroupViewDTO.getId())){
                    continue;
                }
                //普通分组只有N类资源
                List<ResourcePackageProductViewDTO> currProductViewDTOList = updateSaleGroupViewDTO.getDistributionRuleList().get(0).getResourcePackageProductList();
                List<Long> currProductIds = currProductViewDTOList.stream().map(ResourcePackageProductViewDTO::getId).collect(Collectors.toList());
                RogerLogger.info("currProductIds:{}", JSON.toJSONString(currProductIds));
                Map<Long, ResourcePackageProductViewDTO> currProductViewMap = currProductViewDTOList.stream().collect(Collectors.toMap(ResourcePackageProductViewDTO::getId, e->e, (v1, v2)->v2));
                List<CampaignViewDTO> dbCampaignViewDTOList = dbCampaignSaleGroupMap.get(updateSaleGroupViewDTO.getId());
                List<Long> dbProductIds = dbCampaignViewDTOList.stream().map(e-> e.getCampaignSaleViewDTO().getResourcePackageProductId()).collect(Collectors.toList());
                Map<Long, CampaignViewDTO> dbCampaignViewMap = dbCampaignViewDTOList.stream().collect(Collectors.toMap(e->e.getCampaignSaleViewDTO().getResourcePackageProductId(), e->e, (v1, v2)->v2));
                RogerLogger.info("dbProductIds:{}", JSON.toJSONString(dbProductIds));

                //二级产品diff
                List<Long> addProductIdList = Differs.differ(currProductIds, dbProductIds, String::valueOf);
                List<Long> updateProductIdList = Differs.differ(currProductIds, addProductIdList, String::valueOf);
                List<Long> delProductIdList = Differs.differ(dbProductIds, currProductIds, String::valueOf);
                RogerLogger.info("addProductIdList:{}, updateProductIdList:{}, delProductIdList:{}", JSON.toJSONString(addProductIdList), JSON.toJSONString(updateProductIdList), JSON.toJSONString(delProductIdList));

                //二级产品增加
                if(CollectionUtils.isNotEmpty(addProductIdList)){
                    addProductIdSumList.addAll(addProductIdList);
                }

                //二级产品更新
                if(CollectionUtils.isNotEmpty(updateProductIdList)){

                    for(Long updateProductId : updateProductIdList){
                        ResourcePackageProductViewDTO currProductViewDTO = currProductViewMap.get(updateProductId);
                        CampaignViewDTO dbCampaignViewDTO = dbCampaignViewMap.get(updateProductId);
                        //只有产品金额或者周期发生变化，才需要更新计划信息
                        if(BrandDateUtil.isBeforeAndEqual(currProductViewDTO.getStartTime(), dbCampaignViewDTO.getStartTime())
                                && BrandDateUtil.getMinDate(currProductViewDTO.getEndTime()).equals(BrandDateUtil.getMinDate(dbCampaignViewDTO.getEndTime()))
                                && currProductViewDTO.getBandPriceList().get(0).getBookingAmount().equals(dbCampaignViewDTO.getCampaignGuaranteeViewDTO().getAmount())){
                            continue;
                        }
                        updateCampaignSumList.add(dbCampaignViewDTO);
                    }
                }

                //二级产品删除
                if(CollectionUtils.isNotEmpty(delProductIdList)){
                    List<CampaignViewDTO> delCampaignViewDTOList = dbCampaignViewDTOList.stream().filter(e->delProductIdList.contains(e.getCampaignSaleViewDTO().getResourcePackageProductId())).collect(Collectors.toList());
                    deleteCampaignViewDTOList.addAll(delCampaignViewDTOList);
                }
            }

            if(CollectionUtils.isNotEmpty(addProductIdSumList)){
                List<CampaignViewDTO> addCampaignList = buildAddCampaignList(campaignGroupViewDTO, updateSaleGroupIdList, addProductIdSumList);
                addCampaignViewDTOList.addAll(addCampaignList);
            }

            if(CollectionUtils.isNotEmpty(updateCampaignSumList)){
                updateCampaignViewDTOList.addAll(updateCampaignSumList);
            }
        }

        //分组删除---计划、单元逻辑同步删除
        if(CollectionUtils.isNotEmpty(delSaleGroupIdList)){
            for(ResourcePackageSaleGroupViewDTO delSaleGroupViewDTO : delSaleGroupIdList) {
                List<CampaignViewDTO> delCampaignViewDTOList = dbCampaignSaleGroupMap.get(delSaleGroupViewDTO.getId());
                deleteCampaignViewDTOList.addAll(delCampaignViewDTOList);
            }
        }
        CampaignDiffViewDTO campaignDiffViewDTO = new CampaignDiffViewDTO();
        campaignDiffViewDTO.setAddCampaignViewDTOList(addCampaignViewDTOList);
        campaignDiffViewDTO.setUpdateCampaignViewDTOList(updateCampaignViewDTOList);
        campaignDiffViewDTO.setDeleteCampaignViewDTOList(deleteCampaignViewDTOList);
        RogerLogger.info("campaignDiffViewDTO:{}", JSON.toJSONString(campaignDiffViewDTO));
        return campaignDiffViewDTO;
    }


    private List<CampaignViewDTO> buildAddCampaignList(CampaignGroupViewDTO campaignGroupViewDTO, List<ResourcePackageSaleGroupViewDTO> saleGroupList,List<Long> productIdList){
        List<CampaignViewDTO> campaignViewDTOList = Lists.newArrayList();
        if(CollectionUtils.isEmpty(saleGroupList)){
            return campaignViewDTOList;
        }
        for(ResourcePackageSaleGroupViewDTO saleGroup:saleGroupList){
            if(CollectionUtils.isNotEmpty(productIdList)){
                for(ResourcePackageProductViewDTO resourcePackageProductViewDTO:saleGroup.getDistributionRuleList().get(0).getResourcePackageProductList()){
                    Long productId = resourcePackageProductViewDTO.getId();
                    if(productIdList.contains(productId)){
                        CampaignViewDTO campaignViewDTO = new CampaignViewDTO();
                        campaignViewDTO.setCampaignGroupId(campaignGroupViewDTO.getId());

                        CampaignSaleViewDTO saleViewDTO = new CampaignSaleViewDTO();
                        saleViewDTO.setSaleGroupId(saleGroup.getId());
                        saleViewDTO.setResourcePackageProductId(productId);

                        CampaignResourceViewDTO sspResourceViewDTO = new CampaignResourceViewDTO();
                        sspResourceViewDTO.setSspProductId(resourcePackageProductViewDTO.getSspProductId());

                        campaignViewDTO.setCampaignSaleViewDTO(saleViewDTO);
                        campaignViewDTO.setCampaignResourceViewDTO(sspResourceViewDTO);
                        campaignViewDTOList.add(campaignViewDTO);
                    }
                }
            }else{
                for(ResourcePackageProductViewDTO resourcePackageProductViewDTO:saleGroup.getDistributionRuleList().get(0).getResourcePackageProductList()){
                    CampaignViewDTO campaignViewDTO = new CampaignViewDTO();
                    campaignViewDTO.setCampaignGroupId(campaignGroupViewDTO.getId());

                    CampaignSaleViewDTO saleViewDTO = new CampaignSaleViewDTO();
                    saleViewDTO.setSaleGroupId(saleGroup.getId());
                    saleViewDTO.setResourcePackageProductId(resourcePackageProductViewDTO.getId());
                    CampaignResourceViewDTO sspResourceViewDTO = new CampaignResourceViewDTO();
                    sspResourceViewDTO.setSspProductId(resourcePackageProductViewDTO.getSspProductId());

                    campaignViewDTO.setCampaignSaleViewDTO(saleViewDTO);
                    campaignViewDTO.setCampaignResourceViewDTO(sspResourceViewDTO);
                    campaignViewDTOList.add(campaignViewDTO);
                }
            }
        }
        return campaignViewDTOList;
    }
}
