package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.smooth.CampaignSmoothViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignPeriodSmoothTypeEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignSmoothTypeEnum;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignSmoothInitForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignSmoothAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCampaignSmoothInitForAddCampaignAbility implements ICampaignSmoothInitForAddCampaignAbility, SelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignSmoothAbilityParam abilityParam) {
        CampaignSmoothViewDTO campaignSmoothViewDTO = abilityParam.getAbilityTarget();
        ProductViewDTO productViewDTO = abilityParam.getProductViewDTO();
        AssertUtil.notNull(campaignSmoothViewDTO, "计划投放速率信息不能为空");
        AssertUtil.notNull(productViewDTO, "产品不能为空");
        //是否特秀
        boolean isTX = BizCampaignToolsHelper.isTXorShowmaxCampaign(productViewDTO.getMediaScope(), productViewDTO.getProductLineId());
        // 投放速度 默认平滑
        if(isTX){
            campaignSmoothViewDTO.setSmoothType(BrandCampaignSmoothTypeEnum.FAST_BY_HOUR.getCode());
        }else {
            campaignSmoothViewDTO.setSmoothType(BrandCampaignSmoothTypeEnum.AVERAGE.getCode());
        }
        //计划默认周期内平滑
        campaignSmoothViewDTO.setPeriodSmoothType(BrandCampaignPeriodSmoothTypeEnum.PERIOD_AVERAGE.getCode());
        return null;
    }
}
