package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.price.CampaignPriceViewDTO;
import com.alibaba.ad.brand.dto.campaign.price.DayPriceViewDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.EffectAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignPriceInitForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignPriceAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EffectCampaignPriceInitForAddCampaignAbility implements ICampaignPriceInitForAddCampaignAbility, EffectAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignPriceAbilityParam abilityParam) {
        CampaignPriceViewDTO campaignPriceViewDTO = abilityParam.getAbilityTarget();
        ProductViewDTO productViewDTO = abilityParam.getProductViewDTO();
        ResourcePackageProductViewDTO resourcePackageProductViewDTO = abilityParam.getResourcePackageProductViewDTO();
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();
        AssertUtil.notNull(campaignPriceViewDTO, "计划单价信息不能为空");
        AssertUtil.notNull(resourcePackageProductViewDTO, "资源包二级产品不能为空");
        AssertUtil.notNull(productViewDTO, "二级产品不能为空");
        AssertUtil.notNull(campaignViewDTO, "计划不能为空");

        campaignPriceViewDTO.setPublishProductId(productViewDTO.getLabel());

        List<ResourcePackageProductPriceViewDTO> bandPriceList = resourcePackageProductViewDTO.getBandPriceList();
        if(CollectionUtils.isNotEmpty(bandPriceList)){
            ResourcePackageProductPriceViewDTO resourcePackageProductPriceViewDTO = bandPriceList.get(0);
            DayPriceViewDTO dayPriceViewDTO = new DayPriceViewDTO();
            dayPriceViewDTO.setPrice(resourcePackageProductPriceViewDTO.getPublishPrice());
            dayPriceViewDTO.setStartDate(resourcePackageProductPriceViewDTO.getStartDate());
            dayPriceViewDTO.setEndDate(resourcePackageProductPriceViewDTO.getEndDate());
            dayPriceViewDTO.setDiscountRatio(resourcePackageProductPriceViewDTO.getPriceRatio());

            campaignPriceViewDTO.setPublishPriceInfoList(Lists.newArrayList(dayPriceViewDTO));
            campaignPriceViewDTO.setDiscountPriceInfoList(Lists.newArrayList(dayPriceViewDTO));
            campaignPriceViewDTO.setSettlePrice(resourcePackageProductPriceViewDTO.getPublishPrice());
        }
        return null;
    }
}
