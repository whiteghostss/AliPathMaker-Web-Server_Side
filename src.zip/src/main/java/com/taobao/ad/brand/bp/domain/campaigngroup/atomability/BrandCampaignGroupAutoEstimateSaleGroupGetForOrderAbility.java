package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupDeliveryTargetViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSaleOrderStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.nb.ssp.constant.newproduct.DeliveryTargetEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupOrderCommandViewDTO;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupAutoEstimateSaleGroupGetForOrderAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupAutoEstimateSaleGroupGetForOrderAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@BusinessAbility
public class BrandCampaignGroupAutoEstimateSaleGroupGetForOrderAbility
        implements ICampaignGroupAutoEstimateSaleGroupGetForOrderAbility, BrandAtomAbilityRouter {

    @Override
    public List<Long> handle(ServiceContext context, CampaignGroupAutoEstimateSaleGroupGetForOrderAbilityParam abilityParam) {
        CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO = abilityParam.getAbilityTarget();
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        if (BizCampaignGroupToolsHelper.isMainCampaignGroup(campaignGroupViewDTO)) {
            return Lists.newArrayList();
        }
        List<Long> checkedSaleGroupIds = campaignGroupOrderCommandViewDTO.getSaleGroupIds();
        // 筛选本次下单勾选分组，且剔除0元分组（0元分组无需进行交付/成效预估）
        List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream()
                .filter(item -> checkedSaleGroupIds.contains(item.getSaleGroupId()) && Optional.ofNullable(item.getBudget()).orElse(0L) > 0)
                .collect(Collectors.toList());
        if (CollectionUtils.isEmpty(saleGroupInfoViewDTOList)) {
            return Lists.newArrayList();
        }
        List<Long> saleGroupIds = Lists.newArrayList();
        for (SaleGroupInfoViewDTO saleGroupInfoViewDTO : saleGroupInfoViewDTOList) {
            if (Objects.equals(saleGroupInfoViewDTO.getSaleGroupStatus(), BrandCampaignGroupSaleOrderStatusEnum.WAIT_ORDER.getCode())) {
                List<SaleGroupDeliveryTargetViewDTO> saleGroupDeliveryTargetViewDTOS = Optional.ofNullable(saleGroupInfoViewDTO.getDeliveryTargetViewDTOList()).orElse(Lists.newArrayList()).stream().filter(t -> !t.getDeliveryTarget().equals(DeliveryTargetEnum.EXPOSURE.getValue())).collect(Collectors.toList());
                if (CollectionUtils.isNotEmpty(saleGroupDeliveryTargetViewDTOS)) {
                    List<SaleGroupDeliveryTargetViewDTO> filterAfterList = saleGroupDeliveryTargetViewDTOS.stream().filter(item -> Optional.ofNullable(item.getCustomerSwitch()).orElse(BrandBoolEnum.BRAND_TRUE.getCode()).equals(BrandBoolEnum.BRAND_TRUE.getCode())).collect(Collectors.toList());
                    if (CollectionUtils.isEmpty(filterAfterList)) {
                        saleGroupIds.add(saleGroupInfoViewDTO.getSaleGroupId());
                    }
                }
            }
        }
        return saleGroupIds;
    }
}
