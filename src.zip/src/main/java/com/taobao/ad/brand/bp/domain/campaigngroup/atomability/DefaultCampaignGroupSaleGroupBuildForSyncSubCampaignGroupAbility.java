package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleGroupSourceEnum;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.common.constant.campaigngroup.CampaignGroupConstant;
import com.taobao.ad.brand.bp.common.converter.campaigngroup.CampaignGroupViewConverter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupSaleGroupBuildForSyncSubCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupSaleGroupSyncBuildAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2025/2/11
 **/
@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultCampaignGroupSaleGroupBuildForSyncSubCampaignGroupAbility implements ICampaignGroupSaleGroupBuildForSyncSubCampaignGroupAbility {

    private final CampaignGroupViewConverter campaignGroupViewConverter;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupSaleGroupSyncBuildAbilityParam abilityParam) {
        CampaignGroupViewDTO mainCampaignGroup = abilityParam.getMainCampaignGroupViewDTO();
        CampaignGroupViewDTO subCampaignGroup = abilityParam.getAbilityTarget();
        if (CollectionUtils.isEmpty(mainCampaignGroup.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList())) {
            return null;
        }
        Integer sceneId = subCampaignGroup.getSceneId();
        List<SaleGroupInfoViewDTO> saleGroupList = getSubCampaignGroupSaleGroupList(mainCampaignGroup, sceneId);
        boolean canUpdateSalePlatformSaleGroup = CampaignGroupConstant.validUpdateSubSaleCampaignGroupStatusList.contains(subCampaignGroup.getStatus());
        Map<Long, SaleGroupInfoViewDTO> dbSubSaleGroupInfoMap = subCampaignGroup.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList()
                .stream().collect(Collectors.toMap(SaleGroupInfoViewDTO::getSaleGroupId, t -> t, (a1, a2) -> a1));

        List<SaleGroupInfoViewDTO> toSaveSaleGroupList = Lists.newArrayList();
        Set<Long> toSaveSaleGroupIdSet = Sets.newHashSet();
        // DB存在时仅更新部分属性信息
        saleGroupList.forEach(saleGroupInfoViewDTO -> {
            // 不支持更新售卖中心分组时
            if (!canUpdateSalePlatformSaleGroup && BrandSaleGroupSourceEnum.SALE_PLATFORM.getCode().equals(saleGroupInfoViewDTO.getSource())) {
                // 以DB中为准
                if (dbSubSaleGroupInfoMap.containsKey(saleGroupInfoViewDTO.getSaleGroupId())) {
                    toSaveSaleGroupList.add(dbSubSaleGroupInfoMap.get(saleGroupInfoViewDTO.getSaleGroupId()));
                    toSaveSaleGroupIdSet.add(saleGroupInfoViewDTO.getSaleGroupId());
                }
                return;
            }

            saleGroupInfoViewDTO.setCampaignGroupId(subCampaignGroup.getId());
            if (!dbSubSaleGroupInfoMap.containsKey(saleGroupInfoViewDTO.getSaleGroupId())) {
                toSaveSaleGroupList.add(saleGroupInfoViewDTO);
                toSaveSaleGroupIdSet.add(saleGroupInfoViewDTO.getSaleGroupId());
                return;
            }

            SaleGroupInfoViewDTO dbSaleGroupInfo = dbSubSaleGroupInfoMap.get(saleGroupInfoViewDTO.getSaleGroupId());
            dbSaleGroupInfo.setBudget(saleGroupInfoViewDTO.getBudget());
            toSaveSaleGroupList.add(dbSaleGroupInfo);
            toSaveSaleGroupIdSet.add(saleGroupInfoViewDTO.getSaleGroupId());
        });

        // 删除的售卖中心分组，如果当前子订单不支持更新售卖中心的分组，则加回来
        List<SaleGroupInfoViewDTO> toDeleteSalePlateformSaleGroupList = subCampaignGroup.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList()
                .stream().filter(saleGroup -> BrandSaleGroupSourceEnum.SALE_PLATFORM.getCode().equals(saleGroup.getSource()) && !toSaveSaleGroupIdSet.contains(saleGroup.getSaleGroupId()))
                .collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(toDeleteSalePlateformSaleGroupList) && !canUpdateSalePlatformSaleGroup) {
            toSaveSaleGroupList.addAll(toDeleteSalePlateformSaleGroupList);
        }
        subCampaignGroup.getCampaignGroupSaleGroupViewDTO().setSaleGroupInfoViewDTOList(toSaveSaleGroupList);
        return null;
    }

    private List<SaleGroupInfoViewDTO> getSubCampaignGroupSaleGroupList(CampaignGroupViewDTO mainCampaignGroup, Integer sceneId) {
        if (CollectionUtils.isEmpty(mainCampaignGroup.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList())) {
            return Lists.newArrayList();
        }
        List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList = campaignGroupViewConverter.convertSaleGroupInfoSelfList(mainCampaignGroup.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList());
        return saleGroupInfoViewDTOList.stream()
                .filter(saleGroup -> saleGroup.getSaleBusinessLine() != null && saleGroup.getSaleBusinessLine().equals(sceneId))
                .peek(saleGroupInfo -> {
                    saleGroupInfo.setId(null);
                    saleGroupInfo.setCampaignGroupId(null);
                }).collect(Collectors.toList());
    }
}
