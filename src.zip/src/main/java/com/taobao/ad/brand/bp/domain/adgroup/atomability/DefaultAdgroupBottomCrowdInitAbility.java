package com.taobao.ad.brand.bp.domain.adgroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.crowd.AdgroupCrowdScenarioViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupBottomCrowdInitAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupBottomCrowdInitAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultAdgroupBottomCrowdInitAbility implements IAdgroupBottomCrowdInitAbility {

    @Override
    public Void handle(ServiceContext serviceContext, AdgroupBottomCrowdInitAbilityParam abilityParam) {
        AdgroupCrowdScenarioViewDTO adgroupCrowdScenarioViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(adgroupCrowdScenarioViewDTO,"人群参数不能为空");
        //打底单元无人群
        adgroupCrowdScenarioViewDTO.setAdgroupCrowdViewDTOList(Lists.newArrayList());
        adgroupCrowdScenarioViewDTO.setCrowdTag(BrandBoolEnum.BRAND_FALSE.getCode());
        return null;
    }
}
