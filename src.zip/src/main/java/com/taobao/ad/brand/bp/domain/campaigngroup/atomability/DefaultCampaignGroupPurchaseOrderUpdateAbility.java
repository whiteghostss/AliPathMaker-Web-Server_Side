package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.purchase.CampaignGroupPurchaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupPurchaseProcessViewDTO;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupPurchaseOrderUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupPurchaseOrderUpdateAbilityParam;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;
import java.util.Optional;

import static com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupPurchaseStatusEnum.NON_PURCHASE;
import static com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupPurchaseStatusEnum.PURCHASE_FINISH;
import static com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupPurchaseStatusEnum.PURCHASE_ING;

@Component
@BusinessAbility
public class DefaultCampaignGroupPurchaseOrderUpdateAbility implements ICampaignGroupPurchaseOrderUpdateAbility {

    @Resource
    private CampaignGroupRepository campaignGroupRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupPurchaseOrderUpdateAbilityParam abilityParam) {
        CampaignGroupPurchaseViewDTO campaignGroupPurchaseViewDTO = Optional.ofNullable(abilityParam.getAbilityTarget()).orElse(new CampaignGroupPurchaseViewDTO());
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        CampaignGroupPurchaseProcessViewDTO purchaseResultViewDTO = abilityParam.getPurchaseProcessViewDTO();
        if (purchaseResultViewDTO == null || purchaseResultViewDTO.getBrandCampaignGroupPurchaseStatusEnum() == null) {
            return null;
        }

        // 初始化
        if (purchaseResultViewDTO.getBrandCampaignGroupPurchaseStatusEnum() == NON_PURCHASE) {
            if (campaignGroupPurchaseViewDTO.getPurchaseStatus() == null || campaignGroupPurchaseViewDTO.getPurchaseStatus() != PURCHASE_ING.getCode().intValue()) {
                campaignGroupPurchaseViewDTO.setPurchaseStatus(NON_PURCHASE.getCode());
            } else {
                campaignGroupPurchaseViewDTO.setPurchaseStatus(PURCHASE_FINISH.getCode());
            }
        } else {
            campaignGroupPurchaseViewDTO.setPurchaseStatus(purchaseResultViewDTO.getBrandCampaignGroupPurchaseStatusEnum().getCode());
        }
        campaignGroupPurchaseViewDTO.setPurchaseStatusModifyTime(new Date());
        campaignGroupViewDTO.setCampaignGroupPurchaseViewDTO(campaignGroupPurchaseViewDTO);

        // 更新
        CampaignGroupViewDTO updateCampaignGroupViewDTO = new CampaignGroupViewDTO();
        updateCampaignGroupViewDTO.setId(campaignGroupViewDTO.getId());
        updateCampaignGroupViewDTO.setCampaignGroupPurchaseViewDTO(campaignGroupPurchaseViewDTO);
        campaignGroupRepository.updateCampaignGroupPart(serviceContext, updateCampaignGroupViewDTO);

        return null;
    }
}
