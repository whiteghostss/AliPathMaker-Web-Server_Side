package com.taobao.ad.brand.bp.domain.campaign.workflow;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignDelayLockApplyViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignInquiryOperateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignInventoryAutoReleaseMsgViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignScheduleViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignScheduleOperateTypeEnum;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.BizCampaignInventoryWorkflowExt;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignAutoReleaseWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignInventoryWorkflowParam;

import java.util.List;

/**
 * Description:
 * <p>
 * date: 2023/10/24 2:51 PM
 *
 * @author shiyan
 * @version 1.0
 */
@BusinessAbility
public class DefaultCampaignInventoryWorkflowExtImpl implements BizCampaignInventoryWorkflowExt {
    /**
     * 构建扩展参数
     * @param serviceContext
     * @param inquiryOperateViewDTO
     * @return
     */
    @Override
    public BizCampaignInventoryWorkflowParam buildParamForInventory(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO) {

        return null;
    }

    @Override
    public void afterInventoryInquiryOrLock(ServiceContext serviceContext, BizCampaignInventoryWorkflowParam inventoryWorkflowParam, CampaignScheduleOperateTypeEnum operateTypeEnum) {
    }

    /**
     * 库存询缩量回调，后置链路处理
     *
     * @param serviceContext
     * @param inventoryCallbackViewDTO
     * @param inventoryWorkflowParam
     * @param campaignScheduleViewDTOList
     * @return
     */
    @Override
    public Void afterInventoryCallback(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inventoryCallbackViewDTO, BizCampaignInventoryWorkflowParam inventoryWorkflowParam, List<CampaignScheduleViewDTO> campaignScheduleViewDTOList){
        return null;
    }

    /**
     * 库存自动释量预警校验
     *
     * @param context
     * @param inventoryAutoReleaseMsgViewDTOList
     * @return
     */
    @Override
    public Void beforeInventoryAutoReleaseWarning(ServiceContext context, List<CampaignInventoryAutoReleaseMsgViewDTO> inventoryAutoReleaseMsgViewDTOList){
        return null;
    }

    /**
     * 构造锁量延期申请参数
     * @param serviceContext
     * @param campaignDelayLockApplyViewDTO
     * @return
     */
    @Override
    public List<BizCampaignAutoReleaseWorkflowParam> buildAutoReleaseDelayLockParamExt(ServiceContext serviceContext,
                                                                                       CampaignDelayLockApplyViewDTO campaignDelayLockApplyViewDTO) {
        return null;
    }

    /**
     * 按可用金额锁量
     * @param serviceContext
     * @param campaignViewDTOList
     * @param inquiryOperateViewDTO
     * @return
     */
//    @Override
//    public Void resetAvailAmountLockParam(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList, CampaignInquiryOperateViewDTO inquiryOperateViewDTO){
//        return null;
//    }

//    @Override
//    public List<CampaignViewDTO> buildCampaignScrollList(ServiceContext serviceContext, List<CampaignViewDTO> scrollDailyCampaignList, List<CampaignViewDTO> campaignTreeViewDTOList, List<Long> campaignIdList) {
//        return Lists.newArrayList();
//    }

//    @Override
//    public Void updateCampaignScroll(ServiceContext context, List<CampaignViewDTO> originalDbCampaignTreeList) {
//        return null;
//    }
}