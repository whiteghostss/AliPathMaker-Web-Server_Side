package com.taobao.ad.brand.bp.domain.cart.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.alibaba.ad.brand.sdk.constant.cartitem.BrandCartItemStatusEnum;
import com.alibaba.ad.brand.sdk.constant.cartitem.BrandCartItemTypeEnum;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.cartitem.query.CartItemQueryViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.cart.repository.CartItemRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.ICartItemUniqueValidateForAddCartItemAbility;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.param.CartItemValidateAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

@Component
@BusinessAbility
public class SelfServiceCartItemUniqueValidateForAddCartItemAbility implements ICartItemUniqueValidateForAddCartItemAbility, SelfServiceAtomAbilityRouter {
    @Resource
    private CartItemRepository cartItemRepository;

    @Override
    public Void handle(ServiceContext context, CartItemValidateAbilityParam abilityParam) {
        CartItemViewDTO cartItemViewDTO = abilityParam.getAbilityTarget();
        //快速下单操作，允许进行重复操作
        if(BrandCartItemTypeEnum.QUICK_ORDER.getCode().equals(cartItemViewDTO.getType())){
            return null;
        }
        //唯一性校验（原子能力）
        CartItemQueryViewDTO cartItemQueryViewDTO = CartItemQueryViewDTO.builder().type(cartItemViewDTO.getType())
                .skuIdList(Lists.newArrayList(cartItemViewDTO.getSkuId())).bundleId(cartItemViewDTO.getBundleId())
                .statusList(Lists.newArrayList(BrandCartItemStatusEnum.ORDER_WAIT.getCode())).build();
        List<CartItemViewDTO> dbCartList = cartItemRepository.findCartList(context, cartItemQueryViewDTO);
        if(CollectionUtils.isEmpty(dbCartList)){
            return null;
        }
        if(Objects.isNull(cartItemViewDTO.getId())){
            RogerLogger.info(String.format("商品（skuId=%s）已在购物车中存在，请勿重复加购",cartItemViewDTO.getSkuId()));
            AssertUtil.assertTrue(CollectionUtils.isEmpty(dbCartList), getErrorMsg(cartItemViewDTO));
        }
        //非当前加购行
        RogerLogger.info(String.format("商品（skuId=%s）已在购物车中存在，请勿重复加购",cartItemViewDTO.getSkuId()));
        AssertUtil.assertTrue(Objects.equals(cartItemViewDTO.getId(),dbCartList.get(0).getId()), getErrorMsg(cartItemViewDTO));
        return null;
    }

    private String getErrorMsg(CartItemViewDTO cartItemViewDTO) {
        if (BrandCartItemTypeEnum.SLIM_ORDER.getCode().equals(cartItemViewDTO.getType())) {
            return "该套餐包已有完成锁量的记录，请刷新页面查看。";
        } else {
            return  "商品已加购，请勿重复点击操作";
        }
    }
}
