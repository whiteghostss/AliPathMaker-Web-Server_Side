package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.monitor.CampaignMonitorViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignMonitorInitForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignMonitorAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultCampaignMonitorInitForUpdateCampaignAbility implements ICampaignMonitorInitForUpdateCampaignAbility {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignMonitorAbilityParam abilityParam) {
        CampaignMonitorViewDTO campaignMonitorViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        AssertUtil.notNull(campaignMonitorViewDTO, "计划监测信息不能为空");
        AssertUtil.notNull(dbCampaignViewDTO, "计划不存在");

        CampaignMonitorViewDTO dbCampaignMonitorViewDTO = dbCampaignViewDTO.getCampaignMonitorViewDTO();
        if(dbCampaignMonitorViewDTO != null){
            campaignMonitorViewDTO.setProductDataChannel(dbCampaignMonitorViewDTO.getProductDataChannel());
            campaignMonitorViewDTO.setMonitorDimension(dbCampaignMonitorViewDTO.getMonitorDimension());
            campaignMonitorViewDTO.setSplitConfig(dbCampaignMonitorViewDTO.getSplitConfig());
            campaignMonitorViewDTO.setThirdMonitorType(dbCampaignMonitorViewDTO.getThirdMonitorType());
        }
        return null;
    }
}
