package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.CampaignGroupSaleViewDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupSaleInitForUpdateCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupSaleAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@BusinessAbility
public class BrandOneBPCampaignGroupSaleInitForUpdateCampaignGroupAbility extends DefaultCampaignGroupSaleInitForUpdateCampaignGroupAbility
        implements BrandOneBPAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupSaleAbilityParam abilityParam) {
        if (!BizCampaignGroupToolsHelper.isSaleCampaignGroup(abilityParam.getCampaignGroupViewDTO())) {
            return null;
        }
        CampaignGroupSaleViewDTO campaignGroupSaleViewDTO = abilityParam.getAbilityTarget();
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        CampaignGroupSaleViewDTO updateSaleViewDTO = new CampaignGroupSaleViewDTO();
        if (campaignGroupSaleViewDTO != null) {
            updateSaleViewDTO.setDirectSales(campaignGroupSaleViewDTO.getDirectSales());
            updateSaleViewDTO.setChannelSales(campaignGroupSaleViewDTO.getChannelSales());
            // 销售信息
            List<String> relevantSales = Lists.newArrayList();
            if (CollectionUtils.isNotEmpty(campaignGroupSaleViewDTO.getDirectSales())) {
                relevantSales.addAll(campaignGroupSaleViewDTO.getDirectSales());
            }
            if (CollectionUtils.isNotEmpty(campaignGroupSaleViewDTO.getChannelSales())) {
                relevantSales.addAll(campaignGroupSaleViewDTO.getChannelSales());
            }
            updateSaleViewDTO.setRelevantSales(relevantSales);
        }
        campaignGroupViewDTO.setCampaignGroupSaleViewDTO(updateSaleViewDTO);

        return null;
    }
}
