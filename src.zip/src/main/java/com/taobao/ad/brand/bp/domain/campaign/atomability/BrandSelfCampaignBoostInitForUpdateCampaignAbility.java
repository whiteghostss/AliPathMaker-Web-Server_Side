package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.boost.CampaignBoostViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignBoostInitForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBoostAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSelfCampaignBoostInitForUpdateCampaignAbility implements ICampaignBoostInitForUpdateCampaignAbility, BrandSelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignBoostAbilityParam abilityParam) {
        CampaignBoostViewDTO campaignBoostViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        AssertUtil.notNull(dbCampaignViewDTO,"计划不存在");
        AssertUtil.notNull(campaignBoostViewDTO,"计划补量信息不能为空");

        CampaignBoostViewDTO dbCampaignBoostViewDTO = dbCampaignViewDTO.getCampaignBoostViewDTO();
        if(dbCampaignBoostViewDTO != null){
            campaignBoostViewDTO.setSourceCampaignId(dbCampaignBoostViewDTO.getSourceCampaignId());
            campaignBoostViewDTO.setUnionInquiryInfoList(dbCampaignBoostViewDTO.getUnionInquiryInfoList());
            campaignBoostViewDTO.setBoostReason(dbCampaignBoostViewDTO.getBoostReason());
        }
        return null;
    }
}
