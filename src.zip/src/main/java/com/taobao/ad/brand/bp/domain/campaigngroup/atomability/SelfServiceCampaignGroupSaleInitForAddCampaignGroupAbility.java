package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.sale.CampaignGroupSaleViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageTemplateViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSkuViewDTO;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupSaleInitForAddCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupSaleAbilityParam;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Optional;

@Component
@BusinessAbility
public class SelfServiceCampaignGroupSaleInitForAddCampaignGroupAbility
        implements ICampaignGroupSaleInitForAddCampaignGroupAbility, SelfServiceAtomAbilityRouter {
    @Resource
    private ResourcePackageRepository resourcePackageRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupSaleAbilityParam abilityParam) {
        CampaignGroupSaleViewDTO saleViewDTO = Optional.ofNullable(abilityParam.getAbilityTarget()).orElse(new CampaignGroupSaleViewDTO());
        abilityParam.getCampaignGroupViewDTO().setCampaignGroupSaleViewDTO(saleViewDTO);
        BrandSkuViewDTO skuViewDTO = abilityParam.getSkuList().stream().findFirst().orElse(null);
        Long saleGroupId = Optional.ofNullable(skuViewDTO).map(BrandSkuViewDTO::getResourcePackageSaleGroupId).orElse(null);
        if (saleGroupId == null) {
            return null;
        }
        // 招商模板ID
        ResourcePackageTemplateViewDTO customerTemplateViewDTO = resourcePackageRepository.getResourceTemplateBySaleGroupId(serviceContext, saleGroupId);
        Optional.ofNullable(customerTemplateViewDTO).ifPresent(t -> {
            saleViewDTO.setMarketingTemplateId(customerTemplateViewDTO.getMarketingTemplateId());
            saleViewDTO.setMarketingProjectId(customerTemplateViewDTO.getProjectId());
        });

        return null;
    }
}
