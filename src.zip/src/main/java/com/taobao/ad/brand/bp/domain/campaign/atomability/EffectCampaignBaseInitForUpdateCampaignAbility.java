package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.EffectAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignBaseInitForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBaseAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_REQUIRED;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EffectCampaignBaseInitForUpdateCampaignAbility extends DefaultCampaignBaseInitForUpdateCampaignAbility implements EffectAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignBaseAbilityParam abilityParam) {
        super.handle(serviceContext,abilityParam);

        //设置计划投放周期
        ResourcePackageProductViewDTO resourcePackageProductViewDTO = abilityParam.getResourcePackageProductViewDTO();
        AssertUtil.notNull(resourcePackageProductViewDTO, PARAM_REQUIRED, "资源产品不能为空");
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        CampaignViewDTO campaignViewDTO = abilityParam.getAbilityTarget();
        campaignViewDTO.setStartTime(resourcePackageProductViewDTO.getStartTime());
        campaignViewDTO.setEndTime(BrandDateUtil.getDateFullMidnight(resourcePackageProductViewDTO.getEndTime()));
        if(BrandCampaignLevelEnum.LEVEL_TWO_CAMPAIGN.getCode().equals(campaignViewDTO.getCampaignLevel())){
            campaignViewDTO.setTitle(dbCampaignViewDTO.getTitle());
        }
        return null;
    }
}
