package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.guarantee.CampaignGuaranteeViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.EffectAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignGuaranteeInitForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignGuaranteeAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EffectCampaignGuaranteeInitForAddCampaignAbility implements ICampaignGuaranteeInitForAddCampaignAbility, EffectAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGuaranteeAbilityParam abilityParam) {
        CampaignGuaranteeViewDTO campaignGuaranteeViewDTO = abilityParam.getAbilityTarget();
        ProductViewDTO productViewDTO = abilityParam.getProductViewDTO();
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();
        ResourcePackageProductViewDTO packageProductViewDTO = abilityParam.getResourcePackageProductViewDTO();
        AssertUtil.notNull(campaignGuaranteeViewDTO, "计划保量信息不能为空");
        AssertUtil.notNull(productViewDTO, "产品不能为空");
        AssertUtil.notNull(campaignViewDTO, "计划不能为空");
        AssertUtil.notNull(packageProductViewDTO, "资源产品不能为空");
        // 预定单位
        campaignGuaranteeViewDTO.setSspRegisterUnit(productViewDTO.getRegisterUnit() == null ? productViewDTO.getSellUnit() : productViewDTO.getRegisterUnit());
        // 预定量
        if(CollectionUtils.isNotEmpty(packageProductViewDTO.getBandPriceList())){
            ResourcePackageProductPriceViewDTO productPriceViewDTO = packageProductViewDTO.getBandPriceList().get(0);
            campaignGuaranteeViewDTO.setAmount(new BigDecimal(productPriceViewDTO.getBookingAmount())
                    .multiply(new BigDecimal(Constant.DEFAULT_CPM_PV_RATIO)).longValue());
        }
        return null;
    }
}
