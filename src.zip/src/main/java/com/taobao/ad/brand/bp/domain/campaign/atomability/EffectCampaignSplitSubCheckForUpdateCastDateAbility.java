package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.EffectAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignSplitSubCheckForUpdateCastDateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignUpdateCastDateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EffectCampaignSplitSubCheckForUpdateCastDateAbility
    implements ICampaignSplitSubCheckForUpdateCastDateAbility, EffectAtomAbilityRouter {

    @Override
    public Boolean handle(ServiceContext serviceContext, CampaignUpdateCastDateAbilityParam abilityParam) {
        return false;
    }

}
