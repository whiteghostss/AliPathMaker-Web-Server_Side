package com.taobao.ad.brand.bp.domain.mediarule;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.media.protect.MediaProtectRuleViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.mediarule.query.MediaProtectRuleQueryViewDTO;

import java.util.List;

/**
 * 保护规则
 * @author linhua.deng
 * @date 2023/7/20
 */
public interface MediaProtectRuleRepository {
    /**
     * 新增
     *
     * @param serviceContext
     * @param viewDTO
     * @return
     */
    Long addProtectRule(ServiceContext serviceContext, MediaProtectRuleViewDTO viewDTO);

    /**
     * 编辑
     *
     * @param serviceContext
     * @param viewDTO
     * @return
     */
    Integer updateProtectRule(ServiceContext serviceContext, MediaProtectRuleViewDTO viewDTO);

    /**
     * 频控状态修改
     *
     * @param serviceContext
     * @param ids
     * @param status
     * @return
     */
    Integer updateProtectRuleStatus(ServiceContext serviceContext, List<Long> ids, Integer status);

    /**
     * 查询单条数据
     *
     * @param serviceContext
     * @param id
     * @return
     */
    MediaProtectRuleViewDTO getProtectRule(ServiceContext serviceContext, Long id);

    /**
     * 分页查询数据
     *
     * @param serviceContext
     * @param queryViewDTO
     * @return
     */
    PageResultViewDTO<MediaProtectRuleViewDTO> findProtectRuleList(ServiceContext serviceContext, MediaProtectRuleQueryViewDTO queryViewDTO);

    /**
     * 查询匹配的全部数据
     * @param serviceContext
     * @param queryViewDTO
     * @return
     */
    List<MediaProtectRuleViewDTO> findList(ServiceContext serviceContext, MediaProtectRuleQueryViewDTO queryViewDTO);
    /**
     * 根据名称查询保护规则
     * @param serviceContext
     * @param uniqueName
     * @return
     */
    MediaProtectRuleViewDTO getTopOneByName(ServiceContext serviceContext, String uniqueName);
}
