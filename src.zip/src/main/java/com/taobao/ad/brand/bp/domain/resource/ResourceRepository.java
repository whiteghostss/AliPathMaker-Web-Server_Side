package com.taobao.ad.brand.bp.domain.resource;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.dto.product.ResourceScheduleViewDTO;
import com.taobao.ad.brand.bp.client.dto.resource.MediaResourceViewDTO;

import java.util.List;

/**
 * @author jixiu.lj
 * @date 2023/3/21 00:42
 */
public interface ResourceRepository {
    /**
     * 查询资源位列表
     * @param resourceIds
     * @return
     */
    List<MediaResourceViewDTO> getResourceList(List<Long> resourceIds);


    /**
     * 查询资源位列表
     * @param resourceId
     * @return
     */
    MediaResourceViewDTO getResource(Long resourceId);


    /**
     * 根据采购行获取资源排期信息
     * */
    List<ResourceScheduleViewDTO> getResourceScheduleByPurchaseRowIds(List<Long> purchaseRowIds);

    /**
     * 根据采购单id查询采购行信息
     */
    List<ResourceScheduleViewDTO> getResourceScheduleByPurchaseOrderId(ServiceContext serviceContext, Long purchaseOrderId);



}
