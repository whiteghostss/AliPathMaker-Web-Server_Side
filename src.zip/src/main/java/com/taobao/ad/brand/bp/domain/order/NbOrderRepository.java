package com.taobao.ad.brand.bp.domain.order;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;

import java.util.Map;

public interface NbOrderRepository {
    Map<String, String> generateCreativeProtocols(ServiceContext context, CreativeViewDTO creativeViewDTO);
}
