package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.biz.definition.constants.Product;
import com.alibaba.ad.biz.definition.constants.UniversalCampaignModel;
import com.alibaba.ad.biz.definition.constants.UniversalCampaignType;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.*;
import com.alibaba.ad.nb.packages.v2.client.constant.product.CastTypeEnum;
import com.alibaba.ad.nb.ssp.constant.common.CrossSceneEnum;
import com.alibaba.ad.nb.ssp.constant.common.MediaScopeEnum;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignBaseInitForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBaseAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_REQUIRED;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCampaignBaseInitForAddCampaignAbility implements ICampaignBaseInitForAddCampaignAbility, SelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignBaseAbilityParam abilityParam) {
        CampaignViewDTO campaignViewDTO = abilityParam.getAbilityTarget();
        ResourcePackageProductViewDTO resourcePackageProductViewDTO = abilityParam.getResourcePackageProductViewDTO();
        ProductViewDTO productViewDTO = abilityParam.getProductViewDTO();
        AssertUtil.notNull(campaignViewDTO, PARAM_REQUIRED, "计划不能为空");
        AssertUtil.notNull(resourcePackageProductViewDTO, PARAM_REQUIRED, "资源产品不能为空");
        AssertUtil.notNull(productViewDTO, PARAM_REQUIRED, "产品不能为空");

        campaignViewDTO.setProductLineId(Product.BRAND_ONEBP_BRAND.getProductLineId());
        campaignViewDTO.setSceneId(ServiceContextUtil.getSceneId(serviceContext));

        // 默认草稿临时
        campaignViewDTO.setOnlineStatus(BrandCampaignOnlineStatusEnum.DRAFT.getCode());
        // 计费类型
        Integer saleType = resourcePackageProductViewDTO.getSaleUnit() == null ?  productViewDTO.getSellUnit() : resourcePackageProductViewDTO.getSaleUnit();
        UniversalCampaignType campaignType = getCampaignType(saleType,productViewDTO.getMediaScope(), productViewDTO.getProgrammatic());
        AssertUtil.notNull(campaignType, "计费类型不支持");
        campaignViewDTO.setCampaignType(campaignType.getId());
        // 投放方式
        Integer castType = BizCampaignToolsHelper.getCampaignCastType(campaignViewDTO, resourcePackageProductViewDTO);
        Integer pushRatio = campaignViewDTO.getCampaignGuaranteeViewDTO() != null ? campaignViewDTO.getCampaignGuaranteeViewDTO().getSspPushSendRatio() : null;
        UniversalCampaignModel campaignModel = getCampaignModel(productViewDTO.getMediaScope(), castType, pushRatio,saleType,productViewDTO.getProductLineId(), productViewDTO.getProgrammatic(), productViewDTO.getCrossScene());
        AssertUtil.notNull(campaignModel, "投放方式不支持");
        campaignViewDTO.setCampaignModel(campaignModel.getId());

        // 品牌产品线
        campaignViewDTO.setProductLineId(Product.BRAND_ONEBP_BRAND.getProductLineId());
        campaignViewDTO.setSceneId(ServiceContextUtil.getSceneId(serviceContext));
        // 新建状态
        if (campaignViewDTO.getStatus() == null ){
            campaignViewDTO.setStatus(BrandCampaignStatusEnum.NEW.getCode());
        }
        // 一级计划
        campaignViewDTO.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
        // 是否系统投放
        campaignViewDTO.setSspProgrammatic(productViewDTO.getProgrammatic() == null ? BrandCampaignProgrammaticEnum.SYSTEM_CAST.getCode() : productViewDTO.getProgrammatic());
        //后续获取加收项时需要，所以在此次单独设置
        campaignViewDTO.setGmtCreate(BrandDateUtil.getCurrentTime());

        return null;
    }
    /**
     * 获取计费类型
     *
     * @param registerUnit SSP产品预定单位
     * @param programmatic 是否系统投放
     */
    private UniversalCampaignType getCampaignType(Integer registerUnit, Integer mediaScope, Integer programmatic) {
        BrandCampaignRegisterUnitEnum registerUnitEnum = BrandCampaignRegisterUnitEnum.getByCode(registerUnit);
        AssertUtil.notNull(registerUnitEnum, "预定单位不存在");
        switch (registerUnitEnum) {
            case CPM:
                return UniversalCampaignType.BRAND_CPM;
            default:
                return null;
        }
    }

    /**
     * 获取投放方式
     *
     * @param mediaScope   SSP媒体流量域
     * @param castType     资源包二级产品投放方式
     * @param programmatic
     */
    private UniversalCampaignModel getCampaignModel(Integer mediaScope, Integer castType, Integer pushSendRatio,Integer registerUnit,Integer sspProductLineId, Integer programmatic, Integer sspCrossScene) {
        CastTypeEnum castTypeEnum = CastTypeEnum.getEnum(castType);
        AssertUtil.notNull(castTypeEnum, "资源产品投放方式不能为空");
        // 跨域 && GD
        if (MediaScopeEnum.CROSS_SCOPE.getCode().equals(mediaScope)) {
            if (sspCrossScene == null || sspCrossScene == CrossSceneEnum.CROSS_SCENE.getValue()) {
                return UniversalCampaignModel.TAO_CROSS_GD;
            } else if (sspCrossScene == CrossSceneEnum.CROSS_OPAQUE_SCENE.getValue()) {
                return UniversalCampaignModel.TAO_CROSS_BLACK;
            } else if (sspCrossScene == CrossSceneEnum.TAOBAO_INNER_SCENE.getValue() || sspCrossScene == CrossSceneEnum.TAOBAO_INNER_LITE_SCENE.getValue()) {
                return UniversalCampaignModel.TAO_CROSS_TX_SHOWMAX_PACKAGE;
            }
        }
        //特秀
        if (BizCampaignToolsHelper.isTXorShowmaxCampaign(mediaScope,sspProductLineId)) {
            return UniversalCampaignModel.TAO_IN_ONE_TX_GD;
        }

        return null;
    }
}
