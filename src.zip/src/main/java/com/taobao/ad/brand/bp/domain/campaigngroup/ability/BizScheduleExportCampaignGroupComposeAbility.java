package com.taobao.ad.brand.bp.domain.campaigngroup.ability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.context.ScheduleExportContext;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CrmAdvInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesCustomerViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.export.CampaignGroupExportEnum;
import com.taobao.ad.brand.bp.common.util.FenYuanUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CustomerRepository;
import com.taobao.ad.brand.bp.domain.memeber.MemberRepository;
import lombok.RequiredArgsConstructor;
import org.jsoup.internal.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * @author jixiu.lj
 * @date 2023/3/29 13:38
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizScheduleExportCampaignGroupComposeAbility extends BizScheduleExportBaseComposeAbility {

    private final MemberRepository memberRepository;
    private final CustomerRepository customerRepository;

    /**
     * @return filedName-value
     * @see CampaignGroupExportEnum
     */
    public Map<CampaignGroupExportEnum, String> compose(ServiceContext serviceContext,
                                                        ScheduleExportContext scheduleExportContext) {
        Map<CampaignGroupExportEnum, String> result = new HashMap<>();
        // 构造订单数据
        CampaignGroupViewDTO campaignGroupModel = buildCampaignGroupViewDTO(serviceContext, scheduleExportContext);

        // 商家版指标填充
        scheduleExportContext.setCampaignGroupViewDTO(campaignGroupModel);


        Long customerId = campaignGroupModel.getCampaignGroupCustomerViewDTO().getCustomerId();
        SalesCustomerViewDTO customer = customerRepository.getCustomerById(customerId);
//        String industryName = Optional.ofNullable(customer).map(SalesCustomerViewDTO::getIndustryName).orElseGet(() -> "");
        String customerName = Optional.ofNullable(customer).map(SalesCustomerViewDTO::getName).orElseGet(() -> "");
        String brandName = Optional.ofNullable(customer).map(SalesCustomerViewDTO::getBrandName).orElseGet(() -> "");
        // 行业
        CrmAdvInfoViewDTO crmAdvInfoViewDTO = customerRepository.getCustomer(campaignGroupModel.getCampaignGroupCustomerViewDTO().getCustomerMemberId());
        String industryName = Optional.ofNullable(crmAdvInfoViewDTO).map(CrmAdvInfoViewDTO::getIndustryName).orElseGet(() -> "");

        Optional<String> memberNameOpt = Optional.ofNullable(memberRepository.getTbNickNameByMemberId(campaignGroupModel.getMemberId()));
        String memberName = memberNameOpt.orElse("");
        //叉乘账号需要显示具体名称
        Map<Long, String> xMemberDisplayNameMap = memberRepository.queryXMemberDisplayNameMap(Lists.newArrayList(campaignGroupModel.getMemberId()));
        String xDisplayName = xMemberDisplayNameMap.getOrDefault(campaignGroupModel.getMemberId(), "");
        result.put(CampaignGroupExportEnum.MEMBER_NAME, StringUtil.isBlank(xDisplayName) ? memberName : xDisplayName + "(" + memberName + ")");
        result.put(CampaignGroupExportEnum.MEMBER_ID, String.valueOf(campaignGroupModel.getMemberId()));
        result.put(CampaignGroupExportEnum.CAMPAIGN_GROUP_ID, String.valueOf(campaignGroupModel.getId()));
        result.put(CampaignGroupExportEnum.CAMPAIGN_GROUP_NAME, campaignGroupModel.getName());
        result.put(CampaignGroupExportEnum.BUDGET, campaignGroupModel.getBudget() == null ? "" : String.format("%s%.2f", '¥', FenYuanUtil.getYuanFromFen(campaignGroupModel.getBudget()).doubleValue()));
        SimpleDateFormat periodDateFormat = new SimpleDateFormat("yyyy/MM/dd");
        result.put(CampaignGroupExportEnum.PERIOD, String.format("%s~%s", periodDateFormat.format(campaignGroupModel.getStartTime()), periodDateFormat.format(campaignGroupModel.getEndTime())));
        result.put(CampaignGroupExportEnum.VERSION_DATE, new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(new Date()));
        result.put(CampaignGroupExportEnum.CONTRACT_ID,
                campaignGroupModel.getCampaignGroupContractViewDTO().getContractId() == null ? "" :
                        String.valueOf(campaignGroupModel.getCampaignGroupContractViewDTO().getContractId()));
        result.put(CampaignGroupExportEnum.BUDGET_FOR_WAITER, campaignGroupModel.getBudget() == null ? "" : String.format("%.2f", FenYuanUtil.getYuanFromFen(campaignGroupModel.getBudget()).doubleValue()));
        result.put(CampaignGroupExportEnum.INDUSTRY, industryName);
        result.put(CampaignGroupExportEnum.CUSTOMER_NAME, customerName);
        result.put(CampaignGroupExportEnum.BRAND, brandName);
        return result;
    }
}
