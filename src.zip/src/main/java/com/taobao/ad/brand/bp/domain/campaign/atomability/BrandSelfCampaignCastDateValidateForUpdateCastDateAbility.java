package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignCastDateValidateForUpdateCastDateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignUpdateCastDateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSelfCampaignCastDateValidateForUpdateCastDateAbility
    implements ICampaignCastDateValidateForUpdateCastDateAbility, BrandSelfServiceAtomAbilityRouter {

    @Override
    public Boolean handle(ServiceContext serviceContext, CampaignUpdateCastDateAbilityParam abilityParam) {
        CampaignViewDTO campaignViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        AssertUtil.assertTrue(
            BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode().equals(dbCampaignViewDTO.getCampaignLevel()),"一级计划才可调整投放周期");
        Date inquiryDeadlineDate = BizCampaignToolsHelper.inquiryDeadline(dbCampaignViewDTO.getCampaignSaleViewDTO().getSaleType(), dbCampaignViewDTO.getCampaignInquiryLockViewDTO().getCampaignInquiryViewDTOList(),
            dbCampaignViewDTO.getCampaignInquiryLockViewDTO().getFirstOnlineTime());
        if(!dbCampaignViewDTO.getStartTime().equals(campaignViewDTO.getStartTime())){
            AssertUtil.assertTrue(BrandDateUtil.isAfterAndEqual(campaignViewDTO.getStartTime(),inquiryDeadlineDate),"开始时间不可调整到"+BrandDateUtil.date2String(inquiryDeadlineDate)+"之前！");
        }
        return true;
    }
}
