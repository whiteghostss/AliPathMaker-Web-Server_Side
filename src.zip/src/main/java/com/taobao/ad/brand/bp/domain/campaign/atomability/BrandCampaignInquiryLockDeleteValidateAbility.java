package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandInquiryStatusEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignInquiryLockDeleteValidateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignDeleteValidateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandCampaignInquiryLockDeleteValidateAbility implements ICampaignInquiryLockDeleteValidateAbility, BrandAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignDeleteValidateAbilityParam abilityParam) {
        CampaignViewDTO dbCampaign = abilityParam.getAbilityTarget();
        AssertUtil.notNull(dbCampaign, BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR,"未找到对应计划");
        // 【库存】存在锁量记录
        List<CampaignInquiryViewDTO> inquiryList = new ArrayList<>();
        if (dbCampaign.getCampaignInquiryLockViewDTO() != null
                && CollectionUtils.isNotEmpty(dbCampaign.getCampaignInquiryLockViewDTO().getCampaignInquiryViewDTOList())) {
            inquiryList.addAll(dbCampaign.getCampaignInquiryLockViewDTO().getCampaignInquiryViewDTOList());
        }
        if (CollectionUtils.isNotEmpty(dbCampaign.getSubCampaignViewDTOList())) {
            for (CampaignViewDTO subCampaignViewDTO : dbCampaign.getSubCampaignViewDTOList()) {
                if (subCampaignViewDTO.getCampaignInquiryLockViewDTO() != null
                        && CollectionUtils.isNotEmpty(subCampaignViewDTO.getCampaignInquiryLockViewDTO().getCampaignInquiryViewDTOList())) {
                    inquiryList.addAll(subCampaignViewDTO.getCampaignInquiryLockViewDTO().getCampaignInquiryViewDTOList());
                }
            }
        }
        Date firstOnlineTime = Objects.nonNull(dbCampaign.getCampaignInquiryLockViewDTO()) ? dbCampaign.getCampaignInquiryLockViewDTO().getFirstOnlineTime() : null;
        if (CollectionUtils.isNotEmpty(inquiryList) && Objects.nonNull(firstOnlineTime)) {
            boolean hasLocked = inquiryList.stream().anyMatch(item -> BrandInquiryStatusEnum.SUCCESS.getCode().equals(item.getStatus()));
            AssertUtil.assertTrue(!hasLocked, "计划上过线且存在锁量成功记录不允许删除");
        }
        return null;
    }
}
