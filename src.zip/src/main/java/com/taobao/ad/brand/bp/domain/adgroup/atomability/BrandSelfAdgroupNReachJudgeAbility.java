package com.taobao.ad.brand.bp.domain.adgroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryLockViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCrowdTypeEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandStockTypeEnum;
import com.alibaba.ad.nb.ssp.constant.newproduct.DeliveryTargetEnum;
import com.alibaba.ad.nb.ssp.constant.newproduct.ProductDirectionEnum;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupNReachJudgeAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupNReachJudgeAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSelfAdgroupNReachJudgeAbility
        implements IAdgroupNReachJudgeAbility, BrandSelfServiceAtomAbilityRouter {

    private final ResourcePackageRepository resourcePackageRepository;

    @Override
    public Boolean handle(ServiceContext context, AdgroupNReachJudgeAbilityParam abilityParam) {
        CampaignViewDTO campaignViewDTO = abilityParam.getAbilityTarget();
        SaleGroupInfoViewDTO saleGroupInfoViewDTO = abilityParam.getSaleGroupInfoViewDTO();

        //非程序化计划不创建
        Optional<CampaignInquiryViewDTO> any = Optional.ofNullable(campaignViewDTO.getCampaignInquiryLockViewDTO())
                .map(CampaignInquiryLockViewDTO::getCampaignInquiryViewDTOList).orElse(Lists.newArrayList()).stream().filter(
                v -> BrandStockTypeEnum.PRECISION.getCode().equals(v.getStockType())).findAny();
        if (!any.isPresent()) {
            RogerLogger.info("计划ID:{}没有精准库存，无需创建优化单元", campaignViewDTO.getId());
            return false;
        }
        if (CollectionUtils.isNotEmpty(saleGroupInfoViewDTO.getDeliveryTargetViewDTOList())) {
            boolean isNreach = saleGroupInfoViewDTO.getDeliveryTargetViewDTOList().stream()
                    .anyMatch(item -> item.getDeliveryTarget().equals(DeliveryTargetEnum.N_REACH.getValue()));
            if (isNreach) {
                ResourcePackageProductViewDTO resourcePackageProductViewDTO = resourcePackageRepository.getResourcePackageSspProduct(context,
                        campaignViewDTO.getCampaignSaleViewDTO().getResourcePackageProductId());
                List<CommonViewDTO> targetList = resourcePackageProductViewDTO.getTargetList();
                if (CollectionUtils.isNotEmpty(targetList)) {
                    boolean isHasDmpCrowd = targetList.stream().anyMatch(e -> Boolean.TRUE.equals(e.getSelected())
                            && e.getValue().equals(ProductDirectionEnum.DMP_CROW.getType()));
                    if (isHasDmpCrowd) {
                        isNreach = resourcePackageProductViewDTO.getTargetConfigList().stream()
                                .filter(targetConfig -> Objects.equals(targetConfig.getValue(), ProductDirectionEnum.DMP_CROW.getType()))
                                .filter(targetConfig -> CollectionUtils.isNotEmpty(targetConfig.getSubDirectionList()))
                                .flatMap(targetConfig -> targetConfig.getSubDirectionList().stream())
                                .noneMatch(item -> Objects.equals(item.getValue(), BrandCrowdTypeEnum.CUSTOM.getCode()));
                    }
                }
            }
            return isNreach;
        }
        return false;
    }
}
