package com.taobao.ad.brand.bp.domain.motion;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.nb.packages.v2.client.dto.motion.IntelligentMotionDTO;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.taobao.ad.brand.bp.client.dto.motion.IntelligentMotionViewDTO;
import com.taobao.ad.brand.bp.client.dto.motion.query.MotionQueryViewDTO;

import java.util.List;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/20
 **/
public interface IntelligentMotionRepository {

    List<IntelligentMotionViewDTO> queryIntelligentMotionList(ServiceContext serviceContext, MotionQueryViewDTO motionQueryViewDTO);
    MultiResponse<IntelligentMotionViewDTO> queryIntelligentMotionPageList(ServiceContext serviceContext, MotionQueryViewDTO motionQueryViewDTO);

    IntelligentMotionViewDTO getIntelligentMotionById(ServiceContext serviceContext, Long id);
    Long saveOrUpdateIntelligentMotion(ServiceContext serviceContext, IntelligentMotionViewDTO motionViewDTO);

    void updateIntelligentMotionListStatus(ServiceContext serviceContext, List<Long> idList, Integer status);
}
