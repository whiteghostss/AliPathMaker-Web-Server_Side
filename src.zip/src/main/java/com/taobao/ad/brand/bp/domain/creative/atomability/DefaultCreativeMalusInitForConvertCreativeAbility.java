package com.taobao.ad.brand.bp.domain.creative.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandAdReviewTypeEnum;
import com.alibaba.ad.nb.ssp.constant.common.BizCodeConstants;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeSaveViewDTO;
import com.taobao.ad.brand.bp.common.constant.AdcRoleConstant;
import com.taobao.ad.brand.bp.common.constant.TemplateConstant;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.memeber.MemberRepository;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.ICreativeMalusInitForConvertCreativeAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeMalusInitAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultCreativeMalusInitForConvertCreativeAbility implements ICreativeMalusInitForConvertCreativeAbility {

    private final MemberRepository memberRepository;
    /**
     * 创意模板-资源类型-app开屏
     */
    private static final String RESOURCE_TYPE_APP = "24";
    /**
     * 创意模板-媒体-手机淘宝
     */
    private static final String MEDIA_TAOBAO = "1778064";

    @Override
    public Void handle(ServiceContext serviceContext, CreativeMalusInitAbilityParam abilityParam) {
        CreativeSaveViewDTO creativeSaveViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(creativeSaveViewDTO,"海棠创意不能为空");
        initAdReviewType(creativeSaveViewDTO);
        initIsTopshowWhiteCustomer(serviceContext, creativeSaveViewDTO);
        return null;
    }

    private void initIsTopshowWhiteCustomer(ServiceContext context, CreativeSaveViewDTO creativeSaveViewDTO) {
        boolean isTopShowWhiteCustomer = this.isWhiteCustomer(context);
        if (isTopShowWhiteCustomer) {
            creativeSaveViewDTO.setIsTopShowWhiteCustomer(BrandBoolEnum.BRAND_TRUE.getCode());
        } else {
            creativeSaveViewDTO.setIsTopShowWhiteCustomer(BrandBoolEnum.BRAND_FALSE.getCode());
        }
    }

    /**
     * 判断是否是白名单客户
     * @param context
     * @return
     */
    public boolean isWhiteCustomer(ServiceContext context) {
        RogerLogger.info("isTopshowWhiteCustomer query memberId={}", context.getMemberId());
        // 查询拥有的白名单权限角色
        if (context.getMemberId() != null) {
            Set<String> uicRoleCodeSet = memberRepository.findRoleCodeByMemberId(context.getMemberId());
            RogerLogger.info("queryIsWhiteCustomer uicRoleCodeSet={}", JSONObject.toJSONString(uicRoleCodeSet));
            return Optional.ofNullable(uicRoleCodeSet).orElse(Sets.newHashSet()).stream().anyMatch(AdcRoleConstant.TOPSHOW_CREATE_CREATIVE_WHITE_CODE::equals);
        }
        return false;
    }

    /**
     * 初始化审核类型
     * @param malusDatumViewDTO
     */
    private static void initAdReviewType(CreativeSaveViewDTO malusDatumViewDTO) {
        AtomicReference<Boolean> isTopShowReviewType = new AtomicReference<>(false);
        malusDatumViewDTO.getTemplateDatum().forEach(malusTemplateViewDTO -> {
            if (Objects.nonNull(malusTemplateViewDTO.getTemplateData())) {
                JSONObject templateData = JSON.parseObject(malusTemplateViewDTO.getTemplateData());
                Map<String, Map<String, Object>> bizMap = (Map<String, Map<String, Object>>) templateData.get(TemplateConstant.CONSTANT_KEY_BIZ_MAP);
                Map<String, Object> properties = bizMap.get(TemplateConstant.CONSTANT_KEY_PROPERTIES);
                if (RESOURCE_TYPE_APP.equals(properties.get(BizCodeConstants.CreativeEnum.RESOURCE_TYPE.getCode()).toString())
                        && MEDIA_TAOBAO.equals(properties.get(BizCodeConstants.CreativeEnum.SITE_ID.getCode()).toString())) {
                    isTopShowReviewType.set(true);
                }
            }
        });
        if (isTopShowReviewType.get()) {
            malusDatumViewDTO.setAdReviewType(BrandAdReviewTypeEnum.TOPSHOW.getValue());
        } else {
            if (BrandBoolEnum.BRAND_TRUE.getCode().equals(malusDatumViewDTO.getIsTop())) {
                malusDatumViewDTO.setAdReviewType(BrandAdReviewTypeEnum.TMALL_COOPERATE_TOP.getValue());
            } else {
                malusDatumViewDTO.setAdReviewType(BrandAdReviewTypeEnum.OTHER.getValue());
            }
        }
    }
}
