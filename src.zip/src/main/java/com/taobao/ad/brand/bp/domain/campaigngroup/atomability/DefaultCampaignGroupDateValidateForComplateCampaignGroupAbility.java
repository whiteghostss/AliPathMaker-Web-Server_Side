package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupDateValidateForCompleteCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupValidateForCancelAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupDateValidateForCompleteCampaignGroupAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupValidateForCancelAbilityParam;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR;

@Component
@BusinessAbility
public class DefaultCampaignGroupDateValidateForComplateCampaignGroupAbility implements ICampaignGroupDateValidateForCompleteCampaignGroupAbility {
    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupDateValidateForCompleteCampaignGroupAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        boolean isStopCast = campaignGroupViewDTO.getCampaignGroupRealSettleViewDTO().getStopCastTime() != null;
        Date campaignGroupFinishDate = isStopCast ? BrandDateUtil.getDateFullMidnight(campaignGroupViewDTO.getCampaignGroupRealSettleViewDTO().getStopCastTime()) : campaignGroupViewDTO.getEndTime();
        AssertUtil.assertTrue(System.currentTimeMillis() - campaignGroupFinishDate.getTime() > 24 * 60 * 60 * 1000, BIZ_BREAK_RULE_ERROR, "请于订单完成日期T+2之后再结案");
        return null;
    }
}
