package com.taobao.ad.brand.bp.domain.config;

import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.domain.config.base.BaseDiamondConfig;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 创意需要填充客户行业信息的模版白名单配置
 */
@Component
public class CreativeRequireCategoryTemplateDiamondConfig extends BaseDiamondConfig {

    private static volatile String config;

    @Override
    protected String getDataId() {
        return "require.customer.category.templates";
    }

    @Override
    protected String getGroupId() {
        return "com.taobao.ad.brand.bp";
    }

    @Override
    protected void initDiamond(String diamondConfig) {
        RogerLogger.info("DiamondConfig.initDiamond CreativeCustomerCategoryTemplateDiamondConfig param: {}", diamondConfig);
        config = diamondConfig;
    }

    /**
     * 获取创意需要填充客户行业信息的模版列表
     */
    /*public List<Long> getRequireCustomerCategoryTemplateIdList() {
        if (StringUtils.isBlank(config)) {
            return Lists.newArrayList();
        }
        return Arrays.stream(StringUtils.split(config, Constant.CHAR_SPLIT_KEY_DOT))
                .map(String::trim)
                .filter(StringUtils::isNotBlank)
                .map(Long::parseLong).distinct().collect(Collectors.toList());
    }*/
}
