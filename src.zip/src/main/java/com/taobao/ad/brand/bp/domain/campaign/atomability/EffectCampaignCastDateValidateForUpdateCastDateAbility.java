package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSaleOrderStatusEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryViewDTO;
import com.taobao.ad.brand.bp.common.constant.campaigngroup.CampaignGroupConstant;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.EffectAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignCastDateValidateForUpdateCastDateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignUpdateCastDateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EffectCampaignCastDateValidateForUpdateCastDateAbility
    implements ICampaignCastDateValidateForUpdateCastDateAbility, EffectAtomAbilityRouter {

    @Resource
    private CampaignRepository campaignRepository;

    @Resource
    private CampaignGroupRepository campaignGroupRepository;

    @Resource
    private ResourcePackageRepository resourcePackageRepository;

    @Override
    public Boolean handle(ServiceContext serviceContext, CampaignUpdateCastDateAbilityParam abilityParam) {
        CampaignViewDTO campaignViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        AssertUtil.notNull(campaignViewDTO,"计划不允许为空");
        AssertUtil.notNull(dbCampaignViewDTO,"计划不存在");

        campaignViewDTO.setEndTime(
            BrandDateUtil.getMaxDate(campaignViewDTO.getEndTime()));
        AssertUtil.assertTrue(
            BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode().equals(dbCampaignViewDTO.getCampaignLevel()),"一级计划才可调整投放周期");
        Date today = BrandDateUtil.getCurrentDate();
        AssertUtil.assertTrue(BrandDateUtil.isBeforeAndEqual(campaignViewDTO.getStartTime(),campaignViewDTO.getEndTime()),"开始时间不可在结束时间之前！");

        if (!campaignViewDTO.getStartTime().equals(dbCampaignViewDTO.getStartTime())) {
            // 上过线的计划，不支持修改历史日期
            if (dbCampaignViewDTO.getCampaignInquiryLockViewDTO().getFirstOnlineTime() != null) {
                AssertUtil.assertTrue(BrandDateUtil.isAfterAndEqual(dbCampaignViewDTO.getStartTime(), today), "上过线的计划不支持修改历史的开始日期！");
            }
            // 修改的开始日期必须在今天或今天之后
            AssertUtil.assertTrue(BrandDateUtil.isAfterAndEqual(campaignViewDTO.getStartTime(), today), "开始时间不可在今天之前！");
        }
        // 修改的开始日期必须在今天或今天之后
        if (!campaignViewDTO.getEndTime().equals(dbCampaignViewDTO.getEndTime())) {
            AssertUtil.assertTrue(BrandDateUtil.isAfterAndEqual(campaignViewDTO.getEndTime(), today), "结束时间不可在今天之前！");
        }

        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(serviceContext, dbCampaignViewDTO.getCampaignGroupId());
        Long saleGroupId = dbCampaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId();
        SaleGroupInfoViewDTO saleGroupInfoViewDTO = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream().filter(item -> item.getSaleGroupId().equals(saleGroupId)).findFirst().orElse(null);
        AssertUtil.assertTrue(saleGroupInfoViewDTO != null && Objects.equals(saleGroupInfoViewDTO.getSaleGroupStatus(), BrandCampaignGroupSaleOrderStatusEnum.WAIT_ORDER.getCode()),"当前分组状态不支持修改计划日期");

        AssertUtil.assertTrue(CampaignGroupConstant.validUpdateSubSaleCampaignGroupStatusList.contains(campaignGroupViewDTO.getStatus()),"当前订单状态不支持修改计划日期");

        //资源包售卖分组
        ResourcePackageQueryViewDTO queryViewDTO = new ResourcePackageQueryViewDTO();
        queryViewDTO.setSaleGroupIdList(Lists.newArrayList(saleGroupId));
        ResourcePackageQueryOption packageQueryOption = ResourcePackageQueryOption.builder().needProduct(false).needSetting(true).build();
        ResourcePackageSaleGroupViewDTO resourceSaleGroup = resourcePackageRepository.getSaleGroupList(serviceContext, queryViewDTO, packageQueryOption).get(0);
        //计划投放周期应当在资源包分组周期之内
        AssertUtil.assertTrue(BrandDateUtil.isAfterAndEqual(campaignViewDTO.getStartTime(), resourceSaleGroup.getStartDate()),"开始时间不可在客户分组开始时间之前！");
        AssertUtil.assertTrue(BrandDateUtil.isBeforeAndEqual(BrandDateUtil.getMinDate(campaignViewDTO.getEndTime()), resourceSaleGroup.getEndDate()),"结束时间不可在客户分组结束时间之后！");

        // 校验adv绑定相关
        if (CollectionUtils.isNotEmpty(dbCampaignViewDTO.getSubCampaignViewDTOList())) {
            List<Long> dbSubCampaignIds = dbCampaignViewDTO.getSubCampaignViewDTOList().stream().map(sub -> sub.getId()).collect(
                Collectors.toList());
            List<Long> advIds = dbCampaignViewDTO.getSubCampaignViewDTOList().stream().map(item->item.getCampaignEffectProxyViewDTO().getEffectAdvId()).collect(Collectors.toList());

            CampaignQueryViewDTO campaignQueryViewDTO = new CampaignQueryViewDTO();
            campaignQueryViewDTO.setAdvIds(advIds);
            campaignQueryViewDTO.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_TWO_CAMPAIGN.getCode());
            List<CampaignViewDTO> advHasBindSubCampainList = campaignRepository.queryCampaignList(serviceContext,campaignQueryViewDTO);
            advHasBindSubCampainList = advHasBindSubCampainList.stream().filter(item -> !dbSubCampaignIds.contains(item.getId())).collect(Collectors.toList());
            if (CollectionUtils.isNotEmpty(advHasBindSubCampainList)) {
                // ADV未关联其他在投、待投的子合同的订单及其补量订单。即ADV历史关联的子合同订单投放周期均结束
                List<Long> unCanBindAdvIds = advHasBindSubCampainList.stream().filter(repeatCampaign -> !new Date().after(repeatCampaign.getEndTime())).map(item->item.getCampaignEffectProxyViewDTO().getEffectAdvId()).collect(Collectors.toList());
                AssertUtil.assertTrue(org.apache.commons.collections4.CollectionUtils.isEmpty(unCanBindAdvIds),"计划下的adv: \"%s\"已绑定其他待投、在投的计划", StringUtils.join(unCanBindAdvIds,","));

                //同一时间段，只能有一个adv可以绑定
                unCanBindAdvIds = advHasBindSubCampainList.stream().filter(item-> org.apache.commons.collections4.CollectionUtils.isNotEmpty(
                        BrandDateUtil.getMixedDate(campaignViewDTO.getStartTime(),
                            campaignViewDTO.getEndTime(),
                            item.getStartTime(),
                            item.getEndTime())))
                    .map(item->item.getCampaignEffectProxyViewDTO().getEffectAdvId())
                    .collect(Collectors.toList());
                AssertUtil.assertTrue(CollectionUtils.isEmpty(unCanBindAdvIds),"计划下的adv: \"%s\"在此周期内其他合同订单已经绑定", StringUtils.join(unCanBindAdvIds,","));
            }
        }
        return true;
    }
}
