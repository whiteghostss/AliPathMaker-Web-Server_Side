package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupTransitAbilityParam;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

import static com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum.FINISHED;

@Component
@BusinessAbility
public class BrandOneBPCampaignGroupJudgeForFinishCampaignGroupAbility
        extends DefaultCampaignGroupJudgeForFinishCampaignGroupAbility implements BrandOneBPAtomAbilityRouter {
    @Resource
    private CampaignGroupRepository campaignGroupRepository;

    @Override
    public Boolean handle(ServiceContext serviceContext, CampaignGroupTransitAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        // 判断当前订单是否已经是“已完成”状态
        if (BizCampaignGroupToolsHelper.campaignGroupStatusAccepted(campaignGroupViewDTO, FINISHED)) {
            return false;
        }

        List<CampaignGroupViewDTO> subCampaignGroupList = campaignGroupRepository.findSubCampaignGroupList(serviceContext, campaignGroupViewDTO.getId());
        return BizCampaignGroupToolsHelper.allCampaignGroupStatusAccepted(subCampaignGroupList, FINISHED);
    }
}
