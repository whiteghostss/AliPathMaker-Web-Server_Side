package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.common.BottomDateViewDTO;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.base.DateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignBottomDateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignImpressionViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignBottomDateGetAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBottomDateGetAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSelfCampaignBottomDateGetAbility implements ICampaignBottomDateGetAbility, BrandSelfServiceAtomAbilityRouter {

    private final CampaignRepository campaignRepository;

    @Override
    public List<CampaignBottomDateViewDTO> handle(ServiceContext serviceContext, CampaignBottomDateGetAbilityParam abilityParam) {
        List<CampaignViewDTO> subCampaignViewDTOList = abilityParam.getAbilityTargets();
        AssertUtil.notEmpty(subCampaignViewDTOList, "子计划信息不能为空");
        //子计划打底周期
        List<Long> subCampaignIds = subCampaignViewDTOList.stream().map(CampaignViewDTO::getId).collect(Collectors.toList());
        return this.getSubCampaignBottomDateList(serviceContext,subCampaignIds,abilityParam.getNoReadyStatusList());
    }

    private List<CampaignBottomDateViewDTO> getSubCampaignBottomDateList(ServiceContext serviceContext, List<Long> subCampaignIds,List<CampaignImpressionViewDTO.CampaignImpressionStatusEnum> noReadyStatusList) {
        List<CampaignBottomDateViewDTO> result = Lists.newArrayList();
        List<CampaignImpressionViewDTO> campaignImpressionInfoList = campaignRepository.getCampaignImpressionInfoList(serviceContext, subCampaignIds);

        if (CollectionUtils.isEmpty(noReadyStatusList)){
            noReadyStatusList.add(CampaignImpressionViewDTO.CampaignImpressionStatusEnum.NOT_READY);
        }

        Optional<CampaignImpressionViewDTO> impressionDTOOptional = campaignImpressionInfoList.stream()
                .filter(info -> info.getStatus() != null && noReadyStatusList.contains(info.getStatus()))
                .findAny();

        if(impressionDTOOptional.isPresent()) {
            throw new BrandOneBPException("媒体尚未录入排期pubdeal，暂不能创建媒体直投");
        }
        Map<Long, List<CampaignImpressionViewDTO>> campaignImpressionInfoMap = campaignImpressionInfoList
                .stream()
                .collect(Collectors.groupingBy(CampaignImpressionViewDTO::getSubCampaignId));
        campaignImpressionInfoMap.forEach((subCampaignId, impressionInfoList) -> {
            List<BottomDateViewDTO> bottomDateViewDTOList = convertToBottomDateViewDTO(impressionInfoList);
            CampaignBottomDateViewDTO campaignBottomDateViewDTO = new CampaignBottomDateViewDTO();
            campaignBottomDateViewDTO.setSubCampaignId(subCampaignId);
            List<DateViewDTO> dateViewDTOList = Optional.ofNullable(bottomDateViewDTOList).orElse(Lists.newArrayList()).stream().map(item->{
                DateViewDTO dateViewDTO =new DateViewDTO();
                dateViewDTO.setStartDate(item.getStartDate());
                dateViewDTO.setEndDate(item.getEndDate());
                return dateViewDTO;
            }).collect(Collectors.toList());
            campaignBottomDateViewDTO.setBottomDateList(dateViewDTOList);
            result.add(campaignBottomDateViewDTO);
            RogerLogger.info("onebp-purchaseOrder-imprecision 子计划ID：{} 具备非精准打底资格，打底信息如下，result={}",subCampaignId, JSON.toJSONString(impressionInfoList));
        });
        return result;

    }

    private List<BottomDateViewDTO> convertToBottomDateViewDTO(List<CampaignImpressionViewDTO> dateList){
        List<Date> days= dateList.stream().map(CampaignImpressionViewDTO::getDate).filter(Objects::nonNull).distinct().sorted().collect(Collectors.toList());
        List<BottomDateViewDTO> resultList = Lists.newArrayList();
        List<DateViewDTO> dateViewDTOList = BrandDateUtil.formatDateQuantum(days);
        if (CollectionUtils.isNotEmpty(dateViewDTOList)){
            resultList = dateViewDTOList.stream().map(t->{
                BottomDateViewDTO bottomDateViewDTO = new BottomDateViewDTO();
                bottomDateViewDTO.setStartDate(t.getStartDate());
                bottomDateViewDTO.setEndDate(t.getEndDate());

                return bottomDateViewDTO;

            }).collect(Collectors.toList());
        }
        return resultList;
    }
}
