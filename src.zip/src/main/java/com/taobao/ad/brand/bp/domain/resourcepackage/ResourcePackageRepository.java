package com.taobao.ad.brand.bp.domain.resourcepackage;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquirySchedulePolicyViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupBoostGiveApplyInfoViewDTO;
import com.alibaba.ad.brand.dto.demand.DemandViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.salegroup.CampaignGroupSaleGroupBoostGiveApplyViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProjectViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageTemplateViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.wto.SupplierSolutionGroupViewDTO;

import java.util.Date;
import java.util.List;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/25
 */
public interface ResourcePackageRepository {

    /**
     * 获取资源售卖分组列表
     *
     * @param serviceContext
     * @param saleGroupIds
     * @param queryOption
     * @return
     */
    List<ResourcePackageSaleGroupViewDTO> getSaleGroupList(ServiceContext serviceContext, List<Long> saleGroupIds, ResourcePackageQueryOption queryOption);

    /**
     * 获取资源售卖分组列表
     *
     * @param serviceContext
     * @param queryViewDTO
     * @param queryOption
     * @return
     */
    List<ResourcePackageSaleGroupViewDTO> getSaleGroupList(ServiceContext serviceContext, ResourcePackageQueryViewDTO queryViewDTO, ResourcePackageQueryOption queryOption);

    /**
     * 获取售卖分组
     *
     * @param serviceContext
     * @param id
     * @return
     */
    ResourcePackageSaleGroupViewDTO getSaleGroupById(ServiceContext serviceContext, Long id, ResourcePackageQueryOption queryOption);

    /**
     * 售卖分组基础信息（含editMode）
     *
     * @return
     */
    ResourcePackageSaleGroupViewDTO getSaleGroupWithEditMode(ServiceContext serviceContext, Long saleGroupId);

    /**
     * 获取售卖产品
     *
     * @param context
     * @param packageSaleGroupViewDTO
     * @param resourcePackageProductId
     * @return
     */
    ResourcePackageProductViewDTO getResourcePackageProduct(ServiceContext context, ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO, Long resourcePackageProductId);
    /**
     * 批量获取打包平台产品详情（无定向等）
     * @param context
     * @param resourcePackageProductId
     * @return
     */
    ResourcePackageProductViewDTO getSimpleResourcePackageProduct(ServiceContext context, Long resourcePackageProductId);

    /**
     * 查询打包平台产品信息（包含定向等数据）
     * @param context
     * @param resourcePackageProductId
     * @return
     */
    ResourcePackageProductViewDTO getResourcePackageProduct(ServiceContext context, Long resourcePackageProductId);

    /**
     * 获取资源包产品对应周期的预定量周期比例
     *
     * @param resourcePackageProductViewDTO
     * @param startTime
     * @param endTime
     * @return
     */
    List<CampaignInquirySchedulePolicyViewDTO> getResourcePackageProductSchedulePolicyList(ResourcePackageProductViewDTO resourcePackageProductViewDTO, Date startTime, Date endTime);

    /**
     * 根据客户模板ID查询客户模板信息
     *
     * @param serviceContext
     * @param marketingTemplateId
     * @return
     */
    ResourcePackageTemplateViewDTO getCustomerTemplateById(ServiceContext serviceContext, Long marketingTemplateId);

    ResourcePackageTemplateViewDTO getResourceTemplateBySaleGroupId(ServiceContext serviceContext, Long saleGroupId);

    /**
     * 发起补量、配送分组申请
     *
     * @param serviceContext
     * @param applyViewDTO
     * @return
     */
    Long applySaleGroup(ServiceContext serviceContext, SaleGroupBoostGiveApplyInfoViewDTO applyInfoViewDTO, Long mainGroupId);

    /**
     * 删除补量/配送分组
     *
     * @param serviceContext
     * @param applyInfoViewDTO
     * @param mainGroupId
     * @return
     */
    Long deleteSaleGroup(ServiceContext serviceContext, SaleGroupBoostGiveApplyInfoViewDTO applyInfoViewDTO, Long mainGroupId);

    /**
     * 根据resourceProductId查询产品信息
     *
     * @param serviceContext
     * @param resourceProductIds
     * @return
     */
    List<ResourcePackageProductViewDTO> getLevelOneResourcePackageProductList(ServiceContext serviceContext, List<Long> resourceProductIds);

    ResourcePackageProductViewDTO getResourcePackageSspProduct(ServiceContext serviceContext, Long resourceProductId);


    /**
     * 内容黑盒资源替换
     *
     * @param serviceContext
     * @param demandViewDTOList
     * @param solutionGroupList
     */
    void confirmResourcePackage(ServiceContext serviceContext, List<DemandViewDTO> demandViewDTOList, List<SupplierSolutionGroupViewDTO> solutionGroupList);

    /**
     * 获取资源包项目
     *
     * @param serviceContext
     * @param marketingProjectId
     * @return
     */
    ResourcePackageProjectViewDTO getResourcePackageProject(ServiceContext serviceContext, Long marketingProjectId) ;

    /**
     * 获取权益模版
     * @param serviceContext 上下文
     * @return 全量权益模版
     */
    @Deprecated
    public List<Long> findRightsTemplateIdList(ServiceContext serviceContext);
}
