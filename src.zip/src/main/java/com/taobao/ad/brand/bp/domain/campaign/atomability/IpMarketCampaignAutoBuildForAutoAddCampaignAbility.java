package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.guarantee.CampaignGuaranteeViewDTO;
import com.alibaba.ad.brand.dto.campaign.sale.CampaignSaleViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSaleOrderStatusEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupStatusEnum;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.IpMarketAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignAutoBuildForAutoAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignAutoBuildForAutoAddCampaignAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class IpMarketCampaignAutoBuildForAutoAddCampaignAbility implements ICampaignAutoBuildForAutoAddCampaignAbility,IpMarketAtomAbilityRouter {

    private final CampaignRepository campaignRepository;

    @Override
    public List<CampaignViewDTO> handle(ServiceContext serviceContext, CampaignAutoBuildForAutoAddCampaignAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(campaignGroupViewDTO,"订单不能为空");
        // 订单分组
        Map<Long, SaleGroupInfoViewDTO> campaignGroupSaleGroupMap = abilityParam.getSaleGroupInfoMap();
        AssertUtil.notEmpty(campaignGroupSaleGroupMap,"订单分组不能为空");
        // 资源包分组
        Map<Long, ResourcePackageSaleGroupViewDTO> packageSaleGroupMap = abilityParam.getPackageSaleGroupMap();
        AssertUtil.notEmpty(packageSaleGroupMap,"资源包分组不能为空");
        // 二级产品
        Map<Long, ProductViewDTO> sspProductMap = abilityParam.getSspProductMap();
        AssertUtil.notEmpty(sspProductMap,"SSP产品不能为空");

        Long campaignGroupId = campaignGroupViewDTO.getId();
        List<Long> campaignGroupSaleGroupIds = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList()
                .stream().map(SaleGroupInfoViewDTO::getSaleGroupId).collect(Collectors.toList());
        // 查询分组计划
        CampaignQueryViewDTO query = new CampaignQueryViewDTO();
        query.setCampaignGroupId(campaignGroupId);
        query.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
        query.setSaleGroupIds(campaignGroupSaleGroupIds);
        Map<Long, List<CampaignViewDTO>> resourcePackageProduct2CampaignMap = campaignRepository.queryCampaignList(serviceContext, query).
                stream().collect(Collectors.groupingBy(t -> t.getCampaignSaleViewDTO().getResourcePackageProductId()));
        // 构建返回结果
        List<CampaignViewDTO> campaignViewDTOList = Lists.newArrayList();
        for (Long saleGroupId : campaignGroupSaleGroupIds) {
            // 订单分组
            SaleGroupInfoViewDTO campaignGroupSaleGroup = campaignGroupSaleGroupMap.get(saleGroupId);
            if (!BrandCampaignGroupSaleOrderStatusEnum.WAIT_ORDER.getCode().equals(campaignGroupSaleGroup.getSaleGroupStatus())) {
                RogerLogger.info("campaignGroupId: {} saleGroupId: {} saleGroupStatus: {}, 不满足自动创建计划的条件", campaignGroupId, saleGroupId, campaignGroupSaleGroup.getSaleGroupStatus());
                continue;
            }
            // 资源包分组
            ResourcePackageSaleGroupViewDTO packageSaleGroup = packageSaleGroupMap.get(saleGroupId);
            if (!SaleGroupStatusEnum.EFFECTIVE.getValue().equals(packageSaleGroup.getStatus())) {
                RogerLogger.info("campaignGroupId: {} saleGroupId: {} packageSaleGroupStatus: {}, 不满足自动创建计划的条件", campaignGroupId, saleGroupId, packageSaleGroup.getStatus());
                continue;
            }
            Date startTime = BrandDateUtil.getMaxDate(packageSaleGroup.getStartDate(), BrandDateUtil.getTomorrowDate());
            Date endTime = BrandDateUtil.getDateFullMidnight(packageSaleGroup.getEndDate());
            if (startTime == null|| startTime.after(endTime)) {
                RogerLogger.info("campaignGroupId: {} saleGroupId: {} startTime: {} isAfter endTime: {} , 不满足自动创建计划的条件", campaignGroupId, saleGroupId, startTime, endTime);
                continue;
            }
            // 根据二级产品创建计划
            List<ResourcePackageProductViewDTO> resourcePackageProductList = packageSaleGroup.getDistributionRuleList().stream()
                    .flatMap(rule -> rule.getResourcePackageProductList().stream()).collect(Collectors.toList());
            for (ResourcePackageProductViewDTO resourcePackageProduct : resourcePackageProductList) {
                if (resourcePackageProduct2CampaignMap.containsKey(resourcePackageProduct.getId())) {
                    RogerLogger.info("campaignGroupId: {} saleGroupId: {} resourcePackageProductId: {} 已创建计划, 不满足自动创建计划的条件", campaignGroupId, saleGroupId, resourcePackageProduct.getId());
                    continue;
                }
                // 查询ssp产品
                ProductViewDTO productViewDTO = sspProductMap.get(resourcePackageProduct.getSspProductId());
                CampaignViewDTO campaignViewDTO = buildAutoAddCampaignParam(serviceContext, campaignGroupViewDTO, packageSaleGroup, resourcePackageProduct, productViewDTO, startTime, endTime);
                campaignViewDTOList.add(campaignViewDTO);
            }
        }
        return campaignViewDTOList;
    }

    private CampaignViewDTO buildAutoAddCampaignParam(ServiceContext serviceContext,
                                                                 CampaignGroupViewDTO campaignGroupViewDTO,
                                                                 ResourcePackageSaleGroupViewDTO packageSaleGroup,
                                                                 ResourcePackageProductViewDTO resourcePackageProduct,
                                                                 ProductViewDTO productViewDTO,
                                                                 Date startTime, Date endTime) {
        CampaignViewDTO campaignViewDTO = new CampaignViewDTO();
        // 基本信息
        campaignViewDTO.setCampaignGroupId(campaignGroupViewDTO.getId());
        campaignViewDTO.setStartTime(startTime);
        campaignViewDTO.setEndTime(endTime);
        // CPT预订量
        CampaignGuaranteeViewDTO campaignGuaranteeViewDTO = new CampaignGuaranteeViewDTO();
        Integer saleType = resourcePackageProduct.getSaleUnit() == null ?  productViewDTO.getSellUnit() : resourcePackageProduct.getSaleUnit();
        if (BizCampaignToolsHelper.isTwoCPT(productViewDTO.getMediaScope(), saleType)) {
            long totalDateRange = BrandDateUtil.getDateRange(startTime, endTime) + 1;
            campaignGuaranteeViewDTO.setCptAmount(totalDateRange);
        }
        campaignViewDTO.setCampaignGuaranteeViewDTO(campaignGuaranteeViewDTO);
        // 分组信息
        CampaignSaleViewDTO campaignSaleViewDTO = new CampaignSaleViewDTO();
        campaignSaleViewDTO.setSaleGroupId(packageSaleGroup.getId());
        campaignSaleViewDTO.setResourcePackageProductId(resourcePackageProduct.getId());
        campaignViewDTO.setCampaignSaleViewDTO(campaignSaleViewDTO);

        return campaignViewDTO;
    }
}
