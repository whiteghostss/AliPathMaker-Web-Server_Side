package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignTitleValidateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignTitleValidateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_ILLEGAL;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSelfCampaignTitleValidateAbility implements ICampaignTitleValidateAbility, BrandSelfServiceAtomAbilityRouter {

    private final CampaignRepository campaignRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignTitleValidateAbilityParam abilityParam) {
        CampaignViewDTO campaignViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(campaignViewDTO,"计划不能为空");
        if(StringUtils.isBlank(campaignViewDTO.getTitle())){
            return null;
        }
        // 【计划名称】1、长度<=100，为空自动生成
        AssertUtil.maxLength(campaignViewDTO.getTitle(),100,"计划名称长度小于等于100");
        // 【计划名称】同账户下计划名称不能重复
        CampaignQueryViewDTO queryViewDTO = new CampaignQueryViewDTO();
        queryViewDTO.setTitleEq(campaignViewDTO.getTitle());
        queryViewDTO.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
        List<CampaignViewDTO> sameNameCampaignList = campaignRepository.queryCampaignList(serviceContext, queryViewDTO);
        if (CollectionUtils.isNotEmpty(sameNameCampaignList) && campaignViewDTO.getId() != null) {
            sameNameCampaignList = sameNameCampaignList.stream()
                    .filter(e -> !e.getId().equals(campaignViewDTO.getId())).collect(Collectors.toList());
        }
        AssertUtil.assertTrue(CollectionUtils.isEmpty(sameNameCampaignList), PARAM_ILLEGAL, "账号下存在同名计划");
        return null;
    }
}
