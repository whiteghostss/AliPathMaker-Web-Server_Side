package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.threadpooltask.CampaignDeleteTaskIdentifier;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignDeleteAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBatchAbilityParam;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component
@BusinessAbility
public class DefaultCampaignDeleteAbility implements ICampaignDeleteAbility {

    @Resource
    private CampaignDeleteTaskIdentifier campaignDeleteTaskIdentifier;
    @Resource
    private CampaignRepository campaignRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignBatchAbilityParam abilityParam) {
        List<CampaignViewDTO> deleteCampaignViewDTOList = abilityParam.getAbilityTargets();
        if (CollectionUtils.isEmpty(deleteCampaignViewDTOList)) {
            return null;
        }
        TaskStream.consume(campaignDeleteTaskIdentifier, deleteCampaignViewDTOList, (campaignViewDTO, index) -> {
                    // 需要保证计划删除后，绑定的单元也被删除
                    deleteCampaign(serviceContext, campaignViewDTO);
                })
                .commit()
                .handle();
        return null;
    }

    public void deleteCampaign(ServiceContext context, CampaignViewDTO campaignViewDTO) {
        // 删除主计划
        CampaignViewDTO updateCampaignViewDTO = new CampaignViewDTO();
        updateCampaignViewDTO.setId(campaignViewDTO.getId());
        updateCampaignViewDTO.setStatus(BrandCampaignStatusEnum.DELETE.getCode());
        campaignRepository.updateCampaignPart(context, updateCampaignViewDTO);
        //需要删除的所有计划id
        List<Long> needDelCampaignIdList = Lists.newArrayList(campaignViewDTO.getId());
        // 删除子计划
        List<CampaignViewDTO> subCampaignViewDTOList = campaignViewDTO.getSubCampaignViewDTOList();
        if (CollectionUtils.isNotEmpty(subCampaignViewDTOList)) {
            List<CampaignViewDTO> subUpdateCampaignViewDTOList = Lists.newArrayList();
            subCampaignViewDTOList.forEach(item -> {
                CampaignViewDTO updateSubCampaignViewDTO = new CampaignViewDTO();
                updateSubCampaignViewDTO.setId(item.getId());
                updateSubCampaignViewDTO.setStatus(BrandCampaignStatusEnum.DELETE.getCode());
                subUpdateCampaignViewDTOList.add(updateSubCampaignViewDTO);
                needDelCampaignIdList.add(item.getId());
            });
            campaignRepository.updateCampaignPart(context, subUpdateCampaignViewDTOList);
        }
        //删除计划人群定向
        try {
            campaignRepository.deleteAllTargetByCampaignIds(context,needDelCampaignIdList);
        } catch (Exception e) {
            RogerLogger.error(String.format("计划人群定向删除失败，计划ids=%s", StringUtils.join(needDelCampaignIdList,",")),e);
        }
    }


}
