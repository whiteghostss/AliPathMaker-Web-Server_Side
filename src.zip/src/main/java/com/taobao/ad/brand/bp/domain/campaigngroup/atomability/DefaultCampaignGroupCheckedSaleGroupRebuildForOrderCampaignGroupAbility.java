package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleGroupSourceEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupOrderCommandViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.salegroup.SaleGroupCheckedRebuildResultViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupCheckedSaleGroupRebuildForOrderCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupCheckedSaleGroupRebuildForOrderAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_REQUIRED;

@Component
@BusinessAbility
public class DefaultCampaignGroupCheckedSaleGroupRebuildForOrderCampaignGroupAbility implements ICampaignGroupCheckedSaleGroupRebuildForOrderCampaignGroupAbility {

    @Override
    public SaleGroupCheckedRebuildResultViewDTO handle(ServiceContext serviceContext, CampaignGroupCheckedSaleGroupRebuildForOrderAbilityParam abilityParam) {
        CampaignGroupOrderCommandViewDTO orderCommandViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(orderCommandViewDTO.getSaleGroupIds()), PARAM_REQUIRED, "勾选的分组不能为空");
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        SaleGroupCheckedRebuildResultViewDTO rebuildResultViewDTO = new SaleGroupCheckedRebuildResultViewDTO();
        // 售卖中心平台分组
        List<Long> salePlatformSaleGroupIds = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream()
                .filter(t -> BrandSaleGroupSourceEnum.SALE_PLATFORM.getCode().equals(t.getSource()))
                .map(SaleGroupInfoViewDTO::getSaleGroupId)
                .collect(Collectors.toList());

        List<Long> selectedSalePlatformSaleGroupIds = salePlatformSaleGroupIds.stream()
                .filter(saleGroupId -> orderCommandViewDTO.getSaleGroupIds().contains(saleGroupId))
                .collect(Collectors.toList());
        rebuildResultViewDTO.setSalePlatformSaleGroupIds(selectedSalePlatformSaleGroupIds);

        if (CollectionUtils.isNotEmpty(selectedSalePlatformSaleGroupIds)) {
            List<Long> orderSaleGroupIds = Lists.newArrayList(salePlatformSaleGroupIds);
            // 添加资源包平台分组
            List<Long> selectedPackagePlatformSaleGroupIds = orderCommandViewDTO.getSaleGroupIds()
                    .stream().filter(t -> !selectedSalePlatformSaleGroupIds.contains(t))
                    .collect(Collectors.toList());
            rebuildResultViewDTO.setPackagePlatformSaleGroupIds(selectedPackagePlatformSaleGroupIds);
            if (CollectionUtils.isNotEmpty(selectedPackagePlatformSaleGroupIds)) {
                orderSaleGroupIds.addAll(selectedPackagePlatformSaleGroupIds);
            }
            rebuildResultViewDTO.setCalOrderSaleGroupIds(orderSaleGroupIds);
        } else {
            rebuildResultViewDTO.setPackagePlatformSaleGroupIds(orderCommandViewDTO.getSaleGroupIds());
            rebuildResultViewDTO.setCalOrderSaleGroupIds(orderCommandViewDTO.getSaleGroupIds());
        }

        return rebuildResultViewDTO;
    }
}
