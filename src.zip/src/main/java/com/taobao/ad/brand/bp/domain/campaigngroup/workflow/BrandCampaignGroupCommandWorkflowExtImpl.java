package com.taobao.ad.brand.bp.domain.campaigngroup.workflow;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.salegroup.CampaignGroupSaleGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignProgrammaticEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.alibaba.ad.nb.ssp.constant.common.MediaScopeEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.calculate.CampaignCalViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.calculate.CampaignGroupSaleGroupCalViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.calculate.ProductCampaignCalViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.CampaignGroupSaleGroupEstimateQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.workflow.router.BrandExtensionRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.workflow.param.BizCampaignGroupCalculateWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.workflow.param.BizCampaignGroupPurchaseOrderWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.delivery.ISaleGroupEstimateResultClearForSaleGroupEstimateAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.workflow.param.BizSaleGroupEstimateWorkflowParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Description:品牌订单扩展
 * <p>
 * date: 2023/10/24 2:51 PM
 *
 * @author shiyan
 * @version 1.0
 */
@Service
@BusinessAbility
public class BrandCampaignGroupCommandWorkflowExtImpl extends DefaultCampaignGroupCommandWorkflowExtImpl implements BrandExtensionRouter {

    @Resource
    private CampaignGroupRepository campaignGroupRepository;
    @Resource
    private ResourcePackageRepository resourcePackageRepository;
    @Resource
    private ICampaignStructureQueryAbility campaignStructureQueryAbility;
    @Resource
    private ISaleGroupEstimateResultClearForSaleGroupEstimateAbility saleGroupEstimateResultClearForSaleGroupEstimateAbility;


    @Override
    public BizCampaignGroupCalculateWorkflowParam buildParamForCalculate(ServiceContext serviceContext, CampaignGroupSaleGroupCalViewDTO saleGroupCalViewDTO) {
        AssertUtil.notNull(saleGroupCalViewDTO,"计算信息不允许为空");
        AssertUtil.notNull(saleGroupCalViewDTO.getCampaignGroupId(), "订单ID不允许为空");
        AssertUtil.notNull(saleGroupCalViewDTO.getSaleGroupId(),"售卖分组ID不允许为空");
        AssertUtil.notEmpty(saleGroupCalViewDTO.getProductCampaignList(), "订单计算资源信息不能为空");
        //资源包产品id
        List<Long> packageProductIdList = Lists.newArrayList();
        for (ProductCampaignCalViewDTO productCalViewDTO : saleGroupCalViewDTO.getProductCampaignList()) {
            AssertUtil.notNull(productCalViewDTO.getResourcePackageProductId(), "订单计算资源ID不能为空");
            if (CollectionUtils.isNotEmpty(productCalViewDTO.getCampaignList())) {
                for (CampaignCalViewDTO campaignCalViewDTO : productCalViewDTO.getCampaignList()) {
                    AssertUtil.notNull(campaignCalViewDTO.getCampaignId(), "订单计算计划ID不能为空");
                }
            }
            packageProductIdList.add(productCalViewDTO.getResourcePackageProductId());
        }
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(serviceContext, saleGroupCalViewDTO.getCampaignGroupId());
        AssertUtil.notNull(campaignGroupViewDTO, "订单不存在");

        SaleGroupInfoViewDTO saleGroupInfoViewDTO = Optional.ofNullable(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO()).map(CampaignGroupSaleGroupViewDTO::getSaleGroupInfoViewDTOList).orElse(Lists.newArrayList())
                .stream().filter(saleGroupInfo -> Objects.equals(saleGroupCalViewDTO.getSaleGroupId(),saleGroupInfo.getSaleGroupId())).findFirst().orElse(null);
        AssertUtil.notNull(saleGroupInfoViewDTO, "订单售卖分组不存在");

        ResourcePackageQueryOption packageQueryOption = ResourcePackageQueryOption.builder().needProduct(true).needSetting(true).build();
        ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO = resourcePackageRepository.getSaleGroupById(serviceContext, saleGroupCalViewDTO.getSaleGroupId(), packageQueryOption);
        AssertUtil.notNull(packageSaleGroupViewDTO,"资源包售卖分组不存在");

        List<ResourcePackageProductViewDTO> packageProductViewDTOList = packageSaleGroupViewDTO.getDistributionRuleList().stream().flatMap(e -> e.getResourcePackageProductList().stream())
                .filter(e -> packageProductIdList.contains(e.getId())).collect(Collectors.toList());
        AssertUtil.notNull(packageProductViewDTOList, "售卖分组资源位不存在");
        AssertUtil.assertTrue(packageProductViewDTOList.size() == packageProductIdList.size(), "售卖分组部分资源位不存在");

        //查询资源包产品关联的所有计划
        List<CampaignViewDTO> campaignTreeViewDTOList = findPackageProductCampaignList(serviceContext, saleGroupCalViewDTO.getCampaignGroupId(), packageProductIdList);
        AssertUtil.notNull(campaignTreeViewDTOList, "订单计算计划不存在");

        BizCampaignGroupCalculateWorkflowParam calculateWorkflowParam = BizCampaignGroupCalculateWorkflowParam.builder()
                .campaignGroupViewDTO(campaignGroupViewDTO)
                .packageSaleGroupViewDTO(packageSaleGroupViewDTO)
                .saleGroupInfoViewDTO(saleGroupInfoViewDTO)
                .campaignTreeViewDTOList(campaignTreeViewDTOList)
                .build();

        return calculateWorkflowParam;
    }

    @Override
    public BizCampaignGroupPurchaseOrderWorkflowParam buildParamForPurchaseOrder(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO) {
        BizCampaignGroupPurchaseOrderWorkflowParam purchaseOrderWorkflowParam = new BizCampaignGroupPurchaseOrderWorkflowParam();
        CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder()
                .campaignGroupId(campaignGroupViewDTO.getId())
                .campaignLevel(BrandCampaignLevelEnum.LEVEL_TWO_CAMPAIGN.getCode())
                .mediaScopeList(Collections.singletonList(MediaScopeEnum.SITE_OUT.getCode()))
                .sspProgrammatic(BrandCampaignProgrammaticEnum.SYSTEM_CAST.getCode())
                .saleTypes(Lists.newArrayList(BrandSaleTypeEnum.BUY.getCode())).build();
        List<CampaignViewDTO> subCampaignViewDTOList = campaignStructureQueryAbility.handle(serviceContext, CampaignStructureQueryAbilityParam.builder()
                .abilityTarget(campaignQueryViewDTO).queryOption(CampaignQueryOption.builder().needTarget(true).needFrequency(true).build()).build());
        purchaseOrderWorkflowParam.setCampaignList(subCampaignViewDTOList);

        return purchaseOrderWorkflowParam;
    }

    @Override
    public BizSaleGroupEstimateWorkflowParam buildWorkflowParamForEstimate(ServiceContext context, CampaignGroupSaleGroupEstimateQueryViewDTO estimateQueryViewDTO) {
        AssertUtil.notNull(estimateQueryViewDTO, BrandOneBPBaseErrorCode.PARAM_REQUIRED,"参数为空");
        AssertUtil.notNull(estimateQueryViewDTO.getCampaignGroupId(), BrandOneBPBaseErrorCode.PARAM_REQUIRED,"订单ID为空");
        AssertUtil.notEmpty(estimateQueryViewDTO.getSaleGroupIds(),BrandOneBPBaseErrorCode.PARAM_REQUIRED,"分组信息不能为空");

        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(context, estimateQueryViewDTO.getCampaignGroupId());
        AssertUtil.notNull(campaignGroupViewDTO, "订单不存在");

        List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList = Optional.ofNullable(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO()).map(CampaignGroupSaleGroupViewDTO::getSaleGroupInfoViewDTOList).orElse(Lists.newArrayList())
                .stream().filter(saleGroupInfo -> estimateQueryViewDTO.getSaleGroupIds().contains(saleGroupInfo.getSaleGroupId())).collect(Collectors.toList());
        AssertUtil.notEmpty(saleGroupInfoViewDTOList, BrandOneBPBaseErrorCode.BIZ_DATA_EMPTY_ERROR,"分组不存在，请检查");

        List<Long> dbSaleGroupIds = saleGroupInfoViewDTOList.stream().map(SaleGroupInfoViewDTO::getSaleGroupId).distinct().collect(Collectors.toList());
        List<Long> notHasIds = estimateQueryViewDTO.getSaleGroupIds().stream().filter(item->!dbSaleGroupIds.contains(item)).collect(Collectors.toList());
        AssertUtil.assertTrue(CollectionUtils.isEmpty(notHasIds),BrandOneBPBaseErrorCode.BIZ_DATA_EMPTY_ERROR,String.format("分组ID:%s未找到", org.apache.commons.lang3.StringUtils.join(notHasIds,",")));

        List<ResourcePackageSaleGroupViewDTO> packageSaleGroupViewDTOList = resourcePackageRepository.getSaleGroupList(context,
                ResourcePackageQueryViewDTO.builder().saleGroupIdList(estimateQueryViewDTO.getSaleGroupIds()).build(),
                ResourcePackageQueryOption.builder().needSetting(true).needProduct(true).build());
        AssertUtil.notEmpty(packageSaleGroupViewDTOList, BrandOneBPBaseErrorCode.BIZ_DATA_EMPTY_ERROR,"售卖分组不存在，请检查");

        return BizSaleGroupEstimateWorkflowParam.builder().campaignGroupViewDTO(campaignGroupViewDTO).saleGroupInfoViewDTOList(saleGroupInfoViewDTOList)
                .packageSaleGroupViewDTOList(packageSaleGroupViewDTOList).build();
    }

    /**
     * 查询资源包二级产品下的所有计划
     * @param context
     * @param campaignGroupId
     * @param packageProductIdList
     * @return
     */
    private List<CampaignViewDTO> findPackageProductCampaignList(ServiceContext context, Long campaignGroupId,List<Long> packageProductIdList) {
        CampaignQueryViewDTO campaignQueryViewDTO = new CampaignQueryViewDTO();
        campaignQueryViewDTO.setCampaignGroupId(campaignGroupId);
        campaignQueryViewDTO.setResourcePackageProductIds(packageProductIdList);
        campaignQueryViewDTO.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
        CampaignQueryOption campaignQueryOption = new CampaignQueryOption();
        campaignQueryOption.setNeedTarget(true);
        campaignQueryOption.setNeedFrequency(true);
        campaignQueryOption.setNeedChildren(true);

        return campaignStructureQueryAbility.handle(context, CampaignStructureQueryAbilityParam.builder()
                .abilityTarget(campaignQueryViewDTO).queryOption(campaignQueryOption).build());
    }
}