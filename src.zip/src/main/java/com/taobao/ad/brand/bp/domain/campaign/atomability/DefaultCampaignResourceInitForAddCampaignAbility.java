package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.resource.CampaignResourceViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignResourceInitForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignResourceAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultCampaignResourceInitForAddCampaignAbility implements ICampaignResourceInitForAddCampaignAbility {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignResourceAbilityParam abilityParam) {
        CampaignResourceViewDTO campaignResourceViewDTO = abilityParam.getAbilityTarget();
        ProductViewDTO productViewDTO = abilityParam.getProductViewDTO();
        AssertUtil.notNull(productViewDTO, "产品不能为空");
        AssertUtil.notNull(campaignResourceViewDTO, "计划资源不能为空");
        campaignResourceViewDTO.setSspProductId(productViewDTO.getId());
        campaignResourceViewDTO.setSspProductUuid(productViewDTO.getUuid());
        campaignResourceViewDTO.setSspResourceTypes(productViewDTO.getResourceTypeList());
        campaignResourceViewDTO.setSspMediaId(productViewDTO.getCustomerOrientedMediaId());
        campaignResourceViewDTO.setSspResourceIds(productViewDTO.getResourceIdList());
        campaignResourceViewDTO.setSspMediaScope(productViewDTO.getMediaScope());
        campaignResourceViewDTO.setSspCrossScene(productViewDTO.getCrossScene());
        campaignResourceViewDTO.setSspProductLineId(productViewDTO.getProductLineId());
        return null;
    }
}
