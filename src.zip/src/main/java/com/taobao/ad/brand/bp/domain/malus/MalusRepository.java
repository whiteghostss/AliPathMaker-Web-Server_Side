package com.taobao.ad.brand.bp.domain.malus;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.dto.creative.crop.MalusCropViewDTO;

import java.util.List;

public interface MalusRepository {

    String asyncBatchCrop(ServiceContext serviceContext, List<MalusCropViewDTO> cropViewDTOList);
}
