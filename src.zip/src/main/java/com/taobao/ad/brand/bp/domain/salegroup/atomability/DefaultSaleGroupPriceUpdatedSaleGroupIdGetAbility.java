package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.price.DayPriceViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.ResourcePackageProductViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.SaleGroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourceDistributionRuleViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupPriceUpdatedSaleGroupIdGetAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupPriceUpdatedIdGetAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultSaleGroupPriceUpdatedSaleGroupIdGetAbility implements ISaleGroupPriceUpdatedSaleGroupIdGetAbility {

    private final CampaignGroupRepository campaignGroupRepository;

    @Override
    public List<Long> handle(ServiceContext serviceContext, SaleGroupPriceUpdatedIdGetAbilityParam abilityParam) {
        List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList = abilityParam.getAbilityTargets();
        if (CollectionUtils.isEmpty(saleGroupInfoViewDTOList)) {
            return Lists.newArrayList();
        }
        // 子订单
        CampaignGroupViewDTO subCampaignGroup = abilityParam.getCampaignGroupViewDTO();
        // 资源包分组
        Map<Long, ResourcePackageSaleGroupViewDTO> resoucePackageSaleGroupMap = abilityParam.getResourcePackageSaleGroupList().stream()
                .collect(Collectors.toMap(ResourcePackageSaleGroupViewDTO::getId, Function.identity(), (v1, v2) -> v1));

        // 主订单分组
        SaleGroupQueryViewDTO saleGroupQueryViewDTO = new SaleGroupQueryViewDTO();
        saleGroupQueryViewDTO.setCampaignGroupIds(Lists.newArrayList(subCampaignGroup.getParentId()));
        List<SaleGroupInfoViewDTO> parentCampaignGroupSaleGroupList = campaignGroupRepository.findSaleGroupList(serviceContext, saleGroupQueryViewDTO);
        Map<Long, SaleGroupInfoViewDTO> parentSaleGroupMap = parentCampaignGroupSaleGroupList.stream()
                .collect(Collectors.toMap(SaleGroupInfoViewDTO::getSaleGroupId, t -> t, (v1, v2) -> v1));

        List<Long> updatedSaleGroupIds = Lists.newArrayList();
        for (SaleGroupInfoViewDTO campaignGroupSaleGroup : saleGroupInfoViewDTOList) {
            ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO = resoucePackageSaleGroupMap.get(campaignGroupSaleGroup.getSaleGroupId());
            // 只查询资源包分组中存在的分组
            if (Objects.isNull(resourcePackageSaleGroupViewDTO)) {
                continue;
            }
            SaleGroupInfoViewDTO parentCamSaleGroup = parentSaleGroupMap.get(campaignGroupSaleGroup.getSaleGroupId());
            // 1. 校验budget是否发生变更
            boolean hasUpdate = Objects.nonNull(campaignGroupSaleGroup.getCalcBudget())
                    && Objects.nonNull(parentCamSaleGroup) && Objects.nonNull(parentCamSaleGroup.getBudget())
                    && !Objects.equals(parentCamSaleGroup.getBudget(), campaignGroupSaleGroup.getCalcBudget());
            // 2. 校验单价是否发生变更
            hasUpdate = hasUpdate || judgeProductUnitPriceUpdated(resourcePackageSaleGroupViewDTO, campaignGroupSaleGroup.getResourcePackageProductViewDTOList());
            if (hasUpdate) {
                updatedSaleGroupIds.add(campaignGroupSaleGroup.getSaleGroupId());
            }
        }

        return updatedSaleGroupIds;
    }

    /**
     * 资源包单价是否已更新
     * 1-是，0-否
     */
    private boolean judgeProductUnitPriceUpdated(ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO,
                                                List<ResourcePackageProductViewDTO> campaignGroupResourcePackageProductViewDTOList) {
        RogerLogger.info("resourcePackageSaleGroupViewDTO:{}, campaignGroupResourcePackageProductViewDTOList:{}", JSON.toJSONString(resourcePackageSaleGroupViewDTO), JSON.toJSONString(campaignGroupResourcePackageProductViewDTOList));
        if (CollectionUtils.isEmpty(campaignGroupResourcePackageProductViewDTOList)) {
            return false;
        }

        Map<String, Long> productUnitPriceMap = Maps.newHashMap();
        for (ResourceDistributionRuleViewDTO resourceDistributionRuleViewDTO : resourcePackageSaleGroupViewDTO.getDistributionRuleList()) {
            if (CollectionUtils.isEmpty(resourceDistributionRuleViewDTO.getResourcePackageProductList())) {
                continue;
            }
            for (com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO resourcePackageProductViewDTO : resourceDistributionRuleViewDTO.getResourcePackageProductList()) {
                for (ResourcePackageProductPriceViewDTO priceViewDTO : resourcePackageProductViewDTO.getBandPriceList()) {
                    Set<Date> betweenDates = BrandDateUtil.getBetweenDatesDateResult(priceViewDTO.getStartDate(), priceViewDTO.getEndDate());
                    for (Date date : betweenDates) {
                        productUnitPriceMap.put(getUniqueKey(resourcePackageProductViewDTO.getId(), date), priceViewDTO.getPrice());
                    }
                }
            }
        }

        for (ResourcePackageProductViewDTO productViewDTO : campaignGroupResourcePackageProductViewDTOList) {
            for (DayPriceViewDTO dayPriceViewDTO : productViewDTO.getDiscountDayPriceInfoViewDTOList()) {
                Set<Date> betweenDates = BrandDateUtil.getBetweenDatesDateResult(dayPriceViewDTO.getStartDate(), dayPriceViewDTO.getEndDate());
                for (Date date : betweenDates) {
                    String uniqueKey = getUniqueKey(productViewDTO.getResourcePackageProductId(), date);
                    boolean equal = dayPriceViewDTO.getPrice().equals(productUnitPriceMap.get(uniqueKey));
                    if (!equal) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private String getUniqueKey(Long resourcePackageProductId, Date date) {
        return resourcePackageProductId + "_" + BrandDateUtil.date2String(date);
    }
}
