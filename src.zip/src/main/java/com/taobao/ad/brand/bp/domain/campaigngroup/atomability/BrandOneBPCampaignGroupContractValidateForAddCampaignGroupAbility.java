package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.contract.CampaignGroupContractViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupContractValidateForAddCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupContractAbilityParam;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
public class BrandOneBPCampaignGroupContractValidateForAddCampaignGroupAbility
        implements ICampaignGroupContractValidateForAddCampaignGroupAbility, BrandOneBPAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupContractAbilityParam abilityParam) {
        if (!BizCampaignGroupToolsHelper.isSaleCampaignGroup(abilityParam.getCampaignGroupViewDTO())) {
            return null;
        }
        CampaignGroupContractViewDTO campaignGroupContractViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(campaignGroupContractViewDTO, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "合同信息不能为空");
        AssertUtil.assertTrue(campaignGroupContractViewDTO.getContractStartTime() != null, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "合同开始时间不能为空");
        AssertUtil.assertTrue(campaignGroupContractViewDTO.getContractEndTime() != null, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "合同结束时间不能为空");
        AssertUtil.assertTrue(BrandDateUtil.notAfter(campaignGroupContractViewDTO.getContractStartTime(), campaignGroupContractViewDTO.getContractEndTime()), BrandOneBPBaseErrorCode.PARAM_REQUIRED, "合同开始时间不能晚于结束时间");

        return null;
    }
}
