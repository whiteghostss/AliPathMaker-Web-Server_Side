package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleGroupSourceEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizSaleGroupToolsHelper;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupValidateForApplyModifyCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupOrderAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultSaleGroupValidateForApplyModifyCampaignGroupAbility implements ISaleGroupValidateForApplyModifyCampaignGroupAbility {

    @Override
    public Void handle(ServiceContext serviceContext, SaleGroupOrderAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        List<Long> saleGroupIds = abilityParam.getSaleGroupIds();
        List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupList = abilityParam.getResourcePackageSaleGroupList();
        List<SaleGroupInfoViewDTO> salePlatformSaleGroupList = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream()
                .filter(t -> BrandSaleGroupSourceEnum.SALE_PLATFORM.getCode().equals(t.getSource()))
                .collect(Collectors.toList());
        if (CollectionUtils.isEmpty(salePlatformSaleGroupList)) {
            return null;
        }
        // 校验规则配送场景，购买和配送分组需同时勾选
        Map<Long, SaleGroupInfoViewDTO> saleGroupInfoViewDTOMap = salePlatformSaleGroupList.stream().collect(Collectors.toMap(SaleGroupInfoViewDTO::getSaleGroupId, Function.identity(), (v1, v2) -> v1));
        saleGroupIds.forEach(saleGroupId -> {
            SaleGroupInfoViewDTO saleGroupInfoViewDTO = saleGroupInfoViewDTOMap.get(saleGroupId);
            if (Objects.nonNull(saleGroupInfoViewDTO)) {
                if (BrandSaleTypeEnum.BUY.getCode().equals(saleGroupInfoViewDTO.getSaleType())) {
                    List<Long> presentSaleGroupIds = salePlatformSaleGroupList.stream().filter(it -> saleGroupInfoViewDTO.getSaleGroupId().equals(it.getMainSaleGroupId()))
                            .map(SaleGroupInfoViewDTO::getSaleGroupId).collect(Collectors.toList());
                    if (CollectionUtils.isNotEmpty(presentSaleGroupIds)) {
                        AssertUtil.assertTrue(new HashSet<>(saleGroupIds).containsAll(presentSaleGroupIds), BIZ_BREAK_RULE_ERROR,
                                String.format("模板规则配送场景，购买分组(%s)和配送分组(%s)需同时勾选",
                                        StringUtils.join(BizSaleGroupToolsHelper.getSaleGroupNames(resourcePackageSaleGroupList, Lists.newArrayList(saleGroupInfoViewDTO.getSaleGroupId())), ","),
                                        StringUtils.join(BizSaleGroupToolsHelper.getSaleGroupNames(resourcePackageSaleGroupList, presentSaleGroupIds), ",")));
                    }
                } else if (BrandSaleTypeEnum.PRESENT.getCode().equals(saleGroupInfoViewDTO.getSaleType())) {
                    Long mainSaleGroupId = saleGroupInfoViewDTO.getMainSaleGroupId();
                    AssertUtil.assertTrue(saleGroupIds.contains(mainSaleGroupId), BIZ_BREAK_RULE_ERROR,
                            String.format("模板规则配送场景，购买分组(%s)和配送分组(%s)需同时勾选",
                                    StringUtils.join(BizSaleGroupToolsHelper.getSaleGroupNames(resourcePackageSaleGroupList, Lists.newArrayList(mainSaleGroupId)), ","),
                                    StringUtils.join(BizSaleGroupToolsHelper.getSaleGroupNames(resourcePackageSaleGroupList, Lists.newArrayList(saleGroupInfoViewDTO.getSaleGroupId())), ",")));
                }
            }
        });

        return null;
    }
}
