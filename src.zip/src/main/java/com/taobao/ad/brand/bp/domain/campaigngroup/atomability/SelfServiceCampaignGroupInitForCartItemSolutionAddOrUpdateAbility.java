package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.complete.CampaignGroupCompleteConfigViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.contract.CampaignGroupContractViewDTO;
import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSourceEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.alibaba.ad.brand.sdk.constant.cartitem.BrandCartItemTypeEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupInitForCartItemSolutionAddOrUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupInitForCartItemSolutionAddOrUpdateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCampaignGroupInitForCartItemSolutionAddOrUpdateAbility
        implements ICampaignGroupInitForCartItemSolutionAddOrUpdateAbility, SelfServiceAtomAbilityRouter {

    @Override
    public CampaignGroupViewDTO handle(ServiceContext serviceContext, CampaignGroupInitForCartItemSolutionAddOrUpdateAbilityParam abilityParam) {
        CartItemViewDTO cartItemViewDTO = abilityParam.getAbilityTarget();
        if (!BrandCartItemTypeEnum.SLIM_ORDER.getCode().equals(cartItemViewDTO.getType())) {
            return null;
        }

        // base
        CampaignGroupViewDTO campaignGroupViewDTO = new CampaignGroupViewDTO();
        campaignGroupViewDTO.setStatus(BrandCampaignGroupStatusEnum.DRAFT.getCode());
        campaignGroupViewDTO.setSource(BrandCampaignGroupSourceEnum.SLIM_ORDER.getCode());
        campaignGroupViewDTO.setSourceIds(Lists.newArrayList(cartItemViewDTO.getId()));
        // 合同
        campaignGroupViewDTO.setCampaignGroupContractViewDTO(new CampaignGroupContractViewDTO());
        campaignGroupViewDTO.getCampaignGroupContractViewDTO().setPayMode(cartItemViewDTO.getPayMode());
        // 结案品牌
        campaignGroupViewDTO.setCampaignGroupCompleteConfigViewDTO(new CampaignGroupCompleteConfigViewDTO());
        campaignGroupViewDTO.getCampaignGroupCompleteConfigViewDTO().setBrandViewDTOList(cartItemViewDTO.getBrandViewDTOList());

        return campaignGroupViewDTO;
    }
}
