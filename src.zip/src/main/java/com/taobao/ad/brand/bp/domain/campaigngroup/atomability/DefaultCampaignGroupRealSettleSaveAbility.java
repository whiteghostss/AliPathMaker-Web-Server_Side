package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.realsettle.CampaignGroupRealSettleViewDTO;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupRealSettleSaveAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupRealSettleSaveAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
@BusinessAbility
public class DefaultCampaignGroupRealSettleSaveAbility
    implements ICampaignGroupRealSettleSaveAbility {

    @Resource
    private CampaignGroupRepository campaignGroupRepository;

    @Override
    public Integer handle(ServiceContext serviceContext,
                       CampaignGroupRealSettleSaveAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        CampaignGroupViewDTO updateCampaignGroupViewDTO = new CampaignGroupViewDTO();
        updateCampaignGroupViewDTO.setId(campaignGroupViewDTO.getId());
        CampaignGroupRealSettleViewDTO realSettleViewDTO = new CampaignGroupRealSettleViewDTO();
        // 原始金额
        if (campaignGroupViewDTO.getCampaignGroupRealSettleViewDTO().getOriginalCampaignGroupBudget() != null) {
            updateCampaignGroupViewDTO.setBudget(campaignGroupViewDTO.getBudget());
            realSettleViewDTO.setOriginalCampaignGroupBudget(campaignGroupViewDTO.getCampaignGroupRealSettleViewDTO().getOriginalCampaignGroupBudget());
        }
        realSettleViewDTO.setRealSettleProcessStatus(campaignGroupViewDTO.getCampaignGroupRealSettleViewDTO().getRealSettleProcessStatus());
        realSettleViewDTO.setRealSettleInfoViewDTOList(campaignGroupViewDTO.getCampaignGroupRealSettleViewDTO().getRealSettleInfoViewDTOList());
        if (campaignGroupViewDTO.getCampaignGroupRealSettleViewDTO().getRealSettleProcessId() != null) {
            realSettleViewDTO.setRealSettleProcessId(campaignGroupViewDTO.getCampaignGroupRealSettleViewDTO().getRealSettleProcessId());
        }
        updateCampaignGroupViewDTO.setCampaignGroupRealSettleViewDTO(realSettleViewDTO);

        if (CollectionUtils.isNotEmpty(campaignGroupViewDTO.getProcessRecordViewDTOList())) {
            updateCampaignGroupViewDTO.setProcessRecordViewDTOList(campaignGroupViewDTO.getProcessRecordViewDTOList());
        }

        return campaignGroupRepository.updateCampaignGroupPart(serviceContext, updateCampaignGroupViewDTO);
    }
}
