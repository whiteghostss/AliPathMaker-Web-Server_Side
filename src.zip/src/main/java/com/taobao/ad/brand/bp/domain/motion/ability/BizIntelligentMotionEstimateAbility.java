package com.taobao.ad.brand.bp.domain.motion.ability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.nb.packages.constant.ud.RuleComparatorEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.motion.MotionSourceEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.product.CastTypeEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupAmountSettingTypeEnum;
import com.alibaba.ad.nb.packages.v2.client.dto.product.ProductBandPriceDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.product.ResourcePackageProductDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.salegroup.SaleGroupDeliveryTargetDTO;
import com.alibaba.ad.nb.ssp.constant.common.MediaScopeEnum;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.alimama.faas.brand.engine.entity.constant.ServiceCodeEnum;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.dto.campaign.PriceEnginePublishPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.DmpArgusEstimateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.SaleGroupBaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.SaleGroupProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.cartitem.query.CartItemQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.motion.*;
import com.taobao.ad.brand.bp.client.dto.product.AdzoneViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageAmountSettingViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSkuViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.query.BrandSkuQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.BrandDeliveryTargetEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.threadpooltask.ProductPriceBatchTaskIdentifier;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.CalculateUtil;
import com.taobao.ad.brand.bp.domain.cart.repository.CartItemRepository;
import com.taobao.ad.brand.bp.domain.feed.FeedRepository;
import com.taobao.ad.brand.bp.domain.priceEngine.PriceEngineRepository;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.shopwindow.repository.BrandSkuRepository;
import com.taobao.ad.brand.bp.domain.ssp.AdzoneRepository;
import com.taobao.ad.brand.bp.domain.ssp.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.RoundingMode;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;


/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/21
 **/
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizIntelligentMotionEstimateAbility {

    @Resource
    FeedRepository feedRepository;

    @Resource
    ProductRepository productRepository;

    @Resource
    AdzoneRepository adzoneRepository;

    @Resource
    BrandSkuRepository brandSkuRepository;

    @Resource
    ResourcePackageRepository resourcePackageRepository;

    @Resource
    CartItemRepository cartItemRepository;

    @Resource
    PriceEngineRepository priceEngineRepository;

    @Resource
    ProductPriceBatchTaskIdentifier productPriceBatchTaskIdentifier;

    /**
     * 构建售卖分组预估模型
     * @param serviceContext
     * @param motionViewDTO
     * @param saleGroupViewDTO
     * @param strategyViewDTO
     * @return
     */
    public DmpArgusEstimateViewDTO buildEstimateViewDTOList(ServiceContext serviceContext, IntelligentMotionViewDTO motionViewDTO, ResourcePackageSaleGroupViewDTO saleGroupViewDTO, IntelligentStrategyViewDTO strategyViewDTO, Integer estimateDimensionType) {
        DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO = new DmpArgusEstimateViewDTO();
        dmpArgusEstimateViewDTO.setServiceCode(ServiceCodeEnum.BrandStrategyRecommend.name());
        // motionSource决定是「小二版投前策略」还是百灵橱窗的「智能预算分配」
        // estimateDimensionType 决定是对提案进行计算还是对已有的策略进行计算
        // motionSource = 1时，estimateDimensionType = 4（智能提案） 表示在百灵投前策略上发起一个新的智能提案计算；estimateDimensionType = 5（智能策略） 表示在百灵投前策略上针对已有的策略进行预估数据实时更新，或者生成自定义策略的过程
        // motionSource = 2时，estimateDimensionType = 4（智能提案） 表示在百灵商品橱窗「智能预算分配」发起一个新的智能提案计算；
        dmpArgusEstimateViewDTO.setEstimateDimensionType(estimateDimensionType);
        if (MotionSourceEnum.PRE_STRATEGY.getValue().equals(motionViewDTO.getSource())) {
            SaleGroupBaseViewDTO saleGroupBaseViewDTO = new SaleGroupBaseViewDTO();
            saleGroupBaseViewDTO.setSaleType(saleGroupViewDTO.getSaleType());
            saleGroupBaseViewDTO.setProductConfigType(saleGroupViewDTO.getProductConfigType());
            List<ResourcePackageProductViewDTO> resourcePackageProductList = saleGroupViewDTO.getDistributionRuleList().stream().flatMap(item -> item.getResourcePackageProductList().stream()).collect(Collectors.toList());
            Map<Long, Map<Integer,List<ProductStrategyViewDTO>>> productStrategyViewDTOMap = Maps.newHashMap();
            if (Objects.nonNull(strategyViewDTO) && Objects.nonNull(strategyViewDTO.getDistributionRuleDTOList())) {
                productStrategyViewDTOMap =strategyViewDTO.getDistributionRuleDTOList().stream()
                        .flatMap(item -> item.getProductStrategyList().stream())
                        .collect(Collectors.groupingBy(ProductStrategyViewDTO::getResourcePackageProductId, Collectors.groupingBy(ProductStrategyViewDTO::getCastType)));
            }
            saleGroupBaseViewDTO.setSaleGroupProductViewDTOList(buildSaleGroupProductViewDTOList(resourcePackageProductList, productStrategyViewDTOMap, motionViewDTO.getSource()));
            //自定义策略场景增加策略id
            if (Objects.nonNull(strategyViewDTO) && BrandBoolEnum.BRAND_TRUE.getCode().equals(strategyViewDTO.getStrategyType())) {
                saleGroupBaseViewDTO.setStrategyId(strategyViewDTO.getId());
            }
            RogerLogger.info("initSaleGroupEstimateViewDTOList.saleGroupBaseViewDTO:{}",JSON.toJSONString(saleGroupBaseViewDTO));
            dmpArgusEstimateViewDTO.setSaleGroupBaseViewDTO(saleGroupBaseViewDTO);
            //增加分组的约束条件
            List<IntelligentDistributionRuleViewDTO> intelligentDistributionRuleViewDTOList = saleGroupViewDTO.getDistributionRuleList().stream().map(item -> {
                IntelligentDistributionRuleViewDTO intelligentDistributionRuleViewDTO = new IntelligentDistributionRuleViewDTO();
                BeanUtils.copyProperties(item,intelligentDistributionRuleViewDTO,"resourcePackageProductList");
                return intelligentDistributionRuleViewDTO;
            }).collect(Collectors.toList());
            dmpArgusEstimateViewDTO.setDistributionRuleViewDTOList(intelligentDistributionRuleViewDTOList);

        } else if (MotionSourceEnum.BUDGET_ALLOCATION.getValue().equals(motionViewDTO.getSource())) {
            // 智能预算分配场景的产品信息
            List<CartItemViewDTO> cartItemViewDTOList = cartItemRepository.findCartList(serviceContext, CartItemQueryViewDTO.builder().idList(motionViewDTO.getCartItemIdList()).build());
            Map<Long, Long> cartAndSkuMap = cartItemViewDTOList.stream().collect(Collectors.toMap(CartItemViewDTO::getId, CartItemViewDTO::getSkuId));

            List<BrandSkuViewDTO> brandSkuViewDTOList = brandSkuRepository.findSkuList(serviceContext, BrandSkuQueryViewDTO.builder().idList(cartItemViewDTOList.stream().map(CartItemViewDTO::getSkuId).collect(Collectors.toList())).build());
            List<Long> resourcePackageSaleGroupIdList = brandSkuViewDTOList.stream().map(BrandSkuViewDTO::getResourcePackageSaleGroupId).distinct().collect(Collectors.toList());
            Map<Long, Integer> saleGroupSaleProductLineMap = resourcePackageRepository.getSaleGroupList(serviceContext, resourcePackageSaleGroupIdList, ResourcePackageQueryOption.builder().needProduct(Boolean.FALSE).needInquiryPriority(Boolean.FALSE).needSetting(Boolean.TRUE).build()).stream().collect(Collectors.toMap(ResourcePackageSaleGroupViewDTO::getId, ResourcePackageSaleGroupViewDTO::getSaleProductLine));
            Map<Long, Integer> skuSaleProductLineMap = brandSkuViewDTOList.stream().collect(Collectors.toMap(BrandSkuViewDTO::getId, it -> saleGroupSaleProductLineMap.get(it.getResourcePackageSaleGroupId())));
            Map<Long, Long> skuAndProductMap = brandSkuViewDTOList.stream().collect(Collectors.toMap(BrandSkuViewDTO::getId, BrandSkuViewDTO::getResourcePackageProductId));

            List<ResourcePackageProductViewDTO> resourcePackageProductList = resourcePackageRepository.getLevelOneResourcePackageProductList(serviceContext, brandSkuViewDTOList.stream().map(BrandSkuViewDTO::getResourcePackageProductId).distinct().collect(Collectors.toList()));
            Map<Long, SaleGroupProductViewDTO> saleGroupProductViewDTOMap = buildSaleGroupProductViewDTOList(resourcePackageProductList, null, motionViewDTO.getSource()).stream().collect(Collectors.toMap(SaleGroupProductViewDTO::getResourceProductId, Function.identity()));
            List<SaleGroupProductViewDTO> saleGroupProductViewDTOList = Lists.newArrayList();
            for (CartItemViewDTO cartItemViewDTO : cartItemViewDTOList) {
                Long resourcePackageProductId = skuAndProductMap.get(cartAndSkuMap.get(cartItemViewDTO.getId()));
                if (Objects.nonNull(resourcePackageProductId)) {
                    SaleGroupProductViewDTO saleGroupProductViewDTO = saleGroupProductViewDTOMap.get(resourcePackageProductId);
                    saleGroupProductViewDTO.setCartId(cartItemViewDTO.getId());
                    saleGroupProductViewDTOList.add(saleGroupProductViewDTO);
                }
            }
            dmpArgusEstimateViewDTO.setSaleGroupProductViewDTOList(saleGroupProductViewDTOList);
            dmpArgusEstimateViewDTO.setSkuSaleProductLineMap(skuSaleProductLineMap);
            dmpArgusEstimateViewDTO.setCartItemViewDTOList(cartItemViewDTOList);
            //交互结构变更,增加分组默认约束条件
            IntelligentDistributionRuleViewDTO intelligentDistributionRuleViewDTO = new IntelligentDistributionRuleViewDTO();
            intelligentDistributionRuleViewDTO.setCategory("N");
            intelligentDistributionRuleViewDTO.setCategoryName("N");
            intelligentDistributionRuleViewDTO.setRatio(10000);
            intelligentDistributionRuleViewDTO.setMinQuality(1);
            intelligentDistributionRuleViewDTO.setMaxQuality(999);
            dmpArgusEstimateViewDTO.setDistributionRuleViewDTOList(Lists.newArrayList(intelligentDistributionRuleViewDTO));
        }
        //基于customerMemberId查询店铺id
        Long shopId = feedRepository.getShopIdByMemberId(serviceContext.getMemberId());
        if (shopId != null && !shopId.equals(0L)){
            dmpArgusEstimateViewDTO.setShopId(shopId);
        }
        dmpArgusEstimateViewDTO.setMemberId(serviceContext.getMemberId());
        dmpArgusEstimateViewDTO.setIntelligentMotionViewDTO(motionViewDTO);

        return dmpArgusEstimateViewDTO;
    }

    private List<SaleGroupProductViewDTO> buildSaleGroupProductViewDTOList(List<ResourcePackageProductViewDTO> resourcePackageProductList, Map<Long, Map<Integer,List<ProductStrategyViewDTO>>> productStrategyViewDTOMap, Integer source){
        if (CollectionUtils.isEmpty(resourcePackageProductList)){
            return Lists.newArrayList();
        }
        List<Long> sspProductIds = resourcePackageProductList.stream().map(ResourcePackageProductViewDTO::getSspProductId).distinct().collect(Collectors.toList());
        Map<Long, ProductViewDTO> sspProductMap =  productRepository.getProductMapByIds(sspProductIds);

        Map<String, Map<String, ResourcePackageProductPriceViewDTO>> productBandPriceMap = new HashMap<>();
        if (MapUtils.isEmpty(productStrategyViewDTOMap) && MotionSourceEnum.PRE_STRATEGY.getValue().equals(source)) {
            productBandPriceMap = getProductBandPriceList(resourcePackageProductList, sspProductMap);
        }

        Map<String, Map<String, ResourcePackageProductPriceViewDTO>> finalProductBandPriceMap = productBandPriceMap;
        List<SaleGroupProductViewDTO> saleGroupProductViewDTOList = resourcePackageProductList.stream().map(item -> {
            SaleGroupProductViewDTO saleGroupProductViewDTO = new SaleGroupProductViewDTO();
            saleGroupProductViewDTO.setResourceProductId(item.getId());
            saleGroupProductViewDTO.setSaleUnit(item.getSaleUnit());
            saleGroupProductViewDTO.setSspProductId(item.getSspProductId());
            saleGroupProductViewDTO.setSspProductUuid(item.getSspProductUuid());
            ProductViewDTO productViewDTO = sspProductMap.getOrDefault(saleGroupProductViewDTO.getSspProductId(),null);
            AssertUtil.assertTrue(null != productViewDTO,"产品配置有问题， 请联系运营");
            setProductViewFromRemoteProduct(saleGroupProductViewDTO,productViewDTO);
            saleGroupProductViewDTO.setMediaScope(item.getMediaScope());
            saleGroupProductViewDTO.setBandPriceList(item.getBandPriceList());
            saleGroupProductViewDTO.setCategory(item.getCategory());

            //智能策略重设单价,获取高加收价格, 非智能无需重新获取,已在 ad-brandonebp指定
            Map<String, ResourcePackageProductPriceViewDTO> bandPriceMap = finalProductBandPriceMap.getOrDefault(productViewDTO.getLabel()
                    + "_" + productViewDTO.getSellUnit()
                    + "_" + productViewDTO.getResourceTypeList().stream().filter(Objects::nonNull).map(String::valueOf).collect(Collectors.joining(",")),null);
            if (bandPriceMap != null) {
                saleGroupProductViewDTO.getBandPriceList().forEach(bandPriceDTO -> {
                    //获取价格中心的加收价格
                    ResourcePackageProductPriceViewDTO productPriceViewDTO = bandPriceMap.get(BrandDateUtil.date2String(bandPriceDTO.getStartDate(), BrandDateUtil.DATE_FORMAT_YYYYMMDD_TYPE_2) + "_" + BrandDateUtil.date2String(bandPriceDTO.getEndDate(), BrandDateUtil.DATE_FORMAT_YYYYMMDD_TYPE_2));
                    if (productPriceViewDTO == null) {
                        return;
                    }
                    Long price = productPriceViewDTO.getPublishPrice();
                    if (bandPriceDTO.getPriceRatio() != null) {
                        price = CalculateUtil.multiplyCalculate(price, bandPriceDTO.getPriceRatio(), 10000L, RoundingMode.DOWN);
                    }
                    bandPriceDTO.setPrice(price);
                });
            }

            saleGroupProductViewDTO.setSspResourceTypes(productViewDTO.getResourceTypeList());
            saleGroupProductViewDTO.setCastType(item.getCastType().getType());
            return saleGroupProductViewDTO;
        }).collect(Collectors.toList());
        // 针对 投放方式=PDorPDB 的产品进行拆分处理
        List<SaleGroupProductViewDTO> splitSaleGroupProductList = Lists.newArrayList();
        saleGroupProductViewDTOList.stream().filter(it -> CastTypeEnum.PD_OR_PDB.getValue().equals(it.getCastType())).forEach(it -> {
            it.setCastType(CastTypeEnum.PD.getValue());
            SaleGroupProductViewDTO saleGroupProductViewDTO = new SaleGroupProductViewDTO();
            BeanUtils.copyProperties(it, saleGroupProductViewDTO);
            saleGroupProductViewDTO.setCastType(CastTypeEnum.PDB.getValue());
            splitSaleGroupProductList.add(saleGroupProductViewDTO);
        });
        saleGroupProductViewDTOList.addAll(splitSaleGroupProductList);

        if (MapUtils.isNotEmpty(productStrategyViewDTOMap)) {
            saleGroupProductViewDTOList.forEach(item -> {
                if (productStrategyViewDTOMap.containsKey(item.getResourceProductId())) {
                    Map<Integer,List<ProductStrategyViewDTO>> castTypeProducteStrategyViewDTOMap = productStrategyViewDTOMap.get(item.getResourceProductId());
                    if (castTypeProducteStrategyViewDTOMap.containsKey(item.getCastType())) {
                        List<ProductStrategyViewDTO> productStrategyViewDTOList = castTypeProducteStrategyViewDTOMap.get(item.getCastType());
                        AssertUtil.assertTrue(productStrategyViewDTOList.size() == 1, BrandOneBPBaseErrorCode.PARAM_BREAK_RULE.getErrCode(), "指定打包平台产品id和投放方式后只能有一个产品");
                        item.setBandPriceList(productStrategyViewDTOList.get(0).getProductBandPriceStrategyViewDTOList().stream().map(productBandPriceStrategyViewDTO -> {
                            ResourcePackageProductPriceViewDTO productPriceViewDTO = new ResourcePackageProductPriceViewDTO();
                            productPriceViewDTO.setStartDate(productBandPriceStrategyViewDTO.getStartTime());
                            productPriceViewDTO.setEndDate(productBandPriceStrategyViewDTO.getEndTime());
                            productPriceViewDTO.setPrice(productBandPriceStrategyViewDTO.getPrice());
                            // 该字段后续要作为产品粒度的预算传给算法进行计算，针对不同场景有不同的设置逻辑，对于现在这种「手动设置预算生成自定义策略」的场景，需要设置为运营手填值
                            productPriceViewDTO.setActualAmount(productBandPriceStrategyViewDTO.getBudget());
                            productPriceViewDTO.setType(productBandPriceStrategyViewDTO.getType());
                            productPriceViewDTO.setMinRatio(productBandPriceStrategyViewDTO.getMinRatio());
                            productPriceViewDTO.setCastAmount(productBandPriceStrategyViewDTO.getCastAmount());
                            return productPriceViewDTO;
                        }).collect(Collectors.toList()));
                    } else {
                        item.getBandPriceList().forEach(it -> it.setActualAmount(0L));
                    }
                } else {
                    item.getBandPriceList().forEach(it -> it.setActualAmount(0L));
                }
            });
        }
        return saleGroupProductViewDTOList;
    }

    private void setProductViewFromRemoteProduct( SaleGroupProductViewDTO saleGroupProductViewDTO,ProductViewDTO productViewDTO){

        //取sspProductId
        //跨域
        List<Long> adzoneIds = productViewDTO.getAdzoneIdList();
        if (MediaScopeEnum.CROSS_SCOPE.getCode().equals( productViewDTO.getMediaScope())){
            adzoneIds =  productViewDTO.getAssociationProductList().stream().filter(item-> CollectionUtils.isNotEmpty(item.getAdzoneList())).flatMap(item->item.getAdzoneIdList().stream()).collect(Collectors.toList());
        }
        List<AdzoneViewDTO> adzoneViewDTOList =  adzoneRepository.getAdzoneListByAdzoneIds(adzoneIds);
        saleGroupProductViewDTO.setAdzoneViewDTOList(adzoneViewDTOList);
        saleGroupProductViewDTO.setPromiseClick(Objects.nonNull(productViewDTO.getPromiseClick()) ? productViewDTO.getPromiseClick().intValue(): 1);
        saleGroupProductViewDTO.setClickRate(productViewDTO.getClickRate() != null ?productViewDTO.getClickRate().longValue(): 10000);
        saleGroupProductViewDTO.setUnitExposure(Objects.nonNull(productViewDTO.getUnitExposure()) ? productViewDTO.getUnitExposure().intValue() : 1);
        saleGroupProductViewDTO.setTemplateIdList(productViewDTO.getTemplateIdList());
    }

    /**
     * 校验智能提案
     * @param motionViewDTO
     */
    public void validateBaseInfoIntelligentMotion(IntelligentMotionViewDTO motionViewDTO) {
        AssertUtil.notNull(motionViewDTO);
        AssertUtil.notNull(motionViewDTO.getName(), BrandOneBPBaseErrorCode.PARAM_REQUIRED,"智能提案名称不能为空");
        AssertUtil.notNull(motionViewDTO.getMemberId(), BrandOneBPBaseErrorCode.PARAM_REQUIRED,"投放账号不能为空");
        AssertUtil.notNull(motionViewDTO.getSaleGroupId(), BrandOneBPBaseErrorCode.PARAM_REQUIRED, "分组id不能为空");
        AssertUtil.notNull(motionViewDTO.getMarketingScene(), BrandOneBPBaseErrorCode.PARAM_REQUIRED, "营销场景不能为空");
        AssertUtil.assertTrue(Objects.nonNull(motionViewDTO.getStartTime()) && Objects.nonNull(motionViewDTO.getEndTime()) && !motionViewDTO.getStartTime().after(motionViewDTO.getEndTime()), BrandOneBPBaseErrorCode.PARAM_BREAK_RULE.getErrCode(), "开始时间不能大于结束时间");
        AssertUtil.notNull(motionViewDTO.getBudget(), BrandOneBPBaseErrorCode.PARAM_REQUIRED, "预算不能为空");
        AssertUtil.notEmpty(motionViewDTO.getMarketingStageViewDTOList(), BrandOneBPBaseErrorCode.PARAM_REQUIRED, "营销阶段不能为空");
        AssertUtil.assertTrue(Long.valueOf(10000L).equals(motionViewDTO.getMarketingStageViewDTOList().stream().mapToLong(MarketingStageViewDTO::getRatio).sum()), BrandOneBPBaseErrorCode.PARAM_BREAK_RULE.getErrCode(), "比例之和需要等于10000");
        AssertUtil.notEmpty(motionViewDTO.getCrowdIdList(), BrandOneBPBaseErrorCode.PARAM_REQUIRED, "人群不能为空");
        AssertUtil.assertTrue(Optional.of(motionViewDTO.getAttentionTargetViewDTOList()).orElse(Lists.newArrayList()).size() < 4, BrandOneBPBaseErrorCode.PARAM_BREAK_RULE.getErrCode(), "提案关注指标不能超过三个");
        if (CollectionUtils.isNotEmpty(motionViewDTO.getResourceTypeRatioViewDTOList())) {
            motionViewDTO.getResourceTypeRatioViewDTOList().forEach(it -> {
                if (RuleComparatorEnum.GE.getValue().equals(it.getComparator())) {
                    AssertUtil.assertTrue(it.getRatio() <= 10000, BrandOneBPBaseErrorCode.PARAM_BREAK_RULE.getErrCode(), "比例不能大于100");
                }
                if (RuleComparatorEnum.LE.getValue().equals(it.getComparator())) {
                    AssertUtil.assertTrue(it.getRatio() >= 0, BrandOneBPBaseErrorCode.PARAM_BREAK_RULE.getErrCode(), "比例不能小于0");
                }
            });
        }
    }

    public void validateIntelligentMotionBaseOnSaleGroup(IntelligentMotionViewDTO motionViewDTO, ResourcePackageSaleGroupViewDTO saleGroupViewDTO) {
        AssertUtil.assertTrue(!motionViewDTO.getStartTime().before(saleGroupViewDTO.getStartDate()) && !motionViewDTO.getEndTime().after(saleGroupViewDTO.getEndDate()) , BrandOneBPBaseErrorCode.PARAM_BREAK_RULE.getErrCode(), "提案时间不能超出分组时间范围");
        ResourcePackageAmountSettingViewDTO amountConfigure = saleGroupViewDTO.getAmountConfigure();
        if (SaleGroupAmountSettingTypeEnum.FIXED_AMOUNT.getValue().equals(amountConfigure.getType())) {
            AssertUtil.assertTrue(motionViewDTO.getBudget().equals(amountConfigure.getAmount()), BrandOneBPBaseErrorCode.PARAM_BREAK_RULE.getErrCode(), "预算不能超过分组预算上限");
        }
        if (SaleGroupAmountSettingTypeEnum.MAX_AMOUNT.getValue().equals(amountConfigure.getType())) {
            AssertUtil.assertTrue(motionViewDTO.getBudget() <= amountConfigure.getAmount(), BrandOneBPBaseErrorCode.PARAM_BREAK_RULE.getErrCode(), "预算不能超过分组预算上限");
        }
        if (SaleGroupAmountSettingTypeEnum.START_AMOUNT.getValue().equals(amountConfigure.getType())) {
            AssertUtil.assertTrue(motionViewDTO.getBudget() >= amountConfigure.getAmount(), BrandOneBPBaseErrorCode.PARAM_BREAK_RULE.getErrCode(), "预算不能低于分组预算下限");
        }
        if (SaleGroupAmountSettingTypeEnum.INTERVAL_AMOUNT.getValue().equals(amountConfigure.getType())) {
            AssertUtil.assertTrue(motionViewDTO.getBudget() <= amountConfigure.getMaxAmount() && motionViewDTO.getBudget() >= amountConfigure.getAmount(), BrandOneBPBaseErrorCode.PARAM_BREAK_RULE.getErrCode(), "预算需要在分组预算区间内");
        }

        Date startTime = motionViewDTO.getMarketingStageViewDTOList().stream().min(Comparator.comparing(MarketingStageViewDTO::getStartTime)).get().getStartTime();
        Date endTime = motionViewDTO.getMarketingStageViewDTOList().stream().max(Comparator.comparing(MarketingStageViewDTO::getEndTime)).get().getEndTime();
        AssertUtil.assertTrue(saleGroupViewDTO.getDistributionRuleList().stream().flatMap(it -> it.getResourcePackageProductList().stream()).anyMatch(resourcePackageProductViewDTO -> validDate(startTime, endTime, resourcePackageProductViewDTO)), "不存在与提案存在时间交集的二级产品");
    }

    private boolean validDate(Date startTime, Date endTime, ResourcePackageProductViewDTO resourcePackageProductViewDTO) {
        Boolean flag = true;
        for (ResourcePackageProductPriceViewDTO productPriceViewDTO : resourcePackageProductViewDTO.getBandPriceList()) {
            if (productPriceViewDTO.getStartDate().after(endTime) || productPriceViewDTO.getEndDate().before(startTime)) {
                flag = false;
                break;
            }
        }
        return flag;
    }

    /**
     * 批量获取加收后的价格政策
     *
     * @param resourcePackageProductList 二级产品列表
     * @return 价格政策  <label_saleUnit_resourceTypeValueList ,<startDate_endDate,价格政策>>
     */
    public Map<String, Map<String, ResourcePackageProductPriceViewDTO>> getProductBandPriceList(List<ResourcePackageProductViewDTO> resourcePackageProductList, Map<Long, ProductViewDTO> sspProductMap ) {
        Map<String, Map<String, ResourcePackageProductPriceViewDTO>> productBandPriceMap = Maps.newConcurrentMap();
        TaskStream.consume(productPriceBatchTaskIdentifier, resourcePackageProductList, (resourcePackageProductDTO, index) -> {
            if (CollectionUtils.isEmpty(resourcePackageProductDTO.getBandPriceList())) {
                return;
            }
            Optional<Date> startDate = resourcePackageProductDTO.getBandPriceList().stream().map(ResourcePackageProductPriceViewDTO::getStartDate).min(Date::compareTo);
            Optional<Date> endDate = resourcePackageProductDTO.getBandPriceList().stream().map(ResourcePackageProductPriceViewDTO::getEndDate).max(Date::compareTo);
            if (!startDate.isPresent() || !endDate.isPresent()) {
                return;
            }
            ProductViewDTO productViewDTO = sspProductMap.get(resourcePackageProductDTO.getSspProductId());
            if (productViewDTO == null) {
                return;
            }
            List<PriceEnginePublishPriceViewDTO> priceEnginePublishPriceViewDTOS = priceEngineRepository.getAdditionPublishPrice(productViewDTO.getLabel()
                    , productViewDTO.getSellUnit()
                    , productViewDTO.getResourceTypeList()
                    , startDate.get()
                    , endDate.get());
            if (CollectionUtils.isEmpty(priceEnginePublishPriceViewDTOS)) {
                return;
            }
            List<ResourcePackageProductPriceViewDTO> productBandPriceList = divideByPrice(priceEnginePublishPriceViewDTOS);
            Map<String, ResourcePackageProductPriceViewDTO> timeListMap = productBandPriceList.stream()
                    .collect(Collectors.toMap(
                            productBandPriceVO -> BrandDateUtil.date2String(productBandPriceVO.getStartDate(), BrandDateUtil.DATE_FORMAT_YYYYMMDD_TYPE_2) + "_" + BrandDateUtil.date2String(productBandPriceVO.getEndDate(), BrandDateUtil.DATE_FORMAT_YYYYMMDD_TYPE_2),
                            productBandPriceVO -> productBandPriceVO,
                            (v1, v2) -> v1));

            productBandPriceMap.put(productViewDTO.getLabel()
                            + "_" + productViewDTO.getSellUnit()
                            + "_" + productViewDTO.getResourceTypeList().stream().filter(Objects::nonNull).map(String::valueOf).collect(Collectors.joining(","))
                    , timeListMap);
        }).commit();
        return productBandPriceMap;
    }

    public List<ResourcePackageProductPriceViewDTO> divideByPrice(List<PriceEnginePublishPriceViewDTO> priceDTOList) {
        // 未获取价格
        List<ResourcePackageProductPriceViewDTO> productBandPriceList = Lists.newArrayList();
        if (CollectionUtils.isEmpty(priceDTOList)) {
            return productBandPriceList;
        }

        // 日期排序
        priceDTOList.sort(Comparator.comparing(PriceEnginePublishPriceViewDTO::getDate));
        List<Integer> changePoint = Lists.newArrayList();
        for (int i = 0; i < priceDTOList.size(); i++) {
            if (i == 0) {
                continue;
            }
            PriceEnginePublishPriceViewDTO publishPriceDTO = priceDTOList.get(i);
            Long current = publishPriceDTO.getPublishPrice();
            Long last = priceDTOList.get(i - 1).getPublishPrice();
            if (!current.equals(last)) {
                changePoint.add(i);
            }
        }

        // 无波段价格
        if (org.apache.commons.collections.CollectionUtils.isEmpty(changePoint)) {
            ResourcePackageProductPriceViewDTO bandPrice = new ResourcePackageProductPriceViewDTO();
            bandPrice.setPublishPrice(priceDTOList.get(0).getPublishPrice());
            bandPrice.setStartDate(priceDTOList.get(0).getDate());
            bandPrice.setEndDate(priceDTOList.get(priceDTOList.size() - 1).getDate());
            return Lists.newArrayList(bandPrice);
        }

        // 波段价格拆分
        int last = 0;
        List<List<PriceEnginePublishPriceViewDTO>> divideList = Lists.newArrayList();
        for (Integer subPoint : changePoint) {
            divideList.add(priceDTOList.subList(last, subPoint));
            last = subPoint;
        }
        // 最后剩余部分做subList
        divideList.add(priceDTOList.subList(last, priceDTOList.size()));

        return divideList.parallelStream().map(publishPrice -> {
            // 价格日期排序
            publishPrice.sort(Comparator.comparing(PriceEnginePublishPriceViewDTO::getDate));
            ResourcePackageProductPriceViewDTO bandPrice = new ResourcePackageProductPriceViewDTO();
            // 价格
            Long price = publishPrice.get(0).getPublishPrice();
            // 日期
            Date startTime = publishPrice.get(0).getDate();
            Date endTime = publishPrice.get(publishPrice.size() - 1).getDate();
            bandPrice.setPublishPrice(price);
            bandPrice.setStartDate(startTime);
            bandPrice.setEndDate(endTime);
            return bandPrice;
        }).collect(Collectors.toList());
    }
}
