package com.taobao.ad.brand.bp.domain.campaigngroup.workflow;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.cancel.CampaignGroupCancelViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.complete.CampaignGroupCompleteConfigViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.content.CampaignGroupContentViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.ext.CampaignGroupExtViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.inquiry.CampaignGroupInquiryViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.order.CampaignGroupOrderViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.purchase.CampaignGroupPurchaseViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.realsettle.CampaignGroupRealSettleViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.unlock.CampaignGroupUnlockViewDTO;
import com.alibaba.ad.brand.dto.common.WakeupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupProcessStatusEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.context.CampaignGroupStateContext;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupOrderCommandViewDTO;
import com.taobao.ad.brand.bp.client.dto.rule.RuleCheckResultViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupEventEnum;
import com.taobao.ad.brand.bp.common.enums.BooleanEnum;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.event.campaigngroup.CampaignGroupStatusTransitTriggerEvent;
import com.taobao.ad.brand.bp.domain.sdk.base.workflow.router.SelfServiceExtensionRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignValidateForPreOrderCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignValidateForPreOrderCampaignGroupAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.*;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.*;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.workflow.param.BizCampaignGroupProcessOrderWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.workflow.param.BizCampaignGroupWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.ICartItemBindCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.orderjudge.ICartItemStartBudgetCheckForCartItemOrderAbility;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.param.CartItemBindCampaignGroupAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.param.CartItemStartBudgetOrderCheckAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.IMessageSyncSendAbility;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.param.MessageSyncSendAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR;

/**
 * Description:自助营销订单扩展
 * <p>
 * date: 2023/10/24 2:51 PM
 *
 * @author shiyan
 * @version 1.0
 */
@Service
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCampaignGroupCommandWorkflowExtImpl extends DefaultCampaignGroupCommandWorkflowExtImpl implements SelfServiceExtensionRouter {
    @Resource
    private ICampaignGroupBaseValidateForUpdateCampaignGroupAbility campaignGroupBaseValidateForUpdateCampaignGroupAbility;
    @Resource
    private ICampaignGroupBaseInitForUpdateCampaignGroupAbility campaignGroupBaseInitForUpdateCampaignGroupAbility;
    @Resource
    private ICampaignGroupSaleValidateForAddOrUpdateCampaignGroupAbility campaignGroupSaleValidateForAddOrUpdateCampaignGroupAbility;
    @Resource
    private ICampaignGroupSaleInitForUpdateCampaignGroupAbility campaignGroupSaleInitForUpdateCampaignGroupAbility;
    @Resource
    private ICampaignGroupSaleGroupValidateForAddOrUpdateCampaignGroupAbility campaignGroupSaleGroupValidateForAddOrUpdateAbility;
    @Resource
    private ICartItemStartBudgetCheckForCartItemOrderAbility cartItemSpuStartBudgetRuleJudgeAbility;
    @Resource
    private ICampaignGroupBaseInitForAddCampaignGroupAbility campaignGroupBaseInitForAddCampaignGroupAbility;
    @Resource
    private ICampaignGroupCustomerInitForAddCampaignGroupAbility campaignGroupCustomerInitForAddCampaignGroupAbility;
    @Resource
    private ICampaignGroupSaleGroupInitForUpdateCampaignGroupAbility campaignGroupSaleGroupInitForUpdateCampaignGroupAbility;
    @Resource
    private ICampaignGroupSaleInitForAddCampaignGroupAbility campaignGroupSaleInitForAddCampaignGroupAbility;
    private final ICampaignGroupContractInitForAddCampaignGroupAbility campaignGroupContractInitForAddCampaignGroupAbility;
    private final ICampaignGroupContractInitForUpdateCampaignGroupAbility campaignGroupContractInitForUpdateCampaignGroupAbility;
    private final ICampaignGroupCompleteConfigInitForAddCampaignGroupAbility campaignGroupCompleteConfigInitForAddCampaignGroupAbility;
    private final ICampaignGroupOrderInitForAddCampaignGroupAbility campaignGroupOrderInitForAddCampaignGroupAbility;
    private final ICampaignGroupInquiryInitForAddCampaignGroupAbility campaignGroupInquiryInitForAddCampaignGroupAbility;
    private final ICampaignGroupWakeupInitForAddCampaignGroupAbility campaignGroupWakeupInitForAddCampaignGroupAbility;
    private final ICampaignGroupExtInitForAddCampaignGroupAbility campaignGroupExtInitForAddCampaignGroupAbility;
    private final ICartItemBindCampaignGroupAbility cartItemBindCampaignGroupAbility;
    private final ICampaignGroupMessageAsyncSendAbility campaignGroupMessageAsyncSendAbility;
    private final ICampaignGroupInitForPreOrderCampaignGroupAbility campaignGroupInitForPreOrderCampaignGroupAbility;

    private final ICampaignValidateForPreOrderCampaignGroupAbility campaignValidateForPreOrderCampaignGroupAbility;
    private final IMessageSyncSendAbility messageSyncSendAbility;

    @Override
    public void beforeExecuteAddCampaignGroup(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, BizCampaignGroupWorkflowParam workflowParam) {
        // 数据初始化
        this.initForAdd(context, campaignGroupViewDTO, workflowParam);
    }

    @Override
    public void beforeExecuteUpdateCampaignGroup(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, BizCampaignGroupWorkflowParam bizCampaignGroupWorkflowParam) {
        // 校验
        this.validateForUpdate(context, campaignGroupViewDTO, bizCampaignGroupWorkflowParam);
        // 初始化
        this.initForUpdate(context, campaignGroupViewDTO, bizCampaignGroupWorkflowParam);
    }

    @Override
    public void beforeOrder(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO, BizCampaignGroupProcessOrderWorkflowParam orderWorkflowParam) {
        // 初始化
        super.initForOrder(context, campaignGroupOrderCommandViewDTO, orderWorkflowParam);
    }

    private void initForUpdate(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, BizCampaignGroupWorkflowParam bizCampaignGroupWorkflowParam) {
        CampaignGroupViewDTO dbCampaignGroupViewDTO = bizCampaignGroupWorkflowParam.getDbCampaignGroupViewDTO();
        // 基础信息
        campaignGroupBaseInitForUpdateCampaignGroupAbility.handle(context, CampaignGroupBaseAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO).dbCampaignGroupViewDTO(dbCampaignGroupViewDTO).build());
        // 售卖信息
        campaignGroupSaleInitForUpdateCampaignGroupAbility.handle(context, CampaignGroupSaleAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupSaleViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO).build());
        // 订单分组
        super.initSaleGroupInfoForUpdate(context, campaignGroupViewDTO, dbCampaignGroupViewDTO, bizCampaignGroupWorkflowParam.getResourcePackageSaleGroupList());
        // 合同以售卖中心为准
        campaignGroupContractInitForUpdateCampaignGroupAbility.handle(context, CampaignGroupContractAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupContractViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO).build());

        // 其他属性暂时不实现原子能力
        campaignGroupViewDTO.setCampaignGroupOrderViewDTO(new CampaignGroupOrderViewDTO());
        campaignGroupViewDTO.setCampaignGroupUnlockViewDTO(new CampaignGroupUnlockViewDTO());
        campaignGroupViewDTO.setCampaignGroupCancelViewDTO(new CampaignGroupCancelViewDTO());
        campaignGroupViewDTO.setCampaignGroupRealSettleViewDTO(new CampaignGroupRealSettleViewDTO());
        campaignGroupViewDTO.setCampaignGroupCompleteConfigViewDTO(new CampaignGroupCompleteConfigViewDTO());
        campaignGroupViewDTO.setCampaignGroupContentViewDTO(new CampaignGroupContentViewDTO());
        campaignGroupViewDTO.setProcessRecordViewDTOList(Lists.newArrayList());
        campaignGroupViewDTO.setCampaignGroupPurchaseViewDTO(new CampaignGroupPurchaseViewDTO());
        campaignGroupViewDTO.setCampaignGroupInquiryViewDTO(new CampaignGroupInquiryViewDTO());
        campaignGroupViewDTO.setWakeupViewDTO(new WakeupViewDTO());
        campaignGroupViewDTO.setCampaignGroupExtViewDTO(new CampaignGroupExtViewDTO());
    }

    private void validateForUpdate(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, BizCampaignGroupWorkflowParam bizCampaignGroupWorkflowParam) {
        // 基础信息校验
        campaignGroupBaseValidateForUpdateCampaignGroupAbility.handle(context, CampaignGroupBaseAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO).dbCampaignGroupViewDTO(bizCampaignGroupWorkflowParam.getDbCampaignGroupViewDTO()).build());
        // 校验售卖信息
        campaignGroupSaleValidateForAddOrUpdateCampaignGroupAbility.handle(context, CampaignGroupSaleAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupSaleViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO).build());
        // 校验订单分组信息
        campaignGroupSaleGroupValidateForAddOrUpdateAbility.handle(context, CampaignGroupSaleGroupAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO)
                .resourcePackageSaleGroupList(bizCampaignGroupWorkflowParam.getResourcePackageSaleGroupList()).build());
    }


    private void initForAdd(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, BizCampaignGroupWorkflowParam workflowParam) {
        // 客户信息(放在第一位)
        campaignGroupCustomerInitForAddCampaignGroupAbility.handle(context, CampaignGroupCustomerAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupCustomerViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO).build());
        // 基础信息
        campaignGroupBaseInitForAddCampaignGroupAbility.handle(context, CampaignGroupBaseAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO).campaignViewDTOList(workflowParam.getCampaignList()).build());
        // 售卖信息
        campaignGroupSaleInitForAddCampaignGroupAbility.handle(context, CampaignGroupSaleAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupSaleViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO)
                .skuList(workflowParam.getSkuList()).build());
        // 合同信息
        campaignGroupContractInitForAddCampaignGroupAbility.handle(context, CampaignGroupContractAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupContractViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO).build());
        // 结案账号
        campaignGroupCompleteConfigInitForAddCampaignGroupAbility.handle(context, CampaignGroupCompleteConfigAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupCompleteConfigViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO).build());
        // 下单信息
        campaignGroupOrderInitForAddCampaignGroupAbility.handle(context, CampaignGroupOrderAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupOrderViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO).build());
        // 盘量信息
        campaignGroupInquiryInitForAddCampaignGroupAbility.handle(context, CampaignGroupInquiryAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupInquiryViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO).build());
        // 唤端信息
        campaignGroupWakeupInitForAddCampaignGroupAbility.handle(context, CampaignGroupWakeupAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getWakeupViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO).build());
        // 扩展信息
        campaignGroupExtInitForAddCampaignGroupAbility.handle(context, CampaignGroupExtAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupExtViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO).build());
    }

    @Override
    public void afterAdd(ServiceContext context, CampaignGroupViewDTO campaignGroup) {
        // 1. 更新与加购行的关联关系
        cartItemBindCampaignGroupAbility.handle(context, CartItemBindCampaignGroupAbilityParam.builder()
                .abilityTargets(campaignGroup.getSourceIds()).campaignGroupViewDTO(campaignGroup).build());

        // 2. 发送领域消息
        campaignGroupMessageAsyncSendAbility.handle(context, CampaignGroupMessageAsyncSendAbilityParam.builder()
                .abilityTarget(campaignGroup).domainEvent(CampaignGroupEventEnum.CREATE.name()).build());
    }

    @Override
    public void validateForOrder(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO, BizCampaignGroupProcessOrderWorkflowParam orderWorkflowParam) {
        // 无需校验
    }

    @Override
    public void beforePreOrder(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, BizCampaignGroupProcessOrderWorkflowParam processWorkflowParam) {
        // 预下单校验
        validateForPreOrder(serviceContext, campaignGroupViewDTO, processWorkflowParam);
        // 预下单初始化
        campaignGroupInitForPreOrderCampaignGroupAbility.handle(serviceContext, CampaignGroupPreOrderAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO).campaignViewDTOList(processWorkflowParam.getCampaignList()).build());
//        super.beforePreOrder(serviceContext, campaignGroupViewDTO, processWorkflowParam);
    }


    private void validateForPreOrder(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, BizCampaignGroupProcessOrderWorkflowParam processWorkflowParam) {
        List<CampaignViewDTO> campaignViewDTOList = processWorkflowParam.getCampaignList();
        // 校验计划
        campaignValidateForPreOrderCampaignGroupAbility.handle(serviceContext, CampaignValidateForPreOrderCampaignGroupAbilityParam.builder().abilityTargets(campaignViewDTOList).build());
//        bizCampaignGroupProcessAbility.validateCampaignsForPreOrder(serviceContext, campaignViewDTOList);
        // 门槛校验
        RuleCheckResultViewDTO resultViewDTO = cartItemSpuStartBudgetRuleJudgeAbility.handle(serviceContext,
                CartItemStartBudgetOrderCheckAbilityParam.builder().campaignViewDTOList(campaignViewDTOList).build());
        AssertUtil.assertTrue(BooleanEnum.TRUE.getValue().equals(resultViewDTO.getIsPass()), BIZ_BREAK_RULE_ERROR, resultViewDTO.getReason());
    }

//    @Override
//    public BizCampaignGroupProcessOrderWorkflowParam buildWorkflowParamForPreOrder(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO) {
//        BizCampaignGroupProcessOrderWorkflowParam workflowParam = new BizCampaignGroupProcessOrderWorkflowParam();
//        // 计划信息
//        CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder()
//                .campaignGroupId(campaignGroupViewDTO.getId())
//                .campaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode())
//                .build();
//        List<CampaignViewDTO> campaignViewDTOList = campaignRepository.queryCampaignList(serviceContext, campaignQueryViewDTO);
//        workflowParam.setCampaignList(campaignViewDTOList);
//
//        return workflowParam;
//    }
//
//    @Override
//    public Boolean canTransitCampaignGroupToResourceConfirm(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO) {
//        Integer purchaseStatus = campaignGroupViewDTO.getCampaignGroupPurchaseViewDTO().getPurchaseStatus();
//        // 采购完成或无需采购时状态流转
//        if (PURCHASE_FINISH.getCode().equals(purchaseStatus) || NON_PURCHASE.getCode().equals(purchaseStatus)) {
//            return Boolean.TRUE;
//        }
//        return Boolean.FALSE;
//    }

    @Override
    public void afterFinishSubCampaignGroupRealSettleProcess(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, BrandCampaignGroupProcessStatusEnum processStatusEnum) {
        if (BizCampaignGroupToolsHelper.isAgree(processStatusEnum.getCode())) {
            // 发送领域事件
            CampaignGroupStateContext stateContext = CampaignGroupStateContext.builder()
                    .serviceContext(context)
                    .campaignGroupViewDTO(campaignGroupViewDTO)
                    .eventEnum(CampaignGroupEventEnum.REAL_SETTLE_APPROVE)
                    .build();
            messageSyncSendAbility.handle(context, MessageSyncSendAbilityParam.builder().abilityTarget(CampaignGroupStatusTransitTriggerEvent.of(stateContext)).build());
        } else {
            // 发送子->主订单领域事件
            campaignGroupMessageAsyncSendAbility.handle(context, CampaignGroupMessageAsyncSendAbilityParam.builder()
                    .abilityTarget(campaignGroupViewDTO).domainEvent(CampaignGroupEventEnum.REAL_SETTLE_CONFIG.name()).build());
        }
    }
}