package com.taobao.ad.brand.bp.domain.report.repository;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.dto.report.ReportCampaignGroupBrandViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.query.ReportAttributionBrandQueryViewDTO;

import java.util.List;

/**
 * @author yuncheng.lyc
 */
public interface ReportBrandRepository {

    /**
     * 离线回流数据中获取品牌信息
     * @param queryViewDTO
     * @return
     */
    List<ReportCampaignGroupBrandViewDTO> getContractBrandList(ServiceContext context, ReportAttributionBrandQueryViewDTO queryViewDTO);

}
