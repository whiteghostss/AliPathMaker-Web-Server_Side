package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.contract.CampaignGroupContractViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSaleOrderStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupContractInitForOrderCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupContractInitForOrderAbilityParam;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@BusinessAbility
public class BrandOneBPCampaignGroupContractInitForOrderCampaignGroupAbility
        implements ICampaignGroupContractInitForOrderCampaignGroupAbility, BrandOneBPAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupContractInitForOrderAbilityParam abilityParam) {
        CampaignGroupContractViewDTO campaignGroupContractViewDTO = Optional.ofNullable(abilityParam.getAbilityTarget()).orElse(new CampaignGroupContractViewDTO());
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        // 合同时间
        List<SaleGroupInfoViewDTO> exclusionBoostSaleGroupInfoList = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream()
                .filter(t -> !BrandCampaignGroupSaleOrderStatusEnum.WAIT_ORDER.getCode().equals(t.getSaleGroupStatus()) && !BrandSaleTypeEnum.BOOST.getCode().equals(t.getSaleType()))
                .collect(Collectors.toList());
        campaignGroupContractViewDTO.setContractStartTime(BizCampaignGroupToolsHelper.getSaleGroupMinDate(exclusionBoostSaleGroupInfoList));
        campaignGroupContractViewDTO.setContractEndTime(BizCampaignGroupToolsHelper.getSaleGroupMaxDate(exclusionBoostSaleGroupInfoList));

        campaignGroupViewDTO.setCampaignGroupContractViewDTO(campaignGroupContractViewDTO);

        return null;
    }
}
