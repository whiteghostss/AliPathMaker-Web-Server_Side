package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.adgroup.CreativeRefViewDTO;
import com.alibaba.ad.brand.dto.common.BottomDateViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativeTargetTypeEnum;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.dto.base.DateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignBottomDateViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignBottomDirectCreativeRefBuildAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBottomDirectCreativeRefBuildAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSelfCampaignBottomDirectCreativeRefBuildAbility implements ICampaignBottomDirectCreativeRefBuildAbility, BrandSelfServiceAtomAbilityRouter {

    @Override
    public List<CreativeRefViewDTO> handle(ServiceContext serviceContext, CampaignBottomDirectCreativeRefBuildAbilityParam abilityParam) {
        CampaignBottomDateViewDTO campaignBottomDateViewDTO = abilityParam.getAbilityTarget();
        List<CreativeViewDTO> subCreativeViewDTOList = abilityParam.getSubCreativeViewDTOList();
        AdgroupViewDTO adgroupViewDTO = abilityParam.getAdgroupViewDTO();
        AssertUtil.notNull(campaignBottomDateViewDTO,"计划打底日期不能为空");
        if(CollectionUtils.isEmpty(subCreativeViewDTOList)){
            return Lists.newArrayList();
        }
        Map<Date,CreativeViewDTO> finalDirectCreativeMap = buildDateCreativeMap(campaignBottomDateViewDTO.getBottomDateList(),subCreativeViewDTOList);
        //这里需要组装creative_ref,幂等在上面考虑，这里不用考虑幂等
        //组装一个map，key是creative_id，value是日期集合,是打底日期
        //不连续
        Map<Long,List<Date>> mapCreativeIdDate = finalDirectCreativeMap.entrySet().stream()
                        .filter(item->item.getValue().getTargetType().equals(BrandCreativeTargetTypeEnum.DIRECT.getCode()))
                        .collect(Collectors.groupingBy(item -> item.getValue().getId(),Collectors.mapping(Map.Entry::getKey,Collectors.toList())));

        List<CreativeRefViewDTO> creativeRefViewDTOList = Lists.newArrayList();
        if (MapUtils.isNotEmpty(mapCreativeIdDate)){
            mapCreativeIdDate.forEach((key, value) -> {
                CreativeRefViewDTO creativeRefViewDTO = new CreativeRefViewDTO();
                creativeRefViewDTO.setCampaignGroupId(adgroupViewDTO.getCampaignGroupId());
                creativeRefViewDTO.setAdgroupId(adgroupViewDTO.getId());
                creativeRefViewDTO.setCampaignId(adgroupViewDTO.getCampaignId());
                creativeRefViewDTO.setCreativeId(key);
                List<DateViewDTO> dateViewDTOList = BrandDateUtil.formatDateQuantum(value);
                List<BottomDateViewDTO> tmpCampaignBottomViewDTOList =
                        dateViewDTOList.stream().map(item -> {
                            BottomDateViewDTO bottomDateViewDTO = new BottomDateViewDTO();
                            bottomDateViewDTO.setStartDate(item.getStartDate());
                            bottomDateViewDTO.setEndDate(item.getEndDate());
                            return bottomDateViewDTO;
                        }).collect(Collectors.toList());
                creativeRefViewDTO.setBottomDateViewDTOList(tmpCampaignBottomViewDTOList);
                Long creativePackageId = subCreativeViewDTOList.stream().filter(item -> item.getId().equals(key)).findFirst().get().getCreativePackageId();
                creativeRefViewDTO.setCreativePackageId(creativePackageId);
                creativeRefViewDTOList.add(creativeRefViewDTO);
            });
        }
        return creativeRefViewDTOList;
    }

    /**
     * 按照打底日期，取对应匹配到的周期内的创意
     * 按照妈妈审核时间取最早匹配到的
     * key = date
     * value = 创意ID
     * */
    private Map<Date,CreativeViewDTO> buildDateCreativeMap(List<DateViewDTO> bottomDateList,List<CreativeViewDTO> creativeViewDTOList){
        Map<Date,CreativeViewDTO> mapResult = Maps.newLinkedHashMap();
        if (CollectionUtils.isNotEmpty(bottomDateList)){

            List<Date> dateList = bottomDateList.stream().map(item-> BrandDateUtil.getDayList(item.getStartDate(),item.getEndDate())).collect(Collectors.toList())
                    .stream().flatMap(Collection::stream).collect(Collectors.toList());
            dateList.forEach(date->{
                CreativeViewDTO canUseCreativeViewDTO =  creativeViewDTOList.stream().filter(creativeViewDTO -> {
                    Date startDate = creativeViewDTO.getStartTime();
                    Date endDate = creativeViewDTO.getEndTime();
                    return BrandDateUtil.isBetweenDate(startDate, endDate, date);
                }).sorted(Comparator.comparing(CreativeViewDTO::getId)).collect(Collectors.toList()).stream().findFirst().orElse(null);
//            }).sorted(Comparator.comparing(creativeViewDTO -> creativeViewDTO.getCreativeAudit().getMamaAudit().getAuditTime())).collect(Collectors.toList()).stream().findFirst().orElse(null);


                if (Objects.nonNull(canUseCreativeViewDTO)){
                    mapResult.put(date,canUseCreativeViewDTO);
                }
            });
        }
        return mapResult;

    }
}
