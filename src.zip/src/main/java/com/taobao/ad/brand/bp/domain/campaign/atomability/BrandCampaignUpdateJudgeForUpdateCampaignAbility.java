package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandInquiryStatusEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignUpdateJudgeForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignUpdateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_ILLEGAL;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandCampaignUpdateJudgeForUpdateCampaignAbility implements ICampaignUpdateJudgeForUpdateCampaignAbility, BrandAtomAbilityRouter {

    @Override
    public Boolean handle(ServiceContext serviceContext, CampaignUpdateAbilityParam abilityParam) {
        CampaignViewDTO campaignViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        AssertUtil.notNull(campaignViewDTO,"计划不允许为空");
        AssertUtil.notNull(dbCampaignViewDTO,"计划不存在");

        // 【状态】不允许修改状态设置：主计划、子计划如果处于询量中、锁量中、释量中、锁量成功、待投放、投放中、投放结束、投放暂停，不允许修改
        boolean canUpdateByStatus = Boolean.TRUE;
        List<CampaignViewDTO> allCampaignViewDTOList = BizCampaignToolsHelper.flatCampaignList(dbCampaignViewDTO);
        for (CampaignViewDTO viewDTO : allCampaignViewDTOList) {
            BrandCampaignStatusEnum campaignStatusEnum = BrandCampaignStatusEnum.getByCode(viewDTO.getStatus());
            if(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode().equals(viewDTO.getCampaignLevel())){
                if (BrandCampaignStatusEnum.INQUIRING == campaignStatusEnum || BrandCampaignStatusEnum.LOCKING == campaignStatusEnum  || BrandCampaignStatusEnum.RELEASING == campaignStatusEnum
                        || BrandCampaignStatusEnum.LOCK_SUCCESS == campaignStatusEnum || BrandCampaignStatusEnum.WAITING == campaignStatusEnum
                        || BrandCampaignStatusEnum.CASTING == campaignStatusEnum || BrandCampaignStatusEnum.PAUSING == campaignStatusEnum
                        || BrandCampaignStatusEnum.ENDING == campaignStatusEnum) {
                    canUpdateByStatus = Boolean.FALSE;
                }
            }else {
                if (BrandCampaignStatusEnum.INQUIRING == campaignStatusEnum || BrandCampaignStatusEnum.LOCKING == campaignStatusEnum  || BrandCampaignStatusEnum.RELEASING == campaignStatusEnum
                        || BrandCampaignStatusEnum.WAITING == campaignStatusEnum || BrandCampaignStatusEnum.CASTING == campaignStatusEnum || BrandCampaignStatusEnum.PAUSING == campaignStatusEnum
                ) {
                    canUpdateByStatus = Boolean.FALSE;
                }
            }
        }
        if (!canUpdateByStatus) {
            // 【日期】询量中、锁量中、释量中、锁量成功、待投放、投放中、投放结束、投放暂停，不允许修改，不允许修改
            AssertUtil.assertTrue(dbCampaignViewDTO.getStartTime().equals(campaignViewDTO.getStartTime())
                    , PARAM_ILLEGAL, "锁量中、锁量成功、待投放、投放中、投放结束、投放暂停状态的计划，日期不允许修改");
            AssertUtil.assertTrue(dbCampaignViewDTO.getEndTime().equals(campaignViewDTO.getEndTime())
                    , PARAM_ILLEGAL, "锁量中、锁量成功、待投放、投放中、投放结束、投放暂停状态的计划，日期不允许修改");
        }
        //存在锁量周期计划，锁量天数必须包含在计划的投放周期范围内
        boolean hasLockedSuccess = BizCampaignToolsHelper.hasLockedSuccess(dbCampaignViewDTO);
        if(hasLockedSuccess){
            validateCampaignLockDate(dbCampaignViewDTO,campaignViewDTO);
        }
        return canUpdateByStatus && !hasLockedSuccess;
    }

    /**
     * 校验计划锁量
     * @param campaignViewDTO
     * @param campaignViewDTO
     * @return
     */
    private void validateCampaignLockDate(CampaignViewDTO dbCampaignViewDTO,CampaignViewDTO campaignViewDTO){
        //主子计划打平
        List<CampaignViewDTO> allCampaignViewDTOList = BizCampaignToolsHelper.flatCampaignList(dbCampaignViewDTO);
        //查询计划已锁量日期，锁量日期必须在计划投放周期范围内
        List<Date> lockDateList = allCampaignViewDTOList.stream()
                .filter(viewDTO -> viewDTO.getCampaignInquiryLockViewDTO() != null && CollectionUtils.isNotEmpty(viewDTO.getCampaignInquiryLockViewDTO().getCampaignInquiryViewDTOList()))
                .flatMap(viewDTO -> viewDTO.getCampaignInquiryLockViewDTO().getCampaignInquiryViewDTOList().stream())
                .filter(inquiryViewDTO -> BrandInquiryStatusEnum.SUCCESS.getCode().equals(inquiryViewDTO.getStatus()))
                .map(inquiryViewDTO -> BrandDateUtil.getDateMidnight(inquiryViewDTO.getDate()))
                .distinct().collect(Collectors.toList());
        if(CollectionUtils.isNotEmpty(lockDateList)){
            List<Date> lunchDateList = BrandDateUtil.getDayList(campaignViewDTO.getStartTime(),
                    campaignViewDTO.getEndTime());
            for (Date lockDate : lockDateList) {
                AssertUtil.assertTrue(lunchDateList.contains(lockDate), "计划存在周期外的锁量成功日期，请释量后在重新选择新的投放日期");
            }
        }
    }
}
