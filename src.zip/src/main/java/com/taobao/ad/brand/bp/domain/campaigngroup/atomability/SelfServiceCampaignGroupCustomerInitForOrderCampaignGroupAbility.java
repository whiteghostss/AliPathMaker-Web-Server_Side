package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.customer.CampaignGroupCustomerViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupOrderCommandViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupCustomerInitForOrderCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupCustomerInitForOrderAbilityParam;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@BusinessAbility
public class SelfServiceCampaignGroupCustomerInitForOrderCampaignGroupAbility
        implements ICampaignGroupCustomerInitForOrderCampaignGroupAbility, SelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupCustomerInitForOrderAbilityParam abilityParam) {
        CampaignGroupCustomerViewDTO campaignGroupCustomerViewDTO = Optional.ofNullable(abilityParam.getAbilityTarget()).orElse(new CampaignGroupCustomerViewDTO());
        CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO = abilityParam.getCampaignGroupOrderCommandViewDTO();
        // 联系方式
        campaignGroupCustomerViewDTO.setContactPhone(campaignGroupOrderCommandViewDTO.getContactPhone());

        abilityParam.getCampaignGroupViewDTO().setCampaignGroupCustomerViewDTO(campaignGroupCustomerViewDTO);

        return null;
    }
}
