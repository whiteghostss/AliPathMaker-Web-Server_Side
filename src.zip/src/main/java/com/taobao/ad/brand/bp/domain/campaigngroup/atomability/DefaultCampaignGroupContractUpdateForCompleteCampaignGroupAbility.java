package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.contract.CampaignGroupContractViewDTO;
import com.alibaba.hermes.framework.utils.DateUtils;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupContractUpdateForCompleteCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupContractUpdateForTransitCampaignGroupAbilityParam;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
@BusinessAbility
public class DefaultCampaignGroupContractUpdateForCompleteCampaignGroupAbility implements ICampaignGroupContractUpdateForCompleteCampaignGroupAbility {
    @Resource
    private CampaignGroupRepository campaignGroupRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupContractUpdateForTransitCampaignGroupAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        CampaignGroupContractViewDTO campaignGroupContractViewDTO = abilityParam.getAbilityTarget();
        campaignGroupContractViewDTO.setFinalCompletedMoment(DateUtils.currentTime());
        campaignGroupViewDTO.setCampaignGroupContractViewDTO(campaignGroupContractViewDTO);

        CampaignGroupViewDTO updateCampaignGroupViewDTO = new CampaignGroupViewDTO();
        updateCampaignGroupViewDTO.setId(campaignGroupViewDTO.getId());
        updateCampaignGroupViewDTO.setCampaignGroupContractViewDTO(new CampaignGroupContractViewDTO());
        updateCampaignGroupViewDTO.getCampaignGroupContractViewDTO().setFinalCompletedMoment(campaignGroupContractViewDTO.getFinalCompletedMoment());
        campaignGroupRepository.updateCampaignGroupPart(serviceContext, updateCampaignGroupViewDTO);

        return null;
    }
}
