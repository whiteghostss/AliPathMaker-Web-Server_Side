package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupBoostGiveApplyCampaignDetailViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupBoostGiveApplyInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleProductLineEnum;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupApplyInfoInitForApplySaleGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupApplyInfoAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultSaleGroupApplyInfoInitForApplySaleGroupAbility implements ISaleGroupApplyInfoInitForApplySaleGroupAbility {

    @Override
    public Void handle(ServiceContext serviceContext, SaleGroupApplyInfoAbilityParam abilityParam) {
        SaleGroupBoostGiveApplyInfoViewDTO applyInfoViewDTO = abilityParam.getAbilityTarget();
        SaleGroupInfoViewDTO mainSaleGroupInfoViewDTO = abilityParam.getMainSaleGroupInfoViewDTO();

        // 单媒体营销补量分组初始化方式
        if (BrandSaleTypeEnum.BOOST.getCode().equals(applyInfoViewDTO.getSaleType()) && SaleProductLineEnum.SINGLE_MEDIA_MARKING.getValue().equals(mainSaleGroupInfoViewDTO.getSaleProductLine())) {
            applyInfoViewDTO.setBudget(applyInfoViewDTO.getCampaignDetailList().stream().mapToLong(SaleGroupBoostGiveApplyCampaignDetailViewDTO::getBudget).sum());
            applyInfoViewDTO.setAmount(applyInfoViewDTO.getCampaignDetailList().stream().mapToLong(SaleGroupBoostGiveApplyCampaignDetailViewDTO::getAmount).sum());
        // 非单媒体营销的补量分组初始化方式
        } else {
            applyInfoViewDTO.setAmount(0L);
        }
        applyInfoViewDTO.setApproval(Boolean.TRUE);
        return null;
    }
}
