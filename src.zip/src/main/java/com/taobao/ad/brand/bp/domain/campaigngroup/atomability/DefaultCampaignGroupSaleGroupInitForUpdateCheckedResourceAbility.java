package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.salegroup.CampaignGroupSaleGroupViewDTO;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupCheckedResourceViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourceDistributionRuleViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupSaleGroupInitForUpdateCheckedResourceAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupUpdateCheckedResourceAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Component
@BusinessAbility
public class DefaultCampaignGroupSaleGroupInitForUpdateCheckedResourceAbility implements ICampaignGroupSaleGroupInitForUpdateCheckedResourceAbility {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupUpdateCheckedResourceAbilityParam abilityParam) {
        CampaignGroupCheckedResourceViewDTO checkedResourceViewDTO = abilityParam.getAbilityTarget();
        List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupList = abilityParam.getResourcePackageSaleGroupList();
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        // 与db的check结果合并
        List<Long> checkedResourceProductIdList = getCheckedResourceProductIdList(campaignGroupViewDTO, resourcePackageSaleGroupList, checkedResourceViewDTO);
        CampaignGroupSaleGroupViewDTO campaignGroupSaleGroupViewDTO = new CampaignGroupSaleGroupViewDTO();
        campaignGroupSaleGroupViewDTO.setCheckedResourcePackageProductIdList(checkedResourceProductIdList);
        campaignGroupViewDTO.setCampaignGroupSaleGroupViewDTO(campaignGroupSaleGroupViewDTO);

        return null;
    }

    /**
     * 根据分组类型获取保存订单对勾的资源产品
     */
    public List<Long> getCheckedResourceProductIdList(CampaignGroupViewDTO campaignGroup,
                                                      List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupList, CampaignGroupCheckedResourceViewDTO checkedResourceViewDTO) {
        List<Long> dbProductIdList = campaignGroup.getCampaignGroupSaleGroupViewDTO().getCheckedResourcePackageProductIdList();
        if (checkedResourceViewDTO.getSaleType() == null || CollectionUtils.isEmpty(dbProductIdList)) {
            return checkedResourceViewDTO.getCheckedResourcePackageProductIdList();
        }
        Map<Integer, Set<Long>> saleTypeProductMap = Maps.newHashMap();
        for (ResourcePackageSaleGroupViewDTO saleGroupViewDTO : resourcePackageSaleGroupList) {
            if (CollectionUtils.isEmpty(saleGroupViewDTO.getDistributionRuleList())) {
                continue;
            }
            Integer saleType = saleGroupViewDTO.getSaleType();
            for (ResourceDistributionRuleViewDTO resourceDistributionRuleViewDTO : saleGroupViewDTO.getDistributionRuleList()) {
                if (CollectionUtils.isNotEmpty(resourceDistributionRuleViewDTO.getResourcePackageProductList())) {
                    for (ResourcePackageProductViewDTO resourcePackageProduct : resourceDistributionRuleViewDTO.getResourcePackageProductList()) {
                        saleTypeProductMap.computeIfAbsent(saleType, k -> Sets.newHashSet()).add(resourcePackageProduct.getId());
                    }
                }
            }
        }
        //将原有类型分组的产品ID先过滤掉，再添加新的产品ID
        Set<Long> resourcePackageProductSet = saleTypeProductMap.getOrDefault(checkedResourceViewDTO.getSaleType(), Sets.newHashSet());
        List<Long> addProductIdList = checkedResourceViewDTO.getCheckedResourcePackageProductIdList();
        List<Long> result = dbProductIdList.stream().filter(v -> !resourcePackageProductSet.contains(v)).collect(Collectors.toList());
        result.addAll(addProductIdList);
        RogerLogger.info("订单保存对勾产品ID={}", result);
        return result;
    }

}
