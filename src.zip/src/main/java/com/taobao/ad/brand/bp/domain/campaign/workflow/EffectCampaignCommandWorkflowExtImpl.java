package com.taobao.ad.brand.bp.domain.campaign.workflow;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.sale.CampaignSaleViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.salegroup.CampaignGroupSaleGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSaleOrderStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleGroupSourceEnum;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.context.CampaignGroupCalculateContext;
import com.taobao.ad.brand.bp.client.context.CampaignGroupOrderContext;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.effect.EffectAdvertiserViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.effect.EffectAdvertiserRepository;
import com.taobao.ad.brand.bp.domain.event.campaign.CampaignCreateNoticeEvent;
import com.taobao.ad.brand.bp.domain.event.campaigngroup.CampaignGroupCalculateEvent;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.workflow.router.EffectExtensionRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignAdvBindOrUnBindWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.IMessageSyncSendAbility;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.param.MessageSyncSendAbilityParam;
import com.taobao.ad.brand.bp.domain.ssp.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EffectCampaignCommandWorkflowExtImpl extends DefaultCampaignCommandWorkflowExtImpl implements EffectExtensionRouter {

    private final CampaignGroupRepository campaignGroupRepository;
    private final EffectAdvertiserRepository effectAdvertiserRepository;
    private final ResourcePackageRepository resourcePackageRepository;
    private final ProductRepository productRepository;
    private final IMessageSyncSendAbility messageSyncSendAbility;

    private final ICampaignStructureQueryAbility campaignStructureQueryAbility;

    private final ICampaignBaseValidateForAddCampaignAbility campaignBaseValidateForAddCampaignAbility;
    private final ICampaignSaleValidateForAddCampaignAbility campaignSaleValidateForAddCampaignAbility;
    private final ICampaignBaseValidateForUpdateCampaignAbility campaignBaseValidateForUpdateCampaignAbility;
    private final ICampaignBaseInitForAddCampaignAbility campaignBaseInitForAddCampaignAbility;
    private final ICampaignResourceInitForAddCampaignAbility campaignResourceInitForAddCampaignAbility;
    private final ICampaignCreativeControllerInitForAddCampaignAbility campaignCreativeControllerInitForAddCampaignAbility;
    private final ICampaignTitleInitAbility campaignTitleInitAbility;
    private final ICampaignSaleInitForAddCampaignAbility campaignSaleInitForAddCampaignAbility;
    private final ICampaignGuaranteeInitForAddCampaignAbility campaignGuaranteeInitForAddCampaignAbility;
    private final ICampaignInquiryLockInitForAddCampaignAbility campaignInquiryLockInitForAddCampaignAbility;
    private final ICampaignPriceInitForAddCampaignAbility campaignPriceInitForAddCampaignAbility;
    private final ICampaignBudgetInitForAddCampaignAbility campaignBudgetInitForAddCampaignAbility;
    private final ICampaignAdzoneInitForAddCampaignAbility campaignAdzoneInitForAddCampaignAbility;
    private final ICampaignMonitorInitForAddCampaignAbility campaignMonitorInitForAddCampaignAbility;

    private final ICampaignAdvBalanceValidateAbility campaignAdvBalanceValidateAbility;
    private final ICampaignAdvUpdateForUnBindAbility campaignAdvUpdateForUnBindAbility;

    private final ICampaignDeleteAbility campaignDeleteAbility;

    private final ICampaignBaseInitForUpdateCampaignAbility campaignBaseInitForUpdateCampaignAbility;
    private final ICampaignSaleInitForUpdateCampaignAbility campaignSaleInitForUpdateCampaignAbility;
    private final ICampaignResourceInitForUpdateCampaignAbility campaignResourceInitForUpdateCampaignAbility;
    private final ICampaignCreativeControllerInitForUpdateCampaignAbility campaignCreativeControllerInitForUpdateCampaignAbility;
    private final ICampaignPriceInitForUpdateCampaignAbility campaignPriceInitForUpdateCampaignAbility;
    private final ICampaignBudgetInitForUpdateCampaignAbility campaignBudgetInitForUpdateCampaignAbility;
    private final ICampaignGuaranteeInitForUpdateCampaignAbility campaignGuaranteeInitForUpdateCampaignAbility;
    private final ICampaignAdzoneInitForUpdateCampaignAbility campaignAdzoneInitForUpdateCampaignAbility;
    private final ICampaignMonitorInitForUpdateCampaignAbility campaignMonitorInitForUpdateCampaignAbility;
    private final ICampaignUpdatePartAbility campaignUpdatePartAbility;

    @Override
    public BizCampaignWorkflowParam buildParamForAddOrUpdate(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {
        AssertUtil.notNull(campaignViewDTO,"计划不允许为空");
        Long campaignGroupId = campaignViewDTO.getCampaignGroupId();
        AssertUtil.notNull(campaignGroupId, "订单ID不允许为空");
        Long packageSaleGroupId = Optional.ofNullable(campaignViewDTO.getCampaignSaleViewDTO()).map(CampaignSaleViewDTO::getSaleGroupId).orElse(null);
        AssertUtil.notNull(packageSaleGroupId,"售卖分组ID不允许为空");
        Long packageProductId = Optional.ofNullable(campaignViewDTO.getCampaignSaleViewDTO()).map(CampaignSaleViewDTO::getResourcePackageProductId).orElse(null);
        AssertUtil.notNull(packageProductId, "售卖分组资源位ID不存在");

        ResourcePackageQueryOption packageQueryOption = ResourcePackageQueryOption.builder().needProduct(true).needSetting(true).build();
        ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO = resourcePackageRepository.getSaleGroupById(serviceContext, packageSaleGroupId, packageQueryOption);
        AssertUtil.notNull(packageSaleGroupViewDTO,"资源包售卖分组不存在");

        ResourcePackageProductViewDTO packageProductViewDTO = packageSaleGroupViewDTO.getDistributionRuleList().stream().flatMap(e -> e.getResourcePackageProductList().stream())
                .filter(e -> e.getId().equals(packageProductId)).findFirst().orElse(null);
        AssertUtil.notNull(packageProductViewDTO, "售卖分组资源位不存在");

        AssertUtil.notNull(packageProductViewDTO.getSspProductId(),"二级产品ID不允许为空");
        ProductViewDTO productViewDTO = productRepository.getProductById(packageProductViewDTO.getSspProductId());
        AssertUtil.notNull(productViewDTO, "二级产品不存在");

        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(serviceContext, campaignGroupId);
        AssertUtil.notNull(campaignGroupViewDTO, "订单不存在");

        SaleGroupInfoViewDTO saleGroupInfoViewDTO = Optional.ofNullable(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO()).map(CampaignGroupSaleGroupViewDTO::getSaleGroupInfoViewDTOList).orElse(Lists.newArrayList())
                .stream().filter(saleGroupInfo -> Objects.equals(packageSaleGroupId,saleGroupInfo.getSaleGroupId())).findFirst().orElse(null);
        AssertUtil.notNull(saleGroupInfoViewDTO, "订单售卖分组不存在");

        BizCampaignWorkflowParam contentCampaignWorkflowParam = new BizCampaignWorkflowParam();
        contentCampaignWorkflowParam.setCampaignGroupViewDTO(campaignGroupViewDTO);
        contentCampaignWorkflowParam.setPackageSaleGroupViewDTO(packageSaleGroupViewDTO);
        contentCampaignWorkflowParam.setPackageProductViewDTO(packageProductViewDTO);
        contentCampaignWorkflowParam.setProductViewDTO(productViewDTO);
        contentCampaignWorkflowParam.setSaleGroupInfoViewDTO(saleGroupInfoViewDTO);
        return contentCampaignWorkflowParam;
    }

    @Override
    public Void beforeForAdd(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, BizCampaignWorkflowParam workflowParam) {
        resetCampaignDefaultObject(campaignViewDTO);
        this.validateForAdd(serviceContext, campaignViewDTO, workflowParam);
        this.initForAdd(serviceContext,campaignViewDTO,workflowParam);
        return null;
    }

    @Override
    public Void beforeForUpdate(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, CampaignViewDTO dbCampaignViewDTO, BizCampaignWorkflowParam workflowParam) {
        resetCampaignDefaultObject(campaignViewDTO);
        if(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode().equals(dbCampaignViewDTO.getCampaignLevel())){
            this.validateForUpdate(serviceContext, campaignViewDTO);
        }
        this.initForUpdate(serviceContext,campaignViewDTO,dbCampaignViewDTO,workflowParam);
        return null;
    }

    private void validateForAdd(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, BizCampaignWorkflowParam workflowParam) {
        campaignBaseValidateForAddCampaignAbility.handle(serviceContext, CampaignBaseAbilityParam.builder().abilityTarget(campaignViewDTO).build());
        campaignSaleValidateForAddCampaignAbility.handle(serviceContext, CampaignSaleAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignSaleViewDTO())
                .productViewDTO(workflowParam.getProductViewDTO()).resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());
    }

    private void initForAdd(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, BizCampaignWorkflowParam workflowParam){
        campaignBaseInitForAddCampaignAbility.handle(serviceContext,CampaignBaseAbilityParam.builder().abilityTarget(campaignViewDTO)
                .campaignGroupViewDTO(workflowParam.getCampaignGroupViewDTO())
                .resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).productViewDTO(workflowParam.getProductViewDTO()).build());

        String campaignTitle = campaignTitleInitAbility.handle(serviceContext, CampaignTitleInitAbilityParam.builder().abilityTarget(campaignViewDTO)
                .productViewDTO(workflowParam.getProductViewDTO()).showmaxCrowdList(workflowParam.getShowmaxCrowdList()).build());
        campaignViewDTO.setTitle(campaignTitle);

        campaignResourceInitForAddCampaignAbility.handle(serviceContext, CampaignResourceAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignResourceViewDTO())
                .productViewDTO(workflowParam.getProductViewDTO()).build());

        campaignCreativeControllerInitForAddCampaignAbility.handle(serviceContext, CampaignCreativeControllerAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignCreativeControllerViewDTO())
                .productViewDTO(workflowParam.getProductViewDTO()).resourcePackageSaleGroupViewDTO(workflowParam.getPackageSaleGroupViewDTO()).build());

        campaignSaleInitForAddCampaignAbility.handle(serviceContext,CampaignSaleAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignSaleViewDTO())
                .campaignGroupViewDTO(workflowParam.getCampaignGroupViewDTO())
                .resourcePackageSaleGroupViewDTO(workflowParam.getPackageSaleGroupViewDTO()).saleGroupInfoViewDTO(workflowParam.getSaleGroupInfoViewDTO())
                .productViewDTO(workflowParam.getProductViewDTO()).resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        campaignGuaranteeInitForAddCampaignAbility.handle(serviceContext,CampaignGuaranteeAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignGuaranteeViewDTO())
                .campaignViewDTO(campaignViewDTO).productViewDTO(workflowParam.getProductViewDTO()).resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        campaignInquiryLockInitForAddCampaignAbility.handle(serviceContext,CampaignInquiryLockAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignInquiryLockViewDTO())
                .campaignGroupViewDTO(workflowParam.getCampaignGroupViewDTO()).campaignViewDTO(campaignViewDTO)
                .productViewDTO(workflowParam.getProductViewDTO()).resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        campaignPriceInitForAddCampaignAbility.handle(serviceContext,CampaignPriceAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignPriceViewDTO())
                .campaignViewDTO(campaignViewDTO).productViewDTO(workflowParam.getProductViewDTO()).resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        campaignBudgetInitForAddCampaignAbility.handle(serviceContext,CampaignBudgetAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignBudgetViewDTO())
                .campaignViewDTO(campaignViewDTO).resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        campaignAdzoneInitForAddCampaignAbility.handle(serviceContext,CampaignAdzoneAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignTargetScenarioViewDTO())
                .productViewDTO(workflowParam.getProductViewDTO()).build());

        campaignMonitorInitForAddCampaignAbility.handle(serviceContext,CampaignMonitorAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignMonitorViewDTO())
                .resourcePackageSaleGroupViewDTO(workflowParam.getPackageSaleGroupViewDTO()).build());
    }


    private void validateForUpdate(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {
        //修改校验
        campaignBaseValidateForUpdateCampaignAbility.handle(serviceContext, CampaignBaseAbilityParam.builder().abilityTarget(campaignViewDTO).build());
    }

    private void initForUpdate(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, CampaignViewDTO dbCampaignViewDTO, BizCampaignWorkflowParam workflowParam){
        campaignBaseInitForUpdateCampaignAbility.handle(serviceContext,CampaignBaseAbilityParam.builder().abilityTarget(campaignViewDTO)
                .dbCampaignViewDTO(dbCampaignViewDTO).resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        campaignResourceInitForUpdateCampaignAbility.handle(serviceContext,CampaignResourceAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignResourceViewDTO())
                .dbCampaignViewDTO(dbCampaignViewDTO).build());

        campaignCreativeControllerInitForUpdateCampaignAbility.handle(serviceContext,CampaignCreativeControllerAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignCreativeControllerViewDTO())
                .dbCampaignViewDTO(dbCampaignViewDTO).build());

        campaignSaleInitForUpdateCampaignAbility.handle(serviceContext,CampaignSaleAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignSaleViewDTO())
                .dbCampaignViewDTO(dbCampaignViewDTO).build());

        campaignGuaranteeInitForUpdateCampaignAbility.handle(serviceContext,CampaignGuaranteeAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignGuaranteeViewDTO())
                .campaignViewDTO(campaignViewDTO).dbCampaignViewDTO(dbCampaignViewDTO)
                .resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        campaignPriceInitForUpdateCampaignAbility.handle(serviceContext,CampaignPriceAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignPriceViewDTO())
                .campaignViewDTO(campaignViewDTO).dbCampaignViewDTO(dbCampaignViewDTO)
                .resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        campaignBudgetInitForUpdateCampaignAbility.handle(serviceContext,CampaignBudgetAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignBudgetViewDTO())
                .campaignViewDTO(campaignViewDTO).dbCampaignViewDTO(dbCampaignViewDTO)
                .resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        campaignAdzoneInitForUpdateCampaignAbility.handle(serviceContext,CampaignAdzoneAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignTargetScenarioViewDTO())
                .dbCampaignViewDTO(dbCampaignViewDTO).build());

        campaignMonitorInitForUpdateCampaignAbility.handle(serviceContext,CampaignMonitorAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignMonitorViewDTO())
                .dbCampaignViewDTO(dbCampaignViewDTO).build());
    }

    @Override
    public Void throwingAddCampaign(ServiceContext serviceContext, List<Long> campaignIdList) {
        if(CollectionUtils.isNotEmpty(campaignIdList)){
            List<CampaignViewDTO> deleteCampaignList = campaignIdList.stream().map(id -> {
                CampaignViewDTO campaignViewDTO = new CampaignViewDTO();
                campaignViewDTO.setId(id);
                campaignViewDTO.setStatus(BrandCampaignStatusEnum.DELETE.getCode());
                return campaignViewDTO;
            }).collect(Collectors.toList());
            campaignUpdatePartAbility.handle(serviceContext,CampaignBatchAbilityParam.builder().abilityTargets(deleteCampaignList).build());
        }
        return null;
    }

    /**
     * 修改场景后置处理逻辑
     *
     * @param serviceContext
     * @param campaignViewDTO
     * @param dbCampaignViewDTO
     * @param bizCampaignWorkflowParam
     * @return
     */
    @Override
    public Void afterUpdateCampaign(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, CampaignViewDTO dbCampaignViewDTO, BizCampaignWorkflowParam bizCampaignWorkflowParam) {
        // 2. 通知订单更新计算信息
        CampaignGroupCalculateContext calculateContext = CampaignGroupCalculateContext.builder()
                .serviceContext(serviceContext)
                .campaignGroupId(campaignViewDTO.getCampaignGroupId())
                .build();
        messageSyncSendAbility.handle(serviceContext, MessageSyncSendAbilityParam.builder()
                .abilityTarget(CampaignGroupCalculateEvent.of(calculateContext)).build());
        return null;
    }

    @Override
    public Void handleAfterCancelCampaignGroup(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, List<CampaignViewDTO> campaignTreeList) {
        try{
            unBindAdv(serviceContext, campaignGroupViewDTO, campaignTreeList);
        }catch (Exception e){
            RogerLogger.error("effect order cancel notice unbind failed: " + e.getMessage(), e);
        }

        return null;
    }

    @Override
    public Void beforeAutoAddCampaign(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, List<CampaignViewDTO> campaignViewDTOList) {
        // 删除计划
        CampaignQueryViewDTO query = new CampaignQueryViewDTO();
        query.setCampaignGroupId(campaignGroupViewDTO.getId());
        List<CampaignViewDTO> dbCampaignList = campaignStructureQueryAbility.handle(serviceContext,CampaignStructureQueryAbilityParam.builder()
                .abilityTarget(query).queryOption(CampaignQueryOption.builder().build()).build());
        if (CollectionUtils.isEmpty(dbCampaignList)) {
            return null;
        }
        campaignDeleteAbility.handle(serviceContext, CampaignBatchAbilityParam.builder().abilityTargets(dbCampaignList).build());
        return null;
    }

    @Override
    public Void afterAutoAddCampaign(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, List<Long> campaignIds) {
        // 没有新计划生成，则无需通知
        if (CollectionUtils.isEmpty(campaignIds)) {
            return null;
        }
        // 1. 通知订单更新计算信息
        CampaignGroupCalculateContext calculateContext = CampaignGroupCalculateContext.builder()
                .serviceContext(serviceContext)
                .campaignGroupId(campaignGroupViewDTO.getId())
                .build();
        messageSyncSendAbility.handle(serviceContext, MessageSyncSendAbilityParam.builder()
                .abilityTarget(CampaignGroupCalculateEvent.of(calculateContext)).build());

        // 2. 通知子订单下单
        CampaignGroupOrderContext campaignGroupOrderContext = CampaignGroupOrderContext.builder()
                .serviceContext(serviceContext)
                .campaignGroupId(campaignGroupViewDTO.getId())
                .build();
        messageSyncSendAbility.handle(serviceContext, MessageSyncSendAbilityParam.builder()
                .abilityTarget(CampaignCreateNoticeEvent.of(campaignGroupOrderContext)).build());
        return null;
    }

    @Override
    public Void afterAutoUpdateCampaign(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, List<Long> addCampaignIds) {
        // 1. 通知订单更新计算信息
        CampaignGroupCalculateContext calculateContext = CampaignGroupCalculateContext.builder()
                .serviceContext(serviceContext)
                .campaignGroupId(campaignGroupViewDTO.getId())
                .build();
        messageSyncSendAbility.handle(serviceContext, MessageSyncSendAbilityParam.builder()
                .abilityTarget(CampaignGroupCalculateEvent.of(calculateContext)).build());

        // 通知订单下单
        if (CollectionUtils.isNotEmpty(addCampaignIds)) {
            fireCampaignGroupOrderEventForUpdate(serviceContext, campaignGroupViewDTO, addCampaignIds);
        }

        return null;
    }

    private void fireCampaignGroupOrderEventForUpdate(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, List<Long> addCampaignIds) {
        List<Long> waitOrderPackageSaleGroupIds = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream()
                .filter(item -> BrandSaleGroupSourceEnum.PACKAGE_PLATFORM.getCode().equals(item.getSource()))
                .filter(item -> BrandCampaignGroupSaleOrderStatusEnum.WAIT_ORDER.getCode().equals(item.getSaleGroupStatus()))
                .map(SaleGroupInfoViewDTO::getSaleGroupId)
                .collect(Collectors.toList());
        if (CollectionUtils.isEmpty(waitOrderPackageSaleGroupIds)) {
            return;
        }
        // 2. 通知子订单下单
        CampaignQueryViewDTO query = new CampaignQueryViewDTO();
        query.setCampaignGroupId(campaignGroupViewDTO.getId());
        query.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
        query.setSaleGroupIds(waitOrderPackageSaleGroupIds);
        List<CampaignViewDTO> dbCampaignList = campaignStructureQueryAbility.handle(serviceContext,
                CampaignStructureQueryAbilityParam.builder().abilityTarget(query).queryOption(CampaignQueryOption.builder().build()).build());

        Map<Long, List<Long>> dbSaleGroupCampaignIdMap = dbCampaignList.stream()
                .collect(Collectors.groupingBy(item -> item.getCampaignSaleViewDTO().getSaleGroupId(),
                        Collectors.mapping(CampaignViewDTO::getId, Collectors.toList())));
        List<Long> addSaleGroupIds = Lists.newArrayList();
        for (Map.Entry<Long, List<Long>> entry : dbSaleGroupCampaignIdMap.entrySet()) {
            long count = entry.getValue().stream().filter(addCampaignIds::contains).count();
            if (count == entry.getValue().size()) {
                addSaleGroupIds.add(entry.getKey());
            }
        }
        if (CollectionUtils.isEmpty(addSaleGroupIds)) {
            return;
        }

        CampaignGroupOrderContext campaignGroupOrderContext = CampaignGroupOrderContext.builder()
                .serviceContext(serviceContext)
                .campaignGroupId(campaignGroupViewDTO.getId())
                .saleGroupIds(addSaleGroupIds)
                .build();
        messageSyncSendAbility.handle(serviceContext, MessageSyncSendAbilityParam.builder()
                .abilityTarget(CampaignCreateNoticeEvent.of(campaignGroupOrderContext)).build());
    }

    /**
     * 订单解绑ADV, 子订单
     * @param serviceContext
     * @param campaignGroupViewDTO
     * @param campaignTreeList
     */
    private void unBindAdv(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, List<CampaignViewDTO> campaignTreeList) {
        //1. 构建处理参数
        BizCampaignAdvBindOrUnBindWorkflowParam campaignAdvParamDefinition = buildUnbindAdvParam(serviceContext, campaignGroupViewDTO, campaignTreeList);

        // 校验adv余额
        campaignAdvBalanceValidateAbility.handle(serviceContext, CampaignAdvValidateAbilityParam.builder()
                .abilityTargets(campaignAdvParamDefinition.getAdvertiserViewDTOList()).build());
        // 删除子计划
        campaignDeleteAbility.handle(serviceContext, CampaignBatchAbilityParam.builder().abilityTargets(campaignAdvParamDefinition.getSubCampaignViewDTOList()).build());

        //6. 解绑后置处理
        campaignAdvUpdateForUnBindAbility.handle(serviceContext, CampaignAdvUpdateAbilityParam.builder()
                .abilityTargets(campaignAdvParamDefinition.getSubCampaignViewDTOList()).advIds(campaignAdvParamDefinition.getAdvIds()).build());
    }

    public BizCampaignAdvBindOrUnBindWorkflowParam buildUnbindAdvParam(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, List<CampaignViewDTO> campaignTreeList) {
        BizCampaignAdvBindOrUnBindWorkflowParam campaignAdvWorkflowParam = new BizCampaignAdvBindOrUnBindWorkflowParam();
        campaignAdvWorkflowParam.setCampaignGroupViewDTO(campaignGroupViewDTO);
        campaignAdvWorkflowParam.setDbCampaignViewDTOList(campaignTreeList);
        if (CollectionUtils.isEmpty(campaignTreeList)) {
            return campaignAdvWorkflowParam;
        }

        List<CampaignViewDTO> subCampaignList = campaignTreeList.stream()
                .filter(dbCampaignViewDTO -> CollectionUtils.isNotEmpty(dbCampaignViewDTO.getSubCampaignViewDTOList()))
                .flatMap(dbCampaignViewDTO -> dbCampaignViewDTO.getSubCampaignViewDTOList().stream())
                .collect(Collectors.toList());
        campaignAdvWorkflowParam.setSubCampaignViewDTOList(subCampaignList);
        if (CollectionUtils.isEmpty(subCampaignList)) {
            return campaignAdvWorkflowParam;
        }

        List<Long> advIds = subCampaignList.stream()
                .filter(item -> Objects.nonNull(item.getCampaignEffectProxyViewDTO()))
                .filter(item -> Objects.nonNull(item.getCampaignEffectProxyViewDTO().getEffectAdvId()))
                .map(item -> item.getCampaignEffectProxyViewDTO().getEffectAdvId()).distinct().collect(Collectors.toList());
        campaignAdvWorkflowParam.setAdvIds(advIds);

        List<EffectAdvertiserViewDTO> effectAdvertiserViewDTOS = effectAdvertiserRepository.findEffectAdvInnerList(serviceContext, advIds);
        campaignAdvWorkflowParam.setAdvertiserViewDTOList(effectAdvertiserViewDTOS);
        return campaignAdvWorkflowParam;
    }
}
