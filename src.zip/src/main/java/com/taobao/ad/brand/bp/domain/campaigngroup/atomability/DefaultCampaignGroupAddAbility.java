package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.salegroup.CampaignGroupSaleGroupViewDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupAddAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupAbilityParam;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Optional;

@Component
@BusinessAbility
public class DefaultCampaignGroupAddAbility implements ICampaignGroupAddAbility {
    @Resource
    private CampaignGroupRepository campaignGroupRepository;

    @Override
    public Long handle(ServiceContext serviceContext, CampaignGroupAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        //保存订单
        Long campaignGroupId = campaignGroupRepository.addCampaignGroup(serviceContext, campaignGroupViewDTO);
        // 绑定分组
        List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList = Optional.ofNullable(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO()).map(CampaignGroupSaleGroupViewDTO::getSaleGroupInfoViewDTOList)
                .orElse(Lists.newArrayList());
        campaignGroupRepository.bindAllSaleGroup(serviceContext, campaignGroupId, saleGroupInfoViewDTOList);
        return campaignGroupId;
    }
}
