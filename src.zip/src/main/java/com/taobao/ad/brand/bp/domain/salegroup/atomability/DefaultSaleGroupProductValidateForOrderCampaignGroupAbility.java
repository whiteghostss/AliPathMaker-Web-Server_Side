package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourceDistributionRuleViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupProductValidateForOrderCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupOrderAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultSaleGroupProductValidateForOrderCampaignGroupAbility implements ISaleGroupProductValidateForOrderCampaignGroupAbility {

    @Override
    public Void handle(ServiceContext serviceContext, SaleGroupOrderAbilityParam abilityParam) {
        List<SaleGroupInfoViewDTO> orderSaleGroupInfoViewDTOList = abilityParam.getAbilityTargets();
        List<Long> saleGroupIds = abilityParam.getSaleGroupIds();
        List<ResourcePackageSaleGroupViewDTO> resourceSaleGroupViewDTOList = abilityParam.getResourcePackageSaleGroupList();
        List<CampaignViewDTO> campaignViewDTOList = abilityParam.getCampaignViewDTOList();

        Map<Long, List<CampaignViewDTO>> saleGroupCampaignMap = campaignViewDTOList.stream()
                .collect(Collectors.groupingBy(v -> v.getCampaignSaleViewDTO().getSaleGroupId()));
        // 校验资源维度：必选资源、周期
        for (ResourcePackageSaleGroupViewDTO resourceSaleGroupViewDTO : resourceSaleGroupViewDTOList) {
            if (!saleGroupIds.contains(resourceSaleGroupViewDTO.getId())) {
                continue;
            }
            if (CollectionUtils.isEmpty(resourceSaleGroupViewDTO.getDistributionRuleList())) {
                continue;
            }
            // 校验分组下是否有有效的计划
            List<CampaignViewDTO> saleGroupCampaignViewDTOList = saleGroupCampaignMap.get(resourceSaleGroupViewDTO.getId());
            AssertUtil.notEmpty(saleGroupCampaignViewDTOList, String.format("分组(%s)下无有效计划", resourceSaleGroupViewDTO.getName()));

            Map<Long, List<CampaignViewDTO>> resourcePackageProductCampaignMap = saleGroupCampaignViewDTOList.stream().collect(
                    Collectors.groupingBy(v -> v.getCampaignSaleViewDTO().getResourcePackageProductId()));
            for (ResourceDistributionRuleViewDTO ruleViewDTO : resourceSaleGroupViewDTO.getDistributionRuleList()) {
                if (CollectionUtils.isEmpty(ruleViewDTO.getResourcePackageProductList())) {
                    continue;
                }
                for (ResourcePackageProductViewDTO resourcePackageProductViewDTO : ruleViewDTO.getResourcePackageProductList()) {
                    String productName = resourcePackageProductViewDTO.getCustomerOrientedProductName();
                    List<CampaignViewDTO> resourcePackageProductCampaignViewDTOList = resourcePackageProductCampaignMap.get(resourcePackageProductViewDTO.getId());
                    // 资源下无计划时，校验是否是必选资源
                    if (CollectionUtils.isEmpty(resourcePackageProductCampaignViewDTOList)) {
                        AssertUtil.assertTrue(!BrandBoolEnum.BRAND_TRUE.getCode().equals(resourcePackageProductViewDTO.getIsNecessary()), BrandOneBPBaseErrorCode.PARAM_REQUIRED,
                                String.format("分组下必选资源(%s)未建计划，请勾选并创建计划", productName));
                        continue;
                    }
                    // 资源周期覆盖计划周期
                    Date startDate = resourcePackageProductViewDTO.getStartTime();
                    Date endDate = resourcePackageProductViewDTO.getEndTime();
                    for (CampaignViewDTO campaignViewDTO : resourcePackageProductCampaignViewDTOList) {
                        AssertUtil.assertTrue(BrandDateUtil.isAfterAndEqual(campaignViewDTO.getStartTime(), startDate),
                                String.format("资源(%s)下计划(%s)必须在资源投放周期内", productName, campaignViewDTO.getTitle()));
                        AssertUtil.assertTrue(BrandDateUtil.isBeforeAndEqual(campaignViewDTO.getEndTime(), BrandDateUtil.getDateFullMidnight(endDate)),
                                String.format("资源下(%s)计划(%s)必须在资源投放周期内", productName, campaignViewDTO.getTitle()));
                    }
                }
            }
        }

        return null;
    }
}
