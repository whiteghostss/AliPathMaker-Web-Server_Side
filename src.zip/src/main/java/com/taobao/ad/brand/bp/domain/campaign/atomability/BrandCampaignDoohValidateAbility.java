package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.dooh.CampaignDoohViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignDoohStrategyMethodEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupProductCategoryEnum;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohStrategyViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.enums.dooh.DoohStrategyStatusEnum;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.dooh.repository.DoohRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignDoohValidateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignDoohAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandCampaignDoohValidateAbility implements ICampaignDoohValidateAbility, BrandAtomAbilityRouter {

    private final CampaignRepository campaignRepository;
    private final DoohRepository doohRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignDoohAbilityParam abilityParam) {
        ProductViewDTO productViewDTO = abilityParam.getProductViewDTO();
        if(productViewDTO == null || !BizCampaignToolsHelper.isDoohCampaign(productViewDTO.getProductLineId())){
            return null;
        }
        CampaignDoohViewDTO campaignDoohViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(campaignDoohViewDTO,"天攻配置不允许为空");
        ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO = abilityParam.getResourcePackageSaleGroupViewDTO();
        AssertUtil.notNull(resourcePackageSaleGroupViewDTO,"售卖分组不能为空");
        //4. 如果有策略ID，策略不能是计算中
        Long doohStrategyId = campaignDoohViewDTO.getDoohStrategyId();
        //极速达的自定义策略，页面不会传入策略ID，以db数据为准
        if (SaleGroupProductCategoryEnum.SMART_SCREEN_SPEED.getValue().equals(resourcePackageSaleGroupViewDTO.getProductCategory()) && BrandCampaignDoohStrategyMethodEnum.CUSTOM_STRATEGY.getCode().equals(campaignDoohViewDTO.getStrategyMethod())) {
            CampaignViewDTO campaignViewDTO = campaignRepository.getCampaignById(serviceContext, abilityParam.getCampaignViewDTO().getId());
            doohStrategyId = campaignViewDTO.getCampaignDoohViewDTO().getDoohStrategyId();
        }
        if(doohStrategyId != null){
            DoohStrategyViewDTO doohStrategyViewDTO = doohRepository.getStrategyById(doohStrategyId);
            AssertUtil.assertTrue(doohStrategyViewDTO != null && !DoohStrategyStatusEnum.CALCULATING.getCode().equals(doohStrategyViewDTO.getStatus()), "查询不到策略信息或策略计算中，不允许修改计划");
        }
        return null;
    }
}
