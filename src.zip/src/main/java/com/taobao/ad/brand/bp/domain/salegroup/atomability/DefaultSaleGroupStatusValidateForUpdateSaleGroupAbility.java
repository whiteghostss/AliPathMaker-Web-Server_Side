package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSaleOrderStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupStatusValidateForUpdateSaleGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupStatusValidateForUpdateSaleGroupAbilityParam;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Objects;

@Component
@BusinessAbility
public class DefaultSaleGroupStatusValidateForUpdateSaleGroupAbility implements ISaleGroupStatusValidateForUpdateSaleGroupAbility {

    @Override
    public Void handle(ServiceContext context, SaleGroupStatusValidateForUpdateSaleGroupAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        SaleGroupInfoViewDTO saleGroupInfoViewDTO = abilityParam.getSaleGroupInfoViewDTO();
        AssertUtil.assertTrue(saleGroupInfoViewDTO.getSaleGroupStatus().equals(BrandCampaignGroupSaleOrderStatusEnum.WAIT_ORDER.getCode()),
                BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR, "分组在未下单的情况下，才可以修改指标/人群");
        if (campaignGroupViewDTO.getStatus().equals(BrandCampaignGroupStatusEnum.UNLOCKED.getCode())) {
            //日期动态计算
            Date startDate = saleGroupInfoViewDTO.getStartDate();
            AssertUtil.assertTrue(null != startDate, BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR, "分组未计算，缺少开始日期");
            Date endDate = saleGroupInfoViewDTO.getEndDate();
            AssertUtil.assertTrue(null != endDate, BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR, "分组未计算，缺少结束日期");
            AssertUtil.assertTrue(BrandDateUtil.notAfter(startDate, endDate), BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR, "分组开始日期不能晚于结束日期");
            //判断是否在投放期
            int range = BrandDateUtil.timeRange(new Date(), startDate, endDate);
            AssertUtil.assertTrue(range <= 0, BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR, "改单配置,分组已经投放结束，不允许修改");
        }
        AssertUtil.assertTrue(Objects.equals(saleGroupInfoViewDTO.getSaleGroupStatus(),BrandCampaignGroupSaleOrderStatusEnum.WAIT_ORDER.getCode()),
                BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR,"分组在未下单的情况下，才可以修改指标/人群");
        return null;
    }
}
