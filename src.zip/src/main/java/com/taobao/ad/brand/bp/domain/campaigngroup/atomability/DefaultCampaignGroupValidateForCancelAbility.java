package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupCancelModeEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupCancelCommandViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesContractAmountViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.SalesContractRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupValidateForCancelAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupValidateForCancelAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR;

@Component
@BusinessAbility
public class DefaultCampaignGroupValidateForCancelAbility implements ICampaignGroupValidateForCancelAbility{


    /**
     * 支持撤单的订单状态
     */
    private static final List<Integer> validCampaignGroupStatusListOnCancel = Lists.newArrayList(
            BrandCampaignGroupStatusEnum.EDITED.getCode(),
            BrandCampaignGroupStatusEnum.ORDER_ING.getCode(),
            BrandCampaignGroupStatusEnum.RESOURCE_CONFIRM_ING.getCode(),
            BrandCampaignGroupStatusEnum.CONTRACT_PROCESS_ING.getCode(),
            BrandCampaignGroupStatusEnum.WAIT_CAST.getCode()
    );

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupValidateForCancelAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroup = abilityParam.getAbilityTarget();
        // 状态校验
        AssertUtil.assertTrue(validCampaignGroupStatusListOnCancel.contains(campaignGroup.getStatus()), BIZ_BREAK_RULE_ERROR, "当前订单状态不支持该操作");
        return null;
    }
}
