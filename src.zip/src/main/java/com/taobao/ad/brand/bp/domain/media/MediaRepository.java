package com.taobao.ad.brand.bp.domain.media;

import com.taobao.ad.brand.bp.client.dto.media.MediaBusinessManagerViewDTO;
import com.taobao.ad.brand.bp.client.dto.media.MediaContactViewDTO;
import com.taobao.ad.brand.bp.client.dto.media.MediaViewDTO;

import java.util.List;
import java.util.Map;

public interface MediaRepository {

    List<MediaViewDTO> queryMediaListBySiteIds(List<Long> siteIds);

    /**
     * 通过媒体id获取媒体信息
     * @param mediaIds
     * @return
     */
    List<MediaViewDTO> queryMediaListByMediaIds(List<Long> mediaIds);

    /**
     * 通过媒体id获取媒体Map
     * @param mediaIds
     * @return
     */
    Map<Long, MediaViewDTO> queryMediaMapByMediaIds(List<Long> mediaIds);

    /**
     * 获取媒体联系人
     */
    List<MediaContactViewDTO> getMediaContractorList(List<Long> mediaIds);
    List<MediaBusinessManagerViewDTO> getMediaBusinessManagerList(List<Long> mediaIds);

    List<MediaViewDTO> queryMediaWithSettingByMediaIds(List<Long> mediaIds);
}
