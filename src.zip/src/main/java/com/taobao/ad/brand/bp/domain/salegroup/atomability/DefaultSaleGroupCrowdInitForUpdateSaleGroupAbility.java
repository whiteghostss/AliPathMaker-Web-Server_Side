package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupCrowdViewDTO;
import com.taobao.ad.brand.bp.domain.dmp.CrowdRepository;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupCrowdInitForUpdateSaleGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupCrowdInitForUpdateSaleGroupAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultSaleGroupCrowdInitForUpdateSaleGroupAbility implements ISaleGroupCrowdInitForUpdateSaleGroupAbility {

    private final CrowdRepository crowdRepository;

    @Override
    public Void handle(ServiceContext serviceContext, SaleGroupCrowdInitForUpdateSaleGroupAbilityParam abilityParam) {
        SaleGroupInfoViewDTO saleGroupInfoViewDTO = abilityParam.getAbilityTarget();
        CampaignGroupSaleGroupCrowdViewDTO saleGroupCrowdViewDTO = abilityParam.getSaleGroupCrowdViewDTO();
        //人群规模
        Long coverage =  crowdRepository.getCrowdCoverage(serviceContext, saleGroupCrowdViewDTO.getCrowdIdList());
        saleGroupInfoViewDTO.setCrowdIds(saleGroupCrowdViewDTO.getCrowdIdList());
        saleGroupInfoViewDTO.setCoverage(coverage);
        return null;
    }
}
