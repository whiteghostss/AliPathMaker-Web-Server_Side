package com.taobao.ad.brand.bp.domain.dmp;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.TagOptionViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.query.TagOptionQueryViewDTO;

import java.util.List;

/**
 * dmp标签相关服务
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
public interface DmpTagRepository {

    /**
     * 分页查询，tagId下的标签数据
     * @param context
     * @param queryViewDTO
     * @return
     */
    PageResultViewDTO<TagOptionViewDTO> findOptionsPageList(ServiceContext context, TagOptionQueryViewDTO queryViewDTO);

    /**
     * 通过tagId查询标签数据
     * @param context
     * @param tagId
     * @return
     */
    List<TagOptionViewDTO> findOptionsByTagId(ServiceContext context, Long tagId);

}
