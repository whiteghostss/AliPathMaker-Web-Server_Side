package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.taobao.ad.brand.bp.client.dto.rule.RuleCheckResultViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignAddPermissionJudgeAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignAddPermissionJudgeAbilityParam;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
public class DefaultCampaignAddPermissionJudgeAbility implements ICampaignAddPermissionJudgeAbility {

    @Override
    public RuleCheckResultViewDTO handle(ServiceContext serviceContext, CampaignAddPermissionJudgeAbilityParam abilityParam) {
        return RuleCheckResultViewDTO.builder().isPass(BrandBoolEnum.BRAND_TRUE.getCode()).build();
    }
}
