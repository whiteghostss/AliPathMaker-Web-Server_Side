package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.biz.definition.constants.UniversalCampaignModel;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.nb.ssp.constant.common.MediaScopeEnum;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignTemplateViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignBottomSubCampaignGetAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBottomSubCampaignGetAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSelfCampaignBottomSubCampaignGetAbility implements ICampaignBottomSubCampaignGetAbility, BrandSelfServiceAtomAbilityRouter {

    @Override
    public List<CampaignViewDTO> handle(ServiceContext serviceContext, CampaignBottomSubCampaignGetAbilityParam abilityParam) {
        CampaignViewDTO campaignTreeViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(campaignTreeViewDTO,"计划不能为空");
        Map<Long, CampaignTemplateViewDTO> campaignTemplateMap = Optional.ofNullable(abilityParam.getCampaignTemplateMap()).orElse(Maps.newHashMap());
        Set<Integer> bottomCampaignModelSet = Sets.newHashSet(UniversalCampaignModel.TAO_OUT_THREE_PDB.getId(), UniversalCampaignModel.TAO_OUT_THREE_GD.getId());
        List<CampaignViewDTO> subCampaignViewDTOList = campaignTreeViewDTO.getSubCampaignViewDTOList().stream()
                .filter(subCampaignViewDTO -> MediaScopeEnum.SITE_OUT.getCode().equals(subCampaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope()))
                .filter(subCampaignViewDTO -> bottomCampaignModelSet.contains(subCampaignViewDTO.getCampaignModel()))
                .filter(subCampaignViewDTO -> {
                    CampaignTemplateViewDTO campaignTemplateViewDTO = campaignTemplateMap.get(subCampaignViewDTO.getId());
                    return Optional.ofNullable(campaignTemplateViewDTO).map(CampaignTemplateViewDTO::getTemplateIds).isPresent();
                }).collect(Collectors.toList());
        return subCampaignViewDTOList;
    }
}
