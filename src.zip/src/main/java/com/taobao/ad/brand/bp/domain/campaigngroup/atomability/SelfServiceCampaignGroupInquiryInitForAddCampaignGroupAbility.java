package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.inquiry.CampaignGroupInquiryViewDTO;
import com.taobao.ad.brand.bp.common.constant.campaigngroup.CampaignGroupConstant;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupInquiryInitForAddCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupInquiryAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCampaignGroupInquiryInitForAddCampaignGroupAbility
        implements ICampaignGroupInquiryInitForAddCampaignGroupAbility, SelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupInquiryAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        CampaignGroupInquiryViewDTO inquiryViewDTO = Optional.ofNullable(abilityParam.getAbilityTarget()).orElse(new CampaignGroupInquiryViewDTO());
        // 盘量优先级
        inquiryViewDTO.setInquiryDate(BrandDateUtil.string2Date(CampaignGroupConstant.INQUIRY_MIN_DATE, BrandDateUtil.DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_1));
        inquiryViewDTO.setInquiryBatch(0);

        campaignGroupViewDTO.setCampaignGroupInquiryViewDTO(inquiryViewDTO);
        return null;
    }
}
