package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.enums.distlock.DistLockEnum;
import com.taobao.ad.brand.bp.common.util.DistLockUtil;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignOperateDistLockGetAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignOperateDistLockAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2025/5/12
 **/
@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultCampaignOperateDistLockGetAbility implements ICampaignOperateDistLockGetAbility {
    @Override
    public Void handle(ServiceContext serviceContext, CampaignOperateDistLockAbilityParam abilityParam) {
        Optional.ofNullable(abilityParam.getAbilityTargets()).orElse(Lists.newArrayList())
                .forEach(this::tryGetCampaignOperateDistLock);
        return null;
    }

    /**
     * 获取计划操作分布式锁
     * @param campaignId
     */
    private void tryGetCampaignOperateDistLock(Long campaignId){
        String lockCampaignKey = DistLockEnum.CAMPAIGN_LOCKING_KEY.formatLockKey(campaignId);
        DistLockUtil.getLock(lockCampaignKey, lockCurValue -> String.format("计划%s正在发起锁量/释量/取消/超接等操作中,操作信息:%s，请等待操作结束后操作!", campaignId,lockCurValue));
    }
}
