package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageNoticeTemplateViewDTO;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupInquiryInfoUpdateForNoticeSaleGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupInquiryInfoUpdateForNoticeSaleGroupAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultSaleGroupInquiryInfoUpdateForNoticeSaleGroupAbility implements ISaleGroupInquiryInfoUpdateForNoticeSaleGroupAbility {

    private final CampaignGroupRepository campaignGroupRepository;

    @Override
    public Void handle(ServiceContext campaignGroupServiceContext, SaleGroupInquiryInfoUpdateForNoticeSaleGroupAbilityParam abilityParam) {
        List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList = abilityParam.getAbilityTargets();
        ResourcePackageNoticeTemplateViewDTO noticeTemplateViewDTO = abilityParam.getNoticeTemplateViewDTO();
        List<SaleGroupInfoViewDTO> updateSaleGroupInfoViewDTOs = saleGroupInfoViewDTOList.stream()
                .filter(saleGroupInfoViewDTO -> noticeTemplateViewDTO.getSaleGroupIdList().contains(saleGroupInfoViewDTO.getSaleGroupId()))
                .map(saleGroupInfoViewDTO -> {
                    saleGroupInfoViewDTO.setInquiryBatch(noticeTemplateViewDTO.getInquiryBatch());
                    saleGroupInfoViewDTO.setInquiryDate(noticeTemplateViewDTO.getInquiryDate());
                    saleGroupInfoViewDTO.setHasInquiryPriority(noticeTemplateViewDTO.getInquiryDate() == null ?
                            BrandBoolEnum.BRAND_FALSE.getCode() : BrandBoolEnum.BRAND_TRUE.getCode());
                    SaleGroupInfoViewDTO update = new SaleGroupInfoViewDTO();
                    update.setId(saleGroupInfoViewDTO.getId());
                    update.setSaleGroupId(saleGroupInfoViewDTO.getSaleGroupId());
                    update.setCampaignGroupId(saleGroupInfoViewDTO.getCampaignGroupId());
                    update.setInquiryBatch(saleGroupInfoViewDTO.getInquiryBatch());
                    update.setInquiryDate(saleGroupInfoViewDTO.getInquiryDate());
                    update.setHasInquiryPriority(saleGroupInfoViewDTO.getHasInquiryPriority());
                    return update;
                }).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(updateSaleGroupInfoViewDTOs)) {
            return null;
        }
        // 1.更新分组状态
        campaignGroupRepository.updateSaleGroupPart(campaignGroupServiceContext, updateSaleGroupInfoViewDTOs);
        return null;
    }
}
