package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSaleOrderStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleGroupSourceEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupStatusEnum;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupValidateForOrderCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupOrderAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultSaleGroupValidateForOrderCampaignGroupAbility implements ISaleGroupValidateForOrderCampaignGroupAbility {

    @Override
    public Void handle(ServiceContext serviceContext, SaleGroupOrderAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        List<Long> saleGroupIds = abilityParam.getSaleGroupIds();
        List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupViewDTOList = abilityParam.getResourcePackageSaleGroupList();
        // 1. 校验所有source=1的“未下单”状态的分组必须全部勾选
        List<SaleGroupInfoViewDTO> salePlatformSaleGroupList = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream()
                .filter(t -> BrandSaleGroupSourceEnum.SALE_PLATFORM.getCode().equals(t.getSource()))
                .collect(Collectors.toList());
        // 本次下单的购买分组
        List<Long> selectedSalePlatformSaleGroupIds = salePlatformSaleGroupList.stream()
                .map(SaleGroupInfoViewDTO::getSaleGroupId)
                .filter(saleGroupIds::contains).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(selectedSalePlatformSaleGroupIds)) {
            List<Long> remainingSalePlatformSaleGroupIds = salePlatformSaleGroupList.stream().map(SaleGroupInfoViewDTO::getSaleGroupId)
                    .filter(saleGroupId -> !selectedSalePlatformSaleGroupIds.contains(saleGroupId)).collect(Collectors.toList());
            // 售卖中心平台分组没有全部勾选时
            if (CollectionUtils.isNotEmpty(remainingSalePlatformSaleGroupIds)) {
                boolean hasWaitOrderSaleGroup = salePlatformSaleGroupList.stream().filter(t -> remainingSalePlatformSaleGroupIds.contains(t.getSaleGroupId()))
                        .anyMatch(t -> BrandCampaignGroupSaleOrderStatusEnum.WAIT_ORDER.getCode().equals(t.getSaleGroupStatus()));
                AssertUtil.assertTrue(!hasWaitOrderSaleGroup, BIZ_BREAK_RULE_ERROR, "所有购买分组必须全部勾选");
            }
        }

        // 2. 校验分组是否有效
        List<String> unEffectiveSaleGroupNames = resourcePackageSaleGroupViewDTOList.stream()
                .filter(saleGroup -> saleGroupIds.contains(saleGroup.getId()) && !SaleGroupStatusEnum.EFFECTIVE.getValue().equals(saleGroup.getStatus()))
                .map(ResourcePackageSaleGroupViewDTO::getName)
                .collect(Collectors.toList());
        AssertUtil.assertTrue(CollectionUtils.isEmpty(unEffectiveSaleGroupNames), String.format("以下分组(%s)正在审核中，不支持下单", StringUtils.join(unEffectiveSaleGroupNames, ", ")));

        return null;
    }
}
