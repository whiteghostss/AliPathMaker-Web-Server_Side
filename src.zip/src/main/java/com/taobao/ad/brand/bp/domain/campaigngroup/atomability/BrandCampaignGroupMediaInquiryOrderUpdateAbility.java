package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.purchase.CampaignGroupPurchaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignScheduleViewDTO;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupMediaInquiryOrderUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupMediaInquiryOrderUpdateAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
@BusinessAbility
public class BrandCampaignGroupMediaInquiryOrderUpdateAbility
        implements ICampaignGroupMediaInquiryOrderUpdateAbility, BrandAtomAbilityRouter {

    @Resource
    private CampaignGroupRepository campaignGroupRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupMediaInquiryOrderUpdateAbilityParam abilityParam) {
        List<CampaignScheduleViewDTO> campaignScheduleViewDTOList = abilityParam.getAbilityTargets();
        if(CollectionUtils.isEmpty(campaignScheduleViewDTOList)){
            return null;
        }
        Map<Long, Long> campaignGroupSspOrderMap = campaignScheduleViewDTOList.stream().filter(
                v -> v.getCampaignGroupId() != null && v.getMediaInquiryOrderId() != null).collect(
                Collectors.toMap(CampaignScheduleViewDTO::getCampaignGroupId, CampaignScheduleViewDTO::getMediaInquiryOrderId, (o1, o2) -> o2));
        for (Map.Entry<Long, Long> entry : campaignGroupSspOrderMap.entrySet()) {
            CampaignGroupViewDTO campaignGroupViewDTO = new CampaignGroupViewDTO();
            campaignGroupViewDTO.setId(entry.getKey());
            CampaignGroupPurchaseViewDTO purchaseViewDTO = new CampaignGroupPurchaseViewDTO();
            campaignGroupViewDTO.setCampaignGroupPurchaseViewDTO(purchaseViewDTO);
            purchaseViewDTO.setMediaInquiryOrderId(entry.getValue());
            campaignGroupRepository.updateCampaignGroupPart(serviceContext, campaignGroupViewDTO);
        }
        return null;
    }
}
