package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignStatusValidateForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignStatusValidateForUpdateCampaignAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCampaignStatusValidateForUpdateCampaignAbility implements ICampaignStatusValidateForUpdateCampaignAbility, SelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignStatusValidateForUpdateCampaignAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        if(Objects.nonNull(campaignGroupViewDTO)){
            AssertUtil.assertTrue(BrandCampaignGroupStatusEnum.EDITED.getCode().equals(campaignGroupViewDTO.getStatus()),"订单状态不允许，非草稿订单禁止编辑！");
        }
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        AssertUtil.notNull(dbCampaignViewDTO,"计划不存在");
        List<CampaignViewDTO> allCampaignViewDTOList = BizCampaignToolsHelper.flatCampaignList(dbCampaignViewDTO);
        for (CampaignViewDTO viewDTO : allCampaignViewDTOList) {
            BrandCampaignStatusEnum campaignStatusEnum = BrandCampaignStatusEnum.getByCode(viewDTO.getStatus());
            if (BrandCampaignStatusEnum.LOCKING == campaignStatusEnum){
                throw new BrandOneBPException("锁量中不允许修改");
            }
        }
        return null;
    }
}
