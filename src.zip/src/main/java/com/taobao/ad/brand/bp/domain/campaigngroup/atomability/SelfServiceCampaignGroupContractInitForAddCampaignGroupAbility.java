package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.contract.CampaignGroupContractViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupContractPayTypeEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupContractSignStatusEnum;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupCustomerMemberViewDTO;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.SalesContractRepository;
import com.taobao.ad.brand.bp.domain.config.SelfServiceTestMemberConfig;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupContractInitForAddCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupContractAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCampaignGroupContractInitForAddCampaignGroupAbility
        implements ICampaignGroupContractInitForAddCampaignGroupAbility, SelfServiceAtomAbilityRouter {

    private final SalesContractRepository salesContractRepository;
    private final SelfServiceTestMemberConfig selfServiceTestMemberConfig;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupContractAbilityParam abilityParam) {
        CampaignGroupContractViewDTO campaignGroupContractViewDTO = Optional.ofNullable(abilityParam.getAbilityTarget()).orElse(new CampaignGroupContractViewDTO());
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        // 签约状态
        campaignGroupContractViewDTO.setContractSignStatus(BrandCampaignGroupContractSignStatusEnum.NON_SIGN.getCode());
        // 支付方式-For测试
        List<Long> selfContractCreditMemberIds = selfServiceTestMemberConfig.getSelfContractCreditPayTypeMemberList();
        if (CollectionUtils.isNotEmpty(selfContractCreditMemberIds) && selfContractCreditMemberIds.contains(serviceContext.getMemberId())
                && checkMemberEnableCredit(serviceContext, campaignGroupViewDTO)) {
            campaignGroupContractViewDTO.setContractPayType(BrandCampaignGroupContractPayTypeEnum.POST_PAID.getCode());
        } else {
            campaignGroupContractViewDTO.setContractPayType(BrandCampaignGroupContractPayTypeEnum.PRE_PAID.getCode());
        }

        campaignGroupViewDTO.setCampaignGroupContractViewDTO(campaignGroupContractViewDTO);
        return null;
    }

    private boolean checkMemberEnableCredit(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO) {
        if (campaignGroupViewDTO.getCampaignGroupCustomerViewDTO() != null
                && campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getContractMemberType() != null
                && campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getCustomerMemberId() != null) {

            CampaignGroupCustomerMemberViewDTO customerMemberViewDTO = new CampaignGroupCustomerMemberViewDTO();
            customerMemberViewDTO.setMemberId(context.getMemberId());
            customerMemberViewDTO.setMemberType(campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getContractMemberType());
            customerMemberViewDTO.setCustomerMemberId(campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getCustomerMemberId());
            return salesContractRepository.checkMemberEnableCredit(context, customerMemberViewDTO);
        }
        return false;
    }
}
