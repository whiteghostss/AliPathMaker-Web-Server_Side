package com.taobao.ad.brand.bp.domain.creative.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeRepository;
import com.taobao.ad.brand.bp.domain.dooh.repository.DoohRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.IDoohCreativeBindForAdgroupUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.DoohCreativeBindForAdgroupUpdateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.util.List;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSelfDoohCreativeBindForAdgroupUpdateAbility implements IDoohCreativeBindForAdgroupUpdateAbility, BrandSelfServiceAtomAbilityRouter {

    private final DoohRepository doohRepository;
    private final CreativeRepository creativeRepository;
    @Override
    public Void handle(ServiceContext serviceContext, DoohCreativeBindForAdgroupUpdateAbilityParam abilityParam) {
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();
        AdgroupViewDTO adgroupViewDTO = abilityParam.getAdgroupViewDTO();
        List<CreativeViewDTO> creativeViewDTOList = abilityParam.getAbilityTargets();
        //天攻计划需要同步给天攻计划和创意的关联关系，单元如果已经是投中，不做创意的绑定更新
        if(BizCampaignToolsHelper.isDoohCampaign(campaignViewDTO.getCampaignResourceViewDTO().getSspProductLineId())
                && !(BrandDateUtil.isHistoryTime(adgroupViewDTO.getStartTime()))){
            for(CreativeViewDTO creativeViewDTO : creativeViewDTOList){
                try{
                    doohRepository.bindCreativeWithCampaignId(campaignViewDTO.getCampaignDoohViewDTO().getDoohCampaignId(), creativeViewDTO.getId());
                }catch (Exception e){
                    //天攻创意绑定失败，百灵的单元和创意需要解绑
                    creativeRepository.unBindCreative(serviceContext, Lists.newArrayList(adgroupViewDTO.getId()), Lists.newArrayList(creativeViewDTO.getId()));
                    throw new BrandOneBPException("天攻计划绑定单元失败："+ e.getMessage());
                }
            }
        }
        return null;
    }

}
