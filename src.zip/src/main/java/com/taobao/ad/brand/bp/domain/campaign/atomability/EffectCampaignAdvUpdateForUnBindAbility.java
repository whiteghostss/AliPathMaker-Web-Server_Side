package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.nb.direct.client.constant.advertiser.DirectAdvertiserSettingKeyEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.domain.effect.EffectAdvertiserRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.EffectAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignAdvUpdateForUnBindAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignAdvUpdateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EffectCampaignAdvUpdateForUnBindAbility implements ICampaignAdvUpdateForUnBindAbility, EffectAtomAbilityRouter {

    private final EffectAdvertiserRepository effectAdvertiserRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignAdvUpdateAbilityParam abilityParam) {
        List<CampaignViewDTO> subCampaignViewDTOList = abilityParam.getAbilityTargets();
        if (CollectionUtils.isEmpty(subCampaignViewDTOList)) {
            return null;
        }
        List<Long> advIds = abilityParam.getAdvIds();

        List<String> settingKeys = Lists.newArrayList(DirectAdvertiserSettingKeyEnum.BRAND_ONEBP_CAMPAIGN_ID.getKey(),
                DirectAdvertiserSettingKeyEnum.BRAND_ONEBP_SUB_CAMPAIGN_ID.getKey(),
                DirectAdvertiserSettingKeyEnum.EFFECT_AGENCY_CUSTOM_MEMBER_ID.getKey());

        for (CampaignViewDTO subCampaign : subCampaignViewDTOList) {
            if (subCampaign.getCampaignEffectProxyViewDTO() == null || subCampaign.getCampaignEffectProxyViewDTO().getEffectAdvId() == null) {
                continue;
            }
            Long campaignAdvId = subCampaign.getCampaignEffectProxyViewDTO().getEffectAdvId();
            if (!advIds.contains(campaignAdvId)) {
                continue;
            }
            effectAdvertiserRepository.deleteAdvertiserSetting(serviceContext, campaignAdvId, settingKeys);
        }

        return null;
    }
}
