package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Optional;

@Component
@BusinessAbility
public class SelfServiceCampaignAddAbility extends DefaultCampaignAddAbility implements SelfServiceAtomAbilityRouter {
    @Resource
    private CampaignRepository campaignRepository;

    public Long addCampaign(ServiceContext serviceContext, Long campaignGroupId, CampaignViewDTO campaignViewDTO) {
        try {
            //计划保存
            campaignRepository.addCampaign(serviceContext, Lists.newArrayList(campaignViewDTO));
            if(CollectionUtils.isNotEmpty(campaignViewDTO.getCampaignTargetScenarioViewDTO().getCampaignAdzoneViewDTOList())){
                campaignRepository.addCampaignAdzone(serviceContext, Lists.newArrayList(campaignViewDTO));
            }
        } catch (Exception e) {
            RogerLogger.error(String.format("计划保存异常，计划=%s", JSON.toJSONString(campaignViewDTO)),e);
            Long needDelCampaignId = Optional.ofNullable(campaignViewDTO).map(CampaignViewDTO::getId).orElse(null);
            if(needDelCampaignId != null){
                campaignRepository.physicsDelCampaign(serviceContext,campaignViewDTO);
                campaignViewDTO.setId(null);//清空计划id
            }
            throw new BrandOneBPException("计划保存异常",e);
        }
        return campaignViewDTO.getId();
    }


}
