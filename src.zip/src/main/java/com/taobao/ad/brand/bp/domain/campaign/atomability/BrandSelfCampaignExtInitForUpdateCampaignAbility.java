package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.ext.CampaignExtViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignExtInitForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignExtAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSelfCampaignExtInitForUpdateCampaignAbility implements ICampaignExtInitForUpdateCampaignAbility, BrandSelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignExtAbilityParam abilityParam) {
        CampaignExtViewDTO campaignExtViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        CampaignExtViewDTO dbCampaignExtViewDTO = Optional.ofNullable(dbCampaignViewDTO.getCampaignExtViewDTO()).orElse(new CampaignExtViewDTO());
        AssertUtil.notNull(campaignExtViewDTO,"计划扩展属性不能为空");
        //补充ext的db信息
        if (campaignExtViewDTO.getPartitionStrategy() == null && dbCampaignExtViewDTO.getPartitionStrategy() != null) {
            campaignExtViewDTO.setPartitionStrategy(dbCampaignExtViewDTO.getPartitionStrategy());
        }
        if (campaignExtViewDTO.getSubSplitCode() == null && dbCampaignExtViewDTO.getSubSplitCode() != null) {
            campaignExtViewDTO.setSubSplitCode(dbCampaignExtViewDTO.getSubSplitCode());
        }
        if (campaignExtViewDTO.getIntelligentStrategyId() == null && dbCampaignExtViewDTO.getIntelligentStrategyId() != null) {
            campaignExtViewDTO.setIntelligentStrategyId(dbCampaignExtViewDTO.getIntelligentStrategyId());
        }
        return null;
    }
}
