package com.taobao.ad.brand.bp.domain.cart.repository;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.cartitem.query.CartItemQueryViewDTO;

import java.util.List;

/**
 * 加购行相关服务
 * @author shiyan
 * @date 2024/6/26
 **/
public interface CartItemRepository {
    /**
     * 查询加购行列表
     * @param serviceContext
     * @param cartItemQueryViewDTO
     * @return
     */
    List<CartItemViewDTO> findCartList(ServiceContext serviceContext, CartItemQueryViewDTO cartItemQueryViewDTO);

    /**
     * 分页查询加购行列表
     * @param serviceContext
     * @param cartItemQueryViewDTO
     * @return
     */
    PageResultViewDTO<CartItemViewDTO> findCartPage(ServiceContext serviceContext, CartItemQueryViewDTO cartItemQueryViewDTO);

    /**
     * 查询加购行详情
     * @param serviceContext
     * @param id
     * @return
     */
    CartItemViewDTO getCartById(ServiceContext serviceContext, Long id);
    /**
     * 新增加购行
     * @param serviceContext
     * @param cartDTO
     * @return
     */
    Long addCart(ServiceContext serviceContext, CartItemViewDTO cartDTO);
    /**
     * 根据id物理删除加购行
     * @param serviceContext
     * @param ids  (主键id)
     * @return
     */
    Integer physicsDeleteCartItem(ServiceContext serviceContext, List<Long> ids);

    /**
     * 逻辑删除加购行
     * @param serviceContext
     * @param ids (主键id)
     * @return
     */
    Integer deleteCartItem(ServiceContext serviceContext, List<Long> ids);

    /**
     * 批量更新加购行状态
     * @param serviceContext
     * @param ids
     * @param status
     * @return
     */
    Integer batchUpdateCartStatus(ServiceContext serviceContext, List<Long> ids,Integer status);

    /**
     * 全量覆盖更新加购行
     * @param serviceContext
     * @param cartDTO
     * @return
     */
    Integer updateCartAll(ServiceContext serviceContext, CartItemViewDTO cartDTO);

    /**
     * 部分更新加购行
     * @param serviceContext
     * @param cartDTO
     * @return
     */
    Integer updateCartPart(ServiceContext serviceContext, CartItemViewDTO cartDTO);
}
