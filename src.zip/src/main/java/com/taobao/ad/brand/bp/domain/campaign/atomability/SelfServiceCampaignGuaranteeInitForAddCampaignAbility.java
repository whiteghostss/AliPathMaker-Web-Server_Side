package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.biz.definition.constants.UniversalCampaignModel;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.guarantee.CampaignGuaranteeViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignUnionControlFlowEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.product.CastTypeEnum;
import com.alibaba.ad.nb.ssp.constant.common.MediaScopeEnum;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignGuaranteeInitForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignGuaranteeAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Set;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCampaignGuaranteeInitForAddCampaignAbility implements ICampaignGuaranteeInitForAddCampaignAbility, SelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGuaranteeAbilityParam abilityParam) {
        CampaignGuaranteeViewDTO campaignGuaranteeViewDTO = abilityParam.getAbilityTarget();
        ProductViewDTO productViewDTO = abilityParam.getProductViewDTO();
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();
        ResourcePackageProductViewDTO packageProductViewDTO = abilityParam.getResourcePackageProductViewDTO();
        AssertUtil.notNull(campaignGuaranteeViewDTO, "计划保量信息不能为空");
        AssertUtil.notNull(productViewDTO, "产品不能为空");
        AssertUtil.notNull(campaignViewDTO, "计划不能为空");
        AssertUtil.notNull(packageProductViewDTO, "资源产品不能为空");
        // 预定单位
        campaignGuaranteeViewDTO.setSspRegisterUnit(productViewDTO.getRegisterUnit() == null ? productViewDTO.getSellUnit() : productViewDTO.getRegisterUnit());
        // 控量方式
        campaignGuaranteeViewDTO.setSspControlFlow(productViewDTO.getTrafficControlType());
        // 是否联合控量 不联合
        campaignGuaranteeViewDTO.setIsUnionControlFlow(BrandCampaignUnionControlFlowEnum.ANTI_UNION.getCode());
        // 保量方式
        Integer castType = BizCampaignToolsHelper.getCampaignCastType(campaignViewDTO, packageProductViewDTO);
        //兼容资源包逻辑
        if(MediaScopeEnum.CROSS_SCOPE.getCode().equals(productViewDTO.getMediaScope())){
            castType = CastTypeEnum.GUARANTEE.getValue();
        }
        campaignGuaranteeViewDTO.setSspRegisterManner(castType);
        //跨域一级计划默认需要结算控量 否则其他都在二级计划上控量
        if(UniversalCampaignModel.TAO_CROSS_GD.getId() == campaignViewDTO.getCampaignModel()){
            campaignGuaranteeViewDTO.setIsSettleControl(BrandBoolEnum.BRAND_TRUE.getCode());
        } else if (UniversalCampaignModel.TAO_CROSS_TX_SHOWMAX_PACKAGE.getId() == campaignViewDTO.getCampaignModel()) {
            campaignGuaranteeViewDTO.setIsSettleControl(BrandBoolEnum.BRAND_TRUE.getCode());
        }  else if (UniversalCampaignModel.TAO_CROSS_BLACK.getId() == campaignViewDTO.getCampaignModel()) {
            campaignGuaranteeViewDTO.setIsSettleControl(BrandBoolEnum.BRAND_FALSE.getCode());
        } else if(BizCampaignToolsHelper.isTXorShowmaxCampaign(productViewDTO.getMediaScope(), productViewDTO.getProductLineId())) {
            if(CollectionUtils.isNotEmpty(packageProductViewDTO.getBandPriceList())){
                Set<Long> prices = packageProductViewDTO.getBandPriceList().stream()
                        .map(ResourcePackageProductPriceViewDTO::getPrice).collect(Collectors.toSet());
                //如果只存在一个价格波段
                if(prices.size() == 1){
                    campaignGuaranteeViewDTO.setIsSettleControl(BrandBoolEnum.BRAND_TRUE.getCode());
                }else{
                    campaignGuaranteeViewDTO.setIsSettleControl(BrandBoolEnum.BRAND_FALSE.getCode());
                }
            }
        }else{
            campaignGuaranteeViewDTO.setIsSettleControl(BrandBoolEnum.BRAND_FALSE.getCode());
        }
        return null;
    }
}
