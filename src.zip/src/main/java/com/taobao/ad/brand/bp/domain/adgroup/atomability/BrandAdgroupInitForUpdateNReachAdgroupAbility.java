package com.taobao.ad.brand.bp.domain.adgroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupInitForUpdateNReachAdgroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupInitForUpdateNReachAdgroupAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
public class BrandAdgroupInitForUpdateNReachAdgroupAbility
        implements IAdgroupInitForUpdateNReachAdgroupAbility, BrandSelfServiceAtomAbilityRouter {
    @Override
    public Void handle(ServiceContext context, AdgroupInitForUpdateNReachAdgroupAbilityParam abilityParam) {
        AdgroupViewDTO adgroupViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();
        adgroupViewDTO.setStartTime(campaignViewDTO.getStartTime());
        adgroupViewDTO.setEndTime(campaignViewDTO.getEndTime());
        return null;
    }
}
