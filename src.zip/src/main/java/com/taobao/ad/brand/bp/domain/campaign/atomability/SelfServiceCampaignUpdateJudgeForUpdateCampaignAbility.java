package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignUpdateJudgeForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignUpdateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_ILLEGAL;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCampaignUpdateJudgeForUpdateCampaignAbility implements ICampaignUpdateJudgeForUpdateCampaignAbility, SelfServiceAtomAbilityRouter {

    @Override
    public Boolean handle(ServiceContext serviceContext, CampaignUpdateAbilityParam abilityParam) {
        CampaignViewDTO campaignViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        AssertUtil.notNull(campaignViewDTO,"计划不允许为空");
        AssertUtil.notNull(dbCampaignViewDTO,"计划不存在");

        //自助情况只看主计划
        // 【状态】不允许修改状态设置：主计划、子计划如果处于询量中、锁量中、释量中、待投放、投放中、投放结束、投放暂停，不允许修改
        boolean canUpdateByStatus = Boolean.TRUE;
        BrandCampaignStatusEnum campaignStatusEnum = BrandCampaignStatusEnum.getByCode(campaignViewDTO.getStatus());
        if(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode().equals(campaignViewDTO.getCampaignLevel())){
            if (BrandCampaignStatusEnum.INQUIRING == campaignStatusEnum || BrandCampaignStatusEnum.LOCKING == campaignStatusEnum  || BrandCampaignStatusEnum.RELEASING == campaignStatusEnum
                    || BrandCampaignStatusEnum.WAITING == campaignStatusEnum
                    || BrandCampaignStatusEnum.CASTING == campaignStatusEnum || BrandCampaignStatusEnum.PAUSING == campaignStatusEnum
                    || BrandCampaignStatusEnum.ENDING == campaignStatusEnum) {
                canUpdateByStatus = Boolean.FALSE;
            }
        }else {
            if (BrandCampaignStatusEnum.INQUIRING == campaignStatusEnum || BrandCampaignStatusEnum.LOCKING == campaignStatusEnum  || BrandCampaignStatusEnum.RELEASING == campaignStatusEnum
                    || BrandCampaignStatusEnum.WAITING == campaignStatusEnum || BrandCampaignStatusEnum.CASTING == campaignStatusEnum || BrandCampaignStatusEnum.PAUSING == campaignStatusEnum|| BrandCampaignStatusEnum.ENDING == campaignStatusEnum
            ) {
                canUpdateByStatus = Boolean.FALSE;
            }
        }
        if (!canUpdateByStatus) {
            // 【日期】询量中、锁量中、释量中、待投放、投放中、投放结束、投放暂停，不允许修改，不允许修改
            AssertUtil.assertTrue(dbCampaignViewDTO.getStartTime().equals(campaignViewDTO.getStartTime())
                    , PARAM_ILLEGAL, "锁量中、锁量成功、待投放、投放中、投放结束、投放暂停状态的计划，日期不允许修改");
            AssertUtil.assertTrue(dbCampaignViewDTO.getEndTime().equals(campaignViewDTO.getEndTime())
                    , PARAM_ILLEGAL, "锁量中、锁量成功、待投放、投放中、投放结束、投放暂停状态的计划，日期不允许修改");
        }
        return canUpdateByStatus;
    }
}
