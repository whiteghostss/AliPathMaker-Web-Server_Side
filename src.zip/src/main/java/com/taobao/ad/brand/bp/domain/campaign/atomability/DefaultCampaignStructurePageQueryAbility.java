package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructurePageQueryAbility;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
@BusinessAbility
public class DefaultCampaignStructurePageQueryAbility implements ICampaignStructurePageQueryAbility {
    @Resource
    private CampaignRepository campaignRepository;
    @Resource
    private DefaultCampaignStructureQueryAbility defaultCampaignStructureQueryAbility;

    @Override
    public PageResultViewDTO<CampaignViewDTO> handle(ServiceContext context, CampaignStructureQueryAbilityParam abilityParam) {
        CampaignQueryViewDTO query = abilityParam.getAbilityTarget();
        CampaignQueryOption option = abilityParam.getQueryOption();
        //查询计划
        PageResultViewDTO<CampaignViewDTO> pageResultViewDTO = campaignRepository.queryCampaignPageList(context, query);
        if (CollectionUtils.isEmpty(pageResultViewDTO.getList())) {
            return pageResultViewDTO;
        }
        defaultCampaignStructureQueryAbility.processCampaignInfo(context, pageResultViewDTO.getList(), option);
        return pageResultViewDTO;
    }
}
