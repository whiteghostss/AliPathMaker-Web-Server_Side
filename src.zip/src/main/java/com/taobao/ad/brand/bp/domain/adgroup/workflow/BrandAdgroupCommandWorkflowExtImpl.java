package com.taobao.ad.brand.bp.domain.adgroup.workflow;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.adgroup.CreativeRefViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.common.BottomDateViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupWakeupTypeEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativePackageTypeEnum;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativeShowAuditStatusEnum;
import com.alibaba.hermes.framework.event.SimpleEventEngine;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.context.AdgroupWakeUpUpdateContext;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignTemplateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeQueryOptionViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.adgroup.repository.AdgroupRepository;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeRepository;
import com.taobao.ad.brand.bp.domain.event.adgroup.AdgroupWakeUpUpdateEvent;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.ability.param.BizAdgroupAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.*;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.*;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.workflow.param.BizAdgroupBindWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.workflow.param.BizAdgroupDirectCreativeGenerateWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.workflow.param.BizAdgroupWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.workflow.param.BrandAdgroupWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.base.workflow.router.BrandSelfServiceExtensionRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.IDoohCreativeBindForAdgroupUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.IDoohCreativeInitForAdgroupUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.DoohCreativeBindForAdgroupUpdateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.DoohCreativeInitForAdgroupUpdateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.query.ICreativeStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.ssp.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_ILLEGAL;
import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_REQUIRED;

/**
 * Description:
 * <p>
 * date: 2023/10/24 2:51 PM
 *
 * @author shiyan
 * @version 1.0
 */
@Service
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandAdgroupCommandWorkflowExtImpl extends DefaultAdgroupCommandWorkflowExtImpl implements BrandSelfServiceExtensionRouter {

    private final CampaignGroupRepository campaignGroupRepository;
    private final ResourcePackageRepository resourcePackageRepository;
    private final CampaignRepository campaignRepository;
    private final AdgroupRepository adgroupRepository;
    private final CreativeRepository creativeRepository;
    private final ProductRepository productRepository;
    private final ICampaignStructureQueryAbility campaignStructureQueryAbility;

    private final IAdgroupBaseInfoInitForAddOrUpdateAbility adgroupBaseInfoInitForAddOrUpdateAbility;
    private final IAdgroupWakeUpInitAbility adgroupWakeUpInitAbility;
    private final IAdgroupInitForUpdateAbility adgroupInitForUpdateAbility;
    private final IDoohCreativeInitForAdgroupUpdateAbility doohCreativeInitForAdgroupUpdateAbility;
    private final IAdgroupStatusOnlineValidateForAddOrUpdateAbility adgroupStatusOnlineValidateForAddOrUpdateAbility;
    private final IAdgroupCountValidateForAddOrUpdateAbility adgroupCountValidateForAddOrUpdateAbility;
    private final IAdgroupCreateRuleValidateForAddOrUpdateAbility adgroupCreateRuleValidateForAddOrUpdateAbility;
    private final IAdgroupTitleValidateAbility adgroupTitleValidateAbility;
    private final IAdgroupWakeUpValidateForUpdateAbility adgroupWakeUpValidateForUpdateAbility;
    private final IDoohCreativeBindForAdgroupUpdateAbility doohCreativeBindForAdgroupUpdateAbility;
    private final SimpleEventEngine simpleEventEngine;
    private final ICreativeStructureQueryAbility creativeStructureQueryAbility;
    private final IAdgroupWakeUpValidateForAddAbility adgroupWakeUpValidateForAddAbility;

    private static final List<Integer> validWakeupTypeList = Lists.newArrayList(
        BrandCampaignGroupWakeupTypeEnum.NON_WAKEUP.getCode(),
        BrandCampaignGroupWakeupTypeEnum.SINGLE_WAKEUP.getCode());

    @Override
    public Void beforeAdgroupUpdate(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO,
                                    BizAdgroupWorkflowParam paramDefinition) {
        this.initForUpdate(serviceContext,adgroupViewDTO,paramDefinition);
        this.validateForUpdate(serviceContext,adgroupViewDTO,paramDefinition);
        return null;
    }

    @Override
    public Void beforeAdgroupAdd(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO,
                                 BizAdgroupWorkflowParam paramDefinition) {
        this.initForAdd(serviceContext,adgroupViewDTO,paramDefinition);
        this.validateForAdd(serviceContext,adgroupViewDTO,paramDefinition);
        return null;
    }


    private Void initForAdd(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO,
                           BizAdgroupWorkflowParam paramDefinition) {
        BrandAdgroupWorkflowParam brandAdgroupWorkflowParam = (BrandAdgroupWorkflowParam)paramDefinition;
        BizAdgroupAbilityParam bizAdgroupAbilityParam = BizAdgroupAbilityParam.builder()
                .dbAdgroupViewDTO(brandAdgroupWorkflowParam.getDbAdgroupViewDTO())
                .campaignViewDTO(brandAdgroupWorkflowParam.getCampaignViewDTO())
                .creativeViewDTOList(brandAdgroupWorkflowParam.getCreativeViewDTOList())
                .bottomDateViewDTOList(brandAdgroupWorkflowParam.getBottomDateViewDTOList())
                .campaignGroupViewDTO(brandAdgroupWorkflowParam.getCampaignGroupViewDTO())
                .packageSaleGroupViewDTO(brandAdgroupWorkflowParam.getPackageSaleGroupViewDTO())
                .build();
       // bizAdgroupAbility.initAddDefaultProperty(serviceContext,adgroupViewDTO,bizAdgroupAbilityParam);
        //初始化信息
        adgroupBaseInfoInitForAddOrUpdateAbility.handle(serviceContext, AdgroupBaseInfoInitForAddOrUpdateAbilityParam.builder().abilityTarget(adgroupViewDTO).campaignViewDTO(bizAdgroupAbilityParam.getCampaignViewDTO()).build());
        //初始化唤端信息
        adgroupWakeUpInitAbility.handle(serviceContext, AdgroupWakeUpInitAbilityParam.builder().abilityTarget(adgroupViewDTO.getWakeupViewDTO()).build());
        return null;
    }

    @Override
    public BizAdgroupWorkflowParam buildParamForAddOrUpdate(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO) {
        BrandAdgroupWorkflowParam bizAdgroupWorkflowParam = new BrandAdgroupWorkflowParam();

        AssertUtil.notNull(adgroupViewDTO.getCampaignId(),"计划id不能为空");
        CampaignViewDTO campaignViewDTO = this.getCampaignInfoByOption(serviceContext,adgroupViewDTO.getCampaignId(), CampaignQueryOption.builder().needChildren(true).needTarget(true).build());
        AssertUtil.notNull(campaignViewDTO,"计划不能为空");
        bizAdgroupWorkflowParam.setCampaignViewDTO(campaignViewDTO);

        AssertUtil.notNull(campaignViewDTO.getCampaignGroupId(),"订单id不能为空");
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(serviceContext, campaignViewDTO.getCampaignGroupId());
        AssertUtil.notNull(campaignGroupViewDTO,"订单不能为空");
        bizAdgroupWorkflowParam.setCampaignGroupViewDTO(campaignGroupViewDTO);

        ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO = resourcePackageRepository.getSaleGroupById(serviceContext
            , campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId()
            , ResourcePackageQueryOption.builder().needInquiryPriority(false).needProduct(false).needSetting(true).build());
        bizAdgroupWorkflowParam.setPackageSaleGroupViewDTO(resourcePackageSaleGroupViewDTO);

        ResourcePackageProductViewDTO resourcePackageProductViewDTO = resourcePackageRepository.getResourcePackageSspProduct(serviceContext, campaignViewDTO.getCampaignSaleViewDTO().getResourcePackageProductId());
        AssertUtil.notNull(resourcePackageProductViewDTO, "售卖二级产品不存在");
        bizAdgroupWorkflowParam.setResourcePackageProductViewDTO(resourcePackageProductViewDTO);

        ProductViewDTO productViewDTO = productRepository.getProductById(campaignViewDTO.getCampaignResourceViewDTO().getSspProductId());
        AssertUtil.notNull(productViewDTO, "二级产品不存在");
        bizAdgroupWorkflowParam.setProductViewDTO(productViewDTO);

        if(Objects.nonNull(adgroupViewDTO.getId())){
            AdgroupViewDTO dbAdgroupViewDTO =adgroupRepository.getAdgroupById(serviceContext,adgroupViewDTO.getId());
            AssertUtil.notNull(dbAdgroupViewDTO,"单元不存在");
            bizAdgroupWorkflowParam.setDbAdgroupViewDTO(dbAdgroupViewDTO);
        }

        if (CollectionUtils.isNotEmpty(adgroupViewDTO.getCreativeRefViewDTOList())){
            List<Long> creativeIds = adgroupViewDTO.getCreativeRefViewDTOList().stream().map(CreativeRefViewDTO::getCreativeId).collect(Collectors.toList());
            List<CreativeViewDTO> creativeViewDTOList =  creativeRepository.findCreativeByIds(serviceContext,creativeIds);
            if(CollectionUtils.isNotEmpty(creativeViewDTOList)){
                bizAdgroupWorkflowParam.setCreativeViewDTOList(creativeViewDTOList);
            }
        }

        if(CollectionUtils.isNotEmpty(campaignViewDTO.getSubCampaignViewDTOList())){
            List<BottomDateViewDTO>  bottomDateViewDTOList =  campaignRepository.getCampaignBottomDateList(serviceContext,campaignViewDTO.getSubCampaignViewDTOList()
                .stream()
                .filter(item->Objects.nonNull(item.getId()))
                .map(item->item.getId()).collect(
                Collectors.toList()));
            if(CollectionUtils.isNotEmpty(bottomDateViewDTOList)){
                bizAdgroupWorkflowParam.setBottomDateViewDTOList(bottomDateViewDTOList);
            }
        }

        return bizAdgroupWorkflowParam;
    }


    @Override
    public BizAdgroupBindWorkflowParam buildParamForAdgroupBind(ServiceContext serviceContext,
                                                                AdgroupViewDTO adgroupViewDTO) {
        BizAdgroupBindWorkflowParam bizAdgroupBindWorkflowParam = new BizAdgroupBindWorkflowParam();

        AssertUtil.notNull(adgroupViewDTO.getCampaignId(),"计划id不能为空");
        CampaignViewDTO campaignViewDTO = this.getCampaignInfoByOption(serviceContext,adgroupViewDTO.getCampaignId(), CampaignQueryOption.builder().needChildren(true).needTarget(true).build());
        AssertUtil.notNull(campaignViewDTO,"计划不能为空");
        bizAdgroupBindWorkflowParam.setCampaignViewDTO(campaignViewDTO);

        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(serviceContext, campaignViewDTO.getCampaignGroupId());
        AssertUtil.notNull(campaignGroupViewDTO,"订单不能为空");
        bizAdgroupBindWorkflowParam.setCampaignGroupViewDTO(campaignGroupViewDTO);

        if (CollectionUtils.isNotEmpty(adgroupViewDTO.getCreativeRefViewDTOList())){
            List<Long> creativeIds = adgroupViewDTO.getCreativeRefViewDTOList().stream().map(CreativeRefViewDTO::getCreativeId).collect(Collectors.toList());
            List<CreativeViewDTO> creativeViewDTOList =  creativeRepository.findCreativeByIds(serviceContext,creativeIds);
            if(CollectionUtils.isNotEmpty(creativeViewDTOList)){
                bizAdgroupBindWorkflowParam.setCreativeViewDTOList(creativeViewDTOList);
            }
        }

        if(CollectionUtils.isNotEmpty(campaignViewDTO.getSubCampaignViewDTOList())){
            List<BottomDateViewDTO>  bottomDateViewDTOList =  campaignRepository.getCampaignBottomDateList(serviceContext,campaignViewDTO.getSubCampaignViewDTOList()
                .stream()
                .filter(item->Objects.nonNull(item.getId()))
                .map(item->item.getId()).collect(
                    Collectors.toList()));
            if(CollectionUtils.isNotEmpty(bottomDateViewDTOList)){
                bizAdgroupBindWorkflowParam.setBottomDateViewDTOList(bottomDateViewDTOList);
            }
        }

        return bizAdgroupBindWorkflowParam;
    }
    private Void validateForAdd(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO,
                               BizAdgroupWorkflowParam paramDefinition) {

        validateAddOrUpdateBaseParam(serviceContext,adgroupViewDTO,paramDefinition.getCampaignViewDTO());
        //单元创建规则校验（订单、计划状态）
        adgroupCreateRuleValidateForAddOrUpdateAbility.handle(serviceContext, AdgroupCreateRuleValidateForAddOrUpdateAbilityParam.builder().abilityTarget(adgroupViewDTO).campaignViewDTO(paramDefinition.getCampaignViewDTO()).campaignGroupViewDTO(paramDefinition.getCampaignGroupViewDTO()).build());
        //标题校验
        adgroupTitleValidateAbility.handle(serviceContext,AdgroupTitleValidateAbilityParam.builder().abilityTarget(adgroupViewDTO).build());
        //单元数量校验
        adgroupCountValidateForAddOrUpdateAbility.handle(serviceContext, AdgroupCountValidateForAddOrUpdateAbilityParam.builder().abilityTarget(adgroupViewDTO).campaignViewDTO(paramDefinition.getCampaignViewDTO()).build());
        //正式单元保存校验
        adgroupStatusOnlineValidateForAddOrUpdateAbility.handle(serviceContext,AdgroupStatusOnlineValidateForAddOrUpdateAbilityParam.builder().abilityTarget(adgroupViewDTO).campaignViewDTO(paramDefinition.getCampaignViewDTO()).build());

        return null;
    }

    /**
     * dagroup基础校验
     * 不包含人群 创意校验
     */
    private void validateAddOrUpdateBaseParam(ServiceContext context, AdgroupViewDTO adgroupViewDTO,CampaignViewDTO campaignViewDTO) {
        AssertUtil.notNull(adgroupViewDTO, PARAM_REQUIRED, "单元信息为空");
        AssertUtil.notNull(adgroupViewDTO.getCampaignId(), PARAM_REQUIRED, "所属计划ID不能为空");
        AssertUtil.assertTrue(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode().equals(campaignViewDTO.getCampaignLevel()), PARAM_REQUIRED, "计划不存在，请检查后重试");

        AssertUtil.notNull(adgroupViewDTO.getPriority(), PARAM_REQUIRED, "单元优先级不能为空");
        AssertUtil.notNull(adgroupViewDTO.getWeight(), PARAM_REQUIRED, "单元权重不能为空");
        AssertUtil.notNull(adgroupViewDTO.getBottomType(), PARAM_REQUIRED, "打底类型不能为空");

        //单元流量权重
        if(adgroupViewDTO.getWeight() != null && adgroupViewDTO.getWeight() != 0){
            AssertUtil.assertTrue(adgroupViewDTO.getWeight() > 0 && adgroupViewDTO.getWeight() <= 100, "流量分配权重只能是1到100整数");
        }
        AssertUtil.notNull(adgroupViewDTO.getStartTime(), PARAM_REQUIRED, "开始时间不能为空");
        AssertUtil.notNull(adgroupViewDTO.getEndTime(), PARAM_REQUIRED, "结束时间不能为空");

        AssertUtil.assertTrue(BrandDateUtil.isBeforeAndEqual(adgroupViewDTO.getStartTime(), BrandDateUtil.getMaxDate(adgroupViewDTO.getEndTime())), PARAM_ILLEGAL, "计划开始时间小于等于结束时间");

        // 唤端校验
        adgroupWakeUpValidateForAddAbility.handle(context,AdgroupWakeUpValidateForAddAbilityParam.builder()
                .abilityTarget(adgroupViewDTO.getWakeupViewDTO()).build());
    }

    private Void initForUpdate(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO,
                              BizAdgroupWorkflowParam paramDefinition) {
        BrandAdgroupWorkflowParam brandAdgroupWorkflowParam = (BrandAdgroupWorkflowParam)paramDefinition;
        BizAdgroupAbilityParam bizAdgroupAbilityParam = BizAdgroupAbilityParam.builder()
                .dbAdgroupViewDTO(brandAdgroupWorkflowParam.getDbAdgroupViewDTO())
                .campaignViewDTO(brandAdgroupWorkflowParam.getCampaignViewDTO())
                .creativeViewDTOList(brandAdgroupWorkflowParam.getCreativeViewDTOList())
                .bottomDateViewDTOList(brandAdgroupWorkflowParam.getBottomDateViewDTOList())
                .campaignGroupViewDTO(brandAdgroupWorkflowParam.getCampaignGroupViewDTO())
                .packageSaleGroupViewDTO(brandAdgroupWorkflowParam.getPackageSaleGroupViewDTO())
                .build();
        //初始化基础信息信息
        adgroupBaseInfoInitForAddOrUpdateAbility.handle(serviceContext, AdgroupBaseInfoInitForAddOrUpdateAbilityParam.builder().abilityTarget(adgroupViewDTO).campaignViewDTO(bizAdgroupAbilityParam.getCampaignViewDTO()).build());
        //根据DB信息初始化单元信息
        adgroupInitForUpdateAbility.handle(serviceContext, AdgroupInitForUpdateAbilityParam.builder().abilityTarget(adgroupViewDTO).campaignViewDTO(bizAdgroupAbilityParam.getCampaignViewDTO()).dbAdgroupViewDTO(bizAdgroupAbilityParam.getDbAdgroupViewDTO()).build());
        //初始化唤端信息
        adgroupWakeUpInitAbility.handle(serviceContext, AdgroupWakeUpInitAbilityParam.builder().abilityTarget(adgroupViewDTO.getWakeupViewDTO()).build());
        //如果是天攻的计划需要初始化天攻创意
        if(BizCampaignToolsHelper.isDoohCampaign(brandAdgroupWorkflowParam.getCampaignViewDTO().getCampaignResourceViewDTO().getSspProductLineId())){
            doohCreativeInitForAdgroupUpdateAbility.handle(serviceContext, DoohCreativeInitForAdgroupUpdateAbilityParam.builder().abilityTargets(brandAdgroupWorkflowParam.getCreativeViewDTOList()).adgroupViewDTO(adgroupViewDTO).campaignViewDTO(brandAdgroupWorkflowParam.getCampaignViewDTO()).build());
        }
        return null;
    }

    private Void validateForUpdate(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO,
                                  BizAdgroupWorkflowParam paramDefinition) {

        validateAddOrUpdateBaseParam(serviceContext,adgroupViewDTO,paramDefinition.getCampaignViewDTO());

        //标题校验
        adgroupTitleValidateAbility.handle(serviceContext,AdgroupTitleValidateAbilityParam.builder().abilityTarget(adgroupViewDTO).build());
        //单元数量校验
        adgroupCountValidateForAddOrUpdateAbility.handle(serviceContext, AdgroupCountValidateForAddOrUpdateAbilityParam.builder()
                .abilityTarget(adgroupViewDTO).campaignViewDTO(paramDefinition.getCampaignViewDTO()).build());
        //正式单元保存校验
        adgroupStatusOnlineValidateForAddOrUpdateAbility.handle(serviceContext,AdgroupStatusOnlineValidateForAddOrUpdateAbilityParam.builder()
                .abilityTarget(adgroupViewDTO).campaignViewDTO(paramDefinition.getCampaignViewDTO()).build());
        //单元唤端校验
        adgroupWakeUpValidateForUpdateAbility.handle(serviceContext,AdgroupWakeUpValidateForUpdateAbilityParam.builder()
                .abilityTarget(adgroupViewDTO.getWakeupViewDTO()).dbAdgroupViewDTO(paramDefinition.getDbAdgroupViewDTO()).creativeViewDTOList(paramDefinition.getCreativeViewDTOList()).build());
        return null;
    }

    @Override
    public Void afterAdgroupUpdate(ServiceContext context, AdgroupViewDTO adgroupViewDTO, BizAdgroupAbilityParam bizAdgroupAbilityParam) {

        doohCreativeBindForAdgroupUpdateAbility.handle(context, DoohCreativeBindForAdgroupUpdateAbilityParam.builder().abilityTargets(bizAdgroupAbilityParam.getCreativeViewDTOList()).adgroupViewDTO(adgroupViewDTO).campaignViewDTO(bizAdgroupAbilityParam.getCampaignViewDTO()).build());

        //通知创意更新唤端信息
        AdgroupWakeUpUpdateContext adgroupWakeUpUpdateContext = AdgroupWakeUpUpdateContext.builder().adgroupViewDTO(adgroupViewDTO).build();
        simpleEventEngine.fire(AdgroupWakeUpUpdateEvent.of(adgroupWakeUpUpdateContext));
        return null;
    }

    @Override
    public Void beforeSetAdgroupOnline(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, BizAdgroupWorkflowParam workflowParam) {
        this.validateForUpdate(serviceContext,adgroupViewDTO,workflowParam);
        return null;
    }

    @Override
    public BizAdgroupDirectCreativeGenerateWorkflowParam buildParamForGenerateDirectCreative(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO) {
        //媒体直投创意生成业务规则校验
        CampaignViewDTO campaignTreeViewDTO = this.getCampaignInfoByOption(serviceContext, adgroupViewDTO.getCampaignId(), CampaignQueryOption.builder().needChildren(true).build());
        AssertUtil.notNull(campaignTreeViewDTO,String.format("计划不存在，id=%s",adgroupViewDTO.getCampaignId()));
        //一级创意是否审核通过
        List<Long> creativeIdList = adgroupViewDTO.getCreativeRefViewDTOList().stream().filter(creativeRefViewDTO -> BrandBoolEnum.BRAND_TRUE.getCode().equals(creativeRefViewDTO.getOnlineStatus()))
                .map(CreativeRefViewDTO::getCreativeId).distinct().collect(Collectors.toList());

        List<CreativeViewDTO> creativeViewDTOList = creativeStructureQueryAbility.handle(serviceContext, CreativeStructureQueryAbilityParam.builder().abilityTargets(creativeIdList)
                .queryOption(CreativeQueryOptionViewDTO.builder().needChildren(true).build()).build());
        List<CreativeViewDTO> canUserCreativeViewDTOList = Optional.ofNullable(creativeViewDTOList).orElse(Lists.newArrayList()).stream()
                .filter(creativeViewDTO -> Objects.equals(BrandCreativePackageTypeEnum.PACKAGE.getValue(), creativeViewDTO.getPackageType()))
                .filter(creativeViewDTO -> Objects.equals(BrandCreativeShowAuditStatusEnum.AUDIT_PASS.getCode(),
                        creativeViewDTO.getCreativeAudit().getShowAuditStatus()))
                .collect(Collectors.toList());

        AssertUtil.notEmpty(canUserCreativeViewDTOList, String.format("单元下无可用创意，不支持生成媒体直投创意，id=%s",adgroupViewDTO.getId()));

        List<CampaignTemplateViewDTO> campaignTemplateViewDTOList = campaignRepository.getCampaignTemplateIds(serviceContext, Lists.newArrayList(campaignTreeViewDTO));
        Map<Long, CampaignTemplateViewDTO> campaignTemplateMap = campaignTemplateViewDTOList.stream().collect(Collectors.toMap(CampaignTemplateViewDTO::getCampaignId, Function.identity()));

        return BizAdgroupDirectCreativeGenerateWorkflowParam.builder().adgroupViewDTO(adgroupViewDTO).campaignTreeViewDTO(campaignTreeViewDTO)
                .creativeViewDTOList(creativeViewDTOList).campaignTemplateMap(campaignTemplateMap).build();
    }

    /**
     * 获取计划信息
     * @param serviceContext
     * @param id
     * @param option
     * @return
     */
    private CampaignViewDTO getCampaignInfoByOption(ServiceContext serviceContext,Long id,CampaignQueryOption option){
        CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder().campaignIds(Collections.singletonList(id)).build();
        List<CampaignViewDTO> dbCampaignViewDTOList = campaignStructureQueryAbility.handle(serviceContext,
                CampaignStructureQueryAbilityParam.builder().abilityTarget(campaignQueryViewDTO).queryOption(option).build());
        return CollectionUtils.isNotEmpty(dbCampaignViewDTOList) ? dbCampaignViewDTOList.get(0) : null;
    }
}