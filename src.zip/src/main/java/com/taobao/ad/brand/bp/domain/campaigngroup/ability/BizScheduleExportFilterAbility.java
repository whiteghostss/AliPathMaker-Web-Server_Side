package com.taobao.ad.brand.bp.domain.campaigngroup.ability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.context.ScheduleExportContext;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.export.ComposeResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.export.FilterResultViewDTO;
import com.taobao.ad.brand.bp.common.spi.ExtensionPointsFactory;
import com.taobao.ad.brand.bp.domain.campaigngroup.spi.export.BizScheduleExportFilterSpi;
import org.springframework.stereotype.Service;


/**
 * @author jixiu.lj
 * @date 2023/3/29 15:33
 */
@Service
public class BizScheduleExportFilterAbility {

    /**
     * MR数据过滤
     *
     * @param scheduleExportContext
     * @param spiCode
     */
    public FilterResultViewDTO filter(ServiceContext serviceContext, ScheduleExportContext scheduleExportContext, ComposeResultViewDTO composeResultViewDTO, String spiCode) {
        return ExtensionPointsFactory.runAbilitySpi(BizScheduleExportFilterSpi.class, extension -> extension.filter(serviceContext, scheduleExportContext, composeResultViewDTO), spiCode, serviceContext.getBizCode());
    }

}
