package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.EffectAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignAdvUniqueValidateForBindAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignAdvValidateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EffectCampaignAdvUniqueValidateForBindAbility implements ICampaignAdvUniqueValidateForBindAbility, EffectAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignAdvValidateAbilityParam abilityParam) {
        List<CampaignViewDTO> subCampaignViewDTOList = abilityParam.getSubCampaignViewDTOList();
        if (CollectionUtils.isEmpty(subCampaignViewDTOList)) {
            return null;
        }

        List<Long> advIds = abilityParam.getAdvIds();
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();

        //同一时间段，只能有一个adv可以绑定
        List<CampaignViewDTO> needToCheckCampaignViewList = subCampaignViewDTOList.stream()
                .filter(item -> advIds.contains(item.getCampaignEffectProxyViewDTO().getEffectAdvId()))
                .collect(Collectors.toList());
        Date startDate = campaignViewDTO.getStartTime();
        Date endDate = campaignViewDTO.getEndTime();
        List<Long> unCanBindAdvIds = needToCheckCampaignViewList.stream()
                .filter(item->CollectionUtils.isNotEmpty(BrandDateUtil.getMixedDate(startDate,endDate,item.getStartTime(),item.getEndTime())))
                .map(item->item.getCampaignEffectProxyViewDTO().getEffectAdvId()).collect(Collectors.toList());
        AssertUtil.assertTrue(CollectionUtils.isEmpty(unCanBindAdvIds),"关联adv失败，\"%s\"在此周期内其他合同订单已经绑定", StringUtils.join(unCanBindAdvIds,","));

        // ADV未关联其他在投、待投的子合同的订单及其补量订单。即ADV历史关联的子合同订单投放周期均结束
        unCanBindAdvIds = needToCheckCampaignViewList.stream()
                .filter(repeatCampaign -> !new Date().after(repeatCampaign.getEndTime()))
                .map(item->item.getCampaignEffectProxyViewDTO().getEffectAdvId()).collect(Collectors.toList());
        AssertUtil.assertTrue(CollectionUtils.isEmpty(unCanBindAdvIds),"关联adv失败，\"%s\"已绑定其他待投、在投的计划", StringUtils.join(unCanBindAdvIds,","));

        return null;
    }
}
