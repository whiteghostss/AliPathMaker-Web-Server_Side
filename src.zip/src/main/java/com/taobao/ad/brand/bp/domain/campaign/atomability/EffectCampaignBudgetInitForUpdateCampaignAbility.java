package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.budget.CampaignBudgetViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.EffectAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignBudgetInitForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBudgetAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_REQUIRED;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EffectCampaignBudgetInitForUpdateCampaignAbility implements ICampaignBudgetInitForUpdateCampaignAbility, EffectAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignBudgetAbilityParam abilityParam) {
        CampaignBudgetViewDTO campaignBudgetViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        ResourcePackageProductViewDTO resourcePackageProductViewDTO = abilityParam.getResourcePackageProductViewDTO();
        AssertUtil.notNull(campaignBudgetViewDTO, PARAM_REQUIRED, "预算不能为空");
        AssertUtil.notNull(campaignViewDTO, PARAM_REQUIRED, "计划不能为空");
        AssertUtil.notNull(dbCampaignViewDTO, PARAM_REQUIRED, "计划不存在");
        AssertUtil.notNull(resourcePackageProductViewDTO, PARAM_REQUIRED, "售卖产品不存在");

        CampaignBudgetViewDTO dbCampaignBudgetViewDTO = Optional.ofNullable(dbCampaignViewDTO.getCampaignBudgetViewDTO()).orElse(new CampaignBudgetViewDTO());
        campaignBudgetViewDTO.setIsCustomResetBudget(dbCampaignBudgetViewDTO.getIsCustomResetBudget());
        campaignBudgetViewDTO.setBudgetRatio(dbCampaignBudgetViewDTO.getBudgetRatio());
        campaignBudgetViewDTO.setPublishTotalMoney(dbCampaignBudgetViewDTO.getPublishTotalMoney());
        campaignBudgetViewDTO.setDiscountTotalMoney(dbCampaignBudgetViewDTO.getDiscountTotalMoney());
        //预算信息
        List<ResourcePackageProductPriceViewDTO> bandPriceList = resourcePackageProductViewDTO.getBandPriceList();
        if(CollectionUtils.isNotEmpty(bandPriceList)){
            //内容没有多波段，只取一个
            ResourcePackageProductPriceViewDTO resourcePackageProductPriceViewDTO = bandPriceList.get(0);
            //折后总价
            campaignBudgetViewDTO.setDiscountTotalMoney(resourcePackageProductPriceViewDTO.getActualAmount());
            //预算比例，一个二级产品只有一个计划，比例默认100%
            campaignBudgetViewDTO.setBudgetRatio(Integer.parseInt(String.valueOf(Constant.RATIO_100)));
            //刊例总价，用刊例价*预定量
            Long publishTotalMoney = new BigDecimal(resourcePackageProductPriceViewDTO.getPublishPrice())
                    .multiply(new BigDecimal(resourcePackageProductPriceViewDTO.getBookingAmount())).longValue();
            campaignBudgetViewDTO.setPublishTotalMoney(publishTotalMoney);
        }
        return null;
    }
}
