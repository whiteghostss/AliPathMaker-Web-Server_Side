package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesBriefViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.SalesBriefStateEnum;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.SalesBriefRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupSyncBriefForFinishCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupTransitAbilityParam;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
@BusinessAbility
public class BrandOneBPCampaignGroupSyncBriefForFinishCampaignGroupAbility
        implements ICampaignGroupSyncBriefForFinishCampaignGroupAbility, BrandOneBPAtomAbilityRouter {

    @Resource
    private SalesBriefRepository salesBriefRepository;


    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupTransitAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();

        // 数据转换
        SalesBriefViewDTO salesBriefViewDTO = new SalesBriefViewDTO();
        salesBriefViewDTO.setBriefId(campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getBriefId());
        salesBriefViewDTO.setOrderId(campaignGroupViewDTO.getId());
        salesBriefViewDTO.setStatus(SalesBriefStateEnum.EXECUTE_FINISHED.getValue());
        // 同步信息至Brief
        salesBriefRepository.acceptStatusEvent(salesBriefViewDTO);
        return null;
    }

}
