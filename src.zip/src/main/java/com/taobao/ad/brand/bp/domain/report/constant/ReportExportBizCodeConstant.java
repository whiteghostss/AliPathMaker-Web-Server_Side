package com.taobao.ad.brand.bp.domain.report.constant;

/**
 * @author yuncheng.lyc
 */
public interface ReportExportBizCodeConstant {

    /**
     * 常规报表导出
     */
    String RPT_EXPORT_BASIC = "";



}
