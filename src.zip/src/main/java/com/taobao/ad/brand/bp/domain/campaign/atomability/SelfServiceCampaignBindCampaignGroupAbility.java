package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignBindCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBindCampaignGroupAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCampaignBindCampaignGroupAbility
        implements ICampaignBindCampaignGroupAbility, SelfServiceAtomAbilityRouter {

    private final CampaignRepository campaignRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignBindCampaignGroupAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        List<CampaignViewDTO> updateList = Lists.newArrayList();
        // 一级
        for (CampaignViewDTO campaignViewDTO : abilityParam.getAbilityTargets()) {
            CampaignViewDTO updateCampaign = buildUpdateCampaignViewDTO(campaignViewDTO, campaignGroupViewDTO);
            updateList.add(updateCampaign);
            // 二级
            if (CollectionUtils.isNotEmpty(campaignViewDTO.getSubCampaignViewDTOList())) {
                for (CampaignViewDTO subCampaign : campaignViewDTO.getSubCampaignViewDTOList()) {
                    CampaignViewDTO subUpdateCampaign = buildUpdateCampaignViewDTO(subCampaign, campaignGroupViewDTO);
                    updateList.add(subUpdateCampaign);
                }
            }
        }
        if (CollectionUtils.isNotEmpty(updateList)) {
            campaignRepository.updateCampaignPart(serviceContext, updateList);
        }
        return null;
    }

    private CampaignViewDTO buildUpdateCampaignViewDTO(CampaignViewDTO campaignViewDTO, CampaignGroupViewDTO subCampaignGroup) {
        campaignViewDTO.setCampaignGroupId(subCampaignGroup.getId());
        campaignViewDTO.setMainCampaignGroupId(subCampaignGroup.getParentId());

        CampaignViewDTO updateCampaign = new CampaignViewDTO();
        updateCampaign.setId(campaignViewDTO.getId());
        updateCampaign.setCampaignGroupId(subCampaignGroup.getId());
        updateCampaign.setMainCampaignGroupId(subCampaignGroup.getParentId());
        return updateCampaign;
    }
}
