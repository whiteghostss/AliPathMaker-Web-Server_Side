package com.taobao.ad.brand.bp.domain.tag;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.common.TagViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.tag.TagQueryViewDTO;

import java.util.List;

/**
 * @Author: PhilipFry
 * @createTime: 2024年02月27日 19:51:04
 * @Description:
 */
public interface TagRepository {
    /**
     * 新增标签
     *
     * @param serviceContext
     * @param tagViewDTO
     * @return
     */
    Long addTag(ServiceContext serviceContext, TagViewDTO tagViewDTO);

    /**
     * 更新标签
     *
     * @param serviceContext
     * @param tagViewDTO
     * @return
     */
    Integer updateTag(ServiceContext serviceContext, TagViewDTO tagViewDTO);

    /**
     * 删除标签
     *
     * @param serviceContext
     * @param tagId
     * @return
     */
    Integer deleteTag(ServiceContext serviceContext, Long tagId);


    /**
     * 分页查询标签列表
     *
     * @param serviceContext
     * @param queryViewDTO
     * @return
     */
    PageResultViewDTO<TagViewDTO> findTagPage(ServiceContext serviceContext, TagQueryViewDTO queryViewDTO);

    List<TagViewDTO> findTagByIds(ServiceContext serviceContext, List<Long> tagIds);
}
