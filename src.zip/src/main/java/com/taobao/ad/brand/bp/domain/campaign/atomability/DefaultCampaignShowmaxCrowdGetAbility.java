package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.customer.CampaignGroupCustomerViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.CrowdViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaign.RecommendCrowdTypeEnum;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.dmp.CrowdRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignShowmaxCrowdGetAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignShowmaxCrowdGetAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultCampaignShowmaxCrowdGetAbility implements ICampaignShowmaxCrowdGetAbility {

    private final CampaignGroupRepository campaignGroupRepository;
    private final CrowdRepository crowdRepository;

    @Override
    public CrowdViewDTO handle(ServiceContext serviceContext, CampaignShowmaxCrowdGetAbilityParam abilityParam) {
        Integer showmaxCrowdType = abilityParam.getAbilityTarget();
        Long campaignGroupId = abilityParam.getCampaignGroupId();
        List<Long> showmaxCrowdLabelIdList = abilityParam.getShowmaxCrowdLabelIdList();
        List<CrowdViewDTO> crowdViewDTOList;
        if (RecommendCrowdTypeEnum.needLabelForQueryTemplateCrowd(showmaxCrowdType)) {
            CampaignGroupViewDTO campaignGroup = campaignGroupRepository.getCampaignGroup(serviceContext, campaignGroupId);
            Long customerMemberId = Optional.ofNullable(campaignGroup.getCampaignGroupCustomerViewDTO()).map(CampaignGroupCustomerViewDTO::getCustomerMemberId).orElse(campaignGroup.getMemberId());
            crowdViewDTOList = crowdRepository.findRecommendCrowd(serviceContext, customerMemberId, showmaxCrowdType, StringUtils.join(showmaxCrowdLabelIdList, ","), null);
        } else {
            crowdViewDTOList = crowdRepository.queryCrowdByIds(serviceContext, showmaxCrowdLabelIdList);
        }
        if (CollectionUtils.isNotEmpty(crowdViewDTOList)) {
            return crowdViewDTOList.get(0);
        }
        return null;
    }
}
