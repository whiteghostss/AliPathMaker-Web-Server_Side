package com.taobao.ad.brand.bp.domain.creative.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.creative.materialgroup.MaterialGroupAuditResultViewDTO;
import com.alibaba.ad.brand.dto.creative.materialgroup.MaterialGroupViewDTO;
import com.alibaba.ad.brand.dto.creative.materialgroup.crop.MaterialGroupCropResultViewDTO;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCropStatusEnum;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandMaterialGroupAuditStatusEnum;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandMaterialGroupTypeEnum;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.ICreativeSmartMaterialCropSuccessJudgeAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeSmartMaterialCropSuccessJudgeAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultCreativeSmartMaterialCropSuccessJudgeAbility implements ICreativeSmartMaterialCropSuccessJudgeAbility {

    @Override
    public Boolean handle(ServiceContext serviceContext, CreativeSmartMaterialCropSuccessJudgeAbilityParam abilityParam) {
        MaterialGroupViewDTO materialGroupViewDTO = abilityParam.getAbilityTarget();
        if(materialGroupViewDTO == null || CollectionUtils.isEmpty(materialGroupViewDTO.getMaterialViewDTOList())){
            return false;
        }
        Integer auditStatus = Optional.ofNullable(materialGroupViewDTO.getMaterialGroupAuditResultViewDTO())
                .map(MaterialGroupAuditResultViewDTO::getAuditStatus).orElse(BrandMaterialGroupAuditStatusEnum.CREATIVE_CENTER_WAITING.getCode());
        if(!BrandMaterialGroupAuditStatusEnum.CREATIVE_CENTER_PASS.getCode().equals(auditStatus)){
            return false;
        }
        //共享分组审核通过直接认为拓版成功
        if(BrandMaterialGroupTypeEnum.OTHER.getCode().equals(materialGroupViewDTO.getGroupType())){
            return true;
        }
        Integer cropStatus = Optional.ofNullable(materialGroupViewDTO.getMaterialGroupCropResultViewDTO())
                .map(MaterialGroupCropResultViewDTO::getStatus).orElse(null);

        return Objects.equals(BrandCropStatusEnum.SUCCESS.getCode(), cropStatus);
    }
}
