package com.taobao.ad.brand.bp.domain.mediarule.ability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.media.mutex.MediaMutexRuleViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.media.field.BrandMediaMutexRuleObjectTypeEnum;
import com.alibaba.ad.brand.sdk.constant.media.field.BrandMediaMutexRuleSceneEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.mediarule.MediaMutexRuleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Optional;

/**
 * 互斥规则扩展
 * @author linhua.deng
 */
@Component
@RequiredArgsConstructor
public class MediaMutexRuleAbility {
    private final MediaMutexRuleRepository mutexRuleRepository;

    /**
     * 互斥规则参数校验
     *
     * @param viewDTO
     */
    public void validateMutexRule(ServiceContext context, MediaMutexRuleViewDTO viewDTO, MediaMutexRuleViewDTO dbViewDTO){
        AssertUtil.hasText(viewDTO.getName(),"互斥规则名称不能为空");
        AssertUtil.maxLength(viewDTO.getName(),20,"互斥规则名称长度不能超过20");
        AssertUtil.notNull(viewDTO.getSiteId(),"媒体不允许为空");
        AssertUtil.notNull(viewDTO.getType(),"互斥类型不允许为空");

        AssertUtil.notNull(BrandMediaMutexRuleObjectTypeEnum.getByCode(viewDTO.getType()),
            BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR,"互斥类型非法");
        AssertUtil.notNull(viewDTO.getScene(),"互斥场景不允许为空");
        AssertUtil.notNull(BrandMediaMutexRuleSceneEnum.getByCode(viewDTO.getScene()),
            BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR,"互斥场景非法");

        AssertUtil.notEmpty(viewDTO.getMutexSourceList(),"互斥源对象不允许为空");
        AssertUtil.notEmpty(viewDTO.getLeftMutexTargetList(),"左边互斥对象不允许为空");
        AssertUtil.notEmpty(viewDTO.getRightMutexTargetList(),"右边互斥对象不允许为空");

        AssertUtil.notNull(viewDTO.getStartTime(),"开始时间不允许为空");
        AssertUtil.notNull(viewDTO.getEndTime(),"结束时间不允许为空");
        viewDTO.setStartTime(BrandDateUtil.getDateMidnight(viewDTO.getStartTime()));
        viewDTO.setEndTime(BrandDateUtil.getDateFullMidnight(viewDTO.getEndTime()));
        AssertUtil.assertTrue(viewDTO.getEndTime().compareTo(viewDTO.getStartTime()) >= 0,"结束时间不能小于开始时间");

        validateName(context,viewDTO);

        //新增-开始时间不能小于当前时间
        if(dbViewDTO == null){
            AssertUtil.assertTrue(BrandDateUtil.getCurrentDate().compareTo(viewDTO.getStartTime()) <= 0,"开始时间不能小于当前时间");
        }
    }
    public void initMutexRule(MediaMutexRuleViewDTO viewDTO, MediaMutexRuleViewDTO dbViewDTO){
        //默认开启
        viewDTO.setStatus(Optional.ofNullable(dbViewDTO).map(MediaMutexRuleViewDTO::getStatus)
            .orElse(BrandBoolEnum.BRAND_TRUE.getCode()));
    }

    /**
     * 名称唯一性校验
     * @param context
     * @param viewDTO
     */
    private void validateName(ServiceContext context, MediaMutexRuleViewDTO viewDTO){
        MediaMutexRuleViewDTO mutexRuleViewDTO = mutexRuleRepository.getTopOneByName(context, viewDTO.getName());
        if(mutexRuleViewDTO != null){
            AssertUtil.assertTrue(Objects.equals(viewDTO.getId(),mutexRuleViewDTO.getId()),
                    BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR,"互斥规则名称不能允许重复");
        }
    }
}
