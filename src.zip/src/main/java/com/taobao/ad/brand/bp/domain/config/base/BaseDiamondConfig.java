package com.taobao.ad.brand.bp.domain.config.base;

import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.diamond.client.Diamond;
import com.taobao.diamond.manager.ManagerListener;

import javax.annotation.PostConstruct;
import java.util.concurrent.Executor;

public abstract class BaseDiamondConfig {
    //超时时间，单位毫秒
    private final static long DIAMOND_TIMEOUT = 10000;

    @PostConstruct
    public void init() {
        try {
            if (getDataId() != null || getGroupId() != null) {
                String content = Diamond.getConfig(getDataId(), getGroupId(), DIAMOND_TIMEOUT);
                initDiamond(content);
                Diamond.addListener(getDataId(), getGroupId(), new ManagerListener() {

                    @Override
                    public Executor getExecutor() {
                        return null;
                    }

                    @Override
                    public void receiveConfigInfo(String s) {
                        try {
                            initDiamond(s);
                        } catch (Exception e) {
                            RogerLogger.error("diamond-config listener error:" + e);
                        }
                    }
                });
            }
        } catch (Exception e) {
            RogerLogger.info("error diamond init error:" + e);
        }
    }

    protected abstract String getDataId();

    protected abstract String getGroupId();

    protected abstract void initDiamond(String e) throws Exception;
}
