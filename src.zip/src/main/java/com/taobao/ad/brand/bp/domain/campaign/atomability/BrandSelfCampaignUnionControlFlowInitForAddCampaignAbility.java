package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.biz.definition.constants.UniversalCampaignModel;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.boost.CampaignBoostViewDTO;
import com.alibaba.ad.brand.dto.campaign.guarantee.CampaignGuaranteeViewDTO;
import com.alibaba.ad.brand.dto.campaign.sale.CampaignSaleViewDTO;
import com.alibaba.ad.brand.dto.campaign.smartreserved.CampaignSmartReservedViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignUnionControlFlowEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignUnionControlFlowInitForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignUnionControlFlowAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSelfCampaignUnionControlFlowInitForAddCampaignAbility implements
        ICampaignUnionControlFlowInitForAddCampaignAbility, BrandSelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignUnionControlFlowAbilityParam abilityParam) {
        CampaignViewDTO campaignViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(campaignViewDTO, "计划信息不能为空");
        AssertUtil.notNull(campaignViewDTO.getId(), "计划id不能为空");
        Integer saleType = Optional.ofNullable(campaignViewDTO.getCampaignSaleViewDTO()).map(CampaignSaleViewDTO::getSaleType).orElse(null);

        //非补量场景，主计划对应sourceId为自己的id；补量场景，使用界面传入的sourceId
        CampaignBoostViewDTO parentCampaignBoostViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignBoostViewDTO()).orElse(new CampaignBoostViewDTO());
        if(!BrandSaleTypeEnum.BOOST.getCode().equals(saleType)){
            parentCampaignBoostViewDTO.setSourceCampaignId(campaignViewDTO.getId());
        }
        //保量场景
        CampaignGuaranteeViewDTO parentCampaignGuaranteeViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignGuaranteeViewDTO()).orElse(new CampaignGuaranteeViewDTO());
        Long budgetCampaignId = campaignViewDTO.getId();
        // 如果【开启联合控量 && 补量计划】一二级计划budgetCampaignId 取主计划一级计划id
        if (BrandCampaignUnionControlFlowEnum.UNION.getCode().equals(parentCampaignGuaranteeViewDTO.getIsUnionControlFlow()) && BrandSaleTypeEnum.BOOST.getCode().equals(saleType)) {
            budgetCampaignId = parentCampaignBoostViewDTO.getSourceCampaignId();
        }
        parentCampaignGuaranteeViewDTO.setBudgetCampaignId(budgetCampaignId);

        Long pubDealId = null;
        //【二环PDB补量场景】一二级计划pubDealId 取主计划一级计划id
        CampaignSmartReservedViewDTO parentCampaignSmartReservedViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignSmartReservedViewDTO()).orElse(new CampaignSmartReservedViewDTO());
        if(Objects.equals(UniversalCampaignModel.TAO_ECOLOGY_TWO_PDB.getId(), campaignViewDTO.getCampaignModel())){
            //复用主计划deal开关
            Integer isCopyMainDeal = parentCampaignSmartReservedViewDTO.getIsCopyMainDeal();
            //复用其他计划（配送计划补量场景）
            Integer isCopyOtherDeal = parentCampaignSmartReservedViewDTO.getIsCopyOtherDeal();
            if(BrandSaleTypeEnum.BOOST.getCode().equals(saleType) && BrandBoolEnum.BRAND_TRUE.getCode().equals(isCopyMainDeal)){
                pubDealId = parentCampaignBoostViewDTO.getSourceCampaignId();
            } else if(BrandSaleTypeEnum.PRESENT.getCode().equals(saleType) && BrandBoolEnum.BRAND_TRUE.getCode().equals(isCopyOtherDeal)){
                pubDealId = parentCampaignSmartReservedViewDTO.getPubDealId();
            } else {
                pubDealId = campaignViewDTO.getId();
            }
            parentCampaignSmartReservedViewDTO.setPubDealId(pubDealId);
        }
        campaignViewDTO.setCampaignGuaranteeViewDTO(parentCampaignGuaranteeViewDTO);
        campaignViewDTO.setCampaignBoostViewDTO(parentCampaignBoostViewDTO);
        campaignViewDTO.setCampaignSmartReservedViewDTO(parentCampaignSmartReservedViewDTO);

        // 二级计划
        for (CampaignViewDTO subCampaign : campaignViewDTO.getSubCampaignViewDTOList()) {
            CampaignBoostViewDTO subCampaignBoostViewDTO = Optional.ofNullable(subCampaign.getCampaignBoostViewDTO()).orElse(new CampaignBoostViewDTO());
            if(!BrandSaleTypeEnum.BOOST.getCode().equals(saleType)){
                subCampaignBoostViewDTO.setSourceCampaignId(subCampaign.getId());
            }
            CampaignGuaranteeViewDTO subCampaignGuaranteeViewDTO = Optional.ofNullable(subCampaign.getCampaignGuaranteeViewDTO()).orElse(new CampaignGuaranteeViewDTO());
            subCampaignGuaranteeViewDTO.setBudgetCampaignId(budgetCampaignId);

            CampaignSmartReservedViewDTO subCampaignSmartReservedViewDTO = Optional.ofNullable(subCampaign.getCampaignSmartReservedViewDTO()).orElse(new CampaignSmartReservedViewDTO());
            subCampaignSmartReservedViewDTO.setPubDealId(pubDealId);

            subCampaign.setCampaignGuaranteeViewDTO(subCampaignGuaranteeViewDTO);
            subCampaign.setCampaignBoostViewDTO(subCampaignBoostViewDTO);
            subCampaign.setCampaignSmartReservedViewDTO(subCampaignSmartReservedViewDTO);
        }
        return null;
    }
}
