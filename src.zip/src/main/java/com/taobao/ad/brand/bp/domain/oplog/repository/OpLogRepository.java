package com.taobao.ad.brand.bp.domain.oplog.repository;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.dto.oplog.OpLogQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.oplog.OpLogViewDTO;

import java.util.List;

/**
 * @author jixiu.lj
 * @date 2024/3/20 15:31
 * 日志中心日志查询
 */
public interface OpLogRepository {
    List<OpLogViewDTO> queryOpLog(ServiceContext serviceContext, OpLogQueryViewDTO opLogQueryViewDTO);
}
