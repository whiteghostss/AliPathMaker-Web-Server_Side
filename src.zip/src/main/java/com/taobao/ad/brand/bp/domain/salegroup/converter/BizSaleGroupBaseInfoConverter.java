package com.taobao.ad.brand.bp.domain.salegroup.converter;

import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.SaleGroupBaseViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import com.taobao.ad.brand.bp.domain.salegroup.converter.mapstruct.BizSaleGroupInfoBaseInfoMapStruct;
import org.springframework.stereotype.Component;

@Component
public class BizSaleGroupBaseInfoConverter extends BaseViewDTOConverter<SaleGroupInfoViewDTO, SaleGroupBaseViewDTO> {

    @Override
    public BaseMapStructMapper<SaleGroupInfoViewDTO, SaleGroupBaseViewDTO> getBaseMapStructMapper() {
        return BizSaleGroupInfoBaseInfoMapStruct.INSTANCE;
    }



}
