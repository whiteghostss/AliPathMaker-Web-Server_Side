package com.taobao.ad.brand.bp.domain.adgroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.adgroup.crowd.AdgroupCrowdScenarioViewDTO;
import com.alibaba.ad.brand.dto.adgroup.resource.AdgroupResourceViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupPriorityEnum;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupTargetTypeEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupBaseInfoInitForAddOrUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupBaseInfoInitForAddOrUpdateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Optional;

@Component
@BusinessAbility
public class BrandSelfAdgroupBaseInfoInitForAddOrUpdateAbility
    implements IAdgroupBaseInfoInitForAddOrUpdateAbility, BrandSelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, AdgroupBaseInfoInitForAddOrUpdateAbilityParam abilityParam) {
        AdgroupViewDTO adgroupViewDTO  = abilityParam.getAbilityTarget();
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();

        adgroupViewDTO.setCustomerId(campaignViewDTO.getCampaignSaleViewDTO().getCustomerId());
        adgroupViewDTO.setCampaignGroupId(campaignViewDTO.getCampaignGroupId());
        adgroupViewDTO.setSaleGroupId(campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId());
        if(Objects.isNull(adgroupViewDTO.getWeight())){
            adgroupViewDTO.setWeight(0);
        }

        adgroupViewDTO.setEndTime(BrandDateUtil.getMaxDate(adgroupViewDTO.getEndTime()));
        if(BrandAdgroupTargetTypeEnum.DIRECT.getCode().equals(adgroupViewDTO.getTargetType())){
            adgroupViewDTO.setStartTime(campaignViewDTO.getStartTime());
            adgroupViewDTO.setEndTime(campaignViewDTO.getEndTime());
        }

        if(CollectionUtils.isNotEmpty(adgroupViewDTO.getCreativeRefViewDTOList())){
            adgroupViewDTO.getCreativeRefViewDTOList().stream().filter(item->Objects.nonNull(item)).forEach(item->{
                item.setCampaignId(campaignViewDTO.getId());
                item.setCampaignGroupId(campaignViewDTO.getCampaignGroupId());
            });
        }
        AdgroupResourceViewDTO adgroupResourceViewDTO = Optional.ofNullable(adgroupViewDTO.getAdgroupResourceViewDTO()).orElse(new AdgroupResourceViewDTO());
        adgroupResourceViewDTO.setSspMediaScope(campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope());
        adgroupResourceViewDTO.setSspCrossScene(campaignViewDTO.getCampaignResourceViewDTO().getSspCrossScene());
        adgroupViewDTO.setAdgroupResourceViewDTO(adgroupResourceViewDTO);

        if(Objects.equals(adgroupViewDTO.getPriority(), BrandAdgroupPriorityEnum.BOTTOM.getCode())){
            adgroupViewDTO.setAdgroupCrowdScenarioViewDTO(new AdgroupCrowdScenarioViewDTO());
            adgroupViewDTO.getAdgroupCrowdScenarioViewDTO().setAdgroupCrowdViewDTOList(Lists.newArrayList());
            adgroupViewDTO.getAdgroupCrowdScenarioViewDTO().setCrowdTag(BrandBoolEnum.BRAND_FALSE.getCode());
        }
        return null;
    }
}
