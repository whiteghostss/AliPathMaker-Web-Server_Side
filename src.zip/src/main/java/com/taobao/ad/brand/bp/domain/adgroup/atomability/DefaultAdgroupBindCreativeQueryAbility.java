package com.taobao.ad.brand.bp.domain.adgroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.adgroup.CreativeRefViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.common.threadpooltask.CreativeQueryTaskIdentifier;
import com.taobao.ad.brand.bp.common.util.PageUtil;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeRepository;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupBindCreativeQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.query.IAdgroupBindCreativeQueryAbility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author yanjingang
 * @date 2024/9/12
 */
@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultAdgroupBindCreativeQueryAbility implements IAdgroupBindCreativeQueryAbility {

    private final CreativeQueryTaskIdentifier creativeQueryTaskIdentifier;
    private final CreativeRepository creativeRepository;

    @Override
    public Map<Long, List<CreativeViewDTO>> handle(ServiceContext serviceContext, AdgroupBindCreativeQueryAbilityParam abilityParam) {
        List<AdgroupViewDTO> adgroupViewDTOList = abilityParam.getAbilityTargets();
        if(CollectionUtils.isEmpty(adgroupViewDTOList)){
            return Maps.newHashMap();
        }
        Map<Long,List<CreativeViewDTO>> adgroupCreativeGroupMap = Maps.newHashMap();
        List<Long> creativeList = adgroupViewDTOList.stream().filter(adgroupViewDTO -> CollectionUtils.isNotEmpty(adgroupViewDTO.getCreativeRefViewDTOList()))
                .flatMap(adgroupViewDTO -> adgroupViewDTO.getCreativeRefViewDTOList().stream())
                .map(CreativeRefViewDTO::getCreativeId).filter(Objects::nonNull).distinct().collect(Collectors.toList());
        if(CollectionUtils.isEmpty(creativeList)){
            return adgroupCreativeGroupMap;
        }
        //查询创意
        List<List<Long>> creativePartitionList = Lists.partition(creativeList, PageUtil.MAX_PAGE_COUNT);

        List<List<CreativeViewDTO>> allCreativeList = TaskStream
                .execute(creativeQueryTaskIdentifier, creativePartitionList, (creativeIdList, index) -> {
                    List<CreativeViewDTO> tempCreativeList = creativeRepository.findCreativeByIds(serviceContext, creativeIdList);
                    return Optional.ofNullable(tempCreativeList).orElse(Lists.newArrayList());
                })
                .commit()
                .getResultList();

        Map<Long, CreativeViewDTO> creativeViewDTOMap = Optional.of(allCreativeList).orElse(Lists.newArrayList())
                .stream().filter(CollectionUtils::isNotEmpty)
                .flatMap(Collection::stream).collect(Collectors.toMap(CreativeViewDTO::getId, Function.identity()));

        if(MapUtils.isNotEmpty(creativeViewDTOMap)){
            for (AdgroupViewDTO adgroupViewDTO : adgroupViewDTOList) {
                List<CreativeViewDTO> creativeViewDTOList = Optional.ofNullable(adgroupViewDTO.getCreativeRefViewDTOList()).orElse(Lists.newArrayList())
                        .stream().map(CreativeRefViewDTO::getCreativeId).distinct()
                        .map(creativeViewDTOMap::get).filter(Objects::nonNull).collect(Collectors.toList());
                if(CollectionUtils.isNotEmpty(creativeViewDTOList)){
                    adgroupCreativeGroupMap.put(adgroupViewDTO.getId(),creativeViewDTOList);
                }
            }
        }
        return adgroupCreativeGroupMap;
    }
}
