package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.guarantee.CampaignGuaranteeViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignGuaranteeValidateForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignGuaranteeAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Optional;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_ILLEGAL;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandCampaignGuaranteeValidateForUpdateCampaignAbility implements ICampaignGuaranteeValidateForUpdateCampaignAbility, BrandAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGuaranteeAbilityParam abilityParam) {
        ResourcePackageProductViewDTO resourcePackageProductViewDTO = abilityParam.getResourcePackageProductViewDTO();
        AssertUtil.notNull(resourcePackageProductViewDTO,"资源产品不存在");
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();
        AssertUtil.notNull(campaignViewDTO,"计划不存在");
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        AssertUtil.notNull(dbCampaignViewDTO,"计划不存在");
        //【二环CPT场景】1、预定轮数不允许为空
        if(BizCampaignToolsHelper.isTwoCPT(resourcePackageProductViewDTO.getMediaScope(),resourcePackageProductViewDTO.getSaleUnit())){
            Long cptAmount = Optional.ofNullable(campaignViewDTO.getCampaignGuaranteeViewDTO()).map(CampaignGuaranteeViewDTO::getCptAmount).orElse(null);
            AssertUtil.notNull(cptAmount,PARAM_ILLEGAL, "计划进入投放期，或计划在锁量中、锁量成功、待投放、投放中、投放结束、投放暂停状态，计划预定轮数不能为空");
            Long singleCptAmount = cptAmount / (BrandDateUtil.getDateRange(campaignViewDTO.getStartTime(),campaignViewDTO.getEndTime())+1);
            Long dbCptAmount = Optional.ofNullable(dbCampaignViewDTO.getCampaignGuaranteeViewDTO()).map(CampaignGuaranteeViewDTO::getCptAmount).orElse(0L);
            Long dbSingleCptAmount = dbCptAmount/ (BrandDateUtil.getDateRange(dbCampaignViewDTO.getStartTime(),dbCampaignViewDTO.getEndTime())+1);
            AssertUtil.assertTrue(Objects.equals(singleCptAmount,dbSingleCptAmount), PARAM_ILLEGAL, "计划进入投放期，或计划在锁量中、锁量成功、待投放、投放中、投放结束、投放暂停状态，计划单日预定轮数不能修改");
        }
        return null;
    }
}
