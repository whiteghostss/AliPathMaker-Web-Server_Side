package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.smartreserved.CampaignSmartReservedViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignSmartReservedValidateForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignSmartReservedAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Optional;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_ILLEGAL;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandCampaignSmartReservedValidateForUpdateCampaignAbility implements ICampaignSmartReservedValidateForUpdateCampaignAbility, BrandAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignSmartReservedAbilityParam abilityParam) {
        ProductViewDTO productViewDTO = abilityParam.getProductViewDTO();
        AssertUtil.notNull(productViewDTO,"产品不存在");
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        AssertUtil.notNull(dbCampaignViewDTO,"计划不存在");
        CampaignSmartReservedViewDTO smartReservedViewDTO = abilityParam.getAbilityTarget();
        //【智能预留场景】1、三方DSP不允许修改
        if(BrandBoolEnum.BRAND_TRUE.getCode().equals(productViewDTO.getSmartreserved())){
            Long dspId = Optional.ofNullable(smartReservedViewDTO).map(CampaignSmartReservedViewDTO::getDspId).orElse(null);
            Long dbDspId = Optional.ofNullable(dbCampaignViewDTO.getCampaignSmartReservedViewDTO()).map(CampaignSmartReservedViewDTO::getDspId).orElse(null);
            AssertUtil.assertTrue(Objects.equals(dspId,dbDspId), PARAM_ILLEGAL, "计划进入投放期，或计划在锁量中、锁量成功、待投放、投放中、投放结束、投放暂停状态，三方DSP不能修改");
        }
        return null;
    }
}
