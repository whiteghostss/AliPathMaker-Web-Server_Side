package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupValidateForDeleteAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupDeleteAbilityParam;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
public class DefaultCampaignGroupValidateForDeleteAbility implements ICampaignGroupValidateForDeleteAbility {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupDeleteAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        //订单状态必须是草稿
        AssertUtil.assertTrue(BrandCampaignGroupStatusEnum.EDITED.getCode().equals(campaignGroupViewDTO.getStatus()), "当前订单状态不允许删除订单");
        return null;
    }
}
