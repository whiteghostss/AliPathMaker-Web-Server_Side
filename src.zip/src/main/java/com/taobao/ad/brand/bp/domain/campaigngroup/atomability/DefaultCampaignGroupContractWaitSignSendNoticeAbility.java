package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignDealMsgViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignMsgNoticeViewDTO;
import com.taobao.ad.brand.bp.client.dto.message.MessageViewDTO;
import com.taobao.ad.brand.bp.client.enums.message.MessageSendTypeEnum;
import com.taobao.ad.brand.bp.common.util.VelocityUtils;
import com.taobao.ad.brand.bp.domain.memeber.MemberRepository;
import com.taobao.ad.brand.bp.domain.message.MessageRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupCancelSendNoticeAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupContractWaitSignSendNoticeAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupNoticeAbilityParam;
import org.springframework.cglib.beans.BeanMap;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
@BusinessAbility
public class DefaultCampaignGroupContractWaitSignSendNoticeAbility implements ICampaignGroupContractWaitSignSendNoticeAbility {

    @Resource
    private MemberRepository memberRepository;
    @Resource
    private MessageRepository messageRepository;

    /**
     * 合同签约通知
     */
    private static final String CONTRACT_WAIT_SIGN_NOTICE = "vm/contractWaitSignNotice.vm";

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupNoticeAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        MessageViewDTO messageViewDTO = new MessageViewDTO();
        CampaignDealMsgViewDTO campaignDealMsgViewDTO = new CampaignDealMsgViewDTO();
        campaignDealMsgViewDTO.setCampaignGroupViewDTO(campaignGroupViewDTO);
        String subject = String.format("【自助营销订单待签约通知】投放账号：%s  订单：%s",
                memberRepository.getMemberDisplayNameById(campaignGroupViewDTO.getMemberId()),
                campaignGroupViewDTO.getName());
        messageViewDTO.setMemberId(campaignGroupViewDTO.getMemberId());
        messageViewDTO.setSubject(subject);
        messageViewDTO.setContent(buildContractWaitSignMessageContent(serviceContext, campaignGroupViewDTO));
        messageViewDTO.setSendType(Lists.newArrayList(MessageSendTypeEnum.STATION_LETTER.getValue()));
        messageRepository.sendMessage(messageViewDTO);
        return null;
    }

    private String buildContractWaitSignMessageContent(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO) {
        CampaignMsgNoticeViewDTO campaignMsgNoticeViewDTO = new CampaignMsgNoticeViewDTO();
        campaignMsgNoticeViewDTO.setCampaignGroupId(campaignGroupViewDTO.getId());
        campaignMsgNoticeViewDTO.setCampaignGroupName(campaignGroupViewDTO.getName());
        BeanMap beanMap = BeanMap.create(campaignMsgNoticeViewDTO);
        return VelocityUtils.merge(CONTRACT_WAIT_SIGN_NOTICE, beanMap);
    }
}
