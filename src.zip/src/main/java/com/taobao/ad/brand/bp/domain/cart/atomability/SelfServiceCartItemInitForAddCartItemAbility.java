package com.taobao.ad.brand.bp.domain.cart.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.alibaba.ad.brand.sdk.constant.cartitem.BrandCartItemSourceEnum;
import com.alibaba.ad.brand.sdk.constant.cartitem.BrandCartItemStatusEnum;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSkuViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.ICartItemInitForAddCartItemAbility;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.param.CartItemAddInitAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCartItemInitForAddCartItemAbility implements ICartItemInitForAddCartItemAbility, SelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext context, CartItemAddInitAbilityParam initAbilityParam) {
        CartItemViewDTO cartItemViewDTO = initAbilityParam.getAbilityTarget();
        BrandSkuViewDTO skuViewDTO = initAbilityParam.getSkuViewDTO();
        if(Objects.isNull(cartItemViewDTO.getCartSource())){
            cartItemViewDTO.setCartSource(BrandCartItemSourceEnum.BAILING.getCode());
        }
        cartItemViewDTO.setStatus(BrandCartItemStatusEnum.ORDER_WAIT.getCode());
        cartItemViewDTO.setSpuId(skuViewDTO.getSpuId());
        return null;
    }
}
