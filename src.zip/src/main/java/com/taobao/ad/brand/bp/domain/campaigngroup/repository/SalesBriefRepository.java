package com.taobao.ad.brand.bp.domain.campaigngroup.repository;

import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesBriefViewDTO;

/**
 * @author yanjingang
 * @date 2023/3/9
 */
public interface SalesBriefRepository {

    SalesBriefViewDTO getBrief(Long briefId);

    boolean canModify(Long briefId);

    void modifyBrief(Long briefId);

    /**
     * 同步订单信息至Brief
     * @param campaignGroupViewDTO
     */
    void syncCampaignGroupInfoToBrief(CampaignGroupViewDTO campaignGroupViewDTO);

    /**
     * 订单完成通知brief状态变执行完成
     * @param campaignGroupViewDTO
     */
    void finishBrief(CampaignGroupViewDTO campaignGroupViewDTO);

    /**
     * 完成回撤通知brief状态
     * @param campaignGroupViewDTO
     */
    void finishRevertBrief(CampaignGroupViewDTO campaignGroupViewDTO);
    /**
     * 同步Brief更新状态&相关信息
     * @param salesBriefViewDTO
     */
    void acceptStatusEvent(SalesBriefViewDTO salesBriefViewDTO);
}
