package com.taobao.ad.brand.bp.domain.adgroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupBottomTypeEnum;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupPriorityEnum;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupInitForUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupInitForUpdateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Component
@BusinessAbility
public class BrandSelfAdgroupInitForUpdateAbility implements IAdgroupInitForUpdateAbility,
    BrandSelfServiceAtomAbilityRouter {
    @Override
    public Void handle(ServiceContext serviceContext, AdgroupInitForUpdateAbilityParam abilityParam) {
        AdgroupViewDTO dbAdgroupViewDTO = abilityParam.getDbAdgroupViewDTO();
        AdgroupViewDTO adgroupViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();
        if (null != dbAdgroupViewDTO){
            if (Objects.nonNull(dbAdgroupViewDTO.getBottomType())){
                adgroupViewDTO.setBottomType(dbAdgroupViewDTO.getBottomType());
            }
            if (null != dbAdgroupViewDTO.getBottomType()){
                if(Objects.equals(dbAdgroupViewDTO.getBottomType(), BrandAdgroupBottomTypeEnum.BOTTOM.getCode())){
                    adgroupViewDTO.setWeight(0);
                    adgroupViewDTO.setBottomType(BrandAdgroupBottomTypeEnum.BOTTOM.getCode());
                    adgroupViewDTO.setPriority(BrandAdgroupPriorityEnum.BOTTOM.getCode());
                    adgroupViewDTO.setStartTime(campaignViewDTO.getStartTime());
                    adgroupViewDTO.setEndTime(campaignViewDTO.getEndTime());

                }
                if(Objects.equals(dbAdgroupViewDTO.getBottomType(), BrandAdgroupBottomTypeEnum.N_REACH.getCode())){
                    adgroupViewDTO.setWeight(0);
                    adgroupViewDTO.setBottomType(BrandAdgroupBottomTypeEnum.N_REACH.getCode());
                    adgroupViewDTO.setPriority(BrandAdgroupPriorityEnum.ONE.getCode());
                    adgroupViewDTO.setStartTime(campaignViewDTO.getStartTime());
                    adgroupViewDTO.setEndTime(campaignViewDTO.getEndTime());
                }
            }
        }
        return null;
    }
}
