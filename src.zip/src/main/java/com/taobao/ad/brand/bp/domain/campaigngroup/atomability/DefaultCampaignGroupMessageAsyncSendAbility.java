package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.hermes.framework.event.SimpleEventEngine;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.context.DomainMetaqMessageBodyContext;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupEventEnum;
import com.taobao.ad.brand.bp.client.enums.message.DomainMessageTypeEnum;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.event.DomainMetaqMessageEvent;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupMessageAsyncSendAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupMessageAsyncSendAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Optional;

import static com.taobao.ad.brand.bp.common.constant.campaigngroup.CampaignGroupConstant.MAIN_CAMPAIGN_GROUP_ID_KEY;

/**
 * @author yanjingang
 * @date 2025/2/8
 */
@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultCampaignGroupMessageAsyncSendAbility implements ICampaignGroupMessageAsyncSendAbility {

    @Value("${env}")
    private String env;
    private final SimpleEventEngine simpleEventEngine;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupMessageAsyncSendAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroup = abilityParam.getAbilityTarget();
        DomainMessageTypeEnum domainType = BizCampaignGroupToolsHelper.isMainCampaignGroup(campaignGroup) ?
                DomainMessageTypeEnum.MAIN_CAMPAIGN_GROUP
                : DomainMessageTypeEnum.SUB_CAMPAIGN_GROUP;
        Map<String, String> properties = Optional.ofNullable(abilityParam.getProperties()).orElse(Maps.newHashMap());
        String domainEvent = abilityParam.getDomainEvent();
        if (CampaignGroupEventEnum.DELETE.name().equals(domainEvent) && domainType == DomainMessageTypeEnum.SUB_CAMPAIGN_GROUP) {
            properties.put(MAIN_CAMPAIGN_GROUP_ID_KEY, String.valueOf(campaignGroup.getParentId()));
        }
        properties.put("type", String.valueOf(campaignGroup.getType()));

        String bizCode = ServiceContextUtil.getBizCode(campaignGroup.getSceneId());
        // 发送子订单生成的消息
        DomainMetaqMessageBodyContext msgBodyContext = DomainMetaqMessageBodyContext.builder()
                .bizCode(bizCode)
                .domainType(domainType)
                .domainEvent(domainEvent)
                .entityId(campaignGroup.getId())
                .memberId(campaignGroup.getMemberId())
                .env(env)
                .properties(properties)
                .build();
        simpleEventEngine.fire(DomainMetaqMessageEvent.of(msgBodyContext));

        return null;
    }
}
