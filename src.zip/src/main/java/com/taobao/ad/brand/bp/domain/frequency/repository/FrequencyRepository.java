package com.taobao.ad.brand.bp.domain.frequency.repository;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.frequency.FrequencyViewDTO;
import com.alibaba.ad.brand.sdk.constant.frequency.field.BrandFrequencyBizTypeEnum;
import com.alibaba.ad.organizer.dto.FrequencyDTO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.FrequencyQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.FrequencyRefViewDTO;

import java.util.List;
import java.util.Map;

public interface FrequencyRepository {

    /**
     * 新增频控
     * @param serviceContext
     * @param frequencyViewDTO
     */
    Long addFrequency(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO);

    /**
     * 更新频控
     * @param serviceContext
     * @param frequencyViewDTO
     */
    void updateFrequencyAll(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO);

    /**
     * 部分更新频控
     * @param serviceContext
     * @param frequencyViewDTO
     * @return
     */
    Integer updateFrequencyPart(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO);


    /**
     * 根据频控id查询频控详情
     * @param serviceContext
     * @param frequencyId
     * @return
     */
    FrequencyViewDTO getFrequencyById(ServiceContext serviceContext, Long frequencyId);

    /**
     * 根据关键词查询频控id和名称
     * @param serviceContext
     * @param queryViewDTO
     * @return
     */
    PageResultViewDTO<FrequencyViewDTO> frequencyList(ServiceContext serviceContext, FrequencyQueryViewDTO queryViewDTO);

    /**
     * 查询频控ID关联的实体id
     * @param serviceContext
     * @param frequencyId
     * @return
     */
    FrequencyRefViewDTO findFrequencyRefByFreqId(ServiceContext serviceContext, Long frequencyId, Integer frequencyBizType);

    /**
     * 频控重名校验
     * @param serviceContext
     * @param queryViewDTO
     * @return
     */
    List<FrequencyDTO> findFrequencyByName(ServiceContext serviceContext, FrequencyQueryViewDTO queryViewDTO);


    /**————————————————————————————————————————————交付型频控（计划维度）——————————————————————————————————————————**/
    /**
     * 批量保存频控信息
     * @param serviceContext
     * @param campaignViewDTOList
     */
    void saveCampaignFrequency(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList);

    /**
     * 删除计划频控ref
     * @param serviceContext
     * @param campaignIds
     */
    void deleteCampaignFreqRef(ServiceContext serviceContext, List<Long> campaignIds);
    /**
     * 保存频控关联关系
     * @param freqId 频控id
     * @param campaignIds 计划id
     */
    void saveCampaignFreqRef(ServiceContext serviceContext, Long freqId, List<Long> campaignIds);

    /**
     * 获取计划频控信息
     * @param serviceContext
     * @param campaignIds
     * @return key：计划id，value：频控
     */
    Map<Long, FrequencyViewDTO> getCampaignFrequency(ServiceContext serviceContext, List<Long> campaignIds);



    /**————————————————————————————————————————————优化型频控（单元维度）——————————————————————————————————————————**/

    /**
     * 删除单元频控ref
     * @param serviceContext
     * @param adgroupIds
     */
    void deleteAdgroupFreqRef(ServiceContext serviceContext, List<Long> adgroupIds);

    /**
     * 保存频控关联关系
     * @param freqId 频控id
     * @param adgroupIds 单元id
     */
    void saveAdgroupFreqRef(ServiceContext serviceContext, Long freqId, List<Long> adgroupIds);

    /**
     * 获取单元频控信息
     * @param serviceContext
     * @param adgroupIds
     * @return key：单元id，value：频控
     */
    Map<Long, FrequencyViewDTO> getAdgroupFrequency(ServiceContext serviceContext, List<Long> adgroupIds);

}
