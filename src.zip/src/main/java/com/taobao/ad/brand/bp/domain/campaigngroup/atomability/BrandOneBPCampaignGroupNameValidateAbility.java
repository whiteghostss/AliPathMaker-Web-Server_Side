package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignGroupQueryViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.common.util.ValidatorUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupNameValidateAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

@Component
@BusinessAbility
public class BrandOneBPCampaignGroupNameValidateAbility extends DefaultCampaignGroupNameValidateAbility implements BrandOneBPAtomAbilityRouter {

    @Resource
    private CampaignGroupRepository campaignGroupRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupNameValidateAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(campaignGroupViewDTO,"订单信息不能为空");
        String name = campaignGroupViewDTO.getName();
        if(StringUtils.isBlank(name)){
            return null;
        }
        //主订单不区分新增和修改，统一进行校验
        AssertUtil.maxLength(name,50,"订单名称长度不能超过50");
        AssertUtil.assertTrue(ValidatorUtil.isText(name),"订单名称仅支持数字、字母、汉字、下划线、中线");

        CampaignGroupQueryViewDTO queryViewDTO = new CampaignGroupQueryViewDTO();
        queryViewDTO.setFullName(campaignGroupViewDTO.getName());
        Integer sceneId = ServiceContextUtil.getSceneId(serviceContext);
        if (sceneId != null) {
            queryViewDTO.setSceneIds(Lists.newArrayList(sceneId));
        }
        List<CampaignGroupViewDTO> dbCampaignGroupList = campaignGroupRepository.findCampaignGroupList(serviceContext, queryViewDTO);
        if (CollectionUtils.isEmpty(dbCampaignGroupList)) {
            return null;
        }
        dbCampaignGroupList = dbCampaignGroupList.stream().filter(t -> !BrandCampaignGroupStatusEnum.DELETED.getCode()
                .equals(t.getStatus())).collect(Collectors.toList());
        AssertUtil.assertTrue(dbCampaignGroupList.size() == 1
                && dbCampaignGroupList.get(0).getId().equals(campaignGroupViewDTO.getId()),"订单名称重复");
        return null;
    }
}
