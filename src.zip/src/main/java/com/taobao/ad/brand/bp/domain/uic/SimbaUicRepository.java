package com.taobao.ad.brand.bp.domain.uic;

import java.util.List;
import java.util.Map;

import com.alibaba.ad.nb.order.dto.common.EmpDTO;

public interface SimbaUicRepository {

    EmpDTO getEmp(String empId);

    Map<String, EmpDTO> getEmp(List<String> empId);

    Map<String, String> getEmpEmails(List<String> empIds);

    EmpDTO getEmpByBucUserId(Long bucUserId);
}
