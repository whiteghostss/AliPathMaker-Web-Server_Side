package com.taobao.ad.brand.bp.domain.config;

import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.domain.config.base.BaseDiamondConfig;
import lombok.Data;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author zhaorubing
 * @date 2024/8/22 19:52
 */
@Component
public class CreativeTemplateConfigDiamond extends BaseDiamondConfig {

    private static volatile String config;

    @Override
    protected String getDataId() {
        return "creative.template.config";
    }

    @Override
    protected String getGroupId() {
        return "com.taobao.ad.brand.bp";
    }

    @Override
    protected void initDiamond(String diamondConfig) {
        RogerLogger.info("DiamondConfig.initDiamond CreativeTemplateConfigDiamond param: {}", diamondConfig);
        config = diamondConfig;
    }


    /**
     * 查询灰度模板白名单客户列表
     *
     * @return
     */
    public List<Long> getGrayTemplateMembers() {
        if (StringUtils.isBlank(config)) {
            return Lists.newArrayList();
        }
        CreativeTemplateConfigInfo shopWindowConfigInfo = JSON.parseObject(config, CreativeTemplateConfigInfo.class);
        if (StringUtils.isBlank(shopWindowConfigInfo.getGrayTemplateMembers())) {
            return Lists.newArrayList();
        }
        return Arrays.stream(StringUtils.split(shopWindowConfigInfo.getGrayTemplateMembers(), Constant.CHAR_SPLIT_KEY_DOT))
                .map(Long::parseLong).distinct().collect(Collectors.toList());
    }


    @Data
    private static class CreativeTemplateConfigInfo {
        //坑位信息
        private Map<String, String> locationMap;
        //灰度名单
        private String grayTemplateMembers;
    }
}
