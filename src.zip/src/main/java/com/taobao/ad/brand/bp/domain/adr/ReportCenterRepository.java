package com.taobao.ad.brand.bp.domain.adr;

import java.util.List;
import java.util.Map;

/**
 * ADR报表中心相关服务
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
public interface ReportCenterRepository {
    /**
     * 查询报表中心数据明细
     * @param queryParams
     * @return
     */
    List<Map<String, Object>> findData(Map<String, Object> queryParams);


}
