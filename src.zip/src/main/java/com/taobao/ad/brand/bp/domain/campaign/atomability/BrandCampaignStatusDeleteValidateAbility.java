package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignStatusDeleteValidateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignDeleteValidateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandCampaignStatusDeleteValidateAbility implements ICampaignStatusDeleteValidateAbility, BrandAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignDeleteValidateAbilityParam abilityParam) {
        CampaignViewDTO dbCampaign = abilityParam.getAbilityTarget();
        AssertUtil.notNull(dbCampaign, BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR,"计划不存在或已删除");
        // 【状态】只允许在草稿、询量成功、询量失败、锁量失败下可以删除
        BrandCampaignStatusEnum campaignStatus = BrandCampaignStatusEnum.getByCode(dbCampaign.getStatus());
        AssertUtil.assertTrue(BrandCampaignStatusEnum.NEW == campaignStatus || BrandCampaignStatusEnum.INQUIRY_SUCCESS == campaignStatus
                        || BrandCampaignStatusEnum.INQUIRY_FAIL == campaignStatus || BrandCampaignStatusEnum.LOCK_FAIL == campaignStatus
                , BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR,"计划只允许在草稿、询量成功、询量失败、锁量失败下可以删除");
        return null;
    }
}
