package com.taobao.ad.brand.bp.domain.campaigngroup.repository;

import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesProjectViewDTO;

import java.util.List;

/**
 * @author yanjingang
 * @date 2023/3/20
 */
public interface SalesProjectRepository {

    /**
     * 查询售卖项目基础信息
     *
     * @param ids
     * @return
     */
     List<SalesProjectViewDTO> findSimpleProjectByIds(List<Long> ids) ;

}
