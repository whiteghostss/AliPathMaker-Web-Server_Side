package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupWakeupTypeEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupCheckedResourceViewDTO;
import com.taobao.ad.brand.bp.client.enums.CommonEnum;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.SchemaEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupWakeupValidateForUpdateCheckedResourceAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupUpdateCheckedResourceAbilityParam;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Component
@BusinessAbility
public class DefaultCampaignGroupWakeupValidateForUpdateCheckedResourceAbility implements ICampaignGroupWakeupValidateForUpdateCheckedResourceAbility {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupUpdateCheckedResourceAbilityParam abilityParam) {
        CampaignGroupCheckedResourceViewDTO checkedResourceViewDTO = abilityParam.getAbilityTarget();
        if (BrandSaleTypeEnum.BOOST.getCode().equals(checkedResourceViewDTO.getSaleType()) || BrandSaleTypeEnum.PRESENT.getCode().equals(checkedResourceViewDTO.getSaleType())) {
            return null;
        }
        BrandCampaignGroupWakeupTypeEnum wakeupTypeEnum = BrandCampaignGroupWakeupTypeEnum.getByCode(checkedResourceViewDTO.getWakeupType());
        AssertUtil.notNull(wakeupTypeEnum, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "唤端类型不能为空");
        // 校验唤端参数
        validateWakeupSchema(checkedResourceViewDTO);

        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        if (BrandCampaignGroupStatusEnum.EDITED.getCode().equals(campaignGroupViewDTO.getStatus()) ||
                BrandCampaignGroupStatusEnum.UNLOCKED.getCode().equals(campaignGroupViewDTO.getStatus())) {
            return null;
        }
        // 唤端设置仅草稿才能改
        Integer dbWakeupType = campaignGroupViewDTO.getWakeupViewDTO().getWakeupType();
        AssertUtil.assertTrue(wakeupTypeEnum.getCode().equals(dbWakeupType), BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR, "唤端配置不允许修改");

        return null;
    }

    /**
     * 唤端schema校验
     * @param viewDTO
     */
    private void validateWakeupSchema(CampaignGroupCheckedResourceViewDTO viewDTO) {
        if (Objects.equals(viewDTO.getWakeupType(), BrandCampaignGroupWakeupTypeEnum.NON_WAKEUP.getCode())) {
            return;
        }
        AssertUtil.notEmpty(viewDTO.getSchemaConfigViewDTOList(),BrandOneBPBaseErrorCode.PARAM_REQUIRED,"请选择唤端");
        viewDTO.getSchemaConfigViewDTOList().forEach(item -> {
            AssertUtil.notNull(item.getSchemaId(),BrandOneBPBaseErrorCode.PARAM_REQUIRED,"请选择唤端APP");
            SchemaEnum schemaEnum = CommonEnum.of(item.getSchemaId().intValue(), SchemaEnum.class);
            AssertUtil.notNull(schemaEnum,BrandOneBPBaseErrorCode.PARAM_BREAK_RULE,"唤端选择不正确");
            if (schemaEnum.equals(SchemaEnum.WEIXIN_XIAOCHENGXU)) {
                AssertUtil.notNull(item.getSchemaConfigDetailViewDTO(), BrandOneBPBaseErrorCode.PARAM_BREAK_RULE, schemaEnum.getDesc() + "唤端配置不正确");
                AssertUtil.assertTrue(StringUtils.isNotBlank(item.getSchemaConfigDetailViewDTO().getAppId()), BrandOneBPBaseErrorCode.PARAM_BREAK_RULE, "请填写小程序ID");
                AssertUtil.assertTrue(item.getSchemaConfigDetailViewDTO().getAppId().startsWith("gh_"), BrandOneBPBaseErrorCode.PARAM_BREAK_RULE, "小程序ID的格式不正确");
                AssertUtil.assertTrue(StringUtils.isNotBlank(item.getSchemaConfigDetailViewDTO().getAppPath()), BrandOneBPBaseErrorCode.PARAM_BREAK_RULE, "请填写AppPath");
            }
        });
    }
}
