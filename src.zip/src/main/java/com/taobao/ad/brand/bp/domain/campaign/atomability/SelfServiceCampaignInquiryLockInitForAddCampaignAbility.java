package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryLockViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryPolicyViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignInquiryAssignTypeEnum;
import com.alibaba.ad.nb.ssp.constant.common.MediaScopeEnum;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.common.constant.campaigngroup.CampaignGroupConstant;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CustomerRepository;
import com.taobao.ad.brand.bp.domain.memeber.MemberRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignInquiryLockInitForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignInquiryLockAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCampaignInquiryLockInitForAddCampaignAbility implements ICampaignInquiryLockInitForAddCampaignAbility, SelfServiceAtomAbilityRouter {
    private final MemberRepository memberRepository;
    private final CustomerRepository customerRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignInquiryLockAbilityParam abilityParam) {
        CampaignInquiryLockViewDTO campaignInquiryLockViewDTO = abilityParam.getAbilityTarget();
        ProductViewDTO productViewDTO = abilityParam.getProductViewDTO();
        AssertUtil.notNull(campaignInquiryLockViewDTO, "询锁量信息不能为空");
        AssertUtil.notNull(productViewDTO, "二级产品不能为空");
        // 产品优先级
        Integer priority = productViewDTO.getPriority();
        if(priority == null){
            //三环没有产品优先级，二环产品上默认 50为兜底
            if(MediaScopeEnum.TAO_OUT.getCode().equals(productViewDTO.getMediaScope())){
                priority=50;
            }
            if(MediaScopeEnum.SITE_OUT.getCode().equals(productViewDTO.getMediaScope())){
                priority=99;
            }
        }
        campaignInquiryLockViewDTO.setSspProductPriority(priority);
        // 设置客户优先级
        Long customerMemberId = memberRepository.getTargetMemberIdByMemberId(serviceContext.getMemberId());
        String customerPriority = customerRepository.getMemberPriority(serviceContext, Objects.isNull(customerMemberId)?serviceContext.getMemberId():customerMemberId);
        if (StringUtils.isNotBlank(customerPriority)) {
            campaignInquiryLockViewDTO.setCustomerPriority(customerPriority);
        } else {
            campaignInquiryLockViewDTO.setCustomerPriority(CampaignGroupConstant.CUSTOMER_PRIORITY_DEFAULT);
        }
        //询锁量策略
        CampaignInquiryPolicyViewDTO campaignInquiryPolicyViewDTO = Optional.ofNullable(campaignInquiryLockViewDTO.getCampaignInquiryPolicyViewDTO()).orElse(new CampaignInquiryPolicyViewDTO());
        campaignInquiryPolicyViewDTO.setInquiryAssignType(BrandCampaignInquiryAssignTypeEnum.INTELLIGENCE.getCode());
        campaignInquiryLockViewDTO.setCampaignInquiryPolicyViewDTO(campaignInquiryPolicyViewDTO);
        return null;
    }
}
