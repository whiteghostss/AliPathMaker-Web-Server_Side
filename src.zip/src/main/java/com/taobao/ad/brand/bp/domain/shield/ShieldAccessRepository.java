package com.taobao.ad.brand.bp.domain.shield;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.dto.rule.RuleCheckResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.shield.ShieldSyncTextDTO;

import java.util.List;
import java.util.Map;

/**
 * 风控校验
 *
 * @author gxg
 * @date 2023/10/16
 */
public interface ShieldAccessRepository {

    /**
     * 校验名称
     *
     * @param textList 待校验的文字
     * @return 校验结果
     */
    List<ShieldSyncTextDTO> textAccessBatchCheck(List<String> textList);


    /**
     * 多处需要名称校验
     *  逻辑统一处理
     * @param text 待校验名称
     */
    void textAccessCheck(String text);

    /**
     * 商品智能投放校验
     * @param serviceContext
     * @param itemId
     * @return
     */
    RuleCheckResultViewDTO checkFeedSmartAccess(ServiceContext serviceContext, Long itemId);

    /**
     * 商品智能投放校验
     * @param serviceContext
     * @param itemIds
     * @return
     */
    Map<Long, RuleCheckResultViewDTO> checkFeedSmartAccessBatch(ServiceContext serviceContext, List<Long> itemIds);
}
