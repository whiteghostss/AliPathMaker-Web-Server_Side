package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.monitor.CampaignMonitorViewDTO;
import com.alibaba.ad.brand.sdk.constant.monitor.BrandThirdMonitorTypeEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignMonitorInitForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignMonitorAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCampaignMonitorInitForAddCampaignAbility implements ICampaignMonitorInitForAddCampaignAbility, SelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignMonitorAbilityParam abilityParam) {
        CampaignMonitorViewDTO campaignMonitorViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(campaignMonitorViewDTO, "计划监测信息不能为空");

        campaignMonitorViewDTO.setThirdMonitorType(BrandThirdMonitorTypeEnum.API.getCode());
        return null;
    }
}
