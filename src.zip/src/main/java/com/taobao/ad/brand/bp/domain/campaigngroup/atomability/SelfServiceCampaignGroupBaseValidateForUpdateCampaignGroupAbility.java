package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupBaseValidateForUpdateCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupBaseAbilityParam;
import org.springframework.stereotype.Component;

import java.util.List;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_ILLEGAL;

@Component
@BusinessAbility
public class SelfServiceCampaignGroupBaseValidateForUpdateCampaignGroupAbility
        implements ICampaignGroupBaseValidateForUpdateCampaignGroupAbility, SelfServiceAtomAbilityRouter {

    private static final List<Integer> validUpdateCampaignGroupStatusList = Lists.newArrayList(
            BrandCampaignGroupStatusEnum.DRAFT.getCode(),
            BrandCampaignGroupStatusEnum.ORDER_ING.getCode()
    );

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupBaseAbilityParam abilityParam) {
        CampaignGroupViewDTO dbCampaignGroupViewDTO = abilityParam.getDbCampaignGroupViewDTO();
        // 校验订单状态
        AssertUtil.assertTrue(validUpdateCampaignGroupStatusList.contains(dbCampaignGroupViewDTO.getStatus()), PARAM_ILLEGAL,
                String.format("当前订单状态(%s)不支持更新", BrandCampaignGroupStatusEnum.getByCode(dbCampaignGroupViewDTO.getStatus()).getDesc()));

        return null;
    }
}
