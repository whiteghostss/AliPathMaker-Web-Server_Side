package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.guarantee.CampaignGuaranteeViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignInquiryAssignTypeEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignInitForUpdateCastDateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignUpdateCastDateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSelfCampaignInitForUpdateCastDateAbility
    extends DefaultCampaignInitForUpdateCastDateAbility implements ICampaignInitForUpdateCastDateAbility, BrandSelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignUpdateCastDateAbilityParam abilityParam) {
        CampaignViewDTO campaignViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        campaignViewDTO.setStartTime(abilityParam.getStartTime());
        campaignViewDTO.setEndTime(abilityParam.getEndTime());
        if(Constant.CAN_INQUIRY_LOCK_STATUS.contains(dbCampaignViewDTO.getStatus())){
            campaignViewDTO.setStatus(BrandCampaignStatusEnum.NEW.getCode());
        }
        //部分周期智能分配 修改投放日期清除预定量
        if (BrandCampaignInquiryAssignTypeEnum.PERIOD_PART_INTELLIGENCE.getCode().equals(dbCampaignViewDTO.getCampaignInquiryLockViewDTO().getCampaignInquiryPolicyViewDTO().getInquiryAssignType())) {
            campaignViewDTO.getCampaignInquiryLockViewDTO().getCampaignInquiryPolicyViewDTO().setSchedulePolicyList(Lists.newArrayList());
        }
        if(BizCampaignToolsHelper.isTwoCPT(dbCampaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope(),dbCampaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterUnit())){
            Long oriCptSingleAmount = dbCampaignViewDTO.getCampaignGuaranteeViewDTO().getCptAmount()/ (BrandDateUtil.getDateRange(dbCampaignViewDTO.getStartTime(),dbCampaignViewDTO.getEndTime())+1);
            Long afterCptTotalAmount = oriCptSingleAmount * (BrandDateUtil.getDateRange(abilityParam.getStartTime(),abilityParam.getEndTime())+1);
            Long afterCpmTotalAmount = dbCampaignViewDTO.getCampaignGuaranteeViewDTO().getAmount()/dbCampaignViewDTO.getCampaignGuaranteeViewDTO().getCptAmount()*afterCptTotalAmount;
            CampaignGuaranteeViewDTO campaignGuaranteeViewDTO = new CampaignGuaranteeViewDTO();
            campaignGuaranteeViewDTO.setCptAmount(afterCptTotalAmount);
            campaignGuaranteeViewDTO.setAmount(afterCpmTotalAmount);
            campaignViewDTO.setCampaignGuaranteeViewDTO(campaignGuaranteeViewDTO);
//            campaignViewDTO.getCampaignGuaranteeViewDTO().setCptAmount(afterCptTotalAmount);
//            campaignViewDTO.getCampaignGuaranteeViewDTO().setAmount(afterCpmTotalAmount);
        }
        return null;
    }

}
