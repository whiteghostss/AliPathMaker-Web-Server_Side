package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.threadpooltask.CampaignUpdateTaskIdentifier;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignUpdateAllAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBatchAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_REQUIRED;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultCampaignUpdateAllAbility implements ICampaignUpdateAllAbility {

    private final CampaignUpdateTaskIdentifier campaignUpdateTaskIdentifier;
    private final CampaignRepository campaignRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignBatchAbilityParam abilityParam) {
        List<CampaignViewDTO> campaignViewDTOList = abilityParam.getAbilityTargets();
        AssertUtil.notEmpty(campaignViewDTOList,"计划列表为空，不可更新");
        boolean hasAdd = campaignViewDTOList.stream().anyMatch(item -> item.getId() == null);
        AssertUtil.assertTrue(!hasAdd, PARAM_REQUIRED, "有计划id为空的数据");

        if(campaignViewDTOList.size() == 1){
            updateCampaignAll(serviceContext, campaignViewDTOList.get(0));
        }else{
            TaskStream.consume(campaignUpdateTaskIdentifier, campaignViewDTOList,
                            (campaignViewDTO, index) -> updateCampaignAll(serviceContext, campaignViewDTO))
                    .commit().getResultList();
        }
        return null;
    }

    private Void updateCampaignAll(ServiceContext serviceContext,  CampaignViewDTO campaignViewDTO) {
        campaignRepository.updateCampaignAll(serviceContext, Lists.newArrayList(campaignViewDTO));
        campaignRepository.updateCampaignAdzoneAll(serviceContext, Lists.newArrayList(campaignViewDTO));
        return null;
    }


}
