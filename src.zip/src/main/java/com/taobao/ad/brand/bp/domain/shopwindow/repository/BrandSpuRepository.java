package com.taobao.ad.brand.bp.domain.shopwindow.repository;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandBundleViewDTO;
import com.taobao.ad.brand.bp.client.dto.spu.SpuMarketingRuleResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.spu.SpuMarketingRuleViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSpuViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.query.BrandSpuQueryViewDTO;

import java.util.List;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/6/26
 **/
public interface BrandSpuRepository {


    List<BrandSpuViewDTO> findSpuList(ServiceContext serviceContext, BrandSpuQueryViewDTO brandSpuQueryViewDTO);

    BrandSpuViewDTO get(ServiceContext serviceContext, Long id);

    BrandSpuViewDTO getDetail(ServiceContext serviceContext, BrandSpuQueryViewDTO brandSpuQueryViewDTO);

    /**
     * SPU规则门槛校验
     *
     * @param serviceContext
     * @param spuRuleParamList
     * @return
     */
    List<SpuMarketingRuleResultViewDTO> checkSpuMarketingRule(ServiceContext serviceContext, List<SpuMarketingRuleViewDTO> spuRuleParamList);
}
