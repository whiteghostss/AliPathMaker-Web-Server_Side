package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.adzone.CampaignAdzoneViewDTO;
import com.alibaba.ad.brand.dto.campaign.audience.CampaignTargetScenarioViewDTO;
import com.alibaba.ad.brand.dto.campaign.sale.CampaignSaleViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignAdzoneInitForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignSaleInitForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignAdzoneAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignSaleAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultCampaignSaleInitForUpdateCampaignAbility implements ICampaignSaleInitForUpdateCampaignAbility {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignSaleAbilityParam abilityParam) {
        CampaignSaleViewDTO campaignSaleViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(campaignSaleViewDTO,"计划售卖信息不允许为空");
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        AssertUtil.notNull(dbCampaignViewDTO,"计划不存在");

        CampaignSaleViewDTO dbCampaignSaleViewDTO = dbCampaignViewDTO.getCampaignSaleViewDTO();

        campaignSaleViewDTO.setSaleType(dbCampaignSaleViewDTO.getSaleType());
        campaignSaleViewDTO.setCustomerTemplateId(dbCampaignSaleViewDTO.getCustomerTemplateId());
        campaignSaleViewDTO.setSaleGroupId(dbCampaignSaleViewDTO.getSaleGroupId());
        campaignSaleViewDTO.setResourcePackageProductId(dbCampaignSaleViewDTO.getResourcePackageProductId());
        campaignSaleViewDTO.setContractId(dbCampaignSaleViewDTO.getContractId());
        campaignSaleViewDTO.setSubContractId(dbCampaignSaleViewDTO.getSubContractId());
        campaignSaleViewDTO.setCustomerId(dbCampaignSaleViewDTO.getCustomerId());
        campaignSaleViewDTO.setSaleBusinessLine(dbCampaignSaleViewDTO.getSaleBusinessLine());
        campaignSaleViewDTO.setSaleProductLine(dbCampaignSaleViewDTO.getSaleProductLine());
        campaignSaleViewDTO.setProductConfigType(dbCampaignSaleViewDTO.getProductConfigType());
        campaignSaleViewDTO.setSaleUnit(dbCampaignSaleViewDTO.getSaleUnit());
        return null;
    }
}
