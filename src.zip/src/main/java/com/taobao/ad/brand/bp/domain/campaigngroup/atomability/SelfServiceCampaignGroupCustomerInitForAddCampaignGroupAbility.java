package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.customer.CampaignGroupCustomerViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupContractMemberTypeEnum;
import com.taobao.ad.brand.bp.common.constant.campaigngroup.CampaignGroupConstant;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CustomerRepository;
import com.taobao.ad.brand.bp.domain.memeber.MemberRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupCustomerInitForAddCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupCustomerAbilityParam;
import com.taobao.ad.simba.user.consts.RelMemberType;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Objects;
import java.util.Optional;

@Component
@BusinessAbility
public class SelfServiceCampaignGroupCustomerInitForAddCampaignGroupAbility
        implements ICampaignGroupCustomerInitForAddCampaignGroupAbility, SelfServiceAtomAbilityRouter {
    @Resource
    private CustomerRepository customerRepository;
    @Resource
    private MemberRepository memberRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupCustomerAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        CampaignGroupCustomerViewDTO customerViewDTO = Optional.ofNullable(abilityParam.getAbilityTarget()).orElse(new CampaignGroupCustomerViewDTO());
        // 设置账号类型
        Integer relMemberType = memberRepository.getRelMemberType(serviceContext.getMemberId());
        // 客户member
        Long customerMemberId = memberRepository.getTargetMemberIdByMemberId(serviceContext.getMemberId(), relMemberType);
        customerViewDTO.setCustomerMemberId(customerMemberId);
        if (Objects.isNull(relMemberType)) {
            customerViewDTO.setContractMemberType(CampaignGroupContractMemberTypeEnum.CUSTOMER.getCode());
        } else if (RelMemberType.AGENCY.getValue().equals(relMemberType) || RelMemberType.XIAOER_PROXY.getValue().equals(relMemberType)) {
            customerViewDTO.setContractMemberType(CampaignGroupContractMemberTypeEnum.XMEMBER.getCode());
        }
        // 客户优先级
        String customerPriority = customerRepository.getMemberPriority(serviceContext, customerMemberId);
        if (StringUtils.isNotBlank(customerPriority)) {
            customerViewDTO.setCustomerPriority(customerPriority);
        } else {
            customerViewDTO.setCustomerPriority(CampaignGroupConstant.CUSTOMER_PRIORITY_DEFAULT);
        }
        // 销售服务对象
        customerViewDTO.setCustomerId(0L);
        campaignGroupViewDTO.setCampaignGroupCustomerViewDTO(customerViewDTO);
        return null;
    }
}
