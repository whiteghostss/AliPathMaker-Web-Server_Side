package com.taobao.ad.brand.bp.domain.campaigngroup.ability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityInject;
import com.alibaba.abf.isolation.spec.common.ReduceType;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.keyword.CampaignKeywordViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.customer.CampaignGroupCustomerViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.dto.common.BrandViewDTO;
import com.alibaba.ad.brand.dto.globaltag.GlobalTagViewDTO;
import com.alibaba.ad.brand.sdk.constant.audience.field.BrandTargetTypeEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignProgrammaticEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.nb.ssp.constant.common.DictTypeEnum;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.client.context.ScheduleExportContext;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignImpressionViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignTemplateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesContractBrandViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.export.CampaignComposeResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.CrowdViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resource.MediaResourceViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.template.TemplateViewDTO;
import com.taobao.ad.brand.bp.client.enums.CommonEnum;
import com.taobao.ad.brand.bp.client.enums.campaign.RecommendCrowdTypeEnum;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.export.ScheduleExportContentTypeEnum;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.brand.BrandRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.SalesContractRepository;
import com.taobao.ad.brand.bp.domain.dmp.CrowdRepository;
import com.taobao.ad.brand.bp.domain.dooh.repository.DoohRepository;
import com.taobao.ad.brand.bp.domain.feed.FeedRepository;
import com.taobao.ad.brand.bp.domain.inventory.InventoryRepository;
import com.taobao.ad.brand.bp.domain.perform.PerformRepository;
import com.taobao.ad.brand.bp.domain.resource.ResourceRepository;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.ability.BizCampaignGroupComposeAbilityExt;
import com.taobao.ad.brand.bp.domain.ssp.ProductRepository;
import com.taobao.ad.brand.perform.client.dto.globaltag.query.GlobalTagQueryViewDTO;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author jixiu.lj
 * @date 2023/3/29 13:41
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizScheduleExportCampaignComposeAbility extends BizScheduleExportBaseComposeAbility {

    private final ProductRepository productRepository;
    private final ResourcePackageRepository resourcePackageRepository;
    private final ResourceRepository resourceRepository;
    private final InventoryRepository inventoryRepository;
    private final PerformRepository performRepository;
    private final DoohRepository doohRepository;
    private final CampaignGroupRepository campaignGroupRepository;
    private final FeedRepository feedRepository;
    private final SalesContractRepository salesContractRepository;
    private final CrowdRepository crowdRepository;
    private final BrandRepository brandRepository;

    @AbilityInject(reduce = ReduceType.FIRST)
    private final BizCampaignGroupComposeAbilityExt bizCampaignGroupComposeAbilityExt;


    /**
     * 计划数据组装
     *
     * @param serviceContext
     * @param scheduleExportContext
     * @return
     */
    public CampaignComposeResultViewDTO compose(ServiceContext serviceContext,
                                                ScheduleExportContext scheduleExportContext) {
        CampaignComposeResultViewDTO result = new CampaignComposeResultViewDTO();
        // 计划模板信息
        Map<Long, CampaignTemplateViewDTO> initCampaignTemplateMap = new HashMap<>();
        // 全量计划信息查询（含计划模板信息）
        List<CampaignViewDTO> fullCampaignViewDTOList = buildCampaignList(serviceContext, scheduleExportContext, initCampaignTemplateMap);
        RogerLogger.info("exportCompose fullCampaignViewDTOList {}  initCampaignTemplateMap  {} ", JSON.toJSONString(fullCampaignViewDTOList), JSON.toJSONString(initCampaignTemplateMap));

        // 产品Map
        Map<Long, ProductViewDTO> productDTOMap = buildProductMap(serviceContext, scheduleExportContext, fullCampaignViewDTOList);

        // 售卖分组map
        Map<ScheduleExportContentTypeEnum, List<ResourcePackageSaleGroupViewDTO>> saleGroupModelMap = buildSaleGroupList(serviceContext, scheduleExportContext);

        // 售卖分组-计划map
        Map<Long, List<CampaignViewDTO>> saleGroupCampaignModelMap = buildSaleGroupCampaignModelMap(serviceContext, scheduleExportContext, fullCampaignViewDTOList);

        // resource map
        Map<Long, MediaResourceViewDTO> resourceDTOMap = buildResourceMap(serviceContext, scheduleExportContext, fullCampaignViewDTOList);

        // 定向字典map
        EnumMap<BrandTargetTypeEnum, Map<String, String>> dictionaryMap = buildDictionaryMap(serviceContext, scheduleExportContext);

        // 售卖产品线字典
        Map<String, String> sspProductlineMap = buildSspProductlineMap(serviceContext, scheduleExportContext);

        // 地域map
        Map<String, String> productAreaMap = buildProductAreaMap(serviceContext, scheduleExportContext);

        // 智能预留 三方DSP字典
        List<CommonViewDTO> dspList = buildDspList(serviceContext);

        // 计划-创意模板 中间Map
        Map<Long, List<Long>> campaignTemplateMap = buildCampaignCreativeTemplateMap(serviceContext, fullCampaignViewDTOList, initCampaignTemplateMap);
        RogerLogger.info("exportCompose campaignTemplateMap {}", JSON.toJSONString(campaignTemplateMap));

        // 创意模板map 中间Map
        Map<Long, TemplateViewDTO> templateViewDTOMap = buildTemplateViewDTOMap(serviceContext, fullCampaignViewDTOList, campaignTemplateMap);

        // 计划-创意模板ViewDTO
        Map<Long, List<TemplateViewDTO>> creativeTemplateMap = buildCampaignCreativeTemplateMap(campaignTemplateMap, templateViewDTOMap);

        // 跨域计划是否使用了跨域模板
        Map<Long, Boolean> campaignHasCrossTemplate = buildCampaignHasCrossTemplate(fullCampaignViewDTOList, templateViewDTOMap, initCampaignTemplateMap);
        RogerLogger.info("exportCompose campaignHasCrossTemplate {}", JSON.toJSONString(campaignHasCrossTemplate));

        // 计划-mr
        Map<Long, Set<Long>> campaignMaterialRuleMap = buildCampaignMaterialRuleMap(fullCampaignViewDTOList, creativeTemplateMap, resourceDTOMap, productDTOMap, campaignHasCrossTemplate);

        // 计划-库存信息
        Map<Long, String> inventoryUdDetailsDTOMap = buildInventoryUdDetailsDTOMap(serviceContext, scheduleExportContext, fullCampaignViewDTOList);

        // 计划-非精准配置信息
        Map<Long, Set<String>> udImprecisionDTOMap = buildInventoryUdImprecisionDTOMap(serviceContext, scheduleExportContext, fullCampaignViewDTOList);

        List<CommonViewDTO> showmaxCrowdList = this.buildShowmaxCrowdList(serviceContext, scheduleExportContext, fullCampaignViewDTOList);

        //计划-关键词列表
        Map<Long, CampaignKeywordViewDTO> keywordMap = buildKeywordMap(serviceContext, scheduleExportContext, fullCampaignViewDTOList);

        Map<Long, BrandViewDTO> brandMap = buildBrandMap(serviceContext, scheduleExportContext, fullCampaignViewDTOList);

        scheduleExportContext.setCampaignViewDTOList(Lists.newArrayList(fullCampaignViewDTOList));
        scheduleExportContext.setProductDTOMap(Maps.newHashMap(productDTOMap));
        scheduleExportContext.setCampaignMaterialRuleMap(campaignMaterialRuleMap);
        scheduleExportContext.setCampaignHasCrossTemplate(campaignHasCrossTemplate);
        result.setCampaignGroupViewDTO(scheduleExportContext.getCampaignGroupViewDTO());
        result.setCampaignMaterialRuleMap(campaignMaterialRuleMap);
        result.setDictionaryMap(dictionaryMap);
        result.setCreativeTemplateMap(creativeTemplateMap);
        result.setProductAreaMap(productAreaMap);
        result.setInventoryUdDetailsDTOMap(inventoryUdDetailsDTOMap);
        result.setSaleGroupCampaignModelMap(saleGroupCampaignModelMap);
        result.setSaleGroupMap(saleGroupModelMap);
        result.setInventoryUdImprecisionDTOMap(udImprecisionDTOMap);
        result.setResourceMap(resourceDTOMap);
        result.setProductMap(productDTOMap);
        result.setDspList(dspList);
        result.setShowmaxCrowdList(showmaxCrowdList);
        result.setSspProductlineMap(sspProductlineMap);
        result.setKeywordMap(keywordMap);
        result.setBrandMap(brandMap);
        return result;
    }

    private Map<Long, BrandViewDTO> buildBrandMap(ServiceContext serviceContext, ScheduleExportContext scheduleExportContext, List<CampaignViewDTO> campaignViewDTOList) {
        List<Long> brandIds = campaignViewDTOList.stream()
                .filter(t -> t.getCampaignRightsViewDTO() != null && CollectionUtils.isNotEmpty(t.getCampaignRightsViewDTO().getExcludeBrandIds()))
                .flatMap(t -> t.getCampaignRightsViewDTO().getExcludeBrandIds().stream())
                .distinct()
                .collect(Collectors.toList());
        List<BrandViewDTO> brandViewDTOS = brandRepository.queryBrand(brandIds);
        return brandViewDTOS.stream().collect(Collectors.toMap(BrandViewDTO::getBrandId, Function.identity(), (v1, v2) -> v1));
    }

    /**
     * @param serviceContext
     * @return
     */
    public Map<String, String> buildSspProductlineMap(ServiceContext serviceContext, ScheduleExportContext scheduleExportContext) {
        Map<String, String> result = Maps.newHashMap();

        // 产品线字典
        List<CommonViewDTO> sspProductlineList = productRepository.getSSPDict("ssp_product_line_id");

        if (CollectionUtils.isNotEmpty(sspProductlineList)) {
            return sspProductlineList.stream().collect(Collectors.toMap(CommonViewDTO::getValue, CommonViewDTO::getName, (k1, k2) -> k1));
        }
        return result;
    }

    /**
     * @param serviceContext
     * @return
     */
    public EnumMap<BrandTargetTypeEnum, Map<String, String>> buildDictionaryMap(ServiceContext serviceContext,
                                                                                ScheduleExportContext scheduleExportContext) {
        EnumMap<BrandTargetTypeEnum, Map<String, String>> result = Maps.newEnumMap(BrandTargetTypeEnum.class);

        // 性别字典
        List<CommonViewDTO> genderDict = productRepository.getSSPDict(BrandTargetTypeEnum.GENDER_PLUS.getKey());

        if (CollectionUtils.isNotEmpty(genderDict)) {
            result.put(BrandTargetTypeEnum.GENDER_PLUS, genderDict.stream().collect(Collectors.toMap(CommonViewDTO::getValue, CommonViewDTO::getName)));
        }
        // 设备机型字典
        List<CommonViewDTO> modelDict = productRepository.getSSPDict(BrandTargetTypeEnum.MODEL.getKey());
        if (CollectionUtils.isNotEmpty(modelDict)) {
            result.put(BrandTargetTypeEnum.MODEL, modelDict.stream().collect(Collectors.toMap(CommonViewDTO::getValue, CommonViewDTO::getName)));
        }
        // 设备字典
        List<CommonViewDTO> deviceDict = productRepository.getSSPDict(BrandTargetTypeEnum.NEW_DEVICE.getKey());
        if (CollectionUtils.isNotEmpty(deviceDict)) {
            result.put(BrandTargetTypeEnum.NEW_DEVICE, deviceDict.stream().collect(Collectors.toMap(CommonViewDTO::getValue, CommonViewDTO::getName)));
        }
        // 设备字典
        List<CommonViewDTO> deviceMediaDict = productRepository.getSSPDict(BrandTargetTypeEnum.DEVICE_MEDIA.getKey());
        if (CollectionUtils.isNotEmpty(deviceMediaDict)) {
            result.put(BrandTargetTypeEnum.DEVICE_MEDIA, deviceMediaDict.stream().collect(Collectors.toMap(CommonViewDTO::getValue, CommonViewDTO::getName)));
        }
        // UA来源
        List<CommonViewDTO> uaDict = productRepository.getSSPDict(DictTypeEnum.DICT_UA_TYPE.getType());
        if (CollectionUtils.isNotEmpty(uaDict)) {
            result.put(BrandTargetTypeEnum.UA, uaDict.stream().collect(Collectors.toMap(CommonViewDTO::getValue, CommonViewDTO::getName, (v1, v2) -> v2)));
        }
        // APP版本
        List<CommonViewDTO> appDict = productRepository.getSSPDict(DictTypeEnum.DICT_APP_TYPE.getType());
        if (CollectionUtils.isNotEmpty(appDict)) {
            result.put(BrandTargetTypeEnum.APP_VERSION, appDict.stream().collect(Collectors.toMap(CommonViewDTO::getValue, CommonViewDTO::getName, (v1, v2) -> v2)));
        }
        // 位置位序
        List<CommonViewDTO> precedenceDict = productRepository.getSSPDict(DictTypeEnum.DICT_PRECEDENCE_TYPE.getType());
        if (CollectionUtils.isNotEmpty(precedenceDict)) {
            result.put(BrandTargetTypeEnum.PRECEDENCE, precedenceDict.stream().collect(Collectors.toMap(CommonViewDTO::getValue, CommonViewDTO::getName, (v1, v2) -> v2)));
        }
        // 位置位序
        List<CommonViewDTO> positionDict = productRepository.getSSPDict(DictTypeEnum.POSITION_PLUS.getType());
        if (CollectionUtils.isNotEmpty(positionDict)) {
            result.put(BrandTargetTypeEnum.POSITION_PLUS_MEDIA, positionDict.stream().collect(Collectors.toMap(CommonViewDTO::getValue, CommonViewDTO::getName, (v1, v2) -> v2)));
        }
        //频道
        List<CommonViewDTO> sspChannelDict = productRepository.getSSPChannel();
        if (CollectionUtils.isNotEmpty(sspChannelDict)) {
            result.put(BrandTargetTypeEnum.CHANNEL, sspChannelDict.stream().collect(Collectors.toMap(CommonViewDTO::getValue, CommonViewDTO::getName, (v1, v2) -> v2)));
        }
        //全域标签
        List<GlobalTagViewDTO> globalTagViewDTOList = performRepository.findGlobalTagList(serviceContext, new GlobalTagQueryViewDTO());
        if (CollectionUtils.isNotEmpty(globalTagViewDTOList)) {
            result.put(BrandTargetTypeEnum.ALI_CROWD_SCORE, globalTagViewDTOList.stream().collect(Collectors.toMap(it -> it.getId().toString(), GlobalTagViewDTO::getName, (v1, v2) -> v2)));
        }
        // 媒体兴趣标签
        List<CommonViewDTO> firstMediaInterestLabelDict = productRepository.getSSPDict(DictTypeEnum.FIRST_MEDIA_INTEREST_LABEL.getType());
        List<CommonViewDTO> secondMediaInterestLabelDict = productRepository.getSSPDict(DictTypeEnum.SECOND_MEDIA_INTEREST_LABEL.getType());
        if (CollectionUtils.isNotEmpty(firstMediaInterestLabelDict)) {
            result.put(BrandTargetTypeEnum.MEDIA_INTEREST_LABEL, firstMediaInterestLabelDict.stream().collect(Collectors.toMap(CommonViewDTO::getValue, CommonViewDTO::getName, (v1, v2) -> v2)));
        }
        if (CollectionUtils.isNotEmpty(secondMediaInterestLabelDict)) {
            if (result.containsKey(BrandTargetTypeEnum.MEDIA_INTEREST_LABEL)) {
                result.get(BrandTargetTypeEnum.MEDIA_INTEREST_LABEL).putAll(secondMediaInterestLabelDict.stream().collect(Collectors.toMap(CommonViewDTO::getValue, CommonViewDTO::getName, (v1, v2) -> v2)));
            } else {
                result.put(BrandTargetTypeEnum.MEDIA_INTEREST_LABEL, secondMediaInterestLabelDict.stream().collect(Collectors.toMap(CommonViewDTO::getValue, CommonViewDTO::getName, (v1, v2) -> v2)));
            }
        }
        // 开屏刷次定向
        List<CommonViewDTO> splashAdSeq = productRepository.getSSPDict(DictTypeEnum.SPLASH_AD_SEQ.getType());
        if (CollectionUtils.isNotEmpty(splashAdSeq)) {
            result.put(BrandTargetTypeEnum.SPLASH_AD_SEQ, splashAdSeq.stream().collect(Collectors.toMap(CommonViewDTO::getValue, CommonViewDTO::getName, (v1, v2) -> v2)));
        }
        // 天攻优选模式
        List<CommonViewDTO> doohOptimized = productRepository.getSSPDict(DictTypeEnum.OOH_JSD_OPTIMIZED.getType());
        if (CollectionUtils.isNotEmpty(doohOptimized)) {
            result.put(BrandTargetTypeEnum.OOH_JSD_OPTIMIZED, doohOptimized.stream().collect(Collectors.toMap(CommonViewDTO::getValue, CommonViewDTO::getName, (v1, v2) -> v2)));
        }
        // 天攻行业
        List<CommonViewDTO> doohIndustry = doohRepository.getPriorityIndustryList();
        if (CollectionUtils.isNotEmpty(doohIndustry)) {
            result.put(BrandTargetTypeEnum.OOH_JSD_INDUSTRY, doohIndustry.stream().collect(Collectors.toMap(commonViewDTO -> commonViewDTO.getId().toString(), CommonViewDTO::getName, (v1, v2) -> v2)));
        }
        return result;
    }

    /**
     * 获取地域字典
     *
     * @param serviceContext
     * @param scheduleExportContext
     * @return
     */
    public Map<String, String> buildProductAreaMap(ServiceContext serviceContext,
                                                   ScheduleExportContext scheduleExportContext) {
        Map<String, String> productAreaMap = productRepository.getAreaList(serviceContext).stream()
                .collect(Collectors.toMap(CommonViewDTO::getValue, CommonViewDTO::getName));
        if (MapUtils.isEmpty(productAreaMap)) {
            return Maps.newHashMap();
        }
        return productAreaMap;
    }

    /**
     * 根据订单查询分组计划信息
     *
     * @param serviceContext
     */
    public Map<Long, List<CampaignViewDTO>> buildSaleGroupCampaignModelMap(ServiceContext serviceContext,
                                                                           ScheduleExportContext scheduleExportContext,
                                                                           List<CampaignViewDTO> campaignModelList) {
        // 按照分组ID聚合
        return campaignModelList.stream()
                .filter(campaignViewDTO -> Objects.nonNull(campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId()))
                .collect(Collectors.groupingBy(campaignViewDTO -> campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId()));
    }

    /**
     * 根据订单关联的分组ID查询全量分组信息，按照分组类型分类
     *
     * @param serviceContext
     * @return
     */
    public Map<ScheduleExportContentTypeEnum, List<ResourcePackageSaleGroupViewDTO>> buildSaleGroupList(ServiceContext serviceContext, ScheduleExportContext scheduleExportContext) {
        CampaignGroupViewDTO campaignGroupModel = scheduleExportContext.getCampaignGroupViewDTO();
        // 取订单关联的所有分组
        Set<Long> saleGroupIds = Optional.ofNullable(campaignGroupModel
                        .getCampaignGroupSaleGroupViewDTO()
                        .getSaleGroupInfoViewDTOList()).orElse(Lists.newArrayList())
                .stream()
                .map(SaleGroupInfoViewDTO::getSaleGroupId)
                .filter(Objects::nonNull).collect(Collectors.toSet());
        if (CollectionUtils.isEmpty(saleGroupIds)) {
            return Maps.newHashMap();
        }

        // 查询全量的 购买 ｜ 补量 ｜ 配送 售卖分组
        ResourcePackageQueryViewDTO resourcePackageQueryViewDTO = new ResourcePackageQueryViewDTO();
        resourcePackageQueryViewDTO.setSaleGroupIdList(Lists.newArrayList(saleGroupIds));
        ResourcePackageQueryOption resourcePackageQueryOption = ResourcePackageQueryOption.builder().needSetting(true).needProduct(true).build();
        List<ResourcePackageSaleGroupViewDTO> saleGroupList = resourcePackageRepository.getSaleGroupList(serviceContext, resourcePackageQueryViewDTO, resourcePackageQueryOption);

        // 按照分组类型分类
        return saleGroupList.stream()
                .filter(saleGroup -> Objects.nonNull(saleGroup.getSaleType()))
                .collect(Collectors.groupingBy(saleGroup -> CommonEnum.of(saleGroup.getSaleType(), ScheduleExportContentTypeEnum.class)));
    }

    /**
     * 获取资源Map
     *
     * @return
     */
    public Map<Long, MediaResourceViewDTO> buildResourceMap(ServiceContext serviceContext,
                                                            ScheduleExportContext scheduleExportContext,
                                                            List<CampaignViewDTO> campaignModelList) {
        // 获取计划上绑定的资源位单值
        Set<Long> resourceIds = campaignModelList.stream()
                .filter(campaignViewDTO -> CollectionUtils.isNotEmpty(campaignViewDTO.getCampaignResourceViewDTO().getSspResourceIds()))
                .map(campaignViewDTO -> {
                    List<Long> sspResourceIds = campaignViewDTO.getCampaignResourceViewDTO().getSspResourceIds();
                    return sspResourceIds.get(0);
                }).collect(Collectors.toSet());
        List<MediaResourceViewDTO> resourceList = resourceRepository.getResourceList(Lists.newArrayList(resourceIds));
        return resourceList.stream().collect(Collectors.toMap(MediaResourceViewDTO::getId, Function.identity(), (k1, k2) -> k1));
    }

    /**
     * 构建 计划ID-非精准打底信息Map，满足下述条件的计划可以创建非精准打底
     * 1. 计划是三环PDB , 2. 计划下的子计划不能跨媒体（未来可能放开） 3. 计划下的分天锁量信息全部是非精准或者某一天需要打底
     * 需要注意的是未下单的计划展示空，而不应该默认为没有打底配置
     * 与 BizCampaignQueryServiceImpl#getCampaignBottomDateList逻辑保持一致
     *
     * @return
     */
    public Map<Long, Set<String>> buildInventoryUdImprecisionDTOMap(ServiceContext serviceContext,
                                                                    ScheduleExportContext scheduleExportContext,
                                                                    List<CampaignViewDTO> campaignModelList) {
        return bizCampaignGroupComposeAbilityExt.buildInventoryUdImprecisionDTOMap(serviceContext, scheduleExportContext, campaignModelList);
    }

    public Map<Long, CampaignKeywordViewDTO> buildKeywordMap(ServiceContext serviceContext,
                                                             ScheduleExportContext scheduleExportContext,
                                                             List<CampaignViewDTO> campaignModelList){
        return bizCampaignGroupComposeAbilityExt.buildKeywordMap(serviceContext, scheduleExportContext, campaignModelList);
    }

    /**
     * 获取计划-是否程序化投放Map
     * 对于二环和跨域产品都为是，三环则看库存
     *
     * @param serviceContext
     * @return
     */
    public Map<Long, String> buildInventoryUdDetailsDTOMap(ServiceContext serviceContext, ScheduleExportContext scheduleExportContext, List<CampaignViewDTO> campaignModelList) {

        Map<Long, String> result = Maps.newHashMap();
        List<CampaignViewDTO> filterCampaignList = campaignModelList.stream()
                .filter(t -> BrandCampaignProgrammaticEnum.SYSTEM_CAST.getCode().equals(t.getSspProgrammatic()))
                .collect(Collectors.toList());
        Map<Long, BrandBoolEnum> campaignInventoryDetailsMap = inventoryRepository.buildCampaignInventoryDetailsMap(serviceContext, filterCampaignList);

        campaignModelList.forEach(campaignViewDTO -> {
            Long campaignId = campaignViewDTO.getId();
            if (campaignInventoryDetailsMap.containsKey(campaignId)) {
                BrandBoolEnum brandBoolEnum = campaignInventoryDetailsMap.get(campaignId);
                result.put(campaignId, brandBoolEnum.getDesc());
            } else {
                result.put(campaignId, Constant.SEPARATOR_LINE);
            }
        });
        return result;
    }

    /**
     * 构建"配置媒体打底"
     * 如果存在媒体打底配置，则返回set，否则返回null，表示未设置媒体打底-否
     *
     * @return 是否配置媒体打底
     */
    private Set<String> buildMediaBottom(List<CampaignImpressionViewDTO> bottomDateViewDTOList) {

        Optional<CampaignImpressionViewDTO> anyUnqualified = bottomDateViewDTOList.stream()
                .filter(campaignImpressionDTO -> campaignImpressionDTO.getStatus() != CampaignImpressionViewDTO.CampaignImpressionStatusEnum.UNQUALIFIED)
                .findAny();
        // 子计划库存的每一天全部为unqualified即为不用配置媒体打底
        if (!anyUnqualified.isPresent()) {
            return null;
        }


        Optional<CampaignImpressionViewDTO> anyNotReady = bottomDateViewDTOList.stream()
                .filter(campaignImpressionDTO -> campaignImpressionDTO.getStatus() == CampaignImpressionViewDTO.CampaignImpressionStatusEnum.NOT_ORDER
                        || campaignImpressionDTO.getStatus() == CampaignImpressionViewDTO.CampaignImpressionStatusEnum.NOT_READY)
                .findAny();
        // 存在某子计划状态待定则媒体打底配置待定
        if (anyNotReady.isPresent()) {
            return Sets.newHashSet();
        }

        // 配置媒体打底 日期集合
        if (CollectionUtils.isNotEmpty(bottomDateViewDTOList)) {
            Set<String> mediaBottomDateSet = new HashSet<>();

            bottomDateViewDTOList.forEach(bottomDateViewDTO -> {
                // 已排除其余状态
                if (bottomDateViewDTO.getStatus() == CampaignImpressionViewDTO.CampaignImpressionStatusEnum.NOT_ORDER
                        || bottomDateViewDTO.getStatus() == CampaignImpressionViewDTO.CampaignImpressionStatusEnum.NOT_READY
                        || bottomDateViewDTO.getStatus() == CampaignImpressionViewDTO.CampaignImpressionStatusEnum.UNQUALIFIED) {
                    return;
                }
                // QUALIFIED状态
                mediaBottomDateSet.add(BrandDateUtil.date2String(bottomDateViewDTO.getDate(), BrandDateUtil.DATE_FORMAT_YYYYMMDD_TYPE_2));
            });
            return mediaBottomDateSet;
        }
        return null;
    }

    private List<CommonViewDTO> buildDspList(ServiceContext serviceContext) {
        return productRepository.getDspList(serviceContext);
    }

    /**
     * 构造showmax人群
     * @param serviceContext
     * @param scheduleExportContext
     * @return
     */
    public List<CommonViewDTO> buildShowmaxCrowdList(ServiceContext serviceContext, ScheduleExportContext scheduleExportContext, List<CampaignViewDTO> fullCampaignViewDTOList) {
        List<CommonViewDTO> resultList = Lists.newArrayList();
        Set<Integer> recommendCrowdTypeSet = fullCampaignViewDTOList.stream()
                .filter(campaign -> campaign.getCampaignCrowdScenarioViewDTO() != null && campaign.getCampaignCrowdScenarioViewDTO().getCampaignShowmaxCrowdViewDTO() != null && campaign.getCampaignCrowdScenarioViewDTO().getCampaignShowmaxCrowdViewDTO().getShowmaxCrowdType() != null)
                .map(campaign -> campaign.getCampaignCrowdScenarioViewDTO().getCampaignShowmaxCrowdViewDTO().getShowmaxCrowdType()).collect(Collectors.toSet());
        if (CollectionUtils.isEmpty(recommendCrowdTypeSet)) {
            return resultList;
        }
        CampaignGroupViewDTO campaignGroup = scheduleExportContext.getCampaignGroupViewDTO();
        if (campaignGroup == null) {
            campaignGroup = campaignGroupRepository.getCampaignGroup(serviceContext, scheduleExportContext.getCampaignGroupId());
        }
        Long customerMemberId = Optional.ofNullable(campaignGroup.getCampaignGroupCustomerViewDTO()).map(CampaignGroupCustomerViewDTO::getCustomerMemberId).orElse(campaignGroup.getMemberId());
        List<Long> brandIds = getCustomerMemberBrandIds(customerMemberId);
        for (Integer recommendCrowdType : recommendCrowdTypeSet) {
            List<CommonViewDTO> tagCommonViewDTOList = null;
            // 查询标签
            if (RecommendCrowdTypeEnum.needLabelForQueryTemplateCrowd(recommendCrowdType)) {
                tagCommonViewDTOList = crowdRepository.queryShowmaxCrowdTagList(serviceContext, customerMemberId, recommendCrowdType);
            } else {
                // 查询人群
                List<CrowdViewDTO> crowdViewDTOList = crowdRepository.findRecommendCrowd(serviceContext, customerMemberId, recommendCrowdType, null, StringUtils.join(brandIds, ","));
                if (CollectionUtils.isNotEmpty(crowdViewDTOList)) {
                    tagCommonViewDTOList = crowdViewDTOList.stream().map(crowdViewDTO -> {
                        CommonViewDTO commonViewDTO = new CommonViewDTO();
                        commonViewDTO.setId(crowdViewDTO.getCrowdId());
                        commonViewDTO.setName(crowdViewDTO.getCrowdName());
                        return commonViewDTO;
                    }).collect(Collectors.toList());
                }
            }
            if (CollectionUtils.isNotEmpty(tagCommonViewDTOList)){
                resultList.addAll(tagCommonViewDTOList);
            }
        }

//        if (campaignGroup.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream().anyMatch(item -> SaleProductLineEnum.SHOW_MAX.getValue().equals(item.getSaleProductLine()))){
//            for (RecommendCrowdTypeEnum recommendCrowdTypeEnum : RecommendCrowdTypeEnum.getShowmaxCrowdTypeEnumList()) {
//                List<CommonViewDTO> tagCommonViewDTOList = runAbilitySpi(ShowmaxCrowdSpi.class, extension -> extension.queryShowmaxCrowdTagList(serviceContext, customerMemberId, brandIds),
//                        ShowmaxCrowdSpi.getShowmaxCrowdSpiBizCode(recommendCrowdTypeEnum.getCode()));
//                if (CollectionUtils.isNotEmpty(tagCommonViewDTOList)){
//                    resultList.addAll(tagCommonViewDTOList);
//                }
//            }
//        }
        return resultList;
    }

    private List<Long> getCustomerMemberBrandIds(Long customerMemberId) {
        Long shopId = feedRepository.getShopIdByMemberId(customerMemberId);
        List<SalesContractBrandViewDTO> salesContractBrandViewDTOS = salesContractRepository.findBrandList(shopId);
        return salesContractBrandViewDTOS.stream().map(SalesContractBrandViewDTO::getBrandId).distinct().collect(Collectors.toList());
    }
}
