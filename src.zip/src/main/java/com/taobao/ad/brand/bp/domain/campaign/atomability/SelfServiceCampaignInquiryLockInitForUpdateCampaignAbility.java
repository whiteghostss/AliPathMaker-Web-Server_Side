package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryLockViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryViewDTO;
import com.alibaba.ad.nb.ssp.constant.common.BooleanEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignInquiryLockInitForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignInquiryLockAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCampaignInquiryLockInitForUpdateCampaignAbility implements ICampaignInquiryLockInitForUpdateCampaignAbility, SelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignInquiryLockAbilityParam abilityParam) {
        CampaignInquiryLockViewDTO campaignInquiryLockViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        AssertUtil.notNull(campaignInquiryLockViewDTO, "询锁量信息不能为空");
        AssertUtil.notNull(campaignViewDTO, "计划不能为空");
        AssertUtil.notNull(dbCampaignViewDTO, "计划不存在");

        CampaignInquiryLockViewDTO dbCampaignInquiryLockViewDTO = dbCampaignViewDTO.getCampaignInquiryLockViewDTO();

        campaignInquiryLockViewDTO.setCustomerPriority(dbCampaignInquiryLockViewDTO.getCustomerPriority());
        campaignInquiryLockViewDTO.setSspProductPriority(dbCampaignInquiryLockViewDTO.getSspProductPriority());
        campaignInquiryLockViewDTO.setCampaignMediaInquiryViewDTO(dbCampaignInquiryLockViewDTO.getCampaignMediaInquiryViewDTO());
        campaignInquiryLockViewDTO.setCampaignDelayReleaseViewDTO(dbCampaignInquiryLockViewDTO.getCampaignDelayReleaseViewDTO());
        campaignInquiryLockViewDTO.setCampaignMandatoryLockViewDTO(dbCampaignInquiryLockViewDTO.getCampaignMandatoryLockViewDTO());
        campaignInquiryLockViewDTO.setInquirySuccessTime(dbCampaignInquiryLockViewDTO.getInquirySuccessTime());
        campaignInquiryLockViewDTO.setLockCallBackTime(dbCampaignInquiryLockViewDTO.getLockCallBackTime());
        campaignInquiryLockViewDTO.setLockExpireTime(dbCampaignInquiryLockViewDTO.getLockExpireTime());
        campaignInquiryLockViewDTO.setFirstOnlineTime(dbCampaignInquiryLockViewDTO.getFirstOnlineTime());

        //重新编辑计划时间，只保量锁量成功预定量，且清空计划排期预定量比例设置
        campaignInquiryLockViewDTO.setCampaignInquiryPolicyViewDTO(dbCampaignInquiryLockViewDTO.getCampaignInquiryPolicyViewDTO());
        campaignInquiryLockViewDTO.setCampaignInquiryViewDTOList(dbCampaignInquiryLockViewDTO.getCampaignInquiryViewDTOList());
        boolean noUpdateDate = dbCampaignViewDTO.getStartTime().equals(campaignViewDTO.getStartTime())
                && dbCampaignViewDTO.getEndTime().equals(campaignViewDTO.getEndTime());
        if(!noUpdateDate){
            List<CampaignInquiryViewDTO> lockSuccessCampaignInquiryViewDTOList = Optional.ofNullable(dbCampaignInquiryLockViewDTO.getCampaignInquiryViewDTOList()).orElse(Lists.newArrayList())
                    .stream().filter(item -> BooleanEnum.TRUE.getCode().equals(item.getStatus())).collect(Collectors.toList());
            campaignInquiryLockViewDTO.setCampaignInquiryViewDTOList(lockSuccessCampaignInquiryViewDTOList);
            if(campaignInquiryLockViewDTO.getCampaignInquiryPolicyViewDTO() != null){
                campaignInquiryLockViewDTO.getCampaignInquiryPolicyViewDTO().setInquiryAssignType(null);
                campaignInquiryLockViewDTO.getCampaignInquiryPolicyViewDTO().setSchedulePolicyList(null);
            }
        }

        return null;
    }
}
