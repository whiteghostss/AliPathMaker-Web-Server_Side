package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.realsettle.CampaignGroupRealSettleViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupProcessStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupSettleInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.settle.CampaignGroupRealSettleSaveViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.settle.CampaignGroupRealSettleOpTypeEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.Env;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupRealSettleValidateForSaveAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupRealSettleValidateForSaveAbilityParam;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR;
import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_REQUIRED;

@Component
@BusinessAbility
public class DefaultCampaignGroupRealSettleValidateForSaveAbility implements ICampaignGroupRealSettleValidateForSaveAbility {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupRealSettleValidateForSaveAbilityParam abilityParam) {
        CampaignGroupRealSettleSaveViewDTO realSettleSaveViewDTO = abilityParam.getAbilityTarget();
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        AssertUtil.notNull(realSettleSaveViewDTO.getRealSettleOpTypeEnum(), PARAM_REQUIRED, "实结操作类型不能为空");
        AssertUtil.notEmpty(realSettleSaveViewDTO.getRealSettleInfoViewDTOList(), PARAM_REQUIRED, "实结配置信息不能为空");

        // 校验是否可以发起
        AssertUtil.assertTrue(BrandCampaignGroupStatusEnum.FINISHED.getCode().equals(campaignGroupViewDTO.getStatus()), BIZ_BREAK_RULE_ERROR,
            String.format("订单状态(%s)不支持发起实结", BrandCampaignGroupStatusEnum.getByCode(campaignGroupViewDTO.getStatus()).getDesc()));
        if (Env.isProd()) {
            boolean isStopCast = campaignGroupViewDTO.getCampaignGroupRealSettleViewDTO().getStopCastTime() != null;
            Date campaignGroupFinishDate = isStopCast ? BrandDateUtil.getDateFullMidnight(campaignGroupViewDTO.getCampaignGroupRealSettleViewDTO().getStopCastTime()) : campaignGroupViewDTO.getEndTime();
            AssertUtil.assertTrue(System.currentTimeMillis() - campaignGroupFinishDate.getTime() > 24 * 60 * 60 * 1000, BIZ_BREAK_RULE_ERROR, "请于订单完成日期T+2之后再录入实结信息");
        }

        // 流程状态
        CampaignGroupRealSettleViewDTO realSettleViewDTO = campaignGroupViewDTO.getCampaignGroupRealSettleViewDTO();
        AssertUtil.assertTrue(!BrandCampaignGroupProcessStatusEnum.APPROVE_ING.getCode().equals(realSettleViewDTO.getRealSettleProcessStatus()), PARAM_REQUIRED, "当前实结配置正处在审核中，不支持该操作");

        // 个性化校验
        if (realSettleSaveViewDTO.getRealSettleOpTypeEnum() == CampaignGroupRealSettleOpTypeEnum.SUBMIT) {
            Map<Long, SaleGroupInfoViewDTO> saleGroupInfoMap = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList()
                    .stream().collect(Collectors.toMap(SaleGroupInfoViewDTO::getSaleGroupId, Function.identity(), (v1, v2) -> v1));
            for (CampaignGroupSaleGroupSettleInfoViewDTO realSettleInfoViewDTO : realSettleSaveViewDTO.getRealSettleInfoViewDTOList()) {
                String saleGroupName = StringUtils.isNotBlank(realSettleInfoViewDTO.getSaleGroupName()) ? realSettleInfoViewDTO.getSaleGroupName() : String.valueOf(realSettleInfoViewDTO.getSaleGroupId());
                AssertUtil.notNull(realSettleInfoViewDTO.getSaleGroupId(), PARAM_REQUIRED, String.format("分组(%s)的分组ID不能为空", saleGroupName));
                SaleGroupInfoViewDTO saleGroupInfoViewDTO = saleGroupInfoMap.get(realSettleInfoViewDTO.getSaleGroupId());
                AssertUtil.assertTrue(saleGroupInfoViewDTO != null, PARAM_REQUIRED, String.format("分组(%s)不存在", saleGroupName));
                AssertUtil.notNull(realSettleInfoViewDTO.getRealSettlePrice(), PARAM_REQUIRED, String.format("分组(%s)的实结金额不能为空", saleGroupName));
                AssertUtil.assertTrue(realSettleInfoViewDTO.getRealSettlePrice() <= saleGroupInfoViewDTO.getBudget(), PARAM_REQUIRED, String.format("分组(%s)的实结金额不能超过分组总金额", saleGroupName));
            }
        }

        return null;
    }
}
