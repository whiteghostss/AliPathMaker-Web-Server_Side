package com.taobao.ad.brand.bp.domain.campaign.workflow;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.audience.CampaignTargetScenarioViewDTO;
import com.alibaba.ad.brand.dto.campaign.boost.CampaignBoostViewDTO;
import com.alibaba.ad.brand.dto.campaign.budget.CampaignBudgetViewDTO;
import com.alibaba.ad.brand.dto.campaign.creative.CampaignCreativeControllerViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdScenarioViewDTO;
import com.alibaba.ad.brand.dto.campaign.dooh.CampaignDoohViewDTO;
import com.alibaba.ad.brand.dto.campaign.effect.CampaignEffectProxyViewDTO;
import com.alibaba.ad.brand.dto.campaign.ext.CampaignExtViewDTO;
import com.alibaba.ad.brand.dto.campaign.frequence.CampaignFrequencyViewDTO;
import com.alibaba.ad.brand.dto.campaign.guarantee.CampaignGuaranteeViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryLockViewDTO;
import com.alibaba.ad.brand.dto.campaign.monitor.CampaignMonitorViewDTO;
import com.alibaba.ad.brand.dto.campaign.price.CampaignPriceViewDTO;
import com.alibaba.ad.brand.dto.campaign.realtime.CampaignRealTimeOptimizeViewDTO;
import com.alibaba.ad.brand.dto.campaign.resource.CampaignResourceViewDTO;
import com.alibaba.ad.brand.dto.campaign.sale.CampaignRightsViewDTO;
import com.alibaba.ad.brand.dto.campaign.sale.CampaignSaleViewDTO;
import com.alibaba.ad.brand.dto.campaign.scroll.CampaignScrollViewDTO;
import com.alibaba.ad.brand.dto.campaign.selfservice.CampaignSelfServiceViewDTO;
import com.alibaba.ad.brand.dto.campaign.smartreserved.CampaignSmartReservedViewDTO;
import com.alibaba.ad.brand.dto.campaign.smooth.CampaignSmoothViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignBatchDeleteViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.BizCampaignCommandWorkflowExt;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignBudgetWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignCalculateWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignWorkflowParam;

import java.util.List;
import java.util.Optional;

/**
 * 默认实现
 */
@BusinessAbility
public class DefaultCampaignCommandWorkflowExtImpl implements BizCampaignCommandWorkflowExt {


    /**
     * 构建扩展参数
     *
     * @param serviceContext
     * @param campaignViewDTO
     * @return
     */
    @Override
    public BizCampaignWorkflowParam buildParamForAddOrUpdate(ServiceContext serviceContext,
                                                              CampaignViewDTO campaignViewDTO) {

        return null;
    }

    /**
     * 新增场景后置处理逻辑
     *
     * @param serviceContext
     * @param campaignViewDTO
     * @return
     */
    @Override
    public Void afterAddCampaign(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, BizCampaignWorkflowParam bizCampaignWorkflowParam) {

        return null;
    }

    /**
     * 新增异常处理
     *
     * @param serviceContext
     * @param campaignIdList
     * @return
     */
    @Override
    public Void throwingAddCampaign(ServiceContext serviceContext, List<Long> campaignIdList) {

        return null;
    }

    /**
     * 修改场景后置处理逻辑
     *
     * @param serviceContext
     * @param campaignViewDTO
     * @param dbCampaignViewDTO
     * @param bizCampaignWorkflowParam
     * @return
     */
    @Override
    public Void afterUpdateCampaign(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, CampaignViewDTO dbCampaignViewDTO, BizCampaignWorkflowParam bizCampaignWorkflowParam) {

        return null;
    }

    /**
     * 业务删除前置处理
     *
     * @param serviceContext
     * @param campaignViewDTO
     * @return
     */
    @Override
    public Void beforeForDelete(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {
        return null;
    }

    /**
     * 删除场景后置处理逻辑
     *
     * @param serviceContext
     * @param delCampaignViewDTOList
     * @return
     */
    @Override
    public Void afterBatchDeleteCampaign(ServiceContext serviceContext, List<CampaignViewDTO> delCampaignViewDTOList) {

        return null;
    }

    /**
     * 业务批量删除校验
     *
     * @param serviceContext
     * @param batchDeleteViewDTO
     * @return
     */
    @Override
    public Void beforeBatchDeleteCampaign(ServiceContext serviceContext, CampaignBatchDeleteViewDTO batchDeleteViewDTO) {

        return null;
    }

    @Override
    public BizCampaignCalculateWorkflowParam buildParamForCalculate(ServiceContext serviceContext,
                                                                     CampaignViewDTO campaignViewDTO) {
        return null;
    }

    /**
     * 构建扩展参数
     *
     * @param serviceContext
     * @param campaignViewDTO
     * @return
     */
    @Override
    public BizCampaignBudgetWorkflowParam buildParamForAssignBudget(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {

        return null;
    }

    @Override
    public Void rebuildCalSaleGroupInfo(ServiceContext serviceContext, ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO, SaleGroupInfoViewDTO saleGroupInfoViewDTO, List<CampaignViewDTO> campaignViewDTOList) {
        return null;
    }

//    @Override
//    public Void batchSwitchCampaign(ServiceContext serviceContext, List<CampaignViewDTO> operateList,
//                                     SwitchEnum  switchEnum){
//        return null;
//    }

//    @Override
//    public List<BizCampaignAutoReleaseWorkflowParam> buildAutoReleaseDelayLockParamExt(ServiceContext serviceContext,
//                                                                                        CampaignDelayLockApplyViewDTO campaignDelayLockApplyViewDTO){
//        return null;
//    }

    @Override
    public Void handleAfterCancelCampaignGroup(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, List<CampaignViewDTO> campaignTreeList) {
        return null;
    }

    @Override
    public Void handleAfterStopCampaignGroup(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO) {
        return null;
    }

    @Override
    public Void beforeAutoAddCampaign(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, List<CampaignViewDTO> campaignViewDTOList) {
        return null;
    }

    @Override
    public Void afterAutoAddCampaign(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, List<Long> campaignIds) {
        return null;
    }

    @Override
    public Void afterAutoUpdateCampaign(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, List<Long> addCampaignIds) {
        return null;
    }

    @Override
    public Void afterForUpdateCastDate(ServiceContext serviceContext, CampaignViewDTO dbCampaignViewDTO, CampaignViewDTO campaignViewDTO) {
        return null;
    }

    /**
     * 设置计划默认信息
     * @param campaignViewDTO
     */
    protected void resetCampaignDefaultObject(CampaignViewDTO campaignViewDTO) {
        campaignViewDTO.setCampaignSaleViewDTO(Optional.ofNullable(campaignViewDTO.getCampaignSaleViewDTO()).orElse(new CampaignSaleViewDTO()));
        campaignViewDTO.setCampaignRightsViewDTO(Optional.ofNullable(campaignViewDTO.getCampaignRightsViewDTO()).orElse(new CampaignRightsViewDTO()));
        campaignViewDTO.setCampaignInquiryLockViewDTO(Optional.ofNullable(campaignViewDTO.getCampaignInquiryLockViewDTO()).orElse(new CampaignInquiryLockViewDTO()));
        campaignViewDTO.setCampaignSmartReservedViewDTO(Optional.ofNullable(campaignViewDTO.getCampaignSmartReservedViewDTO()).orElse(new CampaignSmartReservedViewDTO()));
        campaignViewDTO.setCampaignDoohViewDTO(Optional.ofNullable(campaignViewDTO.getCampaignDoohViewDTO()).orElse(new CampaignDoohViewDTO()));
        campaignViewDTO.setCampaignSelfServiceViewDTO(Optional.ofNullable(campaignViewDTO.getCampaignSelfServiceViewDTO()).orElse(new CampaignSelfServiceViewDTO()));
        campaignViewDTO.setCampaignResourceViewDTO(Optional.ofNullable(campaignViewDTO.getCampaignResourceViewDTO()).orElse(new CampaignResourceViewDTO()));
        campaignViewDTO.setCampaignSmoothViewDTO(Optional.ofNullable(campaignViewDTO.getCampaignSmoothViewDTO()).orElse(new CampaignSmoothViewDTO()));
        campaignViewDTO.setCampaignGuaranteeViewDTO(Optional.ofNullable(campaignViewDTO.getCampaignGuaranteeViewDTO()).orElse(new CampaignGuaranteeViewDTO()));
        campaignViewDTO.setCampaignScrollViewDTO(Optional.ofNullable(campaignViewDTO.getCampaignScrollViewDTO()).orElse(new CampaignScrollViewDTO()));
        campaignViewDTO.setCampaignBoostViewDTO(Optional.ofNullable(campaignViewDTO.getCampaignBoostViewDTO()).orElse(new CampaignBoostViewDTO()));
        campaignViewDTO.setCampaignPriceViewDTO(Optional.ofNullable(campaignViewDTO.getCampaignPriceViewDTO()).orElse(new CampaignPriceViewDTO()));
        campaignViewDTO.setCampaignBudgetViewDTO(Optional.ofNullable(campaignViewDTO.getCampaignBudgetViewDTO()).orElse(new CampaignBudgetViewDTO()));
        campaignViewDTO.setCampaignMonitorViewDTO(Optional.ofNullable(campaignViewDTO.getCampaignMonitorViewDTO()).orElse(new CampaignMonitorViewDTO()));
        campaignViewDTO.setCampaignRealTimeOptimizeViewDTO(Optional.ofNullable(campaignViewDTO.getCampaignRealTimeOptimizeViewDTO()).orElse(new CampaignRealTimeOptimizeViewDTO()));
        campaignViewDTO.setCampaignFrequencyViewDTO(Optional.ofNullable(campaignViewDTO.getCampaignFrequencyViewDTO()).orElse(new CampaignFrequencyViewDTO()));
        campaignViewDTO.setCampaignTargetScenarioViewDTO(Optional.ofNullable(campaignViewDTO.getCampaignTargetScenarioViewDTO()).orElse(new CampaignTargetScenarioViewDTO()));
        campaignViewDTO.setCampaignCrowdScenarioViewDTO(Optional.ofNullable(campaignViewDTO.getCampaignCrowdScenarioViewDTO()).orElse(new CampaignCrowdScenarioViewDTO()));
        campaignViewDTO.setCampaignCreativeControllerViewDTO(Optional.ofNullable(campaignViewDTO.getCampaignCreativeControllerViewDTO()).orElse(new CampaignCreativeControllerViewDTO()));
        campaignViewDTO.setCampaignEffectProxyViewDTO(Optional.ofNullable(campaignViewDTO.getCampaignEffectProxyViewDTO()).orElse(new CampaignEffectProxyViewDTO()));
        campaignViewDTO.setCampaignExtViewDTO(Optional.ofNullable(campaignViewDTO.getCampaignExtViewDTO()).orElse(new CampaignExtViewDTO()));
    }
}
