package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.nb.ssp.constant.newproduct.DeliveryTargetEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignSaleGroupResourceDeliveryTargetViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupPvBudgetForCalculateUpdateSaleGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupPvBudgetForCalculateUpdateSaleGroupAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Optional;

@Component
@BusinessAbility
public class DefaultSaleGroupPvBudgetForCalculateUpdateSaleGroupAbility implements ISaleGroupPvBudgetForCalculateUpdateSaleGroupAbility {

    @Resource
    private CampaignGroupRepository campaignGroupRepository;
    @Resource
    private CampaignRepository campaignRepository;


    @Override
    public Void handle(ServiceContext context, SaleGroupPvBudgetForCalculateUpdateSaleGroupAbilityParam abilityParam) {
        SaleGroupInfoViewDTO saleGroupInfoViewDTO = abilityParam.getAbilityTarget();
        ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO = abilityParam.getResourcePackageSaleGroupViewDTO();
        List<CampaignViewDTO> levelOneCampaigns = abilityParam.getLevelOneCampaignViewDTOList();
        if(CollectionUtils.isEmpty(levelOneCampaigns)){
            levelOneCampaigns = campaignRepository.queryCampaignList(context, CampaignQueryViewDTO.builder().campaignLevel(
                BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode()).saleGroupId(saleGroupInfoViewDTO.getSaleGroupId()).build());
        }
        Long pv = calculateSaleGroupPv(resourcePackageSaleGroupViewDTO, levelOneCampaigns);
        Long calcBudget = levelOneCampaigns.stream().mapToLong(item->item.getCampaignBudgetViewDTO().getDiscountTotalMoney()).sum();
        Long pvPrice = BigDecimal.valueOf(calcBudget).multiply(BigDecimal.valueOf(Constant.DEFAULT_CPM_PV_RATIO)).divide(BigDecimal.valueOf(pv), 0, RoundingMode.HALF_UP).longValue();
        saleGroupInfoViewDTO.setUnitPrice(pvPrice);
        saleGroupInfoViewDTO.setAmount(pv);
        saleGroupInfoViewDTO.setCalcBudget(calcBudget);
        campaignGroupRepository.updateSaleGroupPart(context, Lists.newArrayList(saleGroupInfoViewDTO));
//        campaignGroupRepository.addOrUpdateSaleGroupPart(context,saleGroupInfoViewDTO.getCampaignGroupId(), Lists.newArrayList(saleGroupInfoViewDTO));
        return null;
    }

    private long calculateSaleGroupPv(ResourcePackageSaleGroupViewDTO saleGroup, List<CampaignViewDTO> oneLevelCampaignList) {
        long pv = oneLevelCampaignList.stream().mapToLong(v -> v.getCampaignGuaranteeViewDTO().getAmount()).sum();
        //存在二三环计划的需要向上取整到cpm
        Integer predictExposureRate = getPredictExposureRate(saleGroup);
        if (!onlyTeXiuCampaign(oneLevelCampaignList)) {
            pv = new BigDecimal(predictExposureRate * pv / 10000).setScale(-3, RoundingMode.UP).longValue();
            AssertUtil.assertTrue(pv >= 1000, "分组曝光量不足1cpm");
        } else {
            pv = new BigDecimal(predictExposureRate * pv / 10000).setScale(0, RoundingMode.UP).longValue();
        }
        return pv;
    }

    private boolean onlyTeXiuCampaign(List<CampaignViewDTO> campaignViewDTOList) {
        if (CollectionUtils.isEmpty(campaignViewDTOList)) {
            return false;
        }
        for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
            if(!BizCampaignToolsHelper.isTXorShowmaxCampaign(campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope(),
                campaignViewDTO.getCampaignResourceViewDTO().getSspProductLineId())){
                return false;
            }
        }
        return true;
    }

    /**
     * 获取曝光量折扣
     */
    private Integer getPredictExposureRate(ResourcePackageSaleGroupViewDTO saleGroup) {
        Integer predictExposureRate = (int)Constant.RATIO_EXPAND_MULTIPLE;
        if (CollectionUtils.isNotEmpty(saleGroup.getResourceDeliveryTargetList())) {
            Optional<CampaignSaleGroupResourceDeliveryTargetViewDTO> priceOptional = saleGroup.getResourceDeliveryTargetList().stream().filter(
                v -> DeliveryTargetEnum.EXPOSURE.getValue().equals(v.getDeliveryTarget())).findFirst();
            if (priceOptional.isPresent()) {
                predictExposureRate = Optional.ofNullable(priceOptional.get().getAmountDiscount()).orElse((int)Constant.RATIO_EXPAND_MULTIPLE);
            }
        } else if (saleGroup.getPredictExposureRate() != null) {
            predictExposureRate = saleGroup.getPredictExposureRate();
        }
        return predictExposureRate;
    }
}

