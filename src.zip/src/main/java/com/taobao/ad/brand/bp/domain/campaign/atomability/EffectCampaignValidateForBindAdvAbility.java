package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.EffectAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignValidateForBindAdvAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignValidateForBindOrUnBindAdvAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EffectCampaignValidateForBindAdvAbility implements ICampaignValidateForBindAdvAbility, EffectAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignValidateForBindOrUnBindAdvAbilityParam abilityParam) {
        CampaignViewDTO campaignViewDTO = abilityParam.getAbilityTarget();
        //一级计划才能绑定adv
        AssertUtil.assertTrue(campaignViewDTO.getCampaignLevel().equals(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode()),"一级计划才可以绑定adv");
        return null;
    }
}
