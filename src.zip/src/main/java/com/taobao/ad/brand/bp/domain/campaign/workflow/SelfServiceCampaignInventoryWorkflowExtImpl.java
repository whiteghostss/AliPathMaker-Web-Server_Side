package com.taobao.ad.brand.bp.domain.campaign.workflow;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryLockViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.alibaba.ad.brand.sdk.constant.cartitem.BrandCartItemTypeEnum;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.context.DomainMetaqMessageBodyContext;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignDelayLockApplyViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignInquiryOperateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignScheduleViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignGroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.SaleGroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignEventEnum;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignScheduleOperateTypeEnum;
import com.taobao.ad.brand.bp.client.enums.message.DomainMessageTypeEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.cart.repository.CartItemRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.workflow.router.SelfServiceExtensionRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignAutoReleaseWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignInventoryWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.IMessageAsyncSendAbility;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.param.MessageAsyncSendAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Description:
 * <p>
 * date: 2023/10/24 2:51 PM
 *
 * @author shiyan
 * @version 1.0
 */
@Service
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCampaignInventoryWorkflowExtImpl extends DefaultCampaignInventoryWorkflowExtImpl implements SelfServiceExtensionRouter {

    private final CampaignGroupRepository campaignGroupRepository;
    private final CampaignRepository campaignRepository;
    private final IMessageAsyncSendAbility messageAsyncSendAbility;
    private final ICampaignStructureQueryAbility campaignStructureQueryAbility;
    private final CartItemRepository cartItemRepository;

    @Override
    public BizCampaignInventoryWorkflowParam buildParamForInventory(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO) {
        AssertUtil.notNull(inquiryOperateViewDTO, "查询参数不能为空");
        AssertUtil.notEmpty(inquiryOperateViewDTO.getCampaignIdList(), "计划不能为空");
        AssertUtil.notNull(inquiryOperateViewDTO.getOperateType(), "操作类型不允许为空");

        List<CampaignViewDTO> campaignTreeViewDTOList = findCampaignTreeList(serviceContext, inquiryOperateViewDTO.getCampaignIdList());
        AssertUtil.notEmpty(campaignTreeViewDTOList,"计划不存在或已被删除");

        List<CampaignGroupViewDTO> campaignGroupList = findCampaignGroupList(serviceContext, campaignTreeViewDTOList);

        return BizCampaignInventoryWorkflowParam.builder().campaignTreeViewDTOList(campaignTreeViewDTOList)
                .campaignGroupViewDTOList(campaignGroupList).build();
    }

    @Override
    public void afterInventoryInquiryOrLock(ServiceContext serviceContext, BizCampaignInventoryWorkflowParam inventoryWorkflowParam, CampaignScheduleOperateTypeEnum operateTypeEnum) {
        if (operateTypeEnum == CampaignScheduleOperateTypeEnum.LOCK) {
            Map<Long, CampaignViewDTO> levelOneCampaignMap = inventoryWorkflowParam.getCampaignTreeViewDTOList().stream().collect(Collectors.toMap(item -> item.getId(), Function.identity()));
            for (CampaignScheduleViewDTO campaignScheduleViewDTO : inventoryWorkflowParam.getCampaignScheduleViewDTOList()) {
                if (!BrandCampaignStatusEnum.LOCKING.getCode().equals(campaignScheduleViewDTO.getStatus())) {
                    continue;
                }
                CampaignViewDTO campaignViewDTO = levelOneCampaignMap.get(campaignScheduleViewDTO.getId());
                CartItemViewDTO cartItemViewDTO = cartItemRepository.getCartById(serviceContext, campaignViewDTO.getCampaignSelfServiceViewDTO().getCartItemId());
                if (BrandCartItemTypeEnum.SLIM_ORDER.getCode().equals(cartItemViewDTO.getType())) {
                    fireAsyncMessageEvent(serviceContext, campaignViewDTO, CampaignEventEnum.LOCK);
                }
            }
        }
    }

    @Override
    public Void afterInventoryCallback(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inventoryCallbackViewDTO, BizCampaignInventoryWorkflowParam inventoryWorkflowParam, List<CampaignScheduleViewDTO> campaignScheduleViewDTOList) {
        if(CollectionUtils.isEmpty(inventoryWorkflowParam.getCampaignTreeViewDTOList())){
            return null;
        }
        List<CampaignViewDTO> campaignTreeViewDTOList = inventoryWorkflowParam.getCampaignTreeViewDTOList();
        Map<Long, CampaignScheduleViewDTO> scheduleViewDTOMap = campaignScheduleViewDTOList.stream().collect(Collectors.toMap(CampaignScheduleViewDTO::getId, Function.identity(), (v1, v2) -> v2));
        for (CampaignViewDTO campaignTreeViewDTO : campaignTreeViewDTOList) {
            CampaignScheduleViewDTO campaignScheduleViewDTO = scheduleViewDTOMap.get(campaignTreeViewDTO.getId());
            if(campaignScheduleViewDTO ==null){
                continue;
            }
            //锁量成功回调
            fire(serviceContext, campaignTreeViewDTO, campaignScheduleViewDTO);
        }
        return null;
    }

    @Override
    public List<BizCampaignAutoReleaseWorkflowParam> buildAutoReleaseDelayLockParamExt(ServiceContext serviceContext, CampaignDelayLockApplyViewDTO campaignDelayLockApplyViewDTO) {

        CampaignQueryViewDTO query = new CampaignQueryViewDTO();
        query.setCampaignIds(campaignDelayLockApplyViewDTO.getCampaignIdList());
        query.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
        List<CampaignViewDTO> campaignList = campaignRepository.queryCampaignList(serviceContext, query);
        AssertUtil.notEmpty(campaignList,"未找到对应计划");
        List<CampaignGroupViewDTO> campaignGroupList = campaignGroupRepository.findCampaignGroupByIds(serviceContext,campaignList.stream().map(item->item.getCampaignGroupId()).distinct().collect(
                Collectors.toList()));
        List<Long> saleGroupIds = campaignList.stream().map(item->item.getCampaignSaleViewDTO().getSaleGroupId()).distinct().collect(Collectors.toList());
        List<Long> campaignGroupIds = campaignGroupList.stream().map(item->item.getId()).distinct().collect(Collectors.toList());

        SaleGroupQueryViewDTO saleGroupQueryViewDTO = new SaleGroupQueryViewDTO();
        saleGroupQueryViewDTO.setSaleGroupIds(saleGroupIds);
        saleGroupQueryViewDTO.setCampaignGroupIds(campaignGroupIds);

        List<SaleGroupInfoViewDTO> saleGroupList = campaignGroupRepository.findSaleGroupList(serviceContext,saleGroupQueryViewDTO);
        List<BizCampaignAutoReleaseWorkflowParam> autoReleaseWorkflowParams = Lists.newArrayList();
        for(CampaignViewDTO campaignViewDTO : campaignList){
            BizCampaignAutoReleaseWorkflowParam bizCampaignAutoReleaseWorkflowParam = new BizCampaignAutoReleaseWorkflowParam();
            bizCampaignAutoReleaseWorkflowParam.setCampaignViewDTO(campaignViewDTO);
            CampaignGroupViewDTO campaignGroupViewDTO =  campaignGroupList.stream().filter(item->campaignViewDTO.getCampaignGroupId().equals(item.getId())).findFirst().get();
            bizCampaignAutoReleaseWorkflowParam.setCampaignGroupViewDTO(campaignGroupViewDTO);
            SaleGroupInfoViewDTO saleGroupInfoViewDTO = saleGroupList.stream().filter(
                    item->campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId().equals(item.getSaleGroupId())
                            && campaignViewDTO.getCampaignGroupId().equals(item.getCampaignGroupId())).findFirst().get();
            bizCampaignAutoReleaseWorkflowParam.setSaleGroupInfoViewDTO(saleGroupInfoViewDTO);
            autoReleaseWorkflowParams.add(bizCampaignAutoReleaseWorkflowParam);
        }
        return autoReleaseWorkflowParams;
    }

    /**
     * 锁量成功构建打底单元
     *
     * @param serviceContext
     * @param campaignTreeViewDTO
     * @param campaignScheduleViewDTO
     */
    private void fire(ServiceContext serviceContext, CampaignViewDTO campaignTreeViewDTO, CampaignScheduleViewDTO campaignScheduleViewDTO) {
        RogerLogger.info("计划" + campaignTreeViewDTO.getId() + "info:"+ JSON.toJSON(campaignScheduleViewDTO));
        if (!BrandCampaignStatusEnum.LOCK_SUCCESS.getCode().equals(campaignScheduleViewDTO.getStatus()) && !BrandCampaignStatusEnum.LOCK_FAIL.getCode().equals(campaignScheduleViewDTO.getStatus()) ) {
            RogerLogger.info("计划" + campaignTreeViewDTO.getId() + "非锁量");
            return;
        }
        campaignTreeViewDTO.setStatus(campaignScheduleViewDTO.getStatus());
        CampaignInquiryLockViewDTO campaignInquiryLockViewDTO = Optional.ofNullable(campaignTreeViewDTO.getCampaignInquiryLockViewDTO()).orElse(new CampaignInquiryLockViewDTO());
        campaignInquiryLockViewDTO.setCampaignInquiryViewDTOList(campaignScheduleViewDTO.getInquiryViewDTOList());
        campaignTreeViewDTO.setCampaignInquiryLockViewDTO(campaignInquiryLockViewDTO);
        //事件消息
        RogerLogger.info("计划" + campaignTreeViewDTO.getId() + "fire start");
        CampaignEventEnum campaignEventEnum = BrandCampaignStatusEnum.LOCK_FAIL.getCode().equals(campaignScheduleViewDTO.getStatus()) ? CampaignEventEnum.LOCK_FAILED : CampaignEventEnum.LOCK_SUCCESS;
        fireAsyncMessageEvent(serviceContext,campaignTreeViewDTO, campaignEventEnum);
        RogerLogger.info("计划" + campaignTreeViewDTO.getId() + "fire success");
    }

    /**
     * 生成异步通知事件
     *
     * @param serviceContext
     * @param campaign
     * @param campaignEventEnum
     * @return
     */
    private void fireAsyncMessageEvent(ServiceContext serviceContext, CampaignViewDTO campaign, CampaignEventEnum campaignEventEnum){
        DomainMetaqMessageBodyContext msgBodyContext = DomainMetaqMessageBodyContext.builder()
                .bizCode(serviceContext.getBizCode())
                .domainType(DomainMessageTypeEnum.MAIN_CAMPAIGN)
                .domainEvent(campaignEventEnum.name())
                .entityId(campaign.getId())
                .memberId(campaign.getMemberId())
                .build();
        messageAsyncSendAbility.handle(serviceContext, MessageAsyncSendAbilityParam.builder().abilityTarget(msgBodyContext).build());
    }


    /**
     * 获取计划树
     * @param context
     * @param campaignIdList
     * @return
     */
    private List<CampaignViewDTO> findCampaignTreeList(ServiceContext context, List<Long> campaignIdList) {
        CampaignQueryViewDTO query = new CampaignQueryViewDTO();
        query.setCampaignIds(campaignIdList);
        CampaignQueryOption option = new CampaignQueryOption();
        option.setNeedCampaignTree(true);
        option.setNeedTarget(true);
        option.setNeedFrequency(true);

        return campaignStructureQueryAbility.handle(context, CampaignStructureQueryAbilityParam.builder()
                .abilityTarget(query).queryOption(option).build());
    }

    private List<CampaignGroupViewDTO> findCampaignGroupList(ServiceContext context, List<CampaignViewDTO> campaignList) {
        List<Long> campaignGroupIdSet = campaignList.stream().map(CampaignViewDTO::getCampaignGroupId).distinct().collect(
                Collectors.toList());
        if (CollectionUtils.isEmpty(campaignGroupIdSet)) {
            return Lists.newArrayList();
        }
        CampaignGroupQueryViewDTO campaignGroupQueryViewDTO = new CampaignGroupQueryViewDTO();
        campaignGroupQueryViewDTO.setIds(campaignGroupIdSet);
        campaignGroupQueryViewDTO.setPageSize(campaignGroupIdSet.size());
        PageResultViewDTO<CampaignGroupViewDTO> pageList = campaignGroupRepository.findCampaignGroupPageList(context,
                campaignGroupQueryViewDTO);
        return pageList.getList();
    }

//    @Override
//    public List<CampaignViewDTO> buildCampaignScrollList(ServiceContext serviceContext, List<CampaignViewDTO> scrollDailyCampaignList, List<CampaignViewDTO> campaignTreeViewDTOList, List<Long> campaignIdList) {
//        //merge滚量数据
//        bizCampaignInventoryAbility.mergeScroll(scrollDailyCampaignList, campaignTreeViewDTOList);
//        //过滤需要滚量的计划
//        return bizCampaignInventoryAbility.filterCampaignScroll(campaignTreeViewDTOList, campaignIdList);
//    }

//    @Override
//    public Void updateCampaignScroll(ServiceContext context, List<CampaignViewDTO> dbCampaignTreeList) {
//        bizCampaignInventoryAbility.updateCampaignScroll(context, dbCampaignTreeList);
//        return null;
//    }
}