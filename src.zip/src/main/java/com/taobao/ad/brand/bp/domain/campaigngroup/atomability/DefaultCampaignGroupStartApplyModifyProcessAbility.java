package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.nb.order.dto.common.EmpDTO;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupBusinessLineEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleProductLineEnum;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.client.dto.account.emp.AliEmpViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupOrderCommandViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesCustomerViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProjectViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.enums.BpmsProcessCodeEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.EmpUtil;
import com.taobao.ad.brand.bp.domain.bpms.BpmsRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CustomerRepository;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupStartApplyModifyProcessAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupStartApplyModifyProcessAbilityParam;
import com.taobao.ad.brand.bp.domain.uic.SimbaUicRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR;

/**
 * @author yanjingang
 * @date 2024/11/25
 */
@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultCampaignGroupStartApplyModifyProcessAbility implements ICampaignGroupStartApplyModifyProcessAbility {

    private final SimbaUicRepository simbaUicRepository;
    private final BpmsRepository bpmsRepository;
    private final CustomerRepository customerRepository;
    private final ResourcePackageRepository resourcePackageRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupStartApplyModifyProcessAbilityParam abilityParam) {
        CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO = abilityParam.getAbilityTarget();
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupViewDTOList = abilityParam.getResourcePackageSaleGroupList();
        SalesCustomerViewDTO salesCustomerViewDTO = null;
        if (campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getCustomerId() != null && campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getCustomerId() != 0L) {
            salesCustomerViewDTO = customerRepository.getCustomerById(campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getCustomerId());
        }
        Map<String, String> initDataMap = buildModifyProcessParam(serviceContext, campaignGroupOrderCommandViewDTO, campaignGroupViewDTO, salesCustomerViewDTO, resourcePackageSaleGroupViewDTOList);
        // title
        String title = new StringBuilder().append(salesCustomerViewDTO != null ? salesCustomerViewDTO.getName() + "-" : "")
                .append(initDataMap.get("memberName")).append("-的改单申请").toString();
        String titleEn = "Brand OneBP Order Modify Apply";
        String processInstId = bpmsRepository.startProcessInstance(title, titleEn, campaignGroupOrderCommandViewDTO.getCreatorId(), initDataMap, BpmsProcessCodeEnum.CAMPAIGN_GROUP_MODIFY_APPLY);
        campaignGroupViewDTO.getCampaignGroupUnlockViewDTO().getUnlockApplyInfoViewDTO().setProcInstId(processInstId);

        return null;
    }

    private Map<String, String> buildModifyProcessParam(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO, CampaignGroupViewDTO campaignGroupViewDTO,
                                                        SalesCustomerViewDTO salesCustomerViewDTO, List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupViewDTOList) {
        Map<String, String> initDataMap = Maps.newHashMap();
        // 基础信息
        initDataMap.put("id", String.valueOf(campaignGroupViewDTO.getId()));
        initDataMap.put("name", campaignGroupViewDTO.getName());
        // 客户信息
        initDataMap.put("customerId", String.valueOf(campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getCustomerId()));
        String customerName;
        if (salesCustomerViewDTO != null) {
            customerName = salesCustomerViewDTO.getName();
        } else {
            customerName = String.valueOf(campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getCustomerId());
        }
        initDataMap.put("customerName", customerName);
        // 投放账号
        initDataMap.put("memberId", String.valueOf(context.getMemberId()));
        if (ObjectUtils.isNotEmpty(context.getExt("adMemberNickName"))) {
            String memberName = String.valueOf(context.getExt("adMemberNickName"));
            initDataMap.put("memberName", memberName);
        } else {
            initDataMap.put("memberName", context.getOperName());
        }
        List<Integer> saleProductLines = resourcePackageSaleGroupViewDTOList.stream()
                .map(ResourcePackageSaleGroupViewDTO::getSaleProductLine).distinct().collect(Collectors.toList());
        //增加是否包含对应产品线
        Arrays.stream(SaleProductLineEnum.values()).forEach(saleProductLineEnum -> {
            initDataMap.put(saleProductLineEnum.name(), saleProductLines.contains(saleProductLineEnum.getValue()) ? "1" : "0");
        });

        Map<String, EmpDTO> empMap = getEmpMap(campaignGroupViewDTO);
        // 直客销售
        initDataMap.put("directSales", getEmpNameList(campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getDirectSales(), empMap));
        // 渠道销售
        initDataMap.put("channelSales", getEmpNameList(campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getChannelSales(), empMap));
        // 运营
        initDataMap.put("operators", getEmpNameList(campaignGroupViewDTO.getOperators(), empMap));
        // 运营相关人
        initDataMap.put("relevantOperators", getEmpNameList(campaignGroupViewDTO.getRelevantOperators(), empMap));

        // 分组信息
        Map<Long, ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupMap = resourcePackageSaleGroupViewDTOList.stream().collect(Collectors.toMap(ResourcePackageSaleGroupViewDTO::getId, Function.identity()));
        List<JSONObject> saleGroupInfoList = Lists.newArrayList();
        campaignGroupOrderCommandViewDTO.getSaleGroupIds().forEach(saleGroupId -> {
            JSONObject saleGroupInfo = new JSONObject();
            saleGroupInfo.put("id", saleGroupId);
            saleGroupInfo.put("name", resourcePackageSaleGroupMap.getOrDefault(saleGroupId, new ResourcePackageSaleGroupViewDTO()).getName());
            saleGroupInfoList.add(saleGroupInfo);
        });
        Map<String, Object> saleGroupInfoMap = Maps.newHashMap();
        saleGroupInfoMap.put("data", saleGroupInfoList);
        initDataMap.put("saleGroupInfos", JSONObject.toJSONString(saleGroupInfoMap));

        // 流程相关
        // 方案审批人
        buildProcessProjectApproveInfo(context, initDataMap, campaignGroupViewDTO);

        // 其他信息
        initDataMap.put("context", JSONObject.toJSONString(context));
        // todo 上线删除
        //initDataMap.put("alipmc_prepub_process_id", "86848108137");
        return initDataMap;
    }

    private void buildProcessProjectApproveInfo(ServiceContext context, Map<String, String> initDataMap, CampaignGroupViewDTO campaignGroupViewDTO) {
        if (!SaleGroupBusinessLineEnum.IP_MARKETING_AD.getValue().equals(campaignGroupViewDTO.getSceneId())) {
            return;
        }
        // 资源包项目
        ResourcePackageProjectViewDTO resourcePackageProjectViewDTO = null;
        if (campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getMarketingProjectId() != null) {
            resourcePackageProjectViewDTO = resourcePackageRepository.getResourcePackageProject(context, campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getMarketingProjectId());
        }

        AssertUtil.notNull(resourcePackageProjectViewDTO, BIZ_BREAK_RULE_ERROR, "资源包项目不存在");
        AssertUtil.notEmpty(resourcePackageProjectViewDTO.getSchemeApprovalEmpList(), BIZ_BREAK_RULE_ERROR, "流程发起失败：未查询到方案审批人");
        List<String> schemeApproveEmpIds = resourcePackageProjectViewDTO.getSchemeApprovalEmpList().stream()
                .map(AliEmpViewDTO::getEmpId).distinct()
                .map(EmpUtil::standardizeEmpNo)
                .collect(Collectors.toList());
        initDataMap.put("schemeApproveEmpIds", JSONObject.toJSONString(schemeApproveEmpIds));
    }

    private Map<String, EmpDTO> getEmpMap(CampaignGroupViewDTO campaignGroupViewDTO) {
        Set<String> empIdSet = Sets.newHashSet();
        // 直客销售
        Optional.ofNullable(campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getDirectSales()).ifPresent(empIdSet::addAll);
        // 渠道销售
        Optional.ofNullable(campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getChannelSales()).ifPresent(empIdSet::addAll);
        // 运营
        Optional.ofNullable(campaignGroupViewDTO.getOperators()).ifPresent(empIdSet::addAll);
        // 运营相关人
        Optional.ofNullable(campaignGroupViewDTO.getRelevantOperators()).ifPresent(empIdSet::addAll);

        if (CollectionUtils.isEmpty(empIdSet)) {
            return Maps.newHashMap();
        }
        return simbaUicRepository.getEmp(Lists.newArrayList(empIdSet));
    }

    private String getEmpNameList(List<String> empIdList, Map<String, EmpDTO> empMap) {
        if (CollectionUtils.isEmpty(empIdList) || MapUtils.isEmpty(empMap)) {
            return "";
        }
        return empMap.values().stream()
                .filter(empDTO -> empIdList.contains(empDTO.getEmpId()))
                .filter(empDTO -> StringUtils.isNotBlank(empDTO.getName()) || StringUtils.isNotBlank(empDTO.getNick()))
                .map(empDTO -> {
                    if (StringUtils.isNotBlank(empDTO.getNick())) {
                        return empDTO.getNick();
                    }
                    return empDTO.getName();
                }).collect(Collectors.joining(Constant.CHAR_SPLIT_KEY_DOT));
    }
}
