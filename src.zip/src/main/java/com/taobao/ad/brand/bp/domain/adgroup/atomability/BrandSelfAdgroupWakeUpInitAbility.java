package com.taobao.ad.brand.bp.domain.adgroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.common.SchemaConfigDetailViewDTO;
import com.alibaba.ad.brand.dto.common.SchemaConfigViewDTO;
import com.alibaba.ad.brand.dto.common.WakeupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupWakeupTypeEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.SchemaEnum;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupWakeUpInitAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupWakeUpInitAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Component
@BusinessAbility
public class BrandSelfAdgroupWakeUpInitAbility implements IAdgroupWakeUpInitAbility, BrandSelfServiceAtomAbilityRouter {
    @Override
    public Void handle(ServiceContext serviceContext, AdgroupWakeUpInitAbilityParam abilityParam) {
        WakeupViewDTO wakeupViewDTO = abilityParam.getAbilityTarget();
        if (Objects.isNull(wakeupViewDTO)) {
            return null;
        }
        if (BrandBoolEnum.BRAND_FALSE.getCode().equals(wakeupViewDTO.getIsOpenWakeup())) {
            wakeupViewDTO.setWakeupType(null);
            wakeupViewDTO.setSchemaConfigViewDTOList(null);
            return null;
        }
        if (BrandCampaignGroupWakeupTypeEnum.NON_WAKEUP.getCode().equals(wakeupViewDTO.getWakeupType())) {
            wakeupViewDTO.setSchemaConfigViewDTOList(null);
            return null;
        }
        if (CollectionUtils.isNotEmpty(wakeupViewDTO.getSchemaConfigViewDTOList())) {
            SchemaConfigViewDTO schemaConfigViewDTO = wakeupViewDTO.getSchemaConfigViewDTOList().get(0);
            SchemaConfigDetailViewDTO schemaConfigDetailViewDTO = new SchemaConfigDetailViewDTO();
            SchemaEnum schemaEnum = SchemaEnum.getByValue(schemaConfigViewDTO.getSchemaId().intValue());
            if (schemaEnum != null) {
                schemaConfigViewDTO.setOpenType(schemaEnum.getOpenType());
                schemaConfigDetailViewDTO.setHostApp(schemaEnum.getHostApp());
            }
            if (schemaEnum == SchemaEnum.WEIXIN_XIAOCHENGXU && Objects.nonNull(schemaConfigViewDTO.getSchemaConfigDetailViewDTO())) {
                schemaConfigDetailViewDTO.setAppId(schemaConfigViewDTO.getSchemaConfigDetailViewDTO().getAppId());
                schemaConfigDetailViewDTO.setAppPath(schemaConfigViewDTO.getSchemaConfigDetailViewDTO().getAppPath());
            }
            schemaConfigViewDTO.setSchemaConfigDetailViewDTO(schemaConfigDetailViewDTO);
            wakeupViewDTO.setSchemaConfigViewDTOList(Lists.newArrayList(schemaConfigViewDTO));
        }
        return null;
    }
}
