package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.biz.definition.constants.Product;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;

import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignCrowdMapQueryAbilityParam;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Component
@BusinessAbility
public class BrandOneBPCampaignCrowdMapQueryAbility
        extends DefaultCampaignCrowdMapQueryAbility implements BrandOneBPAtomAbilityRouter {

    @Resource
    private CampaignRepository campaignRepository;

    @Override
    public Map<Long, CampaignViewDTO> handle(ServiceContext context, CampaignCrowdMapQueryAbilityParam abilityParam) {
        List<Long> campaignIds = abilityParam.getAbilityTargets();
        if (CollectionUtils.isEmpty(campaignIds)) {
            return null;
        }
        //如果是站点级别的bizcode 重新设置productId
        if (Objects.isNull(context.getProductId()) && BizCodeEnum.BRANDONEBP.getBizCode().equals(context.getBizCode())) {
            context.setProductId(Product.BRAND_ONEBP_BRAND.getId());
        }
        return super.handle(context, abilityParam);
    }
}
