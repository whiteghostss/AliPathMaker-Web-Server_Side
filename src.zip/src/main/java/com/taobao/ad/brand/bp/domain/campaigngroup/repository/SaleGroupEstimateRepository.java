package com.taobao.ad.brand.bp.domain.campaigngroup.repository;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupEstimateInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.DmpArgusEstimateViewDTO;

/**
 * 分组预估
 * @author yiyun.myh@taobao.com
 * @date 2023年07月25日
 * */
public interface SaleGroupEstimateRepository {

    /**
     * 分组预估
     * */
    CampaignGroupSaleGroupEstimateInfoViewDTO estimateSaleGroup(ServiceContext serviceContext, DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO);
}
