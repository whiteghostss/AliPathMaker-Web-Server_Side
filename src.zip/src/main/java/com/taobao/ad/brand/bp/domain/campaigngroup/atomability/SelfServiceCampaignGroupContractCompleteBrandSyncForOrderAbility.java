package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CrmAdvInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesContractBrandViewDTO;
import com.taobao.ad.brand.bp.client.dto.shop.ShopBrandViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CustomerRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.SalesContractRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupContractCompleteBrandSyncForOrderAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupContractCompleteBrandSyncForOrderAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCampaignGroupContractCompleteBrandSyncForOrderAbility
        implements ICampaignGroupContractCompleteBrandSyncForOrderAbility, SelfServiceAtomAbilityRouter {

    private final SalesContractRepository salesContractRepository;
    private final CustomerRepository customerRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupContractCompleteBrandSyncForOrderAbilityParam abilityParam) {
        Long targetMemberId = abilityParam.getAbilityTarget();
        AssertUtil.notNull(targetMemberId,"账户memberId不能为空");
        RogerLogger.info("查询妈妈crm账户-店铺信息，memberId={}",targetMemberId);
        CrmAdvInfoViewDTO customer = customerRepository.getCustomer(targetMemberId);
        if(customer == null || customer.getShopId() == null){
            RogerLogger.info("妈妈crm账户-店铺信息不存在，memberId={}",targetMemberId);
            return null;
        }
        if(CollectionUtils.isEmpty(customer.getBrandInfos())){
            RogerLogger.info("妈妈crm账户-店铺关联品牌信息不存在，memberId={},shopId={}",targetMemberId,customer.getShopId());
            return null;
        }
        //ump已存在的绑定关系
        List<SalesContractBrandViewDTO> brandList = salesContractRepository.findBrandList(customer.getShopId());
        Set<Long> existContractBrandIds = Optional.ofNullable(brandList).orElse(Lists.newArrayList()).stream().map(SalesContractBrandViewDTO::getBrandId).collect(Collectors.toSet());

        //同步不在ump存在的绑定关系
        List<SalesContractBrandViewDTO> needAddBrandList = customer.getBrandInfos().stream()
                .filter(brand -> !existContractBrandIds.contains(brand.getBrandId())).collect(Collectors.toList());
        for (SalesContractBrandViewDTO brandInfo : needAddBrandList) {
            try {
                ShopBrandViewDTO shopBrandViewDTO = new ShopBrandViewDTO();
                shopBrandViewDTO.setTbUserId(customer.getUserId());
                shopBrandViewDTO.setShopId(customer.getShopId());
                shopBrandViewDTO.setBrandId(brandInfo.getBrandId());
                shopBrandViewDTO.setBrandName(brandInfo.getBrandName());
                salesContractRepository.addContractCompleteBrand(serviceContext,shopBrandViewDTO);
            } catch (Exception e) {
                RogerLogger.error(String.format("添加合同结案账号关联的品牌失败，memberId=%s,品牌信息=%s", targetMemberId, JSON.toJSONString(brandInfo)),e);
            }
        }
        return null;
    }
}
