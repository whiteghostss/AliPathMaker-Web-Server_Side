package com.taobao.ad.brand.bp.domain.motion;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.dto.motion.IntelligentStrategyViewDTO;
import com.taobao.ad.brand.bp.client.dto.motion.query.StrategyQueryViewDTO;

import java.util.List;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/20
 **/
public interface IntelligentStrategyRepository {

    List<IntelligentStrategyViewDTO> queryIntelligentStrategyList(ServiceContext serviceContext, StrategyQueryViewDTO strategyQueryViewDTO);
    Long saveIntelligentStrategy(ServiceContext serviceContext, IntelligentStrategyViewDTO strategyViewDTO);

    void updateBasicIntelligentStrategy(ServiceContext serviceContext, IntelligentStrategyViewDTO strategyViewDTO);
}
