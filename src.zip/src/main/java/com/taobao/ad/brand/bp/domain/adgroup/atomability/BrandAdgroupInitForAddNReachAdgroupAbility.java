package com.taobao.ad.brand.bp.domain.adgroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;

import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupBottomTypeEnum;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupOnlineStatusEnum;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupPriorityEnum;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupTargetTypeEnum;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupInitForAddNReachAdgroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupInitForAddNReachAdgroupAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
public class BrandAdgroupInitForAddNReachAdgroupAbility
        implements IAdgroupInitForAddNReachAdgroupAbility, BrandSelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext context, AdgroupInitForAddNReachAdgroupAbilityParam abilityParam) {
        AdgroupViewDTO adgroupViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();
        String title = campaignViewDTO.getTitle() + "人群优选单元";
        // 拼接后单元名称超过100字符的，往前截断
        if (title.length() > 100) {
            title = campaignViewDTO.getTitle().substring(0, 94) + "人群优选单元";
        }
        adgroupViewDTO.setTitle(title);
        adgroupViewDTO.setStartTime(campaignViewDTO.getStartTime());
        adgroupViewDTO.setCampaignId(campaignViewDTO.getId());
        adgroupViewDTO.setCampaignGroupId(campaignViewDTO.getCampaignGroupId());
        adgroupViewDTO.setEndTime(campaignViewDTO.getEndTime());
        adgroupViewDTO.setTargetType(BrandAdgroupTargetTypeEnum.PROGRAM.getCode());
        adgroupViewDTO.setOnlineStatus(BrandAdgroupOnlineStatusEnum.DRAFT.getCode());
        adgroupViewDTO.setBottomType(BrandAdgroupBottomTypeEnum.N_REACH.getCode());
        adgroupViewDTO.setWeight(0);
        adgroupViewDTO.setPriority(BrandAdgroupPriorityEnum.ONE.getCode());
        return null;
    }
}
