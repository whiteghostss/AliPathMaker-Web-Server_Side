package com.taobao.ad.brand.bp.domain.adgroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryViewDTO;
import com.taobao.ad.brand.bp.common.threadpooltask.AdgroupDeleteTaskIdentifier;
import com.taobao.ad.brand.bp.domain.adgroup.repository.AdgroupRepository;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeRepository;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupBatchDeleteAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupBatchDeleteAbilityParam;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

@Component
@BusinessAbility
public class DefaultAdgroupBatchDeleteAbility implements IAdgroupBatchDeleteAbility {
    @Resource
    private AdgroupDeleteTaskIdentifier adgroupDeleteTaskIdentifier;
    @Resource
    private AdgroupRepository adgroupRepository;
    @Resource
    private CreativeRepository creativeRepository;

    @Override
    public Void handle(ServiceContext serviceContext, AdgroupBatchDeleteAbilityParam abilityParam) {
        List<Long> deleteCampaignIdList = abilityParam.getAbilityTargets();
        if (CollectionUtils.isEmpty(deleteCampaignIdList)) {
            return null;
        }
        TaskStream.consume(adgroupDeleteTaskIdentifier, deleteCampaignIdList, (campaignId, index) -> {
                    this.deleteAdgroup(serviceContext,campaignId);
                })
                .commit()
                .handle();
        return null;
    }

    /**
     * 删除单元
     * @param serviceContext
     * @param campaignId
     */
    private void deleteAdgroup(ServiceContext serviceContext,Long campaignId){
        AdgroupQueryViewDTO adgroupQueryViewDTO = new AdgroupQueryViewDTO();
        adgroupQueryViewDTO.setCampaignId(campaignId);
        List<AdgroupViewDTO> adgroupViewDTOList = adgroupRepository.queryAdgroupListNoPage(serviceContext, adgroupQueryViewDTO);
        if(CollectionUtils.isEmpty(adgroupViewDTOList)){
            return;
        }
        List<Long> adgroupIds = adgroupViewDTOList.stream().map(AdgroupViewDTO::getId).collect(Collectors.toList());
        //删除单元
        adgroupRepository.batchDeleteAdgroup(serviceContext,adgroupIds);
        //创意解绑
        creativeRepository.unBindCreative(serviceContext,adgroupIds);
    }
}
