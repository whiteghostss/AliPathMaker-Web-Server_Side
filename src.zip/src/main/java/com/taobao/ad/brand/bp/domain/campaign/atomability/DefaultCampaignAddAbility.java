package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.threadpooltask.CampaignBatchAddTaskIdentifier;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignAddAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBatchAbilityParam;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Optional;

@Component
@BusinessAbility
public class DefaultCampaignAddAbility implements ICampaignAddAbility {

    @Resource
    private CampaignBatchAddTaskIdentifier campaignBatchAddTaskIdentifier;
    @Resource
    private CampaignRepository campaignRepository;

    @Override
    public List<Long> handle(ServiceContext serviceContext, CampaignBatchAbilityParam abilityParam) {
        List<CampaignViewDTO> campaignViewDTOList = abilityParam.getAbilityTargets();
        AssertUtil.notEmpty(campaignViewDTOList,"计划为空，不可新增");
        Long campaignGroupId = abilityParam.getCampaignGroupId();
        List<Long> campaignIdList = Lists.newArrayList();
        if(campaignViewDTOList.size() == 1){
            Long campaignId = addCampaign(serviceContext, campaignGroupId, campaignViewDTOList.get(0));
            campaignIdList.add(campaignId);
        }else{
            campaignIdList = TaskStream
                    .execute(campaignBatchAddTaskIdentifier, campaignViewDTOList, (campaignViewDTO, index) -> addCampaign(serviceContext, campaignGroupId, campaignViewDTO))
                    .commit()
                    .getResultList();
        }
        return campaignIdList;
    }


    public Long addCampaign(ServiceContext serviceContext, Long campaignGroupId, CampaignViewDTO campaignViewDTO) {

        try {
            //计划保存
            campaignRepository.addCampaign(serviceContext, campaignGroupId, Lists.newArrayList(campaignViewDTO));
            if(CollectionUtils.isNotEmpty(campaignViewDTO.getCampaignTargetScenarioViewDTO().getCampaignAdzoneViewDTOList())){
                campaignRepository.addCampaignAdzone(serviceContext, Lists.newArrayList(campaignViewDTO));
            }
        } catch (Exception e) {
            RogerLogger.error(String.format("计划保存异常，计划=%s", JSON.toJSONString(campaignViewDTO)),e);
            Long needDelCampaignId = Optional.ofNullable(campaignViewDTO).map(CampaignViewDTO::getId).orElse(null);
            if(needDelCampaignId != null){
                campaignRepository.physicsDelCampaign(serviceContext,campaignViewDTO);
                campaignViewDTO.setId(null);//清空计划id
            }
            throw new BrandOneBPException("计划保存异常",e);
        }
        return campaignViewDTO.getId();
    }


}
