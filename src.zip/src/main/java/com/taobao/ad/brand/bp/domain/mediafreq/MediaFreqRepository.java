package com.taobao.ad.brand.bp.domain.mediafreq;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.media.freq.MediaFreqViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.mediafreq.query.MediaFreqQueryViewDTO;

import java.util.List;

/**
 * 媒体频控
 * @author shiyan
 * @date 2023/7/19
 */
public interface MediaFreqRepository {
    /**
     * 新增
     *
     * @param serviceContext
     * @param viewDTO
     * @return
     */
    Long addMediaFreq(ServiceContext serviceContext, MediaFreqViewDTO viewDTO);

    /**
     * 编辑
     *
     * @param serviceContext
     * @param viewDTO
     * @return
     */
    Integer updateMediaFreq(ServiceContext serviceContext, MediaFreqViewDTO viewDTO);

    /**
     * 批量频控状态修改
     *
     * @param serviceContext
     * @param ids
     * @param status
     * @return
     */
    Integer updateMediaFreqStatus(ServiceContext serviceContext, List<Long> ids, Integer status);

    /**
     * 查询单条数据
     *
     * @param serviceContext
     * @param id
     * @return
     */
    MediaFreqViewDTO getMediaFreq(ServiceContext serviceContext, Long id);

    /**
     * 分页查询数据
     *
     * @param serviceContext
     * @param queryViewDTO
     * @return
     */
    PageResultViewDTO<MediaFreqViewDTO> findListWithPage(ServiceContext serviceContext, MediaFreqQueryViewDTO queryViewDTO);

    /**
     * 查询匹配的全部数据
     * @param serviceContext
     * @param queryViewDTO
     * @return
     */
    List<MediaFreqViewDTO> findList(ServiceContext serviceContext, MediaFreqQueryViewDTO queryViewDTO);
    /**
     * 根据名称查询媒体频控
     * @param serviceContext
     * @param uniqueName
     * @return
     */
    MediaFreqViewDTO getTopOneByName(ServiceContext serviceContext, String uniqueName);
}
