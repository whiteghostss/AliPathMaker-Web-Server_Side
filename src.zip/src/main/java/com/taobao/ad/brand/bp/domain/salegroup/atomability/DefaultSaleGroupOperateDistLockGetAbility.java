package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.enums.distlock.DistLockEnum;
import com.taobao.ad.brand.bp.common.util.DistLockUtil;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupOperateDistLockGetAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupOperateDistLockAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultSaleGroupOperateDistLockGetAbility implements ISaleGroupOperateDistLockGetAbility {

    @Override
    public Void handle(ServiceContext context, SaleGroupOperateDistLockAbilityParam distLockAbilityParam) {
        Optional.ofNullable(distLockAbilityParam.getAbilityTargets()).orElse(Lists.newArrayList())
                .forEach(this::teyGetSaleGroupOperateDistLock);
        return null;
    }

    /**
     * 获取订单分组操作分布式锁
     * @param saleGroupId
     */
    private void teyGetSaleGroupOperateDistLock(Long saleGroupId){
        String calculateSaleGroupKey = DistLockEnum.SALE_GROUP_CALCULATE_KEY.formatLockKey(saleGroupId);
        DistLockUtil.getLock(calculateSaleGroupKey, lockCurValue -> String.format("分组%s正在计算中,操作信息:%s，请稍后操作!",saleGroupId,lockCurValue));
    }
}
