package com.taobao.ad.brand.bp.domain.report.constant;

/**
 * @author yuncheng.lyc
 */
public interface ReportTaskBizCodeConstant {

    /**
     * 多维分析任务
     */
    String MULTI_CUSTOM = "mRptMultiCustom";


}
