package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.contract.CampaignGroupContractViewDTO;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupContractUpdateForNoticeBriefEventAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupContractUpdateForNoticeBriefEventAbilityParam;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Objects;

@Component
@BusinessAbility
public class DefaultCampaignGroupContractUpdateForNoticeBriefEventAbility implements ICampaignGroupContractUpdateForNoticeBriefEventAbility {
    @Resource
    private CampaignGroupRepository campaignGroupRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupContractUpdateForNoticeBriefEventAbilityParam abilityParam) {
        CampaignGroupContractViewDTO campaignGroupContractViewDTO = abilityParam.getAbilityTarget();
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        CampaignGroupContractViewDTO mainCampaignGroupContractViewDTO = abilityParam.getMainCampaignGroupContractViewDTO();
        if (!needUpdateContractInfo(campaignGroupViewDTO, campaignGroupContractViewDTO, mainCampaignGroupContractViewDTO)) {
            return null;
        }
        campaignGroupContractViewDTO.setContractId(mainCampaignGroupContractViewDTO.getContractId());
        campaignGroupContractViewDTO.setContractNumber(mainCampaignGroupContractViewDTO.getContractNumber());
        if (!BizCampaignGroupToolsHelper.isSlimOrderCampaignGroup(campaignGroupViewDTO)) {
            campaignGroupContractViewDTO.setContractSignStatus(mainCampaignGroupContractViewDTO.getContractSignStatus());
        }
        campaignGroupViewDTO.setCampaignGroupContractViewDTO(campaignGroupContractViewDTO);

        CampaignGroupViewDTO updateCampaignGroupViewDTO = new CampaignGroupViewDTO();
        updateCampaignGroupViewDTO.setId(campaignGroupViewDTO.getId());
        updateCampaignGroupViewDTO.setCampaignGroupContractViewDTO(campaignGroupContractViewDTO);
        campaignGroupRepository.updateCampaignGroupPart(serviceContext, updateCampaignGroupViewDTO);

        return null;
    }

    private boolean needUpdateContractInfo(CampaignGroupViewDTO campaignGroupViewDTO, CampaignGroupContractViewDTO campaignGroupContractViewDTO, CampaignGroupContractViewDTO mainCampaignGroupContractViewDTO) {
        if (!Objects.equals(campaignGroupContractViewDTO.getContractId(), mainCampaignGroupContractViewDTO.getContractId())) {
            return true;
        }
        if (!Objects.equals(campaignGroupContractViewDTO.getContractNumber(), mainCampaignGroupContractViewDTO.getContractNumber())) {
            return true;
        }
        if (!BizCampaignGroupToolsHelper.isSlimOrderCampaignGroup(campaignGroupViewDTO)) {
            if (!Objects.equals(campaignGroupContractViewDTO.getContractSignStatus(), mainCampaignGroupContractViewDTO.getContractSignStatus())) {
                return true;
            }
        }

        return false;
    }
}
