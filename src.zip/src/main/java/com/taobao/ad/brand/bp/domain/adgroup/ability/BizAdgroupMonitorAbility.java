package com.taobao.ad.brand.bp.domain.adgroup.ability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityInject;
import com.alibaba.abf.isolation.spec.common.ReduceType;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.monitor.MonitorCodeViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.creative.ContentVersionViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativeShowAuditStatusEnum;
import com.alibaba.ad.brand.sdk.constant.creativeref.ContentVersionBizTypeEnum;
import com.alibaba.ad.brand.sdk.constant.creativeref.OnlineStatusEnum;
import com.alibaba.ad.nb.order.dto.common.EmpDTO;
import com.alibaba.ad.nb.ssp.constant.common.MediaScopeEnum;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.uad.wto.constant.WakeUpEnum;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.dto.adgroup.EmailSendViewDTO;
import com.taobao.ad.brand.bp.client.dto.adgroup.ExportMonitorCodeViewDTO;
import com.taobao.ad.brand.bp.client.dto.media.MediaBusinessManagerViewDTO;
import com.taobao.ad.brand.bp.client.dto.media.MediaContactViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.excel.ExcelOutputViewDTO;
import com.taobao.ad.brand.bp.client.enums.resource.AdzoneOsEnum;
import com.taobao.ad.brand.bp.common.threadpooltask.AdgroupSendEmailTaskIdentifier;
import com.taobao.ad.brand.bp.common.util.*;
import com.taobao.ad.brand.bp.domain.adgroup.constant.AdgroupMonitorConstant;
import com.taobao.ad.brand.bp.domain.adgroup.repository.AdgroupRepository;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeRepository;
import com.taobao.ad.brand.bp.common.helper.adgroup.BizAdgroupToolsHelper;
import com.taobao.ad.brand.bp.domain.media.MediaRepository;
import com.taobao.ad.brand.bp.domain.memeber.MemberRepository;
import com.taobao.ad.brand.bp.domain.message.MessageRepository;
import com.taobao.ad.brand.bp.domain.monitor.MonitorRepository;
import com.taobao.ad.brand.bp.domain.oss.OssRepository;
import com.taobao.ad.brand.bp.domain.report.repository.EasyExcelRepository;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.ability.BizAdgroupMonitorAbilityExt;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.ability.param.BizAdgroupMonitorAbilityParam;
import com.taobao.ad.brand.bp.domain.uic.SimbaUicRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 单元监测能力配置
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizAdgroupMonitorAbility {

    protected final MonitorRepository monitorRepository;
    protected final MediaRepository mediaRepository;
    protected final AdgroupRepository adgroupRepository;
    protected final CreativeRepository creativeRepository;
    protected final SimbaUicRepository simbaUicRepository;
    private final EasyExcelRepository easyExcelRepository;
    private final OssRepository ossRepository;
    private final MessageRepository messageRepository;
    private final MemberRepository memberRepository;
    private final AdgroupSendEmailTaskIdentifier adgroupSendEmailTaskIdentifier;

    @Value("${inaccurate.monitor.login.url}")
    private String visitUrl;

    @AbilityInject(reduce = ReduceType.FIRST)
    private final BizAdgroupMonitorAbilityExt bizAdgroupMonitorAbilityExt;

    protected static final String SUBJECT = "阿里妈妈百灵投放【店铺名称】%s %s单元 %s监测代码(共%s个推广位)";

    /**
     * 获取监测excel头信息
     * @param context
     * @return
     */
    public Map<String, String> getAdgroupMonitorExcelHeader(ServiceContext context){
        return bizAdgroupMonitorAbilityExt.getAdgroupMonitorExcelHeader(context);
    }

    /**
     * 校验单元监测数据
     * @param serviceContext
     * @param adgroupViewDTO
     * @param abilityParam
     */
    public void validateAdgroupMonitor(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, BizAdgroupMonitorAbilityParam abilityParam) {
        //1、创意校验
        List<CreativeViewDTO> creativeViewDTOList = abilityParam.getCreativeViewDTOList();
        AssertUtil.notEmpty(creativeViewDTOList,String.format("单元(id=%s)未关联媒体直投创意，不能进行该操作",adgroupViewDTO.getId()));
        //创意审核状态（审核通过）
        boolean hasUnPassCreative = creativeViewDTOList.stream().anyMatch(creativeViewDTO -> !BrandCreativeShowAuditStatusEnum.AUDIT_PASS.getCode()
                .equals(creativeViewDTO.getCreativeAudit().getShowAuditStatus()));
        AssertUtil.assertTrue(!hasUnPassCreative,String.format("单元(id=%s)有创意未审核通过，不能进行该操作",adgroupViewDTO.getId()));

        //2、计划校验
        CampaignViewDTO campaignTreeViewDTO = abilityParam.getCampaignTreeViewDTO();
        AssertUtil.assertTrue(campaignTreeViewDTO.getCampaignSaleViewDTO().getSubContractId() != null
                        && campaignTreeViewDTO.getCampaignSaleViewDTO().getContractId() != null,
                String.format("请检查发送单元(id=%s)对应计划的合同状态,合同流程通过后才能进行该操作", adgroupViewDTO.getId()));

        List<CampaignViewDTO> subCampaignViewDTOList = campaignTreeViewDTO.getSubCampaignViewDTOList().stream()
                .filter(subCampaignViewDTO -> Objects.equals(subCampaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope(), MediaScopeEnum.SITE_OUT.getCode()))
                .collect(Collectors.toList());
        AssertUtil.notEmpty(subCampaignViewDTOList,String.format("计划(id=%s)不满足要求，不能进行该操作",campaignTreeViewDTO.getId()));

        bizAdgroupMonitorAbilityExt.validateAdgroupMonitor(serviceContext,adgroupViewDTO,abilityParam);
    }
    /**
     * 生成单元监测代码
     * @param serviceContext
     * @param adgroupViewDTO
     * @return
     */
    public List<ExportMonitorCodeViewDTO> generateAdgroupMonitor(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, BizAdgroupMonitorAbilityParam abilityParam) {
        List<ExportMonitorCodeViewDTO> monitorCodeViewDTOList =
                bizAdgroupMonitorAbilityExt.generateAdgroupMonitor(serviceContext,adgroupViewDTO,abilityParam);
        if(CollectionUtils.isNotEmpty(monitorCodeViewDTOList)){
            monitorCodeViewDTOList.forEach(this::resetDeepLinkUrl);
        }
        return monitorCodeViewDTOList;
    }

    /**
     * 获取监测下载cdn地址
     * @param serviceContext
     * @param fileName
     * @param exportMonitorCodeViewDTOList
     * @return
     */
    public String getMonitorDownloadCdnUrl(ServiceContext serviceContext, String fileName, List<ExportMonitorCodeViewDTO> exportMonitorCodeViewDTOList) {
        String sheetName = "监测";
        ExcelOutputViewDTO excelOutputViewDTO = easyExcelRepository.listToExcel(fileName,sheetName,Lists.newArrayList(),
                this.getAdgroupMonitorExcelHeader(serviceContext),getExcelMonitorDataList(serviceContext,exportMonitorCodeViewDTOList));
        ossRepository.upload(excelOutputViewDTO.getFileName(), excelOutputViewDTO.getOutputStream().toByteArray());
        return ossRepository.getTemporaryDownloadUrl(excelOutputViewDTO.getFileName(), OssRepository.EXPIRE_TIME_THREE_MONTH);
    }

    /**
     * 媒体直投单元，发送监测邮件
     * @param adgroupViewDTO 单元DTO
     * @param exportMonitorCodeViewDTOList  导出和监测邮件共用
     * */
    public void sendEmail(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO,List<ExportMonitorCodeViewDTO> exportMonitorCodeViewDTOList,String cdnUrl,Long monitorId,Long subCampaignId){
        EmailSendViewDTO emailSendViewDTO = buildMonitorEmail(serviceContext,adgroupViewDTO,exportMonitorCodeViewDTOList,cdnUrl,monitorId,subCampaignId);
        if(emailSendViewDTO != null){
            TaskStream.consume(adgroupSendEmailTaskIdentifier, emailSendViewDTO.getEmailTos(), (emailTo, index) -> {
                        messageRepository.sendEmail(emailTo, emailSendViewDTO.getTitle(), emailSendViewDTO.getContent());
                        RogerLogger.info("监测链接发送成功，adgroupId={}，subCampaignId={},emailTo={}", emailSendViewDTO.getAdgroupId(), subCampaignId, emailTo);
                    })
                    .asyncHandle((r, e) -> {
                        if (Objects.nonNull(e)) {
                            RogerLogger.error("监测链接发送失败，adgroupId={}，subCampaignId={}", emailSendViewDTO.getAdgroupId(), subCampaignId, e);
                        }
                    })
                    .commit();
        }
    }

    /**
     * 保存单元监测
     * @param context
     * @param adgroupViewDTO
     * @param exportMonitorCodeViewDTOList
     * @return
     */
    public ContentVersionViewDTO saveAdgroupMonitorContent(ServiceContext context, AdgroupViewDTO adgroupViewDTO, List<ExportMonitorCodeViewDTO> exportMonitorCodeViewDTOList){
        //添加非精准监测到中台
        ContentVersionViewDTO contentVersionViewDTO = new ContentVersionViewDTO();
        contentVersionViewDTO.setCustomerId(context.getCustId());
        contentVersionViewDTO.setBizType(ContentVersionBizTypeEnum.MONITOR_URL.getValue());
        contentVersionViewDTO.setMemberId(context.getMemberId());
        contentVersionViewDTO.setOnlineStatus(OnlineStatusEnum.ON.getValue());
        contentVersionViewDTO.setSceneId(ServiceContextUtil.getSceneId(context));
        contentVersionViewDTO.setProductId(context.getProductId());

        List<MonitorCodeViewDTO> monitorCodeViewDTOList = Lists.newArrayList();
        exportMonitorCodeViewDTOList.forEach(exportMonitorCodeViewDTO -> {
            MonitorCodeViewDTO monitorCodeViewDTO = new MonitorCodeViewDTO();
            BeanUtils.copyProperties(exportMonitorCodeViewDTO, monitorCodeViewDTO);
            monitorCodeViewDTO.setLandingUrl(exportMonitorCodeViewDTO.getLandingPage());
            monitorCodeViewDTOList.add(monitorCodeViewDTO);
        });
        contentVersionViewDTO.setContent(JSONObject.toJSONString(monitorCodeViewDTOList));

        if (adgroupViewDTO.getAdgroupMonitorViewDTO() != null
                && adgroupViewDTO.getAdgroupMonitorViewDTO().getMonitorContentId() != null) {
            contentVersionViewDTO.setContentId(adgroupViewDTO.getAdgroupMonitorViewDTO().getMonitorContentId());
        }
        return creativeRepository.addContentVersion(context, contentVersionViewDTO);
    }

    private String buildMonitorContentHtml(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, List<ExportMonitorCodeViewDTO> exportMonitorCodeViewDTOList, String cdnUrl, List<MediaBusinessManagerViewDTO> mediaBusinessManagerViewDTOList, Long monitorId,Long subCampaignId) {
        Map<String, Object> params = buildVMParam(serviceContext, adgroupViewDTO, exportMonitorCodeViewDTOList, cdnUrl, mediaBusinessManagerViewDTOList, monitorId,subCampaignId);
        return VelocityUtils.merge("vm/monitorcode.vm", params);
    }

    private EmailSendViewDTO buildMonitorEmail(ServiceContext serviceContext,AdgroupViewDTO adgroupViewDTO,List<ExportMonitorCodeViewDTO> exportMonitorCodeViewDTOList,String cdnUrl,Long monitorId,Long subCampaignId ) {
        EmailSendViewDTO monitorEmailModel = new EmailSendViewDTO();
        monitorEmailModel.setEmailTos(Lists.newArrayList());

        //当前伪登录用户
        if(ServiceContextUtil.isAliStaff(serviceContext)){
            EmpDTO bucUserEmpDTO = simbaUicRepository.getEmpByBucUserId(ServiceContextUtil.getAliStaffBucUserId(serviceContext));
            monitorEmailModel.getEmailTos().add(bucUserEmpDTO.getEmail());
        }
        List<Long> mediaIds = exportMonitorCodeViewDTOList.stream().map(ExportMonitorCodeViewDTO::getMediaId).distinct().collect(Collectors.toList());

        //线上环境才发送给媒体商务，其他环境只发送给伪登录用户
        if(Env.isProd()){
            List<MediaContactViewDTO> mediaContactViewDTOList = mediaRepository.getMediaContractorList(mediaIds);
            if(CollectionUtils.isNotEmpty(mediaContactViewDTOList)){
                List<String> emails = mediaContactViewDTOList.stream().map(MediaContactViewDTO::getEmail).filter(StringUtils::isNotBlank).distinct().collect(Collectors.toList());
                monitorEmailModel.getEmailTos().addAll(emails);
            }
        }
        List<MediaBusinessManagerViewDTO> mediaBusinessManagerViewDTOList = mediaRepository.getMediaBusinessManagerList(mediaIds);

        //东风测试邮箱，对非精准邮件进行归档，用于问题排查
        monitorEmailModel.getEmailTos().add("alimmdongfeng@alibaba-inc.com");
        monitorEmailModel.getEmailTos().add("alimama_umop@alibaba-inc.com");



        monitorEmailModel.setTitle(buildEmailTitle(adgroupViewDTO,exportMonitorCodeViewDTOList));
        monitorEmailModel.setContent(buildMonitorContentHtml(serviceContext, adgroupViewDTO,exportMonitorCodeViewDTOList,cdnUrl,mediaBusinessManagerViewDTOList,monitorId,subCampaignId));
        monitorEmailModel.setAdgroupId(adgroupViewDTO.getId());
        return monitorEmailModel;
    }
    private String buildEmailTitle(AdgroupViewDTO adgroupViewDTO,List<ExportMonitorCodeViewDTO> exportMonitorCodeViewDTOList){
        //推广位数量
        String mediaName = exportMonitorCodeViewDTOList.get(0).getMediaName();
        long adzoneIdNum = exportMonitorCodeViewDTOList.stream()
                .map(ExportMonitorCodeViewDTO::getAdzoneId)
                .distinct().count();

        String shopName = memberRepository.getMemberNameById(adgroupViewDTO.getMemberId());

        return String.format(SUBJECT, shopName, adgroupViewDTO.getTitle(),
                mediaName,adzoneIdNum);
    }
    private Map<String, Object> buildVMParam(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, List<ExportMonitorCodeViewDTO> exportMonitorCodeViewDTOList, String cdnUrl, List<MediaBusinessManagerViewDTO> mediaBusinessManagerViewDTOList, Long monitorId,Long subCampaignId) {

        Map<String, Object> result = Maps.newHashMap();
        result.put("mediaName", exportMonitorCodeViewDTOList.get(0).getMediaName());
        result.put("adgroupName", adgroupViewDTO.getTitle());
        result.put("cdnUrl",cdnUrl);

        //单元id
        String a = SignatureUtils.encryptAes128EcbSafeBase64String(adgroupViewDTO.getId().toString());
        //版本id
        String v= SignatureUtils.encryptAes128EcbSafeBase64String(monitorId.toString());
        //member
        String m = SignatureUtils.encryptAes128EcbSafeBase64String(adgroupViewDTO.getMemberId().toString());
        //子计划id（全域通场景添加）
        String c = SignatureUtils.encryptAes128EcbSafeBase64String(Optional.ofNullable(subCampaignId).map(String::valueOf).orElse(null));
        //校验码
        String s = SignatureUtils.getMD5((SignatureUtils.salt + adgroupViewDTO.getId() + monitorId + adgroupViewDTO.getMemberId()).getBytes());
        if(subCampaignId == null){
            result.put("visitUrl", visitUrl + a + "&v=" + v + "&m=" + m + "&s=" + s + "&bizCode=" + serviceContext.getBizCode());
        }else{
            result.put("visitUrl", visitUrl + a + "&v=" + v + "&m=" + m + "&s=" + s + "&c=" + c + "&bizCode=" + serviceContext.getBizCode());
        }
        result.put("startDate", BrandDateUtil.date2String(adgroupViewDTO.getStartTime()));
        result.put("endDate", BrandDateUtil.date2String(adgroupViewDTO.getEndTime()));
        result.put("now", BrandDateUtil.date2String(new Date(), BrandDateUtil.DATE_FORMAT_YYYYMMDD_TYPE_1));
        if (CollectionUtils.isEmpty(mediaBusinessManagerViewDTOList)){
            mediaBusinessManagerViewDTOList = Lists.newArrayList(AdgroupMonitorConstant.defaultContactUser());
        }
        result.put("contactUsers", mediaBusinessManagerViewDTOList);
        return result;
    }

    /**
     * 获取excel监测数据
     * @param context
     * @param exportMonitorCodeViewDTOList
     * @return
     */
    private List<Map<String, Object>> getExcelMonitorDataList(ServiceContext context, List<ExportMonitorCodeViewDTO> exportMonitorCodeViewDTOList) {
        List<Map<String, Object>> dataList = Lists.newArrayList();
        exportMonitorCodeViewDTOList.forEach(item -> {
            Map<String, Object> dataMap = Maps.newLinkedHashMap();
            if (item.getTalentUserId() != null) {
                dataMap.put("resourceName", item.getTalentNickName());
            } else {
                dataMap.put("resourceName", item.getResourceName());
            }
            dataMap.put("resourceTypeName", item.getResourceTypeName());
            char line = (char) 10;
            dataMap.put("bottomInfo", BizAdgroupToolsHelper.formatMonitorBottomInfo(item, String.valueOf(line)));
            dataMap.put("osName", item.getOsName());
            dataMap.put("pvMonitorUrl", item.getPvMonitorUrl());
            dataMap.put("deepLinkUrl", item.getDeepLinkUrl());
            dataMap.put("ulkUrl", item.getUlkUrl());
            dataMap.put("clickUrl", item.getClickUrl());
            dataMap.put("clickMonitorUrl", item.getClickMonitorUrl());
            dataMap.put("landingPage", item.getLandingPage());
            dataMap.put("gmtModified", BrandDateUtil.date2String(item.getGmtModified(), BrandDateUtil.DATE_FORMAT_YYYYMMDDHHMM_TYPE_1));
            dataMap.put("purchaseRowId", item.getPurchaseRowId());

            dataList.add(dataMap);
        });
        return dataList;
    }

    /**
     * 重置监测链接
     * @param exportMonitorCodeViewDTO
     */
    private void resetDeepLinkUrl(ExportMonitorCodeViewDTO exportMonitorCodeViewDTO) {
        //安卓，不生成ulk监测链接
        if (Objects.equals(exportMonitorCodeViewDTO.getOs(), AdzoneOsEnum.ANDROID.getValue())) {
            exportMonitorCodeViewDTO.setUlkUrl(null);
        }
        boolean isSupportWakeUp = false;
        boolean isSupportUlk = false;
        if (checkIfBuildDeeplinkUrl(exportMonitorCodeViewDTO)) {
            isSupportWakeUp = true;
        }
        if (checkIfBuildUlk(exportMonitorCodeViewDTO)) {
            isSupportUlk = true;
            isSupportWakeUp = true;
        }
        if (!isSupportWakeUp) {
            exportMonitorCodeViewDTO.setDeepLinkUrl("");
            exportMonitorCodeViewDTO.setUlkUrl("");
        } else {
            if (!isSupportUlk) {
                exportMonitorCodeViewDTO.setUlkUrl("");
            }
        }
        RogerLogger.info("监测链接重置,isSupportWakeUp:{},isSupportUlk:{}",isSupportWakeUp,isSupportUlk);
    }

    /**
     * 检查是否需要构建deeplink唤醒url
     *
     * @param exportMonitorCodeViewDTO 导出监测码视图DTO对象
     * @return 如果包含deeplink唤醒方式，则返回true；否则返回false
     */
    private boolean checkIfBuildDeeplinkUrl(ExportMonitorCodeViewDTO exportMonitorCodeViewDTO) {
        List<Integer> wakeupWayList = exportMonitorCodeViewDTO.getResourceSupportWakeUpList();
        if (CollectionUtils.isNotEmpty(wakeupWayList)) {
            return wakeupWayList.contains(WakeUpEnum.DEEP_LINK.getValue());
        }
        wakeupWayList = exportMonitorCodeViewDTO.getPurchaseRowSupportWakeUpList();
        return wakeupWayList.contains(WakeUpEnum.DEEP_LINK.getValue());
    }

    /**
     * 检查是否构建Ulk
     *
     * @param exportMonitorCodeViewDTO 导出监控码视图DTO对象
     * @return 是否包含Ulk唤醒方式
     */
    private boolean checkIfBuildUlk(ExportMonitorCodeViewDTO exportMonitorCodeViewDTO) {
        List<Integer> wakeupWayList = exportMonitorCodeViewDTO.getResourceSupportWakeUpList();
        if (CollectionUtils.isNotEmpty(wakeupWayList)) {
            return wakeupWayList.contains(WakeUpEnum.U_LINK.getValue());
        }
        wakeupWayList = exportMonitorCodeViewDTO.getPurchaseRowSupportWakeUpList();
        return wakeupWayList.contains(WakeUpEnum.U_LINK.getValue());
    }
}
