package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.creative.CampaignCreativeControllerViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupProductCategoryEnum;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignCreativeControllerInitForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignCreativeControllerAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultCampaignCreativeControllerInitForAddCampaignAbility implements ICampaignCreativeControllerInitForAddCampaignAbility {

    @Override
    public CampaignCreativeControllerViewDTO handle(ServiceContext serviceContext, CampaignCreativeControllerAbilityParam abilityParam) {
        ProductViewDTO productViewDTO = abilityParam.getProductViewDTO();
        AssertUtil.notNull(productViewDTO, "产品不能为空");
        ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO = abilityParam.getResourcePackageSaleGroupViewDTO();
        AssertUtil.notNull(resourcePackageSaleGroupViewDTO, "资源包分组不能为空");
        CampaignCreativeControllerViewDTO campaignCreativeControllerViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(campaignCreativeControllerViewDTO, "计划创意控制不能为空");

        campaignCreativeControllerViewDTO.setIsTop(SaleGroupProductCategoryEnum.TM_COOPERATE.getValue().equals(resourcePackageSaleGroupViewDTO.getProductCategory())
                || SaleGroupProductCategoryEnum.UD_SELECTION_TM_COOPERATE.getValue().equals(resourcePackageSaleGroupViewDTO.getProductCategory())
                ? BrandBoolEnum.BRAND_TRUE.getCode() : BrandBoolEnum.BRAND_FALSE.getCode());
        return campaignCreativeControllerViewDTO;
    }
}
