package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupTypeEnum;
import com.taobao.ad.brand.bp.common.converter.campaigngroup.CampaignGroupViewConverter;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupInitForSplitSubCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupSplitAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author yanjingang
 * @date 2025/2/8
 */
@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultCampaignGroupInitForSplitSubCampaignGroupAbility implements ICampaignGroupInitForSplitSubCampaignGroupAbility {

    private final CampaignGroupViewConverter campaignGroupViewConverter;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupSplitAbilityParam abilityParam) {
        CampaignGroupViewDTO subCampaignGroupViewDTO = abilityParam.getAbilityTarget();
        CampaignGroupViewDTO mainCampaignGroupViewDTO = abilityParam.getMainCampaignGroup();
        List<SaleGroupInfoViewDTO> subSaleGroupList = subCampaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList();
        Integer sceneId = abilityParam.getSceneId();

        subCampaignGroupViewDTO.setId(null);
        subCampaignGroupViewDTO.setGmtCreate(null);
        subCampaignGroupViewDTO.setGmtModified(null);
        // 子订单金额
        subCampaignGroupViewDTO.setBudget(BizCampaignGroupToolsHelper.getBuySaleGroupBudgetTotal(subSaleGroupList));
        // 开始日期
        Date startDate = BizCampaignGroupToolsHelper.getSaleGroupMinDate(subSaleGroupList);
        if (startDate != null) {
            subCampaignGroupViewDTO.setStartTime(startDate);
        } else {
            subCampaignGroupViewDTO.setStartTime(mainCampaignGroupViewDTO.getStartTime());
        }
        // 结束日期
        Date endDate = BizCampaignGroupToolsHelper.getSaleGroupMaxDate(subSaleGroupList);
        if (endDate != null) {
            subCampaignGroupViewDTO.setEndTime(BrandDateUtil.getDateFullMidnight(endDate));
        } else {
            subCampaignGroupViewDTO.setEndTime(mainCampaignGroupViewDTO.getEndTime());
        }

        // 子订单信息
        subCampaignGroupViewDTO.setCampaignGroupLevel(BrandCampaignGroupLevelEnum.LEVEL_TWO.getCode());
        subCampaignGroupViewDTO.setType(BrandCampaignGroupTypeEnum.SALES.getCode());
        subCampaignGroupViewDTO.setParentId(mainCampaignGroupViewDTO.getId());

        // 业务场景
        subCampaignGroupViewDTO.setSceneId(sceneId);

        return null;
    }



    /**
     * 根据主订单获取子订单分组信息
     *
     * @param mainCampaignGroupViewDTO
     * @return
     */
    public Map<Integer, List<SaleGroupInfoViewDTO>> splitSubCampaignGroupSaleGroups(CampaignGroupViewDTO mainCampaignGroupViewDTO) {
        List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList = campaignGroupViewConverter.convertSaleGroupInfoSelfList(mainCampaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList());
        return saleGroupInfoViewDTOList.stream()
                .filter(saleGroup -> saleGroup.getSaleBusinessLine() != null)
                .peek(saleGroupInfo -> {
                    saleGroupInfo.setId(null);
                    saleGroupInfo.setCampaignGroupId(null);
                }).collect(Collectors.groupingBy(SaleGroupInfoViewDTO::getSaleBusinessLine));
    }
}
