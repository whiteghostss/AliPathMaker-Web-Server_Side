package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.dooh.repository.DoohRepository;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignDoohPushForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignDoohPushAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandDoohPushForAddCampaignAbility implements ICampaignDoohPushForAddCampaignAbility, BrandAtomAbilityRouter {

    private final DoohRepository doohRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignDoohPushAbilityParam abilityParam) {
        CampaignViewDTO campaignTreeViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(campaignTreeViewDTO,"计划不能为空");
        //天攻的计划需要同步天攻新建计划，天攻场景子计划只有一个
        if(BizCampaignToolsHelper.isDoohCampaign(campaignTreeViewDTO.getCampaignResourceViewDTO().getSspProductLineId())){
            if(CollectionUtils.isNotEmpty(campaignTreeViewDTO.getSubCampaignViewDTOList())){
                CampaignViewDTO subCampaignViewDTO = campaignTreeViewDTO.getSubCampaignViewDTOList().get(0);
                doohRepository.addCampaign(serviceContext, Lists.newArrayList(subCampaignViewDTO));
                campaignTreeViewDTO.getCampaignDoohViewDTO().setDoohCampaignId(subCampaignViewDTO.getCampaignDoohViewDTO().getDoohCampaignId());
                campaignTreeViewDTO.getCampaignDoohViewDTO().setDoohStrategyId(subCampaignViewDTO.getCampaignDoohViewDTO().getDoohStrategyId());
            }
        }
        return null;
    }
}
