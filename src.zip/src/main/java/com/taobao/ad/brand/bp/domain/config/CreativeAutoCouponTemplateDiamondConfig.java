package com.taobao.ad.brand.bp.domain.config;

import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.domain.config.base.BaseDiamondConfig;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 领券模版列表
 */
@Component
public class CreativeAutoCouponTemplateDiamondConfig extends BaseDiamondConfig {

    private static volatile String config;

    @Override
    protected String getDataId() {
        return "auto.coupon.templates";
    }
    @Override
    protected String getGroupId() { return "com.taobao.ad.brand.bp"; }

    @Override
    protected void initDiamond(String diamondConfig) {
        RogerLogger.info("DiamondConfig.initDiamond CreativeAutoCouponTemplateDiamondConfig param: {}", diamondConfig);
        config = diamondConfig;
    }

    /**
     * 查询领券模版列表
     * @return
     */
    /*public List<Long> getAutoCouponTemplateIdList(){
        if (StringUtils.isBlank(config)) {
            return Lists.newArrayList();
        }
        return Arrays.stream(StringUtils.split(config, Constant.CHAR_SPLIT_KEY_DOT))
                .map(Long::parseLong).distinct().collect(Collectors.toList());
    }*/
}
