package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryLockViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.customer.CampaignGroupCustomerViewDTO;
import com.alibaba.ad.nb.ssp.constant.common.MediaScopeEnum;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignInquiryLockInitForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignInquiryLockAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandCampaignInquiryLockInitForAddCampaignAbility implements ICampaignInquiryLockInitForAddCampaignAbility, BrandAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignInquiryLockAbilityParam abilityParam) {
        CampaignInquiryLockViewDTO campaignInquiryLockViewDTO = abilityParam.getAbilityTarget();
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        ProductViewDTO productViewDTO = abilityParam.getProductViewDTO();
        AssertUtil.notNull(campaignInquiryLockViewDTO, "询锁量信息不能为空");
        AssertUtil.notNull(campaignGroupViewDTO, "订单信息不能为空");
        AssertUtil.notNull(productViewDTO, "二级产品不能为空");

        // 客户优先级
        String customerPriority = Optional.ofNullable(campaignGroupViewDTO.getCampaignGroupCustomerViewDTO())
                .map(CampaignGroupCustomerViewDTO::getCustomerPriority).orElse(null);
        campaignInquiryLockViewDTO.setCustomerPriority(customerPriority);
        // 产品优先级
        Integer priority = productViewDTO.getPriority();
        if(priority == null){
            //三环没有产品优先级，二环产品上默认 50为兜底
            if(MediaScopeEnum.TAO_OUT.getCode().equals(productViewDTO.getMediaScope())){
                priority=50;
            }
            if(MediaScopeEnum.SITE_OUT.getCode().equals(productViewDTO.getMediaScope())){
                priority=99;
            }
        }
        campaignInquiryLockViewDTO.setSspProductPriority(priority);

        return null;
    }
}
