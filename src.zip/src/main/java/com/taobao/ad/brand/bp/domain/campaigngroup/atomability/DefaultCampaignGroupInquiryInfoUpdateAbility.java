package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.inquiry.CampaignGroupInquiryViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.taobao.ad.brand.bp.common.constant.campaigngroup.CampaignGroupConstant;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupInquiryInfoUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupInquiryInfoUpdateAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Objects;
import java.util.Optional;

@Component
@BusinessAbility
public class DefaultCampaignGroupInquiryInfoUpdateAbility implements ICampaignGroupInquiryInfoUpdateAbility {

    @Resource
    private CampaignGroupRepository campaignGroupRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupInquiryInfoUpdateAbilityParam abilityParam) {
        CampaignGroupInquiryViewDTO campaignGroupInquiryViewDTO = abilityParam.getAbilityTarget();
        if (Objects.isNull(campaignGroupInquiryViewDTO)) {
            campaignGroupInquiryViewDTO = new CampaignGroupInquiryViewDTO();
        }
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        campaignGroupViewDTO.setCampaignGroupInquiryViewDTO(campaignGroupInquiryViewDTO);
        if (BizCampaignGroupToolsHelper.isMainCampaignGroup(campaignGroupViewDTO) || campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO() == null || CollectionUtils.isEmpty(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList())) {
            return null;
        }
        CampaignGroupViewDTO updateCampaignGroupViewDTO = new CampaignGroupViewDTO();
        updateCampaignGroupViewDTO.setId(campaignGroupViewDTO.getId());
        boolean allHasInquiry = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream()
                .allMatch(saleGroupInfoViewDTO -> saleGroupInfoViewDTO.getHasInquiryPriority() != null && BrandBoolEnum.BRAND_TRUE.getCode().equals(saleGroupInfoViewDTO.getHasInquiryPriority()));
        if (allHasInquiry) {
            SaleGroupInfoViewDTO saleGroupInfoViewDTO = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().get(0);
            campaignGroupInquiryViewDTO.setInquiryDate(saleGroupInfoViewDTO.getInquiryDate() == null ?
                    BrandDateUtil.string2Date(CampaignGroupConstant.INQUIRY_MAX_DATE, BrandDateUtil.DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_1) : saleGroupInfoViewDTO.getInquiryDate());
            campaignGroupInquiryViewDTO.setInquiryBatch(saleGroupInfoViewDTO.getInquiryBatch() != null ? saleGroupInfoViewDTO.getInquiryBatch() : 0);
        } else {
            Optional<SaleGroupInfoViewDTO> optional = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList()
                    .stream().filter(saleGroupInfoViewDTO1 -> saleGroupInfoViewDTO1.getInquiryBatch() != null).findFirst();
            campaignGroupInquiryViewDTO.setInquiryDate(BrandDateUtil.string2Date(CampaignGroupConstant.INQUIRY_MIN_DATE, BrandDateUtil.DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_1));
            campaignGroupInquiryViewDTO.setInquiryBatch(optional.isPresent() ? optional.get().getInquiryBatch() : 0);
        }
        updateCampaignGroupViewDTO.setCampaignGroupInquiryViewDTO(campaignGroupInquiryViewDTO);
        campaignGroupRepository.updateCampaignGroupPart(serviceContext, updateCampaignGroupViewDTO);
        return null;
    }
}
