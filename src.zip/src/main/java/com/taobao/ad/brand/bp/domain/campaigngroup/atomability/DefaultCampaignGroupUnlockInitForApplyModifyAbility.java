package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.process.ProcessRecordViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.unlock.CampaignGroupUnlockViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.unlock.UnlockApplyInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupProcessStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupProcessTypeEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupOrderCommandViewDTO;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupUnlockInitForApplyModifyAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupValidateForApplyModifyAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupUnlockAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupUnlockInitForApplyModifyAbilityParam;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR;

@Component
@BusinessAbility
public class DefaultCampaignGroupUnlockInitForApplyModifyAbility implements ICampaignGroupUnlockInitForApplyModifyAbility {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupUnlockInitForApplyModifyAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO = abilityParam.getCampaignGroupOrderCommandViewDTO();
        CampaignGroupUnlockViewDTO campaignGroupUnlockViewDTO = Optional.ofNullable(abilityParam.getAbilityTarget()).orElse(new CampaignGroupUnlockViewDTO());
        UnlockApplyInfoViewDTO dbUnlockApplyInfoViewDTO = Optional.ofNullable(campaignGroupUnlockViewDTO.getUnlockApplyInfoViewDTO()).orElse(new UnlockApplyInfoViewDTO());
        // 备份已完成的流程
        backupFinishedProcessRecord(dbUnlockApplyInfoViewDTO, campaignGroupViewDTO);
        // 初始化流程申请信息
        dbUnlockApplyInfoViewDTO.setApplyTime(new Date());
        dbUnlockApplyInfoViewDTO.setSaleGroupIds(campaignGroupOrderCommandViewDTO.getSaleGroupIds());
        dbUnlockApplyInfoViewDTO.setStatus(BrandCampaignGroupProcessStatusEnum.EDITED.getCode());
        campaignGroupUnlockViewDTO.setUnlockApplyInfoViewDTO(dbUnlockApplyInfoViewDTO);
        campaignGroupViewDTO.setCampaignGroupUnlockViewDTO(campaignGroupUnlockViewDTO);

        return null;
    }

    /**
     * 备份申请流程记录
     * @param unlockApplyInfoViewDTO
     * @param campaignGroupViewDTO
     */
    private void backupFinishedProcessRecord(UnlockApplyInfoViewDTO unlockApplyInfoViewDTO, CampaignGroupViewDTO campaignGroupViewDTO) {
        if (unlockApplyInfoViewDTO == null || !BizCampaignGroupToolsHelper.isFinish(unlockApplyInfoViewDTO.getStatus())) {
            return;
        }
        ProcessRecordViewDTO processRecordViewDTO = buildProcessRecordViewDTO(unlockApplyInfoViewDTO);
        List<ProcessRecordViewDTO> processRecordViewDTOList = Optional.ofNullable(campaignGroupViewDTO.getProcessRecordViewDTOList()).orElse(Lists.newArrayList());
        processRecordViewDTOList.add(processRecordViewDTO);

        campaignGroupViewDTO.setProcessRecordViewDTOList(processRecordViewDTOList);
    }
    private ProcessRecordViewDTO buildProcessRecordViewDTO(UnlockApplyInfoViewDTO unlockApplyInfoViewDTO) {
        ProcessRecordViewDTO recordViewDTO = new ProcessRecordViewDTO();
        recordViewDTO.setStatus(unlockApplyInfoViewDTO.getStatus());
        recordViewDTO.setApplyTime(unlockApplyInfoViewDTO.getApplyTime());
        recordViewDTO.setFinishTime(unlockApplyInfoViewDTO.getFinishTime());
        recordViewDTO.setProcInstId(unlockApplyInfoViewDTO.getProcInstId());
        recordViewDTO.setApplyContent(StringUtils.join(unlockApplyInfoViewDTO.getSaleGroupIds(), ","));
        recordViewDTO.setType(BrandCampaignGroupProcessTypeEnum.UNLOCK.getCode());
        return recordViewDTO;
    }
}
