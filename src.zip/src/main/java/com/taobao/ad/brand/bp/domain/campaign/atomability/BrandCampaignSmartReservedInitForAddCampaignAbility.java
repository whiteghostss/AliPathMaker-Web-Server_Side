package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.guarantee.CampaignGuaranteeViewDTO;
import com.alibaba.ad.brand.dto.campaign.smartreserved.CampaignSmartReservedViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.product.CastTypeEnum;
import com.alibaba.ad.nb.ssp.constant.common.MediaScopeEnum;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignSmartReservedInitForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignSmartReservedAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandCampaignSmartReservedInitForAddCampaignAbility implements ICampaignSmartReservedInitForAddCampaignAbility, BrandAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignSmartReservedAbilityParam abilityParam) {
        CampaignSmartReservedViewDTO smartReservedViewDTO = abilityParam.getAbilityTarget();
        ProductViewDTO productViewDTO = abilityParam.getProductViewDTO();
        ResourcePackageProductViewDTO resourcePackageProductViewDTO = abilityParam.getResourcePackageProductViewDTO();
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();
        AssertUtil.notNull(productViewDTO,"产品不存在");
        AssertUtil.notNull(resourcePackageProductViewDTO,"资源产品不存在");
        AssertUtil.notNull(smartReservedViewDTO,"计划智能预留信息不存在");
        AssertUtil.notNull(campaignViewDTO,"计划信息不存在");

        Integer castType = BizCampaignToolsHelper.getCampaignCastType(campaignViewDTO, resourcePackageProductViewDTO);
        //【二环PDB】是否启动打底素材（界面不展示，底层默认逻辑）：与推送比联动，推送比为100%，默认为“是” 且不可修改；推送比为非100%，默认为“否” 且不可修改
        if(MediaScopeEnum.TAO_OUT.getCode().equals(productViewDTO.getMediaScope()) && CastTypeEnum.PDB.getValue().equals(castType)){
            smartReservedViewDTO.setIsSupportBottomMaterial(BrandBoolEnum.BRAND_FALSE.getCode());
            Long sspPushSendRatio = Optional.ofNullable(campaignViewDTO.getCampaignGuaranteeViewDTO())
                    .map(CampaignGuaranteeViewDTO::getSspPushSendRatio).map(Long::valueOf).orElse(0L);
            if(Objects.equals(sspPushSendRatio, Constant.RATIO_100)){
                smartReservedViewDTO.setIsSupportBottomMaterial(BrandBoolEnum.BRAND_TRUE.getCode());
            }
        }
        return null;
    }
}
