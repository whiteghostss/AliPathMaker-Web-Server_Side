package com.taobao.ad.brand.bp.domain.perform;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.globaltag.GlobalTagViewDTO;
import com.taobao.ad.brand.perform.client.dto.globaltag.query.GlobalTagQueryViewDTO;
import com.taobao.ad.brand.perform.client.dto.shopwindow.spu.marketingrule.SpuCheckMarketingRuleViewDTO;

import java.util.List;
import java.util.Set;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/03/08
 */
public interface PerformRepository {

    /**
     * 日更结束回调
     */
    void doCampaignDailyEnd();

    List<GlobalTagViewDTO> findGlobalTagList(ServiceContext serviceContext, GlobalTagQueryViewDTO queryViewDTO);

    Set<String> getSortedScoreSet(ServiceContext serviceContext, List<Long> idList);

    List<SpuCheckMarketingRuleViewDTO> getCheckMarketingRule(ServiceContext serviceContext);
}
