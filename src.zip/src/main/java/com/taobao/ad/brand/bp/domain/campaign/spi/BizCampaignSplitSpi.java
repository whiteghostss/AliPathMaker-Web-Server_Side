package com.taobao.ad.brand.bp.domain.campaign.spi;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandSubCampaignSplitCodeEnum;
import com.alibaba.ad.nb.framework.core.AbilitySpi;
import com.alibaba.ad.nb.framework.core.annotation.Ability;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleProductLineEnum;
import com.alibaba.ad.nb.ssp.constant.common.MediaScopeEnum;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignDayPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignPVAssignSceneEnum;
import com.taobao.ad.brand.bp.domain.sdk.campaign.ability.param.BizCampaignSplitAbilityParam;
import org.apache.commons.collections.CollectionUtils;

import java.util.List;

/**
 * @author yuanxinxi
 */
@Ability(desc = "计划拆分子计划")
public interface BizCampaignSplitSpi extends AbilitySpi {

    /**
     * 不跨域拆分
     */
    String CAMPAIGN_COPY = "copyCampaign";
    /**
     * 跨域拆分
     */
    String CAMPAIGN_SPLIT_CROSS = "crossCampaign";
    /**
     * 价格拆分
     */
    String CAMPAIGN_SPLIT_PRICE_PERIOD = "pricePeriodCampaign";
    /**
     * 跨域 * 多价格波段拆分
     */
    String CAMPAIGN_CROSS_SPLIT_PRICE_PERIOD = "crossPricePeriodCampaign";
    /**
     * ADV拆分
     */
    String CAMPAIGN_SPLIT_EFFECT_ADV = "effectAdvCampaign";

    /**
     * 查询拆分spiCode
     * @param campaignViewDTO
     * @param resourcePackageProductViewDTO
     * @return
     */
    static String getSplitSpiCode(CampaignViewDTO campaignViewDTO,ResourcePackageProductViewDTO resourcePackageProductViewDTO){
        //UD效果代投场景拆分
        if(SaleProductLineEnum.UD_EFFECT_CASTING.getValue().equals(campaignViewDTO.getCampaignSaleViewDTO().getSaleProductLine())){
            return BrandSubCampaignSplitCodeEnum.CAMPAIGN_SPLIT_EFFECT_ADV.getCode();
        }
        //如果是跨域二级产品则是跨域
        if(MediaScopeEnum.CROSS_SCOPE.getCode().equals(campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope())) {
            //如果是价格波段则是分价格拆分
            if(CollectionUtils.isNotEmpty(resourcePackageProductViewDTO.getBandPriceList())
                    && resourcePackageProductViewDTO.getBandPriceList().stream().map(ResourcePackageProductPriceViewDTO::getPrice).distinct().count() > 1){
                return BrandSubCampaignSplitCodeEnum.CAMPAIGN_CROSS_SPLIT_PRICE_PERIOD.getCode();
            }
            return BrandSubCampaignSplitCodeEnum.CAMPAIGN_SPLIT_CROSS.getCode();
        }
        //如果是价格波段则是分价格拆分
        if(CollectionUtils.isNotEmpty(resourcePackageProductViewDTO.getBandPriceList())
                && resourcePackageProductViewDTO.getBandPriceList().stream().map(ResourcePackageProductPriceViewDTO::getPrice).distinct().count() > 1) {
            return BrandSubCampaignSplitCodeEnum.CAMPAIGN_SPLIT_PRICE_PERIOD.getCode();
        }
        return BrandSubCampaignSplitCodeEnum.CAMPAIGN_COPY.getCode();
    }
    /**
     * 查询拆分spiCode
     * @param campaignViewDTO
     * @param campaignPriceViewDTO
     * @return
     */
    static  String  getSplitSpiCode(CampaignViewDTO campaignViewDTO,CampaignPriceViewDTO campaignPriceViewDTO){
        //UD效果代投场景拆分
        if(SaleProductLineEnum.UD_EFFECT_CASTING.getValue().equals(campaignViewDTO.getCampaignSaleViewDTO().getSaleProductLine())){
            return BrandSubCampaignSplitCodeEnum.CAMPAIGN_SPLIT_EFFECT_ADV.getCode();
        }
        //如果是跨域二级产品则是跨域
        if(MediaScopeEnum.CROSS_SCOPE.getCode().equals(campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope())) {
            //如果是价格波段则是分价格拆分
            if(CollectionUtils.isNotEmpty(campaignPriceViewDTO.getPriceInfos())
                    && campaignPriceViewDTO.getPriceInfos().stream().map(CampaignDayPriceViewDTO::getDiscountPrice).distinct().count() > 1){
                return BrandSubCampaignSplitCodeEnum.CAMPAIGN_CROSS_SPLIT_PRICE_PERIOD.getCode();
            }
            return BrandSubCampaignSplitCodeEnum.CAMPAIGN_SPLIT_CROSS.getCode();
        }
        //如果是价格波段则是分价格拆分
        if(CollectionUtils.isNotEmpty(campaignPriceViewDTO.getPriceInfos())
                && campaignPriceViewDTO.getPriceInfos().stream().map(CampaignDayPriceViewDTO::getDiscountPrice).distinct().count() > 1) {
            return BrandSubCampaignSplitCodeEnum.CAMPAIGN_SPLIT_PRICE_PERIOD.getCode();
        }
        return BrandSubCampaignSplitCodeEnum.CAMPAIGN_COPY.getCode();
    }

    List<CampaignViewDTO> splitSubCampaign(ServiceContext serviceContext, CampaignViewDTO parentCampaignViewDTO, BizCampaignSplitAbilityParam splitAbilityParam);

    /**
     * 匹配子计划
     * @param serviceContext
     * @param sourceCampaignViewDTO
     * @param targetCampaignViewDTOList
     * @return
     */
    CampaignViewDTO matchSubCampaign(ServiceContext serviceContext, CampaignViewDTO sourceCampaignViewDTO, List<CampaignViewDTO> targetCampaignViewDTOList);

    /**
     * 填充子计划定向数据
     *
     * @param serviceContext
     * @param campaignTreeViewDTO
     * @param resourcePackageProductViewDTO
     * @return
     */
    Void fillSubCampaignTarget(ServiceContext serviceContext, CampaignViewDTO campaignTreeViewDTO, ResourcePackageProductViewDTO resourcePackageProductViewDTO);

    /**
     * diff拆分
     *
     * @param campaignViewDTO
     * @param dbCampaignViewDTO
     */
    Boolean diffForSplit(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, CampaignViewDTO dbCampaignViewDTO, BizCampaignSplitAbilityParam splitAbilityParam);


    /**
     * 分配预算
     * @param campaignPriceViewDTO
     * @param campaignViewDTO
     */
    //List<CampaignViewDTO> assignBudget(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, Map<Long,List<PriceEnginePublishPriceViewDTO>> campaignPriceEnginePublishPriceMap, CampaignPriceViewDTO campaignPriceViewDTO  , CampaignViewDTO campaignViewDTO);

    List<CampaignViewDTO> assignSubCampaignBudget(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, CampaignPriceViewDTO campaignPriceViewDTO, CampaignViewDTO campaignViewDTO,
                                       CampaignPVAssignSceneEnum campaignPVAssignSceneModel);
    /**
     * 分配预算
     * @param campaignPriceViewDTO
     * @param campaignViewDTO
     */
    //List<CampaignViewDTO> unlockAssignBudget(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, CampaignPriceViewDTO campaignPriceViewDTO  , CampaignViewDTO campaignViewDTO);
}
