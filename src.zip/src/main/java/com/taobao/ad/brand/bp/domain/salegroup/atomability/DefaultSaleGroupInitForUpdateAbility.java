package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupInitForUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupInitAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
@BusinessAbility
public class DefaultSaleGroupInitForUpdateAbility implements ISaleGroupInitForUpdateAbility {

    @Override
    public Void handle(ServiceContext serviceContext, SaleGroupInitAbilityParam abilityParam) {
        if (CollectionUtils.isEmpty(abilityParam.getAbilityTargets()) || CollectionUtils.isEmpty(abilityParam.getOperateSaleGroupIds())) {
            return null;
        }
        List<Long> updateSaleGroupIds = abilityParam.getOperateSaleGroupIds();
        Map<Long, ResourcePackageSaleGroupViewDTO> packageSaleGroupMap = abilityParam.getResourcePackageSaleGroupMap();
        for (SaleGroupInfoViewDTO saleGroupInfoViewDTO : abilityParam.getAbilityTargets()) {
            if (!packageSaleGroupMap.containsKey(saleGroupInfoViewDTO.getSaleGroupId()) || !updateSaleGroupIds.contains(saleGroupInfoViewDTO.getSaleGroupId())) {
                continue;
            }
            ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO = packageSaleGroupMap.get(saleGroupInfoViewDTO.getSaleGroupId());
            saleGroupInfoViewDTO.setBudget(resourcePackageSaleGroupViewDTO.getBudget());
        }

        return null;
    }
}
