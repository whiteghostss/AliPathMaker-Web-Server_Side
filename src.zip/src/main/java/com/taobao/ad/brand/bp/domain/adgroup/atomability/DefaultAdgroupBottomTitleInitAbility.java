package com.taobao.ad.brand.bp.domain.adgroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;

import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.adgroup.repository.AdgroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupBottomTitleInitAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupTitleInitAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultAdgroupBottomTitleInitAbility implements IAdgroupBottomTitleInitAbility {

    private final AdgroupRepository adgroupRepository;
    /**
     * 单元固定后缀
     */
    private final static String ADGROUP_FIXED_SUFFIX = "计划人群兜底单元";
    /**
     * 单元标题最大长度
     */
    private final static int ADGROUP_MAX_LENGTH = 100;

    @Override
    public String handle(ServiceContext serviceContext, AdgroupTitleInitAbilityParam abilityParam) {
        AdgroupViewDTO adgroupViewDTO = abilityParam.getAbilityTarget();
        if(StringUtils.isNotBlank(adgroupViewDTO.getTitle())){
            return adgroupViewDTO.getTitle();
        }
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        AssertUtil.notNull(dbCampaignViewDTO,"计划不能为空");
        // 拼接后单元名称超过100字符的，往前截断
        String adgroupTitle = genTitle(dbCampaignViewDTO.getTitle(),ADGROUP_FIXED_SUFFIX);
        AdgroupViewDTO dbDTO = adgroupRepository.queryAdgroupTopOneByName(serviceContext,adgroupViewDTO.getId(),adgroupTitle);
        //如果单元标题重复，追加计划id
        if(dbDTO != null){
            adgroupTitle = genTitle(dbCampaignViewDTO.getTitle(),String.format("%s%s", dbCampaignViewDTO.getId(),ADGROUP_FIXED_SUFFIX));
        }
        return adgroupTitle;
    }

    private String genTitle(String title,String titleSuffix){
        // 拼接后单元名称超过100字符的，往前截断
        int needLength = ADGROUP_MAX_LENGTH - titleSuffix.length();
        if(title.length() > needLength){
            title = title.substring(0, needLength);
        }
        return String.format("%s%s", title,titleSuffix);
    }
}
