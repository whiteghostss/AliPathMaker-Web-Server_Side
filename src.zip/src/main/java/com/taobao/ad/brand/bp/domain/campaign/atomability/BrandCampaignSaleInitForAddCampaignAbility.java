package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.sale.CampaignSaleViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignSaleInitForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignSaleAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandCampaignSaleInitForAddCampaignAbility implements ICampaignSaleInitForAddCampaignAbility, BrandAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignSaleAbilityParam abilityParam) {
        CampaignSaleViewDTO campaignSaleViewDTO = abilityParam.getAbilityTarget();
        ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO = abilityParam.getResourcePackageSaleGroupViewDTO();
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        ResourcePackageProductViewDTO resourcePackageProductViewDTO = abilityParam.getResourcePackageProductViewDTO();
        SaleGroupInfoViewDTO saleGroupViewDTO = abilityParam.getSaleGroupInfoViewDTO();
        ProductViewDTO productViewDTO = abilityParam.getProductViewDTO();

        AssertUtil.notNull(campaignSaleViewDTO,"售卖信息不能为空");
        AssertUtil.notNull(resourcePackageSaleGroupViewDTO,"售卖分组不能为空");
        AssertUtil.notNull(campaignGroupViewDTO,"订单不能为空");
        AssertUtil.notNull(saleGroupViewDTO,"订单分组不能为空");
        AssertUtil.notNull(resourcePackageProductViewDTO,"分组产品不能为空");
        AssertUtil.notNull(productViewDTO,"产品不能为空");

        // 计划售卖类型：购买、赠送、补量
        campaignSaleViewDTO.setSaleType(resourcePackageSaleGroupViewDTO.getSaleType());
        campaignSaleViewDTO.setCustomerId(campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getCustomerId());
        campaignSaleViewDTO.setCustomerTemplateId(resourcePackageSaleGroupViewDTO.getTemplateId());
        campaignSaleViewDTO.setProductConfigType(resourcePackageSaleGroupViewDTO.getProductConfigType());
        campaignSaleViewDTO.setSaleUnit(resourcePackageProductViewDTO.getSaleUnit() == null ? productViewDTO.getSellUnit() : resourcePackageProductViewDTO.getSaleUnit());
        campaignSaleViewDTO.setSaleProductLine(resourcePackageSaleGroupViewDTO.getSaleProductLine());
        campaignSaleViewDTO.setSaleBusinessLine(resourcePackageSaleGroupViewDTO.getBusinessLine());
        if(Objects.nonNull(saleGroupViewDTO.getSubContractId())){
            campaignSaleViewDTO.setSubContractId(saleGroupViewDTO.getSubContractId());
        }
        if(Objects.nonNull(campaignGroupViewDTO.getCampaignGroupContractViewDTO().getContractId())){
            campaignSaleViewDTO.setContractId(campaignGroupViewDTO.getCampaignGroupContractViewDTO().getContractId());
        }
        return null;
    }
}
