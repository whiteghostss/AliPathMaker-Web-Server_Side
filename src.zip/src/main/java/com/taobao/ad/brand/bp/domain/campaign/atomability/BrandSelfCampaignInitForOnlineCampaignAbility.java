package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryLockViewDTO;
import com.alibaba.ad.brand.dto.campaign.sale.CampaignSaleViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignInitForOnlineCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignForOnlineAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.Objects;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSelfCampaignInitForOnlineCampaignAbility implements ICampaignInitForOnlineCampaignAbility, BrandSelfServiceAtomAbilityRouter {

    @Override
    public List<CampaignViewDTO> handle(ServiceContext serviceContext, CampaignForOnlineAbilityParam abilityParam) {
        List<CampaignViewDTO> campaignViewDTOList = abilityParam.getAbilityTargets();
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        List<Long> onlineSaleGroupIds = abilityParam.getOnlineSaleGroupIds();
        List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList= campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList();
        List<CampaignViewDTO> updateList = Lists.newArrayList();

        for (CampaignViewDTO item : campaignViewDTOList) {
            CampaignViewDTO updateCampaignViewDTO = new CampaignViewDTO();
            updateCampaignViewDTO.setId(item.getId());
            //设置子合同id
            for (SaleGroupInfoViewDTO saleGroupInfoViewDTO : saleGroupInfoViewDTOList) {
                if (!onlineSaleGroupIds.contains(saleGroupInfoViewDTO.getSaleGroupId())) {
                    continue;
                }
                if(!saleGroupInfoViewDTO.getSaleProductLine().equals(item.getCampaignSaleViewDTO().getSaleProductLine())){
                    continue;
                }
                CampaignSaleViewDTO campaignSaleViewDTO = new CampaignSaleViewDTO();
                campaignSaleViewDTO.setSubContractId(saleGroupInfoViewDTO.getSubContractId());
                campaignSaleViewDTO.setContractId(campaignGroupViewDTO.getCampaignGroupContractViewDTO().getContractId());
                updateCampaignViewDTO.setCampaignSaleViewDTO(campaignSaleViewDTO);
            }
            //设置状态
            if(BrandDateUtil.isAfter(item.getStartTime(),BrandDateUtil.getCurrentDate())){
                updateCampaignViewDTO.setStatus(BrandCampaignStatusEnum.WAITING.getCode());
            } else if(BrandDateUtil.isAfterAndEqual( item.getEndTime(),BrandDateUtil.getCurrentDate())
                    && BrandDateUtil.isBeforeAndEqual(item.getStartTime(),BrandDateUtil.getCurrentDate())
            ){
                updateCampaignViewDTO.setStatus(BrandCampaignStatusEnum.CASTING.getCode());
            } else if (BrandDateUtil.isBefore(item.getEndTime(), BrandDateUtil.getCurrentDate())) {
                updateCampaignViewDTO.setStatus(BrandCampaignStatusEnum.ENDING.getCode());
            }
            if(Objects.isNull(item.getCampaignInquiryLockViewDTO().getFirstOnlineTime())){
                CampaignInquiryLockViewDTO campaignInquiryLockViewDTO = new CampaignInquiryLockViewDTO();
                campaignInquiryLockViewDTO.setFirstOnlineTime(new Date());
                updateCampaignViewDTO.setCampaignInquiryLockViewDTO(campaignInquiryLockViewDTO);
            }
            updateList.add(updateCampaignViewDTO);
        }
        return updateList;
    }
}
