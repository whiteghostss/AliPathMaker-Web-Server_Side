package com.taobao.ad.brand.bp.domain.campaign.workflow;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryLockViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignInventoryAutoReleaseWarningTypeEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.context.CampaignInventoryCallbackNoticeContext;
import com.taobao.ad.brand.bp.client.context.DomainMetaqMessageBodyContext;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignDelayLockApplyViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignInquiryOperateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignInventoryAutoReleaseMsgViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignScheduleViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignGroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.SaleGroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignEventEnum;
import com.taobao.ad.brand.bp.client.enums.message.DomainMessageTypeEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.event.campaign.CampaignInventoryCallbackEvent;
import com.taobao.ad.brand.bp.domain.sdk.base.workflow.router.BrandExtensionRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.inventory.ICampaignBoostUpdateForCampaignInventoryCallbackAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignInventoryCallbackAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignAutoReleaseWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignInventoryWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.IMessageAsyncSendAbility;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.IMessageSyncSendAbility;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.param.MessageAsyncSendAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.param.MessageSyncSendAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Description:
 * <p>
 * date: 2023/10/24 2:51 PM
 *
 * @author shiyan
 * @version 1.0
 */
@Service
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandCampaignInventoryWorkflowExtImpl extends DefaultCampaignInventoryWorkflowExtImpl implements BrandExtensionRouter {

    private final CampaignGroupRepository campaignGroupRepository;
    private final CampaignRepository campaignRepository;
    private final ICampaignStructureQueryAbility campaignStructureQueryAbility;
    private final ICampaignBoostUpdateForCampaignInventoryCallbackAbility campaignBoostUpdateForCampaignInventoryCallbackAbility;
    private final IMessageAsyncSendAbility messageAsyncSendAbility;
    private final IMessageSyncSendAbility messageSyncSendAbility;

    @Override
    public BizCampaignInventoryWorkflowParam buildParamForInventory(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO) {
        AssertUtil.notNull(inquiryOperateViewDTO, "查询参数不能为空");
        AssertUtil.notEmpty(inquiryOperateViewDTO.getCampaignIdList(), "计划不能为空");
        AssertUtil.notNull(inquiryOperateViewDTO.getOperateType(), "操作类型不允许为空");

        List<CampaignViewDTO> campaignTreeViewDTOList = findCampaignTreeList(serviceContext, inquiryOperateViewDTO.getCampaignIdList());
        AssertUtil.notEmpty(campaignTreeViewDTOList,"计划不存在或已被删除");
        List<CampaignGroupViewDTO> campaignGroupList = findCampaignGroupList(serviceContext, campaignTreeViewDTOList);
        AssertUtil.notEmpty(campaignGroupList,"订单不存在");

        return BizCampaignInventoryWorkflowParam.builder().campaignTreeViewDTOList(campaignTreeViewDTOList)
                .campaignGroupViewDTOList(campaignGroupList).build();
    }

    @Override
    public Void afterInventoryCallback(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inventoryCallbackViewDTO, BizCampaignInventoryWorkflowParam inventoryWorkflowParam, List<CampaignScheduleViewDTO> campaignScheduleViewDTOList) {
        if(CollectionUtils.isEmpty(inventoryWorkflowParam.getCampaignTreeViewDTOList())){
            return null;
        }
        List<CampaignViewDTO> campaignTreeViewDTOList = inventoryWorkflowParam.getCampaignTreeViewDTOList();
        Map<Long, CampaignScheduleViewDTO> scheduleViewDTOMap = campaignScheduleViewDTOList.stream().collect(Collectors.toMap(CampaignScheduleViewDTO::getId, Function.identity(), (v1, v2) -> v2));
        for (CampaignViewDTO campaignTreeViewDTO : campaignTreeViewDTOList) {
            CampaignScheduleViewDTO campaignScheduleViewDTO = scheduleViewDTOMap.get(campaignTreeViewDTO.getId());
            if(campaignScheduleViewDTO ==null){
                continue;
            }
            //锁量成功回调
            fire(serviceContext, campaignTreeViewDTO, campaignScheduleViewDTO);

            //联合控量补量计划释量后需更新控量计划
            campaignBoostUpdateForCampaignInventoryCallbackAbility.handle(serviceContext,
                    CampaignInventoryCallbackAbilityParam.builder().abilityTarget(inventoryCallbackViewDTO).campaignTreeViewDTO(campaignTreeViewDTO).build());

            //触发锁量回调通知事件
            fireCallbackNoticeEvent(serviceContext,campaignTreeViewDTO,inventoryCallbackViewDTO);
        }
        return null;
    }

    @Override
    public Void beforeInventoryAutoReleaseWarning(ServiceContext context, List<CampaignInventoryAutoReleaseMsgViewDTO> inventoryAutoReleaseMsgViewDTOList) {
        AssertUtil.notEmpty(inventoryAutoReleaseMsgViewDTOList, "待预警计划信息不能为空");
        for (CampaignInventoryAutoReleaseMsgViewDTO autoReleaseMsgViewDTO : inventoryAutoReleaseMsgViewDTOList) {
            Long campaignGroupId = Optional.ofNullable(autoReleaseMsgViewDTO).map(CampaignInventoryAutoReleaseMsgViewDTO::getCampaignGroupViewDTO)
                    .map(CampaignGroupViewDTO::getId).orElse(null);
            AssertUtil.notNull(campaignGroupId, "待预警订单信息不能为空");
            AssertUtil.notEmpty(autoReleaseMsgViewDTO.getCampaignViewDTOList(), "待预警计划信息不能为空");
            AssertUtil.notNull(autoReleaseMsgViewDTO.getWarningType(), "预警类型不能为空");
            BrandCampaignInventoryAutoReleaseWarningTypeEnum releaseWarningTypeEnum =
                    BrandCampaignInventoryAutoReleaseWarningTypeEnum.getByCode(autoReleaseMsgViewDTO.getWarningType());
            AssertUtil.notNull(releaseWarningTypeEnum, "无效的预警类型");
        }
        return null;
    }

    @Override
    public List<BizCampaignAutoReleaseWorkflowParam> buildAutoReleaseDelayLockParamExt(ServiceContext serviceContext, CampaignDelayLockApplyViewDTO campaignDelayLockApplyViewDTO) {

        CampaignQueryViewDTO query = new CampaignQueryViewDTO();
        query.setCampaignIds(campaignDelayLockApplyViewDTO.getCampaignIdList());
        query.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
        List<CampaignViewDTO> campaignList = campaignRepository.queryCampaignList(serviceContext, query);
        AssertUtil.notEmpty(campaignList,"未找到对应计划");
        List<CampaignGroupViewDTO> campaignGroupList = campaignGroupRepository.findCampaignGroupByIds(serviceContext,campaignList.stream().map(item->item.getCampaignGroupId()).distinct().collect(
                Collectors.toList()));
        List<Long> saleGroupIds = campaignList.stream().map(item->item.getCampaignSaleViewDTO().getSaleGroupId()).distinct().collect(Collectors.toList());
        List<Long> campaignGroupIds = campaignGroupList.stream().map(item->item.getId()).distinct().collect(Collectors.toList());

        SaleGroupQueryViewDTO saleGroupQueryViewDTO = new SaleGroupQueryViewDTO();
        saleGroupQueryViewDTO.setSaleGroupIds(saleGroupIds);
        saleGroupQueryViewDTO.setCampaignGroupIds(campaignGroupIds);

        List<SaleGroupInfoViewDTO> saleGroupList = campaignGroupRepository.findSaleGroupList(serviceContext,saleGroupQueryViewDTO);
        List<BizCampaignAutoReleaseWorkflowParam> autoReleaseWorkflowParams = Lists.newArrayList();
        for(CampaignViewDTO campaignViewDTO : campaignList){
            BizCampaignAutoReleaseWorkflowParam bizCampaignAutoReleaseWorkflowParam = new BizCampaignAutoReleaseWorkflowParam();
            bizCampaignAutoReleaseWorkflowParam.setCampaignViewDTO(campaignViewDTO);
            CampaignGroupViewDTO campaignGroupViewDTO =  campaignGroupList.stream().filter(item->campaignViewDTO.getCampaignGroupId().equals(item.getId())).findFirst().get();
            bizCampaignAutoReleaseWorkflowParam.setCampaignGroupViewDTO(campaignGroupViewDTO);
            SaleGroupInfoViewDTO saleGroupInfoViewDTO = saleGroupList.stream().filter(
                    item->campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId().equals(item.getSaleGroupId())
                            && campaignViewDTO.getCampaignGroupId().equals(item.getCampaignGroupId())).findFirst().get();
            bizCampaignAutoReleaseWorkflowParam.setSaleGroupInfoViewDTO(saleGroupInfoViewDTO);
            autoReleaseWorkflowParams.add(bizCampaignAutoReleaseWorkflowParam);
        }
        return autoReleaseWorkflowParams;
    }

    /**
     * 锁量成功构建打底单元
     *
     * @param serviceContext
     * @param campaignTreeViewDTO
     * @param campaignScheduleViewDTO
     */
    private void fire(ServiceContext serviceContext, CampaignViewDTO campaignTreeViewDTO, CampaignScheduleViewDTO campaignScheduleViewDTO) {
        RogerLogger.info("计划" + campaignTreeViewDTO.getId() + "info:"+ JSON.toJSON(campaignScheduleViewDTO));
        if (!BrandCampaignStatusEnum.LOCK_SUCCESS.getCode().equals(campaignScheduleViewDTO.getStatus())) {
            RogerLogger.info("计划" + campaignTreeViewDTO.getId() + "非锁量");
            return;
        }
        campaignTreeViewDTO.setStatus(campaignScheduleViewDTO.getStatus());

        CampaignInquiryLockViewDTO campaignInquiryLockViewDTO = Optional.ofNullable(campaignTreeViewDTO.getCampaignInquiryLockViewDTO()).orElse(new CampaignInquiryLockViewDTO());
        campaignInquiryLockViewDTO.setCampaignInquiryViewDTOList(campaignScheduleViewDTO.getInquiryViewDTOList());
        campaignTreeViewDTO.setCampaignInquiryLockViewDTO(campaignInquiryLockViewDTO);
        //事件消息
        RogerLogger.info("计划" + campaignTreeViewDTO.getId() + "fire start");
        fireAsyncMessageEvent(serviceContext,campaignTreeViewDTO);
        RogerLogger.info("计划" + campaignTreeViewDTO.getId() + "fire success");
    }

    /**
     * 生成异步通知事件
     * @param serviceContext
     * @param campaign
     * @return
     */
    private void fireAsyncMessageEvent(ServiceContext serviceContext, CampaignViewDTO campaign){
        DomainMetaqMessageBodyContext msgBodyContext = DomainMetaqMessageBodyContext.builder()
                .bizCode(serviceContext.getBizCode())
                .domainType(DomainMessageTypeEnum.MAIN_CAMPAIGN)
                .domainEvent(CampaignEventEnum.LOCK_SUCCESS.name())
                .entityId(campaign.getId())
                .memberId(campaign.getMemberId())
                .build();
        messageAsyncSendAbility.handle(serviceContext, MessageAsyncSendAbilityParam.builder().abilityTarget(msgBodyContext).build());
    }

    /**
     * 生成回调通知事件
     * @param serviceContext
     * @param campaign
     * @return
     */
    private void fireCallbackNoticeEvent(ServiceContext serviceContext, CampaignViewDTO campaign,CampaignInquiryOperateViewDTO inventoryCallbackViewDTO){
        CampaignInventoryCallbackNoticeContext campaignNoticeContext = CampaignInventoryCallbackNoticeContext.builder()
                .serviceContext(serviceContext).campaignViewDTO(campaign).campaignInquiryOperateViewDTO(inventoryCallbackViewDTO).build();
        messageSyncSendAbility.handle(serviceContext,
                MessageSyncSendAbilityParam.builder().abilityTarget(CampaignInventoryCallbackEvent.of(campaignNoticeContext)).build());
    }

    /**
     * 获取计划树
     * @param context
     * @param campaignIdList
     * @return
     */
    private List<CampaignViewDTO> findCampaignTreeList(ServiceContext context, List<Long> campaignIdList) {
        CampaignQueryViewDTO query = new CampaignQueryViewDTO();
        query.setCampaignIds(campaignIdList);
        CampaignQueryOption option = new CampaignQueryOption();
        option.setNeedCampaignTree(true);
        option.setNeedTarget(true);
        option.setNeedFrequency(true);

        return campaignStructureQueryAbility.handle(context, CampaignStructureQueryAbilityParam.builder()
                .abilityTarget(query).queryOption(option).build());
    }

    private List<CampaignGroupViewDTO> findCampaignGroupList(ServiceContext context, List<CampaignViewDTO> campaignList) {
        List<Long> campaignGroupIdSet = campaignList.stream().map(v -> v.getCampaignGroupId()).distinct().collect(
                Collectors.toList());
        if (CollectionUtils.isEmpty(campaignGroupIdSet)) {
            return Lists.newArrayList();
        }
        CampaignGroupQueryViewDTO campaignGroupQueryViewDTO = new CampaignGroupQueryViewDTO();
        campaignGroupQueryViewDTO.setIds(campaignGroupIdSet);
        campaignGroupQueryViewDTO.setPageSize(campaignGroupIdSet.size());
        PageResultViewDTO<CampaignGroupViewDTO> pageList = campaignGroupRepository.findCampaignGroupPageList(context,
                campaignGroupQueryViewDTO);
        return pageList.getList();
    }
}