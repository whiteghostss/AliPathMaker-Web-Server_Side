package com.taobao.ad.brand.bp.domain.adc.repository;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.dto.adc.AdcCdnViewDTO;
import com.taobao.ad.brand.bp.client.dto.adc.AdcComponentViewDTO;
import com.taobao.ad.brand.bp.client.dto.adc.query.AdcQueryViewDTO;

import java.util.List;

/**
 * ADC相关服务
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
public interface AdcRepository {
    /**
     * 查询菜单
     * @param context
     * @param queryViewDTO
     * @return
     */
    List<AdcComponentViewDTO> findMenuList(ServiceContext context, AdcQueryViewDTO queryViewDTO);

    /**
     * 查询组件
     * @param context
     * @param queryViewDTO
     * @return
     */
    List<AdcComponentViewDTO> findComponentList(ServiceContext context, AdcQueryViewDTO queryViewDTO);

    /**
     * 查询onesite配置
     * @return
     */
    List<AdcCdnViewDTO> findOneSiteCdnList(ServiceContext context);
    /**
     * 查询onesite配置
     * https://aliyuque.antfin.com/qe2oq1/qvd6hi/xgyw5ch3qxiepko6
     * 根据domain取cdn
     * @return
     */
    List<AdcCdnViewDTO> findOneSiteCdnListByUrl(ServiceContext context,String domainName);
}
