package com.taobao.ad.brand.bp.domain.config;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.domain.config.base.BaseDiamondConfig;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Set;

/**
 * ADC节点id和brand-onebp嵌入模块映射配置
 */
@Component
public class AdcIdToModuleDiamondConfig extends BaseDiamondConfig {

    private static volatile String embeddedMappingConfig;

    @Override
    protected String getDataId() {
        return "permission.embedded-module.mapping-config";
    }
    @Override
    protected String getGroupId() { return "com.taobao.ad.brand.bp"; }

    @Override
    protected void initDiamond(String diamondConfig) {
        RogerLogger.info("DiamondConfig.initDiamond AdcIdToModuleDiamondConfig param: {}", diamondConfig);
        embeddedMappingConfig = diamondConfig;
    }

    /**
     * 获取映射配置
     * @return
     */
    public Map<Long, Set<String>> getEmbeddedMappingConfig(){
        if (StringUtils.isBlank(embeddedMappingConfig)) {
            return Maps.newHashMap();
        }
        return JSON.parseObject(embeddedMappingConfig, new TypeReference<Map<Long, Set<String>>>() {});
    }
}
