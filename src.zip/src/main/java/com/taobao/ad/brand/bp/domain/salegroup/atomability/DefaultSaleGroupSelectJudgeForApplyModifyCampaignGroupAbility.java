package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.unlock.UnlockApplyInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupProcessStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSaleOrderStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleGroupSourceEnum;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.salegroup.SaleGroupSelectJudgeViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.SaleGroupSelectReasonTypeEnum;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupSelectJudgeForApplyModifyCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupOrderAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultSaleGroupSelectJudgeForApplyModifyCampaignGroupAbility implements ISaleGroupSelectJudgeForApplyModifyCampaignGroupAbility {

    private final CampaignGroupRepository campaignGroupRepository;

    /**
     * 主订单-申请修改售卖分组时的订单状态
     */
    private static final List<Integer> validMainCampaignGroupStatusOnApplyModify = Lists.newArrayList(
            BrandCampaignGroupStatusEnum.EDITED.getCode(),
            BrandCampaignGroupStatusEnum.UNLOCKED.getCode(),
            BrandCampaignGroupStatusEnum.ORDER_ING.getCode()
    );

    /**
     * 主订单-申请修改售卖分组时的订单状态
     */
    private static final List<Integer> validSubCampaignGroupStatusOnApplyModify = Lists.newArrayList(
            BrandCampaignGroupStatusEnum.EDITED.getCode(),
            BrandCampaignGroupStatusEnum.ORDER_ING.getCode(),
            BrandCampaignGroupStatusEnum.CONTRACT_PROCESS_ING.getCode(),
            BrandCampaignGroupStatusEnum.UNLOCKED.getCode()
    );

    @Override
    public Map<Long, SaleGroupSelectJudgeViewDTO> handle(ServiceContext serviceContext, SaleGroupOrderAbilityParam abilityParam) {
        List<SaleGroupInfoViewDTO> applySaleGroupInfoViewDTOList = abilityParam.getAbilityTargets();
        CampaignGroupViewDTO subCampaignGroup = abilityParam.getCampaignGroupViewDTO();
        CampaignGroupViewDTO mainCampaignGroup = null;
        boolean hasSalePlatformSaleGroupIds = applySaleGroupInfoViewDTOList.stream().anyMatch(saleGroup -> BrandSaleGroupSourceEnum.SALE_PLATFORM.getCode().equals(saleGroup.getSource()));
        if (hasSalePlatformSaleGroupIds) {
            mainCampaignGroup = campaignGroupRepository.getCampaignGroup(serviceContext, subCampaignGroup.getParentId());
        }
        // 订单是否包含“Topshow/特秀/showmax”以外的产品线
        boolean hasOtherSaleProductLineSaleGroup = subCampaignGroup.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList()
                .stream().anyMatch(saleGroupInfoViewDTO -> !BizCampaignGroupToolsHelper.isTopShowOrTxOrShowMaxCampaignGroup(saleGroupInfoViewDTO.getSaleProductLine()));

        Map<Long, SaleGroupSelectJudgeViewDTO> resultMap = Maps.newHashMap();
        for (SaleGroupInfoViewDTO saleGroup : applySaleGroupInfoViewDTOList) {
            // 1. 校验售卖分组来源=售卖中心 的 订单状态是否支持选择
            if (BrandSaleGroupSourceEnum.SALE_PLATFORM.getCode().equals(saleGroup.getSource())) {
                if (!validSalePlatFormSaleGroupCanSelect(subCampaignGroup, mainCampaignGroup)) {
                    buildResultMap(saleGroup.getSaleGroupId(), BrandBoolEnum.BRAND_FALSE.getCode(), SaleGroupSelectReasonTypeEnum.CAST_ING.getCode(), resultMap);
                    continue;
                }
            }
            // 2. 校验分组本身的状态 非待下单状态可以勾选
            if (BrandCampaignGroupSaleOrderStatusEnum.WAIT_ORDER.getCode().equals(saleGroup.getSaleGroupStatus())) {
                buildResultMap(saleGroup.getSaleGroupId(), BrandBoolEnum.BRAND_FALSE.getCode(), SaleGroupSelectReasonTypeEnum.WAIT_ORDER.getCode(), resultMap);
                continue;
            }
            // 3. 当订单产品线除了“Topshow/特秀/showmax”还有别的产品线，Topshow/特秀/showmax的分组仅支持小二修改
            if (BizCampaignGroupToolsHelper.isTopShowOrTxOrShowMaxCampaignGroup(saleGroup.getSaleProductLine()) && hasOtherSaleProductLineSaleGroup) {
                boolean waiter = ServiceContextUtil.isAliStaff(serviceContext);
                if (!waiter) {
                    buildResultMap(saleGroup.getSaleGroupId(), BrandBoolEnum.BRAND_FALSE.getCode(), SaleGroupSelectReasonTypeEnum.CAST_ING.getCode(), resultMap);
                    continue;
                }
            }

            // 可选择
            buildResultMap(saleGroup.getSaleGroupId(), BrandBoolEnum.BRAND_TRUE.getCode(), getCanSelectReasonTypeOnModifyOrder(saleGroup, subCampaignGroup), resultMap);
        }

        return resultMap;
    }

    private Integer getCanSelectReasonTypeOnModifyOrder(SaleGroupInfoViewDTO saleGroup, CampaignGroupViewDTO campaignGroupViewDTO) {
        // 1. 分组是否被拒绝过 > 分组投放状态
        UnlockApplyInfoViewDTO lastUnlockApply = campaignGroupViewDTO.getCampaignGroupUnlockViewDTO().getUnlockApplyInfoViewDTO();
        if (lastUnlockApply != null && lastUnlockApply.getSaleGroupIds().contains(saleGroup.getSaleGroupId())
                && BizCampaignGroupToolsHelper.isRefuse(lastUnlockApply.getStatus())) {
            return SaleGroupSelectReasonTypeEnum.MODIFY_LAST_REFUSE.getCode();
        } else if (BrandCampaignGroupSaleOrderStatusEnum.ORDER_ING.getCode().equals(saleGroup.getSaleGroupStatus())) {
            return SaleGroupSelectReasonTypeEnum.ORDER_ING_OR_FINISHED.getCode();
        }  else if (BrandCampaignGroupSaleOrderStatusEnum.ORDER_FINISH.getCode().equals(saleGroup.getSaleGroupStatus())) {
            return SaleGroupSelectReasonTypeEnum.CAST_ING.getCode();
        }
        return null;
    }

    private boolean validSalePlatFormSaleGroupCanSelect(CampaignGroupViewDTO subCampaignGroup, CampaignGroupViewDTO mainCampaignGroup) {
        // 子订单状态不符合要求时，校验主订单状态是否支持修改
        if (!validSubCampaignGroupStatusOnApplyModify.contains(subCampaignGroup.getStatus())) {
            Integer campaignGroupStatus = mainCampaignGroup.getStatus();
            if (!validMainCampaignGroupStatusOnApplyModify.contains(campaignGroupStatus)) {
                return false;
            }
        }

        return true;
    }

    private void buildResultMap(Long saleGroupId, Integer canSelect, Integer selectReasonType, Map<Long, SaleGroupSelectJudgeViewDTO> resultMap) {
        SaleGroupSelectJudgeViewDTO selectJudgeViewDTO = new SaleGroupSelectJudgeViewDTO();
        selectJudgeViewDTO.setSaleGroupId(saleGroupId);
        selectJudgeViewDTO.setCanSelect(canSelect);
        selectJudgeViewDTO.setSelectReasonType(selectReasonType);

        resultMap.put(saleGroupId, selectJudgeViewDTO);
    }
}
