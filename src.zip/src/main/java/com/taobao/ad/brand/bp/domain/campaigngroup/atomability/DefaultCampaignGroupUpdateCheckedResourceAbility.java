package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.common.WakeupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupWakeupTypeEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.setting.BrandCampaignGroupSettingKeyEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupCheckedResourceViewDTO;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupUpdateCheckedResourceAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupUpdateCheckedResourceAbilityParam;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
@BusinessAbility
public class DefaultCampaignGroupUpdateCheckedResourceAbility implements ICampaignGroupUpdateCheckedResourceAbility {
    @Resource
    private CampaignGroupRepository campaignGroupRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupUpdateCheckedResourceAbilityParam abilityParam) {
        CampaignGroupCheckedResourceViewDTO checkedResourceViewDTO = abilityParam.getAbilityTarget();
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();

        CampaignGroupViewDTO updateCampaignGroup = new CampaignGroupViewDTO();
        updateCampaignGroup.setId(checkedResourceViewDTO.getId());
        updateCampaignGroup.setName(checkedResourceViewDTO.getName());
        updateCampaignGroup.setWakeupViewDTO(campaignGroupViewDTO.getWakeupViewDTO());
        updateCampaignGroup.setCampaignGroupSaleGroupViewDTO(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO());
        campaignGroupRepository.updateCampaignGroupPart(serviceContext, updateCampaignGroup);

        //不唤端 -> 删除历史设置的唤端配置
        WakeupViewDTO wakeupViewDTO = campaignGroupViewDTO.getWakeupViewDTO();
        if (wakeupViewDTO != null && BrandCampaignGroupWakeupTypeEnum.NON_WAKEUP.getCode().equals(wakeupViewDTO.getWakeupType())) {
            campaignGroupRepository.deleteCampaignGroupSettingBatch(serviceContext, checkedResourceViewDTO.getId(), Lists.newArrayList(BrandCampaignGroupSettingKeyEnum.SCHEMA_IDS.getKey(),
                    BrandCampaignGroupSettingKeyEnum.SCHEMA_CONFIG.getKey()));
        }

        return null;
    }
}
