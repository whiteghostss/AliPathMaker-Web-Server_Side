package com.taobao.ad.brand.bp.domain.campaigngroup.ability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.nb.ssp.constant.common.MediaScopeEnum;
import com.alibaba.ad.nb.ssp.constant.common.PinYinEnum;
import com.alibaba.ad.nb.ssp.constant.common.RuleItemTypeEnum;
import com.alibaba.ad.nb.ssp.constant.common.VideoVoiceEnum;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.client.context.ScheduleExportContext;
import com.taobao.ad.brand.bp.client.dto.mr.MaterialRuleDetailViewDTO;
import com.taobao.ad.brand.bp.client.dto.mr.MaterialRuleItemDetailViewDTO;
import com.taobao.ad.brand.bp.client.dto.mr.audiorule.AudioRuleViewDTO;
import com.taobao.ad.brand.bp.client.dto.mr.gif.GifRuleViewDTO;
import com.taobao.ad.brand.bp.client.dto.mr.picrule.PicRuleViewDTO;
import com.taobao.ad.brand.bp.client.dto.mr.textrule.TextRuleViewDTO;
import com.taobao.ad.brand.bp.client.dto.mr.videorule.VideoRuleViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.export.MaterialRuleExportEnum;
import com.taobao.ad.brand.bp.domain.ssp.MaterialRuleRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author jixiu.lj
 * @date 2023/3/29 13:34
 * MR全量数据组装
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizScheduleExportMrComposeAbility extends BizScheduleExportBaseComposeAbility {

    private final MaterialRuleRepository materialRuleRepository;


    /**
     * @return filedName-value
     * @see MaterialRuleExportEnum
     */
    public List<Map<MaterialRuleExportEnum, String>> compose(ServiceContext serviceContext,
                                                             ScheduleExportContext scheduleExportContext) {

        List<CampaignViewDTO> campaignViewDTOList = scheduleExportContext.getCampaignViewDTOList();
        Map<Long, ProductViewDTO> productDTOMap = scheduleExportContext.getProductDTOMap();
        Map<String, Set<Long>> productMaterialRuleMap = buildProductMaterialRuleMap(serviceContext, scheduleExportContext, campaignViewDTOList ,productDTOMap);


        List<MaterialRuleDetailViewDTO> materialRuleDetailDTOS = materialRuleRepository.getMaterialRuleDetailList(serviceContext, getMaterialRuleIds(productMaterialRuleMap));
        Map<Long, MaterialRuleDetailViewDTO> materialRuleModelMap = materialRuleDetailDTOS
            .stream()
            .filter(materialRuleDetailDTO -> Objects.nonNull(materialRuleDetailDTO.getRuleId()))
            .collect(Collectors.toMap(MaterialRuleDetailViewDTO::getRuleId, Function.identity()));


        List<Map<MaterialRuleExportEnum, String>> results = Lists.newArrayList();

        // 因为多个产品可以共用一个mr，对应的对客媒体需要拆成多行，所以需要按照产品维度聚合数据
        productMaterialRuleMap.forEach((mediaName, materialRule) -> {
            if (CollectionUtils.isNotEmpty(materialRule)) {
                materialRule.forEach(materialId -> {
                    MaterialRuleDetailViewDTO materialRuleModel = materialRuleModelMap.get(materialId);
                    if (Objects.isNull(materialRuleModel) ||
                        CollectionUtils.isEmpty(materialRuleModel.getMaterialRuleItemDetailDTOList())) {
                        return;
                    }

                    // 精准素材规范
                    List<String> onlineRules = Lists.newArrayList();
                    // 非精准素材规范
                    List<String> offlineRules = Lists.newArrayList();
                    for (MaterialRuleItemDetailViewDTO ruleItemDetailDTO : materialRuleModel.getMaterialRuleItemDetailDTOList()) {
                        if (BrandBoolEnum.BRAND_FALSE.getCode().equals(ruleItemDetailDTO.getIsOnline())) {
                            // 非精准
                            offlineRules.add(buildRuleString(ruleItemDetailDTO));
                        } else {
                            // 精准
                            onlineRules.add(buildRuleString(ruleItemDetailDTO));
                        }
                    }

                    Map<MaterialRuleExportEnum, String> result = new HashMap<>();
                    result.put(MaterialRuleExportEnum.ID,
                        materialRuleModel.getRuleId() == null ? "" : materialRuleModel.getRuleId().toString());
                    result.put(MaterialRuleExportEnum.RULE_NAME,
                        materialRuleModel.getRuleName() == null ? "" : materialRuleModel.getRuleName());
                    result.put(MaterialRuleExportEnum.USE_RANGE,
                        materialRuleModel.getMediaScope() == null ? "" : materialRuleModel.getMediaScope());
                    result.put(MaterialRuleExportEnum.MEDIA, mediaName);
                    result.put(MaterialRuleExportEnum.MATERIAL_TYPE,
                        materialRuleModel.getMaterialTypeName() == null ? "" : materialRuleModel.getMaterialTypeName());
                    result.put(MaterialRuleExportEnum.AD_STYLE,
                        materialRuleModel.getAdStyleName() == null ? "" : materialRuleModel.getAdStyleName());
                    result.put(MaterialRuleExportEnum.PRE_DAYS,
                        materialRuleModel.getPreDays() == null ? "" : materialRuleModel.getPreDays().toString());
                    result.put(MaterialRuleExportEnum.DEMO_URL,
                        materialRuleModel.getDemoUrl() == null ? "" : materialRuleModel.getDemoUrl());
                    result.put(MaterialRuleExportEnum.RULE_DESC,
                        materialRuleModel.getRuleDesc() == null ? "" : materialRuleModel.getRuleDesc());
                    result.put(MaterialRuleExportEnum.DESIGN_URLS, materialRuleModel.getDesignCodeUrls() == null ||
                            materialRuleModel.getDesignCodeUrls().isEmpty() ? "" :
                        String.join(",\n", materialRuleModel.getDesignCodeUrls()));
                    result.put(MaterialRuleExportEnum.ONLINE_RULE,
                            onlineRules.isEmpty() ? "" : String.join("\n", onlineRules));
                    result.put(MaterialRuleExportEnum.OFFLINE_RULE,
                            offlineRules.isEmpty() ? "" : String.join("\n", offlineRules));
                    results.add(result);
                });
            }
        });
        return results;
    }

    /**
     * 面客媒体名称xmr
     * @param serviceContext
     * @param scheduleExportContext
     * @param campaignModelList
     * @param productDTOMap
     * @return
     */
    private Map<String, Set<Long>> buildProductMaterialRuleMap(ServiceContext serviceContext, ScheduleExportContext scheduleExportContext, List<CampaignViewDTO> campaignModelList, Map<Long, ProductViewDTO> productDTOMap) {

        Map<String, Set<Long>> result = Maps.newHashMap();
        Map<Long, Set<Long>> campaignMaterialRuleMap = scheduleExportContext.getCampaignMaterialRuleMap();
        Map<Long, Boolean> campaignHasCrossTemplate = scheduleExportContext.getCampaignHasCrossTemplate();
        campaignModelList.stream()
            .filter(campaignViewDTO -> Objects.nonNull(campaignViewDTO.getCampaignResourceViewDTO().getSspProductId()))
            .forEach(campaign -> {
                Long sspProductId = campaign.getCampaignResourceViewDTO().getSspProductId();
                ProductViewDTO productViewDTO = productDTOMap.get(sspProductId);
                Optional<Integer> optional = Optional.ofNullable(productViewDTO).map(ProductViewDTO::getMediaScope);
                /**
                 * 跨域并且未使用跨域模板时不在mr中展示，只展示下边挂的子产品(二级计划)对应的mr即可
                 * 跨域使用跨域模板时，子产品(二级计划)对应的mr不展示,只展示跨域模板对应的mr
                 */
                if(!optional.isPresent() || (MediaScopeEnum.CROSS_SCOPE.getCode().equals(optional.get()) && !campaignHasCrossTemplate.getOrDefault(campaign.getId(), false))) {
                    return;
                }
                if(BrandCampaignLevelEnum.LEVEL_TWO_CAMPAIGN.getCode().equals(campaign.getCampaignLevel()) && campaignHasCrossTemplate.getOrDefault(campaign.getParentCampaignId(), false)) {
                    return;
                }
                Set<Long> materialRuleInfo = campaignMaterialRuleMap.get(campaign.getId());
                // 产品维度的mr聚合，可以对计划上的mr去重
                if(CollectionUtils.isNotEmpty(materialRuleInfo)) {
                    if(result.containsKey(productViewDTO.getCustomerOrientedMediaName())) {
                        Set<Long> ruleInfo = result.get(productViewDTO.getCustomerOrientedMediaName());
                        ruleInfo.addAll(materialRuleInfo);
                        result.put(productViewDTO.getCustomerOrientedMediaName(), ruleInfo);
                    } else {
                        result.put(productViewDTO.getCustomerOrientedMediaName(), materialRuleInfo);
                    }
                }
            });

        return result;
    }


    /**
     * 获取MR ID
     *
     * @param productMaterialRuleMap
     * @return
     */
    private List<Long> getMaterialRuleIds(Map<String, Set<Long>> productMaterialRuleMap) {
        Set<Long> materialRuleIdSet = Sets.newHashSet();
        productMaterialRuleMap.forEach((k, v) -> {
            if (CollectionUtils.isNotEmpty(v)) {
                materialRuleIdSet.addAll(v);
            }
        });
        return new ArrayList<>(materialRuleIdSet);
    }

    /**
     * 素材规范描述生成
     *
     * @param materialRuleItemDetailDTO
     * @return
     */
    private String buildRuleString(MaterialRuleItemDetailViewDTO materialRuleItemDetailDTO) {
        StringBuilder result = new StringBuilder();
        // 文本
        if (CollectionUtils.isNotEmpty(materialRuleItemDetailDTO.getTextRuleDTOList())) {
            for (TextRuleViewDTO textRuleDTO : materialRuleItemDetailDTO.getTextRuleDTOList()) {
                result.append("元素名称：").append(textRuleDTO.getItemName()).append("\n");
                result.append("元素类型：").append(RuleItemTypeEnum.getDesc(textRuleDTO.getItemType())).append("\n");
                result.append("元素描述：").append(textRuleDTO.getItemDesc()).append("\n");
                result.append("文件类型：").append(CollectionUtils.isNotEmpty(textRuleDTO.getFileFormat()) ?
                        String.join(",", textRuleDTO.getFileFormat()) : "").append("\n");
                result.append("文本长度限制：").append(textRuleDTO.getTextLengthLimit() != null ?
                    PinYinEnum.getDesc(textRuleDTO.getTextLengthLimit().getPinyinType()) + "," +
                        textRuleDTO.getTextLengthLimit().getMin() + "-" + textRuleDTO.getTextLengthLimit().getMax() :
                    "").append("\n\n");
            }
        }
        // 图片
        if (CollectionUtils.isNotEmpty(materialRuleItemDetailDTO.getPicRuleDTOList())) {
            for (PicRuleViewDTO picRuleDTO : materialRuleItemDetailDTO.getPicRuleDTOList()) {
                result.append("元素名称：").append(picRuleDTO.getItemName()).append("\n");
                result.append("元素类型：").append(RuleItemTypeEnum.getDesc(picRuleDTO.getItemType())).append("\n");
                result.append("元素描述：").append(picRuleDTO.getItemDesc()).append("\n");
                result.append("文件类型：").append(CollectionUtils.isNotEmpty(picRuleDTO.getFileFormat()) ?
                        String.join(",", picRuleDTO.getFileFormat()) : "").append("\n");
                result.append("文件大小：").append(picRuleDTO.getFileStoreLimit() != null ?
                        picRuleDTO.getFileStoreLimit().getValue() + picRuleDTO.getFileStoreLimit().getUnit() : "")
                    .append("\n");
                result.append("尺寸：").append(CollectionUtils.isNotEmpty(picRuleDTO.getFileSize()) ?
                    picRuleDTO.getFileSize().stream()
                        .map(item -> item.getWidth() + item.getUnit() + "*" + item.getHeight() + item.getUnit())
                        .collect(Collectors.joining("或")) : "").append("\n\n");
            }
        }
        // 视频
        if (CollectionUtils.isNotEmpty(materialRuleItemDetailDTO.getVideoRuleDTOList())) {
            for (VideoRuleViewDTO videoRuleDTO : materialRuleItemDetailDTO.getVideoRuleDTOList()) {
                result.append("元素名称：").append(videoRuleDTO.getItemName()).append("\n");
                result.append("元素类型：").append(RuleItemTypeEnum.getDesc(videoRuleDTO.getItemType())).append("\n");
                result.append("元素描述：").append(videoRuleDTO.getItemDesc()).append("\n");
                result.append("文件类型：").append(CollectionUtils.isNotEmpty(videoRuleDTO.getFileFormat()) ?
                        String.join(",", videoRuleDTO.getFileFormat()) : "").append("\n");
                result.append("文件大小：").append(videoRuleDTO.getFileStoreLimit() != null ?
                        videoRuleDTO.getFileStoreLimit().getValue() + videoRuleDTO.getFileStoreLimit().getUnit() : "")
                    .append("\n");
                result.append("尺寸：").append(CollectionUtils.isNotEmpty(videoRuleDTO.getFileSize()) ?
                    videoRuleDTO.getFileSize().stream()
                        .map(item -> item.getWidth() + item.getUnit() + "*" + item.getHeight() + item.getUnit())
                        .collect(Collectors.joining("或")) : "").append("\n");
                result.append("视频时长限制：").append(videoRuleDTO.getVideoTime() != null ?
                    videoRuleDTO.getVideoTime().getMin() + videoRuleDTO.getVideoTime().getUnit() + "-" +
                        videoRuleDTO.getVideoTime().getMax() + videoRuleDTO.getVideoTime().getUnit() : "").append("\n");
                result.append("视频码率限制：").append(videoRuleDTO.getVideoRate() != null ?
                    videoRuleDTO.getVideoRate().getValue() + videoRuleDTO.getVideoRate().getUnit() : "").append("\n");
                // 是否有声
                String doesVoice = videoRuleDTO.getVideoVoice() != null &&
                    VideoVoiceEnum.HAS_VOICE.getValue().equals(videoRuleDTO.getVideoVoice()) ?
                    VideoVoiceEnum.HAS_VOICE.getDescription() : VideoVoiceEnum.NO_VOICE.getDescription();
                result.append("是否有声：").append(videoRuleDTO.getVideoVoice() != null ? doesVoice : "").append("\n");
                result.append("是否自动播放：").append(BrandBoolEnum.getByCode(videoRuleDTO.getVideoPlay()).getDesc())
                    .append("\n\n");
            }
        }
        // 音频
        if (CollectionUtils.isNotEmpty(materialRuleItemDetailDTO.getAudioRuleDTOList())) {
            for (AudioRuleViewDTO audioRuleDTO : materialRuleItemDetailDTO.getAudioRuleDTOList()) {
                result.append("元素名称：").append(audioRuleDTO.getItemName()).append("\n");
                result.append("元素类型：").append(RuleItemTypeEnum.getDesc(audioRuleDTO.getItemType())).append("\n");
                result.append("元素描述：").append(audioRuleDTO.getItemDesc()).append("\n");
                result.append("文件类型：").append(CollectionUtils.isNotEmpty(audioRuleDTO.getFileFormat()) ?
                        String.join(",", audioRuleDTO.getFileFormat()) : "").append("\n");
                result.append("文件大小：").append(audioRuleDTO.getFileStoreLimit() != null ?
                        audioRuleDTO.getFileStoreLimit().getValue() + audioRuleDTO.getFileStoreLimit().getUnit() : "")
                    .append("\n");
                result.append("音频时长限制：").append(audioRuleDTO.getVoiceTime() != null ?
                    audioRuleDTO.getVoiceTime().getMin() + audioRuleDTO.getVoiceTime().getUnit() + "-" +
                        audioRuleDTO.getVoiceTime().getMax() + audioRuleDTO.getVoiceTime().getUnit() : "").append("\n");
                result.append("音频码率限制：").append(audioRuleDTO.getVoiceRate() != null ?
                    audioRuleDTO.getVoiceRate().getValue() + audioRuleDTO.getVoiceRate().getUnit() : "").append("\n");
                result.append("是否自动播放：").append(BrandBoolEnum.getByCode(audioRuleDTO.getVoicePlay()).getDesc())
                    .append("\n\n");
            }
        }
        // gif
        if (CollectionUtils.isNotEmpty(materialRuleItemDetailDTO.getGifRuleDTOList())) {
            for (GifRuleViewDTO gifRuleDTO : materialRuleItemDetailDTO.getGifRuleDTOList()) {
                result.append("元素名称：").append(gifRuleDTO.getItemName()).append("\n");
                result.append("元素类型：").append(RuleItemTypeEnum.getDesc(gifRuleDTO.getItemType())).append("\n");
                result.append("元素描述：").append(gifRuleDTO.getItemDesc()).append("\n");
                result.append("文件类型：").append(CollectionUtils.isNotEmpty(gifRuleDTO.getFileFormat()) ?
                        String.join(",", gifRuleDTO.getFileFormat()) : "").append("\n");
                result.append("文件大小：").append(gifRuleDTO.getFileStoreLimit() != null ?
                        gifRuleDTO.getFileStoreLimit().getValue() + gifRuleDTO.getFileStoreLimit().getUnit() : "")
                    .append("\n");
                result.append("尺寸：").append(CollectionUtils.isNotEmpty(gifRuleDTO.getFileSize()) ?
                    gifRuleDTO.getFileSize().stream()
                        .map(item -> item.getWidth() + item.getUnit() + "*" + item.getHeight() + item.getUnit())
                        .collect(Collectors.joining("或")) : "").append("\n\n");
            }
        }
        return result.toString();
    }

}
