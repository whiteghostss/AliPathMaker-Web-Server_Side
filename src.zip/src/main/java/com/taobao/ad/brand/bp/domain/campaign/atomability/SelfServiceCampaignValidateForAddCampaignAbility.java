package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.selfservice.CampaignSelfServiceViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignSelfServiceValidateForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignSelfServiceAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_REQUIRED;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCampaignValidateForAddCampaignAbility implements ICampaignSelfServiceValidateForAddCampaignAbility, SelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignSelfServiceAbilityParam abilityParam) {
        CampaignSelfServiceViewDTO selfServiceViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(selfServiceViewDTO, PARAM_REQUIRED, "售卖信息必填");
        AssertUtil.notNull(selfServiceViewDTO.getSkuId(), PARAM_REQUIRED, "skuID必填");
//        AssertUtil.notNull(campaignViewDTO.getCampaignSaleViewDTO().getCartItemId(), PARAM_REQUIRED, "加购行ID必填");
        return null;
    }
}
