package com.taobao.ad.brand.bp.domain.creative.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.adgroup.CreativeRefViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeQueryViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.adgroup.repository.AdgroupRepository;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeRepository;
import com.taobao.ad.brand.bp.common.helper.adgroup.BizAdgroupToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.ICreativeRefAdgroupMixDateValidateAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeRefAdgroupMixDateValidateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultCreativeRefAdgroupMixDateValidateAbility implements ICreativeRefAdgroupMixDateValidateAbility {

    private final AdgroupRepository adgroupRepository;
    private final CreativeRepository creativeRepository;

    /**
     * 创意和单元周期重合度校验
     * @param serviceContext
     * @param abilityParam
     */
    @Override
    public Void handle(ServiceContext serviceContext, CreativeRefAdgroupMixDateValidateAbilityParam abilityParam) {
        CreativeViewDTO creativeViewDTO = abilityParam.getAbilityTarget();
        CreativeQueryViewDTO tmpCreativeQueryDTO = new CreativeQueryViewDTO();
        tmpCreativeQueryDTO.setIds(Collections.singletonList(creativeViewDTO.getId()));
        tmpCreativeQueryDTO.setOnlineStatus(BrandBoolEnum.BRAND_TRUE.getCode());
        List<CreativeRefViewDTO> creativeRefList = creativeRepository.findCreativeRefList(serviceContext, tmpCreativeQueryDTO,false);
        if (CollectionUtils.isNotEmpty(creativeRefList)) {
            AdgroupQueryViewDTO adgroupQueryViewDTO = new AdgroupQueryViewDTO();
            adgroupQueryViewDTO.setIds(creativeRefList.stream().map(CreativeRefViewDTO::getAdgroupId).distinct().collect(Collectors.toList()));
            //校验单元
            List<AdgroupViewDTO> adgroupViewDTOList = adgroupRepository.queryAdgroupListNoPage(serviceContext, adgroupQueryViewDTO);
            List<AdgroupViewDTO> unMixedAdgroup = adgroupViewDTOList.stream().filter(t ->
                    !BrandDateUtil.isMixed(t.getStartTime(), t.getEndTime(),
                            creativeViewDTO.getStartTime(), creativeViewDTO.getEndTime())
            ).collect(Collectors.toList());
            RogerLogger.info("unMixedAdgroup:{}", JSON.toJSONString(unMixedAdgroup));
            AssertUtil.assertTrue(CollectionUtils.isEmpty(unMixedAdgroup), "单元%s有效期与创意投放日期无交集，请修改后重新提交", BizAdgroupToolsHelper.adgroupMessage(unMixedAdgroup));
        }
        return null;
    }

}
