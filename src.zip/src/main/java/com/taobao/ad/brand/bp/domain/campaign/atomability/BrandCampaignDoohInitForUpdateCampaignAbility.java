package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.dooh.CampaignDoohViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignDoohInitForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignDoohAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandCampaignDoohInitForUpdateCampaignAbility implements ICampaignDoohInitForUpdateCampaignAbility, BrandAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignDoohAbilityParam abilityParam) {
        CampaignDoohViewDTO campaignDoohViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        AssertUtil.notNull(campaignDoohViewDTO, "天攻信息不能为空");
        AssertUtil.notNull(dbCampaignViewDTO, "计划不存在");

        CampaignDoohViewDTO dbCampaignDoohViewDTO = Optional.ofNullable(dbCampaignViewDTO.getCampaignDoohViewDTO()).orElse(new CampaignDoohViewDTO());
        if(dbCampaignDoohViewDTO.getDoohCampaignId() != null){
            campaignDoohViewDTO.setDoohCampaignId(dbCampaignDoohViewDTO.getDoohCampaignId());
        }
        //界面没有设置，使用db存储的值
        if(campaignDoohViewDTO.getDoohStrategyId() == null){
            campaignDoohViewDTO.setDoohStrategyId(dbCampaignDoohViewDTO.getDoohStrategyId());
        }
        return null;
    }
}
