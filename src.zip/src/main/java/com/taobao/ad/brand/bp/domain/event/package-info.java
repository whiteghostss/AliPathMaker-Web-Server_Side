/**
 * @author yuhui.sl
 * @since 2020/1/21 14:27
 */
package com.taobao.ad.brand.bp.domain.event;