package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.EffectAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupStatusValidateForUnBindAdvAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupStatusValidateForBindOrUnBindAdvAbilityParam;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;

/**
 * @author yanjingang
 * @date 2024/11/25
 */
@Component
@BusinessAbility
public class EffectCampaignGroupStatusValidateForUnBindAdvAbility implements ICampaignGroupStatusValidateForUnBindAdvAbility, EffectAtomAbilityRouter {


    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupStatusValidateForBindOrUnBindAdvAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        if (Objects.equals(BrandCampaignGroupStatusEnum.CANCELED.getCode(),campaignGroupViewDTO.getStatus())){
            return null;
        }
        List<Integer> statusList = Lists.newArrayList();
        statusList.add(BrandCampaignGroupStatusEnum.EDITED.getCode());
        AssertUtil.assertTrue(!statusList.contains(campaignGroupViewDTO.getStatus()),"当前订单状态不支持解绑。");
        return null;
    }
}
