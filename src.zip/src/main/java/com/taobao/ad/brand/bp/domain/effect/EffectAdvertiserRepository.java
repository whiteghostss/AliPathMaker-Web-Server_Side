package com.taobao.ad.brand.bp.domain.effect;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.dto.effect.DirectAdvertiserSettingViewDTO;
import com.taobao.ad.brand.bp.client.dto.effect.EffectAdvertiserContractFundViewDTO;
import com.taobao.ad.brand.bp.client.dto.effect.EffectAdvertiserViewDTO;

import java.util.List;

public interface EffectAdvertiserRepository {

    List<EffectAdvertiserViewDTO> findEffectAdvInnerList(ServiceContext serviceContext, List<Long> advIds);

    void updateAdvertiserSetting(ServiceContext serviceContext, List<DirectAdvertiserSettingViewDTO> directAdvertiserSettingDTOList);
    void deleteAdvertiserSetting(ServiceContext serviceContext,Long advId,List<String> settingKeys);
    List <EffectAdvertiserContractFundViewDTO> findAdvertiserContractFundList(ServiceContext serviceContext, List<Integer> directMediaIds, List<Long> directAdvertiserIds, List<Long> subContractIds);

}
