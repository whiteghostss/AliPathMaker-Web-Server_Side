package com.taobao.ad.brand.bp.domain.salegroup.converter;

import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupBoostGiveApplyInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.salegroup.CampaignGroupSaleGroupBoostGiveApplyViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import com.taobao.ad.brand.bp.domain.salegroup.converter.mapstruct.BizSaleGroupBoostGiveApplyMapStruct;
import org.springframework.stereotype.Component;


/**
 * @author yunhu.myh@taobao.com
 * @date 2023年07月28日
 */
@Component
public class BizSaleGroupBoostGiveApplyConverter extends BaseViewDTOConverter<SaleGroupBoostGiveApplyInfoViewDTO, CampaignGroupSaleGroupBoostGiveApplyViewDTO> {

    @Override
    public BaseMapStructMapper<SaleGroupBoostGiveApplyInfoViewDTO, CampaignGroupSaleGroupBoostGiveApplyViewDTO> getBaseMapStructMapper() {
        return BizSaleGroupBoostGiveApplyMapStruct.INSTANCE;
    }

}
