package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSaleOrderStatusEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupStatusUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupStatusUpdateAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component
@BusinessAbility
public class DefaultSaleGroupStatusUpdateAbility implements ISaleGroupStatusUpdateAbility {

    @Resource
    private CampaignGroupRepository campaignGroupRepository;


    @Override
    public Void handle(ServiceContext serviceContext, SaleGroupStatusUpdateAbilityParam abilityParam) {
        List<Long> saleGroupIds = abilityParam.getAbilityTargets();
        if (CollectionUtils.isEmpty(saleGroupIds)) {
            return null;
        }
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        BrandCampaignGroupSaleOrderStatusEnum orderStatusEnum = abilityParam.getSaleGroupOrderStatusEnum();
        List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList();
        // 初始化
        List<SaleGroupInfoViewDTO> updateSaleGroupInfoViewDTOList = Lists.newArrayList();
        saleGroupInfoViewDTOList.forEach(saleGroupInfoViewDTO -> {
            if (!saleGroupIds.contains(saleGroupInfoViewDTO.getSaleGroupId())) {
                return;
            }
            saleGroupInfoViewDTO.setSaleGroupStatus(orderStatusEnum.getCode());

            SaleGroupInfoViewDTO updateSaleGroup = new SaleGroupInfoViewDTO();
            updateSaleGroup.setSaleGroupId(saleGroupInfoViewDTO.getSaleGroupId());
            updateSaleGroup.setSaleGroupStatus(orderStatusEnum.getCode());
            updateSaleGroupInfoViewDTOList.add(updateSaleGroup);
        });

        campaignGroupRepository.addOrUpdateSaleGroupPart(serviceContext, campaignGroupViewDTO.getId(), updateSaleGroupInfoViewDTOList);
        return null;
    }
}
