package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdScenarioViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdViewDTO;

import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.CrowdViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaign.RecommendCrowdTypeEnum;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.campaign.util.CampaignTitleBuilder;
import com.taobao.ad.brand.bp.domain.dmp.CrowdRepository;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignTitleInitAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.common.constant.CampaignConstant.MULTI_CROWD;
import static com.taobao.ad.brand.bp.common.util.BrandDateUtil.DATE_FORMAT_MMDD_TYPE_1;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandCampaignTitleInitAbility extends DefaultCampaignTitleInitAbility implements BrandAtomAbilityRouter {

    private final CrowdRepository crowdRepository;

    @Override
    public String handle(ServiceContext context, CampaignTitleInitAbilityParam abilityParam) {
        CampaignViewDTO campaignViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        ProductViewDTO productViewDTO = abilityParam.getProductViewDTO();
        List<CommonViewDTO> showmaxCrowdList = abilityParam.getShowmaxCrowdList();
        String title = campaignViewDTO.getTitle();
        if (StringUtils.isEmpty(title) || isTitleFormatted(context, title, dbCampaignViewDTO, productViewDTO,showmaxCrowdList)) {
            title = generateCampaignTitle(context, campaignViewDTO, productViewDTO, showmaxCrowdList);
        }
        return title;
    }

    private boolean isTitleFormatted(ServiceContext context, String title, CampaignViewDTO dbCampaignViewDTO, ProductViewDTO product, List<CommonViewDTO> showmaxCrowdList) {
        if (StringUtils.isEmpty(title) || dbCampaignViewDTO == null) {
            return false;
        }
        List<CampaignCrowdViewDTO> crowdViewDTOList = Optional.ofNullable(dbCampaignViewDTO.getCampaignCrowdScenarioViewDTO())
                .map(CampaignCrowdScenarioViewDTO::getCampaignCrowdViewDTOList).orElse(Lists.newArrayList());
        if (CollectionUtils.isNotEmpty(crowdViewDTOList)) {
            List<Long> crowdIds = crowdViewDTOList.stream().map(CampaignCrowdViewDTO::getCrowdId).collect(Collectors.toList());
            List<CrowdViewDTO> crowdViewDTOS = crowdRepository.queryCrowdByIds(context, crowdIds);
            Map<Long, String> crowdIdToNameMap = crowdViewDTOS.stream().collect(Collectors.toMap(CrowdViewDTO::getCrowdId, CrowdViewDTO::getCrowdName));
            for (CampaignCrowdViewDTO crowdViewDTO : crowdViewDTOList) {
                String crowdName = crowdIdToNameMap.get(crowdViewDTO.getCrowdId());
                if (crowdName != null) {
                    crowdViewDTO.setCrowdName(crowdName);
                }
            }
        }
        // 结尾为 _[6位数字]
        String regex = ".*_\\d{6}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(title);
        if (!matcher.matches()) {
            return false;
        }
        // 删去末尾防重值对比
        String generatedTitleDBTrimmed = generateCampaignTitle(context, dbCampaignViewDTO, product, showmaxCrowdList);
        generatedTitleDBTrimmed = generatedTitleDBTrimmed.replaceAll("\\d{6}$", "");
        String titleTrimmed = title.replaceAll("\\d{6}$", "");

        return titleTrimmed.equals(generatedTitleDBTrimmed);
    }

    /**
     * 生成计划标题
     * @param context
     * @param campaignViewDTO
     * @param productViewDTO
     * @param showmaxCrowdList
     * @return
     */
    private String generateCampaignTitle(ServiceContext context, CampaignViewDTO campaignViewDTO, ProductViewDTO productViewDTO, List<CommonViewDTO> showmaxCrowdList) {
        String crowdDesc;
        StringBuilder showmaxCrowdInfos = new StringBuilder();
        // showmax计划人群自动命名
        if (BizCampaignToolsHelper.isShowmaxCampaign(productViewDTO.getMediaScope(), productViewDTO.getProductLineId(), productViewDTO.getCrossScene())) {
            RecommendCrowdTypeEnum recommendCrowdTypeEnum = RecommendCrowdTypeEnum.getRecommendCrowdTypeEnum(campaignViewDTO.getCampaignCrowdScenarioViewDTO().getCampaignShowmaxCrowdViewDTO().getShowmaxCrowdType());
            String showMaxCrowdTypeDesc = Optional.ofNullable(recommendCrowdTypeEnum).map(RecommendCrowdTypeEnum::getDesc).orElse(Constant.STRING_EMPTY);
            showmaxCrowdInfos.append(showMaxCrowdTypeDesc);
            showmaxCrowdInfos.append(Constant.UNDERLINE);
            if (CollectionUtils.isNotEmpty(showmaxCrowdList)) {
                showmaxCrowdInfos.append(showmaxCrowdList.stream()
                        .filter(commonViewDTO -> campaignViewDTO.getCampaignCrowdScenarioViewDTO().getCampaignShowmaxCrowdViewDTO().getShowmaxCrowdLabelIdList().contains(commonViewDTO.getId()))
                        .map(CommonViewDTO::getName).distinct().collect(Collectors.joining(Constant.UNDERLINE)));
            }
            crowdDesc = showmaxCrowdInfos.toString();
        } else {
            List<CampaignCrowdViewDTO> campaignCrowdViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignCrowdScenarioViewDTO())
                    .map(CampaignCrowdScenarioViewDTO::getCampaignCrowdViewDTOList).orElse(Lists.newArrayList());

            crowdDesc = Optional.of(campaignCrowdViewDTOList)
                    .filter(CollectionUtils::isNotEmpty)
                    .map(crowds -> crowds.size() == 1 ? crowds.get(0).getCrowdName() : MULTI_CROWD)
                    .orElse(null);
        }
        return CampaignTitleBuilder.builder()
                .id(campaignViewDTO.getId())
                .customerOrientedResource(productViewDTO.getCustomerOrientedResourceName())
                .customerOrientedMedia(productViewDTO.getCustomerOrientedMediaName())
                .crowdDesc(crowdDesc)
                .startTime(BrandDateUtil.date2String(campaignViewDTO.getStartTime(), DATE_FORMAT_MMDD_TYPE_1))
                .endTime(BrandDateUtil.date2String(campaignViewDTO.getEndTime(), DATE_FORMAT_MMDD_TYPE_1))
                .build().getNormalizedName();
    }
}
