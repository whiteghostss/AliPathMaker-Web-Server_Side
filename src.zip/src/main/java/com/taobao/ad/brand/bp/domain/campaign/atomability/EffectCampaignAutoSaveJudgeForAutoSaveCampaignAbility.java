package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.EffectAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignAutoSaveAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EffectCampaignAutoSaveJudgeForAutoSaveCampaignAbility
        extends DefaultCampaignAutoSaveJudgeForAutoSaveCampaignAbility implements EffectAtomAbilityRouter {

    @Override
    public Boolean handle(ServiceContext serviceContext, CampaignAutoSaveAbilityParam abilityParam) {
        return true;
    }
}
