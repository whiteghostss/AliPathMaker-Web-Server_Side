package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.sale.CampaignSaleViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignRegisterUnitEnum;
import com.alibaba.ad.nb.ssp.constant.common.MediaScopeEnum;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignSaleValidateForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignSaleAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_REQUIRED;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandCampaignSaleValidateForAddCampaignAbility implements ICampaignSaleValidateForAddCampaignAbility, BrandAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignSaleAbilityParam abilityParam) {
        CampaignSaleViewDTO campaignSaleViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(campaignSaleViewDTO, PARAM_REQUIRED, "售卖信息必填");
        AssertUtil.notNull(campaignSaleViewDTO.getSaleGroupId(), PARAM_REQUIRED, "售卖分组ID必填");
        AssertUtil.notNull(campaignSaleViewDTO.getResourcePackageProductId(), PARAM_REQUIRED, "资源包产品ID必填");

        ProductViewDTO productViewDTO = abilityParam.getProductViewDTO();
        AssertUtil.notNull(productViewDTO, PARAM_REQUIRED, "产品信息必填");
        ResourcePackageProductViewDTO resourcePackageProductViewDTO = abilityParam.getResourcePackageProductViewDTO();
        AssertUtil.notNull(resourcePackageProductViewDTO, PARAM_REQUIRED, "资源包产品信息必填");

        if(MediaScopeEnum.TAO_OUT.getCode().equals(productViewDTO.getMediaScope())
                && BrandCampaignRegisterUnitEnum.DAY.getCode().equals(resourcePackageProductViewDTO.getSaleUnit())){
            throw new BrandOneBPException("售卖单位=天(CPT/CPD)投放场景，二环暂不支持");
        }
        return null;
    }
}
