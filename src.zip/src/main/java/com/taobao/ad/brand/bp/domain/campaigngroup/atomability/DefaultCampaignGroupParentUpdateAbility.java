package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupParentUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupParentUpdateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author yanjingang
 * @date 2025/2/8
 */
@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultCampaignGroupParentUpdateAbility implements ICampaignGroupParentUpdateAbility {

    private final CampaignGroupRepository campaignGroupRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupParentUpdateAbilityParam abilityParam) {
        CampaignGroupViewDTO subCampaignGroupViewDTO = abilityParam.getAbilityTarget();
        CampaignGroupViewDTO mainCampaignGroupViewDTO = abilityParam.getMainCampaignGroupViewDTO();
        // 设置
        subCampaignGroupViewDTO.setParentId(mainCampaignGroupViewDTO.getId());
        // 更新
        CampaignGroupViewDTO updateCampaignGroupViewDTO = new CampaignGroupViewDTO();
        updateCampaignGroupViewDTO.setId(subCampaignGroupViewDTO.getId());
        updateCampaignGroupViewDTO.setParentId(subCampaignGroupViewDTO.getParentId());
        campaignGroupRepository.updateCampaignGroupPart(serviceContext, updateCampaignGroupViewDTO);

        return null;
    }
}
