package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.selfservice.CampaignSelfServiceViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignSelfServiceInitForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignSelfServiceAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_REQUIRED;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCampaignInitForUpdateCampaignAbility implements ICampaignSelfServiceInitForUpdateCampaignAbility, SelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignSelfServiceAbilityParam abilityParam) {
        CampaignSelfServiceViewDTO selfServiceViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        AssertUtil.notNull(selfServiceViewDTO, PARAM_REQUIRED, "售卖信息必填");
        AssertUtil.notNull(dbCampaignViewDTO, PARAM_REQUIRED, "计划不存在");

        CampaignSelfServiceViewDTO dbCampaignSelfServiceViewDTO = dbCampaignViewDTO.getCampaignSelfServiceViewDTO();

        selfServiceViewDTO.setSpuId(dbCampaignSelfServiceViewDTO.getSpuId());
        selfServiceViewDTO.setSkuId(dbCampaignSelfServiceViewDTO.getSkuId());
        selfServiceViewDTO.setCartItemId(dbCampaignSelfServiceViewDTO.getCartItemId());
        selfServiceViewDTO.setBundleId(dbCampaignSelfServiceViewDTO.getBundleId());
        return null;
    }
}
