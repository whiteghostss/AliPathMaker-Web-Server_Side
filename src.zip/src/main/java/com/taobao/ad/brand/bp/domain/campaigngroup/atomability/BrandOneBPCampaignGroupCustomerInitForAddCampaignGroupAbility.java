package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.customer.CampaignGroupCustomerViewDTO;
import com.taobao.ad.brand.bp.common.constant.campaigngroup.CampaignGroupConstant;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CustomerRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupCustomerInitForAddCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupCustomerAbilityParam;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
@BusinessAbility
public class BrandOneBPCampaignGroupCustomerInitForAddCampaignGroupAbility
        implements ICampaignGroupCustomerInitForAddCampaignGroupAbility, BrandOneBPAtomAbilityRouter {
    @Resource
    private CustomerRepository customerRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupCustomerAbilityParam abilityParam) {
        if (!BizCampaignGroupToolsHelper.isSaleCampaignGroup(abilityParam.getCampaignGroupViewDTO())) {
            return null;
        }
        CampaignGroupCustomerViewDTO campaignGroupCustomerViewDTO = abilityParam.getAbilityTarget();
        if (campaignGroupCustomerViewDTO.getCustomerMemberId() != null) {
            // 设置客户优先级
            String customerPriority = customerRepository.getMemberPriority(serviceContext, campaignGroupCustomerViewDTO.getCustomerMemberId());
            if (StringUtils.isNotBlank(customerPriority)) {
                campaignGroupCustomerViewDTO.setCustomerPriority(customerPriority);
            } else {
                campaignGroupCustomerViewDTO.setCustomerPriority(CampaignGroupConstant.CUSTOMER_PRIORITY_DEFAULT);
            }
        }

        return null;
    }
}
