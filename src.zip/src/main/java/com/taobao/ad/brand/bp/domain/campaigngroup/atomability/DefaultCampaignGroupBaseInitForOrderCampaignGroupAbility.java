package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSaleOrderStatusEnum;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupBaseInitForOrderCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupBaseAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
@BusinessAbility
public class DefaultCampaignGroupBaseInitForOrderCampaignGroupAbility implements ICampaignGroupBaseInitForOrderCampaignGroupAbility {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupBaseAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        // 初始化订单时间
        List<SaleGroupInfoViewDTO> validSaleGroupInfoList = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream()
                .filter(t -> !BrandCampaignGroupSaleOrderStatusEnum.WAIT_ORDER.getCode().equals(t.getSaleGroupStatus()))
                .collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(validSaleGroupInfoList)) {
            campaignGroupViewDTO.setStartTime(BizCampaignGroupToolsHelper.getSaleGroupMinDate(validSaleGroupInfoList));
            campaignGroupViewDTO.setEndTime(BrandDateUtil.getDateFullMidnight(BizCampaignGroupToolsHelper.getSaleGroupMaxDate(validSaleGroupInfoList)));
        }

        return null;
    }
}
