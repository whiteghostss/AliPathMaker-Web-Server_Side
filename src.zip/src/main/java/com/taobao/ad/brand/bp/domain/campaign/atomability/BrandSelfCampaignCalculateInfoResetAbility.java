package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryLockViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryPolicyViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandSubCampaignSplitCodeEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignCalculateInfoResetAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignCalculateInfoResetAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSelfCampaignCalculateInfoResetAbility implements ICampaignCalculateInfoResetAbility, BrandSelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignCalculateInfoResetAbilityParam abilityParam) {
        List<CampaignViewDTO> subCampaignViewDTOList = abilityParam.getAbilityTargets();
        if(CollectionUtils.isEmpty(subCampaignViewDTOList)){
            return null;
        }
        //需要进行处理的拆分子计划
        Set<String> needResetSplitCodes = Sets.newHashSet(BrandSubCampaignSplitCodeEnum.CAMPAIGN_SPLIT_CROSS.getCode(),
                BrandSubCampaignSplitCodeEnum.CAMPAIGN_SPLIT_PRICE_PERIOD.getCode(),BrandSubCampaignSplitCodeEnum.CAMPAIGN_CROSS_SPLIT_PRICE_PERIOD.getCode());
        //子计划如果没有锁量的数据 则清空预定量数据，删除计划不处理
        for (CampaignViewDTO subCampaignViewDTO : subCampaignViewDTOList) {
            if(Objects.equals(subCampaignViewDTO.getStatus(),BrandCampaignStatusEnum.DELETE.getCode())){
                continue;
            }
            if(!needResetSplitCodes.contains(subCampaignViewDTO.getCampaignExtViewDTO().getSubSplitCode())){
                continue;
            }
            if(!BizCampaignToolsHelper.hasLockDate(subCampaignViewDTO)){
                clearCampaignMoneyAndInquiry(subCampaignViewDTO);
            }
        }
        return null;
    }

    /**
     * 清空预定量金额询锁量
     * @param subCampaignViewDTO
     */
    private void clearCampaignMoneyAndInquiry(CampaignViewDTO subCampaignViewDTO) {
        //清空金额、预定量 、以及询锁量信息
        if(subCampaignViewDTO.getCampaignPriceViewDTO() != null){
            subCampaignViewDTO.getCampaignPriceViewDTO().setSettlePrice(0L);
            subCampaignViewDTO.getCampaignPriceViewDTO().setDiscountPriceInfoList(Lists.newArrayList());
            subCampaignViewDTO.getCampaignPriceViewDTO().setPublishPriceInfoList(Lists.newArrayList());
        }
        if(subCampaignViewDTO.getCampaignBudgetViewDTO() != null){
            subCampaignViewDTO.getCampaignBudgetViewDTO().setDiscountTotalMoney(0L);
            subCampaignViewDTO.getCampaignBudgetViewDTO().setPublishTotalMoney(0L);
            subCampaignViewDTO.getCampaignBudgetViewDTO().setIsCustomResetBudget(BrandBoolEnum.BRAND_FALSE.getCode());
        }
        if(subCampaignViewDTO.getCampaignGuaranteeViewDTO().getAmount() != null){
            subCampaignViewDTO.getCampaignGuaranteeViewDTO().setAmount(0L);
        }
        if(subCampaignViewDTO.getStatus() != null){
            subCampaignViewDTO.setStatus(BrandCampaignStatusEnum.NEW.getCode());
        }
        if(subCampaignViewDTO.getCampaignGuaranteeViewDTO().getCptAmount() != null){
            subCampaignViewDTO.getCampaignGuaranteeViewDTO().setCptAmount(0L);
        }
        CampaignInquiryLockViewDTO campaignInquiryLockViewDTO = subCampaignViewDTO.getCampaignInquiryLockViewDTO();
        if(campaignInquiryLockViewDTO != null){
            campaignInquiryLockViewDTO.setCampaignInquiryViewDTOList(Lists.newArrayList());
        }
        if(CollectionUtils.isNotEmpty(subCampaignViewDTO.getSubCampaignViewDTOList())){
            subCampaignViewDTO.setSubCampaignViewDTOList(Lists.newArrayList());
        }
        CampaignInquiryPolicyViewDTO campaignInquiryPolicyViewDTO = Optional.ofNullable(subCampaignViewDTO.getCampaignInquiryLockViewDTO())
                .map(CampaignInquiryLockViewDTO::getCampaignInquiryPolicyViewDTO).orElse(null);
        if(campaignInquiryPolicyViewDTO != null){
            campaignInquiryPolicyViewDTO.setInquiryAssignType(null);
            campaignInquiryPolicyViewDTO.setSchedulePolicyList(null);
        }
    }
}
