package com.taobao.ad.brand.bp.domain.adgroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.common.WakeupViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativeAuditSwitchEnum;
import com.taobao.ad.brand.bp.common.constant.CreativeConstant;
import com.taobao.ad.brand.bp.common.helper.schema.BizSchemaToolsHelper;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupWakeUpValidateForUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupWakeUpInitAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupWakeUpValidateForUpdateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Component
@BusinessAbility
public class BrandSelfAdgroupWakeUpValidateForUpdateAbility implements IAdgroupWakeUpValidateForUpdateAbility,
    BrandSelfServiceAtomAbilityRouter {
    @Override
    public Void handle(ServiceContext serviceContext, AdgroupWakeUpValidateForUpdateAbilityParam abilityParam) {
        WakeupViewDTO wakeupViewDTO = abilityParam.getAbilityTarget();
        WakeupViewDTO dbWakeupViewDTO = abilityParam.getDbAdgroupViewDTO().getWakeupViewDTO();
        List<CreativeViewDTO> creativeViewDTOList = abilityParam.getCreativeViewDTOList();
        boolean isEqual = BizSchemaToolsHelper.isEqual(wakeupViewDTO, dbWakeupViewDTO);
        if (!isEqual && CollectionUtils.isNotEmpty(creativeViewDTOList)) {
            Long adgroupSchemaId = BizSchemaToolsHelper.getSchemaId(wakeupViewDTO);
            List<Long> creativeSchemaIdList = creativeViewDTOList.stream()
                    .map(CreativeViewDTO::getCreativeAudit)
                    .filter(creativeAudit -> creativeAudit.getMediaAudit() != null
                            && creativeAudit.getMediaAudit().getAuditSwitch() != null
                            && !BrandCreativeAuditSwitchEnum.UNWANTED.getCode().equals(creativeAudit.getMediaAudit().getAuditSwitch()))
                    .filter(creativeAudit -> !CreativeConstant.CREATIVE_NOT_YET_DELIVER_TO_MEDIA_STATUS_LIST.contains(creativeAudit.getShowAuditStatus()))
                    .filter(t -> t.getMediaAudit() != null && t.getMediaAudit().getSchemaId() != null)
                    .map(t -> t.getMediaAudit().getSchemaId())
                    .distinct()
                    .collect(Collectors.toList());
            AssertUtil.assertTrue(CollectionUtils.isEmpty(creativeSchemaIdList) || creativeSchemaIdList.get(0).equals(adgroupSchemaId),"单元绑定的创意已关联其他唤端schema信息且已进行媒体送审，不允许修改单元唤端配置");
        }
        return null;
    }
}
