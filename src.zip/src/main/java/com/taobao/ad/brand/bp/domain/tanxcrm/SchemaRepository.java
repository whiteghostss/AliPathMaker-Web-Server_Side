package com.taobao.ad.brand.bp.domain.tanxcrm;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.dto.tanxcrm.SchemaViewDTO;

public interface SchemaRepository {
    SchemaViewDTO getSchemaById(ServiceContext serviceContext, Long id);
}
