package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupBoostGiveApplyCampaignDetailViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupBoostGiveApplyInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.alibaba.ad.brand.sdk.constant.salegroup.field.SaleGroupBoostApplyReasonTypeEnum;
import com.alibaba.ad.brand.sdk.constant.salegroup.field.SaleGroupDistributionTypeEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleProductLineEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupApplyInfoValidateForApplySaleGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupApplyInfoAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Objects;
import java.util.Optional;

@Component
@BusinessAbility
public class DefaultSaleGroupApplyInfoValidateForApplySaleGroupAbility implements ISaleGroupApplyInfoValidateForApplySaleGroupAbility {
    @Override
    public Void handle(ServiceContext serviceContext, SaleGroupApplyInfoAbilityParam abilityParam) {
        SaleGroupBoostGiveApplyInfoViewDTO applyInfoViewDTO = abilityParam.getAbilityTarget();
        CampaignGroupViewDTO campaignGroup = abilityParam.getCampaignGroup();
        SaleGroupInfoViewDTO mainSaleGroupInfoViewDTO = abilityParam.getMainSaleGroupInfoViewDTO();
        AssertUtil.notNull(applyInfoViewDTO.getSaleGroupName(), "分组名称不能为空");
        BrandSaleTypeEnum saleTypeEnum = BrandSaleTypeEnum.getByCode(applyInfoViewDTO.getSaleType());
        AssertUtil.assertTrue(BrandSaleTypeEnum.BOOST.getCode().equals(applyInfoViewDTO.getSaleType()) || BrandSaleTypeEnum.PRESENT.getCode().equals(applyInfoViewDTO.getSaleType()), "分组售卖类型不正确");
        if (saleTypeEnum == BrandSaleTypeEnum.BOOST) {
            AssertUtil.notNull(applyInfoViewDTO.getReasonType(), "补量原因不能为空");
            AssertUtil.notNull(SaleGroupBoostApplyReasonTypeEnum.getByCode(applyInfoViewDTO.getReasonType()), "补量原因不正确");
            AssertUtil.assertTrue(Optional.ofNullable(mainSaleGroupInfoViewDTO.getBudget()).orElse(0L) > 0, "购买金额为0的主分组不允许添加补量分组");
            if (!BrandCampaignGroupStatusEnum.COMPLETED.getCode().equals(campaignGroup.getStatus()) && Objects.nonNull(campaignGroup.getCampaignGroupContractViewDTO().getFinalCompletedMoment())) {
                throw new BrandOneBPException("该订单操作过结案打回，不能进行补量操作，如需补量请走配送流程");
            }
        }
        if (saleTypeEnum == BrandSaleTypeEnum.PRESENT) {
            AssertUtil.notNull(applyInfoViewDTO.getDistributionType(), "配送类型不能为空");
        }
        AssertUtil.assertTrue(applyInfoViewDTO.getStartDate() != null && applyInfoViewDTO.getEndDate() != null, saleTypeEnum.getDesc() + "日期不能为空");
        AssertUtil.assertTrue(BrandDateUtil.isBeforeAndEqual(applyInfoViewDTO.getStartDate(), applyInfoViewDTO.getEndDate()), "开始日期不能晚于结束日期");
        if (saleTypeEnum == BrandSaleTypeEnum.BOOST && SaleProductLineEnum.SINGLE_MEDIA_MARKING.getValue().equals(mainSaleGroupInfoViewDTO.getSaleProductLine())) {
            AssertUtil.assertTrue(CollectionUtils.isNotEmpty(applyInfoViewDTO.getCampaignDetailList()), "计划补量详情不能为空");
            for (SaleGroupBoostGiveApplyCampaignDetailViewDTO campaignDetailViewDTO : applyInfoViewDTO.getCampaignDetailList()) {
                AssertUtil.notNull(campaignDetailViewDTO.getCampaignId(), "计划ID不能为空");
                AssertUtil.notNull(campaignDetailViewDTO.getAmount(), String.format("计划(%d)补量量级不能为空", campaignDetailViewDTO.getCampaignId()));
                AssertUtil.notNull(campaignDetailViewDTO.getBudget(), String.format("计划(%d)补量金额不能为空", campaignDetailViewDTO.getCampaignId()));
            }
        } else {
            AssertUtil.assertTrue(applyInfoViewDTO.getBudget() != null && applyInfoViewDTO.getBudget() > 0L, saleTypeEnum.getDesc() + "金额不正确");
        }
        // 新建时，开始日期不能早于今天
        if (Objects.isNull(applyInfoViewDTO.getSaleGroupId())) {
            AssertUtil.assertTrue(BrandDateUtil.isAfterAndEqual(applyInfoViewDTO.getStartDate(), BrandDateUtil.getDateMidnight(new Date())), "开始日期不能早于今天");
        }
        return null;
    }
}
