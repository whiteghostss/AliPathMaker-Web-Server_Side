package com.taobao.ad.brand.bp.domain.taojimu;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandShopWindowTjmSubscribeViewDTO;

/**
 * @author jixiu.lj
 * @date 2024/9/19 19:52
 * 淘积木相关服务2
 * todo 是否有必要保留
 */
public interface TaoJiMuRepository {

    /**
     * 淘积木包装服务：淘宝开放平台三方isv订购
     * @param serviceContext
     * @param brandShopWindowTjmSubscribeViewDTO
     */
    void subscribe(ServiceContext serviceContext, BrandShopWindowTjmSubscribeViewDTO brandShopWindowTjmSubscribeViewDTO);


    /**
     * 淘积木包装服务：查询订购信息
     * @param serviceContext
     * @param brandShopWindowTjmSubscribeViewDTO
     * @return
     */
    BrandShopWindowTjmSubscribeViewDTO querySubscribeInfo(ServiceContext serviceContext, BrandShopWindowTjmSubscribeViewDTO brandShopWindowTjmSubscribeViewDTO);
}
