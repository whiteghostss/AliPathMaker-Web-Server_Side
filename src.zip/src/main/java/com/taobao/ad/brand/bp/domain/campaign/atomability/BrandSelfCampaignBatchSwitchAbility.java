package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.enums.SwitchEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignBatchSwitchAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBatchSwitchAbilityParam;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component
@BusinessAbility
public class BrandSelfCampaignBatchSwitchAbility implements ICampaignBatchSwitchAbility, BrandSelfServiceAtomAbilityRouter {

    @Resource
    private CampaignRepository campaignRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignBatchSwitchAbilityParam abilityParam) {
        List<CampaignViewDTO> updateList = Lists.newArrayList();
        List<CampaignViewDTO> operateList = abilityParam.getAbilityTargets();
        SwitchEnum switchEnum = abilityParam.getSwitchEnum();
        for(CampaignViewDTO operatorViewDTO : operateList){
            if(BrandDateUtil.isBefore(operatorViewDTO.getEndTime(), BrandDateUtil.getCurrentDate())){
                continue;
            }
            if (switchEnum.equals(SwitchEnum.CLOSE)) {
                operatorViewDTO.setStatus(BrandCampaignStatusEnum.PAUSING.getCode());
            }
            Integer status = operatorViewDTO.getStatus();
            if (switchEnum.equals(SwitchEnum.OPEN)) {
                if (BrandDateUtil.isAfter(operatorViewDTO.getStartTime(), BrandDateUtil.getCurrentDate())) {
                    status = BrandCampaignStatusEnum.WAITING.getCode();
                }
                if (BrandDateUtil.isAfterAndEqual(operatorViewDTO.getEndTime(), BrandDateUtil.getCurrentDate())
                        && BrandDateUtil.isBeforeAndEqual(operatorViewDTO.getStartTime(),
                        BrandDateUtil.getCurrentDate())) {
                    status = BrandCampaignStatusEnum.CASTING.getCode();
                }
            }
            CampaignViewDTO updateDTO = new CampaignViewDTO();
            updateDTO.setId(operatorViewDTO.getId());
            updateDTO.setStatus(status);
            updateList.add(updateDTO);
        }
        try {
            campaignRepository.updateCampaignPart(serviceContext, updateList);
        } catch (Exception e) {
            throw new BrandOneBPException("批量开启/关闭计划失败", e);
        }
        return null;
    }
}
