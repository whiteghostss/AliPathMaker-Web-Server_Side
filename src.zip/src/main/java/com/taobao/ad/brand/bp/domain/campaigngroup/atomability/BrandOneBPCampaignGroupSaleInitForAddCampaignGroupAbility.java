package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.sale.CampaignGroupSaleViewDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageTemplateViewDTO;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupSaleInitForAddCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupSaleAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Optional;

@Component
@BusinessAbility
public class BrandOneBPCampaignGroupSaleInitForAddCampaignGroupAbility
        implements ICampaignGroupSaleInitForAddCampaignGroupAbility, BrandOneBPAtomAbilityRouter {

    @Resource
    private ResourcePackageRepository resourcePackageRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupSaleAbilityParam abilityParam) {
        if (!BizCampaignGroupToolsHelper.isSaleCampaignGroup(abilityParam.getCampaignGroupViewDTO())) {
            return null;
        }
        CampaignGroupSaleViewDTO campaignGroupSaleViewDTO = abilityParam.getAbilityTarget();
        // 招商模板ID、招商项目
        ResourcePackageTemplateViewDTO customerTemplateViewDTO = resourcePackageRepository.getCustomerTemplateById(serviceContext, campaignGroupSaleViewDTO.getCustomerTemplateId());
        Optional.ofNullable(customerTemplateViewDTO).ifPresent(t -> {
            campaignGroupSaleViewDTO.setMarketingTemplateId(customerTemplateViewDTO.getMarketingTemplateId());
            campaignGroupSaleViewDTO.setMarketingProjectId(customerTemplateViewDTO.getProjectId());
        });

        // 销售信息
        List<String> relevantSales = Lists.newArrayList();
        if (CollectionUtils.isNotEmpty(campaignGroupSaleViewDTO.getDirectSales())) {
            relevantSales.addAll(campaignGroupSaleViewDTO.getDirectSales());
        }
        if (CollectionUtils.isNotEmpty(campaignGroupSaleViewDTO.getChannelSales())) {
            relevantSales.addAll(campaignGroupSaleViewDTO.getChannelSales());
        }
        campaignGroupSaleViewDTO.setRelevantSales(relevantSales);

        return null;
    }
}
