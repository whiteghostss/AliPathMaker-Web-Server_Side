package com.taobao.ad.brand.bp.domain.config;

import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.domain.config.base.BaseDiamondConfig;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class AutoTestMemberDiamondConfig extends BaseDiamondConfig {
    private static volatile String autoTestMemberList;

    @Override
    protected String getDataId() {
        return "auto.test.member.whitelist";
    }
    @Override
    protected String getGroupId() { return "com.taobao.ad.brand.bp"; }

    @Override
    protected void initDiamond(String diamondConfig) {
        RogerLogger.info("DiamondConfig.initDiamond AutoTestMemberDiamondConfig param: {}", diamondConfig);
        autoTestMemberList = diamondConfig;
    }

    public List<Long> getInnerMemberList(){
        if (StringUtils.isBlank(autoTestMemberList)) {
            return Lists.newArrayList();
        }
        try {
            return Arrays.stream(StringUtils.split(autoTestMemberList, ",")).map(Long::parseLong).distinct().collect(Collectors.toList());
        } catch (Exception e) {
            RogerLogger.error("autoTestMemberList has error: {}", e);
        }
        return Lists.newArrayList();

    }
}
