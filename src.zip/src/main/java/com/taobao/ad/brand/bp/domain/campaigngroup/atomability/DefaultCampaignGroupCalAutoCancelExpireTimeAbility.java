package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupContractSignStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesContractAmountViewDTO;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.SalesContractRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupCalAutoCancelExpireTimeAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupCalAutoCancelExpireTimeAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2025/4/1
 **/
@Component
@BusinessAbility
public class DefaultCampaignGroupCalAutoCancelExpireTimeAbility implements ICampaignGroupCalAutoCancelExpireTimeAbility {

    @Resource
    private CampaignRepository campaignRepository;
    @Resource
    private SalesContractRepository salesContractRepository;

    @Override
    public Date handle(ServiceContext serviceContext, CampaignGroupCalAutoCancelExpireTimeAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroup = abilityParam.getAbilityTarget();
        if (!BrandCampaignGroupStatusEnum.DRAFT.getCode().equals(campaignGroup.getStatus())
                && !BrandCampaignGroupStatusEnum.EDITED.getCode().equals(campaignGroup.getStatus())
                && !BrandCampaignGroupStatusEnum.CONTRACT_PROCESS_ING.getCode().equals(campaignGroup.getStatus())) {
            RogerLogger.info("订单状态 {} 不支持撤单, 订单id={}", campaignGroup.getStatus(), campaignGroup.getId());
            return null;
        }
        // 查询计划
        CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder().campaignGroupId(campaignGroup.getId())
                .campaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode()).build();
        List<CampaignViewDTO> campaignViewDTOS = campaignRepository.queryCampaignList(serviceContext, campaignQueryViewDTO);
        if (CollectionUtils.isEmpty(campaignViewDTOS)) {
            RogerLogger.info("订单下无计划，不支持撤单， 订单id={}", campaignGroup.getId());
            return null;
        }
        List<Date> lockSuccessDates = campaignViewDTOS.stream()
                .filter(item -> BrandCampaignStatusEnum.LOCK_SUCCESS.getCode().equals(item.getStatus()))
                .map(item -> item.getCampaignInquiryLockViewDTO().getLockCallBackTime())
                .collect(Collectors.toList());
        if (CollectionUtils.isEmpty(lockSuccessDates)) {
            RogerLogger.info("订单下无锁量成功计划,不支持撤单， 订单id={}", campaignGroup.getId());
            return null;
        }
        if (BrandCampaignGroupStatusEnum.DRAFT.getCode().equals(campaignGroup.getStatus())) {
            Date maxLockSuccessDate = lockSuccessDates.stream().max(Date::compareTo).get();
            Date lockSuccessExpireDate = BrandDateUtil.getDateMidnight(maxLockSuccessDate);
            Date finalCancelExpireTime = BrandDateUtil.getAfterDate(lockSuccessExpireDate, 0, 23, 30);
            RogerLogger.info("释量时间={}， 草稿订单id={}", BrandDateUtil.date2String(finalCancelExpireTime, BrandDateUtil.DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_1), campaignGroup.getId());
            return finalCancelExpireTime;
        } else {
            // 查询合同付款金额,已付款时不进行自动撤单
            if (BrandCampaignGroupContractSignStatusEnum.SIGNED.getCode().equals(campaignGroup.getCampaignGroupContractViewDTO().getContractSignStatus())) {
                List<SalesContractAmountViewDTO> salesContractAmountViewDTOS = salesContractRepository.getContractPayments(Lists.newArrayList(campaignGroup.getCampaignGroupContractViewDTO().getContractId()));
                if (CollectionUtils.isNotEmpty(salesContractAmountViewDTOS) && Objects.equals(salesContractAmountViewDTOS.get(0).getWaitRepayAmount(), 0L)) {
                    RogerLogger.info("合同已付款,不支持撤单， 订单id={}", campaignGroup.getId());
                    return null;
                }
            }
            Date maxLockSuccessDate = lockSuccessDates.stream().max(Date::compareTo).get();
            Date lockSuccessExpireDate = BrandDateUtil.getPlusDate(maxLockSuccessDate, 2);
            Date campaignGroupExpireDate = BrandDateUtil.getPlusDate(campaignGroup.getStartTime(), -1);
            Date finalCancelExpireDate = lockSuccessExpireDate.before(campaignGroupExpireDate) ? lockSuccessExpireDate : campaignGroupExpireDate;
            Date finalCancelExpireTime = BrandDateUtil.getAfterDate(finalCancelExpireDate, 0, 23, 30);

            RogerLogger.info("释量时间={}， 订单id={}", BrandDateUtil.date2String(finalCancelExpireTime, BrandDateUtil.DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_1), campaignGroup.getId());

            return finalCancelExpireTime;
        }
    }
}
