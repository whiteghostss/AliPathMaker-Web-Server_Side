package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;

import com.alibaba.ad.brand.dto.campaign.sale.CampaignSaleViewDTO;
import com.alibaba.ad.brand.dto.campaign.selfservice.CampaignSelfServiceViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandBundleViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSkuViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSpuViewDTO;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.campaign.util.SelfCampaignTitleBuilder;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignTitleInitAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.taobao.ad.brand.bp.common.util.BrandDateUtil.DATE_FORMAT_MMDD_TYPE_1;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCampaignTitleInitAbility extends DefaultCampaignTitleInitAbility implements SelfServiceAtomAbilityRouter {

    @Override
    public String handle(ServiceContext context, CampaignTitleInitAbilityParam abilityParam) {
        CampaignViewDTO campaignViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        BrandSpuViewDTO spuViewDTO = abilityParam.getSpuViewDTO();
        BrandSkuViewDTO skuViewDTO = abilityParam.getSkuViewDTO();
        BrandBundleViewDTO bundleViewDTO = abilityParam.getBundleViewDTO();

        String title = campaignViewDTO.getTitle();
        if (StringUtils.isEmpty(title) || isTitleFormatted(context, title, dbCampaignViewDTO, spuViewDTO,skuViewDTO,bundleViewDTO)) {
            title = generateCampaignTitle(context, campaignViewDTO, spuViewDTO,skuViewDTO,bundleViewDTO);
        }
        return title;
    }

    private boolean isTitleFormatted(ServiceContext context, String title, CampaignViewDTO dbCampaignViewDTO,
                                     BrandSpuViewDTO spuViewDTO, BrandSkuViewDTO skuViewDTO, BrandBundleViewDTO bundleViewDTO) {
        if (StringUtils.isEmpty(title) || dbCampaignViewDTO == null) {
            return false;
        }
        // 结尾为 _[6位数字]
        String regex = ".*_\\d{6}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(title);
        if (!matcher.matches()) {
            return false;
        }
        // 删去末尾防重值对比
        String generatedTitleDBTrimmed = generateCampaignTitle(context,dbCampaignViewDTO, spuViewDTO,skuViewDTO,bundleViewDTO);
        generatedTitleDBTrimmed = generatedTitleDBTrimmed.replaceAll("\\d{6}$", "");
        String titleTrimmed = title.replaceAll("\\d{6}$", "");

        return titleTrimmed.equals(generatedTitleDBTrimmed);
    }

    /**
     * 生成计划标题
     * @param context
     * @param campaignViewDTO
     * @param spuViewDTO
     * @param skuViewDTO
     * @param bundleViewDTO
     * @return
     */
    private String generateCampaignTitle(ServiceContext context, CampaignViewDTO campaignViewDTO, BrandSpuViewDTO spuViewDTO, BrandSkuViewDTO skuViewDTO, BrandBundleViewDTO bundleViewDTO) {
        return SelfCampaignTitleBuilder.builder()
                .id(campaignViewDTO.getId()).spuName(spuViewDTO.getName()).skuName(skuViewDTO.getName())
                .bundleName(Optional.ofNullable(bundleViewDTO).map(BrandBundleViewDTO::getName).orElse(null))
                .startTime(BrandDateUtil.date2String(campaignViewDTO.getStartTime(), DATE_FORMAT_MMDD_TYPE_1))
                .cartItemId(Optional.ofNullable(campaignViewDTO.getCampaignSelfServiceViewDTO()).map(CampaignSelfServiceViewDTO::getCartItemId).map(String::valueOf).orElse(null))
                .endTime(BrandDateUtil.date2String(campaignViewDTO.getEndTime(), DATE_FORMAT_MMDD_TYPE_1))
                .build().getNormalizedName().replaceAll(" ","");
    }
}
