package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativePackageTypeEnum;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativeShowAuditStatusEnum;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativeTargetTypeEnum;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.client.dto.base.DateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignBottomDateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignTemplateViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeDateMatchViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignBottomDirectCreativeBuildAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBottomDirectCreativeBuildAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSelfCampaignBottomDirectCreativeBuildAbility implements ICampaignBottomDirectCreativeBuildAbility, BrandSelfServiceAtomAbilityRouter {

    /**
     * 复制的程序化创意(全域黑盒) 可用的创意，需要按照日期进行匹配，能匹配到哪天算哪天 前置已经校验了，每天都需要有创意可以匹配到。但是并不一定可以审核通过。
     * @param serviceContext
     * @param abilityParam
     * @return
     */
    @Override
    public List<CreativeViewDTO> handle(ServiceContext serviceContext, CampaignBottomDirectCreativeBuildAbilityParam abilityParam) {
        CampaignBottomDateViewDTO campaignBottomDateViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(campaignBottomDateViewDTO,"计划打底日期信息不能为空");
        CampaignViewDTO subCampaignViewDTO = abilityParam.getSubCampaignViewDTO();
        CampaignTemplateViewDTO campaignTemplateViewDTO = abilityParam.getCampaignTemplateViewDTO();
        List<CreativeViewDTO> creativeViewDTOList = abilityParam.getCreativeViewDTOList();
        if(subCampaignViewDTO == null){
            RogerLogger.info("计划未查到，子计划ID:{}",campaignBottomDateViewDTO.getSubCampaignId());
            return Lists.newArrayList();
        }
        if(campaignTemplateViewDTO == null){
            RogerLogger.info("计划关联模板未查到，子计划ID:{}",campaignBottomDateViewDTO.getSubCampaignId());
            return Lists.newArrayList();
        }
        //根据模板匹配到的审核通过的精准的子创意
        List<CreativeViewDTO> subProgramCreativeList = creativeViewDTOList.stream()
                .filter(creativeViewDTO -> Objects.equals(BrandCreativePackageTypeEnum.PACKAGE.getValue(),creativeViewDTO.getPackageType()))
                .filter(creativeViewDTO -> org.apache.commons.collections4.CollectionUtils.isNotEmpty(creativeViewDTO.getSubCreativeViewDTOList()))
                .flatMap(creativeViewDTO -> creativeViewDTO.getSubCreativeViewDTOList().stream())
                .filter(subCreativeViewDTO -> campaignTemplateViewDTO.getTemplateIds().contains(subCreativeViewDTO.getCreativeTemplate().getSspTemplateId()))
                .filter(subCreativeViewDTO->Objects.equals(subCreativeViewDTO.getTargetType(), BrandCreativeTargetTypeEnum.PROGRAM.getCode()))
                .filter(subCreativeViewDTO -> Objects.equals(subCreativeViewDTO.getCreativeAudit().getShowAuditStatus(), BrandCreativeShowAuditStatusEnum.AUDIT_PASS.getCode()))
                .collect(Collectors.toList());

        //根据模板匹配到的媒体审核通过的直投子创意
        List<CreativeViewDTO> subDirectCreativeList = creativeViewDTOList.stream()
                .filter(creativeViewDTO -> Objects.equals(BrandCreativePackageTypeEnum.PACKAGE.getValue(),creativeViewDTO.getPackageType()))
                .filter(creativeViewDTO -> CollectionUtils.isNotEmpty(creativeViewDTO.getSubCreativeViewDTOList()))
                .flatMap(creativeViewDTO -> creativeViewDTO.getSubCreativeViewDTOList().stream())
                .filter(subCreativeViewDTO -> campaignTemplateViewDTO.getTemplateIds().contains(subCreativeViewDTO.getCreativeTemplate().getSspTemplateId()))
                .filter(subCreativeViewDTO->Objects.equals(subCreativeViewDTO.getTargetType(), BrandCreativeTargetTypeEnum.DIRECT.getCode()))
                .filter(subCreativeViewDTO->Objects.equals(subCreativeViewDTO.getCreativeAudit().getShowAuditStatus(), BrandCreativeShowAuditStatusEnum.AUDIT_PASS.getCode()))
                .collect(Collectors.toList());

        //构建媒体直投创意
        List<CreativeDateMatchViewDTO> creativeDateMatchViewDTOList = buildCreativeDateViewDTOList(subProgramCreativeList,subDirectCreativeList,campaignBottomDateViewDTO.getBottomDateList());
        List<CreativeViewDTO> needToBuildDirectCreativeList = creativeDateMatchViewDTOList.stream()
                .filter(creativeDateMatchViewDTO -> Objects.isNull(creativeDateMatchViewDTO.getDirectCreativeViewDTO()))
                .map(CreativeDateMatchViewDTO::getProgramCreativeViewDTO)
                .collect(Collectors.toMap(CreativeViewDTO::getId, Function.identity(),(v1, v2)->v1))
                .values().stream().filter(Objects::nonNull).collect(Collectors.toList());

        RogerLogger.info("generateDirectCreative needToBuildDirectCreativeList:{}",JSON.toJSONString(needToBuildDirectCreativeList));
        return needToBuildDirectCreativeList;
    }

    /**
     * 按照打底日期，取对应匹配到的周期内的创意
     * 按照妈妈审核时间取最早匹配到的
     * key = date
     * value = 创意ID
     * */
    private List<CreativeDateMatchViewDTO> buildCreativeDateViewDTOList(List<CreativeViewDTO> subProgramCreativeList,List<CreativeViewDTO> subDirectCreativeList, List<DateViewDTO> bottomDateList){

        Map<Date,CreativeViewDTO> mapSubProgramCreative = buildDateCreativeMap(bottomDateList,subProgramCreativeList);
        Map<Date,CreativeViewDTO> mapSubDirectCreative = buildDateCreativeMap(bottomDateList,subDirectCreativeList);
        List<CreativeDateMatchViewDTO> resultList = Lists.newArrayList();
        Set<Date> dateSet = Sets.newHashSet();
        if (MapUtils.isNotEmpty(mapSubProgramCreative)){
            dateSet.addAll(mapSubProgramCreative.keySet());
        }
        if (MapUtils.isNotEmpty(mapSubDirectCreative)){
            dateSet.addAll(mapSubDirectCreative.keySet());
        }
        dateSet.forEach(date->{
            CreativeDateMatchViewDTO creativeDateMatchViewDTO = new CreativeDateMatchViewDTO();

            CreativeViewDTO subProgramCreative = mapSubProgramCreative.get(date);
            CreativeViewDTO subDirectCreative = mapSubDirectCreative.get(date);
            creativeDateMatchViewDTO.setDate(date);
            creativeDateMatchViewDTO.setProgramCreativeViewDTO(subProgramCreative);
            creativeDateMatchViewDTO.setDirectCreativeViewDTO(subDirectCreative);
            resultList.add(creativeDateMatchViewDTO);
        });
        return resultList;
    }

    /**
     * 按照打底日期，取对应匹配到的周期内的创意
     * 按照妈妈审核时间取最早匹配到的
     * key = date
     * value = 创意ID
     * */
    private Map<Date,CreativeViewDTO> buildDateCreativeMap(List<DateViewDTO> bottomDateList,List<CreativeViewDTO> creativeViewDTOList){
        Map<Date,CreativeViewDTO> mapResult = Maps.newLinkedHashMap();
        if (CollectionUtils.isNotEmpty(bottomDateList)){
            List<Date> dateList = bottomDateList.stream().map(item-> BrandDateUtil.getDayList(item.getStartDate(),item.getEndDate())).collect(Collectors.toList())
                    .stream().flatMap(Collection::stream).collect(Collectors.toList());
            dateList.forEach(date->{
                CreativeViewDTO canUseCreativeViewDTO =  creativeViewDTOList.stream().filter(creativeViewDTO -> {
                    Date startDate = creativeViewDTO.getStartTime();
                    Date endDate = creativeViewDTO.getEndTime();
                    return BrandDateUtil.isBetweenDate(startDate, endDate, date);
                }).sorted(Comparator.comparing(CreativeViewDTO::getId)).collect(Collectors.toList()).stream().findFirst().orElse(null);
                if (Objects.nonNull(canUseCreativeViewDTO)){
                    mapResult.put(date,canUseCreativeViewDTO);
                }
            });
        }
        return mapResult;
    }
}
