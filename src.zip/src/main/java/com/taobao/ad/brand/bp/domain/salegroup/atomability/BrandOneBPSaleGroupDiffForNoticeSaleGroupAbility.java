package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleGroupSourceEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupOperateTypeEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupStatusEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.salegroup.SaleGroupDiffResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageNoticeSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupDiffForNoticeSaleGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupDiffAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
@BusinessAbility
public class BrandOneBPSaleGroupDiffForNoticeSaleGroupAbility implements ISaleGroupDiffForNoticeSaleGroupAbility, BrandOneBPAtomAbilityRouter {

    @Override
    public SaleGroupDiffResultViewDTO handle(ServiceContext serviceContext, SaleGroupDiffAbilityParam abilityParam) {
        List<ResourcePackageNoticeSaleGroupViewDTO> filterNoticeSaleGroupViewList = abilityParam.getFilterNoticeSaleGroupViewList();
        List<SaleGroupInfoViewDTO> campaignGroupSaleGroupList = abilityParam.getDbSaleGroupInfoViewDTOList();
        List<ResourcePackageSaleGroupViewDTO> currentTemplateSaleGroupList = abilityParam.getResourcePackageSaleGroupList();
//        Map<Long, SaleGroupInfoViewDTO> campaignGroupSaleGroupMap = campaignGroupSaleGroupList.stream()
//                .collect(Collectors.toMap(SaleGroupInfoViewDTO::getSaleGroupId, Function.identity(), (v1, v2) -> v1));

        // 删除的客户分组
        SaleGroupDiffResultViewDTO saleGroupDiffResultViewDTO = new SaleGroupDiffResultViewDTO();
        List<Long> deleteSaleGroupIds = filterNoticeSaleGroupViewList.stream()
                .filter(it -> SaleGroupOperateTypeEnum.DELETE.getValue().equals(it.getOperateType()))
//                .filter(it -> !campaignGroupSaleGroupMap.containsKey(it.getId()) || BrandSaleGroupSourceEnum.PACKAGE_PLATFORM.getCode().equals(campaignGroupSaleGroupMap.get(it.getId()).getSource()))
                .map(ResourcePackageNoticeSaleGroupViewDTO::getId).collect(Collectors.toList());
        saleGroupDiffResultViewDTO.setDeleteSaleGroupIds(deleteSaleGroupIds);

        // 新增或更新的客户分组
        List<Long> addOrUpdateSaleGroupIdList = filterNoticeSaleGroupViewList.stream().filter(t -> !SaleGroupOperateTypeEnum.DELETE.getValue().equals(t.getOperateType())).map(ResourcePackageNoticeSaleGroupViewDTO::getId).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(addOrUpdateSaleGroupIdList)) {
            return saleGroupDiffResultViewDTO;
        }
        // 订单上来自打包平台的分组（全部补量+部分配送）
        Map<Long, SaleGroupInfoViewDTO> campaignGroupPackagePlatformSaleGroupMap = campaignGroupSaleGroupList.stream()
                .filter(t -> BrandSaleGroupSourceEnum.PACKAGE_PLATFORM.getCode().equals(t.getSource()))
                .collect(Collectors.toMap(SaleGroupInfoViewDTO::getSaleGroupId, Function.identity()));

        // 订单上来自售卖中心的分组（全部购买+部分配送）
        List<SaleGroupInfoViewDTO> campaignGroupSalesPlatformSaleGroupList = campaignGroupSaleGroupList.stream()
                .filter(t -> BrandSaleGroupSourceEnum.SALE_PLATFORM.getCode().equals(t.getSource()))
                .collect(Collectors.toList());
        // 客户模版下的所有来自打包平台的补量配送分组（key:主分组id：value:补量/配送分组）
        Map<Long, List<ResourcePackageSaleGroupViewDTO>> packagePlatformSaleGroupByMainIdMap = currentTemplateSaleGroupList.stream()
                .filter(t -> BrandSaleGroupSourceEnum.PACKAGE_PLATFORM.getCode().equals(t.getSource()) && t.getMainGroupId() != null)
                .collect(Collectors.groupingBy(ResourcePackageSaleGroupViewDTO::getMainGroupId));

        List<Long> addSaleGroupIds = Lists.newArrayList();
        List<Long> updateSaleGroupIds = Lists.newArrayList();
        // 以售卖中心分组为基准
        campaignGroupSalesPlatformSaleGroupList.forEach(salePlatformSaleGroup -> {
            // 如果是配送分组则进行下一次循环，只有主分组才往下走
            if (packagePlatformSaleGroupByMainIdMap.containsKey(salePlatformSaleGroup.getSaleGroupId())) {
                for (ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO : packagePlatformSaleGroupByMainIdMap.get(salePlatformSaleGroup.getSaleGroupId())) {
                    // 如果订单之前已经绑定了该分组，则【状态】属性以当前分组为准
                    if (campaignGroupPackagePlatformSaleGroupMap.containsKey(resourcePackageSaleGroupViewDTO.getId())) {
                        updateSaleGroupIds.add(resourcePackageSaleGroupViewDTO.getId());
                    } else if (SaleGroupStatusEnum.EFFECTIVE.getValue().equals(resourcePackageSaleGroupViewDTO.getStatus())) {
                        addSaleGroupIds.add(resourcePackageSaleGroupViewDTO.getId());
                    }
                }
            }
        });
        // 注：并不是通过打包侧传入的notice分组来判断新增或更新的，而是查询客户模版下的全量source是打包平台的分组，订单上已经存在的即为更新（无论是否真的更新），不存在的即为新建
        saleGroupDiffResultViewDTO.setAddSaleGroupIds(addSaleGroupIds);
        saleGroupDiffResultViewDTO.setUpdateSaleGroupIds(updateSaleGroupIds);
        return saleGroupDiffResultViewDTO;
    }
}
