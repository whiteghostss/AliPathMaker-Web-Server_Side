package com.taobao.ad.brand.bp.domain.config;

import com.taobao.ad.brand.bp.common.enums.BooleanEnum;
import com.taobao.ad.brand.bp.domain.config.base.BaseDiamondPropertiesConfig;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class BrandOneBPDiamondConfig extends BaseDiamondPropertiesConfig {

    @Override
    protected String getDataId() {
        return "default.properties";
    }

    @Override
    protected String getGroupId() { return "com.taobao.ad.brand.bp"; }

    /**
     * config-key配置
     */
    private interface DiamondConfigKey {
        /**
         * 权限过期时间
         */
        String PERMISSION_CACHE_EXPIRE_TIME = "permission.cache.expire-time";
        /**
         * 权限缓存开关(0:关闭，1:打开)
         */
        String PERMISSION_CACHE_ENABLE = "permission.cache.enable";
        /**
         * 支持原始视频元素模板，-> 客户上传的视频不做压缩处理
         */
        String ORIGINAL_VIDEO_TEMPLATE = "original_video_template";
        /**
         * 异步事件开关(0:关闭，1:打开)
         */
        String ASYNC_EVENT_ENABLE = "async.event.enable";
        /**
         * 直播拒审消息过期时间
         */
        String LIVE_REJECT_MSG_EXPIRE_TIME = "live.reject.msg.expire-time";
    }

    public Integer getPermissionCacheExpireTime(){
        return getPropertyValueAsInteger(DiamondConfigKey.PERMISSION_CACHE_EXPIRE_TIME, 600);
    }

    public Integer getPermissionCacheEnable(){
        return getPropertyValueAsInteger(DiamondConfigKey.PERMISSION_CACHE_ENABLE, BooleanEnum.TRUE.getValue());
    }

    public List<Long> getOriginalVideoTemplateList(){
        return getPropertyValueAsList(DiamondConfigKey.ORIGINAL_VIDEO_TEMPLATE);
    }

    /**
     * 异步事件消息
     * @return
     */
    public Integer getAsyncEventEnable(){
        return getPropertyValueAsInteger(DiamondConfigKey.ASYNC_EVENT_ENABLE, BooleanEnum.FALSE.getValue());
    }

    public Integer getLiveRejectMsgExpireTime(){
        return getPropertyValueAsInteger(DiamondConfigKey.LIVE_REJECT_MSG_EXPIRE_TIME, 300);
    }
}
