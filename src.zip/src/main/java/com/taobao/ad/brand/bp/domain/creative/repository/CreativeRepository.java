package com.taobao.ad.brand.bp.domain.creative.repository;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.adgroup.CreativeRefViewDTO;
import com.alibaba.ad.brand.dto.creative.ContentVersionViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.creative.query.ContentVersionQuery;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeItemBizInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeLandingPageAnalysisViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeQueryViewDTO;

import java.util.List;

public interface CreativeRepository {
    /**
     * 新增创意
     *
     * @param serviceContext
     * @param creativeViewDTO
     * @return
     */
    Long addCreative(ServiceContext serviceContext, CreativeViewDTO creativeViewDTO);

    /**
     * 编辑创意
     *
     * @param serviceContext
     * @param creativeViewDTO
     * @return
     */
    Integer updateCreative(ServiceContext serviceContext, CreativeViewDTO creativeViewDTO);

    /**
     * 直接更新创意，不触发审核
     *
     * @param serviceContext
     * @param creativeViewDTO
     * @return
     */
    Integer updateCreativePart(ServiceContext serviceContext, CreativeViewDTO creativeViewDTO);


    /**
     * 解绑创意
     *
     * @param context
     * @param adgroupIds
     * @param creativeIds
     * @return
     */
    Integer unBindCreative(ServiceContext context, List<Long> adgroupIds, List<Long> creativeIds);

    /**
     * 删除单元创意绑定关系
     *
     * @param serviceContext
     * @param adgroupIds
     * @return
     */
    Integer unBindCreative(ServiceContext serviceContext, List<Long> adgroupIds);

    /**
     * 强行解绑创意，无视校验
     *
     * @param context
     * @param creativeIds
     * @return
     */
    Integer delBindCreative(ServiceContext context, List<Long> creativeIds);

    /**
     * 绑定创意
     *
     * @param serviceContext
     * @param creativeRefViewDTOList
     * @return
     */
    List<CreativeRefViewDTO> addBatchCreativeRef(ServiceContext serviceContext, List<CreativeRefViewDTO> creativeRefViewDTOList);

    /**
     * 绑定创意creative_ref（有update，无add）和creative_ref_setting(全量更新)
     *
     * @param serviceContext
     * @param creativeRefViewDTOList
     * @return
     */
    List<CreativeRefViewDTO> addBatchCreativeRefAndSetting(ServiceContext serviceContext, List<CreativeRefViewDTO> creativeRefViewDTOList);


    /**
     * 分页查询创意列表
     *
     * @param serviceContext
     * @param creativeViewDTO
     * @return
     */
    PageResultViewDTO<CreativeViewDTO> findListWithPage(ServiceContext serviceContext, CreativeQueryViewDTO creativeViewDTO);


    /**
     * 查询创意详情
     *
     * @param serviceContext
     * @param id
     * @return
     */
    CreativeViewDTO getCreativeById(ServiceContext serviceContext, Long id);

    /**
     * 查询创意列表
     *
     * @param serviceContext
     * @param ids
     * @return
     */
    List<CreativeViewDTO> findCreativeByIds(ServiceContext serviceContext, List<Long> ids);

    /**
     * 查询绑定关系列表（默认返回setting-key）
     * @param serviceContext
     * @param queryViewDTO
     * @return
     */
    List<CreativeRefViewDTO> findCreativeRefList(ServiceContext serviceContext, CreativeQueryViewDTO queryViewDTO);

    /**
     * 查询绑定关系列表
     *
     * @param serviceContext
     * @param queryViewDTO
     * @param isNeedSetting  是否返回creativeRef扩展属性
     * @return
     */
    List<CreativeRefViewDTO> findCreativeRefList(ServiceContext serviceContext, CreativeQueryViewDTO queryViewDTO,boolean isNeedSetting);

    /**
     * 重新推审风控中心
     *
     * @param serviceContext
     * @param creativeIdList
     * @param qualifyJson
     */
    void rePushCreativeCenter(ServiceContext serviceContext, List<Long> creativeIdList, String qualifyJson);

    /**
     * 计算更新创意状态
     *
     * @param serviceContext
     * @param creativeId
     * @return
     */
    Integer calcUpdateAndUpperCreativeQualityInfo(ServiceContext serviceContext, Long creativeId);

    /**
     * 强制删除创意
     *
     * @param serviceContext
     * @param creativeIds
     * @return
     */
    List<Long> deleteCreatives(ServiceContext serviceContext, List<Long> creativeIds);

    /**
     * 解析落地页
     *
     * @param serviceContext
     * @param clickUrl
     * @return
     */
    CreativeLandingPageAnalysisViewDTO analysisClickUrl(ServiceContext serviceContext, String clickUrl);

    /**
     * 获取 指定contentId(uuid)的最新版本
     *
     * @param context   上下文
     * @param contentId uuid
     * @return 监测代码
     */
    ContentVersionViewDTO getLastContentVersionByContentId(ServiceContext context, Long contentId);

    /**
     * 获取 指定id的监测
     *
     * @param context 上下文
     * @param id      主键id
     * @return 监测代码
     */
    ContentVersionViewDTO getContentVersionById(ServiceContext context, Long id);

    /**
     * 获取 指定条件的监测
     *
     * @param context             上下文
     * @param contentVersionQuery 查询条件
     * @return 监测代码
     */
    List<ContentVersionViewDTO> findContentVersionList(ServiceContext context, ContentVersionQuery contentVersionQuery);

    /**
     * 添加监测代码
     *
     * @param context           上下文
     * @param contentVersionDTO 内容
     * @return 返回
     */
    ContentVersionViewDTO addContentVersion(ServiceContext context, ContentVersionViewDTO contentVersionDTO);

    /**
     * 向主站库存中心同步加购创意的商品信息(for 特秀加购创意)
     *
     * @param context           上下文
     * @param creativeItemBizInfoViewDTO 内容
     * @return 返回
     */
    void syncItemBizInfo(ServiceContext context, CreativeItemBizInfoViewDTO creativeItemBizInfoViewDTO);

    /**
     * 基于素材组查询创意
     * @param serviceContext
     * @param materialGroupId
     * @return
     */
    List<CreativeViewDTO> findListByMaterialGroupId(ServiceContext serviceContext, Long materialGroupId);

    /**
     * 获取topshow直播在投创意
     * @param serviceContext
     * @return
     */
    List<CreativeViewDTO> findTopShowLiveCreativeList(ServiceContext serviceContext );

}
