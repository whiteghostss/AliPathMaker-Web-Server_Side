package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignRegisterUnitEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.product.CastTypeEnum;
import com.alibaba.ad.nb.ssp.constant.common.CrossSceneEnum;
import com.alibaba.ad.nb.ssp.constant.common.MediaScopeEnum;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignAdzoneValidateForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignAdzoneAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_ILLEGAL;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCampaignAdzoneValidateForAddCampaignAbility implements ICampaignAdzoneValidateForAddCampaignAbility, SelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignAdzoneAbilityParam abilityParam) {
        ProductViewDTO productViewDTO = abilityParam.getProductViewDTO();
        AssertUtil.notNull(productViewDTO,"计划产品不允许为空");
        ResourcePackageProductViewDTO packageProductViewDTO = abilityParam.getResourcePackageProductViewDTO();
        AssertUtil.notNull(packageProductViewDTO,"计划资源位位不允许为空");
        // 【推广位】资源关联产品推广位不能为空，跨域场景下需要判断其关联的子产品推广位是否为空
        if (MediaScopeEnum.CROSS_SCOPE.getCode().equals(productViewDTO.getMediaScope())) {
            AssertUtil.notEmpty(productViewDTO.getAssociationProductList(),  "跨域场景下资源关联产品" + productViewDTO.getUuid() + "的子产品不能为空");
            AssertUtil.assertTrue(BrandCampaignRegisterUnitEnum.CPM.getCode().equals(productViewDTO.getRegisterUnit()) || BrandCampaignRegisterUnitEnum.CPM.getCode().equals(productViewDTO.getSellUnit()),"跨域产品目前不支持CPT");
            for (ProductViewDTO viewDTO : productViewDTO.getAssociationProductList()) {
                AssertUtil.notEmpty(viewDTO.getAdzoneIdList(), PARAM_ILLEGAL, "跨域场景下资源关联产品" + viewDTO.getUuid() + "的推广位不能为空");
            }
            // 跨域场景为“全域通”，不支持含三环PDB/CPM的二级产品
            if (productViewDTO.getCrossScene() != null && productViewDTO.getCrossScene() == CrossSceneEnum.CROSS_SCENE.getValue()) {
                for (ResourcePackageProductViewDTO subPackageProductViewDTO : packageProductViewDTO.getSubResourcePackageProductList()) {
                    AssertUtil.assertTrue(!(Objects.equals(subPackageProductViewDTO.getMediaScope(), MediaScopeEnum.SITE_OUT.getCode())
                            && (CastTypeEnum.PDB.getValue().equals(subPackageProductViewDTO.getCastType().getType())
                            || StringUtils.isNotBlank(subPackageProductViewDTO.getCastType().getReturnRatio()))), "跨域场景为“全域通”，不支持含三环PDB/CPM的二级产品");
                }
            }
        } else {
            AssertUtil.notEmpty(productViewDTO.getAdzoneIdList(), "资源关联产品" + productViewDTO.getUuid() + "的推广位不能为空");
        }
        return null;
    }
}
