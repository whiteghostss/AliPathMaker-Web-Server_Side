package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.price.CampaignPriceViewDTO;
import com.alibaba.ad.brand.dto.campaign.price.DayPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignPriceInitForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignPriceAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandCampaignPriceInitForAddCampaignAbility implements ICampaignPriceInitForAddCampaignAbility, BrandAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignPriceAbilityParam abilityParam) {
        CampaignPriceViewDTO campaignPriceViewDTO = abilityParam.getAbilityTarget();
        ProductViewDTO productViewDTO = abilityParam.getProductViewDTO();
        ResourcePackageProductViewDTO resourcePackageProductViewDTO = abilityParam.getResourcePackageProductViewDTO();
        AssertUtil.notNull(campaignPriceViewDTO, "计划单价信息不能为空");
        AssertUtil.notNull(resourcePackageProductViewDTO, "资源包二级产品不能为空");
        AssertUtil.notNull(productViewDTO, "二级产品不能为空");

        List<ResourcePackageProductPriceViewDTO> bandPriceList = resourcePackageProductViewDTO.getBandPriceList();
        List<DayPriceViewDTO> publishPriceInfoList = bandPriceList.stream().map(item -> {
            DayPriceViewDTO dayPriceViewDTO = new DayPriceViewDTO();
            dayPriceViewDTO.setPrice(item.getPublishPrice());
            dayPriceViewDTO.setStartDate(item.getStartDate());
            dayPriceViewDTO.setEndDate(item.getEndDate());
            return dayPriceViewDTO;
        }).collect(Collectors.toList());
        List<DayPriceViewDTO> discountPriceInfoList = bandPriceList.stream().map(item -> {
            DayPriceViewDTO dayPriceViewDTO = new DayPriceViewDTO();
            dayPriceViewDTO.setPrice(item.getPrice());
            dayPriceViewDTO.setStartDate(item.getStartDate());
            dayPriceViewDTO.setEndDate(item.getEndDate());
            dayPriceViewDTO.setDiscountRatio(item.getPriceRatio());
            return dayPriceViewDTO;
        }).collect(Collectors.toList());

        campaignPriceViewDTO.setPublishProductId(productViewDTO.getLabel());
        campaignPriceViewDTO.setPublishPriceInfoList(publishPriceInfoList);
        campaignPriceViewDTO.setDiscountPriceInfoList(discountPriceInfoList);

        return null;
    }
}
