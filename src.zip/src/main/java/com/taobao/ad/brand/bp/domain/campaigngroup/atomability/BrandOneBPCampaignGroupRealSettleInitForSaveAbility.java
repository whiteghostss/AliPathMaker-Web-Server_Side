package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.realsettle.CampaignGroupRealSettleViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.realsettle.RealSettleInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupProcessStatusEnum;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupRealSettleInitForSaveAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Set;

@Component
@BusinessAbility
public class BrandOneBPCampaignGroupRealSettleInitForSaveAbility
    extends DefaultCampaignGroupRealSettleInitForSaveAbility implements BrandOneBPAtomAbilityRouter {

    @Resource
    private CampaignGroupRepository campaignGroupRepository;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupRealSettleInitForSaveAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        List<CampaignGroupViewDTO> subCampaignGroupList = abilityParam.getSubCampaignGroupList();
        CampaignGroupRealSettleViewDTO mainRealSettleViewDTO = new CampaignGroupRealSettleViewDTO();
        List<RealSettleInfoViewDTO> mainRealSettleInfoViewDTOList = Lists.newArrayList();
        List<Integer> subRealSettleProcessStatusList = Lists.newArrayList();
        for (CampaignGroupViewDTO subCampaignGroup : subCampaignGroupList) {
            // 配置信息
            if (CollectionUtils.isNotEmpty(subCampaignGroup.getCampaignGroupRealSettleViewDTO().getRealSettleInfoViewDTOList())) {
                mainRealSettleInfoViewDTOList.addAll(subCampaignGroup.getCampaignGroupRealSettleViewDTO().getRealSettleInfoViewDTOList());
            }
            // 状态
            if (subCampaignGroup.getCampaignGroupRealSettleViewDTO().getRealSettleProcessStatus() != null) {
                subRealSettleProcessStatusList.add(subCampaignGroup.getCampaignGroupRealSettleViewDTO().getRealSettleProcessStatus());
            }
        }
        Integer realSettleProcessStatus = calculateMainRealSettleProcessStatus(subCampaignGroupList, subRealSettleProcessStatusList);

        mainRealSettleViewDTO.setRealSettleProcessStatus(realSettleProcessStatus);
        mainRealSettleViewDTO.setRealSettleInfoViewDTOList(mainRealSettleInfoViewDTOList);
        campaignGroupViewDTO.setCampaignGroupRealSettleViewDTO(mainRealSettleViewDTO);

        return null;
    }


    private Integer calculateMainRealSettleProcessStatus(List<CampaignGroupViewDTO> subCampaignGroupList, List<Integer> subRealSettleProcessStatusList) {
        // size不相等时，说明有的子订单没有实结配置状态
        if (CollectionUtils.isEmpty(subRealSettleProcessStatusList)) {
            return null;
        }
        if (subCampaignGroupList.size() != subRealSettleProcessStatusList.size()) {
            return BrandCampaignGroupProcessStatusEnum.EDITED.getCode();
        }
        Set<Integer> subRealSettleProcessStatusSet = Sets.newHashSet(subRealSettleProcessStatusList);
        // 说明子订单实结配置状态一致，取第一个返回
        if (subRealSettleProcessStatusSet.size() == 1) {
            return subRealSettleProcessStatusList.get(0);
        } else if (subRealSettleProcessStatusSet.contains(BrandCampaignGroupProcessStatusEnum.EDITED.getCode()) || subRealSettleProcessStatusSet.contains(BrandCampaignGroupProcessStatusEnum.REFUSED.getCode())) {
            return BrandCampaignGroupProcessStatusEnum.EDITED.getCode();
        } else if (subRealSettleProcessStatusSet.contains(BrandCampaignGroupProcessStatusEnum.APPROVE_ING.getCode())) {
            return BrandCampaignGroupProcessStatusEnum.APPROVE_ING.getCode();
        }

        return null;
    }
}
