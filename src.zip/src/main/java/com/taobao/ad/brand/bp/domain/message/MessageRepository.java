package com.taobao.ad.brand.bp.domain.message;

import com.taobao.ad.brand.bp.client.dto.message.MessageViewDTO;

import java.util.List;

public interface MessageRepository {
    /**
     * 发送message通知
     */
    void sendMessage(MessageViewDTO messageViewDTO);

    /**
     * 发送邮件（区分线上和预发环境）
     * @param sendTo 发送人
     * @param subject 标题
     * @param content 内容
     */
    void sendEmail(String sendTo, String subject, String content);
}
