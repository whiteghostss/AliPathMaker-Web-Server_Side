package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupBoostGiveApplyInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSaleOrderStatusEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupAuditStatusEnum;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupApplyInfoValidateForDeleteSaleGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupApplyInfoAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Optional;

import static com.alibaba.ad.nb.packages.constant.common.EditModeConstant.SALE_GROUP_EDIT_MODE_BRAND_NON_CAMPAIGNS;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultSaleGroupApplyInfoValidateForDeleteSaleGroupAbility implements ISaleGroupApplyInfoValidateForDeleteSaleGroupAbility {
    private final CampaignGroupRepository campaignGroupRepository;
    private final ResourcePackageRepository resourcePackageRepository;

    @Override
    public Void handle(ServiceContext serviceContext, SaleGroupApplyInfoAbilityParam abilityParam) {
        SaleGroupBoostGiveApplyInfoViewDTO applyInfoViewDTO = abilityParam.getAbilityTarget();
        CampaignGroupViewDTO campaignGroup = abilityParam.getCampaignGroup();
        SaleGroupInfoViewDTO mainSaleGroupInfoViewDTO = abilityParam.getMainSaleGroupInfoViewDTO();

        AssertUtil.notNull(applyInfoViewDTO.getSaleGroupId(), "补量/配送分组id不能为空");
        SaleGroupBoostGiveApplyInfoViewDTO oldSaleGroupBoostInfo = Optional.of(mainSaleGroupInfoViewDTO.getBoostGiveApplyInfoList().stream()
                .filter(saleGroup -> applyInfoViewDTO.getSaleGroupId().equals(saleGroup.getSaleGroupId()))
                .findFirst()).get().orElse(null);
        AssertUtil.notNull(oldSaleGroupBoostInfo, "非百灵申请的补量/配送分组，不允许删除");

        SaleGroupInfoViewDTO oldSaleGroupInfoViewDTO = campaignGroupRepository.getSaleGroup(serviceContext, campaignGroup.getId(), applyInfoViewDTO.getSaleGroupId());
        ResourcePackageSaleGroupViewDTO oldSaleGroup = resourcePackageRepository.getSaleGroupWithEditMode(serviceContext, applyInfoViewDTO.getSaleGroupId());

        AssertUtil.assertTrue((Objects.isNull(oldSaleGroupInfoViewDTO) || BrandCampaignGroupSaleOrderStatusEnum.WAIT_ORDER.getCode().equals(oldSaleGroupInfoViewDTO.getSaleGroupStatus()))
                        && SALE_GROUP_EDIT_MODE_BRAND_NON_CAMPAIGNS.equals(oldSaleGroup.getEditMode()),
                "当前分组已下单或分组中存在计划，不允许删除，请检查并修改后重试");

        AssertUtil.assertTrue(SaleGroupAuditStatusEnum.AUDIT_FAILED.getValue().equals(oldSaleGroup.getAuditStatus())
                        || SaleGroupAuditStatusEnum.AUDIT_SUCCESS.getValue().equals(oldSaleGroup.getAuditStatus()),
                "当前分组在审核中，不允许删除，请检查并修改后重试");
        return null;
    }
}
