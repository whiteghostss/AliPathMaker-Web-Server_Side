package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupBaseInitForAddCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupBaseAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
public class BrandOneBPCampaignGroupBaseInitForAddCampaignGroupAbility
        implements ICampaignGroupBaseInitForAddCampaignGroupAbility, BrandOneBPAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupBaseAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        if (!BizCampaignGroupToolsHelper.isSaleCampaignGroup(campaignGroupViewDTO)) {
            return null;
        }
        // 设置订单时间
        campaignGroupViewDTO.setStartTime(BrandDateUtil.getDateMidnight(campaignGroupViewDTO.getCampaignGroupContractViewDTO().getContractStartTime()));
        campaignGroupViewDTO.setEndTime(BrandDateUtil.getDateFullMidnight(campaignGroupViewDTO.getCampaignGroupContractViewDTO().getContractEndTime()));
        // 状态
        campaignGroupViewDTO.setStatus(BrandCampaignGroupStatusEnum.EDITED.getCode());
        // 基础信息
        campaignGroupViewDTO.setProductLineId(serviceContext.getProductLineId());
        campaignGroupViewDTO.setMemberId(serviceContext.getMemberId());
        campaignGroupViewDTO.setSceneId(ServiceContextUtil.getSceneId(serviceContext));
        // 主订单ID和层级
        campaignGroupViewDTO.setParentId(0L);
        campaignGroupViewDTO.setCampaignGroupLevel(BrandCampaignGroupLevelEnum.LEVEL_ONE.getCode());

        if (campaignGroupViewDTO.getCampaignGroupSaleViewDTO() != null && campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getBriefId() != null) {
            campaignGroupViewDTO.setSourceIds(Lists.newArrayList(campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getBriefId()));
        }
        // 运营相关人
        if (CollectionUtils.isNotEmpty(campaignGroupViewDTO.getOperators())) {
            campaignGroupViewDTO.setRelevantOperators(campaignGroupViewDTO.getOperators());
        }

        return null;
    }
}
