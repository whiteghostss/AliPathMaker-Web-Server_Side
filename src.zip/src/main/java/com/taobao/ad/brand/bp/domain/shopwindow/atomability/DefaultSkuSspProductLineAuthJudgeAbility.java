package com.taobao.ad.brand.bp.domain.shopwindow.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.dto.product.ProductQueryOption;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSkuViewDTO;
import com.taobao.ad.brand.bp.domain.memeber.MemberRepository;
import com.taobao.ad.brand.bp.domain.sdk.shopwindow.atomability.ISkuSspProductLineAuthJudgeAbility;
import com.taobao.ad.brand.bp.domain.sdk.shopwindow.atomability.param.SkuSspProductLineAuthJudgeAbilityParam;
import com.taobao.ad.brand.bp.domain.ssp.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * sku批量ssp产品线校验能力
 */
@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultSkuSspProductLineAuthJudgeAbility implements ISkuSspProductLineAuthJudgeAbility {

    private final ProductRepository productRepository;
    private final MemberRepository memberRepository;

    /**
     * 校验
     *
     * @param context
     * @param authJudgeAbilityParam
     * @return sspProductUUID--->是否准入
     */
    @Override
    public Map<Long, Boolean> handle(ServiceContext context, SkuSspProductLineAuthJudgeAbilityParam authJudgeAbilityParam) {
        Map<Long, Boolean> checkResult = Maps.newHashMap();
        List<BrandSkuViewDTO> brandSkuViewDTOList = authJudgeAbilityParam.getAbilityTargets();
        if(CollectionUtils.isEmpty(brandSkuViewDTOList)){
            return checkResult;
        }
        List<Long> sspProductUuidList = brandSkuViewDTOList.stream()
                .map(BrandSkuViewDTO::getSspProductUuid)
                .filter(Objects::nonNull)
                .distinct()
                .collect(Collectors.toList());
        if (CollectionUtils.isEmpty(sspProductUuidList)){
            return checkResult;
        }
        //账户未登录
        if(context.getMemberId() == null){
            return checkResult;
        }
        List<ProductViewDTO> productViewDTOList = productRepository.getProductByUuidOption(sspProductUuidList, ProductQueryOption.builder().build());
        if(CollectionUtils.isEmpty(productViewDTOList)){
            return checkResult;
        }
        List<String> sspCodeList = productViewDTOList.stream()
                .map(ProductViewDTO::getProductLineId)
                .filter(Objects::nonNull)
                .distinct()
                .map(String::valueOf)
                .collect(Collectors.toList());
        List<String> sspJoinResult = memberRepository.getSspJoinResult(context, context.getMemberId(), sspCodeList);
        if(CollectionUtils.isEmpty(sspJoinResult)){
            return checkResult;
        }
        productViewDTOList.stream()
                .filter(productViewDTO -> sspJoinResult.contains(productViewDTO.getProductLineId().toString()))
                .forEach(productViewDTO -> checkResult.put(productViewDTO.getUuid(), true));
        return checkResult;
    }
}
