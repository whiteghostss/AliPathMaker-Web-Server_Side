package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.constant.campaigngroup.CampaignGroupConstant;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.EffectAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupStatusValidateForBindAdvAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupStatusValidateForBindOrUnBindAdvAbilityParam;

import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author yanjingang
 * @date 2024/11/25
 */
@Component
@BusinessAbility
public class EffectCampaignGroupStatusValidateForBindAdvAbility implements ICampaignGroupStatusValidateForBindAdvAbility, EffectAtomAbilityRouter {

    public static final List<Integer> EFFECT_ADV_CAN_BIND_STATUS = Lists.newArrayList();
    static {
        EFFECT_ADV_CAN_BIND_STATUS.add(BrandCampaignGroupStatusEnum.EDITED.getCode());
        EFFECT_ADV_CAN_BIND_STATUS.add(BrandCampaignGroupStatusEnum.ORDER_ING.getCode());
        EFFECT_ADV_CAN_BIND_STATUS.add(BrandCampaignGroupStatusEnum.UNLOCKED.getCode());

        EFFECT_ADV_CAN_BIND_STATUS.add(BrandCampaignGroupStatusEnum.CONTRACT_PROCESS_ING.getCode());
        EFFECT_ADV_CAN_BIND_STATUS.add(BrandCampaignGroupStatusEnum.WAIT_CAST.getCode());
        EFFECT_ADV_CAN_BIND_STATUS.add(BrandCampaignGroupStatusEnum.CAST_ING.getCode());

    }

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupStatusValidateForBindOrUnBindAdvAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.assertTrue(CampaignGroupConstant.EFFECT_ADV_CAN_BIND_STATUS.contains(campaignGroupViewDTO.getStatus()),"订单状态："+ BrandCampaignGroupStatusEnum.getByCode(campaignGroupViewDTO.getStatus()).getDesc()+"不支持绑定");
        return null;
    }
}
