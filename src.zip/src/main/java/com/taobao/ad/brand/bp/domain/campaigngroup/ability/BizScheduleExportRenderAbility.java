package com.taobao.ad.brand.bp.domain.campaigngroup.ability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.context.ScheduleExportContext;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.export.FilterResultViewDTO;
import com.taobao.ad.brand.bp.common.spi.ExtensionPointsFactory;
import com.taobao.ad.brand.bp.domain.campaigngroup.spi.export.BizScheduleExportRenderSpi;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Service;

/**
 * @author jixiu.lj
 * @date 2023/3/29 12:17
 */
@Service
public class BizScheduleExportRenderAbility {

    public void render(ServiceContext context, ScheduleExportContext scheduleExportContext, String spiCode, Workbook wb, FilterResultViewDTO filterResultViewDTO) {
        ExtensionPointsFactory.runAbilitySpi(BizScheduleExportRenderSpi.class, extension -> extension.render(context, scheduleExportContext, wb, filterResultViewDTO), spiCode, context.getBizCode());
    }
}
