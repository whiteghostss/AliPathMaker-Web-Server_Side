package com.taobao.ad.brand.bp.domain.cart.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.ICartItemBaseValidateForAddCartItemAbility;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.param.CartItemValidateAbilityParam;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
public class DefaultCartItemBaseValidateForAddCartItemAbility implements ICartItemBaseValidateForAddCartItemAbility {

    @Override
    public Void handle(ServiceContext context, CartItemValidateAbilityParam abilityParam) {
        throw new BrandOneBPException(BrandOneBPBaseErrorCode.BIZ_UN_SUPPORT_ERROR.of("该场景不允许自助化操作"));
    }
}
