package com.taobao.ad.brand.bp.domain.solution.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.domain.sdk.solution.atomability.ISolutionCommandBaseValidateForSaveCartItemSolutionAbility;
import com.taobao.ad.brand.bp.domain.sdk.solution.atomability.param.CartItemSolutionCommandAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultSolutionCommandBaseValidateForSaveCartItemSolutionAbility implements ISolutionCommandBaseValidateForSaveCartItemSolutionAbility {

    @Override
    public Void handle(ServiceContext serviceContext, CartItemSolutionCommandAbilityParam abilityParam) {
        throw new BrandOneBPException("该业务场景暂不支持一站式投放模式");
    }
}
