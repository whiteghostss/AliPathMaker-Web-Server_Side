package com.taobao.ad.brand.bp.domain.bpms;

import java.util.Map;

import com.taobao.ad.brand.bp.common.enums.BpmsProcessCodeEnum;

/**
 * @author yanjingang
 * @date 2023/3/20
 */
public interface BpmsRepository {

    /**
     * 发起并启动
     *
     * @param title
     * @param titleEn
     * @param empId
     * @param initData
     * @param processCodeEnum
     * @return
     */
    String startProcessInstance(String title, String titleEn, String empId, Map<String, String> initData, BpmsProcessCodeEnum processCodeEnum);
}
