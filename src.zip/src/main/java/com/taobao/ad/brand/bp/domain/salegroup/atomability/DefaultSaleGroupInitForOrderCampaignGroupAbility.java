package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSaleOrderStatusEnum;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupInitForOrderCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupOrderAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
@BusinessAbility
public class DefaultSaleGroupInitForOrderCampaignGroupAbility implements ISaleGroupInitForOrderCampaignGroupAbility {

    @Override
    public Void handle(ServiceContext serviceContext, SaleGroupOrderAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        List<CampaignViewDTO> campaignViewDTOList = abilityParam.getCampaignViewDTOList();
        List<Long> checkedSaleGroupIds = abilityParam.getSaleGroupIds();

        Map<Long, ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupMap = abilityParam.getResourcePackageSaleGroupList().stream()
                .collect(Collectors.toMap(ResourcePackageSaleGroupViewDTO::getId, Function.identity()));
        List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList();
        // 计划根据SaleGroupId分组信息
        Map<Long, List<CampaignViewDTO>> saleGroupCampaignMap = campaignViewDTOList.stream().collect(Collectors.groupingBy(t -> t.getCampaignSaleViewDTO().getSaleGroupId()));
        // 设置分组待更新信息
        saleGroupInfoViewDTOList.forEach(saleGroupInfo -> {
            if (checkedSaleGroupIds.contains(saleGroupInfo.getSaleGroupId())) {
                // 设置saleGroup下单状态
                saleGroupInfo.setSaleGroupStatus(BrandCampaignGroupSaleOrderStatusEnum.ORDER_ING.getCode());
                // 设置分组的首次下单时间
                if (saleGroupInfo.getFirstOrderTime() == null) {
                    saleGroupInfo.setFirstOrderTime(BrandDateUtil.getCurrentTime());
                }
            }
            if (!resourcePackageSaleGroupMap.containsKey(saleGroupInfo.getSaleGroupId())) {
                return;
            }
//            ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO = resourcePackageSaleGroupMap.get(saleGroupInfo.getSaleGroupId());
//            saleGroupInfo.setSaleType(resourcePackageSaleGroupViewDTO.getSaleType());
//            saleGroupInfo.setBudget(resourcePackageSaleGroupViewDTO.getBudget());
            // 汇总并设置计划最大最小时间
            List<CampaignViewDTO> saleGroupCampaignList = saleGroupCampaignMap.get(saleGroupInfo.getSaleGroupId());
            if (CollectionUtils.isNotEmpty(saleGroupCampaignList)) {
                saleGroupInfo.setStartDate(BrandDateUtil.getDateMidnight(BizCampaignGroupToolsHelper.getCampaignMinTime(saleGroupCampaignList)));
                saleGroupInfo.setEndDate(BrandDateUtil.getDateMidnight(BizCampaignGroupToolsHelper.getCampaignMaxTime(saleGroupCampaignList)));
            }
        });

        return null;
    }
}
