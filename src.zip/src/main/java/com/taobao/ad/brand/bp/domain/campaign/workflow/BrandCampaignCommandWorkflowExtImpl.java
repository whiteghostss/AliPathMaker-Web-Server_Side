package com.taobao.ad.brand.bp.domain.campaign.workflow;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdScenarioViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignShowmaxCrowdViewDTO;
import com.alibaba.ad.brand.dto.campaign.dooh.CampaignDoohViewDTO;
import com.alibaba.ad.brand.dto.campaign.sale.CampaignSaleViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.salegroup.CampaignGroupSaleGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignProductConfigTypeEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.setting.BrandCampaignSettingKeyEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.alibaba.hermes.framework.event.SimpleEventEngine;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.context.CampaignUpdateCastDateContext;
import com.taobao.ad.brand.bp.client.context.DomainMetaqMessageBodyContext;
import com.taobao.ad.brand.bp.client.context.SaleGroupResetCalculateUpdateContext;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignBatchDeleteViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.CrowdViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohStrategyViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignEventEnum;
import com.taobao.ad.brand.bp.client.enums.message.DomainMessageTypeEnum;
import com.taobao.ad.brand.bp.client.enums.resourcepackage.SaleGroupEventEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPCustomErrorCode;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.dmp.CrowdRepository;
import com.taobao.ad.brand.bp.domain.dooh.repository.DoohRepository;
import com.taobao.ad.brand.bp.domain.event.campaign.CampaignUpdateCastDateNoticeEvent;
import com.taobao.ad.brand.bp.domain.event.salegroup.SaleGroupResetCalculateUpdateEvent;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.workflow.router.BrandExtensionRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignBudgetWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignCalculateWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.calculate.ISaleGroupPvAssignForCalculateAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.ResourcePackageSaleGroupCalculateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.IMessageAsyncSendAbility;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.IMessageSyncSendAbility;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.param.MessageAsyncSendAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.param.MessageSyncSendAbilityParam;
import com.taobao.ad.brand.bp.domain.ssp.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Description:
 * <p>
 * date: 2023/10/24 2:51 PM
 *
 * @author shiyan
 * @version 1.0
 */
@Service
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandCampaignCommandWorkflowExtImpl extends DefaultCampaignCommandWorkflowExtImpl implements BrandExtensionRouter {

    private final ProductRepository productRepository;
    private final CampaignRepository campaignRepository;
    private final CampaignGroupRepository campaignGroupRepository;
    private final ResourcePackageRepository resourcePackageRepository;
    private final CrowdRepository crowdRepository;

    private final ICampaignShowmaxCrowdTagGetAbility campaignShowmaxCrowdTagGetAbility;

    private final DoohRepository doohRepository;
    private final IMessageSyncSendAbility messageSyncSendAbility;
    private final IMessageAsyncSendAbility messageAsyncSendAbility;

    private final ICampaignAddPermissionJudgeAbility campaignAddPermissionJudgeAbility;
    private final ICampaignBaseValidateForAddCampaignAbility campaignBaseValidateForAddCampaignAbility;
    private final ICampaignTitleValidateAbility campaignTitleValidateAbility;
    private final ICampaignSaleValidateForAddCampaignAbility campaignSaleValidateForAddCampaignAbility;
    private final ICampaignAdzoneValidateForAddCampaignAbility campaignAdzoneValidateForAddCampaignAbility;
    private final ICampaignGuaranteeValidateForAddCampaignAbility campaignGuaranteeValidateForAddCampaignAbility;
    private final ICampaignBoostValidateForAddCampaignAbility campaignBoostValidateForAddCampaignAbility;
    private final ICampaignBudgetValidateForAddCampaignAbility campaignBudgetValidateForAddCampaignAbility;
    private final ICampaignSmartReservedValidateForAddCampaignAbility campaignSmartReservedValidateForAddCampaignAbility;
    private final ICampaignDoohValidateForAddCampaignAbility campaignDoohValidateForAddCampaignAbility;
    private final ICampaignDoohValidateAbility campaignDoohValidateAbility;
    private final ICampaignUnionControlFlowInitForAddCampaignAbility campaignUnionControlFlowInitForAddCampaignAbility;
    private final ICampaignDoohPushForAddCampaignAbility campaignDoohPushForAddCampaignAbility;
    private final ICampaignRightsValidateForAddOrUpdateCampaignAbility campaignRightsValidateForAddOrUpdateCampaignAbility;

    private final ICampaignStatusValidateForUpdateCampaignAbility campaignStatusValidateForUpdateCampaignAbility;
    private final ICampaignUpdateJudgeForUpdateCampaignAbility campaignUpdateJudgeForUpdateCampaignAbility;
    private final ICampaignItemIdValidateForUpdateCampaignAbility campaignItemIdValidateForUpdateCampaignAbility;

    private final ICampaignBaseInitForAddCampaignAbility campaignBaseInitForAddCampaignAbility;
    private final ICampaignResourceInitForAddCampaignAbility campaignResourceInitForAddCampaignAbility;
    private final ICampaignCreativeControllerInitForAddCampaignAbility campaignCreativeControllerInitForAddCampaignAbility;
    private final ICampaignSaleInitForAddCampaignAbility campaignSaleInitForAddCampaignAbility;
    private final ICampaignGuaranteeInitForAddCampaignAbility campaignGuaranteeInitForAddCampaignAbility;
    private final ICampaignInquiryLockInitForAddCampaignAbility campaignInquiryLockInitForAddCampaignAbility;
    private final ICampaignSmoothInitForAddCampaignAbility campaignSmoothInitForAddCampaignAbility;
    private final ICampaignSmartReservedInitForAddCampaignAbility campaignSmartReservedInitForAddCampaignAbility;
    private final ICampaignPriceInitForAddCampaignAbility campaignPriceInitForAddCampaignAbility;
    private final ICampaignScrollInitForAddCampaignAbility campaignScrollInitForAddCampaignAbility;
    private final ICampaignAdzoneInitForAddCampaignAbility campaignAdzoneInitForAddCampaignAbility;
    private final ICampaignMonitorInitForAddCampaignAbility campaignMonitorInitForAddCampaignAbility;
    private final ICampaignTitleInitAbility campaignTitleInitAbility;


    private final ICampaignStatusDeleteValidateAbility campaignStatusDeleteValidateAbility;
    private final ICampaignInquiryLockDeleteValidateAbility campaignInquiryLockDeleteValidateAbility;
    private final ICampaignBoostCampaignDeleteValidateAbility campaignBoostCampaignDeleteValidateAbility;
    private final ICampaignSmartReservedDeleteValidateAbility campaignSmartReservedDeleteValidateAbility;
    private final ICampaignStructureQueryAbility campaignStructureQueryAbility;
    private final ISaleGroupPvAssignForCalculateAbility saleGroupPvAssignForCalculateAbility;

    private final ICampaignBaseInitForUpdateCampaignAbility campaignBaseInitForUpdateCampaignAbility;
    private final ICampaignSaleInitForUpdateCampaignAbility campaignSaleInitForUpdateCampaignAbility;
    private final ICampaignResourceInitForUpdateCampaignAbility campaignResourceInitForUpdateCampaignAbility;
    private final ICampaignCreativeControllerInitForUpdateCampaignAbility campaignCreativeControllerInitForUpdateCampaignAbility;
    private final ICampaignPriceInitForUpdateCampaignAbility campaignPriceInitForUpdateCampaignAbility;
    private final ICampaignBudgetInitForUpdateCampaignAbility campaignBudgetInitForUpdateCampaignAbility;
    private final ICampaignSmoothInitForUpdateCampaignAbility campaignSmoothInitForUpdateCampaignAbility;
    private final ICampaignBoostInitForUpdateCampaignAbility campaignBoostInitForUpdateCampaignAbility;
    private final ICampaignGuaranteeInitForUpdateCampaignAbility campaignGuaranteeInitForUpdateCampaignAbility;
    private final ICampaignScrollInitForUpdateCampaignAbility campaignScrollInitForUpdateCampaignAbility;
    private final ICampaignSmartReservedInitForUpdateCampaignAbility campaignSmartReservedInitForUpdateCampaignAbility;
    private final ICampaignDoohInitForUpdateCampaignAbility campaignDoohInitForUpdateCampaignAbility;
    private final ICampaignAdzoneInitForUpdateCampaignAbility campaignAdzoneInitForUpdateCampaignAbility;
    private final ICampaignMonitorInitForUpdateCampaignAbility campaignMonitorInitForUpdateCampaignAbility;
    private final ICampaignInquiryLockInitForUpdateCampaignAbility campaignInquiryLockInitForUpdateCampaignAbility;
    private final ICampaignUpdatePartAbility campaignUpdatePartAbility;
    private final ICampaignExtInitForUpdateCampaignAbility campaignExtInitForUpdateCampaignAbility;
    private final ICampaignAutoSaveAsyncNoticeJudgeForAutoSaveCampaignAbility campaignAutoSaveAsyncNoticeJudgeForAutoSaveCampaignAbility;

    private final SimpleEventEngine simpleEventEngine;

    @Override
    public BizCampaignWorkflowParam buildParamForAddOrUpdate(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {
        AssertUtil.notNull(campaignViewDTO,"计划不允许为空");
        Long campaignGroupId = campaignViewDTO.getCampaignGroupId();
        AssertUtil.notNull(campaignGroupId, "订单ID不允许为空");
        Long packageSaleGroupId = Optional.ofNullable(campaignViewDTO.getCampaignSaleViewDTO()).map(CampaignSaleViewDTO::getSaleGroupId).orElse(null);
        AssertUtil.notNull(packageSaleGroupId,"售卖分组ID不允许为空");
        Long packageProductId = Optional.ofNullable(campaignViewDTO.getCampaignSaleViewDTO()).map(CampaignSaleViewDTO::getResourcePackageProductId).orElse(null);
        AssertUtil.notNull(packageProductId, "售卖分组资源位ID不存在");

        ResourcePackageQueryOption packageQueryOption = ResourcePackageQueryOption.builder().needProduct(true).needSetting(true).build();
        ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO = resourcePackageRepository.getSaleGroupById(serviceContext, packageSaleGroupId, packageQueryOption);
        AssertUtil.notNull(packageSaleGroupViewDTO,"资源包售卖分组不存在");

        ResourcePackageProductViewDTO packageProductViewDTO = packageSaleGroupViewDTO.getDistributionRuleList().stream().flatMap(e -> e.getResourcePackageProductList().stream())
                .filter(e -> e.getId().equals(packageProductId)).findFirst().orElse(null);
        AssertUtil.notNull(packageProductViewDTO, "售卖分组资源位不存在");

        AssertUtil.notNull(packageProductViewDTO.getSspProductId(),"二级产品ID不允许为空");
        ProductViewDTO productViewDTO = productRepository.getProductById(packageProductViewDTO.getSspProductId());
        AssertUtil.notNull(productViewDTO, "二级产品不存在");

        List<CommonViewDTO> showmaxCrowdList = Lists.newArrayList();
        if (BizCampaignToolsHelper.isShowmaxCampaign(productViewDTO.getMediaScope(), productViewDTO.getProductLineId(), productViewDTO.getCrossScene())) {
            Integer showmaxCrowdType = Optional.ofNullable(campaignViewDTO.getCampaignCrowdScenarioViewDTO())
                    .map(CampaignCrowdScenarioViewDTO::getCampaignShowmaxCrowdViewDTO).map(CampaignShowmaxCrowdViewDTO::getShowmaxCrowdType).orElse(null);
            AssertUtil.notNull(showmaxCrowdType, "showmax计划未选类型");
            showmaxCrowdList = campaignShowmaxCrowdTagGetAbility.handle(serviceContext, CampaignShowmaxCrowdTagGetAbilityParam.builder()
                    .abilityTarget(showmaxCrowdType).campaignGroupId(campaignGroupId).build());
        }
        Map<Long, CrowdViewDTO> dmpCrowdMap = Maps.newHashMap();

        List<CampaignCrowdViewDTO> campaignCrowdViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignCrowdScenarioViewDTO())
                .map(CampaignCrowdScenarioViewDTO::getCampaignCrowdViewDTOList).orElse(Lists.newArrayList());
        if (CollectionUtils.isNotEmpty(campaignCrowdViewDTOList)) {
            List<Long> crowdIds = campaignCrowdViewDTOList.stream().map(CampaignCrowdViewDTO::getCrowdId).collect(Collectors.toList());
            dmpCrowdMap = crowdRepository.queryCrowdByIds(serviceContext, crowdIds).stream().collect(Collectors.toMap(CrowdViewDTO::getCrowdId, Function.identity()));
        }

        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(serviceContext, campaignGroupId);
        AssertUtil.notNull(campaignGroupViewDTO, "订单不存在");

        SaleGroupInfoViewDTO saleGroupInfoViewDTO = Optional.ofNullable(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO()).map(CampaignGroupSaleGroupViewDTO::getSaleGroupInfoViewDTOList).orElse(Lists.newArrayList())
                .stream().filter(saleGroupInfo -> Objects.equals(packageSaleGroupId,saleGroupInfo.getSaleGroupId())).findFirst().orElse(null);
        AssertUtil.notNull(saleGroupInfoViewDTO, "订单售卖分组不存在");

        //天攻需要查询策略信息
        DoohStrategyViewDTO strategyViewDTO = null;
        Long doohStrategyId = Optional.ofNullable(campaignViewDTO.getCampaignDoohViewDTO()).map(CampaignDoohViewDTO::getDoohStrategyId).orElse(null);
        if(Objects.nonNull(doohStrategyId)){
            strategyViewDTO = doohRepository.getStrategyById(campaignViewDTO.getCampaignDoohViewDTO().getDoohStrategyId());
            AssertUtil.notNull(strategyViewDTO, "策略不存在或已被删除");
        }

        BizCampaignWorkflowParam campaignWorkflowParam = new BizCampaignWorkflowParam();
        campaignWorkflowParam.setPackageSaleGroupViewDTO(packageSaleGroupViewDTO);
        campaignWorkflowParam.setPackageProductViewDTO(packageProductViewDTO);
        campaignWorkflowParam.setProductViewDTO(productViewDTO);
        campaignWorkflowParam.setCampaignGroupViewDTO(campaignGroupViewDTO);
        campaignWorkflowParam.setSaleGroupInfoViewDTO(saleGroupInfoViewDTO);
        campaignWorkflowParam.setShowmaxCrowdList(showmaxCrowdList);
        campaignWorkflowParam.setCrowdViewDTOMap(dmpCrowdMap);
        campaignWorkflowParam.setDoohStrategyViewDTO(strategyViewDTO);

        return campaignWorkflowParam;
    }

    @Override
    public Void beforeForAdd(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, BizCampaignWorkflowParam workflowParam) {
        resetCampaignDefaultObject(campaignViewDTO);
        this.validateForAdd(serviceContext, campaignViewDTO, workflowParam);
        this.initForAdd(serviceContext, campaignViewDTO, workflowParam);
        return null;
    }

    @Override
    public Void beforeForUpdate(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO,CampaignViewDTO dbCampaignViewDTO, BizCampaignWorkflowParam workflowParam) {
        resetCampaignDefaultObject(campaignViewDTO);
        if(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode().equals(dbCampaignViewDTO.getCampaignLevel())){
            this.validateForAdd(serviceContext, campaignViewDTO, workflowParam);
            this.validateForUpdate(serviceContext, campaignViewDTO,dbCampaignViewDTO, workflowParam);
        }
        this.initForUpdate(serviceContext, campaignViewDTO, dbCampaignViewDTO, workflowParam);
        return null;
    }

    private void validateForUpdate(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, CampaignViewDTO dbCampaignViewDTO, BizCampaignWorkflowParam workflowParam) {
        //状态校验
        campaignStatusValidateForUpdateCampaignAbility.handle(serviceContext, CampaignStatusValidateForUpdateCampaignAbilityParam.builder().abilityTarget(campaignViewDTO)
                .dbCampaignViewDTO(dbCampaignViewDTO).build());
        //是否允许修改
        Boolean canUpdateJudge = campaignUpdateJudgeForUpdateCampaignAbility.handle(serviceContext, CampaignUpdateAbilityParam.builder().abilityTarget(campaignViewDTO)
                .dbCampaignViewDTO(dbCampaignViewDTO).build());
        if(!canUpdateJudge){
            campaignItemIdValidateForUpdateCampaignAbility.handle(serviceContext, CampaignUpdateAbilityParam.builder().abilityTarget(campaignViewDTO)
                    .dbCampaignViewDTO(dbCampaignViewDTO).build());
            campaignGuaranteeValidateForAddCampaignAbility.handle(serviceContext, CampaignGuaranteeAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignGuaranteeViewDTO())
                    .resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO())
                    .campaignViewDTO(campaignViewDTO).dbCampaignViewDTO(dbCampaignViewDTO).build());
            campaignSmartReservedValidateForAddCampaignAbility.handle(serviceContext, CampaignSmartReservedAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignSmartReservedViewDTO())
                            .productViewDTO(workflowParam.getProductViewDTO()).resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO())
                            .resourcePackageSaleGroupViewDTO(workflowParam.getPackageSaleGroupViewDTO())
                    .campaignViewDTO(campaignViewDTO).dbCampaignViewDTO(dbCampaignViewDTO).build());
        }
        campaignDoohValidateAbility.handle(serviceContext, CampaignDoohAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignDoohViewDTO())
                .campaignViewDTO(campaignViewDTO).productViewDTO(workflowParam.getProductViewDTO()).resourcePackageSaleGroupViewDTO(workflowParam.getPackageSaleGroupViewDTO()).build());
        // 竞争品牌
        campaignRightsValidateForAddOrUpdateCampaignAbility.handle(serviceContext, CampaignRightsAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignRightsViewDTO())
                .campaignViewDTO(campaignViewDTO).dbCampaignViewDTO(dbCampaignViewDTO).productViewDTO(workflowParam.getProductViewDTO()).build());
    }

    private void validateForAdd(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, BizCampaignWorkflowParam workflowParam) {

        campaignBaseValidateForAddCampaignAbility.handle(serviceContext, CampaignBaseAbilityParam.builder().abilityTarget(campaignViewDTO)
                .resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        campaignTitleValidateAbility.handle(serviceContext, CampaignTitleValidateAbilityParam.builder().abilityTarget(campaignViewDTO).build());

        campaignSaleValidateForAddCampaignAbility.handle(serviceContext, CampaignSaleAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignSaleViewDTO())
                .productViewDTO(workflowParam.getProductViewDTO()).resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        campaignAdzoneValidateForAddCampaignAbility.handle(serviceContext, CampaignAdzoneAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignTargetScenarioViewDTO())
                .productViewDTO(workflowParam.getProductViewDTO()).resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        campaignGuaranteeValidateForAddCampaignAbility.handle(serviceContext, CampaignGuaranteeAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignGuaranteeViewDTO())
                .resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        campaignBoostValidateForAddCampaignAbility.handle(serviceContext, CampaignBoostAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignBoostViewDTO())
                .campaignViewDTO(campaignViewDTO).resourcePackageSaleGroupViewDTO(workflowParam.getPackageSaleGroupViewDTO())
                .productViewDTO(workflowParam.getProductViewDTO()).resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        campaignBudgetValidateForAddCampaignAbility.handle(serviceContext, CampaignBudgetAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignBudgetViewDTO())
                .campaignViewDTO(campaignViewDTO).build());

        campaignSmartReservedValidateForAddCampaignAbility.handle(serviceContext, CampaignSmartReservedAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignSmartReservedViewDTO())
                .campaignViewDTO(campaignViewDTO).resourcePackageSaleGroupViewDTO(workflowParam.getPackageSaleGroupViewDTO())
                .productViewDTO(workflowParam.getProductViewDTO()).resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        campaignDoohValidateForAddCampaignAbility.handle(serviceContext, CampaignDoohAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignDoohViewDTO())
                .campaignViewDTO(campaignViewDTO).resourcePackageSaleGroupViewDTO(workflowParam.getPackageSaleGroupViewDTO())
                .productViewDTO(workflowParam.getProductViewDTO()).doohStrategyViewDTO(workflowParam.getDoohStrategyViewDTO()).build());
        // 竞争品牌
        campaignRightsValidateForAddOrUpdateCampaignAbility.handle(serviceContext, CampaignRightsAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignRightsViewDTO())
                .campaignViewDTO(campaignViewDTO).productViewDTO(workflowParam.getProductViewDTO()).build());
    }

    private void initForAdd(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, BizCampaignWorkflowParam workflowParam){

        campaignBaseInitForAddCampaignAbility.handle(serviceContext,CampaignBaseAbilityParam.builder().abilityTarget(campaignViewDTO)
                .campaignGroupViewDTO(workflowParam.getCampaignGroupViewDTO())
                .productViewDTO(workflowParam.getProductViewDTO()).resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        String campaignTitle = campaignTitleInitAbility.handle(serviceContext, CampaignTitleInitAbilityParam.builder().abilityTarget(campaignViewDTO)
                .productViewDTO(workflowParam.getProductViewDTO()).showmaxCrowdList(workflowParam.getShowmaxCrowdList()).build());
        campaignViewDTO.setTitle(campaignTitle);

        campaignResourceInitForAddCampaignAbility.handle(serviceContext,CampaignResourceAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignResourceViewDTO())
                .productViewDTO(workflowParam.getProductViewDTO()).build());

        campaignCreativeControllerInitForAddCampaignAbility.handle(serviceContext,CampaignCreativeControllerAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignCreativeControllerViewDTO())
                .productViewDTO(workflowParam.getProductViewDTO()).resourcePackageSaleGroupViewDTO(workflowParam.getPackageSaleGroupViewDTO()).build());

        campaignSaleInitForAddCampaignAbility.handle(serviceContext,CampaignSaleAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignSaleViewDTO())
                .campaignGroupViewDTO(workflowParam.getCampaignGroupViewDTO())
                .resourcePackageSaleGroupViewDTO(workflowParam.getPackageSaleGroupViewDTO()).saleGroupInfoViewDTO(workflowParam.getSaleGroupInfoViewDTO())
                .productViewDTO(workflowParam.getProductViewDTO()).resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        campaignGuaranteeInitForAddCampaignAbility.handle(serviceContext,CampaignGuaranteeAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignGuaranteeViewDTO())
                .campaignViewDTO(campaignViewDTO).productViewDTO(workflowParam.getProductViewDTO()).resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        campaignInquiryLockInitForAddCampaignAbility.handle(serviceContext,CampaignInquiryLockAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignInquiryLockViewDTO())
                .campaignGroupViewDTO(workflowParam.getCampaignGroupViewDTO()).campaignViewDTO(campaignViewDTO)
                .productViewDTO(workflowParam.getProductViewDTO()).resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        campaignSmoothInitForAddCampaignAbility.handle(serviceContext,CampaignSmoothAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignSmoothViewDTO())
                .productViewDTO(workflowParam.getProductViewDTO()).build());

        campaignSmartReservedInitForAddCampaignAbility.handle(serviceContext,CampaignSmartReservedAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignSmartReservedViewDTO())
                .campaignViewDTO(campaignViewDTO).resourcePackageSaleGroupViewDTO(workflowParam.getPackageSaleGroupViewDTO())
                .productViewDTO(workflowParam.getProductViewDTO()).resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        campaignPriceInitForAddCampaignAbility.handle(serviceContext,CampaignPriceAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignPriceViewDTO())
                .campaignViewDTO(campaignViewDTO).productViewDTO(workflowParam.getProductViewDTO()).resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        campaignScrollInitForAddCampaignAbility.handle(serviceContext,CampaignScrollAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignScrollViewDTO())
                .campaignViewDTO(campaignViewDTO).build());

        campaignAdzoneInitForAddCampaignAbility.handle(serviceContext,CampaignAdzoneAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignTargetScenarioViewDTO())
                .productViewDTO(workflowParam.getProductViewDTO()).resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        campaignMonitorInitForAddCampaignAbility.handle(serviceContext,CampaignMonitorAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignMonitorViewDTO())
                .resourcePackageSaleGroupViewDTO(workflowParam.getPackageSaleGroupViewDTO()).build());
    }

    private void initForUpdate(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, CampaignViewDTO dbCampaignViewDTO, BizCampaignWorkflowParam workflowParam){

        campaignBaseInitForUpdateCampaignAbility.handle(serviceContext,CampaignBaseAbilityParam.builder().abilityTarget(campaignViewDTO)
                .dbCampaignViewDTO(dbCampaignViewDTO).build());

        String campaignTitle = campaignTitleInitAbility.handle(serviceContext, CampaignTitleInitAbilityParam.builder().abilityTarget(campaignViewDTO)
                .dbCampaignViewDTO(dbCampaignViewDTO).productViewDTO(workflowParam.getProductViewDTO()).showmaxCrowdList(workflowParam.getShowmaxCrowdList()).build());
        campaignViewDTO.setTitle(campaignTitle);

        campaignSaleInitForUpdateCampaignAbility.handle(serviceContext,CampaignSaleAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignSaleViewDTO())
                .dbCampaignViewDTO(dbCampaignViewDTO).build());

        campaignResourceInitForUpdateCampaignAbility.handle(serviceContext,CampaignResourceAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignResourceViewDTO())
                .dbCampaignViewDTO(dbCampaignViewDTO).build());

        campaignCreativeControllerInitForUpdateCampaignAbility.handle(serviceContext,CampaignCreativeControllerAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignCreativeControllerViewDTO())
                .dbCampaignViewDTO(dbCampaignViewDTO).build());

        campaignPriceInitForUpdateCampaignAbility.handle(serviceContext,CampaignPriceAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignPriceViewDTO())
                .campaignViewDTO(campaignViewDTO).dbCampaignViewDTO(dbCampaignViewDTO).build());

        campaignBudgetInitForUpdateCampaignAbility.handle(serviceContext,CampaignBudgetAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignBudgetViewDTO())
                .campaignViewDTO(campaignViewDTO).dbCampaignViewDTO(dbCampaignViewDTO).resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());

        campaignSmoothInitForUpdateCampaignAbility.handle(serviceContext,CampaignSmoothAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignSmoothViewDTO())
                .campaignViewDTO(campaignViewDTO).dbCampaignViewDTO(dbCampaignViewDTO).build());

        campaignBoostInitForUpdateCampaignAbility.handle(serviceContext,CampaignBoostAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignBoostViewDTO())
                .campaignViewDTO(campaignViewDTO).dbCampaignViewDTO(dbCampaignViewDTO).build());

        campaignGuaranteeInitForUpdateCampaignAbility.handle(serviceContext,CampaignGuaranteeAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignGuaranteeViewDTO())
                .campaignViewDTO(campaignViewDTO).dbCampaignViewDTO(dbCampaignViewDTO).productViewDTO(workflowParam.getProductViewDTO()).build());

        campaignScrollInitForUpdateCampaignAbility.handle(serviceContext,CampaignScrollAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignScrollViewDTO())
                .campaignViewDTO(campaignViewDTO).dbCampaignViewDTO(dbCampaignViewDTO).build());

        campaignSmartReservedInitForUpdateCampaignAbility.handle(serviceContext,CampaignSmartReservedAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignSmartReservedViewDTO())
                .campaignViewDTO(campaignViewDTO).dbCampaignViewDTO(dbCampaignViewDTO).build());

        campaignDoohInitForUpdateCampaignAbility.handle(serviceContext,CampaignDoohAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignDoohViewDTO())
                .dbCampaignViewDTO(dbCampaignViewDTO).build());

        campaignAdzoneInitForUpdateCampaignAbility.handle(serviceContext,CampaignAdzoneAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignTargetScenarioViewDTO())
                .dbCampaignViewDTO(dbCampaignViewDTO).build());

        campaignInquiryLockInitForUpdateCampaignAbility.handle(serviceContext,CampaignInquiryLockAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignInquiryLockViewDTO())
                .campaignViewDTO(campaignViewDTO).dbCampaignViewDTO(dbCampaignViewDTO).build());

        campaignMonitorInitForUpdateCampaignAbility.handle(serviceContext, CampaignMonitorAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignMonitorViewDTO())
                .dbCampaignViewDTO(dbCampaignViewDTO).build());

        campaignExtInitForUpdateCampaignAbility.handle(serviceContext, CampaignExtAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignExtViewDTO())
                .dbCampaignViewDTO(dbCampaignViewDTO).build());
    }

    @Override
    public Void afterAddCampaign(ServiceContext serviceContext, CampaignViewDTO campaignTreeViewDTO, BizCampaignWorkflowParam bizCampaignWorkflowParam) {
        //天攻计划推送
        campaignDoohPushForAddCampaignAbility.handle(serviceContext,CampaignDoohPushAbilityParam.builder().abilityTarget(campaignTreeViewDTO).build());
        //主补联合控量初始化
        campaignUnionControlFlowInitForAddCampaignAbility.handle(serviceContext,
                CampaignUnionControlFlowAbilityParam.builder().abilityTarget(campaignTreeViewDTO).build());
        //更新计划
        List<CampaignViewDTO> updatePartCampaignList = BizCampaignToolsHelper.flatCampaignList(campaignTreeViewDTO).stream().map(campaignViewDTO -> {
            CampaignViewDTO newCampaignViewDTO = new CampaignViewDTO();
            newCampaignViewDTO.setId(campaignViewDTO.getId());
            newCampaignViewDTO.setCampaignGuaranteeViewDTO(campaignViewDTO.getCampaignGuaranteeViewDTO());
            newCampaignViewDTO.setCampaignBoostViewDTO(campaignViewDTO.getCampaignBoostViewDTO());
            newCampaignViewDTO.setCampaignSmartReservedViewDTO(campaignViewDTO.getCampaignSmartReservedViewDTO());
            newCampaignViewDTO.setCampaignDoohViewDTO(campaignViewDTO.getCampaignDoohViewDTO());
            return newCampaignViewDTO;
        }).collect(Collectors.toList());
        campaignUpdatePartAbility.handle(serviceContext,CampaignBatchAbilityParam.builder().abilityTargets(updatePartCampaignList).build());

        //MQ消息发送
         DomainMetaqMessageBodyContext msgBodyContext = DomainMetaqMessageBodyContext.builder()
                .bizCode(serviceContext.getBizCode())
                .domainType(DomainMessageTypeEnum.MAIN_CAMPAIGN)
                .domainEvent(CampaignEventEnum.CREATE.name())
                .entityId(campaignTreeViewDTO.getId())
                .memberId(serviceContext.getMemberId())
                .build();
        messageAsyncSendAbility.handle(serviceContext, MessageAsyncSendAbilityParam.builder().abilityTarget(msgBodyContext).build());
        return null;
    }

    @Override
    public Void afterAutoAddCampaign(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, List<Long> campaignIds) {
        Boolean autoSaveAsyncNoticeJudge = campaignAutoSaveAsyncNoticeJudgeForAutoSaveCampaignAbility.handle(serviceContext, CampaignAutoSaveAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
        if (autoSaveAsyncNoticeJudge) {
            Map<String, String> properties = Maps.newHashMap();
            properties.put(BrandCampaignSettingKeyEnum.CAMPAIGN_GROUP_ID.getKey(), String.valueOf(campaignGroupViewDTO.getId()));
            for (SaleGroupInfoViewDTO saleGroupInfoViewDTO : campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList()) {
                DomainMetaqMessageBodyContext msgBodyContext = DomainMetaqMessageBodyContext.builder()
                        .bizCode(serviceContext.getBizCode())
                        .domainType(DomainMessageTypeEnum.SALE_GROUP)
                        .domainEvent(SaleGroupEventEnum.AUTO_CREATE_CAMPAIGN.name())
                        .entityId(saleGroupInfoViewDTO.getSaleGroupId())
                        .memberId(serviceContext.getMemberId())
                        .properties(properties)
                        .build();
                messageAsyncSendAbility.handle(serviceContext, MessageAsyncSendAbilityParam.builder().abilityTarget(msgBodyContext).build());
            }
        }
        return null;
    }

    @Override
    public Void afterUpdateCampaign(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, CampaignViewDTO dbCampaignViewDTO, BizCampaignWorkflowParam bizCampaignWorkflowParam) {
        //天攻的计划需要同步天攻更新计划
        if(BizCampaignToolsHelper.isDoohCampaign(campaignViewDTO.getCampaignResourceViewDTO().getSspProductLineId()) && (BrandDateUtil.isBefore(BrandDateUtil.getCurrentDate(), campaignViewDTO.getStartTime()) || campaignViewDTO.getCampaignInquiryLockViewDTO().getFirstOnlineTime() == null )){
            List<CampaignViewDTO> subCampaignViewDTOList = campaignViewDTO.getSubCampaignViewDTOList();
            doohRepository.updateCampaign(serviceContext, subCampaignViewDTOList);
        }

        DomainMetaqMessageBodyContext msgBodyContext = DomainMetaqMessageBodyContext.builder()
                .bizCode(serviceContext.getBizCode())
                .domainType(DomainMessageTypeEnum.MAIN_CAMPAIGN)
                .domainEvent(CampaignEventEnum.UPDATE.name())
                .entityId(campaignViewDTO.getId())
                .memberId(serviceContext.getMemberId())
                .build();
        messageAsyncSendAbility.handle(serviceContext, MessageAsyncSendAbilityParam.builder().abilityTarget(msgBodyContext).build());

        return null;
    }

    @Override
    public Void throwingAddCampaign(ServiceContext serviceContext, List<Long> campaignIdList) {
        if(CollectionUtils.isNotEmpty(campaignIdList)){
            List<CampaignViewDTO> deleteCampaignList = campaignIdList.stream().map(id -> {
                CampaignViewDTO campaignViewDTO = new CampaignViewDTO();
                campaignViewDTO.setId(id);
                campaignViewDTO.setStatus(BrandCampaignStatusEnum.DELETE.getCode());
                return campaignViewDTO;
            }).collect(Collectors.toList());
            campaignUpdatePartAbility.handle(serviceContext,CampaignBatchAbilityParam.builder().abilityTargets(deleteCampaignList).build());
        }
        return null;
    }

    @Override
    public Void beforeForDelete(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {
//        campaignPermissionDeleteValidateAbility.handle(serviceContext,
//                CampaignDeleteValidateAbilityParam.builder().abilityTarget(campaignViewDTO).build());
        campaignStatusDeleteValidateAbility.handle(serviceContext,
                CampaignDeleteValidateAbilityParam.builder().abilityTarget(campaignViewDTO).build());
        campaignInquiryLockDeleteValidateAbility.handle(serviceContext,
                CampaignDeleteValidateAbilityParam.builder().abilityTarget(campaignViewDTO).build());
        campaignSmartReservedDeleteValidateAbility.handle(serviceContext,
                CampaignDeleteValidateAbilityParam.builder().abilityTarget(campaignViewDTO).build());

        List<CampaignViewDTO> boostCampaignViewDTOList = campaignRepository.queryCampaignList(serviceContext,
                CampaignQueryViewDTO.builder().sourceCampaignIds(Lists.newArrayList(campaignViewDTO.getId())).build());
        campaignBoostCampaignDeleteValidateAbility.handle(serviceContext, CampaignBoostDeleteValidateAbilityParam.builder()
                .abilityTarget(campaignViewDTO).boostCampaignViewDTOList(boostCampaignViewDTOList).build());

        campaignDoohValidateAbility.handle(serviceContext, buildCampaignDoohAbilityParam(serviceContext,campaignViewDTO));

        return null;
    }

    @Override
    public Void beforeBatchDeleteCampaign(ServiceContext serviceContext, CampaignBatchDeleteViewDTO batchDeleteViewDTO) {
//        campaignPermissionBatchDeleteValidateAbility.handle(serviceContext, CampaignDeleteValidateAbilityParam.builder().build());

        // 批量根据主计划ID查询，构建主计划map，用来判断是否有未删除的补量计划
        CampaignStructureQueryAbilityParam queryAbilityParam = CampaignStructureQueryAbilityParam.builder().abilityTarget(CampaignQueryViewDTO.builder().sourceCampaignIds(batchDeleteViewDTO.getCampaignIds()).build())
                .queryOption(CampaignQueryOption.builder().build()).build();
        List<CampaignViewDTO> subCampaignList = campaignStructureQueryAbility.handle(serviceContext,queryAbilityParam);
        Map<Long, List<CampaignViewDTO>> sourceCampaignMap = subCampaignList.stream().filter(e -> !e.getId().equals(e.getCampaignBoostViewDTO().getSourceCampaignId()))
                .filter(e -> BrandSaleTypeEnum.BOOST.getCode().equals(e.getCampaignSaleViewDTO().getSaleType()))
                .collect(Collectors.groupingBy(e -> e.getCampaignBoostViewDTO().getSourceCampaignId()));

        List<CampaignViewDTO> illegalCampaignViewDTOList = Lists.newArrayList();
        StringBuilder errorMessageBuilder = new StringBuilder();
        // 遍历校验
        for(CampaignViewDTO campaignViewDTO : batchDeleteViewDTO.getDeleteCampaignViewDTOList()) {
            try {
//                campaignPermissionDeleteValidateAbility.handle(serviceContext,
//                        CampaignDeleteValidateAbilityParam.builder().abilityTarget(campaignViewDTO).build());
                campaignStatusDeleteValidateAbility.handle(serviceContext,
                        CampaignDeleteValidateAbilityParam.builder().abilityTarget(campaignViewDTO).build());
                campaignInquiryLockDeleteValidateAbility.handle(serviceContext,
                        CampaignDeleteValidateAbilityParam.builder().abilityTarget(campaignViewDTO).build());
                campaignSmartReservedDeleteValidateAbility.handle(serviceContext,
                        CampaignDeleteValidateAbilityParam.builder().abilityTarget(campaignViewDTO).build());
                campaignBoostCampaignDeleteValidateAbility.handle(serviceContext, CampaignBoostDeleteValidateAbilityParam.builder()
                        .abilityTarget(campaignViewDTO).boostCampaignViewDTOList(sourceCampaignMap.get(campaignViewDTO.getId())).build());
            } catch (BrandOneBPException e) {
                illegalCampaignViewDTOList.add(campaignViewDTO);
                errorMessageBuilder.append(campaignViewDTO.getId());
                errorMessageBuilder.append(": ");
                errorMessageBuilder.append(e.getMessage());
            }
        }
        // 全部计划不符合要求
        AssertUtil.assertTrue(illegalCampaignViewDTOList.size() != batchDeleteViewDTO.getDeleteCampaignViewDTOList().size(),
                BrandOneBPCustomErrorCode.BIZ_UN_SUPPORT_INQUIRY_ALL_ERROR_ERROR, errorMessageBuilder.toString());
        // 如果不是二次确认即第一次请求需要以errCode形式返回校验信息
        if (BrandBoolEnum.BRAND_FALSE.getCode().equals(batchDeleteViewDTO.getConfirm())) {
            // 全部计划符合要求
            AssertUtil.notEmpty(illegalCampaignViewDTOList, BrandOneBPCustomErrorCode.BIZ_UN_SUPPORT_INQUIRY_DEFAULT_ERROR_ERROR, "确认是否删除已勾选计划");
        }
        if(CollectionUtils.isNotEmpty(illegalCampaignViewDTOList)) {
            // 部分计划不符合要求
            throw new BrandOneBPException(BrandOneBPCustomErrorCode.BIZ_UN_SUPPORT_INQUIRY_PART_ERROR_ERROR, errorMessageBuilder.toString());
        }
        return null;
    }

    @Override
    public Void afterBatchDeleteCampaign(ServiceContext serviceContext, List<CampaignViewDTO> delCampaignViewDTOList) {
        //天攻的计划需要通知天攻解锁策略
        for(CampaignViewDTO campaignViewDTO:delCampaignViewDTOList){
            if(BizCampaignToolsHelper.isDoohCampaign(campaignViewDTO.getCampaignResourceViewDTO().getSspProductLineId())){
                doohRepository.deleteCampaign(campaignViewDTO.getCampaignDoohViewDTO().getDoohCampaignId());
            }
        }
        //如果是自定义分组的计划，会出现锁量超出分组总金额的情况，删除后需要刷新分组预定量和分组单价
        List<CampaignViewDTO> calOverCampaign = delCampaignViewDTOList.stream().filter(item -> BrandCampaignProductConfigTypeEnum.CUSTOM.getCode().equals(item.getCampaignSaleViewDTO().getProductConfigType())&& Objects.nonNull(item.getCampaignGuaranteeViewDTO().getAmount())).collect(Collectors.toList());
        if(CollectionUtils.isEmpty(calOverCampaign)){
            return null;
        }
        Set<Long> saleGroupIds = calOverCampaign.stream().map(item->item.getCampaignSaleViewDTO().getSaleGroupId()).collect(Collectors.toSet());
        List<Long> campaignGroupIds = calOverCampaign.stream().map(CampaignViewDTO::getCampaignGroupId).collect(Collectors.toList());
        List<CampaignGroupViewDTO> campaignGroupViewDTO = campaignGroupRepository.findCampaignGroupByIds(serviceContext,campaignGroupIds);
        AssertUtil.notEmpty(campaignGroupViewDTO, "订单不存在");
        List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList = Lists.newArrayList();
        campaignGroupViewDTO.forEach(item->{
            item.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream()
                    .filter(saleGroup->saleGroupIds.contains(saleGroup.getSaleGroupId())).forEach(saleGroupInfoViewDTOList::add);
        });
        //通知更新分组金额
        SaleGroupResetCalculateUpdateContext inquiryContext = SaleGroupResetCalculateUpdateContext.builder()
                .serviceContext(serviceContext).saleGroupInfoViewDTOList(saleGroupInfoViewDTOList).build();
        messageSyncSendAbility.handle(serviceContext, MessageSyncSendAbilityParam.builder().abilityTarget(SaleGroupResetCalculateUpdateEvent.of(inquiryContext)).build());
        return null;
    }

    @Override
    public BizCampaignCalculateWorkflowParam buildParamForCalculate(ServiceContext serviceContext,
                                                                    CampaignViewDTO campaignViewDTO) {
        BizCampaignCalculateWorkflowParam bizCampaignCalculateWorkflowParam = new BizCampaignCalculateWorkflowParam();
        Long packageSaleGroupId = Optional.ofNullable(campaignViewDTO).map(CampaignViewDTO::getCampaignSaleViewDTO).map(CampaignSaleViewDTO::getSaleGroupId).orElse(null);
        AssertUtil.notNull(packageSaleGroupId,"售卖分组ID不允许为空");
        ResourcePackageQueryOption packageQueryOption = ResourcePackageQueryOption.builder().needProduct(true).needSetting(true).build();
        ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO = resourcePackageRepository.getSaleGroupById(serviceContext, packageSaleGroupId, packageQueryOption);
        AssertUtil.notNull(packageSaleGroupViewDTO,"资源包售卖分组不存在");

        Long packageProductId = campaignViewDTO.getCampaignSaleViewDTO().getResourcePackageProductId();
        AssertUtil.notNull(packageProductId, "售卖分组资源位ID不存在");
        AssertUtil.notNull(campaignViewDTO.getCampaignGroupId(),"二级产品ID不允许为空");

        ResourcePackageProductViewDTO packageProductViewDTO = packageSaleGroupViewDTO.getDistributionRuleList().stream().flatMap(e -> e.getResourcePackageProductList().stream())
            .filter(e -> e.getId().equals(packageProductId)).findFirst().orElse(null);
        AssertUtil.notNull(packageProductViewDTO, "售卖分组资源位不存在");

        bizCampaignCalculateWorkflowParam.setPackageSaleGroupViewDTO(packageSaleGroupViewDTO);
        bizCampaignCalculateWorkflowParam.setPackageProductViewDTO(packageProductViewDTO);

        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(serviceContext, campaignViewDTO.getCampaignGroupId());
        AssertUtil.notNull(campaignGroupViewDTO, "订单不存在");

        SaleGroupInfoViewDTO saleGroupInfoViewDTO = Optional.ofNullable(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO()).map(CampaignGroupSaleGroupViewDTO::getSaleGroupInfoViewDTOList).orElse(Lists.newArrayList())
                .stream().filter(saleGroupInfo -> Objects.equals(packageSaleGroupId,saleGroupInfo.getSaleGroupId())).findFirst().orElse(null);
        AssertUtil.notNull(saleGroupInfoViewDTO, "订单售卖分组不存在");

        bizCampaignCalculateWorkflowParam.setCampaignGroupViewDTO(campaignGroupViewDTO);
        bizCampaignCalculateWorkflowParam.setSaleGroupInfoViewDTO(saleGroupInfoViewDTO);

        CampaignQueryViewDTO campaignQueryViewDTO = new CampaignQueryViewDTO();
        campaignQueryViewDTO.setSaleGroupId(bizCampaignCalculateWorkflowParam.getSaleGroupInfoViewDTO().getSaleGroupId());
        List<CampaignViewDTO> campaignViewDTOList = campaignRepository.queryCampaignList(serviceContext, campaignQueryViewDTO);

        List<CampaignViewDTO> groupCampaignLevleOneViewDTOList = campaignViewDTOList.stream().filter(item->BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode().equals(item.getCampaignLevel())).collect(
            Collectors.toList());
        List<CampaignViewDTO> groupCampaignLevleTwoViewDTOList = campaignViewDTOList.stream().filter(item->BrandCampaignLevelEnum.LEVEL_TWO_CAMPAIGN.getCode().equals(item.getCampaignLevel())).collect(
            Collectors.toList());
        bizCampaignCalculateWorkflowParam.setGroupCampaignLevelOneViewDTOList(groupCampaignLevleOneViewDTOList);
        bizCampaignCalculateWorkflowParam.setGroupCampaignLevelTwoViewDTOList(groupCampaignLevleTwoViewDTOList);
        return bizCampaignCalculateWorkflowParam;
    }

    @Override
    public BizCampaignBudgetWorkflowParam buildParamForAssignBudget(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {
        AssertUtil.notNull(campaignViewDTO,"计划不允许为空");
        Long campaignGroupId = campaignViewDTO.getCampaignGroupId();
        Long packageSaleGroupId = Optional.ofNullable(campaignViewDTO.getCampaignSaleViewDTO()).map(CampaignSaleViewDTO::getSaleGroupId).orElse(null);
        AssertUtil.notNull(campaignGroupId,"订单ID不允许为空");
        AssertUtil.notNull(packageSaleGroupId,"售卖分组ID不允许为空");

        // 业务数据获取
        ResourcePackageQueryOption packageQueryOption = ResourcePackageQueryOption.builder().needProduct(true).needSetting(true).build();
        ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO = resourcePackageRepository.getSaleGroupById(serviceContext, packageSaleGroupId, packageQueryOption);
        AssertUtil.notNull(packageSaleGroupViewDTO,"资源包售卖分组不存在");

        SaleGroupInfoViewDTO saleGroupInfoViewDTO = campaignGroupRepository.getSaleGroup(serviceContext,campaignGroupId, packageSaleGroupId);
        AssertUtil.notNull(saleGroupInfoViewDTO, "订单售卖分组不存在");

        BizCampaignBudgetWorkflowParam budgetWorkflowParam = new BizCampaignBudgetWorkflowParam();
        budgetWorkflowParam.setPackageSaleGroupViewDTO(packageSaleGroupViewDTO);
        budgetWorkflowParam.setSaleGroupInfoViewDTO(saleGroupInfoViewDTO);

        return budgetWorkflowParam;
    }



    @Override
    public Void rebuildCalSaleGroupInfo(ServiceContext serviceContext, ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO,SaleGroupInfoViewDTO saleGroupInfoViewDTO,List<CampaignViewDTO> campaignViewDTOList) {
        //计算分组PV和单价
        Long pv = saleGroupPvAssignForCalculateAbility.handle(serviceContext, ResourcePackageSaleGroupCalculateAbilityParam.builder().abilityTarget(packageSaleGroupViewDTO).campaignTreeList(campaignViewDTOList).build());
        Long calcBudget = campaignViewDTOList.stream().mapToLong(item->item.getCampaignBudgetViewDTO().getDiscountTotalMoney()).sum();
        Long pvPrice = BigDecimal.valueOf(calcBudget).multiply(BigDecimal.valueOf(Constant.DEFAULT_CPM_PV_RATIO)).divide(BigDecimal.valueOf(pv), 0, RoundingMode.HALF_UP).longValue();
        saleGroupInfoViewDTO.setUnitPrice(pvPrice);
        saleGroupInfoViewDTO.setAmount(pv);
        saleGroupInfoViewDTO.setCalcBudget(calcBudget);
        return null;
    }

    @Override
    public Void afterForUpdateCastDate(ServiceContext serviceContext, CampaignViewDTO dbCampaignViewDTO,
                                       CampaignViewDTO campaignViewDTO) {
        // 同步事件
        CampaignUpdateCastDateContext updateCastDateContext = CampaignUpdateCastDateContext.builder()
                .serviceContext(serviceContext).campaignId(campaignViewDTO.getId()).build();
        simpleEventEngine.fire(CampaignUpdateCastDateNoticeEvent.of(updateCastDateContext));

        // 异步消息
        DomainMetaqMessageBodyContext msgBodyContext = DomainMetaqMessageBodyContext.builder()
            .bizCode(serviceContext.getBizCode())
            .domainType(DomainMessageTypeEnum.MAIN_CAMPAIGN)
            .domainEvent(CampaignEventEnum.UPDATE.name())
            .entityId(dbCampaignViewDTO.getId())
            .memberId(serviceContext.getMemberId())
            .build();
        messageAsyncSendAbility.handle(serviceContext, MessageAsyncSendAbilityParam.builder().abilityTarget(msgBodyContext).build());

        return null;
    }

    @Override
    public Void handleAfterCancelCampaignGroup(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, List<CampaignViewDTO> campaignTreeList) {
        //天攻计划需要通知天攻取消订单
        List<CampaignViewDTO> doohCampaignViewDTOList = campaignTreeList.stream().filter(e-> BizCampaignToolsHelper.isDoohCampaign(e.getCampaignResourceViewDTO().getSspProductLineId())).collect(Collectors.toList());
        if(CollectionUtils.isEmpty(doohCampaignViewDTOList)){
            return null;
        }
        for(CampaignViewDTO campaignViewDTO:doohCampaignViewDTOList){
            doohRepository.cancel(campaignViewDTO.getCampaignDoohViewDTO().getDoohCampaignId());
        }
        return null;
    }

    private CampaignDoohAbilityParam buildCampaignDoohAbilityParam(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO){
        if(campaignViewDTO != null && campaignViewDTO.getCampaignDoohViewDTO() != null){
            Long packageProductId = Optional.ofNullable(campaignViewDTO.getCampaignSaleViewDTO()).map(CampaignSaleViewDTO::getResourcePackageProductId).orElse(null);
            AssertUtil.notNull(packageProductId, "售卖分组资源位ID不存在");
            Long packageSaleGroupId = Optional.ofNullable(campaignViewDTO.getCampaignSaleViewDTO()).map(CampaignSaleViewDTO::getSaleGroupId).orElse(null);
            AssertUtil.notNull(packageSaleGroupId,"售卖分组ID不允许为空");

            ResourcePackageQueryOption packageQueryOption = ResourcePackageQueryOption.builder().needProduct(true).needSetting(true).build();
            ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO = resourcePackageRepository.getSaleGroupById(serviceContext, packageSaleGroupId, packageQueryOption);
            AssertUtil.notNull(packageSaleGroupViewDTO,"资源包售卖分组不存在");

            ResourcePackageProductViewDTO packageProductViewDTO = packageSaleGroupViewDTO.getDistributionRuleList().stream().flatMap(e -> e.getResourcePackageProductList().stream())
                    .filter(e -> e.getId().equals(packageProductId)).findFirst().orElse(null);
            AssertUtil.notNull(packageProductViewDTO, "售卖分组资源位不存在");

            AssertUtil.notNull(packageProductViewDTO.getSspProductId(),"二级产品ID不允许为空");
            ProductViewDTO productViewDTO = productRepository.getProductById(packageProductViewDTO.getSspProductId());
            AssertUtil.notNull(productViewDTO, "二级产品不存在");

            return CampaignDoohAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignDoohViewDTO())
                    .campaignViewDTO(campaignViewDTO).productViewDTO(productViewDTO).resourcePackageSaleGroupViewDTO(packageSaleGroupViewDTO).build();
        }
        return CampaignDoohAbilityParam.builder().build();
    }
}