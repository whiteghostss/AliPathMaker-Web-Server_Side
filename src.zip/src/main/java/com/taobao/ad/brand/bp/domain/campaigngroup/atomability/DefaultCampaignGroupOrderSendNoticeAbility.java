package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupProductCategoryEnum;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignDealMsgViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignMsgNoticeViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CrmAdvInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesProjectViewDTO;
import com.taobao.ad.brand.bp.client.dto.message.MessageViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageEmpViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.message.MessageSendTypeEnum;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.Env;
import com.taobao.ad.brand.bp.common.util.FenYuanUtil;
import com.taobao.ad.brand.bp.common.util.MailUtils;
import com.taobao.ad.brand.bp.common.util.VelocityUtils;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CustomerRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.SalesProjectRepository;
import com.taobao.ad.brand.bp.domain.memeber.MemberRepository;
import com.taobao.ad.brand.bp.domain.message.MessageRepository;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupOrderSendNoticeAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupNoticeAbilityParam;
import com.taobao.ad.brand.bp.domain.uic.SimbaUicRepository;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.cglib.beans.BeanMap;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@BusinessAbility
public class DefaultCampaignGroupOrderSendNoticeAbility implements ICampaignGroupOrderSendNoticeAbility {

    @Resource
    private ResourcePackageRepository resourcePackageRepository;
    @Resource
    private SimbaUicRepository simbaUicRepository;
    @Resource
    private CustomerRepository customerRepository;
    @Resource
    private MemberRepository memberRepository;
    @Resource
    private MessageRepository messageRepository;
    @Resource
    private SalesProjectRepository salesProjectRepository;
    private static final String CAMPAIGN_GROUP_ORDER_SUBJECT = "【下单通知】%s-%s-%s-%s";
    private static final String CAMPAIGN_GROUP_ORDER_VM = "vm/campaignGroupOrder.vm";

    private static final String DOOH_EMAIL_ADDRESS="showmethemoney@list.alibaba-inc.com";
    private static final List<Integer> DOOH_PRODUCT_CATEGORY_IDS = Lists.newArrayList(SaleGroupProductCategoryEnum.SMART_SCREEN.getValue()
            ,SaleGroupProductCategoryEnum.SMART_SCREEN_SPEED.getValue());

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupNoticeAbilityParam abilityParam) {
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        if (campaignGroupViewDTO == null) {
            return null;
        }
        List<Long> saleGroupIds = abilityParam.getSaleGroupIds();
        List<ResourcePackageSaleGroupViewDTO> saleGroupViewDTOList = Lists.newArrayList();
        if (CollectionUtils.isNotEmpty(saleGroupIds)) {
            ResourcePackageQueryViewDTO queryViewDTO = new ResourcePackageQueryViewDTO();
            queryViewDTO.setSaleGroupIdList(saleGroupIds);
            queryViewDTO.setPageSize(saleGroupIds.size());
            saleGroupViewDTOList.addAll(resourcePackageRepository.getSaleGroupList(serviceContext, queryViewDTO, ResourcePackageQueryOption.builder().needProduct(true).needSetting(true).build()));
        }

        List<String> sendTo = getSendTo(serviceContext, campaignGroupViewDTO, saleGroupViewDTOList);

        MessageViewDTO messageViewDTO = new MessageViewDTO();
        CampaignDealMsgViewDTO campaignDealMsgViewDTO = new CampaignDealMsgViewDTO();
        campaignDealMsgViewDTO.setCampaignGroupViewDTO(campaignGroupViewDTO);
        CrmAdvInfoViewDTO crmAdvInfoViewDTO = customerRepository.getCustomer(campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getCustomerMemberId());
        String subject = String.format(CAMPAIGN_GROUP_ORDER_SUBJECT, memberRepository.getMemberDisplayNameById(campaignGroupViewDTO.getMemberId()),
                crmAdvInfoViewDTO == null ? campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getCustomerMemberId() : crmAdvInfoViewDTO.getAdvName(),
                campaignGroupViewDTO.getName(), BrandDateUtil.date2String(campaignGroupViewDTO.getStartTime()) + "至" + BrandDateUtil.date2String(campaignGroupViewDTO.getEndTime()));
        messageViewDTO.setMemberId(campaignGroupViewDTO.getMemberId());
        messageViewDTO.setSubject(subject);
        messageViewDTO.setContent(buildMessageContent(serviceContext, campaignGroupViewDTO, crmAdvInfoViewDTO, saleGroupViewDTOList, CAMPAIGN_GROUP_ORDER_VM));
        messageViewDTO.setSendTo(sendTo);
        messageViewDTO.setSendType(Lists.newArrayList(MessageSendTypeEnum.STATION_LETTER.getValue(), MessageSendTypeEnum.EMAIL.getValue()));
        messageRepository.sendMessage(messageViewDTO);

        return null;
    }

    private String buildMessageContent(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, CrmAdvInfoViewDTO crmAdvInfoViewDTO, List<ResourcePackageSaleGroupViewDTO> saleGroupViewDTOList, String vm) {
        Map<String, Object> params = buildVMParam(context, campaignGroupViewDTO, crmAdvInfoViewDTO, saleGroupViewDTOList);
        String content = VelocityUtils.merge(vm, params);
        return content;
    }

    private Map<String, Object> buildVMParam(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, CrmAdvInfoViewDTO crmAdvInfoViewDTO
            , List<ResourcePackageSaleGroupViewDTO> saleGroupViewDTOList) {
        CampaignMsgNoticeViewDTO campaignMsgNoticeViewDTO = new CampaignMsgNoticeViewDTO();
        campaignMsgNoticeViewDTO.setMemberId(campaignGroupViewDTO.getMemberId());
        campaignMsgNoticeViewDTO.setMemberName(memberRepository.getMemberNameById(campaignGroupViewDTO.getMemberId()));
        campaignMsgNoticeViewDTO.setMemberDisplayName(memberRepository.getMemberDisplayNameById(campaignGroupViewDTO.getMemberId()));
        campaignMsgNoticeViewDTO.setCampaignGroupId(campaignGroupViewDTO.getId());
        campaignMsgNoticeViewDTO.setCampaignGroupName(campaignGroupViewDTO.getName());
        campaignMsgNoticeViewDTO.setCustomerName(crmAdvInfoViewDTO == null ? campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getCustomerId().toString() : crmAdvInfoViewDTO.getAdvName());
        campaignMsgNoticeViewDTO.setSaleProjectId(campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getSalesProjectId());
        List<SalesProjectViewDTO> salesProjectViewDTOS = salesProjectRepository.findSimpleProjectByIds(Lists.newArrayList(campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getSalesProjectId()));
        if (CollectionUtils.isNotEmpty(salesProjectViewDTOS)) {
            campaignMsgNoticeViewDTO.setSaleProjectName(salesProjectViewDTOS.get(0).getName());
        }
        campaignMsgNoticeViewDTO.setCampaignGroupStartTime(BrandDateUtil.date2String(campaignGroupViewDTO.getStartTime()));
        campaignMsgNoticeViewDTO.setCampaignGroupEndTime(BrandDateUtil.date2String(campaignGroupViewDTO.getEndTime()));
        campaignMsgNoticeViewDTO.setBudget("￥ " + FenYuanUtil.getYuanFromFen(campaignGroupViewDTO.getBudget()).toPlainString());
        if (CollectionUtils.isNotEmpty(saleGroupViewDTOList)) {
            campaignMsgNoticeViewDTO.setProductNames(saleGroupViewDTOList.stream()
                    .flatMap(resourcePackageSaleGroupViewDTO -> resourcePackageSaleGroupViewDTO.getDistributionRuleList().stream()).filter(Objects::nonNull)
                    .flatMap(resourceDistributionRuleViewDTO -> resourceDistributionRuleViewDTO.getResourcePackageProductList().stream())
                    .filter(Objects::nonNull).map(ResourcePackageProductViewDTO::getSspProductName).distinct().collect(Collectors.joining("<br>")));
        }

        BeanMap beanMap = BeanMap.create(campaignMsgNoticeViewDTO);
        return beanMap;
    }

    private List<String> getSendTo(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, List<ResourcePackageSaleGroupViewDTO> saleGroupViewDTOList) {
        List<String> sendToIds = Lists.newArrayList();
        List<String> operatorEmails = Lists.newArrayList(MailUtils.rdRecipients);
        if (Env.isProd()) {
            //运营
            Optional.ofNullable(campaignGroupViewDTO.getOperators()).ifPresent(sendToIds::addAll);
            //运营相关人
            Optional.ofNullable(campaignGroupViewDTO.getRelevantOperators()).ifPresent(sendToIds::addAll);
            //分组负责人
            if (CollectionUtils.isNotEmpty(saleGroupViewDTOList)) {
                sendToIds.addAll(saleGroupViewDTOList.stream()
                        .filter(saleGroupViewDTO -> CollectionUtils.isNotEmpty(saleGroupViewDTO.getChargeEmpList()))
                        .flatMap(saleGroupViewDTO -> saleGroupViewDTO.getChargeEmpList().stream()).collect(Collectors.toList())
                        .stream().map(ResourcePackageEmpViewDTO::getEmpId).collect(Collectors.toSet()));

                //包含天攻需要增加天攻邮件组
                if (saleGroupViewDTOList.stream().anyMatch(resourcePackageSaleGroupViewDTO -> DOOH_PRODUCT_CATEGORY_IDS.contains(resourcePackageSaleGroupViewDTO.getProductCategory()))) {
                    operatorEmails.add(DOOH_EMAIL_ADDRESS);
                }
            }
            //直客销售
            Optional.ofNullable(campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getDirectSales()).ifPresent(sendToIds::addAll);
            //渠道销售
            Optional.ofNullable(campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getChannelSales()).ifPresent(sendToIds::addAll);
            //销售相关人
            Optional.ofNullable(campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getRelevantSales()).ifPresent(sendToIds::addAll);
            //获取邮箱
            Map<String, String> empEmailMap = simbaUicRepository.getEmpEmails(sendToIds);
            RogerLogger.info("sendToIds={},empEmailMap={}", JSON.toJSONString(sendToIds), JSON.toJSONString(empEmailMap));
            operatorEmails.addAll(empEmailMap.values());
        }

        return operatorEmails;
    }
}
