package com.taobao.ad.brand.bp.domain.qualification;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.dto.qualification.QualificationViewDTO;

import java.util.List;

/**
 * 资质相关服务
 */
public interface QualificationRepository {

    List<String> findQualificationTypeList();

    List<QualificationViewDTO> findQualificationList(Long tbUserId, List<String> qualificationTypeList);
}
