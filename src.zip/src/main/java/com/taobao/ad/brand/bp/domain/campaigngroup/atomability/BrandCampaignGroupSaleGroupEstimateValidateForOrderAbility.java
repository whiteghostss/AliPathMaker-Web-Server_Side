package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupDeliveryTargetViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.nb.ssp.constant.newproduct.DeliveryTargetEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupOrderCommandViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizSaleGroupToolsHelper;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupSaleGroupEstimateValidateForOrderAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupSaleGroupEstimateValidateForOrderAbilityParam;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
@BusinessAbility
public class BrandCampaignGroupSaleGroupEstimateValidateForOrderAbility
        implements ICampaignGroupSaleGroupEstimateValidateForOrderAbility, BrandAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupSaleGroupEstimateValidateForOrderAbilityParam abilityParam) {
        CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO = abilityParam.getAbilityTarget();
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        List<Long> checkedSaleGroupIds = campaignGroupOrderCommandViewDTO.getSaleGroupIds();
        List<ResourcePackageSaleGroupViewDTO> checkedResourcePackageSaleGroupList = abilityParam.getResourcePackageSaleGroupList().stream()
                .filter(it -> Optional.ofNullable(it.getBudget()).orElse(0L) > 0)
                .filter(resourceSaleGroup -> checkedSaleGroupIds.contains(resourceSaleGroup.getId())).collect(Collectors.toList());

        List<SaleGroupInfoViewDTO> dbSaleGroupList = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList();
        Map<Long,SaleGroupInfoViewDTO> dbSaleGroupMap =
                dbSaleGroupList.stream().collect(Collectors.toMap(SaleGroupInfoViewDTO::getSaleGroupId, Function.identity()));
        // 1. 校验预估状态
        boolean isAliStaff = ServiceContextUtil.isAliStaff(serviceContext);
        List<ResourcePackageSaleGroupViewDTO> notEstimateViewDTOList = checkedResourcePackageSaleGroupList.stream().map(item -> {
            if (dbSaleGroupMap.containsKey(item.getId())) {
                SaleGroupInfoViewDTO dbViewDTO = dbSaleGroupMap.get(item.getId());
                // 客户登录场景：需要过滤不对客的交付指标。 因为会变成不需要预估，会在后面自动预估
                List<SaleGroupDeliveryTargetViewDTO> deliveryTargetViewDTOS = Optional.ofNullable(dbViewDTO.getDeliveryTargetViewDTOList()).orElse(Lists.newArrayList()).stream()
                        .filter(deliveryTargetViewDTO -> !deliveryTargetViewDTO.getDeliveryTarget().equals(DeliveryTargetEnum.EXPOSURE.getValue()))
                        .filter(deliveryTargetViewDTO -> isAliStaff || Optional.ofNullable(deliveryTargetViewDTO.getCustomerSwitch()).orElse(BrandBoolEnum.BRAND_TRUE.getCode()).equals(BrandBoolEnum.BRAND_TRUE.getCode()))
                        .collect(Collectors.toList());

                if (CollectionUtils.isNotEmpty(deliveryTargetViewDTOS)) {
                    if (dbViewDTO.getSaleGroupEstimateInfoViewDTO() == null) {
                        return item;
                    }
                }
            }
            return null;
        }).filter(Objects::nonNull).collect(Collectors.toList());
        List<Long> notSaleGroupIds = notEstimateViewDTOList.stream().map(ResourcePackageSaleGroupViewDTO::getId).distinct().collect(Collectors.toList());
        AssertUtil.assertTrue(CollectionUtils.isEmpty(notSaleGroupIds), "%s分组未预估,请预估后再下单", StringUtils.join(BizSaleGroupToolsHelper.getSaleGroupNames(notEstimateViewDTOList, notSaleGroupIds), ","));

        return null;
    }
}
