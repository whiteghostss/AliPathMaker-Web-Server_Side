package com.taobao.ad.brand.bp.domain.report.util;

import lombok.Builder;

@Builder
public class ReportWorksPackageMail {
    String accountNameUD;
    Long shopId;
    String shopName;
    Long campaignGroupId;
    String campaignGroupName;
    String talentName;
    String packageName;
    private final String SUFFIX = "已提交一键助推，请查看！\n";

    public String getMailContent() {
        return "UD账号名称：" + accountNameUD + "<br>"
                + "店铺id：" + shopId + "<br>"
                + "店铺名称：" + shopName + "<br>"
                + "订单id：" + campaignGroupId + "<br>"
                + "订单：" + campaignGroupName + "<br>"
                + "达人：" + talentName + "<br>"
                + "指标：" + packageName + "<br>"
                + SUFFIX;
    }
}
