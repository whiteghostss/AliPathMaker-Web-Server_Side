package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.budget.CampaignBudgetViewDTO;
import com.alibaba.ad.brand.dto.campaign.sale.CampaignSaleViewDTO;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleProductLineEnum;
import com.taobao.ad.brand.bp.common.constant.CampaignConstant;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.config.SelfServiceTestMemberConfig;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignBudgetValidateForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBudgetAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCampaignBudgetValidateForAddCampaignAbility implements ICampaignBudgetValidateForAddCampaignAbility, SelfServiceAtomAbilityRouter {

    private final SelfServiceTestMemberConfig selfServiceTestMemberConfig;

    @Override
    public Void handle(ServiceContext serviceContext, CampaignBudgetAbilityParam abilityParam) {
        CampaignBudgetViewDTO campaignBudgetViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();
        AssertUtil.notNull(campaignBudgetViewDTO, "预算参数不能为空");
        AssertUtil.notNull(campaignViewDTO, "计划信息不能为空");

        AssertUtil.notNull(campaignBudgetViewDTO.getDiscountTotalMoney(),"预算金额不能为空");
        AssertUtil.assertTrue(campaignBudgetViewDTO.getDiscountTotalMoney() <= CampaignConstant.SELF_BUDGET_TOP,"计划预算金额不允许大于50万");

        CampaignSaleViewDTO campaignSaleViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignSaleViewDTO()).orElse(new CampaignSaleViewDTO());
        if(SaleProductLineEnum.SUPER_UNIVERSE.getValue().equals(campaignSaleViewDTO.getSaleProductLine())){
            List<Long> selfSpuMarketingRuleMemberIds = selfServiceTestMemberConfig.getSelfSpuMarketingRuleMemberList();
            if (CollectionUtils.isEmpty(selfSpuMarketingRuleMemberIds) || !selfSpuMarketingRuleMemberIds.contains(serviceContext.getMemberId())) {
                if(!BizCampaignToolsHelper.isSlimOrderCampaign(campaignViewDTO)){
                    AssertUtil.assertTrue(campaignBudgetViewDTO.getDiscountTotalMoney() >= 10000000,"全域通计划必须大于10W");
                }
            }
        }
        return null;
    }
}
