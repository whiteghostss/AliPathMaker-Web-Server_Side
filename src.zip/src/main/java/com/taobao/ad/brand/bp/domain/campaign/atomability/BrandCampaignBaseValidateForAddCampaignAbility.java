package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignBaseValidateForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBaseAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_ILLEGAL;
import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_REQUIRED;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandCampaignBaseValidateForAddCampaignAbility implements ICampaignBaseValidateForAddCampaignAbility, BrandAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignBaseAbilityParam abilityParam) {
        CampaignViewDTO campaignViewDTO = abilityParam.getAbilityTarget();
        AssertUtil.notNull(campaignViewDTO, PARAM_REQUIRED, "计划不能为空");

        AssertUtil.notNull(campaignViewDTO.getCampaignGroupId(), PARAM_REQUIRED, "订单ID必填");

        // 【日期】1、必填；2、开始时间小于等于结束时间
        AssertUtil.notNull(campaignViewDTO.getStartTime(), PARAM_REQUIRED, "计划开始时间必填");
        AssertUtil.notNull(campaignViewDTO.getEndTime(), PARAM_REQUIRED, "计划结束时间必填");
        AssertUtil.assertTrue(BrandDateUtil.isBeforeAndEqual(campaignViewDTO.getStartTime(), campaignViewDTO.getEndTime())
                , PARAM_ILLEGAL, "计划开始时间小于等于结束时间");
        //【日期】资源包产品日期的子集
        ResourcePackageProductViewDTO resourcePackageProductViewDTO = abilityParam.getResourcePackageProductViewDTO();
        AssertUtil.notNull(resourcePackageProductViewDTO, PARAM_REQUIRED, "资源位不存在");
        AssertUtil.notEmpty(resourcePackageProductViewDTO.getBandPriceList(), PARAM_REQUIRED, "资源位价格波段不存在");
        Date minStartDate = resourcePackageProductViewDTO.getBandPriceList().stream().map(ResourcePackageProductPriceViewDTO::getStartDate).min(Date::compareTo).orElse(null);
        Date maxEndDate = resourcePackageProductViewDTO.getBandPriceList().stream().map(ResourcePackageProductPriceViewDTO::getEndDate).max(Date::compareTo).orElse(null);
        AssertUtil.assertTrue(BrandDateUtil.isBeforeAndEqual(minStartDate, campaignViewDTO.getStartTime()), PARAM_ILLEGAL, "开始时间大于等于资源位开始时间");
        AssertUtil.assertTrue(BrandDateUtil.isAfterAndEqual(BrandDateUtil.getDateFullMidnight(maxEndDate), campaignViewDTO.getEndTime()), PARAM_ILLEGAL, "结束时间小于等于资源位结束时间");
        return null;
    }
}
