package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.EffectAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignValidateForDeleteCampaignGroupAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EffectCampaignValidateForDeleteCampaignGroupAbility extends DefaultCampaignValidateForDeleteCampaignGroupAbility implements EffectAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignValidateForDeleteCampaignGroupAbilityParam abilityParam) {
        if (CollectionUtils.isEmpty(abilityParam.getAbilityTargets())) {
            return null;
        }
        for (CampaignViewDTO campaignViewDTO : abilityParam.getAbilityTargets()) {
            AssertUtil.assertTrue(BrandCampaignStatusEnum.LOCK_SUCCESS.getCode().equals(campaignViewDTO.getStatus()), "当前计划状态不允许删除订单");
        }
        return null;
    }
}
