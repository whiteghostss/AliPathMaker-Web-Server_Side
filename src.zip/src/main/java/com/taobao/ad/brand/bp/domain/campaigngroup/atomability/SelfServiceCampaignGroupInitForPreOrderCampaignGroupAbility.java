package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.SelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupInitForPreOrderCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupPreOrderAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SelfServiceCampaignGroupInitForPreOrderCampaignGroupAbility
        implements ICampaignGroupInitForPreOrderCampaignGroupAbility, SelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupPreOrderAbilityParam abilityParam) {
        // 子订单
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        // 汇总并设置计划最大最小时间
        List<CampaignViewDTO> campaignList = abilityParam.getCampaignViewDTOList();
        campaignGroupViewDTO.setBudget(BizCampaignGroupToolsHelper.getBuyCampaignBudgetTotal(campaignList));
        campaignGroupViewDTO.setStartTime(BrandDateUtil.getDateMidnight(BizCampaignGroupToolsHelper.getCampaignMinTime(campaignList)));
        campaignGroupViewDTO.setEndTime(BrandDateUtil.getDateFullMidnight(BizCampaignGroupToolsHelper.getCampaignMaxTime(campaignList)));

        return null;
    }
}
