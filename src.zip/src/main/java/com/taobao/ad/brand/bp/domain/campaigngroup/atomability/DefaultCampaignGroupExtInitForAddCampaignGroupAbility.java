package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.ext.CampaignGroupExtViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupExtInitForAddCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupExtAbilityParam;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@BusinessAbility
public class DefaultCampaignGroupExtInitForAddCampaignGroupAbility implements ICampaignGroupExtInitForAddCampaignGroupAbility {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupExtAbilityParam abilityParam) {
        CampaignGroupExtViewDTO campaignGroupExtViewDTO = Optional.ofNullable(abilityParam.getAbilityTarget()).orElse(new CampaignGroupExtViewDTO());
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        campaignGroupViewDTO.setCampaignGroupExtViewDTO(campaignGroupExtViewDTO);

        return null;
    }
}
