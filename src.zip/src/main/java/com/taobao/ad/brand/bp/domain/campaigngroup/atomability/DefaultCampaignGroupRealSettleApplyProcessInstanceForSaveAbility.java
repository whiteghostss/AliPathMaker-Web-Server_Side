package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.process.ProcessRecordViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupProcessStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupProcessTypeEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.alibaba.ad.nb.order.dto.common.EmpDTO;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupBusinessLineEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleProductLineEnum;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.dto.account.emp.AliEmpViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupSettleInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesCustomerViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.settle.CampaignGroupRealSettleSaveViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProjectViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.settle.CampaignGroupRealSettleOpTypeEnum;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.enums.BpmsProcessCodeEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.CurrencyUtil;
import com.taobao.ad.brand.bp.common.util.EmpUtil;
import com.taobao.ad.brand.bp.domain.bpms.BpmsRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CustomerRepository;
import com.taobao.ad.brand.bp.domain.memeber.MemberRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupRealSettleApplyProcessInstanceForSaveAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupRealSettleApplyProcessInstanceForSaveAbilityParam;
import com.taobao.ad.brand.bp.domain.uic.SimbaUicRepository;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR;

@Component
@BusinessAbility
public class DefaultCampaignGroupRealSettleApplyProcessInstanceForSaveAbility implements ICampaignGroupRealSettleApplyProcessInstanceForSaveAbility {

    @Resource
    private SimbaUicRepository simbaUicRepository;

    @Resource
    private BpmsRepository bpmsRepository;

    @Resource
    private MemberRepository memberRepository;
    @Resource
    private CustomerRepository customerRepository;

    @Override
    public Void handle(ServiceContext serviceContext,
                                             CampaignGroupRealSettleApplyProcessInstanceForSaveAbilityParam abilityParam) {

        CampaignGroupViewDTO  campaignGroupViewDTO = abilityParam.getAbilityTarget();
        CampaignGroupRealSettleSaveViewDTO campaignGroupRealSettleSaveViewDTO = abilityParam.getCampaignGroupRealSettleSaveViewDTO();
        // 提交时，发起流程
        if (campaignGroupRealSettleSaveViewDTO.getRealSettleOpTypeEnum() != CampaignGroupRealSettleOpTypeEnum.SUBMIT) {
            return null;
        }
        ResourcePackageProjectViewDTO resourcePackageProjectViewDTO = abilityParam.getResourcePackageProjectViewDTO();
        Map<String, String> initDataMap = buildRealSettleProcessParam(serviceContext, campaignGroupViewDTO, campaignGroupRealSettleSaveViewDTO, resourcePackageProjectViewDTO);
        // title
        String title = new StringBuilder("订单-").append(campaignGroupViewDTO.getName())
            .append("-实结审批流程").toString();
        String titleEn = "Brand OneBP Order RealSettle Apply";
        String processInstanceId = bpmsRepository.startProcessInstance(title, titleEn, serviceContext.getOperIdStr(), initDataMap, BpmsProcessCodeEnum.CAMPAIGN_GROUP_REAL_SETTLE_APPLY);
        //设置实结审批流实例ID和审批状态
        campaignGroupViewDTO.getCampaignGroupRealSettleViewDTO().setRealSettleProcessId(processInstanceId);
        campaignGroupViewDTO.getCampaignGroupRealSettleViewDTO().setRealSettleProcessStatus(
            BrandCampaignGroupProcessStatusEnum.APPROVE_ING.getCode());
        initProcessRecordViewDTOList(campaignGroupViewDTO, BrandCampaignGroupProcessStatusEnum.APPROVE_ING);
        return null;
    }


    private Map<String, String> buildRealSettleProcessParam(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO,
                                                            CampaignGroupRealSettleSaveViewDTO campaignGroupRealSettleSaveViewDTO,
                                                            ResourcePackageProjectViewDTO resourcePackageProjectViewDTO) {
        Map<String, String> initDataMap = Maps.newHashMap();
        List<Integer> saleProductLines = campaignGroupRealSettleSaveViewDTO.getRealSettleInfoViewDTOList().stream().map(
            CampaignGroupSaleGroupSettleInfoViewDTO::getSaleProductLine).distinct().collect(Collectors.toList());
        //增加是否包含对应产品线
        Arrays.stream(SaleProductLineEnum.values()).forEach(saleProductLineEnum -> {
            initDataMap.put(saleProductLineEnum.name(), saleProductLines.contains(saleProductLineEnum.getValue()) ? "1" : "0");
        });
        initDataMap.put("realSettlePriceFlag", campaignGroupRealSettleSaveViewDTO.getRealSettleInfoViewDTOList().stream()
            .filter(settleInfoViewDTO -> settleInfoViewDTO.getRealCastPrice() != null)
            .anyMatch(settleInfoViewDTO -> settleInfoViewDTO.getRealSettlePrice() < settleInfoViewDTO.getRealCastPrice())
            ? "0" : "1");
        // 基础信息
        initDataMap.put("campaignGroupId", String.valueOf(campaignGroupViewDTO.getId()));
        initDataMap.put("campaignGroupName", campaignGroupViewDTO.getName());
        initDataMap.put("budget", CurrencyUtil.f2y(campaignGroupViewDTO.getBudget()));
        // 客户信息
        SalesCustomerViewDTO salesCustomerViewDTO = null;
        if (campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getCustomerId() != null && campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getCustomerId() != 0L) {
            salesCustomerViewDTO = customerRepository.getCustomerById(campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getCustomerId());
        }
        String customerName;
        if (salesCustomerViewDTO != null) {
            customerName = salesCustomerViewDTO.getName();
        } else {
            customerName = "无";
        }
        initDataMap.put("customerName", customerName);
        String memberName = memberRepository.getMemberNameById(context.getMemberId());
        Map<Long, String> xMemberNameMap = memberRepository.queryXMemberDisplayNameMap(Lists.newArrayList(context.getMemberId()));
        // 账号 格式:  直客名称/叉乘账号友好展示(memberId)
        initDataMap.put("member", memberName
            + (MapUtils.isEmpty(xMemberNameMap) ? "" : ("/" + xMemberNameMap.get(context.getMemberId())))
            + "(" + context.getMemberId() + ")");
        initDataMap.put("castDate", BrandDateUtil.date2String(campaignGroupViewDTO.getStartTime()) + "-" + BrandDateUtil.date2String(campaignGroupViewDTO.getEndTime()));

        // 直客销售
        initDataMap.put("directSales", getEmpNameList(campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getDirectSales()));
        // 渠道销售
        initDataMap.put("channelSales", getEmpNameList(campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getChannelSales()));
        // 运营
        initDataMap.put("operators", getEmpNameList(campaignGroupViewDTO.getOperators()));
        // 运营相关人
        initDataMap.put("relevantOperators", getEmpNameList(campaignGroupViewDTO.getRelevantOperators()));

        // 分组信息
        Map<String, Object> settleInfoMap = Maps.newHashMap();
        List<JSONObject> settleInfoList = Lists.newArrayList();
        campaignGroupRealSettleSaveViewDTO.getRealSettleInfoViewDTOList().forEach(settleInfoViewDTO -> {
            JSONObject settleInfo = new JSONObject();
            settleInfo.put("saleGroupName", settleInfoViewDTO.getSaleGroupName());
            settleInfo.put("saleProductLine", SaleProductLineEnum.getDesc(settleInfoViewDTO.getSaleProductLine()));
            settleInfo.put("saleType", BrandSaleTypeEnum.getByCode(settleInfoViewDTO.getSaleType()).getDesc());
            settleInfo.put("saleGroupId", BrandSaleTypeEnum.getByCode(settleInfoViewDTO.getSaleType()).getDesc());
            settleInfo.put("budget", CurrencyUtil.f2y(settleInfoViewDTO.getBudget()));
            settleInfo.put("realSettlePrice", CurrencyUtil.f2y(settleInfoViewDTO.getRealSettlePrice()));
            settleInfo.put("realCastPrice", CurrencyUtil.f2y(settleInfoViewDTO.getRealCastPrice()));
            settleInfo.put("incomePrice", CurrencyUtil.f2y(settleInfoViewDTO.getIncomePrice()));
            settleInfoList.add(settleInfo);
        });
        settleInfoMap.put("data", settleInfoList);
        initDataMap.put("realSettleData", JSONObject.toJSONString(settleInfoMap));
        // 方案审批人
        buildProcessProjectApproveInfo(initDataMap, campaignGroupViewDTO, resourcePackageProjectViewDTO);

        initDataMap.put("context",JSONObject.toJSONString(context));

        return initDataMap;
    }

    private void buildProcessProjectApproveInfo(Map<String, String> initDataMap, CampaignGroupViewDTO campaignGroupViewDTO, ResourcePackageProjectViewDTO resourcePackageProjectViewDTO) {
        if (!SaleGroupBusinessLineEnum.IP_MARKETING_AD.getValue().equals(campaignGroupViewDTO.getSceneId())) {
            return;
        }
        AssertUtil.notNull(resourcePackageProjectViewDTO, BIZ_BREAK_RULE_ERROR, "资源包项目不存在");
        AssertUtil.notEmpty(resourcePackageProjectViewDTO.getSchemeApprovalEmpList(), BIZ_BREAK_RULE_ERROR, "流程发起失败：未查询到方案审批人");
        List<String> schemeApproveEmpIds = resourcePackageProjectViewDTO.getSchemeApprovalEmpList().stream()
            .map(AliEmpViewDTO::getEmpId).distinct()
            .map(EmpUtil::standardizeEmpNo)
            .collect(Collectors.toList());
        initDataMap.put("schemeApproveEmpIds", JSONObject.toJSONString(schemeApproveEmpIds));
    }

    private String getEmpNameList(List<String> empIdList) {
        if (org.apache.commons.collections4.CollectionUtils.isEmpty(empIdList)) {
            return "";
        }
        Map<String, EmpDTO> empMap = simbaUicRepository.getEmp(empIdList);
        if (MapUtils.isEmpty(empMap)) {
            return "";
        }
        return empMap.values().stream()
            .filter(empDTO -> org.apache.commons.lang.StringUtils.isNotBlank(empDTO.getName()) || org.apache.commons.lang.StringUtils.isNotBlank(empDTO.getNick()))
            .map(empDTO -> {
                if (StringUtils.isNotBlank(empDTO.getNick())) {
                    return empDTO.getNick();
                }
                return empDTO.getName();
            })
            .collect(Collectors.joining(Constant.CHAR_SPLIT_KEY_DOT));
    }

    /**
     * 更新订单申请流程明细
     * @param campaignGroupViewDTO 订单
     */
    private void initProcessRecordViewDTOList(CampaignGroupViewDTO campaignGroupViewDTO, BrandCampaignGroupProcessStatusEnum brandCampaignGroupProcessStatusEnum) {
        //提交审核则新建
        ProcessRecordViewDTO processRecordViewDTO = new ProcessRecordViewDTO();
        processRecordViewDTO.setStatus(brandCampaignGroupProcessStatusEnum.getCode());
        processRecordViewDTO.setApplyTime(new Date());
        processRecordViewDTO.setProcInstId(campaignGroupViewDTO.getCampaignGroupRealSettleViewDTO().getRealSettleProcessId());
        processRecordViewDTO.setApplyContent(campaignGroupViewDTO.getId().toString());
        processRecordViewDTO.setType(BrandCampaignGroupProcessTypeEnum.REAL_SETTLE.getCode());
        List<ProcessRecordViewDTO> processRecordViewDTOList = Optional.ofNullable(campaignGroupViewDTO.getProcessRecordViewDTOList()).orElse(
            Lists.newArrayList());
        processRecordViewDTOList.add(processRecordViewDTO);
        campaignGroupViewDTO.setProcessRecordViewDTOList(processRecordViewDTOList);
    }
}
