package com.taobao.ad.brand.bp.domain.salegroup.spi;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.nb.framework.core.AbilitySpi;
import com.alibaba.ad.nb.framework.core.annotation.Ability;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupEstimateResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignSaleGroupResourceDeliveryTargetViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.DeliveryTargetDiamondConfigViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;

import java.util.List;


/**
 * @author yunhu.myh@taobao.com
 * @date 2023年08月09日
 * 分组预估后结果计算SPI
 * 这里只计算与算法有关的，与BP有关的在vo那里处理
 *
 * */
@Ability(desc = "分组预估后结果计算SPI")
public interface BizSaleGroupEstimateFinalValueAbilitySpi extends AbilitySpi {

    /**
     * 预估结果和资源包比对处理
     *
     * @param serviceContext
     * @param campaignSaleGroupResourceDeliveryTargetViewDTO
     * @param campaignGroupSaleGroupEstimateResultViewDTO
     * @param resourcePackageSaleGroupViewDTO
     * @param deliveryTargetConfigViewDTO
     */
    List<CampaignGroupSaleGroupEstimateResultViewDTO> processValue(ServiceContext serviceContext
            , CampaignSaleGroupResourceDeliveryTargetViewDTO campaignSaleGroupResourceDeliveryTargetViewDTO
            , CampaignGroupSaleGroupEstimateResultViewDTO campaignGroupSaleGroupEstimateResultViewDTO
            , ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO, SaleGroupInfoViewDTO dbSaleGroupInfoViewDTO
            ,
                                                                   boolean isSave, boolean isIgnoreAliLogin, DeliveryTargetDiamondConfigViewDTO deliveryTargetConfigViewDTO);

    //    /**
//     * 预估
//     * */
//    Long getCpm(ServiceContext serviceContext, ResourcePackageProductViewDTO resourcePackageProductViewDTO);
//    Long getSaleGroupCpm(ServiceContext serviceContext, SaleGroupInfoViewDTO dbSaleGroupInfoViewDTO);
//    Long getSumCampaignAmount(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList);
//    boolean showPriceResult(ServiceContext serviceContext, SaleGroupInfoViewDTO dbSaleGroupInfoViewDTO,boolean isIgnoreAliLogin);
//    boolean showForecastResult(ServiceContext serviceContext, SaleGroupInfoViewDTO dbSaleGroupInfoViewDTO, CampaignSaleGroupResourceDeliveryTargetViewDTO campaignSaleGroupResourceDeliveryTargetViewDTO,boolean isSave,boolean ignoreAliLogin);
//
//    /**
//     * 预估
//     * */
//    CampaignSaleGroupResourceDeliveryTargetViewDTO getResourceDeliveryTargetViewDTO(ServiceContext serviceContext,ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO, DeliveryTargetEnum udSaleUnitEnum);
//
//    SaleGroupDeliveryTargetViewDTO getLocalSaleGroupDeliveryTargetViewDTO(ServiceContext serviceContext,SaleGroupInfoViewDTO saleGroupInfoViewDTO, DeliveryTargetEnum udSaleUnitEnum);
//    Long getCustomValue(ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO, Long saleGroupBudget, Integer customValue);
//    CampaignGroupSaleGroupEstimateResultViewDTO getPriceResult(CampaignGroupSaleGroupEstimateResultViewDTO campaignGroupSaleGroupEstimateResultViewDTO,Long budget, BrandDeliveryTargetEnum deliveryTargetEnum);
}
