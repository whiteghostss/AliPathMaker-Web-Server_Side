package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupBoostGiveApplyInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupApplyInfoSaveForDeleteSaleGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupApplyInfoAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DefaultSaleGroupApplyInfoSaveForDeleteSaleGroupAbility implements ISaleGroupApplyInfoSaveForDeleteSaleGroupAbility {
    private final CampaignGroupRepository campaignGroupRepository;
    @Override
    public Void handle(ServiceContext serviceContext, SaleGroupApplyInfoAbilityParam abilityParam) {
        SaleGroupBoostGiveApplyInfoViewDTO applyInfoViewDTO = abilityParam.getAbilityTarget();
        SaleGroupInfoViewDTO mainSaleGroupInfoViewDTO = abilityParam.getMainSaleGroupInfoViewDTO();
        List<SaleGroupBoostGiveApplyInfoViewDTO> saleGroupBoostGiveApplyInfoViewDTOList = Optional.of(mainSaleGroupInfoViewDTO.getBoostGiveApplyInfoList().stream()
                .filter(saleGroup -> !applyInfoViewDTO.getSaleGroupId().equals(saleGroup.getSaleGroupId())).collect(Collectors.toList())).orElse(Lists.newArrayList());
        SaleGroupInfoViewDTO updateSaleGroup = new SaleGroupInfoViewDTO();
        updateSaleGroup.setId(mainSaleGroupInfoViewDTO.getId());
        updateSaleGroup.setSaleGroupId(mainSaleGroupInfoViewDTO.getSaleGroupId());
        updateSaleGroup.setBoostGiveApplyInfoList(saleGroupBoostGiveApplyInfoViewDTOList);
        campaignGroupRepository.updateSaleGroupPart(serviceContext, Lists.newArrayList(updateSaleGroup));
        return null;
    }
}
