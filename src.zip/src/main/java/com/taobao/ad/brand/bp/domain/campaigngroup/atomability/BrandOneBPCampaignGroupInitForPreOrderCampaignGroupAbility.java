package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupInitForPreOrderCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupPreOrderAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandOneBPCampaignGroupInitForPreOrderCampaignGroupAbility
        implements ICampaignGroupInitForPreOrderCampaignGroupAbility, BrandOneBPAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupPreOrderAbilityParam abilityParam) {
        // 主订单
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getAbilityTarget();
        CampaignGroupViewDTO subCampaignGroupViewDTO = abilityParam.getSubCampaignGroupList().get(0);
        campaignGroupViewDTO.setBudget(subCampaignGroupViewDTO.getBudget());
        campaignGroupViewDTO.setStartTime(subCampaignGroupViewDTO.getStartTime());
        campaignGroupViewDTO.setEndTime(subCampaignGroupViewDTO.getEndTime());

        return null;
    }
}
