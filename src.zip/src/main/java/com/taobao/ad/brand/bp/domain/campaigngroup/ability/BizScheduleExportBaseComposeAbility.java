package com.taobao.ad.brand.bp.domain.campaigngroup.ability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityInject;
import com.alibaba.abf.isolation.spec.common.ReduceType;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.creative.consts.template.TemplateStatusEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleProductLineEnum;
import com.alibaba.ad.nb.ssp.constant.common.MediaScopeEnum;
import com.alibaba.fastjson.JSONArray;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.client.context.ScheduleExportContext;
import com.taobao.ad.brand.bp.client.dto.adc.AdcComponentViewDTO;
import com.taobao.ad.brand.bp.client.dto.adc.query.AdcQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignTemplateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeTemplateQueryDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductQueryOption;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resource.MediaResourceViewDTO;
import com.taobao.ad.brand.bp.client.dto.template.TemplateViewDTO;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.enums.BooleanEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.adc.repository.AdcRepository;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.config.CreativeTemplatesWhiteListDiamondConfig;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeTemplateRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.ability.BizCampaignGroupComposeAbilityExt;
import com.taobao.ad.brand.bp.domain.ssp.ProductRepository;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_REQUIRED;

/**
 * @author jixiu.lj
 * @date 2023/5/11 12:31
 */
@Service
public class BizScheduleExportBaseComposeAbility {
    @Resource
    private ICampaignStructureQueryAbility campaignStructureQueryAbility;
    @Resource
    private CampaignGroupRepository campaignGroupRepository;
    @Resource
    private ProductRepository productRepository;
    @Resource
    private CreativeTemplateRepository creativeTemplateRepository;
    @Resource
    private AdcRepository adcRepository;

    @Resource
    private CreativeTemplatesWhiteListDiamondConfig creativeTemplatesWhiteListDiamondConfig;

    @Resource
    private CampaignRepository campaignRepository;

    @Resource
    @AbilityInject(reduce = ReduceType.FIRST)
    private BizCampaignGroupComposeAbilityExt bizCampaignGroupComposeAbilityExt;



    public CampaignGroupViewDTO buildCampaignGroupViewDTO(ServiceContext serviceContext,
                                                          ScheduleExportContext scheduleExportContext) {
        CampaignGroupViewDTO campaignGroup = campaignGroupRepository.getCampaignGroup(serviceContext, scheduleExportContext.getCampaignGroupId());
        AssertUtil.notNull(campaignGroup, PARAM_REQUIRED, "无效的订单ID");
        return campaignGroup;
    }


    /**
     * 全量的一二级计划平铺，注意筛去了默认复制的子计划
     * @param serviceContext
     * @param scheduleExportContext
     * @return
     */
    public List<CampaignViewDTO> buildCampaignList(ServiceContext serviceContext,
                                                   ScheduleExportContext scheduleExportContext,Map<Long, CampaignTemplateViewDTO> initCampaignTemplateMap) {
        // 直接查全部一级计划
        CampaignQueryViewDTO campaignQueryViewDTO = bizCampaignGroupComposeAbilityExt.buildCampaignList(serviceContext, scheduleExportContext, initCampaignTemplateMap);

        CampaignQueryOption option = new CampaignQueryOption();
        option.setNeedTarget(true);
        option.setNeedChildren(true);
        option.setNeedFrequency(true);

        List<CampaignViewDTO> completeCampaignList = campaignStructureQueryAbility.handle(serviceContext, CampaignStructureQueryAbilityParam.builder()
                .abilityTarget(campaignQueryViewDTO).queryOption(option).build());
        List<CampaignTemplateViewDTO> campaignTemplateViewDTOS = campaignRepository.getCampaignTemplateIds(serviceContext, completeCampaignList);
        Map<Long, CampaignTemplateViewDTO> campaignTemplateMap = campaignTemplateViewDTOS.stream().collect(Collectors.toMap(CampaignTemplateViewDTO::getCampaignId, Function.identity()));
        if(MapUtils.isNotEmpty(campaignTemplateMap)){
            initCampaignTemplateMap.putAll(campaignTemplateMap);
        }

        List<CampaignViewDTO> campaignViewDTOList = Lists.newArrayList();

        // 二级计划打平
        for (CampaignViewDTO campaignViewDTO : completeCampaignList) {
            campaignViewDTOList.add(campaignViewDTO);
            // 如果有二级计划，就插到对应的一级计划之后
            if (CollectionUtils.isNotEmpty(campaignViewDTO.getSubCampaignViewDTOList())) {
                campaignViewDTO.getSubCampaignViewDTOList().stream()
                        .filter(subCampaign -> Objects.nonNull(subCampaign.getCampaignExtViewDTO()))
                        .forEach(campaignViewDTOList::add);
            }
        }
        // 如果指定了计划ID
        if (CollectionUtils.isNotEmpty(scheduleExportContext.getCampaignIdList())) {
            campaignViewDTOList = campaignViewDTOList.stream().filter(
                    v -> scheduleExportContext.getCampaignIdList().contains(v.getId())).collect(
                    Collectors.toList());
        }
        return campaignViewDTOList;
    }

    /**
     * 相关ssp 二级产品的实体map，注意在全域通场景下，包含ssp二级产品一级其子产品（一二级计划映射得到）
     * @param serviceContext
     * @param scheduleExportContext
     * @param campaignModelList
     * @return
     */
    public Map<Long, ProductViewDTO> buildProductMap(ServiceContext serviceContext,
                                                     ScheduleExportContext scheduleExportContext,
                                                     List<CampaignViewDTO> campaignModelList) {

        Set<Long> sspProductIds = campaignModelList.stream()
                .filter(campaignViewDTO -> Objects.nonNull(campaignViewDTO.getCampaignResourceViewDTO().getSspProductId()))
                .map(campaignViewDTO -> campaignViewDTO.getCampaignResourceViewDTO().getSspProductId())
                .collect(Collectors.toSet());

        ProductQueryOption productQueryOption = ProductQueryOption.builder()
                .needDirection(true).needAssociationProduct(true).needAdzone(true)
                .needResource(true).needParentName(true).needLabelName(true).needTemplateName(true)
                .build();
        List<ProductViewDTO> productViewDTOList = productRepository.getProductByIdsOption(Lists.newArrayList(sspProductIds), productQueryOption);
        return Optional.ofNullable(productViewDTOList).orElseGet(Lists::newArrayList)
                .stream().collect(Collectors.toMap(ProductViewDTO::getId, Function.identity()));
    }


    /**
     * 计划-创意模板map，用来后续的mr数据的组装以及模板数据的渲染
     * 注意这里拿到的模板都是经过筛选的状态为有效的模板templateViewDTOMap
     * @param campaignTeplateMap
     * @param templateViewDTOMap
     * @return
     */
    public Map<Long, List<TemplateViewDTO>> buildCampaignCreativeTemplateMap(Map<Long, List<Long>> campaignTeplateMap, Map<Long, TemplateViewDTO> templateViewDTOMap) {
        Map<Long, List<TemplateViewDTO>> result = Maps.newHashMap();
        campaignTeplateMap.keySet().forEach(campaignId -> {
            List<Long> templateIds = campaignTeplateMap.get(campaignId);
            List<TemplateViewDTO> templateViewDTOList = templateIds.stream()
                    .filter(templateViewDTOMap::containsKey)
                    .map(templateViewDTOMap::get)
                    .collect(Collectors.toList());
            result.put(campaignId, templateViewDTOList);
        });
        return result;
    }

    /**
     * 全域通场景下，不能直接取计划上绑定的产品的全部模板，因为资源打包平台也会筛选模板
     * 全域通场景下，模板取自跨域二级产品的子产品，而一级计划因此取不到（跨域二级产品没有绑定模板），需要把二级计划的模板信息聚合到一级计划上，方便商家版查看（商家版只能看到一级计划）
     * 非全域通场景下，一级计划会带二级产品上的模板，而拆分到的二级计划也会复制一级计划上的信息，因此如果查模板可以直接查二级计划的模板
     * 这里的模板主要用来直接展示以及获取绑定的mr信息，商家客户主要看导出文档中的mr信息制作创意
     *
     * 此结果map仅用来做中间数据，不用来做后续的filter与render
     * @param campaignModelList
     * @return
     */
    public Map<Long, List<Long>> buildCampaignCreativeTemplateMap(ServiceContext serviceContext,List<CampaignViewDTO> campaignModelList,  Map<Long, CampaignTemplateViewDTO> initCampaignTemplateMap) {

        Map<Long, List<Long>> result = Maps.newHashMap();

        campaignModelList.forEach(campaignModel -> {
            List<Long> creativeTemplates = Optional.ofNullable(initCampaignTemplateMap.get(campaignModel.getId()))
                    .map(CampaignTemplateViewDTO::getTemplateIds)
                    .orElseGet(Lists::newArrayList);
            List<Long> creativeDirectTemplates = Optional.ofNullable(initCampaignTemplateMap.get(campaignModel.getId()))
                    .map(CampaignTemplateViewDTO::getDirectTemplateIds)
                    .orElseGet(Lists::newArrayList);
            List<Long> templateIds = new ArrayList<>();
            if(CollectionUtils.isNotEmpty(creativeDirectTemplates)){
                templateIds.addAll(creativeDirectTemplates);
            }
            if(CollectionUtils.isNotEmpty(creativeTemplates)){
                templateIds.addAll(creativeTemplates);
            }
            if(CollectionUtils.isEmpty(templateIds)) {
                return;
            }
            result.put(campaignModel.getId(), templateIds.stream().distinct().collect(Collectors.toList()));
        });

        // 全域通场景下需要将二级计划上绑定的模板信息聚合到一级计划供商家查看
        campaignModelList.stream()
                .filter(campaignViewDTO -> BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode().equals(campaignViewDTO.getCampaignLevel()))
                // 非全域通场景或者全域通场景使用跨域模板时，一级计划上会自带模板
                .filter(campaignViewDTO -> !initCampaignTemplateMap.containsKey(campaignViewDTO.getId()) ||
                        CollectionUtils.isEmpty(initCampaignTemplateMap.get(campaignViewDTO.getId()).getTemplateIds()))
                .filter(campaignViewDTO -> CollectionUtils.isNotEmpty(campaignViewDTO.getSubCampaignViewDTOList()))
                .forEach(campaignViewDTO -> {
                    Set<Long> templateListBySub = Sets.newHashSet();
                    campaignViewDTO.getSubCampaignViewDTOList()
                            .forEach(subCampaignViewDTO -> {
                                templateListBySub.addAll(result.getOrDefault(subCampaignViewDTO.getId(), Lists.newArrayList()));
                            });
                    // 更新一级计划的汇总
                    result.put(campaignViewDTO.getId(), Lists.newArrayList(templateListBySub));
                });
        return result;
    }

    /**
     * 产品线是 品牌定制时 取资源位上的mr
     * 超级全域通时，如果是跨域模板则取跨域模板上的mr，否则是分别取跨域二级产品子产品对应的模板上的mr，其中三环的还是从资源位取
     * @param campaignModelList
     * @param creativeTemplateMap
     * @param resourceDTOMap
     * @return
     */
    public Map<Long, Set<Long>> buildCampaignMaterialRuleMap(List<CampaignViewDTO> campaignModelList,Map<Long, List<TemplateViewDTO>> creativeTemplateMap, Map<Long, MediaResourceViewDTO> resourceDTOMap,
                                                                                                                                                                                                                                                                                                                                                                                                             Map<Long, ProductViewDTO> productDTOMap, Map<Long, Boolean> campaignHasCrossTemplate) {

        Map<Long, Set<Long>> result = Maps.newHashMap();

        campaignModelList.forEach(campaignModel -> {
            if(SaleProductLineEnum.UNIDESK_BRAND.getValue().equals(campaignModel.getCampaignSaleViewDTO().getSaleProductLine())
                    || SaleProductLineEnum.SMART_SCREEN.getValue().equals(campaignModel.getCampaignSaleViewDTO().getSaleProductLine())
                    || SaleProductLineEnum.SUPER_UNIVERSE.getValue().equals(campaignModel.getCampaignSaleViewDTO().getSaleProductLine())) {
                // 三环原生产品（二级产品的流量域 = 站外&二级产品对应的所属一级产品 = 站外原生产品）仍然按资源位拉取MR；
                // 三环衍生产品按二级产品中选择的创意模板中配置的MR拉取显示在客户下载排期表中。
                if(MediaScopeEnum.SITE_OUT.getCode().equals(campaignModel.getCampaignResourceViewDTO().getSspMediaScope())) {
                    if (BooleanEnum.TRUE.getValue().equals(productDTOMap.getOrDefault(campaignModel.getCampaignResourceViewDTO().getSspProductId(), new ProductViewDTO()).getOriginal())) {
                        result.put(campaignModel.getId(), getMrForThreeRound(campaignModel, resourceDTOMap));
                    } else {
                        result.put(campaignModel.getId(), getMrForTwoOrOneRound(campaignModel, creativeTemplateMap));
                    }
                }
                // 对于一二环的计划，mr取模板上的
                if(MediaScopeEnum.TAO_OUT.getCode().equals(campaignModel.getCampaignResourceViewDTO().getSspMediaScope()) || MediaScopeEnum.TAO_INNER.getCode().equals(campaignModel.getCampaignResourceViewDTO().getSspMediaScope())) {
                    result.put(campaignModel.getId(), getMrForTwoOrOneRound(campaignModel, creativeTemplateMap));
                }
                // 跨域一级计划取子计划的mr合并
                if(MediaScopeEnum.CROSS_SCOPE.getCode().equals(campaignModel.getCampaignResourceViewDTO().getSspMediaScope()) && BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode().equals(campaignModel.getCampaignLevel())) {
                    Set<Long> mrIdSet = Sets.newHashSet();
                    // 如果当前跨域一级计划使用的跨域模板，则直接取跨域模板的mr，不用再找二级计划的mr做聚合
                    if(campaignHasCrossTemplate.getOrDefault(campaignModel.getId(), false)) {
                        mrIdSet = getMrForTwoOrOneRound(campaignModel, creativeTemplateMap);
                        result.put(campaignModel.getId(), mrIdSet);
                        return;
                    }
                    if(CollectionUtils.isNotEmpty(campaignModel.getSubCampaignViewDTOList())) {
                        mrIdSet = campaignModel.getSubCampaignViewDTOList().stream().flatMap(subCampaignViewDTO -> {
                            if(MediaScopeEnum.SITE_OUT.getCode().equals(subCampaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope())) {
                                if (BooleanEnum.TRUE.getValue().equals(productDTOMap.getOrDefault(campaignModel.getCampaignResourceViewDTO().getSspProductId(), new ProductViewDTO()).getOriginal())) {
                                    return getMrForThreeRound(subCampaignViewDTO, resourceDTOMap).stream();
                                } else {
                                    return getMrForTwoOrOneRound(subCampaignViewDTO, creativeTemplateMap).stream();
                                }
                            }
                            return getMrForTwoOrOneRound(subCampaignViewDTO, creativeTemplateMap).stream();
                        }).collect(Collectors.toSet());
                    }
                    result.put(campaignModel.getId(), mrIdSet);
                }
            } else {
                result.put(campaignModel.getId(), getMrForTwoOrOneRound(campaignModel, creativeTemplateMap));
            }
        });
        return result;
    }

    /**
     * 注意会过滤掉无效或者是删除的模板
     * @param serviceContext
     * @param campaignModelList
     * @return
     */
    public Map<Long, TemplateViewDTO> buildTemplateViewDTOMap (ServiceContext serviceContext, List<CampaignViewDTO> campaignModelList, Map<Long, List<Long>> campaignTeplateMap) {
        List<Long> templateIds = new ArrayList<>();
        if(CollectionUtils.isNotEmpty(campaignModelList)){
            for (CampaignViewDTO campaignViewDTO : campaignModelList){
                List<Long> ids = campaignTeplateMap.get(campaignViewDTO.getId());
                if(CollectionUtils.isNotEmpty(ids)){
                    templateIds.addAll(ids);
                }
            }
        }
        List<TemplateViewDTO> templateList = Lists.newArrayList();
        // 查询模板时需要过滤配置的模板白名单，目前仅特秀
        if(CollectionUtils.isNotEmpty(templateIds)) {
            CreativeTemplateQueryDTO templateQueryDTO = new CreativeTemplateQueryDTO();
            templateQueryDTO.setTemplateIdList(templateIds.stream().distinct().collect(Collectors.toList()));
            templateQueryDTO.setNeedSetting(true);
            String creativeWhiteList = creativeTemplatesWhiteListDiamondConfig.getTemplatesWhiteList();
            if (StringUtils.isNotBlank(creativeWhiteList)) {
                List<Long> unHavePermissionTemplateIds = unHaveRoleTemplateList(serviceContext, creativeWhiteList);
                if (CollectionUtils.isNotEmpty(unHavePermissionTemplateIds)) {
                    templateQueryDTO.setExcludeTemplateIdList(unHavePermissionTemplateIds);
                }
                RogerLogger.info("unHavePermissionTemplateIds={}", JSONArray.toJSONString(unHavePermissionTemplateIds));
            }
            templateList = creativeTemplateRepository.getTemplateList(serviceContext, templateQueryDTO);
        }
        // 此处过滤掉无效或者是删除的模板
        return templateList.stream()
                .filter(templateViewDTO -> TemplateStatusEnum.VALID.value().equals(templateViewDTO.getStatus()))
                .collect(Collectors.toMap((TemplateViewDTO::getId), Function.identity(), (k1, k2) -> k1));
    }

    /**
     * 跨域计划是否使用了跨域模板
     * @return
     */
    public Map<Long, Boolean> buildCampaignHasCrossTemplate(List<CampaignViewDTO> campaignModelList, Map<Long, TemplateViewDTO> templateViewDTOMap, Map<Long, CampaignTemplateViewDTO> initCampaignTemplateMap) {
        Map<Long, Boolean> result = Maps.newHashMap();
        campaignModelList.stream()
                .filter(campaign -> MediaScopeEnum.CROSS_SCOPE.getCode().equals(campaign.getCampaignResourceViewDTO().getSspMediaScope()))
                .forEach(campaignViewDTO -> {
                    result.put(campaignViewDTO.getId(), hasCrossTemplate(campaignViewDTO, templateViewDTOMap, initCampaignTemplateMap));
                });
        return result;
    }

    /**
     * 过滤模板白名单的相关代码copy子站点包
     * com.alibaba.ad.product.brandOneBP.site.service.creative.CreativeControllerImpl#unHaveRoleTemplateList
     * @param serviceContext
     * @param creativeWhiteList
     * @return
     */
    private List<Long> unHaveRoleTemplateList(ServiceContext serviceContext, String creativeWhiteList) {
        List<Long> result = Lists.newArrayList();
        String[] templateIdAll = StringUtils.split(creativeWhiteList, ",");
        List<Long> templateIdAllList = Arrays.stream(templateIdAll).filter(item -> StringUtils.isNotBlank(item)).map(item -> Long.parseLong(item)).collect(Collectors.toList());
        if (org.apache.commons.collections4.CollectionUtils.isEmpty(templateIdAllList)) {
            return result;
        }
        AdcQueryViewDTO adcQueryViewDTO = new AdcQueryViewDTO();
        adcQueryViewDTO.setComponentCode("creative_template_white_code");
        adcQueryViewDTO.setBizCode(serviceContext.getBizCode());
        List<AdcComponentViewDTO> adcComponentViewDTOS = adcRepository.findComponentList(serviceContext, adcQueryViewDTO);
        List<Long> templateIds = Lists.newArrayList();
        for (AdcComponentViewDTO adcComponentViewDTO : adcComponentViewDTOS) {
            templateIds.addAll(getTemplateIdList(adcComponentViewDTO));
        }
        Set<Long> resultTemp = Sets.newHashSet();
        resultTemp.addAll(templateIdAllList);
        resultTemp.removeAll(templateIds);
        result.addAll(resultTemp);
        return result;
    }

    private List<Long> getTemplateIdList(AdcComponentViewDTO adcComponentViewDTO) {
        List<Long> templateIds = Lists.newArrayList();
        templateIds.addAll(getTemplateIds(adcComponentViewDTO.getProperties()));
        if (org.apache.commons.collections4.CollectionUtils.isEmpty(adcComponentViewDTO.getSubComponentList())) {
            return templateIds;
        }
        for (AdcComponentViewDTO sub : adcComponentViewDTO.getSubComponentList()) {
            List<Long> idList = getTemplateIds(sub.getProperties());
            if (org.apache.commons.collections4.CollectionUtils.isEmpty(idList)) {
                continue;
            }
            templateIds.addAll(idList);
            templateIds.addAll(getTemplateIdList(sub));
        }
        return templateIds;
    }

    private List<Long> getTemplateIds(Map<String, Object> properties) {
        if (MapUtils.isNotEmpty(properties) && properties.containsKey("template_ids")) {
            Object value = properties.get("template_ids");
            if (value == null) {
                return Lists.newArrayList();
            }
            String valueList = value.toString();
            if (StringUtils.isBlank(valueList)) {
                return Lists.newArrayList();
            }
            String[] ids = StringUtils.split(valueList, ",");
            List<Long> idList = Arrays.stream(ids).filter(item -> StringUtils.isNotBlank(item)).map(item -> Long.parseLong(item)).collect(Collectors.toList());
            return idList;
        }
        return Lists.newArrayList();
    }



    /**
     * 判断跨域一级计划是否使用了跨域模板，注意如果使用的跨域模板失效了的话，会被视为没有使用跨域模板
     * @param campaignViewDTO
     * @param templateViewDTOMap
     * @return
     */
    private Boolean hasCrossTemplate(CampaignViewDTO campaignViewDTO, Map<Long, TemplateViewDTO> templateViewDTOMap, Map<Long, CampaignTemplateViewDTO> initCampaignTemplateMap) {
        return Optional.ofNullable(initCampaignTemplateMap.get(campaignViewDTO.getId()))
                .map(CampaignTemplateViewDTO::getTemplateIds)
                .map(templateIds -> {
                    if(CollectionUtils.isEmpty(templateIds)) {
                        return false;
                    }
                    return templateIds.stream().anyMatch(templateId ->
                            Optional.ofNullable(templateViewDTOMap.get(templateId)).map(templateViewDTO -> MediaScopeEnum.CROSS_SCOPE.getCode().equals(templateViewDTO.getMediaScope())).orElse(false));
                }).orElse(false);
    }

    private Set<Long> getMrForThreeRound(CampaignViewDTO campaignViewDTO, Map<Long, MediaResourceViewDTO> resourceDTOMap) {
        Set<Long> result = Sets.newHashSet();
        Long sspResourceId = campaignViewDTO.getCampaignResourceViewDTO().getSspResourceIds().get(0);
        if(resourceDTOMap.containsKey(sspResourceId)) {
            MediaResourceViewDTO mediaResourceViewDTO = resourceDTOMap.get(sspResourceId);
            String materialRuleIds = mediaResourceViewDTO.getMaterialRuleIds();
            return StringUtils.isNotBlank(materialRuleIds) ? Arrays.stream(materialRuleIds.split(Constant.CHAR_SPLIT_KEY_DOT)).map(Long::parseLong).collect(Collectors.toSet()) : Sets.newHashSet();
        }
        return result;
    }

    private Set<Long> getMrForTwoOrOneRound(CampaignViewDTO campaignViewDTO, Map<Long, List<TemplateViewDTO>> creativeTemplateMap) {
        List<TemplateViewDTO> templateDTOList = Optional.ofNullable(creativeTemplateMap.get(campaignViewDTO.getId())).orElse(Lists.newArrayList());

        // 汇总模板的所有MR
        List<CommonViewDTO> materialRuleDTOList = templateDTOList.stream()
                .map(TemplateViewDTO::getMaterialRuleList)
                .filter(CollectionUtils::isNotEmpty)
                .reduce(new ArrayList<>(), (list, mrList) -> {
                    list.addAll(mrList);
                    return list;
                });

        return materialRuleDTOList.stream().map(CommonViewDTO::getId).collect(Collectors.toSet());
    }
}
