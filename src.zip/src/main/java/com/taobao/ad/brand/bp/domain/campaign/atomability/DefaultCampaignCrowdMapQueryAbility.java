package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignCrowdMapQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignCrowdMapQueryAbility;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Component
@BusinessAbility
public class DefaultCampaignCrowdMapQueryAbility implements ICampaignCrowdMapQueryAbility {

    @Resource
    private CampaignRepository campaignRepository;

    @Override
    public Map<Long, CampaignViewDTO> handle(ServiceContext serviceContext, CampaignCrowdMapQueryAbilityParam abilityParam) {
        List<Long> campaignIds = abilityParam.getAbilityTargets();
        if (CollectionUtils.isEmpty(campaignIds)) {
            return null;
        }
        return campaignRepository.getCampaignTarget(serviceContext, campaignIds);
    }
}
