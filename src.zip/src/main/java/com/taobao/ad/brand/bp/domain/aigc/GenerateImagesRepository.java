package com.taobao.ad.brand.bp.domain.aigc;

import com.alibaba.aladdin.lamp.domain.response.GeneralItem;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

/**
 * @Author: PhilipFry
 * @createTime: 2025年01月09日 21:47:14
 * @Description:
 */
public interface GenerateImagesRepository {

    Object getMagicTemplate(Long itemId, Integer width, Integer height);

    GeneralItem getItem(Long itemId);

    List<String> creativeImage(HashMap<String, String> params);
}
