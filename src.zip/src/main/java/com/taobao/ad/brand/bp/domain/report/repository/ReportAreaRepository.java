package com.taobao.ad.brand.bp.domain.report.repository;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.client.dto.report.ReportAreaViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.query.ReportAreaQueryViewDTO;

import java.util.List;

/**
 * 报表获取省市信息
 */
public interface ReportAreaRepository {

    /**
     * 查询地域信息 - 国家、省、市
     */
    List<ReportAreaViewDTO> queryReportAreaList(ServiceContext context, ReportAreaQueryViewDTO queryViewDTO);
}
