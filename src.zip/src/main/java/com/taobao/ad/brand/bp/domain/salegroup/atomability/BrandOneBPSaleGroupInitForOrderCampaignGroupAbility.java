package com.taobao.ad.brand.bp.domain.salegroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupOrderAbilityParam;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
@BusinessAbility
public class BrandOneBPSaleGroupInitForOrderCampaignGroupAbility
        extends DefaultSaleGroupInitForOrderCampaignGroupAbility implements BrandOneBPAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, SaleGroupOrderAbilityParam abilityParam) {
        CampaignGroupViewDTO mainCampaignGroup = abilityParam.getCampaignGroupViewDTO();
        Map<Long, SaleGroupInfoViewDTO> subSaleGroupInfoViewDTOMap = abilityParam.getSubCampaignGroupList().stream().flatMap(t -> t.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream())
                .collect(Collectors.toMap(SaleGroupInfoViewDTO::getSaleGroupId, Function.identity()));

        List<SaleGroupInfoViewDTO> mainSaleGroupInfoList = mainCampaignGroup.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList();
        List<SaleGroupInfoViewDTO> mergedMainSaleGroupInfoList = Lists.newArrayList();
        for (SaleGroupInfoViewDTO mainSaleGroup : mainSaleGroupInfoList) {
            SaleGroupInfoViewDTO subSaleGroup = subSaleGroupInfoViewDTOMap.get(mainSaleGroup.getSaleGroupId());
            if (subSaleGroup == null) {
                mergedMainSaleGroupInfoList.add(mainSaleGroup);
                continue;
            }
            // 仅状态更新时再同步
            if (mainSaleGroup.getSaleGroupStatus().equals(subSaleGroup.getSaleGroupStatus())) {
                mergedMainSaleGroupInfoList.add(mainSaleGroup);
            } else {
                subSaleGroup.setId(null);
                subSaleGroup.setCampaignGroupId(mainCampaignGroup.getId());
                mergedMainSaleGroupInfoList.add(subSaleGroup);
            }
        }
        mainCampaignGroup.getCampaignGroupSaleGroupViewDTO().setSaleGroupInfoViewDTOList(mergedMainSaleGroupInfoList);

        return null;
    }
}
