package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.taobao.ad.brand.bp.client.enums.SwitchEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignValidateForSwitchCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignValidateForSwitchCampaignAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSelfCampaignValidateForSwitchCampaignAbility implements ICampaignValidateForSwitchCampaignAbility, BrandSelfServiceAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignValidateForSwitchCampaignAbilityParam abilityParam) {
        CampaignViewDTO campaignViewTreeDTO = abilityParam.getCampaignViewDTO();
        List<CampaignViewDTO> operateList = abilityParam.getAbilityTargets();
        SwitchEnum switchEnum = abilityParam.getSwitchEnum();
        for(CampaignViewDTO operatorViewDTO : operateList){
            if(BrandDateUtil.isBefore(operatorViewDTO.getEndTime(), BrandDateUtil.getCurrentDate())){
                continue;
            }
            if (switchEnum.equals(SwitchEnum.CLOSE)) {
                AssertUtil.assertTrue(BrandCampaignStatusEnum.CASTING.getCode()
                                .equals(operatorViewDTO.getStatus()) || BrandCampaignStatusEnum.WAITING.getCode()
                                .equals(operatorViewDTO.getStatus()),
                        BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR, "只有等待推广和正在推广可以关闭");
            }
            // 开启
            if (switchEnum.equals(SwitchEnum.OPEN)) {
                AssertUtil.assertTrue(BrandCampaignStatusEnum.PAUSING.getCode()
                                .equals(operatorViewDTO.getStatus()),
                        BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR, "只有暂停推广可以开启");
            }
            Optional<CampaignViewDTO> optional = operateList.stream().filter(item->item.getId().equals(campaignViewTreeDTO.getId())).findAny();
            //一级计划暂停,二级计划不能单独开启
            if(!optional.isPresent()){
                if (BrandCampaignLevelEnum.LEVEL_TWO_CAMPAIGN.getCode().equals(operatorViewDTO.getCampaignLevel())
                        && switchEnum.equals(SwitchEnum.OPEN)) {
                    AssertUtil.assertTrue(!BrandCampaignStatusEnum.PAUSING.getCode().equals(campaignViewTreeDTO.getStatus()),
                            BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR, "二级计划不能单独开启");
                }
            }
        }
        return null;
    }
}
