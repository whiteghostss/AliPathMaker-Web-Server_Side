package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.price.CampaignPriceViewDTO;
import com.alibaba.ad.brand.dto.campaign.price.DayPriceViewDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.EffectAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignPriceInitForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignPriceAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EffectCampaignPriceInitForUpdateCampaignAbility implements ICampaignPriceInitForUpdateCampaignAbility, EffectAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignPriceAbilityParam abilityParam) {
        CampaignPriceViewDTO campaignPriceViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        ResourcePackageProductViewDTO resourcePackageProductViewDTO = abilityParam.getResourcePackageProductViewDTO();
        AssertUtil.notNull(campaignPriceViewDTO, "计划单价信息不能为空");
        AssertUtil.notNull(dbCampaignViewDTO, "计划不存在");
        AssertUtil.notNull(resourcePackageProductViewDTO, "资源产品不能为空");

        CampaignPriceViewDTO dbCampaignPriceViewDTO = Optional.ofNullable(dbCampaignViewDTO.getCampaignPriceViewDTO()).orElse(new CampaignPriceViewDTO());
        campaignPriceViewDTO.setPublishProductId(dbCampaignPriceViewDTO.getPublishProductId());
        campaignPriceViewDTO.setPublishPriceInfoList(dbCampaignPriceViewDTO.getPublishPriceInfoList());
        campaignPriceViewDTO.setDiscountPriceInfoList(dbCampaignPriceViewDTO.getDiscountPriceInfoList());
        campaignPriceViewDTO.setSettlePrice(dbCampaignPriceViewDTO.getSettlePrice());

        //价格信息
        List<ResourcePackageProductPriceViewDTO> bandPriceList = resourcePackageProductViewDTO.getBandPriceList();
        if(CollectionUtils.isNotEmpty(bandPriceList)){
            //内容没有多波段，只取一个
            ResourcePackageProductPriceViewDTO resourcePackageProductPriceViewDTO = bandPriceList.get(0);
            //刊例单价
            DayPriceViewDTO dayPriceViewDTO = new DayPriceViewDTO();
            dayPriceViewDTO.setPrice(resourcePackageProductPriceViewDTO.getPublishPrice());
            dayPriceViewDTO.setStartDate(resourcePackageProductPriceViewDTO.getStartDate());
            dayPriceViewDTO.setEndDate(resourcePackageProductPriceViewDTO.getEndDate());
            //折扣比例
            dayPriceViewDTO.setDiscountRatio(resourcePackageProductPriceViewDTO.getPriceRatio());
            //刊例单价
            campaignPriceViewDTO.setPublishPriceInfoList(Lists.newArrayList(dayPriceViewDTO));
            //折后单价
            campaignPriceViewDTO.setDiscountPriceInfoList(Lists.newArrayList(dayPriceViewDTO));
            //区间折后价，只有一个区间
            campaignPriceViewDTO.setSettlePrice(resourcePackageProductPriceViewDTO.getPrice());
        }
        return null;
    }
}
