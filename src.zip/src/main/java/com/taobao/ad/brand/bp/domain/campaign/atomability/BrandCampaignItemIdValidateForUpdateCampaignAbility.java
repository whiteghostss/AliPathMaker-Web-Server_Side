package com.taobao.ad.brand.bp.domain.campaign.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignItemIdValidateForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignUpdateAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_ILLEGAL;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandCampaignItemIdValidateForUpdateCampaignAbility implements ICampaignItemIdValidateForUpdateCampaignAbility, BrandAtomAbilityRouter {

    @Override
    public Void handle(ServiceContext serviceContext, CampaignUpdateAbilityParam abilityParam) {
        CampaignViewDTO campaignViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO dbCampaignViewDTO = abilityParam.getDbCampaignViewDTO();
        AssertUtil.notNull(campaignViewDTO,"计划不允许为空");
        AssertUtil.notNull(dbCampaignViewDTO,"计划不存在");

        String itemIds = "";
        String dbItemIds = "";
        if(CollectionUtils.isNotEmpty(campaignViewDTO.getCampaignTargetScenarioViewDTO().getItemIdList())){
            itemIds = campaignViewDTO.getCampaignTargetScenarioViewDTO().getItemIdList().stream().sorted().map(String::valueOf).collect(Collectors.joining(","));
        }
        if(CollectionUtils.isNotEmpty(dbCampaignViewDTO.getCampaignTargetScenarioViewDTO().getItemIdList())){
            dbItemIds = dbCampaignViewDTO.getCampaignTargetScenarioViewDTO().getItemIdList().stream().sorted().map(String::valueOf).collect(Collectors.joining(","));
        }
        AssertUtil.assertTrue((StringUtils.isEmpty(itemIds) && StringUtils.isEmpty(dbItemIds))
                        || (StringUtils.isNotEmpty(dbItemIds) && dbItemIds.equals(itemIds)),
                PARAM_ILLEGAL, "计划进入投放期，或计划在锁量中、锁量成功、待投放、投放中、投放结束、投放暂停状态，宝贝不能修改");

        return null;
    }
}
