package com.taobao.ad.brand.bp.domain.adgroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.adgroup.CreativeRefViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativeTargetTypeEnum;
import com.alibaba.ad.nb.ssp.constant.common.CrossSceneEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeQueryViewDTO;
import com.taobao.ad.brand.bp.domain.adgroup.repository.AdgroupRepository;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeRepository;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupUpdateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Component
@BusinessAbility
public class BrandSelfAdgroupUpdateAbility implements IAdgroupUpdateAbility, BrandSelfServiceAtomAbilityRouter {

    @Resource
    private  CreativeRepository creativeRepository;
    @Resource
    private  AdgroupRepository adgroupRepository;
    @Override
    public Long handle(ServiceContext context, AdgroupUpdateAbilityParam abilityParam) {
        AdgroupViewDTO adgroupViewDTO = abilityParam.getAbilityTarget();
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();
        adgroupRepository.updateAdgroup(context,adgroupViewDTO);
        rebuildCreativeRef(context, adgroupViewDTO, campaignViewDTO);
        adgroupRepository.updateCreativeRef(context,adgroupViewDTO);
        return adgroupViewDTO.getId();
    }

    private void rebuildCreativeRef(ServiceContext context, AdgroupViewDTO adgroupViewDTO,
                                    CampaignViewDTO campaignViewDTO) {
        //黑盒全域通场景程序化单元下绑定有非精准创意
        if(Objects.equals(CrossSceneEnum.CROSS_OPAQUE_SCENE.getValue(), campaignViewDTO.getCampaignResourceViewDTO().getSspCrossScene())){
            if(CollectionUtils.isNotEmpty(adgroupViewDTO.getCreativeRefViewDTOList())){
                //全域通场景绑定的是一级创意，根据一级创意，返回对应的打底创意
                Set<Long> bindCreativeIds = adgroupViewDTO.getCreativeRefViewDTOList().stream().map(CreativeRefViewDTO::getCreativeId).collect(Collectors.toSet());
                CreativeQueryViewDTO creativeQueryViewDTO = new CreativeQueryViewDTO();
                creativeQueryViewDTO.setAdgroupIds(Lists.newArrayList(adgroupViewDTO.getId()));
                List<CreativeRefViewDTO> creativeRefList = creativeRepository.findCreativeRefList(context, creativeQueryViewDTO);
                if(CollectionUtils.isNotEmpty(creativeRefList)){
                    List<CreativeViewDTO> creativeViewDTOList = creativeRepository.findCreativeByIds(context,
                            creativeRefList.stream().map(CreativeRefViewDTO::getCreativeId).distinct().collect(Collectors.toList()));
                    List<Long> directCreativeIdList = Optional.ofNullable(creativeViewDTOList).orElse(Lists.newArrayList()).stream()
                            .filter(creativeViewDTO -> Objects.equals(BrandCreativeTargetTypeEnum.DIRECT.getCode(), creativeViewDTO.getTargetType()))
                            .filter(creativeViewDTO -> bindCreativeIds.contains(creativeViewDTO.getCreativePackageId()))
                            .map(CreativeViewDTO::getId).collect(Collectors.toList());
                    if(CollectionUtils.isNotEmpty(directCreativeIdList)){
                        List<CreativeRefViewDTO> directCreativeRefList = creativeRefList.stream()
                                .filter(creativeRefViewDTO -> directCreativeIdList.contains(creativeRefViewDTO.getCreativeId()))
                                .collect(Collectors.toList());
                        adgroupViewDTO.getCreativeRefViewDTOList().addAll(directCreativeRefList);
                    }
                }
            }
        }
    }
}
