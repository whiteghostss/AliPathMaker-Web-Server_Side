package com.taobao.ad.brand.bp.domain.config;

import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.DeliveryTargetDiamondConfigViewDTO;
import com.taobao.ad.brand.bp.domain.config.base.BaseDiamondConfig;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 交付指标配置
 * For测试
 * */
@Component
public class DeliveryTargetDiamondConfig extends BaseDiamondConfig {
    private static volatile List<DeliveryTargetDiamondConfigViewDTO> deliveryTargetDiamondConfigViewDTOList;


    @Override
    protected String getDataId() {
        return "deliveryTarget.config";
    }
    @Override
    protected String getGroupId() { return "com.taobao.ad.brand.bp"; }

    @Override
    protected void initDiamond(String diamondConfig) {
        RogerLogger.info("DiamondConfig.initDiamond DeliveryTargetDiamondConfig param: {}", diamondConfig);
        if (StringUtils.isNotBlank(diamondConfig)) {
            deliveryTargetDiamondConfigViewDTOList = JSON.parseArray(diamondConfig, DeliveryTargetDiamondConfigViewDTO.class);
        } else {
            deliveryTargetDiamondConfigViewDTOList = Lists.newArrayList();
        }
    }

    /**
     * 获取交付指标配置
     * @return
     */
    public List<DeliveryTargetDiamondConfigViewDTO> getDeliveryTargetDiamondConfigList() {
        return deliveryTargetDiamondConfigViewDTOList;
    }

}
