package com.taobao.ad.brand.bp.domain.adgroup.workflow;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.adgroup.CreativeRefViewDTO;
import com.alibaba.ad.brand.dto.adgroup.monitor.AdgroupMonitorViewDTO;
import com.alibaba.ad.brand.dto.adgroup.resource.AdgroupResourceViewDTO;
import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.creative.ContentVersionViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativeTargetTypeEnum;
import com.alibaba.ad.nb.ssp.constant.common.CrossSceneEnum;
import com.alibaba.ad.nb.ssp.constant.common.MediaScopeEnum;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.adgroup.ExportMonitorCodeViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignBottomInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.differ.Differs;
import com.taobao.ad.brand.bp.domain.adgroup.ability.BizAdgroupMonitorAbility;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeRepository;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.workflow.param.BizAdgroupMonitorWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.base.workflow.router.BrandExtensionRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.inventory.ICampaignInventoryBottomGetAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignInventoryBottomGetAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Description:品牌场景监测业务流程扩展
 * <p>
 * date: 2023/10/24 2:51 PM
 *
 * @author shiyan
 * @version 1.0
 */
@Service
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandAdgroupMonitorWorkflowExtImpl extends DefaultAdgroupMonitorWorkflowExtImpl implements BrandExtensionRouter {

    private final BizAdgroupMonitorAbility bizAdgroupMonitorAbility;
    private final CampaignGroupRepository campaignGroupRepository;
    private final CreativeRepository creativeRepository;
    private final ICampaignStructureQueryAbility campaignStructureQueryAbility;
    private final ICampaignInventoryBottomGetAbility campaignInventoryBottomGetAbility;

    @Override
    public boolean supportChecking(String bizCode, BaseViewDTO baseViewDTO) {
        return BrandExtensionRouter.super.supportChecking(bizCode, baseViewDTO)
                || BizCodeEnum.SELFSERVICEAD.getBizCode().equals(bizCode);
    }

    @Override
    public BizAdgroupMonitorWorkflowParam buildParamForMonitor(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO) {
        //创意查询
        List<Long> creativeIdList = adgroupViewDTO.getCreativeRefViewDTOList().stream().map(CreativeRefViewDTO::getCreativeId).distinct().collect(Collectors.toList());
        List<CreativeViewDTO> creativeViewDTOList = creativeRepository.findCreativeByIds(serviceContext, creativeIdList);
        creativeViewDTOList = Optional.ofNullable(creativeViewDTOList).orElse(Lists.newArrayList()).stream()
                .filter(creativeViewDTO -> BrandCreativeTargetTypeEnum.DIRECT.getCode().equals(creativeViewDTO.getTargetType()))
                .collect(Collectors.toList());
        AssertUtil.notEmpty(creativeViewDTOList,"单元未关联媒体直投创意");

        //查询订单
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(serviceContext, adgroupViewDTO.getCampaignGroupId());
        AssertUtil.notNull(campaignGroupViewDTO,"订单查询不存在");

        //单元关联的是一级计划id
        CampaignQueryOption campaignQueryOption = CampaignQueryOption.builder().needChildren(true).needTarget(true).build();
        CampaignViewDTO campaignTreeViewDTO = this.getCampaignInfoByOption(serviceContext, adgroupViewDTO.getCampaignId(), campaignQueryOption);
        AssertUtil.assertTrue(campaignTreeViewDTO != null && CollectionUtils.isNotEmpty(campaignTreeViewDTO.getSubCampaignViewDTOList()),"计划查询不存在");

        //查询三环库存二级计划打底信息
        List<Long> subCampaignIdList = campaignTreeViewDTO.getSubCampaignViewDTOList().stream()
                .filter(subCampaignViewDTO -> Objects.equals(subCampaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope(), MediaScopeEnum.SITE_OUT.getCode()))
                .map(CampaignViewDTO::getId).collect(Collectors.toList());

        List<CampaignBottomInfoViewDTO> campaignBottomViewDTOList = campaignInventoryBottomGetAbility.handle(serviceContext,
                CampaignInventoryBottomGetAbilityParam.builder().abilityTargets(subCampaignIdList).build());
        AssertUtil.notEmpty(campaignBottomViewDTOList,"计划打底日期不存在");

        BizAdgroupMonitorWorkflowParam workflowParam = BizAdgroupMonitorWorkflowParam.builder()
                .adgroupViewDTO(adgroupViewDTO)
                .campaignTreeViewDTO(campaignTreeViewDTO)
                .campaignGroupViewDTO(campaignGroupViewDTO)
                .campaignBottomViewDTOList(campaignBottomViewDTOList)
                .creativeViewDTOList(creativeViewDTOList)
                .build();
        return workflowParam;
    }

    @Override
    public Void sendAdgroupMonitorEmail(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, ContentVersionViewDTO contentVersionViewDTO, List<ExportMonitorCodeViewDTO> monitorCodeViewDTOList) {
        //跨域单元按照子计划发送监测创意
        Integer sspCrossScene = Optional.ofNullable(adgroupViewDTO.getAdgroupResourceViewDTO()).map(AdgroupResourceViewDTO::getSspCrossScene).orElse(null);
        if(Objects.equals(CrossSceneEnum.CROSS_OPAQUE_SCENE.getValue(),sspCrossScene)){
            Map<Long, List<ExportMonitorCodeViewDTO>> subCampaignMonitorCodeList =
                    monitorCodeViewDTOList.stream().collect(Collectors.groupingBy(ExportMonitorCodeViewDTO::getSubCampaignId));
            for (Map.Entry<Long, List<ExportMonitorCodeViewDTO>> subCampaignEntry : subCampaignMonitorCodeList.entrySet()) {
                Long subCampaignId = subCampaignEntry.getKey();
                String fileName = String.format("%s_%s_%s_监测代码.xlsx", subCampaignId,adgroupViewDTO.getTitle(),System.currentTimeMillis()+"");
                String cdnUrl = bizAdgroupMonitorAbility.getMonitorDownloadCdnUrl(serviceContext, fileName, subCampaignEntry.getValue());
                bizAdgroupMonitorAbility.sendEmail(serviceContext, adgroupViewDTO, subCampaignEntry.getValue(), cdnUrl, contentVersionViewDTO.getId(),subCampaignId);
            }
        }else{
            String fileName = String.format("%s_%s_监测代码.xlsx",adgroupViewDTO.getTitle(),System.currentTimeMillis()+"");
            String cdnUrl = bizAdgroupMonitorAbility.getMonitorDownloadCdnUrl(serviceContext, fileName, monitorCodeViewDTOList);
            bizAdgroupMonitorAbility.sendEmail(serviceContext, adgroupViewDTO, monitorCodeViewDTOList, cdnUrl, contentVersionViewDTO.getId(),null);
        }
        return null;
    }
    /**
     * 单元监测-发送监测邮件
     * @param serviceContext
     * @param adgroupViewDTO
     * @param monitorCodeViewDTOList
     * @return
     */
    @Override
    public List<Long> getNeedToSendEmailSubCampaignIds(ServiceContext serviceContext,AdgroupViewDTO adgroupViewDTO, List<ExportMonitorCodeViewDTO> monitorCodeViewDTOList){
        Integer sspCrossScene = Optional.ofNullable(adgroupViewDTO.getAdgroupResourceViewDTO()).map(AdgroupResourceViewDTO::getSspCrossScene).orElse(null);
        if (!Objects.equals(sspCrossScene, CrossSceneEnum.CROSS_OPAQUE_SCENE.getValue())){
            return monitorCodeViewDTOList.stream().map(ExportMonitorCodeViewDTO::getSubCampaignId).distinct().collect(Collectors.toList());
        }
        AdgroupMonitorViewDTO adgroupMonitorViewDTO = Optional.ofNullable(adgroupViewDTO.getAdgroupMonitorViewDTO()).orElse(new AdgroupMonitorViewDTO());
        if (Objects.isNull(adgroupMonitorViewDTO.getMonitorContentId())){
            return monitorCodeViewDTOList.stream().map(ExportMonitorCodeViewDTO::getSubCampaignId).collect(Collectors.toList());
        }
        if (Objects.isNull(adgroupMonitorViewDTO.getLastSendTime())){
            return monitorCodeViewDTOList.stream().map(ExportMonitorCodeViewDTO::getSubCampaignId).collect(Collectors.toList());
        }
        ContentVersionViewDTO contentVersionViewDTO = creativeRepository.getLastContentVersionByContentId(serviceContext, adgroupMonitorViewDTO.getMonitorContentId());
        if (Objects.isNull(contentVersionViewDTO)){
            return monitorCodeViewDTOList.stream().map(ExportMonitorCodeViewDTO::getSubCampaignId).collect(Collectors.toList());
        }
        if (StringUtils.isBlank(contentVersionViewDTO.getContent())) {
            return monitorCodeViewDTOList.stream().map(ExportMonitorCodeViewDTO::getSubCampaignId).collect(Collectors.toList());
        }
        List<Long> resultSubCampaignIds = Lists.newArrayList();
        //数据库里存的
        List<ExportMonitorCodeViewDTO> dbExportMonitorCodeViewDTOList = JSONObject.parseArray(contentVersionViewDTO.getContent(), ExportMonitorCodeViewDTO.class);
//        exportMonitorCodeViewDTOList.forEach(exportMonitorCodeViewDTO -> exportMonitorCodeViewDTO.setLandingPage(exportMonitorCodeViewDTO.getLandingUrl()));
        Map<Long,List<ExportMonitorCodeViewDTO>> dbExportMonitorCodeViewDTOMap =
                dbExportMonitorCodeViewDTOList.stream().collect(Collectors.groupingBy(ExportMonitorCodeViewDTO::getSubCampaignId,Collectors.toList()));

        //刚刚生成的
        Map<Long,List<ExportMonitorCodeViewDTO>> exportMonitorCodeViewDTOMap =
                monitorCodeViewDTOList.stream().collect(Collectors.groupingBy(ExportMonitorCodeViewDTO::getSubCampaignId,Collectors.toList()));
        //比对出子计划有变更的
        //1. 若在db里，则需要比对 比对db里和刚刚生成的有重复的计划关联的创意、adzoneId、
        //1. 若不在db里则直接需要发送
        exportMonitorCodeViewDTOMap.forEach((key, value) -> {
            if (dbExportMonitorCodeViewDTOMap.containsKey(key)){
                List<ExportMonitorCodeViewDTO> dbList = dbExportMonitorCodeViewDTOMap.get(key);
                boolean compareResult = compareDiff(value,dbList);
                if (compareResult){
                    resultSubCampaignIds.add(key);
                }
            }else {
                resultSubCampaignIds.add(key);
            }
        });
        return resultSubCampaignIds;
    }
    /**
     * 监测比对
     * 1. 两个参数都是同一个子计划关联的信息
     * 2. 比对创意ID是否有变化
     * 2.1 若创意ID无变化 则比对deep 和ulk是否有变化
     * 2.3 若创意ID有变化 则无需比对deep和ulk是否有变化
     * 3. 比对azoneId是否有变化
     * 4. 比对资源位ID是否有变化
     * 5. 比对deep是否有变化
     * return 有变化返回true
     * */
    private boolean compareDiff(List<ExportMonitorCodeViewDTO> monitorCodeViewDTOList, List<ExportMonitorCodeViewDTO> dbExportMonitorCodeViewDTOList) {
        //数据条数不一致，则不一致
        if(monitorCodeViewDTOList.size() != dbExportMonitorCodeViewDTOList.size()){
            return true;
        }
        //数据条数一致
        //比对每一条数据
        //creativeId_adzoneId_purchaseRowId_resourceId
        String keyFormat = "%s_%s_%s_%s";

        List<String> keys = monitorCodeViewDTOList.stream().map(item->String.format(keyFormat, item.getCreativeId(),item.getAdzoneId(),item.getPurchaseRowId(),item.getResourceId())).collect(Collectors.toList());
        List<String> dbKeys = dbExportMonitorCodeViewDTOList.stream().map(item->String.format(keyFormat, item.getCreativeId(),item.getAdzoneId(),item.getPurchaseRowId(),item.getResourceId())).collect(Collectors.toList());
        List<String> keyDiffs =  Differs.diff(keys,dbKeys,String::valueOf);
        //关联有差异
        if (CollectionUtils.isNotEmpty(keyDiffs)){
            return true;
        }
        for (ExportMonitorCodeViewDTO monitorCodeViewDTO : monitorCodeViewDTOList){
            String key = String.format(keyFormat, monitorCodeViewDTO.getCreativeId(),monitorCodeViewDTO.getAdzoneId(),monitorCodeViewDTO.getPurchaseRowId(),monitorCodeViewDTO.getResourceId());
            ExportMonitorCodeViewDTO dbExportMonitorCodeViewDTO =
                    dbExportMonitorCodeViewDTOList.stream().filter(item->{
                        String keyInfo =  String.format(keyFormat, item.getCreativeId(),item.getAdzoneId(),item.getPurchaseRowId(),item.getResourceId());
                        return keyInfo.equals(key);
                    }).findFirst().orElse(null);
            //有差异
            if (Objects.isNull(dbExportMonitorCodeViewDTO)){
                return true;
            }
            boolean deepCompareResult = compareDiffDeepLink(monitorCodeViewDTO, dbExportMonitorCodeViewDTO);
            if (deepCompareResult){
                return true;
            }
            boolean ulkCompareResult = compareDiffUlk(monitorCodeViewDTO, dbExportMonitorCodeViewDTO);
            if (ulkCompareResult){
                return true;
            }
            boolean bottomDateCompareResult = compareDiffBottomDate(monitorCodeViewDTO, dbExportMonitorCodeViewDTO);
            if (bottomDateCompareResult){
                return  true;
            }

        }
        return false;
    }
    private boolean compareDiffBottomDate(ExportMonitorCodeViewDTO exportMonitorCodeViewDTO, ExportMonitorCodeViewDTO dbExportMonitorCodeViewDTO){
        if (CollectionUtils.isEmpty(exportMonitorCodeViewDTO.getBottomDateViewList())
                && CollectionUtils.isEmpty(exportMonitorCodeViewDTO.getBottomDateViewList())){
            return false;
        }
        List<Date> monitorDays = BrandDateUtil.getDayList(exportMonitorCodeViewDTO.getBottomDateViewList());
        List<Date> dbMonitorDays = BrandDateUtil.getDayList(dbExportMonitorCodeViewDTO.getBottomDateViewList());
        List<Date> diffDays = Differs.diff(monitorDays, dbMonitorDays, BrandDateUtil::date2String);
        return CollectionUtils.isNotEmpty(diffDays);

    }
    private boolean compareDiffDeepLink(ExportMonitorCodeViewDTO exportMonitorCodeViewDTO, ExportMonitorCodeViewDTO dbExportMonitorCodeViewDTO){
        //有差异
        if (StringUtils.isBlank(exportMonitorCodeViewDTO.getDeepLinkUrl())
                && StringUtils.isBlank(exportMonitorCodeViewDTO.getDeepLinkUrl())){
            return false;
        }
        if (StringUtils.isNotBlank(exportMonitorCodeViewDTO.getDeepLinkUrl())
                && StringUtils.isNotBlank(exportMonitorCodeViewDTO.getDeepLinkUrl())){
            return false;
        }
        return true;
    }

    private boolean compareDiffUlk(ExportMonitorCodeViewDTO exportMonitorCodeViewDTO, ExportMonitorCodeViewDTO dbExportMonitorCodeViewDTO){
        if (StringUtils.isBlank(exportMonitorCodeViewDTO.getUlkUrl())
                && StringUtils.isBlank(exportMonitorCodeViewDTO.getUlkUrl())){
            return false;
        }
        if (StringUtils.isNotBlank(exportMonitorCodeViewDTO.getUlkUrl())
                && StringUtils.isNotBlank(exportMonitorCodeViewDTO.getUlkUrl())){
            return false;
        }
        return true;
    }

    /**
     * 获取计划信息
     * @param serviceContext
     * @param id
     * @param option
     * @return
     */
    private CampaignViewDTO getCampaignInfoByOption(ServiceContext serviceContext,Long id,CampaignQueryOption option){
        CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder().campaignIds(Collections.singletonList(id)).build();
        List<CampaignViewDTO> dbCampaignViewDTOList = campaignStructureQueryAbility.handle(serviceContext,
                CampaignStructureQueryAbilityParam.builder().abilityTarget(campaignQueryViewDTO).queryOption(option).build());
        return CollectionUtils.isNotEmpty(dbCampaignViewDTOList) ? dbCampaignViewDTOList.get(0) : null;
    }
}