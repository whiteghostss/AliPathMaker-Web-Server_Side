package com.taobao.ad.brand.bp.domain.ssp;

import com.taobao.ad.brand.bp.client.dto.product.AdzoneViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ResourceScheduleViewDTO;

import java.util.List;

/**
 * adzone相关服务
 * @Author: 弈云
 * @Date: 2023/3/4
 */
public interface AdzoneRepository {


    /**
     * 获取adzoneList
     * @param adzoneIds
     * @return
     */
    List<AdzoneViewDTO> getAdzoneListByAdzoneIds(List<Long> adzoneIds);

    List<AdzoneViewDTO> selectAdzoneByUserId(List<Long> memberIds, List<String> userIds);

}
