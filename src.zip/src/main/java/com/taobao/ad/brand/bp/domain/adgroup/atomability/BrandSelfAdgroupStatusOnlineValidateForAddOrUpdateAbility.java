package com.taobao.ad.brand.bp.domain.adgroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupBottomTypeEnum;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupOnlineStatusEnum;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupTargetTypeEnum;
import com.alibaba.ad.nb.ssp.constant.common.CrossSceneEnum;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryViewDTO;
import com.taobao.ad.brand.bp.common.helper.adgroup.BizAdgroupToolsHelper;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.adgroup.repository.AdgroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupStatusOnlineValidateForAddOrUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupStatusOnlineValidateForAddOrUpdateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandSelfServiceAtomAbilityRouter;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Component
@BusinessAbility
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSelfAdgroupStatusOnlineValidateForAddOrUpdateAbility
        implements IAdgroupStatusOnlineValidateForAddOrUpdateAbility, BrandSelfServiceAtomAbilityRouter {

    private final AdgroupRepository adgroupRepository;

    /**
     * 非N+的单元验证
     * 优选单元必须先成为正式，其他单元才可以成为正式。
     * N+的单元非正式时，计划下其他单元不可转正式
     * 特秀lite打底单元为「草稿」时，计划下其他单元状态均为「草稿」不可转正式
     * @param serviceContext
     * @param abilityParam
     * @return
     */
    @Override
    public Void handle(ServiceContext serviceContext, AdgroupStatusOnlineValidateForAddOrUpdateAbilityParam abilityParam) {
        CampaignViewDTO campaignViewDTO = abilityParam.getCampaignViewDTO();
        AdgroupViewDTO adgroupViewDTO = abilityParam.getAbilityTarget();
        if(BrandAdgroupOnlineStatusEnum.DRAFT.getCode().equals(adgroupViewDTO.getOnlineStatus())){
            return null;
        }
        if(BrandAdgroupTargetTypeEnum.PROGRAM.getCode().equals(adgroupViewDTO.getTargetType())){
            AdgroupQueryViewDTO adgroupQueryViewDTO = new AdgroupQueryViewDTO();
            adgroupQueryViewDTO.setCampaignId(adgroupViewDTO.getCampaignId());
            List<AdgroupViewDTO> adgroupList = adgroupRepository.queryAdgroupListNoPage(serviceContext,adgroupQueryViewDTO);
            if (!adgroupViewDTO.getBottomType().equals(BrandAdgroupBottomTypeEnum.N_REACH.getCode())){
                List<AdgroupViewDTO> notOnlineReachAdgroupList=
                        adgroupList.stream().filter(item-> BrandAdgroupBottomTypeEnum.N_REACH.getCode().equals(item.getBottomType()) && !item.getOnlineStatus().equals(BrandAdgroupOnlineStatusEnum.ONLINE.getCode())).collect(Collectors.toList());
                AssertUtil.assertTrue(CollectionUtils.isEmpty(notOnlineReachAdgroupList),"该单元所属计划下的单元：%s必须先成为正式", BizAdgroupToolsHelper.adgroupMessage(notOnlineReachAdgroupList));
            }
            if (Objects.nonNull(campaignViewDTO.getCampaignResourceViewDTO().getSspCrossScene()) && campaignViewDTO.getCampaignResourceViewDTO().getSspCrossScene().equals(CrossSceneEnum.TAOBAO_INNER_LITE_SCENE.getValue())
                    && !BrandAdgroupBottomTypeEnum.BOTTOM.getCode().equals(adgroupViewDTO.getBottomType())) {
                List<AdgroupViewDTO> notOnlineBottomAdgroupList=
                        adgroupList.stream().filter(item-> BrandAdgroupBottomTypeEnum.BOTTOM.getCode().equals(item.getBottomType()) && !item.getOnlineStatus().equals(BrandAdgroupOnlineStatusEnum.ONLINE.getCode())).collect(Collectors.toList());
                AssertUtil.assertTrue(CollectionUtils.isEmpty(notOnlineBottomAdgroupList),"该单元所属计划下的单元：%s必须先成为正式",BizAdgroupToolsHelper.adgroupMessage(notOnlineBottomAdgroupList));
            }
            //全域通黑盒，若打底单元非正式， 则其他单元不允许正式
            if (Objects.nonNull(campaignViewDTO.getCampaignResourceViewDTO().getSspCrossScene()) && campaignViewDTO.getCampaignResourceViewDTO().getSspCrossScene().equals(CrossSceneEnum.CROSS_OPAQUE_SCENE.getValue())
                    && !BrandAdgroupBottomTypeEnum.BOTTOM.getCode().equals(adgroupViewDTO.getBottomType())) {
                List<AdgroupViewDTO> notOnlineBottomAdgroupList=
                        adgroupList.stream().filter(item-> BrandAdgroupBottomTypeEnum.BOTTOM.getCode().equals(item.getBottomType()) && !item.getOnlineStatus().equals(BrandAdgroupOnlineStatusEnum.ONLINE.getCode())).collect(Collectors.toList());
                AssertUtil.assertTrue(CollectionUtils.isEmpty(notOnlineBottomAdgroupList),"该单元所属计划下的单元：%s必须先成为正式",BizAdgroupToolsHelper.adgroupMessage(notOnlineBottomAdgroupList));
            }
        }
        return null;
    }
}
