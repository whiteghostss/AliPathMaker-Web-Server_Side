package com.taobao.ad.brand.bp.domain.campaigngroup.atomability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.contract.CampaignGroupContractViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupContractSignStatusEnum;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesBriefViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesContractViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.SalesContractStateEnum;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.SalesContractRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.atomability.router.BrandOneBPAtomAbilityRouter;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupContractUpdateForNoticeBriefEventAbilityParam;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Objects;

@Component
@BusinessAbility
public class BrandOneBPCampaignGroupContractUpdateForNoticeBriefEventAbility
        extends DefaultCampaignGroupContractUpdateForNoticeBriefEventAbility implements BrandOneBPAtomAbilityRouter {
    @Resource
    private CampaignGroupRepository campaignGroupRepository;
    @Resource
    private SalesContractRepository salesContractRepository;


    @Override
    public Void handle(ServiceContext serviceContext, CampaignGroupContractUpdateForNoticeBriefEventAbilityParam abilityParam) {
        CampaignGroupContractViewDTO campaignGroupContractViewDTO = abilityParam.getAbilityTarget();
        CampaignGroupViewDTO campaignGroupViewDTO = abilityParam.getCampaignGroupViewDTO();
        SalesBriefViewDTO brief = abilityParam.getSalesBriefViewDTO();
        boolean isUpdate = false;
        // 设置合同ID
        if (!Objects.equals(campaignGroupContractViewDTO.getContractId(), brief.getContractId())) {
            campaignGroupContractViewDTO.setContractId(brief.getContractId());
            isUpdate = true;
        }
        // 合同号不存在时设置
        if (StringUtils.isBlank(campaignGroupContractViewDTO.getContractNumber())) {
            SalesContractViewDTO contractViewDTO = salesContractRepository.getSimpleContractInfo(brief.getContractId());
            if (StringUtils.isNotBlank(contractViewDTO.getContractNum())) {
                campaignGroupContractViewDTO.setContractNumber(contractViewDTO.getContractNum());
                isUpdate = true;
            }
        }
        // 合同签约状态
        if (!BizCampaignGroupToolsHelper.isSlimOrderCampaignGroup(campaignGroupViewDTO)) {
            if (SalesContractStateEnum.WAIT_ONLINE_CONFIRM.getValue().equals(brief.getContractStatus())) {
                if (!BrandCampaignGroupContractSignStatusEnum.WAIT_SIGN.getCode().equals(campaignGroupContractViewDTO.getContractSignStatus())) {
                    campaignGroupContractViewDTO.setContractSignStatus(BrandCampaignGroupContractSignStatusEnum.WAIT_SIGN.getCode());
                    isUpdate = true;
                }
            } else if (SalesContractStateEnum.WAIT_PAYMENT_AFTER_CREATE.getValue().equals(brief.getContractStatus()) || SalesContractStateEnum.PAYED.getValue().equals(brief.getContractStatus())) {
                if (!BrandCampaignGroupContractSignStatusEnum.SIGNED.getCode().equals(campaignGroupContractViewDTO.getContractSignStatus())) {
                    campaignGroupContractViewDTO.setContractSignStatus(BrandCampaignGroupContractSignStatusEnum.SIGNED.getCode());
                    isUpdate = true;
                }
            }
        }
        campaignGroupViewDTO.setCampaignGroupContractViewDTO(campaignGroupContractViewDTO);

        if (isUpdate) {
            CampaignGroupViewDTO updateCampaignGroupViewDTO = new CampaignGroupViewDTO();
            updateCampaignGroupViewDTO.setId(campaignGroupViewDTO.getId());
            updateCampaignGroupViewDTO.setCampaignGroupContractViewDTO(campaignGroupContractViewDTO);
            campaignGroupRepository.updateCampaignGroupPart(serviceContext, updateCampaignGroupViewDTO);
        }

        return null;
    }
}
