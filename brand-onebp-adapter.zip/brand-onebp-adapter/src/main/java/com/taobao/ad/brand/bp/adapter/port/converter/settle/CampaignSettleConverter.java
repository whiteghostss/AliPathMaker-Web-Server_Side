package com.taobao.ad.brand.bp.adapter.port.converter.settle;

import com.alibaba.ad.settle.billing.api.dto.accounting.response.StlCampaignAccountingResposneDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.settle.mapstruct.CampaignSettleMapStruct;
import com.taobao.ad.brand.bp.client.dto.campaign.settle.CampaignSettleViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;

import org.springframework.stereotype.Component;

/**
 * @author yanjingang
 * @date 2023/4/6
 */
@Component
public class CampaignSettleConverter extends BaseViewDTOConverter<StlCampaignAccountingResposneDTO, CampaignSettleViewDTO> {
    @Override
    public BaseMapStructMapper<StlCampaignAccountingResposneDTO, CampaignSettleViewDTO> getBaseMapStructMapper() {
        return CampaignSettleMapStruct.INSTANCE;
    }
}
