package com.taobao.ad.brand.bp.adapter.port.converter.ssp;

import com.alibaba.ad.nb.ssp.dto.site.SiteDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.ssp.mapstruct.SiteMapStruct;
import com.taobao.ad.brand.bp.client.dto.site.SiteViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.springframework.stereotype.Component;

/**
 * @author yuncheng.lyc
 */
@Component
public class SiteConverter extends BaseViewDTOConverter<SiteDTO, SiteViewDTO> {

    @Override
    public BaseMapStructMapper<SiteDTO, SiteViewDTO> getBaseMapStructMapper() {
        return SiteMapStruct.INSTANCE;
    }
}
