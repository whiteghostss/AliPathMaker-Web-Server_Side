package com.taobao.ad.brand.bp.adapter.port.repository.report;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.nb.task.client.dto.async.AsyncTaskDTO;
import com.alibaba.ad.nb.task.client.dto.async.AsyncTaskQueryDTO;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.taobao.ad.brand.bp.adapter.port.converter.report.ReportTaskQueryViewDTOConverter;
import com.taobao.ad.brand.bp.adapter.port.converter.report.ReportTaskViewDTOConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.report.ReportSyncTaskSAO;
import com.taobao.ad.brand.bp.client.dto.report.ReportTaskViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.query.ReportTaskQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.report.ReportTaskStatusEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.report.repository.ReportSyncTaskRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * 报表异步任务相关服务
 * @author yuncheng.lyc
 * @date 2023/4/10
 **/
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ReportSyncTaskRepositoryImpl implements ReportSyncTaskRepository {
    private final ReportSyncTaskSAO reportSyncTaskSAO;
    private final ReportTaskViewDTOConverter reportTaskViewDTOConverter;
    private final ReportTaskQueryViewDTOConverter reportTaskQueryViewDTOConverter;

    @Override
    public List<ReportTaskViewDTO> queryList(ServiceContext context, ReportTaskQueryViewDTO queryViewDTO) {
        AsyncTaskQueryDTO taskQueryDTO = reportTaskQueryViewDTOConverter.convertViewDTO2DTO(context, queryViewDTO);
        List<AsyncTaskDTO> taskDTOS = reportSyncTaskSAO.queryList(taskQueryDTO);
        return reportTaskViewDTOConverter.convertDTO2ViewDTOList(context, taskDTOS);
    }

    @Override
    public MultiResponse<ReportTaskViewDTO> queryListWithPage(ServiceContext context, ReportTaskQueryViewDTO queryViewDTO){
        AsyncTaskQueryDTO taskQueryDTO = reportTaskQueryViewDTOConverter.convertViewDTO2DTO(context, queryViewDTO);
        MultiResponse<AsyncTaskDTO> response = reportSyncTaskSAO.queryListWithPage(taskQueryDTO);
        return MultiResponse.of(reportTaskViewDTOConverter.convertDTO2ViewDTOList(context, response.getResult()), response.getTotal());
    }

    @Override
    public ReportTaskViewDTO get(ServiceContext context, ReportTaskQueryViewDTO queryViewDTO){
        AsyncTaskQueryDTO taskQueryDTO = reportTaskQueryViewDTOConverter.convertViewDTO2DTO(queryViewDTO);
        AsyncTaskDTO taskDTO = reportSyncTaskSAO.get(taskQueryDTO);
        AssertUtil.notNull(taskDTO, "没有找到任务信息");
        AssertUtil.assertTrue(taskDTO.getBizId().equals(context.getMemberId()), "没有找到任务信息，账号信息不匹配");
        return reportTaskViewDTOConverter.convertDTO2ViewDTO(context, taskDTO);
    }

    @Override
    public Long add(ServiceContext context, ReportTaskViewDTO taskViewDTO){
        AsyncTaskDTO taskDTO = reportTaskViewDTOConverter.convertViewDTO2DTO(context, taskViewDTO);
        return reportSyncTaskSAO.add(taskDTO);
    }

    @Override
    public Long modify(ServiceContext context, ReportTaskViewDTO taskViewDTO){
        AsyncTaskDTO taskDTO = reportTaskViewDTOConverter.convertViewDTO2DTO(context, taskViewDTO);
        return reportSyncTaskSAO.modify(taskDTO);
    }

    @Override
    public Long delete(ServiceContext context, ReportTaskQueryViewDTO queryViewDTO){
        AsyncTaskQueryDTO queryDTO = reportTaskQueryViewDTOConverter.convertViewDTO2DTO(queryViewDTO);
        return reportSyncTaskSAO.delete(queryDTO);
    }

    @Override
    public Long modifyStatus(ServiceContext context, ReportTaskViewDTO taskViewDTO) {
        AssertUtil.notNull(taskViewDTO.getTaskId());
        AssertUtil.notNull(taskViewDTO.getStatus());

        taskViewDTO.setLastModifyBy(context.getOperName());
        taskViewDTO.setGmtModified(new Date());
        return modify(context, taskViewDTO);
    }

    @Override
    public Long runFail(ServiceContext context, ReportTaskViewDTO taskViewDTO) {
        AssertUtil.notNull(taskViewDTO.getTaskId());
        taskViewDTO.setTaskId(taskViewDTO.getTaskId());
        taskViewDTO.setStatus(ReportTaskStatusEnum.FAIL.getValue());
        taskViewDTO.setErrorMsg(taskViewDTO.getErrorMsg());
        taskViewDTO.setLastModifyBy(context.getOperName());
        taskViewDTO.setGmtModified(new Date());
        taskViewDTO.setLastCalDate(new Date());
        return modify(context, taskViewDTO);
    }

    @Override
    public Long runSucceed(ServiceContext context, ReportTaskViewDTO taskViewDTO) {
        AssertUtil.notNull(taskViewDTO.getTaskId());
        AssertUtil.assertTrue((StringUtils.isNotEmpty(taskViewDTO.getOssUrl()) || StringUtils.isNotEmpty(taskViewDTO.getData())), "任务运行结果不能为空");
        taskViewDTO.setTaskId(taskViewDTO.getTaskId());
        taskViewDTO.setStatus(ReportTaskStatusEnum.SUCCEED.getValue());
        taskViewDTO.setErrorMsg("");
        taskViewDTO.setOssUrl(taskViewDTO.getOssUrl());
        taskViewDTO.setLastModifyBy(context.getOperName());
        taskViewDTO.setGmtModified(new Date());
        taskViewDTO.setLastCalDate(new Date());
        return modify(context, taskViewDTO);
    }

}
