package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.resourcepackage;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.nb.common.dto.NbServiceContext;
import com.alibaba.ad.nb.common.query.PageQuery;
import com.alibaba.ad.nb.packages.api.project.NbProjectQueryService;
import com.alibaba.ad.nb.packages.dto.project.ProjectDTO;
import com.alibaba.ad.nb.packages.v2.client.api.customer.CustomerTemplateCommandService;
import com.alibaba.ad.nb.packages.v2.client.api.motion.IntelligentMotionCommandService;
import com.alibaba.ad.nb.packages.v2.client.api.motion.IntelligentMotionQueryService;
import com.alibaba.ad.nb.packages.v2.client.api.motion.IntelligentStrategyCommandService;
import com.alibaba.ad.nb.packages.v2.client.api.motion.IntelligentStrategyQueryService;
import com.alibaba.ad.nb.packages.v2.client.api.salegroup.SaleGroupCommandService;
import com.alibaba.ad.nb.packages.v2.client.api.salegroup.SaleGroupQueryService;
import com.alibaba.ad.nb.packages.v2.client.api.template.TemplateQueryService;
import com.alibaba.ad.nb.packages.v2.client.dto.motion.IntelligentMotionDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.motion.IntelligentStrategyDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.motion.query.MotionQueryDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.motion.query.StrategyQueryDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.product.ResourcePackageProductDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.salegroup.ReplenishOrDistributionSaleGroupInfoDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.salegroup.ResourcePackageSaleGroupDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.salegroup.SaleGroupSubstitutionDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.salegroup.query.ResourcePackageSaleGroupQueryDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.salegroup.query.SspProductQueryDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.template.ResourcePackageTemplateDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.template.query.ResourcePackageTemplateQueryDTO;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Objects;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/22
 */
@BizTunnel

@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ResourcePackageSAO extends BaseSAO {

    private final TemplateQueryService templateQueryService;
    private final CustomerTemplateCommandService customerTemplateCommandService;
    private final SaleGroupQueryService saleGroupQueryService;
    private final SaleGroupCommandService saleGroupCommandService;
    private final NbProjectQueryService nbProjectQueryService;
    private final IntelligentMotionCommandService intelligentMotionCommandService;
    private final IntelligentMotionQueryService intelligentMotionQueryService;
    private final IntelligentStrategyCommandService intelligentStrategyCommandService;
    private final IntelligentStrategyQueryService intelligentStrategyQueryService;


    /**
     * 获取资源包售卖分组信息
     */
    public ResourcePackageTemplateDTO getTemplateById(ServiceContext serviceContext, Long templateId) {
        ResourcePackageTemplateQueryDTO templateQueryDTO = ResourcePackageTemplateQueryDTO.builder().idList(Lists.newArrayList(templateId))
                .needResourcePackageSaleGroup(false)
                .needResourcePackageProduct(false)
                .needPage(false)
                .needCountAndAmount(false)
                .build();
        return findTemplateList(serviceContext, templateQueryDTO).stream().findFirst().orElse(null);
    }

    public List<ResourcePackageTemplateDTO> findTemplateList(ServiceContext serviceContext, ResourcePackageTemplateQueryDTO templateQueryDTO) {
        NbServiceContext nbServiceContext = NbServiceContext.createServiceContext("-1");
        MultiResponse<ResourcePackageTemplateDTO> response = templateQueryService.list(nbServiceContext, templateQueryDTO);
        AssertUtil.assertTrue(response.isSuccess(), "资源包分组查询失败:" + response.getErrorMsg());
        return response.getResult();
    }

    /**
     * 获取资源包售卖分组信息
     */
    public ResourcePackageSaleGroupDTO getSaleGroupById(ServiceContext serviceContext, Long saleGroupId, ResourcePackageQueryOption queryOption) {
        NbServiceContext nbServiceContext = NbServiceContext.createServiceContext("-1");
        ResourcePackageSaleGroupQueryDTO saleGroupQueryDTO = new ResourcePackageSaleGroupQueryDTO();
        saleGroupQueryDTO.setIdList(Lists.newArrayList(saleGroupId));
        saleGroupQueryDTO.setNeedProduct(queryOption.getNeedProduct());
        saleGroupQueryDTO.setNeedSetting(queryOption.getNeedSetting());
        saleGroupQueryDTO.setNeedInquiryPriority(queryOption.getNeedInquiryPriority());
        MultiResponse<ResourcePackageSaleGroupDTO> response = saleGroupQueryService.list(nbServiceContext, saleGroupQueryDTO);
        RogerLogger.info("saleGroup.response={}", JSON.toJSONString(response));
        AssertUtil.assertTrue(response.isSuccess(), "资源包分组查询失败:" + response.getErrorMsg());
        return response.getResult().stream().findFirst().orElse(null);
    }

    /**
     * 售卖分组基础信息（含editMode）
     */
    public ResourcePackageSaleGroupDTO getSaleGroupWithEditMode(ServiceContext serviceContext, Long saleGroupId) {
        NbServiceContext nbServiceContext = NbServiceContext.createServiceContext("-1");

        ResourcePackageSaleGroupQueryDTO queryDTO = new ResourcePackageSaleGroupQueryDTO();
        queryDTO.setIdList(Lists.newArrayList(saleGroupId));
        queryDTO.setNeedSetting(Boolean.TRUE);
        queryDTO.setNeedProduct(Boolean.TRUE);
        MultiResponse<ResourcePackageSaleGroupDTO> resourcePackageSaleGroupDTOList = saleGroupQueryService.list(nbServiceContext, queryDTO);
        AssertUtil.assertTrue(resourcePackageSaleGroupDTOList.isSuccess(), "资源包分组查询失败:" + resourcePackageSaleGroupDTOList.getErrorMsg());
        ResourcePackageSaleGroupDTO saleGroupDTO = resourcePackageSaleGroupDTOList.getResult().get(0);
        RogerLogger.info("售卖分组信息ResourcePackageSaleGroup.saleGroupDTO:{}", JSONObject.toJSONString(saleGroupDTO));
        return saleGroupCommandService.updateSaleGroupEditMode(nbServiceContext, saleGroupDTO).getResult();
    }

    public List<ResourcePackageSaleGroupDTO> getSaleGroupList(ServiceContext serviceContext, ResourcePackageSaleGroupQueryDTO saleGroupQueryDTO) {
        NbServiceContext nbServiceContext = NbServiceContext.createServiceContext("-1");
        MultiResponse<ResourcePackageSaleGroupDTO> response = saleGroupQueryService.list(nbServiceContext, saleGroupQueryDTO);
        RogerLogger.info("saleGroup.response={}", JSON.toJSONString(response));
        AssertUtil.assertTrue(response.isSuccess(), "资源包分组查询失败:" + response.getErrorMsg());
        return response.getResult();
    }
    public List<ResourcePackageProductDTO> getLevelOneResourcePackageProductList(ServiceContext serviceContext, List<Long> resourceProductIds) {
        NbServiceContext nbServiceContext = NbServiceContext.createServiceContext("-1");
        MultiResponse< ResourcePackageProductDTO > response = saleGroupQueryService.getPackageProductListByIds(nbServiceContext, resourceProductIds);
        RogerLogger.info("saleGroup.response={}", JSON.toJSONString(response));
        AssertUtil.assertTrue(response.isSuccess(), "资源包产品查询失败:" + response.getErrorMsg());
        return response.getResult();
    }
    public ResourcePackageProductDTO getResourcePackageProduct(ServiceContext serviceContext, Long resourceProductId) {
        NbServiceContext nbServiceContext = NbServiceContext.createServiceContext("-1");
        MultiResponse< ResourcePackageProductDTO > response = saleGroupQueryService.getPackageProductListByIds(nbServiceContext, Lists.newArrayList(resourceProductId));
        RogerLogger.info("saleGroup.response={}", JSON.toJSONString(response));
        AssertUtil.assertTrue(response.isSuccess(), "资源包产品查询失败:" + response.getErrorMsg());
        if (CollectionUtils.isNotEmpty(response.getResult())){
            return response.getResult().get(0);
        }
        return null;
    }

    /**
     * 发起自动补量/配送申请
     *
     * @param serviceContext
     * @param saleGroupInfoDTO
     * @return
     */
    public Long autoAddReplenishAndDistributionCustomerSaleGroup(ServiceContext serviceContext, ReplenishOrDistributionSaleGroupInfoDTO saleGroupInfoDTO) {
        Integer bucUserId = Objects.nonNull(serviceContext.getExt("aliStaffBucUserId")) ? Integer.valueOf(String.valueOf(serviceContext.getExt("aliStaffBucUserId"))) : null;
        NbServiceContext nbServiceContext = NbServiceContext.createServiceContext(bucUserId, null, null, null);
        SingleResponse<Long> response = customerTemplateCommandService.autoAddReplenishAndDistributionCustomerSaleGroup(nbServiceContext, saleGroupInfoDTO);
        RogerLogger.info("autoAddReplenishAndDistributionCustomerSaleGroup response {}", JSON.toJSONString(response));
        AssertUtil.assertTrue(response.isSuccess(), "保存补量/配送分组失败:" + response.getErrorMsg());
        return response.getResult();
    }

    /**
     * 删除补量/配送申请
     *
     * @param serviceContext
     * @param saleGroupInfoDTO
     * @return
     */
    public Long deleteReplenishAndDistributionCustomerSaleGroup(ServiceContext serviceContext, ReplenishOrDistributionSaleGroupInfoDTO saleGroupInfoDTO) {
        Integer bucUserId = Objects.nonNull(serviceContext.getExt("aliStaffBucUserId")) ? Integer.valueOf(String.valueOf(serviceContext.getExt("aliStaffBucUserId"))) : null;
        NbServiceContext nbServiceContext = NbServiceContext.createServiceContext(bucUserId, null, null, null);
        SingleResponse<Long> response = customerTemplateCommandService.deleteReplenishAndDistributionCustomerSaleGroup(nbServiceContext, saleGroupInfoDTO);
        RogerLogger.info("deleteReplenishAndDistributionCustomerSaleGroup response {}", JSON.toJSONString(response));
        AssertUtil.assertTrue(response.isSuccess(), "删除补量/配送分组失败:" + response.getErrorMsg());
        return response.getResult();
    }

    public List<ResourcePackageProductDTO> findSspProductList(ServiceContext serviceContext, List<Long> sspProductIds) {
        NbServiceContext nbServiceContext = NbServiceContext.createServiceContext("-1");
        SspProductQueryDTO sspProductQueryDTO = new SspProductQueryDTO();
        sspProductQueryDTO.setProductIdList(sspProductIds);
        MultiResponse< ResourcePackageProductDTO > response = saleGroupQueryService.findSspProductList(nbServiceContext, sspProductQueryDTO);
        RogerLogger.info("saleGroup.findSspProductList.resp={}", JSON.toJSONString(response));
        AssertUtil.assertTrue(response.isSuccess(), "资源包SSP产品查询失败:" + response.getErrorMsg());
        return response.getResult();
    }

    public List<ResourcePackageProductDTO> getSimplePackageProductListByIds(ServiceContext serviceContext, List<Long> ids) {
        NbServiceContext nbServiceContext = NbServiceContext.createServiceContext("-1");
        MultiResponse<ResourcePackageProductDTO> response = saleGroupQueryService.getSimplePackageProductListByIds(nbServiceContext, ids);
        AssertUtil.assertTrue(response.isSuccess(), "资源包查询产品失败:"+response.getErrorMsg());
        return response.getResult();
    }

    public List<ResourcePackageProductDTO> getPackageProductListByIds(ServiceContext serviceContext, List<Long> ids) {
        NbServiceContext nbServiceContext = NbServiceContext.createServiceContext("-1");
        MultiResponse<ResourcePackageProductDTO> response = saleGroupQueryService.getPackageProductListByIds(nbServiceContext, ids);
        AssertUtil.assertTrue(response.isSuccess(), "资源包查询产品失败:"+response.getErrorMsg());
        return response.getResult();
    }

    public void resourceSubstitutionForContent(ServiceContext serviceContext, List<SaleGroupSubstitutionDTO> saleGroupSubstitutionDTOList){
        NbServiceContext nbServiceContext = NbServiceContext.createServiceContext("-1");
        if (CollectionUtils.isEmpty(saleGroupSubstitutionDTOList)) {
            return;
        }
        Response response = saleGroupCommandService.resourceSubstitutionForContent(nbServiceContext, saleGroupSubstitutionDTOList);
        AssertUtil.assertTrue(response);
    }

    /**
     * 获取资源包项目信息
     */
    public ProjectDTO getMarketingProjectById(ServiceContext serviceContext, Long marketingProjectId) {
        NbServiceContext nbServiceContext = NbServiceContext.createServiceContext("-1");
        SingleResponse<ProjectDTO> response = nbProjectQueryService.getById(nbServiceContext, marketingProjectId);
        AssertUtil.assertTrue(response.isSuccess(), "资源包项目查询失败:" + response.getErrorMsg());
        return response.getResult();
    }

    /**
     * 创建/编辑智能提案
     * @param serviceContext
     */
    public Long addOrUpdateIntelligentMotion(ServiceContext serviceContext, IntelligentMotionDTO motionDTO) {
        NbServiceContext nbServiceContext = NbServiceContext.createServiceContext("-1");
        SingleResponse<Long> response = intelligentMotionCommandService.save(nbServiceContext, motionDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 查询智能提案列表
     * @param serviceContext
     * @param queryDTO
     * @param pageQuery (为null表示全量查询)
     */
    public List<IntelligentMotionDTO> queryIntelligentMotionList(ServiceContext serviceContext, MotionQueryDTO queryDTO, PageQuery pageQuery) {
        NbServiceContext nbServiceContext = NbServiceContext.createServiceContext("-1");
        MultiResponse<IntelligentMotionDTO> response =  intelligentMotionQueryService.list(nbServiceContext, queryDTO, pageQuery);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    public MultiResponse<IntelligentMotionDTO> queryIntelligentMotionListResponse(ServiceContext serviceContext, MotionQueryDTO queryDTO, PageQuery pageQuery) {
        NbServiceContext nbServiceContext = NbServiceContext.createServiceContext("-1");
        MultiResponse<IntelligentMotionDTO> response =  intelligentMotionQueryService.list(nbServiceContext, queryDTO, pageQuery);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response;
    }

    public void updateIntelligentMotionListStatus(ServiceContext serviceContext, List<Long> idList, Integer status) {
        NbServiceContext nbServiceContext = NbServiceContext.createServiceContext("-1");
        Response response =  intelligentMotionCommandService.batchUpdateStatus(nbServiceContext, idList, status);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
    }

    public Long saveIntelligentStrategy(ServiceContext serviceContext, IntelligentStrategyDTO strategyDTO) {
        NbServiceContext nbServiceContext = NbServiceContext.createServiceContext("-1");
        SingleResponse<Long> response = intelligentStrategyCommandService.save(nbServiceContext, strategyDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    public void updatBasicIntelligentStrategy(ServiceContext serviceContext, IntelligentStrategyDTO strategyDTO) {
        NbServiceContext nbServiceContext = NbServiceContext.createServiceContext("-1");
        Response response = intelligentStrategyCommandService.updateBasicInfo(nbServiceContext, Lists.newArrayList(strategyDTO));
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
    }

    /**
     * 查询智能提案列表
     * @param serviceContext
     * @param queryDTO
     */
    public List<IntelligentStrategyDTO> queryIntelligentStrategyList(ServiceContext serviceContext, StrategyQueryDTO queryDTO) {
        NbServiceContext nbServiceContext = NbServiceContext.createServiceContext("-1");
        MultiResponse<IntelligentStrategyDTO> response =  intelligentStrategyQueryService.list(nbServiceContext, queryDTO, null);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 权益模版查询
     * @param serviceContext 上下文
     * @return 全量权益模版列表
     */
    @Deprecated
    public List<Long> findRightsTemplateIdList(ServiceContext serviceContext) {
        NbServiceContext nbServiceContext = NbServiceContext.createServiceContext("-1");
//        MultiResponse<Long> response = templateQueryService.findRightsTemplateIdList(nbServiceContext);
//        AssertUtil.assertTrue(response.isSuccess(), "资源包全量权益模版查询失败:" + response.getErrorMsg());
        return null;
    }
}