package com.taobao.ad.brand.bp.adapter.port.converter.ssp.mapstruct;

import com.alibaba.ad.nb.ssp.dto.dict.DictionaryDTO;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author jixiu.lj
 * @date 2023/3/23 22:52
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface DictionaryMapStruct extends BaseMapStructMapper<DictionaryDTO, CommonViewDTO> {
    DictionaryMapStruct INSTANCE = Mappers.getMapper(DictionaryMapStruct.class);
}
