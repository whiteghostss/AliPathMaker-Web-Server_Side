package com.taobao.ad.brand.bp.adapter.port.converter.dmp.mapstruct;

import com.taobao.ad.brand.bp.client.dto.dmp.TagOptionViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.dmp.client.dto.TagOptionDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface TagViewDTOMapStruct extends BaseMapStructMapper<TagOptionDTO, TagOptionViewDTO> {

    TagViewDTOMapStruct INSTANCE = Mappers.getMapper(TagViewDTOMapStruct.class);

    @Mappings({
            @Mapping(source = "id",target = "optionId")
    })
    @Override
    TagOptionViewDTO sourceToTarget(TagOptionDTO source);

    @Mappings({
            @Mapping(source = "optionId",target = "id"),
    })
    @Override
    TagOptionDTO targetToSource(TagOptionViewDTO target);


}
