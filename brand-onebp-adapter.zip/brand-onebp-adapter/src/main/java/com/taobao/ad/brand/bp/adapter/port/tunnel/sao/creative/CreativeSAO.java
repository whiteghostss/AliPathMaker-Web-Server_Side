package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.creative;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.biz.definition.constants.Product;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.creative.api.*;
import com.alibaba.ad.creative.api.biz.MediaTmlCreativeCommandService;
import com.alibaba.ad.creative.api.biz.MediaTmlCreativeQueryService;
import com.alibaba.ad.creative.consts.contentversion.ContentVersionBizType;
import com.alibaba.ad.creative.consts.creative.CreativeIndexTagEnum;
import com.alibaba.ad.creative.consts.quality.ReSendParam;
import com.alibaba.ad.creative.dto.bind.CreativeBindDTO;
import com.alibaba.ad.creative.dto.bind.CreativeBindOptionDTO;
import com.alibaba.ad.creative.dto.bind.query.CreativeBindQueryDTO;
import com.alibaba.ad.creative.dto.bind.query.CreativeBindQueryOptionDTO;
import com.alibaba.ad.creative.dto.biz.ud.MediaTmlCreativeDTO;
import com.alibaba.ad.creative.dto.biz.ud.creative.query.MediaTmlCreativeQueryDTO;
import com.alibaba.ad.creative.dto.contentversion.ContentVersionDTO;
import com.alibaba.ad.creative.dto.creative.CreativeUpdateOptionDTO;
import com.alibaba.ad.creative.dto.creative.MaterialUpdateOptionDTO;
import com.alibaba.ad.creative.dto.creative.query.CreativeQueryOptionDTO;
import com.alibaba.ad.creative.dto.material.MaterialDTO;
import com.alibaba.ad.creative.dto.materialgroup.MaterialGroupDTO;
import com.alibaba.ad.creative.dto.url.UrlAnalysisResultDTO;
import com.alibaba.ad.creative.query.ContentVersionQuery;
import com.alibaba.ad.creative.query.MaterialGroupQueryOption;
import com.alibaba.ad.creative.query.MaterialQueryOption;
import com.alibaba.ad.nb.basic.client.api.creative.BizCreativeTemplateQueryService;
import com.alibaba.ad.nb.direct.client.context.NbDirectServiceContext;
import com.alibaba.ad.nb.direct.client.dto.user.UserDTO;
import com.alibaba.ad.nb.user.client.constant.bizspace.BizAbilityEnum;
import com.alibaba.ad.nb.user.client.constant.common.UserTypeEnum;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.alibaba.hermes.framework.utils.BeanUtils;
import com.alibaba.solar.common.dto.BaseServiceContext;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.github.rholder.retry.Retryer;
import com.github.rholder.retry.RetryerBuilder;
import com.github.rholder.retry.StopStrategies;
import com.github.rholder.retry.WaitStrategies;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeItemBizInfoViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.PageRequestUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.inventoryscheduler.client.dump.ISearchDataDumpService;
import com.taobao.inventoryscheduler.dto.ItemBizInfoSyncDTO;
import com.taobao.inventoryscheduler.dto.Result;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

@Component
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CreativeSAO extends BaseSAO {
    private final MediaTmlCreativeCommandService mediaTmlCreativeCommandService;
    private final MediaTmlCreativeQueryService mediaTmlCreativeQueryService;
    private final CreativeBindQueryService creativeBindQueryService;
    private final CreativeBindCommandService creativeBindCommandService;
    private final QualityCommandService qualityCommandService;
    private final com.alibaba.ad.nb.basic.client.api.creative.BizCreativeCommandService udCreativeCommandService;
    private final com.alibaba.ad.nb.basic.client.api.creative.BizCreativeQueryService udCreativeQueryService;
    private final ClickUrlAnalysisQueryService clickUrlAnalysisQueryService;
    private final BizCreativeTemplateQueryService udCreativeTemplateQueryService;
    private final ContentVersionCommandService contentVersionCommandService;
    private final ContentVersionQueryService contentVersionQueryService;
    private final ISearchDataDumpService iSearchDataDumpService;
    private final MaterialGroupQueryService materialGroupQueryService;
    private final MaterialGroupCommandService materialGroupCommandService;
    private final MaterialCommandService materialCommandService;

    Retryer<Result> retryer = RetryerBuilder.<Result>newBuilder()
            .retryIfException()
            .retryIfResult(e -> !e.isSuccess() || StringUtils.isNotEmpty(e.getErrorMsg()) || StringUtils.isNotEmpty(e.getErrorCode()))
            .withWaitStrategy(WaitStrategies.fixedWait(1, TimeUnit.SECONDS))
            .withStopStrategy(StopStrategies.stopAfterAttempt(10))
            .build();

    /**
     * 拆分营销场景下非内容场景都查出品牌的
     *
     * @param serviceContext
     * @return
     */
    private ServiceContext getCreativeServiceContext(ServiceContext serviceContext) {
        ServiceContext context = new ServiceContext();
        context.setMemberId(serviceContext.getMemberId());
        context.setBizId(BizCodeEnum.BRANDONEBP.getBizCode());
        context.setBizCode(BizCodeEnum.BRANDAD.getBizCode());
        context.setAppId(ServiceContextUtil.getSceneId(BizCodeEnum.BRANDAD.getBizCode()));
        context.setProductLineId(Product.BRAND_ONEBP_BRAND.getProductLineId());
        context.setProductId(Product.BRAND_ONEBP_BRAND.getId());
        context.setOperType(BaseServiceContext.OPERTYPE_INNER_OPT);
        return context;
    }

    public Long addCreative(ServiceContext serviceContext, MediaTmlCreativeDTO creativeDTO) {
        SingleResponse<Long> response = mediaTmlCreativeCommandService.addCreative(getCreativeServiceContext(serviceContext), creativeDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(String.format("模板:%s制作创意时报错,error %s:", creativeDTO.getSspTemplateId(), response.getErrorMsg())));
        return response.getResult();
    }

    public List<Long> deleteCreatives(ServiceContext serviceContext, List<Long> creativeIds) {
        CreativeUpdateOptionDTO updateOptionDTO = new CreativeUpdateOptionDTO.Builder().isForceDelete(Boolean.TRUE).reAudit(Boolean.TRUE).syncState(Boolean.TRUE).build();
        MultiResponse<Long> response = mediaTmlCreativeCommandService.deleteCreativeList(getCreativeServiceContext(serviceContext), creativeIds, updateOptionDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    public Integer updateCreative(ServiceContext serviceContext, MediaTmlCreativeDTO creativeDTO) {
        SingleResponse<Integer> response = mediaTmlCreativeCommandService.updateCreative(getCreativeServiceContext(serviceContext), creativeDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    public List<CreativeBindDTO> addBatchCreativeRef(ServiceContext serviceContext, List<CreativeBindDTO> creativeBindDTOList) {
        CreativeBindOptionDTO optionDTO = new CreativeBindOptionDTO();
        optionDTO.setUpdateAll(Boolean.FALSE);
        MultiResponse<CreativeBindDTO> response = creativeBindCommandService.addBatch(getCreativeServiceContext(serviceContext), creativeBindDTOList, optionDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    public List<CreativeBindDTO> addBatchCreativeRefAndSetting(ServiceContext serviceContext, List<CreativeBindDTO> creativeBindDTOList) {
        MultiResponse<CreativeBindDTO> response = creativeBindCommandService.addCreativeBindPartBatch(getCreativeServiceContext(serviceContext), creativeBindDTOList);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    public List<CreativeBindDTO> updateBatchCreativeRef(ServiceContext serviceContext, List<CreativeBindDTO> creativeRefList) {
        AssertUtil.notEmpty(creativeRefList, "参数异常");
        CreativeBindOptionDTO optionDTO = new CreativeBindOptionDTO();
        optionDTO.setUpdateAll(Boolean.TRUE);
        optionDTO.setPhysicalDeletion(Boolean.TRUE);
        MultiResponse<CreativeBindDTO> response = creativeBindCommandService.addBatch(getCreativeServiceContext(serviceContext), creativeRefList, optionDTO);
        RogerLogger.info("updateBatchCreativeRef,response:{}", JSONObject.toJSONString(response));
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    public Integer unBindCreative(ServiceContext serviceContext, List<Long> adgroupIds, List<Long> creativeIds) {
        SingleResponse<Integer> response = creativeBindCommandService.deleteBatchByAdgroupIdsAndCreativeIds(getCreativeServiceContext(serviceContext), adgroupIds, creativeIds);
        RogerLogger.info("unBindCreative,response:{}", JSONObject.toJSONString(response));
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    public Integer unBindCreative(ServiceContext serviceContext, List<Long> creativeIds) {
        SingleResponse<Integer> response = creativeBindCommandService.deleteBatchByCreativeIds(getCreativeServiceContext(serviceContext), creativeIds);
        RogerLogger.info("unBindCreative,response:{}", JSONObject.toJSONString(response));
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    public Integer unBindCreativeRef(ServiceContext serviceContext, List<Long> adgroupIds) {
        AssertUtil.notEmpty(adgroupIds, "参数异常");
        SingleResponse<Integer> response = creativeBindCommandService.deleteBatchByAdgroupIds(getCreativeServiceContext(serviceContext), adgroupIds);
        RogerLogger.info("unBindCreative,response:{}", JSONObject.toJSONString(response));
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    public Integer updateCreativePart(ServiceContext serviceContext, MediaTmlCreativeDTO creativeDTO) {
        CreativeUpdateOptionDTO updateOptionDTO = new CreativeUpdateOptionDTO.Builder().reAudit(Boolean.FALSE).syncState(Boolean.TRUE).build();
        SingleResponse<Integer> response = mediaTmlCreativeCommandService.updateCreativePart(getCreativeServiceContext(serviceContext), creativeDTO, updateOptionDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    public MediaTmlCreativeDTO getCreativeById(ServiceContext serviceContext, Long id) {
        CreativeQueryOptionDTO build = new CreativeQueryOptionDTO.Builder().propertyRequired(true).build();
        SingleResponse<MediaTmlCreativeDTO> response =
                mediaTmlCreativeQueryService.getCreativeById(getCreativeServiceContext(serviceContext), id, build);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    public UrlAnalysisResultDTO analysisClickUrl(ServiceContext serviceContext, String clickUrl) {
        SingleResponse<UrlAnalysisResultDTO> response = clickUrlAnalysisQueryService.analysisClickUrl(getCreativeServiceContext(serviceContext), clickUrl, "");
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 根据创意IDs查询创意
     */
    public List<MediaTmlCreativeDTO> getCreativeByIds(ServiceContext serviceContext, List<Long> ids) {
        CreativeQueryOptionDTO build = new CreativeQueryOptionDTO.Builder().build();
        build.setPropertyRequired(true);
        MultiResponse<MediaTmlCreativeDTO> response =
                mediaTmlCreativeQueryService.findCreativeByIdList(getCreativeServiceContext(serviceContext), ids, build);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 根据单元id 获取创意绑定列表
     */
    public List<CreativeBindDTO> getCreativeRefByAdgroupId(ServiceContext serviceContext, Long adgroupId) {
        CreativeBindQueryDTO creativeBindQueryDTO = new CreativeBindQueryDTO();
        creativeBindQueryDTO.setAdgroupIdList(Lists.newArrayList(adgroupId));
        creativeBindQueryDTO.setOnlineStatus(BrandBoolEnum.BRAND_TRUE.getCode());
        MultiResponse<CreativeBindDTO> response =
                creativeBindQueryService.findCreativeBindList(getCreativeServiceContext(serviceContext), creativeBindQueryDTO);

        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 分页查询创意
     *
     * @param serviceContext
     * @param queryDTO
     * @return
     */
    public PageResultViewDTO<MediaTmlCreativeDTO> findListWithPage(ServiceContext serviceContext, MediaTmlCreativeQueryDTO queryDTO) {
        CreativeQueryOptionDTO optionDTO = new CreativeQueryOptionDTO.Builder().propertyRequired(true).creativeIndexTag(CreativeIndexTagEnum.MDEDIA_TML_BRAND).build();
        RogerLogger.info("findListWithPage,ServiceContext:{},MediaTmlCreativeQueryDTO:{},CreativeQueryOptionDTO:{}", JSON.toJSONString(serviceContext), JSON.toJSONString(queryDTO), JSON.toJSONString(optionDTO));
        MultiResponse<MediaTmlCreativeDTO> response = mediaTmlCreativeQueryService.findCreativePageWithIndex(getCreativeServiceContext(serviceContext), queryDTO, optionDTO);
        RogerLogger.info("findListWithPage,result:{}", JSON.toJSONString(response));
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return PageResultViewDTO.of(response.getResult(), response.getTotal());
    }

    /**
     * 基于素材组id查询创意
     *
     * @param serviceContext
     * @param materialGroupId
     * @return
     */
    public List<MediaTmlCreativeDTO> findListByMaterialGroupId(ServiceContext serviceContext, Long materialGroupId) {
        MaterialGroupQueryOption materialGroupQueryOption = new MaterialGroupQueryOption();
        materialGroupQueryOption.setMaterialRequired(true);
        MaterialQueryOption materialQueryOption = new MaterialQueryOption();
        materialQueryOption.setPropertyRequired(true);
        materialGroupQueryOption.setMaterialQueryOption(materialQueryOption);

        CreativeQueryOptionDTO optionDTO = new CreativeQueryOptionDTO.Builder().propertyRequired(true).materialRequired(true).elementRequired(true).materialGroupQueryOption(materialGroupQueryOption)
                .creativeIndexTag(CreativeIndexTagEnum.MDEDIA_TML_BRAND).build();

        MediaTmlCreativeQueryDTO creativeQueryDTO = new MediaTmlCreativeQueryDTO();
        creativeQueryDTO.setElementName("material_group_id");
        creativeQueryDTO.setElementValue(materialGroupId.toString());
        MultiResponse<MediaTmlCreativeDTO> response = mediaTmlCreativeQueryService.findCreativeList(getCreativeServiceContext(serviceContext), creativeQueryDTO, optionDTO);
        RogerLogger.info("findListByMaterialGroupId,result:{}", JSON.toJSONString(response));
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    @Deprecated
    public List<CreativeBindDTO> findCreativeBindList(ServiceContext serviceContext, CreativeBindQueryDTO queryDTO) {
        CreativeBindQueryOptionDTO creativeBindQueryOptionDTO = new CreativeBindQueryOptionDTO();
        creativeBindQueryOptionDTO.setPropertyRequired(true);
        List<CreativeBindDTO> result = new ArrayList<>();
        int pageSize = 2000;
        queryDTO.setLimit(pageSize);
        PageRequestUtil.execute(idx -> {
                    queryDTO.setSkip((idx - 1) * pageSize);
                    MultiResponse<CreativeBindDTO> response = creativeBindQueryService.findCreativeBindPageV2(getCreativeServiceContext(serviceContext), queryDTO, creativeBindQueryOptionDTO);
                    AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
                    return response;
                }, (idx, response) -> response.isSuccess() && response.getTotal() >= (idx - 1) * pageSize,
                response -> result.addAll(response.getResult()));
        return result;
    }

    public int getCreativeBindCount(ServiceContext serviceContext, CreativeBindQueryDTO queryDTO) {
        SingleResponse<Integer> countResponse = creativeBindQueryService.getCreatvieBindCount(getCreativeServiceContext(serviceContext), queryDTO);
        AssertUtil.assertTrue(countResponse.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(countResponse.getErrorMsg()));
        return Optional.ofNullable(countResponse.getResult()).orElse(0);
    }

    public List<CreativeBindDTO> findCreativeBindPage(ServiceContext serviceContext, CreativeBindQueryDTO queryDTO) {
        return this.findCreativeBindPage(serviceContext, queryDTO, true);
    }

    public List<CreativeBindDTO> findCreativeBindPage(ServiceContext serviceContext, CreativeBindQueryDTO queryDTO, boolean propertyRequired) {
        CreativeBindQueryOptionDTO creativeBindQueryOptionDTO = new CreativeBindQueryOptionDTO();
        creativeBindQueryOptionDTO.setPropertyRequired(propertyRequired);
        MultiResponse<CreativeBindDTO> response = creativeBindQueryService.findCreativeBindPageV2(getCreativeServiceContext(serviceContext), queryDTO, creativeBindQueryOptionDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    public void rePushCreativeCenter(ServiceContext serviceContext, List<Long> creativeIdList, String qualifyJson) {
        ReSendParam reSendParam = new ReSendParam();
        reSendParam.setReSendType(ReSendParam.ReSendParamEnum.SEND_REJECT_QUALIFICATION.getType());
        reSendParam.setTransExt(qualifyJson);
        RogerLogger.info("sendMaterialToQualityByCreativeIds,ServiceContext:{},creativeIdList:{},ReSendParam:{}", JSON.toJSONString(serviceContext), JSON.toJSONString(creativeIdList), JSON.toJSONString(reSendParam));
        SingleResponse<Integer> response = qualityCommandService.sendMaterialToQualityByCreativeIds(getCreativeServiceContext(serviceContext), creativeIdList, reSendParam);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
    }

    public Integer calcUpdateAndUpperCreativeQualityInfo(ServiceContext serviceContext, Long creativeId) {
        RogerLogger.info("calcUpdateAndUpperCreativeQualityInfo,ServiceContext:{},creativeId:{}", JSON.toJSONString(serviceContext), JSON.toJSONString(creativeId));
        SingleResponse<Integer> response = qualityCommandService.calcUpdateAndUpperCreativeQualityInfo(getCreativeServiceContext(serviceContext), creativeId);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 获取 指定contentId(uuid)的最新版本
     *
     * @param context   上下文
     * @param contentId uuid
     * @return 监测代码
     */
    public ContentVersionDTO getLastContentVersionByContentId(ServiceContext context, Long contentId) {

        SingleResponse<ContentVersionDTO> response = contentVersionQueryService.getLastContentVersionByContentId(context, ContentVersionBizType.MONITOR_URL.getValue(), contentId);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 获取 指定id的监测
     *
     * @param context 上下文
     * @param id      主键id
     * @return 监测代码
     */
    public ContentVersionDTO getContentVersionById(ServiceContext context, Long id) {
        SingleResponse<ContentVersionDTO> response = contentVersionQueryService.getContentVersionById(context, id);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 获取 指定条件的监测
     *
     * @param context             上下文
     * @param contentVersionQuery 查询条件
     * @return 监测代码
     */
    public List<ContentVersionDTO> findContentVersionList(ServiceContext context, ContentVersionQuery contentVersionQuery) {
        MultiResponse<ContentVersionDTO> response = contentVersionQueryService.findContentVersionList(context, contentVersionQuery);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 添加监测代码
     *
     * @param context           上下文
     * @param contentVersionDTO 内容
     * @return 返回
     */
    public ContentVersionDTO addContentVersion(ServiceContext context, ContentVersionDTO contentVersionDTO) {
        SingleResponse<ContentVersionDTO> response = contentVersionCommandService.addContentVersion(context, contentVersionDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    public MaterialGroupDTO getMaterialGroupById(ServiceContext serviceContext, Long id) {
        SingleResponse<MaterialGroupDTO> response =
                materialGroupQueryService.getMaterialGroupById(getCreativeServiceContext(serviceContext), id, new MaterialGroupQueryOption.Builder().all().build());
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    public void updateMaterialGroupPart(ServiceContext serviceContext, MaterialGroupDTO materialGroupDTO) {
        SingleResponse<Long> response = materialGroupCommandService.updateMaterialGroupPart(getCreativeServiceContext(serviceContext), materialGroupDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
    }

    public void updateMaterialPart(ServiceContext serviceContext, MaterialDTO materialDTO, MaterialUpdateOptionDTO materialUpdateOptionDTO) {
        SingleResponse<Integer> response = materialCommandService.updateMaterialPart(getCreativeServiceContext(serviceContext), materialDTO, materialUpdateOptionDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
    }

    public void batchUpdateMaterialPart(ServiceContext serviceContext, List<MaterialDTO> materialDTOList, MaterialUpdateOptionDTO materialUpdateOptionDTO) {
        SingleResponse<Integer> response = materialCommandService.updateMaterialPart(getCreativeServiceContext(serviceContext), materialDTOList, materialUpdateOptionDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
    }

    private NbDirectServiceContext initUdServiceContext() {
        Long dspId = 121507994L;
        Long memberId = 3833238314L;
        Long masterId = 3099266L;
        Long cusMemberId = 3833088529L;
        Long brandId = 363324850L;

        NbDirectServiceContext serviceContext = new NbDirectServiceContext();
        serviceContext.setDspId(dspId);
        serviceContext.setBizKey("common");
        serviceContext.setAbilityCode(BizAbilityEnum.PMP.getCode());
        serviceContext.setBizCode(UserTypeEnum.INNER.getCode());
        //产研空间
        serviceContext.setUser(new UserDTO());
        serviceContext.getUser().setMemberId(memberId);
        serviceContext.getUser().addMasterProperty(masterId);
        serviceContext.getUser().addBrandProperty(brandId);
        serviceContext.getUser().addUserTypeProperty(UserTypeEnum.INNER.getValue());
        serviceContext.getUser().addCusMemberIdProperty(cusMemberId);
        serviceContext.getUser().setUserTag(UserDTO.UserTagEnum.UD_BRAND.getValue());
        serviceContext.getUser().setLoginType(UserDTO.LoginTypeEnum.MAIN.getValue());

        serviceContext.setMemberId(memberId);
        serviceContext.setCusMemberId(cusMemberId);
        serviceContext.setOpUserId(masterId);

        return serviceContext;
    }

    public void syncItemBizInfo(ServiceContext context, CreativeItemBizInfoViewDTO creativeItemBizInfoViewDTO) {
        ItemBizInfoSyncDTO itemBizInfoSyncDTO = BeanUtils.copyIgnoreNull(creativeItemBizInfoViewDTO, new ItemBizInfoSyncDTO());
        RogerLogger.info("syncItemBizInfo itemBizInfoSyncDTO:{}", JSON.toJSONString(itemBizInfoSyncDTO));
        try {
            retryer.call(() -> iSearchDataDumpService.syncItemBizInfo(itemBizInfoSyncDTO));
        } catch (Exception e) {
            RogerLogger.error("retry syncItemBizInfo error {}", e.getMessage(), e);
        }
    }
}