package com.taobao.ad.brand.bp.adapter.port.repository.dmpargues;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.nb.packages.constant.ud.RuleComparatorEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.motion.MotionSourceEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.product.ProductAmountSettingTypeEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleProductLineEnum;
import com.alibaba.fastjson.JSONObject;
import com.alimama.faas.brand.engine.entity.constant.BizType;
import com.alimama.faas.brand.engine.entity.constant.CastType;
import com.alimama.faas.brand.engine.entity.constant.TargetType;
import com.alimama.faas.brand.engine.entity.domain.*;
import com.alimama.faas.brand.engine.entity.request.AICreativePredictRequest;
import com.alimama.faas.brand.engine.entity.request.PreStrategyRcmdRequest;
import com.alimama.faas.brand.engine.entity.response.AICreativePredictResponse;
import com.alimama.faas.brand.engine.entity.response.PreStrategyRcmdResponse;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.dmpargus.DmpArgusSAO;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.perform.PerformSAO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.DmpArgusEstimateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.SaleGroupBaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.SaleGroupProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeScoreUnitViewDTO;
import com.taobao.ad.brand.bp.client.dto.motion.IntelligentMotionViewDTO;
import com.taobao.ad.brand.bp.client.dto.motion.MarketingStageViewDTO;
import com.taobao.ad.brand.bp.client.dto.motion.ResourceTypeRatioViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.AdzoneViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductPriceViewDTO;
import com.taobao.ad.brand.bp.client.enums.EstimateDimensionTypeEnum;
import com.taobao.ad.brand.bp.common.enums.BooleanEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.CalculateUtil;
import com.taobao.ad.brand.bp.domain.config.SelfServiceTestMemberConfig;
import com.taobao.ad.brand.bp.domain.dmpargus.DmpArgusRepository;
import com.taobao.ad.brand.perform.client.dto.shopwindow.spu.marketingrule.SpuCheckMarketingRuleViewDTO;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/24
 **/
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DmpArgusRepositoryImpl implements DmpArgusRepository {

    private final DmpArgusSAO dmpArgusSAO;
    private final PerformSAO performSAO;
    private final SelfServiceTestMemberConfig selfServiceTestMemberConfig;
    @Override
    public void calculateIntelligentMotionAndStrategy(ServiceContext serviceContext, DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO) {
        PreStrategyRcmdRequest preStrategyRcmdRequest = initPreStrategyRcmdRequest(serviceContext, dmpArgusEstimateViewDTO);
        preStrategyRcmdRequest.setSync(BrandBoolEnum.BRAND_FALSE.getCode());
        Map<String, Object> param = (Map<String, Object>) JSONObject.toJSON(preStrategyRcmdRequest);
        dmpArgusSAO.asyncDmpArgusInvoke(serviceContext, dmpArgusEstimateViewDTO.getServiceCode(), param);
    }

    @Override
    public PreStrategyRcmdResponse updateIntelligentStrategy(ServiceContext serviceContext, DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO) {
        PreStrategyRcmdRequest preStrategyRcmdRequest = initPreStrategyRcmdRequest(serviceContext, dmpArgusEstimateViewDTO);
        preStrategyRcmdRequest.setSync(BrandBoolEnum.BRAND_TRUE.getCode());
        Map<String, Object> param = (Map<String, Object>) JSONObject.toJSON(preStrategyRcmdRequest);
        return dmpArgusSAO.dmpArgusInvoke(serviceContext, dmpArgusEstimateViewDTO.getServiceCode(), param);
    }

    @Override
    public AICreativePredictResponse predictCreativeScore(ServiceContext serviceContext, List<CreativeScoreUnitViewDTO> creativeScoreUnitViewDTOList) {
        AICreativePredictRequest request = initAICreativePredictRequest(serviceContext, creativeScoreUnitViewDTOList);
        Map<String, Object> param = (Map<String, Object>) JSONObject.toJSON(request);
        return dmpArgusSAO.dmpArgusInvokeForPredictCreativeScore(serviceContext, param);
    }

    /**
     * 构建B端引擎查询参数
     * */
    private PreStrategyRcmdRequest initPreStrategyRcmdRequest(ServiceContext serviceContext, DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO) {
        IntelligentMotionViewDTO intelligentMotionViewDTO = dmpArgusEstimateViewDTO.getIntelligentMotionViewDTO();
        SaleGroupBaseViewDTO saleGroupBaseViewDTO = dmpArgusEstimateViewDTO.getSaleGroupBaseViewDTO();
        PreStrategyRcmdRequest preStrategyRcmdRequest = new PreStrategyRcmdRequest();
        if (EstimateDimensionTypeEnum.MOTION.getValue().equals(dmpArgusEstimateViewDTO.getEstimateDimensionType())) {
            preStrategyRcmdRequest.setBizType(MotionSourceEnum.PRE_STRATEGY.getValue().equals(dmpArgusEstimateViewDTO.getIntelligentMotionViewDTO().getSource())
                    ? BizType.PRE_RESOURCE_RECOMMEND_PRICE_STAGE : BizType.BRAND_WINDOW_RECOMMEND);
        // stimateDimensionType = 5（智能策略） 表示百灵投前策略针对已有的策略进行预估数据实时更新，或者生成自定义策略的过程，通过调引擎是同步调用还是异步调用区分预估数据更新和生成新的策略
        } else if (EstimateDimensionTypeEnum.STRATEGY.getValue().equals(dmpArgusEstimateViewDTO.getEstimateDimensionType())) {
            preStrategyRcmdRequest.setBizType(BizType.PRE_RESOURCE_ESTIMATE_PRICE_STAGE);
        }
        preStrategyRcmdRequest.setProposalId(intelligentMotionViewDTO.getId());
        preStrategyRcmdRequest.setSaleGroupId(intelligentMotionViewDTO.getSaleGroupId());
        preStrategyRcmdRequest.setProposalBudget(intelligentMotionViewDTO.getBudget());
        preStrategyRcmdRequest.setProposalStartTime(intelligentMotionViewDTO.getStartTime());
        preStrategyRcmdRequest.setProposalEndTime(intelligentMotionViewDTO.getEndTime());
        preStrategyRcmdRequest.setMemberId(dmpArgusEstimateViewDTO.getMemberId());
        preStrategyRcmdRequest.setDeliverTargetList(intelligentMotionViewDTO.getAttentionTargetViewDTOList().stream().map(item -> {
            TargetConfig deliverTarget = new TargetConfig();
            deliverTarget.setTargetId(TargetType.getByValue(item.getAttentionTarget()));
            //TODO 下次迭代时记得推进交付指标由枚举改成数字
//            deliverTarget.setTargetTypeId(item.getAttentionTarget());
            return deliverTarget;
        }).collect(Collectors.toList()));
        // 2024年04月24日 与B端引擎确认， 暂时不传优化目标
        preStrategyRcmdRequest.setOptimizeTargetList(Lists.newArrayList());
        preStrategyRcmdRequest.setCrowdList(intelligentMotionViewDTO.getCrowdIdList());
        preStrategyRcmdRequest.setShopId(dmpArgusEstimateViewDTO.getShopId());
        if (Objects.nonNull(saleGroupBaseViewDTO)) {
            preStrategyRcmdRequest.setSaleType(saleGroupBaseViewDTO.getSaleType());
            preStrategyRcmdRequest.setProductConfigType(saleGroupBaseViewDTO.getProductConfigType());
        }
        preStrategyRcmdRequest.setMarketingStageList(getMarketingStageConfigList(intelligentMotionViewDTO.getMarketingStageViewDTOList()));

        List<MediaPreferenceConfig> mediaPreferenceList = Lists.newArrayList();
        if (CollectionUtils.isNotEmpty(intelligentMotionViewDTO.getIncludeMediaList())) {
            mediaPreferenceList.addAll(intelligentMotionViewDTO.getIncludeMediaList().stream().map(it -> {
                MediaPreferenceConfig mediaPreferenceConfig = new MediaPreferenceConfig();
                mediaPreferenceConfig.setSiteId(it);
                mediaPreferenceConfig.setType(BooleanEnum.TRUE.getValue());
                return mediaPreferenceConfig;
            }).collect(Collectors.toList()));
        }
        if (CollectionUtils.isNotEmpty(intelligentMotionViewDTO.getExcludeMediaList())) {
            mediaPreferenceList.addAll(intelligentMotionViewDTO.getExcludeMediaList().stream().map(it -> {
                MediaPreferenceConfig mediaPreferenceConfig = new MediaPreferenceConfig();
                mediaPreferenceConfig.setSiteId(it);
                mediaPreferenceConfig.setType(BooleanEnum.FALSE.getValue());
                return mediaPreferenceConfig;
            }).collect(Collectors.toList()));
        }
        preStrategyRcmdRequest.setMediaPreferenceList(mediaPreferenceList);
        List<CastType> castTypeList = Lists.newArrayList();
        if (CollectionUtils.isNotEmpty(intelligentMotionViewDTO.getCastTypeList())) {
            castTypeList.addAll(intelligentMotionViewDTO.getCastTypeList().stream().map(CastType::getByCode).collect(Collectors.toList()));
        }
        preStrategyRcmdRequest.setCastTypeList(castTypeList);

        preStrategyRcmdRequest.setResourcePreferenceList(getResourcePreferenceConfigList(intelligentMotionViewDTO.getResourceTypeRatioViewDTOList()));
        Date startTime = CollectionUtils.isNotEmpty(intelligentMotionViewDTO.getMarketingStageViewDTOList()) ? intelligentMotionViewDTO.getMarketingStageViewDTOList().stream().min(Comparator.comparing(MarketingStageViewDTO::getStartTime)).get().getStartTime() : intelligentMotionViewDTO.getStartTime();
        Date endTime = CollectionUtils.isNotEmpty(intelligentMotionViewDTO.getMarketingStageViewDTOList()) ? intelligentMotionViewDTO.getMarketingStageViewDTOList().stream().max(Comparator.comparing(MarketingStageViewDTO::getEndTime)).get().getEndTime() : intelligentMotionViewDTO.getEndTime();
        Integer motionSource = dmpArgusEstimateViewDTO.getIntelligentMotionViewDTO().getSource();
        List<SaleGroupProductViewDTO> saleGroupProductViewDTOList = MotionSourceEnum.PRE_STRATEGY.getValue().equals(motionSource) ? saleGroupBaseViewDTO.getSaleGroupProductViewDTOList() : dmpArgusEstimateViewDTO.getSaleGroupProductViewDTOList();
        preStrategyRcmdRequest.setResourcePackageConfigList(buildMotionResourceConfigList(startTime, endTime, saleGroupProductViewDTOList, motionSource , preStrategyRcmdRequest));
        AssertUtil.notEmpty(preStrategyRcmdRequest.getResourcePackageConfigList(), "透传算法资源包配置不能为空");
        if (CollectionUtils.isNotEmpty(dmpArgusEstimateViewDTO.getDistributionRuleViewDTOList())) {
            preStrategyRcmdRequest.setClassificationResourceList(dmpArgusEstimateViewDTO.getDistributionRuleViewDTOList().stream().map(item -> {
                ClassifiedResourceConfig config = new ClassifiedResourceConfig();
                config.setCategory(item.getCategory());
                config.setRatio(item.getRatio());
                config.setMinProductNum(item.getMinQuality());
                config.setMaxProductNum(item.getMaxQuality());
                return config;
            }).collect(Collectors.toList()));
        }
        preStrategyRcmdRequest.setBgtConfig(getBgtTS(serviceContext, dmpArgusEstimateViewDTO));
        //页面创建自定义策略时传入  不包含单独修改产品预算生成新策略场景
        if (Objects.nonNull(saleGroupBaseViewDTO)) {
            preStrategyRcmdRequest.setStrategyId(saleGroupBaseViewDTO.getStrategyId());
        }
        return preStrategyRcmdRequest;
    }

    private AICreativePredictRequest initAICreativePredictRequest(ServiceContext serviceContext, List<CreativeScoreUnitViewDTO> creativeScoreUnitViewDTOList) {
        List<CreativeInfo> creativeInfoList = Lists.newArrayList();
        creativeScoreUnitViewDTOList.forEach(scoreUnit -> {
            CreativeInfo creativeInfo = new CreativeInfo(
                    scoreUnit.getCreativeId(),
                    scoreUnit.getCreativeImageUrl(),
                    scoreUnit.getCreativeTemplateName(),
                    scoreUnit.getCrowdIds(),
                    scoreUnit.getUniqueKey(),
                    null,
                    null
            );
            creativeInfoList.add(creativeInfo);
        });

        AICreativePredictRequest request = new AICreativePredictRequest();
        request.setMemberId(serviceContext.getMemberId());
        request.setCreativeInfoList(creativeInfoList);
        return request;
    }

    private List<BgtT> getBgtTS(ServiceContext serviceContext, DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO) {
        List<BgtT> bgtConfig = Lists.newArrayList();
        if (CollectionUtils.isEmpty(dmpArgusEstimateViewDTO.getCartItemViewDTOList())) {
            return bgtConfig;
        }
        Map<Long, List<CartItemViewDTO>> spuCartItemMap = dmpArgusEstimateViewDTO.getCartItemViewDTOList().stream().collect(Collectors.groupingBy(CartItemViewDTO::getSpuId));
        List<SpuCheckMarketingRuleViewDTO> spuCheckMarketingRuleViewDTOList = performSAO.getCheckMarketingRule(serviceContext);
        if (CollectionUtils.isNotEmpty(spuCheckMarketingRuleViewDTOList)) {
            bgtConfig.addAll(spuCheckMarketingRuleViewDTOList.stream().map(it -> {
                BgtT bgtT = new BgtT();
                bgtT.setCartId(it.getSpuIdList().stream().filter(spuCartItemMap::containsKey).flatMap(spuId -> spuCartItemMap.get(spuId).stream().map(CartItemViewDTO::getId).collect(Collectors.toList()).stream()).collect(Collectors.toList()));
                bgtT.setType(BrandBoolEnum.BRAND_TRUE.getCode());
                bgtT.setValue(it.getBudget());
                return bgtT;
            }).filter(it -> CollectionUtils.isNotEmpty(it.getCartId())).collect(Collectors.toList()));
        }
        List<CartItemViewDTO> superUniverseCartItemViewDTOList = dmpArgusEstimateViewDTO
                .getCartItemViewDTOList()
                .stream()
                .filter(it -> SaleProductLineEnum.SUPER_UNIVERSE.getValue().equals(dmpArgusEstimateViewDTO.getSkuSaleProductLineMap().get(it.getSkuId())))
                .collect(Collectors.toList());
        if (CollectionUtils.isEmpty(selfServiceTestMemberConfig.getSelfSpuMarketingRuleMemberList()) || !selfServiceTestMemberConfig.getSelfSpuMarketingRuleMemberList().contains(serviceContext.getMemberId())) {
            if (CollectionUtils.isNotEmpty(superUniverseCartItemViewDTOList)) {
                bgtConfig.addAll(superUniverseCartItemViewDTOList.stream().map(it -> {
                    BgtT bgtT = new BgtT();
                    bgtT.setCartId(Lists.newArrayList(it.getId()));
                    bgtT.setType(BrandBoolEnum.BRAND_TRUE.getCode());
                    bgtT.setValue(10000000L);
                    return bgtT;
                }).filter(it -> CollectionUtils.isNotEmpty(it.getCartId())).collect(Collectors.toList()));
            }
        }
        return bgtConfig;
    }

    private List<MarketingStageConfig> getMarketingStageConfigList(List<MarketingStageViewDTO> marketingStageViewDTOList) {
        if (CollectionUtils.isEmpty(marketingStageViewDTOList)) {
            return Lists.newArrayList();
        }
        return marketingStageViewDTOList.stream().map(it -> {
            MarketingStageConfig marketingStageConfig = new MarketingStageConfig();
            marketingStageConfig.setStageName(it.getName());
            marketingStageConfig.setStageRatio(it.getRatio());
            marketingStageConfig.setStartTime(it.getStartTime());
            marketingStageConfig.setEndTime(it.getEndTime());
            return marketingStageConfig;
        }).collect(Collectors.toList());
    }

    private List<ResourcePreferenceConfig> getResourcePreferenceConfigList(List<ResourceTypeRatioViewDTO> resourceTypeRatioViewDTOList) {
        if (CollectionUtils.isEmpty(resourceTypeRatioViewDTOList)) {
            return Lists.newArrayList();
        }
        return resourceTypeRatioViewDTOList.stream().map(it -> {
            ResourcePreferenceConfig resourcePreferenceConfig = new ResourcePreferenceConfig();
            resourcePreferenceConfig.setResourceType(it.getResourceType());
            resourcePreferenceConfig.setValue(it.getRatio());
            resourcePreferenceConfig.setType(RuleComparatorEnum.GE.getValue().equals(it.getComparator()) ? BooleanEnum.TRUE.getValue() : BooleanEnum.FALSE.getValue());
            return resourcePreferenceConfig;
        }).collect(Collectors.toList());
    }

    private List<ResourceConfig> buildMotionResourceConfigList(Date startTime, Date endTime, List<SaleGroupProductViewDTO> saleGroupProductViewDTOList, Integer motionSource, PreStrategyRcmdRequest preStrategyRcmdRequest){

        if (CollectionUtils.isNotEmpty(saleGroupProductViewDTOList)){

            Map<String,ClassifiedResourceConfig> classifiedResourceConfigMap= Optional.ofNullable(preStrategyRcmdRequest.getClassificationResourceList())
                    .orElse(Lists.newArrayList()).stream().collect(Collectors.toMap(ClassifiedResourceConfig::getCategory, Function.identity()));

            return saleGroupProductViewDTOList.stream().filter(it -> validDate(startTime, endTime, it, motionSource)).map(item->{
                ResourceConfig resourceConfig = new ResourceConfig();
                resourceConfig.setCartId(item.getCartId());
                resourceConfig.setResourceProductId(item.getResourceProductId());
                resourceConfig.setSspProductId(item.getSspProductId());
                resourceConfig.setSspProductUuid(item.getSspProductUuid());
                resourceConfig.setUnitExposure(item.getUnitExposure());
                resourceConfig.setTemplateId(item.getTemplateIdList());
                resourceConfig.setPromiseClick(item.getPromiseClick());
                resourceConfig.setClickRate(item.getClickRate());
                resourceConfig.setMediaScope(item.getMediaScope());
                resourceConfig.setSspResourceTypes(item.getSspResourceTypes());
                resourceConfig.setPidList(buildPidInfoList(item.getAdzoneViewDTOList()));
                resourceConfig.setSaleUnit(item.getSaleUnit());
                resourceConfig.setCastType(item.getCastType());
                resourceConfig.setCategory(item.getCategory());
                ClassifiedResourceConfig classifiedResourceConfig = classifiedResourceConfigMap.get(item.getCategory());
                List<PriceStageConfig> priceStageList = Lists.newArrayList();
                if (CollectionUtils.isNotEmpty(item.getBandPriceList())) {
                    priceStageList.addAll(item.getBandPriceList().stream().filter(productPrice -> BrandDateUtil.isMixed(productPrice.getStartDate(), productPrice.getEndDate(), startTime, endTime)).map(productPrice -> {
                        PriceStageConfig priceStageConfig = new PriceStageConfig();
                        priceStageConfig.setResourceStartTime(productPrice.getStartDate().before(startTime) ? startTime : productPrice.getStartDate());
                        priceStageConfig.setResourceEndTime(productPrice.getEndDate().after(endTime) ? endTime : productPrice.getEndDate());
                        priceStageConfig.setSettlePrice(productPrice.getPrice());
                        priceStageConfig.setBudget(productPrice.getActualAmount());
                        priceStageConfig.setType(productPrice.getType());
                        priceStageConfig.setMinRatio(productPrice.getMinRatio());
                        priceStageConfig.setCastAmount(productPrice.getCastAmount());
                        if (ProductAmountSettingTypeEnum.MIN_RATE.getValue().equals(productPrice.getType())
                                && classifiedResourceConfig != null) {
                            Long budget = CalculateUtil.multiplyCalculate(preStrategyRcmdRequest.getProposalBudget(), classifiedResourceConfig.getRatio().longValue(), 10000L, RoundingMode.DOWN);
                            priceStageConfig.setCastAmount(CalculateUtil.multiplyCalculate(budget, productPrice.getMinRatio().longValue(), 10000L, RoundingMode.DOWN));
                        }
                        return priceStageConfig;
                    }).collect(Collectors.toList()));
                }
                resourceConfig.setPriceStageList(priceStageList);
                return resourceConfig;
            }).collect(Collectors.toList());
        }
        return Lists.newArrayList();

    }

    public List<PidInfo> buildPidInfoList(List<AdzoneViewDTO> adzoneViewDTOList) {
        return Optional.ofNullable(adzoneViewDTOList).orElse(Lists.newArrayList()).stream().map(item -> {
            PidInfo pidInfo = new PidInfo();
            pidInfo.setPid(item.getPid());
            pidInfo.setMediaScope(item.getMediaScope());
            pidInfo.setResourceType(item.getResourceType());
            return pidInfo;
        }).collect(Collectors.toList());
    }

    private boolean validDate(Date startTime, Date endTime, SaleGroupProductViewDTO saleGroupProductViewDTO, Integer motionSource) {
        Boolean flag = true;
        if (MotionSourceEnum.PRE_STRATEGY.getValue().equals(motionSource)) {
            for (ResourcePackageProductPriceViewDTO productPriceViewDTO : saleGroupProductViewDTO.getBandPriceList()) {
                if (productPriceViewDTO.getStartDate().after(endTime) || productPriceViewDTO.getEndDate().before(startTime)) {
                    flag = false;
                    break;
                }
            }
        } else {
            flag = saleGroupProductViewDTO.getBandPriceList().stream().anyMatch(it -> BrandDateUtil.isMixed(it.getStartDate(), it.getEndDate(), startTime, endTime));
        }
        return flag;
    }

}
