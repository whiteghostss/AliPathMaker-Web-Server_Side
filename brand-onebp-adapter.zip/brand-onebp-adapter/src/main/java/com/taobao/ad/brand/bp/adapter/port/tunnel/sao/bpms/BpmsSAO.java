package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.bpms;

import java.util.Map;

import com.alibaba.alipmc.api.ProcessInstanceService;
import com.alibaba.alipmc.api.model.bpm.ProcessInstance;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.EmpUtil;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import lombok.RequiredArgsConstructor;

/**
 * @author yanjingang
 * @date 2023/3/20
 */
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BpmsSAO extends BaseSAO {

    private final ProcessInstanceService processInstanceService;
    private static final String appEmpId = "WORKER_1469443129435";
    @Value("${bpms.brandonebp.auth-key}")
    private String authKey;

    /**
     * 发起工作流
     *
     * @param title
     * @param titleEn
     * @param empId
     * @param initData
     * @param processCode
     * @return
     */
    public ProcessInstance startProcessInstance(String title,
                                                String titleEn, String empId,
                                                Map<String, String> initData, String processCode) {
        empId = StringUtils.isBlank(empId) ? appEmpId : EmpUtil.standardizeEmpNo(empId);
        ProcessInstance processInstance = processInstanceService.startProcessInstanceInternational(
                processCode, title, titleEn,
                empId, initData, authKey);
        AssertUtil.assertTrue(processInstance != null, BrandOneBPBaseErrorCode.RPC_ERROR, "审批流程发起错误，请稍后重试！");
        return processInstance;
    }
}
