package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.permission;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.uic.api.auth.AuthUserAssetRangeQueryService;
import com.alibaba.ad.uic.api.rolepermission.PermissionGroupQueryService;
import com.alibaba.ad.uic.common.dto.auth.AuthUserAssetRangeDTO;
import com.alibaba.ad.uic.dto.admin.permission.PermissionGroupBindDTO;
import com.alibaba.ad.uic.dto.permission.query.PermissionGroupBindQueryDTO;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.PageUtil;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;

import java.util.List;
import java.util.Optional;

import static com.taobao.ad.brand.bp.common.util.PageUtil.getTotalPage;

/**
 * @author 虫洞 <liuming.liu@alibaba-inc.com>
 * @date 2023/4/3
 */
@BizTunnel
@RequiredArgsConstructor
public class PermissionSAO {
    private final PermissionGroupQueryService permissionGroupQueryService;

    private final AuthUserAssetRangeQueryService authUserAssetRangeQueryService;

    /**
     * 查询生态伙伴广告主员工绑定的权限信息
     *
     * @param advEmpTbNumId  员工淘宝tbNumId
     * @param advMemberId    员工所属商家/代理商/服务商的memberId
     * @param partnerAdvType 1-代理商 2-服务商
     * @return
     */
    public List<PermissionGroupBindDTO> findPartnerEmpBindPermissionGroup(ServiceContext serviceContext, Long advEmpTbNumId, Long advMemberId, Integer partnerAdvType) {
        AssertUtil.notNull(advEmpTbNumId, "查询权限时，广告主员工的淘宝账号ID为空");
        AssertUtil.notNull(advMemberId, "查询权限时，员工所属的广告主MemberID为空");
        AssertUtil.notNull(partnerAdvType, "查询权限时，员工所属的广告主类型为空");

        PermissionGroupBindQueryDTO queryDTO = new PermissionGroupBindQueryDTO();
        queryDTO.setEmployeeOutNumId(advEmpTbNumId);
        queryDTO.setEmployeeOwnerMemberId(advMemberId);
        queryDTO.setEmployeeOwnerAdvType(partnerAdvType);
        List<PermissionGroupBindDTO> bindPermissionGroupList = findBindPermissionGroup(serviceContext, queryDTO);

        return bindPermissionGroupList;
    }

    /**
     * 查询商家广告主员工绑定的权限信息
     *
     * @param advEmpTbNumId 员工淘宝tbNumId
     * @param advMemberId   员工所属商家/代理商/服务商的memberId
     * @param memberId      操作的投放账号
     * @return
     */
    public List<PermissionGroupBindDTO> findSellerEmpBindPermissionGroup(ServiceContext serviceContext, Long advEmpTbNumId, Long advMemberId, Long memberId) {
        AssertUtil.notNull(advEmpTbNumId, "查询权限时，广告主员工的淘宝账号ID为空");
        AssertUtil.notNull(advMemberId, "查询权限时，员工所属的广告主MemberID为空");
        AssertUtil.notNull(memberId, "查询权限时，操作的投放账号为空");

        PermissionGroupBindQueryDTO queryDTO = new PermissionGroupBindQueryDTO();
        queryDTO.setEmployeeOutNumId(advEmpTbNumId);
        queryDTO.setEmployeeOwnerMemberId(advMemberId);
        queryDTO.setOperateMemberId(memberId);
        queryDTO.setEmployeeOwnerAdvType(3);
        return findBindPermissionGroup(serviceContext, queryDTO);
    }

    /**
     * 查询内部小二绑定的权限信息
     *
     * @param bucId
     * @return
     */
    public List<PermissionGroupBindDTO> findAliEmpBindPermissionGroup(ServiceContext serviceContext, Long bucId) {
        AssertUtil.notNull(bucId, "小二bucId为空");
        PermissionGroupBindQueryDTO queryDTO = new PermissionGroupBindQueryDTO();
        queryDTO.setEmployeeOutNumId(bucId);
        queryDTO.setEmployeeOwnerAdvType(4);
        return findBindPermissionGroup(serviceContext, queryDTO);
    }

    /**
     * 查询memberid资产授权服务范围
     * @param memberId
     * @return
     */
    public List<AuthUserAssetRangeDTO> queryMemberAuthRange(Long memberId){
        long pageSize = 50L;//客户中心查询服务最多一次查询50
        List<AuthUserAssetRangeDTO> resultList = Lists.newArrayList();
        PageUtil.execute2(idx -> authUserAssetRangeQueryService.query(memberId, idx.longValue(), pageSize),
                resp -> {
                    //数据返回值小于查询的每页数量，认为查询结束
                    List<AuthUserAssetRangeDTO> authUserAssetRangeDTOList = Optional.ofNullable(resp.getResult()).orElse(Lists.newArrayList());
                    return authUserAssetRangeDTOList.size() < pageSize;
                },
                resp -> {
                    if(resp.isSuccess()){
                        List<AuthUserAssetRangeDTO> authUserAssetRangeDTOList = Optional.ofNullable(resp.getResult()).orElse(Lists.newArrayList());
                        resultList.addAll(authUserAssetRangeDTOList);
                    }else{
                        RogerLogger.info("客户中心服务调用失败，原因：{}",resp.getErrorMsg());
                    }
                });
        return resultList;
    }

    /**
     * 查询绑定的权限信息
     *
     * @param queryDTO {@link PermissionGroupBindQueryDTO#getEmployeeOutNumId()} 广告主员工淘宝tbNumId 或 小二bucId
     *                 {@link PermissionGroupBindQueryDTO#getEmployeeOwnerMemberId()} 员工所属商家/代理商/服务商的memberId；内部小二时不传
     *                 {@link PermissionGroupBindQueryDTO#getEmployeeOwnerAdvType()} 1-代理商 2-服务商 3-直客 4-内部小二
     *                 {@link PermissionGroupBindQueryDTO#getOperateMemberId()} 操作的投放账户，商家员工有场景将权限绑定到某个需要操作的投放账号上
     * @return
     */
    private List<PermissionGroupBindDTO> findBindPermissionGroup(ServiceContext serviceContext, PermissionGroupBindQueryDTO queryDTO) {
        MultiResponse<PermissionGroupBindDTO> response = permissionGroupQueryService.findBindPermissionGroup(serviceContext, queryDTO);
        AssertUtil.assertTrue(response.isSuccess(), "查询绑定的权限信息失败");
        return response.getResult();
    }
}
