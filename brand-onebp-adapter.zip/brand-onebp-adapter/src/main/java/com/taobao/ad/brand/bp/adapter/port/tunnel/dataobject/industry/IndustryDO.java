package com.taobao.ad.brand.bp.adapter.port.tunnel.dataobject.industry;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class IndustryDO {

    /**
     * 店铺id
     */
    @JsonProperty("shop_id")
    private Long shopId;

    /**
     * 主营行业大组ID（按照天猫行业结构打开）
     */
    @JsonProperty("industry_id")
    private Long industryId;

    /**
     * 主营行业大组名称（按照天猫行业结构打开）
     */
    @JsonProperty("industry_name")
    private String industryName;

    /**
     * 主营一级大类ID（按照天猫行业结构打开）
     */
    @JsonProperty("sub_industry_id")
    private Long subIndustryId;

    /**
     * 主营一级大类名称（按照天猫行业结构打开）
     */
    @JsonProperty("sub_industry_name")
    private String subIndustryName;

}
