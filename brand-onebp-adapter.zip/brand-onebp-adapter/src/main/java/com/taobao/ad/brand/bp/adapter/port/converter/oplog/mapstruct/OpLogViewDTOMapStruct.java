package com.taobao.ad.brand.bp.adapter.port.converter.oplog.mapstruct;

import com.alibaba.ad.oplog.dto.OpLogDTO;
import com.taobao.ad.brand.bp.client.dto.oplog.OpLogViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author jixiu.lj
 * @date 2024/3/21 10:23
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface OpLogViewDTOMapStruct extends BaseMapStructMapper<OpLogDTO, OpLogViewDTO> {
    OpLogViewDTOMapStruct INSTANCE = Mappers.getMapper(OpLogViewDTOMapStruct.class);

    @Override
    OpLogViewDTO sourceToTarget(OpLogDTO opLogDTO);
}
