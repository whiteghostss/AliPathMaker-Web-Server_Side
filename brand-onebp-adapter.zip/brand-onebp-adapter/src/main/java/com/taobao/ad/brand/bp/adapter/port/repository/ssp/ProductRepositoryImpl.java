package com.taobao.ad.brand.bp.adapter.port.repository.ssp;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.nb.crm.dto.dsp.DspMemberDTO;
import com.alibaba.ad.nb.crm.dto.dsp.DspMemberQueryDTO;
import com.alibaba.ad.nb.ssp.constant.newproduct.ProductDirectionEnum;
import com.alibaba.ad.nb.ssp.dto.dict.CategoryDTO;
import com.alibaba.ad.nb.ssp.dto.dict.CategoryQueryDTO;
import com.alibaba.ad.nb.ssp.dto.newproduct.ProductDTO;
import com.alibaba.ad.nb.ssp.dto.newproduct.ProductQueryDTO;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.adapter.port.converter.ssp.AreaConverter;
import com.taobao.ad.brand.bp.adapter.port.converter.ssp.DictionaryConverter;
import com.taobao.ad.brand.bp.adapter.port.converter.ssp.ProductConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.ssp.ProductSAO;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.TreeNodeViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.AreaViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductQueryOption;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.common.converter.campaign.CampaignTargetConverter;
import com.taobao.ad.brand.bp.domain.ssp.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @Description: 产品服务
 * @Author: dongyang
 * @Date: 2023/3/4
 */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ProductRepositoryImpl implements ProductRepository {

    private final ProductSAO productSAO;
    private final ProductConverter productConverter;
    private final AreaConverter areaConverter;
    private final DictionaryConverter dictionaryConverter;
    private final CampaignTargetConverter campaignTargetConverter;


    @Override
    public ProductViewDTO getProductWithTargetValue(Long id) {
        ProductDTO productDTO = productSAO.getProductById( id);
        return productConverter.convertDTO2ViewDTO(productDTO);
    }

    @Override
    public ProductViewDTO getProductById(Long id) {
        List<ProductViewDTO> productDTOList = this.getProductByIds(Lists.newArrayList(id));
        return CollectionUtils.isNotEmpty(productDTOList) ? productDTOList.get(0) : null;
    }

    @Override
    public List<ProductViewDTO> getProductByIds(List<Long> ids) {
        if(CollectionUtils.isEmpty(ids)){
            return Lists.newArrayList();
        }
        ProductQueryOption productQueryOption = ProductQueryOption.builder()
                .needDirectionFirstNode(true)
//                .needDirection(true)
                .needAssociationProduct(true)
                .needAdzone(true)
                .needResource(true)
                .needParentName(true)
                .needLabelName(true)
                .needTemplateName(true)
                .build();
        return getProductByIdsOption(ids, productQueryOption);
    }

    @Override
    public List<ProductViewDTO> getProductByIdsOption(List<Long> ids, ProductQueryOption productQueryOption) {
        if(CollectionUtils.isEmpty(ids)){
            return Lists.newArrayList();
        }
        ProductQueryDTO productQueryDTO = new ProductQueryDTO();
        productQueryDTO.setProductIdList(ids);
        productQueryDTO.setNeedResource(productQueryOption.isNeedResource());
        productQueryDTO.setNeedAdzone(productQueryOption.isNeedAdzone());
        productQueryDTO.setNeedAssociationProduct(productQueryOption.isNeedAssociationProduct());
        productQueryDTO.setNeedDirection(productQueryOption.isNeedDirection());
        productQueryDTO.setNeedDirectionFirstNode(productQueryOption.isNeedDirectionFirstNode());
        productQueryDTO.setNeedTemplateName(productQueryOption.isNeedTemplateName());
        productQueryDTO.setNeedParentName(productQueryOption.isNeedParentName());
        productQueryDTO.setNeedLabelName(productQueryOption.isNeedLabelName());
        productQueryDTO.setPageSize(ids.size());

        List<ProductDTO> productDTOList = productSAO.getProductList(productQueryDTO);
        return productConverter.convertDTO2ViewDTOList(productDTOList);
    }

    @Override
    public Map<Long, ProductViewDTO> getProductMapByIds(List<Long> ids) {
        if(CollectionUtils.isEmpty(ids)){
            return Maps.newHashMap();
        }
        List<ProductViewDTO> productDTOList = getProductByIds(ids);
        return productDTOList.stream().collect(Collectors.toMap(ProductViewDTO::getId, m->m));
    }

    @Override
    public List<ProductViewDTO> getProductByUuids(List<Long> ids) {
        if(CollectionUtils.isEmpty(ids)){
            return Lists.newArrayList();
        }
        List<ProductDTO> productDTOList = productSAO.getProductByUuid(ids);
        return productConverter.convertDTO2ViewDTOList(productDTOList);
    }

    @Override
    public List<ProductViewDTO> getProductByUuidOption(List<Long> uuids, ProductQueryOption productQueryOption) {
        List<ProductDTO> productDTOList = productSAO.getProductByQuery(uuids, productQueryOption);
        return productConverter.convertDTO2ViewDTOList(productDTOList);

    }

    @Override
    public List<CommonViewDTO> getAreaList(ServiceContext serviceContext) {
        return areaConverter.convertDTO2ViewDTOList(productSAO.getSSPArea(serviceContext));
    }

    public List<AreaViewDTO> getAreaList(ServiceContext serviceContext, List<Integer> areaIds ) {
        return areaConverter.convertToViewDTOList(productSAO.getSSPArea(areaIds));
    }

    public List<TreeNodeViewDTO> getAreaTreeList(ServiceContext serviceContext, List<Integer> areaValues) {
        List<AreaViewDTO> areaViewDTOS = getAreaList(serviceContext, null);
        Map<Integer, AreaViewDTO> areaMap = areaViewDTOS.stream().collect(Collectors.toMap(AreaViewDTO::getValue, Function.identity(), (v1, v2) -> v2));
        Map<Integer, AreaViewDTO> areaIdMap = areaViewDTOS.stream().collect(Collectors.toMap(AreaViewDTO::getId, Function.identity(), (v1, v2) -> v2));
        // 过滤地域value
        if (CollectionUtils.isNotEmpty(areaValues)) {
            areaViewDTOS.forEach(item -> item.setStatus(BrandBoolEnum.BRAND_FALSE.getCode()));
            for (Integer areaValue : areaValues) {
                if (areaMap.containsKey(areaValue)) {
                    AreaViewDTO areaDTO = areaMap.get(areaValue);
                    // 将该节点与父节点均设置为有效
                    while (Objects.nonNull(areaDTO)) {
                        areaDTO.setStatus(BrandBoolEnum.BRAND_TRUE.getCode());
                        if (areaDTO.getParentId() == -1) {
                            break;
                        }
                        areaDTO = areaIdMap.get(areaDTO.getParentId());
                    }
                }
            }
        }
        List<AreaViewDTO> validAreaList = areaViewDTOS.stream().filter(e -> BrandBoolEnum.BRAND_TRUE.getCode().equals(e.getStatus())).collect(Collectors.toList());
        return areaConverter.buildAreaTreeNode(validAreaList);
    }

    @Override
    public List<CommonViewDTO> getSSPDict(String type) {
        return dictionaryConverter.convertDTO2ViewDTOList(productSAO.getSSPDict(type));
    }

    @Override
    public List<TreeNodeViewDTO> getDicTreeByType(String type, List<String> values) {
        List<CommonViewDTO> sspDictList = getSSPDict(type);
        if (CollectionUtils.isNotEmpty(values)) {
            sspDictList = sspDictList.stream().filter(e -> values.contains(e.getValue())).collect(Collectors.toList());
        }
        return campaignTargetConverter.buildTreeNode(type, sspDictList);
    }

    @Override
    public List<CommonViewDTO> getSSPMedia(List<String> ids) {
        String type = com.alibaba.ad.nb.ssp.constant.common.DictTypeEnum.UNIFIED_MEDIA_ID.getType();
        return dictionaryConverter.convertDTO2ViewDTOList(productSAO.getSSPDict(type, ids));
    }

    @Override
    public List<CommonViewDTO> getSSPChannel() {
        CategoryQueryDTO categoryQueryDTO = new CategoryQueryDTO();
        categoryQueryDTO.setNeedPage(false);
        List<CategoryDTO> sspChannelList = productSAO.getSSPChannel(categoryQueryDTO);
        List<CommonViewDTO> channelList = Optional.ofNullable(sspChannelList).orElse(Lists.newArrayList()).stream()
                .map(categoryDTO -> {
                    CommonViewDTO dictionaryDTO = new CommonViewDTO();
                    dictionaryDTO.setValue(categoryDTO.getCategoryCode());
                    dictionaryDTO.setName(categoryDTO.getCategoryName());
                    return dictionaryDTO;
                }).distinct().collect(Collectors.toList());
        return channelList;
    }

    @Override
    public Map<String, CommonViewDTO> getSSPTerminalMap() {
        String type = ProductDirectionEnum.DEVICE.getType();
        List<CommonViewDTO> terminalList = getSSPDict(type);
        return terminalList.stream().collect(Collectors.toMap(m->m.getValue(), m->m));
    }

    @Override
    public List<CommonViewDTO> getSSPDict(String type, List<String> ids) {
        return dictionaryConverter.convertDTO2ViewDTOList(productSAO.getSSPDict(type, ids));
    }

    public List<CommonViewDTO> getDspList(ServiceContext serviceContext) {
        DspMemberQueryDTO queryDTO = new DspMemberQueryDTO();
        List<DspMemberDTO> dspList = productSAO.getDspList(serviceContext, queryDTO);
        return dspList.stream().map(dspMemberDTO -> {
            CommonViewDTO commonViewDTO = new CommonViewDTO();
            commonViewDTO.setName(dspMemberDTO.getDspName());
            commonViewDTO.setId(dspMemberDTO.getMemberId());
            return commonViewDTO;
        }).collect(Collectors.toList());
    }

    @Override
    public List<CommonViewDTO> getShowPositionList(String type, List<String> positionValueList) {
        //位置位序两级结构
        Map<String,CommonViewDTO> showPositonMap = Maps.newHashMap();
        List<CommonViewDTO> sspPositionList = getSSPDict(type);
        for (String value : positionValueList) {
            String parentValue = null;
            if (value.contains("_")) {
                parentValue = value.split("_")[0];
            }
            for (CommonViewDTO dictionaryDTO : sspPositionList) {
                if (Objects.equals(parentValue, dictionaryDTO.getValue())) {
                    showPositonMap.put(dictionaryDTO.getValue(), dictionaryDTO);
                }
                if (Objects.equals(value, dictionaryDTO.getValue())) {
                    showPositonMap.put(dictionaryDTO.getValue(), dictionaryDTO);
                }
            }
        }

        return Lists.newArrayList(showPositonMap.values());
    }
}
