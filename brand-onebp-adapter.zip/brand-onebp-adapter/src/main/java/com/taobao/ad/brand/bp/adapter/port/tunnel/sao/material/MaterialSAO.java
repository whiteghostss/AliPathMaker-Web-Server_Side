package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.material;


import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.taobao.ad.brand.bp.common.util.YksUtil;
import com.taobao.ad.brand.bp.domain.creative.spi.impl.protocol.context.material.YkVideo;
import com.taobao.ad.brand.bp.domain.creative.spi.impl.protocol.context.material.YkVideoDetail;
import com.taobao.ad.brand.bp.domain.creative.spi.impl.protocol.context.material.YkVideoStream;
import com.youku.java.yks.request.Extension;
import com.youku.java.yks.request.GetHSFParameter;
import com.youku.java.yks.response.*;
import com.youku.java.yks.service.YksPlayService;
import lombok.RequiredArgsConstructor;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.List;
import java.util.StringJoiner;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/3/31 10:40
 * @description ：
 * @modified By：
 */
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class MaterialSAO extends BaseSAO {

    private final YksPlayService yksPlayService;


    public YkVideoDetail getVideoFromYks(Long vid) {
        String encodeId = YksUtil.getVid64ByVid(vid);
        Extension extension = new Extension();
        extension.setHasMp4("1");

        GetHSFParameter parameter = new GetHSFParameter.GetHSFParameterBuilder(
                vid.toString(), "127.0.0.1", "50", "mobile", "video,error,stream"
        ).userId("94210860").ext(extension).build();

        YksGetAPIResponse response = yksPlayService.get(parameter);

        List<YksError> yksErrorList = response.getError();
        // 重试3次
        int retry = 3;
        while (yksErrorList != null && retry != 0) {
            response = yksPlayService.get(parameter);
            yksErrorList = response.getError();
            if (yksErrorList != null) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException ignore) {
                }
            }
            retry--;
        }
        if (yksErrorList != null) {
            StringJoiner errorInfo = new StringJoiner(",", "[", "]");
            for (YksError yksError : yksErrorList) {
                errorInfo.add(yksError.getAttr() + "=" + yksError.getDesc());
            }
            return null;
        }

        YksDataset dataset = response.getDataset();

        YkVideoDetail ykVideoDetail = new YkVideoDetail();
        ykVideoDetail.setVid(vid);

        List<YksStream> yksStreamList = dataset.getStream();
        for (YksStream yksStream : yksStreamList) {
            int idx = 0;
            for (Segment segment : yksStream.getSegments()) {
                YkVideoStream ykVideoStreamEty = new YkVideoStream();
                ykVideoStreamEty.setStreamType(yksStream.getStreamType());
                ykVideoStreamEty.setVid(vid);
                ykVideoStreamEty.setEncodeId(encodeId);
                ykVideoStreamEty.setFileId(segment.getFileId());
                ykVideoStreamEty.setFileKey(segment.getKey());
                ykVideoStreamEty.setSegIndex(idx);
                ykVideoStreamEty.setSize(Long.parseLong(segment.getSizeStr()));
                ykVideoStreamEty.setWidth(yksStream.getWidth());
                ykVideoStreamEty.setHeight(yksStream.getHeight());
                ykVideoStreamEty.setMd5(segment.getMd5());
                ykVideoStreamEty.setLogo(yksStream.getLogo());
                ykVideoStreamEty.setCdnUrl(getMp4Url(segment.getFileId(), yksStream.getStreamType()));
                ykVideoDetail.addVideoStream(ykVideoStreamEty);
                idx++;
            }
        }

        YksVideo yksVideo = dataset.getVideo();
        YkVideo ykVideoEty = new YkVideo();
        ykVideoEty.setVid(vid);
        ykVideoEty.setEncodeId(encodeId);
        ykVideoEty.setPlayUrl(YksUtil.getPlayUrlByVid(vid));
        ykVideoEty.setLogo(yksVideo.getLogo());
        long seconds = new BigDecimal(yksVideo.getSeconds()).setScale(0, BigDecimal.ROUND_HALF_UP).longValue();
        ykVideoEty.setSeconds(seconds);
        ykVideoEty.setTitle(yksVideo.getTitle());
        ykVideoDetail.setYkVideoEty(ykVideoEty);

        return ykVideoDetail;
    }

    private String getMp4Url(String fileid, String streamType) {
        String sid = "" + System.currentTimeMillis() + (1000 + (System.currentTimeMillis() % 1000))
                + ((int) (Math.random() * 9000) + 1000);
        String sidNew = "0" + sid.substring(1);
        String token = Integer.toString((int) (Math.random() * 9000) + 1000);

        String host = "vali.cp31.ott.cibntv.net";

        String abkey = "B";
        String secret = "2QwVfkT3I$6sVage*hhJ.2";
        String vkey = DigestUtils.md5Hex("/" + fileid + ".mp4" + "?ctype=50&sid=" + sidNew + "_00" + secret);
        String sign = DigestUtils.md5Hex(sidNew + ":@$ml6eU80E#Fbc.aA4YnbH8aUM9i0cSR0");

        String filePath = "/" + fileid + ".mp4";

        String secKey = YksUtil.genSec(filePath, host);

        String mp4Url = "https://" + host + "/youku/" + secKey + filePath + "?sid="
                + sidNew + "_00_" + abkey + vkey + "&sign=" + sign
                + "&ctype=50";
        return mp4Url;
    }
}
