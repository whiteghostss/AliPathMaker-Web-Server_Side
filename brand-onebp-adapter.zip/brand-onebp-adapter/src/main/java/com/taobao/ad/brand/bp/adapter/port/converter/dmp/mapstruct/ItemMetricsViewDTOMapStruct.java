package com.taobao.ad.brand.bp.adapter.port.converter.dmp.mapstruct;

import com.taobao.ad.brand.bp.client.dto.dmp.ItemMetricsViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.dmp.site.sdk.dto.ItemIndicatorDTO;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ItemMetricsViewDTOMapStruct extends BaseMapStructMapper<ItemIndicatorDTO, ItemMetricsViewDTO> {
    ItemMetricsViewDTOMapStruct INSTANCE = Mappers.getMapper(ItemMetricsViewDTOMapStruct.class);

    @Override
    ItemMetricsViewDTO sourceToTarget(ItemIndicatorDTO itemIndicatorDTO);

    @Override
    ItemIndicatorDTO targetToSource(ItemMetricsViewDTO itemMetricsViewDTO);
}
