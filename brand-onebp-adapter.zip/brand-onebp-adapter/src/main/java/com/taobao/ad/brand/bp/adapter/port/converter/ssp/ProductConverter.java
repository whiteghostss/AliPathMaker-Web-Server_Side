package com.taobao.ad.brand.bp.adapter.port.converter.ssp;

import com.alibaba.ad.nb.ssp.dto.newproduct.ProductDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.ssp.mapstruct.ProductMapStruct;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.springframework.stereotype.Component;

/**
 * @Description:
 * @Author: dongyang
 * @Date: 2023/3/4
 */
@Component
public class ProductConverter extends BaseViewDTOConverter<ProductDTO, ProductViewDTO> {

    @Override
    public BaseMapStructMapper<ProductDTO, ProductViewDTO> getBaseMapStructMapper() {
        return ProductMapStruct.INSTANCE;
    }
}
