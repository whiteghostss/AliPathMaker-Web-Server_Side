package com.taobao.ad.brand.bp.adapter.port.repository.promotion;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.hermes.framework.utils.BeanUtils;
import com.alimama.checkchain.client.internal.aop.annotation.RogerLog;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.promotioncenter.PromotionSAO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.sellercoupons.SellerCouponViewDTO;
import com.taobao.ad.brand.bp.client.dto.sellercoupons.SellerCouponsQueryViewDTO;
import com.taobao.ad.brand.bp.domain.promotion.PromotionRepository;
import com.taobao.promotioncenter.constants.CouponConstants;
import com.taobao.promotioncenter.coupon.dataobject.SellerCouponFull;
import com.taobao.promotioncenter.coupon.param.SellerCouponsParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @Author: PhilipFry
 * @createTime: 2023年09月14日 14:52:55
 * @Description:
 */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class PromotionRepositoryImpl implements PromotionRepository {
    private final PromotionSAO promotionSAO;

    @Override
    public PageResultViewDTO<SellerCouponViewDTO> querySellerCouponsList(ServiceContext context, SellerCouponsQueryViewDTO queryViewDTO) {

        SellerCouponsParam param = new SellerCouponsParam();
        //卖家ID，
        param.setSupplierId(queryViewDTO.getSellerId());
        //分页所需当前页数，从1开始 ///必填/////
        param.setCurrentPage(queryViewDTO.getPageNo());
        //分页所需 每页数量 最大255 一般20左右 ///必填/////
        param.setPageSize(queryViewDTO.getPageSize());
////查询来源 需要申请  ///必填//
////CouponSearchSourceEnum构造方法第一个参数填自己的业务，第二个参数填申请到sourceId（联系营销产品@沛淋）
//        CouponSearchSourceEnum couponSearchSourceEnum = new CouponSearchSourceEnum("查询来自某某业务", sourceId);
//        param.setQuerySource(couponSearchSourceEnum);
        //需要排除的业务单元 淘系请排除1688，填CouponConstants.BusinessUnit.ALI1688 ///必填///
        param.setNoBusinessUnit(String.valueOf(CouponConstants.BusinessUnit.ALI1688));

        //优惠券状态 可选
        param.setStatus(com.taobao.promotioncenter.constants.CouponConstants.CouponTemplateStatus.NORMAL);

        //根据spreadId筛选，可以传多个，最大支持20 注意：传单个spreadId后，根据spreadIdList查询将实效
        param.setSpreadId(queryViewDTO.getSpreadId());

        //排序字段  可选  最近领用：gmtCreated  即将过期：endTime   修改时间：gmtModified
        param.setSortField(queryViewDTO.getSortField());

        param.setTemplateIds(queryViewDTO.getTemplateIds());

        //只查有效的，等价 status=1 and end_time>now()  可选
        if (BrandBoolEnum.BRAND_TRUE.getCode().equals(queryViewDTO.getNoExpire())) {
            param.setValidFlag(true);
        }

        if(Objects.nonNull(queryViewDTO.getCouponTag())){
            //如果是渠道券，需要传入这列值   非渠道券禁止使用下面条件，否则有严重后果
            param.setCouponTag(queryViewDTO.getCouponTag()); //tag值是卡券平台申请渠道值
            param.setQueryPublic(false);
            param.setApplyPlaces(Lists.newArrayList(CouponConstants.ApplyPlace.HIDE));
        }
        PageResultViewDTO<SellerCouponFull> sellerCouponFullPageResultViewDTO = promotionSAO.querySellerCouponsList(param);
        return PageResultViewDTO.of(sellerCouponFullPageResultViewDTO.getList().stream().map(sellerCouponFull ->
                BeanUtils.copyIgnoreNull(sellerCouponFull, new SellerCouponViewDTO())).collect(Collectors.toList()), sellerCouponFullPageResultViewDTO.getCount());
    }
}
