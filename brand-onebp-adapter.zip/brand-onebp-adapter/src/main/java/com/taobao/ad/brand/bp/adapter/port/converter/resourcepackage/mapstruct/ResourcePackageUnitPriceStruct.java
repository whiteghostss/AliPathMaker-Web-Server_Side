package com.taobao.ad.brand.bp.adapter.port.converter.resourcepackage.mapstruct;

import com.alibaba.ad.nb.packages.v2.client.dto.salegroup.UnitPriceConfigDTO;

import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageUnitPriceViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/23
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
@Deprecated
public interface ResourcePackageUnitPriceStruct extends BaseMapStructMapper<UnitPriceConfigDTO, ResourcePackageUnitPriceViewDTO> {

    ResourcePackageUnitPriceStruct INSTANCE = Mappers.getMapper(ResourcePackageUnitPriceStruct.class);
}