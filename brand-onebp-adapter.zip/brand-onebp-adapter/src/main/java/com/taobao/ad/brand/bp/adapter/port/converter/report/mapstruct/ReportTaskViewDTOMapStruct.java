package com.taobao.ad.brand.bp.adapter.port.converter.report.mapstruct;

import com.alibaba.ad.nb.task.client.dto.async.AsyncTaskDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportTaskViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ReportTaskViewDTOMapStruct extends BaseMapStructMapper<AsyncTaskDTO, ReportTaskViewDTO> {

    ReportTaskViewDTOMapStruct INSTANCE = Mappers.getMapper(ReportTaskViewDTOMapStruct.class);

    @Mappings({
//            @Mapping(source = "id", target = "taskId"),
//            @Mapping(source = "name", target = "taskName"),
//            @Mapping(source = "type", target = "functionCode", qualifiedByName = "parse2FunctionCode"),
//            @Mapping(source = "bizId", target = "memberId"),
//            @Mapping(source = "subBizId", target = "campaignGroupId"),
//            @Mapping(source = "params", target = "taskParams", qualifiedByName = "parse2TaskParams"),
//            @Mapping(source = "status", target = "statusName", qualifiedByName = "parse2StatusName"),
//            @Mapping(source = "result", target = "ossUrl", qualifiedByName = "parse2OssUrl"),
//            @Mapping(source = "lastCalTime", target = "lastCalDate"),
//            @Mapping(source = "params", target = "dimensionCodes", qualifiedByName = "parse2DimensionCodes")

    })
    @Override
    ReportTaskViewDTO sourceToTarget(AsyncTaskDTO dto);

    @Mappings({
//            @Mapping(target = "id", source = "taskId"),
//            @Mapping(target = "abilityCode", expression = "java(com.alibaba.ad.biz.definition.constants.BizCodeEnum.BRANDAD.getBizCode())"),
//            @Mapping(target = "bizId", source = "memberId"),
//            @Mapping(target = "bizType", expression = "java(com.alibaba.ad.nb.task.client.constant.async.AsyncTaskBizTypeEnum.MEMBER.getValue())"),
//            @Mapping(target = "subBizId", source = "campaignGroupId"),
//            @Mapping(target = "subBizType", expression = "java(com.alibaba.ad.nb.task.client.constant.async.AsyncTaskSubBizTypeEnum.BRAND_ONE_BP_CAMPAIGN_GROUP.getValue())"),
//            @Mapping(target = "name", source = "taskName"),
//            @Mapping(target = "type", source = "functionCode", qualifiedByName = "parse2Type"),
//            @Mapping(target = "params", source = "taskParams", qualifiedByName = "parse2Params"),
//            @Mapping(target = "result", source = "ossUrl", qualifiedByName = "parse2Result"),
//            @Mapping(target = "lastCalTime", source = "lastCalDate"),
    })
    @Override
    AsyncTaskDTO targetToSource(ReportTaskViewDTO viewDTO);


//    @Named("parse2Type")
//    default Integer parse2Type(String functionCode){
//        if(StringUtils.isBlank(functionCode)){
//            return null;
//        }
//        switch (functionCode) {
//            case "mRptMultiCustom":
//                return AsyncTaskTypeEnum.BRAND_ONE_BP_MULTI_REPORT.getValue();
//            case "mRptMultiPromotion":
//                return AsyncTaskTypeEnum.BRAND_ONE_BP_PROMOTION_REPORT.getValue();
//            case "mRptMultiLive":
//                return AsyncTaskTypeEnum.BRAND_ONE_BP_LIVE_REPORT.getValue();
//            default:
//                return null;
//        }
//    }
//
//    @Named("parse2FunctionCode")
//    default String parse2FunctionCode(Integer type){
//        if(Objects.isNull(type)){
//            return null;
//        }
//        AsyncTaskTypeEnum typeEnum = CommonEnum.of(type, AsyncTaskTypeEnum.class);
//        switch (typeEnum) {
//            case BRAND_ONE_BP_MULTI_REPORT:
//                return "mRptMultiCustom";
//            case BRAND_ONE_BP_PROMOTION_REPORT:
//                return "mRptMultiPromotion";
//            case BRAND_ONE_BP_LIVE_REPORT:
//                return "mRptMultiLive";
//            default:
//                return null;
//        }
//    }
//
//    @Named("parse2Params")
//    default BrandReportTaskParamDTO parse2Params(Map<String, Object> params){
//        BrandReportTaskParamDTO paramDTO = new BrandReportTaskParamDTO();
//        paramDTO.setParams(params);
//        return paramDTO;
//    }
//
//    @Named("parse2TaskParams")
//    default Map<String, Object> parse2TaskParams(AsyncTaskParamDTO params){
//        BrandReportTaskParamDTO taskParamDTO = null;
//        if(params instanceof BrandReportTaskParamDTO){
//            taskParamDTO = (BrandReportTaskParamDTO)params;
//        }
//        if(Objects.isNull(taskParamDTO)){
//            return Maps.newHashMap();
//        }
//        return taskParamDTO.getParams();
//    }
//
//    @Named("parse2DimensionCodes")
//    default List<String> parse2DimensionCodes(AsyncTaskParamDTO params){
//        String key = "dimensionCodes";
//        BrandReportTaskParamDTO taskParamDTO = null;
//        if(params instanceof BrandReportTaskParamDTO){
//            taskParamDTO = (BrandReportTaskParamDTO)params;
//        }
//        if(Objects.isNull(taskParamDTO) || !taskParamDTO.getParams().containsKey(key)){
//            return Lists.newArrayList();
//        }
//        return JSON.parseArray(taskParamDTO.getParams().get(key).toString(), String.class);
//    }
//
//
//
//    @Named("parse2StatusName")
//    default String parse2StatusName(Integer status){
//        if(Objects.isNull(status)){
//            return null;
//        }
//        AsyncTaskStatusEnum statusEnum = CommonEnum.of(status, AsyncTaskStatusEnum.class);
//        return statusEnum.getDesc();
//    }
//
//    @Named("parse2OssUrl")
//    default String parse2OssUrl(AsyncTaskResultDTO result){
//        return result.getUrl();
//    }
//
//    @Named("parse2Result")
//    default AsyncTaskResultDTO parse2Result(String ossUrl){
//        AsyncTaskResultDTO dto = new AsyncTaskResultDTO();
//        dto.setUrl(ossUrl);
//        dto.setType(AsyncTaskResultTypeEnum.URL.getValue());
//        return dto;
//    }




}
