package com.taobao.ad.brand.bp.adapter.port.repository.material;

import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.material.MaterialSAO;
import com.taobao.ad.brand.bp.domain.creative.spi.impl.protocol.context.material.YkVideoDetail;
import com.taobao.ad.brand.bp.domain.material.MaterialRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/5/10 21:45
 * @description ：
 * @modified By：
 */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class MaterialRepositoryImpl implements MaterialRepository {
    private final MaterialSAO materialSAO;

    public YkVideoDetail getVideoFromYks(Long vid) {
        return materialSAO.getVideoFromYks(vid);
    }
}
