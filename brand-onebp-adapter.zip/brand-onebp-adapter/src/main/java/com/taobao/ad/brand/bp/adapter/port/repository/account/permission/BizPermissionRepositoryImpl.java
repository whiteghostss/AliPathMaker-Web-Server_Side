package com.taobao.ad.brand.bp.adapter.port.repository.account.permission;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.uic.common.dto.auth.AuthUserAssetRangeDTO;
import com.alibaba.ad.uic.dto.admin.permission.PermissionGroupBindDTO;
import com.alibaba.ad.uic.dto.admin.permission.PermissionGroupTemplateDTO;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.adapter.port.converter.account.permission.AdcMenuModulePermissionConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.permission.PermissionSAO;
import com.taobao.ad.brand.bp.client.dto.account.login.LoginSessionViewDTO;
import com.taobao.ad.brand.bp.client.dto.account.permission.AdcMenuModulePermissionViewDTO;
import com.taobao.ad.brand.bp.client.enums.account.login.AuthLoginBizCategoryEnum;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.account.repository.BizPermissionRepository;
import com.taobao.ad.brand.bp.domain.config.BrandOneBPSupportDimensionDiamondConfig;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Repository;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author 虫洞 <liuming.liu@alibaba-inc.com>
 * @date 2023/4/27
 */
@Repository
@RequiredArgsConstructor
public class BizPermissionRepositoryImpl implements BizPermissionRepository {

    private static final Function<AdcMenuModulePermissionViewDTO, Integer> PRIORITY_FUNC = (p) -> {
        // true - 读写权限，false - 只读权限，null - 没有权限
        if (Objects.equals(p.getIsWritable(), true)) {
            return 2;
        }
        if (Objects.equals(p.getIsWritable(), false)) {
            return 1;
        }
        return 0;
    };

    private final PermissionSAO permissionSAO;
    private final AdcMenuModulePermissionConverter adcMenuModulePermissionConverter;
    private final BrandOneBPSupportDimensionDiamondConfig brandOneBPSupportDimensionDiamondConfig;

    @Override
    public List<AdcMenuModulePermissionViewDTO> getBoundPermission(ServiceContext serviceContext, LoginSessionViewDTO loginSession) {
        boolean nonLogin = (loginSession == null || (!loginSession.isPreLogin() && !loginSession.isLogin()));
        if (nonLogin) {
            return Collections.emptyList();
        }

        List<PermissionGroupBindDTO> permissionGroupBindDTOList = Collections.emptyList();

        // 内部小二登录
        if (loginSession.isAliEmpLogin()) {
            permissionGroupBindDTOList = permissionSAO.findAliEmpBindPermissionGroup(serviceContext, loginSession.getAliEmpLogin().getBucId());
        }
        // 广告主员工淘宝账号登录后，授权登录到别的投放账号
        if (loginSession.isAuthLogin() && !loginSession.isAdvTbAccountLogin()) {
            Integer bizCategory = loginSession.getAuthLogin().getBizCategory();
            Long advMemberId = loginSession.getAuthLogin().getAdvMemberId();
            Long advEmpTbNumId = loginSession.getLoginTbAccount().getMainTbNumId();
            if (AuthLoginBizCategoryEnum.AGENCY.getValue().equals(bizCategory)) {
                advEmpTbNumId = loginSession.getLoginTbAccount().getUserIdNum();//生态支持了淘宝子账户作为员工账户，取当前淘宝账户id
                permissionGroupBindDTOList = permissionSAO.findPartnerEmpBindPermissionGroup(serviceContext, advEmpTbNumId, advMemberId, 1);
            }
            if (AuthLoginBizCategoryEnum.SEM.getValue().equals(bizCategory)) {
                permissionGroupBindDTOList = permissionSAO.findPartnerEmpBindPermissionGroup(serviceContext, advEmpTbNumId, advMemberId, 2);
            }
            if (AuthLoginBizCategoryEnum.CRM.getValue().equals(bizCategory)) {
                permissionGroupBindDTOList = permissionSAO.findSellerEmpBindPermissionGroup(serviceContext, advEmpTbNumId, advMemberId, loginSession.getLoginMember().getMemberId());
            }
        }
        List<PermissionGroupTemplateDTO> flatted = Optional.ofNullable(permissionGroupBindDTOList).orElseGet(Collections::emptyList).stream()
            .filter(b -> b.getPermissionGroupDTOList() != null).flatMap(b -> b.getPermissionGroupDTOList().stream())
            .filter(g -> g.getTemplateList() != null).flatMap(g -> g.getTemplateList().stream())
            .collect(Collectors.toList());
        List<AdcMenuModulePermissionViewDTO> adcMenuModulePermissionViewDTOList = adcMenuModulePermissionConverter.convertDTO2ViewDTO(flatted);
        adcMenuModulePermissionViewDTOList.forEach(this::makeSubPermissionConsistency);
        return adcMenuModulePermissionViewDTOList;
    }

    @Override
    public boolean getMemberDmpAuthResult(Long memberId){
        List<AuthUserAssetRangeDTO> authRangeList = permissionSAO.queryMemberAuthRange(memberId);
        if(CollectionUtils.isEmpty(authRangeList)){
            return false;
        }
        //4 人群; 5 人群-品牌高阶; 6 人群-效果高阶
        Set<Integer> authRangeSet = Sets.newHashSet(4, 5, 6);
        Date nowDate = new Date();
        boolean dmpAuth = authRangeList.stream()
                .filter(authRangeDTO -> BrandDateUtil.isBefore(nowDate,authRangeDTO.getAuthEndTime()))
                .filter(authRangeDTO -> authRangeSet.contains(authRangeDTO.getAssetRange()))
                .anyMatch(authRangeDTO -> BrandBoolEnum.BRAND_TRUE.getCode().equals(authRangeDTO.getAuthStatus()));
        return dmpAuth;
    }

    @Override
    public List<String> supportSceneList(ServiceContext context) {
//        return Lists.newArrayList(BizCodeEnum.BRANDAD.getBizCode(), BizCodeEnum.TAOBRANDAD.getBizCode(),
//                BizCodeEnum.CONTENTAD.getBizCode() ,BizCodeEnum.IPMARKETINGAD.getBizCode(), BizCodeEnum.SELFSERVICEAD.getBizCode());
        return brandOneBPSupportDimensionDiamondConfig.getSupportSceneList();
    }

    @Override
    public List<Integer> supportSspProductLineList(ServiceContext context) {
        return brandOneBPSupportDimensionDiamondConfig.getSupportSspProductLineList();
    }

    /**
     * 子节点权限不能大于父节点权限
     *
     * @param adcMenuModule
     */
    private void makeSubPermissionConsistency(AdcMenuModulePermissionViewDTO adcMenuModule) {
        if (CollectionUtils.isEmpty(adcMenuModule.getSubList())) {
            return;
        }
        Integer currentPermissionPriority = PRIORITY_FUNC.apply(adcMenuModule);
        for (AdcMenuModulePermissionViewDTO sub : adcMenuModule.getSubList()) {
            if (PRIORITY_FUNC.apply(sub) > currentPermissionPriority) {
                sub.setIsWritable(adcMenuModule.getIsWritable());
            }
            makeSubPermissionConsistency(sub);
        }
    }
}
