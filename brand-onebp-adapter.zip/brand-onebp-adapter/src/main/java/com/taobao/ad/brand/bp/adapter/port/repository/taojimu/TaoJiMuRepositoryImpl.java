package com.taobao.ad.brand.bp.adapter.port.repository.taojimu;


import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.taojimu.TaoJiMuSAO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandShopWindowTjmSubscribeViewDTO;
import com.taobao.ad.brand.bp.domain.taojimu.TaoJiMuRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * @author jixiu.lj
 * @date 2024/9/19 20:02
 */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class TaoJiMuRepositoryImpl implements TaoJiMuRepository {

    private final TaoJiMuSAO taoJiMuSAO;

    @Override
    public void subscribe(ServiceContext serviceContext, BrandShopWindowTjmSubscribeViewDTO brandShopWindowTjmSubscribeViewDTO) {
        taoJiMuSAO.subscribe(serviceContext, brandShopWindowTjmSubscribeViewDTO);
    }

    @Override
    public BrandShopWindowTjmSubscribeViewDTO querySubscribeInfo(ServiceContext serviceContext, BrandShopWindowTjmSubscribeViewDTO brandShopWindowTjmSubscribeViewDTO) {
        return taoJiMuSAO.querySubscribeInfo(serviceContext, brandShopWindowTjmSubscribeViewDTO);
    }
}
