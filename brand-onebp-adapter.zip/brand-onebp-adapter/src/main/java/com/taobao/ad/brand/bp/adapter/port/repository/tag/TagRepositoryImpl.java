package com.taobao.ad.brand.bp.adapter.port.repository.tag;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.common.TagViewDTO;
import com.alibaba.ad.brand.sdk.convert.custom.viewdto.creative.TagViewDTO2DTOConvertProcessor;
import com.alibaba.ad.creative.consts.order.CreateTimeOrder;
import com.alibaba.ad.creative.consts.order.OrderField;
import com.alibaba.ad.creative.dto.tag.CreativeTagDTO;
import com.alibaba.ad.creative.query.CreativeTagQuery;
import com.alibaba.ad.universal.sdk.convert.custom.onebp.provider.OneBpConvertProcessorProvider;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.creative.CreativeSAO;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.tag.TagSAO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.tag.TagQueryViewDTO;
import com.taobao.ad.brand.bp.domain.tag.TagRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Author: PhilipFry
 * @createTime: 2024年02月27日 19:56:25
 * @Description:
 */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class TagRepositoryImpl implements TagRepository {
    private final TagSAO tagSAO;

    private TagViewDTO2DTOConvertProcessor tagViewDTO2DTOConvertProcessor = OneBpConvertProcessorProvider.getViewDTO2DTOConvertProcessor(TagViewDTO2DTOConvertProcessor.class);

    @Override
    public Long addTag(ServiceContext serviceContext, TagViewDTO tagViewDTO) {
        CreativeTagDTO creativeTagDTO = tagViewDTO2DTOConvertProcessor.viewDTO2DTO(tagViewDTO);
        creativeTagDTO.setMemberId(serviceContext.getMemberId());
        creativeTagDTO.setProductId(serviceContext.getProductId());
        return tagSAO.addCreativeTag(serviceContext, creativeTagDTO);
    }

    @Override
    public Integer updateTag(ServiceContext serviceContext, TagViewDTO tagViewDTO) {
        CreativeTagDTO creativeTagDTO = tagViewDTO2DTOConvertProcessor.viewDTO2DTO(tagViewDTO);
        creativeTagDTO.setMemberId(serviceContext.getMemberId());
        creativeTagDTO.setProductId(serviceContext.getProductId());
        return tagSAO.updateCreativeTag(serviceContext, creativeTagDTO);
    }

    @Override
    public Integer deleteTag(ServiceContext serviceContext, Long tagId) {
        return tagSAO.deleteCreativeTag(serviceContext, tagId);
    }

    @Override
    public PageResultViewDTO<TagViewDTO> findTagPage(ServiceContext serviceContext, TagQueryViewDTO queryViewDTO) {
        CreativeTagQuery creativeTagQuery = new CreativeTagQuery();
        creativeTagQuery.setLikeTagName(queryViewDTO.getLikeTagName());
        creativeTagQuery.setIdList(queryViewDTO.getIdList());
        creativeTagQuery.setTagName(queryViewDTO.getTagName());
        creativeTagQuery.setMemberId(serviceContext.getMemberId());
        creativeTagQuery.setProductId(serviceContext.getProductId());
        creativeTagQuery.setSkip(queryViewDTO.getStart());
        creativeTagQuery.setLimit(queryViewDTO.getPageSize());
        OrderField orderField = new CreateTimeOrder(OrderField.OrderType.DESC);
        creativeTagQuery.setOrderFields(Collections.singletonList(orderField));
        PageResultViewDTO<CreativeTagDTO> pageResultViewDTO =
                tagSAO.findCreativeTagPage(serviceContext, creativeTagQuery);
        if (CollectionUtils.isEmpty(pageResultViewDTO.getList())) {
            return PageResultViewDTO.of(Lists.newArrayList(), pageResultViewDTO.getCount());
        }
        List<TagViewDTO> viewDTOList = pageResultViewDTO.getList().stream()
                .map(dto -> tagViewDTO2DTOConvertProcessor.dto2ViewDTO(dto)).collect(Collectors.toList());
        return PageResultViewDTO.of(viewDTOList, pageResultViewDTO.getCount());
    }

    @Override
    public List<TagViewDTO> findTagByIds(ServiceContext serviceContext, List<Long> tagIds) {
        CreativeTagQuery creativeTagQuery = new CreativeTagQuery();
        creativeTagQuery.setIdList(tagIds);
        creativeTagQuery.setMemberId(serviceContext.getMemberId());
        creativeTagQuery.setProductId(serviceContext.getProductId());
        List<CreativeTagDTO> creativeTagList = tagSAO.findCreativeTagList(serviceContext, creativeTagQuery);
        return creativeTagList.stream()
                .map(dto -> tagViewDTO2DTOConvertProcessor.dto2ViewDTO(dto)).collect(Collectors.toList());
    }

}
