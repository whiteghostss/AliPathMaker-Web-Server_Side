package com.taobao.ad.brand.bp.adapter.port.converter.shopwindow.mapstruct;


import com.taobao.ad.brand.bp.client.dto.shopwindow.query.BrandSpuQueryViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.perform.client.dto.shopwindow.spu.SpuQueryViewDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/7/4
 **/
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface BrandSpuQueryMapStruct extends BaseMapStructMapper<BrandSpuQueryViewDTO, SpuQueryViewDTO> {
    BrandSpuQueryMapStruct INSTANCE = Mappers.getMapper(BrandSpuQueryMapStruct.class);

    @Mappings({
            @Mapping(source = "shopWindowTemplateIdList", target = "creativeStyleIdList"),
    })
    @Override
    SpuQueryViewDTO sourceToTarget(BrandSpuQueryViewDTO brandSpuQueryViewDTO);
}
