package com.taobao.ad.brand.bp.adapter.port.converter.resourcepackage;

import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupBoostGiveApplyInfoViewDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.product.ResourcePackageProductDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.salegroup.ReplenishOrDistributionSaleGroupInfoDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.salegroup.ResourcePackageSaleGroupDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.template.ResourcePackageTemplateDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.adapter.port.converter.resourcepackage.mapstruct.ResourcePackageProductMapStruct;
import com.taobao.ad.brand.bp.adapter.port.converter.resourcepackage.mapstruct.ResourcePackageSaleGroupMapStruct;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.salegroup.CampaignGroupSaleGroupBoostGiveApplyViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourceDistributionRuleViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageTemplateViewDTO;
import com.taobao.ad.brand.bp.client.enums.resourcepackage.ResourcePackageTemplateTypeEnum;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/25
 */
@Component
public class ResourcePackageConverter extends BaseViewDTOConverter<ResourcePackageSaleGroupDTO, ResourcePackageSaleGroupViewDTO> {

    @Override
    public BaseMapStructMapper<ResourcePackageSaleGroupDTO, ResourcePackageSaleGroupViewDTO> getBaseMapStructMapper() {
        return ResourcePackageSaleGroupMapStruct.INSTANCE;
    }

    public ResourcePackageSaleGroupViewDTO convertDTO2ViewDTO(ResourcePackageSaleGroupDTO source) {
        ResourcePackageSaleGroupViewDTO saleGroupViewDTO = super.convertDTO2ViewDTO(source);
        filterEmptyProduct(saleGroupViewDTO);
        return saleGroupViewDTO;
    }

    public List<ResourcePackageSaleGroupViewDTO> convertDTO2ViewDTOList(List<ResourcePackageSaleGroupDTO> sourceList) {
        List<ResourcePackageSaleGroupViewDTO> saleGroupList = super.convertDTO2ViewDTOList(sourceList);
        for (ResourcePackageSaleGroupViewDTO saleGroupViewDTO : saleGroupList) {
            filterEmptyProduct(saleGroupViewDTO);
        }
        return saleGroupList;
    }

    public List<ResourcePackageProductViewDTO> convertDTO2ProductViewDTOList(List<ResourcePackageProductDTO> resourcePackageProductDTOList){
        return ResourcePackageProductMapStruct.INSTANCE.sourceToTarget(resourcePackageProductDTOList);
    }
    public ResourcePackageProductViewDTO convertDTO2ProductViewDTO(ResourcePackageProductDTO resourcePackageProductDTO){
        return ResourcePackageProductMapStruct.INSTANCE.sourceToTarget(resourcePackageProductDTO);
    }

    private void filterEmptyProduct(ResourcePackageSaleGroupViewDTO saleGroupViewDTO) {
        if (saleGroupViewDTO == null) {
            return;
        }
        List<ResourceDistributionRuleViewDTO> distributionRuleList = saleGroupViewDTO.getDistributionRuleList();
        List<ResourceDistributionRuleViewDTO> filteredRuleList = Lists.newArrayList();
        for (ResourceDistributionRuleViewDTO resourceDistributionRuleViewDTO : distributionRuleList) {
            if (CollectionUtils.isNotEmpty(resourceDistributionRuleViewDTO.getResourcePackageProductList())) {
                filteredRuleList.add(resourceDistributionRuleViewDTO);
            }
        }
        saleGroupViewDTO.setDistributionRuleList(filteredRuleList);
    }



    public ResourcePackageTemplateViewDTO convertCustomerTemplateDTO2ViewDTO(ResourcePackageTemplateDTO customerTemplateDTO) {
        if (customerTemplateDTO == null) {
            return null;
        }
        ResourcePackageTemplateViewDTO templateViewDTO = new ResourcePackageTemplateViewDTO();
        templateViewDTO.setMemberId(customerTemplateDTO.getMemberId());
        templateViewDTO.setCustomerTemplateId(customerTemplateDTO.getId());
        templateViewDTO.setCustomerTemplateName(customerTemplateDTO.getName());
        templateViewDTO.setMarketingTemplateId(customerTemplateDTO.getSuperiorTemplateId());
        templateViewDTO.setProjectId(customerTemplateDTO.getProjectId());
        templateViewDTO.setType(customerTemplateDTO.getType());
        templateViewDTO.setCreator(customerTemplateDTO.getCreator());
        return templateViewDTO;
    }

    public ResourcePackageTemplateViewDTO convertResourceTemplateDTO2ViewDTO(ResourcePackageTemplateDTO resourceTemplateDTO) {
        if (resourceTemplateDTO == null) {
            return null;
        }
        ResourcePackageTemplateViewDTO templateViewDTO = new ResourcePackageTemplateViewDTO();
        templateViewDTO.setMemberId(resourceTemplateDTO.getMemberId());
        if (ResourcePackageTemplateTypeEnum.MARKETING.getValue().equals(resourceTemplateDTO.getType())) {
            templateViewDTO.setMarketingTemplateId(resourceTemplateDTO.getId());
        } else {
            templateViewDTO.setCustomerTemplateId(resourceTemplateDTO.getId());
            templateViewDTO.setCustomerTemplateName(resourceTemplateDTO.getName());
            templateViewDTO.setMarketingTemplateId(resourceTemplateDTO.getSuperiorTemplateId());
        }
        templateViewDTO.setProjectId(resourceTemplateDTO.getProjectId());

        templateViewDTO.setType(resourceTemplateDTO.getType());
        templateViewDTO.setCreator(resourceTemplateDTO.getCreator());
        templateViewDTO.setRightsTemplateIdList(resourceTemplateDTO.getRightsTemplateIdList());
        return templateViewDTO;
    }

    /**
     * 转换自动创建补量、配送分组DTO
     * @param applyInfoViewDTO
     * @return
     */
    public ReplenishOrDistributionSaleGroupInfoDTO convertSaleGroupBoostGiveApplyViewDTO2DTO(SaleGroupBoostGiveApplyInfoViewDTO applyInfoViewDTO, Long mainGroupId) {
        ReplenishOrDistributionSaleGroupInfoDTO saleGroupInfoDTO = new ReplenishOrDistributionSaleGroupInfoDTO();
        saleGroupInfoDTO.setSaleGroupId(applyInfoViewDTO.getSaleGroupId());
        saleGroupInfoDTO.setMainGroupId(mainGroupId);
        saleGroupInfoDTO.setChargeType(applyInfoViewDTO.getSaleType());
        saleGroupInfoDTO.setStartDate(applyInfoViewDTO.getStartDate());
        saleGroupInfoDTO.setEndDate(applyInfoViewDTO.getEndDate());
        saleGroupInfoDTO.setAmount(applyInfoViewDTO.getBudget());
        saleGroupInfoDTO.setSaleGroupName(applyInfoViewDTO.getSaleGroupName());
        saleGroupInfoDTO.setApproval(applyInfoViewDTO.getApproval());
        saleGroupInfoDTO.setDistributionType(applyInfoViewDTO.getDistributionType());
        return saleGroupInfoDTO;
    }

}
