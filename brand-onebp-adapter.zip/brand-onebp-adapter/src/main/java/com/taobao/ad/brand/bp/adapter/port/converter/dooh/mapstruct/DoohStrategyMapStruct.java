package com.taobao.ad.brand.bp.adapter.port.converter.dooh.mapstruct;

import com.taobao.ad.brand.bp.client.dto.dooh.DoohStrategyViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.umeng.oplus.domain.dto.dsp.scheme.DspSchemeDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, uses = {DoohStrategyMapStruct.class})
public interface DoohStrategyMapStruct extends BaseMapStructMapper<DspSchemeDTO, DoohStrategyViewDTO> {

    DoohStrategyMapStruct INSTANCE = Mappers.getMapper(DoohStrategyMapStruct.class);

//    @Mappings({
//            @Mapping(source = "dspSchemeId", target = "id"),
//            @Mapping(source = "dspSchemeName", target = "name"),
//            @Mapping(target = "budget", expression = "java(com.taobao.ad.brand.bp.common.util.NumberUtil.getLongNumber(dspSchemeDTO.getBudget(), 100))")
//    })
//    @Override
//    DoohStrategyViewDTO sourceToTarget(DspSchemeDTO dspSchemeDTO);

    @Mappings({
            @Mapping(source = "id", target = "dspSchemeId"),
            @Mapping(source = "name", target = "dspSchemeName")
    })
    @Override
    DspSchemeDTO targetToSource(DoohStrategyViewDTO strategyViewDTO);

}
