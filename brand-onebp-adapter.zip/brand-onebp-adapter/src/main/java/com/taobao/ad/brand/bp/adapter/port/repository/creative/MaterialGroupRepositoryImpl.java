package com.taobao.ad.brand.bp.adapter.port.repository.creative;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.creative.materialgroup.MaterialGroupViewDTO;
import com.alibaba.ad.brand.dto.creative.materialgroup.MaterialViewDTO;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandMamaMaterialTypeEnum;
import com.alibaba.ad.brand.sdk.convert.custom.viewdto.creative.MaterialGroupViewDTO2DTOConvertProcessor;
import com.alibaba.ad.brand.sdk.convert.custom.viewdto.creative.MaterialViewDTO2DTOConvertProcessor;
import com.alibaba.ad.creative.dto.creative.MaterialUpdateOptionDTO;
import com.alibaba.ad.creative.dto.material.MaterialDTO;
import com.alibaba.ad.creative.dto.materialgroup.MaterialGroupDTO;
import com.alibaba.ad.universal.sdk.convert.custom.onebp.provider.OneBpConvertProcessorProvider;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.creative.CreativeSAO;
import com.taobao.ad.brand.bp.domain.creative.repository.MaterialGroupRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/3/4 16:19
 * @description ：
 * @modified By：
 */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class MaterialGroupRepositoryImpl implements MaterialGroupRepository {

    private final CreativeSAO creativeSAO;
    private MaterialGroupViewDTO2DTOConvertProcessor PROCESSOR = OneBpConvertProcessorProvider.getViewDTO2DTOConvertProcessor(MaterialGroupViewDTO2DTOConvertProcessor.class);
    private MaterialViewDTO2DTOConvertProcessor MATERIAL_PROCESSOR = OneBpConvertProcessorProvider.getViewDTO2DTOConvertProcessor(MaterialViewDTO2DTOConvertProcessor.class);
    private MaterialGroupViewDTO2DTOConvertProcessor MATERIAL_GROUP_PROCESSOR = OneBpConvertProcessorProvider.getViewDTO2DTOConvertProcessor(MaterialGroupViewDTO2DTOConvertProcessor.class);

    @Override
    public MaterialGroupViewDTO getMaterialGroupById(ServiceContext context, Long materialGroupId) {
        MaterialGroupDTO materialGroupDTO = creativeSAO.getMaterialGroupById(context, materialGroupId);
        return PROCESSOR.dto2ViewDTO(materialGroupDTO);
    }

    @Override
    public void batchUpdateMaterialPartWithoutReAudit(ServiceContext context, List<MaterialViewDTO> materialViewDTOList) {
        List<MaterialDTO> materialDTOList = MATERIAL_PROCESSOR.viewDTOList2DTOList(materialViewDTOList);
        MaterialUpdateOptionDTO materialUpdateOptionDTO = new MaterialUpdateOptionDTO();
        materialUpdateOptionDTO.setReAudit(false);
        creativeSAO.batchUpdateMaterialPart(context,materialDTOList,materialUpdateOptionDTO);
    }

    @Override
    public void updateMaterialGroupCropResult(ServiceContext context, MaterialGroupViewDTO materialGroupViewDTO) {
        //更新素材拓版信息
        List<MaterialViewDTO> materialViewDTOList = materialGroupViewDTO.getMaterialViewDTOList().stream()
                .filter(materialViewDTO -> BrandMamaMaterialTypeEnum.IMAGE_AUTH_PASS.getCode().equals(materialViewDTO.getType()))
                .map(materialViewDTO -> {
                    MaterialViewDTO newMaterialViewDTO = new MaterialViewDTO();
                    newMaterialViewDTO.setId(materialViewDTO.getId());
                    newMaterialViewDTO.setMaterialCropResultViewDTO(materialViewDTO.getMaterialCropResultViewDTO());
                    return newMaterialViewDTO;
                }).collect(Collectors.toList());
        batchUpdateMaterialPartWithoutReAudit(context,materialViewDTOList);

        //更新素材组拓版信息
        MaterialGroupViewDTO newMaterialGroupViewDTO = new MaterialGroupViewDTO();
        newMaterialGroupViewDTO.setId(materialGroupViewDTO.getId());
        newMaterialGroupViewDTO.setMaterialGroupCropResultViewDTO(materialGroupViewDTO.getMaterialGroupCropResultViewDTO());
        MaterialGroupDTO materialGroupDTO = MATERIAL_GROUP_PROCESSOR.viewDTO2DTO(newMaterialGroupViewDTO);
        creativeSAO.updateMaterialGroupPart(context,materialGroupDTO);
    }
}
