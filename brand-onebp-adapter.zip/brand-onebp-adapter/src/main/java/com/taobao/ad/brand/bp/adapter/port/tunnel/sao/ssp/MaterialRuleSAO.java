package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.ssp;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.nb.ssp.api.material.MaterialRuleQueryService;
import com.alibaba.ad.nb.ssp.dto.material.MaterialQueryDTO;
import com.alibaba.ad.nb.ssp.dto.material.MaterialRuleDTO;
import com.alibaba.ad.nb.ssp.dto.material.MaterialRuleDetailDTO;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * @author jixiu.lj
 * @date 2023/3/21 10:01
 */
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class MaterialRuleSAO extends BaseSAO {

    private final MaterialRuleQueryService materialRuleQueryService;

    /**
     * 查询MR列表
     *
     * @param serviceContext
     * @param materialRuleIds
     * @return
     */
    public List<MaterialRuleDetailDTO> getMaterialRuleDetailList(ServiceContext serviceContext, List<Long> materialRuleIds) {

        if (CollectionUtils.isEmpty(materialRuleIds)) {
            return Lists.newArrayList();
        }

        MaterialQueryDTO materialQueryDTO = new MaterialQueryDTO();
        materialQueryDTO.setIdList(materialRuleIds);
        materialQueryDTO.setPageSize(Integer.MAX_VALUE);
        materialQueryDTO.setPageIndex(0);

        MultiResponse<MaterialRuleDetailDTO> response = materialRuleQueryService.listMaterialRuleDetails(com.alibaba.ad.nb.ssp.context.ServiceContext.create(), materialQueryDTO);
        AssertUtil.assertTrue(response.isSuccess(), "MR信息查询失败");
        return response.getResult();
    }
    /**
     * 查询mr信息，包含模板
     * */
    public List<MaterialRuleDTO> getMaterialRuleList(ServiceContext serviceContext, List<Long> mrIds){
        if (org.apache.commons.collections4.CollectionUtils.isEmpty(mrIds)){
            return Lists.newArrayList();
        }
        com.alibaba.ad.nb.ssp.context.ServiceContext context = com.alibaba.ad.nb.ssp.context.ServiceContext.create();

        MaterialQueryDTO materialQueryDTO = new MaterialQueryDTO();

        materialQueryDTO.setIdList(mrIds);
        materialQueryDTO.setNeedTemplate(true);
        MultiResponse<MaterialRuleDTO> multiResponse = materialRuleQueryService.listMaterialRule(context,materialQueryDTO);
        AssertUtil.assertTrue(multiResponse.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, "MR信息查询失败:" + multiResponse.getErrorMsg());
        return multiResponse.getResult();
    }
}
