package com.taobao.ad.brand.bp.adapter.port.converter.oplog;

import com.alibaba.ad.oplog.dto.OpLogQueryDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.oplog.mapstruct.OpLogQueryMapStruct;
import com.taobao.ad.brand.bp.client.dto.oplog.OpLogQueryViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.springframework.stereotype.Component;

/**
 * @author jixiu.lj
 * @date 2024/3/20 15:42
 */
@Component
public class OpLogQueryViewDTOConverter extends BaseViewDTOConverter<OpLogQueryDTO, OpLogQueryViewDTO> {
    @Override
    public BaseMapStructMapper<OpLogQueryDTO, OpLogQueryViewDTO> getBaseMapStructMapper() {
        return OpLogQueryMapStruct.INSTANCE;
    }
}
