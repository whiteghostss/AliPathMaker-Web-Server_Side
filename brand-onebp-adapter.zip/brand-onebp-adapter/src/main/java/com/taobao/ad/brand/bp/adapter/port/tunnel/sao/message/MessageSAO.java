package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.message;

import com.alibaba.ad.nb.framework.mc.dto.message.MessageNoticeDTO;
import com.alibaba.ad.nb.framework.mc.dto.message.notice.DingDingGroupMessageNoticeDTO;
import com.alibaba.ad.nb.framework.mc.dto.message.notice.DingDingMessageNoticeDTO;
import com.alibaba.ad.nb.framework.mc.dto.message.notice.EmailMessageNoticeDTO;
import com.alibaba.ad.nb.framework.mc.dto.message.notice.StationLetterMessageNoticeDTO;
import com.alibaba.ad.nb.framework.mc.service.McServiceInterface;
import com.alibaba.ad.nb.framework.mc.stationletter.enums.StationLetterBizCodeEnum;
import com.alibaba.fastjson.JSON;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))

public class MessageSAO extends BaseSAO {

    private final McServiceInterface mcServiceInterface;
    private final String hookUrlPrefix  = "https://oapi.dingtalk.com/robot/send?access_token=";

    public void sendStationLetter(Long  memberId, String subject, String content){
        StationLetterMessageNoticeDTO stationLetterMessageNoticeDTO = new StationLetterMessageNoticeDTO();
        stationLetterMessageNoticeDTO.setBizCode(StationLetterBizCodeEnum.BRAND_ONEBP.getCode());
        stationLetterMessageNoticeDTO.setSubject(subject);
        stationLetterMessageNoticeDTO.setContent(content);
        stationLetterMessageNoticeDTO.setNoticeType(StationLetterMessageNoticeDTO.MessageNoticeTypeEnum.SYSTEM.getValue());
        StationLetterMessageNoticeDTO.StationLetterUserDTO stationLetterUserDTO = new StationLetterMessageNoticeDTO.StationLetterUserDTO();
        stationLetterUserDTO.setMemberId(memberId);
        stationLetterMessageNoticeDTO.setStationLetterUsers(Arrays.asList(stationLetterUserDTO));
        try {
            doSendMessage(stationLetterMessageNoticeDTO);
//            SingleResponse<Boolean> sendResponse = mcServiceInterface.sendMessage(stationLetterMessageNoticeDTO);
//            RogerLogger.info("messageService.send result : " + JSON.toJSONString(sendResponse));
        } catch (Exception e) {
            RogerLogger.warn("messageSAO sendStationLetter exception : subject " + subject + " msg : " + e.getMessage());
            RogerLogger.error("messageSAO sendStationLetter exception : subject " + subject + " msg : " + e.getMessage(),  e);
        }
    }

    public void sendEmail(List<String>  sendTo, String subject, String content){
        EmailMessageNoticeDTO emailMessageNoticeDTO = new EmailMessageNoticeDTO();
        emailMessageNoticeDTO.setEmails(sendTo);
        emailMessageNoticeDTO.setContent(content);
        emailMessageNoticeDTO.setSubject(subject);
        try {
            doSendMessage(emailMessageNoticeDTO);
        } catch (Exception e) {
            RogerLogger.warn("messageSAO sendEmail exception : subject " + subject + " msg : " + e.getMessage());
            RogerLogger.error("messageSAO sendEmail exception : subject " + subject + " msg : " + e.getMessage(),  e);
        }
    }

    public  void  sendDingMsg( List<String> empIds, String subject, String content) {
        DingDingMessageNoticeDTO dingMessageNoticeDTO = new DingDingMessageNoticeDTO();
        dingMessageNoticeDTO.setEmpIds(empIds);
        dingMessageNoticeDTO.setContent(content);
        dingMessageNoticeDTO.setSubject(subject);
        try {
            doSendMessage(dingMessageNoticeDTO);
//            SingleResponse<Boolean> sendResponse = mcServiceInterface.sendMessage(dingMessageNoticeDTO);
//            RogerLogger.info("messageService.send result : " + JSON.toJSONString(sendResponse));
        } catch (Exception e) {
            RogerLogger.warn("messageSAO sendDingMsg exception : subject " + subject + " msg : " + e.getMessage());
            RogerLogger.error("messageSAO sendDingMsg exception : subject " + subject + " msg : " + e.getMessage(),  e);
        }

    }

    public void sendDingGroupMsg( String subject, String content,String dingGroupToken) {
        DingDingGroupMessageNoticeDTO dingGroupMessageNoticeDTO = new DingDingGroupMessageNoticeDTO();
        dingGroupMessageNoticeDTO.setWebHookUrl(hookUrlPrefix+dingGroupToken);
        dingGroupMessageNoticeDTO.setSecret(System.currentTimeMillis()+"");
        dingGroupMessageNoticeDTO.setSubject(subject);
        dingGroupMessageNoticeDTO.setContent(content);
        try {
            doSendMessage(dingGroupMessageNoticeDTO);
//            SingleResponse<Boolean> sendResponse = mcServiceInterface.sendMessage(dingGroupMessageNoticeDTO);
//            RogerLogger.info("messageService.send result : " + JSON.toJSONString(sendResponse));
        } catch (Exception e) {
            RogerLogger.warn("messageSAO sendDingGroupMsg exception : subject " + subject + " msg : " + e.getMessage());
            RogerLogger.error("messageSAO sendDingGroupMsg exception : subject " + subject + " msg : " + e.getMessage(),  e);
        }

    }

    private void doSendMessage(MessageNoticeDTO messageNoticeDTO) {
        SingleResponse<Boolean> sendResponse = mcServiceInterface.sendMessage(messageNoticeDTO);
        RogerLogger.info("mcServiceInterface send result : " + JSON.toJSONString(sendResponse));
        AssertUtil.assertTrue(sendResponse);
    }

}
