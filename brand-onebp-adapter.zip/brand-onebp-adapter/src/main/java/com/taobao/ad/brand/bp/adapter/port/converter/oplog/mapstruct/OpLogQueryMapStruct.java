package com.taobao.ad.brand.bp.adapter.port.converter.oplog.mapstruct;

import com.alibaba.ad.oplog.dto.OpLogQueryDTO;
import com.taobao.ad.brand.bp.client.dto.oplog.OpLogQueryViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author jixiu.lj
 * @date 2024/3/21 10:23
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface OpLogQueryMapStruct extends BaseMapStructMapper<OpLogQueryDTO, OpLogQueryViewDTO> {
    OpLogQueryMapStruct INSTANCE = Mappers.getMapper(OpLogQueryMapStruct.class);

    @Mappings({
            @Mapping(target = "timestampGt",source = "startTime"),
            @Mapping(target = "timestampLt",source = "endTime"),
            @Mapping(target = "bizCodeEq",source = "bizCode"),
            @Mapping(target = "entityIdIn",source = "entityIds"),
            @Mapping(target = "entityTypeIn",source = "entityTypes"),
            @Mapping(target = "templateKeyIn",source = "templateKeys"),
            @Mapping(target = "operTypeEq",source = "operType"),
            @Mapping(target = "operTypeIn",source = "operTypeList"),
            @Mapping(target = "offset",source = "start"),
            @Mapping(target = "limit",source = "pageSize"),
    })
    @Override
    OpLogQueryDTO targetToSource(OpLogQueryViewDTO opLogQueryViewDTO);
}
