package com.taobao.ad.brand.bp.adapter.port.converter.sales.mapstruct;

import com.alibaba.ad.nb.sales.dto.brief.SubBriefDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSubContractViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author yanjingang
 * @date 2023/03/23
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface SubBriefMapStruct extends BaseMapStructMapper<SubBriefDTO, CampaignGroupSubContractViewDTO> {
    SubBriefMapStruct INSTANCE = Mappers.getMapper(SubBriefMapStruct.class);

    @Mappings({
            @Mapping(source = "groupProductLine", target = "saleProductLine"),
    })
    @Override
    CampaignGroupSubContractViewDTO sourceToTarget(SubBriefDTO subBriefDTO);

    @Mappings({
            @Mapping(source = "saleProductLine", target = "groupProductLine"),
    })
    @Override
    SubBriefDTO targetToSource(CampaignGroupSubContractViewDTO campaignGroupSubContractViewDTO);
}