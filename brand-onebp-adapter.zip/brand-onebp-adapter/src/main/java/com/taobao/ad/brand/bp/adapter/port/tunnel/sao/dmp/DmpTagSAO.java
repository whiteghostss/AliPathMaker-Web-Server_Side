package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.dmp;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.taobao.ad.brand.bp.client.dto.dmp.query.TagOptionQueryViewDTO;
import com.taobao.ad.brand.bp.common.constant.DmpConstant;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.dmp.client.dto.AppContextDTO;
import com.taobao.ad.dmp.client.dto.ResultDTO;
import com.taobao.ad.dmp.client.dto.TagOptionDTO;
import com.taobao.ad.dmp.client.dto.query.Pager;
import com.taobao.ad.dmp.client.dto.query.TagOptionQuery;
import com.taobao.ad.dmp.client.sdk2.TagService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Objects;

/**
 * dmp标签相关服务
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DmpTagSAO {
    private final TagService tagService;


    public ResultDTO<List<TagOptionDTO>> findTagsPageList(ServiceContext serviceContext, TagOptionQueryViewDTO tagQueryViewDTO){
        AppContextDTO contextDTO = new AppContextDTO();
        contextDTO.setAppId(DmpConstant.APP_ID);
        contextDTO.setMemberId(serviceContext.getMemberId());
        TagOptionQuery tagOptionQuery = new TagOptionQuery();
        tagOptionQuery.setTagId(tagQueryViewDTO.getTagId());
        Pager pager = initPager(tagQueryViewDTO);
        ResultDTO<List<TagOptionDTO>> resultDTO = tagService.findOptions(contextDTO, tagOptionQuery, pager);
        AssertUtil.assertTrue(Objects.nonNull(resultDTO) && resultDTO.isSuccess(), "查询dmp标签接口失败");
        return resultDTO;
    }

    private Pager initPager(TagOptionQueryViewDTO queryViewDTO){
        //分页大小不能超过200
        return new Pager(queryViewDTO.getPageNo(), queryViewDTO.getPageSize());
    }
}
