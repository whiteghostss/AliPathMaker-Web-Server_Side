package com.taobao.ad.brand.bp.adapter.port.repository.shield;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.nb.crm.constant.common.YesOrNoEnum;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.alimama.rcp.shield.api.sync.dto.SyncAuditResultDTO;
import com.alimama.rcp.shield.api.sync.dto.SyncTextDTO;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.MemberSAO;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.shield.ShieldAccessSAO;
import com.taobao.ad.brand.bp.client.dto.rule.RuleCheckResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.shield.ShieldSyncTextDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.shield.ShieldAccessRepository;
import com.taobao.simba.saber.api.dataobject.ItemDTO;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * 风控校验相关
 *
 * @author gxg
 */

@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ShieldAccessRepositoryImpl implements ShieldAccessRepository {

    private final ShieldAccessSAO shieldAccessSAO;
    private final MemberSAO memberSAO;

    @Override
    public List<ShieldSyncTextDTO> textAccessBatchCheck(List<String> textList) {
        if (CollectionUtils.isEmpty(textList)) {
            return Lists.newArrayList();
        }

        List<SyncTextDTO> syncTextDTOS = Lists.newArrayList();

        textList.forEach(text -> {
            SyncTextDTO syncTextDTO = new SyncTextDTO();
            syncTextDTO.setText(text);
            syncTextDTOS.add(syncTextDTO);
        });
        List<SyncAuditResultDTO<SyncTextDTO>> syncAuditResultDTOS = shieldAccessSAO.textAccessSyncRuleBatchJudge(syncTextDTOS);

        if (CollectionUtils.isEmpty(syncAuditResultDTOS)) {
            return Lists.newArrayList();
        }

        List<ShieldSyncTextDTO> shieldSyncTextDTOS = Lists.newArrayList();
        syncAuditResultDTOS.forEach(syncTextDTOSyncAuditResultDTO -> {
            if (syncTextDTOSyncAuditResultDTO.getAuditTarget() == null) {
                return;
            }
            ShieldSyncTextDTO syncTextDTO = new ShieldSyncTextDTO();
            syncTextDTO.setText(syncTextDTOSyncAuditResultDTO.getAuditTarget().getText());
            syncTextDTO.setActionCode(syncTextDTOSyncAuditResultDTO.getActionCode());
            syncTextDTO.setAuditReason(syncTextDTOSyncAuditResultDTO.getAuditReason());
            shieldSyncTextDTOS.add(syncTextDTO);
        });

        return shieldSyncTextDTOS;
    }


    @Override
    public void textAccessCheck(String text) {
        if (StringUtils.isEmpty(text)) {
            return;
        }
        List<ShieldSyncTextDTO> shieldSyncTextDTOS = textAccessBatchCheck(Lists.newArrayList(text));
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(shieldSyncTextDTOS), "风控校验名称异常,请稍后重试");

        ShieldSyncTextDTO syncTextDTO = shieldSyncTextDTOS.get(0);

        AssertUtil.assertTrue(syncTextDTO != null && syncTextDTO.getText().equals(text), "风控校验名称异常,请稍后重试");
        AssertUtil.assertTrue(YesOrNoEnum.YES.getValue().equals(syncTextDTO.getActionCode()), syncTextDTO.getAuditReason());
    }

    @Override
    public RuleCheckResultViewDTO checkFeedSmartAccess(ServiceContext serviceContext, Long itemId) {
        Long tbUserid = memberSAO.getTbNumIdByMemberId(serviceContext.getMemberId());
        ItemDTO itemDTO = shieldAccessSAO.feedAccessCheck(tbUserid,itemId);
        if(itemDTO == null){
            RogerLogger.info(String.format("商品智能投放准入结果查询失败，itemId=%s",itemId));
            return RuleCheckResultViewDTO.builder().isPass(BrandBoolEnum.BRAND_TRUE.getCode()).build();
        }
        RuleCheckResultViewDTO ruleCheckResultViewDTO = new RuleCheckResultViewDTO();
        ruleCheckResultViewDTO.setIsPass(BrandBoolEnum.BRAND_TRUE.getCode().equals(itemDTO.getActionCode()) ?
                BrandBoolEnum.BRAND_TRUE.getCode() : BrandBoolEnum.BRAND_FALSE.getCode());

        ruleCheckResultViewDTO.setReason(itemDTO.getReason());
        return ruleCheckResultViewDTO;
    }

    @Override
    public Map<Long, RuleCheckResultViewDTO> checkFeedSmartAccessBatch(ServiceContext serviceContext, List<Long> itemIds) {
        if (CollectionUtils.isEmpty(itemIds)) {
            return Maps.newHashMap();
        }
        Map<Long, RuleCheckResultViewDTO> checkResultMap = Maps.newHashMap();
        Long tbUserid = memberSAO.getTbNumIdByMemberId(serviceContext.getMemberId());
        List<ItemDTO> itemDTOList = shieldAccessSAO.feedJudgeBatch(tbUserid, itemIds);
        for (ItemDTO itemDTO : itemDTOList) {
            RuleCheckResultViewDTO ruleCheckResultViewDTO = new RuleCheckResultViewDTO();
            ruleCheckResultViewDTO.setIsPass(BrandBoolEnum.BRAND_TRUE.getCode().equals(itemDTO.getActionCode()) ?
                    BrandBoolEnum.BRAND_TRUE.getCode() : BrandBoolEnum.BRAND_FALSE.getCode());
            ruleCheckResultViewDTO.setReason(itemDTO.getReason());

            checkResultMap.put(itemDTO.getItemId(), ruleCheckResultViewDTO);
        }
        return checkResultMap;
    }
}
