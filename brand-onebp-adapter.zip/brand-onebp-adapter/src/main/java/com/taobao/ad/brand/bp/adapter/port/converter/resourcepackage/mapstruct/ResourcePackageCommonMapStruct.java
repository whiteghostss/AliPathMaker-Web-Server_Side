package com.taobao.ad.brand.bp.adapter.port.converter.resourcepackage.mapstruct;

import com.alibaba.ad.nb.packages.dto.common.CommonDTO;

import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/23
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ResourcePackageCommonMapStruct extends BaseMapStructMapper<CommonDTO, CommonViewDTO> {
    ResourcePackageCommonMapStruct INSTANCE = Mappers.getMapper(ResourcePackageCommonMapStruct.class);
}