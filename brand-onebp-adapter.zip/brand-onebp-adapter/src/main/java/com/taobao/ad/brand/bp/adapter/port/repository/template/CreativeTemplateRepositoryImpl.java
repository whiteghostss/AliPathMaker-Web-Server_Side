package com.taobao.ad.brand.bp.adapter.port.repository.template;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.nb.ssp.dto.template.NbTemplateContextDTO;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.adapter.port.converter.template.TemplateContextConverter;
import com.taobao.ad.brand.bp.adapter.port.converter.template.TemplateConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.adzone.AdzoneSAO;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.ssp.TemplateSAO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeTemplateQueryDTO;
import com.taobao.ad.brand.bp.client.dto.product.AdzoneViewDTO;
import com.taobao.ad.brand.bp.client.dto.template.TemplateContextViewDTO;
import com.taobao.ad.brand.bp.client.dto.template.TemplateViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeTemplateRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collections;
import java.util.List;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/3/4 16:18
 * @description ：
 * @modified By：
 */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CreativeTemplateRepositoryImpl implements CreativeTemplateRepository {
    private final TemplateSAO templateSAO;
    private final AdzoneSAO adzoneSAO;

    private final TemplateConverter templateConverter;
    private final TemplateContextConverter templateContextConverter;

    @Override
    public TemplateViewDTO getTemplateById(ServiceContext serviceContext, Long templateId) {
        return templateConverter.convertDTO2ViewDTO(templateSAO.getTemplateById(serviceContext, templateId));
    }

    @Override
    public List<TemplateViewDTO> getTemplateByIds(ServiceContext serviceContext, List<Long> templateIds) {
        return templateConverter.convertDTO2ViewDTOList(templateSAO.getTemplateByIds(serviceContext, templateIds));
    }

    public List<TemplateContextViewDTO> getTemplateMetaData(ServiceContext serviceContext, List<Long> nbTemplateIds,boolean isSmart) {
        return templateContextConverter.convertDTO2ViewDTOList(templateSAO.getTemplateMetaData(serviceContext,nbTemplateIds,isSmart));
    }

    public TemplateContextViewDTO getTemplateMetaData(ServiceContext serviceContext, Long nbTemplateId,boolean isSmart) {
        List<TemplateContextViewDTO> templateMetaDataList = getTemplateMetaData(serviceContext, Lists.newArrayList(nbTemplateId), isSmart);
        return CollectionUtils.isNotEmpty(templateMetaDataList) ? templateMetaDataList.get(0) : null;
    }

    @Override
    public List<TemplateViewDTO> getTemplateList(ServiceContext serviceContext, CreativeTemplateQueryDTO templateQueryDTO) {
        return templateConverter.convertDTO2ViewDTOList(templateSAO.getTemplateList(serviceContext, templateQueryDTO));
    }

    @Override
    public List<AdzoneViewDTO> findAdzoneByTemplateId(Long templateId) {
        return adzoneSAO.findAdzoneByTemplateId(Collections.singletonList(templateId));
    }
}
