package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.resource;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.fastjson.JSON;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.solar.common.dto.QueryOptionDTO;
import com.alibaba.solar.common.dto.ResultDTO;
import com.alibaba.solar.common.query.dto.QueryDTO;
import com.alibaba.uad.wto.api.resource.MediaResourceQueryService;
import com.alibaba.uad.wto.dto.resource.MediaResourceDTO;
import com.alibaba.uad.wto.dto.resource.query.MediaResourceQueryDTO;
import com.alibaba.uad.wto.hsf.dto.ResourceScheduleDTO;
import com.alibaba.uad.wto.hsf.dto.query.purchaseorder.ResourceScheduleQuery;
import com.alibaba.uad.wto.hsf.service.ResourceScheduleService;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.client.dto.product.ResourceScheduleViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author jixiu.lj
 * @date 2023/3/21 00:44
 */
@BizTunnel

@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ResourceSAO {

    private final MediaResourceQueryService mediaResourceQueryService;
    private final ResourceScheduleService resourceScheduleService;

    public List<MediaResourceDTO> getResourceList( List<Long> resourceIdList) {
        if (CollectionUtils.isEmpty(resourceIdList)) {
            return Lists.newArrayList();
        }
        // 构建参数
        com.alibaba.uad.wto.context.ServiceContext wtoServiceContext = new com.alibaba.uad.wto.context.ServiceContext();
        MediaResourceQueryDTO mediaResourceQueryDTO = new MediaResourceQueryDTO();
        mediaResourceQueryDTO.setResourceIdList(resourceIdList);
        MultiResponse<MediaResourceDTO>
            response = mediaResourceQueryService.listResources(wtoServiceContext, mediaResourceQueryDTO);
        AssertUtil.assertTrue(response.isSuccess(), "资源位信息查询失败:"+response.getErrorMsg());
        return response.getResult();
    }
    /**
     * 根据采购行获取资源排期信息，
     * set WakeUpRows
     * */
    public List<ResourceScheduleViewDTO> getResourceScheduleByPurchaseRowIds(List<Long> PurchaseRowIds) {
        if (org.apache.commons.collections4.CollectionUtils.isEmpty(PurchaseRowIds)) {
            return Lists.newArrayList();
        }
        QueryDTO queryDTO = QueryDTO.createQuery();
        //去重下
        Set<Long> purchaseRowIdsSet = Sets.newHashSet(PurchaseRowIds);
        queryDTO.andCondition(ResourceScheduleQuery.id.in(Lists.newArrayList(purchaseRowIdsSet)));

        ResultDTO<List<ResourceScheduleDTO>> resultDTO = resourceScheduleService.findResourceScheduleList(
                com.alibaba.solar.common.dto.ServiceContext.createServiceContext(), queryDTO, QueryOptionDTO.propertyRequired(false));
        RogerLogger.info("调用resourceScheduleService.findResourceScheduleList 接口返回值:{}",
                JSON.toJSONString(resultDTO));

        AssertUtil.assertTrue(resultDTO.isSuccess(),resultDTO.getMsg());
        return Optional.ofNullable(resultDTO.getResult()).orElse(Lists.newArrayList()).stream().map(item -> {
            ResourceScheduleViewDTO resourceScheduleViewDTO = new ResourceScheduleViewDTO();
            resourceScheduleViewDTO.setId(item.getId());
            resourceScheduleViewDTO.setWakeUpList(item.getWakeUpList());

            return resourceScheduleViewDTO;
        }).collect(Collectors.toList());
    }

    /**
     * 根据采购单id查询采购行信息
     */
    public List<ResourceScheduleViewDTO> getResourceScheduleByPurchaseOrderId(ServiceContext serviceContext, Long purchaseOrderId) {
        AssertUtil.notNull(purchaseOrderId, "采购单id");
        com.alibaba.solar.common.dto.ServiceContext wtoServiceContext = com.alibaba.solar.common.dto.ServiceContext.createServiceContext();
        // 查询采购
        QueryDTO queryDTO = QueryDTO.createQuery(ResourceScheduleQuery.orderNo.eq(purchaseOrderId));
        QueryOptionDTO optionDTO = QueryOptionDTO.propertyRequired(false);
        ResultDTO<List<ResourceScheduleDTO>> resultDTO = resourceScheduleService.findResourceScheduleList(wtoServiceContext, queryDTO, optionDTO);
        AssertUtil.assertTrue(resultDTO.isSuccess(), resultDTO.getMsg());
        // 构建返回参数
        return Optional.ofNullable(resultDTO.getResult()).orElse(Lists.newArrayList()).stream().map(item -> {
            ResourceScheduleViewDTO resourceScheduleViewDTO = new ResourceScheduleViewDTO();
            resourceScheduleViewDTO.setId(item.getId());
            resourceScheduleViewDTO.setWakeUpList(item.getWakeUpList());
            return resourceScheduleViewDTO;
        }).collect(Collectors.toList());
    }

}
