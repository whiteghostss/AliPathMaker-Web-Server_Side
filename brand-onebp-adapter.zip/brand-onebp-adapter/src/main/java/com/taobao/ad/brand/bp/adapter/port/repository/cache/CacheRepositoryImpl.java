package com.taobao.ad.brand.bp.adapter.port.repository.cache;

import java.io.Serializable;

import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.cache.TairSAO;
import com.taobao.ad.brand.bp.domain.cache.CacheRepository;

import org.springframework.stereotype.Repository;

import lombok.RequiredArgsConstructor;

/**
 * @author 虫洞 <liuming.liu@alibaba-inc.com>
 * @date 2023/6/5
 */
@Repository
@RequiredArgsConstructor
public class CacheRepositoryImpl implements CacheRepository {
    private final TairSAO tairSAO;

    @Override
    public void put(String key, Serializable value) {
        tairSAO.put(key, value);
    }

    @Override
    public void put(String key, Serializable value, int expire) {
        tairSAO.put(key, value, expire);
    }

    @Override
    public void delete(String key) {
        tairSAO.delete(key);
    }

    @Override
    public Object get(String key) {
        return tairSAO.get(key);
    }
}
