package com.taobao.ad.brand.bp.adapter.port.converter.adc.mapstruct;

import com.alibaba.ad.nb.framework.adc.dto.AdcComponentDTO;
import com.taobao.ad.brand.bp.client.dto.adc.AdcComponentViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface AdcComponentViewDTOMapStruct extends BaseMapStructMapper<AdcComponentDTO, AdcComponentViewDTO> {

    AdcComponentViewDTOMapStruct INSTANCE = Mappers.getMapper(AdcComponentViewDTOMapStruct.class);

}
