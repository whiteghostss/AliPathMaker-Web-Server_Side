package com.taobao.ad.brand.bp.adapter.port.converter.dooh;

import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.adapter.port.converter.dooh.mapstruct.DoohStrategyMapStruct;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohPointClassificationViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohPointSourceViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohStrategyViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportTaskViewDTO;
import com.taobao.ad.brand.bp.client.enums.dooh.DoohStrategyPointTypeEnum;
import com.taobao.ad.brand.bp.client.enums.dooh.DoohStrategyPointSourceEnum;
import com.taobao.ad.brand.bp.client.enums.dooh.DoohStrategyStatusEnum;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import com.taobao.ad.brand.bp.common.util.NumberUtil;
import com.umeng.oplus.domain.dto.bailing.SchemeMediaCountDTO;
import com.umeng.oplus.domain.dto.bailing.SchemeMediaItemCountDTO;
import com.umeng.oplus.domain.dto.dsp.scheme.DspSchemeDTO;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class DoohStrategyConverter extends BaseViewDTOConverter<DspSchemeDTO, DoohStrategyViewDTO> {

    @Override
    public BaseMapStructMapper<DspSchemeDTO, DoohStrategyViewDTO> getBaseMapStructMapper() {
        return DoohStrategyMapStruct.INSTANCE;
    }

    @Override
    public DoohStrategyViewDTO convertDTO2ViewDTO(DspSchemeDTO dspSchemeDTO){
        if(dspSchemeDTO == null){
            return null;
        }
        DoohStrategyViewDTO viewDTO = new DoohStrategyViewDTO();
        viewDTO.setId(dspSchemeDTO.getDspSchemeId());
        viewDTO.setName(dspSchemeDTO.getDspSchemeName());
        viewDTO.setGmtCreate(dspSchemeDTO.getGmtCreate());
        viewDTO.setBudget(NumberUtil.getLongNumber(dspSchemeDTO.getBudget(),100));
        viewDTO.setStartDate(dspSchemeDTO.getStartDate());
        viewDTO.setEndDate(dspSchemeDTO.getEndDate());
        if(dspSchemeDTO.getTaskCode() != null){
            DoohStrategyStatusEnum statusEnum = DoohStrategyStatusEnum.getStatusByDoohStatus(dspSchemeDTO.getTaskCode().code);
            if(statusEnum != null){
                viewDTO.setStatus(statusEnum.getCode());
                if(DoohStrategyStatusEnum.CALCULATION_TAILED_BUSINESS_ERROR.getCode().equals(statusEnum.getCode()) || DoohStrategyStatusEnum.CALCULATION_TAILED_RETRY.getCode().equals(statusEnum.getCode())){
                    viewDTO.setCalculateFailedReason(dspSchemeDTO.getTaskCode().tips);
                }
            }
        }
        viewDTO.setPointSourceList(convertPointSourceDTO2ViewDTO(dspSchemeDTO.getSchemeMediaCountS()));
        viewDTO.setCompleteDate(dspSchemeDTO.getExpectedFinishTime());
        viewDTO.setLockDeadlineDate(dspSchemeDTO.getLockConfirmDeadline());
        return viewDTO;
    }

    @Override
    public List<DoohStrategyViewDTO> convertDTO2ViewDTOList(List<DspSchemeDTO> dspSchemeDTOList){
        if(CollectionUtils.isEmpty(dspSchemeDTOList)){
            return Lists.newArrayList();
        }
        List<DoohStrategyViewDTO> result = Lists.newArrayList();
        dspSchemeDTOList.forEach(dto-> result.add(convertDTO2ViewDTO(dto)));
        return result;
    }

    private List<DoohPointSourceViewDTO> convertPointSourceDTO2ViewDTO(List<SchemeMediaCountDTO> schemeMediaCountList){
        if(CollectionUtils.isEmpty(schemeMediaCountList)){
            return Lists.newArrayList();
        }
        List<DoohPointSourceViewDTO> doohPointSourceViewDTOList = Lists.newArrayList();
        for(SchemeMediaCountDTO schemeMediaCountDTO : schemeMediaCountList){
            DoohPointSourceViewDTO pointSourceViewDTO = new DoohPointSourceViewDTO();
            DoohStrategyPointSourceEnum pointSourceEnum = DoohStrategyPointSourceEnum.getPointSourceByDooh(schemeMediaCountDTO.getDspQuickSchemeMediaType().getCode());
            if(pointSourceEnum != null){
                pointSourceViewDTO.setId(pointSourceEnum.getCode());
                pointSourceViewDTO.setName(pointSourceEnum.getDesc());
            }
            pointSourceViewDTO.setPointCount(schemeMediaCountDTO.getCountNum());
            pointSourceViewDTO.setPointClassificationList(convertPointClassification2ViewDTO(pointSourceViewDTO.getId(), schemeMediaCountDTO.getSchemeMediaItemCountDTOS()));

            doohPointSourceViewDTOList.add(pointSourceViewDTO);
        }
        return doohPointSourceViewDTOList;
    }

    private List<DoohPointClassificationViewDTO> convertPointClassification2ViewDTO(Integer pointSource, List<SchemeMediaItemCountDTO> schemeMediaItemCountList){
        if(CollectionUtils.isEmpty(schemeMediaItemCountList)){
            return Lists.newArrayList();
        }
        List<DoohPointClassificationViewDTO> pointClassificationViewDTOList = Lists.newArrayList();
        for(SchemeMediaItemCountDTO mediaItemCountDTO : schemeMediaItemCountList){
            DoohPointClassificationViewDTO pointClassificationViewDTO = new DoohPointClassificationViewDTO();
            //自定义点位取枚举
            if(DoohStrategyPointSourceEnum.USER_DEFINED.getCode().equals(pointSource)){
                DoohStrategyPointTypeEnum pointOpTypeEnum = DoohStrategyPointTypeEnum.getStrategyPointOpTypeByDooh(mediaItemCountDTO.getCode());
                if(pointOpTypeEnum != null){
                    pointClassificationViewDTO.setId(pointOpTypeEnum.getCode());
                    pointClassificationViewDTO.setName(pointOpTypeEnum.getDesc());
                }
            }
            //推荐点位以天攻为准
            else{
                pointClassificationViewDTO.setId(mediaItemCountDTO.getCode());
                pointClassificationViewDTO.setName(mediaItemCountDTO.getName());
            }
            pointClassificationViewDTO.setPointCount(mediaItemCountDTO.getCountNum());
            pointClassificationViewDTOList.add(pointClassificationViewDTO);
        }
        return pointClassificationViewDTOList;
    }
}
