package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.mediarule;

import com.ali.unit.rule.util.lang.CollectionUtils;
import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.organizer.api.media.MediaMutexRuleCommandService;
import com.alibaba.ad.organizer.api.media.MediaMutexRuleQueryService;
import com.alibaba.ad.organizer.dto.media.MediaMutexRuleDTO;
import com.alibaba.ad.organizer.dto.query.MediaFrequencyQuery;
import com.alibaba.ad.organizer.dto.query.MediaMutexRuleQuery;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.alibaba.solar.common.query.dto.PageQueryDTO;
import com.alibaba.solar.common.query.dto.QueryDTO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.mediarule.query.MediaMutexRuleQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.mediarule.MediaRuleQueryEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;

@Component
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class MediaMutexRuleSAO extends BaseSAO {

    private final MediaMutexRuleCommandService mediaMutexRuleCommandService;
    private final MediaMutexRuleQueryService mediaMutexRuleQueryService;

    public Long addMutexRule(ServiceContext serviceContext, MediaMutexRuleDTO mediaMutexRuleDTO) {
        SingleResponse<Long> response = mediaMutexRuleCommandService.addMutexRule(serviceContext, mediaMutexRuleDTO);
        AssertUtil.assertTrue(response.isSuccess(),response.getErrorMsg());
        return response.getResult();
    }

    public Integer updateMutexRule(ServiceContext serviceContext, MediaMutexRuleDTO MediaMutexRuleDTO) {
        SingleResponse<Integer> response = mediaMutexRuleCommandService.updateMutexRuleAll(serviceContext, MediaMutexRuleDTO);
        AssertUtil.assertTrue(response.isSuccess(),response.getErrorMsg());
        return response.getResult();
    }

    public Integer updateMutexRuleStatus(ServiceContext serviceContext, List<Long> mutexRuleIds, Integer status) {
        SingleResponse<Integer> response = mediaMutexRuleCommandService.updateMutexRuleStatusBatch(serviceContext, mutexRuleIds,status);
        AssertUtil.assertTrue(response.isSuccess(),response.getErrorMsg());
        return response.getResult();
    }

    public MediaMutexRuleDTO getMutexRule(ServiceContext serviceContext, Long id) {
        QueryDTO queryDTO = QueryDTO.createQuery().andCondition(MediaMutexRuleQuery.id.eq(id));
        MultiResponse<MediaMutexRuleDTO> response = mediaMutexRuleQueryService.findMediaMutexRuleList(serviceContext, queryDTO);
        AssertUtil.assertTrue(response.isSuccess(),response.getErrorMsg());
        return (CollectionUtils.isEmpty(response.getResult())) ? null : response.getResult().get(0);
    }

    public PageResultViewDTO<MediaMutexRuleDTO> findListWithPage(ServiceContext serviceContext, MediaMutexRuleQueryViewDTO queryViewDTO) {
        MultiResponse<MediaMutexRuleDTO> response = mediaMutexRuleQueryService.findMediaMutexRulePage(serviceContext, initPageQueryDTO(queryViewDTO));
        AssertUtil.assertTrue(response.isSuccess(), response.getErrorMsg());
        return PageResultViewDTO.of(response.getResult(), response.getTotal());
    }

    public List<MediaMutexRuleDTO> findList(ServiceContext serviceContext, MediaMutexRuleQueryViewDTO queryViewDTO) {
        MultiResponse<MediaMutexRuleDTO> response = mediaMutexRuleQueryService.findMediaMutexRuleList(serviceContext, initQueryDTO(queryViewDTO));
        AssertUtil.assertTrue(response.isSuccess(), response.getErrorMsg());
        return response.getResult();
    }

    /**
     * 根据名称查询互斥规则
     * @param serviceContext
     * @param uniqueName
     * @return
     */
    public MediaMutexRuleDTO getTopOneByName(ServiceContext serviceContext, String uniqueName) {
        QueryDTO queryDTO = QueryDTO.createQuery().andCondition(MediaMutexRuleQuery.name.eq(uniqueName));
        MultiResponse<MediaMutexRuleDTO> response = mediaMutexRuleQueryService.findMediaMutexRuleList(serviceContext, queryDTO);
        AssertUtil.assertTrue(response.isSuccess(), response.getErrorMsg());
        return org.apache.commons.collections4.CollectionUtils.isNotEmpty(response.getResult()) ? response.getResult().get(0) : null;
    }

    private PageQueryDTO initPageQueryDTO(MediaMutexRuleQueryViewDTO queryViewDTO) {
        PageQueryDTO pageQueryDTO = PageQueryDTO.createQuery(queryViewDTO.getStart(), queryViewDTO.getPageSize());
        initQueryDTO(queryViewDTO,pageQueryDTO);
        return pageQueryDTO;
    }

    private QueryDTO initQueryDTO(MediaMutexRuleQueryViewDTO queryViewDTO) {
        QueryDTO queryDTO = QueryDTO.createQuery();
        initQueryDTO(queryViewDTO,queryDTO);
        return queryDTO;
    }

    private QueryDTO initQueryDTO(MediaMutexRuleQueryViewDTO queryViewDTO, QueryDTO queryDTO) {
        if (Objects.equals(queryViewDTO.getKeywordType(),MediaRuleQueryEnum.ID.getValue())) {
            queryDTO.andCondition(MediaMutexRuleQuery.id.eq(Long.valueOf(queryViewDTO.getKeyword())));
        }
        if (Objects.equals(queryViewDTO.getKeywordType(),MediaRuleQueryEnum.NAME.getValue())) {
            queryDTO.andCondition(MediaMutexRuleQuery.name.like(queryViewDTO.getKeyword()));
        }
        if (Objects.nonNull(queryViewDTO.getStatus())) {
            queryDTO.andCondition(MediaMutexRuleQuery.status.eq(queryViewDTO.getStatus()));
        }
        if (Objects.nonNull(queryViewDTO.getSiteId())) {
            queryDTO.andCondition(MediaMutexRuleQuery.siteId.eq(queryViewDTO.getSiteId()));
        }
        queryDTO.orderBy(MediaMutexRuleQuery.gmtModified.descOrder());
        return queryDTO;
    }

}
