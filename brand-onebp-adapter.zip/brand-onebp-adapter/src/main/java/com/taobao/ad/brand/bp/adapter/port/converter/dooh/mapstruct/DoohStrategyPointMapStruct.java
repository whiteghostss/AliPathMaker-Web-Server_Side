package com.taobao.ad.brand.bp.adapter.port.converter.dooh.mapstruct;

import com.taobao.ad.brand.bp.client.dto.dooh.DoohStrategyPointViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.umeng.oplus.domain.dto.bailing.SchemeMediaInfoDTO;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, uses = {DoohStrategyPointMapStruct.class})
public interface DoohStrategyPointMapStruct extends BaseMapStructMapper<SchemeMediaInfoDTO, DoohStrategyPointViewDTO> {
    DoohStrategyPointMapStruct INSTANCE = Mappers.getMapper(DoohStrategyPointMapStruct.class);
}
