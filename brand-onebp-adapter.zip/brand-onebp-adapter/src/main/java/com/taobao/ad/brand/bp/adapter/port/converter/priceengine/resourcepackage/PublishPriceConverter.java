package com.taobao.ad.brand.bp.adapter.port.converter.priceengine.resourcepackage;

import com.alibaba.ad.nb.price.dto.engine.PublishPriceDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.priceengine.resourcepackage.mapstruct.PublishPriceMapStruct;
import com.taobao.ad.brand.bp.client.dto.campaign.PriceEnginePublishPriceViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.springframework.stereotype.Component;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/25
 */
@Component
public class PublishPriceConverter extends BaseViewDTOConverter<PublishPriceDTO, PriceEnginePublishPriceViewDTO> {

    @Override
    public BaseMapStructMapper<PublishPriceDTO, PriceEnginePublishPriceViewDTO> getBaseMapStructMapper() {
        return PublishPriceMapStruct.INSTANCE;
    }

}
