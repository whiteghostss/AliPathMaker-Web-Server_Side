package com.taobao.ad.brand.bp.adapter.port.converter.dmp.mapstruct;

import com.taobao.ad.brand.bp.client.dto.dmp.CrowdViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.dmp.client.dto.BusinessTypeEnum;
import com.taobao.ad.dmp.client.dto.CrowdDTO;
import com.taobao.ad.dmp.client.dto.CrowdFullStatusEnum;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

import java.util.Arrays;
import java.util.Objects;
import java.util.Optional;

/**
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface CrowdViewDTOMapStruct extends BaseMapStructMapper<CrowdDTO, CrowdViewDTO> {

    CrowdViewDTOMapStruct INSTANCE = Mappers.getMapper(CrowdViewDTOMapStruct.class);

    @Mappings({
            @Mapping(source = "createtime",target = "createDate"),
            @Mapping(source = "businessType",target = "businessTypeName", qualifiedByName = "parseBusinessTypeName"),
            @Mapping(source = "fullStatus",target = "fullStatusName", qualifiedByName = "parseFullStatusName")
    })
    @Override
    CrowdViewDTO sourceToTarget(CrowdDTO crowdDTO);

    @Mappings({
            @Mapping(source = "createDate",target = "createtime"),
    })
    @Override
    CrowdDTO targetToSource(CrowdViewDTO crowdDTO);


    @Named("parseBusinessTypeName")
    default String parseBusinessTypeName(Integer businessType){
        if(businessType == null){
            return "";
        }
        Optional<BusinessTypeEnum> first = Arrays.stream(BusinessTypeEnum.values()).filter(m -> m.getValue() == businessType.intValue()).findFirst();
        if(first.isPresent()){
            return first.get().getName();
        }
        return "";
    }

    @Named("parseFullStatusName")
    default String parseFullStatusName(Integer fullStatus){
        if(fullStatus == null){
            return "";
        }
        Optional<CrowdFullStatusEnum> first = Arrays.stream(CrowdFullStatusEnum.values()).filter(m -> m.getValue() == fullStatus.intValue()).findFirst();
        if(first.isPresent()){
            return first.get().getName();
        }
        return "";
    }
}
