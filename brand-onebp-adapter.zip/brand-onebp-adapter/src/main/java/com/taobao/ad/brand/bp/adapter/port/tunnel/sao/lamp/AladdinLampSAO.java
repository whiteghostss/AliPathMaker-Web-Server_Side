package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.lamp;

import com.alibaba.aladdin.lamp.client.AladdinLampClient;
import com.alibaba.aladdin.lamp.domain.request.Request;
import com.alibaba.aladdin.lamp.domain.request.RequestItem;
import com.alibaba.aladdin.lamp.domain.response.GeneralItem;
import com.alibaba.aladdin.lamp.domain.response.ResResponse;
import com.alibaba.aladdin.lamp.domain.response.Response;
import com.alibaba.aladdin.lamp.domain.user.UserProfile;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.Map;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.ITEM_SUPPORTED_SMART_ERROR;
import static com.taobao.ad.brand.bp.common.constant.Constant.CHAR_SPLIT_KEY_DOT;
import static com.taobao.ad.brand.bp.common.constant.GenerateImageConstant.*;

/**
 * @Author: PhilipFry
 * @createTime: 2024年12月03日 15:13:45
 * @Description:
 */
@Component
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AladdinLampSAO {

    private final AladdinLampClient aladdinLampClient;

    public GeneralItem getGeneralItem(Long itemId) {
        Request request = new Request();
        request.setBizId(BIZ_ID);
        RequestItem requestItem = new RequestItem();
        request.setRequestItems(Lists.newArrayList(requestItem));
        UserProfile userProfile = new UserProfile();
        request.setUserProfile(userProfile);

        requestItem.setResId(RESOURCE_ID);
        JSONObject data = new JSONObject();
        requestItem.setData(data);
        data.put(ENTITYTYPE, ITEM);
        data.put(FIELDS, Arrays.stream(ITEM_KEY).map(key -> ITEM_KEY_PRE + key).collect(Collectors.joining(CHAR_SPLIT_KEY_DOT)));
        data.put(IDS, Lists.newArrayList(itemId).stream().map(String::valueOf).collect(Collectors.joining(CHAR_SPLIT_KEY_DOT)));
        userProfile.setUicSite(0);
        userProfile.setUserId(-1l);
        Response response = aladdinLampClient.execute(request);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of("宝贝详情查询异常"));
        Map<String, ResResponse> responseData = response.getData();
        ResResponse resResponse = responseData.get(RESOURCE_ID);
        AssertUtil.notNull(resResponse, ITEM_SUPPORTED_SMART_ERROR, "商品信息不允许为空");
        AssertUtil.notNull(resResponse.getData(), ITEM_SUPPORTED_SMART_ERROR, "商品信息不允许为空");
        LinkedList<GeneralItem> itemList = (LinkedList<GeneralItem>) resResponse.getData();
        AssertUtil.notEmpty(itemList, ITEM_SUPPORTED_SMART_ERROR, "商品信息不允许为空");
        return itemList.getFirst();
    }
}
