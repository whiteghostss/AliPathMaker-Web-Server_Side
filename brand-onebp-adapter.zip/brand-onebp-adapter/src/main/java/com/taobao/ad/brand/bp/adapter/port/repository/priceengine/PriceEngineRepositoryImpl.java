package com.taobao.ad.brand.bp.adapter.port.repository.priceengine;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.nb.packages.dto.common.CastDateDTO;
import com.alibaba.ad.nb.price.dto.engine.query.PriceQueryDTO;
import com.alibaba.ad.nb.sales.constant.engine.PriceChargeTypeEnum;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.priceengine.PriceEngineSAO;
import com.taobao.ad.brand.bp.client.dto.campaign.PriceEnginePublishPriceViewDTO;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.priceEngine.PriceEngineRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/25
 */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class PriceEngineRepositoryImpl implements PriceEngineRepository {

    private final PriceEngineSAO priceEngineSAO;

    @Override
    public List<PriceEnginePublishPriceViewDTO> getPublishPrice(ServiceContext serviceContext,
                                                                CampaignViewDTO campaignViewDTO, CampaignGroupViewDTO campaignGroup) {
        return priceEngineSAO.getPublishPrice(serviceContext,campaignViewDTO,campaignGroup);
    }


    @Override
    public List<PriceEnginePublishPriceViewDTO> getAdditionPublishPrice(Long publicationProductId, Integer saleUnit, List<Integer> resourceTypeValueList, Date startDate, Date endDate) {
        PriceQueryDTO condition = buildPriceCondition(publicationProductId, saleUnit, resourceTypeValueList, startDate, endDate);
        return priceEngineSAO.getAdditionPublishPrice(0L, condition);
    }

    private PriceQueryDTO buildPriceCondition(Long publicationProductId, Integer saleUnit, List<Integer> resourceTypeValueList, Date startDate, Date endDate) {
        PriceQueryDTO condition = new PriceQueryDTO();
        condition.setPublishProductId(publicationProductId);
        condition.setOrderDate(startDate);
        condition.setCastStartDate(startDate);
        condition.setCastEndDate(endDate);
        condition.setDetailCastDateList(dateListToDateMapList(Lists.newArrayList(new CastDateDTO(BrandDateUtil.date2String(startDate), BrandDateUtil.date2String(endDate)))));
        condition.setChargeType(PriceChargeTypeEnum.BUY.getValue());
        condition.setChargeUnit(String.valueOf(saleUnit));
        condition.setResourceTypeList(resourceTypeValueList.stream().map(String::valueOf).collect(Collectors.toList()));
        return condition;
    }

    private List<Map<String, Date>> dateListToDateMapList(List<CastDateDTO> dateList) {
        List<Map<String, Date>> result = Lists.newArrayList();
        if (dateList == null) {
            return result;
        }
        for (CastDateDTO castDateDTO : dateList) {
            Map<String, Date> dateMap = Maps.newHashMap();
            dateMap.put(PriceQueryDTO.CAST_DATE_KEY_START, BrandDateUtil.string2Date(castDateDTO.getStartDate(), BrandDateUtil.DATE_FORMAT_YYYYMMDD_TYPE_1));
            dateMap.put(PriceQueryDTO.CAST_DATE_KEY_END, BrandDateUtil.string2Date(castDateDTO.getEndDate(), BrandDateUtil.DATE_FORMAT_YYYYMMDD_TYPE_1));
            result.add(dateMap);
        }
        return result;
    }

}
