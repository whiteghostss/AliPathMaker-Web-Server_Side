package com.taobao.ad.brand.bp.adapter.port.repository.report;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.builder.ExcelWriterSheetBuilder;
import com.alibaba.excel.write.metadata.WriteTable;
import com.alibaba.excel.write.metadata.style.WriteCellStyle;
import com.alibaba.excel.write.style.HorizontalCellStyleStrategy;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.adapter.port.repository.report.excelstyle.CustomStyleCellWriteHandler;
import com.taobao.ad.brand.bp.client.dto.report.excel.ExcelCatalogueViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.excel.ExcelOutputViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.report.repository.EasyExcelRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static org.apache.poi.ss.usermodel.BorderStyle.THIN;

/**
 * easyExcel相关服务
 * @author yuncheng.lyc
 * @date 2023/3/23
 **/
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EasyExcelRepositoryImpl implements EasyExcelRepository {

    @Override
    public ExcelOutputViewDTO listToExcel(String fileName, String sheetName, List<ExcelCatalogueViewDTO> homePageList, Map<String, String> fieldMap, List<Map<String, Object>> dataList) {
        AssertUtil.assertTrue(Objects.nonNull(fileName), "文件名称不能为空");
        AssertUtil.assertTrue(Objects.nonNull(sheetName), "表格名称不能为空");
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(dataList), "查询数据为空");
        AssertUtil.assertTrue(MapUtils.isNotEmpty(fieldMap), "表格表头不能为空");
        try {
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            ExcelWriter excelWriter = EasyExcel.write(outputStream).registerWriteHandler(getHorizontalCellStyleStrategy()).registerWriteHandler(new CustomStyleCellWriteHandler(homePageList)).build();

            int sheetIndex = 1;
            //创建目录页
            if (CollectionUtils.isNotEmpty(homePageList)) {
                createCatalogSheet(excelWriter, sheetIndex, homePageList);
                ++sheetIndex;
            }
            //创建sheet数据页
            ExcelWriterSheetBuilder sheet = new ExcelWriterSheetBuilder(excelWriter);
            sheet.sheetNo(sheetIndex);
            sheet.sheetName(sheetName);
            excelWriter.write(excelRows(fieldMap, dataList), sheet.head(excelHead(fieldMap)).build());

            excelWriter.finish();
            outputStream.close();

            return new ExcelOutputViewDTO(fileName, outputStream);
        }catch (Exception e) {
            RogerLogger.error("导出Excel文件失败", e);
            throw new RuntimeException("导出Excel文件失败", e);
        }
    }


    @Override
    public ExcelOutputViewDTO listToExcel(String fileName, Map<String, String> sheetNameMap, List<ExcelCatalogueViewDTO> homePageList, Map<String, Map<String, String>> fieldMap, Map<String, List<Map<String, Object>>> dataMap) {
        AssertUtil.assertTrue(Objects.nonNull(fileName), "文件名称不能为空");
        AssertUtil.assertTrue(MapUtils.isNotEmpty(sheetNameMap), "表格名称不能为空");
        AssertUtil.assertTrue(MapUtils.isNotEmpty(dataMap), "查询数据为空");
        AssertUtil.assertTrue(MapUtils.isNotEmpty(fieldMap), "表格表头不能为空");
        AssertUtil.assertTrue(sheetNameMap.size() == dataMap.size(), "sheetNameMap、dataMap内容不匹配");
        AssertUtil.assertTrue(sheetNameMap.size() == fieldMap.size(), "sheetNameMap、fieldMap内容不匹配");
        try {
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            ExcelWriter excelWriter = EasyExcel.write(outputStream).registerWriteHandler(getHorizontalCellStyleStrategy()).registerWriteHandler(new CustomStyleCellWriteHandler(homePageList)).build();

            int sheetIndex = 1;
            //创建目录页
            if (CollectionUtils.isNotEmpty(homePageList)) {
                createCatalogSheet(excelWriter, sheetIndex, homePageList);
                ++sheetIndex;
            }
            //创建sheet数据页
            for(Map.Entry<String, String> sheetNameEntry : sheetNameMap.entrySet()) {
                String key = sheetNameEntry.getKey();
                ExcelWriterSheetBuilder sheet = new ExcelWriterSheetBuilder(excelWriter);
                sheet.sheetNo(sheetIndex);
                sheet.sheetName(sheetNameEntry.getValue());
                List<Map<String, Object>> dataList = dataMap.get(key);
                Map<String, String> filed = fieldMap.get(key);
                excelWriter.write(excelRows(filed, dataList), sheet.head(excelHead(filed)).build());

                ++sheetIndex;
            }

            excelWriter.finish();
            outputStream.close();

            return new ExcelOutputViewDTO(fileName, outputStream);
        }catch (Exception e) {
            RogerLogger.error("导出Excel文件失败", e);
            throw new RuntimeException("导出Excel文件失败", e);
        }
    }

    /**
     * 构建目录的sheet页
     * @param excelWriter
     * @param sheetIndex
     * @param homePageList
     */
    private void createCatalogSheet(ExcelWriter excelWriter, int sheetIndex, List<ExcelCatalogueViewDTO> homePageList){
        ExcelWriterSheetBuilder catalogSheet = new ExcelWriterSheetBuilder(excelWriter);
        catalogSheet.sheetNo(sheetIndex);
        catalogSheet.sheetName("目录");
        List<List<Object>> row = Lists.newArrayList();
        List<List<String>> head;
        WriteTable writeTable = null;
        int index = 1;
        for (ExcelCatalogueViewDTO homePage : homePageList) {
            if (ExcelCatalogueViewDTO.ExcelCatalogueFormatEnum.TITLE_ITEM.getValue().equals(homePage.getType())) {
                if (CollectionUtils.isNotEmpty(row)) {
                    excelWriter.write(row, catalogSheet.build(), writeTable);
                }
                head = Lists.newArrayList();
                row = Lists.newArrayList();
                head.add(Lists.newArrayList(homePage.getContent()));
                writeTable = EasyExcel.writerTable(index).needHead(Boolean.TRUE).head(head).build();
                ++index;
            } else if (ExcelCatalogueViewDTO.ExcelCatalogueFormatEnum.DATA_ITEM.getValue().equals(homePage.getType()) ||
                    ExcelCatalogueViewDTO.ExcelCatalogueFormatEnum.HYPERLINK_ITEM.getValue().equals(homePage.getType())) {
                //row.add(Lists.newArrayList(StringUtils.replace(homePage.getContent(), "-", "_")));
                row.add(Lists.newArrayList(homePage.getContent()));
            } else if (ExcelCatalogueViewDTO.ExcelCatalogueFormatEnum.EMPTY_ITEM.getValue().equals(homePage.getType())) {
                row.add(Lists.newArrayList(""));
            }
        }
        if (CollectionUtils.isNotEmpty(row)) {
            excelWriter.write(row, catalogSheet.build(), writeTable);
        }
    }

    /**
     * 表头处理，可以支持多级表头，
     * eg： fieldMap.put(id, "ID");
     *     fieldMap.put(name, "详细信息,名称");
     *     fieldMap.put(sex, "详细信息,性别");
     * @param fieldMap
     * @return
     */
    private List<List<String>> excelHead(Map<String, String> fieldMap){
        //获取列名称
        List<List<String>> head = new ArrayList<>();
        if(MapUtils.isNotEmpty(fieldMap)){
            //key为匹配符，value为列名，如果多级列名用逗号隔开
            fieldMap.forEach((key, value) -> head.add(Lists.newArrayList(value.split(","))));
        }
        return head;
    }

    /**
     * 构建sheet内容
     * @param fieldMap
     * @param dataList
     * @return
     */
    private List<List<Object>> excelRows(Map<String, String> fieldMap, List<Map<String, Object>> dataList){
        List<List<Object>> excelRows = Lists.newArrayList();
        if(MapUtils.isEmpty(fieldMap) || CollectionUtils.isEmpty(dataList)){
            return excelRows;
        }
        for(Map<String, Object> data : dataList){
            List<Object> rows = Lists.newArrayList();
            fieldMap.forEach((key, value) -> {
                if (data.containsKey(key)) {
                    if(Objects.isNull(data.get(key))){
                        rows.add("");
                    }else {
                        rows.add(data.get(key));
                    }
                }
            });
            excelRows.add(rows);
        }
        return excelRows;
    }

    private HorizontalCellStyleStrategy getHorizontalCellStyleStrategy(){
        WriteCellStyle headWriteCellStyle = new WriteCellStyle();
        headWriteCellStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        headWriteCellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        headWriteCellStyle.setHorizontalAlignment(HorizontalAlignment.CENTER);
        WriteCellStyle contentWriteCellStyle = new WriteCellStyle();
        contentWriteCellStyle.setWrapped(true);
        contentWriteCellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        contentWriteCellStyle.setHorizontalAlignment(HorizontalAlignment.LEFT);
//        contentWriteCellStyle.setHidden(true);
        contentWriteCellStyle.setBorderLeft(THIN);
        contentWriteCellStyle.setBorderTop(THIN);
        contentWriteCellStyle.setBorderRight(THIN);
        contentWriteCellStyle.setBorderBottom(THIN);
        return new HorizontalCellStyleStrategy(headWriteCellStyle, contentWriteCellStyle);

    }

}
