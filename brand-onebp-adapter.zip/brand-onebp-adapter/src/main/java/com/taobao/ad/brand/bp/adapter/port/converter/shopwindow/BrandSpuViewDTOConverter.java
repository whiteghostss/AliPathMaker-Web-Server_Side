package com.taobao.ad.brand.bp.adapter.port.converter.shopwindow;


import com.taobao.ad.brand.bp.adapter.port.converter.shopwindow.mapstruct.BrandSpuMapStruct;
import com.taobao.ad.brand.bp.adapter.port.converter.shopwindow.mapstruct.BrandSpuQueryMapStruct;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSpuViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.query.BrandSpuQueryViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import com.taobao.ad.brand.perform.client.dto.shopwindow.spu.SpuQueryViewDTO;
import com.taobao.ad.brand.perform.client.dto.shopwindow.spu.SpuViewDTO;
import org.springframework.stereotype.Component;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/6/25
 **/
@Component
public class BrandSpuViewDTOConverter extends BaseViewDTOConverter<SpuViewDTO, BrandSpuViewDTO> {

    @Override
    public BaseMapStructMapper<SpuViewDTO, BrandSpuViewDTO> getBaseMapStructMapper() {
        return BrandSpuMapStruct.INSTANCE;
    }

    public SpuQueryViewDTO convert2QueryViewDTO(BrandSpuQueryViewDTO brandSpuQueryViewDTO){
        return BrandSpuQueryMapStruct.INSTANCE.sourceToTarget(brandSpuQueryViewDTO);
    }
}
