package com.taobao.ad.brand.bp.adapter.port.converter.media.mapstruct;

import com.alibaba.uad.wto.dto.common.CommonDTO;
import com.alibaba.uad.wto.dto.resource.MediaDTO;
import com.taobao.ad.brand.bp.client.dto.media.MediaViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;


/**
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface MediaDTOMapStruct extends BaseMapStructMapper<MediaDTO, MediaViewDTO> {

    MediaDTOMapStruct INSTANCE = Mappers.getMapper(MediaDTOMapStruct.class);

//    @Mappings({
//            @Mapping(target = "id",source = "id"),
//            @Mapping(target = "memberId",source = "memberId"),
//            @Mapping(target = "siteId",source = "siteId"),
//            @Mapping(target = "supplierNo",source = "supplierNo"),
//            @Mapping(target = "mediaName",source = "mediaName"),
//            @Mapping(target = "mediaStatus",source = "mediaStatus"),
//            @Mapping(target = "mediaType",source = "mediaType"),
//            @Mapping(target = "androidPkgName",source = "androidPkgName"),
//            @Mapping(target = "androidSchema",source = "androidSchema"),
//            @Mapping(target = "androidBcAppkey",source = "androidBcAppkey"),
//            @Mapping(target = "androidSourceId",source = "androidSourceId"),
//            @Mapping(target = "iosBundleId",source = "iosBundleId"),
//            @Mapping(target = "iosSchema",source = "iosSchema"),
//            @Mapping(target = "iosBcAppkey",source = "iosBcAppkey"),
//            @Mapping(target = "iosSourceId",source = "iosSourceId"),
//            @Mapping(target = "unifiedMediaId", expression = "java(targetToSourceUnifiedMedia(mediaDTO))"),
//    })
//    @Override
//    MediaViewDTO sourceToTarget(MediaDTO mediaDTO);
//
//    default Long targetToSourceUnifiedMedia(MediaDTO mediaDTO) {
//        if (mediaDTO == null || mediaDTO.getUnifiedMedia() == null || mediaDTO.getUnifiedMedia().getValue() == null) {
//            return null;
//        }
//        return Long.valueOf(mediaDTO.getUnifiedMedia().getValue());
//    }
}
