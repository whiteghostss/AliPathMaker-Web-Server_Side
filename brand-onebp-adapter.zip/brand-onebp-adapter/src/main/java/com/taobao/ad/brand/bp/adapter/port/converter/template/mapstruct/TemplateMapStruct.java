package com.taobao.ad.brand.bp.adapter.port.converter.template.mapstruct;

import com.alibaba.ad.nb.ssp.dto.template.NbTemplateDTO;
import com.taobao.ad.brand.bp.client.dto.template.TemplateViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/23
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface TemplateMapStruct extends BaseMapStructMapper<NbTemplateDTO, TemplateViewDTO> {
    TemplateMapStruct INSTANCE = Mappers.getMapper(TemplateMapStruct.class);
}