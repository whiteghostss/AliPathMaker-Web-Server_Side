package com.taobao.ad.brand.bp.adapter.port.converter.mmcrm;

import com.taobao.ad.brand.bp.adapter.port.converter.mmcrm.mapstruct.AdvInfoMapStruct;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CrmAdvInfoViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import com.taobao.ad.mm.crm.service.dto.adv.AdvInfoDTO;
import org.springframework.stereotype.Component;

/**
 * @author yanjingang
 * @date 2024/07/12
 */
@Component
public class AdvInfoConverter extends BaseViewDTOConverter<AdvInfoDTO, CrmAdvInfoViewDTO> {

    @Override
    public BaseMapStructMapper<AdvInfoDTO, CrmAdvInfoViewDTO> getBaseMapStructMapper() {
        return AdvInfoMapStruct.INSTANCE;
    }
}
