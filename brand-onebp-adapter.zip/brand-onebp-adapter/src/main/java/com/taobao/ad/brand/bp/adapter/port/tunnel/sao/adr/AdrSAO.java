package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.adr;

import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.simba.report.client.dto.QueryDTO;
import com.alibaba.simba.report.client.dto.ReportQueryResult;
import com.alibaba.simba.report.client.service.ReportService;
import com.alibaba.solar.common.dto.ServiceContext;
import com.taobao.ad.brand.bp.common.constant.ReportConstant;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;

/**
 * adr相关服务
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AdrSAO {
    private final ReportService reportService;
    /**
     * 查询菜单
     * @param queryParams
     * @return
     */
    public List<Map<String, Object>> findData(Map<String, Object> queryParams){
        AssertUtil.assertTrue(MapUtils.isNotEmpty(queryParams), "查询报表中心参数不能为空");
        AssertUtil.assertTrue(queryParams.containsKey(ReportConstant.ADR_UNIQUE_KEY), "查询报表中心报表"+ReportConstant.ADR_UNIQUE_KEY+"参数不能为空");
        ServiceContext context = ServiceContext.createServiceContext();
        QueryDTO queryDTO = new QueryDTO();
        queryDTO.setUniqueKey(queryParams.get(ReportConstant.ADR_UNIQUE_KEY).toString());
        queryDTO.setCondition(queryParams);
        ReportQueryResult result = reportService.query(context, queryDTO);
        AssertUtil.assertTrue(result != null && result.isSuccess(), "报表中心查询失败，错误信息:" + result.getMsg());
        return result.getData();
    }

}
