package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.feed;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.biz.definition.constants.Product;
import com.alibaba.ad.biz.definition.constants.ProductLine;
import com.alibaba.ad.feed.api.feedoutentity.CatQueryService;
import com.alibaba.ad.feed.api.feedoutentity.FeedOutEntityQueryService;
import com.alibaba.ad.feed.api.feedoutentity.ItemQueryService;
import com.alibaba.ad.feed.api.feedoutentity.ShopQueryService;
import com.alibaba.ad.feed.dto.feedentity.FeedEntityDTO;
import com.alibaba.ad.feed.dto.feedoutentity.AccessAllowDTO;
import com.alibaba.ad.feed.dto.feedoutentity.OutCatDTO;
import com.alibaba.ad.feed.dto.feedoutentity.OutEntityAccessDTO;
import com.alibaba.ad.feed.dto.feedoutentity.OutItemInventoryDTO;
import com.alibaba.ad.feed.dto.feedoutentity.OutItemInventoryQueryDTO;
import com.alibaba.ad.feed.dto.feedoutentity.OutShopDTO;
import com.alibaba.ad.feed.dto.feedtype.FeedTypeEnum;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.solar.common.dto.ResultDTO;
import com.alibaba.solar.jupiter.client.dto.outentity.OutItemDTO;
import com.alibaba.solar.jupiter.client.sdk.FeedOutEntityService;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.simba.user.SimbaUic;
import com.taobao.ad.simba.user.dto.ShopInfoDTO;
import com.taobao.ad.simba.user.result.Result;
import com.taobao.unifiedsession.core.json.JSON;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/**
 * 商品店铺服务SAO
 *
 * @author yunhu.myh@taobao.com
 * @date 2023年07月26日
 */
@BizTunnel

@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class FeedSAO {

    private final ShopQueryService shopQueryService;
    private final FeedOutEntityService feedOutEntityService;
    private final ItemQueryService itemQueryService;
    private final FeedOutEntityQueryService feedOutEntityQueryService;
    private final CatQueryService catQueryService;

    public List<OutCatDTO> getCatByIds(List<Long> categoryIds) {
        if (CollectionUtils.isEmpty(categoryIds)) {
            return Lists.newArrayList();
        }
        RogerLogger.info("FeedSAO.getCatByIds param = {}", JSON.toJSONString(categoryIds));
        ResultDTO<List<OutCatDTO>> catResultDTO = catQueryService.getCatByIdList(initServiceContext(), categoryIds);
        RogerLogger.info("FeedSAO.getCatByIds response = {}", JSON.toJSONString(catResultDTO));
        if (catResultDTO.getResult() != null) {
            return catResultDTO.getResult();
        }
        return Lists.newArrayList();
    }


    public Long getShopIdByMemberId(Long memberId) {

        ResultDTO<OutShopDTO> shopDTOResultDTO = shopQueryService.getOutEntityByMemberId(initServiceContext(), memberId);
        AssertUtil.assertTrue(shopDTOResultDTO != null && shopDTOResultDTO.isSuccess(), "查询店铺失败");
        if (null != shopDTOResultDTO.getResult()) {
            return shopDTOResultDTO.getResult().getShopId();
        }
        return null;

    }

    public OutShopDTO getShopInfoByMemberId(Long memberId) {
        ResultDTO<OutShopDTO> shopDTOResultDTO = shopQueryService.getOutEntityByMemberId(initServiceContext(), memberId);
        AssertUtil.assertTrue(shopDTOResultDTO != null && shopDTOResultDTO.isSuccess(), "查询店铺失败");
        if (null != shopDTOResultDTO.getResult()) {
            return shopDTOResultDTO.getResult();
        }
        return null;
    }

    public Long getUserIdByShopId(Long shopId) {
        ResultDTO<OutShopDTO> shopDTOResultDTO = shopQueryService.getOutEntityById(initServiceContext(), shopId);
        RogerLogger.info("getUserIdByShopId,response:{}", JSONObject.toJSONString(shopDTOResultDTO));
        AssertUtil.assertTrue(shopDTOResultDTO != null && shopDTOResultDTO.isSuccess(), "查询店铺失败");
        if (null != shopDTOResultDTO.getResult()) {
            return shopDTOResultDTO.getResult().getUserId();
        }
        return null;
    }

    private com.alibaba.abf.governance.context.ServiceContext initServiceContext() {
        Long DEFAULT_MEMBER_ID = 2010500150L;

        com.alibaba.abf.governance.context.ServiceContext context = new ServiceContext();
        context.setClientAppName("brand-obebp");
        context.setMemberId(DEFAULT_MEMBER_ID);
        context.setOperType(0);
        context.setBizCode(BizCodeEnum.BRANDONEBP.getBizCode());
        context.setProductLineId(ProductLine.BRAND_ONEBP.getId());
        context.setProductId(Product.BRAND_ONEBP_BRAND.getId());
        return context;
    }


    public Long getItemUserId(Long itemId) {
        RogerLogger.info("ICItemQuerySAO.getItem itemId = {}", itemId);
        com.alibaba.solar.common.core.dto.ResultDTO<OutItemDTO> resultDTO =
                feedOutEntityService.getItem(itemId);
        RogerLogger.info("ICItemQuerySAO.getItem response = {}", JSON.toJSONString(resultDTO));
        if (!resultDTO.isSuccess()) {
            return null;
        }
        if (Objects.nonNull(resultDTO.getResult())) {
            return resultDTO.getResult().getUserId();
        } else {
            return null;
        }
    }

    public Long getShopIdByUserId(Long userId) {
        Result<ShopInfoDTO> shopInfo = SimbaUic._shopInfo.getShopInfoByTbNumId(userId);
        if (!shopInfo.isSuccess()) {
            return null;
        }
        return shopInfo.getModule().getShopId();
    }

    public List<OutItemInventoryDTO> getItemInventory(Long itemId, Long skuId) {
        OutItemInventoryQueryDTO.ItemInventoryQuery itemInventoryQuery = new OutItemInventoryQueryDTO.ItemInventoryQuery();
        itemInventoryQuery.setItemId(itemId);
        itemInventoryQuery.setIncludeSku(Boolean.TRUE);
        if (Objects.nonNull(skuId)) {
            itemInventoryQuery.setSkuList(Lists.newArrayList(skuId));
        }
        OutItemInventoryQueryDTO itemInventoryQueryDTO = new OutItemInventoryQueryDTO();
        itemInventoryQueryDTO.setItemList(Lists.newArrayList(itemInventoryQuery));
        ResultDTO<List<OutItemInventoryDTO>> resultDTO = itemQueryService.getItemInventory(initServiceContext(), itemInventoryQueryDTO);
        AssertUtil.assertTrue(Objects.nonNull(resultDTO) && resultDTO.isSuccess(), "查询宝贝失败");
        return resultDTO.getResult();
    }

    /**
     * 准入结果查询
     * @param memberId
     * @param itemId
     * @return
     */
    public AccessAllowDTO checkAccess(Long memberId,Long itemId){
        ServiceContext serviceContext = initServiceContext();
        serviceContext.setMemberId(memberId);
        OutEntityAccessDTO outEntityAccessDTO = new OutEntityAccessDTO();
        outEntityAccessDTO.setEntityType(FeedTypeEnum.TAOBAO_ITEM.getId());
        FeedEntityDTO feedEntityDTO = new FeedEntityDTO();
        feedEntityDTO.setEntityType(FeedTypeEnum.TAOBAO_ITEM.getId());
        feedEntityDTO.setSubPromotionType(com.alibaba.ad.universal.sdk.constant.feed.field.SubPromotionType.ITEM.getId());//商品
        feedEntityDTO.setEntityId(itemId);
        outEntityAccessDTO.setFeedEntityList(Lists.newArrayList(feedEntityDTO));
        ResultDTO<Map<Long, AccessAllowDTO>> resultDTO = feedOutEntityQueryService.checkAccess(serviceContext, outEntityAccessDTO);
        AssertUtil.assertTrue(resultDTO != null && resultDTO.isSuccess(), "商品准入查询失败");
        AccessAllowDTO accessAllowDTO = Optional.ofNullable(resultDTO.getResult()).map(map -> map.get(itemId)).orElse(null);
        return accessAllowDTO;
    }
}
