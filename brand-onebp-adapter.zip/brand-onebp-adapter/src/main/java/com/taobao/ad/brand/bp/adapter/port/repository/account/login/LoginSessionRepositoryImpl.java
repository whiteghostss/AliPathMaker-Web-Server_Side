package com.taobao.ad.brand.bp.adapter.port.repository.account.login;

import com.alibaba.abf.governance.context.GatewayContext;
import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.uic.common.dto.login.ADUicSessionDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.account.login.LoginSessionConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.login.LoginSessionSAO;
import com.taobao.ad.brand.bp.client.dto.account.login.LoginSessionViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.account.repository.LoginSessionRepository;

import org.springframework.stereotype.Repository;

import lombok.RequiredArgsConstructor;

/**
 * @author 虫洞 <liuming.liu@alibaba-inc.com>
 * @date 2023/4/26
 */
@Repository
@RequiredArgsConstructor
public class LoginSessionRepositoryImpl implements LoginSessionRepository {
    private final LoginSessionSAO loginSessionSAO;
    private final LoginSessionConverter loginSessionConverter;

    @Override
    public LoginSessionViewDTO get(ServiceContext serviceContext, GatewayContext gatewayContext) {
        AssertUtil.notNull(serviceContext, "serviceContext is null");

        ADUicSessionDTO adUicSessionDTO;
        if (serviceContext.getMemberId() == null) {
            // 没有memberId，表示未登录
            adUicSessionDTO = loginSessionSAO.getPreSession(serviceContext, gatewayContext);
        } else {
            // 有memberId，表示已经登录
            adUicSessionDTO = loginSessionSAO.getSession(serviceContext, gatewayContext);
        }
        return loginSessionConverter.convertDTO2ViewDTO(adUicSessionDTO);
    }
}
