package com.taobao.ad.brand.bp.adapter.port.converter.feed;

import com.alibaba.ad.feed.dto.feedoutentity.OutItemInventoryDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.feed.mapstruct.ItemInventoryMapStruct;
import com.taobao.ad.brand.bp.client.dto.item.ItemInventoryViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.springframework.stereotype.Component;

/**
 * @Author: PhilipFry
 * @createTime: 2024年05月08日 10:55:13
 * @Description:
 */
@Component
public class ItemInventoryConverter extends BaseViewDTOConverter<OutItemInventoryDTO, ItemInventoryViewDTO> {
    @Override
    public BaseMapStructMapper<OutItemInventoryDTO, ItemInventoryViewDTO> getBaseMapStructMapper() {
        return ItemInventoryMapStruct.INSTANCE;
    }
}
