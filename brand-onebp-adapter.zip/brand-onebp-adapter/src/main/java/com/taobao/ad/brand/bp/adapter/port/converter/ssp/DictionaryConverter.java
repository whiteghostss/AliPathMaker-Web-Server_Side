package com.taobao.ad.brand.bp.adapter.port.converter.ssp;

import com.alibaba.ad.nb.ssp.dto.dict.DictionaryDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.ssp.mapstruct.DictionaryMapStruct;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.springframework.stereotype.Component;

/**
 * @author jixiu.lj
 * @date 2023/3/23 22:53
 */
@Component
public class DictionaryConverter extends BaseViewDTOConverter<DictionaryDTO, CommonViewDTO> {
    @Override
    public BaseMapStructMapper<DictionaryDTO, CommonViewDTO> getBaseMapStructMapper() {
        return DictionaryMapStruct.INSTANCE;
    }
}
