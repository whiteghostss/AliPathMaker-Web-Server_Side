package com.taobao.ad.brand.bp.adapter.port.converter.resourcepackage.mapstruct;

import com.alibaba.ad.nb.packages.v2.client.dto.salegroup.ResourcePackageSaleGroupDTO;

import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/23
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, uses = {ResourceDistributionRuleMapStruct.class})
public interface ResourcePackageSaleGroupMapStruct extends BaseMapStructMapper<ResourcePackageSaleGroupDTO, ResourcePackageSaleGroupViewDTO> {
    ResourcePackageSaleGroupMapStruct INSTANCE = Mappers.getMapper(ResourcePackageSaleGroupMapStruct.class);

    @Mappings({
            @Mapping(source = "distributionRuleDTOList", target = "distributionRuleList"),
            @Mapping(source = "chargeType", target = "saleType"),
            @Mapping(source = "saleAmount", target = "budget"),
            @Mapping(source = "newDeliveryTargetList", target = "resourceDeliveryTargetList"),
            @Mapping(source = "optimizeTargetList", target = "resourceOptimizeTargetList"),
            @Mapping(source = "priceAuditStatus", target = "processAuditInfo.priceAuditStatus"),
            @Mapping(source = "priceAuditWorkflowInstanceId", target = "processAuditInfo.priceAuditWorkflowInstanceId"),
            @Mapping(source = "auditStatus", target = "processAuditInfo.auditStatus"),
            @Mapping(source = "auditWorkflowInstanceId", target = "processAuditInfo.auditWorkflowInstanceId"),
    })
    @Override
    ResourcePackageSaleGroupViewDTO sourceToTarget(ResourcePackageSaleGroupDTO resourcePackageSaleGroupDTO);

    @Mappings({
            @Mapping(source = "distributionRuleList", target = "distributionRuleDTOList"),
            @Mapping(source = "saleType", target = "chargeType"),
            @Mapping(source = "budget", target = "saleAmount"),
            @Mapping(source = "resourceDeliveryTargetList", target = "newDeliveryTargetList"),
            @Mapping(source = "resourceOptimizeTargetList", target = "optimizeTargetList"),
            @Mapping(source = "processAuditInfo.priceAuditStatus", target = "priceAuditStatus"),
            @Mapping(source = "processAuditInfo.priceAuditWorkflowInstanceId", target = "priceAuditWorkflowInstanceId"),
            @Mapping(source = "processAuditInfo.auditStatus", target = "auditStatus"),
            @Mapping(source = "processAuditInfo.auditWorkflowInstanceId", target = "auditWorkflowInstanceId"),

    })
    @Override
    ResourcePackageSaleGroupDTO targetToSource(ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO);

}