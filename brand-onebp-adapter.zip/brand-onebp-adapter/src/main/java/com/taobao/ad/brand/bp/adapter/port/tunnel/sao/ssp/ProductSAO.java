package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.ssp;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.nb.crm.api.dsp.DspMemberQueryService;
import com.alibaba.ad.nb.crm.dto.dsp.DspMemberDTO;
import com.alibaba.ad.nb.crm.dto.dsp.DspMemberQueryDTO;
import com.alibaba.ad.nb.ssp.api.category.CategoryQueryService;
import com.alibaba.ad.nb.ssp.api.dict.DictionaryQueryService;
import com.alibaba.ad.nb.ssp.api.newproduct.ProductQueryService;
import com.alibaba.ad.nb.ssp.dto.dict.*;
import com.alibaba.ad.nb.ssp.dto.newproduct.ProductDTO;
import com.alibaba.ad.nb.ssp.dto.newproduct.ProductQueryDTO;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.product.ProductQueryOption;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ProductSAO extends BaseSAO {

    private final ProductQueryService productQueryService;
    private final DictionaryQueryService dictionaryQueryService;
    private final CategoryQueryService categoryQueryService;
    private final DspMemberQueryService dspMemberQueryService;


    public ProductDTO getProductById(Long id) {
        com.alibaba.ad.nb.ssp.context.ServiceContext context = com.alibaba.ad.nb.ssp.context.ServiceContext.create();
        SingleResponse<ProductDTO> response = productQueryService.get(context, id);
        AssertUtil.assertTrue(response);
        return response.getResult();
    }

    public List<ProductDTO> getProductList(ProductQueryDTO productQueryDTO) {
        com.alibaba.ad.nb.ssp.context.ServiceContext productServiceContext = com.alibaba.ad.nb.ssp.context.ServiceContext.create();
        MultiResponse<ProductDTO> response = productQueryService.list(productServiceContext, productQueryDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, "资源产品信息查询失败:" + response.getErrorMsg());
        return response.getResult();
    }

    public List<ProductDTO> getProductByQuery(List<Long> uuids, ProductQueryOption productQueryOption) {
        ProductQueryDTO productQueryDTO = ProductQueryDTO.builder()
                .needAdzone(productQueryOption.isNeedAdzone())
                .needResource(productQueryOption.isNeedResource())
                .needAssociationProduct(productQueryOption.isNeedAssociationProduct())
                .needParentName(productQueryOption.isNeedParentName())
                .needLabelName(productQueryOption.isNeedLabelName())
                .needTemplateName(productQueryOption.isNeedTemplateName())
                .needPage(productQueryOption.isNeedPage())
                .needDirection(productQueryOption.isNeedDirection())
                .productUuidList(uuids)
                .build();
        com.alibaba.ad.nb.ssp.context.ServiceContext productServiceContext = com.alibaba.ad.nb.ssp.context.ServiceContext.create();
        MultiResponse<ProductDTO> response = productQueryService.list(productServiceContext, productQueryDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, "资源产品信息查询失败:" + response.getErrorMsg());
        return response.getResult();
    }

    public List<ProductDTO> getProductByUuid(List<Long> productUuids) {
        if (CollectionUtils.isEmpty(productUuids)){

            return Lists.newArrayList();
        }
        com.alibaba.ad.nb.ssp.context.ServiceContext productServiceContext = com.alibaba.ad.nb.ssp.context.ServiceContext.create();
        ProductQueryDTO productQueryDTO = new ProductQueryDTO();
        productQueryDTO.setProductUuidList(productUuids);
        productQueryDTO.setNeedResource(true);
        productQueryDTO.setNeedAdzone(true);
//        productQueryDTO.setNeedDirection(true);
        productQueryDTO.setNeedDirectionFirstNode(true);
        productQueryDTO.setNeedTemplateName(true);
        productQueryDTO.setNeedParentName(true);
        productQueryDTO.setNeedLabelName(true);
        productQueryDTO.setPageSize(productUuids.size());
        MultiResponse<ProductDTO> response = productQueryService.list(productServiceContext, productQueryDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, "资源产品信息查询失败:" + response.getErrorMsg());
        return response.getResult();
    }

    public List<ProductDTO> getProductListByName(String name) {
        if (StringUtils.isBlank(name)){
            return Lists.newArrayList();
        }
        com.alibaba.ad.nb.ssp.context.ServiceContext productServiceContext = com.alibaba.ad.nb.ssp.context.ServiceContext.create();
        ProductQueryDTO productQueryDTO = new ProductQueryDTO();
        productQueryDTO.setCustomerOrientedResourceName(name);
        productQueryDTO.setPageSize(40);
        MultiResponse<ProductDTO> response = productQueryService.list(productServiceContext, productQueryDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, "资源产品信息查询失败:" + response.getErrorMsg());
        return response.getResult();
    }

    public List<DictionaryDTO> getSSPDict(String type) {
        if (StringUtils.isBlank(type)){
            return Lists.newArrayList();
        }
        DictionaryQueryDTO queryDTO = new DictionaryQueryDTO();
        queryDTO.setType(type);
        com.alibaba.ad.nb.ssp.context.ServiceContext context = com.alibaba.ad.nb.ssp.context.ServiceContext.create();
        MultiResponse<DictionaryDTO> response = dictionaryQueryService.list(context, queryDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR,"资源字典信息查询失败:"+response.getErrorMsg());
        return response.getResult();
    }

    public List<DictionaryDTO> getSSPDict(String type, List<String> ids) {
        if(CollectionUtils.isEmpty(ids)){
            return Lists.newArrayList();
        }
        DictionaryQueryDTO queryDTO = new DictionaryQueryDTO();
        queryDTO.setType(type);
        queryDTO.setValueList(ids);
        queryDTO.setNeedPage(false);
        com.alibaba.ad.nb.ssp.context.ServiceContext context = com.alibaba.ad.nb.ssp.context.ServiceContext.create();
        MultiResponse<DictionaryDTO> response = dictionaryQueryService.list(context, queryDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR,"资源字典信息查询失败:"+response.getErrorMsg());
        return response.getResult();
    }

    public List<DictionaryDTO> getSSPDictByName(String type,String name) {
        DictionaryQueryDTO queryDTO = new DictionaryQueryDTO();
        queryDTO.setType(type);
        queryDTO.setName(name);
        com.alibaba.ad.nb.ssp.context.ServiceContext context = com.alibaba.ad.nb.ssp.context.ServiceContext.create();
        MultiResponse<DictionaryDTO> response = dictionaryQueryService.list(context, queryDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR,"媒体字典信息查询失败:"+response.getErrorMsg());
        return response.getResult();
    }

    public List<AreaDTO> getSSPArea(List<Integer> areaIds) {
        com.alibaba.ad.nb.ssp.context.ServiceContext context = com.alibaba.ad.nb.ssp.context.ServiceContext.create();
        AreaQueryDTO queryDTO = new AreaQueryDTO();
        queryDTO.setValueList(areaIds);
        MultiResponse<AreaDTO> response = dictionaryQueryService.listAreas(context, queryDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, "资源地域信息查询失败:"+response.getErrorMsg());
        return response.getResult();
    }

    public List<AreaDTO> getSSPArea(ServiceContext serviceContext) {
        com.alibaba.ad.nb.ssp.context.ServiceContext context = com.alibaba.ad.nb.ssp.context.ServiceContext.create();
        AreaQueryDTO queryDTO = new AreaQueryDTO();
        MultiResponse<AreaDTO> response = dictionaryQueryService.listAreas(context, queryDTO);
        AssertUtil.assertTrue(response.isSuccess(), "资源地域信息查询失败:"+response.getErrorMsg());
        return response.getResult();
    }

    /**
     * 查询频道配置
     * @return
     */
    public List<CategoryDTO> getSSPChannel(CategoryQueryDTO categoryQueryDTO) {
        MultiResponse<CategoryDTO> response = categoryQueryService.list(
                com.alibaba.ad.nb.ssp.context.ServiceContext.create(), categoryQueryDTO);
        AssertUtil.assertTrue(response.isSuccess(),"频道信息查询失败:"+response.getErrorMsg());
        return response.getResult();
    }

    public List<DspMemberDTO> getDspList(ServiceContext serviceContext, DspMemberQueryDTO queryDTO) {
        com.alibaba.ad.nb.crm.context.ServiceContext tanxCrmServiceContext = com.alibaba.ad.nb.crm.context.ServiceContext.createServiceContext();
        MultiResponse<DspMemberDTO> response = dspMemberQueryService.listDspMembers(tanxCrmServiceContext, queryDTO);
        AssertUtil.assertTrue(response.isSuccess(), "DSP信息查询失败:"+response.getErrorMsg());
        return response.getResult();
    }


}