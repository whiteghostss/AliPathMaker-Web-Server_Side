package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.purchase;

import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class PurchaseSAO extends BaseSAO {



}