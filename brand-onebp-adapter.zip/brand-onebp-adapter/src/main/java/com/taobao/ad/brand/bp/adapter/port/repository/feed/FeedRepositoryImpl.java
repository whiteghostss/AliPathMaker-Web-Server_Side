package com.taobao.ad.brand.bp.adapter.port.repository.feed;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.feed.dto.feedoutentity.AccessAllowDTO;
import com.alibaba.ad.feed.dto.feedoutentity.OutCatDTO;
import com.alibaba.ad.feed.dto.feedoutentity.OutShopDTO;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.adapter.port.converter.feed.ItemInventoryConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.agi.GenerateImagesTemplateSAO;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.feed.FeedSAO;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.lamp.AladdinLampSAO;
import com.taobao.ad.brand.bp.client.dto.cat.CategoryViewDTO;
import com.taobao.ad.brand.bp.client.dto.item.ItemInventoryViewDTO;
import com.taobao.ad.brand.bp.client.dto.rule.RuleCheckResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.shop.ShopViewDTO;
import com.taobao.ad.brand.bp.domain.feed.FeedRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class FeedRepositoryImpl implements FeedRepository {

    private final FeedSAO feedSAO;
    private final ItemInventoryConverter itemInventoryConverter;


    @Override
    public List<CategoryViewDTO> getCatByIds(List<Long> categoryIds) {
        List<OutCatDTO> outCatDTOList = feedSAO.getCatByIds(categoryIds);
        return outCatDTOList.stream().map(outCatDTO -> {
            CategoryViewDTO categoryViewDTO = new CategoryViewDTO();
            categoryViewDTO.setCatId(outCatDTO.getCatId());
            categoryViewDTO.setCatName(outCatDTO.getCatName());
            return categoryViewDTO;
        }).collect(Collectors.toList());
    }

    /**
     * 根据memberid获取shopid
     * */
    @Override
    public Long getShopIdByMemberId(Long memberId) {
        return feedSAO.getShopIdByMemberId(memberId);
    }

    @Override
    public ShopViewDTO getShopInfoByMemberId(Long memberId) {
        OutShopDTO outShopDTO = feedSAO.getShopInfoByMemberId(memberId);
        if(Objects.nonNull(outShopDTO)){
            ShopViewDTO shopViewDTO = new ShopViewDTO();
            shopViewDTO.setId(outShopDTO.getShopId());
            shopViewDTO.setName(outShopDTO.getName());
            return shopViewDTO;
        }
        return null;
    }

    @Override
    public List<ItemInventoryViewDTO> getItemInventory(Long itemId, Long skuId) {
        return itemInventoryConverter.convertDTO2ViewDTOList(feedSAO.getItemInventory(itemId, skuId));
    }

    @Override
    public Long getUserIdByShopId(Long shopId) {
        return feedSAO.getUserIdByShopId(shopId);
    }
    @Override
    public Long getShopIdByUserId(Long userId) {
        return feedSAO.getShopIdByUserId(userId);
    }
    @Override
    public Long getUserIdByItemId(Long itemId) {
        return feedSAO.getItemUserId(itemId);
    }

    @Override
    public RuleCheckResultViewDTO checkAccess(ServiceContext serviceContext, Long itemId) {
        AccessAllowDTO accessAllowDTO = feedSAO.checkAccess(serviceContext.getMemberId(), itemId);
        if(accessAllowDTO == null){
            RogerLogger.info(String.format("商品准入结果查询失败，itemId=%s",itemId));
            return RuleCheckResultViewDTO.builder().isPass(BrandBoolEnum.BRAND_TRUE.getCode()).build();
        }
        RuleCheckResultViewDTO ruleCheckResultViewDTO = new RuleCheckResultViewDTO();
        ruleCheckResultViewDTO.setIsPass(accessAllowDTO.getAccessAllowed() ? BrandBoolEnum.BRAND_TRUE.getCode() : BrandBoolEnum.BRAND_FALSE.getCode());
        ruleCheckResultViewDTO.setReason(accessAllowDTO.getReason());
        return ruleCheckResultViewDTO;
    }
}
