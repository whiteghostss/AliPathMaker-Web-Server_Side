package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.sales;

import com.alibaba.ad.nb.common.dto.NbServiceContext;
import com.alibaba.ad.nb.sales.context.NbServiceContext2;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;

/**
 * @author yanjingang
 * @date 2023/3/16
 */
public class SalesBaseSAO extends BaseSAO {

    protected final static String MM_SALES_BIZ_CODE = "nb-brandOneBp";

    protected static NbServiceContext createNbServiceContext() {
        NbServiceContext context = NbServiceContext.createServiceContext("-1");
        context.setBizCode(MM_SALES_BIZ_CODE);
        return context;
    }
    protected static NbServiceContext2 createNbServiceContext2() {
        NbServiceContext2 context = new NbServiceContext2();
        context.setEmpId("-1");
        context.setBizCode(MM_SALES_BIZ_CODE);
        return context;
    }

    protected static NbServiceContext2 createNbServiceContext2(Long memberId) {
        NbServiceContext2 context = new NbServiceContext2();
        context.setMemberId(memberId);
        context.setEmpId("-1");
        context.setBizCode(MM_SALES_BIZ_CODE);
        return context;
    }
}
