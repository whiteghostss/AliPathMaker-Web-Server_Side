package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.dmp;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.SAO;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.constant.DmpConstant;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.dmp.site.sdk.dto.AppContextDTO;
import com.taobao.ad.dmp.site.sdk.dto.GoodsItemQueryDTO;
import com.taobao.ad.dmp.site.sdk.dto.ItemIndicatorDTO;
import com.taobao.ad.dmp.site.sdk.dto.Pager;
import com.taobao.ad.dmp.site.sdk.dto.ResultDTO;
import com.taobao.ad.dmp.site.sdk.interfaces.GoodsItemService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * @author yanjingang
 * @date 2025/2/18
 */
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DmpSiteSAO implements SAO {

    private final GoodsItemService goodsItemService;

    public List<ItemIndicatorDTO> findItemIndicatorsTrend(ServiceContext serviceContext, GoodsItemQueryDTO goodsItemQueryDTO) {
        AppContextDTO appContextDTO = initDmpContext(serviceContext.getMemberId(), DmpConstant.APP_ID);
        ResultDTO<List<ItemIndicatorDTO>> resultDTO = goodsItemService.findItemIndicatorsTrend(appContextDTO, goodsItemQueryDTO);
        RogerLogger.info("查询DMP宝贝趋势 {}, {}, 返回 {}", JSONObject.toJSONString(appContextDTO), JSONObject.toJSONString(goodsItemQueryDTO), JSONObject.toJSONString(resultDTO));
        if (!resultDTO.isSuccess()) {
            return Lists.newArrayList();
        }
        return resultDTO.getResult();
    }

    public List<ItemIndicatorDTO> findItemList4ShowMax(ServiceContext serviceContext, GoodsItemQueryDTO goodsItemQueryDTO, Pager pager) {
        AppContextDTO appContextDTO = initDmpContext(serviceContext.getMemberId(), DmpConstant.APP_ID);
        ResultDTO<List<ItemIndicatorDTO>> resultDTO = goodsItemService.findItemList4ShowMax(appContextDTO, goodsItemQueryDTO, pager);
        RogerLogger.info("查询DMP宝贝列表入参 {}, {}, {}, 返回 {}", JSONObject.toJSONString(appContextDTO), JSONObject.toJSONString(goodsItemQueryDTO), JSONObject.toJSONString(pager), JSONObject.toJSONString(resultDTO));
        AssertUtil.assertTrue(resultDTO.isSuccess(), "查询宝贝失败");
        return resultDTO.getResult();
    }

    private AppContextDTO initDmpContext(Long memberId, Long appId){
        AssertUtil.notNull(memberId, "memberId不能为空");
        AppContextDTO contextDTO = new AppContextDTO();
        contextDTO.setAppId(appId);
        contextDTO.setMemberId(memberId);
        return contextDTO;
    }
}
