package com.taobao.ad.brand.bp.adapter.port.converter.motion.mapstruct;

import com.alibaba.ad.nb.packages.v2.client.dto.motion.MediaStrategyDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.motion.ResourceTypeStrategyDTO;
import com.taobao.ad.brand.bp.client.dto.motion.MediaStrategyViewDTO;
import com.taobao.ad.brand.bp.client.dto.motion.ResourceTypeStrategyViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/18
 **/
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ResourceTypeStrategyMapStruct extends BaseMapStructMapper<ResourceTypeStrategyDTO, ResourceTypeStrategyViewDTO> {

    MediaStrategyMapStruct INSTANCE = Mappers.getMapper(MediaStrategyMapStruct.class);

    @Mappings({
            @Mapping(source = "predictData", target = "predictDataViewDTO"),
    })
    @Override
    ResourceTypeStrategyViewDTO sourceToTarget(ResourceTypeStrategyDTO resourceTypeStrategyDTO);

    @Mappings({
            @Mapping(source = "predictDataViewDTO", target = "predictData"),
    })
    @Override
    ResourceTypeStrategyDTO targetToSource(ResourceTypeStrategyViewDTO resourceTypeStrategyViewDTO);
}
