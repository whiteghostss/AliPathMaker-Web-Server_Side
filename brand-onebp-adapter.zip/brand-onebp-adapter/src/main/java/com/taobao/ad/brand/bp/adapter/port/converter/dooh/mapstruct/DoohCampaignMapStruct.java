package com.taobao.ad.brand.bp.adapter.port.converter.dooh.mapstruct;

import com.taobao.ad.brand.bp.client.dto.dooh.DoohCampaignViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.umeng.oplus.domain.dto.dsp.plan.DspPlan4BailingDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, uses = {DoohCampaignMapStruct.class})
public interface DoohCampaignMapStruct extends BaseMapStructMapper<DspPlan4BailingDTO, DoohCampaignViewDTO> {

    DoohCampaignMapStruct INSTANCE = Mappers.getMapper(DoohCampaignMapStruct.class);

    @Mappings({
            @Mapping(source = "dspPlanId", target = "id"),
            @Mapping(source = "dspPlanName", target = "name"),
            @Mapping(source = "dspSchemeId", target = "strategyId"),
            @Mapping(source = "bailingPlanId", target = "brandCampaignId"),
            @Mapping(source = "materialPlanSet.materials", target = "materials"),
            @Mapping(source = "materialPlanSet.mrOssUrl", target = "mrOssUrl"),
            @Mapping(target = "status", expression = "java(dspPlan4BailingDTO.getScheduleState().getCode())")
    })
    @Override
    DoohCampaignViewDTO sourceToTarget(DspPlan4BailingDTO dspPlan4BailingDTO);

    @Mappings({
            @Mapping(source = "id", target = "dspPlanId"),
            @Mapping(source = "name", target = "dspPlanName"),
            @Mapping(source = "strategyId", target = "dspSchemeId"),
            @Mapping(source = "brandCampaignId", target = "bailingPlanId")
    })
    @Override
    DspPlan4BailingDTO targetToSource(DoohCampaignViewDTO doohCampaignViewDTO);

}
