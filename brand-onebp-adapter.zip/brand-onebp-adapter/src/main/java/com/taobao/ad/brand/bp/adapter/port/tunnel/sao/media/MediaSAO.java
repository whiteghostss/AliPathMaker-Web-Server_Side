package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.media;

import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.alibaba.uad.wto.api.resource.MediaQueryService;
import com.alibaba.uad.wto.constant.resource.MediaResourceSettingEnum;
import com.alibaba.uad.wto.context.ServiceContext;
import com.alibaba.uad.wto.dto.common.SettingQueryDTO;
import com.alibaba.uad.wto.dto.resource.MediaDTO;
import com.alibaba.uad.wto.dto.resource.query.MediaBusinessManagerQueryDTO;
import com.alibaba.uad.wto.dto.resource.query.MediaQueryDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.adapter.port.converter.media.MediaDTOConverter;
import com.taobao.ad.brand.bp.client.dto.media.MediaBusinessManagerViewDTO;
import com.taobao.ad.brand.bp.client.dto.media.MediaContactViewDTO;
import com.taobao.ad.brand.bp.client.dto.media.MediaViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class MediaSAO extends BaseSAO {

    private final MediaQueryService mediaQueryService;

    private final MediaDTOConverter mediaDTOConverter;

    /**
     * 媒体信息
     * */
    public List<MediaViewDTO> queryMediaListByMediaIds(List<Long> mediaIds){
        MediaQueryDTO mediaQueryDTO = new MediaQueryDTO();
        mediaQueryDTO.setMediaIdList(mediaIds);
        ServiceContext serviceContext = ServiceContext.builder().build();
        MultiResponse<MediaDTO> response =  mediaQueryService.listMedias(serviceContext,mediaQueryDTO);
        AssertUtil.assertTrue(response);
       return  mediaDTOConverter.convertDTO2ViewDTOList(response.getResult());

    }
    public List<MediaBusinessManagerViewDTO> queryMediaBusinessManagerByMediaIds(List<Long> mediaIds){
        MediaBusinessManagerQueryDTO mediaQueryDTO = new MediaBusinessManagerQueryDTO();
        mediaQueryDTO.setMediaIdList(mediaIds);
        mediaQueryDTO.setBusinessType(com.alibaba.uad.wto.constant.PlatformBusinessEnum.UD.getCode());
        ServiceContext serviceContext = ServiceContext.builder().build();
        MultiResponse<MediaDTO.BusinessManagerDTO> response =  mediaQueryService.listBusinessManagers(serviceContext,mediaQueryDTO);
        AssertUtil.assertTrue(response);
        return Optional.ofNullable(response.getResult()).orElse(Lists.newArrayList()).stream().map(item->{
            MediaBusinessManagerViewDTO mediaBusinessManagerViewDTO = new MediaBusinessManagerViewDTO();
            mediaBusinessManagerViewDTO.setName(item.getEmpName());
            mediaBusinessManagerViewDTO.setEmail(item.getEmail());
            return mediaBusinessManagerViewDTO;
        }).collect(Collectors.toList());


    }
    public List<MediaViewDTO> queryMediaListBySiteIds(List<Long> siteIds){
        MediaQueryDTO mediaQueryDTO = new MediaQueryDTO();
        mediaQueryDTO.setSiteIdList(siteIds);
        ServiceContext serviceContext = ServiceContext.builder().build();
        MultiResponse<MediaDTO> response =  mediaQueryService.listMedias(serviceContext,mediaQueryDTO);
        AssertUtil.assertTrue(response);
        return  mediaDTOConverter.convertDTO2ViewDTOList(response.getResult());
    }

    /**
     * 媒体联系人
     * */
    public List<MediaContactViewDTO> queryMediaContactList(List<Long> mediaIds){
        MediaDTO.MediaContactQueryDTO mediaQueryDTO = new MediaDTO.MediaContactQueryDTO();
        mediaQueryDTO.setMediaIdList(mediaIds);
        ServiceContext serviceContext = ServiceContext.builder().build();
        MultiResponse<MediaDTO.MediaContactDTO> response =  mediaQueryService.listMediaContacts(serviceContext,mediaQueryDTO);
        AssertUtil.assertTrue(response);
       return Optional.ofNullable(response.getResult()).orElse(Lists.newArrayList()).stream().map(item->{
            MediaContactViewDTO mediaContactViewDTO = new MediaContactViewDTO();
            mediaContactViewDTO.setEmail(item.getEmail());
            mediaContactViewDTO.setMediaId(item.getMediaId());
            mediaContactViewDTO.setId(item.getId());
            mediaContactViewDTO.setName(item.getName());
            return mediaContactViewDTO;
        }).collect(Collectors.toList());

    }

    /**
     * 媒体信息
     * */
    public List<MediaViewDTO> queryMediaWithSettingByMediaIds(List<Long> mediaIds){
        MediaQueryDTO mediaQueryDTO = new MediaQueryDTO();
        mediaQueryDTO.setMediaIdList(mediaIds);
        mediaQueryDTO.setNeedSetting(true);
        SettingQueryDTO settingQueryDTO = new SettingQueryDTO();
//        settingQueryDTO.setKey(MediaResourceSettingEnum.NB_WTO_CONTENT_USED_FLAG.getCode());
//        settingQueryDTO.setValues(Lists.newArrayList(1));
//        mediaQueryDTO.setSettingQueryList();
        ServiceContext serviceContext = ServiceContext.builder().build();
        MultiResponse<MediaDTO> response =  mediaQueryService.listMedias(serviceContext,mediaQueryDTO);
        AssertUtil.assertTrue(response);
        return  mediaDTOConverter.convertDTO2ViewDTOList(response.getResult());

    }
}
