package com.taobao.ad.brand.bp.adapter.port.converter.account.agreement;

import com.alibaba.legal.agreement.dto.AgreementSignResultDto;
import com.taobao.ad.brand.bp.adapter.port.converter.account.agreement.mapstruct.AgreementMapStruct;
import com.taobao.ad.brand.bp.client.dto.account.agreement.AgreementSignResultViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;

import org.springframework.stereotype.Component;

/**
 * @author 虫洞 <liuming.liu@alibaba-inc.com>
 * @date 2023/4/4
 */
@Component
public class AgreementConverter extends BaseViewDTOConverter<AgreementSignResultDto, AgreementSignResultViewDTO> {
    @Override
    public BaseMapStructMapper<AgreementSignResultDto, AgreementSignResultViewDTO> getBaseMapStructMapper() {
        return AgreementMapStruct.INSTANCE;
    }
}
