package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.uic;

import com.alibaba.ad.nb.order.api.user.BucUserQueryService;
import com.alibaba.ad.nb.order.dto.common.EmpDTO;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Map;
import java.util.Set;

@BizTunnel
@RequiredArgsConstructor(onConstructor_ = @Autowired)
public class SimbaUicSAO {

    private final BucUserQueryService bucUserQueryService;

    /**
     * 根据员工账户查询员工信息
     *
     * @param empId
     * @return
     */
    public EmpDTO getEmp(String empId) {
        SingleResponse<EmpDTO> response = bucUserQueryService.getEmpInfo(empId);
        AssertUtil.assertTrue(response.isSuccess(), response.getErrorMsg());
        return response.getResult();
    }

    /**
     * 查询
     *
     * @param empIds
     * @return
     */
    public Map<String, EmpDTO> getEmp(Set<String> empIds) {
        SingleResponse<Map<String, EmpDTO>> response = bucUserQueryService.findEmpInfos(empIds);
        AssertUtil.assertTrue(response.isSuccess(), "buc服务查询失败：" + response.getErrorMsg());
        return response.getResult();
    }

    /**
     * 根据员工id查询员工信息
     * @param bucUserId
     * @return
     */
    public EmpDTO getEmpByBucUserId(Long bucUserId) {
        SingleResponse<String> response = bucUserQueryService.getEmpIdByBucId(bucUserId);
        AssertUtil.assertTrue(response.isSuccess(), response.getErrorMsg());
        return getEmp(response.getResult());
    }

    /**
     * 查询员工邮箱
     *
     * @param empIds
     * @return
     */
    public Map<String, String> getEmpEmails(Set<String> empIds) {
        if (CollectionUtils.isEmpty(empIds)) {
            return Maps.newHashMap();
        }
        Map<String, String> mapResult = Maps.newHashMap();
        SingleResponse<Map<String, EmpDTO>> response = bucUserQueryService.findEmpInfos(empIds);
        AssertUtil.assertTrue(response.isSuccess(), "buc服务查询失败：" + response.getErrorMsg());
        Map<String, EmpDTO> aliNoMap = response.getResult();
        if (MapUtils.isNotEmpty(aliNoMap)) {
            for (Map.Entry<String, EmpDTO> entry : aliNoMap.entrySet()) {
                if ("A".equals(entry.getValue().getStatus())) {
                    mapResult.put(entry.getValue().getEmpId(), entry.getValue().getEmail());
                }
            }
        }
        return mapResult;
    }
}
