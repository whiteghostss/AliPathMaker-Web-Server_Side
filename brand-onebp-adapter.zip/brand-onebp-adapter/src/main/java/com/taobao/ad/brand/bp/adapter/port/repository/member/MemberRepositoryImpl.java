package com.taobao.ad.brand.bp.adapter.port.repository.member;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.common.annotation.SwitchContext;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.uic.common.dto.accesscontrol.ssp.JoinSspDTO;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.MemberSAO;
import com.taobao.ad.brand.bp.client.dto.shop.ShopViewDTO;
import com.taobao.ad.brand.bp.common.constant.AdcRoleConstant;
import com.taobao.ad.brand.bp.domain.memeber.MemberRepository;
import com.taobao.ad.simba.user.consts.RelMemberType;
import com.taobao.ad.simba.user.dto.ShopInfoDTO;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

import java.util.*;

/**
 * @author jixiu.lj
 * @date 2023/3/21 09:48
 */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class MemberRepositoryImpl implements MemberRepository {
    private final MemberSAO memberSAO;

    @Override
    public String getTbNickNameByMemberId(Long memberId) {
        return memberSAO.getMemberNameById(memberId);
    }

    @Override
    @Cacheable(value = "uic-role", key = "#memberId")
    public Set<String> findRoleCodeByMemberId(Long memberId) {
        if (memberId == null) {
            return Collections.emptySet();
        }
        RogerLogger.info("a cache miss, request to find role, memberId={}", memberId);
        Set<String> roleCodeSet = memberSAO.findRoleCodeByMemberId(memberId);
        if(CollectionUtils.isEmpty(roleCodeSet)){
            return Collections.emptySet();
        }
        //去除基础角色
        roleCodeSet.removeAll(AdcRoleConstant.getBasicRoleList());
        return roleCodeSet;
    }

    @Override
    public Long getMemberIdByTbNumId(Long tbUserId) {
        return memberSAO.getMemberIdByTbNumId(tbUserId);
    }

    @Override
    public String getMemberNameById(Long memberId) {
        if (memberId == null) {
            return null;
        }
        return memberSAO.getMemberNameById(memberId);
    }

    @Override
    public String getMemberDisplayNameById(Long memberId) {
        if (memberSAO.queryRelMemberType(memberId) != null) {
            Map<Long, String> memberNameMap = this.queryXMemberDisplayNameMap(Collections.singletonList(memberId));
            return memberNameMap.get(memberId);
        }
        return getMemberNameById(memberId);
    }

    @Override
    public Map<Long, String> queryXMemberDisplayNameMap(List<Long> memberIds) {
        return memberSAO.queryXMemberDisplayNameMap(memberIds);
    }

    @Override
    public Long getTargetMemberIdByMemberId(Long memberId) {
        //如果是叉乘账号memberid，返回叉乘账号的memberType,如果是商家账号，返回null
        Integer relMemberType = getRelMemberType(memberId);
        return getTargetMemberIdByMemberId(memberId, relMemberType);
    }

    @Override
    public Long getTargetMemberIdByMemberId(Long memberId, Integer relMemberType) {
        if (RelMemberType.AGENCY.getValue().equals(relMemberType)) {
            return memberSAO.queryAgencyTargetMemberId(memberId);
        }
        if (RelMemberType.SEM_PROXY.getValue().equals(relMemberType)) {
            return memberSAO.querySemTargetMemberId(memberId);
        }
        if (RelMemberType.XIAOER_PROXY.getValue().equals(relMemberType)) {
            return memberSAO.queryTargetMemberOfRelMember(memberId);
        }
        return memberId;
    }

    @Override
    public Integer getRelMemberType(Long memberId) {
        return memberSAO.queryRelMemberType(memberId);
    }

    @SwitchContext
    @Override
    public List<String> getJoinResult(ServiceContext context, Long memberId, List<String> supportScenceCodeList) {
        context.setBizCode(BizCodeEnum.BRANDONEBP.getBizCode());
        return memberSAO.queryJoinResult(context, memberId, supportScenceCodeList);
    }
    @SwitchContext
    public List<String> getSspJoinResult(ServiceContext context, Long memberId, List<String> supportSspCodeList) {
        context.setBizCode(BizCodeEnum.BRANDONEBP.getBizCode());
        return memberSAO.querySspJoinResult(context, memberId, supportSspCodeList);
    }

    @Override
    public ShopViewDTO getShopByMemberId(Long cusMemberId) {
        ShopInfoDTO shopInfoDTO = memberSAO.getShopByMemberId(cusMemberId);
        if(shopInfoDTO == null){
            return null;
        }
        ShopViewDTO shopViewDTO = new ShopViewDTO();
        shopViewDTO.setId(shopInfoDTO.getId());
        shopViewDTO.setName(shopViewDTO.getName());
        return shopViewDTO;
    }

    @Override
    public Long getTbNumIdByMemberId(Long memberId) {
        return memberSAO.getTbNumIdByMemberId(memberId);
    }

    @Override
    public Boolean isAgencyX(Long memberId) {
        return memberSAO.isAgencyX(memberId);
    }

    @Override
    public Long queryAgencyMemberId(Long memberId) {
        return memberSAO.queryAgencyMemberId(memberId);
    }
}
