package com.taobao.ad.brand.bp.adapter.port.repository.campaigngroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupContractPayTypeEnum;
import com.alibaba.ad.nb.sales.dto.contract.ContractBalance;
import com.alibaba.ad.nb.sales.dto.contract.ContractChargeDTO;
import com.alibaba.ad.nb.sales.dto.contract.ContractMemberInfo;
import com.alibaba.ad.nb.sales.dto.zhubajie.CompleteBrandDTO;
import com.alibaba.ad.nb.sales.dto.zhubajie.CompleteContractBrandDTO;
import com.alibaba.ad.nb.sales.dto.zhubajie.QabDimShopIdBrandIdDTO;
import com.alibaba.solar.libra.client.dto.ContractVersionDTO;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.adapter.port.converter.sales.ContractAmountViewDTOConverter;
import com.taobao.ad.brand.bp.adapter.port.converter.sales.ContractBrandViewDTOConverter;
import com.taobao.ad.brand.bp.adapter.port.converter.sales.ContractViewDTOConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.sales.ContractSAO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupCustomerMemberViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesContractAmountViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesContractBrandViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesContractViewDTO;
import com.taobao.ad.brand.bp.client.dto.shop.ShopBrandViewDTO;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.SalesContractRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * @author yanjingang
 * @date 2023/3/16
 */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SalesContractRepositoryImpl implements SalesContractRepository {

    private final ContractSAO contractSAO;
    private final ContractViewDTOConverter contractViewDTOConverter;
    private final ContractBrandViewDTOConverter contractBrandViewDTOConverter;
    private final ContractAmountViewDTOConverter contractAmountViewDTOconverter;

    @Override
    public SalesContractViewDTO getSimpleContractInfo(Long contractId) {
        if (contractId == null) {
            return null;
        }
        ContractVersionDTO contractDTO = contractSAO.getSimpleContract(contractId);
        return contractViewDTOConverter.convertDTO2ViewDTO(contractDTO);
    }

    @Override
    public String createChargeUrl(ServiceContext context, SalesContractViewDTO salesContractViewDTO) {
        ContractChargeDTO contractChargeDTO = new ContractChargeDTO();
        contractChargeDTO.setContractId(salesContractViewDTO.getContractId());
        contractChargeDTO.setMemberId(salesContractViewDTO.getMemberId());
        contractChargeDTO.setCashAmount(salesContractViewDTO.getCashAmount());
        contractChargeDTO.setProductId(salesContractViewDTO.getProductId());
        contractChargeDTO.setVersion(salesContractViewDTO.getVersion());
        return contractSAO.createChargeUrl(context, contractChargeDTO);
    }

    @Override
    public List<SalesContractViewDTO> getSimpleContractInfo(List<Long> contractIds) {
        if(CollectionUtils.isEmpty(contractIds)){
            return Lists.newArrayList();
        }
        return contractViewDTOConverter.convertDTO2ViewDTOList(contractSAO.getSimpleContract(contractIds));
    }

    @Override
    public List<SalesContractBrandViewDTO> getContractBrandList(Long contractId){
        if (contractId == null) {
            return Lists.newArrayList();
        }
        CompleteContractBrandDTO contractBrandDTO = contractSAO.getContractBrand(contractId);
        List<CompleteBrandDTO> brandInfo = contractBrandDTO.getBrandInfo();
        return contractBrandViewDTOConverter.convertDTO2ViewDTOList(brandInfo);
    }

    @Override
    public List<SalesContractBrandViewDTO> getContractBrandList(List<Long> contractIds) {
        if(CollectionUtils.isEmpty(contractIds)){
            return Lists.newArrayList();
        }
        List<CompleteContractBrandDTO> contractBrandList = contractSAO.getContractBrand(contractIds);
        List<Long> brandIds = Lists.newArrayList();
        List<SalesContractBrandViewDTO> result = Lists.newArrayList();
        for (CompleteContractBrandDTO contractBrand: contractBrandList){
            for(CompleteBrandDTO brandDTO: contractBrand.getBrandInfo()){
                if(brandIds.contains(brandDTO.getBrandId())){
                    continue;
                }
                brandIds.add(brandDTO.getBrandId());
                result.add(contractBrandViewDTOConverter.convertDTO2ViewDTO(brandDTO));
            }
        }
        return result;
    }

    @Override
    public Map<Long, List<SalesContractBrandViewDTO>> getContractBrandMap(List<Long> contractIds) {
        if(CollectionUtils.isEmpty(contractIds)){
            return Maps.newHashMap();
        }
        Map<Long, List<SalesContractBrandViewDTO>> contractBranMap = Maps.newHashMap();
        List<CompleteContractBrandDTO> contractBrandList = contractSAO.getContractBrand(contractIds);
        List<SalesContractBrandViewDTO> result = Lists.newArrayList();
        for (CompleteContractBrandDTO contractBrand: contractBrandList){
            for(CompleteBrandDTO brandDTO: contractBrand.getBrandInfo()){
                SalesContractBrandViewDTO contractBrandViewDTO = contractBrandViewDTOConverter.convertDTO2ViewDTO(brandDTO);
                if(contractBranMap.containsKey(contractBrand.getContractId())){
                    contractBranMap.get(contractBrand.getContractId()).add(contractBrandViewDTO);
                }else{
                    contractBranMap.put(contractBrand.getContractId(), Lists.newArrayList(contractBrandViewDTO));
                }
            }
        }
        return contractBranMap;
    }
    @Override
    public List<SalesContractBrandViewDTO> findBrandList(Long shopId) {
        List<CompleteBrandDTO> completeBrandDTOList =  contractSAO.findBrandList(shopId);
        if (CollectionUtils.isEmpty(completeBrandDTOList)){
            return Lists.newArrayList();
        }
        return contractBrandViewDTOConverter.convertDTO2ViewDTOList(completeBrandDTOList);
    }

    @Override
    public List<Long> getSubContractIds(Long contractId) {
        return contractSAO.getSubContractIds(contractId);
    }

    @Override
    public List<SalesContractAmountViewDTO> getContractPayments(List<Long> contractIds) {
        if (CollectionUtils.isEmpty(contractIds)){
            return Lists.newArrayList();
        }
        List<ContractBalance> contractBalances = contractSAO.getContractPayments(contractIds);
        return contractAmountViewDTOconverter.convertDTO2ViewDTOList(contractBalances);
    }

    @Override
    public void checkMemberForSelfContract(ServiceContext context, CampaignGroupCustomerMemberViewDTO campaignGroupCustomerMemberViewDTO) {
        ContractMemberInfo memberInfo = contractViewDTOConverter.convertMemberViewDTO(campaignGroupCustomerMemberViewDTO);
        memberInfo.setContractPayType(BrandCampaignGroupContractPayTypeEnum.PRE_PAID.getCode());
        contractSAO.checkMemberInfoForSelfContract(memberInfo);
    }

    @Override
    public boolean checkMemberEnableCredit(ServiceContext context, CampaignGroupCustomerMemberViewDTO campaignGroupCustomerMemberViewDTO) {
        ContractMemberInfo memberInfo = contractViewDTOConverter.convertMemberViewDTO(campaignGroupCustomerMemberViewDTO);
        memberInfo.setContractPayType(BrandCampaignGroupContractPayTypeEnum.POST_PAID.getCode());
        String errorCode = contractSAO.checkMemberInfoForSelfContract(memberInfo);
        return StringUtils.isBlank(errorCode);
    }

    @Override
    public Long createSelfContract(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO) {
        return contractSAO.createContract(campaignGroupViewDTO);
    }

    @Override
    public void addContractCompleteBrand(ServiceContext context, ShopBrandViewDTO shopBrandViewDTO) {
        QabDimShopIdBrandIdDTO shopIdBrandIdDTO = contractBrandViewDTOConverter.convertViewDTO2DTO(shopBrandViewDTO);
        contractSAO.addContractCompleteBrand(shopIdBrandIdDTO);
    }
}
