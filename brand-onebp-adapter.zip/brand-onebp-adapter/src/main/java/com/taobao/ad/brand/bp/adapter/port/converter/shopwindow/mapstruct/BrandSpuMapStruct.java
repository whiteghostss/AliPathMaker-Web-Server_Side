
package com.taobao.ad.brand.bp.adapter.port.converter.shopwindow.mapstruct;

import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSpuViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.perform.client.dto.shopwindow.spu.SpuViewDTO;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * DTO与领域模型实体映射
 * @author ddd-coder-init
 * @date 2020/12/12
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface BrandSpuMapStruct extends BaseMapStructMapper<SpuViewDTO, BrandSpuViewDTO> {

	BrandSpuMapStruct INSTANCE = Mappers.getMapper(BrandSpuMapStruct.class);
}

