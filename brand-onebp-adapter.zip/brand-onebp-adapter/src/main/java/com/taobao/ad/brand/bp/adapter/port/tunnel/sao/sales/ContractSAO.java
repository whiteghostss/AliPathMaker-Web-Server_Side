package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.sales;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.nb.sales.api.contract.ContractCommandService;
import com.alibaba.ad.nb.sales.api.contract.ContractQueryService;
import com.alibaba.ad.nb.sales.api.retail.OneBpRetailService;
import com.alibaba.ad.nb.sales.api.zhubajie.ContractCompleteCommandService;
import com.alibaba.ad.nb.sales.api.zhubajie.ContractCompleteQueryService;
import com.alibaba.ad.nb.sales.dto.contract.ContractBalance;
import com.alibaba.ad.nb.sales.dto.contract.ContractChargeDTO;
import com.alibaba.ad.nb.sales.dto.contract.ContractMemberInfo;
import com.alibaba.ad.nb.sales.dto.zhubajie.CompleteBrandDTO;
import com.alibaba.ad.nb.sales.dto.zhubajie.CompleteContractBrandDTO;
import com.alibaba.ad.nb.sales.dto.zhubajie.QabDimShopIdBrandIdDTO;
import com.alibaba.fastjson.JSON;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.solar.libra.client.dto.ContractSettingDTO;
import com.alibaba.solar.libra.client.dto.ContractVersionDTO;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.overnight.dto.nbcrm.NbContractVersionOrderDTO;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author yanjingang
 * @date 2023/3/16
 */
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ContractSAO extends SalesBaseSAO {

    private final ContractQueryService contractQueryService;
    private final ContractCompleteQueryService contractCompleteQueryService;
    private final ContractCompleteCommandService contractCompleteCommandService;
    private final ContractCommandService contractCommandService;
    private final OneBpRetailService oneBpRetailService;

    private final static String INVALID_AUTHED_COMPANY = "400001";
    private final static String INVALID_CREDIT_STATUS = "400002";

    public ContractVersionDTO getSimpleContract(Long contractId) {
        AssertUtil.notNull(contractId, "合同ID不能为空");
        SingleResponse<ContractVersionDTO> singleResponse = contractQueryService.getSimpleContractById(createNbServiceContext(), contractId);
        AssertUtil.assertTrue(singleResponse.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, singleResponse.getErrorMsg());
        AssertUtil.assertTrue(singleResponse.getResult() != null, BrandOneBPBaseErrorCode.RPC_ERROR, "未查询到合同");
        return singleResponse.getResult();
    }

    public String createChargeUrl(ServiceContext context, ContractChargeDTO contractChargeDTO) {
        SingleResponse<ContractChargeDTO> singleResponse = contractQueryService.createChargeUrl(createNbServiceContext2(context.getMemberId()), contractChargeDTO);
        AssertUtil.assertTrue(singleResponse.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, singleResponse.getErrorMsg());
        AssertUtil.assertTrue(singleResponse.getResult() != null, BrandOneBPBaseErrorCode.RPC_ERROR, "获取支付链接失败");
        return singleResponse.getResult().getChargeUrl();
    }

    public List<ContractVersionDTO> getSimpleContract(List<Long> contractIds) {
        if(CollectionUtils.isEmpty(contractIds)){
            return Lists.newArrayList();
        }
        MultiResponse<ContractVersionDTO> response = contractQueryService.listFullContractByIdList(createNbServiceContext(), contractIds);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, response.getErrorMsg());
        AssertUtil.assertTrue(response.getResult() != null, BrandOneBPBaseErrorCode.RPC_ERROR, "未查询到合同");
        return response.getResult();
    }

    public List<ContractBalance> getContractPayments(List<Long> contractIds) {
        if(CollectionUtils.isEmpty(contractIds)){
            return Lists.newArrayList();
        }
        MultiResponse<ContractBalance> response = contractQueryService.getContractBalance(createNbServiceContext(), contractIds);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, response.getErrorMsg());
        return response.getResult();
    }

    public List<Long> getSubContractIds(Long contractId){
        SingleResponse<ContractVersionDTO> response= contractQueryService.getFullContractById(createNbServiceContext(),contractId);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, response.getErrorMsg());

        ContractVersionDTO contract = response.getResult();
        String ordersInfoJson = contract.getProperty(ContractSettingDTO.ORDERS_INFO_JSON);
        List<NbContractVersionOrderDTO> nbContractVersionOrderDTOS = JSON.parseArray(ordersInfoJson, NbContractVersionOrderDTO.class);
        if (CollectionUtils.isNotEmpty(nbContractVersionOrderDTOS)){
            return nbContractVersionOrderDTOS.stream().map(NbContractVersionOrderDTO::getSubContractId).filter(Objects::nonNull).distinct().collect(Collectors.toList());
        }
        return Lists.newArrayList();
    }
    public CompleteContractBrandDTO getContractBrand(Long contractId) {
        SingleResponse<CompleteContractBrandDTO> singleResponse = contractCompleteQueryService.getContractCompleteInfo(createNbServiceContext2(), contractId);
        AssertUtil.assertTrue(singleResponse.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, singleResponse.getErrorMsg());
        AssertUtil.assertTrue(singleResponse.getResult() != null, BrandOneBPBaseErrorCode.RPC_ERROR, "未查询到合同");
        return singleResponse.getResult();
    }

    public List<CompleteContractBrandDTO> getContractBrand(List<Long> contractIds) {
        MultiResponse<CompleteContractBrandDTO> multiResponse = contractCompleteQueryService.getContractCompleteInfo(createNbServiceContext2(), contractIds);
        AssertUtil.assertTrue(multiResponse.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, multiResponse.getErrorMsg());
        AssertUtil.assertTrue(multiResponse.getResult() != null, BrandOneBPBaseErrorCode.RPC_ERROR, "未查询到合同");
        return multiResponse.getResult();
    }
    public List<CompleteBrandDTO> findBrandList(Long shopId) {
        MultiResponse<CompleteBrandDTO> response = contractCompleteQueryService.findBrandList(createNbServiceContext2(), Lists.newArrayList(shopId));
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, response.getErrorMsg());
        AssertUtil.assertTrue(response.getResult() != null, BrandOneBPBaseErrorCode.RPC_ERROR, "未查询到品牌");
        return response.getResult();
    }

    public String checkMemberInfoForSelfContract(ContractMemberInfo memberInfo) {
        SingleResponse<Boolean> response = contractCommandService.checkMemberInfo4RetailContract(createNbServiceContext2(), memberInfo);
        if (!response.isSuccess()) {
            if (!INVALID_CREDIT_STATUS.equals(response.getErrorCode())) {
                throw new BrandOneBPException(BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR.of(response.getErrorMsg()));
            }
            return response.getErrorCode();
        }
        return StringUtils.EMPTY;
    }

    public Long createContract(CampaignGroupViewDTO campaignGroupViewDTO) {
        SingleResponse<Long> response = oneBpRetailService.syncCreateAndSignContract(MM_SALES_BIZ_CODE, campaignGroupViewDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, response.getErrorMsg());
        AssertUtil.assertTrue(response.getResult() != null, BrandOneBPBaseErrorCode.RPC_ERROR, "创建合同失败");
        return response.getResult();
    }

    /**
     * 添加合同结案账号关联的品牌
     * @param shopIdBrandIdDTO
     */
    public void addContractCompleteBrand(QabDimShopIdBrandIdDTO shopIdBrandIdDTO){
        Response response = contractCompleteCommandService.addBrand(shopIdBrandIdDTO);
        if(!response.isSuccess()){
            RogerLogger.info("contract-brand add error，reason={}",response.getErrorMsg());
        }
    }
}
