package com.taobao.ad.brand.bp.adapter.port.repository.report;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.dto.report.ReportAreaViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.query.ReportAreaQueryViewDTO;
import com.taobao.ad.brand.bp.common.constant.ReportAreaConstant;
import com.taobao.ad.brand.bp.domain.adr.ReportCenterRepository;
import com.taobao.ad.brand.bp.domain.report.repository.ReportAreaRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;


/**
 * 报表获取省市信息
 */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ReportAreaRepositoryImpl implements ReportAreaRepository {

    @Resource
    private ReportCenterRepository reportCenterRepository;

    @Override
    public List<ReportAreaViewDTO> queryReportAreaList(ServiceContext context, ReportAreaQueryViewDTO queryViewDTO) {

        Map<String, Object> queryParams = Maps.newHashMap();
        queryParams.put(ReportAreaConstant.ADR_UNIQUE_KEY, ReportAreaConstant.PROVINCE_CITY_TRANSFER_API);

        if (CollectionUtils.isNotEmpty(queryViewDTO.getCountryIdList())) {
            queryParams.put(ReportAreaConstant.COUNTRY_ID_IN, queryViewDTO.getCountryIdList());
        } else if (CollectionUtils.isNotEmpty(queryViewDTO.getProvinceIdList())) {
            queryParams.put(ReportAreaConstant.PROVINCE_ID_IN, queryViewDTO.getProvinceIdList());
        } else if (CollectionUtils.isNotEmpty(queryViewDTO.getCityIdList())) {
            queryParams.put(ReportAreaConstant.CITY_ID_IN, queryViewDTO.getCityIdList());
        }

        List<Map<String, Object>> areaInfoList = reportCenterRepository.findData(queryParams);

        if (org.apache.commons.collections.CollectionUtils.isEmpty(areaInfoList)) {
            return Lists.newArrayList();
        }
        return JSON.parseArray(JSON.toJSONString(areaInfoList), ReportAreaViewDTO.class);
    }
}
