package com.taobao.ad.brand.bp.adapter.port.converter.adc.mapstruct;

import com.alibaba.ad.nb.framework.adc.dto.AdcCdnDTO;
import com.taobao.ad.brand.bp.client.dto.adc.AdcCdnViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface AdcCdnViewDTOMapStruct extends BaseMapStructMapper<AdcCdnDTO, AdcCdnViewDTO> {

    AdcCdnViewDTOMapStruct INSTANCE = Mappers.getMapper(AdcCdnViewDTOMapStruct.class);

}
