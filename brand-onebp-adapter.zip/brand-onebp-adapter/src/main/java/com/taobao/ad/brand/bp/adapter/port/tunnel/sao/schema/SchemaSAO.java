package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.schema;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.nb.crm.api.schema.SchemaInfoQueryService;
import com.alibaba.ad.nb.crm.dto.schema.SchemaInfoDTO;
import com.alibaba.ad.nb.crm.dto.schema.SchemaInfoQueryDTO;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/4/14 16:19
 * @description ：
 * @modified By：
 */
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SchemaSAO extends BaseSAO {

    private final SchemaInfoQueryService schemaInfoQueryService;

    public SchemaInfoDTO getSchemaById(ServiceContext serviceContext, Long id) {
        com.alibaba.ad.nb.crm.context.ServiceContext context = new com.alibaba.ad.nb.crm.context.ServiceContext();
        SchemaInfoQueryDTO schemaInfoQueryDTO = new SchemaInfoQueryDTO();
        schemaInfoQueryDTO.setId(id);
        SingleResponse<SchemaInfoDTO> response = schemaInfoQueryService.detail(context, schemaInfoQueryDTO);
        AssertUtil.assertTrue(response);
        return response.getResult();
    }
}
