package com.taobao.ad.brand.bp.adapter.port.converter.account.agreement.mapstruct;

import com.alibaba.legal.agreement.dto.AgreementSignResultDto;
import com.taobao.ad.brand.bp.client.dto.account.agreement.AgreementSignResultViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;

import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author 虫洞 <liuming.liu@alibaba-inc.com>
 * @date 2023/4/4
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface AgreementMapStruct extends BaseMapStructMapper<AgreementSignResultDto, AgreementSignResultViewDTO> {
    AgreementMapStruct INSTANCE = Mappers.getMapper(AgreementMapStruct.class);
}