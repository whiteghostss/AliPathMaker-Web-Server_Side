package com.taobao.ad.brand.bp.adapter.port.repository.dmp;

import com.alibaba.abf.governance.context.ServiceContext;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.adapter.port.converter.dmp.CrowdViewDTOConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.dmp.CrowdSAO;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.CrowdViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.query.CrowdQueryViewDTO;
import com.taobao.ad.brand.bp.domain.dmp.CrowdRepository;
import com.taobao.ad.dmp.client.dto.CrowdDTO;
import com.taobao.ad.dmp.client.dto.ResultDTO;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 人群相关服务
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CrowdRepositoryImpl implements CrowdRepository {
    private final CrowdSAO crowdSAO;
    private final CrowdViewDTOConverter crowdViewDTOConverter;
    private final static int MAX_PAGE_COUNT = 200;

    @Override
    public PageResultViewDTO<CrowdViewDTO> findCrowdPageList(ServiceContext context, CrowdQueryViewDTO queryViewDTO) {
        ResultDTO<List<CrowdDTO>> crowdDTOResult = crowdSAO.findCrowdPageList(context, queryViewDTO);
        return PageResultViewDTO.of(crowdViewDTOConverter.convertDTO2ViewDTOList(crowdDTOResult.getResult()), crowdDTOResult.getPager().getTotal());
    }

    @Override
    public List<CrowdViewDTO> queryCrowdByIds(ServiceContext context, List<Long> crowdIds) {
        if(CollectionUtils.isEmpty(crowdIds)){
            return Lists.newArrayList();
        }
        List<CrowdDTO> crowdDTOS = crowdSAO.queryCrowdList(context, crowdIds);
        return crowdViewDTOConverter.convertDTO2ViewDTOList(crowdDTOS);
    }

    @Override
    public Long getCrowdCoverage(ServiceContext context, List<Long> crowdIds) {
       return  crowdSAO.getCrowdCoverage(context,crowdIds);
    }

    @Override
    public Long increaseCalculate(ServiceContext serviceContext, List<Long> newCrowdIdList, List<Long> oldCrowdIdList) {
        return crowdSAO.increaseCalculate(serviceContext, newCrowdIdList, oldCrowdIdList);
    }

    @Override
    public List<CommonViewDTO> queryShowmaxCrowdTagList(ServiceContext serviceContext, Long memberId, Integer showmaxCrowdType) {
        return crowdSAO.queryShowmaxCrowdTagList(serviceContext, memberId, showmaxCrowdType);
    }

    @Override
    public List<CrowdViewDTO> findRecommendCrowd(ServiceContext serviceContext,Long memberId, Integer showmaxType, String labelIdList,String brandIds) {
        return crowdViewDTOConverter.convertDTO2ViewDTOList(crowdSAO.findRecommendCrowd(serviceContext, memberId, showmaxType, labelIdList, brandIds));
    }

    @Override
    public PageResultViewDTO<CrowdViewDTO> findCreativePreviewCrowdPageList(ServiceContext context, CrowdQueryViewDTO queryViewDTO) {
        ResultDTO<List<CrowdDTO>> crowdDTOResult = crowdSAO.findCreativePreviewCrowdPageList(context, queryViewDTO);
        return PageResultViewDTO.of(crowdViewDTOConverter.convertDTO2ViewDTOList(crowdDTOResult.getResult()), crowdDTOResult.getPager().getTotal());    }
}
