package com.taobao.ad.brand.bp.adapter.port.repository.uic;

import com.alibaba.ad.nb.order.dto.common.EmpDTO;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.uic.SimbaUicSAO;
import com.taobao.ad.brand.bp.domain.uic.SimbaUicRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
@RequiredArgsConstructor(onConstructor_ = @Autowired)
public class SimbaUicRepositoryImpl implements SimbaUicRepository {

    private final SimbaUicSAO simbaUicSAO;

    @Override
    public EmpDTO getEmp(String empId) {
        return simbaUicSAO.getEmp(empId);
    }

    @Override
    public Map<String, EmpDTO> getEmp(List<String> empIds) {
        return simbaUicSAO.getEmp(Sets.newHashSet(empIds));
    }

    public Map<String, String> getEmpEmails(List<String> empIds) {
        return simbaUicSAO.getEmpEmails(Sets.newHashSet(empIds));
    }

    @Override
    public EmpDTO getEmpByBucUserId(Long bucUserId) {
        return simbaUicSAO.getEmpByBucUserId(bucUserId);
    }
}
