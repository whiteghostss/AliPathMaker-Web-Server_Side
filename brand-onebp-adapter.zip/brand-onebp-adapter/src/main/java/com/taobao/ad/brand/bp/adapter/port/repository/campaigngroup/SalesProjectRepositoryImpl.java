package com.taobao.ad.brand.bp.adapter.port.repository.campaigngroup;

import com.alibaba.ad.nb.sales.dto.project.ProjectDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.sales.ProjectViewDTOConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.sales.ProjectSAO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesProjectViewDTO;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.SalesProjectRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collections;
import java.util.List;


@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SalesProjectRepositoryImpl implements SalesProjectRepository {

    private final ProjectSAO projectSAO;
    private final ProjectViewDTOConverter projectViewDTOConverter;

    @Override
    public List<SalesProjectViewDTO> findSimpleProjectByIds(List<Long> ids) {
        if (CollectionUtils.isEmpty(ids)) {
            return Collections.emptyList();
        }
        List<ProjectDTO> projectDTOS = projectSAO.findSimpleProjectByIds(ids);
        return projectViewDTOConverter.convertDTO2ViewDTOList(projectDTOS);
    }
}
