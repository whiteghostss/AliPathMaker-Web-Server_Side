package com.taobao.ad.brand.bp.adapter.port.converter.report;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.nb.direct.client.constant.common.CommonEnum;
import com.alibaba.ad.nb.task.client.constant.async.*;
import com.alibaba.ad.nb.task.client.dto.async.AsyncTaskDTO;
import com.alibaba.ad.nb.task.client.dto.async.AsyncTaskParamDTO;
import com.alibaba.ad.nb.task.client.dto.async.AsyncTaskResultDTO;
import com.alibaba.ad.nb.task.client.dto.async.BrandReportTaskParamDTO;
import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.adapter.port.converter.report.mapstruct.ReportTaskViewDTOMapStruct;
import com.taobao.ad.brand.bp.client.dto.report.ReportFileViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportTaskViewDTO;
import com.taobao.ad.brand.bp.common.constant.AdcRoleConstant;
import com.taobao.ad.brand.bp.common.constant.CampaignConstant;
import com.taobao.ad.brand.bp.common.constant.ReportConstant;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@Component
public class ReportTaskViewDTOConverter extends BaseViewDTOConverter<AsyncTaskDTO, ReportTaskViewDTO> {

    @Override
    public BaseMapStructMapper<AsyncTaskDTO, ReportTaskViewDTO> getBaseMapStructMapper() {
        return ReportTaskViewDTOMapStruct.INSTANCE;
    }

    public List<ReportTaskViewDTO> convertDTO2ViewDTOList(ServiceContext context, List<AsyncTaskDTO> dtos) {
        if(CollectionUtils.isEmpty(dtos)){
            return Lists.newArrayList();
        }
        List<ReportTaskViewDTO> result = Lists.newArrayList();
        dtos.forEach(dto-> result.add(convertDTO2ViewDTO(context, dto)));
        return result;
    }

    public ReportTaskViewDTO convertDTO2ViewDTO(ServiceContext context, AsyncTaskDTO dto) {
        if ( dto == null ) {
            return null;
        }

        ReportTaskViewDTO reportTaskViewDTO = getBaseMapStructMapper().sourceToTarget(dto);

        reportTaskViewDTO.setTaskId(dto.getId());
        reportTaskViewDTO.setTaskName(dto.getName());
        reportTaskViewDTO.setFunctionCode(parse2FunctionCode(dto.getType()));
        reportTaskViewDTO.setMemberId(dto.getBizId());
        reportTaskViewDTO.setCampaignGroupId(dto.getSubBizId());
        reportTaskViewDTO.setTaskParams(parse2TaskParams(dto.getParams()));
        reportTaskViewDTO.setStatusName(parse2StatusName(dto.getStatus()));
        reportTaskViewDTO.setOssUrl(parse2OssUrl(dto.getResult()));
        reportTaskViewDTO.setLastCalDate(dto.getLastCalTime());
        reportTaskViewDTO.setDimensionCodes(parse2DimensionCodes(dto.getParams()));
        reportTaskViewDTO.setFileViewDTO(parse2FileViewDTO(dto.getParams()));
        reportTaskViewDTO.setBizCode(parse2BizCode(dto.getParams()));
        return reportTaskViewDTO;
    }

    public AsyncTaskDTO convertViewDTO2DTO(ServiceContext context, ReportTaskViewDTO viewDTO) {
        if ( viewDTO == null ) {
            return null;
        }

        AsyncTaskDTO asyncTaskDTO = getBaseMapStructMapper().targetToSource(viewDTO);

        asyncTaskDTO.setId(viewDTO.getTaskId());
        asyncTaskDTO.setBizId(viewDTO.getMemberId());
        asyncTaskDTO.setSubBizId(viewDTO.getCampaignGroupId());
        asyncTaskDTO.setName(viewDTO.getTaskName());
        asyncTaskDTO.setType(parse2Type(viewDTO.getFunctionCode()));
        asyncTaskDTO.setParams(parse2Params(context, viewDTO.getTaskParams(), viewDTO));
        asyncTaskDTO.setResult(parse2Result(viewDTO.getOssUrl(), viewDTO.getData()));
        asyncTaskDTO.setLastCalTime(viewDTO.getLastCalDate());
        asyncTaskDTO.setStatus(viewDTO.getStatus());
        asyncTaskDTO.setErrorMsg(viewDTO.getErrorMsg());
        asyncTaskDTO.setTraceId(viewDTO.getTraceId());
        asyncTaskDTO.setCreateBy(viewDTO.getCreateBy());
        asyncTaskDTO.setLastModifyBy(viewDTO.getLastModifyBy());
        asyncTaskDTO.setGmtCreate(viewDTO.getGmtCreate());
        asyncTaskDTO.setGmtModified(viewDTO.getGmtModified());
        asyncTaskDTO.setAbilityCode( BizCodeEnum.BRANDAD.getBizCode() );
        asyncTaskDTO.setBizType( AsyncTaskBizTypeEnum.MEMBER.getValue() );
//        asyncTaskDTO.setSubBizType( AsyncTaskSubBizTypeEnum.BRAND_ONE_BP_CAMPAIGN_GROUP.getValue() );

        return asyncTaskDTO;
    }

    private Integer parse2Type(String functionCode){
        if(StringUtils.isBlank(functionCode)){
            return null;
        }
        switch (functionCode) {
            case "mRptMultiCustom":
                return AsyncTaskTypeEnum.BRAND_ONE_BP_MULTI_REPORT.getValue();
            case "mRptMultiPromotion":
                return AsyncTaskTypeEnum.BRAND_ONE_BP_PROMOTION_REPORT.getValue();
            case "mRptMultiLive":
                return AsyncTaskTypeEnum.BRAND_ONE_BP_LIVE_REPORT.getValue();
            case "campaignBatchInsert":
                return AsyncTaskTypeEnum.BRAND_ONE_BP_CAMPAIGN_BATCH_INSERT.getValue();
            case "batchImportCampaignBookingAmount":
                return AsyncTaskTypeEnum.BRAND_ONE_BP_CAMPAIGN_BOOKING_AMOUNT_BATCH_UPDATE.getValue();
            case "adgroupBatchMonitorUpdate":
                return AsyncTaskTypeEnum.BRAND_ONE_BP_ADGROUP_MONITOR_BATCH_UPDATE.getValue();
            case "contentMediaPush":
                return AsyncTaskTypeEnum.BRAND_ONE_BP_CONTENT_REPORT.getValue();
            case "mRptMultiCommon":
                return AsyncTaskTypeEnum.BRAND_ONE_BP_COMMON_REPORT.getValue();
            case "creativeBatchUpdate":
                return AsyncTaskTypeEnum.BRAND_ONE_BP_CREATIVE_BATCH_UPDATE.getValue();
            default:
                return null;
        }
    }

    private String parse2FunctionCode(Integer type){
        if(Objects.isNull(type)){
            return null;
        }
        AsyncTaskTypeEnum typeEnum = CommonEnum.of(type, AsyncTaskTypeEnum.class);
        switch (typeEnum) {
            case BRAND_ONE_BP_MULTI_REPORT:
                return "mRptMultiCustom";
            case BRAND_ONE_BP_PROMOTION_REPORT:
                return "mRptMultiPromotion";
            case BRAND_ONE_BP_LIVE_REPORT:
                return "mRptMultiLive";
            case BRAND_ONE_BP_CAMPAIGN_BATCH_INSERT:
                return "campaignBatchInsert";
            case BRAND_ONE_BP_CAMPAIGN_BOOKING_AMOUNT_BATCH_UPDATE:
                return "batchImportCampaignBookingAmount";
            case BRAND_ONE_BP_ADGROUP_MONITOR_BATCH_UPDATE:
                return "adgroupBatchMonitorUpdate";
            case BRAND_ONE_BP_CONTENT_REPORT:
                return "contentMediaPush";
            case BRAND_ONE_BP_COMMON_REPORT:
                return "mRptMultiCommon";
            case BRAND_ONE_BP_CREATIVE_BATCH_UPDATE:
                return "creativeBatchUpdate";
            default:
                return null;
        }
    }

    private BrandReportTaskParamDTO parse2Params(ServiceContext context, Map<String, Object> params, ReportTaskViewDTO viewDTO){
        BrandReportTaskParamDTO paramDTO = new BrandReportTaskParamDTO();
        params.remove("fileViewDTO");
        params.put("fileViewDTO", viewDTO.getFileViewDTO());
        //小二和商家异步任务隔离
        params.put("innerWaiter", context.getRoleNameList().contains(AdcRoleConstant.INNER_WAITER_ADC_ROLE)? BrandBoolEnum.BRAND_TRUE.getCode(): BrandBoolEnum.BRAND_FALSE.getCode());
        paramDTO.setParams(params);
        return paramDTO;
    }

    private Map<String, Object> parse2TaskParams(AsyncTaskParamDTO params){
        BrandReportTaskParamDTO taskParamDTO = null;
        if(params instanceof BrandReportTaskParamDTO){
            taskParamDTO = (BrandReportTaskParamDTO)params;
        }
        if(Objects.isNull(taskParamDTO)){
            return Maps.newHashMap();
        }
        return taskParamDTO.getParams();
    }

    private String parse2BizCode(AsyncTaskParamDTO params){
        String key = "bizCode";
        BrandReportTaskParamDTO taskParamDTO = null;
        if(params instanceof BrandReportTaskParamDTO){
            taskParamDTO = (BrandReportTaskParamDTO)params;
        }
        if(Objects.isNull(taskParamDTO) || !taskParamDTO.getParams().containsKey(key)){
            return "";
        }
        return taskParamDTO.getParams().get(key).toString();
    }

    private List<String> parse2DimensionCodes(AsyncTaskParamDTO params){
        String key = "dimensionCodes";
        BrandReportTaskParamDTO taskParamDTO = null;
        if(params instanceof BrandReportTaskParamDTO){
            taskParamDTO = (BrandReportTaskParamDTO)params;
        }
        if(Objects.isNull(taskParamDTO) || !taskParamDTO.getParams().containsKey(key)){
            return Lists.newArrayList();
        }
        return JSON.parseArray(taskParamDTO.getParams().get(key).toString(), String.class);
    }

    private ReportFileViewDTO parse2FileViewDTO(AsyncTaskParamDTO params){
        String key = "fileViewDTO";
        BrandReportTaskParamDTO taskParamDTO = null;
        if(params instanceof BrandReportTaskParamDTO){
            taskParamDTO = (BrandReportTaskParamDTO)params;
        }
        if(Objects.isNull(taskParamDTO) || !taskParamDTO.getParams().containsKey(key)){
            return null;
        }
        return JSON.parseObject(taskParamDTO.getParams().get(key).toString(), ReportFileViewDTO.class);
    }

    private String parse2StatusName(Integer status){
        if(Objects.isNull(status)){
            return null;
        }
        AsyncTaskStatusEnum statusEnum = CommonEnum.of(status, AsyncTaskStatusEnum.class);
        return statusEnum.getDesc();
    }

    private String parse2OssUrl(AsyncTaskResultDTO result){
        return result.getUrl();
    }

    private AsyncTaskResultDTO parse2Result(String ossUrl, String data){
        AsyncTaskResultDTO dto = new AsyncTaskResultDTO();
        if(Objects.nonNull(ossUrl)){
            dto.setUrl(ossUrl);
            dto.setType(AsyncTaskResultTypeEnum.URL.getValue());
        }else if(Objects.nonNull(data)){
            dto.setData(data);
            dto.setType(AsyncTaskResultTypeEnum.JSON_DATA.getValue());
        }
        return dto;
    }

}
