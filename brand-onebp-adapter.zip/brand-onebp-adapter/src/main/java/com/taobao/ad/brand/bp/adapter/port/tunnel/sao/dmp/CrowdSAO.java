package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.dmp;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.query.CrowdQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.BizKeywordTypeEnum;
import com.taobao.ad.brand.bp.client.enums.campaign.RecommendCrowdTypeEnum;
import com.taobao.ad.brand.bp.common.constant.DmpConstant;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.dmp.client.dto.AppContextDTO;
import com.taobao.ad.dmp.client.dto.CrowdDTO;
import com.taobao.ad.dmp.client.dto.RecommendCrowdDTO;
import com.taobao.ad.dmp.client.dto.ResultDTO;
import com.taobao.ad.dmp.client.dto.TagOptionDTO;
import com.taobao.ad.dmp.client.dto.TemplateContextDTO;
import com.taobao.ad.dmp.client.dto.query.CrowdQueryDTO;
import com.taobao.ad.dmp.client.dto.query.Pager;
import com.taobao.ad.dmp.client.dto.query.TagOptionQuery;
import com.taobao.ad.dmp.client.sdk2.AnalysisService;
import com.taobao.ad.dmp.client.sdk2.CrowdService;
import com.taobao.ad.dmp.client.sdk2.CrowdTemplateService;
import com.taobao.ad.dmp.client.sdk2.TagService;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * 人群相关服务
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CrowdSAO {
    private final CrowdService crowdService;

    private final AnalysisService analysisService;

    private final TagService tagService;

    private final CrowdTemplateService crowdTemplateService;

    /**
     * 查询人群信息（白盒人群统一）
     * @param serviceContext
     * @param crowdIds
     * @return
     */
    public List<CrowdDTO> queryCrowdList(ServiceContext serviceContext, List<Long> crowdIds) {
        if (CollectionUtils.isEmpty(crowdIds)) {
            return Lists.newArrayList();
        }
        AppContextDTO context = initDmpContext(serviceContext.getMemberId(),DmpConstant.APP_ID_NEW);
        CrowdQueryDTO crowdQueryDTO = initCrowdNewQueryDTO(crowdIds);
        ResultDTO<List<CrowdDTO>> crowdResult = crowdService.query(context, crowdQueryDTO);
        AssertUtil.assertTrue(crowdResult != null && crowdResult.isSuccess(), "调用dmp接口失败");
        return crowdResult.getResult();
    }

    private CrowdQueryDTO initCrowdNewQueryDTO(List<Long> crowdIds) {
        CrowdQueryDTO queryDTO = new CrowdQueryDTO();
        crowdIds = crowdIds.stream().distinct().collect(Collectors.toList());
        queryDTO.setCrowdIdList(crowdIds);

        Map<String, Object> queryExt = new HashMap<>();
        queryExt.put("requireQueryCrowdExtra", true);
        queryExt.put("requireQueryCrowdXApp", true);
        //过滤掉黑盒人群
        queryExt.put("requireQueryDspSubCrowd", false);
        queryDTO.setQueryExt(queryExt);
        return queryDTO;
    }

    /**
     * 查询人群信息
     * @param queryViewDTO
     * @return
     */
    public ResultDTO<List<CrowdDTO>> findCrowdPageList(ServiceContext serviceContext, CrowdQueryViewDTO queryViewDTO){
        AppContextDTO context = initDmpContext(serviceContext.getMemberId(),DmpConstant.APP_ID);
        CrowdQueryDTO crowdQueryDTO = initCrowdQueryDTO(queryViewDTO);
        Pager pager = initPager(queryViewDTO);
        ResultDTO<List<CrowdDTO>> crowdResult = crowdService.find(context, crowdQueryDTO, pager);
        AssertUtil.assertTrue(crowdResult != null && crowdResult.isSuccess(), "调用dmp接口失败");
        return crowdResult;
    }

    /**
     * 查询人群覆盖数
     * @param serviceContext
     * @param crowdIds
     * @return
     */
    public Long getCrowdCoverage(ServiceContext serviceContext, List<Long> crowdIds) {
        if (CollectionUtils.isEmpty(crowdIds)){
            return 0L;
        }
        AppContextDTO appContextDTO = initDmpContext(serviceContext.getMemberId(), DmpConstant.APP_ID_NEW);
        return analysisService.countCrowds(appContextDTO, crowdIds).getResult();
    }

    private AppContextDTO initDmpContext(Long memberId, Long appId){
        AssertUtil.notNull(memberId, "memberId不能为空");
        AppContextDTO contextDTO = new AppContextDTO();
        contextDTO.setAppId(appId);
        contextDTO.setMemberId(memberId);
        return contextDTO;
    }

    private Pager initPager(CrowdQueryViewDTO queryViewDTO){
        //分页大小不能超过200
        return new Pager(queryViewDTO.getPageNo(), queryViewDTO.getPageSize());
    }

    /**
     * 过期失效:2,
     * 同步中:11,
     * 已同步:12,
     * 正常状态：10（等于11+12）
     */
    private CrowdQueryDTO initCrowdQueryDTO(CrowdQueryViewDTO queryViewDTO){
        CrowdQueryDTO queryDTO = new CrowdQueryDTO();
        if(Objects.isNull(queryViewDTO.getIncludeExpire()) || BrandBoolEnum.BRAND_FALSE.getCode().equals(queryViewDTO.getIncludeExpire())) {
            queryDTO.setDeliverAppId(DmpConstant.DELIVER_APP_ID_BRAND_DMP);
        }
        BizKeywordTypeEnum keywordTypeEnum = BizKeywordTypeEnum.getByName(queryViewDTO.getKeywordType());
        //过期失效:2,同步中:11,已同步:12,正常状态：10（等于11+12）
        if(Objects.nonNull(queryViewDTO.getPullStatus())) {
            queryDTO.setQueryStatus(queryViewDTO.getPullStatus());
        }
        if(Objects.nonNull(queryViewDTO.getBusinessType())) {
            queryDTO.setBusinessTypeList(Lists.newArrayList(queryViewDTO.getBusinessType()));
        }
        if(CollectionUtils.isNotEmpty(queryViewDTO.getBusinessTypes())) {
            queryDTO.setBusinessTypeList(queryViewDTO.getBusinessTypes());
        }
//        if(Objects.isNull(queryViewDTO.getBusinessType()) && CollectionUtils.isEmpty(queryViewDTO.getBusinessTypes())){
//            queryDTO.setBusinessTypeList(Arrays.stream(BusinessTypeEnum.values()).map(m->m.getValue()).collect(Collectors.toList()));
//        }
        // 人群id
        List<Long> crowdIds = new ArrayList<>();
        if (BizKeywordTypeEnum.CROWD_ID == keywordTypeEnum && StringUtils.isNotBlank(queryViewDTO.getKeyword())) {
            // 人群id输入用英文逗号,隔开，可批量搜索
            String[] keywords = queryViewDTO.getKeyword().split(",");
            if (keywords != null && keywords.length != 0){
                for (int i = 0; i < keywords.length; i++){
                    AssertUtil.assertTrue(StringUtils.isNumeric(keywords[i]), "id搜索需要填写数字");
                    crowdIds.add(Long.parseLong(keywords[i]));
                }
            }
        }
        if(CollectionUtils.isNotEmpty(queryViewDTO.getCrowdIds())){
            crowdIds.addAll(queryViewDTO.getCrowdIds());
        }
        if (Objects.nonNull(queryViewDTO.getCrowdId())) {
            crowdIds.add(queryViewDTO.getCrowdId());
        }
        if (CollectionUtils.isNotEmpty(crowdIds)) {
            queryDTO.setCrowdIdList(crowdIds);
        }
        // 人群名称
        if(BizKeywordTypeEnum.CROWD_NAME == keywordTypeEnum && StringUtils.isNotBlank(queryViewDTO.getKeyword())) {
            queryDTO.setCrowdName(queryViewDTO.getKeyword());
        }
        return queryDTO;
    }

    public Long increaseCalculate(ServiceContext serviceContext, List<Long> newCrowdIdList, List<Long> oldCrowdIdList) {
        AppContextDTO appContextDTO = initDmpContext(serviceContext.getMemberId(), DmpConstant.APP_ID_NEW);
        return analysisService.increaseCalculate(appContextDTO, newCrowdIdList, oldCrowdIdList).getResult();
    }

    public List<CommonViewDTO> queryShowmaxCrowdTagList(ServiceContext serviceContext, Long memberId, Integer showmaxCrowdType) {
        List<TagOptionDTO> tagOptionList = Lists.newArrayList();
        Pager pager = new Pager();
        pager.setPage(1);
        pager.setPageSize(50000);
        if (RecommendCrowdTypeEnum.CATEGORY.getCode().equals(showmaxCrowdType) || RecommendCrowdTypeEnum.CATEGORY_ADDITION.getCode().equals(showmaxCrowdType)) {
            //行业
            AppContextDTO appContextDTO = new AppContextDTO();
            //获取全量类目
            appContextDTO.setMemberId(memberId);
            appContextDTO.setAppId(DmpConstant.BRAND_HUB_DMP_APP_ID);
            TagOptionQuery tagQuery =  new TagOptionQuery();
            tagQuery.setTagId(DmpConstant.CATEGORY_TAG_ID);
            tagQuery.setTagOptionGroupId(DmpConstant.CATEGORY_OPTION_GROUP_ID);
            tagOptionList = tagService.findOptions(appContextDTO, tagQuery, pager).getResult();
            if (CollectionUtils.isEmpty(tagOptionList)) {
                return Lists.newArrayList();
            }
            //一级行业
            tagOptionList = tagOptionList.stream().filter(tagOptionDTO -> tagOptionDTO.getParentOptionId().equals(0L)).collect(Collectors.toList());
        } else if (RecommendCrowdTypeEnum.BRAND.getCode().equals(showmaxCrowdType) || RecommendCrowdTypeEnum.BRAND_ADDITION.getCode().equals(showmaxCrowdType)) {
            //品牌
            AppContextDTO appContextDTO = new AppContextDTO();
            appContextDTO.setMemberId(memberId);
            appContextDTO.setAppId(DmpConstant.BRAND_HUB_DMP_APP_ID);
            TagOptionQuery tagQuery =  new TagOptionQuery();
            tagQuery.setTagId(DmpConstant.BRAND_TAG_ID);
            tagQuery.setTagOptionGroupId(DmpConstant.BRAND_OPTION_GROUP_ID);
            tagOptionList = tagService.findOptions(appContextDTO, tagQuery, pager).getResult();
            if (CollectionUtils.isEmpty(tagOptionList)) {
                return Lists.newArrayList();
            }
        }

        return tagOptionList.stream()
                .map(tagOptionDTO -> {
                    CommonViewDTO common = new CommonViewDTO();
                    common.setId(Long.valueOf(tagOptionDTO.getOptionValue()));
                    common.setName(tagOptionDTO.getOptionName());
                    return common;
                }).collect(Collectors.toList());
    }

    public List<CrowdDTO> findRecommendCrowd(ServiceContext serviceContext, Long memberId, Integer showmaxType, String labelIdList, String brandIds) {
        AppContextDTO appContextDTO = initDmpContext(memberId, DmpConstant.RECOMMEND_APP_ID);
        appContextDTO.setAppId(DmpConstant.RECOMMEND_APP_ID);
        TemplateContextDTO templateContextDTO = new TemplateContextDTO();
        Map<String, String> contextParams = new HashMap<>();
        contextParams.put("skip_template_coverage_limit", "true");
        contextParams.put("need_coverage", "true");
        if (RecommendCrowdTypeEnum.CATEGORY.getCode().equals(showmaxType) || RecommendCrowdTypeEnum.CATEGORY_ADDITION.getCode().equals(showmaxType)) {
            contextParams.put("cateLv1Ids", labelIdList);
            contextParams.put("cateLv1Name", "行业精选人群");
        } else if (RecommendCrowdTypeEnum.BRAND.getCode().equals(showmaxType) || RecommendCrowdTypeEnum.BRAND_ADDITION.getCode().equals(showmaxType)) {
            contextParams.put("brandValue", labelIdList);
            contextParams.put("brandName", "品牌精选人群");
        } else if (RecommendCrowdTypeEnum.GLOBAL.getCode().equals(showmaxType) || RecommendCrowdTypeEnum.MEMBER.getCode().equals(showmaxType)) {
            contextParams.put("brandValue", brandIds);
            contextParams.put("brandName", "全域追投人群");
        } else if (RecommendCrowdTypeEnum.SCENE_CUSTOMIZE.getCode().equals(showmaxType)) {
            contextParams.put("need_template_info", "true");
        } else if (RecommendCrowdTypeEnum.RECOMMEND.getCode().equals(showmaxType) || RecommendCrowdTypeEnum.SCENE_RECOMMEND.getCode().equals(showmaxType)) {
            contextParams.put("need_brand_fill", "true");
        }
        templateContextDTO.setContextParams(contextParams);
        templateContextDTO.setTopicId(RecommendCrowdTypeEnum.getRecommendCrowdTypeEnum(showmaxType).getTopicId());
        ResultDTO<RecommendCrowdDTO> resultDTO = crowdTemplateService.findRecommendCrowd(appContextDTO, templateContextDTO);
        if (resultDTO != null && resultDTO.isSuccess() && resultDTO.getResult() != null && CollectionUtils.isNotEmpty(resultDTO.getResult().getCrowdList())) {
            return resultDTO.getResult().getCrowdList();
        }
        return new ArrayList<>();
    }

    public ResultDTO<List<CrowdDTO>> findCreativePreviewCrowdPageList(ServiceContext serviceContext, CrowdQueryViewDTO queryViewDTO){
        AppContextDTO context = initDmpContext(serviceContext.getMemberId(),DmpConstant.APP_ID);
        CrowdQueryDTO crowdQueryDTO = initCrowdQueryDTO(queryViewDTO);
        crowdQueryDTO.setDeliverAppId(DmpConstant.CREATIVE_PREVIEW_DMP_MASK_APP_ID);
        Pager pager = initPager(queryViewDTO);
        ResultDTO<List<CrowdDTO>> crowdResult = crowdService.find(context, crowdQueryDTO, pager);
        AssertUtil.assertTrue(crowdResult != null && crowdResult.isSuccess(), "调用dmp接口失败");
        return crowdResult;
    }
}
