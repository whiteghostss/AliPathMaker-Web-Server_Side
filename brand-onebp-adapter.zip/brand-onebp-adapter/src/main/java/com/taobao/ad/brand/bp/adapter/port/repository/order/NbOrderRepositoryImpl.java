package com.taobao.ad.brand.bp.adapter.port.repository.order;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.nb.common.dto.NbServiceContext;
import com.alibaba.ad.nb.order.constant.common.ProductCodeEnum;
import com.alibaba.ad.nb.order.dto.creative.CreativeDTO;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.order.NbOrderSAO;
import com.taobao.ad.brand.bp.domain.order.NbOrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Iterator;
import java.util.Map;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/5/11 16:42
 * @description ：
 * @modified By：
 */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class NbOrderRepositoryImpl implements NbOrderRepository {

    private final NbOrderSAO nbOrderSAO;

    @Override
    public Map<String, String> generateCreativeProtocols(ServiceContext context, CreativeViewDTO creativeViewDTO) {
        CreativeDTO creativeDTO = new CreativeDTO();
        creativeDTO.setTemplateData(rebuildTemplateData(creativeViewDTO.getCreativeMalus().getTemplateData()));
        creativeDTO.setProductId(ProductCodeEnum.YOUKU_BRAND_MIG.getProductId());
        return nbOrderSAO.generateCreativeProtocols(new NbServiceContext(), creativeDTO);
    }

    private String rebuildTemplateData(String templateData) {
        JSONObject jsonObject = JSON.parseObject(templateData);
        Iterator<Map.Entry<String, Object>> iterator = jsonObject.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, Object> entry = iterator.next();
            if (!entry.getKey().startsWith("$")) {
                if (entry.getKey().contains("landingPage")) {
                    iterator.remove();
                    continue;
                }
                if (entry.getValue().toString().startsWith("{")) {
                    JSONObject value = JSON.parseObject(entry.getValue().toString());
                    Object url = value.get("url");
                    entry.setValue(url);
                }
            }
        }
        return jsonObject.toString();
    }
}
