package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.adoss;

import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.google.common.collect.Lists;
import com.taobao.ad.adoss.nautilus.dto.CustomerInfoDTO;
import com.taobao.ad.adoss.nautilus.service.CustomerService;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.media.common.core.dto.ResultDTO;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * 获取客户行业SAO定义
 */
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AdossIndustrySAO extends BaseSAO {

//    private final CustomerService adossCustomerService;

    /**
     * 查询客户行业id（二级类目id）
     *
     * @param memberId 客户投放账号
     * @return 客户行业id（二级类目id）
     */
//    public Long getCustomerIndustry(Long memberId) {
//        ResultDTO<List<CustomerInfoDTO>> resultDTO = adossCustomerService.listCustomerByMemberIdList(Lists.newArrayList(memberId));
//        AssertUtil.assertTrue(resultDTO != null && resultDTO.isSuccess()
//                && CollectionUtils.isNotEmpty(resultDTO.getResult()), "客户行业查询失败");
//        CustomerInfoDTO customerInfoDTO = resultDTO.getResult().get(0);
//        //返回客户的二级类目id作为行业id
//        return customerInfoDTO.getCategoryC1Id();
//    }
}
