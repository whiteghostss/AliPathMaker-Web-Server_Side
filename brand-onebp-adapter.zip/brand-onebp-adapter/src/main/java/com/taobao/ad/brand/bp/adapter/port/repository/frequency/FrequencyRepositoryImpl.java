package com.taobao.ad.brand.bp.adapter.port.repository.frequency;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.frequence.CampaignFrequencyViewDTO;
import com.alibaba.ad.brand.dto.frequency.FrequencyViewDTO;
import com.alibaba.ad.brand.sdk.constant.frequency.field.BrandFrequencyBizTypeEnum;
import com.alibaba.ad.brand.sdk.constant.frequency.field.BrandFrequencyTargetEnum;
import com.alibaba.ad.brand.sdk.convert.custom.viewdto.FrequencyViewDTO2DTOConvertProcessor;
import com.alibaba.ad.organizer.dto.FrequencyDTO;
import com.alibaba.ad.organizer.dto.FrequencyRefDTO;
import com.alibaba.ad.universal.sdk.convert.custom.onebp.provider.OneBpConvertProcessorProvider;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.frequency.FrequencySAO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.FrequencyQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.FrequencyRefViewDTO;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class FrequencyRepositoryImpl implements com.taobao.ad.brand.bp.domain.frequency.repository.FrequencyRepository {

    private final FrequencySAO frequencySAO;
    private FrequencyViewDTO2DTOConvertProcessor frequencyProcessor = OneBpConvertProcessorProvider.getViewDTO2DTOConvertProcessor(FrequencyViewDTO2DTOConvertProcessor.class);

    @Override
    public Long addFrequency(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO) {
        FrequencyDTO frequencyDTO = frequencyProcessor.viewDTO2DTO(frequencyViewDTO);
        return frequencySAO.addFrequency(serviceContext, frequencyDTO);
    }
    @Override
    public void updateFrequencyAll(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO) {
        FrequencyDTO frequencyDTO = frequencyProcessor.viewDTO2DTO(frequencyViewDTO);
        frequencySAO.updateFrequencyAll(serviceContext, frequencyDTO);
    }

    @Override
    public Integer updateFrequencyPart(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO) {
        FrequencyDTO frequencyDTO = frequencyProcessor.viewDTO2DTO(frequencyViewDTO);
        return frequencySAO.updateFrequencyPart(serviceContext, frequencyDTO);
    }

    @Override
    public void saveCampaignFrequency(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList) {
        // 先删后增
        deleteCampaignFreqRef(serviceContext, campaignViewDTOList.stream().map(campaignViewDTO -> campaignViewDTO.getId()).collect(Collectors.toList()));
        for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
            // 说明改成不限或者移除绑定频控了
            FrequencyViewDTO frequencyViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignFrequencyViewDTO()).map(CampaignFrequencyViewDTO::getFrequencyViewDTO).orElse(null);
            if (Objects.nonNull(frequencyViewDTO)) {
                FrequencyRefDTO refDTO = new FrequencyRefDTO();
                refDTO.setBizId(campaignViewDTO.getId());
                Long freqId;
                if (Objects.isNull(frequencyViewDTO.getId())) {
                    freqId = frequencySAO.addFrequency(serviceContext, frequencyProcessor.viewDTO2DTO(frequencyViewDTO));
                } else {
                    freqId = frequencyViewDTO.getId();
                }
                refDTO.setFreqId(freqId);
                refDTO.setBizType(BrandFrequencyBizTypeEnum.CAMPAIGN.getCode());
                frequencySAO.addFrequencyRef(serviceContext, refDTO);
            }
        }
    }

    @Override
    public void saveCampaignFreqRef(ServiceContext serviceContext, Long freqId, List<Long> campaignIds) {
        List<FrequencyRefDTO> frequencyRefList = frequencySAO.findFrequencyRef(serviceContext, campaignIds, BrandFrequencyBizTypeEnum.CAMPAIGN);
        // 删除
        List<Long> deleteRefIds = frequencyRefList.stream().filter(e -> !e.getFreqId().equals(freqId))
                .map(FrequencyRefDTO::getId).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(deleteRefIds)) {
            frequencySAO.deleteFrequencyRef(serviceContext, deleteRefIds);
        }
        // 新增
        Set<Long> existedCampaignIds = frequencyRefList.stream().filter(e -> e.getFreqId().equals(freqId))
                .map(FrequencyRefDTO::getBizId).collect(Collectors.toSet());
        List<Long> addCampaignIds = campaignIds.stream().filter(item -> !existedCampaignIds.contains(item)).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(addCampaignIds)) {
            for (Long campaignId : addCampaignIds) {
                FrequencyRefDTO refDTO = new FrequencyRefDTO();
                refDTO.setBizId(campaignId);
                refDTO.setFreqId(freqId);
                refDTO.setBizType(BrandFrequencyBizTypeEnum.CAMPAIGN.getCode());
                frequencySAO.addFrequencyRef(serviceContext, refDTO);
            }
        }
    }

    @Override
    public void deleteCampaignFreqRef(ServiceContext serviceContext, List<Long> campaignIds) {
        if (CollectionUtils.isEmpty(campaignIds)) {
            return;
        }
        List<FrequencyRefDTO> frequencyRefList = frequencySAO.findFrequencyRef(serviceContext, campaignIds, BrandFrequencyBizTypeEnum.CAMPAIGN);
        // 删除
        List<Long> deleteRefIds = frequencyRefList.stream().map(FrequencyRefDTO::getId).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(deleteRefIds)) {
            frequencySAO.deleteFrequencyRef(serviceContext, deleteRefIds);
        }
    }

    @Override
    public Map<Long, FrequencyViewDTO> getCampaignFrequency(ServiceContext serviceContext, List<Long> campaignIds) {
        Map<Long, FrequencyViewDTO> result = new HashMap<>();
        // 计划x频控 关联关系
        List<FrequencyRefDTO> frequencyRefList = frequencySAO.findFrequencyRef(serviceContext, campaignIds, BrandFrequencyBizTypeEnum.CAMPAIGN);
        // 频控信息
        if (CollectionUtils.isNotEmpty(frequencyRefList)) {
            List<Long> freqIds = frequencyRefList.stream().map(FrequencyRefDTO::getFreqId).collect(Collectors.toList());
            List<FrequencyDTO> frequencyList = frequencySAO.findFrequency(serviceContext, freqIds);
            Map<Long, FrequencyDTO> frequencyMap = frequencyList.stream().collect(Collectors.toMap(FrequencyDTO::getId, Function.identity(), (v1, v2) -> v2));
            // 填充
            for (FrequencyRefDTO refDTO : frequencyRefList) {
                Long freqId = refDTO.getFreqId();
                if (frequencyMap.containsKey(freqId)) {
                    FrequencyViewDTO frequencyViewDTO = frequencyProcessor.dto2ViewDTO(frequencyMap.get(freqId));
                    if (Objects.isNull(frequencyViewDTO.getFrequencyTarget())) {
                        frequencyViewDTO.setFrequencyTarget(BrandFrequencyTargetEnum.PROMISE.getCode());
                    }
                    result.put(refDTO.getBizId(), frequencyViewDTO);
                }
            }
        }
        return result;
    }

    @Override
    public FrequencyViewDTO getFrequencyById(ServiceContext serviceContext, Long frequencyId) {
        List<FrequencyDTO> frequencyDTOList = frequencySAO.findFrequency(serviceContext, Lists.newArrayList(frequencyId));
        if (CollectionUtils.isEmpty(frequencyDTOList)) {
            return null;
        }
        FrequencyViewDTO frequencyViewDTO = frequencyProcessor.dto2ViewDTO(frequencyDTOList.get(0));
        if (Objects.isNull(frequencyViewDTO.getFrequencyTarget())) {
            frequencyViewDTO.setFrequencyTarget(BrandFrequencyTargetEnum.PROMISE.getCode());
        }
        return frequencyViewDTO;
    }

    @Override
    public PageResultViewDTO<FrequencyViewDTO> frequencyList(ServiceContext serviceContext, FrequencyQueryViewDTO queryViewDTO) {
        MultiResponse<FrequencyDTO> frequencyDTOList = frequencySAO.findFrequencyByKeyword(serviceContext, queryViewDTO);
        List<FrequencyViewDTO> frequencyViewDTOList = frequencyProcessor.dtoList2ViewDTOList(frequencyDTOList.getResult());
        if (CollectionUtils.isNotEmpty(frequencyViewDTOList)) {
            for (FrequencyViewDTO frequencyViewDTO: frequencyViewDTOList) {
                if (Objects.isNull(frequencyViewDTO.getFrequencyTarget())) {
                    frequencyViewDTO.setFrequencyTarget(BrandFrequencyTargetEnum.PROMISE.getCode());
                }
            }
        }
        return PageResultViewDTO.of(frequencyViewDTOList, frequencyDTOList.getTotal());
    }
    @Override
    public FrequencyRefViewDTO findFrequencyRefByFreqId(ServiceContext serviceContext, Long frequencyId, Integer frequencyBizType) {
        List<FrequencyRefDTO> frequencyRefDTOList = frequencySAO.findFrequencyRefByFreqIds(serviceContext, Lists.newArrayList(frequencyId), frequencyBizType);
        FrequencyRefViewDTO frequencyRefViewDTO = new FrequencyRefViewDTO();
        if (CollectionUtils.isNotEmpty(frequencyRefDTOList)) {
            frequencyRefViewDTO.setFreqId(frequencyId);
            List<Long> campaignIdList = frequencyRefDTOList.stream()
                    .filter(frequencyRefDTO -> BrandFrequencyBizTypeEnum.CAMPAIGN.getCode().equals(frequencyRefDTO.getBizType()))
                    .map(FrequencyRefDTO::getBizId).distinct().collect(Collectors.toList());
            List<Long> adgroupIdList = frequencyRefDTOList.stream()
                    .filter(frequencyRefDTO -> BrandFrequencyBizTypeEnum.ADGROUP.getCode().equals(frequencyRefDTO.getBizType()))
                    .map(FrequencyRefDTO::getBizId).distinct().collect(Collectors.toList());
            frequencyRefViewDTO.setCampaignIdList(campaignIdList);
            frequencyRefViewDTO.setAdgroupIdList(adgroupIdList);
        }
        return frequencyRefViewDTO;
    }
    @Override
    public List<FrequencyDTO> findFrequencyByName(ServiceContext serviceContext, FrequencyQueryViewDTO queryViewDTO) {
        return frequencySAO.findFrequencyByName(serviceContext, queryViewDTO);
    }

    @Override
    public void deleteAdgroupFreqRef(ServiceContext serviceContext, List<Long> adgroupIds) {
        if (CollectionUtils.isEmpty(adgroupIds)) {
            return;
        }
        List<FrequencyRefDTO> frequencyRefList = frequencySAO.findFrequencyRef(serviceContext, adgroupIds, BrandFrequencyBizTypeEnum.ADGROUP);
        // 删除
        List<Long> deleteRefIds = frequencyRefList.stream().map(FrequencyRefDTO::getId).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(deleteRefIds)) {
            frequencySAO.deleteFrequencyRef(serviceContext, deleteRefIds);
        }
    }

    @Override
    public void saveAdgroupFreqRef(ServiceContext serviceContext, Long freqId, List<Long> adgroupIds) {
        List<FrequencyRefDTO> frequencyRefList = frequencySAO.findFrequencyRef(serviceContext, adgroupIds, BrandFrequencyBizTypeEnum.ADGROUP);
        // 删除
        List<Long> deleteRefIds = frequencyRefList.stream().filter(e -> !e.getFreqId().equals(freqId))
                .map(FrequencyRefDTO::getId).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(deleteRefIds)) {
            frequencySAO.deleteFrequencyRef(serviceContext, deleteRefIds);
        }
        // 新增
        Set<Long> existedAdgroupIds = frequencyRefList.stream().filter(e -> e.getFreqId().equals(freqId))
                .map(FrequencyRefDTO::getBizId).collect(Collectors.toSet());
        List<Long> addAdgroupIds = adgroupIds.stream().filter(item -> !existedAdgroupIds.contains(item)).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(addAdgroupIds)) {
            for (Long adgroupId : addAdgroupIds) {
                FrequencyRefDTO refDTO = new FrequencyRefDTO();
                refDTO.setBizId(adgroupId);
                refDTO.setFreqId(freqId);
                refDTO.setBizType(BrandFrequencyBizTypeEnum.ADGROUP.getCode());
                frequencySAO.addFrequencyRef(serviceContext, refDTO);
            }
        }
    }

    @Override
    public Map<Long, FrequencyViewDTO> getAdgroupFrequency(ServiceContext serviceContext, List<Long> adgroupIds) {
        Map<Long, FrequencyViewDTO> result = new HashMap<>();
        // 计划x频控 关联关系
        List<FrequencyRefDTO> frequencyRefList = frequencySAO.findFrequencyRef(serviceContext, adgroupIds, BrandFrequencyBizTypeEnum.ADGROUP);
        // 频控信息
        if (CollectionUtils.isNotEmpty(frequencyRefList)) {
            List<Long> freqIds = frequencyRefList.stream().map(FrequencyRefDTO::getFreqId).collect(Collectors.toList());
            List<FrequencyDTO> frequencyList = frequencySAO.findFrequency(serviceContext, freqIds);
            Map<Long, FrequencyDTO> frequencyMap = frequencyList.stream().collect(Collectors.toMap(FrequencyDTO::getId, Function.identity(), (v1, v2) -> v2));
            // 填充
            for (FrequencyRefDTO refDTO : frequencyRefList) {
                Long freqId = refDTO.getFreqId();
                if (frequencyMap.containsKey(freqId)) {
                    FrequencyViewDTO frequencyViewDTO = frequencyProcessor.dto2ViewDTO(frequencyMap.get(freqId));
                    if (Objects.isNull(frequencyViewDTO.getFrequencyTarget())) {
                        frequencyViewDTO.setFrequencyTarget(BrandFrequencyTargetEnum.IMPROVE.getCode());
                    }
                    result.put(refDTO.getBizId(), frequencyViewDTO);
                }
            }
        }
        return result;
    }
}
