package com.taobao.ad.brand.bp.adapter.port.converter.industry;

import com.taobao.ad.brand.bp.adapter.port.converter.industry.mapStruct.IndustryMapStruct;
import com.taobao.ad.brand.bp.adapter.port.tunnel.dataobject.industry.IndustryDO;
import com.taobao.ad.brand.bp.client.dto.industry.IndustryViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.springframework.stereotype.Component;

@Component
public class IndustryViewDTOConverter extends BaseViewDTOConverter<IndustryDO, IndustryViewDTO> {

    @Override
    public BaseMapStructMapper<IndustryDO, IndustryViewDTO> getBaseMapStructMapper() {
        return IndustryMapStruct.INSTANCE;
    }
}
