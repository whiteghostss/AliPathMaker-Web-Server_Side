package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.cart;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.organizer.api.CartCommandService;
import com.alibaba.ad.organizer.api.CartQueryService;
import com.alibaba.ad.organizer.dto.CartDTO;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.solar.common.dto.QueryOptionDTO;
import com.alibaba.solar.common.query.dto.PageQueryDTO;
import com.alibaba.solar.common.query.dto.QueryDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * 加购行相关服务
 * @author shiyan
 * @date 2024/6/26
 **/
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CartItemSAO {
    private final CartQueryService cartQueryService;
    private final CartCommandService cartCommandService;

    /**
     * 查询购物车列表
     * @param serviceContext
     * @param queryDTO
     * @param optionDTO
     * @return
     */
    public List<CartDTO> findCartList(ServiceContext serviceContext, QueryDTO queryDTO, QueryOptionDTO optionDTO){
        MultiResponse<CartDTO> response = cartQueryService.findCartList(serviceContext, queryDTO, optionDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 分页查询购物车列表
     * @param serviceContext
     * @param pageQueryDTO
     * @param optionDTO
     * @return
     */
    public MultiResponse<CartDTO> findCartPage(ServiceContext serviceContext, PageQueryDTO pageQueryDTO, QueryOptionDTO optionDTO){
        MultiResponse<CartDTO> response = cartQueryService.findCartPage(serviceContext, pageQueryDTO, optionDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response;
    }


    /**
     * 查询购物车详情
     * @param serviceContext
     * @param id
     * @return
     */
    public CartDTO getCartById(ServiceContext serviceContext, Long id){
        SingleResponse<CartDTO> response = cartQueryService.getCartById(serviceContext, id);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 新增加购行
     * @param serviceContext
     * @param cartDTO
     * @return
     */
    public Long addCart(ServiceContext serviceContext, CartDTO cartDTO){
        SingleResponse<Long> response = cartCommandService.addCart(serviceContext, cartDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 根据id删除购物车
     * @param serviceContext
     * @param ids            (主键id)
     * @return
     */
    public Integer delCartByIds(ServiceContext serviceContext, List<Long> ids){
        SingleResponse<Integer> response = cartCommandService.delCartByIds(serviceContext, ids);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 全量覆盖更新购物车
     * @param serviceContext
     * @param cartDTO
     * @return
     */
    public Integer updateCartAll(ServiceContext serviceContext, CartDTO cartDTO){
        SingleResponse<Integer> response = cartCommandService.updateCartAll(serviceContext, cartDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 部分更新购物车
     * @param serviceContext
     * @param cartDTO
     * @return
     */
    public Integer updateCartPart(ServiceContext serviceContext, CartDTO cartDTO){
        SingleResponse<Integer> response = cartCommandService.updateCartPart(serviceContext, cartDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 批量更新加购行状态
     * @param serviceContext
     * @param cartIdList
     * @param cartStatus
     * @return
     */
    public Integer batchUpdateCartStatus(ServiceContext serviceContext, List<Long> cartIdList, Integer cartStatus){
        SingleResponse<Integer> response = cartCommandService.updateCartStatusBatch(serviceContext, cartIdList,cartStatus);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }
}
