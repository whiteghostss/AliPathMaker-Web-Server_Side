package com.taobao.ad.brand.bp.adapter.port.repository.motion;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.nb.common.query.PageQuery;
import com.alibaba.ad.nb.packages.v2.client.dto.motion.IntelligentMotionDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.motion.query.MotionQueryDTO;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.adapter.port.converter.motion.IntelligentMotionDTOConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.dmpargus.DmpArgusSAO;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.resourcepackage.ResourcePackageSAO;
import com.taobao.ad.brand.bp.client.dto.motion.IntelligentMotionViewDTO;
import com.taobao.ad.brand.bp.client.dto.motion.query.MotionQueryViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.motion.IntelligentMotionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/20
 **/
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class IntelligentMotionRepositoryImpl implements IntelligentMotionRepository {

    private final DmpArgusSAO dmpArgusSAO;
    private final ResourcePackageSAO resourcePackageSAO;
    private final IntelligentMotionDTOConverter intelligentMotionDTOConverter;

    @Override
    public List<IntelligentMotionViewDTO> queryIntelligentMotionList(ServiceContext serviceContext, MotionQueryViewDTO motionQueryViewDTO) {
        List<IntelligentMotionDTO> intelligentMotionDTOList = resourcePackageSAO.queryIntelligentMotionList(serviceContext, convertMotionQuery(motionQueryViewDTO), null);
        return intelligentMotionDTOConverter.convertDTO2ViewDTOList(intelligentMotionDTOList);
    }

    @Override
    public IntelligentMotionViewDTO getIntelligentMotionById(ServiceContext serviceContext, Long id) {
        List<IntelligentMotionDTO> intelligentMotionDTOList = resourcePackageSAO.queryIntelligentMotionList(serviceContext, MotionQueryDTO.builder().idList(Lists.newArrayList(id)).build(), null);
        AssertUtil.notEmpty(intelligentMotionDTOList, BrandOneBPBaseErrorCode.BIZ_DATA_EMPTY_ERROR, "无法查到策略对应的提案");
        return intelligentMotionDTOConverter.convertDTO2ViewDTOList(intelligentMotionDTOList).get(0);
    }

    @Override
    public MultiResponse<IntelligentMotionViewDTO> queryIntelligentMotionPageList(ServiceContext serviceContext, MotionQueryViewDTO motionQueryViewDTO) {
        PageQuery pageQuery = new PageQuery(motionQueryViewDTO.getPageNo(), motionQueryViewDTO.getPageSize());
        MultiResponse<IntelligentMotionDTO> response = resourcePackageSAO.queryIntelligentMotionListResponse(serviceContext, convertMotionQuery(motionQueryViewDTO), pageQuery);
        return MultiResponse.of(intelligentMotionDTOConverter.convertDTO2ViewDTOList(response.getResult()), response.getTotal());
    }

    @Override
    public Long saveOrUpdateIntelligentMotion(ServiceContext serviceContext, IntelligentMotionViewDTO motionViewDTO) {
        IntelligentMotionDTO intelligentMotionDTO = intelligentMotionDTOConverter.convertViewDTO2DTO(motionViewDTO);
        return resourcePackageSAO.addOrUpdateIntelligentMotion(serviceContext, intelligentMotionDTO);
    }

    @Override
    public void updateIntelligentMotionListStatus(ServiceContext serviceContext, List<Long> idList, Integer status) {
        resourcePackageSAO.updateIntelligentMotionListStatus(serviceContext, idList, status);
    }

    private MotionQueryDTO convertMotionQuery(MotionQueryViewDTO motionQueryViewDTO) {
        return MotionQueryDTO.builder()
                .idList(motionQueryViewDTO.getIdList())
                .memberId(motionQueryViewDTO.getMemberId())
                .name(motionQueryViewDTO.getName())
                .creator(motionQueryViewDTO.getCreator())
                .statusList(motionQueryViewDTO.getStatusList())
                .startDate(motionQueryViewDTO.getStartTime())
                .endDate(motionQueryViewDTO.getEndTime())
                .source(motionQueryViewDTO.getSource())
                .build();
    }

}
