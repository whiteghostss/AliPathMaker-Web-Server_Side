package com.taobao.ad.brand.bp.adapter.port.repository.effect;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.effect.EffectAdvertiserSAO;
import com.taobao.ad.brand.bp.client.dto.effect.DirectAdvertiserSettingViewDTO;
import com.taobao.ad.brand.bp.client.dto.effect.EffectAdvertiserContractFundViewDTO;
import com.taobao.ad.brand.bp.client.dto.effect.EffectAdvertiserViewDTO;
import com.taobao.ad.brand.bp.domain.effect.EffectAdvertiserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
/**
 * 效果adv实现
 * */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EffectAdvertiserRepositoryImpl implements EffectAdvertiserRepository {

    private final EffectAdvertiserSAO effectAdvertiserSAO;

//    @Override
//    public List<EffectAdvertiserViewDTO> findEffectAdvList(ServiceContext serviceContext, List<Long> advIds) {
//        return effectAdvertiserSAO.findEffectAdvList(advIds);
//    }
    @Override
    public List<EffectAdvertiserViewDTO> findEffectAdvInnerList(ServiceContext serviceContext, List<Long> advIds) {
        return effectAdvertiserSAO.findEffectAdvInnerList(advIds);
    }

    @Override
    public void updateAdvertiserSetting(ServiceContext serviceContext, List<DirectAdvertiserSettingViewDTO> directAdvertiserSettingDTOList) {
        effectAdvertiserSAO.updateEffectAdvertiserSetting(directAdvertiserSettingDTOList);
    }

    @Override
    public void deleteAdvertiserSetting(ServiceContext serviceContext, Long advId, List<String> settingKey) {
        effectAdvertiserSAO.deleteEffectAdvertiserSetting(advId,settingKey);

    }

    @Override
    public List<EffectAdvertiserContractFundViewDTO> findAdvertiserContractFundList(ServiceContext serviceContext, List<Integer> directMediaIds, List<Long> directAdvertiserIds, List<Long> subContractIds) {
        return effectAdvertiserSAO.findAdvertiserContractFundList(serviceContext,directMediaIds,directAdvertiserIds,subContractIds);
    }
}
