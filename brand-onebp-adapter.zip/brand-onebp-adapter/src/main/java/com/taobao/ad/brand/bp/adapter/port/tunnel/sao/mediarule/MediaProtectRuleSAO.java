package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.mediarule;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.organizer.api.media.MediaProtectRuleCommandService;
import com.alibaba.ad.organizer.api.media.MediaProtectRuleQueryService;
import com.alibaba.ad.organizer.dto.media.MediaProtectRuleDTO;
import com.alibaba.ad.organizer.dto.query.MediaProtectRulePidRefQuery;
import com.alibaba.ad.organizer.dto.query.MediaProtectRuleQuery;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.alibaba.solar.common.query.dto.PageQueryDTO;
import com.alibaba.solar.common.query.dto.QueryDTO;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.mediarule.query.MediaProtectRuleQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.mediarule.MediaRuleQueryEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class MediaProtectRuleSAO extends BaseSAO {

    private final MediaProtectRuleCommandService mediaProtectRuleCommandService;
    private final MediaProtectRuleQueryService mediaProtectRuleQueryService;

    public Long addProtectRule(ServiceContext serviceContext, MediaProtectRuleDTO mediaProtectRuleDTO) {
        SingleResponse<Long> response = mediaProtectRuleCommandService.addProtectRule(serviceContext, mediaProtectRuleDTO);
        AssertUtil.assertTrue(response.isSuccess(),response.getErrorMsg());
        return response.getResult();
    }

    public Integer updateProtectRule(ServiceContext serviceContext, MediaProtectRuleDTO MediaProtectRuleDTO) {
        SingleResponse<Integer> response = mediaProtectRuleCommandService.updateProtectRuleAll(serviceContext, MediaProtectRuleDTO);
        AssertUtil.assertTrue(response.isSuccess(),response.getErrorMsg());
        return response.getResult();
    }

    public Integer updateProtectRuleStatus(ServiceContext serviceContext, List<Long> protectRuleIds, Integer status) {
        SingleResponse<Integer> response = mediaProtectRuleCommandService.updateProtectRuleStatusBatch(serviceContext, protectRuleIds,status);
        AssertUtil.assertTrue(response.isSuccess(),response.getErrorMsg());
        return response.getResult();
    }

    public MediaProtectRuleDTO getProtectRule(ServiceContext serviceContext, Long id) {
        QueryDTO queryDTO = QueryDTO.createQuery().andCondition(MediaProtectRuleQuery.id.eq(id));
        MultiResponse<MediaProtectRuleDTO> response = mediaProtectRuleQueryService.findMediaProtectRuleList(serviceContext, queryDTO);
        AssertUtil.assertTrue(response.isSuccess(),response.getErrorMsg());
        if(CollectionUtils.isEmpty(response.getResult())){
            return null;
        }
        return response.getResult().get(0);
    }

    public PageResultViewDTO<MediaProtectRuleDTO> findListWithPage(ServiceContext serviceContext, MediaProtectRuleQueryViewDTO queryViewDTO) {
        RogerLogger.info("保护findListWithPage queryViewDTO={}",queryViewDTO.toString());
        if(CollectionUtils.isNotEmpty(queryViewDTO.getPidList())){
            List<Long> protectIdList = queryProtectRuleByPid(serviceContext, queryViewDTO.getPidList());
            if(CollectionUtils.isEmpty(protectIdList)){
                return PageResultViewDTO.empty();
            }
            queryViewDTO.setIds(protectIdList);
        }
        MultiResponse<MediaProtectRuleDTO> response = mediaProtectRuleQueryService.findMediaProtectRulePage(serviceContext, initPageQueryDTO(queryViewDTO));
        AssertUtil.assertTrue(response.isSuccess(), response.getErrorMsg());
        return PageResultViewDTO.of(response.getResult(), response.getTotal());
    }

    private List<Long> queryProtectRuleByPid(ServiceContext context,List<String> pidList) {
        QueryDTO queryDTO = QueryDTO.createQuery();
        queryDTO.andCondition(MediaProtectRulePidRefQuery.pid.findInSet(pidList));
        MultiResponse<MediaProtectRuleDTO> response = mediaProtectRuleQueryService.findMediaProtectRuleListByPid(context, queryDTO);
        AssertUtil.assertTrue(response);
        return Optional.ofNullable(response.getResult()).orElse(Lists.newArrayList())
            .stream().map(MediaProtectRuleDTO::getId).distinct().collect(Collectors.toList());
    }

    public List<MediaProtectRuleDTO> findList(ServiceContext serviceContext, MediaProtectRuleQueryViewDTO queryViewDTO) {
        if(CollectionUtils.isNotEmpty(queryViewDTO.getPidList())){
            List<Long> protectIdList = queryProtectRuleByPid(serviceContext, queryViewDTO.getPidList());
            if(CollectionUtils.isEmpty(protectIdList)){
                return Lists.newArrayList();
            }
            queryViewDTO.setIds(protectIdList);
        }
        MultiResponse<MediaProtectRuleDTO> response = mediaProtectRuleQueryService.findMediaProtectRuleList(serviceContext, initQueryDTO(queryViewDTO));
        AssertUtil.assertTrue(response.isSuccess(), response.getErrorMsg());
        return response.getResult();
    }

    /**
     * 根据名称查询媒体频控
     * @param serviceContext
     * @param uniqueName
     * @return
     */
    public MediaProtectRuleDTO getTopOneByName(ServiceContext serviceContext, String uniqueName) {
        QueryDTO queryDTO = QueryDTO.createQuery().andCondition(MediaProtectRuleQuery.name.eq(uniqueName));
        MultiResponse<MediaProtectRuleDTO> response = mediaProtectRuleQueryService.findMediaProtectRuleList(serviceContext, queryDTO);
        AssertUtil.assertTrue(response.isSuccess(), response.getErrorMsg());
        return CollectionUtils.isNotEmpty(response.getResult()) ? response.getResult().get(0) : null;
    }

    private PageQueryDTO initPageQueryDTO(MediaProtectRuleQueryViewDTO queryViewDTO) {
        PageQueryDTO pageQueryDTO = PageQueryDTO.createQuery(queryViewDTO.getStart(), queryViewDTO.getPageSize());
        initQueryDTO(queryViewDTO,pageQueryDTO);
        return pageQueryDTO;
    }

    private QueryDTO initQueryDTO(MediaProtectRuleQueryViewDTO queryViewDTO) {
        QueryDTO queryDTO = QueryDTO.createQuery();
        initQueryDTO(queryViewDTO,queryDTO);
        return queryDTO;
    }

    private QueryDTO initQueryDTO(MediaProtectRuleQueryViewDTO queryViewDTO, QueryDTO queryDTO) {
        if (Objects.equals(queryViewDTO.getKeywordType(),MediaRuleQueryEnum.ID.getValue())) {
            queryDTO.andCondition(MediaProtectRuleQuery.id.eq(Long.valueOf(queryViewDTO.getKeyword())));
        }
        if (Objects.equals(queryViewDTO.getKeywordType(),MediaRuleQueryEnum.NAME.getValue())) {
            queryDTO.andCondition(MediaProtectRuleQuery.name.like(queryViewDTO.getKeyword()));
        }
        if (CollectionUtils.isNotEmpty(queryViewDTO.getIds())) {
            queryDTO.andCondition(MediaProtectRuleQuery.id.in(queryViewDTO.getIds()));
        }
        if (Objects.nonNull(queryViewDTO.getStatus())) {
            queryDTO.andCondition(MediaProtectRuleQuery.status.eq(queryViewDTO.getStatus()));
        }
        if (Objects.nonNull(queryViewDTO.getSiteId())) {
            queryDTO.andCondition(MediaProtectRuleQuery.siteId.eq(queryViewDTO.getSiteId()));
        }
        queryDTO.orderBy(MediaProtectRuleQuery.gmtModified.descOrder());
        return queryDTO;
    }
    
}
