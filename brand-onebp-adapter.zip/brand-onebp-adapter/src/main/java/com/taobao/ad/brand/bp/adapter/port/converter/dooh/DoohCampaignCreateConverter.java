
package com.taobao.ad.brand.bp.adapter.port.converter.dooh;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.audience.CrowdBaseViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.audience.CampaignTargetViewDTO;
import com.alibaba.ad.brand.dto.campaign.budget.CampaignBudgetViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdScenarioViewDTO;
import com.alibaba.ad.brand.dto.campaign.dooh.CampaignDoohViewDTO;
import com.alibaba.ad.brand.dto.campaign.sale.CampaignSaleViewDTO;
import com.alibaba.ad.brand.sdk.constant.audience.field.BrandTargetTypeEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupProductCategoryEnum;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.memeber.MemberRepository;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.umeng.oplus.domain.dto.dsp.plan.DspPlanCreateDTO;
import com.umeng.oplus.domain.emuntype.dsp.plan.DspPlanScheduleTypeEnum;
import com.umeng.oplus.domain.emuntype.dsp.plan.DspQuickPriorityType;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DoohCampaignCreateConverter {

    private final MemberRepository memberRepository;

    private final ResourcePackageRepository resourcePackageRepository;


    public DspPlanCreateDTO convertToDspPlanCreateDTO(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {
        DspPlanCreateDTO dspPlanCreateDTO = new DspPlanCreateDTO();

//        CampaignBaseViewDTO campaignBaseViewDTO = campaignViewDTO.getCampaignBaseViewDTO();
        CampaignSaleViewDTO campaignSaleViewDTO = campaignViewDTO.getCampaignSaleViewDTO();
        CampaignDoohViewDTO campaignDoohViewDTO = campaignViewDTO.getCampaignDoohViewDTO();
        CampaignBudgetViewDTO campaignBudgetViewDTO = campaignViewDTO.getCampaignBudgetViewDTO();
        List<CampaignTargetViewDTO> targetViewDTOS = campaignViewDTO.getCampaignTargetScenarioViewDTO().getCampaignTargetViewDTOList();

        dspPlanCreateDTO.setMemberId(campaignViewDTO.getMemberId());
        dspPlanCreateDTO.setMemberName(memberRepository.getMemberNameById(campaignViewDTO.getMemberId()));
        dspPlanCreateDTO.setTbUserId(memberRepository.getTbNumIdByMemberId(campaignViewDTO.getMemberId()));
        dspPlanCreateDTO.setBailingPlanName(campaignViewDTO.getTitle());
        dspPlanCreateDTO.setBailingPlanId(campaignViewDTO.getId());
        dspPlanCreateDTO.setParentBailingPlanId(campaignViewDTO.getParentCampaignId());
        dspPlanCreateDTO.setStartDate(campaignViewDTO.getStartTime());
        dspPlanCreateDTO.setEndDate(campaignViewDTO.getEndTime());

        if (campaignDoohViewDTO != null) {
            dspPlanCreateDTO.setDspPlanId(campaignDoohViewDTO.getDoohCampaignId());
            dspPlanCreateDTO.setDspSchemeId(campaignDoohViewDTO.getDoohStrategyId());
        }
        BigDecimal budget;
        if (campaignBudgetViewDTO != null && campaignBudgetViewDTO.getDiscountTotalMoney() != null) {
            budget = BigDecimal.valueOf(campaignBudgetViewDTO.getDiscountTotalMoney());
        } else {
            //目前天攻分组下只有一个天攻计划,可以直接使用分组金额.
            ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO = resourcePackageRepository.getSaleGroupById(ServiceContextUtil.buildServiceContextForSceneId(campaignViewDTO.getMemberId(), campaignViewDTO.getSceneId())
                    , campaignSaleViewDTO.getSaleGroupId()
                    , ResourcePackageQueryOption.builder().needInquiryPriority(Boolean.FALSE).needProduct(Boolean.FALSE).needSetting(Boolean.TRUE).build());
            AssertUtil.assertTrue(resourcePackageSaleGroupViewDTO != null, "convertToDspPlanCreateDTO error saleGroupId empty %s", campaignSaleViewDTO.getSaleGroupId());
            budget = BigDecimal.valueOf(resourcePackageSaleGroupViewDTO.getBudget());
        }
        dspPlanCreateDTO.setBudget(budget.equals(BigDecimal.ZERO) ? BigDecimal.ZERO : budget.divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP));

        if (CollectionUtils.isNotEmpty(targetViewDTOS)) {

            CampaignTargetViewDTO priorityType = targetViewDTOS.stream().filter(targetViewDTO -> BrandTargetTypeEnum.OOH_JSD_OPTIMIZED.getCode().toString().equals(targetViewDTO.getType())).findFirst().orElse(new CampaignTargetViewDTO());
            dspPlanCreateDTO.setPriorityType(DspQuickPriorityType.find(CollectionUtils.isEmpty(priorityType.getTargetValues()) ? null : priorityType.getTargetValues().get(0)));

            CampaignTargetViewDTO industry = targetViewDTOS.stream().filter(targetViewDTO -> BrandTargetTypeEnum.OOH_JSD_INDUSTRY.getCode().toString().equals(targetViewDTO.getType())).findFirst().orElse(new CampaignTargetViewDTO());
            dspPlanCreateDTO.setIndustryId(CollectionUtils.isEmpty(industry.getTargetValues()) ? null : Long.valueOf(industry.getTargetValues().get(0)));

            CampaignTargetViewDTO cityCodes = targetViewDTOS.stream().filter(targetViewDTO -> BrandTargetTypeEnum.AREA.getCode().toString().equals(targetViewDTO.getType())).findFirst().orElse(new CampaignTargetViewDTO());
            dspPlanCreateDTO.setCityCodes(CollectionUtils.isEmpty(cityCodes.getTargetValues()) ? null : cityCodes.getTargetValues().stream().map(Integer::valueOf).collect(Collectors.toList()));

            CampaignTargetViewDTO deviceType = targetViewDTOS.stream().filter(targetViewDTO -> BrandTargetTypeEnum.DOOH_DEVICE_TYPE.getCode().toString().equals(targetViewDTO.getType())).findFirst().orElse(new CampaignTargetViewDTO());
            dspPlanCreateDTO.setDeviceTypeIds(CollectionUtils.isEmpty(deviceType.getTargetValues()) ? null : deviceType.getTargetValues().stream().map(Integer::valueOf).collect(Collectors.toList()));

        }

        List<CampaignCrowdViewDTO> crowdTargetViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignCrowdScenarioViewDTO())
                .map(CampaignCrowdScenarioViewDTO::getCampaignCrowdViewDTOList).orElse(null);
        if (CollectionUtils.isNotEmpty(crowdTargetViewDTOList)) {
            List<Long> crowdList = crowdTargetViewDTOList.stream()
                    .filter(campaignCrowdViewDTO -> Long.valueOf(BrandTargetTypeEnum.DMP_CROWD.getCode()).equals(campaignCrowdViewDTO.getTargetType())
                            || Long.valueOf(BrandTargetTypeEnum.RECOMMEND.getCode()).equals(campaignCrowdViewDTO.getTargetType()))
                    .map(CrowdBaseViewDTO::getCrowdId).distinct().collect(Collectors.toList());
            dspPlanCreateDTO.setCrowdList(crowdList);
        }

        ResourcePackageSaleGroupViewDTO saleGroupViewDTO = resourcePackageRepository.getSaleGroupById(serviceContext, campaignSaleViewDTO.getSaleGroupId(), ResourcePackageQueryOption.builder().build());
        if(SaleGroupProductCategoryEnum.SMART_SCREEN_SPEED.getValue().equals(saleGroupViewDTO.getProductCategory())){
            dspPlanCreateDTO.setDspPlanScheduleType(DspPlanScheduleTypeEnum.QUICK);
        }else{
            dspPlanCreateDTO.setDspPlanScheduleType(DspPlanScheduleTypeEnum.BIND);
        }

        return dspPlanCreateDTO;
    }
}
