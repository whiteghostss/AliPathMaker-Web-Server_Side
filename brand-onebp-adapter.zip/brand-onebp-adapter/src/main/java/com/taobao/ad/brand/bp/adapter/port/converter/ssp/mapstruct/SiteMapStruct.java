package com.taobao.ad.brand.bp.adapter.port.converter.ssp.mapstruct;

import com.alibaba.ad.nb.ssp.dto.site.SiteDTO;
import com.taobao.ad.brand.bp.client.dto.site.SiteViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/23
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface SiteMapStruct extends BaseMapStructMapper<SiteDTO, SiteViewDTO> {
    SiteMapStruct INSTANCE = Mappers.getMapper(SiteMapStruct.class);
}