
package com.taobao.ad.brand.bp.adapter.port.converter.motion.mapstruct;

import com.alibaba.ad.nb.packages.v2.client.dto.motion.IntelligentMotionDTO;
import com.taobao.ad.brand.bp.client.dto.motion.IntelligentMotionViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * BizCreativeMapStruct
 * DTO与领域模型实体映射
 * @author ddd-coder-init
 * @date 2020/12/12
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, uses = {MarketingStageMapStruct.class})
public interface IntelligentMotionMapStruct extends BaseMapStructMapper<IntelligentMotionDTO, IntelligentMotionViewDTO> {

	IntelligentMotionMapStruct INSTANCE = Mappers.getMapper(IntelligentMotionMapStruct.class);

	@Mappings({
			@Mapping(source = "marketingStageList", target = "marketingStageViewDTOList"),
			@Mapping(source = "attentionTargetList", target = "attentionTargetViewDTOList"),
			@Mapping(source = "resourceTypeRatioList", target = "resourceTypeRatioViewDTOList"),
			@Mapping(source = "startDate", target = "startTime"),
			@Mapping(source = "endDate", target = "endTime"),
	})
	@Override
	IntelligentMotionViewDTO sourceToTarget(IntelligentMotionDTO intelligentMotionDTO);

	@Mappings({
			@Mapping(source = "marketingStageViewDTOList", target = "marketingStageList"),
			@Mapping(source = "attentionTargetViewDTOList", target = "attentionTargetList"),
			@Mapping(source = "resourceTypeRatioViewDTOList", target = "resourceTypeRatioList"),
			@Mapping(source = "startTime", target = "startDate"),
			@Mapping(source = "endTime", target = "endDate"),
	})
	@Override
	IntelligentMotionDTO targetToSource(IntelligentMotionViewDTO intelligentMotionViewDTO);
}

