package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.dmpargus;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.audience.CampaignTargetScenarioViewDTO;
import com.alibaba.ad.brand.dto.campaign.audience.CampaignTargetViewDTO;
import com.alibaba.ad.brand.dto.campaign.keyword.CampaignKeywordViewDTO;
import com.alibaba.ad.brand.dto.campaign.keyword.CampaignWordPackageViewDTO;
import com.alibaba.ad.brand.dto.campaign.keyword.CampaignWordViewDTO;
import com.alibaba.ad.brand.sdk.constant.audience.field.BrandTargetTypeEnum;
import com.alibaba.ad.brand.sdk.constant.keyword.field.BrandKeywordMatchScopeEnum;
import com.alibaba.ad.brand.sdk.constant.keyword.field.BrandWordPackageTypeEnum;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.alimama.faas.brand.engine.entity.constant.KWEstimateElem;
import com.alimama.faas.brand.engine.entity.constant.KWEstimateScope;
import com.alimama.faas.brand.engine.entity.constant.KWEstimateType;
import com.alimama.faas.brand.engine.entity.constant.KeywordInfo;
import com.alimama.faas.brand.engine.entity.constant.KeywordPackageType;
import com.alimama.faas.brand.engine.entity.constant.KwSearchType;
import com.alimama.faas.brand.engine.entity.constant.MediaType;
import com.alimama.faas.brand.engine.entity.constant.PuttingInfo;
import com.alimama.faas.brand.engine.entity.constant.RcmdRelevanceType;
import com.alimama.faas.brand.engine.entity.constant.RecommendKWType;
import com.alimama.faas.brand.engine.entity.constant.ServiceCodeEnum;
import com.alimama.faas.brand.engine.entity.constant.TianGongPuttingPlan;
import com.alimama.faas.brand.engine.entity.constant.TiangongStrategyType;
import com.alimama.faas.brand.engine.entity.domain.*;
import com.alimama.faas.brand.engine.entity.request.EstimateRequest;
import com.alimama.faas.brand.engine.entity.request.KeywordEffectEstimateRequest;
import com.alimama.faas.brand.engine.entity.request.KeywordPackageRecommendRequest;
import com.alimama.faas.brand.engine.entity.request.KeywordRecommendRequest;
import com.alimama.faas.brand.engine.entity.request.TianGongRcmdRequest;
import com.alimama.faas.brand.engine.entity.response.AICreativePredictResponse;
import com.alimama.faas.brand.engine.entity.response.EstimateResponse;
import com.alimama.faas.brand.engine.entity.response.KeywordEffectEstimateResponse;
import com.alimama.faas.brand.engine.entity.response.KeywordPackageRecommendResponse;
import com.alimama.faas.brand.engine.entity.response.KeywordRecommendResponse;
import com.alimama.faas.brand.engine.entity.response.PreStrategyRcmdResponse;
import com.alimama.faas.brand.engine.entity.response.TianGongRcmdResponse;
import com.alimama.ginkgo.parent.sdk.CommonResponse;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.dto.base.TreeNodeViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignKeywordEstimateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignShowConfigViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.DmpArgusEstimateViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohPointClassificationViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohPointSourceViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohStrategyPointViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohStrategyRecommendReasonViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohStrategyViewDTO;
import com.taobao.ad.brand.bp.client.enums.dooh.DoohStrategyPointSourceEnum;
import com.taobao.ad.brand.bp.client.enums.keyword.KeywordAssociateMethodEnum;
import com.taobao.ad.brand.bp.client.enums.keyword.KeywordClassificationEnum;
import com.taobao.ad.brand.bp.client.enums.keyword.KeywordEstimateTypeEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.enums.BooleanEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.dmp.argus.sdk.dto.AppContext;
import com.taobao.ad.dmp.argus.sdk.dto.ResultDTO;
import com.taobao.ad.dmp.argus.sdk.interfaces.ServiceGateway;
import com.taobao.eagleeye.EagleEye;
import com.taobao.eagleeye.RpcContext_inner;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * b端引擎SAO
 * @author yunhu.myh@taobao.com
 * @date 2023年07月25日
 * */
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DmpArgusSAO {

    private final ServiceGateway serviceGateway;
    private final static String ESTIMATE_TOKEN =  "6a7790f7b30f482e489162d488f93099";
    private final static Long ESTIMATE_APP_ID =  120L;

    /**
     * 预估计算
     * */
    public EstimateResponse estimateSaleGroup(ServiceContext serviceContext, String serviceCode, EstimateRequest estimateRequest) {
        Map<String, Object> param = (Map<String, Object>) JSONObject.toJSON(estimateRequest);
        String value = doInvokeEstimate(serviceContext, serviceCode, param);
        CommonResponse<EstimateResponse> fcResponse = JSONObject.parseObject(value, new TypeReference<CommonResponse<EstimateResponse>>(){});
        AssertUtil.assertTrue(fcResponse.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of("预估失败，请重试" ));
        EstimateResponse estimateResponse = fcResponse.getData();
        AssertUtil.assertTrue(estimateResponse.getErrorCode() == 0, estimateResponse.getMessage());
        return estimateResponse;
    }

//    /**
//     * 预估计算
//     * */
//    public CampaignGroupSaleGroupEstimateInfoViewDTO estimateSaleGroup(ServiceContext serviceContext, DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO){
//        return ServiceCodeEnum.BrandOneBpEngineSuper.name().equals(dmpArgusEstimateViewDTO.getServiceCode()) ? estimateSuperUniverse(serviceContext, dmpArgusEstimateViewDTO):estimateNormal(serviceContext, dmpArgusEstimateViewDTO);
//    }
//
//    @NotNull
//    private CampaignGroupSaleGroupEstimateInfoViewDTO estimateSuperUniverse(
//        ServiceContext serviceContext, DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO) {
//        SuperEstimateRequest estimateRequest  = initSuperEstimateRequest(dmpArgusEstimateViewDTO);
//        Map<String, Object> param = (Map<String, Object>) JSONObject.toJSON(estimateRequest);
//        String value = doInvokeEstimate(serviceContext, dmpArgusEstimateViewDTO, param);
//        CommonResponse<SuperEstimateResponse> fcResponse = JSONObject.parseObject(value,
//                new TypeReference<CommonResponse<SuperEstimateResponse>>(){});
//        AssertUtil.assertTrue(fcResponse.isSuccess(),"预估失败，请重试" );
//        SuperEstimateResponse estimateResponse = fcResponse.getData();
//        AssertUtil.assertTrue(estimateResponse.getErrorCode() == 0,estimateResponse.getMessage() );
//
//        if (CollectionUtils.isNotEmpty(estimateResponse.getDeliverTarget())){
//            List<TargetResult> nReachList= estimateResponse.getDeliverTarget().stream().filter(item->item.getTargetId().equals(TargetType.N_REACH)).collect(Collectors.toList());
//            if (CollectionUtils.isNotEmpty(nReachList)){
//                TargetResult nReach = nReachList.get(0);
//                AssertUtil.assertTrue(nReach.getEstimateMin() >= 50L,"N+reach比例过低，请扩充人群或者资源或增加投放时间");
//            }
//        }
//        //构建返回信息
//        return buildSaleGroupEstimateResultViewDTO(estimateResponse, dmpArgusEstimateViewDTO);
//    }



    private String doInvokeEstimate(ServiceContext serviceContext,  String serviceCode, Map<String, Object> param) {
        AppContext appContext = new AppContext();
        // 目前固定使用的token
        appContext.setToken(ESTIMATE_TOKEN);
        // 固定
        appContext.setAppId(ESTIMATE_APP_ID);
        // 下面两个根据业务需要填写，主要用于记录与debug
        appContext.setMemberId(serviceContext.getMemberId());
        appContext.setNickname(serviceContext.getOperName());
        ResultDTO<String> invokeResult  = serviceGateway.invoke(appContext, serviceCode, param);
        AssertUtil.assertTrue(invokeResult.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of("预估调用失败，请重试" ));
        String value = invokeResult.getValue();
        AssertUtil.assertTrue(StringUtils.isNotBlank(value),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of("预估调用返回为空，请重试" ));
        return value;
    }

    /**
     * 异步调用
     * @param serviceContext
     * @param serviceCode
     * @param param
     */
    public void asyncDmpArgusInvoke(ServiceContext serviceContext, String serviceCode, Map<String, Object> param) {
        AppContext appContext = new AppContext();
        // 目前固定使用的token
        appContext.setToken(ESTIMATE_TOKEN);
        // 固定
        appContext.setAppId(ESTIMATE_APP_ID);
        // 下面两个根据业务需要填写，主要用于记录与debug
        appContext.setMemberId(serviceContext.getMemberId());
        appContext.setNickname(serviceContext.getOperName());
        RpcContext_inner rpcContext = EagleEye.getRpcContext();
        CompletableFuture.runAsync(() -> {
            EagleEye.setRpcContext(rpcContext);
            RogerLogger.info("DmpArgusSAO dmpArgusInvoke 调用 serviceGateway.invoke 接口参数：serviceCode:{}, param:{}", serviceCode, JSONObject.toJSONString(param));
            serviceGateway.invoke(appContext, serviceCode, param);
        });
    }

    /**
     * 同步调用
     * @param serviceContext
     * @param serviceCode
     * @param param
     * @return
     */
    public PreStrategyRcmdResponse dmpArgusInvoke(ServiceContext serviceContext, String serviceCode, Map<String, Object> param) {
        AppContext appContext = new AppContext();
        // 目前固定使用的token
        appContext.setToken(ESTIMATE_TOKEN);
        // 固定
        appContext.setAppId(ESTIMATE_APP_ID);
        // 下面两个根据业务需要填写，主要用于记录与debug
        appContext.setMemberId(serviceContext.getMemberId());
        appContext.setNickname(serviceContext.getOperName());
        RogerLogger.info("DmpArgusSAO dmpArgusInvoke 调用 serviceGateway.invoke 接口参数：serviceCode:{}, param:{}", serviceCode, JSONObject.toJSONString(param));
        ResultDTO<String> result = serviceGateway.invoke(appContext, serviceCode, param);
        AssertUtil.assertTrue(result.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of("同步计算投前策略预估数据失败，请重试" ));
        CommonResponse<PreStrategyRcmdResponse> fcResponse = JSONObject.parseObject(result.getValue(), new TypeReference<CommonResponse<PreStrategyRcmdResponse>>(){});
        AssertUtil.assertTrue(fcResponse.isSuccess(),"预估失败，请重试" );
        PreStrategyRcmdResponse preStrategyRcmdResponse = fcResponse.getData();
        AssertUtil.assertTrue(BooleanEnum.FALSE.getValue().equals(preStrategyRcmdResponse.getErrorCode()), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of("同步计算投前策略预估数据失败，请重试" ));
        return fcResponse.getData();
    }

    /**
     * 创意AI打分
     * @param serviceContext
     * @param param
     * @return
     */
    public AICreativePredictResponse dmpArgusInvokeForPredictCreativeScore(ServiceContext serviceContext, Map<String, Object> param) {
        AppContext appContext = new AppContext();
        appContext.setToken(ESTIMATE_TOKEN);
        appContext.setAppId(ESTIMATE_APP_ID);
        appContext.setMemberId(serviceContext.getMemberId());
        appContext.setNickname(serviceContext.getOperName());

        RogerLogger.info("创意AI打分 dmpArgusInvoke 调用 serviceGateway.invoke 接口参数：param:{}", JSONObject.toJSONString(param));
        ResultDTO<String> response = serviceGateway.invoke(appContext, ServiceCodeEnum.AICreativePredict.name(), param);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of("创意AI打分失败，请重试" ));
        CommonResponse<AICreativePredictResponse> commonResponse = JSONObject.parseObject(response.getValue(), new TypeReference<CommonResponse<AICreativePredictResponse>>(){});
        AssertUtil.assertTrue(commonResponse.isSuccess() &&
                Objects.nonNull(commonResponse.getData()) && CollectionUtils.isNotEmpty(commonResponse.getData().getCreativeScoreList()),"创意AI打分失败，请重试" );
        return commonResponse.getData();
    }

    public CampaignKeywordEstimateViewDTO estimateKeyword(ServiceContext serviceContext, DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO){
        List<CampaignWordViewDTO> keywordList = dmpArgusEstimateViewDTO.getCampaignWordViewDTOList();
        if(CollectionUtils.isEmpty(keywordList)){
            return null;
        }
        return ServiceCodeEnum.OneSearchShow.name().equals(dmpArgusEstimateViewDTO.getServiceCode()) ? estimateKeywordDayPrePv(serviceContext, dmpArgusEstimateViewDTO):null;
    }

    public List<CampaignWordViewDTO> recommendKeyword(ServiceContext serviceContext, DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO){
        if(ServiceCodeEnum.OneSearchShow.name().equals(dmpArgusEstimateViewDTO.getServiceCode())){
            KeywordRecommendRequest estimateRequest  = initKeywordRecommendRequest(dmpArgusEstimateViewDTO);
            Map<String, Object> param = (Map<String, Object>) JSONObject.toJSON(estimateRequest);
            String value = doInvokeEstimate(serviceContext, dmpArgusEstimateViewDTO.getServiceCode(), param);
            CommonResponse<KeywordRecommendResponse> kwResponse = JSONObject.parseObject(value,
                    new TypeReference<CommonResponse<KeywordRecommendResponse>>(){});
            AssertUtil.assertTrue(kwResponse.isSuccess(),"预估失败，请重试" );
            KeywordRecommendResponse estimateResponse = kwResponse.getData();
            //构建返回信息
            return buildKeywordRecommendResultViewDTO(estimateResponse);
        }else{
            return Lists.newArrayList();
        }
    }

    public DoohStrategyRecommendReasonViewDTO getDoohStrategyRecommendReason(ServiceContext serviceContext, DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO){
        if(dmpArgusEstimateViewDTO == null || dmpArgusEstimateViewDTO.getCampaignViewDTO() == null){
            return null;
        }
        return ServiceCodeEnum.TianGong.name().equals(dmpArgusEstimateViewDTO.getServiceCode()) ? estimateDoohStrategyRecommendReason(serviceContext, dmpArgusEstimateViewDTO):null;
    }

    public CampaignWordPackageViewDTO recommendWordPackage(ServiceContext serviceContext, DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO){
        if(ServiceCodeEnum.OneSearchShow.name().equals(dmpArgusEstimateViewDTO.getServiceCode())){
            KeywordPackageRecommendRequest estimateRequest  = initWordPackageEstimateRequest(dmpArgusEstimateViewDTO);
            Map<String, Object> param = (Map<String, Object>) JSONObject.toJSON(estimateRequest);
            String value = doInvokeEstimate(serviceContext, dmpArgusEstimateViewDTO.getServiceCode(), param);
            CommonResponse<KeywordPackageRecommendResponse> kwResponse = JSONObject.parseObject(value,
                    new TypeReference<CommonResponse<KeywordPackageRecommendResponse>>(){});
            AssertUtil.assertTrue(kwResponse.isSuccess(),"预估失败，请重试" );
            KeywordPackageRecommendResponse estimateResponse = kwResponse.getData();
            //构建返回信息
            return buildWordPackageEstimateResultViewDTO(estimateResponse);
        }
        return null;
    }

    private CampaignKeywordEstimateViewDTO estimateKeywordDayPrePv(ServiceContext serviceContext, DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO){
        KeywordEffectEstimateRequest estimateRequest  = initKeywordEstimateRequest(dmpArgusEstimateViewDTO);
        Map<String, Object> param = (Map<String, Object>) JSONObject.toJSON(estimateRequest);
        String value = doInvokeEstimate(serviceContext, dmpArgusEstimateViewDTO.getServiceCode(), param);
        CommonResponse<KeywordEffectEstimateResponse> kwResponse = JSONObject.parseObject(value,
                new TypeReference<CommonResponse<KeywordEffectEstimateResponse>>(){});
        AssertUtil.assertTrue(kwResponse.isSuccess(),"预估失败，请重试" );
        KeywordEffectEstimateResponse estimateResponse = kwResponse.getData();
        //构建返回信息
        return buildKeywordEstimateResultViewDTO(estimateResponse);
    }

    private DoohStrategyRecommendReasonViewDTO estimateDoohStrategyRecommendReason(ServiceContext serviceContext, DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO){
        TianGongRcmdRequest estimateRequest  = initDoohEstimateRequest(dmpArgusEstimateViewDTO);
        Map<String, Object> param = (Map<String, Object>) JSONObject.toJSON(estimateRequest);
        String value = doInvokeEstimate(serviceContext, dmpArgusEstimateViewDTO.getServiceCode(), param);
        CommonResponse<TianGongRcmdResponse> kwResponse = JSONObject.parseObject(value,
                new TypeReference<CommonResponse<TianGongRcmdResponse>>(){});
        AssertUtil.assertTrue(kwResponse.isSuccess(),"预估失败，请重试" );
        TianGongRcmdResponse estimateResponse = kwResponse.getData();
        //构建返回信息
        return buildDoohEstimateResultViewDTO(estimateResponse);
    }

    private KeywordEffectEstimateRequest initKeywordEstimateRequest(DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO){
        KeywordEffectEstimateRequest keywordEffectEstimateRequest = new KeywordEffectEstimateRequest();
        String keywordEstimateType = dmpArgusEstimateViewDTO.getKeywordEstimateType();
        if(KeywordEstimateTypeEnum.KW_PV.getCode().equals(keywordEstimateType)){
            keywordEffectEstimateRequest.setKwEstimateType(KWEstimateType.KW_PV);
        }else {
            keywordEffectEstimateRequest.setKwEstimateType(KWEstimateType.KW_ESTIMATE_SCOPE);
        }
        List<KeywordInfo> keywordInfoList = Lists.newArrayList();
        for(CampaignWordViewDTO wordViewDTO : dmpArgusEstimateViewDTO.getCampaignWordViewDTOList()){
            KeywordInfo keywordInfo = new KeywordInfo();
            keywordInfo.setKeyword(wordViewDTO.getWord());
            //本期只有中心词匹配，兼容历史精准匹配的计划
            if(wordViewDTO.getMatchScope() != null && BrandKeywordMatchScopeEnum.EXACT_MATCH.getCode().equals(wordViewDTO.getMatchScope())){
                keywordInfo.setKwSearchType(KwSearchType.PRECISION_MATCH);
            }else{
                keywordInfo.setKwSearchType(KwSearchType.CENTER_MATCH);
            }
            keywordInfoList.add(keywordInfo);
        }
        keywordEffectEstimateRequest.setKeywordList(keywordInfoList);
        return keywordEffectEstimateRequest;
    }

    private KeywordPackageRecommendRequest initWordPackageEstimateRequest(DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO){
        KeywordPackageRecommendRequest keywordPackageRecommendRequest = new KeywordPackageRecommendRequest();

        keywordPackageRecommendRequest.setBrandId(dmpArgusEstimateViewDTO.getBrandId());
        keywordPackageRecommendRequest.setItemIds(Lists.newArrayList(dmpArgusEstimateViewDTO.getItemId()));
        keywordPackageRecommendRequest.setMemberId(dmpArgusEstimateViewDTO.getMemberId());

        Integer wordPackageType = dmpArgusEstimateViewDTO.getWordPackageType();
        if(BrandWordPackageTypeEnum.BRAND.getCode().equals(wordPackageType)){
            keywordPackageRecommendRequest.setPackageType(KeywordPackageType.BRAND_PACKAGE);
        }else if(BrandWordPackageTypeEnum.CATEGORY.getCode().equals(wordPackageType)) {
            keywordPackageRecommendRequest.setPackageType(KeywordPackageType.CATE_PACKAGE);
        }else if(BrandWordPackageTypeEnum.COMPETITIVE.getCode().equals(wordPackageType)){
            keywordPackageRecommendRequest.setPackageType(KeywordPackageType.COMPETITIVE_PACKAGE);
        }else if(BrandWordPackageTypeEnum.ITEM.getCode().equals(wordPackageType)){
            keywordPackageRecommendRequest.setPackageType(KeywordPackageType.ITEM_PACKAGE);
        }

        return keywordPackageRecommendRequest;
    }

    private KeywordRecommendRequest initKeywordRecommendRequest(DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO){
        KeywordRecommendRequest keywordRecommendRequest = new KeywordRecommendRequest();
        keywordRecommendRequest.setKeyword(dmpArgusEstimateViewDTO.getKeyword());
        keywordRecommendRequest.setBrandId(dmpArgusEstimateViewDTO.getBrandId());
        keywordRecommendRequest.setMemberId(dmpArgusEstimateViewDTO.getMemberId());
        if(dmpArgusEstimateViewDTO.getKeywordClassification() != null){
            if(KeywordClassificationEnum.BRAND.getCode().equals(dmpArgusEstimateViewDTO.getKeywordClassification())){
                keywordRecommendRequest.setRecommendKWType(RecommendKWType.BRAND_SPECIAL_WORD);
            }else if (KeywordClassificationEnum.COMPETITIVE_PRODUCT.getCode().equals(dmpArgusEstimateViewDTO.getKeywordClassification())){
                keywordRecommendRequest.setRecommendKWType(RecommendKWType.COMPETITIVE_WORD);
            }else if (KeywordClassificationEnum.CATEGORY_PENETRATION.getCode().equals(dmpArgusEstimateViewDTO.getKeywordClassification())){
                keywordRecommendRequest.setRecommendKWType(RecommendKWType.CATEGORY_PENETRATE);
            }
        }
        if(dmpArgusEstimateViewDTO.getKeywordAssociateMethod() != null){
            if(KeywordAssociateMethodEnum.BRAND_ASSOCIATE.getCode().equals(dmpArgusEstimateViewDTO.getKeywordAssociateMethod())){
                keywordRecommendRequest.setRcmdRelevanceType(RcmdRelevanceType.BRAND_RELEVANCE);
            }else if (KeywordAssociateMethodEnum.KEYWORD_ASSOCIATE.getCode().equals(dmpArgusEstimateViewDTO.getKeywordAssociateMethod())){
                keywordRecommendRequest.setRcmdRelevanceType(RcmdRelevanceType.KEYWORD_RELEVANCE);
            }else{
                keywordRecommendRequest.setRcmdRelevanceType(RcmdRelevanceType.ITEM_RELEVANCE);
            }
        }
        keywordRecommendRequest.setKwSearchType(KwSearchType.CENTER_MATCH);

        return keywordRecommendRequest;
    }

    private CampaignKeywordEstimateViewDTO buildKeywordEstimateResultViewDTO(KeywordEffectEstimateResponse estimateResponse){
        if(estimateResponse == null){
            return null;
        }
        List<KWEstimateElem> kwEstimateElemList = estimateResponse.getKwEstimateElemList();
        KWEstimateScope kwEstimateScope = estimateResponse.getKwEstimateScope();
        if(CollectionUtils.isEmpty(kwEstimateElemList)){
            return null;
        }
        CampaignKeywordEstimateViewDTO estimateViewDTO = new CampaignKeywordEstimateViewDTO();
        List<CampaignWordViewDTO> campaignWordViewDTOList = Lists.newArrayList();
        if(CollectionUtils.isNotEmpty(kwEstimateElemList)){
            for(KWEstimateElem kwEstimateElem : kwEstimateElemList) {
                CampaignWordViewDTO keywordViewDTO = new CampaignWordViewDTO();
                keywordViewDTO.setWord(kwEstimateElem.getKeyword());
                keywordViewDTO.setDayPerPv(kwEstimateElem.getPv());
                keywordViewDTO.setCtr(kwEstimateElem.getInteractionIndex());
                keywordViewDTO.setMatchScope(BrandKeywordMatchScopeEnum.PHRASE_MATCH.getCode());
                campaignWordViewDTOList.add(keywordViewDTO);
            }
            CampaignKeywordViewDTO campaignKeywordViewDTO = new CampaignKeywordViewDTO();
            campaignKeywordViewDTO.setCampaignWordViewDTOList(campaignWordViewDTOList);
            estimateViewDTO.setKeywordViewDTO(campaignKeywordViewDTO);
        }
        if(kwEstimateScope != null){
            estimateViewDTO.setMinDayPerPv(kwEstimateScope.getMinPv());
            estimateViewDTO.setMaxDayPerPv(kwEstimateScope.getMaxPv());
        }
        return estimateViewDTO;
    }

    private CampaignWordPackageViewDTO buildWordPackageEstimateResultViewDTO(KeywordPackageRecommendResponse estimateResponse){
        if(estimateResponse == null){
            return null;
        }
        List<KeywordPackage> keywordPackageList = estimateResponse.getKeywordPackageList();
        if(CollectionUtils.isEmpty(keywordPackageList)){
            return null;
        }
        KeywordPackage keywordPackage = keywordPackageList.get(0);
        CampaignWordPackageViewDTO estimateViewDTO = new CampaignWordPackageViewDTO();
        estimateViewDTO.setAlgoPackageId(keywordPackage.getPackageId());
        estimateViewDTO.setDayPerPv(keywordPackage.getSumPv());
        estimateViewDTO.setCtr(keywordPackage.getSearchIndex());
        return estimateViewDTO;
    }


    private List<CampaignWordViewDTO> buildKeywordRecommendResultViewDTO(KeywordRecommendResponse estimateResponse){
        if(estimateResponse == null){
            return null;
        }
        List<KWEstimateElem> kwEstimateElemList = estimateResponse.getKwEstimateElemList();

        List<CampaignWordViewDTO> campaignWordViewDTOList = Lists.newArrayList();
        if(CollectionUtils.isNotEmpty(kwEstimateElemList)){
            for(KWEstimateElem kwEstimateElem : kwEstimateElemList) {
                CampaignWordViewDTO keywordViewDTO = new CampaignWordViewDTO();
                keywordViewDTO.setWord(kwEstimateElem.getKeyword());
                keywordViewDTO.setDayPerPv(kwEstimateElem.getPv());
                keywordViewDTO.setMatchScope(BrandKeywordMatchScopeEnum.PHRASE_MATCH.getCode());
                keywordViewDTO.setCtr(kwEstimateElem.getInteractionIndex());
                campaignWordViewDTOList.add(keywordViewDTO);
            }
        }
        return campaignWordViewDTOList;
    }

    private TianGongRcmdRequest initDoohEstimateRequest(DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO){
        RogerLogger.info("initDoohEstimateRequest.dmpArgusEstimateViewDTO:{}", JSON.toJSONString(dmpArgusEstimateViewDTO));
        CampaignViewDTO campaignViewDTO = dmpArgusEstimateViewDTO.getCampaignViewDTO();
        //点位列表
        List<DoohStrategyPointViewDTO> doohStrategyPointViewDTOList = dmpArgusEstimateViewDTO.getDoohStrategyPointViewDTOList();
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(doohStrategyPointViewDTOList), "点位列表不能为空");
        //策略详情
        DoohStrategyViewDTO strategyViewDTO = dmpArgusEstimateViewDTO.getDoohStrategyViewDTO();
        AssertUtil.assertTrue(strategyViewDTO != null, "策略详情不能为空");
        //计划对应的定向列表
        List<CampaignShowConfigViewDTO> campaignShowConfigViewDTOList = dmpArgusEstimateViewDTO.getCampaignShowConfigViewDTOList();
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(campaignShowConfigViewDTOList), "计划定向不能为空");
        //全部户外屏场景列表
        Map<String, String> deviceTypeMap = Maps.newHashMap();
        //全部极速达行业列表
        Map<String, String> industryMap = Maps.newHashMap();
        //全部极速达优选列表
        Map<String, String> optimizedMap = Maps.newHashMap();
        //地域定向列表
        List<TreeNodeViewDTO> areaList = Lists.newArrayList();

        //填充各个定向全集
        for(CampaignShowConfigViewDTO showConfigViewDTO : campaignShowConfigViewDTOList){
            BrandTargetTypeEnum targetTypeEnum = StringUtils.isNotBlank(showConfigViewDTO.getType()) ? BrandTargetTypeEnum.getByKey(showConfigViewDTO.getType()) : null;
            if (targetTypeEnum == null || CollectionUtils.isEmpty(showConfigViewDTO.getConfigs())){
                continue;
            }
            //行业定向
            if (targetTypeEnum == BrandTargetTypeEnum.OOH_JSD_INDUSTRY) {
                industryMap = showConfigViewDTO.getConfigs().stream().collect(Collectors.toMap(TreeNodeViewDTO::getValue, TreeNodeViewDTO::getName));
            }
            //户外屏资源场景定向
            if (targetTypeEnum == BrandTargetTypeEnum.DOOH_DEVICE_TYPE) {
                deviceTypeMap = showConfigViewDTO.getConfigs().stream().collect(Collectors.toMap(TreeNodeViewDTO::getValue, TreeNodeViewDTO::getName));
            }
            //优选定向
            if (targetTypeEnum == BrandTargetTypeEnum.OOH_JSD_OPTIMIZED){
                optimizedMap = showConfigViewDTO.getConfigs().stream().collect(Collectors.toMap(TreeNodeViewDTO::getValue, TreeNodeViewDTO::getName));
            }
            //地域定向
            if(targetTypeEnum == BrandTargetTypeEnum.AREA){
                //只取市级
                areaList = showConfigViewDTO.getConfigs().stream().filter(e->CollectionUtils.isNotEmpty(e.getChildren())).flatMap(it -> it.getChildren().stream()).filter(it->CollectionUtils.isNotEmpty(it.getChildren())).flatMap(it->it.getChildren().stream()).collect(Collectors.toList());
            }
        }


        AssertUtil.assertTrue(strategyViewDTO != null && CollectionUtils.isNotEmpty(strategyViewDTO.getPointSourceList()), "策略点位不能为空");
        List<DoohPointSourceViewDTO> pointSourceList = strategyViewDTO.getPointSourceList().stream().filter(e->DoohStrategyPointSourceEnum.RECOMMEND.getCode().equals(e.getId())).collect(Collectors.toList());
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(pointSourceList), "策略点位不能为空");
        Map<Integer, DoohPointClassificationViewDTO> pointClassificationMap = pointSourceList.get(0).getPointClassificationList().stream().collect(Collectors.toMap(DoohPointClassificationViewDTO::getId, e->e));

        List<String> currDoohIndustryIdList = Lists.newArrayList();
        List<String> currDeviceTypeIdList = Lists.newArrayList();
        List<String> currOptimizedIdList = Lists.newArrayList();
        CampaignTargetScenarioViewDTO campaignTargetScenarioViewDTO = campaignViewDTO.getCampaignTargetScenarioViewDTO();
        if (campaignTargetScenarioViewDTO != null && CollectionUtils.isNotEmpty(campaignTargetScenarioViewDTO.getCampaignTargetViewDTOList())) {
            for (CampaignTargetViewDTO targetViewDTO : campaignTargetScenarioViewDTO.getCampaignTargetViewDTOList()) {
                BrandTargetTypeEnum targetTypeEnum = StringUtils.isNotBlank(targetViewDTO.getType()) ? BrandTargetTypeEnum.getByCode(Integer.parseInt(targetViewDTO.getType())) : null;
                if (targetTypeEnum == null){
                    continue;
                }
                //行业定向
                if (targetTypeEnum == BrandTargetTypeEnum.OOH_JSD_INDUSTRY) {
                    currDoohIndustryIdList.addAll(targetViewDTO.getTargetValues());
                }
                //户外屏资源场景定向
                if (targetTypeEnum == BrandTargetTypeEnum.DOOH_DEVICE_TYPE) {
                    currDeviceTypeIdList.addAll(targetViewDTO.getTargetValues());
                }
                //优选定向
                if (targetTypeEnum == BrandTargetTypeEnum.OOH_JSD_OPTIMIZED){
                    currOptimizedIdList.addAll(targetViewDTO.getTargetValues());
                }
            }
        }

        //组装
        TianGongRcmdRequest tianGongRcmdRequest = new TianGongRcmdRequest();
        tianGongRcmdRequest.setCate(industryMap.get(currDoohIndustryIdList.get(0)));

        List<PuttingInfo> puttingInfoList = Lists.newArrayList();
        for(DoohStrategyPointViewDTO point : doohStrategyPointViewDTOList){
            PuttingInfo puttingInfo = new PuttingInfo();
            puttingInfo.setName(point.getName());
            puttingInfo.setAddress(point.getAddress());
            if(point.getTgi() != null){
                puttingInfo.setTgi(point.getTgi().doubleValue());
            }
            puttingInfo.setResourceScene(deviceTypeMap.get(String.valueOf(point.getDeviceType())));
            puttingInfoList.add(puttingInfo);
        }
        tianGongRcmdRequest.setPuttingInfoList(puttingInfoList);

        List<TianGongPuttingPlan> puttingPlanList = Lists.newArrayList();
        for(Map.Entry<String, String> optimized : optimizedMap.entrySet()){
            TianGongPuttingPlan puttingPlan = new TianGongPuttingPlan();
            puttingPlan.setName(optimized.getValue());
            if(currOptimizedIdList.contains(optimized.getKey())){
                puttingPlan.setIsChoose(true);
            }else{
                puttingPlan.setIsChoose(false);
            }
            puttingPlanList.add(puttingPlan);
        }
        tianGongRcmdRequest.setPuttingPlan(puttingPlanList);

        List<MediaType> mediaCountList = Lists.newArrayList();
        for(Map.Entry<String, String> deviceType : deviceTypeMap.entrySet()){
            MediaType mediaType = new MediaType();
            mediaType.setId(Integer.valueOf(deviceType.getKey()));
            mediaType.setName(deviceType.getValue());
            if(pointClassificationMap.containsKey(mediaType.getId())){
                mediaType.setNum(pointClassificationMap.get(mediaType.getId()).getPointCount());
            }else{
                mediaType.setNum(0);
            }
            mediaCountList.add(mediaType);
        }
        tianGongRcmdRequest.setMediaCountMap(mediaCountList);
        tianGongRcmdRequest.setPuttingCityList(areaList.stream().map(TreeNodeViewDTO::getName).collect(Collectors.toList()));
        RogerLogger.info("initDoohEstimateRequest.tianGongRcmdRequest:{}", JSON.toJSONString(tianGongRcmdRequest));
        return tianGongRcmdRequest;
    }

    private DoohStrategyRecommendReasonViewDTO buildDoohEstimateResultViewDTO(TianGongRcmdResponse estimateResponse){
        if(estimateResponse == null || estimateResponse.getRecommendedStrategy().isEmpty()){
            return null;
        }
        Map<TiangongStrategyType, String> recommendedStrategyMap = estimateResponse.getRecommendedStrategy();
        DoohStrategyRecommendReasonViewDTO doohStrategyRecommendReasonViewDTO = new DoohStrategyRecommendReasonViewDTO();
        doohStrategyRecommendReasonViewDTO.setSummary(recommendedStrategyMap.get(TiangongStrategyType.PROJECT_STRATEGY_OUTLINE));
        doohStrategyRecommendReasonViewDTO.setOptimizateSuggestion(recommendedStrategyMap.get(TiangongStrategyType.TARGET_OPTIMIZE_SUGGESTION));
        doohStrategyRecommendReasonViewDTO.setRecommendedReason(recommendedStrategyMap.get(TiangongStrategyType.POINT_RECOMMEND_REASON));
        return doohStrategyRecommendReasonViewDTO;
    }
}
