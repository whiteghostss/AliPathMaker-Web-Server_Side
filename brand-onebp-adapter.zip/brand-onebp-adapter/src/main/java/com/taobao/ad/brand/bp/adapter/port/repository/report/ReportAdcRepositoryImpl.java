package com.taobao.ad.brand.bp.adapter.port.repository.report;

import com.alibaba.abf.governance.context.ServiceContext;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.report.ReportDimensionConfigViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportFunctionConfigViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportMetricsConfigViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.query.ReportQueryViewDTO;
import com.taobao.ad.brand.bp.common.spi.ExtensionPointsFactory;
import com.taobao.ad.brand.bp.domain.report.constant.ReportAdcBizCodeConstant;
import com.taobao.ad.brand.bp.domain.report.repository.ReportAdcRepository;
import com.taobao.ad.brand.bp.domain.report.spi.report.adc.BizReportAdcSpi;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * 报表Adc相关服务
 * @author yuncheng.lyc
 * @date 2023/3/23
 **/
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ReportAdcRepositoryImpl implements ReportAdcRepository {

    private String getReportAdcSpiBizCode(ServiceContext context, ReportQueryViewDTO queryViewDTO){
        List<String> functionCodes = Lists.newArrayList("mRptMultiCustom");
        if(functionCodes.contains(queryViewDTO.getFunctionCode())){
            return ReportAdcBizCodeConstant.DIMENSION_AUTO;
        }
        return queryViewDTO.getFunctionCode();
    }

    @Override
    public ReportFunctionConfigViewDTO findFunctionConfig(ServiceContext context, ReportQueryViewDTO queryViewDTO){
        return ExtensionPointsFactory.runAbilitySpi(BizReportAdcSpi.class, extension->extension.findFunctionConfig(context, queryViewDTO), getReportAdcSpiBizCode(context, queryViewDTO));
    }

    @Override
    public Map<String, ReportDimensionConfigViewDTO> findDimensionConfigMap(ServiceContext context, ReportQueryViewDTO queryViewDTO){
        return ExtensionPointsFactory.runAbilitySpi(BizReportAdcSpi.class, extension->extension.findDimensionConfigMap(context, queryViewDTO), getReportAdcSpiBizCode(context, queryViewDTO));
    }

    @Override
    public ReportDimensionConfigViewDTO findDimensionConfig(ServiceContext context, ReportQueryViewDTO queryViewDTO) {
        return ExtensionPointsFactory.runAbilitySpi(BizReportAdcSpi.class, extension->extension.findDimensionConfig(context, queryViewDTO), getReportAdcSpiBizCode(context, queryViewDTO));
    }

    @Override
    public Map<String, List<ReportMetricsConfigViewDTO>> findMetricsConfigMap(ServiceContext context, ReportQueryViewDTO queryViewDTO){
        return ExtensionPointsFactory.runAbilitySpi(BizReportAdcSpi.class, extension->extension.findMetricsConfigMap(context, queryViewDTO), getReportAdcSpiBizCode(context, queryViewDTO));
    }


    @Override
    public List<ReportMetricsConfigViewDTO> findMetricsConfig(ServiceContext context, ReportQueryViewDTO queryViewDTO) {
        return ExtensionPointsFactory.runAbilitySpi(BizReportAdcSpi.class, extension->extension.findMetricsConfig(context, queryViewDTO), getReportAdcSpiBizCode(context, queryViewDTO));
    }

    @Override
    public String findAdcAdrApiConfig(ServiceContext context, ReportQueryViewDTO queryViewDTO) {
        return ExtensionPointsFactory.runAbilitySpi(BizReportAdcSpi.class, extension->extension.findAdcAdrApiConfig(context, queryViewDTO), getReportAdcSpiBizCode(context, queryViewDTO));
    }


}
