package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.qualification;

import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.simba.qualification.api.QualificationBizService;
import com.taobao.simba.qualification.api.common.QualificationConstant;
import com.taobao.simba.qualification.api.common.Result;
import com.taobao.simba.qualification.api.dataobject.biz.QualificationQueryResultDTO;
import com.taobao.simba.qualification.api.dataobject.biz.QualificationTypeNewDTO;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class QualificationSAO extends BaseSAO {

    private final QualificationBizService qualificationBizService;

    public List<QualificationTypeNewDTO> findQualificationTypeList(){
        Result<List<QualificationTypeNewDTO>> response = qualificationBizService.getNewTemplateTypesByProductId(QualificationConstant.PRODUCT_ID_BRAND_ONEBP);
        AssertUtil.assertTrue(response.isOK(), "获取资质类型失败");
        return response.getObj();
    }

    public List<QualificationQueryResultDTO> findQualificationList(Long tbUserId, List<String> qualificationTypeList){
        List<QualificationTypeNewDTO> qualificationTypeNewDTOList = Lists.newArrayList();
        if(CollectionUtils.isEmpty(qualificationTypeList)){
            return Lists.newArrayList();
        }
        for(String qualificationType : qualificationTypeList){
            QualificationTypeNewDTO qualificationTypeNewDTO = new QualificationTypeNewDTO();
            qualificationTypeNewDTO.setTypeName(qualificationType);
            qualificationTypeNewDTOList.add(qualificationTypeNewDTO);
        }
        Result<List<QualificationQueryResultDTO>> response = qualificationBizService.getQualificationList(tbUserId, QualificationConstant.PRODUCT_ID_BRAND_ONEBP, qualificationTypeNewDTOList);
        AssertUtil.assertTrue(response.isOK(), "获取资质列表失败");
        return response.getObj();
    }
}
