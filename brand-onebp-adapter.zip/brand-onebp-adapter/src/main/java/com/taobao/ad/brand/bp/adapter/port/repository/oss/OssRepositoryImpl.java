package com.taobao.ad.brand.bp.adapter.port.repository.oss;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.Objects;

import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.aliyun.oss.HttpMethod;
import com.aliyun.oss.OSS;
import com.aliyun.oss.model.CannedAccessControlList;
import com.aliyun.oss.model.GeneratePresignedUrlRequest;
import com.aliyun.oss.model.OSSObject;
import com.aliyun.oss.model.ObjectMetadata;
import com.taobao.ad.brand.bp.domain.oss.OssRepository;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author jixiu.lj
 * @date 2023/3/20 22:28
 */
@Component
public class OssRepositoryImpl implements OssRepository {

    @Value("${oss.onebp.bucket:brand-onebp}")
    private String ossBucket;

    @Value("${oss.onebp.url}")
    private String ossUrl;

    @Value("${oss.cdn.onebp.url}")
    private String cdnUrl;

    @Value("${oss.onebp.objecturl}")
    private String objectUrl;

    @Autowired
    private OSS ossClient;

    /**
     * 临时链接默认过期时间为2h
     */
    private final static Long EXPIRE_TIME = 2 * 60 * 60 * 1000L;

    /**
     *
     * @param path 文件路径
     * @param fileByte 数据
     * @return
     * 上传并获取CDN链接
     */
    public String uploadWithCDN(String path, byte[] fileByte) {
        // OSS处理
        upload(path, fileByte);
        return cdnUrl + "/" + path;
    }


    /**
     * 上传
     *
     * @param ossPath
     * @param fileByte
     */
    public void upload(String ossPath, byte[] fileByte) {
        upload(ossPath, fileByte, CannedAccessControlList.Private);
    }

    @Override
    public void upload(String originalFileName, String ossPath, byte[] fileByte) {
        upload(originalFileName, ossPath, fileByte, CannedAccessControlList.Private);
    }

    public void upload(String ossPath, byte[] fileByte, CannedAccessControlList accessControl) {
        upload(null, ossPath, fileByte, accessControl);
    }

    /**
     * 下载
     *
     * @param fileName
     * @return
     */
    public byte[] download(String fileName) {
        OSSObject ossObject = ossClient.getObject(ossBucket, fileName);
        if (Objects.isNull(ossObject)) {
            return null;
        }
        InputStream bis = ossObject.getObjectContent();
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            IOUtils.copy(bis, bos);
        } catch (IOException e) {
            RogerLogger.error("OSS download failed with fileName {} | {}", fileName, e);
        }
        return bos.toByteArray();
    }

    @Override
    public byte[] download(URL url) {
        OSSObject ossObject = ossClient.getObject(url, new HashMap<>());
        if (Objects.isNull(ossObject)) {
            return null;
        }
        InputStream bis = ossObject.getObjectContent();
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            IOUtils.copy(bis, bos);
        } catch (IOException e) {
            RogerLogger.error("OSS download failed with url {}, error {}", url, e.getMessage(), e);
            throw new RuntimeException(e);
        }
        return bos.toByteArray();
    }

    /**
     * 文件是否存在
     *
     * @param fileName
     * @return
     */
    public boolean exists(String fileName) {
        OSSObject ossObject = ossClient.getObject(ossBucket, fileName);
        return !Objects.isNull(ossObject);
    }

    /**
     * 删除文件
     *
     * @param fileName
     * @return
     */
    public boolean delete(String fileName) {
        ossClient.deleteObject(ossBucket, fileName);
        return true;
    }

    /**
     * 生成OSS可访问的短期公共链接（签名所需授权ak是业务方自行申请的oss bucket）
     *
     * @param fileName
     * @param expireTime 秒
     * @return
     */
    @Override
    public String getTemporaryDownloadUrl(String fileName, Long expireTime) {
        Date expiration = expireTime == null ? new Date(System.currentTimeMillis() + EXPIRE_TIME) : new Date(System.currentTimeMillis() + expireTime);
        GeneratePresignedUrlRequest request = new GeneratePresignedUrlRequest(ossBucket, fileName, HttpMethod.GET);
        //设置过期时间
        request.setExpiration(expiration);
        // 生成URL签名(HTTP GET请求)
        URL url = ossClient.generatePresignedUrl(request);
        // 执行endpoint域名替换
        String rawOssUrl = url.toString();
        return rawOssUrl.replaceAll(objectUrl, ossUrl);
    }

    public String getTemporaryDownloadUrl(String fileName) {
        return getTemporaryDownloadUrl(fileName, EXPIRE_TIME);
    }

    private void upload(String originalFileName, String ossPath, byte[] fileByte, CannedAccessControlList aclMode) {
        try (InputStream inputStream = new ByteArrayInputStream(fileByte)) {
            ObjectMetadata meta = new ObjectMetadata();
            meta.setObjectAcl(aclMode);
            if (StringUtils.isNotBlank(originalFileName)) {
                try {
                    // 设置内容被下载时的名称
                    meta.setContentDisposition("attachement; fileName*=UTF-8''" + URLEncoder.encode(originalFileName, "UTF-8"));
                } catch (UnsupportedEncodingException e) {
                    throw new RuntimeException(e);
                }
            }
            ossClient.putObject(ossBucket, ossPath, inputStream, meta);
        } catch (Exception e) {
            RogerLogger.error("oss 上传失败 filename {}, {}", originalFileName, e);
            throw new RuntimeException(e);
        }
    }
}