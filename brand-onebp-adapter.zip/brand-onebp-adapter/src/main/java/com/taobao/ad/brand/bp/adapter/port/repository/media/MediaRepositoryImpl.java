package com.taobao.ad.brand.bp.adapter.port.repository.media;

import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.media.MediaSAO;
import com.taobao.ad.brand.bp.client.dto.media.MediaBusinessManagerViewDTO;
import com.taobao.ad.brand.bp.client.dto.media.MediaContactViewDTO;
import com.taobao.ad.brand.bp.client.dto.media.MediaViewDTO;
import com.taobao.ad.brand.bp.domain.media.MediaRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/4/4 22:00
 * @description ：
 * @modified By：
 */

@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class MediaRepositoryImpl implements MediaRepository {

    private final MediaSAO mediaSAO;

    @Override
    public List<MediaViewDTO> queryMediaListBySiteIds(List<Long> siteIds) {
        return mediaSAO.queryMediaListBySiteIds(siteIds);
    }

    @Override
    public List<MediaViewDTO> queryMediaListByMediaIds(List<Long> mediaIds) {
        if(CollectionUtils.isEmpty(mediaIds)){
            return Lists.newArrayList();
        }
        return mediaSAO.queryMediaListByMediaIds(mediaIds);
    }

    @Override
    public Map<Long, MediaViewDTO> queryMediaMapByMediaIds(List<Long> mediaIds) {
        List<MediaViewDTO> mediaViewDTOS = queryMediaListByMediaIds(mediaIds);
        return mediaViewDTOS.stream().collect(Collectors.toMap(m->m.getId(), m->m));
    }


    @Override
    public List<MediaContactViewDTO> getMediaContractorList(List<Long> mediaIds) {
        return mediaSAO.queryMediaContactList(mediaIds);
    }
    @Override
    public List<MediaBusinessManagerViewDTO> getMediaBusinessManagerList(List<Long> mediaIds) {
        return mediaSAO.queryMediaBusinessManagerByMediaIds(mediaIds);
    }

    @Override
    public List<MediaViewDTO> queryMediaWithSettingByMediaIds(List<Long> mediaIds) {
        return mediaSAO.queryMediaWithSettingByMediaIds(mediaIds);
    }

}
