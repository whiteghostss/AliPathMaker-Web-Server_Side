package com.taobao.ad.brand.bp.adapter.port.converter.resourcepackage;

import com.alibaba.ad.nb.packages.dto.project.ProjectDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.resourcepackage.mapstruct.ResourcePackageProjectMapStruct;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProjectViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.springframework.stereotype.Component;

/**
 * @author yanjingang
 * @date 2024/03/25
 */
@Component
public class ResourcePackageProjectConverter extends BaseViewDTOConverter<ProjectDTO, ResourcePackageProjectViewDTO> {

    @Override
    public BaseMapStructMapper<ProjectDTO, ResourcePackageProjectViewDTO> getBaseMapStructMapper() {
        return ResourcePackageProjectMapStruct.INSTANCE;
    }
}
