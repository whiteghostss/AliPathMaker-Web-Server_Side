package com.taobao.ad.brand.bp.adapter.port.converter.sales;

import com.alibaba.ad.nb.sales.dto.contract.ContractMemberInfo;
import com.alibaba.solar.libra.client.dto.ContractVersionDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.sales.mapstruct.ContractMapStruct;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupCustomerMemberViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesContractViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;

import org.springframework.stereotype.Component;

/**
 * @author yanjingang
 * @date 2023/3/16
 */
@Component
public class ContractViewDTOConverter extends BaseViewDTOConverter<ContractVersionDTO, SalesContractViewDTO> {

    @Override
    public BaseMapStructMapper<ContractVersionDTO, SalesContractViewDTO> getBaseMapStructMapper() {
        return ContractMapStruct.INSTANCE;
    }

    public ContractMemberInfo convertMemberViewDTO(CampaignGroupCustomerMemberViewDTO campaignGroupCustomerMemberViewDTO) {
        if (campaignGroupCustomerMemberViewDTO == null) {
            return null;
        }
        ContractMemberInfo memberInfo = new ContractMemberInfo();
        memberInfo.setMemberId(campaignGroupCustomerMemberViewDTO.getMemberId());
        memberInfo.setCustomerMemberId(campaignGroupCustomerMemberViewDTO.getCustomerMemberId());
        memberInfo.setMemberIdType(campaignGroupCustomerMemberViewDTO.getMemberType());
        return memberInfo;
    }
}
