package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.agreement;

import com.alibaba.aecp.logic.model.ActionResult;
import com.alibaba.fastjson.JSON;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.alibaba.legal.agreement.api.AgreementOpenApi;
import com.alibaba.legal.agreement.dto.AgreementSignResultDto;
import com.alibaba.legal.agreement.dto.AgreementSignerFactSyncMsgDto;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.client.dto.account.agreement.AgreementSignRequestViewDTO;

import lombok.RequiredArgsConstructor;

/**
 * @author 虫洞 <liuming.liu@alibaba-inc.com>
 * @date 2023/3/24
 */
@BizTunnel
@RequiredArgsConstructor
public class AgreementSAO extends BaseSAO {
    private final AgreementOpenApi agreementOpenApi;

    /**
     * 回流协议签署数据，拿到历史签署链接等
     *
     * @param signRequest 协议签署请求信息
     * @return
     */
    public AgreementSignResultDto syncAgreementSignInfo(AgreementSignRequestViewDTO signRequest) {
        RogerLogger.info("AgreementSAO.syncAgreementSignInfo, signRequest={}", signRequest);

        AgreementSignerFactSyncMsgDto syncMsgDto = new AgreementSignerFactSyncMsgDto();
        syncMsgDto.setSignedSystemCode(signRequest.getSignedSystemCode());
        syncMsgDto.setSignedUserType(signRequest.getSignedUserType());
        syncMsgDto.setSignedUserId(signRequest.getSignedUserId());
        syncMsgDto.setSignedTime(signRequest.getSignedTime());
        ActionResult<AgreementSignResultDto> result = agreementOpenApi.getHisAgreementLink(signRequest.getAgreementUrl(), syncMsgDto);

        RogerLogger.info("agreementOpenApi.getHisAgreementLink, syncMsgDto={}, result={}", JSON.toJSONString(syncMsgDto), JSON.toJSONString(result));
        if (result.isSuccess()) {
            return result.getContent();
        }
        throw new RuntimeException("执行合同协议签署失败");
    }
}
