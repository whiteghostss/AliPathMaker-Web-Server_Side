package com.taobao.ad.brand.bp.adapter.port.converter.report.mapstruct;

import com.alibaba.ad.nb.task.client.constant.async.AsyncTaskTypeEnum;
import com.alibaba.ad.nb.task.client.dto.async.AsyncTaskQueryDTO;
import com.taobao.ad.brand.bp.client.dto.report.query.ReportTaskQueryViewDTO;
import com.taobao.ad.brand.bp.common.constant.CampaignConstant;
import com.taobao.ad.brand.bp.common.constant.ReportConstant;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

/**
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ReportTaskQueryViewDTOMapStruct extends BaseMapStructMapper<AsyncTaskQueryDTO, ReportTaskQueryViewDTO> {

    ReportTaskQueryViewDTOMapStruct INSTANCE = Mappers.getMapper(ReportTaskQueryViewDTOMapStruct.class);


    @Mappings({
            @Mapping(target = "id",source = "taskId"),
            @Mapping(target = "ids",source = "taskIds"),
            @Mapping(target = "name",source = "taskName"),
            @Mapping(target = "abilityCode",expression = "java(com.alibaba.ad.biz.definition.constants.BizCodeEnum.BRANDAD.getBizCode())"),
            @Mapping(target = "bizId",source = "memberId"),
            @Mapping(target = "bizType",expression = "java(com.alibaba.ad.nb.task.client.constant.async.AsyncTaskBizTypeEnum.MEMBER.getValue())"),
            @Mapping(target = "subBizId",source = "campaignGroupId"),
//            @Mapping(target = "subBizType",expression = "java(com.alibaba.ad.nb.task.client.constant.async.AsyncTaskSubBizTypeEnum.BRAND_ONE_BP_CAMPAIGN_GROUP.getValue())"),
            @Mapping(target = "type",source = "functionCode", qualifiedByName = "parse2Type"),
    })
    @Override
    AsyncTaskQueryDTO targetToSource(ReportTaskQueryViewDTO viewDTO);


    @Named("parse2Type")
    default Integer parse2Type(String functionCode){
        switch (functionCode) {
            case "mRptMultiCustom":
                return AsyncTaskTypeEnum.BRAND_ONE_BP_MULTI_REPORT.getValue();
            case "mRptMultiPromotion":
                return AsyncTaskTypeEnum.BRAND_ONE_BP_PROMOTION_REPORT.getValue();
            case "mRptMultiLive":
                return AsyncTaskTypeEnum.BRAND_ONE_BP_LIVE_REPORT.getValue();
            case "campaignBatchInsert":
                return AsyncTaskTypeEnum.BRAND_ONE_BP_CAMPAIGN_BATCH_INSERT.getValue();
            case "batchImportCampaignBookingAmount":
                return AsyncTaskTypeEnum.BRAND_ONE_BP_CAMPAIGN_BOOKING_AMOUNT_BATCH_UPDATE.getValue();
            case "adgroupBatchMonitorUpdate":
                return AsyncTaskTypeEnum.BRAND_ONE_BP_ADGROUP_MONITOR_BATCH_UPDATE.getValue();
            case "contentMediaPush":
                return AsyncTaskTypeEnum.BRAND_ONE_BP_CONTENT_REPORT.getValue();
            case "mRptMultiCommon":
                return AsyncTaskTypeEnum.BRAND_ONE_BP_COMMON_REPORT.getValue();
            case "creativeBatchUpdate":
                return AsyncTaskTypeEnum.BRAND_ONE_BP_CREATIVE_BATCH_UPDATE.getValue();
            default:
                return null;
        }
    }


}
