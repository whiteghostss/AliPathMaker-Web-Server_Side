package com.taobao.ad.brand.bp.adapter.port.converter.brand.mapstruct;

import com.alibaba.ad.brand.dto.common.BrandViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.brand.domain.Brand;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface BrandViewDTOMapStruct extends BaseMapStructMapper<Brand, BrandViewDTO> {

    BrandViewDTOMapStruct INSTANCE = Mappers.getMapper(BrandViewDTOMapStruct.class);
    @Override
    BrandViewDTO sourceToTarget(Brand brand);
}
