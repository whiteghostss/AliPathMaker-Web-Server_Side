package com.taobao.ad.brand.bp.adapter.port.converter.materialrule;

import com.alibaba.ad.nb.ssp.dto.material.MaterialRuleDetailDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.materialrule.mapstruct.MaterialRuleDetailMapStruct;
import com.taobao.ad.brand.bp.client.dto.mr.MaterialRuleDetailViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.springframework.stereotype.Component;

/**
 * @author jixiu.lj
 * @date 2023/3/21 11:54
 */
@Component
public class MaterialRuleDetailConverter extends BaseViewDTOConverter<MaterialRuleDetailDTO, MaterialRuleDetailViewDTO> {
    @Override
    public BaseMapStructMapper<MaterialRuleDetailDTO, MaterialRuleDetailViewDTO> getBaseMapStructMapper() {
        return MaterialRuleDetailMapStruct.INSTANCE;
    }
}
