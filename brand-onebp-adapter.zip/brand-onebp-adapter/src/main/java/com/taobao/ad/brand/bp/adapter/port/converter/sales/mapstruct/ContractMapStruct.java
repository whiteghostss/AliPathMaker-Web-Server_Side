package com.taobao.ad.brand.bp.adapter.port.converter.sales.mapstruct;

import com.alibaba.solar.libra.client.dto.ContractVersionDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesContractViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.DecoratedWith;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author yanjingang
 * @date 2023/03/23
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
@DecoratedWith(ContractMapStructDecorator.class)
public interface ContractMapStruct extends BaseMapStructMapper<ContractVersionDTO, SalesContractViewDTO> {
    ContractMapStruct INSTANCE = Mappers.getMapper(ContractMapStruct.class);

}