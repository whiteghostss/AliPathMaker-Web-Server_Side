package com.taobao.ad.brand.bp.adapter.port.repository.brand;

import com.alibaba.ad.brand.dto.common.BrandViewDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.adapter.port.converter.brand.BrandViewDTOConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.brand.BrandSAO;
import com.taobao.ad.brand.bp.domain.brand.BrandRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Objects;

/**
 * 品牌查询服务
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandRepositoryImpl implements BrandRepository {
    private final BrandSAO brandSAO;
    private final BrandViewDTOConverter brandViewDTOConverter;


    @Override
    public List<BrandViewDTO> queryByKeyword(String keyword, Integer limit) {
        if (StringUtils.isBlank(keyword)) {
            return Lists.newArrayList();
        }

        return brandViewDTOConverter.convertDTO2ViewDTOList(brandSAO.findBrandByNameFuzzy(keyword, limit));
    }

    @Override
    public List<BrandViewDTO> queryBrand(List<Long> brandIds) {
        if(CollectionUtils.isEmpty(brandIds)){
            return Lists.newArrayList();
        }

        return brandViewDTOConverter.convertDTO2ViewDTOList(brandSAO.queryBrand(brandIds));
    }

    @Override
    public BrandViewDTO getBrand(Long brandId) {
        if(Objects.isNull(brandId)){
            return null;
        }
        return brandViewDTOConverter.convertDTO2ViewDTO(brandSAO.getBrand(brandId));
    }
}
