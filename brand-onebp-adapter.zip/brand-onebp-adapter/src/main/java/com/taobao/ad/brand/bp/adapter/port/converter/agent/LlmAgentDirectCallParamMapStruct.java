package com.taobao.ad.brand.bp.adapter.port.converter.agent;

import com.alibaba.ad.brand.ai.client.dto.LlmAgentDirectCallParam;
import com.taobao.ad.brand.bp.client.dto.agent.LlmAgentDirectCallParamViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author jixiu.lj
 * @date 2023/3/23 22:29
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface LlmAgentDirectCallParamMapStruct extends BaseMapStructMapper<LlmAgentDirectCallParam, LlmAgentDirectCallParamViewDTO> {

    LlmAgentDirectCallParamMapStruct INSTANCE = Mappers.getMapper(LlmAgentDirectCallParamMapStruct.class);
}
