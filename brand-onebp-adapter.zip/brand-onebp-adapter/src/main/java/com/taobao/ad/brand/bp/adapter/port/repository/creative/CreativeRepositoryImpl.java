package com.taobao.ad.brand.bp.adapter.port.repository.creative;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.adgroup.CreativeRefViewDTO;
import com.alibaba.ad.brand.dto.creative.ContentVersionViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.brand.sdk.convert.custom.viewdto.CreativeRefViewDTO2DTOConvertProcessor;
import com.alibaba.ad.brand.sdk.convert.custom.viewdto.creative.ContentVersionViewDTO2DTOConvertProcessor;
import com.alibaba.ad.brand.sdk.convert.custom.viewdto.creative.CreativeViewDTO2DTOConvertProcessor;
import com.alibaba.ad.creative.consts.order.CreateTimeOrder;
import com.alibaba.ad.creative.consts.order.OrderField;
import com.alibaba.ad.creative.dto.bind.CreativeBindDTO;
import com.alibaba.ad.creative.dto.bind.query.CreativeBindQueryDTO;
import com.alibaba.ad.creative.dto.biz.ud.MediaTmlCreativeDTO;
import com.alibaba.ad.creative.dto.biz.ud.creative.query.MediaTmlCreativeQueryDTO;
import com.alibaba.ad.creative.dto.contentversion.ContentVersionDTO;
import com.alibaba.ad.creative.dto.url.UrlAnalysisResultDTO;
import com.alibaba.ad.creative.query.ContentVersionQuery;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alibaba.ad.universal.sdk.convert.custom.onebp.provider.OneBpConvertProcessorProvider;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.hermes.framework.utils.BeanUtils;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.creative.CreativeSAO;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.ssp.TemplateSAO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeItemBizInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeLandingPageAnalysisViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.MemberPageCheckViewDTO;
import com.taobao.ad.brand.bp.common.threadpooltask.CreativeRefQueryTaskIdentifier;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/3/4 16:19
 * @description ：
 * @modified By：
 */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CreativeRepositoryImpl implements CreativeRepository {

    private final CreativeSAO creativeSAO;
    private final TemplateSAO templateSAO;
    private CreativeViewDTO2DTOConvertProcessor PROCESSOR = OneBpConvertProcessorProvider.getViewDTO2DTOConvertProcessor(CreativeViewDTO2DTOConvertProcessor.class);
    private CreativeRefViewDTO2DTOConvertProcessor creativeRefViewDTO2DTOConvertProcessor = OneBpConvertProcessorProvider.getViewDTO2DTOConvertProcessor(CreativeRefViewDTO2DTOConvertProcessor.class);
    private ContentVersionViewDTO2DTOConvertProcessor contentVersionViewDTO2DTOConvertProcessor = OneBpConvertProcessorProvider.getViewDTO2DTOConvertProcessor(ContentVersionViewDTO2DTOConvertProcessor.class);

    private final CreativeRefQueryTaskIdentifier creativeRefQueryTaskIdentifier;

//    private static final ThreadPoolExecutor THREAD_QUERY_POOL = new ThreadPoolExecutor(
//            20, 20, 60L, TimeUnit.SECONDS, new ArrayBlockingQueue<>(2048),
//            new ThreadFactoryBuilder().setNameFormat("creative_query_repository-%d").build());

    @Override
    public Long addCreative(ServiceContext serviceContext, CreativeViewDTO creativeViewDTO) {
        RogerLogger.info("addCreative,CreativeViewDTO:{}", JSONObject.toJSONString(creativeViewDTO));
        MediaTmlCreativeDTO mediaTmlCreativeDTO = PROCESSOR.viewDTO2DTO(creativeViewDTO);
        RogerLogger.info("addCreative,MediaTmlCreativeDTO:{}", JSONObject.toJSONString(mediaTmlCreativeDTO));
        return creativeSAO.addCreative(serviceContext, mediaTmlCreativeDTO);
    }

    @Override
    public Integer updateCreative(ServiceContext serviceContext, CreativeViewDTO creativeViewDTO) {
        RogerLogger.info("updateCreative,CreativeViewDTO:{}", JSONObject.toJSONString(creativeViewDTO));
        MediaTmlCreativeDTO mediaTmlCreativeDTO = PROCESSOR.viewDTO2DTO(creativeViewDTO);
        RogerLogger.info("updateCreative,MediaTmlCreativeDTO:{}", JSONObject.toJSONString(mediaTmlCreativeDTO));
        return creativeSAO.updateCreative(serviceContext, mediaTmlCreativeDTO);
    }

    @Override
    public Integer updateCreativePart(ServiceContext serviceContext, CreativeViewDTO creativeViewDTO) {
        RogerLogger.info("updateCreativePart,CreativeViewDTO:{}", JSONObject.toJSONString(creativeViewDTO));
        MediaTmlCreativeDTO mediaTmlCreativeDTO = PROCESSOR.viewDTO2DTO(creativeViewDTO);
        RogerLogger.info("updateCreativePart,MediaTmlCreativeDTO:{}", JSONObject.toJSONString(mediaTmlCreativeDTO));
        return creativeSAO.updateCreativePart(serviceContext, mediaTmlCreativeDTO);
    }

    @Override
    public Integer unBindCreative(ServiceContext context, List<Long> adgroupIds, List<Long> creativeIds) {
        if (CollectionUtils.isNotEmpty(adgroupIds) && CollectionUtils.isNotEmpty(creativeIds)){
            return creativeSAO.unBindCreative(context, adgroupIds, creativeIds);
        }
        return 0;
    }

    @Override
    public Integer unBindCreative(ServiceContext serviceContext, List<Long> adgroupIds) {
        if (CollectionUtils.isNotEmpty(adgroupIds)){
            return creativeSAO.unBindCreativeRef(serviceContext, adgroupIds);
        }
        return 0;
    }

    @Override
    public Integer delBindCreative(ServiceContext context, List<Long> creativeIds) {
        if (CollectionUtils.isNotEmpty(creativeIds)){
            return creativeSAO.unBindCreative(context, creativeIds);
        }
        return 0;
    }

    @Override
    public List<CreativeRefViewDTO> addBatchCreativeRef(ServiceContext serviceContext, List<CreativeRefViewDTO> creativeRefViewDTOList) {
        RogerLogger.info("addBatchCreativeRef,creativeRefViewDTOList:{}", JSONObject.toJSONString(creativeRefViewDTOList));
        List<CreativeBindDTO> creativeBindDTOList = creativeRefViewDTO2DTOConvertProcessor.viewDTOList2DTOList(creativeRefViewDTOList);
        RogerLogger.info("addBatchCreativeRefConvert,creativeBindDTOList:{}", JSONObject.toJSONString(creativeRefViewDTOList));
        return creativeRefViewDTO2DTOConvertProcessor.dtoList2ViewDTOList(creativeSAO.addBatchCreativeRef(serviceContext, creativeBindDTOList));
    }

    @Override
    public List<CreativeRefViewDTO> addBatchCreativeRefAndSetting(ServiceContext serviceContext, List<CreativeRefViewDTO> creativeRefViewDTOList) {
        List<CreativeBindDTO> creativeBindDTOList = creativeRefViewDTO2DTOConvertProcessor.viewDTOList2DTOList(creativeRefViewDTOList);
        return creativeRefViewDTO2DTOConvertProcessor.dtoList2ViewDTOList(creativeSAO.addBatchCreativeRefAndSetting(serviceContext, creativeBindDTOList));
    }

    @Override
    public CreativeViewDTO getCreativeById(ServiceContext serviceContext, Long id) {
        MediaTmlCreativeDTO dto = creativeSAO.getCreativeById(serviceContext, id);
        return PROCESSOR.dto2ViewDTO(dto);
    }

    @Override
    public List<CreativeViewDTO> findCreativeByIds(ServiceContext serviceContext, List<Long> ids) {
        if (CollectionUtils.isEmpty(ids)) {
            return Lists.newArrayList();
        }
        List<MediaTmlCreativeDTO> creativeDTOList = creativeSAO.getCreativeByIds(serviceContext, ids);
        return creativeDTOList.stream().map(dto -> PROCESSOR.dto2ViewDTO(dto)).collect(Collectors.toList());
    }

    @Override
    public PageResultViewDTO<CreativeViewDTO> findListWithPage(ServiceContext serviceContext, CreativeQueryViewDTO creativeViewDTO) {
        MediaTmlCreativeQueryDTO mediaTmlCreativeQueryDTO = new MediaTmlCreativeQueryDTO();
        mediaTmlCreativeQueryDTO.setIdList(creativeViewDTO.getIds());
        mediaTmlCreativeQueryDTO.setName(creativeViewDTO.getName());
        mediaTmlCreativeQueryDTO.setTemplateIdList(creativeViewDTO.getSspTemplateIds());
        mediaTmlCreativeQueryDTO.setShowAuditStatusList(creativeViewDTO.getShowAuditStatusList());
        mediaTmlCreativeQueryDTO.setBoundAdgroupStatus(creativeViewDTO.getHadBoundAdgroup());
        mediaTmlCreativeQueryDTO.setResourceType(creativeViewDTO.getResourceType());
        mediaTmlCreativeQueryDTO.setMemberId(serviceContext.getMemberId());
        mediaTmlCreativeQueryDTO.setTargetType(creativeViewDTO.getTargetType());
        mediaTmlCreativeQueryDTO.setProductId(serviceContext.getProductId());
        mediaTmlCreativeQueryDTO.setStartTime(creativeViewDTO.getStartTime());
        mediaTmlCreativeQueryDTO.setLeEndTime(creativeViewDTO.getLeEndTime());
        mediaTmlCreativeQueryDTO.setOnlineStatus(creativeViewDTO.getOnlineStatus());
        mediaTmlCreativeQueryDTO.setLinkageMode(creativeViewDTO.getLinkageMode());
        mediaTmlCreativeQueryDTO.setPackageType(creativeViewDTO.getPackageType());
        mediaTmlCreativeQueryDTO.setCreativePackageIdList(creativeViewDTO.getCreativePackageIdList());
        mediaTmlCreativeQueryDTO.setCreativeIdEqCreativePackageId(creativeViewDTO.getCreativeIdEqCreativePackageId());
        mediaTmlCreativeQueryDTO.setEndTime(creativeViewDTO.getEndTime());
        mediaTmlCreativeQueryDTO.setTopCreative(creativeViewDTO.getIsTop());
        mediaTmlCreativeQueryDTO.setGmtCreateStartTime(creativeViewDTO.getQueryAfterGmtCreateTime());
        mediaTmlCreativeQueryDTO.setGtEndTime(creativeViewDTO.getQueryAfterEndTime());
        mediaTmlCreativeQueryDTO.setCreativeTagIdList(creativeViewDTO.getCreativeTagIdList());
        mediaTmlCreativeQueryDTO.setSkip(creativeViewDTO.getStart());
        mediaTmlCreativeQueryDTO.setLimit(creativeViewDTO.getPageSize());
        OrderField orderField = new CreateTimeOrder(OrderField.OrderType.DESC);
        mediaTmlCreativeQueryDTO.setOrderFields(Collections.singletonList(orderField));
        PageResultViewDTO<MediaTmlCreativeDTO> pageResultViewDTO =
                creativeSAO.findListWithPage(serviceContext, mediaTmlCreativeQueryDTO);
        if (CollectionUtils.isEmpty(pageResultViewDTO.getList())) {
            return PageResultViewDTO.of(Lists.newArrayList(), pageResultViewDTO.getCount());
        }
        List<CreativeViewDTO> viewDTOList = pageResultViewDTO.getList().stream()
                .map(dto -> PROCESSOR.dto2ViewDTO(dto)).collect(Collectors.toList());
        return PageResultViewDTO.of(viewDTOList, pageResultViewDTO.getCount());
    }

    @Override
    public List<CreativeRefViewDTO> findCreativeRefList(ServiceContext serviceContext, CreativeQueryViewDTO queryViewDTO) {
        return this.findCreativeRefList(serviceContext,queryViewDTO,true);
    }

    public List<CreativeRefViewDTO> findCreativeRefList(ServiceContext serviceContext, CreativeQueryViewDTO queryViewDTO, boolean isNeedSetting) {
        long startTime = System.currentTimeMillis();
        int totalCount = creativeSAO.getCreativeBindCount(serviceContext, initCreativeBindQueryDTO(queryViewDTO));
        RogerLogger.info("getCreativeBindCount totalCount = {}", totalCount);
        if(totalCount == 0){
            return Lists.newArrayList();
        }
        int MAX_PAGE_COUNT = 1000;
        List<CreativeRefViewDTO> resultList = Lists.newArrayList();
        if(totalCount > MAX_PAGE_COUNT){
            int frequency = totalCount / MAX_PAGE_COUNT;
            if(totalCount % MAX_PAGE_COUNT != 0){
                frequency++;
            }
            List<CreativeBindQueryDTO> bindQueryDTOList = Lists.newArrayList();
            for(int i =0; i < frequency ; i++){
                CreativeBindQueryDTO creativeBindQueryDTO = initCreativeBindQueryDTO(queryViewDTO);
                creativeBindQueryDTO.setSkip(MAX_PAGE_COUNT * i);
                creativeBindQueryDTO.setLimit(MAX_PAGE_COUNT);
                bindQueryDTOList.add(creativeBindQueryDTO);
            }
            RogerLogger.info("getCreativeBindCount,totalCount={}, threadNum = {}", totalCount,frequency);
            List<List<CreativeRefViewDTO>> creativeList = TaskStream.execute(creativeRefQueryTaskIdentifier, bindQueryDTOList, (creativeBindQueryDTO, index) -> {
                List<CreativeBindDTO> creativeBindPageList = creativeSAO.findCreativeBindPage(serviceContext, creativeBindQueryDTO, isNeedSetting);
                return creativeRefViewDTO2DTOConvertProcessor.dtoList2ViewDTOList(creativeBindPageList);
            }).commit().getResultList();
            resultList = creativeList.stream().filter(Objects::nonNull).flatMap(Collection::stream).collect(Collectors.toList());
        }else{
            CreativeBindQueryDTO creativeBindQueryDTO = initCreativeBindQueryDTO(queryViewDTO);
            creativeBindQueryDTO.setSkip(0);
            creativeBindQueryDTO.setLimit(MAX_PAGE_COUNT);
            List<CreativeBindDTO> creativeBindPageList = creativeSAO.findCreativeBindPage(serviceContext, creativeBindQueryDTO, isNeedSetting);
            resultList = creativeRefViewDTO2DTOConvertProcessor.dtoList2ViewDTOList(creativeBindPageList);
        }
        RogerLogger.info("findCreativeRefList 执行耗时：{}",System.currentTimeMillis() - startTime);
        return resultList;
    }

    /**
     * 构建查询条件
     * @param queryViewDTO
     * @return
     */
    private static CreativeBindQueryDTO initCreativeBindQueryDTO(CreativeQueryViewDTO queryViewDTO) {
        CreativeBindQueryDTO creativeBindQueryDTO = new CreativeBindQueryDTO();
        creativeBindQueryDTO.setCreativeIdList(queryViewDTO.getIds());
        creativeBindQueryDTO.setOnlineStatus(queryViewDTO.getOnlineStatus());
        if (CollectionUtils.isNotEmpty(queryViewDTO.getAdgroupIds())) {
            creativeBindQueryDTO.setAdgroupIdList(queryViewDTO.getAdgroupIds());
        }
        if (CollectionUtils.isNotEmpty(queryViewDTO.getCampaignIds())) {
            creativeBindQueryDTO.setCampaignIdList(queryViewDTO.getCampaignIds());
        }
        return creativeBindQueryDTO;
    }

    @Override
    public void rePushCreativeCenter(ServiceContext serviceContext, List<Long> creativeIdList, String qualifyJson) {
        creativeSAO.rePushCreativeCenter(serviceContext, creativeIdList, qualifyJson);
    }

    @Override
    public Integer calcUpdateAndUpperCreativeQualityInfo(ServiceContext serviceContext, Long creativeId) {
        return creativeSAO.calcUpdateAndUpperCreativeQualityInfo(serviceContext, creativeId);
    }

    @Override
    public List<Long> deleteCreatives(ServiceContext serviceContext, List<Long> creativeIds) {
        return creativeSAO.deleteCreatives(serviceContext, creativeIds);
    }

    @Override
    public CreativeLandingPageAnalysisViewDTO analysisClickUrl(ServiceContext serviceContext, String clickUrl) {
        UrlAnalysisResultDTO urlAnalysisResultDTO = creativeSAO.analysisClickUrl(serviceContext, clickUrl);
        return BeanUtils.copyIgnoreNull(urlAnalysisResultDTO, new CreativeLandingPageAnalysisViewDTO());
    }


    @Override
    public ContentVersionViewDTO getLastContentVersionByContentId(ServiceContext context, Long contentId) {
        ContentVersionDTO contentVersionDTO = creativeSAO.getLastContentVersionByContentId(context, contentId);
        return contentVersionViewDTO2DTOConvertProcessor.dto2ViewDTO(contentVersionDTO);
    }

    @Override
    public ContentVersionViewDTO getContentVersionById(ServiceContext context, Long id) {
        ContentVersionDTO contentVersionDTO = creativeSAO.getContentVersionById(context, id);
        return contentVersionViewDTO2DTOConvertProcessor.dto2ViewDTO(contentVersionDTO);
    }

    @Override
    public List<ContentVersionViewDTO> findContentVersionList(ServiceContext context, ContentVersionQuery contentVersionQuery) {
        List<ContentVersionDTO> contentVersionDTOS = creativeSAO.findContentVersionList(context, contentVersionQuery);
        return contentVersionViewDTO2DTOConvertProcessor.dtoList2ViewDTOList(contentVersionDTOS);
    }

    @Override
    public ContentVersionViewDTO addContentVersion(ServiceContext context, ContentVersionViewDTO contentVersionViewDTO) {
        ContentVersionDTO contentVersionDTO = creativeSAO.addContentVersion(context,
                contentVersionViewDTO2DTOConvertProcessor.viewDTO2DTO(contentVersionViewDTO));
        return contentVersionViewDTO2DTOConvertProcessor.dto2ViewDTO(contentVersionDTO);
    }

    @Override
    public void syncItemBizInfo(ServiceContext context, CreativeItemBizInfoViewDTO creativeItemBizInfoViewDTO) {
        // 特秀一键加购业务
        creativeItemBizInfoViewDTO.setBizType(2);
        creativeSAO.syncItemBizInfo(context, creativeItemBizInfoViewDTO);
    }

    @Override
    public List<CreativeViewDTO> findListByMaterialGroupId(ServiceContext serviceContext, Long materialGroupId) {
        List<MediaTmlCreativeDTO> creativeDTOList = creativeSAO.findListByMaterialGroupId(serviceContext, materialGroupId);
        return PROCESSOR.dtoList2ViewDTOList(creativeDTOList);
    }

    @Override
    public List<CreativeViewDTO> findTopShowLiveCreativeList(ServiceContext serviceContext) {
        CreativeQueryViewDTO creativeQueryViewDTO = new CreativeQueryViewDTO();
        creativeQueryViewDTO.setSspTemplateIds(templateSAO.getTopShowLiveTemplateIdList());
        creativeQueryViewDTO.setQueryAfterEndTime(BrandDateUtil.getCurrentTime());
        return this.findListWithPage(serviceContext, creativeQueryViewDTO).getList();
    }
}
