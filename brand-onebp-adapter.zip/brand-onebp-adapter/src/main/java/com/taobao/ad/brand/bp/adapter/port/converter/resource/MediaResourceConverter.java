package com.taobao.ad.brand.bp.adapter.port.converter.resource;

import com.alibaba.uad.wto.dto.resource.MediaResourceDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.resource.mapstruct.MediaResourceMapStruct;
import com.taobao.ad.brand.bp.client.dto.resource.MediaResourceViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * @author jixiu.lj
 * @date 2023/3/29 17:52
 */
@Component
public class MediaResourceConverter extends BaseViewDTOConverter<MediaResourceDTO, MediaResourceViewDTO> {
    @Override
    public BaseMapStructMapper<MediaResourceDTO, MediaResourceViewDTO> getBaseMapStructMapper() {
        return MediaResourceMapStruct.INSTANCE;
    }


}
