package com.taobao.ad.brand.bp.adapter.port.repository.account.agreement;

import com.alibaba.legal.agreement.dto.AgreementSignResultDto;
import com.taobao.ad.brand.bp.adapter.port.converter.account.agreement.AgreementConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.agreement.AgreementSAO;
import com.taobao.ad.brand.bp.client.dto.account.agreement.AgreementSignRequestViewDTO;
import com.taobao.ad.brand.bp.client.dto.account.agreement.AgreementSignResultViewDTO;
import com.taobao.ad.brand.bp.domain.account.repository.AgreementRepository;

import org.springframework.stereotype.Repository;

import lombok.RequiredArgsConstructor;

/**
 * @author 虫洞 <liuming.liu@alibaba-inc.com>
 * @date 2023/4/4
 */
@Repository
@RequiredArgsConstructor
public class AgreementRepositoryImpl implements AgreementRepository {
    private final AgreementSAO agreementSAO;
    private final AgreementConverter agreementConverter;

    @Override
    public AgreementSignResultViewDTO sign(AgreementSignRequestViewDTO requestViewDTO) {
        AgreementSignResultDto agreementSignResultDto = agreementSAO.syncAgreementSignInfo(requestViewDTO);
        return agreementConverter.convertDTO2ViewDTO(agreementSignResultDto);
    }
}
