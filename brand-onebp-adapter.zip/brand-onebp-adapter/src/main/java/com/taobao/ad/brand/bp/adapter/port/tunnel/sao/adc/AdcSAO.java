package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.adc;

import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.nb.framework.adc.dto.AdcCdnDTO;
import com.alibaba.ad.nb.framework.adc.dto.AdcComponentDTO;
import com.alibaba.ad.nb.framework.adc.dto.AdcPermissionDTO;
import com.alibaba.ad.nb.framework.adc.dto.AdcQueryDTO;
import com.alibaba.ad.nb.framework.adc.service.AdcService;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.dto.adc.query.AdcQueryViewDTO;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;

/**
 * adc相关服务
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AdcSAO {
    private final AdcService adcService;

    /**
     * 查询菜单
     * @param queryViewDTO
     * @return
     */
    public List<AdcComponentDTO> findMenuList(AdcQueryViewDTO queryViewDTO){
        AdcQueryDTO adcQuery = getAdcQuery(queryViewDTO);
        List<AdcComponentDTO> menuList = adcService.findMenuList(adcQuery);
        return CollectionUtils.isNotEmpty(menuList) ? menuList : Lists.newArrayList();
    }

    /**
     * 查询组件
     * @param queryViewDTO
     * @return
     */
    public List<AdcComponentDTO> findComponentList(AdcQueryViewDTO queryViewDTO){
        AdcQueryDTO adcQuery = getAdcQuery(queryViewDTO);
        List<AdcComponentDTO> componentList = adcService.findComponentList(adcQuery);
        return CollectionUtils.isNotEmpty(componentList) ? componentList : Lists.newArrayList();
    }

    /**
     * 查询onesiteCdn配置
     * @return
     */
    public List<AdcCdnDTO> findOneSiteCdnList(){
        List<AdcCdnDTO> componentList = adcService.findOneSiteCdnVersion();
        return CollectionUtils.isNotEmpty(componentList) ? componentList : Lists.newArrayList();
    }
    /**
     * 根据url查询onesiteCdn配置
     * @return
     */
    public List<AdcCdnDTO> findOneSiteCdnByUrl(String domain){
        List<AdcCdnDTO> componentList = adcService.findOneSiteCdnVersion(domain);
        return CollectionUtils.isNotEmpty(componentList) ? componentList : Lists.newArrayList();
    }

    private AdcQueryDTO getAdcQuery(AdcQueryViewDTO queryViewDTO){
        AdcQueryDTO adcQuery = new AdcQueryDTO();
        adcQuery.setBizCode(BizCodeEnum.BRANDONEBP.getBizCode());
        adcQuery.setComponentCode(queryViewDTO.getComponentCode());
        adcQuery.setAdcRoles(queryViewDTO.getAdcRoles());
        List<AdcPermissionDTO> permissionList = Lists.newArrayList();
        adcQuery.setPermissionList(permissionList);

        //filterMap逻辑填充
        Map<String, Object> filterMap = MapUtils.isNotEmpty(queryViewDTO.getFilterMap()) ? queryViewDTO.getFilterMap() : Maps.newHashMap();
        adcQuery.setFilterMap(filterMap);
        return adcQuery;
    }
}
