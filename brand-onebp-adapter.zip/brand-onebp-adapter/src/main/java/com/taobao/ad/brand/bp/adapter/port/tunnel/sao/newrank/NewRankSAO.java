package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.newrank;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashMap;
import java.util.Objects;
import java.util.Optional;

@Component
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class NewRankSAO {
    private final OkHttpClient httpClient;
    private static final String SUCCESS_CODE = "000000";
    private static final String CODE = "code";
    private static final String MESSAGE = "message";
    private static final String NEW_RANK_ACCESS_KEY = "ce6d033d92ec4dcd95fbe64f33957c74";
    private static final String UPLOAD_TALENT_WORK_CONFIG= "yz/haihui/udwork/submit";
    @Value("${newrank.api.url.prefix}")
    private String urlPrefix;

    public Response postWorkConfig(HashMap<String, Object> params) throws IOException {
        String url = urlPrefix + UPLOAD_TALENT_WORK_CONFIG;
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody requestBody = RequestBody.create(mediaType, JSON.toJSONString(params));
        Request request = new Request.Builder()
                .url(url)
                .header("Content-Type", "application/json")
                .header("access-key", NEW_RANK_ACCESS_KEY)
                .post(requestBody)
                .build();

        RogerLogger.info("发送HTTP请求同步新榜, Request {} \n requestBody {}", request.toString(), requestBody.toString());
        Response response = httpClient.newCall(request).execute();
        validateResult(response);

        return response;
    }
    private void validateResult(Response response) throws IOException {
        AssertUtil.assertTrue(Objects.nonNull(response) && response.isSuccessful(), "达人配置同步新榜失败，请联系小二进行排查" + response.message());

        String responseBody = response.body().string();
        RogerLogger.info("新榜返回结果 {}", responseBody);
        JSONObject jsonObject = JSONObject.parseObject(responseBody);
        String code = Optional.ofNullable(jsonObject).map(obj -> obj.getString(CODE)).orElse("");
        String message = Optional.ofNullable(jsonObject).map(obj -> obj.getString(MESSAGE)).orElse("");

        AssertUtil.assertTrue(SUCCESS_CODE.equals(code), "同步新榜单失败，请联系小二进行排查，新榜返回信息：" + message);
    }

}
