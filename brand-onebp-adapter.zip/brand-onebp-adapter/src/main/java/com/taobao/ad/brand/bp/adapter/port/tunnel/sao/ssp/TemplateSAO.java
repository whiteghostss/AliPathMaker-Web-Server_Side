package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.ssp;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.nb.ssp.api.tag.TagTargetDataQueryService;
import com.alibaba.ad.nb.ssp.api.template.NbTemplateQueryService;
import com.alibaba.ad.nb.ssp.constant.common.tag.TagSceneTypeEnum;
import com.alibaba.ad.nb.ssp.constant.common.tag.TagTargetTypeEnum;
import com.alibaba.ad.nb.ssp.constant.template.TemplateBusinessLineEnum;
import com.alibaba.ad.nb.ssp.dto.tag.TagTargetDataDTO;
import com.alibaba.ad.nb.ssp.dto.tag.TagTargetDataQueryDTO;
import com.alibaba.ad.nb.ssp.dto.template.NbTemplateContextDTO;
import com.alibaba.ad.nb.ssp.dto.template.NbTemplateDTO;
import com.alibaba.ad.nb.ssp.dto.template.NbTemplateMetaDataQueryDTO;
import com.alibaba.ad.nb.ssp.dto.template.NbTemplateQueryDTO;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeTemplateQueryDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/3/2 20:33
 * @description ：
 * @modified By：
 */
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class TemplateSAO extends BaseSAO {
    private final NbTemplateQueryService nbTemplateQueryService;
    private final TagTargetDataQueryService tagTargetDataQueryService;

    public NbTemplateDTO getTemplateById(ServiceContext serviceContext, Long id) {
        com.alibaba.ad.nb.ssp.context.ServiceContext context = com.alibaba.ad.nb.ssp.context.ServiceContext.create();
        NbTemplateQueryDTO queryDTO = new NbTemplateQueryDTO();
        queryDTO.setId(id);
        queryDTO.setNeedAssociation(Boolean.TRUE);
        queryDTO.setNeedTag(Boolean.TRUE);
        SingleResponse<NbTemplateDTO> response = nbTemplateQueryService.detail(context, queryDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, "创意模版信息查询失败:" + response.getErrorMsg());
        return response.getResult();
    }

    public List<NbTemplateContextDTO> getTemplateMetaData(ServiceContext serviceContext, List<Long> nbTemplateIds,boolean isSmart) {
        com.alibaba.ad.nb.ssp.context.ServiceContext context = com.alibaba.ad.nb.ssp.context.ServiceContext.create();
        NbTemplateMetaDataQueryDTO metaDataQueryDTO = new NbTemplateMetaDataQueryDTO();
        metaDataQueryDTO.setTemplateIdList(nbTemplateIds);
        metaDataQueryDTO.setSmart(isSmart);
        MultiResponse<NbTemplateContextDTO> response = nbTemplateQueryService.queryTemplateMetaData(context, metaDataQueryDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, "模版信息查询失败:" + response.getErrorMsg());
        return response.getResult();
    }

    public List<NbTemplateDTO> getTemplateByIds(ServiceContext serviceContext, List<Long> ids) {
        if(CollectionUtils.isEmpty(ids)) {
            return Lists.newArrayList();
        }
        com.alibaba.ad.nb.ssp.context.ServiceContext context = com.alibaba.ad.nb.ssp.context.ServiceContext.create();
        NbTemplateQueryDTO queryDTO = new NbTemplateQueryDTO();
        queryDTO.setTemplateIdList(ids);
        queryDTO.setNeedSetting(true);
        queryDTO.setNeedAssociation(true);
        MultiResponse<NbTemplateDTO> response = nbTemplateQueryService.list(context, queryDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, "创意模版信息查询失败:" + response.getErrorMsg());
        return response.getResult();
    }

    public List<NbTemplateDTO> getTemplateList(ServiceContext serviceContext, CreativeTemplateQueryDTO templateQueryDTO) {
        com.alibaba.ad.nb.ssp.context.ServiceContext context = com.alibaba.ad.nb.ssp.context.ServiceContext.create();
        NbTemplateQueryDTO queryDTO = new NbTemplateQueryDTO();
        queryDTO.setTemplateIdList(templateQueryDTO.getTemplateIdList());
        queryDTO.setExcludeTemplateIdList(templateQueryDTO.getExcludeTemplateIdList());
        queryDTO.setNeedSetting(templateQueryDTO.isNeedSetting());
        queryDTO.setNeedAssociation(templateQueryDTO.isNeedAssociation());
        queryDTO.setNeedTag(templateQueryDTO.isNeedTag());
        queryDTO.setPageSize(templateQueryDTO.getPageSize());
        queryDTO.setToPage(templateQueryDTO.getPageNo());
        MultiResponse<NbTemplateDTO> response = nbTemplateQueryService.list(context, queryDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, "创意模版信息查询失败:" + response.getErrorMsg());
        return response.getResult();
    }

    public List<Long> getRightTemplateIdList() {
        com.alibaba.ad.nb.ssp.context.ServiceContext context = com.alibaba.ad.nb.ssp.context.ServiceContext.create();
        MultiResponse<TagTargetDataDTO> response = tagTargetDataQueryService.list(context,
                TagTargetDataQueryDTO.builder().tagIdList(Lists.newArrayList(79L)).firstCategory("brand_equity").targetType(TagTargetTypeEnum.TARGET_TYPE_TEMPLATE_ENUM.getCode()).sceneType(TagSceneTypeEnum.TAG_SCENE_BRAND_EQUITY_TYPE_ENUM.getCode()).build());
        RogerLogger.info("SspSAO getRightTemplateList 调用接口 tagTargetDataQueryService.list 接口返回:{}", JSONObject.toJSONString(response));
        if (Objects.isNull(response) || !response.isSuccess()) {
            RogerLogger.error("SspSAO getRightTemplateList 获取权益创意模板失败，原因:{}", JSONObject.toJSONString(response));
            return Lists.newArrayList();
        }
        List<Long> targetIdList = response.getResult().stream().map(TagTargetDataDTO::getTargetId).collect(Collectors.toList());
        return targetIdList;
    }
    public List<Long> getTopShowLiveTemplateIdList() {
        com.alibaba.ad.nb.ssp.context.ServiceContext context = com.alibaba.ad.nb.ssp.context.ServiceContext.create();
        MultiResponse<TagTargetDataDTO> response = tagTargetDataQueryService.list(context,
                TagTargetDataQueryDTO.builder().secondCategory(TemplateBusinessLineEnum.TOPSHOW_LIVE.getCode()).targetType(TagTargetTypeEnum.TARGET_TYPE_TEMPLATE_ENUM.getCode()).sceneType(TagSceneTypeEnum.TAG_SCENE_BRAND_TEMPLATE_BUSINESS_ENUM.getCode()).build());
        RogerLogger.info("SspSAO getTopShowLiveTemplateIdList 调用接口 tagTargetDataQueryService.list 接口返回:{}", JSONObject.toJSONString(response));
        if (Objects.isNull(response) || !response.isSuccess()) {
            RogerLogger.error("SspSAO getTopShowLiveTemplateIdList 获取权益创意模板失败，原因:{}", JSONObject.toJSONString(response));
            return Lists.newArrayList();
        }
        List<Long> targetIdList = response.getResult().stream().map(TagTargetDataDTO::getTargetId).collect(Collectors.toList());
        return targetIdList;
    }
}
