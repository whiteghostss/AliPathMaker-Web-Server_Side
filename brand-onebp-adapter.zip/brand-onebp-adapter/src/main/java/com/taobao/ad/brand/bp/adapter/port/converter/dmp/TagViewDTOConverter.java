package com.taobao.ad.brand.bp.adapter.port.converter.dmp;

import com.taobao.ad.brand.bp.adapter.port.converter.dmp.mapstruct.TagViewDTOMapStruct;
import com.taobao.ad.brand.bp.client.dto.dmp.TagOptionViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import com.taobao.ad.dmp.client.dto.TagOptionDTO;
import org.springframework.stereotype.Component;

/**
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@Component
public class TagViewDTOConverter extends BaseViewDTOConverter<TagOptionDTO, TagOptionViewDTO> {

    @Override
    public BaseMapStructMapper<TagOptionDTO, TagOptionViewDTO> getBaseMapStructMapper() {
        return TagViewDTOMapStruct.INSTANCE;
    }
}
