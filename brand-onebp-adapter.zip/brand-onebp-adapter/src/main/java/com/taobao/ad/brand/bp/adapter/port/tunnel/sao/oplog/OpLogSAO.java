package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.oplog;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.oplog.dto.OpLogDTO;
import com.alibaba.ad.oplog.dto.OpLogQueryDTO;
import com.alibaba.ad.oplog.sdk.OpLogQueryService;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author jixiu.lj
 * @date 2024/3/20 15:18
 */
@Component
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class OpLogSAO {
    private final OpLogQueryService opLogQueryService;

    public List<OpLogDTO> queryOpLog(ServiceContext serviceContext, OpLogQueryDTO opLogQueryDTO) {
        MultiResponse<OpLogDTO> opLogDTOMultiResponse = opLogQueryService.queryOpLogList(serviceContext, opLogQueryDTO);
        AssertUtil.assertTrue(opLogDTOMultiResponse);
        return opLogDTOMultiResponse.getResult();
    }
}
