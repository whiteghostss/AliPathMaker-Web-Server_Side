package com.taobao.ad.brand.bp.adapter.port.repository.agent;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.ai.client.dto.LlmAgentDirectCallParam;
import com.alibaba.fastjson.JSONObject;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.adapter.port.converter.agent.LlmAgentDirectCallParamConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.agent.AgentSAO;
import com.taobao.ad.brand.bp.client.dto.agent.LlmAgentDirectCallParamViewDTO;
import com.taobao.ad.brand.bp.domain.agent.AgentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AgentRepositoryImpl implements AgentRepository {

    private final AgentSAO agentSAO;
    private final LlmAgentDirectCallParamConverter llmAgentDirectCallParamConverter;

    @Override
    public String directCall(ServiceContext serviceContext, LlmAgentDirectCallParamViewDTO callParam) {
        RogerLogger.info("AgentRepositoryImpl.directCall, serviceContext:{}, callParam:{}", JSONObject.toJSONString(serviceContext), JSONObject.toJSONString(callParam));
        LlmAgentDirectCallParam llmAgentDirectCallParam = llmAgentDirectCallParamConverter.convertViewDTO2DTO(callParam);
        String callResult = agentSAO.directCall(serviceContext, llmAgentDirectCallParam);
        RogerLogger.info("AgentRepositoryImpl.directCall, callResult:{}", callResult);
        return callResult;
    }
}
