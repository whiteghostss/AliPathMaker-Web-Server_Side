package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.brand;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.brand.domain.Brand;
import com.taobao.brand.domain.ChannelSource;
import com.taobao.brand.domain.PageResult;
import com.taobao.brand.service.tolong.StandardBrandService;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * 品牌相关服务
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSAO {
    private final StandardBrandService standardBrandService;


//    /**
//     * 根据关键词查询品牌信息
//     * @param keyword
//     * @return
//     */
//    public List<Brand> queryByKeyword(String keyword){
//        List<Brand> brandList;
//        try {
//            brandList = standardBrandService.queryBrand(keyword);
//        } catch (Exception e) {
//            RogerLogger.error("品牌库服务查询异常",e);
//            brandList = Lists.newArrayList();
//        }
//        return brandList;
//    }

    /**
     * 根据品牌名模糊搜索
     *
     * @param brandName
     * @param limit
     * @return
     */
    public List<Brand> findBrandByNameFuzzy(String brandName, Integer limit) {
        if (StringUtils.isBlank(brandName)) {
            return Lists.newArrayList();
        }
        if (limit == null || limit <= 0) {
            limit = 10;
        }
        PageResult<Brand> pageResult = standardBrandService.findBrandByNameFuzzy(brandName, ChannelSource.ALL, 1, limit);
        if (!pageResult.isSuccess()) {
            RogerLogger.error("查询品牌发生错误 {}", JSONObject.toJSONString(pageResult.getErrorInfo()));
            return Lists.newArrayList();
        }
        return pageResult.getList();
    }

    public List<Brand> queryBrand(List<Long> brandIds) {
        List<Brand> brandList;
        try {
            brandList = standardBrandService.queryBrand(brandIds);
        } catch (Exception e) {
            RogerLogger.error("品牌库服务查询异常", e);
            brandList = Lists.newArrayList();
        }
        return brandList;
    }

    public Brand getBrand(Long brandId) {
        Brand brand = null;
        try {
            brand = standardBrandService.queryBrand(brandId);
        } catch (Exception e) {
            RogerLogger.error("品牌库服务查询异常", e);
        }
        return brand;
    }
}
