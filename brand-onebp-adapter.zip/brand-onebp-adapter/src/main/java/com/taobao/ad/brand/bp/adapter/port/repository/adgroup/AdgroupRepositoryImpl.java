package com.taobao.ad.brand.bp.adapter.port.repository.adgroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.audience.dto.bind.BindCrowdDTO;
import com.alibaba.ad.audience.dto.bind.DeleteCrowdDTO;
import com.alibaba.ad.brand.dto.adgroup.*;
import com.alibaba.ad.brand.dto.adgroup.crowd.AdgroupCrowdScenarioViewDTO;
import com.alibaba.ad.brand.dto.adgroup.crowd.AdgroupCrowdViewDTO;
import com.alibaba.ad.brand.dto.adgroup.monitor.AdgroupMonitorViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.convert.custom.viewdto.AdgroupViewDTO2DTOConvertProcessor;
import com.alibaba.ad.brand.sdk.convert.custom.viewdto.CreativeRefViewDTO2DTOConvertProcessor;
import com.alibaba.ad.brand.sdk.convert.custom.viewdto.audience.AdgroupCrowdViewDTO2DTOConvertProcessor;
import com.alibaba.ad.brand.sdk.convert.custom.viewdto.audience.CampaignCrowdViewDTO2DTOConvertProcessor;
import com.alibaba.ad.creative.dto.bind.CreativeBindDTO;
import com.alibaba.ad.organizer.dto.AdgroupDTO;
import com.alibaba.ad.universal.sdk.convert.custom.onebp.provider.OneBpConvertProcessorProvider;
import com.alibaba.fastjson.JSON;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.adgroup.AdgroupSAO;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.creative.CreativeSAO;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.targetcenter.TargetSAO;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.adgroup.repository.AdgroupRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AdgroupRepositoryImpl implements AdgroupRepository {

    private final AdgroupSAO adgroupSAO;
    private final TargetSAO targetSAO;
    private final CreativeSAO creativeSAO;

    private final AdgroupCrowdViewDTO2DTOConvertProcessor adgroupCrowdViewDTO2DTOConvertProcessor = OneBpConvertProcessorProvider.getViewDTO2DTOConvertProcessor(AdgroupCrowdViewDTO2DTOConvertProcessor.class);
    private CampaignCrowdViewDTO2DTOConvertProcessor campaignCrowdProcessor = OneBpConvertProcessorProvider.getViewDTO2DTOConvertProcessor(CampaignCrowdViewDTO2DTOConvertProcessor.class);
    private CreativeRefViewDTO2DTOConvertProcessor creativeRefViewDTO2DTOConvertProcessor = OneBpConvertProcessorProvider.getViewDTO2DTOConvertProcessor(CreativeRefViewDTO2DTOConvertProcessor.class);
    private AdgroupViewDTO2DTOConvertProcessor adgroupViewDTO2DTOConvertProcessor = OneBpConvertProcessorProvider.getViewDTO2DTOConvertProcessor(AdgroupViewDTO2DTOConvertProcessor.class);


    @Override
    public PageResultViewDTO<AdgroupViewDTO> queryAdgroupPageList(ServiceContext serviceContext, AdgroupQueryViewDTO query) {
        MultiResponse<AdgroupDTO> multiResponse = adgroupSAO.findAdgroupPageList(serviceContext,query);
        List<AdgroupViewDTO> adgroupViewDTOList = Lists.newArrayList();
        if (CollectionUtils.isNotEmpty(multiResponse.getResult())){
            multiResponse.getResult().forEach(t->{
                AdgroupViewDTO adgroupViewDTO = adgroupViewDTO2DTOConvertProcessor.dto2ViewDTO(t);
                adgroupViewDTOList.add(adgroupViewDTO);

            });
        }
        return  PageResultViewDTO.of(adgroupViewDTOList,multiResponse.getTotal());
    }

    @Override
    public List<AdgroupViewDTO> queryAdgroupListNoPage(ServiceContext serviceContext, AdgroupQueryViewDTO adgroupQueryViewDTO) {
        List<AdgroupDTO> adgroupDTOS = adgroupSAO.findAdgroupListNoPage(serviceContext, adgroupQueryViewDTO);
        List<AdgroupViewDTO> adgroupViewDTOList = Lists.newArrayList();
        adgroupDTOS.forEach(t -> {
            AdgroupViewDTO adgroupViewDTO = adgroupViewDTO2DTOConvertProcessor.dto2ViewDTO(t);
            adgroupViewDTOList.add(adgroupViewDTO);
        });
        return adgroupViewDTOList;
    }

    @Override
    public Integer count(ServiceContext serviceContext, AdgroupQueryViewDTO adgroupQueryViewDTO) {
        return adgroupSAO.getCount(serviceContext,adgroupQueryViewDTO);
    }

    @Override
    public List<AdgroupViewDTO> queryAdgroupBasicListNoPage(ServiceContext serviceContext, AdgroupQueryViewDTO adgroupQueryViewDTO) {
        List<AdgroupDTO> adgroupDTOS = adgroupSAO.findAdgroupBasicListNoPage(serviceContext, adgroupQueryViewDTO);
        List<AdgroupViewDTO> adgroupViewDTOList = Lists.newArrayList();
        adgroupDTOS.forEach(t -> {
            AdgroupViewDTO adgroupViewDTO = adgroupViewDTO2DTOConvertProcessor.dto2ViewDTO(t);
            adgroupViewDTOList.add(adgroupViewDTO);
        });
        return adgroupViewDTOList;
    }

    @Override
    public AdgroupViewDTO queryAdgroupTopOneByName(ServiceContext serviceContext, Long excludeAdgroupId, String title) {
       AdgroupDTO adgroupDTO=  adgroupSAO.findTopOneAdgroupByTitle(serviceContext, excludeAdgroupId,title);
       return adgroupViewDTO2DTOConvertProcessor.dto2ViewDTO(adgroupDTO);
    }
    /**
     * 添加adgroup主表
     * */
    @Override
    public Long addAdgroup(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO) {
        AdgroupDTO adgroupDTO= adgroupViewDTO2DTOConvertProcessor.viewDTO2DTO(adgroupViewDTO);
        Long id = adgroupSAO.addAdgroup(serviceContext, adgroupDTO);
        adgroupViewDTO.setId(id);
        return id;
    }
    /**
     * 添加adgroup人群定向
     * */
    @Override
    public void addAdgroupCrowdTarget(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO) {
        List<AdgroupCrowdViewDTO> adgroupCrowdViewDTOList = Optional.ofNullable(adgroupViewDTO.getAdgroupCrowdScenarioViewDTO())
                .map(AdgroupCrowdScenarioViewDTO::getAdgroupCrowdViewDTOList).orElse(null);
        List<BindCrowdDTO> bindCrowdDTOList = convertAdgroupBindCrowdDTOList(adgroupCrowdViewDTOList, adgroupViewDTO.getId(), adgroupViewDTO.getCampaignId());
        if (CollectionUtils.isNotEmpty(bindCrowdDTOList)) {
            targetSAO.addAdgroupBindCrowd(serviceContext, bindCrowdDTOList);
        }
    }

    private List<BindCrowdDTO> convertAdgroupBindCrowdDTOList(List<AdgroupCrowdViewDTO> adgroupCrowdViewDTOList, Long adgroupId, Long campaignId) {
        if (CollectionUtils.isEmpty(adgroupCrowdViewDTOList)) {
            return Lists.newArrayList();
        }
        List<BindCrowdDTO> bindCrowdDTOList =
                adgroupCrowdViewDTO2DTOConvertProcessor.viewDTOList2DTOList(adgroupCrowdViewDTOList);
        bindCrowdDTOList.forEach(item -> {
            item.setAdgroupId(adgroupId);
            item.setCampaignId(campaignId);
        });
        return bindCrowdDTOList;
    }

    /**
     * 更新adgroup人群定向
     * @param serviceContext
     * @param adgroupViewDTO
     * */
    @Override
    public void updateAdgroupCrowdTarget(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO) {
        Long adgroupId = adgroupViewDTO.getId();
        List<AdgroupCrowdViewDTO> adgroupCrowdViewDTOList = Optional.ofNullable(adgroupViewDTO.getAdgroupCrowdScenarioViewDTO())
                .map(AdgroupCrowdScenarioViewDTO::getAdgroupCrowdViewDTOList).orElse(null);
        if (CollectionUtils.isNotEmpty(adgroupCrowdViewDTOList)) {
            List<BindCrowdDTO> bindCrowdDTOList = convertAdgroupBindCrowdDTOList(adgroupCrowdViewDTOList, adgroupViewDTO.getId(), adgroupViewDTO.getCampaignId());
            targetSAO.updateAdgroupBindCrowd(serviceContext, bindCrowdDTOList);
        } else {
            List<BindCrowdDTO> dbBind = targetSAO.getCrowdTargetByAdgroupIds(serviceContext, Lists.newArrayList(adgroupId));
            if (CollectionUtils.isNotEmpty(dbBind)){
                List<Long> audienceCrowdIds = dbBind.stream()
                        .filter(bindCrowdDTO -> bindCrowdDTO.getCrowdDTO() != null && bindCrowdDTO.getCrowdDTO().getId() != null)
                        .map(bindCrowdDTO -> bindCrowdDTO.getCrowdDTO().getId()).collect(Collectors.toList());
                deleteAdgroupCrowdByAudienceCrowdIds(serviceContext, adgroupId, audienceCrowdIds);
            }
        }
    }

    @Override
    public void batchUpdateAdgroupCrowdTag(ServiceContext serviceContext, List<Long> adgroupIdList) {
        if (CollectionUtils.isEmpty(adgroupIdList)) {
            return;
        }
        List<BindCrowdDTO> crowBindList = targetSAO.getCrowdTargetByAdgroupIds(serviceContext, adgroupIdList);
        Map<Long, List<BindCrowdDTO>> adgroupCrowdGroupMap = Optional.ofNullable(crowBindList).orElse(Lists.newArrayList())
                .stream().collect(Collectors.groupingBy(BindCrowdDTO::getAdgroupId));
        List<AdgroupViewDTO> updateAdgroupViewDTOList = Lists.newArrayList();
        for (Long adgroupId : adgroupIdList) {
            List<BindCrowdDTO> adgroupCrowBindList = adgroupCrowdGroupMap.getOrDefault(adgroupId,Lists.newArrayList());
                    Integer crowTag = BrandBoolEnum.BRAND_FALSE.getCode();
            if(CollectionUtils.isNotEmpty(adgroupCrowBindList)){
                crowTag = BrandBoolEnum.BRAND_TRUE.getCode();
            }
            AdgroupViewDTO adgroupViewDTO = new AdgroupViewDTO();
            adgroupViewDTO.setId(adgroupId);

            AdgroupCrowdScenarioViewDTO crowdScenarioViewDTO = new AdgroupCrowdScenarioViewDTO();
            crowdScenarioViewDTO.setCrowdTag(crowTag);
            adgroupViewDTO.setAdgroupCrowdScenarioViewDTO(crowdScenarioViewDTO);

            updateAdgroupViewDTOList.add(adgroupViewDTO);
        }
        batchUpdateAdgroupPart(serviceContext,updateAdgroupViewDTOList);
        RogerLogger.info("单元人群标识更改成功，adgroupCrowTag={}", JSON.toJSONString(updateAdgroupViewDTOList));
    }


    @Override
    public void batchUpdateAdgroupViewDTOCrowdTag(ServiceContext serviceContext, List<AdgroupViewDTO> adgroupViewDTOList) {
        List<AdgroupViewDTO> updateAdgroupViewDTOList = Lists.newArrayList();
        for (AdgroupViewDTO adgroupViewDTO : adgroupViewDTOList) {
            List<AdgroupCrowdViewDTO> adgroupBindCrowdDTOS = Optional.ofNullable(adgroupViewDTO.getAdgroupCrowdScenarioViewDTO())
                    .map(AdgroupCrowdScenarioViewDTO::getAdgroupCrowdViewDTOList).orElse(null);
            Integer crowTag = BrandBoolEnum.BRAND_FALSE.getCode();
            if(CollectionUtils.isNotEmpty(adgroupBindCrowdDTOS)){
                Optional<AdgroupCrowdViewDTO> optional = adgroupBindCrowdDTOS.stream().filter(item->Objects.nonNull(item.getCrowdId())).findAny();
                if(optional.isPresent()){
                    crowTag = BrandBoolEnum.BRAND_TRUE.getCode();
                }
            }
            AdgroupViewDTO updateAdgroupViewDTO = new AdgroupViewDTO();
            updateAdgroupViewDTO.setId(adgroupViewDTO.getId());

            AdgroupCrowdScenarioViewDTO crowdScenarioViewDTO = new AdgroupCrowdScenarioViewDTO();
            crowdScenarioViewDTO.setCrowdTag(crowTag);
            updateAdgroupViewDTO.setAdgroupCrowdScenarioViewDTO(crowdScenarioViewDTO);

            updateAdgroupViewDTOList.add(updateAdgroupViewDTO);
        }
        batchUpdateAdgroupPart(serviceContext,updateAdgroupViewDTOList);
        RogerLogger.info("单元人群标识更改成功，adgroupCrowTag={}", JSON.toJSONString(updateAdgroupViewDTOList));
    }


    /**
     * 添加or更新adgroup关联的创意
     * */
    @Override
    public void updateCreativeRef(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO) {
        if (CollectionUtils.isNotEmpty(adgroupViewDTO.getCreativeRefViewDTOList())){
            adgroupViewDTO.getCreativeRefViewDTOList().forEach(t->{
                t.setAdgroupId(adgroupViewDTO.getId());
                t.setCampaignId(adgroupViewDTO.getCampaignId());
                t.setCampaignGroupId(adgroupViewDTO.getCampaignGroupId());
                t.setMonitorCodeViewDTOList(t.getMonitorCodeViewDTOList());
                t.setBottomDateViewDTOList(t.getBottomDateViewDTOList());
            });
            List<CreativeBindDTO> creativeBindDTOList = creativeRefViewDTO2DTOConvertProcessor.viewDTOList2DTOList(adgroupViewDTO.getCreativeRefViewDTOList());
            creativeSAO.updateBatchCreativeRef(serviceContext, creativeBindDTOList);
        }else{
            creativeSAO.unBindCreativeRef(serviceContext,Collections.singletonList(adgroupViewDTO.getId()));
        }
    }

    @Override
    public void addCreativeRef(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO) {
        if (CollectionUtils.isNotEmpty(adgroupViewDTO.getCreativeRefViewDTOList())){
            adgroupViewDTO.getCreativeRefViewDTOList().forEach(t->{
                t.setAdgroupId(adgroupViewDTO.getId());
                t.setCampaignId(adgroupViewDTO.getCampaignId());
                t.setCampaignGroupId(adgroupViewDTO.getCampaignGroupId());
                t.setMonitorCodeViewDTOList(t.getMonitorCodeViewDTOList());
                t.setBottomDateViewDTOList(t.getBottomDateViewDTOList());
            });
            List<CreativeBindDTO> creativeBindDTOList = creativeRefViewDTO2DTOConvertProcessor.viewDTOList2DTOList(adgroupViewDTO.getCreativeRefViewDTOList());
            creativeSAO.addBatchCreativeRef(serviceContext,creativeBindDTOList);
        }
    }

    @Override
    public Long updateAdgroup(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO) {
        AdgroupDTO adgroupDTO= adgroupViewDTO2DTOConvertProcessor.viewDTO2DTO(adgroupViewDTO);
        adgroupSAO.updateAdgroup(serviceContext,adgroupDTO);
        return adgroupViewDTO.getId();
    }

    @Override
    public Long updateAdgroupLastSendTime(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO) {
        AdgroupViewDTO updateAdgroup = new AdgroupViewDTO();
        updateAdgroup.setAdgroupMonitorViewDTO(new AdgroupMonitorViewDTO());

        AdgroupMonitorViewDTO adgroupMonitorViewDTO = Optional.ofNullable(adgroupViewDTO.getAdgroupMonitorViewDTO())
                .orElse(new AdgroupMonitorViewDTO());
        if(adgroupMonitorViewDTO.getLastSendTime()!=null){
            updateAdgroup.getAdgroupMonitorViewDTO().setLastSendTime(adgroupMonitorViewDTO.getLastSendTime());
        }
        if (adgroupMonitorViewDTO.getMonitorContentId() != null) {
            updateAdgroup.getAdgroupMonitorViewDTO().setMonitorContentId(adgroupMonitorViewDTO.getMonitorContentId());
        }
        updateAdgroup.setId(adgroupViewDTO.getId());
        updateAdgroup.setMemberId(adgroupViewDTO.getMemberId());
        updateAdgroup.setCampaignId(adgroupViewDTO.getCampaignId());
        AdgroupDTO adgroupDTO= adgroupViewDTO2DTOConvertProcessor.viewDTO2DTO(updateAdgroup);
        return  adgroupSAO.updateAdgroupPart(serviceContext,adgroupDTO).longValue();
    }

    @Override
    public Integer deleteAdgroupSettingBatch(ServiceContext serviceContext, Long adgroupId, List<String> settingKeyList) {
        return adgroupSAO.deleteAdgroupSettingBatch(serviceContext, adgroupId, settingKeyList);
    }

    @Override
    public void batchUpdateAdgroupStatus(ServiceContext serviceContext, List<Long> ids, Integer status) {
        adgroupSAO.batchUpdateAdgroupStatus(serviceContext,ids,status);
    }

    @Override
    public void batchUpdateAdgroupPart(ServiceContext serviceContext, List<AdgroupViewDTO> adgroupDTOList) {
        List<AdgroupDTO> dtoList = adgroupDTOList.stream()
                .map(adgroupViewDTO2DTOConvertProcessor::viewDTO2DTO)
                .collect(Collectors.toList());
        adgroupSAO.batchUpdateAdgroupPart(serviceContext, dtoList);
    }

    @Override
    public void deleteAdgroupByCampaignId(ServiceContext serviceContext, Long campaignId) {
        AssertUtil.notNull(campaignId,"参数不能为空");
        AdgroupQueryViewDTO adgroupQueryViewDTO = new AdgroupQueryViewDTO();
        adgroupQueryViewDTO.setCampaignId(campaignId);
        List<AdgroupDTO> list = adgroupSAO.findAdgroupListNoPage(serviceContext,adgroupQueryViewDTO);
        if (CollectionUtils.isNotEmpty(list)){
            List<Long> adgroupIds= list.stream().map(AdgroupDTO::getId).collect(Collectors.toList());
            adgroupSAO.deleteAdgroupByIds(serviceContext,adgroupIds);
        }
    }
    @Override
    public void deleteAdgroupByCampaignIds(ServiceContext serviceContext, List<Long> campaignIds) {
        AssertUtil.notEmpty(campaignIds,"参数不能为空");
        AdgroupQueryViewDTO adgroupQueryViewDTO = new AdgroupQueryViewDTO();
        adgroupQueryViewDTO.setCampaignIds(campaignIds);
        List<AdgroupDTO> list = adgroupSAO.findAdgroupListNoPage(serviceContext,adgroupQueryViewDTO);
        if (CollectionUtils.isNotEmpty(list)){
            List<Long> adgroupIds= list.stream().map(AdgroupDTO::getId).collect(Collectors.toList());
            adgroupSAO.deleteAdgroupByIds(serviceContext,adgroupIds);
        }
    }

    @Override
    public void deleteAdgroup(ServiceContext serviceContext, Long id){
        AssertUtil.notNull(id,"id不能为空");
        adgroupSAO.deleteAdgroupByIds(serviceContext,Lists.newArrayList(id));
    }

    @Override
    public void batchDeleteAdgroup(ServiceContext serviceContext, List<Long> ids){
        AssertUtil.notEmpty(ids,"id不能为空");
        adgroupSAO.deleteAdgroupByIds(serviceContext,Lists.newArrayList(ids));
    }

    @Override
    public AdgroupViewDTO getAdgroupById(ServiceContext serviceContext, Long adgroupId) {
        AdgroupDTO adgroupDTO = adgroupSAO.getAdgroupById(serviceContext, adgroupId);
        if (null == adgroupDTO) {
            return null;
        }
        AdgroupViewDTO adgroupViewDTO = adgroupViewDTO2DTOConvertProcessor.dto2ViewDTO(adgroupDTO);
        List<CreativeBindDTO> creativeBindDTOList = creativeSAO.getCreativeRefByAdgroupId(serviceContext,adgroupId);
        if (CollectionUtils.isNotEmpty(creativeBindDTOList)) {
            List<CreativeRefViewDTO> creativeRefViewDTOList = creativeRefViewDTO2DTOConvertProcessor.dtoList2ViewDTOList(creativeBindDTOList);
            adgroupViewDTO.setCreativeRefViewDTOList(creativeRefViewDTOList);
        } else {
            adgroupViewDTO.setCreativeRefViewDTOList(Lists.newArrayList());
        }

        List<BindCrowdDTO> adgroupBindCrowdDTOS = targetSAO.getCrowdTargetByAdgroupIds(serviceContext, Lists.newArrayList(adgroupId));
        if (CollectionUtils.isNotEmpty(adgroupBindCrowdDTOS)) {
            List<AdgroupCrowdViewDTO> crowdBaseViewDTOS = adgroupCrowdViewDTO2DTOConvertProcessor.dtoList2ViewDTOList(adgroupBindCrowdDTOS);
            adgroupViewDTO.getAdgroupCrowdScenarioViewDTO().setAdgroupCrowdViewDTOList(crowdBaseViewDTOS);
        } else {
            adgroupViewDTO.getAdgroupCrowdScenarioViewDTO().setAdgroupCrowdViewDTOList(Lists.newArrayList());
        }
        return adgroupViewDTO;
    }
    @Override
    public AdgroupViewDTO getBaseAdgroupById(ServiceContext serviceContext, Long adgroupId) {
        AdgroupDTO adgroupDTO = adgroupSAO.getAdgroupById(serviceContext, adgroupId);
        return adgroupViewDTO2DTOConvertProcessor.dto2ViewDTO(adgroupDTO);
    }

    @Override
    public Map<Long, List<AdgroupCrowdViewDTO>> getCrowdTargetMapByAdgroupIds(ServiceContext serviceContext, List<Long> adgroupIds) {
        List<BindCrowdDTO> adgroupBindCrowdDTOList = targetSAO.getCrowdTargetByAdgroupIds(serviceContext, adgroupIds);
        if (CollectionUtils.isEmpty(adgroupBindCrowdDTOList)) {
            return Maps.newHashMap();
        }
        Map<Long, List<AdgroupCrowdViewDTO>> mapCrowdBaseView = Maps.newHashMap();
        Map<Long, List<BindCrowdDTO>> adgroupBindMap = adgroupBindCrowdDTOList.stream().collect(Collectors.groupingBy(BindCrowdDTO::getAdgroupId));
        for (Map.Entry<Long, List<BindCrowdDTO>> entry : adgroupBindMap.entrySet()) {
            mapCrowdBaseView.put(entry.getKey(), adgroupCrowdViewDTO2DTOConvertProcessor.dtoList2ViewDTOList(entry.getValue()));
        }

        return mapCrowdBaseView;
    }
    @Override
   public  List<AdgroupCrowdViewDTO> getCrowdTargetByAdgroupId(ServiceContext serviceContext, Long adgroupId){
        if (Objects.isNull(adgroupId)) {
            return Lists.newArrayList();
        }
        List<BindCrowdDTO> adgroupBindCrowdDTOList = targetSAO.getCrowdTargetByAdgroupIds(serviceContext,Lists.newArrayList(adgroupId));
        if (CollectionUtils.isEmpty(adgroupBindCrowdDTOList)){
            return Lists.newArrayList();
        }
        return adgroupCrowdViewDTO2DTOConvertProcessor.dtoList2ViewDTOList(adgroupBindCrowdDTOList);
    }

    @Override
    public  void updateAdgroupPart(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO) {
        AdgroupDTO adgroupDTO = adgroupViewDTO2DTOConvertProcessor.viewDTO2DTO(adgroupViewDTO);
        adgroupSAO.updateAdgroupPart(serviceContext,adgroupDTO);
    }

    @Override
    public void deleteAdgroupSettingBatch(ServiceContext serviceContext, List<Long> adgroupIdList, List<String> settingKeyList) {
        adgroupSAO.deleteAdgroupSettingBatch(serviceContext,adgroupIdList,settingKeyList);
    }

    @Override
    public void deleteAdgroupTargetPart(ServiceContext serviceContext, Long adgroupId, Long targetType){
        DeleteCrowdDTO deleteCrowdDTO = new DeleteCrowdDTO();
        deleteCrowdDTO.setAdgroupId(adgroupId);
        deleteCrowdDTO.setTargetType(targetType);
        targetSAO.deleteAdgroupBindCrowd(serviceContext,deleteCrowdDTO);
    }

    @Override
    public void deleteAdgroupCrowdByAudienceCrowdIds(ServiceContext serviceContext, Long adgroupId, List<Long> audienceCrowdIds) {
        if (CollectionUtils.isEmpty(audienceCrowdIds)) {
            return;
        }
        targetSAO.deleteAdgroupCrowdByAudienceCrowdIds(serviceContext, audienceCrowdIds);
    }

    @Override
    public void addAdgroupCastingCrowdTarget(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, List<CampaignCrowdViewDTO> crowdViewDTOList) {
        Long adgroupId = adgroupViewDTO.getId();
        List<BindCrowdDTO> bindCrowdDTOList = campaignCrowdProcessor.viewDTOList2DTOList(crowdViewDTOList);
        bindCrowdDTOList.forEach(item -> {
            item.setAdgroupId(adgroupId);
            item.setCampaignId(adgroupViewDTO.getCampaignId());

        });
        if (CollectionUtils.isNotEmpty(bindCrowdDTOList)) {
            targetSAO.addOrUpdateBatchAdgroupCrowd(serviceContext, bindCrowdDTOList);
        }
    }
    @Override
    public void addOrUpdateAdgroupTargetPart(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO) {
        Long adgroupId = adgroupViewDTO.getId();
        List<AdgroupCrowdViewDTO> adgroupCrowdViewDTOList = Optional.ofNullable(adgroupViewDTO.getAdgroupCrowdScenarioViewDTO())
                .map(AdgroupCrowdScenarioViewDTO::getAdgroupCrowdViewDTOList).orElse(null);
        if (CollectionUtils.isNotEmpty(adgroupCrowdViewDTOList)) {
            List<BindCrowdDTO> bindCrowdDTOList = convertAdgroupBindCrowdDTOList(adgroupCrowdViewDTOList, adgroupId, adgroupViewDTO.getCampaignId());
            targetSAO.addOrUpdateBatchAdgroupCrowd(serviceContext, bindCrowdDTOList);
        }
    }
}
