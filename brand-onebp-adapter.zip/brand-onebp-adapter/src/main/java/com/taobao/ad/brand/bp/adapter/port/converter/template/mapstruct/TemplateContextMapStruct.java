package com.taobao.ad.brand.bp.adapter.port.converter.template.mapstruct;

import com.alibaba.ad.nb.ssp.dto.template.NbTemplateContextDTO;
import com.taobao.ad.brand.bp.client.dto.template.TemplateContextViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface TemplateContextMapStruct extends BaseMapStructMapper<NbTemplateContextDTO, TemplateContextViewDTO> {
    TemplateContextMapStruct INSTANCE = Mappers.getMapper(TemplateContextMapStruct.class);

    @Mappings({
            @Mapping(source = "nbTemplateDTO", target = "templateViewDTO"),
    })
    @Override
    TemplateContextViewDTO sourceToTarget(NbTemplateContextDTO nbTemplateContextDTO);

    @Mappings({
            @Mapping(source = "templateViewDTO", target = "nbTemplateDTO"),
    })
    @Override
    NbTemplateContextDTO targetToSource(TemplateContextViewDTO templateContextViewDTO);
}