package com.taobao.ad.brand.bp.adapter.port.repository.dmp;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.adapter.port.converter.dmp.ItemMetricsViewDTOConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.dmp.DmpSiteSAO;
import com.taobao.ad.brand.bp.client.dto.dmp.ItemMetricsViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.query.GoodsItemQueryViewDTO;
import com.taobao.ad.brand.bp.domain.dmp.GoodsItemRepository;
import com.taobao.ad.dmp.site.sdk.dto.GoodsItemQueryDTO;
import com.taobao.ad.dmp.site.sdk.dto.ItemIndicatorDTO;
import com.taobao.ad.dmp.site.sdk.dto.Pager;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 商品相关服务
 **/
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class GoodsItemRepositoryImpl implements GoodsItemRepository {

    private final DmpSiteSAO dmpSiteSAO;
    private final ItemMetricsViewDTOConverter itemMetricsViewDTOConverter;
    @Override
    public List<ItemMetricsViewDTO> findGoodsItemList(ServiceContext context, GoodsItemQueryViewDTO queryViewDTO) {
        GoodsItemQueryDTO goodsItemQueryDTO = initGoodsItemQueryDTO(queryViewDTO);
        Pager pager = new Pager(1, queryViewDTO.getPageSize());
        List<ItemIndicatorDTO> indicatorDTOList = dmpSiteSAO.findItemList4ShowMax(context, goodsItemQueryDTO, pager);
        return itemMetricsViewDTOConverter.convertDTO2ViewDTOList(indicatorDTOList);
    }

    @Override
    public List<ItemMetricsViewDTO> findItemMetrics(ServiceContext context, GoodsItemQueryViewDTO queryViewDTO) {
        GoodsItemQueryDTO goodsItemQueryDTO = initGoodsItemQueryDTO(queryViewDTO);
        List<ItemIndicatorDTO> indicatorDTOList = dmpSiteSAO.findItemIndicatorsTrend(context, goodsItemQueryDTO);
        return itemMetricsViewDTOConverter.convertDTO2ViewDTOList(indicatorDTOList);
    }

    private GoodsItemQueryDTO initGoodsItemQueryDTO(GoodsItemQueryViewDTO queryViewDTO) {
        GoodsItemQueryDTO queryDTO = new GoodsItemQueryDTO();
        if (StringUtils.isNotBlank(queryViewDTO.getKeyword())) {
            queryDTO.setKeyword(queryViewDTO.getKeyword());
        }
        queryDTO.setBeginDate(queryViewDTO.getStartDate());
        queryDTO.setEndDate(queryViewDTO.getEndDate());
        queryDTO.setItemLevel(queryViewDTO.getItemLevel());
        if (CollectionUtils.isNotEmpty(queryViewDTO.getItemIds())) {
            queryDTO.setItemIdList(queryViewDTO.getItemIds());
        }
        if (queryViewDTO.getCompareType() != null) {
            queryDTO.setCompareType(queryViewDTO.getCompareType());
        }

        return queryDTO;
    }
}
