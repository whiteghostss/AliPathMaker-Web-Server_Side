package com.taobao.ad.brand.bp.adapter.port.converter.resourcepackage.mapstruct;

import com.alibaba.ad.nb.packages.v2.client.dto.salegroup.DistributionRuleDTO;

import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourceDistributionRuleViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.DecoratedWith;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/23
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, uses = ResourcePackageProductMapStruct.class)
@DecoratedWith(ResourceDistributionRuleMapStructDecorator.class)
public interface ResourceDistributionRuleMapStruct extends BaseMapStructMapper<DistributionRuleDTO, ResourceDistributionRuleViewDTO> {
    ResourceDistributionRuleMapStruct INSTANCE = Mappers.getMapper(ResourceDistributionRuleMapStruct.class);

    @Mappings({
        @Mapping(source = "sspProductList", target = "resourcePackageProductList"),
    })
    @Override
    ResourceDistributionRuleViewDTO sourceToTarget(DistributionRuleDTO distributionRuleDTO);

    @Mappings({
        @Mapping(source = "resourcePackageProductList", target = "sspProductList"),
    })
    @Override
    DistributionRuleDTO targetToSource(ResourceDistributionRuleViewDTO resourceDistributionRuleViewDTO);

}