package com.taobao.ad.brand.bp.adapter.port.converter.resourcepackage.mapstruct;

import java.util.List;

import com.alibaba.ad.nb.packages.v2.client.dto.salegroup.DistributionRuleDTO;

import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourceDistributionRuleViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/23
 */
public abstract class ResourceDistributionRuleMapStructDecorator implements ResourceDistributionRuleMapStruct {

    private final ResourceDistributionRuleMapStruct resourceDistributionRuleMapStruct;

    public ResourceDistributionRuleMapStructDecorator(ResourceDistributionRuleMapStruct resourceDistributionRuleMapStruct) {
        this.resourceDistributionRuleMapStruct = resourceDistributionRuleMapStruct;
    }

    @Override
    public ResourceDistributionRuleViewDTO sourceToTarget(DistributionRuleDTO distributionRuleDTO) {
        ResourceDistributionRuleViewDTO resourceDistributionRuleViewDTO = resourceDistributionRuleMapStruct.sourceToTarget(distributionRuleDTO);
        List<ResourcePackageProductViewDTO> resourcePackageProductList = resourceDistributionRuleViewDTO.getResourcePackageProductList();
        if (resourceDistributionRuleViewDTO.getMinQuality() == null) {
            resourceDistributionRuleViewDTO.setMinQuality(0);
        }
        if (resourceDistributionRuleViewDTO.getMaxQuality() == null) {
            resourceDistributionRuleViewDTO.setMaxQuality(resourcePackageProductList.size());
        }
        if (resourceDistributionRuleViewDTO.getRatio() == null && "N".equals(resourceDistributionRuleViewDTO.getCategory())) {
            resourceDistributionRuleViewDTO.setRatio(10000);
        }
        return resourceDistributionRuleViewDTO;
    }

    @Override
    public DistributionRuleDTO targetToSource(ResourceDistributionRuleViewDTO resourceDistributionRuleViewDTO) {
        return resourceDistributionRuleMapStruct.targetToSource(resourceDistributionRuleViewDTO);
    }
}