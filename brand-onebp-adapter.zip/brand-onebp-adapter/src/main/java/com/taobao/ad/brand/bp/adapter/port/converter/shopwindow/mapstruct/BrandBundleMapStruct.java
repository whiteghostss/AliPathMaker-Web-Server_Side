
package com.taobao.ad.brand.bp.adapter.port.converter.shopwindow.mapstruct;

import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandBundleViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSkuViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.perform.client.dto.shopwindow.bundle.BundleViewDTO;
import com.taobao.ad.brand.perform.client.dto.shopwindow.sku.SkuViewDTO;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * DTO与领域模型实体映射
 * @author ddd-coder-init
 * @date 2020/12/12
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface BrandBundleMapStruct extends BaseMapStructMapper<BundleViewDTO, BrandBundleViewDTO> {
	BrandBundleMapStruct INSTANCE = Mappers.getMapper(BrandBundleMapStruct.class);
}

