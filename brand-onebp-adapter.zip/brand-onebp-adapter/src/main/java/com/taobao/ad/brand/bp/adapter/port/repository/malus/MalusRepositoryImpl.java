package com.taobao.ad.brand.bp.adapter.port.repository.malus;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.hermes.framework.utils.BeanUtils;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.MemberSAO;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.malus.MalusSAO;
import com.taobao.ad.brand.bp.client.dto.creative.crop.MalusCropViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.malus.MalusRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 素材拓版
 * @author shiyan
 * @date 2024/8/16
 **/
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class MalusRepositoryImpl implements MalusRepository {

    private final MalusSAO malusSAO;
    private final MemberSAO memberSAO;

    @Value("${kb.access.channelId}")
    private Long channelId;
    @Value("${kb.access.key}")
    private String key;

    @Override
    public String asyncBatchCrop(ServiceContext serviceContext, List<MalusCropViewDTO> cropViewDTOList) {
        AssertUtil.notEmpty(cropViewDTOList,"拓版参数不允许为空");
        List<Map<String, Object>> cropMapList = cropViewDTOList.stream().map(BeanUtils::describe).collect(Collectors.toList());
        return malusSAO.asyncBatchCrop(initAuth(),cropMapList,initOps(serviceContext.getMemberId()));
    }

    private Map<String,Object> initOps(Long memberId){
        Long tbUserId = memberSAO.getTbNumIdByMemberId(memberId);
        String memberName = memberSAO.getMemberNameById(memberId);
        AssertUtil.notNull(tbUserId,"淘宝用户不存在");
        Map<String, Object> opsMap = Maps.newHashMap();
        opsMap.put("userId",tbUserId);
        opsMap.put("nickname",memberName);
        return opsMap;
    }

    /**
     * 初始化auth
     * @return
     */
    private  Map<String,Object> initAuth(){
        Map<String, Object> authMap = Maps.newHashMap();
        authMap.put("channelId",channelId);
        authMap.put("key",key);
        return authMap;
    }
}
