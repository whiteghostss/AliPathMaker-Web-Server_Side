package com.taobao.ad.brand.bp.adapter.port.converter.agent;

import com.alibaba.ad.brand.ai.client.dto.LlmAgentDirectCallParam;
import com.taobao.ad.brand.bp.client.dto.agent.LlmAgentDirectCallParamViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.springframework.stereotype.Component;

/**
 * @author jixiu.lj
 * @date 2023/3/23 22:31
 */
@Component
public class LlmAgentDirectCallParamConverter extends BaseViewDTOConverter<LlmAgentDirectCallParam, LlmAgentDirectCallParamViewDTO> {
    @Override
    public BaseMapStructMapper<LlmAgentDirectCallParam, LlmAgentDirectCallParamViewDTO> getBaseMapStructMapper() {
        return LlmAgentDirectCallParamMapStruct.INSTANCE;
    }
}
