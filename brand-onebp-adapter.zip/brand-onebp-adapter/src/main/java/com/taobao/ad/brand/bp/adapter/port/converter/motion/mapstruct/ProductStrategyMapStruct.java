package com.taobao.ad.brand.bp.adapter.port.converter.motion.mapstruct;

import com.alibaba.ad.nb.packages.v2.client.dto.motion.ProductStrategyDTO;
import com.taobao.ad.brand.bp.client.dto.motion.ProductStrategyViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/18
 **/
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, uses = {ProductBandPriceStrategyMapStruct.class})
public interface ProductStrategyMapStruct extends BaseMapStructMapper<ProductStrategyDTO, ProductStrategyViewDTO> {

    ProductStrategyMapStruct INSTANCE = Mappers.getMapper(ProductStrategyMapStruct.class);

    @Mappings({
            @Mapping(source = "productBandPriceStrategyList", target = "productBandPriceStrategyViewDTOList"),
    })
    @Override
    ProductStrategyViewDTO sourceToTarget(ProductStrategyDTO productStrategyDTO);

    @Mappings({
            @Mapping(source = "productBandPriceStrategyViewDTOList", target = "productBandPriceStrategyList"),
    })
    @Override
    ProductStrategyDTO targetToSource(ProductStrategyViewDTO productStrategyViewDTO);
}
