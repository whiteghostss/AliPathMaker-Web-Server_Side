package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.perform;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.globaltag.GlobalTagViewDTO;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.perform.client.api.campaign.PerfCampaignCommandService;
import com.taobao.ad.brand.perform.client.api.globaltag.PerfGlobalTagQueryService;
import com.taobao.ad.brand.perform.client.api.shopwindow.spu.PerfBundleQueryService;
import com.taobao.ad.brand.perform.client.api.shopwindow.spu.PerfSkuQueryService;
import com.taobao.ad.brand.perform.client.api.shopwindow.spu.PerfSpuCommandService;
import com.taobao.ad.brand.perform.client.api.shopwindow.spu.PerfSpuQueryService;
import com.taobao.ad.brand.perform.client.dto.globaltag.query.GlobalTagQueryViewDTO;
import com.taobao.ad.brand.perform.client.dto.shopwindow.bundle.BundleQueryViewDTO;
import com.taobao.ad.brand.perform.client.dto.shopwindow.bundle.BundleViewDTO;
import com.taobao.ad.brand.perform.client.dto.shopwindow.sku.SkuViewDTO;
import com.taobao.ad.brand.perform.client.dto.shopwindow.spu.SkuQueryViewDTO;
import com.taobao.ad.brand.perform.client.dto.shopwindow.spu.SpuQueryViewDTO;
import com.taobao.ad.brand.perform.client.dto.shopwindow.spu.SpuViewDTO;
import com.taobao.ad.brand.perform.client.dto.shopwindow.spu.marketingrule.SpuCheckMarketingRuleParamViewDTO;
import com.taobao.ad.brand.perform.client.dto.shopwindow.spu.marketingrule.SpuCheckMarketingRuleResultViewDTO;
import com.taobao.ad.brand.perform.client.dto.shopwindow.spu.marketingrule.SpuCheckMarketingRuleViewDTO;
import com.taobao.ad.brand.perform.client.enums.shopwindow.BundleStatusEnum;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/03/08
 */
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class PerformSAO extends BaseSAO {
    private final PerfCampaignCommandService perfCampaignCommandService;
    private final PerfGlobalTagQueryService perfGlobalTagQueryService;
    private final PerfSpuQueryService perfSpuQueryService;
    private final PerfSkuQueryService perfSkuQueryService;
    private final PerfSpuCommandService perfSpuCommandService;
    private final PerfBundleQueryService perfBundleQueryService;


    /**
     * 日更结束回调
     */
    public void doCampaignDailyEnd() {
        RogerLogger.info("日更结束: 调用履约接口");
        Response response = perfCampaignCommandService.doCampaignDailyEnd();
        AssertUtil.assertTrue(response.isSuccess(), response.getErrorMsg());
    }

    public List<GlobalTagViewDTO> getGlobalTagList(ServiceContext serviceContext, GlobalTagQueryViewDTO queryViewDTO){
        AssertUtil.notNull(queryViewDTO, "查询参数不能为空");
        MultiResponse<GlobalTagViewDTO> response = perfGlobalTagQueryService.findGlobalTagPage(serviceContext, queryViewDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    public Set<String> getSortedScoreSet(ServiceContext serviceContext, List<Long> idList){
        AssertUtil.notNull(idList, "查询参数不能为空");
        GlobalTagQueryViewDTO queryViewDTO = new GlobalTagQueryViewDTO();
        queryViewDTO.setIdList(idList);
        MultiResponse<GlobalTagViewDTO> response = perfGlobalTagQueryService.findGlobalTagPage(serviceContext, queryViewDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR.of(response.getErrorMsg()));
        Set<String> scoreSet = Sets.newHashSet();
        if (CollectionUtils.isNotEmpty(response.getResult())) {
            List<GlobalTagViewDTO> globalTagViewDTOS = response.getResult();
            scoreSet = globalTagViewDTOS.stream().flatMap(it -> it.getScoreList().stream()).distinct().sorted().map(Object::toString).collect(Collectors.toCollection(LinkedHashSet::new));
        }
        return scoreSet;
    }

    public List<SpuViewDTO> findSpuList(ServiceContext serviceContext, SpuQueryViewDTO spuQueryViewDTO) {
        RogerLogger.info("PerformSAO findSpuList 调用 perfSpuQueryService.findList 接口参数：{}", JSONObject.toJSONString(spuQueryViewDTO));
        MultiResponse<SpuViewDTO> response = perfSpuQueryService.findList(serviceContext, spuQueryViewDTO);
        RogerLogger.info("PerformSAO findSpuList 调用 perfSpuQueryService.findList 返回结果：{}", JSONObject.toJSONString(response));
        AssertUtil.assertTrue(response);
        return response.getResult();
    }

    public SpuViewDTO getSpuDetail(SpuQueryViewDTO spuQueryViewDTO) {
        RogerLogger.info("PerformSAO getSpuDetail 调用 perfSpuQueryService.detail 接口参数：{}", JSONObject.toJSONString(spuQueryViewDTO));
        SingleResponse<SpuViewDTO> response = perfSpuQueryService.detail(new ServiceContext(), spuQueryViewDTO);
        RogerLogger.info("PerformSAO getSpuDetail 调用 perfSpuQueryService.detail 返回结果：{}", JSONObject.toJSONString(response));
        AssertUtil.assertTrue(response);
        return response.getResult();
    }

    public List<SkuViewDTO> findSkuList(SkuQueryViewDTO skuQueryViewDTO) {
        RogerLogger.info("BrandPerformSAO findSkuList 调用 perfSkuQueryService.findList 接口参数：{}", JSONObject.toJSONString(skuQueryViewDTO));
        MultiResponse<SkuViewDTO> response = perfSkuQueryService.findList(new ServiceContext(), skuQueryViewDTO);
        RogerLogger.info("BrandPerformSAO findSkuList 调用 perfSkuQueryService.findList 返回结果：{}", JSONObject.toJSONString(response));
        AssertUtil.assertTrue(response);
        return response.getResult();
    }

    public SkuViewDTO getSkuDetail(SkuQueryViewDTO skuQueryViewDTO) {
        RogerLogger.info("BrandPerformSAO getSkuDetail 调用 perfSkuQueryService.detail 接口参数：{}", JSONObject.toJSONString(skuQueryViewDTO));
        SingleResponse<SkuViewDTO> response = perfSkuQueryService.detail(new ServiceContext(), skuQueryViewDTO);
        RogerLogger.info("BrandPerformSAO getSkuDetail 调用 perfSkuQueryService.detail 返回结果：{}", JSONObject.toJSONString(response));
        AssertUtil.assertTrue(response);
        return response.getResult();
    }

    public SpuCheckMarketingRuleResultViewDTO checkMarketingRule(ServiceContext serviceContext,List<SpuCheckMarketingRuleParamViewDTO> spuRuleParamList){
        SingleResponse<SpuCheckMarketingRuleResultViewDTO> response = perfSpuCommandService.checkMarketingRule(serviceContext, spuRuleParamList);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR,response.getErrorMsg());
        return response.getResult();
    }

    public List<SpuCheckMarketingRuleViewDTO> getCheckMarketingRule(ServiceContext serviceContext){
        MultiResponse<SpuCheckMarketingRuleViewDTO> response = perfSpuCommandService.getCheckMarketingRule(serviceContext);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR,response.getErrorMsg());
        return response.getResult();
    }

    /**
     * 查询套餐包
     * @param serviceContext
     * @param bundleQueryViewDTO
     * @return
     */
    public BundleViewDTO getBundleDetail(ServiceContext serviceContext, BundleQueryViewDTO bundleQueryViewDTO){
        SingleResponse<BundleViewDTO> response = perfBundleQueryService.detail(serviceContext, bundleQueryViewDTO);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR,response.getErrorMsg());
        return response.getResult();
    }

    /**
     * 查询套餐包列表
     * @param serviceContext
     * @param bundleQueryViewDTO
     * @return
     */
    public List<BundleViewDTO> findBundleList(ServiceContext serviceContext, BundleQueryViewDTO bundleQueryViewDTO){
        MultiResponse<BundleViewDTO> response = perfBundleQueryService.findList(serviceContext, bundleQueryViewDTO);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR,response.getErrorMsg());
        return response.getResult();
    }


}
