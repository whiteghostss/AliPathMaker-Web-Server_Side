package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.monitor;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.nb.basic.client.api.monitor.MonitorCommandService;
import com.alibaba.ad.nb.basic.client.api.monitor.MonitorQueryService;
import com.alibaba.ad.nb.basic.client.dto.monitor.BizMonitorCodeDTO;
import com.alibaba.ad.nb.basic.client.dto.monitor.MonitorQueryDTO;
import com.alibaba.ad.nb.basic.client.dto.monitor.MonitorRuleXMediaDTO;
import com.alibaba.ad.nb.direct.client.context.NbDirectServiceContext;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.taobao.ad.brand.bp.client.dto.monitor.MonitorRuleXMediaViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class MonitorSAO extends BaseSAO {
    private final MonitorQueryService monitorQueryService;

    private final MonitorCommandService monitorCommandService;


    public List<BizMonitorCodeDTO> queryMonitorCodeList(NbDirectServiceContext serviceContext, MonitorQueryDTO monitorQueryDTO){

        MultiResponse<BizMonitorCodeDTO> response = monitorQueryService.queryMonitor(serviceContext,monitorQueryDTO);
        AssertUtil.assertTrue(response);
        return response.getResult();
    }

    public void addMonitorRuleXMedia(NbDirectServiceContext nbDirectServiceContext, MonitorRuleXMediaDTO monitorRuleXMediaDTO) {
        SingleResponse<Integer> response =  monitorCommandService.addMonitorRuleXMedia(nbDirectServiceContext,monitorRuleXMediaDTO);
        AssertUtil.assertTrue(response);
    }

}
