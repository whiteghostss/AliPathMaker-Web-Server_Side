package com.taobao.ad.brand.bp.adapter.port.converter.sales;

import com.alibaba.ad.nb.sales.dto.project.ProjectDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.sales.mapstruct.ProjectMapStruct;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesProjectViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.springframework.stereotype.Component;

/**
 * @author yanjingang
 * @date 2023/3/16
 */
@Component
public class ProjectViewDTOConverter extends BaseViewDTOConverter<ProjectDTO, SalesProjectViewDTO> {

    @Override
    public BaseMapStructMapper<ProjectDTO, SalesProjectViewDTO> getBaseMapStructMapper() {
        return ProjectMapStruct.INSTANCE;
    }
}
