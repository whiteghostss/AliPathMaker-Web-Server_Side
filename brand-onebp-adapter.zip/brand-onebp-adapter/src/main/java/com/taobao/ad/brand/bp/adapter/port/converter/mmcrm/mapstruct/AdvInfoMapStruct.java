package com.taobao.ad.brand.bp.adapter.port.converter.mmcrm.mapstruct;

import com.taobao.ad.brand.bp.client.dto.campaigngroup.CrmAdvInfoViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.mm.crm.service.dto.adv.AdvInfoDTO;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author yanjingang
 * @date 2024/07/12
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface AdvInfoMapStruct extends BaseMapStructMapper<AdvInfoDTO, CrmAdvInfoViewDTO> {

    AdvInfoMapStruct INSTANCE = Mappers.getMapper(AdvInfoMapStruct.class);
}
