package com.taobao.ad.brand.bp.adapter.port.converter.motion;

import com.alibaba.ad.nb.packages.v2.client.dto.motion.IntelligentMotionDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.motion.mapstruct.IntelligentMotionMapStruct;
import com.taobao.ad.brand.bp.client.dto.motion.IntelligentMotionViewDTO;

import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.springframework.stereotype.Component;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/18
 **/
@Component
public class IntelligentMotionDTOConverter extends BaseViewDTOConverter<IntelligentMotionDTO, IntelligentMotionViewDTO> {

    @Override
    public BaseMapStructMapper<IntelligentMotionDTO, IntelligentMotionViewDTO> getBaseMapStructMapper() {
        return IntelligentMotionMapStruct.INSTANCE;
    }

    public IntelligentMotionViewDTO convertDTO2ViewDTO(IntelligentMotionDTO source) {
        return IntelligentMotionMapStruct.INSTANCE.sourceToTarget(source);
    }

    public IntelligentMotionDTO convertViewDTO2DTO(IntelligentMotionViewDTO source) {
        return IntelligentMotionMapStruct.INSTANCE.targetToSource(source);
    }
}
