package com.taobao.ad.brand.bp.adapter.port.repository.mediarule;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.media.protect.MediaProtectRuleViewDTO;
import com.alibaba.ad.brand.sdk.convert.custom.viewdto.media.MediaProtectRuleViewDTO2DTOConvertProcessor;
import com.alibaba.ad.organizer.dto.media.MediaProtectRuleDTO;
import com.alibaba.ad.universal.sdk.convert.custom.onebp.provider.OneBpConvertProcessorProvider;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.mediarule.MediaProtectRuleSAO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.mediarule.query.MediaProtectRuleQueryViewDTO;
import com.taobao.ad.brand.bp.domain.mediarule.MediaProtectRuleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * 保护规则
 * @author linhua.deng
 */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class MediaProtectRuleRepositoryImpl implements MediaProtectRuleRepository {

    private final MediaProtectRuleSAO mediaProtectRuleSAO;
    private MediaProtectRuleViewDTO2DTOConvertProcessor PROCESSOR =
            OneBpConvertProcessorProvider.getViewDTO2DTOConvertProcessor(MediaProtectRuleViewDTO2DTOConvertProcessor.class);

    @Override
    public Long addProtectRule(ServiceContext context, MediaProtectRuleViewDTO viewDTO) {
        MediaProtectRuleDTO mediaProtectRuleDTO = PROCESSOR.viewDTO2DTO(viewDTO);
        return mediaProtectRuleSAO.addProtectRule(context,mediaProtectRuleDTO);
    }

    @Override
    public Integer updateProtectRule(ServiceContext context, MediaProtectRuleViewDTO viewDTO) {
        MediaProtectRuleDTO mediaProtectRuleDTO = PROCESSOR.viewDTO2DTO(viewDTO);
        return mediaProtectRuleSAO.updateProtectRule(context, mediaProtectRuleDTO);
    }

    @Override
    public Integer updateProtectRuleStatus(ServiceContext context, List<Long> ids, Integer status) {
        return mediaProtectRuleSAO.updateProtectRuleStatus(context, ids, status);
    }

    @Override
    public MediaProtectRuleViewDTO getProtectRule(ServiceContext context, Long id) {
        MediaProtectRuleDTO mediaProtectRuleDTO = mediaProtectRuleSAO.getProtectRule(context, id);
        return (mediaProtectRuleDTO == null) ? null : PROCESSOR.dto2ViewDTO(mediaProtectRuleDTO);
    }

    @Override
    public PageResultViewDTO<MediaProtectRuleViewDTO> findProtectRuleList(ServiceContext context, MediaProtectRuleQueryViewDTO queryViewDTO) {
        PageResultViewDTO<MediaProtectRuleDTO> listWithPage = mediaProtectRuleSAO.findListWithPage(context, queryViewDTO);
        List<MediaProtectRuleViewDTO> resultList = listWithPage.getList().stream().map(dto -> PROCESSOR.dto2ViewDTO(dto)).collect(Collectors.toList());
        return PageResultViewDTO.of(resultList, listWithPage.getCount());
    }

    @Override
    public List<MediaProtectRuleViewDTO> findList(ServiceContext serviceContext, MediaProtectRuleQueryViewDTO queryViewDTO) {
        List<MediaProtectRuleDTO> dataList = mediaProtectRuleSAO.findList(serviceContext, queryViewDTO);
        return PROCESSOR.dtoList2ViewDTOList(dataList);
    }

    @Override
    public MediaProtectRuleViewDTO getTopOneByName(ServiceContext serviceContext, String uniqueName) {
        MediaProtectRuleDTO mediaProtectRuleDTO = mediaProtectRuleSAO.getTopOneByName(serviceContext, uniqueName);
        return Objects.nonNull(mediaProtectRuleDTO) ? PROCESSOR.dto2ViewDTO(mediaProtectRuleDTO) : null;
    }
}
