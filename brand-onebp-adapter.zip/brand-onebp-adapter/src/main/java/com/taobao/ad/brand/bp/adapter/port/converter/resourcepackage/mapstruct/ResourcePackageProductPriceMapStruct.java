package com.taobao.ad.brand.bp.adapter.port.converter.resourcepackage.mapstruct;


import com.alibaba.ad.nb.packages.v2.client.dto.product.ProductBandPriceDTO;

import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductPriceViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/23
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ResourcePackageProductPriceMapStruct extends BaseMapStructMapper<ProductBandPriceDTO, ResourcePackageProductPriceViewDTO> {
    ResourcePackageProductPriceMapStruct INSTANCE = Mappers.getMapper(ResourcePackageProductPriceMapStruct.class);

}