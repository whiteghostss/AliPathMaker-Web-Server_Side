package com.taobao.ad.brand.bp.adapter.port.converter.sales.mapstruct;

import com.alibaba.ad.nb.sales.dto.contract.ContractBalance;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesContractAmountViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author yanjingang
 * @date 2023/03/23
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ContractAmountMapStruct extends BaseMapStructMapper<ContractBalance, SalesContractAmountViewDTO> {
    ContractAmountMapStruct INSTANCE = Mappers.getMapper(ContractAmountMapStruct.class);

    @Mappings({
            @Mapping(source = "amount", target = "discountAmount"),
            @Mapping(source = "balance", target = "waitRepayAmount")
    })
    @Override
    SalesContractAmountViewDTO sourceToTarget(ContractBalance contractBalance);

    @Mappings({
            @Mapping(source = "discountAmount", target = "amount"),
            @Mapping(source = "waitRepayAmount", target = "balance")
    })
    @Override
    ContractBalance targetToSource(SalesContractAmountViewDTO salesContractAmountViewDTO);
}