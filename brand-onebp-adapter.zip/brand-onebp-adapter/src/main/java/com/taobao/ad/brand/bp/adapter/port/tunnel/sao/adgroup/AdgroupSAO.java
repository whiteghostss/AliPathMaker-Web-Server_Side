package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.adgroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.biz.definition.constants.Product;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupOnlineStatusEnum;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupStatusEnum;
import com.alibaba.ad.brand.sdk.constant.adgroup.setting.BrandAdgroupSettingKeyEnum;
import com.alibaba.ad.nb.ssp.constant.newproduct.ProductLineEnum;
import com.alibaba.ad.organizer.api.AdgroupCommandService;
import com.alibaba.ad.organizer.api.AdgroupQueryService;
import com.alibaba.ad.organizer.dto.AdgroupDTO;
import com.alibaba.ad.organizer.dto.query.AdgroupQuery;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.error.ErrorCodeAware;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.alibaba.solar.common.dto.QueryOptionDTO;
import com.alibaba.solar.common.query.dto.PageQueryDTO;
import com.alibaba.solar.common.query.dto.QueryDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.BizKeywordTypeEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.PageRequestUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Component
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AdgroupSAO extends BaseSAO {
    private final AdgroupCommandService adgroupCommandService;
    private final AdgroupQueryService adgroupQueryService;

    public Long addAdgroup(ServiceContext serviceContext, AdgroupDTO adgroupDTO) {
        SingleResponse<Long> response = adgroupCommandService.addAdgroup(serviceContext, adgroupDTO);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    public Integer updateAdgroup(ServiceContext serviceContext, AdgroupDTO adgroupDTO) {
        SingleResponse<Integer> response = adgroupCommandService.updateAdgroupAll(serviceContext, adgroupDTO);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }
    /**
     * 部分更新
     * */
    public Integer updateAdgroupPart(ServiceContext serviceContext, AdgroupDTO adgroupDTO) {
        SingleResponse<Integer> response = adgroupCommandService.updateAdgroupPart(serviceContext, adgroupDTO);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 批量清除adgroup setting属性
     * @param serviceContext 上下文
     * @param adgroupIdList  单元列表
     * @param settingKeyList settingKey
     * @return 结果
     */
    public Integer deleteAdgroupSettingBatch(ServiceContext serviceContext, List<Long> adgroupIdList, List<String> settingKeyList) {
        SingleResponse<Integer> response = adgroupCommandService.deleteAdgroupSettingBatch(serviceContext, adgroupIdList, settingKeyList);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }


    public void batchUpdateAdgroupStatus(ServiceContext serviceContext, List<Long> ids,Integer status) {
        List<AdgroupDTO> adgroupDTOList = Lists.newArrayList();
        for (Long id:ids){

            AdgroupDTO adgroupDTO = new AdgroupDTO();
            adgroupDTO.setId(id);
            adgroupDTO.setOnlineStatus(status);
            adgroupDTOList.add(adgroupDTO);

        }
        MultiResponse<AdgroupDTO> response = adgroupCommandService.updateAdgroupPartBatch(serviceContext, adgroupDTOList);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        if(CollectionUtils.isNotEmpty(response.getPartialErrors())){
            String errorMsg = response.getPartialErrors().stream().map(ErrorCodeAware::getErrMsg).collect(Collectors.joining(";"));
            throw new BrandOneBPException(BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(errorMsg));
        }
    }

    /**
     * 批量部分更新AdGroup
     * @param serviceContext
     * @param adgroupDTOList
     */
    public void batchUpdateAdgroupPart(ServiceContext serviceContext, List<AdgroupDTO> adgroupDTOList) {
        MultiResponse<AdgroupDTO> response = adgroupCommandService.updateAdgroupPartBatch(serviceContext, adgroupDTOList);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        if(CollectionUtils.isNotEmpty(response.getPartialErrors())){
            String errorMsg = response.getPartialErrors().stream().map(ErrorCodeAware::getErrMsg).collect(Collectors.joining(";"));
            throw new BrandOneBPException(BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(errorMsg));
        }
    }

    public MultiResponse<AdgroupDTO> findAdgroupPageList(ServiceContext serviceContext, AdgroupQueryViewDTO query){
        PageQueryDTO pageQueryDTO = PageQueryDTO.createQuery();
        initQueryDTO(serviceContext,pageQueryDTO,query);
        pageQueryDTO.setSkip(query.getStart());
        pageQueryDTO.setLimit(query.getPageSize());
        QueryOptionDTO queryOptionDTO = QueryOptionDTO.propertyRequired(true);

        MultiResponse<AdgroupDTO> response = adgroupQueryService.findAdgroupPage(serviceContext, pageQueryDTO,queryOptionDTO);

        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response;

    }
    public List<AdgroupDTO> findAdgroupListNoPage(ServiceContext serviceContext, AdgroupQueryViewDTO adgroupQueryViewDTO){
        QueryDTO queryDTO = QueryDTO.createQuery();

        initQueryDTO(serviceContext,queryDTO,adgroupQueryViewDTO);
        QueryOptionDTO queryOptionDTO = QueryOptionDTO.propertyRequired(true);

        MultiResponse<AdgroupDTO> response = adgroupQueryService.findAdgroupList(serviceContext, queryDTO,queryOptionDTO);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();

    }


    /**
     * 查询基础信息无分页
     *
     * @param serviceContext      上下文
     * @param adgroupQueryViewDTO
     * @return
     */
    public List<AdgroupDTO> findAdgroupBasicListNoPage(ServiceContext serviceContext, AdgroupQueryViewDTO adgroupQueryViewDTO) {
        QueryDTO queryDTO = QueryDTO.createQuery();

        initQueryDTO(serviceContext, queryDTO, adgroupQueryViewDTO);
        QueryOptionDTO queryOptionDTO = QueryOptionDTO.propertyRequired(false);

        List<AdgroupDTO> resultAdgroupList = Lists.newArrayList();
        //中台限制最多查询5000个
        int pageSize = 5000;
        PageRequestUtil.execute(idx -> {
                    adgroupQueryViewDTO.setStart((idx - 1) * pageSize);
                    MultiResponse<AdgroupDTO> response = adgroupQueryService.findAdgroupList(serviceContext, queryDTO, queryOptionDTO);
                    AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
                    return response;
                }, (idx, response) -> response.isSuccess() && response.getTotal() >= (idx - 1) * pageSize,
                response -> resultAdgroupList.addAll(response.getResult()));
        return resultAdgroupList;
    }



    public Integer getCount(ServiceContext serviceContext, AdgroupQueryViewDTO adgroupQueryViewDTO){
        QueryDTO queryDTO = QueryDTO.createQuery();

        initQueryDTO(serviceContext,queryDTO,adgroupQueryViewDTO);
        SingleResponse<Integer> response = adgroupQueryService.getAdgroupCount(serviceContext, queryDTO);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();

    }

    public AdgroupDTO getAdgroupById(ServiceContext serviceContext, Long adgroupId) {
        if (null == adgroupId){
            return null;
        }
        QueryOptionDTO optionDTO = QueryOptionDTO.propertyRequired(true);
        SingleResponse<AdgroupDTO> response = adgroupQueryService.getAdgroupById(serviceContext, adgroupId,optionDTO);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }
    /**
     * 根据名称查询单元
     * @param serviceContext
     * @param excludeAdgroupId
     * @param title
     * */
    public AdgroupDTO findTopOneAdgroupByTitle(ServiceContext serviceContext,Long excludeAdgroupId,String title){
        PageQueryDTO queryDTO =  PageQueryDTO.createQuery();
        queryDTO.andCondition(AdgroupQuery.title.eq(title));
        if (Objects.nonNull(excludeAdgroupId)){
            queryDTO.andCondition(AdgroupQuery.id.notEq(excludeAdgroupId));
        }
        QueryOptionDTO queryOptionDTO = QueryOptionDTO.propertyRequired(false);
        queryDTO.setSkip(0);
        queryDTO.setLimit(1);
        MultiResponse<AdgroupDTO> response = adgroupQueryService.findAdgroupPage(serviceContext, queryDTO,queryOptionDTO);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        if (CollectionUtils.isNotEmpty(response.getResult())){

            return response.getResult().get(0);
        }else{
            return null;
        }
    }

    /**
     * 根据计划id删除单元
     * @param serviceContext
     * @param adgroupIds
     * @return
     * */
    public Integer deleteAdgroupByIds(ServiceContext serviceContext,List<Long> adgroupIds){

        SingleResponse<Integer> response = adgroupCommandService.deleteAdgroupBatch(serviceContext, adgroupIds);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();

    }

    /**
     * 根据单元id批量删除单元setting属性
     * @param serviceContext
     * @param adgroupId
     * @return
     * */
    public Integer deleteAdgroupSettingBatch(ServiceContext serviceContext, Long adgroupId, List<String> settingKeyList) {
        SingleResponse<Integer> response = adgroupCommandService.deleteAdgroupSettingBatch(serviceContext, Lists.newArrayList(adgroupId), settingKeyList);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();

    }
    @NotNull
    private void initQueryDTO(ServiceContext serviceContext,QueryDTO queryDTO,AdgroupQueryViewDTO adgroupQueryViewDTO) {
//        PageQueryDTO queryDTO =  PageQueryDTO.createQuery();
        if (adgroupQueryViewDTO.getCustomizedOrderBy() != null) {
            queryDTO.orderBy(adgroupQueryViewDTO.getCustomizedOrderBy());
        }
        queryDTO.orderBy(AdgroupQuery.gmtCreate.descOrder());

        if (BizCodeEnum.BRANDONEBP.getBizCode().equals(serviceContext.getBizCode())) {
            serviceContext.setProductId(Product.BRAND_ONEBP_BRAND.getId());
            //queryDTO.andCondition(AdgroupQuery.sceneId.in(Lists.newArrayList(426, 374)));
        } else if (CollectionUtils.isNotEmpty(adgroupQueryViewDTO.getSceneIds())) {
            queryDTO.andCondition(AdgroupQuery.sceneId.in(adgroupQueryViewDTO.getSceneIds()));
        } else {
            if (Objects.nonNull(ServiceContextUtil.getSceneId(serviceContext))) {
                queryDTO.andCondition(AdgroupQuery.sceneId.eq(ServiceContextUtil.getSceneId(serviceContext)));
            }
        }
        if (StringUtils.isBlank(adgroupQueryViewDTO.getKeywordType())){
            adgroupQueryViewDTO.setKeywordType(BizKeywordTypeEnum.ADGROUP_NAME.getName());
        }
        if (Objects.nonNull(adgroupQueryViewDTO.getTargetType())){
            queryDTO.andCondition(AdgroupQuery.settingKeyValue.eq(BrandAdgroupSettingKeyEnum.TARGET_TYPE.getKey(),String.valueOf(adgroupQueryViewDTO.getTargetType())));
        }
        if (Objects.nonNull(adgroupQueryViewDTO.getBottomType())){
            queryDTO.andCondition(AdgroupQuery.settingKeyValue.eq(BrandAdgroupSettingKeyEnum.BOTTOM_TYPE.getKey(),String.valueOf(adgroupQueryViewDTO.getBottomType())));
        }
        if(StringUtils.isNotBlank(adgroupQueryViewDTO.getKeyword())){

            if (BizKeywordTypeEnum.ADGROUP_NAME.getName().equals(adgroupQueryViewDTO.getKeywordType())){
                queryDTO.andCondition(AdgroupQuery.title.like(adgroupQueryViewDTO.getKeyword()));

            }
            if (BizKeywordTypeEnum.ADGROUP_ID.getName().equals(adgroupQueryViewDTO.getKeywordType())){
                try{
                    Long id = Long.parseLong(adgroupQueryViewDTO.getKeyword());
                    queryDTO.andCondition(AdgroupQuery.id.eq(id));
                }catch (Exception ex){
                    //查询参数不合法的情况下， 设置为-1，查询为空
                    queryDTO.andCondition(AdgroupQuery.id.eq(-1L));
//                    throw new BrandOneBPException("参数不合法");
                }


            }

        }
        if(CollectionUtils.isNotEmpty(adgroupQueryViewDTO.getIds())){
            queryDTO.andCondition(AdgroupQuery.id.in(adgroupQueryViewDTO.getIds()));

        }
        if(CollectionUtils.isNotEmpty(adgroupQueryViewDTO.getExcludedAdgroupIds())){
            queryDTO.andCondition(AdgroupQuery.id.notIn(adgroupQueryViewDTO.getExcludedAdgroupIds()));

        }
        if (Objects.nonNull(adgroupQueryViewDTO.getCampaignId())){
            queryDTO.andCondition(AdgroupQuery.campaignId.eq(adgroupQueryViewDTO.getCampaignId()));

        }
        if (CollectionUtils.isNotEmpty(adgroupQueryViewDTO.getCampaignIds())){
            queryDTO.andCondition(AdgroupQuery.campaignId.in(adgroupQueryViewDTO.getCampaignIds()));

        }
        if (Objects.nonNull(adgroupQueryViewDTO.getCampaignGroupId())){
            queryDTO.andCondition(AdgroupQuery.settingKeyValue.eq(BrandAdgroupSettingKeyEnum.CAMPAIGN_GROUP_ID.getKey(),String.valueOf(adgroupQueryViewDTO.getCampaignGroupId())));

        }
        if(CollectionUtils.isNotEmpty(adgroupQueryViewDTO.getCampaignGroupIds())){
            List<String> campaignGroupIds = adgroupQueryViewDTO.getCampaignGroupIds().stream().map(e->String.valueOf(e)).collect(Collectors.toList());
            queryDTO.andCondition(AdgroupQuery.settingKeyValue.in(BrandAdgroupSettingKeyEnum.CAMPAIGN_GROUP_ID.getKey(),campaignGroupIds));
        }


        //状态查询
        if (Objects.nonNull(adgroupQueryViewDTO.getStatus())){

            Date nowDate = new Date();
            if(BrandAdgroupStatusEnum.DRAFT.getCode().equals(adgroupQueryViewDTO.getStatus())){
                queryDTO.andCondition(AdgroupQuery.onlineStatus.eq(BrandAdgroupOnlineStatusEnum.DRAFT.getCode()));
            }else if(BrandAdgroupStatusEnum.CLOSE.getCode().equals(adgroupQueryViewDTO.getStatus())){
                queryDTO.andCondition(AdgroupQuery.onlineStatus.eq(BrandAdgroupOnlineStatusEnum.CLOSED.getCode()));

            }else{
                queryDTO.andCondition(AdgroupQuery.onlineStatus.eq(BrandAdgroupOnlineStatusEnum.ONLINE.getCode()));
                if(BrandAdgroupStatusEnum.WAIT_TO_EXECUTE.getCode().equals(adgroupQueryViewDTO.getStatus())){
                    queryDTO.andCondition(AdgroupQuery.startTime.gt(nowDate));
                }
                else if(BrandAdgroupStatusEnum.EXECUTING.getCode().equals(adgroupQueryViewDTO.getStatus())){
                    queryDTO.andCondition(AdgroupQuery.startTime.lt(nowDate));
                    queryDTO.andCondition(AdgroupQuery.endTime.gt(nowDate));
                }
                else if(BrandAdgroupStatusEnum.EXECUTED.getCode().equals(adgroupQueryViewDTO.getStatus())){
                    queryDTO.andCondition(AdgroupQuery.endTime.lt(nowDate));
                }
            }
        }
        if(Objects.nonNull(adgroupQueryViewDTO.getStartTime())){
            queryDTO.andCondition(AdgroupQuery.endTime.gtEq(adgroupQueryViewDTO.getStartTime()));
        }
        if(Objects.nonNull(adgroupQueryViewDTO.getEndTime())){
            Date queryEndTime = BrandDateUtil.getDateFullMidnight(adgroupQueryViewDTO.getEndTime());
            queryDTO.andCondition(AdgroupQuery.startTime.ltEq(queryEndTime));
        }

        if (CollectionUtils.isNotEmpty(adgroupQueryViewDTO.getSaleGroupIds())) {
            List<String> saleGroupIds = adgroupQueryViewDTO.getSaleGroupIds().stream().map(String::valueOf).collect(Collectors.toList());
            queryDTO.andCondition(AdgroupQuery.settingKeyValue.in(BrandAdgroupSettingKeyEnum.SALE_GROUP_ID.getKey(), saleGroupIds));
        }
    }

}