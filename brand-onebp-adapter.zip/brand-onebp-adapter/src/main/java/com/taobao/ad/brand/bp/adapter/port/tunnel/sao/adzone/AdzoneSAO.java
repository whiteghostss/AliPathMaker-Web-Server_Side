package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.adzone;

import com.alibaba.ad.nb.ssp.api.newadzone.AdzoneQueryService;
import com.alibaba.ad.nb.ssp.constant.newadzone.AdzoneSettingKey;
import com.alibaba.ad.nb.ssp.context.ServiceContext;
import com.alibaba.ad.nb.ssp.dto.SettingQueryDTO;
import com.alibaba.ad.nb.ssp.dto.newadzone.AdzoneDTO;
import com.alibaba.ad.nb.ssp.dto.newadzone.AdzoneQueryDTO;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.tunnel.sao.SAO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.product.AdzoneViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * ssp-adzone
 */
@Component
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AdzoneSAO implements SAO {
    private final AdzoneQueryService adzoneQueryService;

    public List<AdzoneViewDTO> findAdzoneByTemplateId(List<Long> templateIds){
        AdzoneQueryDTO adzoneQueryDTO = new AdzoneQueryDTO();
        adzoneQueryDTO.setTemplateIdList(templateIds);
        MultiResponse<AdzoneDTO> response = adzoneQueryService.list(ServiceContext.create(), adzoneQueryDTO);
        AssertUtil.assertTrue(response.isSuccess(),response.getErrorMsg());
        List<AdzoneViewDTO> adzoneViewDTOList = Optional.ofNullable(response.getResult()).orElse(Lists.newArrayList()).stream().map(adzoneDTO -> {
            AdzoneViewDTO adzoneViewDTO = new AdzoneViewDTO();
            adzoneViewDTO.setPid(adzoneDTO.getPid());
            adzoneViewDTO.setMemberId(adzoneDTO.getMemberId());
            adzoneViewDTO.setSiteId(adzoneDTO.getSiteId());
            adzoneViewDTO.setAdzoneId(adzoneDTO.getAdzoneId());
            adzoneViewDTO.setSspTemplateIds(adzoneDTO.getTemplateIdList());
            return adzoneViewDTO;
        }).collect(Collectors.toList());
        return adzoneViewDTOList;
    }
    public List<AdzoneViewDTO> findAdzoneByAdzoneIds(List<Long> adzoneIds){
        if (CollectionUtils.isEmpty(adzoneIds)){
            return Lists.newArrayList();
        }
        AdzoneQueryDTO adzoneQueryDTO = new AdzoneQueryDTO();
        adzoneQueryDTO.setAdzoneIdList(adzoneIds);
        adzoneQueryDTO.setNeedSite(true);
        adzoneQueryDTO.setNeedPage(false);
        MultiResponse<AdzoneDTO> response = adzoneQueryService.list(ServiceContext.create(), adzoneQueryDTO);
        AssertUtil.assertTrue(response.isSuccess(),response.getErrorMsg());
        List<AdzoneViewDTO> adzoneViewDTOList = Optional.ofNullable(response.getResult()).orElse(Lists.newArrayList()).stream().map(adzoneDTO -> {
            AdzoneViewDTO adzoneViewDTO = new AdzoneViewDTO();
            adzoneViewDTO.setPid(adzoneDTO.getPid());
            adzoneViewDTO.setMemberId(adzoneDTO.getMemberId());
            adzoneViewDTO.setSiteId(adzoneDTO.getSiteId());
            adzoneViewDTO.setAdzoneId(adzoneDTO.getAdzoneId());
            adzoneViewDTO.setOs(adzoneDTO.getOs());
            adzoneViewDTO.setAdzoneName(adzoneDTO.getAdzoneName());
            adzoneViewDTO.setOsName(adzoneDTO.getOsName());
            adzoneViewDTO.setMediaScope(adzoneDTO.getMediaScope());
            adzoneViewDTO.setResourceType(adzoneDTO.getResourceType());
            adzoneViewDTO.setSspTemplateIds(adzoneDTO.getTemplateIdList());
            adzoneViewDTO.setMaxReserveAmount(adzoneDTO.getMaxReserveAmount());
            return adzoneViewDTO;
        }).collect(Collectors.toList());
        return adzoneViewDTOList;
    }

    /**
     * 通过memberID和达人userID查询对应的adzone信息
     * @param memberIds
     * @param userIds
     * @return
     */
    public List<AdzoneViewDTO> selectAdzoneByUserId(List<Long> memberIds, List<String> userIds){
        AdzoneQueryDTO queryDTO = new AdzoneQueryDTO();
        queryDTO.setMemberIdList(memberIds);
        SettingQueryDTO settingQueryDTO = SettingQueryDTO.of(AdzoneSettingKey.TALENT_USER_ID, SettingQueryDTO.ValueList.of(userIds));
        queryDTO.setSettingQueryList(Lists.newArrayList(settingQueryDTO));
        MultiResponse<AdzoneDTO> response = adzoneQueryService.list(ServiceContext.create(), queryDTO);
        AssertUtil.assertTrue(response.isSuccess(),String.format("资源管理平台请求失败，原因：%s",response.getErrorMsg()));
        List<AdzoneViewDTO> adzoneViewDTOList = Optional.ofNullable(response.getResult()).orElse(Lists.newArrayList()).stream().map(adzoneDTO -> {
            AdzoneViewDTO adzoneViewDTO = new AdzoneViewDTO();
            adzoneViewDTO.setAdzoneId(adzoneDTO.getAdzoneId());
            adzoneViewDTO.setPid(adzoneDTO.getPid());
            adzoneViewDTO.setTalentUserId(adzoneDTO.getTalentUserId());
            return adzoneViewDTO;
        }).collect(Collectors.toList());
        return adzoneViewDTOList;
    }

}
