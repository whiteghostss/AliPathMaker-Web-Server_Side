package com.taobao.ad.brand.bp.adapter.port.converter.sales.mapstruct;

import com.alibaba.solar.libra.client.dto.ContractSettingDTO;
import com.alibaba.solar.libra.client.dto.ContractVersionDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesContractViewDTO;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author ximu.cly
 * @date 2021/4/17
 */
public abstract class ContractMapStructDecorator implements ContractMapStruct {

    private final ContractMapStruct contractMapStruct;

    public ContractMapStructDecorator(ContractMapStruct contractMapStruct) {
        this.contractMapStruct = contractMapStruct;
    }

    @Override
    public SalesContractViewDTO sourceToTarget(ContractVersionDTO contractVersionDTO) {
        SalesContractViewDTO salesContractViewDTO = contractMapStruct.sourceToTarget(contractVersionDTO);
        salesContractViewDTO.setChannelSalesJson(contractVersionDTO.getProperty(ContractSettingDTO.CHANNELSALESJSON));
        salesContractViewDTO.setDirectSalesJson(contractVersionDTO.getProperty(ContractSettingDTO.DIRECTSALESJSON));
        return salesContractViewDTO;
    }

    @Override
    public List<SalesContractViewDTO> sourceToTarget(List<ContractVersionDTO> contractVersionDTOS) {
        return contractVersionDTOS.stream().map(this::sourceToTarget).collect(Collectors.toList());
    }
}
