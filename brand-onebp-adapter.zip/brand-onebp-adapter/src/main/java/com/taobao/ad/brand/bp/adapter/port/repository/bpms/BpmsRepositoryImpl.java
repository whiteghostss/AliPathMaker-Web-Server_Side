package com.taobao.ad.brand.bp.adapter.port.repository.bpms;

import java.util.Map;

import com.alibaba.alipmc.api.model.bpm.ProcessInstance;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.bpms.BpmsSAO;
import com.taobao.ad.brand.bp.common.enums.BpmsProcessCodeEnum;
import com.taobao.ad.brand.bp.domain.bpms.BpmsRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import lombok.RequiredArgsConstructor;

/**
 * @author yanjingang
 * @date 2023/3/20
 */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BpmsRepositoryImpl implements BpmsRepository {

    private final BpmsSAO bpmsSAO;

    @Override
    public String startProcessInstance(String title, String titleEn, String empId, Map<String, String> initData, BpmsProcessCodeEnum processCodeEnum) {
        ProcessInstance processInstance = bpmsSAO.startProcessInstance(title, titleEn, empId, initData, processCodeEnum.getCode());
        return processInstance.getProcessInstanceId();
    }
}
