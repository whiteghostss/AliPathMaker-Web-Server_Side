package com.taobao.ad.brand.bp.adapter.port.converter.media;

import com.alibaba.uad.wto.dto.resource.MediaDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.media.mapstruct.MediaDTOMapStruct;
import com.taobao.ad.brand.bp.client.dto.media.MediaViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.springframework.stereotype.Component;


/**
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@Component
public class MediaDTOConverter extends BaseViewDTOConverter<MediaDTO, MediaViewDTO> {

    @Override
    public BaseMapStructMapper<MediaDTO, MediaViewDTO> getBaseMapStructMapper() {
        return MediaDTOMapStruct.INSTANCE;
    }


    @Override
    public MediaViewDTO convertDTO2ViewDTO(MediaDTO source) {
        MediaViewDTO mediaViewDTO = super.convertDTO2ViewDTO(source);
//        List<MediaContactViewDTO> mediaContactViewDTOList =
//                Optional.ofNullable(source.getMediaContactList()).orElse(Lists.newArrayList()).stream().map(item->{
//                    MediaContactViewDTO mediaContactViewDTO = new MediaContactViewDTO();
//                    mediaContactViewDTO.setId(item.getId());
//                    mediaContactViewDTO.setName(item.getName());
//                    mediaContactViewDTO.setEmail(item.getEmail());
//                    return mediaContactViewDTO;
//                }).collect(Collectors.toList());
//        mediaViewDTO.setMediaContactList(mediaContactViewDTOList);
        return mediaViewDTO;
    }
}
