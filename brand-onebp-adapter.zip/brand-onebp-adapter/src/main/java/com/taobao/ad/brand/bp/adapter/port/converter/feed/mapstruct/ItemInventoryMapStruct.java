package com.taobao.ad.brand.bp.adapter.port.converter.feed.mapstruct;

import com.alibaba.ad.feed.dto.feedoutentity.OutItemInventoryDTO;
import com.taobao.ad.brand.bp.client.dto.item.ItemInventoryViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @Author: PhilipFry
 * @createTime: 2024年05月08日 10:55:55
 * @Description: 宝贝库存转换
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ItemInventoryMapStruct extends BaseMapStructMapper<OutItemInventoryDTO, ItemInventoryViewDTO> {
    ItemInventoryMapStruct INSTANCE = Mappers.getMapper(ItemInventoryMapStruct.class);
}
