package com.taobao.ad.brand.bp.adapter.port.repository.industry;

import com.alibaba.abf.governance.context.ServiceContext;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.adapter.port.converter.industry.IndustryViewDTOConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.dataobject.industry.IndustryDO;
import com.taobao.ad.brand.bp.client.dto.industry.IndustryViewDTO;
import com.taobao.ad.brand.bp.common.constant.industry.IndustryQueryConstant;
import com.taobao.ad.brand.bp.common.constant.talent.TalentQueryConstant;
import com.taobao.ad.brand.bp.domain.adr.ReportCenterRepository;
import com.taobao.ad.brand.bp.domain.industry.repository.IndustryRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;

@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class IndustryRepositoryImpl implements IndustryRepository {

    private final ReportCenterRepository reportCenterRepository;

    private final IndustryViewDTOConverter industryViewDTOConverter;

    @Override
    public IndustryViewDTO getIndustryByShopId(ServiceContext serviceContext, Long shopId) {
        if(shopId == null){
            return null;
        }
        IndustryViewDTO industryViewDTO = new IndustryViewDTO();
        Map<String, Object> queryParams = Maps.newHashMap();
        queryParams.put(TalentQueryConstant.ADR_UNIQUE_KEY,"brand_onebp.common.common.getIndustryInfoApi");
        queryParams.put(IndustryQueryConstant.SHOP_ID_EQUAL,shopId);
        List<Map<String, Object>> industryDataList = reportCenterRepository.findData(queryParams);
        try {
            List<IndustryDO> industryDOS = conver(industryDataList, IndustryDO.class);
            if(CollectionUtils.isNotEmpty(industryDOS)){
                List<IndustryViewDTO> industryViewDTOList = industryViewDTOConverter.convertDTO2ViewDTOList(industryDOS);
                industryViewDTO = industryViewDTOList.get(0);
            }
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
        return industryViewDTO;
    }

    private <T> List<T> conver(List<Map<String, Object>> dataList, Class<T> clazz) throws InstantiationException, IllegalAccessException {
        List<T> result = Lists.newArrayList();
        if(CollectionUtils.isEmpty(dataList)){
            return result;
        }
        for(Map<String, Object> data:dataList){
            Object obj = clazz.newInstance();
            Field[] fields = obj.getClass().getDeclaredFields();
            for (Field field : fields) {
                String fieldName = field.getAnnotation(JsonProperty.class).value();
                if(data.containsKey(fieldName)){
                    Object v = data.get(fieldName);
                    field.setAccessible(true);
                    if (obj == null) {
                        continue;
                    }
                    try {
                        field.set(obj, v);
                    } catch (IllegalAccessException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
            result.add((T)obj);
        }
        return result;
    }
}
