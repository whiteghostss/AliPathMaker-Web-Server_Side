package com.taobao.ad.brand.bp.adapter.port.converter.motion.mapstruct;

import com.alibaba.ad.nb.packages.v2.client.dto.motion.IntelligentMotionDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.motion.MarketingStageDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.resourcepackage.mapstruct.ResourceDistributionRuleMapStruct;
import com.taobao.ad.brand.bp.client.dto.motion.IntelligentMotionViewDTO;
import com.taobao.ad.brand.bp.client.dto.motion.MarketingStageViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/18
 **/
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, uses = {MediaStrategyMapStruct.class, ResourceTypeStrategyMapStruct.class})
public interface MarketingStageMapStruct extends BaseMapStructMapper<MarketingStageDTO, MarketingStageViewDTO> {

    MarketingStageMapStruct INSTANCE = Mappers.getMapper(MarketingStageMapStruct.class);

    @Mappings({
            @Mapping(source = "mediaStrategyList", target = "mediaStrategyViewDTOList"),
            @Mapping(source = "resourceTypeStrategyList", target = "resourceTypeStrategyViewDTOList"),
            @Mapping(source = "startDate", target = "startTime"),
            @Mapping(source = "endDate", target = "endTime"),
    })
    @Override
    MarketingStageViewDTO sourceToTarget(MarketingStageDTO marketingStageDTO);



    @Mappings({
            @Mapping(source = "mediaStrategyViewDTOList", target = "mediaStrategyList"),
            @Mapping(source = "resourceTypeStrategyViewDTOList", target = "resourceTypeStrategyList"),
            @Mapping(source = "startTime", target = "startDate"),
            @Mapping(source = "endTime", target = "endDate"),
    })
    @Override
    MarketingStageDTO targetToSource(MarketingStageViewDTO marketingStageViewDTO);
}
