package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.login;

import com.alibaba.abf.governance.context.GatewayContext;
import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.uic.api.LoginQueryService;
import com.alibaba.ad.uic.common.dto.login.ADUicSessionDTO;
import com.alibaba.ad.uic.common.dto.login.query.PreSessionQueryDTO;
import com.alibaba.ad.uic.common.dto.login.query.SessionQueryDTO;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.utils.BeanUtils;
import com.taobao.ad.brand.bp.common.util.AssertUtil;

import lombok.RequiredArgsConstructor;

/**
 * @author 虫洞 <liuming.liu@alibaba-inc.com>
 * @date 2023/4/26
 */
@BizTunnel
@RequiredArgsConstructor
public class LoginSessionSAO {
    private final LoginQueryService loginQueryService;

    public ADUicSessionDTO getSession(ServiceContext serviceContext, GatewayContext gatewayContext) {
        AssertUtil.notNull(serviceContext, "serviceContext is null");
        AssertUtil.notNull(gatewayContext, "gatewayContext is null");
        AssertUtil.hasText(gatewayContext.getSessionId(), "gatewayContext.sessionId is blank");
        AssertUtil.hasText(gatewayContext.getSessionId(), "gatewayContext.uri is blank");

        SessionQueryDTO sessionQueryDTO = new SessionQueryDTO();
        sessionQueryDTO.setSessionId(gatewayContext.getSessionId());
        sessionQueryDTO.setRequestURL(gatewayContext.getUri());
        SingleResponse<ADUicSessionDTO> response = loginQueryService.getSession(buildServiceContext(serviceContext), sessionQueryDTO);
        AssertUtil.assertTrue(response.isSuccess(), "获取登录态失败");
        return response.getResult();
    }

    public ADUicSessionDTO getPreSession(ServiceContext serviceContext, GatewayContext gatewayContext) {
        AssertUtil.notNull(serviceContext, "serviceContext is null");
        AssertUtil.notNull(gatewayContext, "gatewayContext is null");
        AssertUtil.hasText(gatewayContext.getSessionId(), "gatewayContext.sessionId is blank");
        AssertUtil.hasText(gatewayContext.getSessionId(), "gatewayContext.uri is blank");

        PreSessionQueryDTO sessionQueryDTO = new PreSessionQueryDTO();
        sessionQueryDTO.setSessionId(gatewayContext.getSessionId());
        sessionQueryDTO.setRequestURL(gatewayContext.getUri());
        SingleResponse<ADUicSessionDTO> response = loginQueryService.getPreSession(buildServiceContext(serviceContext), sessionQueryDTO);
        AssertUtil.assertTrue(response.isSuccess(), "获取登录态失败");
        return response.getResult();
    }

    private ServiceContext buildServiceContext(ServiceContext serviceContext) {
        ServiceContext copied = BeanUtils.copy(serviceContext, new ServiceContext());
        // 客户中心只识别站点的业务身份code
        copied.setBizCode(BizCodeEnum.BRANDONEBP.getBizCode());
        return copied;
    }
}
