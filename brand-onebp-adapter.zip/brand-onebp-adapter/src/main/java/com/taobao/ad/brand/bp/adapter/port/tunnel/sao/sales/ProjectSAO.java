package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.sales;

import com.alibaba.ad.nb.sales.api.face.ProjectService;
import com.alibaba.ad.nb.sales.dto.project.ProjectDTO;
import com.alibaba.ad.nb.sales.dto.project.ProjectQueryDTO;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;

import java.util.List;

/**
 * @author yanjingang
 * @date 2023/3/16
 */
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ProjectSAO extends SalesBaseSAO {

    private final ProjectService projectService;

    /**
     * 根据ids获取项目列表
     */
    public List<ProjectDTO> findSimpleProjectByIds(List<Long> ids) {
        if (CollectionUtils.isEmpty(ids)) {
            return Lists.newArrayList();
        }
        ProjectQueryDTO queryDTO = new ProjectQueryDTO();
        queryDTO.setIds(ids);
        queryDTO.setToPage(1);
        queryDTO.setPageSize(ids.size());
        MultiResponse<ProjectDTO> response = projectService.findProjectListSimple(createNbServiceContext(), queryDTO);
        AssertUtil.assertTrue(response);
        return response.getResult();
    }

}
