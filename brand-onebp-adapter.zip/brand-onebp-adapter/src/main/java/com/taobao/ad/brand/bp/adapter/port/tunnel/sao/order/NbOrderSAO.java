package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.order;

import com.alibaba.ad.nb.common.dto.NbServiceContext;
import com.alibaba.ad.nb.order.api.creative.CreativeCommandService;
import com.alibaba.ad.nb.order.dto.creative.CreativeDTO;
import com.alibaba.ad.nb.order.dto.creative.CreativeProtocolDTO;
import com.alibaba.fastjson.JSON;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/5/11 15:51
 * @description ：
 * @modified By：
 */
@Component
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class NbOrderSAO extends BaseSAO {

    private final CreativeCommandService creativeCommandService;

    public Map<String, String> generateCreativeProtocols(NbServiceContext serviceContext, CreativeDTO creativeDTO) {
        MultiResponse<CreativeProtocolDTO> multiResponse = creativeCommandService.generateCreativeProtocols(serviceContext, creativeDTO);
        AssertUtil.assertTrue(multiResponse);
        List<CreativeProtocolDTO> result = multiResponse.getResult();
        RogerLogger.info("[compareProtocol] nbOrder协议{}", JSON.toJSONString(result));
        return result.stream().collect(Collectors.toMap(creativeProtocolDTO -> creativeProtocolDTO.getMedia()
                + "_" + creativeProtocolDTO.getDevice()
                + "_" + creativeProtocolDTO.getWidth()
                + "_" + creativeProtocolDTO.getHeight(), CreativeProtocolDTO::getContent, (v1, v2) -> v1));
    }
}
