package com.taobao.ad.brand.bp.adapter.port.converter.oplog;

import com.alibaba.ad.oplog.dto.OpLogDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.oplog.mapstruct.OpLogViewDTOMapStruct;
import com.taobao.ad.brand.bp.client.dto.oplog.OpLogViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.springframework.stereotype.Component;

/**
 * @author jixiu.lj
 * @date 2024/3/20 15:42
 */
@Component
public class OpLogViewDTOConverter extends BaseViewDTOConverter<OpLogDTO, OpLogViewDTO> {
    @Override
    public BaseMapStructMapper<OpLogDTO, OpLogViewDTO> getBaseMapStructMapper() {
        return OpLogViewDTOMapStruct.INSTANCE;
    }
}
