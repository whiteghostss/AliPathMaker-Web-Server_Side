package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.benchmark;

import com.alibaba.ad.nb.content.client.api.talent.TalentQueryService;
import com.alibaba.ad.nb.content.client.dto.talent.ContentIndustryTalentBenchmarkDTO;
import com.alibaba.ad.nb.content.client.dto.talent.TalentBenchmarkQueryDTO;
import com.alibaba.ad.nb.direct.client.context.NbDirectServiceContext;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BenchmarkSAO extends BaseSAO {

    private final TalentQueryService nbTalentQueryService;

    public List<ContentIndustryTalentBenchmarkDTO> findTalentBenchmark(NbDirectServiceContext serviceContext, TalentBenchmarkQueryDTO queryDTO){
        MultiResponse<ContentIndustryTalentBenchmarkDTO> response = nbTalentQueryService.findTalentBenchmark(serviceContext,queryDTO);
        AssertUtil.assertTrue(response);
        return response.getResult();
    }
}
