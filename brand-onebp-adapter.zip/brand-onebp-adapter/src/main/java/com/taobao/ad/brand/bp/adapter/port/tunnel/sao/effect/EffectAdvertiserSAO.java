package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.effect;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.nb.direct.client.api.advertiser.DirectAdvertiserCommandService;
import com.alibaba.ad.nb.direct.client.api.advertiser.DirectAdvertiserQueryService;
import com.alibaba.ad.nb.direct.client.constant.advertiser.DirectAdvertiserSettingKeyEnum;
import com.alibaba.ad.nb.direct.client.constant.common.BoolEnum;
import com.alibaba.ad.nb.direct.client.context.NbDirectServiceContext;
import com.alibaba.ad.nb.direct.client.dto.advertiser.AdvertiserContractFundDTO;
import com.alibaba.ad.nb.direct.client.dto.advertiser.AdvertiserFundDTO;
import com.alibaba.ad.nb.direct.client.dto.advertiser.DirectAdvertiserDTO;
import com.alibaba.ad.nb.direct.client.dto.advertiser.DirectAdvertiserSettingDTO;
import com.alibaba.ad.nb.direct.client.dto.advertiser.query.AdvertiserContractFundQueryDTO;
import com.alibaba.ad.nb.direct.client.dto.advertiser.query.DirectAdvertiserQueryDTO;
import com.alibaba.ad.nb.direct.client.dto.user.UserDTO;
import com.alibaba.ad.nb.user.client.constant.bizspace.BizAbilityEnum;
import com.alibaba.ad.nb.user.client.constant.common.UserTypeEnum;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.effect.DirectAdvertiserSettingViewDTO;
import com.taobao.ad.brand.bp.client.dto.effect.EffectAdvertiserContractFundViewDTO;
import com.taobao.ad.brand.bp.client.dto.effect.EffectAdvertiserViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.config.EffectAdAgencyMasterDiamondConfig;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * 广告主服务
 * @author yunhu.myh@taobao.com
 * @date 2023年08月29日
 * */
@BizTunnel

@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EffectAdvertiserSAO {

    private final DirectAdvertiserQueryService directAdvertiserQueryService;

    private final DirectAdvertiserCommandService directAdvertiserCommandService;

    private final EffectAdAgencyMasterDiamondConfig effectAdAgencyMasterDiamondConfig;



    /**
     * 根据效果advId查询代投空间的adv
     * */
    public void updateEffectAdvertiserSetting(List<DirectAdvertiserSettingViewDTO> directAdvertiserSettingViewDTOList){
        if (CollectionUtils.isEmpty(directAdvertiserSettingViewDTOList)){
            return;
        }
        List<DirectAdvertiserSettingDTO> toSaveList =  directAdvertiserSettingViewDTOList.stream().map(item->{
            DirectAdvertiserSettingDTO directAdvertiserSettingDTO = new DirectAdvertiserSettingDTO();
            directAdvertiserSettingDTO.setId(item.getId());
            directAdvertiserSettingDTO.setCustomMemberId(item.getCustomMemberId());
            directAdvertiserSettingDTO.setCampaignId(item.getCampaignId());
            directAdvertiserSettingDTO.setSubCampaignId(item.getSubCampaignId());
            return directAdvertiserSettingDTO;
        }).collect(Collectors.toList());
        SingleResponse<Integer> singleResponse =  directAdvertiserCommandService.updateEffectAgencyDirectAdvertiserSetting(initUdServiceContext(),toSaveList);
        AssertUtil.assertTrue(singleResponse);
    }
    /**
     * 根据效果advId查询代投空间的adv
     * */
    public void deleteEffectAdvertiserSetting(Long advId,List<String> settingKeys){
        if (CollectionUtils.isEmpty(settingKeys)){
            return;
        }
        List<DirectAdvertiserSettingKeyEnum> settingKeyEnums =
                settingKeys.stream().map(item-> DirectAdvertiserSettingKeyEnum.getByKey(item)).collect(Collectors.toList());

        SingleResponse<Long> singleResponse =  directAdvertiserCommandService.deleteEffectAgencyDirectAdvertiserSetting(initUdServiceContext(),advId,settingKeyEnums);
        AssertUtil.assertTrue(singleResponse);
    }
    public List<EffectAdvertiserContractFundViewDTO> findAdvertiserContractFundList(ServiceContext serviceContext, List<Integer> directMediaIds, List<Long> directAdvertiserIds, List<Long> subContractIds) {

        if (CollectionUtils.isEmpty(directMediaIds)){
            return Lists.newArrayList();
        }
        if (CollectionUtils.isEmpty(directAdvertiserIds)){
            return Lists.newArrayList();
        }
        if (CollectionUtils.isEmpty(subContractIds)){
            return Lists.newArrayList();
        }
        AdvertiserContractFundQueryDTO advertiserContractFundQuery =  new AdvertiserContractFundQueryDTO();
        advertiserContractFundQuery.setDirectMediaIds(directMediaIds);
        advertiserContractFundQuery.setDirectAdvertiserIds(directAdvertiserIds);
        advertiserContractFundQuery.setSubContractIds(subContractIds);

        MultiResponse<AdvertiserContractFundDTO> multiResponse = directAdvertiserQueryService.getAdvertiserContractFundList(initUdServiceContext(),advertiserContractFundQuery);
        AssertUtil.assertTrue(multiResponse);
        List<AdvertiserContractFundDTO> advertiserContractFundDTOList = multiResponse.getResult();
        return Optional.ofNullable(advertiserContractFundDTOList).orElse(Lists.newArrayList()).stream().map(item->{
            EffectAdvertiserContractFundViewDTO effectAdvertiserContractFundViewDTO = new EffectAdvertiserContractFundViewDTO();
            effectAdvertiserContractFundViewDTO.setDirectAdvertiserId(item.getDirectAdvertiserId());
            effectAdvertiserContractFundViewDTO.setDirectMediaId(item.getDirectMediaId());
            effectAdvertiserContractFundViewDTO.setTransferOut(item.getTransferOut());
            effectAdvertiserContractFundViewDTO.setTransferIn(item.getTransferIn());
            effectAdvertiserContractFundViewDTO.setSubContractId(item.getSubContractId());
            return effectAdvertiserContractFundViewDTO;
        }).collect(Collectors.toList());
    }
    /**
     * 根据效果advId查询代投空间的adv
     * */
    public List<EffectAdvertiserViewDTO> findEffectAdvInnerList(List<Long> advIds){
        if (CollectionUtils.isEmpty(advIds)){
            return Lists.newArrayList();
        }
        DirectAdvertiserQueryDTO directAdvertiserQueryDTO = new DirectAdvertiserQueryDTO();
        directAdvertiserQueryDTO.setIds(advIds);
        directAdvertiserQueryDTO.setAgencyType(BoolEnum.TRUE.getValue());
//        directAdvertiserQueryDTO.setMasterIds(effectAdAgencyMasterDiamondConfig.getWhiteMasterIds());

        MultiResponse<DirectAdvertiserDTO> multiResponse =  directAdvertiserQueryService.findDetailInnerList(initUdServiceContext(),directAdvertiserQueryDTO);
        AssertUtil.assertTrue(multiResponse.isSuccess(), multiResponse.getErrorMsg());
        return Optional.ofNullable(multiResponse.getResult()).orElse(Lists.newArrayList()).stream().map(item->{
            EffectAdvertiserViewDTO effectAdvertiserViewDTO = new EffectAdvertiserViewDTO();
            effectAdvertiserViewDTO.setChannelId(item.getDirectMediaId().longValue());
            if (null != item.getFund()){
                AdvertiserFundDTO advertiserFundDTO =  item.getFund();
                effectAdvertiserViewDTO.setCost(advertiserFundDTO.getCost());
                effectAdvertiserViewDTO.setBalance(advertiserFundDTO.getBalance());
                effectAdvertiserViewDTO.setCashBalance(advertiserFundDTO.getCashBalance());
                effectAdvertiserViewDTO.setRewardBalance(advertiserFundDTO.getRewardBalance());
                effectAdvertiserViewDTO.setGrantBalance(advertiserFundDTO.getGrantBalance());

            }
            effectAdvertiserViewDTO.setId(item.getId());
            effectAdvertiserViewDTO.setAdvMemberId(item.getAdvMemberId());
            effectAdvertiserViewDTO.setStatus(item.getStatus());
            effectAdvertiserViewDTO.setSellerId(item.getSellerId());
            effectAdvertiserViewDTO.setShopId(item.getShopId());
            effectAdvertiserViewDTO.setShopName(item.getShopName());
            effectAdvertiserViewDTO.setChannelId(item.getDirectMediaId().longValue());
            effectAdvertiserViewDTO.setStartTime(item.getStartTime());
            effectAdvertiserViewDTO.setDirectAdvertiserId(item.getDirectAdvertiserId());
            effectAdvertiserViewDTO.setDirectAdvertiserUuid(item.getDirectAdvertiserUuid());
            effectAdvertiserViewDTO.setDirectMediaName(item.getDirectMediaName());
            effectAdvertiserViewDTO.setBrandName(item.getBrandName());
            effectAdvertiserViewDTO.setEndTime(item.getEndTime());
            effectAdvertiserViewDTO.setName(item.getName());
            effectAdvertiserViewDTO.setCustomerId(item.getCustomerId());
            effectAdvertiserViewDTO.setCustomerType(item.getCustomerType());
            effectAdvertiserViewDTO.setCustomerTypeName(item.getCustomerTypeName());
            effectAdvertiserViewDTO.setCustomerName(item.getCustomerName());
            effectAdvertiserViewDTO.setInvalid(item.getInvalid());
            effectAdvertiserViewDTO.setNickName(item.getNickName());
            effectAdvertiserViewDTO.setEffectType(item.getEffectType());
            effectAdvertiserViewDTO.setChannelName(item.getDirectMediaName());
            effectAdvertiserViewDTO.setSpaceId(item.getSpaceId());
            effectAdvertiserViewDTO.setSpaceName(item.getSpaceName());
            effectAdvertiserViewDTO.setMasterId(item.getMasterId());
            effectAdvertiserViewDTO.setMasterName(item.getMasterName());
            return effectAdvertiserViewDTO;
        }).collect(Collectors.toList());
    }
    private NbDirectServiceContext initUdServiceContext() {
        Long dspId = 121507994L;
        Long memberId = 3833238314L;
        Long masterId = 3099266L;
        Long cusMemberId = 3833088529L;
        Long brandId = 363324850L;

        NbDirectServiceContext serviceContext = new NbDirectServiceContext();
        serviceContext.setDspId(dspId);
        serviceContext.setBizKey("common");
        serviceContext.setAbilityCode(BizAbilityEnum.RTA_PUSH.getCode());
        serviceContext.setBizCode(UserTypeEnum.INNER.getCode());
        //产研空间
        serviceContext.setUser(new UserDTO());
        serviceContext.getUser().setMemberId(memberId);
        serviceContext.getUser().addMasterProperty(masterId);
        serviceContext.getUser().addBrandProperty(brandId);
        serviceContext.getUser().addUserTypeProperty(UserTypeEnum.INNER.getValue());
        serviceContext.getUser().addCusMemberIdProperty(cusMemberId);
        serviceContext.getUser().setUserTag(UserDTO.UserTagEnum.UD_EFFECT.getValue());
        serviceContext.getUser().setLoginType(UserDTO.LoginTypeEnum.MAIN.getValue());

        serviceContext.setMemberId(memberId);
        serviceContext.setCusMemberId(cusMemberId);
        serviceContext.setOpUserId(masterId);

        return serviceContext;
    }


}
