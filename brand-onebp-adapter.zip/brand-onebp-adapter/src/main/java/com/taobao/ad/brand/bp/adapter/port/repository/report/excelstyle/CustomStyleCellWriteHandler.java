package com.taobao.ad.brand.bp.adapter.port.repository.report.excelstyle;

import com.alibaba.excel.enums.CellDataTypeEnum;
import com.alibaba.excel.metadata.data.CellData;
import com.alibaba.excel.metadata.data.WriteCellData;
import com.alibaba.excel.write.handler.CellWriteHandler;
import com.alibaba.excel.write.handler.context.CellWriteHandlerContext;
import com.alibaba.excel.write.metadata.style.WriteCellStyle;
import com.alibaba.excel.write.style.HorizontalCellStyleStrategy;
import com.taobao.ad.brand.bp.client.dto.report.excel.ExcelCatalogueViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.poi.common.usermodel.HyperlinkType;
import org.apache.poi.ss.usermodel.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.apache.poi.ss.usermodel.BorderStyle.THIN;

/**
 * 目录页列宽设置
 * @author yuncheng.lyc
 * @date 2023/3/23
 **/
public class CustomStyleCellWriteHandler implements CellWriteHandler {
    private static final int MAX_COLUMN_WIDTH = 80;
    private Map<Integer, Map<Integer, Integer>> CACHE = new HashMap<>();
    private List<ExcelCatalogueViewDTO> homePageList;

    public CustomStyleCellWriteHandler(List<ExcelCatalogueViewDTO> homePageList){
        this.homePageList = homePageList;
    }

    public CustomStyleCellWriteHandler(){
    }

    @Override
    public void beforeCellCreate(CellWriteHandlerContext context) {

    }

    @Override
    public void afterCellDispose(CellWriteHandlerContext context) {
        if(CollectionUtils.isNotEmpty(this.homePageList)) {
            Sheet sheet = context.getWriteSheetHolder().getSheet();
            if (context.getCell().getColumnIndex() == 0 && sheet.getSheetName().equals("目录")) {
                sheet.setColumnWidth(context.getColumnIndex(), 80 * 256);
            }

            int row = 0;
            for (ExcelCatalogueViewDTO homePage : homePageList) {
                AssertUtil.notNull(homePage.getType());
                if (ExcelCatalogueViewDTO.ExcelCatalogueFormatEnum.HYPERLINK_ITEM.getValue().equals(homePage.getType()) && context.getRowIndex() == row) {
                    CreationHelper helper = context.getWriteSheetHolder().getSheet().getWorkbook().getCreationHelper();
                    Hyperlink hyperlink = helper.createHyperlink(HyperlinkType.DOCUMENT);
                    hyperlink.setAddress("#'" + homePage.getContent() + "'!A1");

                    context.getCell().setHyperlink(hyperlink);
                }
                ++row;
            }
        }
        boolean needSetWidth = context.getHead() || !CollectionUtils.isEmpty(context.getCellDataList()) || context.getRowIndex() <= 5 ;
        if (needSetWidth) {
            Map<Integer, Integer> maxColumnWidthMap = CACHE.get(context.getWriteSheetHolder().getSheetNo());
            if (maxColumnWidthMap == null) {
                maxColumnWidthMap = new HashMap<>();
                CACHE.put(context.getWriteSheetHolder().getSheetNo(), maxColumnWidthMap);
            }
            Cell cell = context.getCell();
            Integer columnWidth = dataLength(context.getCellDataList(), context.getCell(), context.getHead());
            if (columnWidth >= 0) {
                if (columnWidth > MAX_COLUMN_WIDTH) {
                    columnWidth = MAX_COLUMN_WIDTH;
                }
                Integer maxColumnWidth = maxColumnWidthMap.get(cell.getColumnIndex());
                if (maxColumnWidth == null || columnWidth > maxColumnWidth) {
                    maxColumnWidthMap.put(cell.getColumnIndex(), columnWidth);
                    context.getWriteSheetHolder().getSheet().setColumnWidth(cell.getColumnIndex(), columnWidth * 256);
                }
            }
        }

    }

    private HorizontalCellStyleStrategy getHorizontalCellStyleStrategy(){
        WriteCellStyle headWriteCellStyle = new WriteCellStyle();
        headWriteCellStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());

        WriteCellStyle contentWriteCellStyle = new WriteCellStyle();
        contentWriteCellStyle.setWrapped(true);
        contentWriteCellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        contentWriteCellStyle.setHorizontalAlignment(HorizontalAlignment.LEFT);
        contentWriteCellStyle.setBorderLeft(THIN);
        contentWriteCellStyle.setBorderTop(THIN);
        contentWriteCellStyle.setBorderRight(THIN);
        contentWriteCellStyle.setBorderBottom(THIN);

        return new HorizontalCellStyleStrategy(headWriteCellStyle, contentWriteCellStyle);

    }

    private Integer dataLength(List<WriteCellData<?>> cellDataList, Cell cell, Boolean isHead) {
        if (isHead) {
            return cell.getStringCellValue().getBytes().length;
        } else {
            CellData cellData = cellDataList.get(0);
            CellDataTypeEnum type = cellData.getType();
            if (type == null) {
                return -1;
            } else {
                switch (type) {
                    case STRING:
                        return cellData.getStringValue().getBytes().length;
                    case BOOLEAN:
                        return cellData.getBooleanValue().toString().getBytes().length;
                    case NUMBER:
                        return cellData.getNumberValue().toString().getBytes().length;
                    default:
                        return -1;
                }
            }
        }
    }

}
