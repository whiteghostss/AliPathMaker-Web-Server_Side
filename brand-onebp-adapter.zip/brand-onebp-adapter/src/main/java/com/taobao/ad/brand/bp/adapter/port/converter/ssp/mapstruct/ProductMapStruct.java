package com.taobao.ad.brand.bp.adapter.port.converter.ssp.mapstruct;

import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.alibaba.ad.nb.ssp.dto.newproduct.ProductDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/23
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ProductMapStruct extends BaseMapStructMapper<ProductDTO, ProductViewDTO> {
    ProductMapStruct INSTANCE = Mappers.getMapper(ProductMapStruct.class);
}