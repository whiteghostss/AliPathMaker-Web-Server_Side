package com.taobao.ad.brand.bp.adapter.port.repository.resourcepackage;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquirySchedulePolicyViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupBoostGiveApplyInfoViewDTO;
import com.alibaba.ad.brand.dto.demand.DemandViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.alibaba.ad.nb.packages.dto.project.ProjectDTO;


import com.alibaba.ad.nb.packages.v2.client.dto.product.ProductSubstitutionDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.product.ResourcePackageProductDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.salegroup.ReplenishOrDistributionSaleGroupInfoDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.salegroup.ResourcePackageSaleGroupDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.salegroup.SaleGroupSubstitutionDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.salegroup.query.ResourcePackageSaleGroupQueryDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.salegroup.query.ResourcePackageSaleGroupQueryDTO.ResourcePackageSaleGroupQueryDTOBuilder;
import com.alibaba.ad.nb.packages.v2.client.dto.template.ResourcePackageTemplateDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.template.query.ResourcePackageTemplateQueryDTO;
import com.alibaba.ad.nb.ssp.constant.newproduct.ProductLineEnum;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.adapter.port.converter.motion.IntelligentMotionDTOConverter;
import com.taobao.ad.brand.bp.adapter.port.converter.resourcepackage.ResourcePackageConverter;
import com.taobao.ad.brand.bp.adapter.port.converter.resourcepackage.ResourcePackageProductConverter;
import com.taobao.ad.brand.bp.adapter.port.converter.resourcepackage.ResourcePackageProjectConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.resourcepackage.ResourcePackageSAO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.salegroup.CampaignGroupSaleGroupBoostGiveApplyViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.*;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.wto.SupplierSolutionGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.wto.SupplierSolutionResourceDetailViewDTO;
import com.taobao.ad.brand.bp.client.dto.wto.SupplierSolutionViewDTO;
import com.taobao.ad.brand.bp.common.enums.BooleanEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/25
 */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ResourcePackageRepositoryImpl implements ResourcePackageRepository {

    private final ResourcePackageSAO resourcePackageSAO;
    private final ResourcePackageConverter resourcePackageConverter;
    private final ResourcePackageProductConverter resourcePackageProductConverter;
    private final ResourcePackageProjectConverter resourcePackageProjectConverter;
    private final IntelligentMotionDTOConverter intelligentMotionDTOConverter;

    @Override
    public List<ResourcePackageSaleGroupViewDTO> getSaleGroupList(ServiceContext serviceContext, List<Long> saleGroupIds, ResourcePackageQueryOption queryOption) {
        if (CollectionUtils.isEmpty(saleGroupIds)) {
            return Lists.newArrayList();
        }
        ResourcePackageQueryViewDTO queryViewDTO = ResourcePackageQueryViewDTO.builder()
            .saleGroupIdList(saleGroupIds)
            .build();
        return getSaleGroupList(serviceContext, queryViewDTO, queryOption);
    }

    @Override
    public List<ResourcePackageSaleGroupViewDTO> getSaleGroupList(ServiceContext serviceContext, ResourcePackageQueryViewDTO queryViewDTO,
        ResourcePackageQueryOption queryOption) {
        ResourcePackageSaleGroupQueryDTO resourcePackageSaleGroupQueryDTO = convertSaleGroupQuery(queryViewDTO, queryOption);
        List<ResourcePackageSaleGroupDTO> saleGroupList = resourcePackageSAO.getSaleGroupList(serviceContext, resourcePackageSaleGroupQueryDTO);
        List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupViewDTOS = resourcePackageConverter.convertDTO2ViewDTOList(saleGroupList);
        parseSaleGroupList(resourcePackageSaleGroupViewDTOS);
        return resourcePackageSaleGroupViewDTOS;
    }
    @Override
    public List<ResourcePackageProductViewDTO> getLevelOneResourcePackageProductList(ServiceContext serviceContext, List<Long> resourceProductIds) {
        List<ResourcePackageProductDTO> resourcePackageProductDTOS = resourcePackageSAO.getLevelOneResourcePackageProductList(serviceContext, resourceProductIds);
        List<ResourcePackageProductViewDTO> resourcePackageSaleGroupViewDTOS = resourcePackageProductConverter.convertDTO2ViewDTOList(resourcePackageProductDTOS);
        return resourcePackageSaleGroupViewDTOS;
    }
    @Override
    public ResourcePackageProductViewDTO getResourcePackageSspProduct(ServiceContext serviceContext, Long resourceProductId) {
        ResourcePackageProductDTO resourcePackageProductDTO = resourcePackageSAO.getResourcePackageProduct(serviceContext,resourceProductId);
        return resourcePackageProductDTO== null ? null :resourcePackageProductConverter.convertDTO2ViewDTO(resourcePackageProductDTO);

    }


    @Override
    public void confirmResourcePackage(ServiceContext serviceContext, List<DemandViewDTO> demandViewDTOList, List<SupplierSolutionGroupViewDTO> solutionGroupList){
        if(CollectionUtils.isEmpty(solutionGroupList)){
            return;
        }
        List<SaleGroupSubstitutionDTO> saleGroupSubstitutionDTOList = new ArrayList<>();
        Map<Long, DemandViewDTO> demandViewDTOMap = Maps.uniqueIndex(demandViewDTOList, DemandViewDTO::getId);
        for (SupplierSolutionGroupViewDTO solutionGroupDTO : solutionGroupList) {
            AssertUtil.assertTrue(CollectionUtils.isNotEmpty(solutionGroupDTO.getSolutionList()), "供应商提案数据异常");
            SaleGroupSubstitutionDTO saleGroupSubstitutionDTO = new SaleGroupSubstitutionDTO();
            saleGroupSubstitutionDTO.setId(solutionGroupDTO.getSaleGroupId());
            List<ProductSubstitutionDTO> productSubstitutionDTOList = new ArrayList<>();
            for(SupplierSolutionViewDTO solutionDTO:solutionGroupDTO.getSolutionList()){
                AssertUtil.assertTrue(CollectionUtils.isNotEmpty(solutionDTO.getResourceDetailList()), "供应商提案资源数据异常");
                DemandViewDTO demandViewDTO = demandViewDTOMap.get(solutionGroupDTO.getDemandId());
                AssertUtil.assertTrue(demandViewDTO != null, "供应商提案无对应诉求信息");
                for (SupplierSolutionResourceDetailViewDTO solutionResourceDetailDTO : solutionDTO.getResourceDetailList()) {
                    ProductSubstitutionDTO productSubstitutionDTO = new ProductSubstitutionDTO();
                    productSubstitutionDTO.setSspProductId(solutionResourceDetailDTO.getSspProductId());
                    productSubstitutionDTO.setStartDate(demandViewDTO.getStartTime());
                    productSubstitutionDTO.setEndDate(demandViewDTO.getEndTime());
                    // CPM达人包取客户填写的
                    if (Objects.equals(solutionDTO.getSspProductLineId(), ProductLineEnum.UD_CONTENT_TALENT_CPM_PACKAGE.getValue())) {
                        //按照cpm单价打的包
                        if(solutionDTO.getCpmSellUnit()){
                            long price = solutionResourceDetailDTO.getPricePolicy().getOriginalPrice().multiply(BigDecimal.valueOf(100)).longValue();
                            long amount = BigDecimal.valueOf(demandViewDTO.getAssignBudget()).divide(BigDecimal.valueOf(price), RoundingMode.FLOOR).longValue();
                            productSubstitutionDTO.setBookingAmount(Math.max(amount, 1));
                            productSubstitutionDTO.setCastAmount(price);
                        }
                        //按照整包档位打包
                        else{
                            long price = solutionResourceDetailDTO.getPricePolicy().getOriginalPrice().multiply(BigDecimal.valueOf(100)).longValue();
                            productSubstitutionDTO.setBookingAmount(1L);
                            productSubstitutionDTO.setCastAmount(price);
                        }
                    } else if (Objects.equals(solutionDTO.getSspProductLineId(), ProductLineEnum.UD_CONTENT_TOP_TALENT.getValue()) || Objects.equals(solutionDTO.getSspProductLineId(), ProductLineEnum.UD_CONTENT_MATERIAL.getValue()))  {
                        long price = solutionResourceDetailDTO.getPricePolicy().getOriginalPrice().multiply(BigDecimal.valueOf(100)).longValue();
                        productSubstitutionDTO.setBookingAmount(1L);
                        productSubstitutionDTO.setCastAmount(price);
                    } else if (Objects.equals(solutionDTO.getSspProductLineId(), ProductLineEnum.UD_CONTENT_TALENT_HOT.getValue())) {
                        long price = Optional.ofNullable(solutionResourceDetailDTO.getOriginalPrice())
                                .map(originalPrice -> originalPrice.multiply(BigDecimal.valueOf(100)))
                                .map(BigDecimal::longValue)
                                .orElse(null);
                        AssertUtil.notNull(price, "获取达人加热净价失败");
                        productSubstitutionDTO.setBookingAmount(1L);
                        productSubstitutionDTO.setCastAmount(price);
                    } else {
                        long price = solutionResourceDetailDTO.getPricePolicy().getOriginalPrice().multiply(BigDecimal.valueOf(100)).longValue();
                        productSubstitutionDTO.setBookingAmount(solutionDTO.getSupplyAmount().longValue());
                        productSubstitutionDTO.setCastAmount(price);
                    }
                    productSubstitutionDTOList.add(productSubstitutionDTO);
                }
            }
            saleGroupSubstitutionDTO.setProductSubstitutionDTOList(productSubstitutionDTOList);
            saleGroupSubstitutionDTOList.add(saleGroupSubstitutionDTO);
        }
        resourcePackageSAO.resourceSubstitutionForContent(serviceContext, saleGroupSubstitutionDTOList);
    }


    private ResourcePackageSaleGroupQueryDTO convertSaleGroupQuery(ResourcePackageQueryViewDTO queryViewDTO, ResourcePackageQueryOption queryOption) {
        ResourcePackageSaleGroupQueryDTOBuilder builder = ResourcePackageSaleGroupQueryDTO.builder().status(
                 queryViewDTO.getStatus()).templateIdList(queryViewDTO.getTemplateId() != null ? Lists.newArrayList(queryViewDTO.getTemplateId()) : null)
                .chargeType(queryViewDTO.getSaleType()).mainGroupId(queryViewDTO.getMainGroupId()).idList(queryViewDTO.getSaleGroupIdList())
                .needProduct(queryOption.getNeedProduct()).needSetting(queryOption.getNeedSetting()).needInquiryPriority(queryOption.getNeedInquiryPriority())
                .hasInquiryPriority(queryViewDTO.getHasInquiryPriority()).memberId(queryViewDTO.getMemberId());
        ResourcePackageSaleGroupQueryDTO build = builder.build();
        build.setPageSize(500);
        build.setToPage(1);
        return build;
    }

    private void parseSaleGroupList(List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupViewDTOS) {
        Map<Long, List<Long>> replenishGroupMap = Maps.newHashMap();
        Map<Long, List<Long>> distributionGroupMap = Maps.newHashMap();
        for (ResourcePackageSaleGroupViewDTO saleGroupViewDTO : resourcePackageSaleGroupViewDTOS) {
            if (saleGroupViewDTO.getMainGroupId() != null) {
                if (BrandSaleTypeEnum.BOOST.getCode().equals(saleGroupViewDTO.getSaleType())) {
                    replenishGroupMap.computeIfAbsent(saleGroupViewDTO.getMainGroupId(), k -> Lists.newArrayList()).add(saleGroupViewDTO.getId());
                } else if (BrandSaleTypeEnum.PRESENT.getCode().equals(saleGroupViewDTO.getSaleType())) {
                    distributionGroupMap.computeIfAbsent(saleGroupViewDTO.getMainGroupId(), k -> Lists.newArrayList()).add(saleGroupViewDTO.getId());
                }
            }
        }
        for (ResourcePackageSaleGroupViewDTO saleGroupViewDTO : resourcePackageSaleGroupViewDTOS) {
            saleGroupViewDTO.setReplenishGroupIds(replenishGroupMap.get(saleGroupViewDTO.getId()));
            saleGroupViewDTO.setDistributionGroupIds(distributionGroupMap.get(saleGroupViewDTO.getId()));
        }
    }

    @Override
    public ResourcePackageSaleGroupViewDTO getSaleGroupById(ServiceContext serviceContext, Long id, ResourcePackageQueryOption queryOption) {
        ResourcePackageSaleGroupDTO saleGroupById = resourcePackageSAO.getSaleGroupById(serviceContext, id, queryOption);
        ResourcePackageSaleGroupViewDTO saleGroupViewDTO = resourcePackageConverter.convertDTO2ViewDTO(saleGroupById);
        return saleGroupViewDTO;
    }

    @Override
    public ResourcePackageSaleGroupViewDTO getSaleGroupWithEditMode(ServiceContext serviceContext, Long saleGroupId) {
        ResourcePackageSaleGroupDTO resourcePackageSaleGroupDTO = resourcePackageSAO.getSaleGroupWithEditMode(serviceContext, saleGroupId);
        return resourcePackageConverter.convertDTO2ViewDTO(resourcePackageSaleGroupDTO);
    }

    @Override
    public ResourcePackageProductViewDTO getResourcePackageProduct(ServiceContext context, ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO, Long resourcePackageProductId) {
        ResourcePackageProductViewDTO resourcePackageProductViewDTO = packageSaleGroupViewDTO.getDistributionRuleList().stream()
                .flatMap(e -> e.getResourcePackageProductList().stream())
                .filter(e -> e.getId().equals(resourcePackageProductId)).findFirst().orElse(null);
        return resourcePackageProductViewDTO;
    }

    @Override
    public ResourcePackageProductViewDTO getSimpleResourcePackageProduct(ServiceContext context, Long resourcePackageProductId) {
        if(resourcePackageProductId == null){
            return null;
        }
        List<ResourcePackageProductDTO> resourcePackageProductDTOList = resourcePackageSAO.getSimplePackageProductListByIds(context, Collections.singletonList(resourcePackageProductId));
        if(CollectionUtils.isEmpty(resourcePackageProductDTOList)){
            return null;
        }
        return resourcePackageConverter.convertDTO2ProductViewDTO(resourcePackageProductDTOList.get(0));
    }

    @Override
    public ResourcePackageProductViewDTO getResourcePackageProduct(ServiceContext context, Long resourcePackageProductId) {
        if(resourcePackageProductId == null){
            return null;
        }
        List<ResourcePackageProductDTO> resourcePackageProductDTOList = resourcePackageSAO.getPackageProductListByIds(context, Collections.singletonList(resourcePackageProductId));
        if(CollectionUtils.isEmpty(resourcePackageProductDTOList)){
            return null;
        }
        return resourcePackageConverter.convertDTO2ProductViewDTO(resourcePackageProductDTOList.get(0));
    }

    @Override
    public List<CampaignInquirySchedulePolicyViewDTO> getResourcePackageProductSchedulePolicyList(ResourcePackageProductViewDTO resourcePackageProductViewDTO, Date startTime, Date endTime) {
        // 匹配资源包产品对应价格波段的开始时间和结束时间
        List<CampaignInquirySchedulePolicyViewDTO> policyViewDTOList = Lists.newArrayList();
        for (ResourcePackageProductPriceViewDTO productPriceViewDTO : resourcePackageProductViewDTO.getBandPriceList()) {
            //时间统一转换为年-月-日进行对比
            if(BrandDateUtil.getDateMidnight(productPriceViewDTO.getStartDate()).compareTo(startTime) <= 0 && BrandDateUtil.getDateMidnight(productPriceViewDTO.getEndDate()).compareTo(endTime) >= 0){
                List<ResoucePackageProductReserveRatioViewDTO> reserveRatioList = Optional.ofNullable(productPriceViewDTO.getReserveList()).orElse(Lists.newArrayList());
                for (ResoucePackageProductReserveRatioViewDTO reserveRatioViewDTO : reserveRatioList) {
                    CampaignInquirySchedulePolicyViewDTO policyViewDTO = new CampaignInquirySchedulePolicyViewDTO();
                    policyViewDTO.setStartTime(BrandDateUtil.getDateMidnight(reserveRatioViewDTO.getStartDate()));
                    policyViewDTO.setEndTime(BrandDateUtil.getDateMidnight(reserveRatioViewDTO.getEndDate()));
                    policyViewDTO.setAmountRatio(reserveRatioViewDTO.getRatio());
                    policyViewDTOList.add(policyViewDTO);
                }
            }
        }
        policyViewDTOList = policyViewDTOList.stream().sorted(Comparator.comparing(
                CampaignInquirySchedulePolicyViewDTO::getStartTime)).collect(Collectors.toList());
        RogerLogger.info("有效时间段（startTime={},endTime={}）资源包二级产品={} 匹配到的预定量周期配置={}",
                BrandDateUtil.date2String(startTime),BrandDateUtil.date2String(endTime),
                resourcePackageProductViewDTO.getId(), JSON.toJSONString(policyViewDTOList));
        return policyViewDTOList;
    }

    @Override
    public ResourcePackageTemplateViewDTO getCustomerTemplateById(ServiceContext serviceContext, Long customerTemplateId) {
        if (customerTemplateId == null) {
            return null;
        }
        ResourcePackageTemplateDTO customerTemplateDTO = resourcePackageSAO.getTemplateById(serviceContext, customerTemplateId);
        return resourcePackageConverter.convertCustomerTemplateDTO2ViewDTO(customerTemplateDTO);
    }

    @Override
    public ResourcePackageTemplateViewDTO getResourceTemplateBySaleGroupId(ServiceContext serviceContext, Long saleGroupId) {
        if (saleGroupId == null) {
            return null;
        }
        ResourcePackageTemplateQueryDTO templateQueryDTO = ResourcePackageTemplateQueryDTO.builder().saleGroupId(saleGroupId)
                .needResourcePackageSaleGroup(false)
                .needResourcePackageProduct(false)
                .needPage(false)
                .needCountAndAmount(false)
                .needRelevantEmp(false)
                .build();
        List<ResourcePackageTemplateDTO> templateDTOS = resourcePackageSAO.findTemplateList(serviceContext, templateQueryDTO);
        return resourcePackageConverter.convertResourceTemplateDTO2ViewDTO(templateDTOS.stream().findFirst().orElse(null));
    }

    @Override
    public Long applySaleGroup(ServiceContext serviceContext, SaleGroupBoostGiveApplyInfoViewDTO applyInfoViewDTO, Long mainGroupId) {
        ReplenishOrDistributionSaleGroupInfoDTO replenishOrDistributionSaleGroupInfoDTO = resourcePackageConverter.convertSaleGroupBoostGiveApplyViewDTO2DTO(applyInfoViewDTO, mainGroupId);
        return resourcePackageSAO.autoAddReplenishAndDistributionCustomerSaleGroup(serviceContext, replenishOrDistributionSaleGroupInfoDTO);
    }

    @Override
    public Long deleteSaleGroup(ServiceContext serviceContext, SaleGroupBoostGiveApplyInfoViewDTO applyInfoViewDTO, Long mainGroupId) {
        ReplenishOrDistributionSaleGroupInfoDTO replenishOrDistributionSaleGroupInfoDTO = resourcePackageConverter.convertSaleGroupBoostGiveApplyViewDTO2DTO(applyInfoViewDTO, mainGroupId);
        return resourcePackageSAO.deleteReplenishAndDistributionCustomerSaleGroup(serviceContext, replenishOrDistributionSaleGroupInfoDTO);
    }

    @Override
    public ResourcePackageProjectViewDTO getResourcePackageProject(ServiceContext serviceContext, Long marketingProjectId) {
        if (marketingProjectId == null) {
            return null;
        }
        ProjectDTO projectDTO = resourcePackageSAO.getMarketingProjectById(serviceContext, marketingProjectId);
        return resourcePackageProjectConverter.convertDTO2ViewDTO(projectDTO);
    }

    @Override
    public List<Long> findRightsTemplateIdList(ServiceContext serviceContext) {
        return resourcePackageSAO.findRightsTemplateIdList(serviceContext);
    }
}
