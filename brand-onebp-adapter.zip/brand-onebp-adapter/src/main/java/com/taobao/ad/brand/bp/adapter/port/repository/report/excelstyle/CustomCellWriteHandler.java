package com.taobao.ad.brand.bp.adapter.port.repository.report.excelstyle;

import com.alibaba.excel.enums.CellDataTypeEnum;
import com.alibaba.excel.metadata.Head;
import com.alibaba.excel.metadata.data.CellData;
import com.alibaba.excel.metadata.data.WriteCellData;
import com.alibaba.excel.write.metadata.holder.WriteSheetHolder;
import com.alibaba.excel.write.style.column.AbstractColumnWidthStyleStrategy;
import com.taobao.ad.brand.bp.client.dto.report.excel.ExcelCatalogueViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.poi.common.usermodel.HyperlinkType;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Hyperlink;
import org.apache.poi.ss.usermodel.Sheet;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 目录页列宽设置
 * @author yuncheng.lyc
 * @date 2023/3/23
 **/
public class CustomCellWriteHandler extends AbstractColumnWidthStyleStrategy {
    private static final int MAX_COLUMN_WIDTH = 255;
    private Map<Integer, Map<Integer, Integer>> CACHE = new HashMap<>();
    private List<ExcelCatalogueViewDTO> homePageList;

    public CustomCellWriteHandler(List<ExcelCatalogueViewDTO> homePageList){
        this.homePageList = homePageList;
    }


    @Override
    protected void setColumnWidth(WriteSheetHolder writeSheetHolder, List<WriteCellData<?>> cellDataList, Cell cell, Head head, Integer relativeRowIndex, Boolean isHead) {
        boolean needSetWidth = isHead || !CollectionUtils.isEmpty(cellDataList);
        if (needSetWidth) {
            Map<Integer, Integer> maxColumnWidthMap = CACHE.get(writeSheetHolder.getSheetNo());
            if (maxColumnWidthMap == null) {
                maxColumnWidthMap = new HashMap<>();
                CACHE.put(writeSheetHolder.getSheetNo(), maxColumnWidthMap);
            }

            Integer columnWidth = this.dataLength(cellDataList, cell, isHead);
            if (columnWidth >= 0) {
                if (columnWidth > MAX_COLUMN_WIDTH) {
                    columnWidth = MAX_COLUMN_WIDTH;
                }
                Integer maxColumnWidth = maxColumnWidthMap.get(cell.getColumnIndex());
                if (maxColumnWidth == null || columnWidth > maxColumnWidth) {
                    maxColumnWidthMap.put(cell.getColumnIndex(), columnWidth);
                    writeSheetHolder.getSheet().setColumnWidth(cell.getColumnIndex(), columnWidth * 256);
                }
            }
        }

        Sheet sheet = writeSheetHolder.getSheet();
        if(cell.getColumnIndex() == 0 && sheet.getSheetName().equals("目录")){
            sheet.setColumnWidth(cell.getColumnIndex(), 80 * 256);
        }

        int rowIndex = 0;
        for(ExcelCatalogueViewDTO homePage: homePageList){
            Integer type = homePage.getType();
            AssertUtil.notNull(type);
            if(ExcelCatalogueViewDTO.ExcelCatalogueFormatEnum.HYPERLINK_ITEM.getValue().equals(type) && rowIndex == relativeRowIndex){
                CreationHelper helper= sheet.getWorkbook().getCreationHelper();
                Hyperlink hyperlink=helper.createHyperlink(HyperlinkType.DOCUMENT);
                hyperlink.setAddress("#"+homePage.getContent()+"!A1");

                cell.setHyperlink(hyperlink);
            }
            ++rowIndex;
        }
    }


    private Integer dataLength(List<WriteCellData<?>> cellDataList, Cell cell, Boolean isHead) {
        if (isHead) {
            return cell.getStringCellValue().getBytes().length;
        } else {
            CellData cellData = cellDataList.get(0);
            CellDataTypeEnum type = cellData.getType();
            if (type == null) {
                return -1;
            } else {
                switch (type) {
                    case STRING:
                        return cellData.getStringValue().getBytes().length;
                    case BOOLEAN:
                        return cellData.getBooleanValue().toString().getBytes().length;
                    case NUMBER:
                        return cellData.getNumberValue().toString().getBytes().length;
                    default:
                        return -1;
                }
            }
        }
    }

}
