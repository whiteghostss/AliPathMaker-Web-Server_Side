package com.taobao.ad.brand.bp.adapter.port.converter.sales;

import com.alibaba.ad.nb.sales.dto.contract.ContractBalance;
import com.taobao.ad.brand.bp.adapter.port.converter.sales.mapstruct.ContractAmountMapStruct;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesContractAmountViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.springframework.stereotype.Component;

/**
 * @author yanjingang
 */
@Component
public class ContractAmountViewDTOConverter extends BaseViewDTOConverter<ContractBalance, SalesContractAmountViewDTO> {

    @Override
    public BaseMapStructMapper<ContractBalance, SalesContractAmountViewDTO> getBaseMapStructMapper() {
        return ContractAmountMapStruct.INSTANCE;
    }
}
