package com.taobao.ad.brand.bp.adapter.port.converter.oplog.mapstruct;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.control.DeepClone;
import org.mapstruct.factory.Mappers;


@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, mappingControl= DeepClone.class)
public interface ServiceContextMapStruct extends BaseMapStructMapper<ServiceContext, ServiceContext> {
    ServiceContextMapStruct INSTANCE = Mappers.getMapper(ServiceContextMapStruct.class);
}
