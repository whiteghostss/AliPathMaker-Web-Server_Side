package com.taobao.ad.brand.bp.adapter.port.repository.mediarule;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.media.mutex.MediaMutexRuleViewDTO;
import com.alibaba.ad.brand.sdk.convert.custom.viewdto.media.MediaMutexRuleViewDTO2DTOConvertProcessor;
import com.alibaba.ad.organizer.dto.media.MediaMutexRuleDTO;
import com.alibaba.ad.universal.sdk.convert.custom.onebp.provider.OneBpConvertProcessorProvider;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.mediarule.MediaMutexRuleSAO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.mediarule.query.MediaMutexRuleQueryViewDTO;
import com.taobao.ad.brand.bp.domain.mediarule.MediaMutexRuleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * 媒体互斥规则
 * @author linhua.deng
 */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class MediaMutexRuleRepositoryImpl implements MediaMutexRuleRepository {

    private final MediaMutexRuleSAO mediaMutexRuleSAO;
    private MediaMutexRuleViewDTO2DTOConvertProcessor PROCESSOR =
            OneBpConvertProcessorProvider.getViewDTO2DTOConvertProcessor(MediaMutexRuleViewDTO2DTOConvertProcessor.class);

    @Override
    public Long addMutexRule(ServiceContext context, MediaMutexRuleViewDTO viewDTO) {
        MediaMutexRuleDTO mediaMutexRuleDTO = PROCESSOR.viewDTO2DTO(viewDTO);
        return mediaMutexRuleSAO.addMutexRule(context,mediaMutexRuleDTO);
    }

    @Override
    public Integer updateMutexRule(ServiceContext context, MediaMutexRuleViewDTO viewDTO) {
        MediaMutexRuleDTO mediaMutexRuleDTO = PROCESSOR.viewDTO2DTO(viewDTO);
        return mediaMutexRuleSAO.updateMutexRule(context, mediaMutexRuleDTO);
    }

    @Override
    public Integer updateMutexRuleStatus(ServiceContext context, List<Long> ids, Integer status) {
        return mediaMutexRuleSAO.updateMutexRuleStatus(context, ids, status);
    }

    @Override
    public MediaMutexRuleViewDTO getMutexRule(ServiceContext context, Long id) {
        MediaMutexRuleDTO mediaMutexRuleDTO = mediaMutexRuleSAO.getMutexRule(context, id);
        RogerLogger.info("转换前={},转换后={}",mediaMutexRuleDTO.toString(),PROCESSOR.dto2ViewDTO(mediaMutexRuleDTO));
        return (mediaMutexRuleDTO == null) ? null : PROCESSOR.dto2ViewDTO(mediaMutexRuleDTO);
    }

    @Override
    public PageResultViewDTO<MediaMutexRuleViewDTO> findMutexRuleList(ServiceContext context, MediaMutexRuleQueryViewDTO queryViewDTO) {
        PageResultViewDTO<MediaMutexRuleDTO> resultList = mediaMutexRuleSAO.findListWithPage(context, queryViewDTO);
        List<MediaMutexRuleViewDTO> mediaMutexRuleViewDTOList = resultList.getList().stream().map(dto -> PROCESSOR.dto2ViewDTO(dto)).collect(Collectors.toList());
        return PageResultViewDTO.of(mediaMutexRuleViewDTOList, resultList.getCount());
    }

    @Override
    public List<MediaMutexRuleViewDTO> findList(ServiceContext serviceContext, MediaMutexRuleQueryViewDTO queryViewDTO) {
        List<MediaMutexRuleDTO> dataList = mediaMutexRuleSAO.findList(serviceContext, queryViewDTO);
        return PROCESSOR.dtoList2ViewDTOList(dataList);
    }

    @Override
    public MediaMutexRuleViewDTO getTopOneByName(ServiceContext serviceContext, String uniqueName) {
        MediaMutexRuleDTO mediaMutexRuleDTO = mediaMutexRuleSAO.getTopOneByName(serviceContext, uniqueName);
        return Objects.nonNull(mediaMutexRuleDTO) ? PROCESSOR.dto2ViewDTO(mediaMutexRuleDTO) : null;
    }
}
