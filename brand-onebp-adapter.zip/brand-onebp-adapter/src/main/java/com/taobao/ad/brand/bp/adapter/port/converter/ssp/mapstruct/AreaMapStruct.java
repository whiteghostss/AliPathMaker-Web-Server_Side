package com.taobao.ad.brand.bp.adapter.port.converter.ssp.mapstruct;

import com.alibaba.ad.nb.ssp.dto.dict.AreaDTO;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.AreaViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author jixiu.lj
 * @date 2023/3/23 22:29
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface AreaMapStruct extends BaseMapStructMapper<AreaDTO, CommonViewDTO> {

    AreaMapStruct INSTANCE = Mappers.getMapper(AreaMapStruct.class);

    AreaViewDTO sourceToViewDTO(AreaDTO source);
}
