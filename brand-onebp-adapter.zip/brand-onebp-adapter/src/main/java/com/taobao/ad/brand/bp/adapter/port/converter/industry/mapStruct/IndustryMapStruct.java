package com.taobao.ad.brand.bp.adapter.port.converter.industry.mapStruct;

import com.taobao.ad.brand.bp.adapter.port.tunnel.dataobject.industry.IndustryDO;
import com.taobao.ad.brand.bp.client.dto.industry.IndustryViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface IndustryMapStruct extends BaseMapStructMapper<IndustryDO, IndustryViewDTO> {
    IndustryMapStruct INSTANCE = Mappers.getMapper(IndustryMapStruct.class);
}
