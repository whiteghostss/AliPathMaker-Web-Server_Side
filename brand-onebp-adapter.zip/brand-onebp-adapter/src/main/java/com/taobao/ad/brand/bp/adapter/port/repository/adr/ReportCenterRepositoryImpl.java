package com.taobao.ad.brand.bp.adapter.port.repository.adr;

import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.adr.AdrSAO;
import com.taobao.ad.brand.bp.domain.adr.ReportCenterRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * ADR报表中心数据查询服务
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ReportCenterRepositoryImpl implements ReportCenterRepository {
    private final AdrSAO adrSAO;

    @Override
    public List<Map<String, Object>> findData(Map<String, Object> queryParams) {
        return adrSAO.findData(queryParams);
    }

}
