package com.taobao.ad.brand.bp.adapter.port.converter.ssp;

import com.alibaba.ad.nb.ssp.dto.dict.AreaDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.ssp.mapstruct.AreaMapStruct;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.TreeNodeViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.AreaViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author jixiu.lj
 * @date 2023/3/23 22:31
 */
@Component
public class AreaConverter extends BaseViewDTOConverter<AreaDTO, CommonViewDTO> {
    @Override
    public BaseMapStructMapper<AreaDTO, CommonViewDTO> getBaseMapStructMapper() {
        return AreaMapStruct.INSTANCE;
    }

    public AreaViewDTO convertToViewDTO(AreaDTO areaDTO){
        AreaViewDTO areaViewDTO = AreaMapStruct.INSTANCE.sourceToViewDTO(areaDTO);
        return areaViewDTO;
    }
    public List<AreaViewDTO> convertToViewDTOList(List<AreaDTO> areaDTOList){
        if(areaDTOList == null){
            return new ArrayList<>();
        }
        return areaDTOList.stream().map(this::convertToViewDTO).collect(Collectors.toList());
    }

    /**
     * 递归构造地域结构树
     * @param areaList
     * @return
     */
    public List<TreeNodeViewDTO> buildAreaTreeNode(List<AreaViewDTO> areaList) {
        List<TreeNodeViewDTO> result = new ArrayList<>();
        Map<Long, List<TreeNodeViewDTO>> areaMap = areaList.stream().map(item -> {
            TreeNodeViewDTO nodeModel = new TreeNodeViewDTO();
            nodeModel.setId(item.getId() != null ? item.getId().longValue() : null);
            nodeModel.setParentId(item.getParentId() != null ? item.getParentId().longValue() : -1L);
            nodeModel.setValue(String.valueOf(item.getValue()));
            nodeModel.setName(item.getName());
            return nodeModel;
        }).collect(Collectors.groupingBy(TreeNodeViewDTO::getParentId));
        List<TreeNodeViewDTO> rootNodeList = areaMap.get(-1L);
        result.addAll(rootNodeList);

        for (TreeNodeViewDTO nodeModel : rootNodeList) {
            buildAreaChildren(nodeModel, areaMap);
        }
        return result;
    }

    private void buildAreaChildren(TreeNodeViewDTO node, Map<Long, List<TreeNodeViewDTO>> areaMap) {
        List<TreeNodeViewDTO> children = areaMap.get(node.getId());
        if (CollectionUtils.isEmpty(children)) {
            return;
        }
        node.setChildren(children);
        for (TreeNodeViewDTO nodeModel : children) {
            buildAreaChildren(nodeModel, areaMap);
        }
    }
}
