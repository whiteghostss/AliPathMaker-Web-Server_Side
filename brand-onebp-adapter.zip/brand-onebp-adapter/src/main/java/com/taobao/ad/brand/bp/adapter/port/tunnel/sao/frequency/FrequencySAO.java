package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.frequency;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.biz.definition.constants.Product;
import com.alibaba.ad.brand.sdk.constant.frequency.field.BrandFrequencyBizTypeEnum;
import com.alibaba.ad.brand.sdk.constant.frequency.setting.BrandFrequencySettingKeyEnum;
import com.alibaba.ad.organizer.api.FrequencyCommandService;
import com.alibaba.ad.organizer.api.FrequencyQueryService;
import com.alibaba.ad.organizer.api.FrequencyRefCommandService;
import com.alibaba.ad.organizer.api.FrequencyRefQueryService;
import com.alibaba.ad.organizer.dto.FrequencyDTO;
import com.alibaba.ad.organizer.dto.FrequencyRefDTO;
import com.alibaba.ad.organizer.dto.query.FrequencyQuery;
import com.alibaba.ad.organizer.dto.query.FrequencyRefQuery;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.alibaba.solar.common.dto.QueryOptionDTO;
import com.alibaba.solar.common.query.dto.PageQueryDTO;
import com.alibaba.solar.common.query.dto.QueryDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.FrequencyQueryViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;

@Component
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class FrequencySAO extends BaseSAO {
    private final FrequencyCommandService frequencyCommandService;
    private final FrequencyQueryService frequencyQueryService;
    private final FrequencyRefCommandService frequencyRefCommandService;
    private final FrequencyRefQueryService frequencyRefQueryService;

    /**
     * 创建中台频控
     * @param serviceContext
     * @param frequencyDTO
     * @return
     */
    public Long addFrequency(ServiceContext serviceContext, FrequencyDTO frequencyDTO) {
        if (BizCodeEnum.BRANDONEBP.getBizCode().equals(serviceContext.getBizCode())) {
            serviceContext.setProductId(Product.BRAND_ONEBP_BRAND.getId());
        }
        SingleResponse<Long> response = frequencyCommandService.addFrequency(serviceContext, frequencyDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 修改中台频控
     * @param serviceContext
     * @param frequencyDTO
     */
    public Integer updateFrequencyPart(ServiceContext serviceContext, FrequencyDTO frequencyDTO) {
        SingleResponse<Integer> response = frequencyCommandService.updateFrequencyPart(serviceContext, frequencyDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 修改中台频控
     * @param serviceContext
     * @param frequencyDTO
     */
    public void updateFrequencyAll(ServiceContext serviceContext, FrequencyDTO frequencyDTO) {
        if (BizCodeEnum.BRANDONEBP.getBizCode().equals(serviceContext.getBizCode())) {
            serviceContext.setProductId(Product.BRAND_ONEBP_BRAND.getId());
        }
        SingleResponse<Integer> response = frequencyCommandService.updateFrequencyAll(serviceContext, frequencyDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR.of(response.getErrorMsg()));
    }

    /**
     * 删除频控
     * @param serviceContext
     * @param ids
     */
    public void deleteFrequency(ServiceContext serviceContext, List<Long> ids) {
        SingleResponse<Integer> response = frequencyCommandService.delFrequencyByIds(serviceContext, ids);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR.of(response.getErrorMsg()));
    }

    /**
     * 删除频控关联关系
     * @param serviceContext
     * @param ids
     */
    public void deleteFrequencyRef(ServiceContext serviceContext, List<Long> ids) {
        if (BizCodeEnum.BRANDONEBP.getBizCode().equals(serviceContext.getBizCode())) {
            serviceContext.setProductId(Product.BRAND_ONEBP_BRAND.getId());
        }
        SingleResponse<Integer> response = frequencyRefCommandService.delFrequencyRefByIds(serviceContext, ids);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR.of(response.getErrorMsg()));
    }

    /**
     * 获取频控信息
     * @param serviceContext
     * @param frequencyIds
     * @return
     */
    public List<FrequencyDTO> findFrequency(ServiceContext serviceContext, List<Long> frequencyIds) {
        QueryDTO queryDTO = QueryDTO.createQuery();
        queryDTO.andCondition(FrequencyQuery.id.in(frequencyIds));
        if (BizCodeEnum.BRANDONEBP.getBizCode().equals(serviceContext.getBizCode())) {
            serviceContext.setProductId(Product.BRAND_ONEBP_BRAND.getId());
        }
        MultiResponse<FrequencyDTO> response = frequencyQueryService.findFrequencyList(serviceContext, queryDTO, QueryOptionDTO.propertyRequired(true));
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 获取频控信息
     * @param serviceContext
     * @param queryViewDTO
     * @return
     */
    public MultiResponse<FrequencyDTO> findFrequencyByKeyword(ServiceContext serviceContext, FrequencyQueryViewDTO queryViewDTO) {
        PageQueryDTO pageQueryDTO = PageQueryDTO.createQuery();
        if (StringUtils.isNotBlank(queryViewDTO.getKeyword())) {
            if (StringUtils.isNumeric(queryViewDTO.getKeyword())) {
                pageQueryDTO.andCondition(FrequencyQuery.id.eq(Long.valueOf(queryViewDTO.getKeyword())));
            } else {
                pageQueryDTO.andCondition(FrequencyQuery.freqName.like(queryViewDTO.getKeyword()));
            }
        }
        if (Objects.nonNull(queryViewDTO.getFrequencyTarget())) {
            pageQueryDTO.andCondition(FrequencyQuery.settingKeyValue.eq(BrandFrequencySettingKeyEnum.FREQUENCY_TARGET.getKey(), String.valueOf(queryViewDTO.getFrequencyTarget())));
        }
        pageQueryDTO.setLimit(queryViewDTO.getPageSize());
        pageQueryDTO.setSkip(queryViewDTO.getStart());
        pageQueryDTO.orderBy(FrequencyQuery.gmtCreate.descOrder());
        if (BizCodeEnum.BRANDONEBP.getBizCode().equals(serviceContext.getBizCode())) {
            serviceContext.setProductId(Product.BRAND_ONEBP_BRAND.getId());
        }
        MultiResponse<FrequencyDTO> response = frequencyQueryService.findFrequencyPage(serviceContext, pageQueryDTO, QueryOptionDTO.propertyRequired(true));
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR.of(response.getErrorMsg()));
        return response;
    }

    /**
     * 通过名称查询频控
     * @param serviceContext
     * @param queryViewDTO
     * @return
     */
    public List<FrequencyDTO> findFrequencyByName(ServiceContext serviceContext, FrequencyQueryViewDTO queryViewDTO) {
        PageQueryDTO pageQueryDTO = PageQueryDTO.createQuery();
        pageQueryDTO.andCondition(FrequencyQuery.freqName.eq(queryViewDTO.getKeyword()));
        if (Objects.nonNull(queryViewDTO.getFrequencyId())) {
            pageQueryDTO.andCondition(FrequencyQuery.id.notEq(queryViewDTO.getFrequencyId()));
        }
        pageQueryDTO.setLimit(queryViewDTO.getPageSize());
        pageQueryDTO.setSkip(queryViewDTO.getStart());
        pageQueryDTO.orderBy(FrequencyQuery.gmtCreate.descOrder());
        pageQueryDTO.andCondition(FrequencyQuery.settingKeyValue.eq(BrandFrequencySettingKeyEnum.FREQUENCY_TARGET.getKey(), String.valueOf(queryViewDTO.getFrequencyTarget())));
        if (BizCodeEnum.BRANDONEBP.getBizCode().equals(serviceContext.getBizCode())) {
            serviceContext.setProductId(Product.BRAND_ONEBP_BRAND.getId());
        }
        MultiResponse<FrequencyDTO> response = frequencyQueryService.findFrequencyPage(serviceContext, pageQueryDTO, QueryOptionDTO.propertyRequired(true));
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 获取频控信息
     * @param serviceContext
     * @param frequencyId
     * @return
     */
    public FrequencyDTO getFrequencyById(ServiceContext serviceContext, Long frequencyId) {
        if (BizCodeEnum.BRANDONEBP.getBizCode().equals(serviceContext.getBizCode())) {
            serviceContext.setProductId(Product.BRAND_ONEBP_BRAND.getId());
        }
        SingleResponse<FrequencyDTO> response = frequencyQueryService.getFrequencyById(serviceContext, frequencyId);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 添加中台 计划/单元与频控绑定关系
     * @param serviceContext
     * @param frequencyDTO
     * @return
     */
    public Long addFrequencyRef(ServiceContext serviceContext, FrequencyRefDTO frequencyDTO) {
        if (BizCodeEnum.BRANDONEBP.getBizCode().equals(serviceContext.getBizCode())) {
            serviceContext.setProductId(Product.BRAND_ONEBP_BRAND.getId());
        }
        SingleResponse<Long> response = frequencyRefCommandService.addFrequencyRef(serviceContext, frequencyDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 获取计划关联的频控
     *
     * @param serviceContext
     * @param ids
     * @param frequencyBizType
     * @return
     */
    public List<FrequencyRefDTO> findFrequencyRef(ServiceContext serviceContext, List<Long> ids, BrandFrequencyBizTypeEnum frequencyBizType) {
        QueryDTO queryDTO = QueryDTO.createQuery();
        queryDTO.andCondition(FrequencyRefQuery.bizId.in(ids));
        queryDTO.andCondition(FrequencyRefQuery.bizType.eq(frequencyBizType.getCode()));
        if (BizCodeEnum.BRANDONEBP.getBizCode().equals(serviceContext.getBizCode())) {
            serviceContext.setProductId(Product.BRAND_ONEBP_BRAND.getId());
        }
        MultiResponse<FrequencyRefDTO> response = frequencyRefQueryService.findFrequencyRefList(serviceContext, queryDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 获取频控关联关系
     * @param serviceContext
     * @param freqIds
     * @return
     */
    public List<FrequencyRefDTO> findFrequencyRefByFreqIds(ServiceContext serviceContext, List<Long> freqIds, Integer frequencyBizType) {
        QueryDTO queryDTO = QueryDTO.createQuery();
        if (CollectionUtils.isNotEmpty(freqIds)) {
            queryDTO.andCondition(FrequencyRefQuery.freqId.in(freqIds));
        }
        queryDTO.andCondition(FrequencyRefQuery.bizType.eq(frequencyBizType));
        if (BizCodeEnum.BRANDONEBP.getBizCode().equals(serviceContext.getBizCode())) {
            serviceContext.setProductId(Product.BRAND_ONEBP_BRAND.getId());
        }
        MultiResponse<FrequencyRefDTO> response = frequencyRefQueryService.findFrequencyRefList(serviceContext, queryDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }
}
