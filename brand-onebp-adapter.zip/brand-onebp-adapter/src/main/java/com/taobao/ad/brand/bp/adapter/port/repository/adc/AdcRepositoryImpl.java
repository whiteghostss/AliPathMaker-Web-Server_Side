package com.taobao.ad.brand.bp.adapter.port.repository.adc;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.nb.framework.adc.dto.AdcCdnDTO;
import com.alibaba.ad.nb.framework.adc.dto.AdcComponentDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.adc.AdcCdnViewDTOConverter;
import com.taobao.ad.brand.bp.adapter.port.converter.adc.AdcComponentViewDTOConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.adc.AdcSAO;
import com.taobao.ad.brand.bp.client.dto.adc.AdcCdnViewDTO;
import com.taobao.ad.brand.bp.client.dto.adc.AdcComponentViewDTO;
import com.taobao.ad.brand.bp.client.dto.adc.query.AdcQueryViewDTO;
import com.taobao.ad.brand.bp.domain.adc.repository.AdcRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AdcRepositoryImpl implements AdcRepository {
    private final AdcSAO adcSAO;
    private final AdcComponentViewDTOConverter adcComponentViewDTOConverter;
    private final AdcCdnViewDTOConverter adcCdnViewDTOConverter;
    public static final String URL_DOMAIN = "alimama";

    @Override
    public List<AdcComponentViewDTO> findMenuList(ServiceContext context, AdcQueryViewDTO queryViewDTO) {
        List<AdcComponentDTO> menuList = adcSAO.findMenuList(buildAdcQueryViewDTO(context, queryViewDTO));

        return adcComponentViewDTOConverter.convertDTO2ViewDTOList(menuList);
    }

    @Override
    public List<AdcComponentViewDTO> findComponentList(ServiceContext context, AdcQueryViewDTO queryViewDTO) {
        List<AdcComponentDTO> componentList = adcSAO.findComponentList(buildAdcQueryViewDTO(context, queryViewDTO));

        return adcComponentViewDTOConverter.convertDTO2ViewDTOList(componentList);
    }

    @Override
    public List<AdcCdnViewDTO> findOneSiteCdnList(ServiceContext context){
        List<AdcCdnDTO> oneSiteCdnList = adcSAO.findOneSiteCdnList();
        return adcCdnViewDTOConverter.convertDTO2ViewDTOList(oneSiteCdnList);
    }
    @Override
    public List<AdcCdnViewDTO> findOneSiteCdnListByUrl(ServiceContext context,String domainTag){
        if (StringUtils.isBlank(domainTag)){
            domainTag = URL_DOMAIN;
        }
        List<AdcCdnDTO> oneSiteCdnList = adcSAO.findOneSiteCdnByUrl(domainTag);

        return adcCdnViewDTOConverter.convertDTO2ViewDTOList(oneSiteCdnList);
    }
    private AdcQueryViewDTO buildAdcQueryViewDTO(ServiceContext context, AdcQueryViewDTO queryViewDTO) {
        AdcQueryViewDTO adcQueryViewDTO = new AdcQueryViewDTO();
        adcQueryViewDTO.setBizCode(BizCodeEnum.BRANDONEBP.getBizCode());
//        adcQueryViewDTO.setBizCode(queryViewDTO.getBizCode());
        adcQueryViewDTO.setComponentCode(queryViewDTO.getComponentCode());
        adcQueryViewDTO.setAdcRoles(context.getRoleNameList());
        adcQueryViewDTO.setFilterMap(queryViewDTO.getFilterMap());
        return adcQueryViewDTO;
    }
}
