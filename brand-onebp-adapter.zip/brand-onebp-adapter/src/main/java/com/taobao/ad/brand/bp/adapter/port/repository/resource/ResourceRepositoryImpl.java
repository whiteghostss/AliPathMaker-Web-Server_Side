package com.taobao.ad.brand.bp.adapter.port.repository.resource;

import com.alibaba.uad.wto.dto.resource.MediaResourceDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.adapter.port.converter.resource.MediaResourceConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.resource.ResourceSAO;
import com.taobao.ad.brand.bp.client.dto.product.ResourceScheduleViewDTO;
import com.taobao.ad.brand.bp.client.dto.resource.MediaResourceViewDTO;
import com.taobao.ad.brand.bp.domain.resource.ResourceRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Objects;

import com.alibaba.abf.governance.context.ServiceContext;

/**
 * @author jixiu.lj
 * @date 2023/3/21 00:43
 */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ResourceRepositoryImpl implements ResourceRepository {

    private final ResourceSAO resourceSAO;
    private final MediaResourceConverter mediaResourceConverter;

    /**
     * 查询资源位列表
     * @param resourceIds
     * @return
     */
    @Override
    public List<MediaResourceViewDTO> getResourceList(List<Long> resourceIds) {
        return mediaResourceConverter.convertDTO2ViewDTOList(resourceSAO.getResourceList( resourceIds));
    }

    @Override
    public MediaResourceViewDTO getResource(Long resourceId) {
        if (Objects.isNull(resourceId)){
            return null;
        }
        List<MediaResourceDTO> mediaResourceDTOList = resourceSAO.getResourceList(Lists.newArrayList(resourceId));
        if (CollectionUtils.isEmpty(mediaResourceDTOList)){
            return null;
        }
        return mediaResourceConverter.convertDTO2ViewDTO(mediaResourceDTOList.get(0));
    }

    /**
     * 根据采购行获取资源排期信息
     * */
    @Override
    public List<ResourceScheduleViewDTO> getResourceScheduleByPurchaseRowIds(List<Long> rowIds) {
        List<ResourceScheduleViewDTO> resourceScheduleViewDTOList = resourceSAO.getResourceScheduleByPurchaseRowIds(rowIds);
        return resourceScheduleViewDTOList;
    }

    /**
     * 根据采购单id查询采购行信息
     */
    @Override
    public List<ResourceScheduleViewDTO> getResourceScheduleByPurchaseOrderId(ServiceContext serviceContext, Long purchaseOrderId) {
        return resourceSAO.getResourceScheduleByPurchaseOrderId(serviceContext, purchaseOrderId);
    }

}
