package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.dooh;

import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.umeng.oplus.domain.dto.bailing.DeviceType4BailingDTO;
import com.umeng.oplus.domain.dto.bailing.SchemeMediaInfoDTO;
import com.umeng.oplus.domain.dto.dsp.plan.DspPlan4BailingDTO;
import com.umeng.oplus.domain.dto.dsp.plan.DspPlanCreateDTO;
import com.umeng.oplus.domain.dto.dsp.plan.DspPlanPriorityIndustryDTO;
import com.umeng.oplus.domain.dto.dsp.scheme.DspSchemeDTO;
import com.umeng.oplus.domain.query.dsp.presale.DspPresaleMedia4BailingQuery;
import com.umeng.oplus.domain.result.PageResultDO;
import com.umeng.oplus.domain.result.ResultDO;
import com.umeng.oplus.openapi.service.dsp.DspScheme4ApiService;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DoohSAO extends BaseSAO {

    private final DspScheme4ApiService dspScheme4ApiService;

//    public Long createCampaign(Long strategyId, Long campaignId, String campaignName, Date startDate){
//        ResultDO<DspPlan4BailingDTO> response = dspScheme4ApiService.createPlanBySchemeId(strategyId, campaignId, campaignName, startDate);
//        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, "天攻计划创建失败:" + response.getErrorMsg());
//        return response.getResult().getDspPlanId();
//    }

    public DspPlan4BailingDTO createCampaign(DspPlanCreateDTO dspPlanCreateDTO) {
        ResultDO<DspPlan4BailingDTO> response = dspScheme4ApiService.createPlan(dspPlanCreateDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, "天攻计划创建失败:" + response.getErrorMsg());
        return response.getResult();
    }

    public Long updateCampaign(Long strategyId, Long campaignId, String campaignName, Date startDate){
        ResultDO<DspPlan4BailingDTO> response = dspScheme4ApiService.updatePlanBySchemeId(strategyId, campaignId, campaignName, startDate);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, "天攻计划更新失败:" + response.getErrorMsg());
        return response.getResult().getDspPlanId();
    }

    public Long updateCampaign(DspPlanCreateDTO dspPlanCreateDTO) {
        ResultDO<DspPlan4BailingDTO> response = dspScheme4ApiService.updatePlan(dspPlanCreateDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, "天攻计划更新失败:" + response.getErrorMsg());
        return response.getResult().getDspPlanId();
    }

    public DspPlan4BailingDTO getCampaignById(Long doohCampaignId){
        ResultDO<DspPlan4BailingDTO> response = dspScheme4ApiService.detailDspPlanInfo(doohCampaignId);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, "天攻查询计划详情失败:" + response.getErrorMsg());
        return response.getResult();
    }

    public List<DspSchemeDTO> findStrategyList(Long memberId, Long doohCampaignId){
        ResultDO<List<DspSchemeDTO>> response = dspScheme4ApiService.getSchemeListByMemberId(memberId, doohCampaignId);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, "天攻查询户外定制策略列表失败:" + response.getErrorMsg());
        return response.getResult();
    }

    public List<DspSchemeDTO> findJsdStrategyList(Long memberId, Long doohCampaignId){
        ResultDO<List<DspSchemeDTO>> response = dspScheme4ApiService.getQuickSchemeListByMemberId(memberId, doohCampaignId);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, "天攻查询极速达策略列表失败:" + response.getErrorMsg());
        return response.getResult();
    }

    public DspSchemeDTO getStrategyById(Long strategyId){
        ResultDO<DspSchemeDTO> response = dspScheme4ApiService.detailSchemeInfo(strategyId);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, "天攻查询策略详情失败:" + response.getErrorMsg());
        return response.getResult();
    }

    public void order(Long doohCampaignId){
        ResultDO<Boolean> response = dspScheme4ApiService.submitCreateOrderAction(doohCampaignId);
        AssertUtil.assertTrue(response.isSuccess() && response.getResult(), BrandOneBPBaseErrorCode.RPC_ERROR, "天攻计划下单失败:" + response.getErrorMsg());
    }

    public void cancelOrder(Long doohCampaignId){
        ResultDO<Boolean> response = dspScheme4ApiService.releaseOrderAction(doohCampaignId);
        AssertUtil.assertTrue(response.isSuccess() && response.getResult(), BrandOneBPBaseErrorCode.RPC_ERROR, "天攻计划撤单失败:" + response.getErrorMsg());

    }

    public void bindCreativeWithCampaignId(Long doohCampaignId, Long creativeId){
        ResultDO<Boolean> response = dspScheme4ApiService.bindCreativeWithDsp(doohCampaignId, creativeId);
        AssertUtil.assertTrue(response.isSuccess() && response.getResult(), BrandOneBPBaseErrorCode.RPC_ERROR, "天攻创意绑定计划失败:" + response.getErrorMsg());
    }

    public void deleteCampaign(Long doohCampaignId){
        ResultDO<Boolean> response = dspScheme4ApiService.delete(doohCampaignId);
        AssertUtil.assertTrue(response.isSuccess() && response.getResult(), BrandOneBPBaseErrorCode.RPC_ERROR, "天攻计划删除失败:" + response.getErrorMsg());
    }

    public void updateCampaignName(Long doohCampaignId, String campaignName){
        dspScheme4ApiService.updatePlanName(doohCampaignId, campaignName);
    }

    public List<CommonViewDTO> getPriorityIndustryList() {
        ResultDO<List<DspPlanPriorityIndustryDTO>> response = dspScheme4ApiService.getPriorityIndustryList();
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, "获取天攻行业失败:" + response.getErrorMsg());
        if (CollectionUtils.isEmpty(response.getResult())) {
            return Collections.emptyList();
        }

        return response.getResult().stream()
                .map(dspPlanPriorityIndustryDTO -> new CommonViewDTO(dspPlanPriorityIndustryDTO.getIndustryId(), dspPlanPriorityIndustryDTO.getIndustryName())).collect(Collectors.toList());
    }

    public MultiResponse<SchemeMediaInfoDTO> pointList(DspPresaleMedia4BailingQuery dspPresaleMedia4BailingQuery){
        PageResultDO<List<SchemeMediaInfoDTO>> response = dspScheme4ApiService.getSchemeMediaInfoList(dspPresaleMedia4BailingQuery);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, "天攻点位列表查询失败:" + response.getErrorMsg());
        return MultiResponse.of(response.getResult(), (int)response.getTotalNum());
    }

    public void savePoint(Long strategyId, List<String> addPointIdList, List<String> removePointIdList){
        ResultDO<Boolean> response = dspScheme4ApiService.resetDspScheme(strategyId, addPointIdList, removePointIdList);
        AssertUtil.assertTrue(response.isSuccess() && response.getResult(), BrandOneBPBaseErrorCode.RPC_ERROR, "天攻策略重新计算失败:" + response.getErrorMsg());
    }

    public List<CommonViewDTO> getDeviceTypeList() {
        ResultDO<List<DeviceType4BailingDTO>> response = dspScheme4ApiService.getDeviceType4BailingList();
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, "获取户外资源场景失败:" + response.getErrorMsg());
        if (CollectionUtils.isEmpty(response.getResult())) {
            return Collections.emptyList();
        }

        return response.getResult().stream()
                .map(deviceTypeDTO -> new CommonViewDTO(deviceTypeDTO.getDeviceTypeId().longValue(), deviceTypeDTO.getDeviceTypeName())).collect(Collectors.toList());
    }
}
