package com.taobao.ad.brand.bp.adapter.port.converter.sales.mapstruct;

import com.alibaba.ad.nb.sales.dto.project.ProjectDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesProjectViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author gxg
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ProjectMapStruct extends BaseMapStructMapper<ProjectDTO, SalesProjectViewDTO> {
    ProjectMapStruct INSTANCE = Mappers.getMapper(ProjectMapStruct.class);

}