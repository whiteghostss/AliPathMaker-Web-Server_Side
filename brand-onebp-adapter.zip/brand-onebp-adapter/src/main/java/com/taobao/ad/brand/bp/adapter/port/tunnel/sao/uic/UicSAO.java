package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.uic;

import com.alibaba.fastjson.JSON;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.uic.common.constants.Sites;
import com.taobao.uic.common.domain.ResultDO;
import com.taobao.uic.common.service.membership.MerchantServiceClient;
import com.taobao.uic.common.service.membership.constant.MembershipConstants;
import com.taobao.uic.common.service.membership.model.SimpleMerchantSetting;
import com.taobao.uic.common.service.membership.param.SiteSeller;
import com.taobao.uic.common.service.userdata.client.UicTagServiceClient;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Objects;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.EXTERNAL_ERROR;

@BizTunnel
@RequiredArgsConstructor(onConstructor_ = @Autowired)
public class UicSAO {
    private final MerchantServiceClient merchantServiceClient;
    private final UicTagServiceClient uicTagServiceClient;

    /**
     * 商家是否开通会员体系
     *
     * @param sellerId
     * @return
     */
    public boolean memberCheck(Long sellerId) {
        try {
            SiteSeller siteSeller = new SiteSeller();
            siteSeller.setSite(Sites.TAOBAO.getSiteName());
            siteSeller.setSellerId(sellerId.toString());
            ResultDO<SimpleMerchantSetting> resultDO = merchantServiceClient.querySimpleMerchantSetting(siteSeller);
            RogerLogger.info("merchantServiceClient querySimpleMerchantSetting result={}", JSON.toJSONString(resultDO));
            if (resultDO == null || !resultDO.isSuccess()) {
                RogerLogger.error("merchantServiceClient querySimpleMerchantSetting error. siteSeller={}, result={}", JSON.toJSONString(siteSeller), JSON.toJSONString(resultDO));
                return false;
            }
            if (resultDO.getModule() == null) {
                return false;
            }
            SimpleMerchantSetting simpleMerchantSetting = resultDO.getModule();
            return Objects.equals(MembershipConstants.MemberProductStatus.ONLINE, simpleMerchantSetting.getMemberProductStatus());
        } catch (Exception e) {
            RogerLogger.error("querySellerStatus error. sellerId={}", sellerId, e);
            return false;
        }
    }

    /**
     * 商家入会是否未被冻结
     *
     * @param sellerId
     * @return
     */
    public boolean checkTag(Long sellerId, String tagCode) {
        ResultDO<Boolean> resultDO = uicTagServiceClient.checkTag(sellerId, tagCode);
        AssertUtil.notNull(resultDO, EXTERNAL_ERROR, "标签返回结果为空");
        AssertUtil.assertTrue(resultDO.isSuccess(), EXTERNAL_ERROR, resultDO.getErrMsg());
        AssertUtil.notNull(resultDO.getModule(), EXTERNAL_ERROR, "标签返回结果为空");
        RogerLogger.info("uicTagServiceClient checkTag result={}", JSON.toJSONString(resultDO));
        return resultDO.getModule();
    }
}
