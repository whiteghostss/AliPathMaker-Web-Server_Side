package com.taobao.ad.brand.bp.adapter.port.repository.campaign;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.audience.constants.SettingKeyEnum;
import com.alibaba.ad.audience.dto.bind.BindAdzoneDTO;
import com.alibaba.ad.audience.dto.bind.BindCrowdDTO;
import com.alibaba.ad.audience.dto.label.LabelDTO;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.biz.definition.constants.Product;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.adzone.CampaignAdzoneViewDTO;
import com.alibaba.ad.brand.dto.campaign.audience.CampaignTargetScenarioViewDTO;
import com.alibaba.ad.brand.dto.campaign.audience.CampaignTargetViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdScenarioViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdViewDTO;
import com.alibaba.ad.brand.dto.campaign.frequence.CampaignFrequencyViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryViewDTO;
import com.alibaba.ad.brand.dto.campaign.keyword.CampaignKeywordViewDTO;
import com.alibaba.ad.brand.dto.campaign.realtime.CampaignRealTimeOptimizeViewDTO;
import com.alibaba.ad.brand.dto.campaign.sale.CampaignSaleViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupBoostGiveApplyCampaignDetailViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupBoostGiveApplyInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.dto.common.BottomDateViewDTO;
import com.alibaba.ad.brand.dto.frequency.FrequencyViewDTO;
import com.alibaba.ad.brand.sdk.constant.audience.field.BrandTargetTypeEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignOnlineStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.setting.BrandCampaignSettingKeyEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.frequency.field.BrandFrequencyBizTypeEnum;
import com.alibaba.ad.brand.sdk.convert.custom.viewdto.CampaignViewDTO2DTOConvertProcessor;
import com.alibaba.ad.brand.sdk.convert.custom.viewdto.audience.AdzoneViewDTO2DTOConvertProcessor;
import com.alibaba.ad.brand.sdk.convert.custom.viewdto.audience.CampaignCrowdViewDTO2DTOConvertProcessor;
import com.alibaba.ad.brand.sdk.convert.custom.viewdto.audience.TargetViewDTO2DTOConvertProcessor;
import com.alibaba.ad.nb.packages.dto.common.CommonDTO;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleProductLineEnum;
import com.alibaba.ad.nb.packages.v2.client.dto.product.ResourcePackageProductDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.salegroup.ResourcePackageSaleGroupDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.salegroup.query.ResourcePackageSaleGroupQueryDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.template.ResourcePackageTemplateDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.template.query.ResourcePackageTemplateQueryDTO;
import com.alibaba.ad.nb.ssp.constant.common.DictTypeEnum;
import com.alibaba.ad.nb.ssp.constant.common.MediaScopeEnum;
import com.alibaba.ad.nb.ssp.constant.common.TemplateAccurateEnum;
import com.alibaba.ad.nb.ssp.constant.template.TemplateAdditionalStatusEnum;
import com.alibaba.ad.nb.ssp.dto.dict.DictionaryDTO;
import com.alibaba.ad.nb.ssp.dto.newproduct.ProductDTO;
import com.alibaba.ad.nb.ssp.dto.template.NbTemplateDTO;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alibaba.ad.organizer.dto.CampaignDTO;
import com.alibaba.ad.organizer.dto.CampaignDealRefDTO;
import com.alibaba.ad.organizer.dto.CampaignInquiryDTO;
import com.alibaba.ad.organizer.dto.FrequencyRefDTO;
import com.alibaba.ad.organizer.dto.query.CampaignQuery;
import com.alibaba.ad.universal.sdk.convert.custom.onebp.provider.OneBpConvertProcessorProvider;
import com.alibaba.fastjson.JSON;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.solar.common.query.dto.PageQueryDTO;
import com.alibaba.solar.common.query.dto.QueryDTO;
import com.alibaba.solar.common.utils.BeanUtilsEx;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.alimama.inventory.dto.ud.InventoryUdImprecisionDTO;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.campaign.CampaignSAO;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.frequency.FrequencySAO;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.inventory.InventorySAO;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.resourcepackage.ResourcePackageSAO;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.ssp.ProductSAO;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.ssp.TemplateSAO;
import com.taobao.ad.brand.bp.client.dto.base.DateViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignBottomDateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignImpressionViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignTemplateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.ItemViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.SaleGroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeTemplateQueryDTO;
import com.taobao.ad.brand.bp.client.dto.mr.MaterialRuleViewDTO;
import com.taobao.ad.brand.bp.client.dto.resource.MediaResourceViewDTO;
import com.taobao.ad.brand.bp.client.dto.template.TemplateViewDTO;
import com.taobao.ad.brand.bp.client.enums.BizKeywordTypeEnum;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignCrowdSceneEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.constant.CampaignConstant;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.constant.ReportConstant;
import com.taobao.ad.brand.bp.common.threadpooltask.CampaignGetBottomInfoTaskIdentifier;
import com.taobao.ad.brand.bp.common.threadpooltask.CampaignQueryTaskIdentifier;
import com.taobao.ad.brand.bp.common.threadpooltask.CampaignSettingDeleteTaskIdentifier;
import com.taobao.ad.brand.bp.common.threadpooltask.CampaignUpdateTaskIdentifier;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.PageUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.config.CreativeTemplateConfigDiamond;
import com.taobao.ad.brand.bp.domain.keywordcenter.repository.KeywordRepository;
import com.taobao.ad.brand.bp.domain.resource.ResourceRepository;
import com.taobao.ad.brand.bp.domain.ssp.MaterialRuleRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_REQUIRED;
import static com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper.isTXorShowmaxCampaign;


@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CampaignRepositoryImpl implements CampaignRepository {
    private final CampaignSAO campaignSAO;
    private final FrequencySAO frequencySAO;
    private final InventorySAO inventorySAO;
    private final TemplateSAO templateSAO;

    private final ProductSAO productSAO;
    private final CampaignGroupRepository campaignGroupRepository;

    private final ResourceRepository resourceRepository;

    private final MaterialRuleRepository materialRuleRepository;
    private final KeywordRepository keywordRepository;

    private final ResourcePackageSAO resourcePackageSAO;
    private final CreativeTemplateConfigDiamond creativeTemplateConfigDiamond;
    private static final ThreadPoolExecutor THREAD_POOL = new ThreadPoolExecutor(
            20, 20, 60L, TimeUnit.SECONDS, new ArrayBlockingQueue<>(2048),
            new ThreadFactoryBuilder().setNameFormat("default_biz_campaign_repository-%d").build());

    private CampaignViewDTO2DTOConvertProcessor campaignProcessor = OneBpConvertProcessorProvider.getViewDTO2DTOConvertProcessor(CampaignViewDTO2DTOConvertProcessor.class);
    private AdzoneViewDTO2DTOConvertProcessor adzoneProcessor = OneBpConvertProcessorProvider.getViewDTO2DTOConvertProcessor(AdzoneViewDTO2DTOConvertProcessor.class);
    private TargetViewDTO2DTOConvertProcessor targetProcessor = OneBpConvertProcessorProvider.getViewDTO2DTOConvertProcessor(TargetViewDTO2DTOConvertProcessor.class);
    private CampaignCrowdViewDTO2DTOConvertProcessor crowdProcessor = OneBpConvertProcessorProvider.getViewDTO2DTOConvertProcessor(CampaignCrowdViewDTO2DTOConvertProcessor.class);;

    private final CampaignQueryTaskIdentifier campaignQueryTaskIdentifier;
    private final CampaignUpdateTaskIdentifier campaignUpdateTaskIdentifier;
    private final CampaignGetBottomInfoTaskIdentifier campaignGetBottomInfoTaskIdentifier;
    private final CampaignSettingDeleteTaskIdentifier campaignSettingDeleteTaskIdentifier;

//    private static final ThreadPoolExecutor THREAD_UPDATE_POOL = new ThreadPoolExecutor(
//            30, 30, 60L, TimeUnit.SECONDS, new ArrayBlockingQueue<>(4096),
//            new ThreadFactoryBuilder().setNameFormat("campaign_update_repository-%d").build());
//
//    private static final ThreadPoolExecutor THREAD_QUERY_POOL = new ThreadPoolExecutor(
//        20, 20, 60L, TimeUnit.SECONDS, new ArrayBlockingQueue<>(2048),
//        new ThreadFactoryBuilder().setNameFormat("campaign_query_repository-%d").build());

    @Override
    public PageResultViewDTO<CampaignViewDTO> queryCampaignPageList(ServiceContext serviceContext, CampaignQueryViewDTO query) {
        PageQueryDTO pageQueryDTO = PageQueryDTO.createQuery();
        initQueryDTO(serviceContext,query,pageQueryDTO);
        pageQueryDTO.setLimit(query.getPageSize());
        pageQueryDTO.setSkip(query.getStart());
        pageQueryDTO.orderBy(CampaignQuery.gmtCreate.descOrder());
        MultiResponse<CampaignDTO> campaignResult = campaignSAO.queryCampaignPageList(serviceContext,pageQueryDTO);
        PageResultViewDTO<CampaignViewDTO> pageResultViewDTO = new PageResultViewDTO<CampaignViewDTO>();
        List<CampaignViewDTO> campaignViewDTOList = campaignProcessor.dtoList2ViewDTOList(campaignResult.getResult());
        pageResultViewDTO.setList(campaignViewDTOList);
        pageResultViewDTO.setCount(campaignResult.getTotal());
        return pageResultViewDTO;
    }

    @Override
    public Integer queryCampaignCount(ServiceContext serviceContext, CampaignQueryViewDTO query) {
        QueryDTO queryDTO = QueryDTO.createQuery();
        initQueryDTO(serviceContext, query, queryDTO);
        return campaignSAO.queryCampaignListCount(serviceContext, queryDTO);
    }

    @Override
    public List<CampaignViewDTO> queryCampaignList(ServiceContext serviceContext, CampaignQueryViewDTO query) {
        return queryCampaignListByThread(serviceContext,query);
    }

    private List<CampaignViewDTO> queryCampaignListByThread(ServiceContext serviceContext, CampaignQueryViewDTO query) {
        //查询全量改为分页查询
        PageQueryDTO pageQueryDTO = PageQueryDTO.createQuery();
        initQueryDTO(serviceContext,query,pageQueryDTO);
        int total = campaignSAO.queryCampaignListCount(serviceContext,pageQueryDTO);
        List<CampaignViewDTO> resultList = Lists.newArrayList();
        if(total <= 0){
            return resultList;
        }
        if(total > PageUtil.MAX_PAGE_COUNT){
            int frequency = total/PageUtil.MAX_PAGE_COUNT;
            if(total % PageUtil.MAX_PAGE_COUNT != 0){
                frequency++;
            }
            RogerLogger.info("queryByThread total {} frequency {}",total,frequency);
            List<PageQueryDTO> queryViewDTOS = Lists.newArrayList();
            for(int i =0; i < frequency ; i++){
                PageQueryDTO pageQueryDTOTemp = PageQueryDTO.createQuery(PageUtil.MAX_PAGE_COUNT*i,PageUtil.MAX_PAGE_COUNT);
                initQueryDTO(serviceContext,query,pageQueryDTOTemp);
                queryViewDTOS.add(pageQueryDTOTemp);
            }
            TaskStream.execute(campaignQueryTaskIdentifier, queryViewDTOS, (pageQueryDTOTemp, index) -> {
                        MultiResponse<CampaignDTO> campaignResult = campaignSAO.queryCampaignPageList(serviceContext,pageQueryDTOTemp);
                        return campaignProcessor.dtoList2ViewDTOList(campaignResult.getResult());
                    })
                    .commit()
                    .handleResult((result) -> {
                        result.forEach(resultList::addAll);
                    });
        }else{
            pageQueryDTO.setLimit(PageUtil.MAX_PAGE_COUNT);
            pageQueryDTO.setSkip(0);
            RogerLogger.info("queryByNormal total {}  ",total);
            MultiResponse<CampaignDTO> campaignResult = campaignSAO.queryCampaignPageList(serviceContext,pageQueryDTO);
            List<CampaignViewDTO> campaignViewDTOList = campaignProcessor.dtoList2ViewDTOList(campaignResult.getResult());
            resultList.addAll(campaignViewDTOList);
        }
        return resultList;
    }

    @Override
    public boolean queryIsBindCampaignByCrowdId(ServiceContext serviceContext, Long crowdId) {
       return  campaignSAO.queryIsBindCampaign(serviceContext,crowdId);
    }

    @Override
    public void addCampaign(ServiceContext serviceContext, Long campaignGroupId, List<CampaignViewDTO> campaignViewDTOList) {
        for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
            CampaignDTO campaignDTO = campaignProcessor.viewDTO2DTO(campaignViewDTO);
            Long campaignId = campaignSAO.addCampaign(serviceContext, campaignGroupId, campaignDTO);
            campaignViewDTO.setId(campaignId);
        }
    }


    @Override
    public void addCampaign(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList) {
        for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
            CampaignDTO campaignDTO = campaignProcessor.viewDTO2DTO(campaignViewDTO);
            Long campaignId = campaignSAO.addCampaign(serviceContext, campaignDTO);
            campaignViewDTO.setId(campaignId);
        }
    }


    @Override
    public void updateCampaignPart(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList) {
        //单条数据，不启动多线程
        if(campaignViewDTOList.size() == 1){
            updateCampaignPart(serviceContext,campaignViewDTOList.get(0));
        }else{
            TaskStream.consume(campaignUpdateTaskIdentifier, campaignViewDTOList, (campaignViewDTO, index) -> {
                        CampaignDTO campaignDTO = campaignProcessor.viewDTO2DTO(campaignViewDTO);
                        campaignSAO.updateCampaignPart(serviceContext, campaignDTO);
                    }).commit().handle();
        }
    }

    @Override
    public void updateCampaignPartWithoutInquiry(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList) {
        TaskStream.consume(campaignUpdateTaskIdentifier, campaignViewDTOList, (campaignViewDTO, index) -> {
                    CampaignDTO campaignDTO = campaignProcessor.viewDTO2DTO(campaignViewDTO);
                    campaignDTO.setCampaignInquiryList(null);
                    campaignSAO.updateCampaignPart(serviceContext, campaignDTO);
                })
                .commit()
                .handle();
//        CompletableFutureTask.batchOperate(campaignViewDTO -> {
//            CampaignDTO campaignDTO = campaignProcessor.viewDTO2DTO(campaignViewDTO);
//            campaignDTO.setCampaignInquiryList(null);
//            campaignSAO.updateCampaignPart(serviceContext, campaignDTO);
//            return campaignDTO.getId();
//        },campaignViewDTOList,3,"批量部分更新计划",THREAD_UPDATE_POOL);
    }

    @Override
    public void updateCampaignBudgetRatio(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList) {
        boolean hasAdd = campaignViewDTOList.stream().anyMatch(item -> item.getId() == null);
        AssertUtil.assertTrue(!hasAdd, PARAM_REQUIRED, "有计划id为空的数据");
        TaskStream.consume(campaignUpdateTaskIdentifier, campaignViewDTOList, (campaignViewDTO, index) -> {
                    CampaignDTO campaignDTO = new CampaignDTO();
                    campaignDTO.setId(campaignViewDTO.getId());
                    String settingKey = BrandCampaignSettingKeyEnum.BUDGET_RATIO.getKey();
                    String settingValue = String.valueOf(campaignViewDTO.getCampaignBudgetViewDTO().getBudgetRatio());
                    campaignDTO.getUserDefineProperties().put(settingKey, settingValue);
                    campaignSAO.updateCampaignPart(serviceContext, campaignDTO);
                })
                .commit()
                .handle();
    }

    @Override
    public void updateCampaignAll(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList) {
        for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
            CampaignDTO campaignDTO = campaignProcessor.viewDTO2DTO(campaignViewDTO);
            campaignSAO.updateCampaignAll(serviceContext, campaignDTO);
        }
    }

    @Override
    public void updateCampaignSetting(ServiceContext serviceContext,String settingKey,String settingValue,Long campaignId) {
        CampaignDTO dbCampaignDTO = campaignSAO.getCampaignById(serviceContext,campaignId);
        if(dbCampaignDTO == null){
            return;
        }
        String dbSettingValue = dbCampaignDTO.getProperty(settingKey);
        if(StringUtils.equals(settingValue,dbSettingValue)){
            return;
        }
        CampaignDTO campaignDTO = new CampaignDTO();
        campaignDTO.setId(campaignId);
        campaignDTO.getUserDefineProperties().put(settingKey,settingValue);
        campaignSAO.updateCampaignSetting(serviceContext, campaignDTO);
    }


    @Override
    public void updateCampaignInquiryAll(ServiceContext serviceContext, Long campaignId, List<CampaignInquiryViewDTO> inquiryDTOList) {
        List<CampaignInquiryDTO> inquiryDTOS = Optional.ofNullable(inquiryDTOList).orElse(Lists.newArrayList()).stream().filter(v -> v.getBookAmount() > 0).map(
            (item) -> BeanUtilsEx.copyPropertiesExcludeNull(item, new CampaignInquiryDTO())).collect(Collectors.toList());
        campaignSAO.updateCampaignInquiryAll(serviceContext, campaignId, inquiryDTOS);
    }


    @Override
    public void deleteCampaignSettingBatch(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList, List<String> settingKeyList) {
        TaskStream.consume(campaignSettingDeleteTaskIdentifier, campaignViewDTOList, (campaignViewDTO, index) -> {
                    Long campaignId = campaignViewDTO.getId();
                    campaignSAO.deleteCampaignSettingBatch(serviceContext, campaignId, settingKeyList);
                })
                .commit()
                .handle();
//        CompletableFutureTask.batchOperate(campaignViewDTO -> {
//            Long campaignId = campaignViewDTO.getId();
//            campaignSAO.deleteCampaignSettingBatch(serviceContext, campaignId, settingKeyList);
//            return campaignId;
//        }, campaignViewDTOList, 10, "计划批量删除setting信息", THREAD_UPDATE_POOL);
    }

    @Override
    public void updateCampaignPart(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {
        CampaignDTO campaignDTO = campaignProcessor.viewDTO2DTO(campaignViewDTO);
        campaignSAO.updateCampaignPart(serviceContext, campaignDTO);
    }

    @Override
    public void addCampaignTarget(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList) {
        for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
            List<BindCrowdDTO> allTarget = buildCampaignTarget(campaignViewDTO);
            // 添加定向
            if (CollectionUtils.isNotEmpty(allTarget)) {
                //TODO 定向数据中过滤小时定向：BrandTargetTypeEnum.TIME_PLUS
                campaignSAO.addCampaignCrowd(serviceContext, allTarget);
            }
        }
    }

    @Override
    public void addCampaignAdzone(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList) {
        for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
            Long campaignId = campaignViewDTO.getId();
            List<CampaignAdzoneViewDTO> campaignAdzoneViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignTargetScenarioViewDTO())
                    .map(CampaignTargetScenarioViewDTO::getCampaignAdzoneViewDTOList).orElse(null);
            if (CollectionUtils.isNotEmpty(campaignAdzoneViewDTOList)) {
                List<BindAdzoneDTO> bindAdzoneDTOS = adzoneProcessor.viewDTOList2DTOList(campaignAdzoneViewDTOList);
                bindAdzoneDTOS.forEach(item -> item.setCampaignId(campaignId));
                campaignSAO.addCampaignAdzone(serviceContext, bindAdzoneDTOS);
            }
        }
    }

    @Override
    public void updateCampaignAdzoneAll(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList) {
        for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
            Long campaignId = campaignViewDTO.getId();
            List<CampaignAdzoneViewDTO> campaignAdzoneViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignTargetScenarioViewDTO())
                    .map(CampaignTargetScenarioViewDTO::getCampaignAdzoneViewDTOList).orElse(null);
            if (CollectionUtils.isNotEmpty(campaignAdzoneViewDTOList)) {
                List<BindAdzoneDTO> bindAdzoneDTOS = adzoneProcessor.viewDTOList2DTOList(campaignAdzoneViewDTOList);
                bindAdzoneDTOS.forEach(item -> item.setCampaignId(campaignId));
                campaignSAO.updateCampaignAdzoneAll(serviceContext, bindAdzoneDTOS);
            }
        }
    }

    @Override
    public void updateCampaignTarget(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList) {
        List<Long> campaignIds = campaignViewDTOList.stream().map(e -> e.getId()).collect(Collectors.toList());
        List<BindCrowdDTO> bindCrowdDTOList = campaignSAO.findBindCrowdDTO(serviceContext, campaignIds);
        Map<Long, List<BindCrowdDTO>> campaignCrowdMap = bindCrowdDTOList.stream().collect(Collectors.groupingBy(BindCrowdDTO::getCampaignId));
        for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
            List<BindCrowdDTO> allTarget = buildCampaignTarget(campaignViewDTO);
            List<BindCrowdDTO> dbCrowdDTOS = campaignCrowdMap.get(campaignViewDTO.getId());
            if (CollectionUtils.isNotEmpty(allTarget)) {
                //TODO 定向数据中过滤小时定向：BrandTargetTypeEnum.TIME_PLUS
                // 修改定向
                campaignSAO.updateCampaignCrowd(serviceContext, allTarget);
            } else if (CollectionUtils.isNotEmpty(dbCrowdDTOS)) {
                // 删除定向
                campaignSAO.deleteCampaignCrowd(serviceContext, campaignViewDTO.getId());
            }
        }
    }


    @Override
    public void deleteAllTargetByCampaignIds(ServiceContext serviceContext, List<Long> campaignIds) {
        //主子计划复制场景：计划数量2个，避免这个场景使用多线程
        if(campaignIds.size() <= 2){
            for (Long campaignId : campaignIds) {
                campaignSAO.deleteCampaignCrowd(serviceContext,campaignId);
            }
            return;
        }
        //数据量大于2
        TaskStream.consume(campaignSettingDeleteTaskIdentifier, campaignIds, (campaignId, index) -> {
                    campaignSAO.deleteCampaignCrowd(serviceContext, campaignId);
                })
                .commit()
                .handle();
    }

    @Override
    public void addOrUpdateCampaignTargetPart(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {
        List<BindCrowdDTO> targetPart = buildCampaignTarget(campaignViewDTO);
        if (CollectionUtils.isEmpty(targetPart)) {
            return;
        }
        campaignSAO.addOrUpdateBatchCampaignCrowd(serviceContext, targetPart);
    }

    @Override
    public void deleteCampaignCrowdPart(ServiceContext serviceContext, Long campaignId, BrandTargetTypeEnum targetTypeEnum) {
        campaignSAO.deleteCampaignCrowd(serviceContext, campaignId,targetTypeEnum);
    }

    @Override
    public void deleteCampaignCrowdByAudienceCrowdIds(ServiceContext serviceContext, Long campaignId, List<Long> audienceCrowdIds) {
        if (CollectionUtils.isEmpty(audienceCrowdIds)) {
            return;
        }
        campaignSAO.deleteCampaignCrowdByAudienceCrowdIds(serviceContext, audienceCrowdIds);
    }

    @Override
    public void deleteCampaignCrowdPart(ServiceContext serviceContext, List<Long> campaignIds, BrandTargetTypeEnum targetTypeEnum) {
        //主子计划复制场景：计划数量2个，避免这个场景使用多线程
        if(campaignIds.size() <= 2){
            for (Long campaignId : campaignIds) {
                campaignSAO.deleteCampaignCrowd(serviceContext,campaignId,targetTypeEnum);
            }
            return;
        }
        //数据量大于2
        TaskStream.consume(campaignSettingDeleteTaskIdentifier, campaignIds, (campaignId, index) -> {
                    campaignSAO.deleteCampaignCrowd(serviceContext, campaignId,targetTypeEnum);
                })
                .commit()
                .handle();
//        CompletableFutureTask.batchOperate(campaignId -> {
//            campaignSAO.deleteCampaignCrowd(serviceContext, campaignId,targetTypeEnum);
//            return campaignId;
//        },campaignIds,3,"批量删除计划定向",THREAD_UPDATE_POOL);
    }

    private List<BindCrowdDTO> buildCampaignTarget(CampaignViewDTO campaignViewDTO) {
        Long campaignId = campaignViewDTO.getId();
        List<BindCrowdDTO> allTarget = new ArrayList<>();
        // 人群构建
        List<CampaignCrowdViewDTO> campaignCrowdViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignCrowdScenarioViewDTO())
                .map(CampaignCrowdScenarioViewDTO::getCampaignCrowdViewDTOList).orElse(null);
        List<BindCrowdDTO> bindCrowdDTOList = crowdProcessor.viewDTOList2DTOList(campaignCrowdViewDTOList);
        if (CollectionUtils.isNotEmpty(bindCrowdDTOList)) {
            //天攻人群定向引擎不感知
            if (campaignViewDTO.getCampaignSaleViewDTO() != null
                    && SaleProductLineEnum.SMART_SCREEN.getValue().equals(campaignViewDTO.getCampaignSaleViewDTO().getSaleProductLine())) {
                bindCrowdDTOList.forEach(item -> item.setOnlineStatus(BrandCampaignOnlineStatusEnum.OFFLINE.getCode()));
            }
            allTarget.addAll(bindCrowdDTOList);
        }
        // 定向构建
        List<CampaignTargetViewDTO> campaignTargetViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignTargetScenarioViewDTO()).map(CampaignTargetScenarioViewDTO::getCampaignTargetViewDTOList).orElse(Lists.newArrayList());
        List<BindCrowdDTO> targetDTOList = targetProcessor.viewDTOList2DTOList(campaignTargetViewDTOList);
        if (CollectionUtils.isNotEmpty(targetDTOList)) {
            for(BindCrowdDTO crowdDTO : targetDTOList){
                Integer code = crowdDTO.getTagDTO().getTagRefType() != null ? crowdDTO.getTagDTO().getTagRefType().intValue() : null;
                //非二环地域引擎不关心
                crowdDTO.setOnlineStatus(BrandCampaignOnlineStatusEnum.ONLINE.getCode());
                //年龄 性别 媒体人群  联投媒体 媒体地域 媒体小时定向 全域标签 媒体兴趣标签 引擎不关心
                //三环 贴位定向 引擎不感知   天攻的定向引擎不感知
                if (BrandTargetTypeEnum.GENDER_PLUS.getCode().equals(code) ||
                        BrandTargetTypeEnum.AGE_PLUS.getCode().equals(code) ||
                        BrandTargetTypeEnum.MULTI_MEDIA.getCode().equals(code) ||
                        BrandTargetTypeEnum.MEDIA_CROWD.getCode().equals(code) ||
                        BrandTargetTypeEnum.AREA_MEDIA.getCode().equals(code) ||
                        BrandTargetTypeEnum.TIME_PLUS_MEDIA.getCode().equals(code) ||
                        BrandTargetTypeEnum.ALI_CROWD_SCORE.getCode().equals(code) ||
                        BrandTargetTypeEnum.MEDIA_INTEREST_LABEL.getCode().equals(code) ||
                        BrandTargetTypeEnum.OOH_JSD_INDUSTRY.getCode().equals(code) ||
                        BrandTargetTypeEnum.OOH_JSD_OPTIMIZED.getCode().equals(code) ||
                        (campaignViewDTO.getCampaignSaleViewDTO()!=null
                                && SaleProductLineEnum.SMART_SCREEN.getValue().equals(campaignViewDTO.getCampaignSaleViewDTO().getSaleProductLine())) ||
                        BrandTargetTypeEnum.DEVICE_MEDIA.getCode().equals(code) ||
                        BrandTargetTypeEnum.POSITION_PLUS_MEDIA.getCode().equals(code)
                ) {
                    crowdDTO.setOnlineStatus(BrandCampaignOnlineStatusEnum.OFFLINE.getCode());
                }
            }
            allTarget.addAll(targetDTOList);
        }
        allTarget.forEach(item -> item.setCampaignId(campaignId));
        return allTarget;
    }

    @Override
    public CampaignViewDTO getCampaignById(ServiceContext serviceContext, Long campaignId) {
        CampaignDTO campaign = campaignSAO.getCampaignById(serviceContext, campaignId);
        CampaignViewDTO campaignViewDTO = campaignProcessor.dto2ViewDTO(campaign);
        return campaignViewDTO;
    }

    /**
     * 从库存获取计划的打底配置信息
     * @param serviceContext
     * @param subCampaignIds
     * @return
     */
    @Override
    public List<CampaignImpressionViewDTO> getCampaignImpressionInfoList(ServiceContext serviceContext, List<Long> subCampaignIds){

        if(CollectionUtils.isEmpty(subCampaignIds)){
            return Lists.newArrayList();
        }
        List<InventoryUdImprecisionDTO> inventoryUdImprecisionDTOList =
        TaskStream.execute(campaignGetBottomInfoTaskIdentifier, subCampaignIds, (subCampaignId, index) ->
                        inventorySAO.getBottomPurchaseOrder(subCampaignId))
                .commit()
                .getResultList();
//        List<InventoryUdImprecisionDTO> inventoryUdImprecisionDTOList =
//                CompletableFutureTask.batchOperate(inventorySAO::getBottomPurchaseOrder, subCampaignIds, 10, "批量从库存获取计划的打底配置信息", THREAD_POOL);

        if (CollectionUtils.isEmpty(inventoryUdImprecisionDTOList)) {
            return Lists.newArrayList();
        }
        //对库存数据进行处理
        List<CampaignImpressionViewDTO> resultList = Lists.newArrayList();
        inventoryUdImprecisionDTOList.forEach(imprecisionDTO->{
            //只有state=QUALIFIED，才会取到具体的数据，NOT_ORDER是还没有到获取的时机，UNQUALIFIED表示该点位不需要打底
            //state=QUALIFIED时表示数据完全可用
            if(imprecisionDTO.getState() == InventoryUdImprecisionDTO.State.NOT_READY){
                RogerLogger.info("onebp-purchaseOrder-imprecision 客户未下单，子计划id = {}，result={}",imprecisionDTO.getBusinessId(), JSON.toJSONString(imprecisionDTO));
                CampaignImpressionViewDTO campaignImpressionDTO = new CampaignImpressionViewDTO();
                campaignImpressionDTO.setStatus(CampaignImpressionViewDTO.CampaignImpressionStatusEnum.NOT_ORDER);
                campaignImpressionDTO.setSubCampaignId(imprecisionDTO.getBusinessId());
                resultList.add(campaignImpressionDTO);
                return;
            }

            if(imprecisionDTO.getState() == InventoryUdImprecisionDTO.State.UNQUALIFIED){
                RogerLogger.info("onebp-purchaseOrder-imprecision 子计划ID：{} 无需创建非精准投放，result={}",imprecisionDTO.getBusinessId(),JSON.toJSONString(imprecisionDTO));
                CampaignImpressionViewDTO campaignImpressionDTO = new CampaignImpressionViewDTO();
                campaignImpressionDTO.setStatus(CampaignImpressionViewDTO.CampaignImpressionStatusEnum.UNQUALIFIED);
                campaignImpressionDTO.setSubCampaignId(imprecisionDTO.getBusinessId());
                resultList.add(campaignImpressionDTO);
                return;
            }

            if(imprecisionDTO.getState() == InventoryUdImprecisionDTO.State.QUALIFIED){
                List<InventoryUdImprecisionDTO.DayDTO> dayDTOList = imprecisionDTO.getDayList();
                if(org.apache.commons.collections4.CollectionUtils.isEmpty(dayDTOList)){
                    RogerLogger.info("onebp-purchaseOrder-imprecision 子计划ID：{} 具备非精准打底资格，打底排期数据为空，result={}",imprecisionDTO.getBusinessId(),JSON.toJSONString(imprecisionDTO));
                    CampaignImpressionViewDTO campaignImpressionDTO = new CampaignImpressionViewDTO();
                    campaignImpressionDTO.setStatus(CampaignImpressionViewDTO.CampaignImpressionStatusEnum.NOT_READY);
                    campaignImpressionDTO.setSubCampaignId(imprecisionDTO.getBusinessId());
                    resultList.add(campaignImpressionDTO);
                    return;
                }

                boolean noBottomDay = dayDTOList.stream().anyMatch(dayDTO -> dayDTO.getDay() == null || CollectionUtils.isEmpty(dayDTO.getRowList()));
                if(noBottomDay){
                    RogerLogger.info("onebp-purchaseOrder-imprecision 子计划ID：{} 具备非精准打底资格，打底排期数据为空，result={}",imprecisionDTO.getBusinessId(),JSON.toJSONString(imprecisionDTO));
                    CampaignImpressionViewDTO campaignImpressionDTO = new CampaignImpressionViewDTO();
                    campaignImpressionDTO.setStatus(CampaignImpressionViewDTO.CampaignImpressionStatusEnum.NOT_READY);
                    campaignImpressionDTO.setSubCampaignId(imprecisionDTO.getBusinessId());
                    resultList.add(campaignImpressionDTO);
                    return;
                }

                dayDTOList.stream().map(InventoryUdImprecisionDTO.DayDTO::getDay).distinct().sorted().forEach(day -> {
                    CampaignImpressionViewDTO campaignImpressionDTO = new CampaignImpressionViewDTO();
                    campaignImpressionDTO.setStatus(CampaignImpressionViewDTO.CampaignImpressionStatusEnum.QUALIFIED);
                    campaignImpressionDTO.setDate(day);
                    campaignImpressionDTO.setSubCampaignId(imprecisionDTO.getBusinessId());
                    resultList.add(campaignImpressionDTO);
                });
            }
        });
        return resultList;
    }


    /**
     * 获取计划的打底日期
     * */
    @Override
    public List<BottomDateViewDTO> getCampaignBottomDateList(ServiceContext serviceContext, List<Long> subCampaignIds) {
        List<CampaignBottomDateViewDTO> campaignBottomDateViewDTOList = getSubCampaignBottomDateList(serviceContext, subCampaignIds,Lists.newArrayList());
        List<Date> days =
                campaignBottomDateViewDTOList.stream().filter(item->CollectionUtils.isNotEmpty(item.getBottomDateList())).flatMap(item -> item.getBottomDateList().stream()).map(item-> BrandDateUtil.getDayList(item.getStartDate(),item.getEndDate())).flatMap(Collection::stream).distinct().sorted().collect(Collectors.toList());


        List<DateViewDTO> dateViewDTOList = BrandDateUtil.formatDateQuantum(days);

        List<BottomDateViewDTO> resultList = Optional.ofNullable(dateViewDTOList).orElse(Lists.newArrayList()).stream().map(item->{
            BottomDateViewDTO bottomDateViewDTO =new BottomDateViewDTO();
            bottomDateViewDTO.setStartDate(item.getStartDate());
            bottomDateViewDTO.setEndDate(item.getEndDate());
            return bottomDateViewDTO;
        }).collect(Collectors.toList());
        return resultList;
    }

    @Override
    public List<CampaignBottomDateViewDTO> getSubCampaignBottomDateList(ServiceContext serviceContext, List<Long> subCampaignIds,List<CampaignImpressionViewDTO.CampaignImpressionStatusEnum> noReadyStatusList) {
        List<CampaignBottomDateViewDTO> result = Lists.newArrayList();
        List<CampaignImpressionViewDTO> campaignImpressionInfoList = getCampaignImpressionInfoList(serviceContext, subCampaignIds);

        if (CollectionUtils.isEmpty(noReadyStatusList)){
            noReadyStatusList.add(CampaignImpressionViewDTO.CampaignImpressionStatusEnum.NOT_READY);
        }

        Optional<CampaignImpressionViewDTO> impressionDTOOptional = campaignImpressionInfoList.stream()
                .filter(info -> info.getStatus() != null && noReadyStatusList.contains(info.getStatus()))
                .findAny();

//        Optional<CampaignImpressionViewDTO> impressionDTOOptional = campaignImpressionInfoList.stream()
//                .filter(info -> info.getStatus() == CampaignImpressionViewDTO.CampaignImpressionStatusEnum.NOT_READY)
//                .findAny();
        if(impressionDTOOptional.isPresent()) {
            throw new BrandOneBPException("媒体尚未录入排期pubdeal，暂不能创建媒体直投");
        }
        Map<Long, List<CampaignImpressionViewDTO>> campaignImpressionInfoMap = campaignImpressionInfoList
                .stream()
                .collect(Collectors.groupingBy(CampaignImpressionViewDTO::getSubCampaignId));
        campaignImpressionInfoMap.forEach((subCampaignId, impressionInfoList) -> {
            List<BottomDateViewDTO> bottomDateViewDTOList = convertToBottomDateViewDTO(impressionInfoList);
            CampaignBottomDateViewDTO campaignBottomDateViewDTO = new CampaignBottomDateViewDTO();
            campaignBottomDateViewDTO.setSubCampaignId(subCampaignId);
            List<DateViewDTO> dateViewDTOList = Optional.ofNullable(bottomDateViewDTOList).orElse(Lists.newArrayList()).stream().map(item->{
                DateViewDTO dateViewDTO =new DateViewDTO();
                dateViewDTO.setStartDate(item.getStartDate());
                dateViewDTO.setEndDate(item.getEndDate());
                return dateViewDTO;
            }).collect(Collectors.toList());
            campaignBottomDateViewDTO.setBottomDateList(dateViewDTOList);
            result.add(campaignBottomDateViewDTO);
            RogerLogger.info("onebp-purchaseOrder-imprecision 子计划ID：{} 具备非精准打底资格，打底信息如下，result={}",subCampaignId,JSON.toJSONString(impressionInfoList));
        });
        return result;

    }

    /**
     * 获取计划的打底日期
     * */
    public List<BottomDateViewDTO> getCampaignBottomDateList(ServiceContext serviceContext, List<Long> subCampaignIds,List<CampaignImpressionViewDTO.CampaignImpressionStatusEnum> noReadyStatusList) {

        List<CampaignImpressionViewDTO> campaignImpressionInfoList = getCampaignImpressionInfoList(serviceContext, subCampaignIds);

        List<BottomDateViewDTO> result = Lists.newArrayList();
        Optional<CampaignImpressionViewDTO> impressionDTOOptional = campaignImpressionInfoList.stream()
                .filter(info -> info.getStatus() != null && noReadyStatusList.contains(info.getStatus()))
                .findAny();
        if(impressionDTOOptional.isPresent()) {
            throw new BrandOneBPException("媒体尚未录入排期pubdeal，暂不能创建媒体直投");
        }

        Map<Long, List<CampaignImpressionViewDTO>> campaignImpressionInfoMap = campaignImpressionInfoList
                .stream()
                .collect(Collectors.groupingBy(CampaignImpressionViewDTO::getSubCampaignId));
        campaignImpressionInfoMap.forEach((subCampaignId, impressionInfoList) -> {
            result.addAll(convertToBottomDateViewDTO(impressionInfoList));
            RogerLogger.info("onebp-purchaseOrder-imprecision 子计划ID：{} 具备非精准打底资格，打底信息如下，result={}",subCampaignId,JSON.toJSONString(impressionInfoList));
        });
        return result;
    }

    /**
     * 数据转换
     */
    @Override
    public List<BottomDateViewDTO> convertToBottomDateViewDTO(List<CampaignImpressionViewDTO> dateList){

        List<Date> days= dateList.stream().map(CampaignImpressionViewDTO::getDate).filter(Objects::nonNull).distinct().sorted().collect(Collectors.toList());
        List<BottomDateViewDTO> resultList = Lists.newArrayList();
        List<DateViewDTO> dateViewDTOList = BrandDateUtil.formatDateQuantum(days);
        if (CollectionUtils.isNotEmpty(dateViewDTOList)){
            resultList = dateViewDTOList.stream().map(t->{
                BottomDateViewDTO bottomDateViewDTO = new BottomDateViewDTO();
                bottomDateViewDTO.setStartDate(t.getStartDate());
                bottomDateViewDTO.setEndDate(t.getEndDate());

                return bottomDateViewDTO;

            }).collect(Collectors.toList());
        }
        return resultList;
    }

    @Override
    public Map<Long, CampaignViewDTO> getCampaignTarget(ServiceContext serviceContext, List<Long> campaignIds) {
        Map<Long, CampaignViewDTO> result = new HashMap<>();
        List<BindCrowdDTO> bindCrowdDTOList = campaignSAO.findBindCrowdDTO(serviceContext, campaignIds);
        Map<Long, List<BindCrowdDTO>> campaignMap = bindCrowdDTOList.stream().collect(Collectors.groupingBy(BindCrowdDTO::getCampaignId));
        for (Map.Entry<Long, List<BindCrowdDTO>> entry : campaignMap.entrySet()) {
            CampaignViewDTO campaignViewDTO = new CampaignViewDTO();
            if (CollectionUtils.isEmpty(entry.getValue())) {
                result.put(entry.getKey(), campaignViewDTO);
                continue;
            }
            List<BindCrowdDTO> crowdDTOList = entry.getValue().stream().filter(e -> Objects.nonNull(e.getCrowdDTO()) && Objects.nonNull(e.getCrowdDTO().getTargetType())
                    && (BrandTargetTypeEnum.DMP_CROWD.getCode().equals(e.getCrowdDTO().getTargetType().intValue()) ||
                    CampaignConstant.TX_OPTIMIZE_CROWD_TYPE.stream().anyMatch(brandTargetTypeEnum -> brandTargetTypeEnum.getCode().equals(e.getCrowdDTO().getTargetType().intValue())) ||
                    BrandTargetTypeEnum.RECOMMEND.getCode().equals(e.getCrowdDTO().getTargetType().intValue()) ||
                    BrandTargetTypeEnum.BLOCK_CROWD.getCode().equals(e.getCrowdDTO().getTargetType().intValue()) ||
                    BrandTargetTypeEnum.BLOCK_CROWD_ID.getCode().equals(e.getCrowdDTO().getTargetType().intValue()) ||
                    BrandTargetTypeEnum.BRAND_ALGO_CROWD_NEW.getCode().equals(e.getCrowdDTO().getTargetType().intValue())) ||
                    BrandTargetTypeEnum.ALGO_CONTROL_NO_TARGET_CROWD.getCode().equals(e.getCrowdDTO().getTargetType().intValue())
            ).collect(Collectors.toList());

            List<CampaignCrowdViewDTO> campaignCrowdViewDTOList = crowdProcessor.dtoList2ViewDTOList(crowdDTOList);
            //百灵临时兜底方案,后续dmp升级接口后可去除
            if (CollectionUtils.isNotEmpty(campaignCrowdViewDTOList)) {
                campaignCrowdViewDTOList.forEach(crowdViewDTO -> {
                    if (crowdViewDTO.getCrowdId() != null && StringUtils.isBlank(crowdViewDTO.getCrowdName())) {
                        crowdViewDTO.setCrowdName(ReportConstant.DMP_CROWD_DEFAULT_NAME);
                    }
                });
            }
            CampaignCrowdScenarioViewDTO campaignCrowdScenarioViewDTO = new CampaignCrowdScenarioViewDTO();
            campaignCrowdScenarioViewDTO.setCampaignCrowdViewDTOList(campaignCrowdViewDTOList);
            campaignViewDTO.setCampaignCrowdScenarioViewDTO(campaignCrowdScenarioViewDTO);

            CampaignTargetScenarioViewDTO campaignTargetScenarioViewDTO = new CampaignTargetScenarioViewDTO();
            List<CampaignTargetViewDTO> targetViewDTOList = targetProcessor.dtoList2ViewDTOList(entry.getValue());
            campaignTargetScenarioViewDTO.setCampaignTargetViewDTOList(targetViewDTOList.stream().filter(Objects::nonNull).collect(Collectors.toList()));
            campaignViewDTO.setCampaignTargetScenarioViewDTO(campaignTargetScenarioViewDTO);

            result.put(entry.getKey(), campaignViewDTO);
        }
        //关键词定向
        Map<Long, CampaignKeywordViewDTO> campaignKeywordViewDTOMap = keywordRepository.selectByCampaignIds(serviceContext, campaignIds);
        if(!campaignKeywordViewDTOMap.isEmpty()){
            for (Map.Entry<Long, CampaignKeywordViewDTO> entry : campaignKeywordViewDTOMap.entrySet()) {
                if(result.containsKey(entry.getKey())){
                    result.get(entry.getKey()).setCampaignKeywordViewDTO(entry.getValue());
                }else{
                    CampaignViewDTO campaignViewDTO = new CampaignViewDTO();
                    campaignViewDTO.setCampaignKeywordViewDTO(entry.getValue());
                    result.put(entry.getKey(), campaignViewDTO);
                }
            }
        }
        return result;
    }

    @Override
    public Map<Long, List<CampaignAdzoneViewDTO>> getCampaignAdzone(ServiceContext serviceContext, List<Long> campaignIds) {
        Map<Long, List<CampaignAdzoneViewDTO>> result = new HashMap<>();
        List<BindAdzoneDTO> bindAdzoneDTOList = campaignSAO.findBindAdzoneDTO(serviceContext, campaignIds);
        Map<Long, List<BindAdzoneDTO>> adzoneMap = bindAdzoneDTOList.stream().collect(Collectors.groupingBy(BindAdzoneDTO::getCampaignId));
        for (Map.Entry<Long, List<BindAdzoneDTO>> entry : adzoneMap.entrySet()) {
            List<CampaignAdzoneViewDTO> adzoneViewDTOList = adzoneProcessor.dtoList2ViewDTOList(entry.getValue());
            result.put(entry.getKey(), adzoneViewDTOList);
        }
        return result;
    }

    @Override
    public List<CampaignAdzoneViewDTO> getCampaignAdzoneByCampaignIds(ServiceContext serviceContext, List<Long> campaignIds){
        List<BindAdzoneDTO> bindAdzoneDTOList = campaignSAO.findBindAdzoneDTO(serviceContext, campaignIds);
        List<CampaignAdzoneViewDTO> adzoneViewDTOList = adzoneProcessor.dtoList2ViewDTOList(bindAdzoneDTOList);
        return adzoneViewDTOList;
    }

    @Override
    public List<Long> getCampaignTanxDealIds(ServiceContext serviceContext, List<Long> campaignIds) {
        List<CampaignDealRefDTO>  campaignDealRefDTOList = campaignSAO.queryCampaignDealRefDTOList(serviceContext,campaignIds);
        if(CollectionUtils.isNotEmpty(campaignDealRefDTOList)){
            return campaignDealRefDTOList.stream()
                    //过滤过期的tanxDeal
                    .filter(item -> !BrandDateUtil.getCurrentDate().after(item.getTanxDealDTO().getEndTime()))
                    .map(item->item.getTanxDealDTO().getTanxDealId()).distinct().collect(Collectors.toList());
        }
        return Lists.newArrayList();
    }


    /**
     * key subCampaingID
     * value: dealIds
     * */
    @Override
    public Map<Long,List<Long>> getSubCampaignTanxDealIdsMap(ServiceContext serviceContext, List<Long> campaignIds) {
        List<CampaignDealRefDTO>  campaignDealRefDTOList = campaignSAO.queryCampaignDealRefDTOList(serviceContext,campaignIds);
        if(CollectionUtils.isNotEmpty(campaignDealRefDTOList)){

           return
                   campaignDealRefDTOList.stream().collect(Collectors.groupingBy(CampaignDealRefDTO::getCampaignId,
                            Collectors.mapping(item->item.getTanxDealDTO().getTanxDealId(), Collectors.toList())));

        }
        return Maps.newHashMap();
    }
    @Override
    public List<String> getCampaignPubdealDealIds(ServiceContext serviceContext, List<Long> campaignIds) {
        List<CampaignDealRefDTO>  campaignDealRefDTOList = campaignSAO.queryCampaignDealRefDTOList(serviceContext,campaignIds);
        if(CollectionUtils.isNotEmpty(campaignDealRefDTOList)){
            return campaignDealRefDTOList.stream().map(item->item.getTanxDealDTO().getPubDealId()).filter(StringUtils::isNotBlank).collect(Collectors.toList());
        }
        return Lists.newArrayList();
    }

    @Override
    public void physicsDelCampaign(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO){
        Exception exception = null;
        try {
            List<CampaignAdzoneViewDTO> campaignAdzoneViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignTargetScenarioViewDTO())
                    .map(CampaignTargetScenarioViewDTO::getCampaignAdzoneViewDTOList).orElse(null);
            if(CollectionUtils.isNotEmpty(campaignAdzoneViewDTOList)){
                campaignSAO.delCampaignAdzoneByCampaignId(serviceContext,campaignViewDTO.getId());
            }
            List<CampaignTargetViewDTO> campaignTargetViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignTargetScenarioViewDTO())
                    .map(CampaignTargetScenarioViewDTO::getCampaignTargetViewDTOList).orElse(null);
            if(CollectionUtils.isNotEmpty(campaignTargetViewDTOList)){
                campaignSAO.deleteCampaignCrowd(serviceContext,campaignViewDTO.getId());
            }
            FrequencyViewDTO frequencyViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignFrequencyViewDTO())
                    .map(CampaignFrequencyViewDTO::getFrequencyViewDTO).orElse(null);
            if (Objects.isNull(frequencyViewDTO)) {
                List<FrequencyRefDTO> frequencyRefList = frequencySAO.findFrequencyRef(serviceContext, Lists.newArrayList(campaignViewDTO.getId()), BrandFrequencyBizTypeEnum.CAMPAIGN);
                List<Long> refIds = frequencyRefList.stream().map(FrequencyRefDTO::getId).collect(Collectors.toList());
                if(CollectionUtils.isNotEmpty(refIds)){
                    frequencySAO.deleteFrequencyRef(serviceContext, refIds);
                }
            }
        } catch (Exception e) {
            RogerLogger.error("计划部分数据删除失败",e);
            exception = e;
        }
        campaignSAO.physicsDelCampaign(serviceContext,campaignViewDTO.getId());
        if(exception != null){
            throw new BrandOneBPException("计划部分数据删除失败",exception);
        }
    }

    @NotNull
    private void initQueryDTO(ServiceContext serviceContext,CampaignQueryViewDTO query,QueryDTO queryDTO) {
        //如果是站点级别的bizcode 不需要根据场景查询
        if(!BizCodeEnum.BRANDONEBP.getBizCode().equals(serviceContext.getBizCode())){
            if(Objects.nonNull(ServiceContextUtil.getSceneId(serviceContext))){
                queryDTO.andCondition(CampaignQuery.sceneId.eq(ServiceContextUtil.getSceneId(serviceContext)));
            }
        } else {
            serviceContext.setProductId(Product.BRAND_ONEBP_BRAND.getId());
        }
        // 新建补量计划时，当产品线=单媒体营销 时，新建补量选择主计划时，只能选择补量申请的主一级计划。
        if (Objects.nonNull(query.getBoostSaleGroupId())) {
            List<Long> boostQueryCampaignIds = getApplyCampaignIdsOnCreateBoostCampaign(serviceContext, query);
            query.setCampaignIds(mergeQueryCampaignIds(boostQueryCampaignIds, query.getCampaignIds()));
        }
        if(StringUtils.isNotBlank(query.getKeyword()) && Objects.nonNull(query.getKeywordType()) ){
            if(query.getKeywordType().equals(BizKeywordTypeEnum.CAMPAIGN_ID)){
                queryDTO.andCondition(CampaignQuery.id.eq(Long.parseLong(query.getKeyword())));
            }
            if(query.getKeywordType().equals(BizKeywordTypeEnum.CAMPAIGN_NAME)){
                queryDTO.andCondition(CampaignQuery.title.like(query.getKeyword()));
            }
            if(query.getKeywordType().equals(BizKeywordTypeEnum.CAMPAIGN_SSP_RESOURCE_ID)){
                queryDTO.andCondition(CampaignQuery.settingKeyValue.like(BrandCampaignSettingKeyEnum.SSP_RESOURCE_IDS.getKey(),
                    query.getKeyword()));
            }
            if(query.getKeywordType().equals(BizKeywordTypeEnum.CAMPAIGN_SSP_PRODUCT_UUID)){
                queryDTO.andCondition(CampaignQuery.settingKeyValue.eq(BrandCampaignSettingKeyEnum.SSP_PRODUCT_UUID.getKey(),
                    query.getKeyword()));
            }
            if(query.getKeywordType().equals(BizKeywordTypeEnum.CAMPAIGN_SSP_PRODUCT_ID)){
                queryDTO.andCondition(CampaignQuery.settingKeyValue.eq(BrandCampaignSettingKeyEnum.SSP_PRODUCT_ID.getKey(),
                    query.getKeyword()));
            }
            if(query.getKeywordType().equals(BizKeywordTypeEnum.CAMPAIGN_SSP_MEDIA_NAME)){
                List<DictionaryDTO> dictionaryDTOList = productSAO.getSSPDictByName(DictTypeEnum.UNIFIED_MEDIA_ID.getType(), query.getKeyword());
                if(CollectionUtils.isNotEmpty(dictionaryDTOList)){
                    List<String> mediaIds = dictionaryDTOList.stream().map(DictionaryDTO::getValue).collect(Collectors.toList());
                    if(CollectionUtils.isNotEmpty(mediaIds)){
                        queryDTO.andCondition(CampaignQuery.settingKeyValue.in(BrandCampaignSettingKeyEnum.SSP_MEDIA_ID.getKey(), mediaIds));
                    }
                }
            }
            if(query.getKeywordType().equals(BizKeywordTypeEnum.CAMPAIGN_SSP_RESOURCE_NAME)){
                List<ProductDTO> productDTOList = productSAO.getProductListByName(query.getKeyword());
                if(CollectionUtils.isNotEmpty(productDTOList)){
                    List<Long> productIds = productDTOList.stream().map(ProductDTO::getUuid).collect(Collectors.toList());
                    if(CollectionUtils.isNotEmpty(productIds)){
                        List<String> productStrList = productIds.stream().map(String::valueOf).collect(Collectors.toList());
                        queryDTO.andCondition(CampaignQuery.settingKeyValue.in(BrandCampaignSettingKeyEnum.SSP_PRODUCT_UUID.getKey(), productStrList));
                    }
                }
            }
        }
        if(Objects.nonNull(query.getCampaignLevel())){
            queryDTO.andCondition(CampaignQuery.settingKeyValue.eq(BrandCampaignSettingKeyEnum.CAMPAIGN_LEVEL.getKey(),
                query.getCampaignLevel().toString()));
        }
        if(Objects.nonNull(query.getCampaignGroupId())){
            queryDTO.andCondition(CampaignQuery.settingKeyValue.eq(BrandCampaignSettingKeyEnum.CAMPAIGN_GROUP_ID.getKey(), query.getCampaignGroupId().toString()));
        }
        if(Objects.nonNull(query.getMainCampaignGroupId())){
            queryDTO.andCondition(CampaignQuery.settingKeyValue.eq(BrandCampaignSettingKeyEnum.MAIN_CAMPAIGN_GROUP_ID.getKey(), query.getMainCampaignGroupId().toString()));
        }
        if(Objects.nonNull(query.getSubContractId())){
            queryDTO.andCondition(CampaignQuery.settingKeyValue.eq(BrandCampaignSettingKeyEnum.SUB_CONTRACT_ID.getKey(), query.getSubContractId().toString()));
        }
        if(CollectionUtils.isNotEmpty(query.getSubContractIds())){
            queryDTO.andCondition(CampaignQuery.settingKeyValue.in(BrandCampaignSettingKeyEnum.SUB_CONTRACT_ID.getKey(),query.getSubContractIds().stream().map(String::valueOf).collect(Collectors.toList())));
        }

        if(CollectionUtils.isNotEmpty(query.getCampaignGroupIds())){
            queryDTO.andCondition(CampaignQuery.settingKeyValue.in(BrandCampaignSettingKeyEnum.CAMPAIGN_GROUP_ID.getKey(), query.getCampaignGroupIds().stream().map(String::valueOf).collect(Collectors.toList())));
        }
        if(CollectionUtils.isNotEmpty(query.getCampaignIds())){
            queryDTO.andCondition(CampaignQuery.id.in(query.getCampaignIds()));
            // queryDTO.andCondition(CampaignQuery.p.in(BrandCampaignSettingKeyEnum..getDesc(), query.getCampaignGroupId().toString()));
        }
        if(Objects.nonNull(query.getTitle())){
            queryDTO.andCondition(CampaignQuery.title.like(query.getTitle()));
        }
        if(Objects.nonNull(query.getTitleEq())){
            queryDTO.andCondition(CampaignQuery.title.eq(query.getTitleEq()));
        }
        if (Objects.nonNull(query.getCampaignModel())){
            queryDTO.andCondition(CampaignQuery.campaignModel.eq(query.getCampaignModel()));
        }

        if(CollectionUtils.isNotEmpty(query.getParentCampaignIds())){
             queryDTO.andCondition(CampaignQuery.orderId.in(query.getParentCampaignIds()));
        }
        if(Objects.nonNull(query.getResourcePackageProductId())){
            queryDTO.andCondition(CampaignQuery.settingKeyValue.eq(BrandCampaignSettingKeyEnum.RESOURCE_PACKAGE_PRODUCT_ID.getKey(), query.getResourcePackageProductId().toString()));
        }
        if(CollectionUtils.isNotEmpty(query.getResourcePackageProductIds())){
            queryDTO.andCondition(CampaignQuery.settingKeyValue.in(BrandCampaignSettingKeyEnum.RESOURCE_PACKAGE_PRODUCT_ID.getKey(), query.getResourcePackageProductIds().stream().map(String::valueOf).collect(Collectors.toList())));
        }
        if(CollectionUtils.isNotEmpty(query.getBudgetCampaignIds())){
            queryDTO.andCondition(CampaignQuery.settingKeyValue.in(BrandCampaignSettingKeyEnum.BUDGET_CAMPAIGN_ID.getKey(), query.getBudgetCampaignIds().stream().map(String::valueOf).collect(Collectors.toList())));
        }
        if (CollectionUtils.isNotEmpty(query.getSourceCampaignIds())) {
            queryDTO.andCondition(CampaignQuery.settingKeyValue.in(BrandCampaignSettingKeyEnum.SOURCE_CAMPAIGN_ID.getKey(), query.getSourceCampaignIds().stream().map(String::valueOf).collect(Collectors.toList())));
        }
        if(Objects.nonNull(query.getSspRegisterUnit())){
            queryDTO.andCondition(CampaignQuery.settingKeyValue.eq(BrandCampaignSettingKeyEnum.SSP_REGISTER_UNIT.getKey(), query.getSspRegisterUnit().toString()));
        }
        if(Objects.nonNull(query.getSaleGroupId())){
            queryDTO.andCondition(CampaignQuery.settingKeyValue.eq(BrandCampaignSettingKeyEnum.SALE_GROUP_ID.getKey(), query.getSaleGroupId().toString()));
        }
        if(CollectionUtils.isNotEmpty(query.getStatusList())){
            queryDTO.andCondition(CampaignQuery.settingKeyValue.in(BrandCampaignSettingKeyEnum.STATUS.getKey(), query.getStatusList().stream().map(String::valueOf).collect(Collectors.toList())));
        }else {
            queryDTO.andCondition(CampaignQuery.settingKeyValue.notEq(BrandCampaignSettingKeyEnum.STATUS.getKey(), BrandCampaignStatusEnum.DELETE.getCode().toString()));
        }
        if(CollectionUtils.isNotEmpty(query.getSaleGroupIds())){
            queryDTO.andCondition(CampaignQuery.settingKeyValue.in(BrandCampaignSettingKeyEnum.SALE_GROUP_ID.getKey(), query.getSaleGroupIds().stream().map(String::valueOf).collect(Collectors.toList())));
        }
        if(CollectionUtils.isNotEmpty(query.getSspRegisterManners())){
            queryDTO.andCondition(CampaignQuery.settingKeyValue.in(BrandCampaignSettingKeyEnum.SSP_REGISTERMANNER.getKey(), query.getSspRegisterManners().stream().map(String::valueOf).collect(Collectors.toList())));
        }
        if(CollectionUtils.isNotEmpty(query.getSaleTypes())){
            queryDTO.andCondition(CampaignQuery.settingKeyValue.in(BrandCampaignSettingKeyEnum.SALE_TYPE.getKey(), query.getSaleTypes().stream().map(String::valueOf).collect(Collectors.toList())));
        }
        if(Objects.nonNull(query.getSspProductId())){
            queryDTO.andCondition(CampaignQuery.settingKeyValue.eq(BrandCampaignSettingKeyEnum.SSP_PRODUCT_ID.getKey(), String.valueOf(query.getSspProductId())));
        }
        if(CollectionUtils.isNotEmpty(query.getSspMediaIds())){
            queryDTO.andCondition(CampaignQuery.settingKeyValue.in(BrandCampaignSettingKeyEnum.SSP_MEDIA_ID.getKey(), query.getSspMediaIds().stream().map(String::valueOf).collect(Collectors.toList())));
        }
        if(Objects.nonNull(query.getStartTime()) && Objects.nonNull(query.getEndTime())){
            queryDTO.andCondition(CampaignQuery.startTime.ltEq(query.getEndTime()));
            queryDTO.andCondition(CampaignQuery.endTime.gtEq(query.getStartTime()));
        }else{
            if(Objects.nonNull(query.getStartTime())){
                queryDTO.andCondition(CampaignQuery.startTime.gtEq(query.getStartTime()));
            }
            if(Objects.nonNull(query.getEndTime())){
                queryDTO.andCondition(CampaignQuery.endTime.ltEq(query.getEndTime()));
            }
        }
        if(Objects.nonNull(query.getStartTimeSpan()) && Objects.nonNull(query.getStartTimeSpan().getStartTime()) && Objects.nonNull(query.getStartTimeSpan().getEndTime()) ) {
            queryDTO.andCondition(CampaignQuery.startTime.gtEq(query.getStartTimeSpan().getStartTime()));
            queryDTO.andCondition(CampaignQuery.startTime.ltEq(query.getStartTimeSpan().getEndTime()));
        }

        if(Objects.nonNull(query.getEndTimeSpan()) && Objects.nonNull(query.getEndTimeSpan().getStartTime()) && Objects.nonNull(query.getEndTimeSpan().getEndTime())) {
            queryDTO.andCondition(CampaignQuery.endTime.gtEq(query.getEndTimeSpan().getStartTime()));
            queryDTO.andCondition(CampaignQuery.endTime.ltEq(query.getEndTimeSpan().getEndTime()));
        }

        if(CollectionUtils.isNotEmpty(query.getResourceIds())) {
            queryDTO.andCondition(CampaignQuery.settingKeyValue.in(BrandCampaignSettingKeyEnum.SSP_PRODUCT_UUID.getKey(), query.getResourceIds().stream().map(String::valueOf).collect(Collectors.toList())));
        }

        if (CollectionUtils.isNotEmpty(query.getAdvIds())){
            queryDTO.andCondition(CampaignQuery.settingKeyValue.in(BrandCampaignSettingKeyEnum.EFFECT_ADV_ID.getKey(), query.getAdvIds().stream().map(String::valueOf).collect(Collectors.toList())));
        }
        if(Objects.nonNull(query.getCampaignFrequencyTarget())){
            queryDTO.andCondition(CampaignQuery.settingKeyValue.eq(BrandCampaignSettingKeyEnum.CAMPAIGN_FREQUENCY_TARGET.getKey(), String.valueOf(query.getCampaignFrequencyTarget())));
        }
        if (CollectionUtils.isNotEmpty(query.getSaleProductLineList())) {
            queryDTO.andCondition(CampaignQuery.settingKeyValue.in(BrandCampaignSettingKeyEnum.SALE_PRODUCT_LINE.getKey(), query.getSaleProductLineList().stream().map(String::valueOf).collect(Collectors.toList())));
        }
        if(CollectionUtils.isNotEmpty(query.getMediaScopeList())){
            queryDTO.andCondition(CampaignQuery.settingKeyValue.in(BrandCampaignSettingKeyEnum.SSP_MEDIA_SCOPE.getKey(), query.getMediaScopeList().stream().map(String::valueOf).collect(Collectors.toList())));
        }
        if(Objects.nonNull(query.getSspProgrammatic())){
            queryDTO.andCondition(CampaignQuery.settingKeyValue.eq(BrandCampaignSettingKeyEnum.SSP_PROGRAMMATIC.getKey(), String.valueOf(query.getSspProgrammatic())));
        }
        if(CollectionUtils.isNotEmpty(query.getCartItemIds())){
            queryDTO.andCondition(CampaignQuery.settingKeyValue.in(BrandCampaignSettingKeyEnum.CART_ITEM_ID.getKey(), query.getCartItemIds().stream().map(String::valueOf).collect(Collectors.toList())));
        }
        if(CollectionUtils.isNotEmpty(query.getSkuIds())){
            queryDTO.andCondition(CampaignQuery.settingKeyValue.in(BrandCampaignSettingKeyEnum.SKU_ID.getKey(), query.getSkuIds().stream().map(String::valueOf).collect(Collectors.toList())));
        }
        if(CollectionUtils.isNotEmpty(query.getOnlineStatusList())){
            queryDTO.andCondition(CampaignQuery.onlineStatus.in(query.getOnlineStatusList()));
        }
        if(Objects.nonNull(query.getDoohStrategyId())){
            queryDTO.andCondition(CampaignQuery.settingKeyValue.eq(BrandCampaignSettingKeyEnum.DOOH_STRATEGY_ID.getKey(), String.valueOf(query.getDoohStrategyId())));
        }
    }

    private List<Long> mergeQueryCampaignIds(List<Long> boostQueryCampaignIds, List<Long> campaignIds) {
        if (CollectionUtils.isEmpty(boostQueryCampaignIds)) {
            return campaignIds;
        }
        if (CollectionUtils.isEmpty(campaignIds)) {
            return boostQueryCampaignIds;
        }
        boostQueryCampaignIds.retainAll(campaignIds);
        if (CollectionUtils.isNotEmpty(boostQueryCampaignIds)) {
            return boostQueryCampaignIds;
        }
        // 防止查出全部计划
        return Lists.newArrayList(-1L);
    }

    private List<Long> getApplyCampaignIdsOnCreateBoostCampaign(ServiceContext serviceContext, CampaignQueryViewDTO query) {
        SaleGroupQueryViewDTO saleGroupQueryViewDTO = new SaleGroupQueryViewDTO();
        if (Objects.nonNull(query.getCampaignGroupId())) {
            saleGroupQueryViewDTO.setCampaignGroupIds(Lists.newArrayList(query.getCampaignGroupId()));
        }
        if (Objects.nonNull(query.getSaleGroupId())) {
            saleGroupQueryViewDTO.setSaleGroupIds(Lists.newArrayList(query.getSaleGroupId()));
        }
        List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOS = campaignGroupRepository.findSaleGroupList(serviceContext, saleGroupQueryViewDTO);
        if (CollectionUtils.isEmpty(saleGroupInfoViewDTOS)) {
            return Lists.newArrayList();
        }

        SaleGroupInfoViewDTO mainSaleGroup = saleGroupInfoViewDTOS.get(0);
        if (!SaleProductLineEnum.SINGLE_MEDIA_MARKING.getValue().equals(mainSaleGroup.getSaleProductLine())
                || CollectionUtils.isEmpty(mainSaleGroup.getBoostGiveApplyInfoList())) {
            return Lists.newArrayList();
        }
        SaleGroupBoostGiveApplyInfoViewDTO boostApplyInfoViewDTO = mainSaleGroup.getBoostGiveApplyInfoList().stream()
                .filter(t -> query.getBoostSaleGroupId().equals(t.getSaleGroupId())).findFirst().orElse(null);
        if (boostApplyInfoViewDTO == null || CollectionUtils.isEmpty(boostApplyInfoViewDTO.getCampaignDetailList())) {
            return Lists.newArrayList();
        }
        return boostApplyInfoViewDTO.getCampaignDetailList().stream()
                .map(SaleGroupBoostGiveApplyCampaignDetailViewDTO::getCampaignId)
                .collect(Collectors.toList());
    }

    @Override
    public List<CampaignCrowdViewDTO> getBeforeCastingCrowd(CampaignViewDTO campaignViewDTO) {
        List<CampaignCrowdViewDTO> campaignCrowdViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignCrowdScenarioViewDTO())
                .map(CampaignCrowdScenarioViewDTO::getCampaignCrowdViewDTOList).orElse(null);
        if (CollectionUtils.isEmpty(campaignCrowdViewDTOList)) {
            return new ArrayList<>();
        }
        return campaignCrowdViewDTOList.stream()
                .filter(campaignCrowdViewDTO -> Objects.isNull(campaignCrowdViewDTO.getScene()))
                .collect(Collectors.toList());
    }

    @Override
    public List<CampaignCrowdViewDTO> getDmpBeforeCastingCrowd(List<CampaignCrowdViewDTO> campaignCrowdViewDTOList) {
        if (CollectionUtils.isEmpty(campaignCrowdViewDTOList)) {
            return new ArrayList<>();
        }
        return campaignCrowdViewDTOList.stream()
                .filter(campaignCrowdViewDTO -> BrandTargetTypeEnum.DMP_CROWD.getCode().equals(campaignCrowdViewDTO.getTargetType().intValue())
                        && Objects.isNull(campaignCrowdViewDTO.getScene()))
                .collect(Collectors.toList());
    }

    @Override
    public List<CampaignCrowdViewDTO> getDmpCastingCrowd(List<CampaignCrowdViewDTO> campaignCrowdViewDTOList) {
        if (CollectionUtils.isEmpty(campaignCrowdViewDTOList)) {
            return new ArrayList<>();
        }
        return campaignCrowdViewDTOList.stream()
                .filter(campaignCrowdViewDTO -> CampaignCrowdSceneEnum.CASTING.getCode().equals(campaignCrowdViewDTO.getScene()))
                .filter(campaignCrowdViewDTO ->
                        BrandTargetTypeEnum.DMP_CROWD.getCode().equals(campaignCrowdViewDTO.getTargetType().intValue())
                                || BrandTargetTypeEnum.RECOMMEND.getCode().equals(campaignCrowdViewDTO.getTargetType().intValue())
                                || BrandTargetTypeEnum.BLOCK_CROWD_ID.getCode().equals(campaignCrowdViewDTO.getTargetType().intValue()))
                .collect(Collectors.toList());
    }

    @Override
    public List<CampaignCrowdViewDTO> getDmpAlgoCrowd(List<CampaignCrowdViewDTO> campaignCrowdViewDTOList) {
        if (CollectionUtils.isEmpty(campaignCrowdViewDTOList)) {
            return new ArrayList<>();
        }
        return campaignCrowdViewDTOList.stream()
                .filter(campaignCrowdViewDTO -> BrandTargetTypeEnum.BRAND_ALGO_CROWD_NEW.getCode().equals(campaignCrowdViewDTO.getTargetType().intValue())
//                        || BrandTargetTypeEnum.ALGO_CONTROL_NO_TARGET_CROWD.getCode().equals(campaignCrowdViewDTO.getTargetType().intValue())
                ).collect(Collectors.toList());
    }

    @Override
    public List<CampaignCrowdViewDTO> findCrowdByType(ServiceContext serviceContext, Long campaignId, BrandTargetTypeEnum targetTypeEnum) {
        List<BindCrowdDTO> bindCrowdDTOList = campaignSAO.findBindCrowdByType(serviceContext, campaignId, targetTypeEnum);
        return crowdProcessor.dtoList2ViewDTOList(bindCrowdDTOList);
    }

    @Override
    public List<ItemViewDTO> getItemByIdList(ServiceContext serviceContext, List<Long> ids) {
        List<LabelDTO> labelDTOList = campaignSAO.getItemByIdList(serviceContext, ids);
        List<ItemViewDTO> itemViewDTOList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(labelDTOList)) {
            labelDTOList.get(0).getOptionList().forEach(labelOptionDTO -> {
                ItemViewDTO itemViewDTO = new ItemViewDTO();
                if (Objects.nonNull(labelOptionDTO.getOptionValue())) {
                    itemViewDTO.setId(Long.parseLong(labelOptionDTO.getOptionValue()));
                }
                itemViewDTO.setName(labelOptionDTO.getOptionName());
                if (Objects.nonNull(labelOptionDTO.getProperty(SettingKeyEnum._PRICE.value))) {
                    itemViewDTO.setPrice(Double.parseDouble(labelOptionDTO.getProperty(SettingKeyEnum._PRICE.value)));
                }
                itemViewDTO.setPicUrl(labelOptionDTO.getProperty(SettingKeyEnum._ITEM_PIC_URL.value));
                itemViewDTOList.add(itemViewDTO);
            });
        }
        return itemViewDTOList;
    }

    /**
     * 特秀/showmax创建黑盒人群
     * @param campaignViewDTO
     * @param campaignRealTimeOptimizeViewDTO
     * @return
     */
    @Override
    public List<CampaignCrowdViewDTO> createOptimizeCrowdList(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, CampaignRealTimeOptimizeViewDTO campaignRealTimeOptimizeViewDTO, List<Long> itemIds, List<Long> shopIds) {
        List<CampaignCrowdViewDTO> campaignCrowdViewDTOList = Lists.newArrayList();

        if (CollectionUtils.isNotEmpty(shopIds) ) {
            //相似店铺
            String shopIdStr = StringUtils.join(shopIds, ",");
            CampaignCrowdViewDTO campaignCrowdViewDTO1 = createCampaignCrowdViewDTO(BrandTargetTypeEnum.SIMILAR_SHOP, campaignRealTimeOptimizeViewDTO.getOptimizeGenderLabel(), campaignRealTimeOptimizeViewDTO.getOptimizeAgeLabels(), shopIdStr, null, null);
            campaignCrowdViewDTOList.add(campaignCrowdViewDTO1);
            //访客定向
            CampaignCrowdViewDTO campaignCrowdViewDTO4 = createCampaignCrowdViewDTO(BrandTargetTypeEnum.VISITOR, campaignRealTimeOptimizeViewDTO.getOptimizeGenderLabel(), campaignRealTimeOptimizeViewDTO.getOptimizeAgeLabels(), shopIdStr, null, null);
            campaignCrowdViewDTOList.add(campaignCrowdViewDTO4);
        }
        if (CollectionUtils.isNotEmpty(itemIds)) {
            //宝贝偏好
            String itemIdStr = StringUtils.join(itemIds, ",");
            CampaignCrowdViewDTO campaignCrowdViewDTO2 = createCampaignCrowdViewDTO(BrandTargetTypeEnum.PREFERENCE_ITEM, campaignRealTimeOptimizeViewDTO.getOptimizeGenderLabel(), campaignRealTimeOptimizeViewDTO.getOptimizeAgeLabels(), null, itemIdStr, null);
            campaignCrowdViewDTOList.add(campaignCrowdViewDTO2);
            //相似宝贝
            CampaignCrowdViewDTO campaignCrowdViewDTO3 = createCampaignCrowdViewDTO(BrandTargetTypeEnum.SIMILAR_ITEM, campaignRealTimeOptimizeViewDTO.getOptimizeGenderLabel(), campaignRealTimeOptimizeViewDTO.getOptimizeAgeLabels(), null, itemIdStr, null);
            campaignCrowdViewDTOList.add(campaignCrowdViewDTO3);
            //纯黑盒TA调控人群
            CampaignCrowdViewDTO campaignCrowdViewDTO5 = createCampaignCrowdViewDTO(BrandTargetTypeEnum.BLACK_TA_CONTROL, campaignRealTimeOptimizeViewDTO.getOptimizeGenderLabel(), campaignRealTimeOptimizeViewDTO.getOptimizeAgeLabels(), null, itemIdStr, campaignViewDTO.getId());
            campaignCrowdViewDTOList.add(campaignCrowdViewDTO5);
        }
        return campaignCrowdViewDTOList;
    }

    /**
     * 创建黑盒人群
     * @param targetTypeEnum
     * @param genderLabel
     * @param itemId
     * @return
     */
    private CampaignCrowdViewDTO createCampaignCrowdViewDTO(BrandTargetTypeEnum targetTypeEnum, Integer genderLabel, List<Integer> ageLabels, String shopId, String itemId, Long parentCampaignId) {
        CampaignCrowdViewDTO campaignCrowdViewDTO = new CampaignCrowdViewDTO();
        campaignCrowdViewDTO.setCrowdName("人群_" + targetTypeEnum.getCode() + "_" + targetTypeEnum.getLabelId() + "_" + genderLabel + "_" + System.currentTimeMillis());
        campaignCrowdViewDTO.setScene(CampaignCrowdSceneEnum.CASTING.getCode());
        campaignCrowdViewDTO.setTargetType(targetTypeEnum.getCode().longValue());

        campaignCrowdViewDTO.setGenderLabel(String.valueOf(genderLabel));
        campaignCrowdViewDTO.setAgeLabels(StringUtils.join(ageLabels, ","));
        campaignCrowdViewDTO.setLabelId(targetTypeEnum.getLabelId());
        campaignCrowdViewDTO.setItemId(itemId);
        campaignCrowdViewDTO.setShopId(shopId);
        if (Objects.nonNull(parentCampaignId)) {
            campaignCrowdViewDTO.setParentCampaignId(parentCampaignId);
        }
        return campaignCrowdViewDTO;
    }

    /**
     * 计算预定PV
     * @param mediaScope
     * @param sspProductLineId
     * @param price
     * @return
     */
    @Override
    public Long reCalCpmTotalMoney(Integer mediaScope,Integer sspProductLineId,Long amount,Long price){
        Long totalMoney = 0L;
        if(isTXorShowmaxCampaign(mediaScope,sspProductLineId)){
            totalMoney = new BigDecimal(price).multiply(new BigDecimal(amount)).divide(new BigDecimal(1000),0,BigDecimal.ROUND_DOWN).longValue();
        }else{
            totalMoney = new BigDecimal(price).multiply(new BigDecimal(amount/1000)).longValue();
        }
        return  totalMoney;
    }

    @Override
    public List<CampaignTemplateViewDTO> getCampaignTemplateIds(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList) {
        List<CampaignTemplateViewDTO> campaignTemplateViewDTOS = new ArrayList<>();
        Map<Long, List<Long>> saleGroupRightsTemplateMap = new HashMap<>();
        List<Long> resourcePackageProductIds = campaignViewDTOList.stream().map(item -> item.getCampaignSaleViewDTO().getResourcePackageProductId()).collect(Collectors.toList());
        List<Long> saleGroupIds = campaignViewDTOList.stream().map(CampaignViewDTO::getCampaignSaleViewDTO).filter(campaignSaleViewDTO ->
                Objects.nonNull(campaignSaleViewDTO.getSaleGroupId())).map(CampaignSaleViewDTO::getSaleGroupId).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(saleGroupIds)) {
            saleGroupRightsTemplateMap = findRightsTemplateIdList(serviceContext, saleGroupIds);
        }
        List<ResourcePackageProductDTO> packageProductList = resourcePackageSAO.getLevelOneResourcePackageProductList(serviceContext, resourcePackageProductIds);
        List<Long> allRightsTemplateIds = templateSAO.getRightTemplateIdList();
        if (CollectionUtils.isNotEmpty(packageProductList)) {
            Map<Long, ResourcePackageProductDTO> packageProductViewDTOMap = packageProductList.stream().collect(Collectors.toMap(ResourcePackageProductDTO::getId, Function.identity()));
            List<ResourcePackageProductDTO> commonPackageProducts = packageProductList.stream().filter(resourcePackageProductViewDTO ->
                    BrandBoolEnum.BRAND_FALSE.getCode().equals(resourcePackageProductViewDTO.getCreativeTemplateType())).collect(Collectors.toList());
            //非跨域模版场景都需要根据产品获取最新模版
            Map<Long, List<Long>> templateMap = getTemplateIdsByProduct(serviceContext, commonPackageProducts);
            Map<Long, List<Long>> directTemplateMap = getDirectTemplateIds(serviceContext, campaignViewDTOList);

            for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
                Long packageProductId = campaignViewDTO.getCampaignSaleViewDTO().getResourcePackageProductId();
                ResourcePackageProductDTO packageProductDTO = packageProductViewDTOMap.get(packageProductId);
                Long saleGroupId = campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId();
                List<Long> saleRightsTemplateIds = saleGroupRightsTemplateMap.get(saleGroupId);

                CampaignTemplateViewDTO campaignTemplateViewDTO = new CampaignTemplateViewDTO();
                campaignTemplateViewDTOS.add(campaignTemplateViewDTO);
                campaignTemplateViewDTO.setCampaignId(campaignViewDTO.getId());
                if (Objects.nonNull(campaignViewDTO.getCampaignResourceViewDTO()) && CollectionUtils.isNotEmpty(campaignViewDTO.getCampaignResourceViewDTO().getSspResourceIds())) {
                    Long resourceId = campaignViewDTO.getCampaignResourceViewDTO().getSspResourceIds().get(0);
                    campaignTemplateViewDTO.setDirectTemplateIds(directTemplateMap.getOrDefault(resourceId, Lists.newArrayList()));
                }
                //全域通选择普通模版|单媒体营销场景
                if (Objects.nonNull(packageProductDTO) && BrandBoolEnum.BRAND_FALSE.getCode().equals(packageProductDTO.getCreativeTemplateType())) {
                    Long sspProductUuid = campaignViewDTO.getCampaignResourceViewDTO().getSspProductUuid();
                    if (Objects.nonNull(sspProductUuid) && templateMap.containsKey(sspProductUuid)) {
                        campaignTemplateViewDTO.setTemplateIds(filter(templateMap.getOrDefault(sspProductUuid, Lists.newArrayList()), saleRightsTemplateIds, allRightsTemplateIds));
                    }
                    for (CampaignViewDTO subCampaignViewDTO : campaignViewDTO.getSubCampaignViewDTOList()) {
                        CampaignTemplateViewDTO subCampaignTemplateViewDTO = new CampaignTemplateViewDTO();
                        campaignTemplateViewDTOS.add(subCampaignTemplateViewDTO);
                        subCampaignTemplateViewDTO.setCampaignId(subCampaignViewDTO.getId());

                        Long subSSPProductUuid = subCampaignViewDTO.getCampaignResourceViewDTO().getSspProductUuid();
                        if (Objects.nonNull(subSSPProductUuid) && templateMap.containsKey(subSSPProductUuid)) {
                            subCampaignTemplateViewDTO.setTemplateIds(filter(templateMap.getOrDefault(subSSPProductUuid, Lists.newArrayList()), saleRightsTemplateIds, allRightsTemplateIds));
                        }

                        if (CollectionUtils.isNotEmpty(subCampaignViewDTO.getCampaignResourceViewDTO().getSspResourceIds())) {
                            Long resourceId = subCampaignViewDTO.getCampaignResourceViewDTO().getSspResourceIds().get(0);
                            subCampaignTemplateViewDTO.setDirectTemplateIds(directTemplateMap.getOrDefault(resourceId, Lists.newArrayList()));
                        }
                    }

                    //全域通选择跨域模版场景
                } else if (Objects.nonNull(packageProductDTO) && BrandBoolEnum.BRAND_TRUE.getCode().equals(packageProductDTO.getCreativeTemplateType())) {
                    Map<Long, ResourcePackageProductDTO> subPackageProductMap = packageProductDTO.getSubProductDTOList().stream().collect(Collectors.toMap(ResourcePackageProductDTO::getId, Function.identity()));
                    campaignTemplateViewDTO.setTemplateIds(filter(packageProductDTO.getSspTemplateList().stream().filter(commonDTO ->
                            StringUtils.isNotBlank(commonDTO.getValue())).map(CommonDTO::getValue).map(Long::valueOf).collect(Collectors.toList()), saleRightsTemplateIds, allRightsTemplateIds));
                    for (CampaignViewDTO subCampaignViewDTO : campaignViewDTO.getSubCampaignViewDTOList()) {
                        Long resourcePackageProductId = subCampaignViewDTO.getCampaignSaleViewDTO().getResourcePackageProductId();
                        CampaignTemplateViewDTO subCampaignTemplateViewDTO = new CampaignTemplateViewDTO();
                        campaignTemplateViewDTOS.add(subCampaignTemplateViewDTO);
                        subCampaignTemplateViewDTO.setCampaignId(subCampaignViewDTO.getId());
                        if (Objects.nonNull(resourcePackageProductId) && subPackageProductMap.containsKey(resourcePackageProductId)) {
                            subCampaignTemplateViewDTO.setTemplateIds(filter(subPackageProductMap.get(resourcePackageProductId).getSspTemplateList().stream().filter(commonDTO ->
                                    StringUtils.isNotBlank(commonDTO.getValue())).map(CommonDTO::getValue).map(Long::valueOf).collect(Collectors.toList()), saleRightsTemplateIds, allRightsTemplateIds));
                        }

                        if (CollectionUtils.isNotEmpty(subCampaignViewDTO.getCampaignResourceViewDTO().getSspResourceIds())) {
                            Long resourceId = subCampaignViewDTO.getCampaignResourceViewDTO().getSspResourceIds().get(0);
                            subCampaignTemplateViewDTO.setDirectTemplateIds(directTemplateMap.getOrDefault(resourceId, Lists.newArrayList()));
                        }
                    }
                }
            }
        }
        List<Long> grayTemplateMembers = creativeTemplateConfigDiamond.getGrayTemplateMembers();
        if (CollectionUtils.isNotEmpty(grayTemplateMembers) && grayTemplateMembers.contains(serviceContext.getMemberId())) {
            return campaignTemplateViewDTOS;
        }
        List<Long> allTemplateIds = campaignTemplateViewDTOS.stream().filter(campaignTemplateViewDTO -> CollectionUtils.isNotEmpty(campaignTemplateViewDTO.getTemplateIds()))
                .flatMap(campaignTemplateViewDTO -> campaignTemplateViewDTO.getTemplateIds().stream()).distinct().collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(allTemplateIds)) {
            CreativeTemplateQueryDTO templateQueryDTO = new CreativeTemplateQueryDTO();
            templateQueryDTO.setTemplateIdList(allTemplateIds);
            templateQueryDTO.setNeedSetting(false);
            List<NbTemplateDTO> templateList = templateSAO.getTemplateList(serviceContext, templateQueryDTO);
            List<Long> displayedTemplateIds = templateList.stream().filter(nbTemplateDTO -> !TemplateAdditionalStatusEnum.GRAY_ING.getCode().equals(nbTemplateDTO.getAdditionalStatus())).map(NbTemplateDTO::getId).collect(Collectors.toList());
            for (CampaignTemplateViewDTO campaignTemplate : campaignTemplateViewDTOS) {
                if (CollectionUtils.isNotEmpty(campaignTemplate.getTemplateIds())) {
                    campaignTemplate.setTemplateIds(campaignTemplate.getTemplateIds().stream().filter(displayedTemplateIds::contains).collect(Collectors.toList()));
                }
            }
        }
        return campaignTemplateViewDTOS;
    }

    private Map<Long, List<Long>> findRightsTemplateIdList(ServiceContext serviceContext, List<Long> saleGroupIds) {
        Map<Long, List<Long>> saleGroupRightsTemplateMap = new HashMap<>();
        ResourcePackageSaleGroupQueryDTO saleGroupQueryDTO = new ResourcePackageSaleGroupQueryDTO();
        saleGroupQueryDTO.setNeedSetting(Boolean.TRUE);
        saleGroupQueryDTO.setIdList(saleGroupIds);
        List<ResourcePackageSaleGroupDTO> saleGroupList = resourcePackageSAO.getSaleGroupList(serviceContext, saleGroupQueryDTO);
        if (CollectionUtils.isNotEmpty(saleGroupList)) {
            ResourcePackageTemplateQueryDTO queryDTO = ResourcePackageTemplateQueryDTO.builder().idList(Lists.newArrayList(saleGroupList.stream().map(ResourcePackageSaleGroupDTO::getTemplateId).collect(Collectors.toList())))
                    .needPage(false).needCountAndAmount(false).needResourcePackageProduct(false).needResourcePackageSaleGroup(false)
                    .build();
            List<ResourcePackageTemplateDTO> resourcePackageTemplateDTOS = resourcePackageSAO.findTemplateList(serviceContext, queryDTO);
            if (CollectionUtils.isNotEmpty(resourcePackageTemplateDTOS)) {
                for (ResourcePackageTemplateDTO resourcePackageTemplateDTO : resourcePackageTemplateDTOS) {
                    if (CollectionUtils.isNotEmpty(resourcePackageTemplateDTO.getRightsTemplateIdList()) && CollectionUtils.isNotEmpty(resourcePackageTemplateDTO.getSaleGroupIdList())) {
                        //移除客户模版中包含的权益模版
                        for (Long saleGroupId : resourcePackageTemplateDTO.getSaleGroupIdList()){
                            saleGroupRightsTemplateMap.put(saleGroupId, resourcePackageTemplateDTO.getRightsTemplateIdList());
                        }
                    }
                }
            }
        }
        return saleGroupRightsTemplateMap;
    }

    private List<Long> filter(List<Long> templateIds, List<Long> saleRightsTemplateIds, List<Long> allRightsTemplateIds) {
        List<Long> rightsTemplateIdList = Lists.newArrayList(allRightsTemplateIds);
        if (CollectionUtils.isNotEmpty(templateIds) && CollectionUtils.isNotEmpty(rightsTemplateIdList)) {
            //获取列表中包含的权益模板
            rightsTemplateIdList.retainAll(templateIds);
            if (CollectionUtils.isNotEmpty(rightsTemplateIdList)) {
                if (CollectionUtils.isNotEmpty(saleRightsTemplateIds)) {
                    //移除客户模版中包含的权益模版
                    rightsTemplateIdList.removeAll(saleRightsTemplateIds);
                }
                //rightsTemplateIdList 如果还有元素,则说明客户模版中不包含该权益模版, 需要剔除
                rightsTemplateIdList.forEach(templateIds::remove);
                if (CollectionUtils.isEmpty(templateIds)) {
                    //避免影响, 添加一个无效的模版id
                    templateIds.add(-1L);
                }
            }
        }
        return templateIds;
    }

    private Map<Long, List<Long>> getDirectTemplateIds(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList) {
        Map<Long, List<Long>> resourceTemplateMap = new HashMap<>();
        HashSet<Long> resourceIds = new HashSet<>();
        for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
            if (Objects.nonNull(campaignViewDTO.getCampaignResourceViewDTO()) &&
                    CollectionUtils.isNotEmpty(campaignViewDTO.getCampaignResourceViewDTO().getSspResourceIds())) {
                resourceIds.addAll(campaignViewDTO.getCampaignResourceViewDTO().getSspResourceIds());
            }
            if(CollectionUtils.isEmpty(campaignViewDTO.getSubCampaignViewDTOList())){
                continue;
            }
            for (CampaignViewDTO subCampaignViewDTO : campaignViewDTO.getSubCampaignViewDTOList()) {
                if (Objects.nonNull(subCampaignViewDTO.getCampaignResourceViewDTO()) &&
                        CollectionUtils.isNotEmpty(subCampaignViewDTO.getCampaignResourceViewDTO().getSspResourceIds())) {
                    resourceIds.addAll(subCampaignViewDTO.getCampaignResourceViewDTO().getSspResourceIds());
                }
            }
        }
        if(CollectionUtils.isEmpty(resourceIds)){
            return resourceTemplateMap;
        }
        List<MediaResourceViewDTO> mediaResourceViewDTOS = resourceRepository.getResourceList(resourceIds.stream().collect(Collectors.toList()));
        if (CollectionUtils.isNotEmpty(mediaResourceViewDTOS)) {
            List<Long> ruleIds = mediaResourceViewDTOS.stream().filter(item ->
                    StringUtils.isNotBlank(item.getMaterialRuleIds())).flatMap(item ->
                    Arrays.stream(item.getMaterialRuleIds().split(Constant.CHAR_SPLIT_KEY_DOT)).map(Long::valueOf)).distinct().collect(Collectors.toList());
            Map<Long, MaterialRuleViewDTO> materialRuleViewDTOMap = materialRuleRepository.getMaterialRuleList(serviceContext, ruleIds).stream().collect(Collectors.toMap(MaterialRuleViewDTO::getId, Function.identity()));

            for (MediaResourceViewDTO mediaResourceViewDTO : mediaResourceViewDTOS) {
                List<Long> directTemplateIds = new ArrayList<>();
                if (StringUtils.isNotBlank(mediaResourceViewDTO.getMaterialRuleIds())) {
                    for (String str : mediaResourceViewDTO.getMaterialRuleIds().split(Constant.CHAR_SPLIT_KEY_DOT)) {
                        Long materialRuleId = Long.valueOf(str);
                        if (materialRuleViewDTOMap.containsKey(materialRuleId)) {
                            MaterialRuleViewDTO materialRuleViewDTO = materialRuleViewDTOMap.get(materialRuleId);
                            if (CollectionUtils.isNotEmpty(materialRuleViewDTO.getTemplateList())) {
                                directTemplateIds.addAll(materialRuleViewDTO.getTemplateList().stream().filter(templateViewDTO ->
                                                Optional.ofNullable(templateViewDTO.getIsAccurate()).
                                                        orElse(TemplateAccurateEnum.TEMPLATE_YES_ACCURATE_ENUM.getValue()).
                                                        equals(TemplateAccurateEnum.TEMPLATE_NON_ACCURATE_ENUM.getValue())).
                                        map(TemplateViewDTO::getId).collect(Collectors.toList()));
                            }
                        }
                    }
                    resourceTemplateMap.put(mediaResourceViewDTO.getId(), directTemplateIds.stream().distinct().collect(Collectors.toList()));
                }
            }
        }
        return resourceTemplateMap;
    }

    private Map<Long, List<Long>> getTemplateIdsByProduct(ServiceContext serviceContext, List<ResourcePackageProductDTO> packageProductList) {
        Map<Long, List<Long>> templateMap = new HashMap<>();
        if(CollectionUtils.isEmpty(packageProductList)){
            return templateMap;
        }
        Set<Long> productUuids = new HashSet<>();
        for (ResourcePackageProductDTO resourcePackageProductDTO : packageProductList) {
            if (Objects.nonNull(resourcePackageProductDTO.getSspProductUuid()) && !MediaScopeEnum.CROSS_SCOPE.getCode().equals(resourcePackageProductDTO.getMediaScope())) {
                productUuids.add(resourcePackageProductDTO.getSspProductUuid());
            }
            if (CollectionUtils.isNotEmpty(resourcePackageProductDTO.getSubProductDTOList())) {
                productUuids.addAll(resourcePackageProductDTO.getSubProductDTOList().stream().filter(subResourcePackageProductDTO ->
                        Objects.nonNull(subResourcePackageProductDTO.getSspProductUuid())).map(subResourcePackageProductDTO ->
                        subResourcePackageProductDTO.getSspProductUuid()).collect(Collectors.toList()));
            }
        }
        if (CollectionUtils.isNotEmpty(productUuids)) {
            List<ProductDTO> productDTOS = productSAO.getProductByUuid(productUuids.stream().collect(Collectors.toList()));
            if (CollectionUtils.isNotEmpty(productDTOS)) {
                templateMap = productDTOS.stream().filter(productDTO -> CollectionUtils.isNotEmpty(productDTO.getTemplateIdList())).collect(Collectors.toMap(ProductDTO::getUuid, ProductDTO::getTemplateIdList));
            }
        }
        return templateMap;
    }
}
