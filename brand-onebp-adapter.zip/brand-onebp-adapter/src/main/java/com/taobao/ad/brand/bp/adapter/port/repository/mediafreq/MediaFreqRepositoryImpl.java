package com.taobao.ad.brand.bp.adapter.port.repository.mediafreq;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.media.freq.MediaFreqViewDTO;
import com.alibaba.ad.brand.sdk.convert.custom.viewdto.media.MediaFreqViewDTO2DTOConvertProcessor;
import com.alibaba.ad.organizer.dto.media.MediaFrequencyDTO;
import com.alibaba.ad.universal.sdk.convert.custom.onebp.provider.OneBpConvertProcessorProvider;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.mediafreq.MediaFreqSAO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.mediafreq.query.MediaFreqQueryViewDTO;
import com.taobao.ad.brand.bp.domain.mediafreq.MediaFreqRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Objects;

/**
 * 媒体频控
 * @author shiyan
 * @date 2023/3/21 09:48
 */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class MediaFreqRepositoryImpl implements MediaFreqRepository {
    private final MediaFreqSAO mediaFreqSAO;
    private MediaFreqViewDTO2DTOConvertProcessor PROCESSOR = OneBpConvertProcessorProvider.getViewDTO2DTOConvertProcessor(MediaFreqViewDTO2DTOConvertProcessor.class);
    @Override
    public Long addMediaFreq(ServiceContext serviceContext, MediaFreqViewDTO viewDTO) {
        MediaFrequencyDTO frequencyDTO = PROCESSOR.viewDTO2DTO(viewDTO);
        return mediaFreqSAO.addMediaFreq(serviceContext,frequencyDTO);
    }

    @Override
    public Integer updateMediaFreq(ServiceContext serviceContext, MediaFreqViewDTO viewDTO) {
        MediaFrequencyDTO frequencyDTO = PROCESSOR.viewDTO2DTO(viewDTO);
        return mediaFreqSAO.updateMediaFreq(serviceContext,frequencyDTO);
    }

    @Override
    public Integer updateMediaFreqStatus(ServiceContext serviceContext, List<Long> ids, Integer status) {
        return mediaFreqSAO.updateMediaFreqStatus(serviceContext,ids,status);
    }

    @Override
    public MediaFreqViewDTO getMediaFreq(ServiceContext serviceContext, Long id) {
        MediaFrequencyDTO mediaFreqDTO = mediaFreqSAO.getMediaFreq(serviceContext, id);
        if(mediaFreqDTO == null){
            return null;
        }
        MediaFreqViewDTO mediaFreqViewDTO = PROCESSOR.dto2ViewDTO(mediaFreqDTO);
        return mediaFreqViewDTO;
    }

    @Override
    public PageResultViewDTO<MediaFreqViewDTO> findListWithPage(ServiceContext serviceContext, MediaFreqQueryViewDTO queryViewDTO) {
        PageResultViewDTO<MediaFrequencyDTO> listWithPage = mediaFreqSAO.findListWithPage(serviceContext, queryViewDTO);
        List<MediaFreqViewDTO> resultList = PROCESSOR.dtoList2ViewDTOList(listWithPage.getList());
        return PageResultViewDTO.of(resultList, listWithPage.getCount());
    }

    @Override
    public List<MediaFreqViewDTO> findList(ServiceContext serviceContext, MediaFreqQueryViewDTO queryViewDTO) {
        List<MediaFrequencyDTO> dataList = mediaFreqSAO.findList(serviceContext, queryViewDTO);
        return PROCESSOR.dtoList2ViewDTOList(dataList);
    }

    @Override
    public MediaFreqViewDTO getTopOneByName(ServiceContext serviceContext, String uniqueName) {
        MediaFrequencyDTO mediaFrequencyDTO = mediaFreqSAO.getTopOneByName(serviceContext, uniqueName);
        return Objects.nonNull(mediaFrequencyDTO) ? PROCESSOR.dto2ViewDTO(mediaFrequencyDTO) : null;
    }
}
