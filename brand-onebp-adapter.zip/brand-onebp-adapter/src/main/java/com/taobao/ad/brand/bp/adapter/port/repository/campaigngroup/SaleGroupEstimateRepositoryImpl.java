package com.taobao.ad.brand.bp.adapter.port.repository.campaigngroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaigngroup.sale.ConfidenceInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.salegroup.field.SaleGroupEstimateTypeEnum;
import com.alibaba.ad.nb.ssp.constant.newproduct.DeliveryTargetEnum;
import com.alimama.faas.brand.engine.entity.constant.BizType;
import com.alimama.faas.brand.engine.entity.constant.KeywordPackageType;
import com.alimama.faas.brand.engine.entity.constant.ServiceCodeEnum;
import com.alimama.faas.brand.engine.entity.constant.TargetType;
import com.alimama.faas.brand.engine.entity.domain.CampaignConfig;
import com.alimama.faas.brand.engine.entity.domain.PidInfo;
import com.alimama.faas.brand.engine.entity.domain.ResourceConfig;
import com.alimama.faas.brand.engine.entity.domain.SceneType;
import com.alimama.faas.brand.engine.entity.domain.TargetConfig;
import com.alimama.faas.brand.engine.entity.domain.TargetResult;
import com.alimama.faas.brand.engine.entity.request.EstimateRequest;
import com.alimama.faas.brand.engine.entity.request.SuperEstimateRequest;
import com.alimama.faas.brand.engine.entity.response.EstimateResponse;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.dmpargus.DmpArgusSAO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignEstimateResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupEstimateInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupEstimateResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignSaleGroupDeliveryTargetViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.DmpArgusEstimateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.SaleGroupBaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.SaleGroupProductCampaignViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.SaleGroupProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.AdzoneViewDTO;
import com.taobao.ad.brand.bp.client.enums.EstimateDimensionTypeEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.SaleGroupEstimateRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * 分组预估相关实现
 * @author yiyun.myh@taobao.com
 * @date 2023年07月25日
 * */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SaleGroupEstimateRepositoryImpl implements SaleGroupEstimateRepository {

    private final DmpArgusSAO dmpArgusSAO;

    /**
     * 这里是算法预估的数据
     * */
    @Override
    public CampaignGroupSaleGroupEstimateInfoViewDTO estimateSaleGroup(ServiceContext serviceContext, DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO) {
        // 参数转换
        EstimateRequest estimateRequest = initEstimateRequest(dmpArgusEstimateViewDTO);
        EstimateResponse estimateResponse = dmpArgusSAO.estimateSaleGroup(serviceContext, dmpArgusEstimateViewDTO.getServiceCode(), estimateRequest);
        if (CollectionUtils.isNotEmpty(estimateResponse.getDeliverTarget())) {
            List<TargetResult> nReachList = estimateResponse.getDeliverTarget().stream()
                    .filter(item -> TargetType.N_REACH.equals(item.getTargetId()) || item.getTargetTypeId() != null && item.getTargetTypeId() == TargetType.N_REACH.getId()).collect(Collectors.toList());
            if (CollectionUtils.isNotEmpty(nReachList)) {
                TargetResult nReach = nReachList.get(0);
                AssertUtil.assertTrue(nReach.getEstimateMin() >= 50L, BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR.of("N+reach比例过低，请扩充人群或者资源或增加投放时间"));
            }
        }
        //构建返回信息
        return buildSaleGroupEstimateResultViewDTO(estimateResponse, dmpArgusEstimateViewDTO);
    }

    /**
     * 构建B端引擎查询参数
     * */
    @NotNull
    private EstimateRequest initEstimateRequest(DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO){
        EstimateRequest estimateRequest = ServiceCodeEnum.BrandOneBpEngineSuper.name().equals(dmpArgusEstimateViewDTO.getServiceCode()) ? new SuperEstimateRequest() : new EstimateRequest();
        if (dmpArgusEstimateViewDTO.getEstimateType().equals(SaleGroupEstimateTypeEnum.EFFECT_ESTIMATE.getCode())) {
            estimateRequest.setBizType(BizType.EFFECT_ESTIMATE);
        }else{
            estimateRequest.setBizType(BizType.DELIVER_ESTIMATE);
        }
        // 预估类型 1 == 分组粒度（默认） 2 == 一级计划粒度 3 == 二级计划粒度
        estimateRequest.setEstimateDimensionType(dmpArgusEstimateViewDTO.getEstimateDimensionType());
        // 基本信息
        SaleGroupBaseViewDTO campaignGroupSaleGroupViewDTO = dmpArgusEstimateViewDTO.getSaleGroupBaseViewDTO();
        estimateRequest.setSaleGroupId(campaignGroupSaleGroupViewDTO.getSaleGroupId());
        estimateRequest.setSaleGroupBudget(campaignGroupSaleGroupViewDTO.getBudget());
        estimateRequest.setSaleGroupStartTime(campaignGroupSaleGroupViewDTO.getStartTime());
        estimateRequest.setSaleGroupEndTime(campaignGroupSaleGroupViewDTO.getEndTime());
        // 分组曝光量
        estimateRequest.setSaleGroupAmount(campaignGroupSaleGroupViewDTO.getAmount());
        estimateRequest.setMemberId(dmpArgusEstimateViewDTO.getMemberId());
        estimateRequest.setCrowdList(campaignGroupSaleGroupViewDTO.getCrowdIdList());
        estimateRequest.setShopId(dmpArgusEstimateViewDTO.getShopId());
        estimateRequest.setSaleType(campaignGroupSaleGroupViewDTO.getSaleType());
        estimateRequest.setSaleProductLine(dmpArgusEstimateViewDTO.getSaleGroupBaseViewDTO().getSaleProductLine());
        estimateRequest.setSceneType(getSceneType(dmpArgusEstimateViewDTO.getSaleGroupBaseViewDTO().getSaleBusinessLine()));
        // 高级分组类型 智选：1 (INTELLIGENT_SELECTION) 标准：2 (STANDARD)
        estimateRequest.setProductConfigType(campaignGroupSaleGroupViewDTO.getProductConfigType());
        // 是否推荐投放周期
        estimateRequest.setOptimizeSaleCycle(dmpArgusEstimateViewDTO.getOptimizeSaleCycle());

        // 交付目标
        estimateRequest.setDeliverTargetList(buildDeliverTargetList(campaignGroupSaleGroupViewDTO.getDeliveryTargetList()));
        // 优化目标（不再使用）
        estimateRequest.setOptimizeTargetList(buildOptimizeTargetList(campaignGroupSaleGroupViewDTO.getOptimizeTargetList()));

        // 资源，计划，pid信息
        estimateRequest.setResourcePackageConfigList(buildResourceConfigList(campaignGroupSaleGroupViewDTO.getSaleGroupProductViewDTOList()));
        return estimateRequest;
    }

    private static SceneType getSceneType(Integer saleBusinessLine) {
        if (saleBusinessLine == null) {
            return null;
        }
        return SceneType.find(saleBusinessLine);
    }

    /**
     * 构建交付指标
     * 过滤掉曝光
     * */
    private List<TargetConfig> buildDeliverTargetList(List<CampaignSaleGroupDeliveryTargetViewDTO> saleGroupDeliveryTargetViewDTOList){

        return Optional.ofNullable(saleGroupDeliveryTargetViewDTOList).orElse(Lists.newArrayList()).stream().filter(item->!item.getDeliveryTarget().equals(DeliveryTargetEnum.EXPOSURE.getValue())).map(item->{
            TargetConfig targetConfig = new TargetConfig();
//            targetConfig.setTargetId(TargetType.getByValue(item.getDeliveryTarget()));
            targetConfig.setTargetTypeId(item.getDeliveryTarget());
            if (item.getDeliveryTarget().equals(DeliveryTargetEnum.N_REACH.getValue())){
                targetConfig.setTargetValue(item.getDeliveryTargetValue().longValue());
            }else{
                //给资源包的值
                if (item.getResourceDeliveryTargetValue() != null) {
                    targetConfig.setTargetValue(item.getResourceDeliveryTargetValue().longValue());
                }
            }
            return targetConfig;

        }).collect(Collectors.toList());
    }

    /**
     * 构建优化指标
     * 2023年09月18日 与B端引擎确认， 暂时不传。
     * */
    private List<TargetConfig> buildOptimizeTargetList(List<Integer> optimizeTargetIdList) {
        return Lists.newArrayList();
    }

    private List<ResourceConfig> buildResourceConfigList(List<SaleGroupProductViewDTO> saleGroupProductViewDTOList) {
        if (CollectionUtils.isNotEmpty(saleGroupProductViewDTOList)) {
            return saleGroupProductViewDTOList.stream().map(item -> {
                ResourceConfig resourceConfig = new ResourceConfig();
                resourceConfig.setAmount(item.getAmount());
                resourceConfig.setBudget(item.getBudget());
                resourceConfig.setResourceProductId(item.getResourceProductId());
                resourceConfig.setCastType(item.getCastType());
                resourceConfig.setMediaScope(item.getMediaScope());
                resourceConfig.setPromiseClick(item.getPromiseClick());
                resourceConfig.setResourceStartTime(item.getResourceStartTime());
                resourceConfig.setResourceEndTime(item.getResourceEndTime());
                resourceConfig.setSaleUnit(item.getSaleUnit());
                resourceConfig.setSspProductId(item.getSspProductId());
                resourceConfig.setSspProductUuid(item.getSspProductUuid());
                resourceConfig.setSspResourceTypes(item.getSspResourceTypes());
                resourceConfig.setClickRate(item.getClickRate());
                // pid
                resourceConfig.setPidList(buildPidInfoList(item.getAdzoneViewDTOList()));
                // 计划信息
                resourceConfig.setCampaignConfig(buildCampaignConfig(item.getCampaignViewDTOList()));
                return resourceConfig;
            }).collect(Collectors.toList());

        }
        return Lists.newArrayList();
    }

    /**
     * buildPidInfo
     * */
    private List<CampaignConfig> buildCampaignConfig(List<SaleGroupProductCampaignViewDTO> campaignViewDTOList){
        return Optional.ofNullable(campaignViewDTOList).orElse(Lists.newArrayList()).stream().map(item->{
            CampaignConfig campaignConfig = new CampaignConfig();
            campaignConfig.setCampaignId(item.getCampaignId());
            campaignConfig.setAmount(item.getAmount());
            campaignConfig.setCampaignLevel(item.getCampaignLevel());
            campaignConfig.setPidList(buildPidInfoList(item.getAdzoneViewDTOList()));
            campaignConfig.setCrowdList(item.getCrowdList());
            campaignConfig.setEndTime(item.getEndTime());
            campaignConfig.setStartTime(item.getStartTime());
            campaignConfig.setShowMaxCrowdType(item.getShowMaxCrowdType());
            campaignConfig.setShowMaxCrowdTypeValueList(item.getShowMaxCrowdTypeValueList());
            campaignConfig.setAlgoBizType(item.getAlgoBizType());
            campaignConfig.setDoohCampaignId(item.getDoohCampaignId());
            campaignConfig.setKeyWordPackageId(item.getWordPackageId());
            campaignConfig.setBrandId(item.getBrandId());
            if(item.getWordPackageType() != null){
                campaignConfig.setKeyWordPackageType(KeywordPackageType.getByValue(item.getWordPackageType()));
            }
            // 二级计划
            if (CollectionUtils.isNotEmpty(item.getSubCampaignList())){
                campaignConfig.setSubCampaignList(buildCampaignConfig(item.getSubCampaignList()));
            }
            return campaignConfig;
        }).collect(Collectors.toList());
    }

    /**
     * buildPidInfo
     */
    public List<PidInfo> buildPidInfoList(List<AdzoneViewDTO> adzoneViewDTOList) {
        return Optional.ofNullable(adzoneViewDTOList).orElse(Lists.newArrayList()).stream().map(item -> {
            PidInfo pidInfo = new PidInfo();
            pidInfo.setPid(item.getPid());
            pidInfo.setMediaScope(item.getMediaScope());
            pidInfo.setResourceType(item.getResourceType());
            return pidInfo;
        }).collect(Collectors.toList());
    }

    private CampaignGroupSaleGroupEstimateInfoViewDTO buildSaleGroupEstimateResultViewDTO(EstimateResponse estimateResponse, DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO){
        CampaignGroupSaleGroupEstimateInfoViewDTO saleGroupEstimateInfoViewDTO = new CampaignGroupSaleGroupEstimateInfoViewDTO();
        saleGroupEstimateInfoViewDTO.setEstimateTime(estimateResponse.getEstimateTime());
        saleGroupEstimateInfoViewDTO.setEstimateType(dmpArgusEstimateViewDTO.getEstimateType());
        saleGroupEstimateInfoViewDTO.setSaleGroupId(dmpArgusEstimateViewDTO.getSaleGroupBaseViewDTO().getSaleGroupId());

        if (EstimateDimensionTypeEnum.CAMPAIGN.getValue().equals(dmpArgusEstimateViewDTO.getEstimateDimensionType())) {
            List<CampaignEstimateResultViewDTO> campaignEstimateResultList = new ArrayList<>();
            //一级计划粒度
            for (Map.Entry<Long, List<TargetResult>> entry: estimateResponse.getCampaignDeliverTarget().entrySet()) {
                CampaignEstimateResultViewDTO campaignEstimateResultViewDTO = new CampaignEstimateResultViewDTO();
                campaignEstimateResultViewDTO.setCampaignId(entry.getKey());
                //计划只有ctr预估
                List<TargetResult> targetResults = entry.getValue().stream()
                        .filter(e -> e.getTargetTypeId() != null && e.getTargetTypeId() == TargetType.CLICK_RATIO.getId() || TargetType.CLICK_RATIO.equals(e.getTargetId()))
                        .collect(Collectors.toList());
                if (CollectionUtils.isNotEmpty(targetResults)) {
                    //ctr预估值
                    TargetResult targetResult = targetResults.get(0);
                    campaignEstimateResultViewDTO.setMax(targetResult.getEstimateMax());
                    campaignEstimateResultViewDTO.setMin(targetResult.getEstimateMin());
                    if (targetResult.getConfidenceInfo() != null) {
                        ConfidenceInfoViewDTO confidenceInfoViewDTO = new ConfidenceInfoViewDTO();
                        confidenceInfoViewDTO.setConfidenceValue(targetResult.getConfidenceInfo().getConfidenceValue());
                        confidenceInfoViewDTO.setConfidence(targetResult.getConfidenceInfo().getConfidence());
                        campaignEstimateResultViewDTO.setConfidenceInfoViewDTO(confidenceInfoViewDTO);
                    }
                    //推荐周期
                    if (Objects.nonNull(estimateResponse.getOptimizeProposeCycle()) && Objects.nonNull(estimateResponse.getOptimizeProposeCycle().get(entry.getKey()))) {
                        campaignEstimateResultViewDTO.setStartDate(estimateResponse.getOptimizeProposeCycle().get(entry.getKey()).getStartDate());
                        campaignEstimateResultViewDTO.setEndDate(estimateResponse.getOptimizeProposeCycle().get(entry.getKey()).getEndDate());
                    }
                    campaignEstimateResultList.add(campaignEstimateResultViewDTO);
                }
            }
            saleGroupEstimateInfoViewDTO.setCampaignEstimateResultList(campaignEstimateResultList);
        } else {
            //分组粒度
            List<CampaignGroupSaleGroupEstimateResultViewDTO> campaignGroupSaleGroupEstimateResultViewDTOList = estimateResponse.getDeliverTarget().stream().map(item -> {
                CampaignGroupSaleGroupEstimateResultViewDTO campaignGroupSaleGroupEstimateResultViewDTO = new CampaignGroupSaleGroupEstimateResultViewDTO();
                campaignGroupSaleGroupEstimateResultViewDTO.setMax(item.getEstimateMax());
                campaignGroupSaleGroupEstimateResultViewDTO.setMin(item.getEstimateMin());
                campaignGroupSaleGroupEstimateResultViewDTO.setDeliveryTarget(item.getTargetTypeId());
//                campaignGroupSaleGroupEstimateResultViewDTO.setDeliveryTarget(item.getTargetId().getId());
                if (item.getConfidenceInfo() != null) {
                    ConfidenceInfoViewDTO confidenceInfoViewDTO = new ConfidenceInfoViewDTO();
                    confidenceInfoViewDTO.setConfidenceValue(item.getConfidenceInfo().getConfidenceValue());
                    confidenceInfoViewDTO.setConfidence(item.getConfidenceInfo().getConfidence());
                    campaignGroupSaleGroupEstimateResultViewDTO.setConfidenceInfoViewDTO(confidenceInfoViewDTO);
                }
                return campaignGroupSaleGroupEstimateResultViewDTO;

            }).collect(Collectors.toList());
            saleGroupEstimateInfoViewDTO.setEstimateResult(campaignGroupSaleGroupEstimateResultViewDTOList);
        }
        return saleGroupEstimateInfoViewDTO;
    }

}
