package com.taobao.ad.brand.bp.adapter.port.repository.aigc;

import com.alibaba.aladdin.lamp.domain.response.GeneralItem;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.agi.GenerateImagesTemplateSAO;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.lamp.AladdinLampSAO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.domain.aigc.GenerateImagesRepository;
import com.taobao.eagleeye.EagleEye;
import com.taobao.eagleeye.EagleEyeRequestTracer;
import com.taobao.vipserver.client.core.Host;
import com.taobao.vipserver.client.core.VIPClient;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.*;
import java.util.zip.GZIPInputStream;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.IMAGE_GENERATE_ERROR;
import static com.taobao.ad.brand.bp.common.constant.Constant.DEFAULT_CHARSET;
import static com.taobao.ad.brand.bp.common.constant.GenerateImageConstant.CREATIVES;
import static com.taobao.ad.brand.bp.common.constant.GenerateImageConstant.CREATIVE_URL;

/**
 * @Author: PhilipFry
 * @createTime: 2025年01月09日 21:49:33
 * @Description:
 */

@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class GenerateImagesRepositoryImpl implements GenerateImagesRepository {
    private final GenerateImagesTemplateSAO generateImagesTemplateSAO;
    private final AladdinLampSAO aladdinLampSAO;
    private static final String UPLOAD_TALENT_WORK_CONFIG = "http://alimama-fund-base-cv-ddm-live.vipserver/generate_aigc_creatives";

    @Override
    public Object getMagicTemplate(Long itemId, Integer width, Integer height) {
        return generateImagesTemplateSAO.getTemplate(itemId, width, height);
    }

    @Override
    public GeneralItem getItem(Long itemId) {
        return aladdinLampSAO.getGeneralItem(itemId);
    }

    @Override
    public List<String> creativeImage(HashMap<String, String> params) {
        List<String> images = new ArrayList<>();
        CloseableHttpClient aDefault = HttpClients.createDefault();
        HttpResult httpResult = doGet(UPLOAD_TALENT_WORK_CONFIG, params, new HashMap<>(), DEFAULT_CHARSET, true, aDefault);
        try {
            aDefault.close();
        } catch (IOException e) {
            throw new BrandOneBPException(IMAGE_GENERATE_ERROR, "生图失败");
        }
        String result = httpResult.getResult();
        JSONObject jsonObject = JSONObject.parseObject(result);
        JSONArray creatives = jsonObject.getJSONArray(CREATIVES);
        if (Objects.nonNull(creatives)) {
            for (int i = 0; i < creatives.size(); i++) {
                // 将每个元素转换为JSONObject
                JSONObject creativeJsonObject = creatives.getJSONObject(i);
                if (Objects.nonNull(creativeJsonObject.get(CREATIVE_URL))) {
                    images.add(creativeJsonObject.get(CREATIVE_URL).toString());
                }
            }
        }
        return images;
    }

    /**
     * 发起get请求
     *
     * @param url         请求的url地址
     * @param params      请求参数
     * @param cookies     请求cookie
     * @param charsetName 响应数据的编码
     * @param isVipServer 是否是vipserver地址
     * @return
     */
    private HttpResult doGet(String url, Map<String, String> params, Map<String, String> cookies, String charsetName,
                             boolean isVipServer, CloseableHttpClient client) {
        HttpResult httpResult = new HttpResult();

        URI uri = null;
        try {
            // check charset
            Charset.forName(charsetName);
            //build url

            URL tmpURL = new URL(url);
            URIBuilder uriBuilder = new URIBuilder();
            uriBuilder.setScheme(tmpURL.getProtocol());
            if (isVipServer) {
                Host thisHost = VIPClient.srvHost(tmpURL.getHost());
                uriBuilder.setHost(thisHost.getIp());
                uriBuilder.setPort(thisHost.getPort());
            } else {
                uriBuilder.setHost(tmpURL.getHost());
                int port = tmpURL.getPort();
                if (port != -1) {
                    uriBuilder.setPort(port);
                }
            }
            uriBuilder.setPath(tmpURL.getPath());
            if (params != null && params.size() > 0) {
                for (Map.Entry<String, String> entry : params.entrySet()) {
                    uriBuilder.addParameter(entry.getKey(), entry.getValue());
                }
            }
            uri = uriBuilder.build();
        } catch (Exception e) {
            httpResult.setSuccess(false);
            httpResult.setE(e);
            return httpResult;
        }

        HttpUriRequest httpUriRequest = new HttpGet(uri);
        if (cookies != null && cookies.size() > 0) {
            StringBuilder sb = new StringBuilder();
            for (Map.Entry<String, String> entry : cookies.entrySet()) {
                sb.append(entry.getKey()).append("=").append(entry.getValue()).append("; ");
            }
            sb.deleteCharAt(sb.length() - 1);
            sb.deleteCharAt(sb.length() - 1);
            httpUriRequest.addHeader("Cookie", sb.toString());
        }
        EagleEye.startRpc(httpUriRequest.getMethod(), uri.toString());
        String resultCode = EagleEye.RPC_RESULT_FAILED;
        try {
            long start = System.currentTimeMillis();
            httpUriRequest.addHeader(EagleEyeRequestTracer.EAGLEEYE_TRACEID_HEADER_KEY, EagleEye.getTraceId());
            httpUriRequest.addHeader(EagleEyeRequestTracer.EAGLEEYE_RPCID_HEADER_KEY, EagleEye.getRpcId());

            String result = client.execute(httpUriRequest, getResponseHandler(charsetName));
            httpResult.setSuccess(true);
            httpResult.setResult(result);
            httpResult.setUrl(uri.toString());
            httpResult.setElapsedTime(System.currentTimeMillis() - start);
            resultCode = "200";
            return httpResult;
        } catch (IOException e) {
            httpResult.setSuccess(false);
            httpResult.setUrl(uri.toString());
            httpResult.setE(e);
            return httpResult;
        } finally {
            EagleEye.rpcClientRecv(resultCode, EagleEye.TYPE_HTTP_CLIENT);
        }
    }

    private ResponseHandler<String> getResponseHandler(final String charset) {
        ResponseHandler<String> responseHandler = response -> {
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode != 200) {
                throw new IOException("Http server response status code is " + statusCode);
            }
            HttpEntity entity = response.getEntity();
            if (entity == null) {
                throw new IOException("Http server response none");
            }
            if (entity.getContentEncoding() != null
                    && StringUtils.isNotBlank(entity.getContentEncoding().getValue())
                    && entity.getContentEncoding().getValue().toLowerCase().contains("gzip")) {
                InputStream is = entity.getContent();
                GZIPInputStream gzin = new GZIPInputStream(is);
                InputStreamReader isr = new InputStreamReader(gzin, charset);
                try {
                    StringBuffer sb = new StringBuffer();
                    final char[] tmp = new char[1024];
                    int l;
                    while ((l = isr.read(tmp)) != -1) {
                        sb.append(tmp, 0, l);
                    }
                    return sb.toString();
                } finally {
                    isr.close();
                    gzin.close();
                }
            } else {
                String result = EntityUtils.toString(entity, charset);
                return result;
            }
        };
        return responseHandler;
    }

    public class HttpResult {

        private boolean isSuccess;
        private String result;
        private Exception e;
        private long elapsedTime;
        private String url;

        /**
         * 是否成功
         *
         * @return
         */
        public boolean isSuccess() {
            return isSuccess;
        }

        public void setSuccess(boolean success) {
            isSuccess = success;
        }

        /**
         * 结果数据
         *
         * @return
         */
        public String getResult() {
            return result;
        }

        public void setResult(String result) {
            this.result = result;
        }

        /**
         * 异常对象
         *
         * @return
         */
        public Exception getE() {
            return e;
        }

        public void setE(Exception e) {
            this.e = e;
        }

        /**
         * 耗时   毫秒
         *
         * @return
         */
        public long getElapsedTime() {
            return elapsedTime;
        }

        public void setElapsedTime(long elapsedTime) {
            this.elapsedTime = elapsedTime;
        }

        /**
         * 请求串
         *
         * @return
         */
        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }
    }
}
