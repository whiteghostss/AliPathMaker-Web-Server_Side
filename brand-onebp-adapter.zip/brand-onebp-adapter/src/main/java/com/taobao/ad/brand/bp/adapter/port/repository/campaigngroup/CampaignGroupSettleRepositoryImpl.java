package com.taobao.ad.brand.bp.adapter.port.repository.campaigngroup;

import java.util.List;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.settle.billing.api.dto.accounting.request.StlCampaignAccountingRequestDTO;
import com.alibaba.ad.settle.billing.api.dto.accounting.response.StlCampaignAccountingResposneDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.settle.CampaignSettleConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.settle.SettleSAO;
import com.taobao.ad.brand.bp.client.dto.campaign.settle.CampaignSettleQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.settle.CampaignSettleViewDTO;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupSettleRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import lombok.RequiredArgsConstructor;

/**
 * @author yanjingang
 * @date 2023/4/6
 */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CampaignGroupSettleRepositoryImpl implements CampaignGroupSettleRepository {

    private final SettleSAO settleSAO;
    private final CampaignSettleConverter campaignSettleConverter;

    private final static String SETTLE_CODE = "BDUNION";

    @Override
    public List<CampaignSettleViewDTO> getCampaignSettleList(ServiceContext context, CampaignSettleQueryViewDTO campaignSettleQueryViewDTO) {
        StlCampaignAccountingRequestDTO requestDTO = new StlCampaignAccountingRequestDTO();
        requestDTO.setSettleCode(SETTLE_CODE);
        requestDTO.setMemberId(context.getMemberId());
        requestDTO.setCampaignList(campaignSettleQueryViewDTO.getCampaignIds());
        List<StlCampaignAccountingResposneDTO> accountingResposneDTOList = settleSAO.getHisAccountingResWithOrder(requestDTO);
        return campaignSettleConverter.convertDTO2ViewDTOList(accountingResposneDTOList);
    }
}
