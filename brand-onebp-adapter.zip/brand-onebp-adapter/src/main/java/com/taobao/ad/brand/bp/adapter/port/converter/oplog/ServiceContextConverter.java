package com.taobao.ad.brand.bp.adapter.port.converter.oplog;

import com.alibaba.abf.governance.context.ServiceContext;
import com.taobao.ad.brand.bp.adapter.port.converter.oplog.mapstruct.ServiceContextMapStruct;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author jixiu.lj
 * @date 2024/3/20 15:42
 */
@Component
public class ServiceContextConverter {
    public ServiceContext sourceToTarget(ServiceContext source) {
        return ServiceContextMapStruct.INSTANCE.sourceToTarget(source);
    }
}
