package com.taobao.ad.brand.bp.adapter.port.repository.ssp;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.nb.ssp.dto.material.MaterialRuleDTO;
import com.alibaba.ad.nb.ssp.dto.material.MaterialRuleDetailDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.materialrule.MaterialRuleConverter;
import com.taobao.ad.brand.bp.adapter.port.converter.materialrule.MaterialRuleDetailConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.ssp.MaterialRuleSAO;
import com.taobao.ad.brand.bp.client.dto.mr.MaterialRuleDetailViewDTO;
import com.taobao.ad.brand.bp.client.dto.mr.MaterialRuleViewDTO;
import com.taobao.ad.brand.bp.domain.ssp.MaterialRuleRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collections;
import java.util.List;

/**
 * @author jixiu.lj
 * @date 2023/3/21 10:00
 */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class MaterialRuleRepositoryImpl implements MaterialRuleRepository {

    private final MaterialRuleSAO materialRuleSAO;
    private final MaterialRuleDetailConverter materialRuleDetailConverter;
    private final MaterialRuleConverter materialRuleConverter;

    @Override
    public List<MaterialRuleDetailViewDTO> getMaterialRuleDetailList(ServiceContext serviceContext, List<Long> ruleIds) {
        List<MaterialRuleDetailDTO> materialRuleList = materialRuleSAO.getMaterialRuleDetailList(serviceContext, ruleIds);
        return materialRuleDetailConverter.convertDTO2ViewDTOList(materialRuleList);
    }
    @Override
    public List<MaterialRuleViewDTO> getMaterialRuleList(ServiceContext serviceContext, List<Long> ruleIds) {
        List<MaterialRuleDTO> materialRuleList = materialRuleSAO.getMaterialRuleList(serviceContext, ruleIds);
        return materialRuleConverter.convertDTO2ViewDTOList(materialRuleList);
    }
    @Override
    public MaterialRuleViewDTO getMaterialRuleByMrId(ServiceContext serviceContext, Long ruleId) {
        List<MaterialRuleDTO> materialRuleList = materialRuleSAO.getMaterialRuleList(serviceContext, Collections.singletonList(ruleId));
        if (CollectionUtils.isNotEmpty(materialRuleList)){
            return materialRuleConverter.convertDTO2ViewDTOList(materialRuleList).get(0);
        }
        return null;
    }
}
