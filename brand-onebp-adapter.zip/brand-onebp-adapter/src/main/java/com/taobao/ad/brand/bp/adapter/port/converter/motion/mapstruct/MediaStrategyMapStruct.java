package com.taobao.ad.brand.bp.adapter.port.converter.motion.mapstruct;

import com.alibaba.ad.nb.packages.v2.client.dto.motion.MarketingStageDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.motion.MediaStrategyDTO;
import com.taobao.ad.brand.bp.client.dto.motion.MarketingStageViewDTO;
import com.taobao.ad.brand.bp.client.dto.motion.MediaStrategyViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/18
 **/
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface MediaStrategyMapStruct extends BaseMapStructMapper<MediaStrategyDTO, MediaStrategyViewDTO> {

    MediaStrategyMapStruct INSTANCE = Mappers.getMapper(MediaStrategyMapStruct.class);

    @Mappings({
            @Mapping(source = "predictData", target = "predictDataViewDTO"),
            @Mapping(source = "mediaInsightData", target = "mediaInsightDataViewDTO"),
    })
    @Override
    MediaStrategyViewDTO sourceToTarget(MediaStrategyDTO mediaStrategyDTO);

    @Mappings({
            @Mapping(source = "predictDataViewDTO", target = "predictData"),
            @Mapping(source = "mediaInsightDataViewDTO", target = "mediaInsightData"),
    })
    @Override
    MediaStrategyDTO targetToSource(MediaStrategyViewDTO mediaStrategyViewDTO);
}
