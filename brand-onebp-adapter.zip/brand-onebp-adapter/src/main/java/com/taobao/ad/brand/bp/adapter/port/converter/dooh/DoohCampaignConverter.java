package com.taobao.ad.brand.bp.adapter.port.converter.dooh;

import com.taobao.ad.brand.bp.adapter.port.converter.dooh.mapstruct.DoohCampaignMapStruct;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohCampaignViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import com.umeng.oplus.domain.dto.dsp.plan.DspPlan4BailingDTO;
import org.springframework.stereotype.Component;

@Component
public class DoohCampaignConverter extends BaseViewDTOConverter<DspPlan4BailingDTO, DoohCampaignViewDTO> {

    @Override
    public BaseMapStructMapper<DspPlan4BailingDTO, DoohCampaignViewDTO> getBaseMapStructMapper() {
        return DoohCampaignMapStruct.INSTANCE;
    }
}
