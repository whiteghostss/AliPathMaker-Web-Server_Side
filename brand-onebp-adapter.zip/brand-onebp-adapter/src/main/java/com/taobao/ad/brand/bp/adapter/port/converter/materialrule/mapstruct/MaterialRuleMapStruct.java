package com.taobao.ad.brand.bp.adapter.port.converter.materialrule.mapstruct;
import com.alibaba.ad.nb.ssp.dto.material.MaterialRuleDTO;
import com.taobao.ad.brand.bp.client.dto.mr.MaterialRuleViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author yunghu.myh
 * @date 2023年09月30日
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface MaterialRuleMapStruct extends BaseMapStructMapper<MaterialRuleDTO, MaterialRuleViewDTO> {
    MaterialRuleMapStruct INSTANCE = Mappers.getMapper(MaterialRuleMapStruct.class);
}