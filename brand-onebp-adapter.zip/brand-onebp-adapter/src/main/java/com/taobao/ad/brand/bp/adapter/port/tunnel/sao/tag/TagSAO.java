package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.tag;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.biz.definition.constants.Product;
import com.alibaba.ad.creative.api.CreativeTagCommandService;
import com.alibaba.ad.creative.api.CreativeTagQueryService;
import com.alibaba.ad.creative.dto.tag.CreativeTagDTO;
import com.alibaba.ad.creative.query.CreativeTagQuery;
import com.alibaba.fastjson.JSON;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.alibaba.solar.common.dto.BaseServiceContext;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @Author: PhilipFry
 * @createTime: 2024年02月27日 19:47:36
 * @Description:
 */
@Component
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class TagSAO extends BaseSAO {

    private final CreativeTagCommandService creativeTagCommandService;
    private final CreativeTagQueryService creativeTagQueryService;

    /**
     * 拆分营销场景下非内容场景都查出品牌的
     *
     * @param serviceContext
     * @return
     */
    private ServiceContext getCreativeServiceContext(ServiceContext serviceContext) {
        ServiceContext context = new ServiceContext();
        context.setMemberId(serviceContext.getMemberId());
        context.setBizId(BizCodeEnum.BRANDONEBP.getBizCode());
        context.setBizCode(BizCodeEnum.BRANDAD.getBizCode());
        context.setAppId(ServiceContextUtil.getSceneId(BizCodeEnum.BRANDAD.getBizCode()));
        context.setProductLineId(Product.BRAND_ONEBP_BRAND.getProductLineId());
        context.setProductId(Product.BRAND_ONEBP_BRAND.getId());
        context.setOperType(BaseServiceContext.OPERTYPE_INNER_OPT);
        return context;
    }

    /**
     * 分页查询创意标签列表
     *
     * @param serviceContext
     * @param queryDTO
     * @return
     */
    public PageResultViewDTO<CreativeTagDTO> findCreativeTagPage(ServiceContext serviceContext, CreativeTagQuery queryDTO) {
        RogerLogger.info("findCreativeTagPage,ServiceContext:{},CreativeTagQuery:{}", JSON.toJSONString(serviceContext), JSON.toJSONString(queryDTO));
        MultiResponse<CreativeTagDTO> response = creativeTagQueryService.findCreativeTagPage(getCreativeServiceContext(serviceContext), queryDTO);
        RogerLogger.info("findCreativeTagPage,result:{}", JSON.toJSONString(response));
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return PageResultViewDTO.of(response.getResult(), response.getTotal());
    }

    /**
     * 查询创意标签列表
     *
     * @param serviceContext
     * @param queryDTO
     * @return
     */
    public List<CreativeTagDTO> findCreativeTagList(ServiceContext serviceContext, CreativeTagQuery queryDTO) {
        RogerLogger.info("findCreativeTagList,ServiceContext:{},CreativeTagQuery:{}", JSON.toJSONString(serviceContext), JSON.toJSONString(queryDTO));
        MultiResponse<CreativeTagDTO> response = creativeTagQueryService.findCreativeTagList(getCreativeServiceContext(serviceContext), queryDTO);
        RogerLogger.info("findCreativeTagList,result:{}", JSON.toJSONString(response));
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    public Long addCreativeTag(ServiceContext serviceContext, CreativeTagDTO creativeTagDTO) {
        SingleResponse<CreativeTagDTO> response = creativeTagCommandService.addCreativeTag(getCreativeServiceContext(serviceContext), creativeTagDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(String.format("新增创意标签时报错,error %s:", response.getErrorMsg())));
        return response.getResult().getId();
    }

    public Integer updateCreativeTag(ServiceContext serviceContext, CreativeTagDTO creativeTagDTO) {
        SingleResponse<Integer> response = creativeTagCommandService.updateCreativeTag(getCreativeServiceContext(serviceContext), creativeTagDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(String.format("编辑创意标签时报错,error %s:", response.getErrorMsg())));
        return response.getResult();
    }

    public Integer deleteCreativeTag(ServiceContext serviceContext, Long creativeTagId) {
        SingleResponse<Integer> response = creativeTagCommandService.deleteCreativeTag(getCreativeServiceContext(serviceContext), creativeTagId);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(String.format("删除创意标签时报错,error %s:", response.getErrorMsg())));
        return response.getResult();
    }
}
