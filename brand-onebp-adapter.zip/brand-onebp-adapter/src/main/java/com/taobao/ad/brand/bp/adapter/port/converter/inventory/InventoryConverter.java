package com.taobao.ad.brand.bp.adapter.port.converter.inventory;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.biz.definition.constants.Product;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.adzone.CampaignAdzoneViewDTO;
import com.alibaba.ad.brand.dto.campaign.audience.CampaignCategoryTargetViewDTO;
import com.alibaba.ad.brand.dto.campaign.audience.CampaignTargetViewDTO;
import com.alibaba.ad.brand.dto.campaign.audience.CampaignTargetScenarioViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.DayAmountViewDTO;
import com.alibaba.ad.brand.dto.campaign.creative.CampaignCreativeControllerViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdScenarioViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignShowmaxCrowdViewDTO;
import com.alibaba.ad.brand.dto.campaign.guarantee.CampaignGuaranteeViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryLockViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryPolicyViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryViewDTO;
import com.alibaba.ad.brand.dto.campaign.keyword.CampaignWordPackageViewDTO;
import com.alibaba.ad.brand.dto.campaign.keyword.CampaignWordViewDTO;
import com.alibaba.ad.brand.dto.campaign.realtime.CampaignRealTimeOptimizeViewDTO;
import com.alibaba.ad.brand.dto.campaign.resource.CampaignResourceViewDTO;
import com.alibaba.ad.brand.dto.campaign.safeip.CampaignSafeIpViewDTO;
import com.alibaba.ad.brand.dto.campaign.sale.CampaignSaleViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.frequency.FrequencyRuleViewDTO;
import com.alibaba.ad.brand.dto.frequency.FrequencyViewDTO;
import com.alibaba.ad.brand.dto.media.protect.MediaProtectRuleBlackViewDTO;
import com.alibaba.ad.brand.dto.media.protect.MediaProtectRuleTargetViewDTO;
import com.alibaba.ad.brand.dto.media.protect.MediaProtectRuleViewDTO;
import com.alibaba.ad.brand.sdk.constant.audience.field.BrandTargetTypeEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.*;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.alibaba.ad.brand.sdk.constant.keyword.field.BrandKeywordMatchScopeEnum;
import com.alibaba.ad.brand.sdk.constant.keyword.field.BrandKeywordTypeEnum;
import com.alibaba.ad.brand.sdk.constant.keyword.field.BrandWordPackageTypeEnum;
import com.alibaba.ad.brand.sdk.constant.media.field.BrandMediaProtectRuleBlackTypeEnum;
import com.alibaba.ad.nb.ssp.constant.common.MediaScopeEnum;
import com.alibaba.ad.nb.ssp.dto.common.CommonDTO;
import com.alibaba.ad.nb.ssp.dto.template.NbTemplateDTO;
import com.alibaba.fastjson.JSON;
import com.alibaba.solar.common.dto.BaseServiceContext;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.alimama.inventory.dto.ud.InventoryUdInquiryDTO;
import com.alimama.inventory.dto.universal.*;
import com.alimama.inventory.enums.AdEffectEnum;
import com.alimama.inventory.enums.InventorySourceAppEnum;
import com.alimama.inventory.enums.UnitEnum;
import com.alimama.inventory.enums.universal.*;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.sales.CustomerSAO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignScheduleViewDTO;
import com.taobao.ad.brand.bp.client.dto.mediarule.query.MediaProtectRuleQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.AdStyleEnum;
import com.taobao.ad.brand.bp.client.enums.campaign.RecommendCrowdTypeEnum;
import com.taobao.ad.brand.bp.common.constant.campaigngroup.CampaignGroupConstant;
import com.taobao.ad.brand.bp.common.helper.campaign.BizTargetToolsHelper;
import com.taobao.ad.brand.bp.common.util.*;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.domain.mediarule.MediaProtectRuleRepository;
import com.taobao.ad.brand.bp.domain.perform.PerformRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/25
 */
@Component
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class InventoryConverter {
    private static final String TX_PACKAGE_PID_MAPPING = "mm_12852562_1778064_111863050048";
    private static final String SHOWMAX_TYPE = "showMaxType";
    private static final String BRAND_IDS = "brandIds";
    private static final String CATEGORY_IDS = "categoryIds";

    private static final String DOOH_CAMPAIGN_ID = "doohCampaignId";
    private static final String IS_DOOH_RELEASE = "isDoohRelease";

    private final MediaProtectRuleRepository mediaProtectRuleRepository;

    private final CampaignGroupRepository campaignGroupRepository;

    private final PerformRepository performRepository;

    private final CustomerSAO customerSAO;

    public UniInquiryRequest convertToInquiryRequest(CampaignViewDTO campaignViewDTO, CampaignScheduleViewDTO scheduleViewDTO,
                                                     List<NbTemplateDTO> templateList) {
        UniInquiryRequest request = new UniInquiryRequest();

        CampaignGuaranteeViewDTO campaignGuaranteeViewDTO = campaignViewDTO.getCampaignGuaranteeViewDTO();
        CampaignResourceViewDTO campaignResourceViewDTO = campaignViewDTO.getCampaignResourceViewDTO();
        CampaignSaleViewDTO campaignSaleViewDTO = campaignViewDTO.getCampaignSaleViewDTO();
        CampaignRealTimeOptimizeViewDTO campaignRealTimeOptimizeViewDTO = campaignViewDTO.getCampaignRealTimeOptimizeViewDTO();
        CampaignSafeIpViewDTO campaignSafeIpViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignSafeIpViewDTO()).orElse(new CampaignSafeIpViewDTO());

        request.setBusinessId(campaignViewDTO.getId());
        request.setMemberId(campaignViewDTO.getMemberId());
        request.setSspProductId(campaignResourceViewDTO.getSspProductId());
        request.setBusinessType(BusinessType.BRAND);
        request.setSourceApp(InventorySourceAppEnum.BRAND_ONE_BP);
        request.setBusinessGroupId(campaignViewDTO.getCampaignGroupId());
        request.setTotalBudget(campaignViewDTO.getCampaignBudgetViewDTO().getDiscountTotalMoney());
        request.setSafeIpSupport(campaignSafeIpViewDTO.getIsSupportSafeIp());
        request.setSaleType(campaignSaleViewDTO.getSaleType());
        request.setSaleProductLine(campaignViewDTO.getCampaignSaleViewDTO().getSaleProductLine());
        //目前仅 部分周期预定量使用
        request.setTotalAmount(BizCampaignToolsHelper.isCPT(campaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterUnit()) ? scheduleViewDTO.getFutureCptAmount() : scheduleViewDTO.getFutureAmount());
        if (campaignViewDTO.getCampaignInquiryLockViewDTO() != null) {
            if(Objects.isNull(campaignViewDTO.getCampaignInquiryLockViewDTO().getCustomerPriority())){
                request.setCustomerPriority(CampaignGroupConstant.CUSTOMER_PRIORITY_DEFAULT);
            }else {
                request.setCustomerPriority(campaignViewDTO.getCampaignInquiryLockViewDTO().getCustomerPriority());
            }
        }
//        if (campaignRealTimeOptimizeViewDTO != null) {
//            boolean isLookLike = BrandBoolEnum.BRAND_TRUE.getCode().equals(campaignRealTimeOptimizeViewDTO.getIsCastingExpand());
//            request.setLookLike(isLookLike);
//        }
        request.setLookLike(false);
        boolean isCompulsive = BrandBoolEnum.BRAND_TRUE.getCode().equals(scheduleViewDTO.getIsCompulsive());
        request.setCompulsive(isCompulsive);
        request.setProgramType(convertToProgramType(campaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterManner()));
        request.setSaleUnit(convertToSaleUnit(campaignGuaranteeViewDTO.getSspRegisterUnit()));
        request.setBookingUnit(convertToBookingUnit(campaignGuaranteeViewDTO.getSspRegisterUnit(), campaignResourceViewDTO.getSspMediaScope()));
        request.setReleaseType(convertToReleaseType(scheduleViewDTO.getInquiryAssignType()));
        request.setSceneType(convertToSceneType(campaignSaleViewDTO.getSaleType()));
        request.setFrequencyInfo(getFrequencyInfo(campaignViewDTO.getCampaignFrequencyViewDTO().getFrequencyViewDTO(), scheduleViewDTO));

        List<CampaignAdzoneViewDTO> campaignAdzoneViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignTargetScenarioViewDTO())
                .map(CampaignTargetScenarioViewDTO::getCampaignAdzoneViewDTOList).orElse(null);
        if (CollectionUtils.isNotEmpty(campaignAdzoneViewDTOList)) {
            List<String> pidList = campaignAdzoneViewDTOList.stream().map(CampaignAdzoneViewDTO::getPid).collect(Collectors.toList());
            request.setPids(pidList);
        }


        List<TargetDimension> targetDimensionList = getTargetDimensionList(campaignViewDTO, scheduleViewDTO, templateList);
        if (CollectionUtils.isNotEmpty(targetDimensionList)) {
            request.setTargetDimensions(targetDimensionList);
        }

        //补充ShowMax成效预估参数
        fillShowMaxExtensions(request, campaignViewDTO);

        //考虑保护规则影响
        considerProtectRule(request, campaignViewDTO);

        //天攻计划增加天攻计划ID传参
        fillDoohInfo(request, campaignViewDTO);
        if(Objects.nonNull(campaignViewDTO.getCampaignSelfServiceViewDTO())
                && Objects.nonNull(campaignViewDTO.getCampaignSelfServiceViewDTO().getCartItemId())){
            request.setSelfService(BrandBoolEnum.BRAND_TRUE.getCode());
        }

        //一搜即现匹配模式传参
        if(campaignViewDTO.getCampaignKeywordViewDTO() != null) {
            if(CollectionUtils.isNotEmpty(campaignViewDTO.getCampaignKeywordViewDTO().getCampaignWordViewDTOList())){
                //一个计划下所有的词匹配模式是一样的
                List<CampaignWordViewDTO> campaignWordViewDTOList = campaignViewDTO.getCampaignKeywordViewDTO().getCampaignWordViewDTOList();
                Integer matchScope = campaignWordViewDTOList.get(0).getMatchScope();
                if(BrandKeywordMatchScopeEnum.PHRASE_MATCH.getCode().equals(matchScope)){
                    request.setKeywordMatchScope(KeywordMatchScope.PHRASE_MATCH);
                } else {
                    request.setKeywordMatchScope(KeywordMatchScope.EXACT_MATCH);
                }
                //如果有词包信息，自定义词
                if(campaignViewDTO.getCampaignKeywordViewDTO().getCampaignWordPackageViewDTO() != null && StringUtils.isNotEmpty(campaignViewDTO.getCampaignKeywordViewDTO().getCampaignWordPackageViewDTO().getAlgoPackageId())){
                    request.setKeywordType(KeywordType.GRAYSCALE);
                }else{
                    request.setKeywordType(KeywordType.CUSTOM);
                }
            }
            if(campaignViewDTO.getCampaignKeywordViewDTO().getCampaignWordPackageViewDTO() != null){
                CampaignWordPackageViewDTO campaignWordPackageViewDTO = campaignViewDTO.getCampaignKeywordViewDTO().getCampaignWordPackageViewDTO();
                if(BrandWordPackageTypeEnum.CATEGORY.getCode().equals(campaignWordPackageViewDTO.getType())){
                    request.setWordPackageType(WordPackageType.CATEGORY);
                }else if(BrandWordPackageTypeEnum.BRAND.getCode().equals(campaignWordPackageViewDTO.getType())){
                    request.setWordPackageType(WordPackageType.BRAND);
                }else if(BrandWordPackageTypeEnum.COMPETITIVE.getCode().equals(campaignWordPackageViewDTO.getType())){
                    request.setWordPackageType(WordPackageType.COMPETITIVE);
                }else if(BrandWordPackageTypeEnum.ITEM.getCode().equals(campaignWordPackageViewDTO.getType())){
                    request.setWordPackageType(WordPackageType.ITEM);
                }
            }
        }

        return request;
    }


    private void fillShowMaxExtensions(UniInquiryRequest request, CampaignViewDTO campaignViewDTO) {
        if (BizCampaignToolsHelper.isShowmaxCampaign(campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope(),campaignViewDTO.getCampaignResourceViewDTO().getSspProductLineId(), campaignViewDTO.getCampaignResourceViewDTO().getSspCrossScene())) {
            Map<String, Object> extensions = Maps.newHashMap();
            CampaignShowmaxCrowdViewDTO campaignShowmaxCrowdViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignCrowdScenarioViewDTO()).map(CampaignCrowdScenarioViewDTO::getCampaignShowmaxCrowdViewDTO).orElse(null);
            if (Objects.nonNull(campaignShowmaxCrowdViewDTO) && Objects.nonNull(campaignShowmaxCrowdViewDTO.getShowmaxCrowdType())) {
                extensions.put(SHOWMAX_TYPE, String.valueOf(campaignShowmaxCrowdViewDTO.getShowmaxCrowdType()));
                if (CollectionUtils.isNotEmpty(campaignShowmaxCrowdViewDTO.getShowmaxCrowdLabelIdList())) {
                    if (RecommendCrowdTypeEnum.BRAND.getCode().equals(campaignShowmaxCrowdViewDTO.getShowmaxCrowdType()) || RecommendCrowdTypeEnum.BRAND_ADDITION.getCode().equals(campaignShowmaxCrowdViewDTO.getShowmaxCrowdType())) {
                        extensions.put(BRAND_IDS, StringUtils.join(campaignShowmaxCrowdViewDTO.getShowmaxCrowdLabelIdList(), ","));
                    } else if (RecommendCrowdTypeEnum.CATEGORY.getCode().equals(campaignShowmaxCrowdViewDTO.getShowmaxCrowdType()) || RecommendCrowdTypeEnum.CATEGORY_ADDITION.getCode().equals(campaignShowmaxCrowdViewDTO.getShowmaxCrowdType())) {
                        extensions.put(CATEGORY_IDS, StringUtils.join(campaignShowmaxCrowdViewDTO.getShowmaxCrowdLabelIdList(), ","));
                    }
                }
            }
            request.setExtensions(extensions);
        }
    }

    /**
     * 填充预定量
     */
    public void convertToInquiryBookingSlots(CampaignScheduleViewDTO scheduleViewDTO, UniInquiryRequest request) {
        List<BookingSlot> bookingSlots = Lists.newArrayList();
        Date deadlineDate = inquiryDeadline(scheduleViewDTO.getSaleType(), scheduleViewDTO.getInquiryViewDTOList(),
                scheduleViewDTO.getFirstOnlineTime());
        List<CampaignInquiryViewDTO> futureInquiryList = scheduleViewDTO.getFutureInquiryList();
        Integer sspMediaScope = scheduleViewDTO.getSspMediaScope();
        Integer sspRegisterUnit = scheduleViewDTO.getSspRegisterUnit();
        if (CollectionUtils.isNotEmpty(futureInquiryList)) {
            request.setAssignMode(AssignMode.BY_DAY);
            for (CampaignInquiryViewDTO inquiryViewDTO : futureInquiryList) {
                BookingSlot bookingSlot = new BookingSlot();
                bookingSlot.setStartDate(inquiryViewDTO.getDate());
                bookingSlot.setEndDate(inquiryViewDTO.getDate());
                if (BizCampaignToolsHelper.isTwoCPT(sspMediaScope,sspRegisterUnit)) {
                    bookingSlot.setAmount(inquiryViewDTO.getCptAmount());
                } else {
                    bookingSlot.setAmount(inquiryViewDTO.getBookAmount());
                }
                bookingSlots.add(bookingSlot);
            }
        } else {
            long totalAmount = scheduleViewDTO.getFutureAmount();
            Date startTime = BrandDateUtil.maxDate(deadlineDate, scheduleViewDTO.getStartTime());
            Date endTime = scheduleViewDTO.getEndTime();
            AssertUtil.assertTrue(NumberUtil.greaterThanZero(totalAmount), String.format("计划(%s)可用预定量为0", scheduleViewDTO.getTitle()));
            AssertUtil.assertTrue(BrandDateUtil.isBeforeAndEqual(startTime, endTime),
                    String.format("计划(%s)历史日期不能询锁量", scheduleViewDTO.getTitle()));
            //部分周期分配比例需要设置多段, 总预定量读取 totalAmount
            if (BrandCampaignInquiryAssignTypeEnum.PERIOD_PART_INTELLIGENCE.getCode().equals(scheduleViewDTO.getInquiryAssignType())
                    && CollectionUtils.isNotEmpty(scheduleViewDTO.getSchedulePolicyList())) {
                request.setAssignMode(AssignMode.BY_MULTI_PERIOD);
                scheduleViewDTO.getSchedulePolicyList().forEach(schedulePolicy -> {
                    BookingSlot bookingSlot = new BookingSlot();
                    bookingSlot.setStartDate(schedulePolicy.getStartTime());
                    bookingSlot.setEndDate(schedulePolicy.getEndTime());
                    bookingSlots.add(bookingSlot);
                });
                AssertUtil.assertTrue(request.getTotalAmount() != null && request.getTotalAmount() > 0, "部分周期智能分配,预定量不能为空");
            } else {
                request.setAssignMode(AssignMode.BY_PERIOD);
                BookingSlot bookingSlot = new BookingSlot();
                bookingSlot.setStartDate(startTime);
                bookingSlot.setEndDate(endTime);
                bookingSlot.setAmount(totalAmount);
                bookingSlots.add(bookingSlot);
            }
        }
        request.setBookingSlots(bookingSlots);
    }

    public void convertToDailyUpdateBookingSlots(CampaignViewDTO campaign, UniInquiryRequest request) {
        if (CollectionUtils.isEmpty(campaign.getCampaignScrollViewDTO().getCastInfoList())) {
            return;
        }
        Date currentDate = BrandDateUtil.getCurrentDate();
        List<DayAmountViewDTO> dayAmountViewDTOList = campaign.getCampaignScrollViewDTO().getCastInfoList().stream().filter(
                v -> BrandDateUtil.isAfterAndEqual(v.getDay(), currentDate)).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(dayAmountViewDTOList)) {
            return;
        }
        List<BookingSlot> bookingSlots = Lists.newArrayList();
        request.setAssignMode(AssignMode.BY_DAY);
        for (DayAmountViewDTO dayAmountViewDTO : dayAmountViewDTOList) {
            BookingSlot bookingSlot = new BookingSlot();
            bookingSlot.setStartDate(dayAmountViewDTO.getDay());
            bookingSlot.setEndDate(dayAmountViewDTO.getDay());
            bookingSlot.setAmount(dayAmountViewDTO.getAmount());
            bookingSlots.add(bookingSlot);
        }
        request.setBookingSlots(bookingSlots);
    }

    private void considerProtectRule(UniInquiryRequest request, CampaignViewDTO campaignViewDTO) {
        Integer sspMediaScope = campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope();
        //只有二环需要排除保护规则的定向
        if (!MediaScopeEnum.TAO_OUT.getCode().equals(sspMediaScope)) {
            return;
        }
        List<CampaignAdzoneViewDTO> campaignAdzoneViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignTargetScenarioViewDTO())
                .map(CampaignTargetScenarioViewDTO::getCampaignAdzoneViewDTOList).orElse(null);
        if (CollectionUtils.isEmpty(campaignAdzoneViewDTOList)) {
            return;
        }
        List<String> pids = campaignAdzoneViewDTOList.stream().map(CampaignAdzoneViewDTO::getPid).collect(Collectors.toList());
        RogerLogger.info("originalPids={},campaignId={}", JSON.toJSONString(pids), campaignViewDTO.getId());
        MediaProtectRuleQueryViewDTO protectRuleQueryViewDTO = new MediaProtectRuleQueryViewDTO();
        protectRuleQueryViewDTO.setPidList(pids);
        protectRuleQueryViewDTO.setStatus(BrandBoolEnum.BRAND_TRUE.getCode());
        List<MediaProtectRuleViewDTO> protectRuleViewDTOList = mediaProtectRuleRepository.findList(buildServiceContext(campaignViewDTO), protectRuleQueryViewDTO);
        RogerLogger.info("protectRuleViewDTOList={},campaignId={}", JSON.toJSONString(protectRuleViewDTOList), campaignViewDTO.getId());
        if (CollectionUtils.isEmpty(protectRuleViewDTOList)) {
            return;
        }

        List<MediaProtectRuleViewDTO> matchedProtectRuleViewDTOList = protectRuleViewDTOList.stream()
                .filter(ruleViewDTO -> ruleViewDTO.getEndTime() != null && !ruleViewDTO.getEndTime().before(BrandDateUtil.getCurrentDate()))
                .filter(ruleViewDTO -> hitProtectRuleBlackList(ruleViewDTO, campaignViewDTO))
                .collect(Collectors.toList());
        RogerLogger.info("matchedProtectRuleViewDTOList={},campaignId={}", JSON.toJSONString(matchedProtectRuleViewDTOList), campaignViewDTO.getId());
        if (CollectionUtils.isEmpty(matchedProtectRuleViewDTOList)) {
            return;
        }

        //匹配的保护规则定向，需要在询锁量中排除掉
        List<TargetDimension> exclusionDimensions = Lists.newArrayList();
        Set<String> protectAreaSet = Sets.newHashSet();
        Set<String> protectChannelSet = Sets.newHashSet();
        matchedProtectRuleViewDTOList.stream()
                .filter(ruleViewDTO -> ruleViewDTO.getTargetViewDTO() != null)
                .forEach(ruleViewDTO -> {
                    MediaProtectRuleTargetViewDTO targetViewDTO = ruleViewDTO.getTargetViewDTO();
                    if (CollectionUtils.isNotEmpty(targetViewDTO.getAreaList())) {
                        protectAreaSet.addAll(targetViewDTO.getAreaList());
                    }
                    if (CollectionUtils.isNotEmpty(targetViewDTO.getChannelList())) {
                        protectChannelSet.addAll(targetViewDTO.getChannelList());
                    }
                });
        if (CollectionUtils.isNotEmpty(protectAreaSet)) {
            TargetDimension exclusionDimension = new TargetDimension();
            exclusionDimension.setType(TargetType.AREA);
            exclusionDimension.setValues(protectAreaSet);
            exclusionDimensions.add(exclusionDimension);
        }
        if (CollectionUtils.isNotEmpty(protectChannelSet)) {
            TargetDimension exclusionDimension = new TargetDimension();
            exclusionDimension.setType(TargetType.CHANNEL);
            exclusionDimension.setValues(protectChannelSet);
            exclusionDimensions.add(exclusionDimension);
        }
        if (CollectionUtils.isNotEmpty(exclusionDimensions)) {
            request.setExclusionDimensions(exclusionDimensions);
        }

        //保护规则定向全部设置不限的场景，保护规则的pid需要在询锁量中排除掉
        Set<String> protectedPidSet = Sets.newHashSet();
        matchedProtectRuleViewDTOList.stream()
                .filter(ruleViewDTO -> protectTargetNotSpecified(ruleViewDTO.getTargetViewDTO()))
                .filter(ruleViewDTO -> CollectionUtils.isNotEmpty(ruleViewDTO.getPidList()))
                .forEach(ruleViewDTO -> protectedPidSet.addAll(ruleViewDTO.getPidList()));
        RogerLogger.info("protectedPids={},campaignId={}", JSON.toJSONString(protectedPidSet), campaignViewDTO.getId());
        if (CollectionUtils.isNotEmpty(request.getPids())) {
            request.setPids(request.getPids().stream().filter(pid -> !protectedPidSet.contains(pid)).collect(Collectors.toList()));
        }
        RogerLogger.info("finalPids={},campaignId={}", JSON.toJSONString(request.getPids()), campaignViewDTO.getId());
    }

    private boolean protectTargetNotSpecified(MediaProtectRuleTargetViewDTO targetViewDTO) {
        if (targetViewDTO == null) {
            return true;
        }
        return CollectionUtils.isEmpty(targetViewDTO.getChannelList())
                && CollectionUtils.isEmpty(targetViewDTO.getAreaList())
                && CollectionUtils.isEmpty(targetViewDTO.getAppList())
                && CollectionUtils.isEmpty(targetViewDTO.getUaList())
                && CollectionUtils.isEmpty(targetViewDTO.getIdentityIdList());
    }

    private boolean hitProtectRuleBlackList(MediaProtectRuleViewDTO ruleViewDTO, CampaignViewDTO campaignViewDTO) {
        List<MediaProtectRuleBlackViewDTO> protectRuleBlackViewList = ruleViewDTO.getBlackViewDTOList();
        RogerLogger.info("protectRuleBlackViewList={},campaignId={}", JSON.toJSONString(protectRuleBlackViewList), campaignViewDTO.getId());
        if (CollectionUtils.isEmpty(protectRuleBlackViewList)) {
            return false;
        }

        for (MediaProtectRuleBlackViewDTO blackViewDTO : protectRuleBlackViewList) {
            BrandMediaProtectRuleBlackTypeEnum bizType = BrandMediaProtectRuleBlackTypeEnum.getByCode(blackViewDTO.getBizType());
            String value = blackViewDTO.getValue();
            switch (bizType) {
                case CAMPAIGN:
                    if (hitBlackListOfCampaignCategory(value, campaignViewDTO)) {
                        RogerLogger.info("hitBlackListOfCampaignCategory:campaignId={},protectRuleId={},bizType={},bizValue={}",
                                campaignViewDTO.getId(), ruleViewDTO.getId(), blackViewDTO.getBizType(), blackViewDTO.getValue());
                        return true;
                    }
                    break;
                case CAMPAIGN_GROUP:
                    if (hitBlackListOfCampaignGroupCategory(value, campaignViewDTO)) {
                        RogerLogger.info("hitBlackListOfCampaignGroupCategory:campaignId={},protectRuleId={},bizType={},bizValue={}",
                                campaignViewDTO.getId(), ruleViewDTO.getId(), blackViewDTO.getBizType(), blackViewDTO.getValue());
                        return true;
                    }
                    break;
                case PRODUCT:
                    if (hitBlackListOfProductCategory(value, campaignViewDTO)) {
                        RogerLogger.info("hitBlackListOfProductCategory:campaignId={},protectRuleId={},bizType={},bizValue={}",
                                campaignViewDTO.getId(), ruleViewDTO.getId(), blackViewDTO.getBizType(), blackViewDTO.getValue());
                        return true;
                    }
                    break;
                case ADVERTISER:
                    if (hitBlackListOfAdvertiserCategory(value, campaignViewDTO)) {
                        RogerLogger.info("hitBlackListOfAdvertiserCategory:campaignId={},protectRuleId={},bizType={},bizValue={}",
                                campaignViewDTO.getId(), ruleViewDTO.getId(), blackViewDTO.getBizType(), blackViewDTO.getValue());
                        return true;
                    }
                    break;
                case INDUSTRY:
                    if (hitBlackListOfIndustryCategory(value, campaignViewDTO)) {
                        RogerLogger.info("hitBlackListOfIndustryCategory:campaignId={},protectRuleId={},bizType={},bizValue={}",
                                campaignViewDTO.getId(), ruleViewDTO.getId(), blackViewDTO.getBizType(), blackViewDTO.getValue());
                        return true;
                    }
                    break;
                default:
                    break;
            }
        }

        return false;
    }

    private boolean hitBlackListOfIndustryCategory(String value, CampaignViewDTO campaignViewDTO) {
//        CampaignBaseViewDTO baseViewDTO = campaignViewDTO.getCampaignBaseViewDTO();
        Long campaignGroupId = campaignViewDTO.getCampaignGroupId();
        if(campaignGroupId == null){
            RogerLogger.info("计划关联订单不存在（如自助化场景），不做命中逻辑判断");
            return false;
        }
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(buildServiceContext(campaignViewDTO), campaignGroupId);
        AssertUtil.assertTrue(campaignGroupViewDTO != null && campaignGroupViewDTO.getCampaignGroupExtViewDTO() != null
                && campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getCustomerMemberId() != null, "获取真实客户的投放账号失败");
        Long customerMemberId = campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getCustomerMemberId();
        Long customerIndustry = customerSAO.getCustomerIndustry(customerMemberId);
        RogerLogger.info("campaignId={},customerMemberId={},customerIndustry={}", campaignViewDTO.getId(), customerMemberId, customerIndustry);
        return String.valueOf(customerIndustry).equals(value);
    }

    private boolean hitBlackListOfAdvertiserCategory(String value, CampaignViewDTO campaignViewDTO) {
        Long customerId = Optional.ofNullable(campaignViewDTO.getCampaignSaleViewDTO())
                .map(CampaignSaleViewDTO::getCustomerId).orElse(null);
        if(customerId == null){
            RogerLogger.info("计划关联customerId不存在（如自助化场景），不做命中逻辑判断");
            return false;
        }
        return String.valueOf(customerId).equals(value);
    }

    private boolean hitBlackListOfProductCategory(String value, CampaignViewDTO campaignViewDTO) {
        CampaignResourceViewDTO campaignResourceViewDTO = campaignViewDTO.getCampaignResourceViewDTO();
        AssertUtil.assertTrue(campaignResourceViewDTO != null && campaignResourceViewDTO.getSspProductUuid() != null, "获取SSP产品uuid失败");
        return String.valueOf(campaignResourceViewDTO.getSspProductUuid()).equals(value);
    }

    private boolean hitBlackListOfCampaignGroupCategory(String value, CampaignViewDTO campaignViewDTO) {
//        CampaignBaseViewDTO baseViewDTO = campaignViewDTO.getCampaignBaseViewDTO();
        Long campaignGroupId = campaignViewDTO.getCampaignGroupId();
        if(campaignGroupId == null){
            RogerLogger.info("计划关联订单不存在（如自助化场景），不做命中逻辑判断");
            return false;
        }
        return String.valueOf(campaignGroupId).equals(value);
    }

    private boolean hitBlackListOfCampaignCategory(String value, CampaignViewDTO campaignViewDTO) {
        AssertUtil.notNull(campaignViewDTO.getParentCampaignId(), "获取一级计划id失败");
        return String.valueOf(campaignViewDTO.getParentCampaignId()).equals(value);
    }

    private List<TargetDimension> getTargetDimensionList(CampaignViewDTO campaignViewDTO, CampaignScheduleViewDTO scheduleViewDTO,
                                                         List<NbTemplateDTO> templateList) {
        CampaignGuaranteeViewDTO campaignGuaranteeViewDTO = campaignViewDTO.getCampaignGuaranteeViewDTO();
        CampaignInquiryLockViewDTO campaignInquiryLockViewDTO = campaignViewDTO.getCampaignInquiryLockViewDTO();

        List<TargetDimension> targetDimensions = Lists.newArrayList();
        List<CampaignCrowdViewDTO> campaignCrowdViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignCrowdScenarioViewDTO())
                .map(CampaignCrowdScenarioViewDTO::getCampaignCrowdViewDTOList).orElse(null);
        if (CollectionUtils.isNotEmpty(campaignCrowdViewDTOList)) {
            Set<String> crowdIds = campaignCrowdViewDTOList.stream()
                    //过滤品牌智能人群
                    .filter(item->!item.getTargetType().equals(BrandTargetTypeEnum.BRAND_ALGO_CROWD_NEW.getCode().longValue()))
                    //算法调控通投人群
                    .filter(item->!item.getTargetType().equals(BrandTargetTypeEnum.ALGO_CONTROL_NO_TARGET_CROWD.getCode().longValue()))
                    //过滤屏蔽人群
                    .filter(item->!item.getTargetType().equals(BrandTargetTypeEnum.BLOCK_CROWD.getCode().longValue()))
                    //实时优选人群不参与询锁量
                    .filter(v -> Objects.isNull(v.getScene()))
                    .map(v -> v.getCrowdId().toString()).collect(Collectors.toSet());
            if (CollectionUtils.isNotEmpty(crowdIds)) {
                TargetDimension crowdTarget = new TargetDimension();
                crowdTarget.setType(TargetType.DMP_CROWD);
                crowdTarget.setValues(crowdIds);
                targetDimensions.add(crowdTarget);
            }
        }

        List<CampaignTargetViewDTO> campaignTargetViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignTargetScenarioViewDTO())
                .map(CampaignTargetScenarioViewDTO::getCampaignTargetViewDTOList).orElse(Lists.newArrayList());
        if (CollectionUtils.isNotEmpty(campaignTargetViewDTOList)) {
            for (CampaignTargetViewDTO campaignTargetViewDTO : campaignTargetViewDTOList) {
                //三环场景-阿里小时定向、阿里地域、阿里设备定向、阿里贴片定向不参与询锁量
                if(Objects.equals(MediaScopeEnum.SITE_OUT.getCode(),campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope())){
                    if(Objects.equals(BrandTargetTypeEnum.TIME_PLUS.getCode().toString(), campaignTargetViewDTO.getType())
                            || Objects.equals(BrandTargetTypeEnum.AREA.getCode().toString(), campaignTargetViewDTO.getType())
                            || Objects.equals(BrandTargetTypeEnum.NEW_DEVICE.getCode().toString(), campaignTargetViewDTO.getType())
                            || Objects.equals(BrandTargetTypeEnum.PRECEDENCE.getCode().toString(), campaignTargetViewDTO.getType())
                        ){
                        continue;
                    }
                }
                TargetType targetType = convertToInventoryTargetType(campaignTargetViewDTO.getType());
                if (targetType == null) {
                    continue;
                }
                TargetDimension targetDimension = new TargetDimension();
                targetDimension.setType(targetType);
                if (TargetType.CROWD_AGE.equals(targetType)) {
                    // 年龄需要获取范围内的所有值
                    Set<String> ageSet = campaignTargetViewDTO.getTargetValues().stream().flatMap(item -> NumberUtil.getRangeNums(item, "-").stream())
                            .map(String::valueOf).collect(Collectors.toSet());
                    targetDimension.setValues(ageSet);
                } else if (TargetType.HOUR_SLOT.equals(targetType)) {
                    List<String> hourList = BrandLocalDateTimeUtil.getBetweenHourResult(campaignTargetViewDTO.getTargetValues(), MediaScopeEnum.SITE_OUT.getCode().equals(campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope()));
                    targetDimension.setValues(Sets.newHashSet(hourList));
                // 人群打分定向 需要使用实际的分数值去询锁量（媒体询量中同样如此）
                } else if (TargetType.ALI_CROWD_SCORE.equals(targetType)) {
                    targetDimension.setValues(performRepository.getSortedScoreSet(buildServiceContext(campaignViewDTO), campaignTargetViewDTO.getTargetValues().stream().map(Long::valueOf).collect(Collectors.toList())));
                } else if (TargetType.SHOW_BUY_CATEGORY.equals(targetType)) {
                    // 剔除投中类目
                    List<String> castingCategoryList = Optional.ofNullable(campaignTargetViewDTO.getCampaignCategoryTargetViewDTOList()).orElse(Lists.newArrayList()).stream()
                            .filter(categoryViewDTO -> BrandCategorySceneEnum.CASTING.getCode().equals(categoryViewDTO.getScene()))
                            .map(CampaignCategoryTargetViewDTO::getCatId).map(String::valueOf)
                            .collect(Collectors.toList());
                    List<String> filterCategoryIdList = campaignTargetViewDTO.getTargetValues().stream()
                            .filter(categoryId -> !castingCategoryList.contains(categoryId))
                            .collect(Collectors.toList());
                    targetDimension.setValues(Sets.newHashSet(filterCategoryIdList));
                } else {
                    targetDimension.setValues(Sets.newHashSet(campaignTargetViewDTO.getTargetValues()));
                }
                targetDimensions.add(targetDimension);
            }
        }

        CampaignCreativeControllerViewDTO campaignCreativeControllerViewDTO = campaignViewDTO.getCampaignCreativeControllerViewDTO();
        if (campaignCreativeControllerViewDTO != null && campaignCreativeControllerViewDTO.getTimeLength() != null) {
            Integer timeLength = campaignCreativeControllerViewDTO.getTimeLength();
            TargetDimension targetDimension = new TargetDimension();
            targetDimension.setType(TargetType.TIME_LENGTH);
            targetDimension.setValues(Sets.newHashSet(timeLength.toString()));
            targetDimensions.add(targetDimension);
        }

        if (campaignGuaranteeViewDTO != null && campaignGuaranteeViewDTO.getSspPushSendRatio() != null) {
            TargetDimension targetDimension = new TargetDimension();
            targetDimension.setType(TargetType.PDB_PUSH_RATIO);
            targetDimension.setValues(Sets.newHashSet(String.valueOf(campaignGuaranteeViewDTO.getSspPushSendRatio() / 100)));
            targetDimensions.add(targetDimension);
        }

        if(campaignViewDTO.getCampaignKeywordViewDTO() != null && CollectionUtils.isNotEmpty(campaignViewDTO.getCampaignKeywordViewDTO().getCampaignWordViewDTOList())){
            List<CampaignWordViewDTO> keywordList = campaignViewDTO.getCampaignKeywordViewDTO().getCampaignWordViewDTOList();
            Set<String> normalWordList = keywordList.stream().map(CampaignWordViewDTO::getNormalWord).collect(Collectors.toSet());
            TargetDimension targetDimension = new TargetDimension();
            targetDimension.setType(TargetType.KEYWORD);
            targetDimension.setValues(normalWordList);
            targetDimensions.add(targetDimension);
        }
        if(campaignViewDTO.getCampaignKeywordViewDTO() != null && campaignViewDTO.getCampaignKeywordViewDTO().getCampaignWordPackageViewDTO() != null){
            CampaignWordPackageViewDTO campaignWordPackageViewDTO = campaignViewDTO.getCampaignKeywordViewDTO().getCampaignWordPackageViewDTO();
            Set<String> wordPackageIdList = Sets.newHashSet(campaignWordPackageViewDTO.getAlgoPackageId());
            TargetDimension targetDimension = new TargetDimension();
            targetDimension.setType(TargetType.WORD_PACKAGE);
            targetDimension.setValues(wordPackageIdList);
            targetDimensions.add(targetDimension);
        }

        if (CollectionUtils.isNotEmpty(templateList)) {
            /**
             * 影响库存询锁量的模版样式处理，开屏样式优先级：仅开屏(995) > Topview(997、993) > PopView(998、996) > 底纹词(999、994)
             * 开屏样式和优酷聚焦贴片样式不可能同时存在于一个计划中，没有优先级关系
             */
            AdEffectEnum adEffect = null;
            List<CommonDTO> effectList = templateList.stream().map(NbTemplateDTO::getEffectList).flatMap(Collection::stream).collect(Collectors.toList());

            //手淘底纹词场景
            boolean isWord = effectList.stream()
                    .anyMatch(common -> Lists.newArrayList(AdStyleEnum.TB_STAR_PIC_WORD.getValue().toString(),
                            AdStyleEnum.TB_STAR_PIC_WORD_NOT_JUMP.getValue().toString()).contains(common.getValue()));
            if (isWord) {
                adEffect = AdEffectEnum.TB_STAR_PIC_WORD;
            }
            //手淘PopView场景
            boolean isPop = effectList.stream()
                    .anyMatch(common -> Lists.newArrayList(AdStyleEnum.TB_STAR_PIC_POPVIEW.getValue().toString(),
                            AdStyleEnum.TB_STAR_PIC_POPVIEW_JUMP.getValue().toString()).contains(common.getValue()));
            if (isPop) {
                adEffect = AdEffectEnum.TB_STAR_PIC_POPVIEW;
            }
            //手淘TopView场景
            boolean isTop = effectList.stream()
                    .anyMatch(common -> Lists.newArrayList(AdStyleEnum.TB_STAR_PIC_TOPVIEW.getValue().toString(),
                            AdStyleEnum.TB_STAR_PIC_POPVIEW_FIRST_SHOW.getValue().toString()).contains(common.getValue()));
            if (isTop) {
                adEffect = AdEffectEnum.TB_STAR_PIC_TOPVIEW;
            }
            //手淘仅开屏场景
            boolean isOnlyPop = effectList.stream()
                    .anyMatch(common -> Objects.equals(common.getValue(), AdStyleEnum.TB_STAR_PIC_ONLY_POPVIEW.getValue().toString()));
            if (isOnlyPop) {
                adEffect = AdEffectEnum.TB_STAR_PIC_PIC;
            }
            //优酷聚焦贴片场景
            boolean isMovieAdsFocusView = effectList.stream()
                    .anyMatch(common -> Objects.equals(common.getValue(), AdStyleEnum.YK_MOVIE_ADS_FOCUS_VIEW.getValue().toString()));
            if(isMovieAdsFocusView) {
                adEffect = AdEffectEnum.YK_MOVIE_ADS_FOCUS_VIEW;
            }

            if (adEffect != null) {
                TargetDimension targetDimension = new TargetDimension();
                targetDimension.setType(TargetType.AD_EFFECT);
                targetDimension.setValues(Sets.newHashSet(adEffect.getValue().toString()));
                targetDimensions.add(targetDimension);
            }
        }

        CampaignInquiryPolicyViewDTO campaignInquiryPolicyViewDTO = Optional.ofNullable(campaignInquiryLockViewDTO).map(CampaignInquiryLockViewDTO::getCampaignInquiryPolicyViewDTO).orElse(null);
        if (campaignInquiryPolicyViewDTO != null && (CollectionUtils.isNotEmpty(campaignInquiryPolicyViewDTO.getInquiryRowIds()) ||
                CollectionUtils.isNotEmpty(campaignInquiryPolicyViewDTO.getPurchaseRowIds()))) {
            if (CollectionUtils.isNotEmpty(campaignInquiryPolicyViewDTO.getInquiryRowIds())) {
                TargetDimension targetDimension = new TargetDimension();
                targetDimension.setType(TargetType.RESERVE_GROUP);
                Set<String> ids = campaignInquiryPolicyViewDTO.getInquiryRowIds().stream().map(Object::toString).collect(Collectors.toSet());
                targetDimension.setValues(ids);
                targetDimensions.add(targetDimension);
            }
            if (CollectionUtils.isNotEmpty(campaignInquiryPolicyViewDTO.getPurchaseRowIds())) {
                TargetDimension targetDimension = new TargetDimension();
                targetDimension.setType(TargetType.CONFIRM_ROW);
                Set<String> ids = campaignInquiryPolicyViewDTO.getPurchaseRowIds().stream().map(Object::toString).collect(Collectors.toSet());
                targetDimension.setValues(ids);
                targetDimensions.add(targetDimension);
            }
        } else {
            if (CollectionUtils.isNotEmpty(scheduleViewDTO.getInquiryOrderIds())) {
                TargetDimension targetDimension = new TargetDimension();
                targetDimension.setType(TargetType.RESERVE_ORDER);
                Set<String> ids = scheduleViewDTO.getInquiryOrderIds().stream().map(Object::toString).collect(Collectors.toSet());
                targetDimension.setValues(ids);
                targetDimensions.add(targetDimension);
            }
            if (CollectionUtils.isNotEmpty(scheduleViewDTO.getPurchaseOrderIds())) {
                TargetDimension targetDimension = new TargetDimension();
                targetDimension.setType(TargetType.CONFIRM_ORDER);
                Set<String> ids = scheduleViewDTO.getPurchaseOrderIds().stream().map(Object::toString).collect(Collectors.toSet());
                targetDimension.setValues(ids);
                targetDimensions.add(targetDimension);
            }
        }
        return targetDimensions;
    }

    private ProgramType convertToProgramType(Integer registerManner) {
        BrandCampaignRegisterMannerEnum registerMannerEnum = BrandCampaignRegisterMannerEnum.getByCode(registerManner);
        AssertUtil.notNull(registerMannerEnum, String.format("registerManner=%s不能为空", registerManner));
        switch (registerMannerEnum) {
            case GUARANTEE:
                return ProgramType.GD;
            case PDB:
                return ProgramType.PDB;
            case ANTI_GUARANTEE:
            case PD:
                return ProgramType.PD;
        }
        return null;
    }

    private UnitEnum convertToBookingUnit(Integer sspRegisterUnit, Integer sspMediaScope) {
        UnitEnum saleUnit = convertToSaleUnit(sspRegisterUnit);
        if ((saleUnit == UnitEnum.ROUND || saleUnit == UnitEnum.DAY)
                && MediaScopeEnum.SITE_OUT.getCode().equals(sspMediaScope)) {
            //三环按轮或者CPT售卖场景需要按照CPM预定
            return UnitEnum.CPM;
        } else {
            return saleUnit;
        }
    }

    private UnitEnum convertToSaleUnit(Integer sspRegisterUnit) {
        BrandCampaignRegisterUnitEnum unitEnum = BrandCampaignRegisterUnitEnum.getByCode(sspRegisterUnit);
        switch (unitEnum) {
            case CPM:
                return UnitEnum.CPM;
            case ROUND:
                return UnitEnum.ROUND;
            case SECTION:
                return UnitEnum.TIME_SLOT;
            case CPV:
                return UnitEnum.CPV;
            case DAY:
                return UnitEnum.DAY;
            case CPC:
                return UnitEnum.CPC;
            case CPA:
                return UnitEnum.CPA;
            case JUMP:
            case COLLECTION:
            case PIECE:
                AssertUtil.notNull(null, String.format("售卖方式，type=%s", sspRegisterUnit));
        }
        return null;
    }

    private TargetType convertToInventoryTargetType(String type) {
        AssertUtil.notNull(type, String.format("定向类型为空，type=%s", type));
        BrandTargetTypeEnum targetTypeEnum = BizTargetToolsHelper.getByCode(Integer.parseInt(type));
        AssertUtil.notNull(targetTypeEnum, String.format("定向类型不存在，type=%s", type));
        switch (targetTypeEnum) {
            case AREA:
            case AREA_MEDIA:
                return TargetType.AREA;
            case AGE_PLUS:
                return TargetType.CROWD_AGE;
            case GENDER_PLUS:
                return TargetType.CROWD_GENDER;
            case MODEL:
                return TargetType.MODEL;
            case NEW_DEVICE:
            case DEVICE_MEDIA:
                return TargetType.DEVICE;
            case TIME_PLUS:
            case TIME_PLUS_MEDIA:
                return TargetType.HOUR_SLOT;
            case CHANNEL:
                return TargetType.CHANNEL;
            case PRECEDENCE:
            case POSITION_PLUS_MEDIA:
                return TargetType.PRECEDENCE;
            case ALI_CROWD_SCORE:
                return TargetType.ALI_CROWD_SCORE;
            case SHOW_BUY_CATEGORY:
                return TargetType.SHOW_BUY_CATEGORY;
            case SPLASH_AD_SEQ:
                return TargetType.SPLASH_AD_SEQ;
            default:
                return null;
        }
    }

    private ReleaseType convertToReleaseType(Integer inquiryAssignType) {
        if (inquiryAssignType == null) {
            return ReleaseType.INTELLECT;
        }
        BrandCampaignInquiryAssignTypeEnum assignTypeEnum = BrandCampaignInquiryAssignTypeEnum.getByCode(inquiryAssignType);
        AssertUtil.notNull(assignTypeEnum, String.format("区间类型不存在，assignType=%s", inquiryAssignType));
        switch (assignTypeEnum) {
            case BY_DAY:
            case PERIOD:
                return ReleaseType.AVERAGE;
            case PERIOD_PART_INTELLIGENCE:
            case INTELLIGENCE:
                return ReleaseType.INTELLECT;
            default:
                return null;
        }
    }

    private SceneType convertToSceneType(Integer saleType) {
        BrandSaleTypeEnum saleTypeEnum = BrandSaleTypeEnum.getByCode(saleType);
        AssertUtil.notNull(saleTypeEnum, String.format("场景类型不存在，saleTypeEnum=%s", saleType));
        switch (saleTypeEnum) {
            case BUY:
                return SceneType.BUY;
            case BOOST:
                return SceneType.COMPENSATE;
            case PRESENT:
                return SceneType.GIVE;
            default:
                return null;
        }
    }

    private FrequencyInfo getFrequencyInfo(FrequencyViewDTO frequencyViewDTO, CampaignScheduleViewDTO scheduleViewDTO) {
        if (frequencyViewDTO == null) {
            return null;
        }
        FrequencyInfo frequencyInfo = new FrequencyInfo();
        frequencyInfo.setFrequencyId(frequencyViewDTO.getId());
        Integer onlineStatus = frequencyViewDTO.getOnlineStatus();
        if (!BrandBoolEnum.BRAND_TRUE.getCode().equals(onlineStatus)) {
            return null;
        }
        List<FrequencyRule> frequencyRules = Lists.newArrayList();
        for (FrequencyRuleViewDTO frequencyRuleViewDTO : frequencyViewDTO.getFrequencyRuleViewDTOList()) {
            if (!BrandBoolEnum.BRAND_TRUE.getCode().equals(frequencyRuleViewDTO.getStatus())) {
                continue;
            }
            FrequencyRule frequencyRule = new FrequencyRule();
            frequencyRule.setLimit(frequencyRuleViewDTO.getFreqLimit());
            frequencyRule.setPeriod(frequencyRuleViewDTO.getFreqPeriod());
            frequencyRule.setType(FrequencyType.IMPRESSION);
            frequencyRules.add(frequencyRule);
        }
        if (CollectionUtils.isEmpty(frequencyRules)) {
            return null;
        }
        frequencyInfo.setFrequencyRules(frequencyRules);
        if (MapUtils.isNotEmpty(scheduleViewDTO.getMediaScopeBudgetRatioMap())) {
            List<MediaComposition> mediaCompositions = Lists.newArrayList();
            for (Map.Entry<Integer, Integer> entry : scheduleViewDTO.getMediaScopeBudgetRatioMap().entrySet()) {
                InventoryScope inventoryScope = convertToInventoryScope(entry.getKey());
                if (inventoryScope == null) {
                    continue;
                }
                MediaComposition mediaComposition = new MediaComposition();
                mediaComposition.setScope(inventoryScope);
                mediaComposition.setRatio((double) entry.getValue() / 10000);
                mediaCompositions.add(mediaComposition);
            }
            frequencyInfo.setMediaCompositions(mediaCompositions);
        }
        return frequencyInfo;
    }

    private InventoryScope convertToInventoryScope(Integer mediaScope) {
        if (MediaScopeEnum.SITE_OUT.getCode().equals(mediaScope)) {
            return InventoryScope.RING_THREE;
        } else if (MediaScopeEnum.TAO_OUT.getCode().equals(mediaScope)) {
            return InventoryScope.RING_TWO;
        } else {
            return null;
        }
    }

    public UniReleaseRequest convertToReleaseRequest(CampaignViewDTO campaignViewDTO) {
        UniReleaseRequest request = new UniReleaseRequest();
        request.setReleaseOption(ReleaseOption.SPECIFIED_DATES);
//        CampaignBaseViewDTO campaignBaseViewDTO = campaignViewDTO.getCampaignBaseViewDTO();
        request.setBusinessId(campaignViewDTO.getId());
        request.setMemberId(campaignViewDTO.getMemberId());
        request.setSspProductId(campaignViewDTO.getCampaignResourceViewDTO().getSspProductId());
        request.setSourceApp(InventorySourceAppEnum.BRAND_ONE_BP);

        List<CampaignInquiryViewDTO> inquiryViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignInquiryLockViewDTO()).map(CampaignInquiryLockViewDTO::getCampaignInquiryViewDTOList).orElse(Lists.newArrayList());
        Date deadlineDate = inquiryDeadline(campaignViewDTO.getCampaignSaleViewDTO().getSaleType(), inquiryViewDTOList, campaignViewDTO.getCampaignInquiryLockViewDTO().getFirstOnlineTime());
        List<ReleaseSlot> releaseSlots = Lists.newArrayList();
        if (CollectionUtils.isNotEmpty(inquiryViewDTOList)) {
            for (CampaignInquiryViewDTO inquiryViewDTO : inquiryViewDTOList) {
                if (inquiryViewDTO == null) {
                    continue;
                }
                if (BrandDateUtil.isAfterAndEqual(inquiryViewDTO.getDate(), deadlineDate)) {
                    ReleaseSlot releaseSlot = new ReleaseSlot();
                    releaseSlot.setDate(inquiryViewDTO.getDate());
                    releaseSlots.add(releaseSlot);
                }
            }
        }
        request.setReleaseSlots(releaseSlots);
        //天攻计划增加天攻计划ID传参
        fillDoohInfo(request,campaignViewDTO);
        RogerLogger.info("UniReleaseRequest={}", JSON.toJSONString(request));
        return request;
    }

    public UniRequest convertToCancelRequest(CampaignViewDTO campaignViewDTO) {
        UniRequest request = new UniRequest();
        request.setBusinessId(campaignViewDTO.getId());
        request.setMemberId(campaignViewDTO.getMemberId());
        request.setSspProductId(campaignViewDTO.getCampaignResourceViewDTO().getSspProductId());
        request.setSourceApp(InventorySourceAppEnum.BRAND_ONE_BP);
        return request;
    }

    private Date inquiryDeadline(Integer saleType, List<CampaignInquiryViewDTO> inquiryViewDTOList, Date firstOnlineTime) {
        //补量计划在投放中不能释当天
        inquiryViewDTOList = inquiryViewDTOList == null ? Lists.newArrayList() : inquiryViewDTOList;
        long count = inquiryViewDTOList.stream().filter(
                v -> v.getDate().equals(BrandDateUtil.getCurrentDate()) && BrandInquiryStatusEnum.SUCCESS.getCode().equals(v.getStatus())).count();
        boolean online = firstOnlineTime != null;
        Date deadlineDate = (!NumberUtil.greaterThanZero(count) || !online) && BizCampaignToolsHelper.isBoostOrPresent(saleType) ? BrandDateUtil
                .getCurrentDate() : BrandDateUtil.getTomorrowDate();
        return deadlineDate;
    }

    public InventoryUdInquiryDTO.InquiryResourceDTO convertInventoryUdInquiryDTO(CampaignViewDTO campaignViewDTO) {
        InventoryUdInquiryDTO.InquiryResourceDTO inquiryResourceDTO = new InventoryUdInquiryDTO.InquiryResourceDTO();
        // 填充属性
        // businessId
        inquiryResourceDTO.setBusinessId(campaignViewDTO.getId());
        // positionId
        if (CollectionUtils.isNotEmpty(campaignViewDTO.getCampaignResourceViewDTO().getSspResourceIds())) {
            inquiryResourceDTO.setResourceId(campaignViewDTO.getCampaignResourceViewDTO().getSspResourceIds().get(0));
        }

        return inquiryResourceDTO;
    }


    public ServiceContext buildServiceContext(CampaignViewDTO campaignViewDTO) {
        ServiceContext serviceContext = new ServiceContext();
        serviceContext.setOperType(BaseServiceContext.OPERTYPE_INNER_OPT);
        serviceContext.setMemberId(campaignViewDTO.getMemberId());
        serviceContext.setBizCode(ServiceContextUtil.getBizCode(campaignViewDTO.getSceneId()));
        serviceContext.setProductLineId(Product.BRAND_ONEBP_BRAND.getProductLineId());
        return serviceContext;
    }

    private void fillDoohInfo(UniRequest request, CampaignViewDTO campaignViewDTO){
        if(BizCampaignToolsHelper.isDoohCampaign(campaignViewDTO.getCampaignResourceViewDTO().getSspProductLineId())){
            Map<String, Object> extensions = request.getExtensions();
            if(extensions == null){
                extensions = Maps.newHashMap();
            }
            extensions.put(DOOH_CAMPAIGN_ID, campaignViewDTO.getCampaignDoohViewDTO().getDoohCampaignId());
            if(BrandDateUtil.isBeforeAndEqual(campaignViewDTO.getStartTime(), BrandDateUtil.getCurrentDate()) && campaignViewDTO.getCampaignInquiryLockViewDTO().getFirstOnlineTime() != null){
                extensions.put(IS_DOOH_RELEASE, false);
            }else{
                extensions.put(IS_DOOH_RELEASE, true);
            }
            request.setExtensions(extensions);
        }
    }
}
