package com.taobao.ad.brand.bp.adapter.port.repository.uic;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.uic.UicSAO;
import com.taobao.ad.brand.bp.client.dto.creative.MemberPageCheckViewDTO;
import com.taobao.ad.brand.bp.domain.uic.UicRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * @Author: PhilipFry
 * @createTime: 2025年03月11日 15:50:45
 * @Description:
 */

@Repository
@RequiredArgsConstructor(onConstructor_ = @Autowired)
public class UicRepositoryImpl implements UicRepository {

    private final UicSAO uicSAO;

    private final String TAG_CODE = "tb_limit_business";

    @Override
    public boolean checkTag(Long sellerId, String tagCode) {
        try {
            return uicSAO.checkTag(sellerId, tagCode);
        } catch (Exception e) {
            RogerLogger.error("queryCheckTag error. sellerId={}", sellerId, e);
            return false;
        }
    }

    @Override
    /**
     * 在落地页类型中选择了【会员】选项后，需要校验下列情况
     * 1.商家是否开通会员体系
     * 2.商家入会是否未被冻结
     */
    public MemberPageCheckViewDTO memberPageCheck(ServiceContext serviceContext, Long sellerId) {
        boolean memberCheck = uicSAO.memberCheck(sellerId);
        boolean notFreezeCheck = notFreezeCheck(sellerId);

        MemberPageCheckViewDTO memberPageCheckViewDTO = new MemberPageCheckViewDTO();
        memberPageCheckViewDTO.setMemberCheck(memberCheck);
        memberPageCheckViewDTO.setNotFreezeCheck(notFreezeCheck);
        return memberPageCheckViewDTO;
    }

    /**
     * 商家入会是否未被冻结
     *
     * @param sellerId
     * @return
     */
    public boolean notFreezeCheck(Long sellerId) {
        try {
            boolean checkTag = uicSAO.checkTag(sellerId, TAG_CODE);
            return !checkTag;
        } catch (Exception e) {
            RogerLogger.error("queryCheckTag error. sellerId={}", sellerId, e);
            return false;
        }
    }
}
