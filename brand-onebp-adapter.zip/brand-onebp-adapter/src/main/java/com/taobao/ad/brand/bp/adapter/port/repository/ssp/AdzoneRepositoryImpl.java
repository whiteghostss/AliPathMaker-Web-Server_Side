package com.taobao.ad.brand.bp.adapter.port.repository.ssp;

import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.adzone.AdzoneSAO;
import com.taobao.ad.brand.bp.client.dto.product.AdzoneViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ResourceScheduleViewDTO;
import com.taobao.ad.brand.bp.domain.ssp.AdzoneRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * adzone相关
 * @author 弈云
 * @date 2023年04月04日
 * */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AdzoneRepositoryImpl implements AdzoneRepository {

    private final AdzoneSAO adzoneSAO;

    @Override
    public List<AdzoneViewDTO> getAdzoneListByAdzoneIds(List<Long> adzoneIds) {
        List<AdzoneViewDTO> adzoneViewDTOList = adzoneSAO.findAdzoneByAdzoneIds(adzoneIds);
        return adzoneViewDTOList;
    }

    @Override
    public List<AdzoneViewDTO> selectAdzoneByUserId(List<Long> memberIds, List<String> userIds) {
        List<AdzoneViewDTO> adzoneViewDTOList = adzoneSAO.selectAdzoneByUserId(memberIds, userIds);
        return adzoneViewDTOList;
    }


}
