package com.taobao.ad.brand.bp.adapter.message;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.rocketmq.client.producer.SendResult;
import com.alibaba.rocketmq.common.message.Message;
import com.taobao.metaq.client.MetaProducer;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.UUID;

@Component
public class MetaQSendProcessor implements InitializingBean {
    private static final Log logger = LogFactory.getLog(MetaQSendProcessor.class);

//    @Value("${operation.metaq3.group}")
    private String group;
//
//    @Value("${operation.metaq3.topic}")
    private String topic;

    private MetaProducer producer;

    @Override
    public void afterPropertiesSet() throws Exception {
//        logger.info("metaQ3 send message 开始加载");
//        logger.info("metaQ3 group = " + group);
//        logger.info("metaQ3 topic = " + topic);
//        producer = new MetaProducer(group);
//        producer.start();
//        logger.info("metaQ3 send message 加载成功");
    }

    public void send(String code, Long memberId, Object ext) {
        LogInfo4Manatee logInfo4Manatee = new LogInfo4Manatee();
        logInfo4Manatee.setCode(code);
        logInfo4Manatee.setExt(ext);
        logInfo4Manatee.setMemberId(memberId);
        logInfo4Manatee.setSendDate(new Date());
        send(logInfo4Manatee.getCode(), JSONObject.toJSONString(logInfo4Manatee), UUID.randomUUID().toString());
    }

    public void send(String code, Long memberId, Object ext, Object id) {
        LogInfo4Manatee logInfo4Manatee = new LogInfo4Manatee();
        logInfo4Manatee.setCode(code);
        logInfo4Manatee.setExt(ext);
        logInfo4Manatee.setMemberId(memberId);
        logInfo4Manatee.setSendDate(new Date());
        send(logInfo4Manatee.getCode(), JSONObject.toJSONString(logInfo4Manatee), code + id);
    }

    private void send(String tag, String msgStr, String key) {
        try {
            Message msg = new Message(topic, tag, key, msgStr.getBytes("UTF-8"));
            SendResult sendResult = producer.send(msg);
        } catch (Exception e) {
            logger.error("send fast message error", e);
        }
    }

    public SendResult send(String topic, String tag, String msgStr, String key) {
        SendResult sendResult = null;
        try {
            Message msg = new Message(topic, tag, key, msgStr.getBytes("UTF-8"));
            sendResult = producer.send(msg);
        } catch (Exception e) {
            logger.error("send fast message error", e);
        }
        return sendResult;
    }

    public SendResult send(String topic, String tag, String key, byte[] msgContent) {
        SendResult sendResult = null;
        try {
            Message msg = new Message(topic, tag, key, msgContent);
            sendResult = producer.send(msg);
        } catch (Exception e) {
            logger.error("send fast message error", e);
        }
        return sendResult;
    }
}
