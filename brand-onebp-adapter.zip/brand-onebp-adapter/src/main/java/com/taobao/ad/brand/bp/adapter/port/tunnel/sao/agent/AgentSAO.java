package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.agent;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.ai.client.api.LlmAgentDirectCallService;
import com.alibaba.ad.brand.ai.client.dto.LlmAgentDirectCallParam;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author jx.lj
 * @date 2025/4/17 16:55
 * @desc
 */
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class AgentSAO extends BaseSAO {
    private final LlmAgentDirectCallService llmAgentDirectCallService;

    public String directCall(ServiceContext serviceContext, LlmAgentDirectCallParam callParam) {
        SingleResponse<String> response = llmAgentDirectCallService.call(serviceContext, callParam);
        AssertUtil.assertTrue(response.isSuccess(), response.getErrorCode(), response.getErrorMsg());
        return response.getResult();
    }
}
