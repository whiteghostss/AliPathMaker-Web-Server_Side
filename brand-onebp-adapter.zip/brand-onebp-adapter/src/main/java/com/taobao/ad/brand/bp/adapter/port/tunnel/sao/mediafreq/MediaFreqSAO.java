package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.mediafreq;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.sdk.constant.media.field.BrandMediaFreqBizTypeEnum;
import com.alibaba.ad.organizer.api.media.MediaFrequencyCommandService;
import com.alibaba.ad.organizer.api.media.MediaFrequencyQueryService;
import com.alibaba.ad.organizer.dto.media.MediaFrequencyDTO;
import com.alibaba.ad.organizer.dto.media.MediaFrequencyRefDTO;
import com.alibaba.ad.organizer.dto.query.MediaFrequencyQuery;
import com.alibaba.ad.organizer.dto.query.MediaFrequencyRefQuery;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.alibaba.solar.common.query.dto.PageQueryDTO;
import com.alibaba.solar.common.query.dto.QueryDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.mediafreq.query.MediaFreqQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.mediarule.MediaRuleQueryEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class MediaFreqSAO extends BaseSAO {

    private final MediaFrequencyCommandService mediaFrequencyCommandService;
    private final MediaFrequencyQueryService mediaFrequencyQueryService;

    public Long addMediaFreq(ServiceContext serviceContext, MediaFrequencyDTO mediaFrequencyDTO) {
        SingleResponse<Long> response = mediaFrequencyCommandService.addMediaFreq(serviceContext, mediaFrequencyDTO);
        AssertUtil.assertTrue(response.isSuccess(),response.getErrorMsg());
        return response.getResult();
    }

    public Integer updateMediaFreq(ServiceContext serviceContext, MediaFrequencyDTO mediaFrequencyDTO) {
        SingleResponse<Integer> response = mediaFrequencyCommandService.updateMediaFreqAll(serviceContext, mediaFrequencyDTO);
        AssertUtil.assertTrue(response.isSuccess(),response.getErrorMsg());
        return response.getResult();
    }

    public Integer updateMediaFreqStatus(ServiceContext serviceContext, List<Long> mediaFreqIds, Integer status) {
        SingleResponse<Integer> response = mediaFrequencyCommandService.updateMediaFreqStatusBatch(serviceContext, mediaFreqIds,status);
        AssertUtil.assertTrue(response.isSuccess(),response.getErrorMsg());
        return response.getResult();
    }

    public MediaFrequencyDTO getMediaFreq(ServiceContext serviceContext, Long id) {
        QueryDTO queryDTO = QueryDTO.createQuery().andCondition(MediaFrequencyQuery.id.eq(id));
        MultiResponse<MediaFrequencyDTO> response = mediaFrequencyQueryService.findMediaFreqList(serviceContext, queryDTO);
        AssertUtil.assertTrue(response.isSuccess(),response.getErrorMsg());
        if(CollectionUtils.isEmpty(response.getResult())){
            return null;
        }
        return response.getResult().get(0);
    }

    public PageResultViewDTO<MediaFrequencyDTO> findListWithPage(ServiceContext serviceContext, MediaFreqQueryViewDTO queryViewDTO) {
        if(CollectionUtils.isNotEmpty(queryViewDTO.getPidList())){
            List<Long> mediaFreqIdList = queryMediaFreqByPid(serviceContext, queryViewDTO.getPidList());
            if(CollectionUtils.isEmpty(mediaFreqIdList)){
                return PageResultViewDTO.empty();
            }
            queryViewDTO.setIds(mediaFreqIdList);
        }
        MultiResponse<MediaFrequencyDTO> response = mediaFrequencyQueryService.findMediaFreqPage(serviceContext,initPageQueryDTO(queryViewDTO));
        AssertUtil.assertTrue(response.isSuccess(), response.getErrorMsg());
        List<MediaFrequencyDTO> frequencyDTOList = response.getResult();
        if(CollectionUtils.isNotEmpty(frequencyDTOList)){
            List<Long> freqIdList = frequencyDTOList.stream().map(MediaFrequencyDTO::getId).collect(Collectors.toList());
            List<MediaFrequencyRefDTO> mediaFreqRefList = findMediaFreqRefList(serviceContext, freqIdList);
            Map<Long, List<MediaFrequencyRefDTO>> freqGroupMap = Optional.ofNullable(mediaFreqRefList).orElse(Lists.newArrayList()).stream().collect(Collectors.groupingBy(MediaFrequencyRefDTO::getMediaFrequencyId));
            for (MediaFrequencyDTO mediaFrequencyDTO : frequencyDTOList) {
                mediaFrequencyDTO.setFrequencyRefList(freqGroupMap.get(mediaFrequencyDTO.getId()));
            }
        }
        return PageResultViewDTO.of(frequencyDTOList, response.getTotal());
    }

    public List<MediaFrequencyDTO> findList(ServiceContext serviceContext, MediaFreqQueryViewDTO queryViewDTO) {
        if(CollectionUtils.isNotEmpty(queryViewDTO.getPidList())){
            List<Long> mediaFreqIdList = queryMediaFreqByPid(serviceContext, queryViewDTO.getPidList());
            if(CollectionUtils.isEmpty(mediaFreqIdList)){
                return Lists.newArrayList();
            }
            queryViewDTO.setIds(mediaFreqIdList);
        }
        MultiResponse<MediaFrequencyDTO> response = mediaFrequencyQueryService.findMediaFreqList(serviceContext, initQueryDTO(queryViewDTO));
        AssertUtil.assertTrue(response.isSuccess(), response.getErrorMsg());
        List<MediaFrequencyDTO> frequencyDTOList = response.getResult();
        if(CollectionUtils.isNotEmpty(frequencyDTOList)){
            List<Long> freqIdList = frequencyDTOList.stream().map(MediaFrequencyDTO::getId).collect(Collectors.toList());
            List<MediaFrequencyRefDTO> mediaFreqRefList = findMediaFreqRefList(serviceContext, freqIdList);
            Map<Long, List<MediaFrequencyRefDTO>> freqGroupMap = Optional.ofNullable(mediaFreqRefList).orElse(Lists.newArrayList()).stream().collect(Collectors.groupingBy(MediaFrequencyRefDTO::getMediaFrequencyId));
            for (MediaFrequencyDTO mediaFrequencyDTO : frequencyDTOList) {
                mediaFrequencyDTO.setFrequencyRefList(freqGroupMap.get(mediaFrequencyDTO.getId()));
            }
        }
        return frequencyDTOList;
    }

    /**
     * 根据名称查询媒体频控
     * @param serviceContext
     * @param uniqueName
     * @return
     */
    public MediaFrequencyDTO getTopOneByName(ServiceContext serviceContext, String uniqueName) {
        QueryDTO queryDTO = QueryDTO.createQuery().andCondition(MediaFrequencyQuery.name.eq(uniqueName));
        MultiResponse<MediaFrequencyDTO> response = mediaFrequencyQueryService.findMediaFreqList(serviceContext, queryDTO);
        AssertUtil.assertTrue(response.isSuccess(), response.getErrorMsg());
        return CollectionUtils.isNotEmpty(response.getResult()) ? response.getResult().get(0) : null;
    }

    /**
     * 根据频控id查询关联信息
     * @param context
     * @param freqIdList
     * @return
     */
    private List<MediaFrequencyRefDTO> findMediaFreqRefList(ServiceContext context,List<Long> freqIdList) {
        QueryDTO queryDTO = QueryDTO.createQuery();
        queryDTO.andCondition(MediaFrequencyRefQuery.mediaFrequencyId.in(freqIdList));
        MultiResponse<MediaFrequencyRefDTO> response = mediaFrequencyQueryService.findMediaFreqRefList(context, queryDTO);
        AssertUtil.assertTrue(response);
        return response.getResult();
    }

    /**
     * 根据pid查询媒体频控配置
     * @param context
     * @param pidList
     * @return
     */
    private List<Long> queryMediaFreqByPid(ServiceContext context,List<String> pidList) {
        QueryDTO queryDTO = QueryDTO.createQuery();
        queryDTO.andCondition(MediaFrequencyRefQuery.bizType.eq(BrandMediaFreqBizTypeEnum.PID.getCode()));
        queryDTO.andCondition(MediaFrequencyRefQuery.bizId.in(pidList));
        MultiResponse<MediaFrequencyRefDTO> response = mediaFrequencyQueryService.findMediaFreqRefList(context, queryDTO);
        AssertUtil.assertTrue(response);
        return Optional.ofNullable(response.getResult()).orElse(Lists.newArrayList())
                .stream().map(MediaFrequencyRefDTO::getMediaFrequencyId).distinct().collect(Collectors.toList());
    }

    private PageQueryDTO initPageQueryDTO(MediaFreqQueryViewDTO queryViewDTO) {
        PageQueryDTO pageQueryDTO = PageQueryDTO.createQuery(queryViewDTO.getStart(), queryViewDTO.getPageSize());
        initQueryDTO(queryViewDTO,pageQueryDTO);
        return pageQueryDTO;
    }

    private QueryDTO initQueryDTO(MediaFreqQueryViewDTO queryViewDTO) {
        QueryDTO queryDTO = QueryDTO.createQuery();
        initQueryDTO(queryViewDTO,queryDTO);
        return queryDTO;
    }

    private void initQueryDTO(MediaFreqQueryViewDTO queryViewDTO, QueryDTO queryDTO) {
        if (CollectionUtils.isNotEmpty(queryViewDTO.getIds())) {
            queryDTO.andCondition(MediaFrequencyQuery.id.in(queryViewDTO.getIds()));
        }
        if (Objects.nonNull(queryViewDTO.getStatus())) {
            queryDTO.andCondition(MediaFrequencyQuery.status.eq(queryViewDTO.getStatus()));
        }
        if (Objects.nonNull(queryViewDTO.getFreqBiz())) {
            queryDTO.andCondition(MediaFrequencyQuery.freqBiz.eq(queryViewDTO.getFreqBiz()));
        }
        if (Objects.nonNull(queryViewDTO.getStartTime())) {
            queryDTO.andCondition(MediaFrequencyQuery.endTime.gtEq(queryViewDTO.getStartTime()));
        }
        if (Objects.nonNull(queryViewDTO.getEndTime())) {
            queryDTO.andCondition(MediaFrequencyQuery.startTime.ltEq(queryViewDTO.getEndTime()));
        }
        if (Objects.nonNull(queryViewDTO.getKeyword())) {
            queryDTO.andCondition(MediaFrequencyQuery.name.like(queryViewDTO.getKeyword()));
        }
        // 排序
        queryDTO.orderBy(MediaFrequencyQuery.gmtModified.descOrder());
    }

}
