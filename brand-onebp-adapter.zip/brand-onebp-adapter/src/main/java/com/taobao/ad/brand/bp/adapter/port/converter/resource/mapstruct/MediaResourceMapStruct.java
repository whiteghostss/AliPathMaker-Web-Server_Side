package com.taobao.ad.brand.bp.adapter.port.converter.resource.mapstruct;

import com.alibaba.uad.wto.dto.resource.MediaResourceDTO;
import com.taobao.ad.brand.bp.client.dto.resource.MediaResourceViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author jixiu.lj
 * @date 2023/3/29 17:51
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface MediaResourceMapStruct extends BaseMapStructMapper<MediaResourceDTO, MediaResourceViewDTO> {
    MediaResourceMapStruct INSTANCE = Mappers.getMapper(MediaResourceMapStruct.class);

}
