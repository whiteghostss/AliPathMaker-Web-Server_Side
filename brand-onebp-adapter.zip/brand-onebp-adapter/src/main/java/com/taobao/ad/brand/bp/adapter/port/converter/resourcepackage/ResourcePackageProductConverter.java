package com.taobao.ad.brand.bp.adapter.port.converter.resourcepackage;

import com.alibaba.ad.nb.packages.v2.client.dto.product.ResourcePackageProductDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.salegroup.ResourcePackageSaleGroupDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.template.ResourcePackageTemplateDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.adapter.port.converter.resourcepackage.mapstruct.ResourcePackageProductMapStruct;
import com.taobao.ad.brand.bp.adapter.port.converter.resourcepackage.mapstruct.ResourcePackageSaleGroupMapStruct;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourceDistributionRuleViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageTemplateViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/25
 */
@Component
public class ResourcePackageProductConverter extends BaseViewDTOConverter<ResourcePackageProductDTO, ResourcePackageProductViewDTO> {

    @Override
    public BaseMapStructMapper<ResourcePackageProductDTO, ResourcePackageProductViewDTO> getBaseMapStructMapper() {
        return ResourcePackageProductMapStruct.INSTANCE;
    }


}
