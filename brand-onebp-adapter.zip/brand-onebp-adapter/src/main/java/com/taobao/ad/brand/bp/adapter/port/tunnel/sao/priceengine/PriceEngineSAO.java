package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.priceengine;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.audience.CampaignTargetViewDTO;
import com.alibaba.ad.brand.dto.campaign.audience.CampaignTargetScenarioViewDTO;
import com.alibaba.ad.brand.dto.campaign.frequence.CampaignFrequencyViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.frequency.FrequencyRuleViewDTO;
import com.alibaba.ad.brand.dto.frequency.FrequencyViewDTO;
import com.alibaba.ad.brand.sdk.constant.audience.field.BrandTargetTypeEnum;
import com.alibaba.ad.nb.price.api.engine.PriceEngineService;
import com.alibaba.ad.nb.price.dto.engine.PublishPriceDTO;
import com.alibaba.ad.nb.price.dto.engine.query.PriceQueryDTO;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.adapter.port.converter.priceengine.resourcepackage.PublishPriceConverter;
import com.taobao.ad.brand.bp.client.dto.campaign.PriceEnginePublishPriceViewDTO;
import com.taobao.ad.brand.bp.common.helper.campaign.BizTargetToolsHelper;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandLocalDateTimeUtil;
import com.taobao.ad.brand.bp.common.util.NumberUtil;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

@Component
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class PriceEngineSAO extends BaseSAO {
    private final PriceEngineService  priceEngineService;
    private final PublishPriceConverter publishPriceConverter;

    public List<PriceEnginePublishPriceViewDTO> getPublishPrice(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO,
        CampaignGroupViewDTO campaignGroup ) {
        PriceQueryDTO priceQueryDTO = getPriceQueryDTO(campaignViewDTO,campaignGroup);
        //Long customerMemberId = Optional.ofNullable(campaignGroup.getExtViewDTO()).map(CampaignGroupExtViewDTO::getCustomerMemberId).orElse(null);
//        MultiResponse<PublishPriceDTO> response =  priceEngineService.getPublishPrice(customerMemberId, priceQueryDTO);
        MultiResponse<PublishPriceDTO> response =  priceEngineService.getPublishPrice(null, priceQueryDTO);
        AssertUtil.assertTrue(response);
        return publishPriceConverter.convertDTO2ViewDTOList(response.getResult());
    }

    @NotNull
    private PriceQueryDTO getPriceQueryDTO(CampaignViewDTO campaignViewDTO, CampaignGroupViewDTO campaignGroup) {
        PriceQueryDTO priceQueryDTO = new PriceQueryDTO();
        priceQueryDTO.setPublishProductId(campaignViewDTO.getCampaignPriceViewDTO().getPublishProductId());
        Date orderDate;
        if (campaignGroup != null) {
            orderDate = campaignGroup.getGmtCreate();
        } else if (campaignViewDTO.getGmtCreate() != null) {
            orderDate = campaignViewDTO.getGmtCreate();
        } else {
            orderDate = new Date();
        }
        priceQueryDTO.setOrderDate(orderDate);
        priceQueryDTO.setCastStartDate(campaignViewDTO.getStartTime());
        priceQueryDTO.setCastEndDate(campaignViewDTO.getEndTime());
        priceQueryDTO.setResourceTypeList(campaignViewDTO.getCampaignResourceViewDTO().getSspResourceTypes().stream().map(String::valueOf).collect(Collectors.toList()));
        priceQueryDTO.setChargeUnit(String.valueOf(campaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterUnit()));
        List<Map<String, Date>> detailCastDateList = Lists.newArrayList();
        priceQueryDTO.setDetailCastDateList(detailCastDateList);
        Map<String, Date> map = Maps.newHashMap();
        map.put(PriceQueryDTO.CAST_DATE_KEY_START, campaignViewDTO.getStartTime());
        map.put(PriceQueryDTO.CAST_DATE_KEY_END, campaignViewDTO.getEndTime());
        detailCastDateList.add(map);

        List<CampaignTargetViewDTO> campaignTargetViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignTargetScenarioViewDTO())
                .map(CampaignTargetScenarioViewDTO::getCampaignTargetViewDTOList).orElse(Lists.newArrayList());
        if (CollectionUtils.isNotEmpty(campaignTargetViewDTOList)) {
            for (CampaignTargetViewDTO campaignTargetViewDTO : campaignTargetViewDTOList) {
                if(campaignTargetViewDTO == null || campaignTargetViewDTO.getType() == null){
                    continue;
                }
                BrandTargetTypeEnum  brandTargetTypeEnum = BizTargetToolsHelper.getByCode(Integer.parseInt(campaignTargetViewDTO.getType()));
                AssertUtil.assertTrue(brandTargetTypeEnum != null,"未找到定向类型");
                if(BrandTargetTypeEnum.MEDIA_CROWD.equals(brandTargetTypeEnum)){
                    //魔法值由价格中心确认！0 代表有值就加收
                    priceQueryDTO.setProperty(brandTargetTypeEnum.getKey(), "0");
                } else if (BrandTargetTypeEnum.AGE_PLUS.equals(brandTargetTypeEnum)) {
                    // 年龄需要获取范围内的所有值
                    Set<Integer> ageSet = campaignTargetViewDTO.getTargetValues().stream().flatMap(item -> NumberUtil.getRangeNums(item, "-").stream()).collect(Collectors.toSet());
                    String ageStr = ageSet.stream().map(String::valueOf).collect(Collectors.joining(","));
                    priceQueryDTO.setProperty(brandTargetTypeEnum.getKey(), ageStr);
                } else if (BrandTargetTypeEnum.TIME_PLUS.equals(brandTargetTypeEnum) || BrandTargetTypeEnum.TIME_PLUS_MEDIA.equals(brandTargetTypeEnum)) {
                    priceQueryDTO.setProperty(brandTargetTypeEnum.getKey(), StringUtils.join(
                            BrandLocalDateTimeUtil.getBetweenHourResult(campaignTargetViewDTO.getTargetValues(), true), ","));
                } else {
                    priceQueryDTO.setProperty(brandTargetTypeEnum.getKey(), StringUtils.join(campaignTargetViewDTO.getTargetValues(), ","));
                }

            }
        }
        FrequencyViewDTO frequencyViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignFrequencyViewDTO()).map(CampaignFrequencyViewDTO::getFrequencyViewDTO).orElse(null);
        if (frequencyViewDTO != null && frequencyViewDTO.getFrequencyRuleViewDTOList() != null) {
            List<FrequencyRuleViewDTO> frequencyRuleViewDTOList = frequencyViewDTO.getFrequencyRuleViewDTOList();
            if(CollectionUtils.isNotEmpty(frequencyRuleViewDTOList)){
                Set<String> frequencySet =  frequencyRuleViewDTOList.stream().map(item->item.getFreqPeriod()+"_"+item.getFreqLimit()).collect(Collectors.toSet());
                priceQueryDTO.setProperty(PriceQueryDTO.NEW_ATTR_KEY_FREQUENCY,StringUtils.join(frequencySet,","));
            }
        }

        if(campaignViewDTO.getCampaignGuaranteeViewDTO().getSspPushSendRatio() != null){
            priceQueryDTO.setProperty(PriceQueryDTO.NEW_ATTR_TYPE_PUSH_PERCENTAGE,String.valueOf(
                campaignViewDTO.getCampaignGuaranteeViewDTO().getSspPushSendRatio()/100));
        }

        if(campaignViewDTO.getCampaignInquiryLockViewDTO().getPdType() != null){
            priceQueryDTO.setProperty(PriceQueryDTO.NEW_ATTR_TYPE_SALE_TYPE,String.valueOf(
                campaignViewDTO.getCampaignInquiryLockViewDTO().getPdType()));
        }

        if(campaignViewDTO.getCampaignCreativeControllerViewDTO().getTimeLength() != null){
            priceQueryDTO.setProperty(PriceQueryDTO.NEW_ATTR_TYPE_TIME_LENGTH,String.valueOf(
                campaignViewDTO.getCampaignCreativeControllerViewDTO().getTimeLength()));
        }
        return priceQueryDTO;
    }


    /**
     * *获取指定排期内最高的刊例价-会将所有加收内容都计算在内
     *
     * @param customerId
     * @param priceQueryDTO
     * @return
     */
    public List<PriceEnginePublishPriceViewDTO> getAdditionPublishPrice(Long customerId, PriceQueryDTO priceQueryDTO) {
        MultiResponse<PublishPriceDTO> response = priceEngineService.getAdditionPublishPrice(customerId, priceQueryDTO);
        AssertUtil.assertTrue(response);
        return publishPriceConverter.convertDTO2ViewDTOList(response.getResult());
    }

}