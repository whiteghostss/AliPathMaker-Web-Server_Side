package com.taobao.ad.brand.bp.adapter.port.repository.campaigngroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.biz.definition.constants.Product;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.setting.BrandCampaignGroupSettingKeyEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleGroupBudgetSettingTypeEnum;
import com.alibaba.ad.brand.sdk.convert.custom.viewdto.CampaignGroupSaleGroupViewDTO2DTOConvertProcessor;
import com.alibaba.ad.brand.sdk.convert.custom.viewdto.CampaignGroupViewDTO2DTOConvertProcessor;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupBusinessLineEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleProductLineEnum;
import com.alibaba.ad.organizer.dto.CampaignGroupDTO;
import com.alibaba.ad.organizer.dto.SaleGroupDTO;
import com.alibaba.ad.organizer.dto.query.CampaignGroupQuery;
import com.alibaba.ad.organizer.dto.query.SaleGroupQuery;
import com.alibaba.ad.universal.sdk.convert.custom.onebp.provider.OneBpConvertProcessorProvider;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.solar.common.query.dto.PageQueryDTO;
import com.alibaba.solar.common.query.dto.QueryDTO;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.campaigngroup.CampaignGroupSAO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignGroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.SaleGroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.shop.ShopViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupContractMemberTypeEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.PageUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.feed.FeedRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.*;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.common.util.PageUtil.getTotalPage;

@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CampaignGroupRepositoryImpl implements CampaignGroupRepository {
    private final CampaignGroupSAO campaignGroupSAO;
    private CampaignGroupViewDTO2DTOConvertProcessor PROCESSOR = OneBpConvertProcessorProvider.getViewDTO2DTOConvertProcessor(CampaignGroupViewDTO2DTOConvertProcessor.class);
    private CampaignGroupSaleGroupViewDTO2DTOConvertProcessor SALE_GROUP_PROCESSOR = OneBpConvertProcessorProvider.getViewDTO2DTOConvertProcessor(CampaignGroupSaleGroupViewDTO2DTOConvertProcessor.class);

    private final FeedRepository feedRepository;

    @Override
    public PageResultViewDTO<CampaignGroupViewDTO> findCampaignGroupPageList(ServiceContext context, CampaignGroupQueryViewDTO campaignGroupQueryViewDTO) {
        PageQueryDTO pageQueryDTO = (PageQueryDTO) initCampaignGroupQueryDTO(context, campaignGroupQueryViewDTO, true);
        MultiResponse<CampaignGroupDTO> multiResponse = campaignGroupSAO.findCampaignGroupPageList(context, pageQueryDTO);
        return PageResultViewDTO.of(dtoList2ViewDTOList(context,multiResponse.getResult()), multiResponse.getTotal());
    }

    @Override
    public List<CampaignGroupViewDTO> findCampaignGroupByIds(ServiceContext context, List<Long> ids) {
        if (CollectionUtils.isEmpty(ids)) {
            return Lists.newArrayList();
        }
        QueryDTO queryDTO = QueryDTO.createQuery(CampaignGroupQuery.id.in(ids));
        queryDTO.andCondition(CampaignGroupQuery.status.notEq(BrandCampaignGroupStatusEnum.DELETED.getCode()));
        List<CampaignGroupDTO> campaignGroupDTOList = campaignGroupSAO.findCampaignGroupList(context, queryDTO);
        return dtoList2ViewDTOList(context,campaignGroupDTOList);
    }

    @Override
    public List<CampaignGroupViewDTO> findSubCampaignGroupList(ServiceContext context, Long mainCampaignGroupId) {
        return findSubCampaignGroupList(context, mainCampaignGroupId, null);
    }

    @Override
    public List<CampaignGroupViewDTO> findSubCampaignGroupList(ServiceContext context, Long mainCampaignGroupId, List<Integer> sceneIds) {
        AssertUtil.notNull(mainCampaignGroupId, "主订单ID不能为空");
        QueryDTO queryDTO = initSubCampaignGroupQueryDTO(mainCampaignGroupId, sceneIds);
        List<CampaignGroupDTO> campaignGroupDTOList = campaignGroupSAO.findCampaignGroupList(context, queryDTO);
        return dtoList2ViewDTOList(context,campaignGroupDTOList);
    }

    private QueryDTO initSubCampaignGroupQueryDTO(Long mainCampaignGroupId, List<Integer> sceneIds) {
        QueryDTO queryDTO = QueryDTO.createQuery();
        queryDTO.andCondition(CampaignGroupQuery.parentId.eq(mainCampaignGroupId));
        queryDTO.andCondition(CampaignGroupQuery.campaignGroupLevel.eq(BrandCampaignGroupLevelEnum.LEVEL_TWO.getCode()));
        queryDTO.andCondition(CampaignGroupQuery.status.notEq(BrandCampaignGroupStatusEnum.DELETED.getCode()));
        if (CollectionUtils.isNotEmpty(sceneIds)) {
            queryDTO.andCondition(CampaignGroupQuery.sceneId.in(sceneIds));
        }
        return queryDTO;
    }

    @Override
    public List<CampaignGroupViewDTO> findCampaignGroupList(ServiceContext context, CampaignGroupQueryViewDTO campaignGroupQueryViewDTO){
        campaignGroupQueryViewDTO.setPageNo(1);
        campaignGroupQueryViewDTO.setPageSize(200);
        List<CampaignGroupViewDTO> campaignGroupViewDTOList = Lists.newArrayList();
        PageUtil.execute(idx -> {
                    campaignGroupQueryViewDTO.setPageNo(idx);
                    PageQueryDTO pageQueryDTO = (PageQueryDTO) initCampaignGroupQueryDTO(context, campaignGroupQueryViewDTO, true);
                    return campaignGroupSAO.findCampaignGroupPageList(context, pageQueryDTO);
                },
                resp -> getTotalPage(resp.getTotal(), campaignGroupQueryViewDTO.getPageSize()),
                resp -> {
                    if (resp != null) {
                        campaignGroupViewDTOList.addAll(dtoList2ViewDTOList(context, resp.getResult()));
                    }
                });
        return campaignGroupViewDTOList;
//        QueryDTO queryDTO = initCampaignGroupQueryDTO(context, campaignGroupQueryViewDTO, false);
//        List<CampaignGroupDTO> campaignGroupDTOList = campaignGroupSAO.findCampaignGroupList(context, queryDTO);
//        return dtoList2ViewDTOList(context,campaignGroupDTOList);
    }

    private List<CampaignGroupViewDTO> dtoList2ViewDTOList(ServiceContext context, List<CampaignGroupDTO> campaignGroupDTOList) {
        if (CollectionUtils.isEmpty(campaignGroupDTOList)) {
            return Lists.newArrayList();
        }
        List<CampaignGroupViewDTO> campaignGroupViewDTOList = PROCESSOR.dtoList2ViewDTOList(campaignGroupDTOList);
        fillCampaignGroupSaleGroup(context,campaignGroupViewDTOList);
        return campaignGroupViewDTOList;
    }

    @Override
    public CampaignGroupViewDTO getCampaignGroup(ServiceContext serviceContext, Long id) {
        if (id == null) {
            return null;
        }
        CampaignGroupDTO campaignGroup = campaignGroupSAO.getCampaignGroup(serviceContext, id);
        if (Objects.isNull(campaignGroup) || BrandCampaignGroupStatusEnum.DELETED.getCode().equals(campaignGroup.getStatus())) {
            return null;
        }
        CampaignGroupViewDTO campaignGroupViewDTO = PROCESSOR.dto2ViewDTO(campaignGroup);
        fillCampaignGroupSaleGroup(serviceContext,Lists.newArrayList(campaignGroupViewDTO));
        return campaignGroupViewDTO;
    }

    @Override
    public Integer updateCampaignGroupPart(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO) {
        CampaignGroupDTO campaignGroupDTO = PROCESSOR.viewDTO2DTO(campaignGroupViewDTO);
        return campaignGroupSAO.updateCampaignGroupPart(serviceContext, campaignGroupDTO);
    }

    @Override
    public Long addCampaignGroup(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO) {
        CampaignGroupDTO campaignGroupDTO = PROCESSOR.viewDTO2DTO(campaignGroupViewDTO);
        Long id = campaignGroupSAO.addCampaignGroup(serviceContext, campaignGroupDTO);
        campaignGroupViewDTO.setId(id);
        return id;
    }

    @Override
    public Integer updateCampaignGroupSettingPartBatch(ServiceContext serviceContext, Long campaignGroupId, Map<String, String> settingMap) {
        if (MapUtils.isEmpty(settingMap)) {
            return 0;
        }
        return campaignGroupSAO.updateCampaignGroupSettingPartBatch(serviceContext, campaignGroupId, settingMap);
    }

    @Override
    public Integer deleteCampaignGroup(ServiceContext serviceContext, Long id) {
        return campaignGroupSAO.deleteCampaignGroup(serviceContext, id);
    }

    @Override
    public Integer deleteCampaignGroupSettingBatch(ServiceContext serviceContext, Long campaignGroupId, List<String> settingKeyList) {
        if (CollectionUtils.isEmpty(settingKeyList)) {
            return 0;
        }
        return campaignGroupSAO.deleteCampaignGroupSettingBatch(serviceContext, campaignGroupId, settingKeyList);
    }

    @Override
    public Integer addSaleGroup(ServiceContext serviceContext, List<SaleGroupInfoViewDTO> saleGroupViewDTOList) {
        if(CollectionUtils.isEmpty(saleGroupViewDTOList)){
            return 0;
        }
        List<SaleGroupDTO> saleGroupList = saleGroupViewDTOList.stream()
                .peek(this::setDefaultValue)
                .map(saleGroupViewDTO -> SALE_GROUP_PROCESSOR.viewDTO2DTO(saleGroupViewDTO))
                .collect(Collectors.toList());
        return campaignGroupSAO.addSaleGroup(serviceContext, saleGroupList);
    }
    private  void setDefaultValue(SaleGroupInfoViewDTO saleGroupInfoViewDTO){
        if(saleGroupInfoViewDTO.getSaleProductLine() == null){
            saleGroupInfoViewDTO.setSaleProductLine(SaleProductLineEnum.UNIDESK_BRAND.getValue());
        }
        if(saleGroupInfoViewDTO.getSaleBusinessLine() == null){
            saleGroupInfoViewDTO.setSaleBusinessLine(SaleGroupBusinessLineEnum.BRAND_AD.getValue());
        }
        //预算设置类型，默认：1-按比例设置
        if(saleGroupInfoViewDTO.getBudgetSettingType() == null){
            saleGroupInfoViewDTO.setBudgetSettingType(BrandSaleGroupBudgetSettingTypeEnum.RATIO.getCode());
        }
    }

    @Override
    public Integer addOrUpdateSaleGroupPart(ServiceContext serviceContext, Long campaignGroupId, List<SaleGroupInfoViewDTO> saleGroupViewDTOList) {
        if(CollectionUtils.isEmpty(saleGroupViewDTOList)){
            return 0;
        }
        //查询数据表中已有的订单售卖分组
        SaleGroupQueryViewDTO saleGroupQueryViewDTO = new SaleGroupQueryViewDTO();
        saleGroupQueryViewDTO.setCampaignGroupIds(Collections.singletonList(campaignGroupId));
        saleGroupQueryViewDTO.setSaleGroupIds(saleGroupViewDTOList.stream()
                .map(SaleGroupInfoViewDTO::getSaleGroupId).collect(Collectors.toList()));
        List<SaleGroupInfoViewDTO> dbSaleGroupList = this.findSaleGroupList(serviceContext, saleGroupQueryViewDTO);
        // Map<资源包卖分组：订单售卖分组id>
        Map<Long, Long> dbSaleGroupMap = Optional.ofNullable(dbSaleGroupList).orElse(Lists.newArrayList()).stream().collect(
                Collectors.toMap(SaleGroupInfoViewDTO::getSaleGroupId, SaleGroupInfoViewDTO::getId, (v1, v2) -> v2));

        List<SaleGroupDTO> saleGroupList = saleGroupViewDTOList.stream()
                .peek(saleGroupViewDTO -> {
                    saleGroupViewDTO.setId(dbSaleGroupMap.get(saleGroupViewDTO.getSaleGroupId()));
                    saleGroupViewDTO.setCampaignGroupId(campaignGroupId);
                })
                .map(saleGroupViewDTO -> SALE_GROUP_PROCESSOR.viewDTO2DTO(saleGroupViewDTO))
                .collect(Collectors.toList());

        // add分组
        List<SaleGroupDTO> addList = saleGroupList.stream().filter(saleGroupDTO -> Objects.isNull(saleGroupDTO.getId()))
                .collect(Collectors.toList());
        Integer count = 0;
        if(CollectionUtils.isNotEmpty(addList)){
            Integer group = campaignGroupSAO.addSaleGroup(serviceContext, addList);
            count += group;
        }

        // update分组
        List<SaleGroupDTO> updateList = saleGroupList.stream().filter(saleGroupDTO -> Objects.nonNull(saleGroupDTO.getId()))
                .collect(Collectors.toList());
        if(CollectionUtils.isNotEmpty(updateList)){
            Integer group = campaignGroupSAO.updateSaleGroupPart(serviceContext,updateList);
            count += group;
        }
        return count;
    }

    @Override
    public Integer updateSaleGroupPart(ServiceContext serviceContext, List<SaleGroupInfoViewDTO> saleGroupViewDTOList) {
        if(CollectionUtils.isEmpty(saleGroupViewDTOList)){
            return 0;
        }
        saleGroupViewDTOList.forEach(saleGroupInfoViewDTO -> AssertUtil.notNull(saleGroupInfoViewDTO.getId(), "分组id不能为空"));
        List<SaleGroupDTO> saleGroupList = saleGroupViewDTOList.stream()
                .map(saleGroupViewDTO -> SALE_GROUP_PROCESSOR.viewDTO2DTO(saleGroupViewDTO))
                .collect(Collectors.toList());
        return campaignGroupSAO.updateSaleGroupPart(serviceContext, saleGroupList);
    }

    @Override
    public Integer bindAllSaleGroup(ServiceContext serviceContext,Long campaignGroupId, List<SaleGroupInfoViewDTO> saleGroupViewDTOList){
        if(CollectionUtils.isEmpty(saleGroupViewDTOList)){
            return 0;
        }
        List<SaleGroupDTO> saleGroupList = saleGroupViewDTOList.stream()
                .peek(saleGroupViewDTO -> {
                    saleGroupViewDTO.setCampaignGroupId(campaignGroupId);
                    setDefaultValue(saleGroupViewDTO);
                })
                .map(saleGroupViewDTO -> SALE_GROUP_PROCESSOR.viewDTO2DTO(saleGroupViewDTO))
                .collect(Collectors.toList());
        return campaignGroupSAO.rebindAllSaleGroup(serviceContext,campaignGroupId,saleGroupList);
    }

    @Override
    public Integer deleteSaleGroup(ServiceContext serviceContext,List<Long> campaignGroupSaleGroupIdList){
        if (CollectionUtils.isEmpty(campaignGroupSaleGroupIdList)) {
            return 0;
        }
        return campaignGroupSAO.deleteSaleGroup(serviceContext,campaignGroupSaleGroupIdList);
    }

    @Override
    public Integer deleteSaleGroupByCampaignGroupId(ServiceContext serviceContext, Long campaignGroupId) {
        if (campaignGroupId == null) {
            return 0;
        }
        return campaignGroupSAO.deleteSaleGroupByCampaignGroupId(serviceContext, campaignGroupId);
    }

    @Override
    public SaleGroupInfoViewDTO getSaleGroup(ServiceContext serviceContext,Long campaignGroupId,Long resourceSaleGroupId){
        SaleGroupQueryViewDTO saleGroupQueryViewDTO = new SaleGroupQueryViewDTO();
        saleGroupQueryViewDTO.setCampaignGroupIds(Collections.singletonList(campaignGroupId));
        saleGroupQueryViewDTO.setSaleGroupIds(Collections.singletonList(resourceSaleGroupId));
        List<SaleGroupInfoViewDTO> saleGroupList = this.findSaleGroupList(serviceContext, saleGroupQueryViewDTO);
        return CollectionUtils.isNotEmpty(saleGroupList) ? saleGroupList.get(0) : null;
    }
//    @Override
//    public SaleGroupInfoViewDTO getSaleGroup(ServiceContext serviceContext,Long resourceSaleGroupId){
//        SaleGroupQueryViewDTO saleGroupQueryViewDTO = new SaleGroupQueryViewDTO();
//        saleGroupQueryViewDTO.setSaleGroupIds(Collections.singletonList(resourceSaleGroupId));
//        List<SaleGroupInfoViewDTO> saleGroupList = this.findSaleGroupList(serviceContext, saleGroupQueryViewDTO);
//        return CollectionUtils.isNotEmpty(saleGroupList) ? saleGroupList.get(0) : null;
//    }
    @Override
    public List<SaleGroupInfoViewDTO> findSaleGroupList(ServiceContext serviceContext, SaleGroupQueryViewDTO saleGroupQueryViewDTO) {
        List<SaleGroupDTO> saleGroupList = doFindSaleGroupList(serviceContext, saleGroupQueryViewDTO);
        return Optional.ofNullable(saleGroupList).orElse(Lists.newArrayList()).stream()
                .map(saleGroupViewDTO -> SALE_GROUP_PROCESSOR.dto2ViewDTO(saleGroupViewDTO)).collect(Collectors.toList());
    }

    private List<SaleGroupDTO> doFindSaleGroupList(ServiceContext serviceContext, SaleGroupQueryViewDTO saleGroupQueryViewDTO) {
        QueryDTO queryDTO = initSaleGroupQueryDTO(saleGroupQueryViewDTO);
        return campaignGroupSAO.findSaleGroupList(serviceContext, queryDTO);
    }

    @Override
    public Integer updateSaleGroupAll(ServiceContext serviceContext,List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList){
        List<SaleGroupDTO> saleGroupList = saleGroupInfoViewDTOList.stream()
                .map(saleGroupViewDTO -> SALE_GROUP_PROCESSOR.viewDTO2DTO(saleGroupViewDTO))
                .collect(Collectors.toList());
        return campaignGroupSAO.updateSaleGroupAll(serviceContext, saleGroupList);
    }

    @Override
    public ShopViewDTO getShopInfoByCampaignGroupId(ServiceContext serviceContext, Long campaignGroupId) {
        ShopViewDTO shopViewDTO = new ShopViewDTO();
        CampaignGroupViewDTO campaignGroupViewDTO = this.getCampaignGroup(serviceContext, campaignGroupId);
        //代投或叉乘账号
        if (campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getContractMemberType().equals(CampaignGroupContractMemberTypeEnum.XMEMBER.getCode())
                || campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getContractMemberType().equals(CampaignGroupContractMemberTypeEnum.PROXY.getCode())) {
            shopViewDTO = feedRepository.getShopInfoByMemberId(campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getCustomerMemberId());
        } else if (campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getContractMemberType().equals(CampaignGroupContractMemberTypeEnum.CUSTOMER.getCode())) {
            //直客账号
            shopViewDTO = feedRepository.getShopInfoByMemberId(serviceContext.getMemberId());
        }
        return shopViewDTO;
    }


    private QueryDTO initSaleGroupQueryDTO(SaleGroupQueryViewDTO queryViewDTO) {
        QueryDTO queryDTO = QueryDTO.createQuery();
        if (CollectionUtils.isNotEmpty(queryViewDTO.getCampaignGroupIds())) {
            queryDTO.andCondition(SaleGroupQuery.campaignGroupId.in(queryViewDTO.getCampaignGroupIds()));
        }
        if (CollectionUtils.isNotEmpty(queryViewDTO.getSaleGroupIds())) {
            queryDTO.andCondition(SaleGroupQuery.resourceSaleGroupId.in(queryViewDTO.getSaleGroupIds()));
        }
        if (CollectionUtils.isNotEmpty(queryViewDTO.getMainSaleGroupIds())) {
            queryDTO.andCondition(SaleGroupQuery.mainResourceSaleGroupId.in(queryViewDTO.getMainSaleGroupIds()));
        }
        if (Objects.nonNull(queryViewDTO.getSaleType())) {
            queryDTO.andCondition(SaleGroupQuery.saleType.eq(queryViewDTO.getSaleType()));
        }
        if (Objects.nonNull(queryViewDTO.getSubContractId())) {
            queryDTO.andCondition(SaleGroupQuery.subContractId.eq(queryViewDTO.getSubContractId()));
        }
        if (Objects.nonNull(queryViewDTO.getSource())) {
            queryDTO.andCondition(SaleGroupQuery.source.eq(queryViewDTO.getSource()));
        }
        if (Objects.nonNull(queryViewDTO.getSaleGroupStatus())) {
            queryDTO.andCondition(SaleGroupQuery.orderStatus.eq(queryViewDTO.getSaleGroupStatus()));
        }
        if (CollectionUtils.isNotEmpty(queryViewDTO.getSaleProductLineList())) {
            queryDTO.andCondition(SaleGroupQuery.saleProductLine.in(queryViewDTO.getSaleProductLineList()));
        }
        queryDTO.orderBy(SaleGroupQuery.id.descOrder());

        return queryDTO;
    }

    private QueryDTO initCampaignGroupQueryDTO(ServiceContext context, CampaignGroupQueryViewDTO queryViewDTO, boolean needPage) {
        QueryDTO queryDTO = needPage ? PageQueryDTO.createQuery(queryViewDTO.getStart(), queryViewDTO.getPageSize()) : QueryDTO.createQuery();
        // 分组ID、售卖产品线时
        if (CollectionUtils.isNotEmpty(queryViewDTO.getSaleGroupIds()) || CollectionUtils.isNotEmpty(queryViewDTO.getSaleProductLineList())) {
            queryViewDTO.setIds(mergeCampaignGroupQueryIds(context, queryViewDTO));
        }

        if (Objects.nonNull(queryViewDTO.getId())) {
            queryDTO.andCondition(CampaignGroupQuery.id.eq(queryViewDTO.getId()));
        }
        if (CollectionUtils.isNotEmpty(queryViewDTO.getIds())) {
            queryDTO.andCondition(CampaignGroupQuery.id.in(queryViewDTO.getIds()));
        }
        if (CollectionUtils.isNotEmpty(queryViewDTO.getNotIds())) {
            queryDTO.andCondition(CampaignGroupQuery.id.notIn(queryViewDTO.getNotIds()));
        }
        if (StringUtils.isNotBlank(queryViewDTO.getName())) {
            queryDTO.andCondition(CampaignGroupQuery.name.like(queryViewDTO.getName()));
        }
        // 名称全匹配查询
        if (StringUtils.isNotBlank(queryViewDTO.getFullName())) {
            queryDTO.andCondition(CampaignGroupQuery.name.eq(queryViewDTO.getFullName()));
        }
        if (CollectionUtils.isNotEmpty(queryViewDTO.getStatusList())) {
            queryDTO.andCondition(CampaignGroupQuery.status.in(queryViewDTO.getStatusList()));
        }
        if (CollectionUtils.isNotEmpty(queryViewDTO.getNoInStatusList())) {
            List<Integer> noInStatusList = Lists.newArrayList(queryViewDTO.getNoInStatusList());
            noInStatusList.add(BrandCampaignGroupStatusEnum.DELETED.getCode());
            noInStatusList.add(BrandCampaignGroupStatusEnum.DRAFT.getCode());
            queryDTO.andCondition(CampaignGroupQuery.status.notIn(noInStatusList));
        }
        if (CollectionUtils.isEmpty(queryViewDTO.getStatusList()) && CollectionUtils.isEmpty(queryViewDTO.getNoInStatusList())) {
            queryDTO.andCondition(CampaignGroupQuery.status.notIn(BrandCampaignGroupStatusEnum.DELETED.getCode(), BrandCampaignGroupStatusEnum.DRAFT.getCode()));
        }
        if (Objects.nonNull(queryViewDTO.getStartTime())) {
            queryDTO.andCondition(CampaignGroupQuery.endTime.gtEq(queryViewDTO.getStartTime()));
        }
        if (Objects.nonNull(queryViewDTO.getEndTime())) {
            Date queryEndTime = BrandDateUtil.getDateFullMidnight(queryViewDTO.getEndTime());
            queryDTO.andCondition(CampaignGroupQuery.startTime.ltEq(queryEndTime));
        }
        if (Objects.nonNull(queryViewDTO.getParentId())) {
            queryDTO.andCondition(CampaignGroupQuery.parentId.eq(queryViewDTO.getParentId()));
        }

        if (BizCodeEnum.BRANDONEBP.getBizCode().equals(context.getBizCode())) {
            if (CollectionUtils.isNotEmpty(queryViewDTO.getSceneIds())) {
                queryDTO.andCondition(CampaignGroupQuery.sceneId.in(queryViewDTO.getSceneIds()));
            } else if (queryViewDTO.getCampaignGroupLevel() != null && BrandCampaignGroupLevelEnum.LEVEL_TWO.getCode().equals(queryViewDTO.getCampaignGroupLevel())) {
                queryDTO.andCondition(CampaignGroupQuery.sceneId.notEq(ServiceContextUtil.getSceneId(BizCodeEnum.BRANDONEBP.getBizCode())));
            } else {
                context.setProductId(Product.BRAND_ONEBP_BRAND.getId());
//                queryDTO.andCondition(CampaignGroupQuery.sceneId.eq(ServiceContextUtil.getSceneId(BizCodeEnum.BRANDONEBP.getBizCode())));
            }
        } else {
            Integer sceneId = ServiceContextUtil.getSceneId(context);
            // 场景如果传入以传入的为准，否则以context中为准
            if (sceneId != null) {
                queryDTO.andCondition(CampaignGroupQuery.sceneId.eq(sceneId));
            } else if (CollectionUtils.isNotEmpty(queryViewDTO.getSceneIds())) {
                queryDTO.andCondition(CampaignGroupQuery.sceneId.in(queryViewDTO.getSceneIds()));
            } else {
                queryDTO.andCondition(CampaignGroupQuery.sceneId.notEq(ServiceContextUtil.getSceneId(BizCodeEnum.BRANDONEBP.getBizCode())));
            }
        }
        // 客户模板ID
        if (Objects.nonNull(queryViewDTO.getCustomerTemplateId())) {
            queryDTO.andCondition(CampaignGroupQuery.settingKeyValue.eq(BrandCampaignGroupSettingKeyEnum.CUSTOMER_TEMPLATE_ID.getKey(), String.valueOf(queryViewDTO.getCustomerTemplateId())));
        }
        if (CollectionUtils.isNotEmpty(queryViewDTO.getNotInCustomerTemplateIds())) {
            queryDTO.andCondition(CampaignGroupQuery.settingKeyValue.notIn(BrandCampaignGroupSettingKeyEnum.CUSTOMER_TEMPLATE_ID.getKey()
                    , queryViewDTO.getNotInCustomerTemplateIds().stream().map(String::valueOf).collect(Collectors.toList())));
        }
        if (CollectionUtils.isNotEmpty(queryViewDTO.getCustomerTemplateIds())) {
            queryDTO.andCondition(CampaignGroupQuery.settingKeyValue.in(BrandCampaignGroupSettingKeyEnum.CUSTOMER_TEMPLATE_ID.getKey()
                    , queryViewDTO.getCustomerTemplateIds().stream().map(String::valueOf).collect(Collectors.toList())));
        }
        // 主合同ID
        if (Objects.nonNull(queryViewDTO.getContractId())) {
            queryDTO.andCondition(CampaignGroupQuery.settingKeyValue.eq(BrandCampaignGroupSettingKeyEnum.CONTRACT_ID.getKey(), String.valueOf(queryViewDTO.getContractId())));
        }
        if (Objects.nonNull(queryViewDTO.getCampaignGroupLevel())) {
            queryDTO.andCondition(CampaignGroupQuery.campaignGroupLevel.eq(queryViewDTO.getCampaignGroupLevel()));
        }
        if (Objects.nonNull(queryViewDTO.getBriefId())) {
            queryDTO.andCondition(CampaignGroupQuery.settingKeyValue.eq(BrandCampaignGroupSettingKeyEnum.BRIEF_ID.getKey(), String.valueOf(queryViewDTO.getBriefId())));
        }
        if (CollectionUtils.isNotEmpty(queryViewDTO.getTalentConfigStatusList())) {
//            // 单选时的临时解决方案 如需支持多选 则需要填充订单默认值
//            if (queryViewDTO.getTalentConfigStatusList().size() == 1 && queryViewDTO.getTalentConfigStatusList().get(0).equals(TalentConfigStatusEnum.UN_CONFIGURED.getValue())) {
//                queryDTO.andCondition(CampaignGroupQuery.settingKeyValue.notIn(BrandCampaignGroupSettingKeyEnum.TALENT_CONFIG_STATUS.getKey(),
//                        Arrays.asList(String.valueOf(TalentConfigStatusEnum.CONFIGURED.getValue()), String.valueOf(TalentConfigStatusEnum.PARTIAL_CONFIGURED.getValue()))));
//            } else {
                queryDTO.andCondition(CampaignGroupQuery.settingKeyValue.in(BrandCampaignGroupSettingKeyEnum.TALENT_CONFIG_STATUS.getKey(),
                        queryViewDTO.getTalentConfigStatusList().stream().map(String::valueOf).collect(Collectors.toList())));
//            }
        }
        //允许盘量的订单
        if (Objects.nonNull(queryViewDTO.getLeInquiryDate())) {
            queryDTO.andCondition(CampaignGroupQuery.settingKeyValue.ltEq(BrandCampaignGroupSettingKeyEnum.INQUIRY_DATE.getKey(),
                    BrandDateUtil.date2String(queryViewDTO.getLeInquiryDate(), BrandDateUtil.DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_1)));
        }

        // 排序
        queryDTO.orderBy(CampaignGroupQuery.gmtCreate.descOrder());

        return queryDTO;
    }

    /**
     * 填充订单售卖分组
     * @param serviceContext
     * @param campaignGroupViewDTOList
     */
    private void fillCampaignGroupSaleGroup(ServiceContext serviceContext,List<CampaignGroupViewDTO> campaignGroupViewDTOList){
        List<Long> campaignGroupIds= campaignGroupViewDTOList.stream().map(campaignGroupViewDTO -> campaignGroupViewDTO.getId()).collect(Collectors.toList());
        SaleGroupQueryViewDTO saleGroupQueryViewDTO = new SaleGroupQueryViewDTO();
        saleGroupQueryViewDTO.setCampaignGroupIds(campaignGroupIds);
        List<SaleGroupInfoViewDTO> saleGroupList = this.findSaleGroupList(serviceContext, saleGroupQueryViewDTO);
        Map<Long, List<SaleGroupInfoViewDTO>> saleGroupMap = Optional.ofNullable(saleGroupList).orElse(Lists.newArrayList())
                .stream().collect(Collectors.groupingBy(SaleGroupInfoViewDTO::getCampaignGroupId));

        for (CampaignGroupViewDTO campaignGroupViewDTO : campaignGroupViewDTOList) {
            List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList =
                    saleGroupMap.getOrDefault(campaignGroupViewDTO.getId(), Lists.newArrayList());
            campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().setSaleGroupInfoViewDTOList(saleGroupInfoViewDTOList);
        }
    }

    private List<Long> mergeCampaignGroupQueryIds(ServiceContext context, CampaignGroupQueryViewDTO queryViewDTO) {
        SaleGroupQueryViewDTO saleGroupQueryViewDTO = new SaleGroupQueryViewDTO();
        saleGroupQueryViewDTO.setSaleGroupIds(queryViewDTO.getSaleGroupIds());
        saleGroupQueryViewDTO.setSaleProductLineList(queryViewDTO.getSaleProductLineList());
        List<SaleGroupDTO> saleGroupList = this.doFindSaleGroupList(context, saleGroupQueryViewDTO);
        if (CollectionUtils.isEmpty(saleGroupList)) {
            return Lists.newArrayList(-1L);
        }
        List<Long> ids = saleGroupList.stream().map(SaleGroupDTO::getCampaignGroupId).distinct().collect(Collectors.toList());
        if (CollectionUtils.isEmpty(queryViewDTO.getIds())) {
            return ids;
        }
        // 取交集，无交集时返回-1
        ids.retainAll(queryViewDTO.getIds());
        RogerLogger.info("DLH ids={},saleGroupList.size={},queryViewDTO.getIds={}", ids, saleGroupList.size(), queryViewDTO.getIds());
        if (CollectionUtils.isNotEmpty(ids)) {
            return ids;
        }
        return Lists.newArrayList(-1L);
    }

}
