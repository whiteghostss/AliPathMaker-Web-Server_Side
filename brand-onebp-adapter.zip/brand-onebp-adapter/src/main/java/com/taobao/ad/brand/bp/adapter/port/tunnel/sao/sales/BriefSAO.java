package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.sales;

import java.util.Map;

import com.alibaba.ad.nb.sales.api.brief.BriefCommandService;
import com.alibaba.ad.nb.sales.api.brief.BriefQueryService;
import com.alibaba.ad.nb.sales.api.face.BriefService;
import com.alibaba.ad.nb.sales.dto.brief.BriefDTO;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;

import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;

import lombok.RequiredArgsConstructor;

/**
 * @author yanjingang
 * @date 2023/3/9
 */
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BriefSAO extends SalesBaseSAO {

    private final BriefQueryService briefQueryService;
    private final BriefCommandService briefCommandService;
    private final BriefService briefService;

    /**
     * 同步信息&更新Brief状态
     *
     * @param briefId
     */
    public BriefDTO getBrief(Long briefId) {
        AssertUtil.assertTrue(briefId != null, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "查询Brief时BriefId不能为空");
        SingleResponse<BriefDTO> singleResponse = briefQueryService.getSimpleBrief(createNbServiceContext(), briefId);
        AssertUtil.assertTrue(singleResponse.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, singleResponse.getErrorMsg());
        AssertUtil.assertTrue(singleResponse.getResult() != null, BrandOneBPBaseErrorCode.RPC_ERROR, "未查询到brief");
        return singleResponse.getResult();
    }

    /**
     * 同步信息&更新Brief状态
     *
     * @param briefDTO
     */
    public void acceptStatusEvent(BriefDTO briefDTO) {
        AssertUtil.assertTrue(briefDTO != null, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "同步至Brief的信息不能为空");
        SingleResponse<BriefDTO> singleResponse = briefCommandService.acceptStatusEvent(createNbServiceContext(), briefDTO);
        AssertUtil.assertTrue(singleResponse.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, singleResponse.getErrorMsg());
    }

    public boolean canModify(Long briefId) {
        AssertUtil.assertTrue(briefId != null, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "briefId不能为空");
        SingleResponse<Map<Long, Boolean>> singleResponse = briefService.canModify(createNbServiceContext(), Lists.newArrayList(briefId));
        AssertUtil.assertTrue(singleResponse.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, singleResponse.getErrorMsg());
        AssertUtil.assertTrue(MapUtils.isNotEmpty(singleResponse.getResult()), BrandOneBPBaseErrorCode.RPC_ERROR, "Brief是否支持修改结果返回错误");
        return singleResponse.getResult().get(briefId);
    }

    public void modifyBrief(Long briefId) {
        AssertUtil.assertTrue(briefId != null, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "briefId不能为空");
        Response response = briefService.modifyBrief(createNbServiceContext(), briefId);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, response.getErrorMsg());
    }

}
