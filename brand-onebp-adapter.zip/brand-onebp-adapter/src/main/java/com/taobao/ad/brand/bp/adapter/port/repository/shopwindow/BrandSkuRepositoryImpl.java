package com.taobao.ad.brand.bp.adapter.port.repository.shopwindow;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.adapter.port.converter.shopwindow.BrandBundleViewDTOConverter;
import com.taobao.ad.brand.bp.adapter.port.converter.shopwindow.BrandSkuViewDTOConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.perform.PerformSAO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandBundleViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSkuViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.query.BrandBundleQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.query.BrandSkuQueryViewDTO;
import com.taobao.ad.brand.bp.domain.shopwindow.repository.BrandSkuRepository;
import com.taobao.ad.brand.perform.client.dto.shopwindow.bundle.BundleQueryViewDTO;
import com.taobao.ad.brand.perform.client.dto.shopwindow.bundle.BundleViewDTO;
import com.taobao.ad.brand.perform.client.dto.shopwindow.sku.SkuViewDTO;
import com.taobao.ad.brand.perform.client.dto.shopwindow.spu.SkuQueryViewDTO;
import com.taobao.ad.brand.perform.client.enums.shopwindow.BundleStatusEnum;
import com.taobao.ad.brand.perform.client.enums.shopwindow.SkuStatusEnum;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/6/26
 **/
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSkuRepositoryImpl implements BrandSkuRepository {

    private final PerformSAO performSAO;
    private final BrandSkuViewDTOConverter brandSkuViewDTOConverter;
    private final BrandBundleViewDTOConverter brandBundleViewDTOConverter;

    @Override
    public List<BrandSkuViewDTO> findSkuList(ServiceContext serviceContext, BrandSkuQueryViewDTO brandSkuQueryViewDTO) {
        SkuQueryViewDTO skuQueryViewDTO = brandSkuViewDTOConverter.sourceToQueryTarget(brandSkuQueryViewDTO);
        List<SkuViewDTO> skuList = performSAO.findSkuList(skuQueryViewDTO);
        return brandSkuViewDTOConverter.convertDTO2ViewDTOList(skuList);
    }

    @Override
    public List<BrandSkuViewDTO> findSkuList(ServiceContext serviceContext, List<Long> skuIds) {
        if(CollectionUtils.isEmpty(skuIds)){
            return Lists.newArrayList();
        }
        List<Integer> allStatusList = Arrays.stream(SkuStatusEnum.values()).map(SkuStatusEnum::getCode).collect(Collectors.toList());
        BrandSkuQueryViewDTO queryViewDTO = BrandSkuQueryViewDTO.builder().idList(skuIds).statusList(allStatusList).build();
        queryViewDTO.setPageSize(skuIds.size());
        return this.findSkuList(serviceContext,queryViewDTO);
    }

    @Override
    public BrandSkuViewDTO get(ServiceContext serviceContext, Long id) {
        SkuQueryViewDTO skuQueryViewDTO = new SkuQueryViewDTO();
        skuQueryViewDTO.setIdList(Lists.newArrayList(id));
        SkuViewDTO skuViewDTO = performSAO.getSkuDetail(skuQueryViewDTO);
        return brandSkuViewDTOConverter.convertDTO2ViewDTO(skuViewDTO);
    }

    @Override
    public BrandBundleViewDTO getBundleDetail(ServiceContext serviceContext, Long bundleId) {
        BundleQueryViewDTO bundleQueryViewDTO = new BundleQueryViewDTO();
        bundleQueryViewDTO.setId(bundleId);
        bundleQueryViewDTO.setStatusList(Arrays.stream(BundleStatusEnum.values()).map(BundleStatusEnum::getCode).collect(Collectors.toList()));
        BundleViewDTO bundleViewDTO = performSAO.getBundleDetail(serviceContext, bundleQueryViewDTO);
        return brandBundleViewDTOConverter.convertDTO2ViewDTO(bundleViewDTO);
    }

    @Override
    public List<BrandBundleViewDTO> findBundleList(ServiceContext serviceContext, BrandBundleQueryViewDTO queryViewDTO) {
        BundleQueryViewDTO bundleQueryViewDTO = brandBundleViewDTOConverter.sourceToQueryTarget(queryViewDTO);
        List<BundleViewDTO> bundleList = performSAO.findBundleList(serviceContext, bundleQueryViewDTO);
        return brandBundleViewDTOConverter.convertDTO2ViewDTOList(bundleList);
    }

}
