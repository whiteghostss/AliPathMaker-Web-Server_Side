package com.taobao.ad.brand.bp.adapter.port.repository.message;

import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.message.MessageSAO;
import com.taobao.ad.brand.bp.client.dto.message.MessageViewDTO;
import com.taobao.ad.brand.bp.client.enums.message.MessageSendTypeEnum;
import com.taobao.ad.brand.bp.common.util.Env;
import com.taobao.ad.brand.bp.common.util.MailUtils;
import com.taobao.ad.brand.bp.domain.message.MessageRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collections;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/05/15
 */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class MessageRepositoryImpl implements MessageRepository {

    private final MessageSAO messageSAO;

    public void sendMessage(MessageViewDTO messageViewDTO) {
        if (CollectionUtils.isEmpty(messageViewDTO.getSendType())) {
            return;
        }
        for (Integer sendType : messageViewDTO.getSendType()) {
            MessageSendTypeEnum sendTypeEnum = MessageSendTypeEnum.getByValue(sendType);
            switch (sendTypeEnum) {
                case EMAIL:
                    messageSAO.sendEmail(messageViewDTO.getSendTo(), messageViewDTO.getSubject(), messageViewDTO.getContent());
                    break;
                case DING_DING:
                    messageSAO.sendDingMsg(messageViewDTO.getSendTo(), messageViewDTO.getSubject(), messageViewDTO.getContent());
                    break;
                case DING_GROUP:
                    messageSAO.sendDingGroupMsg(messageViewDTO.getSubject(), messageViewDTO.getContent(), messageViewDTO.getDingGroupToken());
                    break;
                case STATION_LETTER:
                    messageSAO.sendStationLetter(messageViewDTO.getMemberId(), messageViewDTO.getSubject(), messageViewDTO.getContent());
            }
        }
    }

    @Override
    public void sendEmail(String sendTo, String subject, String content) {
        if (Env.isDaily() || Env.isPre()) {
            subject = "[日常测试]" + subject;
            content = String.format("<div>本应发往To：%s </div>", sendTo)+ content;
            sendTo = MailUtils.rdRecipients;
        }
        messageSAO.sendEmail(Collections.singletonList(sendTo), subject, content);
    }
}
