package com.taobao.ad.brand.bp.adapter.port.repository.dooh;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.dooh.CampaignDoohViewDTO;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupProductCategoryEnum;
import com.alibaba.fastjson.JSON;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.alimama.faas.brand.engine.entity.constant.ServiceCodeEnum;
import com.aliyun.opensearch.sdk.dependencies.com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.adapter.port.converter.dooh.DoohCampaignConverter;
import com.taobao.ad.brand.bp.adapter.port.converter.dooh.DoohCampaignCreateConverter;
import com.taobao.ad.brand.bp.adapter.port.converter.dooh.DoohStrategyConverter;
import com.taobao.ad.brand.bp.adapter.port.converter.dooh.DoohStrategyPointConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.dmpargus.DmpArgusSAO;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.dooh.DoohSAO;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.DmpArgusEstimateViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohCampaignViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohStrategyPointQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohStrategyPointViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohStrategyRecommendReasonQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohStrategyRecommendReasonViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohStrategyViewDTO;
import com.taobao.ad.brand.bp.domain.dooh.repository.DoohRepository;
import com.umeng.oplus.domain.dto.bailing.SchemeMediaInfoDTO;
import com.umeng.oplus.domain.dto.dsp.plan.DspPlan4BailingDTO;
import com.umeng.oplus.domain.dto.dsp.scheme.DspSchemeDTO;
import com.umeng.oplus.domain.query.dsp.presale.DspPresaleMedia4BailingQuery;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DoohRepositoryImpl implements DoohRepository {

    private final DoohSAO doohSAO;

    private final DmpArgusSAO dmpArgusSAO;

    private final DoohStrategyConverter strategyConverter;

    private final DoohCampaignConverter doohCampaignConverter;

    private final DoohCampaignCreateConverter doohCampaignCreateConverter;

    private final DoohStrategyPointConverter strategyPointConverter;

    @Override
    public Void addCampaign(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOs) {
        if(CollectionUtils.isEmpty(campaignViewDTOs)){
            return null;
        }
        for(CampaignViewDTO campaignViewDTO:campaignViewDTOs){
            DspPlan4BailingDTO dspPlan4BailingDTO = doohSAO.createCampaign(doohCampaignCreateConverter.convertToDspPlanCreateDTO(serviceContext, campaignViewDTO));
            CampaignDoohViewDTO campaignDoohViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignDoohViewDTO()).orElse(new CampaignDoohViewDTO());
            campaignDoohViewDTO.setDoohCampaignId(dspPlan4BailingDTO.getDspPlanId());
            campaignDoohViewDTO.setDoohStrategyId(dspPlan4BailingDTO.getDspSchemeId());
            campaignViewDTO.setCampaignDoohViewDTO(campaignDoohViewDTO);
        }
        return null;
    }

    @Override
    public Void updateCampaign(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOs) {
        if(CollectionUtils.isEmpty(campaignViewDTOs)){
            return null;
        }
        for(CampaignViewDTO campaignViewDTO:campaignViewDTOs){
            doohSAO.updateCampaign(doohCampaignCreateConverter.convertToDspPlanCreateDTO(serviceContext, campaignViewDTO));
        }
        return null;
    }

    @Override
    public Void deleteCampaign(Long doohCampaignId) {
        doohSAO.deleteCampaign(doohCampaignId);
        return null;
    }

    @Override
    public DoohCampaignViewDTO getCampaignById(Long doohCampaignId) {
        DspPlan4BailingDTO dspPlan4BailingDTO =  doohSAO.getCampaignById(doohCampaignId);
        return doohCampaignConverter.convertDTO2ViewDTO(dspPlan4BailingDTO);
    }

    @Override
    public List<DoohStrategyViewDTO> strategyList(Long memberId, Long doohCampaignId,  Integer productCategory) {
        if(productCategory == null){
            return Lists.newArrayList();
        }
        List<DspSchemeDTO> dspSchemeDTOList = Lists.newArrayList();
        //极速达
        if(SaleGroupProductCategoryEnum.SMART_SCREEN_SPEED.getValue().equals(productCategory)){
            dspSchemeDTOList  = doohSAO.findJsdStrategyList(memberId, doohCampaignId);
        }
        //户外定制
        else{
            dspSchemeDTOList = doohSAO.findStrategyList(memberId, doohCampaignId);
        }
        return strategyConverter.convertDTO2ViewDTOList(dspSchemeDTOList);
    }

    @Override
    public DoohStrategyViewDTO getStrategyById(Long strategyId) {
        DspSchemeDTO dspSchemeDTO = doohSAO.getStrategyById(strategyId);
        return strategyConverter.convertDTO2ViewDTO(dspSchemeDTO);
    }

    @Override
    public Void order(Long doogCampaignId) {
        doohSAO.order(doogCampaignId);
        return null;
    }

    @Override
    public Void cancel(Long doohCampaignId) {
        doohSAO.cancelOrder(doohCampaignId);
        return null;
    }

    @Override
    public Void bindCreativeWithCampaignId(Long doohCampaignId, Long creativeId) {
        doohSAO.bindCreativeWithCampaignId(doohCampaignId, creativeId);
        return null;
    }

    @Override
    public Void updateCampaignName(Long doohCampaignId, String campaignName) {
        doohSAO.updateCampaignName(doohCampaignId, campaignName);
        return null;
    }

    @Override
    public List<CommonViewDTO> getPriorityIndustryList() {
        return doohSAO.getPriorityIndustryList();
    }

    @Override
    public MultiResponse<DoohStrategyPointViewDTO> pointList(DoohStrategyPointQueryViewDTO queryViewDTO) {
        DspPresaleMedia4BailingQuery query = strategyPointConverter.convertQueryViewDTO2DTO(queryViewDTO);
        MultiResponse<SchemeMediaInfoDTO> response = doohSAO.pointList(query);
        return MultiResponse.of(strategyPointConverter.convertDTO2ViewDTOList(response.getResult()), response.getTotal());
    }

    @Override
    public void savePoint(Long strategyId, List<String> addPointIdList, List<String> removePointIdList) {
        doohSAO.savePoint(strategyId, addPointIdList, removePointIdList);
    }

    @Override
    public List<CommonViewDTO> getDeviceTypeList() {
        return doohSAO.getDeviceTypeList();
    }

    @Override
    public DoohStrategyRecommendReasonViewDTO getRecommendReason(ServiceContext serviceContext, DoohStrategyRecommendReasonQueryViewDTO queryViewDTO) {
        RogerLogger.info("getRecommendReason--queryViewDTO:{}", JSON.toJSONString(queryViewDTO));
        DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO = new DmpArgusEstimateViewDTO();
        dmpArgusEstimateViewDTO.setServiceCode(ServiceCodeEnum.TianGong.name());
        dmpArgusEstimateViewDTO.setCampaignViewDTO(queryViewDTO.getCampaignViewDTO());
        dmpArgusEstimateViewDTO.setCampaignShowConfigViewDTOList(queryViewDTO.getCampaignShowConfigViewDTOList());
        dmpArgusEstimateViewDTO.setDoohStrategyPointViewDTOList(queryViewDTO.getDoohStrategyPointViewDTOList());
        dmpArgusEstimateViewDTO.setDoohStrategyViewDTO(queryViewDTO.getDoohStrategyViewDTO());
        return dmpArgusSAO.getDoohStrategyRecommendReason(serviceContext, dmpArgusEstimateViewDTO);
    }


}
