package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.sales;

import com.alibaba.ad.nb.sales.api.face.CustomerService;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.overnight.dto.nbcrm.NbCustomerDTO;
import com.taobao.ad.media.common.core.dto.ResultDTO;
import com.taobao.ad.mm.crm.service.dto.adv.AdvInfoDTO;
import com.taobao.ad.mm.crm.service.dto.adv.AdvInfoQueryDTO;
import com.taobao.ad.mm.crm.service.dto.customer.CustomerContactDTO;
import com.taobao.ad.mm.crm.service.sdk.adv.AdvInfoService;
import com.taobao.ad.mm.crm.service.sdk.customer.CustomerContactService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Objects;

/**
 * @author yanjingang
 * @date 2023/3/20
 */
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CustomerSAO extends SalesBaseSAO {

    private final CustomerService customerService;
    private final AdvInfoService advInfoService;
    private final CustomerContactService customerContactService;

    public NbCustomerDTO getCustomerById(Long customerId) {
        SingleResponse<NbCustomerDTO> singleResponse = customerService.getCustomerById(createNbServiceContext(), customerId);
        AssertUtil.assertTrue(singleResponse.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, singleResponse.getErrorMsg());
        AssertUtil.assertTrue(singleResponse.getResult() != null, BrandOneBPBaseErrorCode.RPC_ERROR, "未查询到客户");
        return singleResponse.getResult();
    }

    /**
     * 查询新老客（下单维度）
     *
     * @param customerMemberId
     * @return 1=新客(首单)，2=老客，3=新客（次单）
     */
    public Integer getCustomerType(Long customerMemberId) {
        SingleResponse<Integer> singleResponse = customerService.getCustomerType(customerMemberId);
        AssertUtil.assertTrue(singleResponse.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, singleResponse.getErrorMsg());
        AssertUtil.assertTrue(singleResponse.getResult() != null, BrandOneBPBaseErrorCode.RPC_ERROR, "未查询到客户类型");
        return singleResponse.getResult();
    }

    public AdvInfoDTO getAdvInfo(Long customerMemberId) {
        AdvInfoQueryDTO advInfoQueryDTO = new AdvInfoQueryDTO();
        advInfoQueryDTO.setMemberId(customerMemberId);
        ResultDTO<AdvInfoDTO> resultDTO = advInfoService.getForUmp(advInfoQueryDTO);
        AssertUtil.assertTrue(resultDTO.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, resultDTO.getErrorMsg());
        AssertUtil.assertTrue(resultDTO.getResult() != null, BrandOneBPBaseErrorCode.RPC_ERROR, "未查询到广告主");
        return resultDTO.getResult();
    }

    /**
     * 查询客户行业id（二级类目id）
     *
     * @param memberId 客户投放账号
     * @return 客户行业id（二级类目id）
     */
    public Long getCustomerIndustry(Long memberId) {
        ResultDTO<AdvInfoDTO> resultDTO = advInfoService.getByMemberId(memberId);
        AssertUtil.assertTrue(resultDTO != null && resultDTO.isSuccess()
                && Objects.nonNull(resultDTO.getResult()), "客户行业查询失败");
        AdvInfoDTO advInfoDTO = resultDTO.getResult();
        //返回客户的二级类目id作为行业id
        return advInfoDTO.getSubIndustryId();
    }

    /**
     * 查询客户行业id（二级类目id）
     *
     * @param memberId 客户投放账号
     * @return 客户行业id（二级类目id）
     */
    public AdvInfoDTO getCustomer(Long memberId) {
        AdvInfoQueryDTO advInfoQueryDTO = new AdvInfoQueryDTO();
        advInfoQueryDTO.setMemberId(memberId);
        ResultDTO<AdvInfoDTO> resultDTO = advInfoService.getForUmp(advInfoQueryDTO);
        AssertUtil.assertTrue(resultDTO != null && resultDTO.isSuccess()
                && Objects.nonNull(resultDTO.getResult()), "查询客户失败");
        //返回客户的二级类目id作为行业id
        return resultDTO.getResult();
    }

    /**
     * 保存客户联系方式
     *
     * @param customerContactDTO
     */
    public Integer saveCustomerContact(CustomerContactDTO customerContactDTO) {
        ResultDTO<Integer> resultDTO = customerContactService.insertWithUkNamePhone(customerContactDTO);
        AssertUtil.assertTrue(resultDTO.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, resultDTO.getErrorMsg());
        return resultDTO.getResult();
    }




}
