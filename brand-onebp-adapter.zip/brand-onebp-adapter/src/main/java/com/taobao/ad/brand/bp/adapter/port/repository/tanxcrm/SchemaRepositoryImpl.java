package com.taobao.ad.brand.bp.adapter.port.repository.tanxcrm;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.hermes.framework.utils.BeanUtils;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.schema.SchemaSAO;
import com.taobao.ad.brand.bp.client.dto.tanxcrm.SchemaViewDTO;
import com.taobao.ad.brand.bp.domain.tanxcrm.SchemaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/4/14 16:37
 * @description ：
 * @modified By：
 */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SchemaRepositoryImpl implements SchemaRepository {

    private final SchemaSAO schemaSAO;

    @Override
    public SchemaViewDTO getSchemaById(ServiceContext serviceContext, Long id) {
        return BeanUtils.copyIgnoreNull(schemaSAO.getSchemaById(serviceContext,id), new SchemaViewDTO());
    }
}
