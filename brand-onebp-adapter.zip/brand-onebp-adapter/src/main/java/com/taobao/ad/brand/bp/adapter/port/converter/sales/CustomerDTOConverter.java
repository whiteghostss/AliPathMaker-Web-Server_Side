package com.taobao.ad.brand.bp.adapter.port.converter.sales;

import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesCustomerViewDTO;
import com.taobao.ad.brand.overnight.dto.nbcrm.NbCustomerDTO;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

/**
 * @author yanjingang
 * @date 2023/3/10
 */
@Component
public class CustomerDTOConverter {


    public SalesCustomerViewDTO convertCustomerDTO2ViewDTO(NbCustomerDTO nbCustomerDTO) {
        SalesCustomerViewDTO customerViewDTO = new SalesCustomerViewDTO();
        BeanUtils.copyProperties(nbCustomerDTO, customerViewDTO);
        return customerViewDTO;
    }


}
