package com.taobao.ad.brand.bp.adapter.port.repository.monitor;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.common.WakeupViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.brand.dto.creative.element.ElementViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativeElementTypeEnum;
import com.alibaba.ad.nb.basic.client.constant.monitor.MonitorSceneEnum;
import com.alibaba.ad.nb.basic.client.dto.monitor.BizMonitorCodeDTO;
import com.alibaba.ad.nb.basic.client.dto.monitor.MonitorActivityPageDTO;
import com.alibaba.ad.nb.basic.client.dto.monitor.MonitorAppconfigDTO;
import com.alibaba.ad.nb.basic.client.dto.monitor.MonitorOnebpEParamQueryDTO;
import com.alibaba.ad.nb.basic.client.dto.monitor.MonitorPmpLandingPageQueryDTO;
import com.alibaba.ad.nb.basic.client.dto.monitor.MonitorQueryDTO;
import com.alibaba.ad.nb.basic.client.dto.monitor.MonitorRuleXMediaDTO;
import com.alibaba.ad.nb.direct.client.context.NbDirectServiceContext;
import com.alibaba.ad.nb.ssp.constant.common.CrossSceneEnum;
import com.alibaba.ad.nb.user.client.constant.bizspace.BizAbilityEnum;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.taobao.ad.brand.bp.adapter.port.converter.monitor.MonitorCodeDTOConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.adzone.AdzoneSAO;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.media.MediaSAO;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.monitor.MonitorSAO;
import com.taobao.ad.brand.bp.client.dto.adgroup.AdgroupMonitorCodeViewDTO;
import com.taobao.ad.brand.bp.client.dto.adgroup.ExportMonitorCodeViewDTO;
import com.taobao.ad.brand.bp.client.dto.media.MediaViewDTO;
import com.taobao.ad.brand.bp.client.dto.monitor.MonitorRuleXMediaViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.AdzoneViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.helper.schema.BizSchemaToolsHelper;
import com.taobao.ad.brand.bp.domain.monitor.MonitorRepository;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * 监测实现
 */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class MonitorRepositoryImpl implements MonitorRepository {
    private static ExecutorService EXECUTOR = new ThreadPoolExecutor(Runtime.getRuntime().availableProcessors(),
            Runtime.getRuntime().availableProcessors(),
            60L, TimeUnit.SECONDS, new LinkedBlockingQueue<>(2048),
            new ThreadFactoryBuilder().setNameFormat("brand_one_bp_monitor_task- %d").build());
    @Resource
    private MonitorSAO monitorSAO;

    @Resource
    private AdzoneSAO adzoneSAO;

    @Resource
    private MediaSAO mediaSAO;

    private final MonitorCodeDTOConverter monitorCodeDTOConverter;

    @Override
    public void generateMonitor(ServiceContext context, AdgroupViewDTO adgroupViewDTO, CampaignViewDTO campaignViewDTO, CampaignGroupViewDTO campaignGroupViewDTO, List<ExportMonitorCodeViewDTO> exportMonitorCodeViewDTOList, List<CreativeViewDTO> creativeViewDTOList, BizAbilityEnum bizAbilityEnum) {
        Map<Long, MediaInfoTempViewDTO> subCampaignMediaMap = getSubCampaignMediaMap(campaignGroupViewDTO,campaignViewDTO,adgroupViewDTO,exportMonitorCodeViewDTOList);
        NbDirectServiceContext nbDirectServiceContext = initNbDirectServiceContext();
        nbDirectServiceContext.setMemberId(context.getMemberId());
        for (ExportMonitorCodeViewDTO exportMonitorCodeViewDTO : exportMonitorCodeViewDTOList) {
            RogerLogger.info("生成监测链接,adgroupId={},campaignId={},adgroupMonitorRelationViewDTO={}", adgroupViewDTO.getId(), campaignViewDTO.getId(), JSON.toJSONString(exportMonitorCodeViewDTO));
            MediaInfoTempViewDTO mediaInfoTempViewDTO = subCampaignMediaMap.get(exportMonitorCodeViewDTO.getSubCampaignId());
            CreativeViewDTO creativeViewDTO = creativeViewDTOList.stream()
                    .filter(creativeView -> creativeView.getId().equals(exportMonitorCodeViewDTO.getCreativeId()))
                    .findFirst().orElse(null);
            List<BizMonitorCodeDTO> monitorCodeDTOList = monitorSAO.queryMonitorCodeList(nbDirectServiceContext,
                    genMonitorQueryDTO(context, mediaInfoTempViewDTO, campaignViewDTO, exportMonitorCodeViewDTO, creativeViewDTO, bizAbilityEnum));
            AssertUtil.notEmpty(monitorCodeDTOList, String.format("监测链接不能为空,adgroupId=%s", adgroupViewDTO.getId()));
            AdgroupMonitorCodeViewDTO monitorCodeViewDTO = monitorCodeDTOConverter.convertDTO2ViewDTO(monitorCodeDTOList.get(0));
            exportMonitorCodeViewDTO.setUlkUrl(monitorCodeViewDTO.getUlkUrl());
            exportMonitorCodeViewDTO.setPvMonitorUrl(monitorCodeViewDTO.getPvMonitorUrl());
            exportMonitorCodeViewDTO.setClickMonitorUrl(monitorCodeViewDTO.getClickMonitorUrl());
            exportMonitorCodeViewDTO.setClickUrl(monitorCodeViewDTO.getClickUrl());
            exportMonitorCodeViewDTO.setLandingPage(monitorCodeViewDTO.getLandingUrl());
            exportMonitorCodeViewDTO.setDeepLinkUrl(monitorCodeViewDTO.getDeepLinkUrl());
        }
    }

    @Override
    public void addMonitorRuleXMedia(ServiceContext context, MonitorRuleXMediaViewDTO monitorRuleXMediaViewDTO) {
        MonitorRuleXMediaDTO ruleXMediaDTO = new MonitorRuleXMediaDTO();
        ruleXMediaDTO.setMediaId(monitorRuleXMediaViewDTO.getMediaId());
        ruleXMediaDTO.setMonitorRuleId(monitorRuleXMediaViewDTO.getMonitorRuleId());
        ruleXMediaDTO.setAbilityCode(monitorRuleXMediaViewDTO.getAbilityCode());
        ruleXMediaDTO.setMediaMemberId(monitorRuleXMediaViewDTO.getMediaMemberId());
        monitorSAO.addMonitorRuleXMedia(initNbDirectServiceContext(), ruleXMediaDTO);
    }

    private MonitorQueryDTO genMonitorQueryDTO(ServiceContext context, MediaInfoTempViewDTO mediaInfoTempViewDTO, CampaignViewDTO campaignViewDTO, ExportMonitorCodeViewDTO exportMonitorCodeViewDTO, CreativeViewDTO creativeViewDTO, BizAbilityEnum bizAbilityEnum) {
        MonitorQueryDTO monitorQueryDTO = new MonitorQueryDTO();
        monitorQueryDTO.setAbilityEnum(bizAbilityEnum);
        monitorQueryDTO.setSceneId(MonitorSceneEnum.BRAND_ONEBP.getValue());
        monitorQueryDTO.setSchemaId(mediaInfoTempViewDTO.getSchemaId());
        Optional<AdzoneViewDTO> any = mediaInfoTempViewDTO.getAdzoneViewDTOList().stream().filter(item -> item.getAdzoneId().equals(exportMonitorCodeViewDTO.getAdzoneId())).findAny();
        AssertUtil.assertTrue(any.isPresent(), "计划推广位配置不正确，请检查后重试");
        AdzoneViewDTO adzoneViewDTO = any.get();
        monitorQueryDTO.setMonitorAppconfig(genMonitorAppconfigDTO(mediaInfoTempViewDTO.getMediaViewDTO(), adzoneViewDTO));
        monitorQueryDTO.setCustomerOrientedMediaId(campaignViewDTO.getCampaignResourceViewDTO().getSspMediaId());
        monitorQueryDTO.setResourceType(adzoneViewDTO.getResourceType());
        monitorQueryDTO.setMonitorOnebpEParamQuery(genMonitorOnebpEParamQueryDTO(campaignViewDTO, exportMonitorCodeViewDTO, creativeViewDTO));
        return monitorQueryDTO;
    }

    /**
     * 查询子计划媒体映射map
     *
     * @param campaignGroupViewDTO
     * @param adgroupViewDTO
     * @param exportMonitorCodeViewDTOList
     * @return
     */
    private Map<Long,MediaInfoTempViewDTO> getSubCampaignMediaMap(CampaignGroupViewDTO campaignGroupViewDTO, CampaignViewDTO parentCampaignViewDTO, AdgroupViewDTO adgroupViewDTO, List<ExportMonitorCodeViewDTO> exportMonitorCodeViewDTOList){
        //Long schemaId = campaignGroupViewDTO.getExtViewDTO().getSchemaIds().get(0);
        //根据adzone拿媒体ID
        List<Long> adzoneIdList = exportMonitorCodeViewDTOList.stream().map(ExportMonitorCodeViewDTO::getAdzoneId).distinct().collect(Collectors.toList());
        List<AdzoneViewDTO> adzoneViewDTOList = adzoneSAO.findAdzoneByAdzoneIds(adzoneIdList);
        AssertUtil.notEmpty(adzoneViewDTOList, "当前计划未查询到媒体信息，请检查后重试");
        Set<Long> siteIdset = adzoneViewDTOList.stream().map(AdzoneViewDTO::getSiteId).collect(Collectors.toSet());
        //非全域通黑盒场景：计划关联adzone必须归属于同一个媒体；
        //全域通黑盒场景：子计划关联adzone必须归属于同一个媒体
        if(!Objects.equals(CrossSceneEnum.CROSS_OPAQUE_SCENE.getValue(),parentCampaignViewDTO.getCampaignResourceViewDTO().getSspCrossScene())){
            AssertUtil.assertTrue(siteIdset.size() == 1, "当前计划媒体数量过多，无法生成监测，请检查后重新配置");
        }
        List<MediaViewDTO> mediaViewDTOList = mediaSAO.queryMediaListBySiteIds(Lists.newArrayList(siteIdset));
        AssertUtil.notEmpty(mediaViewDTOList,"计划关联媒体不存在，请检查后重试");

        Map<Long, Set<Long>> subCampaignAdzoneGroupMap = exportMonitorCodeViewDTOList.stream().collect(Collectors.groupingBy(ExportMonitorCodeViewDTO::getSubCampaignId,
                Collectors.mapping(ExportMonitorCodeViewDTO::getAdzoneId, Collectors.toSet())));
        Map<Long, MediaViewDTO> siteMediaMap = mediaViewDTOList.stream().collect(Collectors.toMap(MediaViewDTO::getSiteId, Function.identity(), (v1, v2) -> v2));
        Map<Long,MediaInfoTempViewDTO> subCampaignMediaMap = Maps.newHashMap();
        WakeupViewDTO wakeupViewDTO = BizSchemaToolsHelper.getWakeupConfig(campaignGroupViewDTO, adgroupViewDTO);
        for (Map.Entry<Long, Set<Long>> subCampaignEntry : subCampaignAdzoneGroupMap.entrySet()) {
            Set<Long> adzoneSet = subCampaignEntry.getValue();
            List<AdzoneViewDTO> mediaAdzoneList = adzoneViewDTOList.stream().filter(adzoneViewDTO -> adzoneSet.contains(adzoneViewDTO.getAdzoneId())).collect(Collectors.toList());
            List<Long> siteIdList = mediaAdzoneList.stream().map(AdzoneViewDTO::getSiteId).distinct().collect(Collectors.toList());
            AssertUtil.notEmpty(siteIdList, "关联计划未查询到媒体信息，请检查后重试");
            AssertUtil.assertTrue(siteIdList.size() == 1, "当前关联计划媒体数量过多，无法生成监测，请检查后重新配置");
            MediaInfoTempViewDTO mediaInfoViewDTO = new MediaInfoTempViewDTO();
            mediaInfoViewDTO.setAdzoneViewDTOList(mediaAdzoneList);
            if (CollectionUtils.isNotEmpty(wakeupViewDTO.getSchemaConfigViewDTOList())) {
                mediaInfoViewDTO.setSchemaId(wakeupViewDTO.getSchemaConfigViewDTOList().get(0).getSchemaId());
            }
            mediaInfoViewDTO.setMediaViewDTO(siteMediaMap.get(siteIdList.get(0)));
            subCampaignMediaMap.put(subCampaignEntry.getKey(),mediaInfoViewDTO);
        }
        return subCampaignMediaMap;
    }

    @Data
    static class MediaInfoTempViewDTO {

        private MediaViewDTO mediaViewDTO;
        private List<AdzoneViewDTO> adzoneViewDTOList;
        private Long schemaId;

    }

    /**
     * 构建e参数所需要的内容
     */
    private MonitorOnebpEParamQueryDTO genMonitorOnebpEParamQueryDTO(CampaignViewDTO campaignViewDTO, ExportMonitorCodeViewDTO exportMonitorCodeViewDTO, CreativeViewDTO creativeViewDTO) {
        MonitorOnebpEParamQueryDTO monitorOnebpEParamQueryDTO = new MonitorOnebpEParamQueryDTO();
        monitorOnebpEParamQueryDTO.setAdgroupId(exportMonitorCodeViewDTO.getAdgroupId());
        monitorOnebpEParamQueryDTO.setAdzoneId(exportMonitorCodeViewDTO.getAdzoneId());
        monitorOnebpEParamQueryDTO.setPid(exportMonitorCodeViewDTO.getPid());
        monitorOnebpEParamQueryDTO.setCampaignId(exportMonitorCodeViewDTO.getCampaignId());
        monitorOnebpEParamQueryDTO.setSubCampaignId(exportMonitorCodeViewDTO.getSubCampaignId());
        monitorOnebpEParamQueryDTO.setDealId(null);
        monitorOnebpEParamQueryDTO.setItemId(null);
        monitorOnebpEParamQueryDTO.setSspProductId(campaignViewDTO.getCampaignResourceViewDTO().getSspProductId());
        monitorOnebpEParamQueryDTO.setMemberId(campaignViewDTO.getMemberId());
        monitorOnebpEParamQueryDTO.setReturnChannel(campaignViewDTO.getCampaignMonitorViewDTO().getProductDataChannel());
        monitorOnebpEParamQueryDTO.setOrderId(exportMonitorCodeViewDTO.getCampaignGroupId());
        monitorOnebpEParamQueryDTO.setCreativeId(creativeViewDTO.getCreativePackageId());
        monitorOnebpEParamQueryDTO.setSubCreativeId(exportMonitorCodeViewDTO.getCreativeId());
        monitorOnebpEParamQueryDTO.setCampaignType(campaignViewDTO.getCampaignType());
        monitorOnebpEParamQueryDTO.setCampaignModel(campaignViewDTO.getCampaignModel());
        monitorOnebpEParamQueryDTO.setContractId(Optional.ofNullable(campaignViewDTO.getCampaignSaleViewDTO().getContractId()).orElse(0L));
        monitorOnebpEParamQueryDTO.setSubContractId(Optional.ofNullable(campaignViewDTO.getCampaignSaleViewDTO().getSubContractId()).orElse(0L));
        monitorOnebpEParamQueryDTO.setSettlePrice(0L);
        monitorOnebpEParamQueryDTO.setBudgetCampaignId(Optional.ofNullable(campaignViewDTO.getCampaignGuaranteeViewDTO().getBudgetCampaignId()).orElse(0L));
        monitorOnebpEParamQueryDTO.setSaleGroupId(campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId());
        monitorOnebpEParamQueryDTO.setRowId(exportMonitorCodeViewDTO.getPurchaseRowId());
        monitorOnebpEParamQueryDTO.setTalentUserId(exportMonitorCodeViewDTO.getTalentUserId());
        monitorOnebpEParamQueryDTO.setSceneId(campaignViewDTO.getSceneId());
        Optional.ofNullable(creativeViewDTO.getExtViewDTO()).ifPresent(extViewDTO -> {
            monitorOnebpEParamQueryDTO.setCreativeTagId(extViewDTO.getCreativeTagId());
        });
        List<MonitorActivityPageDTO> monitorActivityPageDTOS = Lists.newArrayList();
        MonitorPmpLandingPageQueryDTO monitorActivityPageDTO = new MonitorPmpLandingPageQueryDTO();
        monitorActivityPageDTO.setLandingUrl(getCreativeLandingPage(creativeViewDTO));
        monitorActivityPageDTO.setActivityPageId(0L);
        monitorActivityPageDTO.setLandingType(1);
        monitorActivityPageDTOS.add(monitorActivityPageDTO);
        monitorOnebpEParamQueryDTO.setLandingUrls(monitorActivityPageDTOS);

        return monitorOnebpEParamQueryDTO;
    }

    private String getCreativeLandingPage(CreativeViewDTO creativeViewDTO) {

        List<ElementViewDTO> elementViewDTOS = creativeViewDTO.getElementList().stream().filter(item -> item.getElementType().equals(BrandCreativeElementTypeEnum.LANDING_PAGE.getCode())).collect(Collectors.toList());
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(elementViewDTOS), "创意%s:%s没有落地页，请检查后重试", creativeViewDTO.getId(), creativeViewDTO.getName());
        return elementViewDTOS.get(0).getElementValue();
    }

    private MonitorAppconfigDTO genMonitorAppconfigDTO(MediaViewDTO mediaViewDTO, AdzoneViewDTO adzoneViewDTO) {
        MonitorAppconfigDTO monitorAppconfigDTO = new MonitorAppconfigDTO();
        //ios
        if (adzoneViewDTO.getOs().equals(BrandBoolEnum.BRAND_FALSE.getCode())) {
            monitorAppconfigDTO.setAppkey(mediaViewDTO.getIosBcAppkey());
            monitorAppconfigDTO.setPackageName(mediaViewDTO.getIosBundleId());
            monitorAppconfigDTO.setBackURL(mediaViewDTO.getIosSchema());
            monitorAppconfigDTO.setSourceId(mediaViewDTO.getIosSourceId());

        } else {
            monitorAppconfigDTO.setAppkey(mediaViewDTO.getAndroidBcAppkey());
            monitorAppconfigDTO.setPackageName(mediaViewDTO.getAndroidPkgName());
            monitorAppconfigDTO.setBackURL(mediaViewDTO.getAndroidSchema());
            monitorAppconfigDTO.setSourceId(mediaViewDTO.getAndroidSourceId());

        }
        return monitorAppconfigDTO;
    }

    private NbDirectServiceContext initNbDirectServiceContext() {
        NbDirectServiceContext nbDirectServiceContext = new NbDirectServiceContext();
        return nbDirectServiceContext;
    }
}
