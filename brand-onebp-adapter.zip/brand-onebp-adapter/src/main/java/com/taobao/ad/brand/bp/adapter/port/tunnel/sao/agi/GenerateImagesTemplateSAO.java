package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.agi;

import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.hsf.remoting.service.GenericService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

import static com.taobao.ad.brand.bp.common.constant.GenerateImageConstant.*;
import static com.taobao.ad.brand.bp.common.constant.TemplateConstant.*;

/**
 * @Author: PhilipFry
 * @createTime: 2024年12月25日 17:04:26
 * @Description:
 */
@Component
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class GenerateImagesTemplateSAO {
    private final GenericService templateServer;

    public Object getTemplate(Long itemId, Integer width, Integer height) {
        //使用泛化接口获取代理
        try {
            // ---------------------- 调用 -----------------------//
            // [调用] 发起HSF泛化调用, 返回map类型的result。
            Map<String, Object> paramMap = new HashMap<>();
            paramMap.put(ITEM_ID, itemId.toString());
            paramMap.put(CHANNEL_KEY, CHANNEL_ID);
            paramMap.put(CONSTANT_KEY_WIDTH, width);
            paramMap.put(CONSTANT_KEY_HEIGHT, height);
            Map resultMap = (Map) templateServer.$invoke(METHOD_NAME,
                    new String[]{INTERFACE_NAME},
                    //参数，如果是pojo，则需要转成Map
                    new Object[]{paramMap});

            Object result = resultMap.get(TEMPLATE_KEY);
            if (result == null) {
                return null;
            }
            return result;
        } catch (Exception e) {
            RogerLogger.error("获取生图模版异常", e);
        }
        return null;
    }

}
