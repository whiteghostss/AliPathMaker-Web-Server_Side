package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.ssp;

import com.alibaba.ad.nb.ssp.api.site.SiteQueryService;
import com.alibaba.ad.nb.ssp.context.ServiceContext;
import com.alibaba.ad.nb.ssp.dto.site.SiteDTO;
import com.alibaba.ad.nb.ssp.dto.site.SiteQueryDTO;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;

@Component
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SiteSAO extends BaseSAO {

    private final SiteQueryService siteQueryService;

    /**
     * site信息
     * */
    public List<SiteDTO> findBySiteIds(List<Long> siteIds){
        if(CollectionUtils.isEmpty(siteIds)){
            return Lists.newArrayList();
        }
        ServiceContext context = ServiceContext.create();
        SiteQueryDTO queryDTO = new SiteQueryDTO();
        queryDTO.setSiteIds(siteIds);
        queryDTO.setNeedPage(false);
        MultiResponse<SiteDTO> response = siteQueryService.listSites(context, queryDTO);
        AssertUtil.assertTrue(Objects.nonNull(response) && response.isSuccess(), "查询site信息失败");
        return response.getResult();
    }
}
