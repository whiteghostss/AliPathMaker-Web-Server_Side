package com.taobao.ad.brand.bp.adapter.port.converter.account.login;

import com.alibaba.ad.uic.common.dto.adv.EmployeeDTO;
import com.alibaba.ad.uic.common.dto.login.ADUicSessionDTO;
import com.alibaba.ad.uic.common.dto.login.ADUicSessionMemberDTO;
import com.alibaba.ad.uic.common.dto.login.LoginUserDTO;
import com.alibaba.ad.uic.common.dto.login.PseudoAccountDTO;
import com.alibaba.ad.uic.common.dto.login.PseudoInnerXiaoerDTO;
import com.alibaba.ad.uic.common.dto.login.SessionScenceDTO;
import com.taobao.ad.brand.bp.client.dto.account.login.AliEmpLoginViewDTO;
import com.taobao.ad.brand.bp.client.dto.account.login.AuthLoginViewDTO;
import com.taobao.ad.brand.bp.client.dto.account.login.LoginMemberViewDTO;
import com.taobao.ad.brand.bp.client.dto.account.login.LoginSessionViewDTO;
import com.taobao.ad.brand.bp.client.dto.account.login.LoginTbAccountViewDTO;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * @author 虫洞 <liuming.liu@alibaba-inc.com>
 * @date 2023/4/27
 */
@Mapper(componentModel = "spring")
public abstract class LoginSessionConverter {
    @Mapping(target = "sessionId", source = "sessionId")
    @Mapping(target = "bizCode", source = "bizCode")
    @Mapping(target = "loginStatus", source = "loginStatus")
    @Mapping(target = "loginMember", source = "sessionMember")
    @Mapping(target = "loginTbAccount", source = "loginUser")
    @Mapping(target = "authLogin", source = "pseudoAccountDTO")
    @Mapping(target = "aliEmpLogin", source = "pseudoXiaoerDTO")
    public abstract LoginSessionViewDTO convertDTO2ViewDTO(ADUicSessionDTO adUicSessionDTO);


    @Mapping(target = "loginSceneList", source = "sessionScenceDTOs")
    @Mapping(target = "preLoginSceneList", source = "authSessionScenceDTOs")
    public abstract LoginMemberViewDTO convertDTO2ViewDTO(ADUicSessionMemberDTO adUicSessionMemberDTO);

    @Mapping(target = "sceneCode", source = "scenceCode")
    @Mapping(target = "operMode", source = "operMode")
    public abstract LoginMemberViewDTO.BizSceneViewDTO convertDTO2ViewDTO(SessionScenceDTO sessionScenceDTO);


    public abstract LoginTbAccountViewDTO convertDTO2ViewDTO(LoginUserDTO loginUserDTO);


    @Mapping(target = "advTbNumId", source = "tbNumId")
    @Mapping(target = "advNickName", source = "nickName")
    @Mapping(target = "advMemberId", source = "memberId")
    @Mapping(target = "advEmployee", source = "employeeDTO")
    @Mapping(target = "bizCategory", source = "authServiceBizCategory")
    public abstract AuthLoginViewDTO convertDTO2ViewDTO(PseudoAccountDTO pseudoAccountDTO);

    public abstract AuthLoginViewDTO.AdvEmployeeViewDTO convertDTO2ViewDTO(EmployeeDTO employeeDTO);


    public abstract AliEmpLoginViewDTO convertDTO2ViewDTO(PseudoInnerXiaoerDTO pseudoInnerXiaoerDTO);
}
