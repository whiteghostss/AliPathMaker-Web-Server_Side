package com.taobao.ad.brand.bp.adapter.message;

/**
 * @author yuhui.sl
 * @since 2020/2/26 10:22
 */
public enum OpType4Manatee {
    //---------账户---------

    CAMPAIGN_ADD("添加计划", "OP_ZZ_CAMPAIGN_ADD"),


    //---------创意---------
    CREATIVE_ADD("添加创意", "OP_ZZ_CREATIVE_ADD"),


    //----------定向--------
    CROWD_ADD("添加定向", "OP_ZZ_ADGROUP_CROWD_ADD"),

    //----------账户--------
    ACCOUNT_BALANCE_WARN("余额提醒设置", "STATE_ZZ_ACCOUNT_BALANCE_WARN"),

    CAMPAIGN_BUDGET("计划预算设置", "STATE_ZZ_CAMPAIGN_BUDGET"),

    // 新手新建创意
    NEWGUEST_CREATIVE_ADD("添加创意", "OP_ZZ_NEWGUEST_CREATIVE_ADD"),

    // 新手新建计划
    NEWGUEST_CAMPAIGN_ADD("添加计划", "OP_ZZ_NEWGUEST_CAMPAIGN_ADD")
    ;

    private String name;

    private String code;

    OpType4Manatee(String name, String code) {
        this.name = name;
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public String getCode() {
        return code;
    }
}
