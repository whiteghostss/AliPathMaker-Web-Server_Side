package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.campaigngroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.organizer.api.CampaignGroupCommandService;
import com.alibaba.ad.organizer.api.CampaignGroupQueryService;
import com.alibaba.ad.organizer.dto.CampaignGroupDTO;
import com.alibaba.ad.organizer.dto.SaleGroupDTO;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.alibaba.solar.common.query.dto.PageQueryDTO;
import com.alibaba.solar.common.query.dto.QueryDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;

@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CampaignGroupSAO extends BaseSAO {
    private final CampaignGroupCommandService campaignGroupCommandService;
    private final CampaignGroupQueryService campaignGroupQueryService;

    public List<CampaignGroupDTO> findCampaignGroupList(ServiceContext serviceContext, QueryDTO queryDTO) {
        MultiResponse<CampaignGroupDTO> response = campaignGroupQueryService.findCampaignGroupList(serviceContext, queryDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    public MultiResponse<CampaignGroupDTO> findCampaignGroupPageList(ServiceContext serviceContext, PageQueryDTO pageQueryDTO) {
        MultiResponse<CampaignGroupDTO> response = campaignGroupQueryService.findCampaignGroupByPage(serviceContext, pageQueryDTO);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response;
    }

    public CampaignGroupDTO getCampaignGroup(ServiceContext serviceContext, Long id) {
        SingleResponse<CampaignGroupDTO> response = campaignGroupQueryService.getCampaignGroupById(serviceContext, id);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    public Long addCampaignGroup(ServiceContext serviceContext, CampaignGroupDTO campaignGroupDTO) {
        SingleResponse<Long> response = campaignGroupCommandService.addCampaignGroup(serviceContext, campaignGroupDTO);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    public Integer updateCampaignGroupPart(ServiceContext serviceContext, CampaignGroupDTO campaignGroupDTO) {
        SingleResponse<Integer> response = campaignGroupCommandService.updateCampaignGroup(serviceContext, campaignGroupDTO);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    public Integer updateCampaignGroupSettingPartBatch(ServiceContext serviceContext, Long campaignGroupId, Map<String, String> settingMap) {
        SingleResponse<Integer> response = campaignGroupCommandService.updateCampaignGroupSettingPartBatch(serviceContext, campaignGroupId, settingMap);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 删除订单售卖分组
     * @param serviceContext
     * @param id 订单id
     * @return
     */
    public Integer deleteCampaignGroup(ServiceContext serviceContext, Long id) {
        SingleResponse<Integer> response = campaignGroupCommandService.deleteCampaignGroup(serviceContext, id);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    public Integer deleteCampaignGroupSettingBatch(ServiceContext serviceContext, Long campaignGroupId, List<String> settingKeyList) {
        SingleResponse<Integer> response = campaignGroupCommandService.deleteCampaignGroupSettingBatch(serviceContext, campaignGroupId, settingKeyList);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 新增售卖分组
     * @param serviceContext
     * @param saleGroupList
     * @return
     */
    public Integer addSaleGroup(ServiceContext serviceContext,List<SaleGroupDTO> saleGroupList){
        SingleResponse<Integer> response = campaignGroupCommandService.addSaleGroup(serviceContext, saleGroupList);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 部分更新订单售卖分组
     * @param serviceContext
     * @param saleGroupList
     * @return
     */
    public Integer updateSaleGroupPart(ServiceContext serviceContext,List<SaleGroupDTO> saleGroupList){
        SingleResponse<Integer> response = campaignGroupCommandService.updateSaleGroupPart(serviceContext, saleGroupList);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 全量覆盖订单id下的售卖分组
     * @param serviceContext
     * @param campaignGroupId
     * @param saleGroupList
     * @return
     */
    public Integer rebindAllSaleGroup(ServiceContext serviceContext,Long campaignGroupId, List<SaleGroupDTO> saleGroupList){
        SingleResponse<Integer> response = campaignGroupCommandService.rebindSaleGroupByCampaignGroupId(serviceContext, campaignGroupId, saleGroupList);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 删除订单售卖分组
     * @param serviceContext
     * @param ids 订单售卖分组主键id
     * @return
     */
    public Integer deleteSaleGroup(ServiceContext serviceContext,List<Long> ids){
        SingleResponse<Integer> response = campaignGroupCommandService.delSaleGroupByIdList(serviceContext, ids);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 删除订单售卖分组
     * @param serviceContext
     * @param campaignGroupId 订单id
     * @return
     */
    public Integer deleteSaleGroupByCampaignGroupId(ServiceContext serviceContext, Long campaignGroupId) {
        SingleResponse<Integer> response = campaignGroupCommandService.delSaleGroupByCampaignGroupId(serviceContext, campaignGroupId);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 查询售卖分组
     * @param serviceContext
     * @param queryDTO
     * @return
     */
    public List<SaleGroupDTO> findSaleGroupList(ServiceContext serviceContext,QueryDTO queryDTO){
        MultiResponse<SaleGroupDTO> response = campaignGroupQueryService.findSaleGroup(serviceContext, queryDTO);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 覆盖更新订单售卖分组
     * @param serviceContext
     * @param saleGroupDTOS
     * @return
     */
    public Integer updateSaleGroupAll(ServiceContext serviceContext,List<SaleGroupDTO> saleGroupDTOS){
        SingleResponse<Integer> response = campaignGroupCommandService.updateSaleGroupAll(serviceContext, saleGroupDTOS);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }
}