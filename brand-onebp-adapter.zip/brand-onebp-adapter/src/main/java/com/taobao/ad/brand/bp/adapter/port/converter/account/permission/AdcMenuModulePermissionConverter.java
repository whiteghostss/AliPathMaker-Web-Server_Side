package com.taobao.ad.brand.bp.adapter.port.converter.account.permission;

import com.alibaba.ad.uic.dto.admin.permission.PermissionGroupTemplateDTO;
import com.taobao.ad.brand.bp.client.dto.account.permission.AdcMenuModulePermissionViewDTO;
import com.taobao.ad.brand.bp.client.dto.adc.AdcComponentViewDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;
import java.util.Objects;

/**
 * @author 虫洞 <liuming.liu@alibaba-inc.com>
 * @date 2023/4/27
 */
@Mapper(componentModel = "spring")
public abstract class AdcMenuModulePermissionConverter {
    @Mapping(target = "adcId", source = "businessId")
    @Mapping(target = "adcCode", source = "businessCode")
    @Mapping(target = "isWritable", expression = "java(com.taobao.ad.brand.bp.adapter.port.converter.account.permission.AdcMenuModulePermissionConverter.isWritable(permissionGroupTemplateDTO))")
    @Mapping(target = "subList", source = "subList")
    public abstract AdcMenuModulePermissionViewDTO convertDTO2ViewDTO(PermissionGroupTemplateDTO permissionGroupTemplateDTO);

    public abstract List<AdcMenuModulePermissionViewDTO> convertDTO2ViewDTO(List<PermissionGroupTemplateDTO> permissionGroupTemplateDTOList);

    @Mapping(target = "adcId", source = "id")
    @Mapping(target = "adcCode", source = "code")
    @Mapping(target = "isWritable",constant = "true")
    @Mapping(target = "subList", source = "subComponentList")
    public abstract AdcMenuModulePermissionViewDTO convertAdcDTO2ViewDTO(AdcComponentViewDTO adcComponentViewDTO);

    public abstract List<AdcMenuModulePermissionViewDTO> convertAdcDTO2ViewDTO(List<AdcComponentViewDTO> adcComponentViewDTOList);


    static Boolean isWritable(PermissionGroupTemplateDTO permissionGroupTemplateDTO) {
        if (Objects.equals(permissionGroupTemplateDTO.getOpenWrite(), true)) {
            return true;
        }
        if (Objects.equals(permissionGroupTemplateDTO.getOpenRead(), true)) {
            return false;
        }
        return null;
    }
}
