package com.taobao.ad.brand.bp.adapter.port.repository.perform;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.globaltag.GlobalTagViewDTO;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.perform.PerformSAO;
import com.taobao.ad.brand.bp.domain.perform.PerformRepository;
import com.taobao.ad.brand.perform.client.dto.globaltag.query.GlobalTagQueryViewDTO;
import com.taobao.ad.brand.perform.client.dto.shopwindow.spu.marketingrule.SpuCheckMarketingRuleViewDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Set;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/03/08
 */
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class PerformRepositoryImpl implements PerformRepository {
    private final PerformSAO performSAO;

    @Override
    public void doCampaignDailyEnd() {
        performSAO.doCampaignDailyEnd();
    }

    @Override
    public List<GlobalTagViewDTO> findGlobalTagList(ServiceContext serviceContext, GlobalTagQueryViewDTO queryViewDTO) {
        return performSAO.getGlobalTagList(serviceContext, queryViewDTO);
    }

    @Override
    public Set<String> getSortedScoreSet(ServiceContext serviceContext, List<Long> idList) {
        return performSAO.getSortedScoreSet(serviceContext, idList);
    }

    @Override
    public List<SpuCheckMarketingRuleViewDTO> getCheckMarketingRule(ServiceContext serviceContext) {
        return performSAO.getCheckMarketingRule(serviceContext);
    }
}
