package com.taobao.ad.brand.bp.adapter.message;

import java.util.Date;
import java.util.Map;

import com.google.common.collect.Maps;

/**
 * @author yuhui.sl
 * @since 2020/2/26 10:21
 */
public class LogInfo4Manatee {
    private String code;
    private Object ext;
    private Long memberId;
    private Date sendDate;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Object getExt() {
        return ext;
    }

    public void setExt(Object ext) {
        this.ext = ext;
    }

    public void setExtWithKey(String key, Object value) {
        Map<String, Object> extMap = Maps.newHashMap();
        extMap.put(key, value);
        this.ext = extMap;
    }

    public Long getMemberId() {
        return memberId;
    }

    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }

    public Date getSendDate() {
        return sendDate;
    }

    public void setSendDate(Date sendDate) {
        this.sendDate = sendDate;
    }
}
