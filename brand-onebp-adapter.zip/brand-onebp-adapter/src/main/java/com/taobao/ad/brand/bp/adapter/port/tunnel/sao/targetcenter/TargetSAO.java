package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.targetcenter;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.audience.api.AdgroupBindCrowdQueryService;
import com.alibaba.ad.audience.api.BindCrowdCommandService;
import com.alibaba.ad.audience.constants.BindDimensionEnum;
import com.alibaba.ad.audience.dto.bind.BindCrowdDTO;
import com.alibaba.ad.audience.dto.bind.BindDimensionDTO;
import com.alibaba.ad.audience.dto.bind.DeleteCrowdDTO;
import com.alibaba.ad.audience.dto.query.AdgroupBindCrowdQuery;
import com.alibaba.ad.audience.dto.query.BindCrowdQueryOptionDTO;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.solar.common.query.dto.QueryDTO;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * 定向中心SAO
 * */
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class TargetSAO {
    private final AdgroupBindCrowdQueryService adgroupBindCrowdQueryService;

    private final BindCrowdCommandService bindCrowdCommandService;

//    /**
//     * 根据adgroupId获取人群定向
//     * */
//    public List<BindCrowdDTO> getCrowdTargetByAdgroupId(ServiceContext serviceContext, Long adgroupId ){
//        QueryDTO queryDTO = QueryDTO.createQuery();
//        queryDTO.andCondition(AdgroupBindCrowdQuery.adgroupId.eq(adgroupId));
//
//        BindCrowdQueryOptionDTO adgroupBindCrowdQueryOptionDTO = buildAdgroupBindCrowdQueryOption();
//
//        MultiResponse<BindCrowdDTO> multiResponse = adgroupBindCrowdQueryService.findAdgroupBindCrowdList(
//                serviceContext,queryDTO,adgroupBindCrowdQueryOptionDTO
//        );
//        AssertUtil.assertTrue(multiResponse);
//        return multiResponse.getResult();
//    }
    /**
     * 创建中台定向
     * @param serviceContext
     * @param adgroupBindCrowdDTOList
     */
    public void addAdgroupBindCrowd(ServiceContext serviceContext, List<BindCrowdDTO> adgroupBindCrowdDTOList) {
        BindDimensionDTO bindDimensionDTO = new BindDimensionDTO();
        bindDimensionDTO.setBindDimension(BindDimensionEnum.ADGROUP.getValue());
        SingleResponse<Integer> response = bindCrowdCommandService.add(serviceContext, adgroupBindCrowdDTOList,bindDimensionDTO);
        AssertUtil.assertTrue(response);
    }
    /**
     * 删除中台定向
     * @param serviceContext
     * @param deleteCrowdDTO
     */
    public void deleteAdgroupBindCrowd(ServiceContext serviceContext, DeleteCrowdDTO deleteCrowdDTO) {
        BindDimensionDTO bindDimensionDTO = new BindDimensionDTO();
        bindDimensionDTO.setBindDimension(BindDimensionEnum.ADGROUP.getValue());
        SingleResponse<Integer> response = bindCrowdCommandService.deletePart(serviceContext, deleteCrowdDTO,bindDimensionDTO);
        AssertUtil.assertTrue(response);
    }
    /**
     * 删除中台定向
     * @param serviceContext
     * @param audienceCrowdIds
     */
    public void deleteAdgroupCrowdByAudienceCrowdIds(ServiceContext serviceContext, List<Long> audienceCrowdIds) {
        if (CollectionUtils.isEmpty(audienceCrowdIds)) {
            return;
        }
        BindDimensionDTO bindDimensionDTO = new BindDimensionDTO();
        bindDimensionDTO.setBindDimension(BindDimensionEnum.ADGROUP.getValue());
        SingleResponse<Integer> response = bindCrowdCommandService.deleteByCrowdId(serviceContext, audienceCrowdIds, bindDimensionDTO);
        AssertUtil.assertTrue(response);
    }

    /**
     * 更新中台定向
     * @param serviceContext
     * @param adgroupBindCrowdDTOList
     */
    public void updateAdgroupBindCrowd(ServiceContext serviceContext, List<BindCrowdDTO> adgroupBindCrowdDTOList) {
        BindDimensionDTO bindDimensionDTO = new BindDimensionDTO();
        bindDimensionDTO.setBindDimension(BindDimensionEnum.ADGROUP.getValue());
        SingleResponse<Integer> response = bindCrowdCommandService.updateAll(serviceContext, adgroupBindCrowdDTOList,bindDimensionDTO);
        AssertUtil.assertTrue(response);
    }
    /**
     * 根据单元IDs获取人群定向条件
     * */
    public List<BindCrowdDTO> getCrowdTargetByAdgroupIds(ServiceContext serviceContext, List<Long> adgroupIds ){
        if (CollectionUtils.isEmpty(adgroupIds)) {
            return Lists.newArrayList();
        }
        QueryDTO queryDTO = QueryDTO.createQuery();
        queryDTO.andCondition(AdgroupBindCrowdQuery.adgroupId.in(adgroupIds));

        BindCrowdQueryOptionDTO adgroupBindCrowdQueryOptionDTO = buildAdgroupBindCrowdQueryOption();
        MultiResponse<BindCrowdDTO> multiResponse = adgroupBindCrowdQueryService.findAdgroupBindCrowdList(
                serviceContext,queryDTO,adgroupBindCrowdQueryOptionDTO
        );
        RogerLogger.info("adgroupBindCrowdQueryService findAdgroupBindCrowdList request {} response {}", StringUtils.join(adgroupIds, ","), JSONObject.toJSONString(multiResponse));
        AssertUtil.assertTrue(multiResponse);
        return multiResponse.getResult();
    }
    /**
     * 构建查询option
     * */
    private BindCrowdQueryOptionDTO buildAdgroupBindCrowdQueryOption(){
        BindCrowdQueryOptionDTO adgroupBindCrowdQueryOptionDTO = BindCrowdQueryOptionDTO.builder().build();
        adgroupBindCrowdQueryOptionDTO.setPropertyRequired(true);
        adgroupBindCrowdQueryOptionDTO.setLabelRequired(true);
        return adgroupBindCrowdQueryOptionDTO;
    }
    public void addOrUpdateBatchAdgroupCrowd(ServiceContext serviceContext, List<BindCrowdDTO> bindCrowdDTOList) {
        BindDimensionDTO bindDimensionDTO = new BindDimensionDTO();
        bindDimensionDTO.setBindDimension(BindDimensionEnum.ADGROUP.getValue());
        SingleResponse<Integer> response = bindCrowdCommandService.addOrUpdateBatch(serviceContext, bindCrowdDTOList, bindDimensionDTO);
        AssertUtil.assertTrue(response);
    }
}
