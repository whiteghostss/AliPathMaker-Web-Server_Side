package com.taobao.ad.brand.bp.adapter.port.repository.dmp;

import com.alibaba.abf.governance.context.ServiceContext;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.adapter.port.converter.dmp.TagViewDTOConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.dmp.DmpTagSAO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.TagOptionViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.query.TagOptionQueryViewDTO;
import com.taobao.ad.brand.bp.domain.dmp.DmpTagRepository;
import com.taobao.ad.dmp.client.dto.ResultDTO;
import com.taobao.ad.dmp.client.dto.TagOptionDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Objects;

/**
 * 人群标签相关服务
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DmpTagRepositoryImpl implements DmpTagRepository {
    private final DmpTagSAO dmpTagSAO;
    private final TagViewDTOConverter tagViewDTOConverter;
    private final static int MAX_PAGE_COUNT = 500;

    @Override
    public PageResultViewDTO<TagOptionViewDTO> findOptionsPageList(ServiceContext context, TagOptionQueryViewDTO queryViewDTO) {
        ResultDTO<List<TagOptionDTO>> resultDTO = dmpTagSAO.findTagsPageList(context, queryViewDTO);
        return PageResultViewDTO.of(tagViewDTOConverter.convertDTO2ViewDTOList(resultDTO.getResult()), resultDTO.getPager().getTotal());
    }

    @Override
    public List<TagOptionViewDTO> findOptionsByTagId(ServiceContext context, Long tagId){
        if(Objects.isNull(tagId)){
            return Lists.newArrayList();
        }
        TagOptionQueryViewDTO queryViewDTO = new TagOptionQueryViewDTO();
        queryViewDTO.setPageNo(1);
        queryViewDTO.setPageSize(MAX_PAGE_COUNT);
        queryViewDTO.setTagId(tagId);
        ResultDTO<List<TagOptionDTO>> resultDTO = dmpTagSAO.findTagsPageList(context, queryViewDTO);
        return tagViewDTOConverter.convertDTO2ViewDTOList(resultDTO.getResult());
    }



}
