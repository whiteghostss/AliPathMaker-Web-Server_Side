package com.taobao.ad.brand.bp.adapter.port.converter.dmp;

import com.taobao.ad.brand.bp.adapter.port.converter.dmp.mapstruct.ItemMetricsViewDTOMapStruct;
import com.taobao.ad.brand.bp.client.dto.dmp.ItemMetricsViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import com.taobao.ad.dmp.site.sdk.dto.ItemIndicatorDTO;
import org.springframework.stereotype.Component;

/**
 * @author yanjingang
 * @date 2025/2/18
 **/
@Component
public class ItemMetricsViewDTOConverter extends BaseViewDTOConverter<ItemIndicatorDTO, ItemMetricsViewDTO> {

    @Override
    public BaseMapStructMapper<ItemIndicatorDTO, ItemMetricsViewDTO> getBaseMapStructMapper() {
        return ItemMetricsViewDTOMapStruct.INSTANCE;
    }
}
