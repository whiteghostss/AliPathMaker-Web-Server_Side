package com.taobao.ad.brand.bp.adapter.port.repository.ssp;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.adapter.port.converter.ssp.SiteConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.ssp.SiteSAO;
import com.taobao.ad.brand.bp.client.dto.site.SiteViewDTO;
import com.taobao.ad.brand.bp.domain.ssp.SiteRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * site相关
 * @author yuncheng.lyc
 * */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SiteRepositoryImpl implements SiteRepository {

    private final SiteSAO siteSAO;
    private final SiteConverter siteConverter;

    @Override
    public List<SiteViewDTO> findBySiteIds(List<Long> siteIds) {
        if(CollectionUtils.isEmpty(siteIds)){
            return Lists.newArrayList();
        }
        return siteConverter.convertDTO2ViewDTOList(siteSAO.findBySiteIds(siteIds));
    }

    @Override
    public Map<Long, SiteViewDTO> findMapBySiteIds(List<Long> siteIds) {
        List<SiteViewDTO> siteViewDTOS = findBySiteIds(siteIds);
        //如果site查询到多个信息，取第一条
        Map<Long, List<SiteViewDTO>> siteViewDTOMap = siteViewDTOS.stream().collect(Collectors.groupingBy(SiteViewDTO::getSiteId));
        Map<Long, SiteViewDTO> result = Maps.newHashMap();
        siteViewDTOMap.keySet().forEach(siteId-> result.put(siteId, siteViewDTOMap.get(siteId).get(0)));
        return result;
    }
}
