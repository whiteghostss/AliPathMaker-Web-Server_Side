package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.shield;

import com.alibaba.ad.biz.definition.constants.Product;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.alimama.rcp.shield.api.sync.dto.SyncAuditResultDTO;
import com.alimama.rcp.shield.api.sync.dto.SyncItemDTO;
import com.alimama.rcp.shield.api.sync.dto.SyncTextDTO;
import com.alimama.rcp.shield.api.sync.sdk.ShieldSyncRuleService;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.simba.saber.api.RuleServiceBasedMiku;
import com.taobao.simba.saber.api.dataobject.ItemDTO;
import com.taobao.simba.shield.api.common.Result;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 风控规则SAO
 */
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ShieldAccessSAO extends BaseSAO {

    private final ShieldSyncRuleService shieldSyncRuleService;
    private final RuleServiceBasedMiku ruleServiceBasedMiku;

    @Value("${shield.access.tokenId}")
    private Long tokenId;

    @Value("${saber.access.tokenId}")
    private Long saberTokenId;
    private static final Long FEED_JUDGE_TOKEN_ID = 105L;


    public List<SyncAuditResultDTO<SyncTextDTO>>  textAccessSyncRuleBatchJudge(List<SyncTextDTO> textList){
        textList.forEach(syncTextDTO -> syncTextDTO.setTokenId(tokenId));
        Result<List<SyncAuditResultDTO<SyncTextDTO>>> result = shieldSyncRuleService.textAccessSyncRuleBatchJudge(textList);
        AssertUtil.assertTrue(result.isOK(), BrandOneBPBaseErrorCode.RPC_ERROR, result.getMessage());
        return result.getObj();
    }

    /**
     *
     * @param tbUserId
     * @param itemIds
     * @return
     */
    public List<ItemDTO> feedJudgeBatch(Long tbUserId, List<Long> itemIds) {
        List<ItemDTO> itemDTOList = itemIds.stream().map(itemId -> {
            ItemDTO itemDTO = new ItemDTO();
            itemDTO.setItemId(itemId);
            itemDTO.setSimbaApplicationId(Product.BRAND_ONEBP_BRAND.getId().longValue());
            itemDTO.setUserId(tbUserId);
            return itemDTO;
        }).collect(Collectors.toList());

        com.taobao.simba.saber.api.common.Result<List<ItemDTO>> result = ruleServiceBasedMiku.feedJudge(itemDTOList, FEED_JUDGE_TOKEN_ID);
        AssertUtil.assertTrue(result.isOK(), BrandOneBPBaseErrorCode.RPC_ERROR, result.getMessage());
        return result.getObj();
    }


    /**
     * 商品智能投放校验
     * @param tbUserid
     * @param itemId
     */
    public ItemDTO feedAccessCheck(Long tbUserid,Long itemId){
        ItemDTO itemDTO = new ItemDTO();
        itemDTO.setItemId(itemId);
        itemDTO.setSimbaApplicationId(Product.BRAND_ONEBP_BRAND.getId().longValue());
        itemDTO.setUserId(tbUserid);
        com.taobao.simba.saber.api.common.Result<List<ItemDTO>> result =
                ruleServiceBasedMiku.feedJudge(Lists.newArrayList(itemDTO), saberTokenId);

        AssertUtil.assertTrue(result.isOK(), BrandOneBPBaseErrorCode.RPC_ERROR, result.getMessage());
        return CollectionUtils.isEmpty(result.getObj()) ? null : result.getObj().get(0);

    }
}
