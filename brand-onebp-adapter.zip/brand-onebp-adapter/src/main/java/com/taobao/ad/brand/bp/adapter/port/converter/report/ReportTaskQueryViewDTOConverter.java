package com.taobao.ad.brand.bp.adapter.port.converter.report;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.nb.task.client.dto.async.AsyncTaskQueryDTO;
import com.alibaba.ad.nb.task.client.dto.async.AsyncTaskQueryOptionDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.report.mapstruct.ReportTaskQueryViewDTOMapStruct;
import com.taobao.ad.brand.bp.client.dto.report.query.ReportTaskQueryViewDTO;
import com.taobao.ad.brand.bp.common.constant.AdcRoleConstant;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.springframework.stereotype.Component;

import java.util.Objects;

/**
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@Component
public class ReportTaskQueryViewDTOConverter extends BaseViewDTOConverter<AsyncTaskQueryDTO, ReportTaskQueryViewDTO> {

    @Override
    public BaseMapStructMapper<AsyncTaskQueryDTO, ReportTaskQueryViewDTO> getBaseMapStructMapper() {
        return ReportTaskQueryViewDTOMapStruct.INSTANCE;
    }

    public AsyncTaskQueryDTO convertViewDTO2DTO(ServiceContext context, ReportTaskQueryViewDTO viewDTO) {
        if ( viewDTO == null ) {
            return null;
        }
        AsyncTaskQueryDTO queryDTO = getBaseMapStructMapper().targetToSource(viewDTO);
        AsyncTaskQueryOptionDTO queryOption = new AsyncTaskQueryOptionDTO();
        queryOption.setInnerWaiter(context.getRoleNameList().contains(AdcRoleConstant.INNER_WAITER_ADC_ROLE)? BrandBoolEnum.BRAND_TRUE.getCode(): BrandBoolEnum.BRAND_FALSE.getCode());
        if(Objects.nonNull(viewDTO.getSaleGroupId())) {
            queryOption.setSaleGroupId(viewDTO.getSaleGroupId());
        }
        if(Objects.nonNull(viewDTO.getCampaignId())) {
            queryOption.setCampaignId(viewDTO.getCampaignId());
        }
        if(Objects.nonNull(viewDTO.getAdgroupId())) {
            queryOption.setAdgroupId(viewDTO.getAdgroupId());
        }
        queryDTO.setQueryOption(queryOption);

        return queryDTO;
    }
}
