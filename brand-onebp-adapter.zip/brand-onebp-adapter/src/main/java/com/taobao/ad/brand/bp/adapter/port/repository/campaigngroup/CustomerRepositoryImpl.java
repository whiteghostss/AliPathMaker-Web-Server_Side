package com.taobao.ad.brand.bp.adapter.port.repository.campaigngroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.adapter.port.converter.mmcrm.AdvInfoConverter;
import com.taobao.ad.brand.bp.adapter.port.converter.sales.CustomerDTOConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.sales.CustomerSAO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CrmAdvInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesCustomerViewDTO;
import com.taobao.ad.brand.bp.client.dto.cartitem.CustomerContactViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CustomerRepository;
import com.taobao.ad.brand.overnight.dto.nbcrm.NbCustomerDTO;
import com.taobao.ad.mm.crm.service.dto.adv.AdvInfoDTO;
import com.taobao.ad.mm.crm.service.dto.customer.CustomerContactDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * @author yanjingang
 * @date 2023/3/20
 */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CustomerRepositoryImpl implements CustomerRepository {
    private final CustomerSAO customerSAO;
    private final CustomerDTOConverter customerDTOConverter;
    private final AdvInfoConverter advInfoConverter;

    @Override
    public SalesCustomerViewDTO getCustomerById(Long customerId) {
        if (customerId == null || customerId == 0L) {
            return null;
        }
        NbCustomerDTO nbCustomerDTO = customerSAO.getCustomerById(customerId);
        return customerDTOConverter.convertCustomerDTO2ViewDTO(nbCustomerDTO);
    }

    @Override
    public Integer getCustomerType(Long customerMemberId) {
        AssertUtil.notNull(customerMemberId, "登录用户为空");
        return customerSAO.getCustomerType(customerMemberId);
    }

    @Override
    public String getMemberPriority(ServiceContext context, Long customerMemberId) {
        if (customerMemberId == null) {
            return null;
        }
        AdvInfoDTO advInfoDTO = customerSAO.getAdvInfo(customerMemberId);
        return advInfoDTO.getServePriority();
    }

    @Override
    public Long getCustomerMainCateId(Long customerMemberId) {
        if (customerMemberId == null) {
            return null;
        }
        AdvInfoDTO advInfoDTO = customerSAO.getAdvInfo(customerMemberId);
        if (advInfoDTO == null) {
            return null;
        }
        return advInfoDTO.getMainCateId();
    }

    @Override
    public CrmAdvInfoViewDTO getCustomer(Long memberId) {
        if (memberId == null) {
            return null;
        }
        AdvInfoDTO advInfoDTO = customerSAO.getCustomer(memberId);
        RogerLogger.info("CustomerRepositoryImpl getCustomer:{}", JSON.toJSONString(advInfoDTO));
        return advInfoConverter.convertDTO2ViewDTO(advInfoDTO);
    }

    @Override
    public Integer saveCustomerContact(ServiceContext context, CustomerContactViewDTO customerContactViewDTO) {
        if (customerContactViewDTO == null) {
            return 0;
        }
        CustomerContactDTO customerContactDTO = new CustomerContactDTO();
        customerContactDTO.setMemberId(context.getMemberId());
        customerContactDTO.setName(customerContactViewDTO.getName());
        customerContactDTO.setPhone(customerContactViewDTO.getPhone());
        customerContactDTO.setEmail(customerContactViewDTO.getEmail());
        customerContactDTO.setDomain("brand_onebp");
        return customerSAO.saveCustomerContact(customerContactDTO);
    }
}
