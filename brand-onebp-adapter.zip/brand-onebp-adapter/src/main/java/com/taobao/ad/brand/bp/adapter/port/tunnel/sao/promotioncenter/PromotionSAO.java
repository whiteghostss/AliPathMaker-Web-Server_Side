package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.promotioncenter;

import com.alibaba.fastjson.JSON;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.promotioncenter.core.service.impl.CouponSearchReadServiceClient;
import com.taobao.promotioncenter.coupon.dataobject.SellerCouponFull;
import com.taobao.promotioncenter.coupon.param.SellerCouponsParam;
import com.taobao.promotioncenter.result.ResultSupport;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * @Author: PhilipFry
 * @createTime: 2023年09月14日 10:08:25
 * @Description: 推广中心SAO
 */

@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class PromotionSAO extends BaseSAO {
    private final CouponSearchReadServiceClient couponSearchReadServiceClient;

    /**
     * 查询商家券
     * @param param
     * @return
     */
    public PageResultViewDTO<SellerCouponFull> querySellerCouponsList(SellerCouponsParam param) {
        RogerLogger.info("querySellerCouponsList SellerCouponsParam:{}", JSON.toJSONString(param));
        ResultSupport<List<SellerCouponFull>> resultSupport = couponSearchReadServiceClient.querySellerCouponsList(param);
        RogerLogger.info("querySellerCouponsList resultSupport:{}", JSON.toJSONString(resultSupport));
        AssertUtil.assertTrue(resultSupport.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, "商家优惠券信息查询失败:" + resultSupport.getErrorMsg());
        return PageResultViewDTO.of(resultSupport.getModule(), (int) resultSupport.getTotalCount());
    }
}
