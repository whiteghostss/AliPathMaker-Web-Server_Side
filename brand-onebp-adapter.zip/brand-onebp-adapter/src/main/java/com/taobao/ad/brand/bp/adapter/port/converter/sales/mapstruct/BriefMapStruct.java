package com.taobao.ad.brand.bp.adapter.port.converter.sales.mapstruct;

import com.alibaba.ad.nb.sales.dto.brief.BriefDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.resourcepackage.mapstruct.ResourceDistributionRuleMapStruct;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesBriefViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author yanjingang
 * @date 2023/03/23
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, uses = SubBriefMapStruct.class)
public interface BriefMapStruct extends BaseMapStructMapper<BriefDTO, SalesBriefViewDTO> {
    BriefMapStruct INSTANCE = Mappers.getMapper(BriefMapStruct.class);

    @Mappings({
            @Mapping(source = "subBriefList", target = "subContractViewDTOList"),
            @Mapping(source = "productGroupList", target = "saleGroupList"),
    })
    @Override
    SalesBriefViewDTO sourceToTarget(BriefDTO briefDTO);

    @Mappings({
            @Mapping(source = "subContractViewDTOList", target = "subBriefList"),
            @Mapping(source = "saleGroupList", target = "productGroupList"),
    })
    @Override
    BriefDTO targetToSource(SalesBriefViewDTO salesBriefViewDTO);
}