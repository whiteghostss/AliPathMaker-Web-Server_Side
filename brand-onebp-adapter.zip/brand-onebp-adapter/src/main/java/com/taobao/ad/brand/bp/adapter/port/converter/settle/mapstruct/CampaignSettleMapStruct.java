package com.taobao.ad.brand.bp.adapter.port.converter.settle.mapstruct;

import com.alibaba.ad.settle.billing.api.dto.accounting.response.StlCampaignAccountingResposneDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.settle.CampaignSettleViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;

import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author yanjingang
 * @date 2023/4/6
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface CampaignSettleMapStruct extends BaseMapStructMapper<StlCampaignAccountingResposneDTO, CampaignSettleViewDTO> {

    CampaignSettleMapStruct INSTANCE = Mappers.getMapper(CampaignSettleMapStruct.class);

}
