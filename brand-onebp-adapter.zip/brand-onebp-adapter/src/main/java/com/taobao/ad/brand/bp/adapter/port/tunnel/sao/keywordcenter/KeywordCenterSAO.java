package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.keywordcenter;

import com.alibaba.hermes.framework.dto.query.condition.Condition;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.solar.common.dto.QueryOptionDTO;
import com.alibaba.solar.common.dto.ResultDTO;
import com.alibaba.solar.common.dto.ServiceContext;
import com.alibaba.solar.common.query.condition.QueryField;
import com.alibaba.solar.common.query.dto.QueryDTO;
import com.alibaba.solar.sirius.client.dto.BidwordAccessDTO;
import com.alibaba.solar.sirius.client.dto.BidwordDTO;
import com.alibaba.solar.sirius.client.dto.BidwordSettingDTO;
import com.alibaba.solar.sirius.client.dto.BrandBidwordPackageDTO;
import com.alibaba.solar.sirius.client.dto.query.BrandBidwordPackageQuery;
import com.alibaba.solar.sirius.client.dto.query.BrandBidwordQuery;
import com.alibaba.solar.sirius.client.sdk.BidwordNormalizeService;
import com.alibaba.solar.sirius.client.sdk.BidwordService;
import com.alibaba.solar.sirius.client.sdk.BrandWordPackageService;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;

/**
 * 关键词中心
 */
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class KeywordCenterSAO {

    private final BidwordService bidWordService;

    private final BidwordNormalizeService bidWordNormalizeService;

    private final BrandWordPackageService brandWordPackageService;

    /**
     * 词绑定计划
     * @param serviceContext
     * @param bidWordDTOList
     */
    public void batchAddWords(ServiceContext serviceContext, List<BidwordDTO> bidWordDTOList){
        ResultDTO<List<BidwordDTO>> response = bidWordService.addBatchCarryAddedWords(serviceContext, bidWordDTOList);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getMsg()));
    }

    public void batchDelWords(ServiceContext serviceContext, List<Long> wordIdList){
        ResultDTO<Integer> response = bidWordService.deleteBidwordBatch(serviceContext, wordIdList);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getMsg()));
    }

    /**
     * 根据计划ID查询词列表
     * @param serviceContext
     * @param campaignIdList
     * @return
     */
    public List<BidwordDTO> findBidWordList(ServiceContext serviceContext, List<Long> campaignIdList){
        ResultDTO<List<BidwordDTO>> response = bidWordService.findBidwordList(serviceContext,QueryDTO.createQuery().andCondition(BrandBidwordQuery.campaignId.in(campaignIdList)), QueryOptionDTO.propertyRequired(true).andChildRequired(false).andParentRequired(false));
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getMsg()));
        if(CollectionUtils.isEmpty(response.getResult())){
            return Lists.newArrayList();
        }
        return response.getResult();
    }

    /**
     * 关键词风控准入
     * @param serviceContext
     * @param wordList
     * @return
     */
    public Map<String, BidwordAccessDTO> bidWordAccess(ServiceContext serviceContext, List<String> wordList){
        ResultDTO<Map<String, BidwordAccessDTO>> response = bidWordService.bidwordAccess(serviceContext, "-1", wordList);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getMsg()));
        return response.getResult();
    }

    /**
     * 关键词归一化
     * @param serviceContext
     * @param wordList
     * @return
     */
    public Map<String, String> normalizeBatch(ServiceContext serviceContext, List<String> wordList){
        ResultDTO<Map<String, String>> response = bidWordNormalizeService.normalizeBatch(serviceContext, wordList);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getMsg()));
        return response.getResult();
    }

    /**
     * 批量更新搜索词的扩展信息
     * @param serviceContext
     * @param wordSettingList
     */
    public void batchUpdateWordSetting(ServiceContext serviceContext, List<BidwordSettingDTO> wordSettingList){
        ResultDTO<Integer> response = bidWordService.updateBidwordSettingBatch(serviceContext, wordSettingList);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getMsg()));
    }

    /**
     * 批量添加词包
     * @param serviceContext
     * @param campaignId
     * @param brandBidwordPackageDTOList
     */
    public List<Long> batchAddWordPackage(ServiceContext serviceContext, Long campaignId, List<BrandBidwordPackageDTO> brandBidwordPackageDTOList){
        if(CollectionUtils.isEmpty(brandBidwordPackageDTOList) || campaignId == null){
            return Lists.newArrayList();
        }
        ResultDTO<List<Long>> response = brandWordPackageService.addWordPackageBatch(serviceContext, campaignId, brandBidwordPackageDTOList);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getMsg()));
        return response.getResult();
    }

    /**
     * 批量删除词包
     * @param serviceContext
     * @param wordPackageIdList
     */
    public void batchDelWordPackages(ServiceContext serviceContext, List<Long> wordPackageIdList){
        ResultDTO<Integer> response = brandWordPackageService.deleteWordPackageBatch(serviceContext, wordPackageIdList);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getMsg()));
    }

    /**
     * 根据计划ID查询词包
     * @param serviceContext
     * @param campaignIdList
     * @return
     */
    public List<BrandBidwordPackageDTO> findWordPackageList(ServiceContext serviceContext, List<Long> campaignIdList){
        ResultDTO<List<BrandBidwordPackageDTO>> response = brandWordPackageService.findList(serviceContext, QueryDTO.createQuery().andCondition(BrandBidwordPackageQuery.campaignId.in(campaignIdList)), QueryOptionDTO.propertyRequired(true).andChildRequired(false).andParentRequired(false));
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getMsg()));
        if(CollectionUtils.isEmpty(response.getResult())){
            return Lists.newArrayList();
        }
        return response.getResult();
    }


}
