package com.taobao.ad.brand.bp.adapter.port.converter.sales;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSaleOrderStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.alibaba.ad.nb.sales.constant.brief.BriefStateEnum;
import com.alibaba.ad.nb.sales.dto.brief.BriefDTO;
import com.alibaba.ad.nb.sales.dto.brief.SubBriefDTO;
import com.alibaba.ad.nb.sales.dto.brief.productgroup.ProductGroupDTO;
import com.alibaba.solar.libra.client.dto.ContractVersionDTO;
import com.google.common.collect.ImmutableMap;
import com.taobao.ad.brand.bp.adapter.port.converter.sales.mapstruct.BriefMapStruct;
import com.taobao.ad.brand.bp.adapter.port.converter.sales.mapstruct.ProjectMapStruct;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSubContractViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesBriefViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesContractViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.factory.Mappers;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import static com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum.EDITED;
import static com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum.UNLOCKED;

/**
 * @author yanjingang
 * @date 2023/3/10
 */
@Component
public class BriefDTOConverter extends BaseViewDTOConverter<BriefDTO, SalesBriefViewDTO> {

    @Override
    public BaseMapStructMapper<BriefDTO, SalesBriefViewDTO> getBaseMapStructMapper() {
        return BriefMapStruct.INSTANCE;
    }

    public final Map<Integer, Integer> campaignGroup2BriefStatusMap = ImmutableMap.<Integer, Integer>builder()
            .put(EDITED.getCode(), BriefStateEnum.CONFIRMED.value)
            .put(UNLOCKED.getCode(), BriefStateEnum.UNLOCK_CONFIRMED.value)
            .build();

    public SalesBriefViewDTO convertBriefDTO2ViewDTO(BriefDTO briefDTO) {
        SalesBriefViewDTO briefViewDTO = new SalesBriefViewDTO();
        BeanUtils.copyProperties(briefDTO, briefViewDTO);
        if (CollectionUtils.isNotEmpty(briefDTO.getSubBriefList())) {
            List<CampaignGroupSubContractViewDTO> campaignGroupSubContractViewDTOS = briefDTO.getSubBriefList().stream().map(this::convertSubBriefDTO2ViewDTO).collect(Collectors.toList());
            briefViewDTO.setSubContractViewDTOList(campaignGroupSubContractViewDTOS);
        }

        return briefViewDTO;
    }

    private CampaignGroupSubContractViewDTO convertSubBriefDTO2ViewDTO(SubBriefDTO subBriefDTO) {
        CampaignGroupSubContractViewDTO campaignGroupSubContractViewDTO = new CampaignGroupSubContractViewDTO();
        campaignGroupSubContractViewDTO.setSubContractId(subBriefDTO.getSubContractId());
        if (StringUtils.isNotBlank(subBriefDTO.getGroupProductLine())) {
            campaignGroupSubContractViewDTO.setSaleProductLine(Integer.parseInt(subBriefDTO.getGroupProductLine()));
        }
        return campaignGroupSubContractViewDTO;
    }


    /**
     *
     * @param campaignGroupViewDTO
     * @return
     */
    public BriefDTO convertCampaignGroupViewDTO2DTOForSyncInfo(CampaignGroupViewDTO campaignGroupViewDTO) {
        // 转换接口基本信息
        BriefDTO briefDTO = convertBaseInfoViewDTO2DTO(campaignGroupViewDTO);
        //
        briefDTO.setName(campaignGroupViewDTO.getName());
        briefDTO.setStatus(campaignGroup2BriefStatusMap.get(campaignGroupViewDTO.getStatus()));
        briefDTO.setDiscountAmount(campaignGroupViewDTO.getBudget());
        briefDTO.setTotalAmount(campaignGroupViewDTO.getBudget());
        briefDTO.setStartDate(campaignGroupViewDTO.getCampaignGroupContractViewDTO().getContractStartTime());
        briefDTO.setEndDate(campaignGroupViewDTO.getCampaignGroupContractViewDTO().getContractEndTime());
        // 子合同信息
//        Map<Long, SaleGroupCalculateInfoViewDTO> saleGroupCalculateInfoMap = campaignGroupViewDTO.getGroupSaleViewDTO().getSaleGroupCalculateInfoViewDTOList()
//                .stream().collect(Collectors.toMap(SaleGroupCalculateInfoViewDTO::getSaleGroupId, Function.identity()));
        List<ProductGroupDTO> productGroupDTOS = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList()
                        .stream().filter(this::isValidSaleGroup)
                        .map(saleGroupInfoViewDTO -> {
                            ProductGroupDTO productGroupDTO = new ProductGroupDTO();
                            productGroupDTO.setId(saleGroupInfoViewDTO.getSaleGroupId());
                            Optional.ofNullable(saleGroupInfoViewDTO.getSaleProductLine()).ifPresent(saleProductLine -> productGroupDTO.setGroupProductLine(String.valueOf(saleProductLine)));
                            productGroupDTO.setBudget(saleGroupInfoViewDTO.getBudget());
                            productGroupDTO.setStartDate(saleGroupInfoViewDTO.getStartDate());
                            productGroupDTO.setEndDate(BrandDateUtil.getDateMidnight(saleGroupInfoViewDTO.getEndDate()));
                            productGroupDTO.setSaleType(saleGroupInfoViewDTO.getSaleType());
                            productGroupDTO.setSource(saleGroupInfoViewDTO.getSource());
                            if(CollectionUtils.isNotEmpty(saleGroupInfoViewDTO.getResourcePackageProductViewDTOList())){
                                productGroupDTO.setSignPv(saleGroupInfoViewDTO.getAmount());
                            }
//                            if (saleGroupCalculateInfoMap.containsKey(saleGroupInfoViewDTO.getSaleGroupId())) {
//                                productGroupDTO.setSignPv(saleGroupCalculateInfoMap.get(saleGroupInfoViewDTO.getSaleGroupId()).getAmount());
//                            }

                            return productGroupDTO;
                        }).collect(Collectors.toList());
        briefDTO.setProductGroupList(productGroupDTOS);

        return briefDTO;
    }

    /**
     *
     * @param campaignGroupViewDTO
     * @return
     */
    public BriefDTO convertBaseInfoViewDTO2DTO(CampaignGroupViewDTO campaignGroupViewDTO) {
        BriefDTO briefDTO = new BriefDTO();
        briefDTO.setOrderId(campaignGroupViewDTO.getId());
        briefDTO.setBriefId(campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getBriefId());
        briefDTO.setSource("nb-brandOneBp");

        return briefDTO;
    }

    /**
     * 有效的分组
     * 非补量 & 非待下单状态
     * @param saleGroupInfoViewDTO
     * @return
     */
    private boolean isValidSaleGroup(SaleGroupInfoViewDTO saleGroupInfoViewDTO) {
        return !BrandSaleTypeEnum.BOOST.getCode().equals(saleGroupInfoViewDTO.getSaleType())
                && !BrandCampaignGroupSaleOrderStatusEnum.WAIT_ORDER.getCode().equals(saleGroupInfoViewDTO.getSaleGroupStatus());
    }

}
