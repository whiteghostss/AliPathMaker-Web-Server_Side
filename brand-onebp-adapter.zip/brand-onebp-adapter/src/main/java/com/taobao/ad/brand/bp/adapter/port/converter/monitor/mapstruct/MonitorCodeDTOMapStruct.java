package com.taobao.ad.brand.bp.adapter.port.converter.monitor.mapstruct;

import com.alibaba.ad.brand.dto.monitor.MonitorCodeViewDTO;
import com.alibaba.ad.nb.basic.client.dto.monitor.BizMonitorCodeDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

/**
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface MonitorCodeDTOMapStruct extends BaseMapStructMapper<BizMonitorCodeDTO, MonitorCodeViewDTO> {

    MonitorCodeDTOMapStruct INSTANCE = Mappers.getMapper(MonitorCodeDTOMapStruct.class);
}
