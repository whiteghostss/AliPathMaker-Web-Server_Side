package com.taobao.ad.brand.bp.adapter.port.converter.motion;

import com.alibaba.ad.nb.packages.v2.client.dto.motion.IntelligentStrategyDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.motion.mapstruct.IntelligentStrategyMapStruct;
import com.taobao.ad.brand.bp.client.dto.motion.IntelligentStrategyViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.springframework.stereotype.Component;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/18
 **/
@Component
public class IntelligentStrategyDTOConverter extends BaseViewDTOConverter<IntelligentStrategyDTO, IntelligentStrategyViewDTO> {

    @Override
    public BaseMapStructMapper<IntelligentStrategyDTO, IntelligentStrategyViewDTO> getBaseMapStructMapper() {
        return IntelligentStrategyMapStruct.INSTANCE;
    }

    public IntelligentStrategyViewDTO convertDTO2ViewDTO(IntelligentStrategyDTO source) {
        return IntelligentStrategyMapStruct.INSTANCE.sourceToTarget(source);
    }

    public IntelligentStrategyDTO convertViewDTO2DTO(IntelligentStrategyViewDTO source) {
        return IntelligentStrategyMapStruct.INSTANCE.targetToSource(source);
    }
}
