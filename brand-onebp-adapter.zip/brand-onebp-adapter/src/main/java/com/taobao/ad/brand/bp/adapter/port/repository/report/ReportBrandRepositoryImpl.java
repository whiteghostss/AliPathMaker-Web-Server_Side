package com.taobao.ad.brand.bp.adapter.port.repository.report;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.dto.report.ReportCampaignGroupBrandViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.query.ReportAttributionBrandQueryViewDTO;
import com.taobao.ad.brand.bp.common.constant.ReportConstant;
import com.taobao.ad.brand.bp.domain.adr.ReportCenterRepository;
import com.taobao.ad.brand.bp.domain.report.repository.ReportBrandRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * 报表获取品牌和订单信息
 * @author yuncheng.lyc
 * @date 2023/3/23
 **/
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ReportBrandRepositoryImpl implements ReportBrandRepository {
    private final ReportCenterRepository reportCenterRepository;

    @Override
    public List<ReportCampaignGroupBrandViewDTO> getContractBrandList(ServiceContext context, ReportAttributionBrandQueryViewDTO queryViewDTO) {
        Map<String, Object> queryParams = Maps.newHashMap();
        queryParams.put(ReportConstant.ADR_UNIQUE_KEY,"brand_onebp.common.common.brandOneBPBrandInfoApi");
        if(Objects.nonNull(queryViewDTO.getMemberId())){
            queryParams.put("memberIdEqual",queryViewDTO.getMemberId());
        }
        if(Objects.nonNull(queryViewDTO.getCampaignGroupId())){
            queryParams.put("campaignGroupIdEqual",queryViewDTO.getCampaignGroupId());
        }
        if(Objects.nonNull(queryViewDTO.getBrandId())){
            queryParams.put("brandIdEqual",queryViewDTO.getBrandId());
        }
        if(Objects.nonNull(queryViewDTO.getBrandIds())){
            queryParams.put("brandIdIn", queryViewDTO.getBrandIds());
        }
        if(CollectionUtils.isNotEmpty(queryViewDTO.getCampaignGroupIds())){
            queryParams.put("campaignGroupIdIn", queryViewDTO.getCampaignGroupIds());
        }
        if(StringUtils.isNotEmpty(queryViewDTO.getKeyword())){
            queryParams.put("keywordEqual", queryViewDTO.getKeyword());
        }
        List<Map<String, Object>> brandInfoList = reportCenterRepository.findData(queryParams);
        if(CollectionUtils.isEmpty(brandInfoList)){
            return Lists.newArrayList();
        }
        return JSON.parseArray(JSON.toJSONString(brandInfoList), ReportCampaignGroupBrandViewDTO.class);
    }
}
