package com.taobao.ad.brand.bp.adapter.port.repository.cart;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.alibaba.ad.brand.sdk.constant.cartitem.BrandCartItemStatusEnum;
import com.alibaba.ad.brand.sdk.constant.cartitem.setting.BrandCartItemSettingKeyEnum;
import com.alibaba.ad.brand.sdk.convert.custom.viewdto.cartitem.CartItemViewDTO2DTOConvertProcessor;
import com.alibaba.ad.organizer.dto.CartDTO;
import com.alibaba.ad.organizer.dto.query.CartQuery;
import com.alibaba.ad.universal.sdk.convert.custom.onebp.provider.OneBpConvertProcessorProvider;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.solar.common.dto.QueryOptionDTO;
import com.alibaba.solar.common.query.dto.PageQueryDTO;
import com.alibaba.solar.common.query.dto.QueryDTO;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.cart.CartItemSAO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.cartitem.query.CartItemQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.BizKeywordTypeEnum;
import com.taobao.ad.brand.bp.domain.cart.repository.CartItemRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Objects;

/**
 * 加购行相关服务
 * @author shiyan
 * @date 2024/6/26
 **/
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CartItemRepositoryImpl implements CartItemRepository {

    private final CartItemSAO cartItemSAO;
    private CartItemViewDTO2DTOConvertProcessor cartItemViewDTO2DTOConvertProcessor = OneBpConvertProcessorProvider.getViewDTO2DTOConvertProcessor(CartItemViewDTO2DTOConvertProcessor.class);

    @Override
    public List<CartItemViewDTO> findCartList(ServiceContext serviceContext, CartItemQueryViewDTO query) {
        QueryDTO queryDTO = QueryDTO.createQuery();
        initQueryDTO(serviceContext,query,queryDTO);
        List<CartDTO> cartList = cartItemSAO.findCartList(serviceContext, queryDTO, QueryOptionDTO.propertyRequired(true));
        return cartItemViewDTO2DTOConvertProcessor.dtoList2ViewDTOList(cartList);
    }

    @Override
    public PageResultViewDTO<CartItemViewDTO> findCartPage(ServiceContext serviceContext, CartItemQueryViewDTO query) {
        PageQueryDTO pageQueryDTO = PageQueryDTO.createQuery();
        initQueryDTO(serviceContext,query,pageQueryDTO);
        pageQueryDTO.setLimit(query.getPageSize());
        pageQueryDTO.setSkip(query.getStart());
        MultiResponse<CartDTO> response = cartItemSAO.findCartPage(serviceContext, pageQueryDTO, QueryOptionDTO.propertyRequired(true));
        return PageResultViewDTO.of(cartItemViewDTO2DTOConvertProcessor.dtoList2ViewDTOList(response.getResult()),response.getTotal());
    }

    @Override
    public CartItemViewDTO getCartById(ServiceContext serviceContext, Long id) {
        CartDTO cartDTO = cartItemSAO.getCartById(serviceContext, id);
        if (cartDTO == null || BrandCartItemStatusEnum.DELETE.getCode().equals(cartDTO.getStatus())) {
            return null;
        }
        return cartItemViewDTO2DTOConvertProcessor.dto2ViewDTO(cartDTO);
    }

    @Override
    public Long addCart(ServiceContext serviceContext, CartItemViewDTO cartViewDTO) {
        CartDTO cartDTO = cartItemViewDTO2DTOConvertProcessor.viewDTO2DTO(cartViewDTO);
        Long id = cartItemSAO.addCart(serviceContext, cartDTO);
        cartViewDTO.setId(id);
        return id;
    }

    @Override
    public Integer physicsDeleteCartItem(ServiceContext serviceContext, List<Long> ids) {
        return cartItemSAO.delCartByIds(serviceContext,ids);
    }

    @Override
    public Integer deleteCartItem(ServiceContext serviceContext, List<Long> ids) {
        return batchUpdateCartStatus(serviceContext,ids, BrandCartItemStatusEnum.DELETE.getCode());
    }

    @Override
    public Integer batchUpdateCartStatus(ServiceContext serviceContext, List<Long> ids, Integer status) {
        if(CollectionUtils.isEmpty(ids)){
            return 0;
        }
        return cartItemSAO.batchUpdateCartStatus(serviceContext,ids,status);
    }

    @Override
    public Integer updateCartAll(ServiceContext serviceContext, CartItemViewDTO cartViewDTO) {
        CartDTO cartDTO = cartItemViewDTO2DTOConvertProcessor.viewDTO2DTO(cartViewDTO);
        return cartItemSAO.updateCartAll(serviceContext,cartDTO);
    }

    @Override
    public Integer updateCartPart(ServiceContext serviceContext, CartItemViewDTO cartViewDTO) {
        CartDTO cartDTO = cartItemViewDTO2DTOConvertProcessor.viewDTO2DTO(cartViewDTO);
        return cartItemSAO.updateCartPart(serviceContext,cartDTO);
    }

    private void initQueryDTO(ServiceContext serviceContext, CartItemQueryViewDTO query, QueryDTO queryDTO) {
        if(StringUtils.isNotBlank(query.getKeyword()) && Objects.nonNull(query.getKeywordType()) ){
            if(query.getKeywordType().equals(BizKeywordTypeEnum.CART_ID.getName())){
                queryDTO.andCondition(CartQuery.id.eq(Long.parseLong(query.getKeyword())));
            }
            if(query.getKeywordType().equals(BizKeywordTypeEnum.SPU_ID.getName())){
                queryDTO.andCondition(CartQuery.spuId.eq(Long.parseLong(query.getKeyword())));
            }
            if(query.getKeywordType().equals(BizKeywordTypeEnum.SKU_ID.getName())){
                queryDTO.andCondition(CartQuery.skuId.eq(Long.parseLong(query.getKeyword())));
            }
            if(query.getKeywordType().equals(BizKeywordTypeEnum.CAMPAIGN_GROUP_ID.getName())){
                queryDTO.andCondition(CartQuery.campaignGroupId.eq(Long.parseLong(query.getKeyword())));
            }
        }
        if(Objects.nonNull(query.getType())){
            queryDTO.andCondition(CartQuery.type.eq(query.getType()));
        }
        if(CollectionUtils.isNotEmpty(query.getIdList())){
            queryDTO.andCondition(CartQuery.id.in(query.getIdList()));
        }
        if(CollectionUtils.isNotEmpty(query.getStatusList())){
            queryDTO.andCondition(CartQuery.status.in(query.getStatusList()));
        } else {
            queryDTO.andCondition(CartQuery.status.notEq(BrandCartItemStatusEnum.DELETE.getCode()));
        }
        if(CollectionUtils.isNotEmpty(query.getSkuIdList())){
            queryDTO.andCondition(CartQuery.skuId.in(query.getSkuIdList()));
        }
        if(CollectionUtils.isNotEmpty(query.getSpuIdList())){
            queryDTO.andCondition(CartQuery.spuId.in(query.getSpuIdList()));
        }
        if(CollectionUtils.isNotEmpty(query.getCampaignGroupIds())){
            queryDTO.andCondition(CartQuery.campaignGroupId.in(query.getCampaignGroupIds()));
        }
        if(CollectionUtils.isNotEmpty(query.getMainCampaignGroupIds())){
            queryDTO.andCondition(CartQuery.mainCampaignGroupId.in(query.getMainCampaignGroupIds()));
        }
        if (Objects.nonNull(query.getBundleId())){
            queryDTO.andCondition(CartQuery.settingKeyValue.eq(BrandCartItemSettingKeyEnum.BUNDLE_ID.getKey(),String.valueOf(query.getBundleId())));
        }
        queryDTO.orderBy(CartQuery.gmtCreate.descOrder());
    }
}
