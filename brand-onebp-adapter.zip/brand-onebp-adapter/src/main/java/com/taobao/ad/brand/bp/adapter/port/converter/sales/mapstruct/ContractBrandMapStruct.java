package com.taobao.ad.brand.bp.adapter.port.converter.sales.mapstruct;

import com.alibaba.ad.nb.sales.dto.zhubajie.CompleteBrandDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesContractBrandViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author yuncheng.lyc
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ContractBrandMapStruct extends BaseMapStructMapper<CompleteBrandDTO, SalesContractBrandViewDTO> {
    ContractBrandMapStruct INSTANCE = Mappers.getMapper(ContractBrandMapStruct.class);

}