package com.taobao.ad.brand.bp.adapter.port.repository.oplog;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.oplog.dto.OpLogDTO;
import com.alibaba.ad.oplog.dto.OpLogQueryDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.oplog.OpLogQueryViewDTOConverter;
import com.taobao.ad.brand.bp.adapter.port.converter.oplog.OpLogViewDTOConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.oplog.OpLogSAO;
import com.taobao.ad.brand.bp.client.dto.oplog.OpLogQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.oplog.OpLogViewDTO;
import com.taobao.ad.brand.bp.domain.oplog.repository.OpLogRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author jixiu.lj
 * @date 2024/3/20 15:34
 */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class OpLogRepositoryImpl implements OpLogRepository {

    private final OpLogSAO opLogSAO;
    private final OpLogQueryViewDTOConverter opLogQueryViewDTOConverter;
    private final OpLogViewDTOConverter opLogViewDTOConverter;

    @Override
    public List<OpLogViewDTO> queryOpLog(ServiceContext serviceContext, OpLogQueryViewDTO opLogQueryViewDTO) {
        OpLogQueryDTO opLogQueryDTO = opLogQueryViewDTOConverter.convertViewDTO2DTO(opLogQueryViewDTO);
        List<OpLogDTO> opLogDTOList = opLogSAO.queryOpLog(serviceContext, opLogQueryDTO);
        return opLogViewDTOConverter.convertDTO2ViewDTOList(opLogDTOList);
    }
}
