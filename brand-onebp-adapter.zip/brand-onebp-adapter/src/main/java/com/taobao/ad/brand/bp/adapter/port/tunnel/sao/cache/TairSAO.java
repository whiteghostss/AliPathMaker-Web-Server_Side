package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.cache;

import java.io.Serializable;

import com.alibaba.hermes.framework.tunnel.sao.SAO;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.github.rholder.retry.Attempt;
import com.github.rholder.retry.RetryException;
import com.github.rholder.retry.Retryer;
import com.github.rholder.retry.RetryerBuilder;
import com.github.rholder.retry.StopStrategies;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.tair.DataEntry;
import com.taobao.tair.Result;
import com.taobao.tair.ResultCode;
import com.taobao.tair.TairManager;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import lombok.RequiredArgsConstructor;

/**
 * @author 虫洞 <liuming.liu@alibaba-inc.com>
 * @date 2023/6/5
 */
@Component
@RequiredArgsConstructor
public class TairSAO implements SAO {
    private static final int DEFAULT_NAME_SPACE = 175;
    private static final int DEFAULT_EXPIRE_TIME = 600;
    private static final int DEFAULT_VERSION = 0;

    private final TairManager tairManager;

    @Value("${tair.ldb.namespace}")
    private Integer ldbNamespace;

    private final Retryer<ResultCode> retryer = RetryerBuilder.<ResultCode>newBuilder()
        .retryIfException()
        .retryIfResult(e -> !e.isSuccess())
        .withStopStrategy(StopStrategies.stopAfterAttempt(2))
        .build();


    public void put(String key, Serializable value) {
        this.put(ldbNamespace, key, value, DEFAULT_VERSION, DEFAULT_EXPIRE_TIME);
    }

    public void put(String key, Serializable value, int expire) {
        this.put(ldbNamespace, key, value, DEFAULT_VERSION, expire);
    }

    public void delete(String key) {
        try {
            ResultCode resultCode = retryer.call(() -> tairManager.invalid(ldbNamespace, key));
            if (!resultCode.isSuccess()) {
                RogerLogger.info("tair delete fail, msg: {}", resultCode.getMessage());
            }
        } catch (Exception e) {
            RogerLogger.error("tair delete fail, msg: {}", e.getMessage(), e);
        }
    }

    public Object get(String key) {
        return this.get(ldbNamespace, key);
    }

    private Object get(int namespace, String key) {
        try {
            Result<DataEntry> r = tairManager.get(namespace, key);
            if (r.isSuccess() && r.getValue() != null) {
                return r.getValue().getValue();
            }
        } catch (Exception e) {
            RogerLogger.error("tair get fail, msg: {}", e.getMessage(), e);
        }
        return null;
    }


    private boolean put(int namespace, String key, Serializable value, int version, int expireTime) {
        AssertUtil.notNull(value, "cache value cannot be null");

        try {
            ResultCode r = retryer.call(() -> tairManager.put(namespace, key, value, version, expireTime));
            if (r.isSuccess()) {
                return true;
            }
            RogerLogger.info("tair put fail, msg: {}", r.getMessage());
            return false;
        } catch (Exception e) {
            if (e instanceof RetryException) {
                try {
                    Attempt<?> attempt = ((RetryException) e).getLastFailedAttempt();
                    StringBuilder error = new StringBuilder();
                    if (attempt.hasResult()) {
                        error.append(((ResultCode) attempt.getResult()).getMessage());
                    } else if (attempt.hasException()) {
                        error.append(attempt.getExceptionCause());
                    }
                    RogerLogger.error("tair put fail, msg: {}", error.toString(), e);
                } catch (Exception ignore) {
                }
            } else {
                RogerLogger.error("tair put fail, msg: {}", e.getMessage(), e);
            }
        }
        return false;
    }
}
