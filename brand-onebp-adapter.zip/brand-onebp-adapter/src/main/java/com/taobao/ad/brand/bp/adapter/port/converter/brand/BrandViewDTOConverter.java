package com.taobao.ad.brand.bp.adapter.port.converter.brand;

import com.alibaba.ad.brand.dto.common.BrandViewDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.brand.mapstruct.BrandViewDTOMapStruct;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import com.taobao.brand.domain.Brand;
import org.springframework.stereotype.Component;

/**
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@Component
public class BrandViewDTOConverter extends BaseViewDTOConverter<Brand, BrandViewDTO> {


    @Override
    public BaseMapStructMapper<Brand, BrandViewDTO> getBaseMapStructMapper() {
        return BrandViewDTOMapStruct.INSTANCE;
    }
}
