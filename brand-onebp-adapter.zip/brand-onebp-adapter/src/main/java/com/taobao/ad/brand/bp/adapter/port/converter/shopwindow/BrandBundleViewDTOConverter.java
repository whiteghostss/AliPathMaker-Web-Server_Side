package com.taobao.ad.brand.bp.adapter.port.converter.shopwindow;


import com.taobao.ad.brand.bp.adapter.port.converter.shopwindow.mapstruct.BrandBundleMapStruct;
import com.taobao.ad.brand.bp.adapter.port.converter.shopwindow.mapstruct.BrandBundleQueryMapStruct;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandBundleViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.query.BrandBundleQueryViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import com.taobao.ad.brand.perform.client.dto.shopwindow.bundle.BundleQueryViewDTO;
import com.taobao.ad.brand.perform.client.dto.shopwindow.bundle.BundleViewDTO;
import org.springframework.stereotype.Component;

@Component
public class BrandBundleViewDTOConverter extends BaseViewDTOConverter<BundleViewDTO, BrandBundleViewDTO> {

    @Override
    public BaseMapStructMapper<BundleViewDTO, BrandBundleViewDTO> getBaseMapStructMapper() {
        return BrandBundleMapStruct.INSTANCE;
    }

    public BundleQueryViewDTO sourceToQueryTarget(BrandBundleQueryViewDTO queryViewDTO){
        return BrandBundleQueryMapStruct.INSTANCE.sourceToTarget(queryViewDTO);
    }
}
