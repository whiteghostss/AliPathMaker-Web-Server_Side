package com.taobao.ad.brand.bp.adapter.port.converter.motion.mapstruct;

import com.alibaba.ad.nb.packages.v2.client.dto.motion.ProductBandPriceStrategyDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.motion.ProductStrategyDTO;
import com.taobao.ad.brand.bp.client.dto.motion.ProductBandPriceStrategyViewDTO;
import com.taobao.ad.brand.bp.client.dto.motion.ProductStrategyViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/18
 **/
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ProductBandPriceStrategyMapStruct extends BaseMapStructMapper<ProductBandPriceStrategyDTO, ProductBandPriceStrategyViewDTO> {

    ProductBandPriceStrategyMapStruct INSTANCE = Mappers.getMapper(ProductBandPriceStrategyMapStruct.class);

    @Mappings({
            @Mapping(source = "predictData", target = "predictDataViewDTO"),
            @Mapping(source = "startDate", target = "startTime"),
            @Mapping(source = "endDate", target = "endTime"),
    })
    @Override
    ProductBandPriceStrategyViewDTO sourceToTarget(ProductBandPriceStrategyDTO productBandPriceStrategyDTO);

    @Mappings({
            @Mapping(source = "predictDataViewDTO", target = "predictData"),
            @Mapping(source = "startTime", target = "startDate"),
            @Mapping(source = "endTime", target = "endDate"),
    })
    @Override
    ProductBandPriceStrategyDTO targetToSource(ProductBandPriceStrategyViewDTO productBandPriceStrategyViewDTO);
}
