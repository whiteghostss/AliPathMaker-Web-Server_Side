package com.taobao.ad.brand.bp.adapter.port.converter.resourcepackage.mapstruct;

import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import com.alibaba.ad.nb.packages.dto.common.CommonDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.product.ResourcePackageProductDTO;

import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import org.apache.commons.collections4.CollectionUtils;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/23
 */
public abstract class ResourcePackageProductMapStructDecorator implements ResourcePackageProductMapStruct {

    private final ResourcePackageProductMapStruct resourcePackageProductMapStruct;

    public ResourcePackageProductMapStructDecorator(ResourcePackageProductMapStruct resourcePackageProductMapStruct) {
        this.resourcePackageProductMapStruct = resourcePackageProductMapStruct;
    }

    @Override
    public ResourcePackageProductViewDTO sourceToTarget(ResourcePackageProductDTO resourcePackageProductDTO) {
        ResourcePackageProductViewDTO resourcePackageProductViewDTO = resourcePackageProductMapStruct.sourceToTarget(resourcePackageProductDTO);
        List<ResourcePackageProductPriceViewDTO> bandPriceList = resourcePackageProductViewDTO.getBandPriceList();
        if (CollectionUtils.isNotEmpty(bandPriceList)) {
            Date startTime = bandPriceList.stream().map(ResourcePackageProductPriceViewDTO::getStartDate).min(Comparator.naturalOrder()).get();
            Date endTime = bandPriceList.stream().map(ResourcePackageProductPriceViewDTO::getEndDate).max(Comparator.naturalOrder()).get();
            resourcePackageProductViewDTO.setStartTime(startTime);
            resourcePackageProductViewDTO.setEndTime(endTime);
        }
        if (CollectionUtils.isNotEmpty(resourcePackageProductDTO.getSspTemplateList())) {
            List<CommonDTO> sspTemplateList = resourcePackageProductDTO.getSspTemplateList();
            Set<String> valueSet = sspTemplateList.stream().filter(v -> Boolean.TRUE.equals(v.getSelected())).map(v -> v.getValue()).collect(
                Collectors.toSet());
            if (CollectionUtils.isNotEmpty(valueSet)) {
                List<CommonViewDTO> commonViewDTOList = resourcePackageProductViewDTO.getSspTemplateList().stream().filter(
                    v -> valueSet.contains(v.getValue()))
                    .collect(Collectors.toList());
                resourcePackageProductViewDTO.setSspTemplateList(commonViewDTOList);
            }
        }
        if (CollectionUtils.isNotEmpty(resourcePackageProductDTO.getSubProductDTOList())) {
            List<ResourcePackageProductViewDTO> resourcePackageProductViewDTOS = sourceToTarget(
                resourcePackageProductDTO.getSubProductDTOList());
            resourcePackageProductViewDTO.setSubResourcePackageProductList(resourcePackageProductViewDTOS);
        }
        return resourcePackageProductViewDTO;
    }

    @Override
    public ResourcePackageProductDTO targetToSource(ResourcePackageProductViewDTO resourcePackageProductViewDTO) {
        return resourcePackageProductMapStruct.targetToSource(resourcePackageProductViewDTO);
    }
}