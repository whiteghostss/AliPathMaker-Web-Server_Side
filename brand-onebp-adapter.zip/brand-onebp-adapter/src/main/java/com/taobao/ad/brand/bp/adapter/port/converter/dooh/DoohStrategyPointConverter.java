package com.taobao.ad.brand.bp.adapter.port.converter.dooh;

import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.adapter.port.converter.dooh.mapstruct.DoohStrategyPointMapStruct;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohStrategyPointQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohStrategyPointViewDTO;
import com.taobao.ad.brand.bp.client.enums.dooh.DoohStrategyPointSourceEnum;
import com.taobao.ad.brand.bp.client.enums.dooh.DoohStrategyPointTypeEnum;
import com.taobao.ad.brand.bp.common.constant.CommonConstant;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import com.umeng.oplus.domain.dto.bailing.SchemeMediaInfoDTO;
import com.umeng.oplus.domain.emuntype.dsp.scheme.DspSchemeMediaSignType;
import com.umeng.oplus.domain.query.dsp.presale.DspPresaleMedia4BailingQuery;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.math.RoundingMode;
import java.util.List;

@Component
public class DoohStrategyPointConverter extends BaseViewDTOConverter<SchemeMediaInfoDTO, DoohStrategyPointViewDTO> {
    @Override
    public BaseMapStructMapper<SchemeMediaInfoDTO, DoohStrategyPointViewDTO> getBaseMapStructMapper() {
        return DoohStrategyPointMapStruct.INSTANCE;
    }

    @Override
    public DoohStrategyPointViewDTO convertDTO2ViewDTO(SchemeMediaInfoDTO schemeMediaInfoDTO){
        if(schemeMediaInfoDTO == null){
            return null;
        }
        DoohStrategyPointViewDTO viewDTO = new DoohStrategyPointViewDTO();
        viewDTO.setId(schemeMediaInfoDTO.getOplusMediaId());
        viewDTO.setName(schemeMediaInfoDTO.getMediaName());
        viewDTO.setAddress(schemeMediaInfoDTO.getMediaAddress());
        viewDTO.setUrl(schemeMediaInfoDTO.getSampleImageUrl());
        if(schemeMediaInfoDTO.getWeight() != null){
            viewDTO.setTgi(schemeMediaInfoDTO.getWeight().setScale(2, RoundingMode.HALF_UP));
        }

        viewDTO.setDeviceType(schemeMediaInfoDTO.getDeviceTypeId());
        viewDTO.setDeviceTypeName(schemeMediaInfoDTO.getDeviceTypeName());
        if(schemeMediaInfoDTO.getDspSchemeMediaSignType() != null){
            DoohStrategyPointTypeEnum pointOpTypeEnum = DoohStrategyPointTypeEnum.getStrategyPointOpTypeByDooh(schemeMediaInfoDTO.getDspSchemeMediaSignType().getCode());
            if(pointOpTypeEnum != null){
                viewDTO.setType(pointOpTypeEnum.getCode());
            }
        }
        if(schemeMediaInfoDTO.getDspSchemeMediaSignType() != null){
            if(DspSchemeMediaSignType.ADD.equals(schemeMediaInfoDTO.getDspSchemeMediaSignType())){
                viewDTO.setIsAdd(CommonConstant.YES);
                viewDTO.setIsRemove(CommonConstant.NO);
            }else if(DspSchemeMediaSignType.REMOVE.equals(schemeMediaInfoDTO.getDspSchemeMediaSignType())){
                viewDTO.setIsAdd(CommonConstant.NO);
                viewDTO.setIsRemove(CommonConstant.YES);
            }else{
                viewDTO.setIsAdd(CommonConstant.NO);
                viewDTO.setIsRemove(CommonConstant.NO);
            }
        } else {
            viewDTO.setIsAdd(CommonConstant.NO);
            viewDTO.setIsRemove(CommonConstant.NO);
        }
        return viewDTO;
    }

    @Override
    public List<DoohStrategyPointViewDTO> convertDTO2ViewDTOList(List<SchemeMediaInfoDTO> schemeMediaInfoDTOList){
        if(CollectionUtils.isEmpty(schemeMediaInfoDTOList)){
            return Lists.newArrayList();
        }
        List<DoohStrategyPointViewDTO> result = Lists.newArrayList();
        schemeMediaInfoDTOList.forEach(dto-> result.add(convertDTO2ViewDTO(dto)));
        return result;
    }

    public DspPresaleMedia4BailingQuery convertQueryViewDTO2DTO(DoohStrategyPointQueryViewDTO queryViewDTO){
        if(queryViewDTO == null){
            return null;
        }
        DspPresaleMedia4BailingQuery query = new DspPresaleMedia4BailingQuery();
        query.setPageNo(queryViewDTO.getPageNo());
        query.setPageSize(queryViewDTO.getPageSize());
        query.setCityCodes(queryViewDTO.getAreaList());
        query.setDeviceCodes(queryViewDTO.getDeviceTypeList());
        query.setKeyword(queryViewDTO.getKeyword());
        query.setDspSchemeId(queryViewDTO.getStrategyId());
        query.setDspQuickSchemeMediaType(DoohStrategyPointSourceEnum.getDoohPointSource(queryViewDTO.getSource()));
        if(DoohStrategyPointSourceEnum.USER_DEFINED.getCode().equals(queryViewDTO.getSource()) && queryViewDTO.getType() != null){
            query.setCode(queryViewDTO.getType());
        }else if(DoohStrategyPointSourceEnum.RECOMMEND.getCode().equals(queryViewDTO.getSource()) && CollectionUtils.isNotEmpty(queryViewDTO.getDeviceTypeList())){
            query.setCode(queryViewDTO.getDeviceTypeList().get(0));
        }
        return query;
    }
}
