package com.taobao.ad.brand.bp.adapter.port.converter.materialrule;

import com.alibaba.ad.nb.ssp.dto.material.MaterialRuleDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.materialrule.mapstruct.MaterialRuleMapStruct;
import com.taobao.ad.brand.bp.client.dto.mr.MaterialRuleViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.springframework.stereotype.Component;

/**
 * @author ：yunhu.myh
 * @date ：2023年09月30日
 */
@Component
public class MaterialRuleConverter extends BaseViewDTOConverter<MaterialRuleDTO, MaterialRuleViewDTO> {

    @Override
    public BaseMapStructMapper<MaterialRuleDTO, MaterialRuleViewDTO> getBaseMapStructMapper() {
        return MaterialRuleMapStruct.INSTANCE;
    }
}
