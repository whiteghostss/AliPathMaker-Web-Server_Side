package com.taobao.ad.brand.bp.adapter.port.converter.resourcepackage.mapstruct;

import com.alibaba.ad.nb.packages.dto.project.ProjectDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProjectViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author yanjingang
 * @date 2024/03/25
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ResourcePackageProjectMapStruct extends BaseMapStructMapper<ProjectDTO, ResourcePackageProjectViewDTO> {

    ResourcePackageProjectMapStruct INSTANCE = Mappers.getMapper(ResourcePackageProjectMapStruct.class);
}