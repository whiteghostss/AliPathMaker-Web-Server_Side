package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.campaign;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.audience.api.BindAdzoneCommandService;
import com.alibaba.ad.audience.api.BindCrowdCommandService;
import com.alibaba.ad.audience.api.CampaignBindAdzoneQueryService;
import com.alibaba.ad.audience.api.CampaignBindCrowdQueryService;
import com.alibaba.ad.audience.api.label.LabelQueryService;
import com.alibaba.ad.audience.constants.BindDimensionEnum;
import com.alibaba.ad.audience.dto.CrowdQueryDTO;
import com.alibaba.ad.audience.dto.bind.BindAdzoneDTO;
import com.alibaba.ad.audience.dto.bind.BindCrowdDTO;
import com.alibaba.ad.audience.dto.bind.BindDimensionDTO;
import com.alibaba.ad.audience.dto.bind.DeleteCrowdDTO;
import com.alibaba.ad.audience.dto.label.LabelDTO;
import com.alibaba.ad.audience.dto.label.query.LabelQueryDTO;
import com.alibaba.ad.audience.dto.query.BindAdzoneQuery;
import com.alibaba.ad.audience.dto.query.BindCrowdQuery;
import com.alibaba.ad.audience.dto.query.BindCrowdQueryOptionDTO;
import com.alibaba.ad.brand.sdk.constant.audience.field.BrandTargetTypeEnum;
import com.alibaba.ad.organizer.api.CampaignCommandService;
import com.alibaba.ad.organizer.api.CampaignDealRefQueryService;
import com.alibaba.ad.organizer.api.CampaignQueryService;
import com.alibaba.ad.organizer.dto.CampaignDTO;
import com.alibaba.ad.organizer.dto.CampaignDealRefDTO;
import com.alibaba.ad.organizer.dto.CampaignInquiryDTO;
import com.alibaba.ad.organizer.dto.query.CampaignDealRefQuery;
import com.alibaba.hermes.framework.dto.response.CountResponse;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.alibaba.hermes.framework.utils.BeanUtils;
import com.alibaba.solar.common.dto.QueryOptionDTO;
import com.alibaba.solar.common.query.dto.PageQueryDTO;
import com.alibaba.solar.common.query.dto.QueryDTO;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Component
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CampaignSAO extends BaseSAO {
    private final CampaignQueryService campaignQueryService;
    private final CampaignCommandService campaignCommandService;
    private final CampaignBindAdzoneQueryService campaignBindAdzoneQueryService;
    private final CampaignBindCrowdQueryService campaignBindCrowdQueryService;
    private final BindCrowdCommandService bindCrowdCommandService;
    private final BindAdzoneCommandService bindAdzoneCommandService;
    private final CampaignDealRefQueryService campaignDealRefQueryService;

    private final LabelQueryService labelQueryService;


    public MultiResponse<CampaignDTO> queryCampaignPageList(ServiceContext serviceContext, PageQueryDTO pageQueryDTO ) {
        MultiResponse<CampaignDTO> response =  campaignQueryService.findCampaignPage(serviceContext,pageQueryDTO,QueryOptionDTO.propertyRequired(true));
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response;
    }


    public List<CampaignDTO> queryCampaignList(ServiceContext serviceContext, QueryDTO queryDTO ) {
        MultiResponse<CampaignDTO> response =  campaignQueryService.findCampaignList(serviceContext,queryDTO,QueryOptionDTO.propertyRequired(true));
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }



    public int queryCampaignListCount(ServiceContext serviceContext, QueryDTO queryDTO ) {
        CountResponse response =  campaignQueryService.getCampaignCount(serviceContext,queryDTO);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getCount();
    }
    public boolean queryIsBindCampaign(ServiceContext serviceContext, Long crowdId ) {
        CrowdQueryDTO crowdQueryDTO = new CrowdQueryDTO();
        crowdQueryDTO.setSubcrowdValue(String.valueOf(crowdId));
        crowdQueryDTO.setTargetType(BrandTargetTypeEnum.DMP_CROWD.getCode().longValue());
        SingleResponse<Boolean> response =  campaignBindCrowdQueryService.findCampaignIdByCrowd(serviceContext,crowdQueryDTO);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 根据id获取中台计划
     * @param serviceContext
     * @param id
     * @return
     */
    public CampaignDTO getCampaignById(ServiceContext serviceContext, Long id) {
        SingleResponse<CampaignDTO> response = campaignQueryService.getCampaignById(serviceContext, id);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        AssertUtil.notNull(response.getResult(), "账号 " + serviceContext.getMemberId() + " 下不存在该计划 " + id);
        return response.getResult();
    }

    /**
     *
     * 创建中台计划
     * @param serviceContext
     * @param campaignGroupId 订单id（对应中台campaignGroup）
     * @param campaignDTO
     */
    public Long addCampaign(ServiceContext serviceContext, Long campaignGroupId, CampaignDTO campaignDTO) {
        SingleResponse<Long> response = campaignCommandService.addCampaign(serviceContext, campaignGroupId, campaignDTO, Lists.newArrayList());
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }



    /**
     *
     * 创建中台计划
     * @param serviceContext
     * @param campaignDTO
     */
    public Long addCampaign(ServiceContext serviceContext, CampaignDTO campaignDTO) {
        SingleResponse<Long> response = campaignCommandService.addCampaign(serviceContext, campaignDTO, Lists.newArrayList());
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }


    public void physicsDelCampaign(ServiceContext serviceContext,Long campaignId){
        SingleResponse<Integer> response = campaignCommandService.deleteCampaign(serviceContext, campaignId);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
    }
    /**
     *
     * 批量更新计划
     * @param serviceContext
     * @param campaignDTO
     */
    public Integer updateCampaignSetting(ServiceContext serviceContext, CampaignDTO campaignDTO) {
        SingleResponse<Integer> response = campaignCommandService.updateCampaignPart(serviceContext, campaignDTO);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    public Integer updateCampaignInquiryAll(ServiceContext serviceContext, Long campaignId, List<CampaignInquiryDTO> inquiryDTOList) {
        SingleResponse<Integer> response = campaignCommandService.updateCampaignInquiryAll(serviceContext, campaignId, inquiryDTOList);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    public Integer deleteCampaignSettingBatch(ServiceContext serviceContext, Long campaignId, List<String> settingKeyList) {
        SingleResponse<Integer> response = campaignCommandService.deleteCampaignSettingBatch(serviceContext, campaignId, settingKeyList);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     *
     * 批量更新计划
     * @param serviceContext
     * @param campaignDTO
     */
    public Integer updateCampaignPart(ServiceContext serviceContext, CampaignDTO campaignDTO) {
        SingleResponse<Integer> response = campaignCommandService.updateCampaignPart(serviceContext, campaignDTO);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 全量更新
     * @param serviceContext
     * @param campaignDTO
     * @return
     */
    public Integer updateCampaignAll(ServiceContext serviceContext, CampaignDTO campaignDTO) {
        SingleResponse<Integer> response = campaignCommandService.updateCampaignAll(serviceContext, campaignDTO, Lists.newArrayList());
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    /**
     * 创建中台定向
     * @param serviceContext
     * @param bindCrowdDTOList
     */
    public void addCampaignCrowd(ServiceContext serviceContext, List<BindCrowdDTO> bindCrowdDTOList) {
        BindDimensionDTO bindDimensionDTO = new BindDimensionDTO();
        bindDimensionDTO.setBindDimension(BindDimensionEnum.CAMPAIGN.getValue());
        List<BindCrowdDTO> lastBindCrowdDTOList = getBindCrowdDTOListSplitByCrowdScore(bindCrowdDTOList);
        SingleResponse<Integer> response = bindCrowdCommandService.add(serviceContext, lastBindCrowdDTOList, bindDimensionDTO);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
    }

    /**
     * 修改中台定向
     * @param serviceContext
     * @param bindCrowdDTOList
     */
    public void updateCampaignCrowd(ServiceContext serviceContext, List<BindCrowdDTO> bindCrowdDTOList) {
        BindDimensionDTO bindDimensionDTO = new BindDimensionDTO();
        bindDimensionDTO.setBindDimension(BindDimensionEnum.CAMPAIGN.getValue());
        List<BindCrowdDTO> lastBindCrowdDTOList = getBindCrowdDTOListSplitByCrowdScore(bindCrowdDTOList);
        SingleResponse<Integer> response = bindCrowdCommandService.updateAll(serviceContext, lastBindCrowdDTOList, bindDimensionDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
    }

    /**
     * 新增或修改中台定向（新增或修改指定类型，不会覆盖所有）
     * @param serviceContext
     * @param bindCrowdDTOList
     */
    public void addOrUpdateBatchCampaignCrowd(ServiceContext serviceContext, List<BindCrowdDTO> bindCrowdDTOList) {
        BindDimensionDTO bindDimensionDTO = new BindDimensionDTO();
        bindDimensionDTO.setBindDimension(BindDimensionEnum.CAMPAIGN.getValue());
        List<BindCrowdDTO> lastBindCrowdDTOList = getBindCrowdDTOListSplitByCrowdScore(bindCrowdDTOList);
        SingleResponse<Integer> response = bindCrowdCommandService.addOrUpdateBatch(serviceContext, lastBindCrowdDTOList, bindDimensionDTO);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
    }

    private List<BindCrowdDTO> getBindCrowdDTOListSplitByCrowdScore(List<BindCrowdDTO> bindCrowdDTOList) {
        List<BindCrowdDTO> lastBindCrowdDTOList = Lists.newArrayList();
        if (CollectionUtils.isEmpty(bindCrowdDTOList)) {
            return lastBindCrowdDTOList;
        }
        for (BindCrowdDTO bindCrowdDTO : bindCrowdDTOList) {
            if (Objects.nonNull(bindCrowdDTO.getTagDTO()) && Long.valueOf(BrandTargetTypeEnum.ALI_CROWD_SCORE.getCode()).equals(bindCrowdDTO.getTagDTO().getTagRefType())) {
                for (String tagValue : bindCrowdDTO.getTagDTO().getTagValueList()) {
                    BindCrowdDTO splitBindCrowdDTO = BeanUtils.copy(bindCrowdDTO, new BindCrowdDTO());
                    splitBindCrowdDTO.getTagDTO().setTagValueList(Lists.newArrayList(tagValue));
                    lastBindCrowdDTOList.add(splitBindCrowdDTO);
                }
            } else {
                lastBindCrowdDTOList.add(bindCrowdDTO);
            }
        }
        return lastBindCrowdDTOList;
    }

    /**
     * 删除中台定向
     * @param serviceContext
     * @param campaignId
     */
    public void deleteCampaignCrowd(ServiceContext serviceContext, Long campaignId) {
        DeleteCrowdDTO deleteCrowdDTO = new DeleteCrowdDTO();
        deleteCrowdDTO.setCampaignId(campaignId);
        BindDimensionDTO bindDimensionDTO = new BindDimensionDTO();
        bindDimensionDTO.setBindDimension(BindDimensionEnum.CAMPAIGN.getValue());
        SingleResponse<Integer> response = bindCrowdCommandService.deletePart(serviceContext, deleteCrowdDTO, bindDimensionDTO);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
    }

    /**
     * 删除中台人群定向
     * @param serviceContext
     */
    public void deleteCampaignCrowdByAudienceCrowdIds(ServiceContext serviceContext, List<Long> audienceCrowdIds) {
        if (CollectionUtils.isEmpty(audienceCrowdIds)) {
            return;
        }
        BindDimensionDTO bindDimensionDTO = new BindDimensionDTO();
        bindDimensionDTO.setBindDimension(BindDimensionEnum.CAMPAIGN.getValue());
        SingleResponse<Integer> response = bindCrowdCommandService.deleteByCrowdId(serviceContext, audienceCrowdIds, bindDimensionDTO);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
    }

    /**
     * 删除中台定向-指定定向类型删除
     */
    public void deleteCampaignCrowd(ServiceContext serviceContext, Long campaignId, BrandTargetTypeEnum targetTypeEnum) {
        DeleteCrowdDTO deleteCrowdDTO = new DeleteCrowdDTO();
        deleteCrowdDTO.setCampaignId(campaignId);
        deleteCrowdDTO.setTargetType(Long.valueOf(targetTypeEnum.getCode()));
        BindDimensionDTO bindDimensionDTO = new BindDimensionDTO();
        bindDimensionDTO.setBindDimension(BindDimensionEnum.CAMPAIGN.getValue());
        SingleResponse<Integer> response = bindCrowdCommandService.deletePart(serviceContext, deleteCrowdDTO, bindDimensionDTO);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
    }

    /**
     * 创建中台Adzone
     * @param serviceContext
     * @param bindAdzoneDTOList
     */
    public void addCampaignAdzone(ServiceContext serviceContext, List<BindAdzoneDTO> bindAdzoneDTOList) {
        SingleResponse<Integer> response = bindAdzoneCommandService.add(serviceContext, bindAdzoneDTOList);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
    }



    /**
     * 创建中台Adzone
     * @param serviceContext
     */
    public void delCampaignAdzoneByCampaignId(ServiceContext serviceContext, Long campaignId) {
        SingleResponse<Integer> response = bindAdzoneCommandService.deleteByCampaignId(serviceContext, campaignId);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
    }


    /**
     * 创建中台Adzone
     * @param serviceContext
     * @param bindAdzoneDTOList
     */
    public void updateCampaignAdzoneAll(ServiceContext serviceContext, List<BindAdzoneDTO> bindAdzoneDTOList) {
        SingleResponse<Integer> response = bindAdzoneCommandService.updateAll(serviceContext, bindAdzoneDTOList);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
    }


    /**
     * 查询计划绑定定向
     * @param serviceContext
     * @param campaignIds
     * @return
     */
    public List<BindCrowdDTO> findBindCrowdDTO(ServiceContext serviceContext, List<Long> campaignIds) {
        QueryDTO queryDTO = QueryDTO.createQuery();
        queryDTO.andCondition(BindCrowdQuery.campaignId.in(campaignIds));
        return doFindBindCrowd(serviceContext, queryDTO);
    }

    /**
     * 查询计划绑定定向
     * @param serviceContext
     * @param campaignId
     * @return
     */
    public List<BindCrowdDTO> findBindCrowdByType(ServiceContext serviceContext, Long campaignId, BrandTargetTypeEnum targetTypeEnum) {
        QueryDTO queryDTO = QueryDTO.createQuery();
        queryDTO.andCondition(BindCrowdQuery.campaignId.eq(campaignId));
        queryDTO.andCondition(BindCrowdQuery.TARGET_TYPE.eq(targetTypeEnum.getCode().longValue()));
        return doFindBindCrowd(serviceContext, queryDTO);
    }

    private List<BindCrowdDTO> doFindBindCrowd(ServiceContext serviceContext, QueryDTO queryDTO) {
        BindCrowdQueryOptionDTO optionDTO = BindCrowdQueryOptionDTO.builder().crowdRequired(true).labelRequired(true).build();
        MultiResponse<BindCrowdDTO> response = campaignBindCrowdQueryService.findCampBindCrowdList(serviceContext, queryDTO, optionDTO);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        mergeByCrowdScore(response.getResult());
        return response.getResult();
    }


    private void mergeByCrowdScore(List<BindCrowdDTO> allBindCrowdDTOList) {
        Map<Long, List<BindCrowdDTO>> scoreBindCrowdDTOMap = allBindCrowdDTOList.stream()
                .filter(bindCrowdDTO -> Objects.nonNull(bindCrowdDTO.getTagDTO()) && Long.valueOf(BrandTargetTypeEnum.ALI_CROWD_SCORE.getCode()).equals(bindCrowdDTO.getTagDTO().getTagRefType()))
                .collect(Collectors.groupingBy(BindCrowdDTO::getCampaignId));
        if (scoreBindCrowdDTOMap.isEmpty()) {
            return;
        }
        List<BindCrowdDTO> mergeScoreBindCrowdDTOList = scoreBindCrowdDTOMap.values().stream().map(scoreBindCrowdDTOList -> {
            BindCrowdDTO bindCrowdDTO = scoreBindCrowdDTOList.get(0);
            bindCrowdDTO.getTagDTO().setTagValueList(scoreBindCrowdDTOList.stream().flatMap(scoreBindCrowdDTO -> scoreBindCrowdDTO.getTagDTO().getTagValueList().stream()).distinct().collect(Collectors.toList()));
            return bindCrowdDTO;
        }).collect(Collectors.toList());
        allBindCrowdDTOList.removeIf(it -> Objects.nonNull(it.getTagDTO()) && Long.valueOf(BrandTargetTypeEnum.ALI_CROWD_SCORE.getCode()).equals(it.getTagDTO().getTagRefType()));
        allBindCrowdDTOList.addAll(mergeScoreBindCrowdDTOList);
    }

    /**
     * 查询计划绑定adzone
     * @param serviceContext
     * @param campaignIds
     * @return
     */
    public List<BindAdzoneDTO> findBindAdzoneDTO(ServiceContext serviceContext, List<Long> campaignIds) {
        QueryDTO queryDTO = QueryDTO.createQuery();
        queryDTO.andCondition(BindAdzoneQuery.campaignId.in(campaignIds));
        QueryOptionDTO queryOptionDTO = QueryOptionDTO.propertyRequired(true);
        MultiResponse<BindAdzoneDTO> response =  campaignBindAdzoneQueryService.findCampBindAdzoneList(serviceContext, queryDTO, queryOptionDTO);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }


    public List<CampaignDealRefDTO> queryCampaignDealRefDTOList(ServiceContext serviceContext, List<Long> campaignIds) {
        QueryDTO queryDTO = QueryDTO.createQuery().andCondition(CampaignDealRefQuery.campaignId.in(campaignIds));
        MultiResponse<CampaignDealRefDTO> response =  campaignDealRefQueryService.findCampaignDealRefList(serviceContext,queryDTO);
        AssertUtil.assertTrue(response.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getErrorMsg()));
        return response.getResult();
    }

    public List<LabelDTO> getItemByIdList(ServiceContext serviceContext, List<Long> ids) {
        LabelQueryDTO labelQueryDTO = new LabelQueryDTO();
        labelQueryDTO.setLabelId(3000790L);
        labelQueryDTO.setNeedOption(true);
        List<String> optionValueList = ids.stream().map(String::valueOf).collect(Collectors.toList());
        labelQueryDTO.setOptionValueList(optionValueList);
        MultiResponse<LabelDTO> multiResponse = labelQueryService.findLabelListByLabelId(serviceContext, labelQueryDTO);
        AssertUtil.assertTrue(multiResponse.isSuccess(),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(multiResponse.getErrorMsg()));
        return multiResponse.getResult();
    }
}