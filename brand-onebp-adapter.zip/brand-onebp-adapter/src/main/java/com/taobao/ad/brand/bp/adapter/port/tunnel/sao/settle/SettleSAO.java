package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.settle;

import com.alibaba.ad.settle.billing.api.dto.accounting.request.StlCampaignAccountingRequestDTO;
import com.alibaba.ad.settle.billing.api.dto.accounting.response.StlCampaignAccountingResposneDTO;
import com.alibaba.ad.settle.billing.api.dto.base.response.MultiResponse;
import com.alibaba.ad.settle.billing.api.gateway.accounting.StlAccountingDetailService;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * @author yanjingang
 * @date 2023/4/5
 */
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SettleSAO extends BaseSAO {

    private final StlAccountingDetailService stlAccountingDetailService;

    public List<StlCampaignAccountingResposneDTO> getHisAccountingResWithOrder(StlCampaignAccountingRequestDTO requestDTO) {
        MultiResponse<StlCampaignAccountingResposneDTO> response = stlAccountingDetailService.getHisAccountingResWithOrder(requestDTO);
        AssertUtil.assertTrue(response.isSuccess(), BrandOneBPBaseErrorCode.RPC_ERROR, response.getErrorMsg());
        return response.getResult();
    }

}
