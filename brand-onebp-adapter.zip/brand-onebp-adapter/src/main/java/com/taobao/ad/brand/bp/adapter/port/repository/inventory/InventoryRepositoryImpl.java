package com.taobao.ad.brand.bp.adapter.port.repository.inventory;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.biz.definition.constants.Product;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.audience.CampaignTargetViewDTO;
import com.alibaba.ad.brand.dto.campaign.audience.CampaignTargetScenarioViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.DayAmountViewDTO;
import com.alibaba.ad.brand.dto.campaign.guarantee.CampaignGuaranteeViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryLockViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignMediaInquiryViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.audience.field.BrandTargetTypeEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.*;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupPurchaseStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.alibaba.ad.brand.sdk.constant.frequency.field.BrandFrequencyBizTypeEnum;
import com.alibaba.ad.nb.packages.constant.ud.UdSaleUnitEnum;
import com.alibaba.ad.nb.packages.v2.client.dto.template.ResourcePackageTemplateDTO;
import com.alibaba.ad.nb.ssp.constant.common.DictTypeEnum;
import com.alibaba.ad.nb.ssp.constant.common.MediaScopeEnum;
import com.alibaba.ad.nb.ssp.dto.dict.AreaDTO;
import com.alibaba.ad.nb.ssp.dto.dict.DictionaryDTO;
import com.alibaba.ad.nb.ssp.dto.template.NbTemplateDTO;
import com.alibaba.ad.organizer.dto.FrequencyRefDTO;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.hermes.framework.utils.DateUtils;
import com.alibaba.uad.wto.constant.PlatformBusinessEnum;
import com.alibaba.uad.wto.constant.SellTypeEnum;
import com.alibaba.uad.wto.constant.purchase.OrderPurchaseModeEnum;
import com.alibaba.uad.wto.constant.purchase.SchedulePurchaseModeEnum;
import com.alibaba.uad.wto.constant.purchase.SchedulePutTypeEnum;
import com.alibaba.uad.wto.dto.purchase.UdContentPurchaseOrderCreationDTO;
import com.alibaba.uad.wto.dto.purchase.UdContentPurchaseOrderCreationDTO.UdContentScheduleCreationDTO;
import com.alibaba.uad.wto.dto.purchase.UdContentPurchaseOrderCreationDTO.UdContentScheduleCycleCreationDTO;
import com.alibaba.uad.wto.dto.purchase.query.PurchaseOrderQueryDTO;
import com.alibaba.uad.wto.hsf.dto.AddPolicyNode;
import com.alibaba.uad.wto.hsf.dto.PurchaseOrderDTO;
import com.alibaba.uad.wto.hsf.dto.ResourceScheduleCycleDTO;
import com.alibaba.uad.wto.hsf.dto.enums.PurchaseOrderStatusEnum;
import com.alibaba.uad.wto.hsf.dto.inquiry.InquiryAmountDTO;
import com.alibaba.uad.wto.hsf.dto.inquiry.InquiryDTO;
import com.alibaba.uad.wto.hsf.dto.inquiry.InquiryGroupDTO;
import com.alibaba.uad.wto.hsf.dto.inquiry.InquiryResDTO;
import com.alibaba.uad.wto.hsf.dto.purchase.SystemCreateResourceScheduleDTO;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.alimama.inventory.dto.ud.*;
import com.alimama.inventory.dto.ud.InventoryUdBaseDTO.ProgramMode;
import com.alimama.inventory.dto.universal.UniInquiryRequest;
import com.alimama.inventory.dto.universal.UniReleaseRequest;
import com.alimama.inventory.dto.universal.UniRequest;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.adapter.port.converter.inventory.InventoryConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.MemberSAO;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.frequency.FrequencySAO;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.inventory.InventorySAO;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.perform.PerformSAO;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.resourcepackage.ResourcePackageSAO;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.ssp.ProductSAO;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.ssp.TemplateSAO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignScheduleViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupPurchaseProcessViewDTO;
import com.taobao.ad.brand.bp.client.dto.inventory.InventoryDetailsDayAmountViewDTO;
import com.taobao.ad.brand.bp.client.dto.inventory.InventoryDetailsViewDTO;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.BrandLocalDateTimeUtil;
import com.taobao.ad.brand.bp.common.util.NumberUtil;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.domain.inventory.InventoryRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/03/08
 */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class InventoryRepositoryImpl implements InventoryRepository {

    private final InventorySAO inventorySAO;
    private final InventoryConverter inventoryConverter;
    private final ProductSAO productSAO;
    private final MemberSAO memberSAO;
    private final Integer RETURN_TYPE_NAME = 0;
    private final Integer RETURN_TYPE_VALUE = 1;
    private final TemplateSAO templateSAO;
    private final ResourcePackageSAO resourcePackageSAO;
    private final FrequencySAO frequencySAO;
    private final PerformSAO performSAO;

    private final List<Integer> unLockSuccessStatusList = Lists.newArrayList(BrandCampaignStatusEnum.LOCKING.getCode(), BrandCampaignStatusEnum.LOCK_FAIL.getCode(), BrandCampaignStatusEnum.NEW.getCode()
            ,BrandCampaignStatusEnum.INQUIRING.getCode(), BrandCampaignStatusEnum.INQUIRY_SUCCESS.getCode(), BrandCampaignStatusEnum.INQUIRY_FAIL.getCode());


    @Override
    public void search(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, CampaignScheduleViewDTO scheduleViewDTO, List<Long> templateIds) {
        List<NbTemplateDTO> templateList = getTemplateList(serviceContext, templateIds);

        UniInquiryRequest request = inventoryConverter.convertToInquiryRequest(campaignViewDTO, scheduleViewDTO, templateList);
        inventoryConverter.convertToInquiryBookingSlots(scheduleViewDTO, request);
        fillJointFrequencyFlag(serviceContext, request);
        RogerLogger.info("UniInquiryRequest={}", JSON.toJSONString(request));
        inventorySAO.search(request);
    }


    /**
     * 这里只返回通用模板
     * */
    private List<NbTemplateDTO> getTemplateList(ServiceContext serviceContext, List<Long> templateIds) {
        if (CollectionUtils.isNotEmpty(templateIds)) {
            return templateSAO.getTemplateByIds(serviceContext,templateIds);
        }
        return Lists.newArrayList();
    }
    private void fillJointFrequencyFlag(ServiceContext serviceContext, UniInquiryRequest request) {
        if (request.getFrequencyInfo() == null) {
            return;
        }
        List<FrequencyRefDTO> frequencyRefList = frequencySAO.findFrequencyRefByFreqIds(serviceContext, Lists.newArrayList(request.getFrequencyInfo().getFrequencyId()), BrandFrequencyBizTypeEnum.CAMPAIGN.getCode());
        if (CollectionUtils.isNotEmpty(frequencyRefList) && frequencyRefList.size() > 1) {
            request.getFrequencyInfo().setJointFrequencyFlag(true);
        }
    }

    @Override
    public void book(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, CampaignScheduleViewDTO scheduleViewDTO,List<Long> templateIds) {
        List<NbTemplateDTO> templateList = getTemplateList(serviceContext, templateIds);
        UniInquiryRequest request = inventoryConverter.convertToInquiryRequest(campaignViewDTO, scheduleViewDTO, templateList);
        inventoryConverter.convertToInquiryBookingSlots(scheduleViewDTO, request);
        fillJointFrequencyFlag(serviceContext, request);
        RogerLogger.info("UniInquiryRequest={}", JSON.toJSONString(request));
        inventorySAO.book(request);
    }

    @Override
    public void release(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {
        UniReleaseRequest uniReleaseRequest = inventoryConverter.convertToReleaseRequest(campaignViewDTO);
        inventorySAO.release(uniReleaseRequest);
    }

    @Override
    public void cancel(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {
        UniRequest uniRequest = inventoryConverter.convertToCancelRequest(campaignViewDTO);
        inventorySAO.cancel(uniRequest);
    }

    @Override
    public void dailyUpdate(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, CampaignScheduleViewDTO scheduleViewDTO,List<Long> templateIds) {
        List<NbTemplateDTO> templateList = getTemplateList(serviceContext, templateIds);
        UniInquiryRequest request = inventoryConverter.convertToInquiryRequest(campaignViewDTO, scheduleViewDTO, templateList);
        inventoryConverter.convertToDailyUpdateBookingSlots(campaignViewDTO, request);
        inventorySAO.dailyUpdate(request);
    }

    @Override
    public Long mediaInquiry(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList,
                             List<CampaignScheduleViewDTO> campaignScheduleViewDTOList) {
        if (CollectionUtils.isEmpty(campaignViewDTOList) || CollectionUtils.isEmpty(campaignScheduleViewDTOList)) {
            RogerLogger.info("媒体询量List为空");
            return null;
        }
        InquiryDTO inquiryDTO = converterFrom(campaignViewDTOList, campaignScheduleViewDTOList);
        Long resultDTO = inventorySAO.mediaInquiry(inquiryDTO);
        return resultDTO;
    }

    @Override
    public InventoryUdImprecisionDTO getBottomPurchaseOrder(Long subCampaignId) {
        return inventorySAO.getBottomPurchaseOrder(subCampaignId);
    }


    private InquiryDTO converterFrom(List<CampaignViewDTO> campaignViewDTOList, List<CampaignScheduleViewDTO> campaignScheduleViewDTOList) {
        InquiryDTO inquiryDTO = new InquiryDTO();
        // 构建询量单基础信息
        CampaignScheduleViewDTO campaignScheduleViewDTO = campaignScheduleViewDTOList.get(0);
        //
        inquiryDTO.setId(campaignScheduleViewDTO.getMediaInquiryOrderId());
        Long customerMemberId = campaignScheduleViewDTO.getCustomerMemberId() != null ? campaignScheduleViewDTO.getCustomerMemberId() : campaignViewDTOList.get(0)
                .getMemberId();
        String remark = "【订单ID】" + campaignScheduleViewDTO.getCampaignGroupId() + "【店铺名称】" + memberSAO.getMemberNameById(customerMemberId);
        inquiryDTO.setRemark(remark);
        inquiryDTO.setCreatorId(campaignScheduleViewDTOList.get(0).getCreatorId());
        inquiryDTO.setCreator(campaignScheduleViewDTOList.get(0).getCreatorName());
        // 询量单信息处理
        List<InquiryGroupDTO> inquiryGroupDTOList = Lists.newArrayList();
        for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
            List<CampaignInquiryViewDTO> inquiryViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignInquiryLockViewDTO())
                    .map(CampaignInquiryLockViewDTO::getCampaignInquiryViewDTOList).orElse(Lists.newArrayList());
            if (CollectionUtils.isEmpty(inquiryViewDTOList)) {
                continue;
            }
            InquiryGroupDTO inquiryGroupDTO = convertToInquiryGroupDTO(campaignScheduleViewDTO.getCampaignGroupName(), customerMemberId, campaignViewDTO);
            if (Objects.nonNull(inquiryGroupDTO)) {
                inquiryGroupDTOList.add(inquiryGroupDTO);
            }
        }
        inquiryDTO.setInquiryGroupDTOList(inquiryGroupDTOList);
        return inquiryDTO;
    }

    private InquiryGroupDTO convertToInquiryGroupDTO(String campaignGroupName, Long customerMemberId, CampaignViewDTO campaignViewDTO) {
        Map<Date, Long> bookAmountMap = Optional.ofNullable(campaignViewDTO.getCampaignInquiryLockViewDTO())
                .map(CampaignInquiryLockViewDTO::getCampaignInquiryViewDTOList).orElse(Lists.newArrayList()).stream()
                .filter(inquiryViewDTO -> inquiryViewDTO.getBookAmount() > 0)
                .collect(Collectors.toMap(CampaignInquiryViewDTO::getDate, CampaignInquiryViewDTO::getBookAmount));
        RogerLogger.info("bookAmountMap={},campaignId={}", JSON.toJSONStringWithDateFormat(bookAmountMap, BrandDateUtil.DATE_FORMAT_YYYYMMDD_TYPE_1), campaignViewDTO.getId());
        if (MapUtils.isEmpty(bookAmountMap)) {
            return null;
        }
        if (campaignViewDTO.getCampaignInquiryLockViewDTO() == null) {
            RogerLogger.info("campaignExtViewDTO is null,campaignId={}", campaignViewDTO.getId());
            return null;
        }
        List<DayAmountViewDTO> mediaInquiryDemandAmountList = Optional.ofNullable(campaignViewDTO.getCampaignInquiryLockViewDTO().getCampaignMediaInquiryViewDTO())
                .map(CampaignMediaInquiryViewDTO::getMediaInquiryDemandAmountList).orElse(Lists.newArrayList());
        RogerLogger.info("mediaInquiryDemandAmountList={},campaignId={}", JSON.toJSONStringWithDateFormat(mediaInquiryDemandAmountList, BrandDateUtil.DATE_FORMAT_YYYYMMDD_TYPE_1), campaignViewDTO.getId());
        if (CollectionUtils.isEmpty(mediaInquiryDemandAmountList)) {
            return null;
        }
        AssertUtil.assertTrue(!mediaInquiryDemandAmountList.stream()
                .anyMatch(demandAmount -> demandAmount.getDay() == null || demandAmount.getAvailConfirmedAmount() == null), "媒体询量信息不完整，需要重新操作计划询量，计划id:" + campaignViewDTO.getId());
        // 构建 InquiryGroupDTO
        InquiryGroupDTO inquiryGroupDTO = new InquiryGroupDTO();
        // 排期id
        inquiryGroupDTO.setUdScheduleId(campaignViewDTO.getId());
        // resourceList
        List<InquiryResDTO> resourceList = Lists.newArrayList();
        for (Long sspResourceId : campaignViewDTO.getCampaignResourceViewDTO().getSspResourceIds()) {
            InquiryResDTO inquiryResDTO = new InquiryResDTO();
            inquiryResDTO.setResourceId(sspResourceId);
            resourceList.add(inquiryResDTO);
        }
        inquiryGroupDTO.setResourceList(resourceList);
        // 采购方式
        SellTypeEnum purchaseWay = getPurchaseWay(campaignViewDTO);
        inquiryGroupDTO.setSupportSellWay(purchaseWay.getCode());
        if (campaignViewDTO.getCampaignGuaranteeViewDTO().getSspPushSendRatio() != null) {
            inquiryGroupDTO.setPushRatio(String.valueOf(campaignViewDTO.getCampaignGuaranteeViewDTO().getSspPushSendRatio() / 100));
        }
        // 投放单位
        inquiryGroupDTO.setSupportSellNuit(campaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterUnit());
        // 精准/非精准
        inquiryGroupDTO.setAccurate(ProgramMode.PRECISION.getValue());
        // 定向
        Map<String, String> properties = Maps.newHashMap();
        properties.put(InquiryGroupDTO.PropertyKeyEnum.UD_TARGET.getValue(), JSONObject.toJSONString(getAddPolicyNodeList(campaignViewDTO)));
        inquiryGroupDTO.setProperties(properties);

        // 生效时间
        inquiryGroupDTO.setInventoryStartTime(campaignViewDTO.getStartTime());
        // 失效时间
        inquiryGroupDTO.setInventoryEndTime(campaignViewDTO.getEndTime());
        // 描述
        inquiryGroupDTO.setRemark(getRemark(campaignGroupName, customerMemberId, campaignViewDTO));
        List<InquiryAmountDTO> groupInquiryAmountDTOList = Lists.newArrayList();
        Long registerUnitRatio = getRegisterUnitRatio(campaignViewDTO.getCampaignGuaranteeViewDTO());
        mediaInquiryDemandAmountList.stream()
                .filter(inquiry -> bookAmountMap.containsKey(inquiry.getDay()))
                .filter(inquiry -> bookAmountMap.get(inquiry.getDay()) - inquiry.getAvailConfirmedAmount() > 0)
                .forEach(inquiry -> {
                    InquiryAmountDTO inquiryAmountDTO = new InquiryAmountDTO();
                    inquiryAmountDTO.setDay(BrandDateUtil.date2String(inquiry.getDay()));
                    Long mediaInquiryAmount = bookAmountMap.get(inquiry.getDay()) - inquiry.getAvailConfirmedAmount();
                    inquiryAmountDTO.setAmount(mediaInquiryAmount.intValue() / registerUnitRatio.intValue());
                    groupInquiryAmountDTOList.add(inquiryAmountDTO);
                });
        RogerLogger.info("groupInquiryAmountDTOList={},campaignId={}", JSON.toJSONStringWithDateFormat(groupInquiryAmountDTOList, BrandDateUtil.DATE_FORMAT_YYYYMMDD_TYPE_1), campaignViewDTO.getId());
        if (CollectionUtils.isEmpty(groupInquiryAmountDTOList)) {
            return null;
        }
        inquiryGroupDTO.setInquiryAmountDTOList(groupInquiryAmountDTOList);
        return inquiryGroupDTO;
    }

    private Long getRegisterUnitRatio(CampaignGuaranteeViewDTO campaignGuaranteeViewDTO) {
        Integer sspRegisterUnit = campaignGuaranteeViewDTO.getSspRegisterUnit();
        if (BrandCampaignRegisterUnitEnum.ROUND.getCode().equals(sspRegisterUnit) ||
                BrandCampaignRegisterUnitEnum.DAY.getCode().equals(sspRegisterUnit)) {
            return campaignGuaranteeViewDTO.getAmount() / campaignGuaranteeViewDTO.getCptAmount();
        }
        return Constant.DEFAULT_CPM_PV_RATIO;
    }

    /**
     * @param serviceContext
     * @param subCampaignViewDTOList
     * @return
     */
    @Override
    public CampaignGroupPurchaseProcessViewDTO needPurchaseOrder(ServiceContext serviceContext, List<CampaignViewDTO> subCampaignViewDTOList) {
        CampaignGroupPurchaseProcessViewDTO campaignGroupPurchaseProcessViewDTO = new CampaignGroupPurchaseProcessViewDTO();
        if (CollectionUtils.isEmpty(subCampaignViewDTOList)) {
            campaignGroupPurchaseProcessViewDTO.setBrandCampaignGroupPurchaseStatusEnum(BrandCampaignGroupPurchaseStatusEnum.NON_PURCHASE);
            return campaignGroupPurchaseProcessViewDTO;
        }
        //获取非锁量成功的计划列表
        List<CampaignViewDTO> unLockSuccessCampaignViewDTOList = subCampaignViewDTOList.stream().filter(
                        campaign -> unLockSuccessStatusList.contains(campaign.getStatus()))
                .collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(unLockSuccessCampaignViewDTOList)) {
            RogerLogger.info("needPurchaseOrder process,campaignGroupId:{},unLockSuccessSubCampaignIds:{}", unLockSuccessCampaignViewDTOList.get(0).getCampaignGroupId(),
                    JSON.toJSONString(unLockSuccessCampaignViewDTOList.stream().map(campaign -> campaign.getId()).collect(Collectors.toList())));
            //如果有未锁量计划，则订单采购状态还是在采购中
            campaignGroupPurchaseProcessViewDTO.setBrandCampaignGroupPurchaseStatusEnum(BrandCampaignGroupPurchaseStatusEnum.PURCHASE_ING);
            return campaignGroupPurchaseProcessViewDTO;
        }
        //获取计划的预定详情信息
        InventoryUdDetailsDTO inventoryUdDetailsDTO = getInventoryUdDetailsDTO(serviceContext, subCampaignViewDTOList);
        //获取无预定详情的计划列表
        List<CampaignViewDTO> noBookDetailsCampaignViewDTOList = subCampaignViewDTOList.stream().filter(
                campaign -> MapUtils.isEmpty(inventoryUdDetailsDTO.getDetailsResourceMap())
                        || !inventoryUdDetailsDTO.getDetailsResourceMap().containsKey(String.valueOf(campaign.getId()))
        ).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(noBookDetailsCampaignViewDTOList)) {
            RogerLogger.info("needPurchaseOrder process,campaignGroupId:{},noBookDetailsSubCampaignIds:{}", noBookDetailsCampaignViewDTOList.get(0).getCampaignGroupId(),
                    JSON.toJSONString(noBookDetailsCampaignViewDTOList.stream().map(campaign -> campaign.getId()).collect(Collectors.toList())));
            //如果存在无预定详情的计划，则订单采购状态还是在采购中
            campaignGroupPurchaseProcessViewDTO.setBrandCampaignGroupPurchaseStatusEnum(BrandCampaignGroupPurchaseStatusEnum.PURCHASE_ING);
            return campaignGroupPurchaseProcessViewDTO;
        }
        // 获取库存下单数据
        Map<String, InventoryUdDetailsDTO.DetailsResourceDTO> detailsResourceDTOMaps = getNeedPurchaseMap(inventoryUdDetailsDTO.getDetailsResourceMap());
        if (MapUtils.isNotEmpty(detailsResourceDTOMaps)) {
            campaignGroupPurchaseProcessViewDTO.setBrandCampaignGroupPurchaseStatusEnum(BrandCampaignGroupPurchaseStatusEnum.PURCHASE_ING);
        } else {
            campaignGroupPurchaseProcessViewDTO.setBrandCampaignGroupPurchaseStatusEnum(BrandCampaignGroupPurchaseStatusEnum.NON_PURCHASE);
        }
        return campaignGroupPurchaseProcessViewDTO;
    }

    /**
     * @param serviceContext
     * @param subCampaignViewDTOList
     * @return
     */
    @Override
    public void confirmOrder(ServiceContext serviceContext, List<CampaignViewDTO> subCampaignViewDTOList) {
        if (CollectionUtils.isEmpty(subCampaignViewDTOList)) {
            return;
        }
        // 获取库存下单数据
        InventoryUdInquiryDTO inventoryUdInquiryDTO = getInventoryUdInquiryDTO(subCampaignViewDTOList);
        inventorySAO.confirmOrder(inventoryUdInquiryDTO);
    }

    @Override
    public Map<String, Date> getInventoryExpireTime(ServiceContext serviceContext, List<CampaignViewDTO> subCampaignViewDTOList) {
        Map<String, Date> result = Maps.newHashMap();
        InventoryUdDetailsDTO inventoryUdDetailsDTO = getInventoryUdDetailsDTO(serviceContext, subCampaignViewDTOList);
        RogerLogger.info("三环媒体询量有效期查询 subCampaignViewDTOList {}, inventoryUdDetailsDTO {}", JSON.toJSONString(subCampaignViewDTOList), JSON.toJSONString(inventoryUdDetailsDTO));
        if (Objects.nonNull(inventoryUdDetailsDTO)) {
            Map<String, InventoryUdDetailsDTO.DetailsResourceDTO> detailsResourceMap = inventoryUdDetailsDTO.getDetailsResourceMap();
            if (MapUtils.isNotEmpty(detailsResourceMap)) {
                for (String campaignId : detailsResourceMap.keySet()) {
                    InventoryUdDetailsDTO.DetailsResourceDTO detailsResourceDTO = detailsResourceMap.get(campaignId);
                    if (Objects.nonNull(detailsResourceDTO) && CollectionUtils.isNotEmpty(detailsResourceDTO.getDayAmountList())) {
                        List<Date> expireDateList = detailsResourceDTO.getDayAmountList().stream()
                                .filter(detailsDayAmount -> CollectionUtils.isNotEmpty(detailsDayAmount.getAssignDetailsList()))
                                .flatMap(detailsDayAmount -> detailsDayAmount.getAssignDetailsList().stream())
                                .map(InventoryUdDetailsDTO.AssignDetails::getExpireTime)
                                .filter(Objects::nonNull)
                                .sorted()
                                .collect(Collectors.toList());
                        if (CollectionUtils.isNotEmpty(expireDateList)) {
                            // 取所有三环排期内的最早的媒体询量库存失效时间
                            result.put(campaignId, expireDateList.get(0));
                        }
                    }
                }
            }
        }
        return result;
    }


    private InventoryUdDetailsDTO getInventoryUdDetailsDTO(ServiceContext serviceContext,
                                                          List<CampaignViewDTO> subCampaignViewDTOList) {
        InventoryUdInquiryDTO inventoryUdInquiryDTO = getInventoryUdInquiryDTO(subCampaignViewDTOList);
        return inventorySAO.getBookDetail(inventoryUdInquiryDTO);
    }

    @Override
    public Map<Long, BrandBoolEnum> buildCampaignInventoryDetailsMap(ServiceContext serviceContext, List<CampaignViewDTO> campaignModelList) {
        Map<Long, BrandBoolEnum> result = Maps.newHashMap();
        if (CollectionUtils.isEmpty(campaignModelList)) {
            return result;
        }
        /**
         * 过滤出已锁量的计划，判断库存类型
         * 一二环的一二级计划都是精准，跨域一环的是精准
         * 三环的一（二）级计划根据库存查询判断
         */
        campaignModelList.stream().filter(campaignViewDTO -> !unLockSuccessStatusList.contains(campaignViewDTO.getStatus()))
                .forEach(campaignViewDTO -> {
                    if(MediaScopeEnum.TAO_OUT.getCode().equals(campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope()) ||
                            MediaScopeEnum.TAO_INNER.getCode().equals(campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope())) {
                        result.put(campaignViewDTO.getId(), BrandBoolEnum.BRAND_TRUE);
                        return;
                    }
                    // 跨域一级计划肯定是精准
                    if(MediaScopeEnum.CROSS_SCOPE.getCode().equals(campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope())
                            && BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode().equals(campaignViewDTO.getCampaignLevel())) {
                        result.put(campaignViewDTO.getId(), BrandBoolEnum.BRAND_TRUE);
                    }
                    // 跨域或三环的一二级计划判断投放类型
                    if(CollectionUtils.isNotEmpty(campaignViewDTO.getSubCampaignViewDTOList())) {
                        // 判断跨域计划是否有三环的二级计划，三环一级计划的二级计划肯定是三环的
                        Optional<CampaignViewDTO> anyThreeRoundCampaign = campaignViewDTO.getSubCampaignViewDTOList().stream().filter(subCampaignViewDTO -> MediaScopeEnum.SITE_OUT.getCode().equals(subCampaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope())).findAny();
                        if(anyThreeRoundCampaign.isPresent()) {
                            InventoryUdDetailsDTO inventoryUdDetailsDTO = getInventoryUdDetailsDTO(serviceContext, campaignViewDTO.getSubCampaignViewDTOList());
                            Map<String, InventoryUdDetailsDTO.DetailsResourceDTO> detailsResourceMap = inventoryUdDetailsDTO.getDetailsResourceMap();
                            if(MapUtils.isNotEmpty(detailsResourceMap)) {
                                // 跨域一级计划肯定是精准，三环一级计划默认设置为非精准，根据二级计划库存状态更新
                                if(MediaScopeEnum.CROSS_SCOPE.getCode().equals(campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope())) {
                                    result.put(campaignViewDTO.getId(), BrandBoolEnum.BRAND_TRUE);
                                } else {
                                    result.put(campaignViewDTO.getId(), BrandBoolEnum.BRAND_FALSE);
                                }
                                detailsResourceMap.keySet().forEach(businessId -> {
                                    InventoryUdDetailsDTO.DetailsResourceDTO detailsResourceDTO = detailsResourceMap.get(businessId);
                                    if(CollectionUtils.isNotEmpty(detailsResourceDTO.getDayAmountList())) {
                                        Optional<InventoryUdDetailsDTO.DetailsDayAmount> anyPrecision = detailsResourceDTO.getDayAmountList()
                                                .stream()
                                                .filter(dayAmount -> Objects.nonNull(dayAmount.getProgramMode()))
                                                .filter(dayAmount -> dayAmount.getProgramMode().equals(InventoryUdBaseDTO.ProgramMode.PRECISION))
                                                .findAny();
                                        if(anyPrecision.isPresent()) {
                                            result.put(Long.parseLong(businessId), BrandBoolEnum.BRAND_TRUE);
                                            result.put(campaignViewDTO.getId(), BrandBoolEnum.BRAND_TRUE);
                                        } else {
                                            result.put(Long.parseLong(businessId), BrandBoolEnum.BRAND_FALSE);
                                        }
                                    }
                                });
                            }
                        }
                    }
                });
        return result;
    }

    @Override
    public List<InventoryDetailsViewDTO> getInventoryDetailsViewDTOList(ServiceContext serviceContext,
                                                          List<CampaignViewDTO> subCampaignViewDTOList) {
        List<InventoryDetailsViewDTO> resultList = Lists.newArrayList();
        InventoryUdDetailsDTO inventoryUdDetailsDTO = getInventoryUdDetailsDTO(serviceContext, subCampaignViewDTOList);
        if (Objects.nonNull(inventoryUdDetailsDTO)) {
            inventoryUdDetailsDTO.getDetailsResourceMap().forEach((businessId, resourceDetails) -> {
                InventoryDetailsViewDTO inventoryDetailsViewDTO = new InventoryDetailsViewDTO();
                resultList.add(inventoryDetailsViewDTO);
                List<InventoryDetailsDayAmountViewDTO> dayAmountList = Lists.newArrayList();
                inventoryDetailsViewDTO.setSubCampaignId(Long.parseLong(businessId));
                if (CollectionUtils.isNotEmpty(resourceDetails.getDayAmountList())) {
                    resourceDetails.getDayAmountList().forEach(detailsDayAmount -> {
                        InventoryDetailsDayAmountViewDTO inventoryDetailsDayAmountViewDTO =
                                new InventoryDetailsDayAmountViewDTO();
                        inventoryDetailsDayAmountViewDTO.setProgramMode(detailsDayAmount.getProgramMode().getValue());
                        inventoryDetailsDayAmountViewDTO.setDay(detailsDayAmount.getDay());
                        inventoryDetailsDayAmountViewDTO.setAmount(detailsDayAmount.getAmount());
                        dayAmountList.add(inventoryDetailsDayAmountViewDTO);
                    });
                    inventoryDetailsViewDTO.setDayAmountList(dayAmountList);

                }else{
                    inventoryDetailsViewDTO.setDayAmountList(Lists.newArrayList());
                }
            });
        }
        return resultList;
    }

    /**
     * 获取计划是否需要打底
     * */
    @Override
    public Map<Long, BrandBoolEnum> getCampaignNeedBottom(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList) {
        Map<Long, BrandBoolEnum> result = Maps.newHashMap();
        // 过滤出已锁量的一级计划，判断库存类型
        campaignViewDTOList.stream().filter(campaignViewDTO -> BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode().equals(campaignViewDTO.getCampaignLevel())
                        && !unLockSuccessStatusList.contains(campaignViewDTO.getStatus()))
                .forEach(campaignViewDTO -> {
                    if(MediaScopeEnum.TAO_OUT.getCode().equals(campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope()) ||
                            MediaScopeEnum.TAO_INNER.getCode().equals(campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope())) {
                        result.put(campaignViewDTO.getId(), BrandBoolEnum.BRAND_TRUE);
                        return;
                    }

                    if(CollectionUtils.isNotEmpty(campaignViewDTO.getSubCampaignViewDTOList())) {
                        Optional<CampaignViewDTO> anyThreeRoundCampaign = campaignViewDTO.getSubCampaignViewDTOList().stream().filter(subCampaignViewDTO -> MediaScopeEnum.SITE_OUT.getCode().equals(subCampaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope())).findAny();
                        if(anyThreeRoundCampaign.isPresent()) {
                            List<InventoryDetailsViewDTO> inventoryUdDetailsDTOList = getInventoryDetailsViewDTOList(serviceContext, campaignViewDTO.getSubCampaignViewDTOList());
//                        Map<String, InventoryUdDetailsDTO.DetailsResourceDTO> detailsResourceMap = inventoryUdDetailsDTO.getDetailsResourceMap();
                            if(CollectionUtils.isNotEmpty(inventoryUdDetailsDTOList)) {
                                Optional<InventoryDetailsDayAmountViewDTO> optionalInventoryDetailsDayAmountViewDTO=   inventoryUdDetailsDTOList.stream().flatMap(item->item.getDayAmountList().stream()).filter(dayAmount -> dayAmount.getProgramMode().equals(InventoryUdBaseDTO.ProgramMode.PRECISION.getValue())).findAny();
                                if(optionalInventoryDetailsDayAmountViewDTO.isPresent()) {

                                    result.put(campaignViewDTO.getId(), BrandBoolEnum.BRAND_TRUE);
                                } else {

                                    result.put(campaignViewDTO.getId(), BrandBoolEnum.BRAND_FALSE);

                                }
                                inventoryUdDetailsDTOList.forEach(item -> {
                                    if(CollectionUtils.isNotEmpty(item.getDayAmountList())) {
                                        Optional<InventoryDetailsDayAmountViewDTO> anyPrecision = item.getDayAmountList()
                                                .stream()
                                                .filter(dayAmount -> Objects.nonNull(dayAmount.getProgramMode()))
                                                .filter(dayAmount -> dayAmount.getProgramMode().equals(InventoryUdBaseDTO.ProgramMode.PRECISION.getValue()))
                                                .findAny();
                                        if(anyPrecision.isPresent()) {
                                            result.put(item.getSubCampaignId(), BrandBoolEnum.BRAND_TRUE);

                                        } else {
                                            result.put(item.getSubCampaignId(), BrandBoolEnum.BRAND_FALSE);
                                        }
                                    }
                                });
                            }
                        }
                    }
                });
        return result;
    }

    @NotNull
    private InventoryUdInquiryDTO getInventoryUdInquiryDTO(List<CampaignViewDTO> subCampaignViewDTOList) {
        InventoryUdInquiryDTO inventoryUdInquiryDTO = new InventoryUdInquiryDTO();
        List<InventoryUdInquiryDTO.InquiryResourceDTO> inquiryResourceDTOList = Lists.newArrayList();
        for (CampaignViewDTO campaignViewDTO : subCampaignViewDTOList) {
            if (!MediaScopeEnum.SITE_OUT.getCode().equals(campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope())) {
                continue;
            }
            inquiryResourceDTOList.add(inventoryConverter.convertInventoryUdInquiryDTO(campaignViewDTO));
        }
        inventoryUdInquiryDTO.setInquiryResourceList(inquiryResourceDTOList);
        return inventoryUdInquiryDTO;
    }

    /**
     * 媒体下单
     *
     * @param campaignGroupViewDTO
     * @param subCampaignViewDTOList
     * @return
     */
    @Override
    public CampaignGroupPurchaseProcessViewDTO addPurchaseOrder(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, List<CampaignViewDTO> subCampaignViewDTOList) {
        CampaignGroupPurchaseProcessViewDTO campaignGroupPurchaseProcessViewDTO = new CampaignGroupPurchaseProcessViewDTO();
        List<CampaignViewDTO> filterSideOutCampaignViewDTOList = subCampaignViewDTOList.stream().filter(item -> MediaScopeEnum.SITE_OUT.getCode().equals(item.getCampaignResourceViewDTO().getSspMediaScope())).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(filterSideOutCampaignViewDTOList)) {
            campaignGroupPurchaseProcessViewDTO.setBrandCampaignGroupPurchaseStatusEnum(BrandCampaignGroupPurchaseStatusEnum.NON_PURCHASE);
            return campaignGroupPurchaseProcessViewDTO;
        }
        // 获取库存下单数据

        InventoryUdDetailsDTO inventoryUdDetailsDTO = getInventoryUdDetailsDTO(context, filterSideOutCampaignViewDTOList);
        Map<String, InventoryUdDetailsDTO.DetailsResourceDTO> detailsResourceDTOMaps = getNeedPurchaseMap(inventoryUdDetailsDTO.getDetailsResourceMap());
        if (MapUtils.isEmpty(detailsResourceDTOMaps)) {
            RogerLogger.info("{} no need addPurchaseOrder ", campaignGroupViewDTO.getId());
            campaignGroupPurchaseProcessViewDTO.setBrandCampaignGroupPurchaseStatusEnum(BrandCampaignGroupPurchaseStatusEnum.NON_PURCHASE);
            return campaignGroupPurchaseProcessViewDTO;
        }
        // context
        //com.alibaba.solar.common.dto.ServiceContext context = com.alibaba.solar.common.dto.ServiceContext.createServiceContext();

        PurchaseOrderDTO purchaseOrderDTO = initPurchaseOrder(context, campaignGroupViewDTO, filterSideOutCampaignViewDTOList);
        RogerLogger.info("{}  need init  purchaseOrderDTO finish ", campaignGroupViewDTO.getId());
        // 资源排期信息
        List<SystemCreateResourceScheduleDTO> systemCreateResourceScheduleDTOList = Lists.newArrayList();
        // 排期
        Map<Long, CampaignViewDTO> campaignViewDTOMap = filterSideOutCampaignViewDTOList.stream().collect(Collectors.toMap(a -> a.getId(), Function.identity()));
        // Map<排期id, 资源详情>
        for (String businessId : detailsResourceDTOMaps.keySet()) {
            initPurchaseData(campaignGroupViewDTO, detailsResourceDTOMaps, systemCreateResourceScheduleDTOList, campaignViewDTOMap, businessId);
        }
        RogerLogger.info("{}  need add  purchaseOrder and  finish prepare data  businessIds : {}", campaignGroupViewDTO.getId(), JSON.toJSONString(detailsResourceDTOMaps.keySet()));
        Long purchaseOrderId = inventorySAO.addPurchaseOrder(context, purchaseOrderDTO, systemCreateResourceScheduleDTOList);
        campaignGroupPurchaseProcessViewDTO.setBrandCampaignGroupPurchaseStatusEnum(BrandCampaignGroupPurchaseStatusEnum.PURCHASE_ING);
        campaignGroupPurchaseProcessViewDTO.setPurchaseOrderId(purchaseOrderId);
        return campaignGroupPurchaseProcessViewDTO;
    }

    @NotNull
    private PurchaseOrderDTO initPurchaseOrder(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, List<CampaignViewDTO> filterSideOutCampaignViewDTOList) {
        //【采购单】
        PurchaseOrderDTO purchaseOrderDTO = new PurchaseOrderDTO();
        // 采购订单名称
        Long customerMemberId = campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getCustomerMemberId() != null ? campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getCustomerMemberId() : filterSideOutCampaignViewDTOList.get(0)
                .getMemberId();
        String orderName = "【订单ID】" + campaignGroupViewDTO.getId() + "【店铺名称】" + memberSAO.getMemberNameById(customerMemberId);
        purchaseOrderDTO.setOrderName(orderName);
        // 资源包创建人工号
        ResourcePackageTemplateDTO resourcePackageTemplateDTO = resourcePackageSAO.getTemplateById(context, campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getCustomerTemplateId());
        purchaseOrderDTO.setCreatorId(resourcePackageTemplateDTO.getCreator());
        // 采购模式：数量
        purchaseOrderDTO.setPurchaseMode(OrderPurchaseModeEnum.PUT_AMOUNT.getCode());
        // busiCode
        purchaseOrderDTO.setBusiCode(PlatformBusinessEnum.UD.getCode());
        // 采购发起方式 1：采购平台发起  2.UD接口发起
        purchaseOrderDTO.setSource(2);
        //增加业务线字段回传给采购
        purchaseOrderDTO.setBusinessProductId(Product.BRAND_ONEBP_BRAND.getId());
        return purchaseOrderDTO;
    }

    @NotNull
    private Map<String, InventoryUdDetailsDTO.DetailsResourceDTO> getNeedPurchaseMap(
            Map<String, InventoryUdDetailsDTO.DetailsResourceDTO> detailsResourceDTOMap) {
        Map<String, InventoryUdDetailsDTO.DetailsResourceDTO> detailsResourceDTOMaps = Maps.newHashMap();
        for (String businessId : detailsResourceDTOMap.keySet()) {
            InventoryUdDetailsDTO.DetailsResourceDTO detailsResourceDTO = detailsResourceDTOMap.get(businessId);
            List<InventoryUdDetailsDTO.DetailsDayAmount> detailsDayAmountList = detailsResourceDTO.getDayAmountList();
            if (CollectionUtils.isEmpty(detailsDayAmountList)) {
                continue;
            }
            for (InventoryUdDetailsDTO.DetailsDayAmount detailsDayAmount : detailsDayAmountList) {
                List<InventoryUdDetailsDTO.AssignDetails> assignDetailsList = detailsDayAmount.getAssignDetailsList();
                for (InventoryUdDetailsDTO.AssignDetails assignDetails : assignDetailsList) {
                    // 待购买库存量，如果大于0且预占库存未过期业务侧需要发起流量采购
                    Integer toBuyAmount = assignDetails.getToBuyAmount();
                    Boolean reserveExpired = assignDetails.getReserveExpired();
                    // 如果=0，不需要采购
                    if (toBuyAmount == 0) {
                        continue;
                    }
                    //如果toBuyAmount > 0 则需要发起采购
                    if (toBuyAmount > 0) {
                        detailsResourceDTOMaps.putAll(detailsResourceDTOMap);
                    }
//                    // 如果>0，看下expired，如果过期的话BP需要提示，状态改下单失败 需要重新锁量
//                    if (reserveExpired) {
//                        RogerLogger.error("排期id：" + businessId + " 预占库存已过期，请重新询锁量");
//                        // 提示"下单失败，需要重新锁量"
//                        throw new BrandOneBPException(BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR,
//                            "排期id：" + businessId + " 预占库存已过期，请重新询锁量");
//                    } else {
//                        //此行需要发起采购
//                        detailsResourceDTOMaps.putAll(detailsResourceDTOMap);
//                    }
                }
            }
        }
        RogerLogger.info("need purchase campaignIds {}", JSON.toJSONString(detailsResourceDTOMaps.keySet()));
        return detailsResourceDTOMaps;
    }

    private void initPurchaseData(CampaignGroupViewDTO campaignGroupViewDTO, Map<String, InventoryUdDetailsDTO.DetailsResourceDTO> detailsResourceDTOMaps,
                                  List<SystemCreateResourceScheduleDTO> systemCreateResourceScheduleDTOList,
                                  Map<Long, CampaignViewDTO> campaignViewDTOMap, String businessId) {
        // 排期（资源）
        CampaignViewDTO campaignViewDTO = campaignViewDTOMap.get(Long.parseLong(businessId));
        if (Objects.isNull(campaignViewDTO)) {
            return;
        }
        InventoryUdDetailsDTO.DetailsResourceDTO detailsResourceDTO = detailsResourceDTOMaps.get(businessId);
        if (Objects.isNull(detailsResourceDTO) || CollectionUtils.isEmpty(detailsResourceDTO.getDayAmountList())) {
            return;
        }
        List<InventoryUdDetailsDTO.DetailsDayAmount> detailsDayAmountList = detailsResourceDTO.getDayAmountList();

        // 分组
        // Map<ProgramMode, List<date>>
        Map<Integer, List<String>> programModeDayMap = Maps.newHashMap();

        // Map<SelleType, Map<date, List<AssignDetails>>>
        Map<Integer, Map<String, List<InventoryUdDetailsDTO.AssignDetails>>> sellTypeDayDetailsMap = Maps.newHashMap();

        for (InventoryUdDetailsDTO.DetailsDayAmount detailsDayAmount : detailsDayAmountList) {
            Date day = detailsDayAmount.getDay();
            String date = DateUtils.dateOf(day);
            List<InventoryUdDetailsDTO.AssignDetails> assignDetailsList = detailsDayAmount.getAssignDetailsList();
            // 精准/非精准
            InventoryUdBaseDTO.ProgramMode programMode = detailsDayAmount.getProgramMode();
            // programModeDayMap
            if (programModeDayMap.containsKey(programMode.getValue())) {
                programModeDayMap.get(programMode.getValue()).add(date);
            } else {
                List<String> dateList = Lists.newArrayList();
                dateList.add(date);
                programModeDayMap.put(programMode.getValue(), dateList);
            }

            for (InventoryUdDetailsDTO.AssignDetails assignDetails : assignDetailsList) {
                // 售卖类型
                InventoryUdBaseDTO.SellType sellType = assignDetails.getSupplySellType();

                if (sellTypeDayDetailsMap.containsKey(sellType.getValue())) {
                    if (sellTypeDayDetailsMap.get(sellType.getValue()).containsKey(date)) {
                        sellTypeDayDetailsMap.get(sellType.getValue()).get(date).add(assignDetails);
                    } else {
                        List<InventoryUdDetailsDTO.AssignDetails> dateAssignDetailsList = Lists.newArrayList();
                        dateAssignDetailsList.add(assignDetails);
                        sellTypeDayDetailsMap.get(sellType.getValue()).put(date, dateAssignDetailsList);
                    }
                } else {
                    Map<String, List<InventoryUdDetailsDTO.AssignDetails>> dateAssignDetailsMap = Maps.newHashMap();
                    List<InventoryUdDetailsDTO.AssignDetails> dateAssignDetailsList = Lists.newArrayList();
                    dateAssignDetailsList.add(assignDetails);
                    dateAssignDetailsMap.put(date, dateAssignDetailsList);
                    sellTypeDayDetailsMap.put(sellType.getValue(), dateAssignDetailsMap);
                }
            }
        }

        // 构建结果
        for (Integer programMode : programModeDayMap.keySet()) {
            // 精准/非精准包含日期
            List<String> dateList = programModeDayMap.get(programMode);

            for (Integer sellType : sellTypeDayDetailsMap.keySet()) {
                SystemCreateResourceScheduleDTO resourceScheduleDTO = new SystemCreateResourceScheduleDTO();
                if (CollectionUtils.isNotEmpty(campaignViewDTO.getCampaignResourceViewDTO().getSspResourceIds())) {
                    resourceScheduleDTO.setResourceId(campaignViewDTO.getCampaignResourceViewDTO().getSspResourceIds().get(0));
                }
                // ResourceSchedulePutStyleEnum:精准/非精准
                if (programMode.intValue() == InventoryUdBaseDTO.ProgramMode.PRECISION.getValue()) {
                    resourceScheduleDTO.setSchedulePutType(SchedulePutTypeEnum.PRECISE_PUT.getCode());
                } else if (programMode.intValue() == InventoryUdBaseDTO.ProgramMode.IMPRECISION.getValue()) {
                    resourceScheduleDTO.setSchedulePutType(SchedulePutTypeEnum.NO_PRECISE_PUT.getCode());
                }
                // MediaResourceSellNuitEnum
                if (BrandCampaignRegisterUnitEnum.CPM.getCode().equals(campaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterUnit())) {
                    resourceScheduleDTO.setResourceSellUnit(UdSaleUnitEnum.CPM.getValue());
                } else if (BrandCampaignRegisterUnitEnum.DAY.getCode().equals(campaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterUnit())) {
                    resourceScheduleDTO.setResourceSellUnit(UdSaleUnitEnum.CPT.getValue());
                } else if (BrandCampaignRegisterUnitEnum.ROUND.getCode().equals(campaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterUnit())) {
                    resourceScheduleDTO.setResourceSellUnit(UdSaleUnitEnum.ROUND.getValue());
                } else if (BrandCampaignRegisterUnitEnum.CPC.getCode().equals(campaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterUnit())) {
                    resourceScheduleDTO.setResourceSellUnit(UdSaleUnitEnum.CPC.getValue());
                }
                // MediaResourceSellWayEnum
                resourceScheduleDTO.setPurchaseWay(getPurchaseWay(campaignViewDTO).getCode());

                // 单元备注：文本格式。如定向条件选择了 地域，则在单元备注中填写具体的城市名称。媒体制作排期时根据
                resourceScheduleDTO.setNote(getRemark(campaignViewDTO.getTitle(), BizCampaignGroupToolsHelper.getCustomerMemberId(campaignGroupViewDTO), campaignViewDTO));
                // 构建结构化定向信息
                resourceScheduleDTO.setAddPolicyNodeList(getAddPolicyNodeList(campaignViewDTO));

                List<ResourceScheduleCycleDTO> scheduleCycleList = Lists.newArrayList();
                // 售卖类型维度
                Map<String, List<InventoryUdDetailsDTO.AssignDetails>> dateSellTypeAssignDetailsMap = sellTypeDayDetailsMap.get(sellType);

                for (String date : dateSellTypeAssignDetailsMap.keySet()) {
                    Integer totalToBuyAmount = 0;
                    // 精准非精准过滤
                    List<InventoryUdDetailsDTO.AssignDetails> extraInfoAssignDetailsList = Lists.newArrayList();
                    if (dateList.contains(date)) {
                        for (InventoryUdDetailsDTO.AssignDetails assignDetails : dateSellTypeAssignDetailsMap.get(date)) {
                            // 按售卖单位维度进行累加
                            totalToBuyAmount += assignDetails.getToBuyAmount();
                            if (assignDetails.getToBuyAmount() != 0) {
                                extraInfoAssignDetailsList.add(assignDetails);
                            }
                        }

                        if (CollectionUtils.isEmpty(dateSellTypeAssignDetailsMap.get(date)) || totalToBuyAmount == 0) {
                            continue;
                        }

                        ResourceScheduleCycleDTO resourceScheduleCycleDTO = new ResourceScheduleCycleDTO();
                        resourceScheduleCycleDTO.setScheduleDate(DateUtils.parseDate(date));
                        resourceScheduleCycleDTO.setAmount(totalToBuyAmount);
                        resourceScheduleCycleDTO.setExtraInfo(getExtraInfo(businessId, extraInfoAssignDetailsList, campaignViewDTO));
                        scheduleCycleList.add(resourceScheduleCycleDTO);
                    }
                }
                if (!CollectionUtils.isEmpty(scheduleCycleList)) {
                    resourceScheduleDTO.setScheduleCycleList(scheduleCycleList);
                    systemCreateResourceScheduleDTOList.add(resourceScheduleDTO);
                }
            }
        }
    }

    private static SellTypeEnum getPurchaseWay(CampaignViewDTO campaignViewDTO) {
        if (BrandCampaignRegisterMannerEnum.PD.getCode().equals(campaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterManner())) {
            return SellTypeEnum.PD;
        }
        if (BrandCampaignRegisterMannerEnum.PDB.getCode().equals(campaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterManner())) {
            if (campaignViewDTO.getCampaignGuaranteeViewDTO().getSspPushSendRatio() == null) {
                return SellTypeEnum.DIRECT;
            }
            return SellTypeEnum.PDB;
        }
        return SellTypeEnum.DIRECT;
    }

    /**
     * 获取备注
     *
     * @param campaignGroupName
     * @param campaignViewDTO
     * @return
     */
    private String getRemark(String campaignGroupName, Long customerMemberId, CampaignViewDTO campaignViewDTO) {
        String str = "【订单名称】" + campaignGroupName + "【店铺名称】" + memberSAO.getMemberNameById(customerMemberId);

        // 构建备注信息
        List<String> targetList = Lists.newArrayList();
        targetList.add(str);
        List<CampaignTargetViewDTO> campaignTargetViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignTargetScenarioViewDTO())
                .map(CampaignTargetScenarioViewDTO::getCampaignTargetViewDTOList).orElse(Lists.newArrayList());
        if (CollectionUtils.isNotEmpty(campaignTargetViewDTOList)) {
            Optional<CampaignTargetViewDTO> campaignTargetViewDTO = campaignTargetViewDTOList.stream().filter(
                    item -> item.getType().equals(String.valueOf(BrandTargetTypeEnum.AREA_MEDIA.getCode()))).findFirst();
            if (campaignTargetViewDTO.isPresent()) {
                CampaignTargetViewDTO area = campaignTargetViewDTO.get();
                // 地域
                List<Integer> areaIds = area.getTargetValues().stream().map(item -> Integer.parseInt(item)).collect(Collectors.toList());
                List<AreaDTO> areaDTOS = productSAO.getSSPArea(areaIds);
                targetList.add("【媒体地域】" + StringUtils.join(areaDTOS.stream().map(item -> item.getName()).collect(Collectors.toList()), ","));
            }
//            //三环场景-阿里小时定向不参与询缩量
//            if(!Objects.equals(MediaScopeEnum.SITE_OUT.getCode(),campaignViewDTO.getSspResourceViewDTO().getSspMediaScope())){
//                Optional<CampaignTargetViewDTO> timePlusList = campaignViewDTO.getCampaignTargetViewDTOList().stream()
//                        .filter(item -> item.getType().equals(String.valueOf(BrandTargetTypeEnum.TIME_PLUS.getCode()))).findFirst();
//                if (timePlusList.isPresent()) {
//                    CampaignTargetViewDTO timePlus = timePlusList.get();
//                    // 时段
//                    targetList.add("【时段】" + StringUtils.join(BrandLocalDateTimeUtil.getBetweenHourResult(timePlus.getTargetValues(), true), ","));
//                }
//            }

            Optional<CampaignTargetViewDTO> timePlusMediaList = campaignTargetViewDTOList.stream().filter(
                    item -> item.getType().equals(String.valueOf(BrandTargetTypeEnum.TIME_PLUS_MEDIA.getCode()))).findFirst();
            if (timePlusMediaList.isPresent()) {
                CampaignTargetViewDTO timePlus = timePlusMediaList.get();
                // 时段
                targetList.add("【媒体时段】" + StringUtils.join(BrandLocalDateTimeUtil.getBetweenHourResult(timePlus.getTargetValues(), true), ","));
            }
            // 人群打分
            Optional<CampaignTargetViewDTO> crowdScoreTarget = campaignTargetViewDTOList.stream().filter(item -> String.valueOf(BrandTargetTypeEnum.ALI_CROWD_SCORE.getCode()).equals(item.getType())).findFirst();
            if (crowdScoreTarget.isPresent()) {
                Set<String> crowdScoreSet = performSAO.getSortedScoreSet(inventoryConverter.buildServiceContext(campaignViewDTO), crowdScoreTarget.get().getTargetValues().stream().map(Long::valueOf).collect(Collectors.toList()));
                targetList.add("【人群打分】" + StringUtils.join(crowdScoreSet, ","));
            }

        }
        List<String> genderNames = buildDicList(BrandTargetTypeEnum.GENDER_PLUS, campaignViewDTO, RETURN_TYPE_NAME);
        if (CollectionUtils.isNotEmpty(genderNames)) {
            targetList.add("【性别】" + StringUtils.join(genderNames, ","));
        }


        List<String> newDeviceNames = buildDicList(BrandTargetTypeEnum.DEVICE_MEDIA, campaignViewDTO, RETURN_TYPE_NAME);
        if (CollectionUtils.isNotEmpty(newDeviceNames)) {
            targetList.add("【平台】" + StringUtils.join(newDeviceNames, ","));
        }


        List<String> ageNames = buildAgeDicList(campaignViewDTO, RETURN_TYPE_NAME);
        if (CollectionUtils.isNotEmpty(ageNames)) {
            targetList.add("【年龄】" + StringUtils.join(ageNames, ","));
        }

        // 贴片
        List<String> positionPlusNames = buildDicList(BrandTargetTypeEnum.POSITION_PLUS_MEDIA, campaignViewDTO, RETURN_TYPE_NAME);
        if (CollectionUtils.isNotEmpty(positionPlusNames)) {
            targetList.add("【贴片位置】" + StringUtils.join(positionPlusNames, ","));
        }

        // 投放方式PDB/PD
        String pdbInfo = "";
        String pdTypeName = "";
        SellTypeEnum sellTypeEnum = getPurchaseWay(campaignViewDTO);
        String typeName = sellTypeEnum.getName();
        // 推送比
        if (campaignViewDTO.getCampaignGuaranteeViewDTO().getSspPushSendRatio() != null) {
            pdbInfo += " 推送比：" + campaignViewDTO.getCampaignGuaranteeViewDTO().getSspPushSendRatio() / 100 + "%";
        }
        // pd类型
        if (campaignViewDTO.getCampaignInquiryLockViewDTO().getPdType() != null) {
            pdTypeName = " PD类型：" + BrandCampaignPdTypeEnum.getByCode(campaignViewDTO.getCampaignInquiryLockViewDTO().getPdType()).getDesc();
        }
        targetList.add("【PDB-PD】投放类型：" + typeName + pdbInfo + pdTypeName);

        // 素材时长
        if (campaignViewDTO.getCampaignCreativeControllerViewDTO().getTimeLength() != null) {
            targetList.add("【素材时长】" + campaignViewDTO.getCampaignCreativeControllerViewDTO().getTimeLength());
        }
        return StringUtils.join(targetList, ";");
    }

    private List<String> buildDicList(BrandTargetTypeEnum brandTargetTypeEnum, CampaignViewDTO campaignViewDTO, Integer returnType) {
        List<String> resultList = Lists.newArrayList();

        List<CampaignTargetViewDTO> campaignTargetViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignTargetScenarioViewDTO())
                .map(CampaignTargetScenarioViewDTO::getCampaignTargetViewDTOList).orElse(Lists.newArrayList());
        if (CollectionUtils.isEmpty(campaignTargetViewDTOList)) {
            return resultList;
        }
        Optional<CampaignTargetViewDTO> campaignTargetViewDTO = campaignTargetViewDTOList.stream().filter(item -> item.getType().equals(String.valueOf(brandTargetTypeEnum.getCode()))).findFirst();
        if (campaignTargetViewDTO.isPresent()) {
            CampaignTargetViewDTO age = campaignTargetViewDTO.get();
            // 地域
            List<DictionaryDTO> dictionaryDTOS = productSAO.getSSPDict(brandTargetTypeEnum.getKey());
            for (DictionaryDTO dto : dictionaryDTOS) {
                for (String value : age.getTargetValues()) {
                    if (dto.getValue().equals(value)) {
                        if (returnType.equals(RETURN_TYPE_NAME)) {
                            resultList.add(dto.getName());
                        }
                        if (returnType.equals(RETURN_TYPE_VALUE)) {
                            resultList.add(dto.getValue());
                        }
                    }
                }
            }
        }
        return resultList;
    }

    private List<String> buildAgeDicList(CampaignViewDTO campaignViewDTO, Integer returnType) {
        List<CampaignTargetViewDTO> campaignTargetViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignTargetScenarioViewDTO())
                .map(CampaignTargetScenarioViewDTO::getCampaignTargetViewDTOList).orElse(Lists.newArrayList());
        if (CollectionUtils.isEmpty(campaignTargetViewDTOList)) {
            return Lists.newArrayList();
        }
        Optional<CampaignTargetViewDTO> campaignTargetViewDTO = campaignTargetViewDTOList.stream()
                .filter(item -> item.getType().equals(String.valueOf(BrandTargetTypeEnum.AGE_PLUS.getCode()))).findFirst();
        if (campaignTargetViewDTO.isPresent()) {
            Set<Integer> campaignAgeSet = campaignTargetViewDTO.get().getTargetValues().stream().flatMap(item -> NumberUtil.getRangeNums(item, "-").stream())
                    .collect(Collectors.toCollection(TreeSet::new));
            if (RETURN_TYPE_VALUE.equals(returnType)) {
                return campaignAgeSet.stream().map(String::valueOf).collect(Collectors.toList());
            }
            if (RETURN_TYPE_NAME.equals(returnType)) {
                List<DictionaryDTO> dictionaryDTOS = productSAO.getSSPDict(BrandTargetTypeEnum.AGE_PLUS.getKey());
                Map<String, String> dicAgeMap = dictionaryDTOS.stream().collect(Collectors.toMap(DictionaryDTO::getValue, DictionaryDTO::getName));
                return campaignAgeSet.stream().map(age -> dicAgeMap.get(String.valueOf(age))).filter(Objects::nonNull).collect(Collectors.toList());
            }
        }
        return Lists.newArrayList();
    }


    private List<String> buildAgeTargetList(List<String> valueList) {
        List<String> ageValueList = Lists.newArrayList();
        if (CollectionUtils.isEmpty(valueList)) {
            return ageValueList;
        }

        for (String value : valueList) {
            if (StringUtils.isBlank(value)) {
                continue;
            }
            String[] values = StringUtils.split(value, "-");
            if (Objects.isNull(values) || values.length != 2) {
                continue;
            }

            Integer minAge = Integer.parseInt(values[0]);
            Integer maxAge = Integer.parseInt(values[1]);
            while (minAge <= maxAge) {
                ageValueList.add(String.valueOf(minAge));
                minAge++;
            }
        }

        return ageValueList;
    }

    /**
     * 构建备注(用于MD5)
     *
     * @param campaignViewDTO
     * @return
     */
    private String getOtherDimensions(CampaignViewDTO campaignViewDTO) {
        String str = "";
        // 定向集合
        List<String> targetList = Lists.newArrayList();

        List<CampaignTargetViewDTO> campaignTargetViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignTargetScenarioViewDTO())
                .map(CampaignTargetScenarioViewDTO::getCampaignTargetViewDTOList).orElse(Lists.newArrayList());
        if (CollectionUtils.isNotEmpty(campaignTargetViewDTOList)) {
            Optional<CampaignTargetViewDTO> campaignTargetViewDTO = campaignTargetViewDTOList.stream().filter(
                    item -> item.getType().equals(String.valueOf(BrandTargetTypeEnum.AREA_MEDIA.getCode()))).findFirst();
            if (campaignTargetViewDTO.isPresent()) {
                CampaignTargetViewDTO area = campaignTargetViewDTO.get();
                // 地域
                targetList.add("【地域】" + StringUtils.join(area.getTargetValues(), ","));
            }

            List<String> genderValues = buildDicList(BrandTargetTypeEnum.GENDER_PLUS, campaignViewDTO, RETURN_TYPE_VALUE);
            if (CollectionUtils.isNotEmpty(genderValues)) {
                targetList.add("【性别】" + StringUtils.join(genderValues, ","));
            }

            List<String> ageValues = buildAgeDicList(campaignViewDTO, RETURN_TYPE_VALUE);
            if (CollectionUtils.isNotEmpty(ageValues)) {
                targetList.add("【年龄】" + StringUtils.join(ageValues, ","));
            }

            List<String> newDeviceValues = buildDicList(BrandTargetTypeEnum.DEVICE_MEDIA, campaignViewDTO, RETURN_TYPE_VALUE);
            if (CollectionUtils.isNotEmpty(newDeviceValues)) {
                targetList.add("【平台】" + StringUtils.join(newDeviceValues, ","));
            }
        }

        // 素材时长
        if (campaignViewDTO.getCampaignCreativeControllerViewDTO().getTimeLength() != null) {
            targetList.add("【素材时长】" + campaignViewDTO.getCampaignCreativeControllerViewDTO().getTimeLength());
        }
        // 排序
        Collections.sort(targetList);
        str = StringUtils.join(targetList, ";");
        RogerLogger.info("UdInventoryConverter campaign {} getOtherDimensions str:{}", campaignViewDTO.getId(), str);
        return str;
    }


    private List<AddPolicyNode> getAddPolicyNodeList(CampaignViewDTO campaignViewDTO) {
        List<AddPolicyNode> addPolicyNodeList = Lists.newArrayList();

        List<CampaignTargetViewDTO> campaignTargetViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignTargetScenarioViewDTO())
                .map(CampaignTargetScenarioViewDTO::getCampaignTargetViewDTOList).orElse(Lists.newArrayList());
        if (CollectionUtils.isNotEmpty(campaignTargetViewDTOList)) {
            // 地域
            Optional<CampaignTargetViewDTO> areaTarget = campaignTargetViewDTOList.stream().filter(
                    item -> item.getType().equals(String.valueOf(BrandTargetTypeEnum.AREA_MEDIA.getCode()))).findFirst();
            if (areaTarget.isPresent()) {
                AddPolicyNode areaPolicyNode = buildAddPolicyNode(BrandTargetTypeEnum.AREA_MEDIA.getKey(), areaTarget.get().getTargetValues());
                addPolicyNodeList.add(areaPolicyNode);
            }
            // 人群性别
            Optional<CampaignTargetViewDTO> genderTarget = campaignTargetViewDTOList.stream().filter(
                    item -> item.getType().equals(String.valueOf(BrandTargetTypeEnum.GENDER_PLUS.getCode()))).findFirst();
            if (genderTarget.isPresent()) {
                AddPolicyNode genderPolicyNode = buildAddPolicyNode(BrandTargetTypeEnum.GENDER_PLUS.getKey(), genderTarget.get().getTargetValues());
                addPolicyNodeList.add(genderPolicyNode);
            }

            // 人群年龄段
            Optional<CampaignTargetViewDTO> ageTarget = campaignTargetViewDTOList.stream().filter(
                    item -> item.getType().equals(String.valueOf(BrandTargetTypeEnum.AGE_PLUS.getCode()))).findFirst();
            if (ageTarget.isPresent()) {
                Set<Integer> ageSet = ageTarget.get().getTargetValues().stream().flatMap(item -> NumberUtil.getRangeNums(item, "-").stream())
                        .collect(Collectors.toCollection(TreeSet::new));
                List<String> ageList = ageSet.stream().map(String::valueOf).collect(Collectors.toList());
                AddPolicyNode agePolicyNode = buildAddPolicyNode(BrandTargetTypeEnum.AGE_PLUS.getKey(), ageList);
                addPolicyNodeList.add(agePolicyNode);
            }

            // 平台
            Optional<CampaignTargetViewDTO> newDeviceTarget = campaignTargetViewDTOList.stream().filter(
                    item -> item.getType().equals(String.valueOf(BrandTargetTypeEnum.DEVICE_MEDIA.getCode()))).findFirst();
            if (newDeviceTarget.isPresent()) {
                AddPolicyNode devicePolicyNode = buildAddPolicyNode(BrandTargetTypeEnum.DEVICE_MEDIA.getKey(), newDeviceTarget.get().getTargetValues());
                addPolicyNodeList.add(devicePolicyNode);
            }
            // 贴片
            Optional<CampaignTargetViewDTO> positionPlusTarget = campaignTargetViewDTOList.stream().filter(
                    item -> item.getType().equals(String.valueOf(BrandTargetTypeEnum.POSITION_PLUS_MEDIA.getCode()))).findFirst();
            if (positionPlusTarget.isPresent()) {
                AddPolicyNode positionPlusNode = buildAddPolicyNode(BrandTargetTypeEnum.POSITION_PLUS_MEDIA.getKey(), positionPlusTarget.get().getTargetValues());
                addPolicyNodeList.add(positionPlusNode);
            }

            //三环场景-阿里小时定向不参与询缩量，媒体投放时段定向参与询缩量
//            if(!Objects.equals(MediaScopeEnum.SITE_OUT.getCode(),campaignViewDTO.getSspResourceViewDTO().getSspMediaScope())){
//                Optional<CampaignTargetViewDTO> timePlusTarget = campaignViewDTO.getCampaignTargetViewDTOList().stream().filter(
//                        item -> item.getType().equals(String.valueOf(BrandTargetTypeEnum.TIME_PLUS.getCode()))).findFirst();
//                if (timePlusTarget.isPresent()) {
//                    List<String> timePlusList = timePlusTarget.get().getTargetValues();
//                    AddPolicyNode devicePolicyNode = buildAddPolicyNode(BrandTargetTypeEnum.TIME_PLUS.getKey(), BrandLocalDateTimeUtil.getBetweenHourResult(timePlusList, true));
//                    addPolicyNodeList.add(devicePolicyNode);
//                }
//            }else{
//            }
            // 三环媒体投放时段
            Optional<CampaignTargetViewDTO> timePlusMediaTarget = campaignTargetViewDTOList.stream().filter(
                    item -> item.getType().equals(String.valueOf(BrandTargetTypeEnum.TIME_PLUS_MEDIA.getCode()))).findFirst();
            if (timePlusMediaTarget.isPresent()) {
                List<String> timePlusList = timePlusMediaTarget.get().getTargetValues();
                AddPolicyNode devicePolicyNode = buildAddPolicyNode(BrandTargetTypeEnum.TIME_PLUS_MEDIA.getKey(), BrandLocalDateTimeUtil.getBetweenHourResult(timePlusList, true));
                addPolicyNodeList.add(devicePolicyNode);
            }

            // 人群打分
            Optional<CampaignTargetViewDTO> crowdScoreTarget = campaignTargetViewDTOList.stream().filter(item -> item.getType().equals(String.valueOf(BrandTargetTypeEnum.ALI_CROWD_SCORE.getCode()))).findFirst();
            if (crowdScoreTarget.isPresent()) {
                Set<String> crowdScoreSet = performSAO.getSortedScoreSet(inventoryConverter.buildServiceContext(campaignViewDTO), crowdScoreTarget.get().getTargetValues().stream().map(Long::valueOf).collect(Collectors.toList()));
                AddPolicyNode areaPolicyNode = buildAddPolicyNode(BrandTargetTypeEnum.ALI_CROWD_SCORE.getKey(), new ArrayList<>(crowdScoreSet));
                addPolicyNodeList.add(areaPolicyNode);
            }
        }
        // 素材时长
        if (campaignViewDTO.getCampaignCreativeControllerViewDTO().getTimeLength() != null) {
            AddPolicyNode timeLengPolicyNode = buildAddPolicyNode(DictTypeEnum.TIMELENG_PLUS.getType(),
                    Lists.newArrayList(String.valueOf(campaignViewDTO.getCampaignCreativeControllerViewDTO().getTimeLength())));
            addPolicyNodeList.add(timeLengPolicyNode);
        }

        //PDB
        if (campaignViewDTO.getCampaignGuaranteeViewDTO().getSspPushSendRatio() != null) {
            AddPolicyNode pdbPolicyNode = buildAddPolicyNode(DictTypeEnum.PUSHPGE.getType(),
                    Lists.newArrayList(String.valueOf(campaignViewDTO.getCampaignGuaranteeViewDTO().getSspPushSendRatio() != null ?
                            campaignViewDTO.getCampaignGuaranteeViewDTO().getSspPushSendRatio() / 100 : 100)));
            addPolicyNodeList.add(pdbPolicyNode);
        }

        if (BrandCampaignRegisterMannerEnum.PD.getCode().equals(campaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterManner()) &&
                campaignViewDTO.getCampaignInquiryLockViewDTO().getPdType() != null) {
            AddPolicyNode pdPolicyNode = buildAddPolicyNode(DictTypeEnum.PD_PLUS.getType(),
                    Lists.newArrayList(String.valueOf(campaignViewDTO.getCampaignInquiryLockViewDTO().getPdType())));
            addPolicyNodeList.add(pdPolicyNode);
        }

        return addPolicyNodeList;
    }

    /**
     * 构建结构化定向
     *
     * @param firstLevelValue
     * @param valueList
     * @return
     */
    private AddPolicyNode buildAddPolicyNode(String firstLevelValue, List<String> valueList) {
        if (CollectionUtils.isEmpty(valueList)) {
            return null;
        }

        AddPolicyNode addPolicyNode = new AddPolicyNode();
        // 一级节点
        addPolicyNode.setKey(AddPolicyNode.FIRST_LEVEL_KEY);
        addPolicyNode.setValue(firstLevelValue);
        // 二级节点（采购三级节点）
        List<AddPolicyNode> childNodeList = Lists.newArrayList();
        valueList.forEach(value -> {
            if (StringUtils.isNotBlank(value)) {
                AddPolicyNode childNode = new AddPolicyNode();
                childNode.setKey(AddPolicyNode.THIRD_LEVEL_KEY);
                childNode.setValue(value);
                childNodeList.add(childNode);
            }
        });
        addPolicyNode.setChildNodes(childNodeList);
        return addPolicyNode;
    }


    private String getExtraInfo(String businessId, List<InventoryUdDetailsDTO.AssignDetails> assignDetailsList, CampaignViewDTO campaignViewDTO) {
        if (CollectionUtils.isEmpty(assignDetailsList)) {
            return "";
        }
        // 构建返回数据
        InventoryUdExtDTO inventoryUdExtDTO = new InventoryUdExtDTO();
        List<InventoryUdExtDTO.ReserveResource> reserveResourceList = Lists.newArrayList();
        for (InventoryUdDetailsDTO.AssignDetails assignDetails : assignDetailsList) {
            InventoryUdExtDTO.ReserveResource reserveResource = new InventoryUdExtDTO.ReserveResource();
            reserveResource.setBusinessId(Long.parseLong(businessId));
            reserveResource.setReserveGroupId(assignDetails.getReserveGroupId());
            reserveResource.setReserveOrderId(assignDetails.getReserveOrderId());
            reserveResource.setResourceId(campaignViewDTO.getCampaignResourceViewDTO().getSspResourceIds().get(0));
            reserveResource.setAmount(assignDetails.getToBuyAmount());
            reserveResourceList.add(reserveResource);
        }
        String extraInfo = getOtherDimensions(campaignViewDTO);
        if (StringUtils.isNotBlank(extraInfo)) {
            inventoryUdExtDTO.setDimensionsMD5(DigestUtils.md5Hex(extraInfo));
        }
        inventoryUdExtDTO.setReserveResourceList(reserveResourceList);
        return JSONObject.toJSONString(inventoryUdExtDTO);
    }

}
