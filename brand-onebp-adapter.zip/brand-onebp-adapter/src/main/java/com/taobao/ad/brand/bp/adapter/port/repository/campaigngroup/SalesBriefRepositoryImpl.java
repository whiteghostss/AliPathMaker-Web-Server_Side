package com.taobao.ad.brand.bp.adapter.port.repository.campaigngroup;

import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.alibaba.ad.nb.sales.constant.brief.BriefStateEnum;
import com.alibaba.ad.nb.sales.dto.brief.BriefDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.sales.BriefDTOConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.sales.BriefSAO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesBriefViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.SalesBriefRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * @author yanjingang
 * @date 2023/3/9
 */
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SalesBriefRepositoryImpl implements SalesBriefRepository {

    private final BriefSAO briefSAO;
    private final BriefDTOConverter briefDTOConverter;


    @Override
    public SalesBriefViewDTO getBrief(Long briefId) {
        BriefDTO briefDTO = briefSAO.getBrief(briefId);
        return briefDTOConverter.convertBriefDTO2ViewDTO(briefDTO);
    }

    @Override
    public boolean canModify(Long briefId) {
        return briefSAO.canModify(briefId);
    }

    @Override
    public void modifyBrief(Long briefId) {
        briefSAO.modifyBrief(briefId);
    }

    @Override
    public void syncCampaignGroupInfoToBrief(CampaignGroupViewDTO campaignGroupViewDTO) {
        BrandCampaignGroupStatusEnum statusEnum = BrandCampaignGroupStatusEnum.getByCode(campaignGroupViewDTO.getStatus());
        AssertUtil.assertTrue(briefDTOConverter.campaignGroup2BriefStatusMap.containsKey(statusEnum.getCode()),
                BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR,
                String.format("当前订单状态[%s]不支持订单信息同步至Brief", statusEnum.getDesc()));
        BriefDTO briefDTO = briefDTOConverter.convertCampaignGroupViewDTO2DTOForSyncInfo(campaignGroupViewDTO);
        briefSAO.acceptStatusEvent(briefDTO);
    }

    @Override
    public void finishBrief(CampaignGroupViewDTO campaignGroupViewDTO) {
        BriefDTO briefDTO = briefDTOConverter.convertBaseInfoViewDTO2DTO(campaignGroupViewDTO);
        briefDTO.setStatus(BriefStateEnum.EXECUTE_FINISHED.value);
        briefSAO.acceptStatusEvent(briefDTO);
    }

    @Override
    public void finishRevertBrief(CampaignGroupViewDTO campaignGroupViewDTO) {
        BriefDTO briefDTO = briefDTOConverter.convertBaseInfoViewDTO2DTO(campaignGroupViewDTO);
        briefDTO.setStatus(BriefStateEnum.EXECUTE_ING.value);
        briefSAO.acceptStatusEvent(briefDTO);
    }

    @Override
    public void acceptStatusEvent(SalesBriefViewDTO salesBriefViewDTO) {
        if (salesBriefViewDTO == null) {
            return;
        }
        BriefDTO briefDTO = briefDTOConverter.convertViewDTO2DTO(salesBriefViewDTO);
        fillBaseInfo(briefDTO);
        briefSAO.acceptStatusEvent(briefDTO);
    }

    public void fillBaseInfo(BriefDTO briefDTO) {
        if (briefDTO == null) {
            return;
        }
        briefDTO.setSource("nb-brandOneBp");
    }
}
