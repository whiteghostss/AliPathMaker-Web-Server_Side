package com.taobao.ad.brand.bp.adapter.port.converter.template;

import com.alibaba.ad.nb.ssp.dto.template.NbTemplateContextDTO;
import com.alibaba.ad.nb.ssp.dto.template.NbTemplateDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.template.mapstruct.TemplateContextMapStruct;
import com.taobao.ad.brand.bp.adapter.port.converter.template.mapstruct.TemplateMapStruct;
import com.taobao.ad.brand.bp.client.dto.template.TemplateContextViewDTO;
import com.taobao.ad.brand.bp.client.dto.template.TemplateViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.springframework.stereotype.Component;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/3/17 21:26
 * @description ：
 * @modified By：
 */
@Component
public class TemplateContextConverter extends BaseViewDTOConverter<NbTemplateContextDTO, TemplateContextViewDTO> {

    @Override
    public BaseMapStructMapper<NbTemplateContextDTO, TemplateContextViewDTO> getBaseMapStructMapper() {
        return TemplateContextMapStruct.INSTANCE;
    }
}
