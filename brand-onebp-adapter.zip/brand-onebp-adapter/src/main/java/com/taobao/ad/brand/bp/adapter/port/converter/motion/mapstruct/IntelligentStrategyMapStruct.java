
package com.taobao.ad.brand.bp.adapter.port.converter.motion.mapstruct;

import com.alibaba.ad.nb.packages.v2.client.dto.motion.IntelligentMotionDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.motion.IntelligentStrategyDTO;
import com.taobao.ad.brand.bp.client.dto.motion.IntelligentMotionViewDTO;
import com.taobao.ad.brand.bp.client.dto.motion.IntelligentStrategyViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * BizCreativeMapStruct
 * DTO与领域模型实体映射
 * @author ddd-coder-init
 * @date 2020/12/12
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, uses = {MediaStrategyMapStruct.class, MarketingStageMapStruct.class, ProductStrategyMapStruct.class})
public interface IntelligentStrategyMapStruct extends BaseMapStructMapper<IntelligentStrategyDTO, IntelligentStrategyViewDTO> {

	IntelligentStrategyMapStruct INSTANCE = Mappers.getMapper(IntelligentStrategyMapStruct.class);

	@Mappings({
			@Mapping(source = "predictData", target = "predictDataViewDTO"),
			@Mapping(source = "mediaStrategyList", target = "mediaStrategyViewDTOList"),
			@Mapping(source = "resourceProductStrategyList", target = "resourceProductStrategyViewDTOList"),
			@Mapping(source = "marketingStageList", target = "marketingStageViewDTOList"),
			@Mapping(source = "productStrategyList", target = "productStrategyViewDTOList"),
			@Mapping(source = "distributionRuleList", target = "distributionRuleDTOList"),
            @Mapping(source = "newDeliveryTargetList", target = "newDeliveryTargetList"),
	})
	@Override
	IntelligentStrategyViewDTO sourceToTarget(IntelligentStrategyDTO intelligentMotionDTO);

	@Mappings({
			@Mapping(source = "predictDataViewDTO", target = "predictData"),
			@Mapping(source = "mediaStrategyViewDTOList", target = "mediaStrategyList"),
			@Mapping(source = "resourceProductStrategyViewDTOList", target = "resourceProductStrategyList"),
			@Mapping(source = "marketingStageViewDTOList", target = "marketingStageList"),
			@Mapping(source = "productStrategyViewDTOList", target = "productStrategyList"),
			@Mapping(source = "distributionRuleDTOList", target = "distributionRuleList"),
            @Mapping(source = "newDeliveryTargetList", target = "newDeliveryTargetList"),
	})
	@Override
	IntelligentStrategyDTO targetToSource(IntelligentStrategyViewDTO intelligentStrategyViewDTO);
}

