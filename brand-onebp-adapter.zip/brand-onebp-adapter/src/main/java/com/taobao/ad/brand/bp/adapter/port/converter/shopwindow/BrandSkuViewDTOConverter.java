package com.taobao.ad.brand.bp.adapter.port.converter.shopwindow;


import com.taobao.ad.brand.bp.adapter.port.converter.shopwindow.mapstruct.BrandSkuMapStruct;
import com.taobao.ad.brand.bp.adapter.port.converter.shopwindow.mapstruct.BrandSkuQueryMapStruct;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSkuViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.query.BrandSkuQueryViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import com.taobao.ad.brand.perform.client.dto.shopwindow.sku.SkuViewDTO;
import com.taobao.ad.brand.perform.client.dto.shopwindow.spu.SkuQueryViewDTO;
import org.springframework.stereotype.Component;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/6/25
 **/
@Component
public class BrandSkuViewDTOConverter extends BaseViewDTOConverter<SkuViewDTO, BrandSkuViewDTO> {

    @Override
    public BaseMapStructMapper<SkuViewDTO, BrandSkuViewDTO> getBaseMapStructMapper() {
        return BrandSkuMapStruct.INSTANCE;
    }

    public SkuQueryViewDTO sourceToQueryTarget(BrandSkuQueryViewDTO brandSkuQueryViewDTO){
        return BrandSkuQueryMapStruct.INSTANCE.sourceToTarget(brandSkuQueryViewDTO);
    }
}
