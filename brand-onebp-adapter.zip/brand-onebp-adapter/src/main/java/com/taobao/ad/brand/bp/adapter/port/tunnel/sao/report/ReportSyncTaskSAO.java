package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.report;

import com.alibaba.ad.nb.direct.client.context.NbDirectServiceContext;
import com.alibaba.ad.nb.task.client.api.async.AsyncTaskCommandService;
import com.alibaba.ad.nb.task.client.api.async.AsyncTaskQueryService;
import com.alibaba.ad.nb.task.client.dto.async.AsyncTaskDTO;
import com.alibaba.ad.nb.task.client.dto.async.AsyncTaskQueryDTO;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Objects;

/**
 * 报表异步任务相关方法
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ReportSyncTaskSAO {
    private final AsyncTaskQueryService asyncTaskQueryService;
    private final AsyncTaskCommandService asyncTaskCommandService;

    public List<AsyncTaskDTO> queryList(AsyncTaskQueryDTO taskQueryDTO){
        MultiResponse<AsyncTaskDTO> response = asyncTaskQueryService.queryList(initNbDirectServiceContext(), taskQueryDTO);
        AssertUtil.assertTrue(Objects.nonNull(response) && response.isSuccess(), "查询异步任务列表失败");
        return response.getResult();
    }

    public MultiResponse<AsyncTaskDTO> queryListWithPage(AsyncTaskQueryDTO taskQueryDTO){
        MultiResponse<AsyncTaskDTO> response = asyncTaskQueryService.queryListWithPage(initNbDirectServiceContext(), taskQueryDTO);
        AssertUtil.assertTrue(Objects.nonNull(response) && response.isSuccess(), "查询异步任务列表失败");
        return response;
    }

    public AsyncTaskDTO get(AsyncTaskQueryDTO taskQueryDTO){
        AssertUtil.notNull(taskQueryDTO.getId());
        SingleResponse<AsyncTaskDTO> response = asyncTaskQueryService.get(initNbDirectServiceContext(), taskQueryDTO.getId());
        AssertUtil.assertTrue(Objects.nonNull(response) && response.isSuccess(), "查询异步任务列表失败");
        return response.getResult();
    }

    public Long add(AsyncTaskDTO asyncTaskDTO){
        SingleResponse<Long> response = asyncTaskCommandService.add(initNbDirectServiceContext(), asyncTaskDTO);
        AssertUtil.assertTrue(Objects.nonNull(response) && response.isSuccess(), "添加异步任务失败");
        return response.getResult();
    }

    public Long modify(AsyncTaskDTO asyncTaskDTO){
        AssertUtil.notNull(asyncTaskDTO.getId());
        SingleResponse<Long> response = asyncTaskCommandService.update(initNbDirectServiceContext(), asyncTaskDTO);
        AssertUtil.assertTrue(Objects.nonNull(response) && response.isSuccess(), "更新异步任务失败");
        return response.getResult();
    }

    public Long delete(AsyncTaskQueryDTO queryDTO){
        SingleResponse<Long> response = asyncTaskCommandService.delete(initNbDirectServiceContext(), queryDTO);
        AssertUtil.assertTrue(Objects.nonNull(response) && response.isSuccess(), "删除异步任务失败");
        return response.getResult();
    }

    private NbDirectServiceContext initNbDirectServiceContext(){
        NbDirectServiceContext context = new NbDirectServiceContext();
        return context;
    }
}
