package com.taobao.ad.brand.bp.adapter.port.converter.sales;

import com.alibaba.ad.nb.sales.dto.zhubajie.CompleteBrandDTO;
import com.alibaba.ad.nb.sales.dto.zhubajie.QabDimShopIdBrandIdDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.sales.mapstruct.ContractBrandMapStruct;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesContractBrandViewDTO;
import com.taobao.ad.brand.bp.client.dto.shop.ShopBrandViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.springframework.stereotype.Component;

/**
 * @author yuncheng.lyc
 */
@Component
public class ContractBrandViewDTOConverter extends BaseViewDTOConverter<CompleteBrandDTO, SalesContractBrandViewDTO> {

    @Override
    public BaseMapStructMapper<CompleteBrandDTO, SalesContractBrandViewDTO> getBaseMapStructMapper() {
        return ContractBrandMapStruct.INSTANCE;
    }

    public QabDimShopIdBrandIdDTO convertViewDTO2DTO(ShopBrandViewDTO shopBrandViewDTO){
        QabDimShopIdBrandIdDTO shopIdBrandIdDTO = new QabDimShopIdBrandIdDTO();
        shopIdBrandIdDTO.setSellerId(shopBrandViewDTO.getTbUserId());
        shopIdBrandIdDTO.setShopId(shopBrandViewDTO.getShopId());
        shopIdBrandIdDTO.setBrandId(shopBrandViewDTO.getBrandId());
        shopIdBrandIdDTO.setBrandName(shopBrandViewDTO.getBrandName());
        return shopIdBrandIdDTO;
    }
}
