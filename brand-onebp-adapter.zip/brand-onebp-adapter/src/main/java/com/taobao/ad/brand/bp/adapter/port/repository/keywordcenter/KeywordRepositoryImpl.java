package com.taobao.ad.brand.bp.adapter.port.repository.keywordcenter;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.keyword.CampaignKeywordViewDTO;
import com.alibaba.ad.brand.dto.campaign.keyword.CampaignWordPackageViewDTO;
import com.alibaba.ad.brand.dto.campaign.keyword.CampaignWordViewDTO;
import com.alibaba.ad.brand.sdk.convert.custom.viewdto.keywordcenter.WordPackageViewDTO2DTOConvertProcessor;
import com.alibaba.ad.brand.sdk.convert.custom.viewdto.keywordcenter.WordViewDTO2DTOConvertProcessor;
import com.alibaba.ad.universal.sdk.convert.custom.onebp.provider.OneBpConvertProcessorProvider;
import com.alibaba.fastjson.JSON;
import com.alibaba.hermes.framework.utils.BeanUtils;
import com.alibaba.solar.sirius.client.dto.BidwordAccessDTO;
import com.alibaba.solar.sirius.client.dto.BidwordDTO;
import com.alibaba.solar.sirius.client.dto.BrandBidwordPackageDTO;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.alimama.faas.brand.engine.entity.constant.ServiceCodeEnum;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.dmpargus.DmpArgusSAO;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.keywordcenter.KeywordCenterSAO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignKeywordEstimateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.KeywordAccessViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignKeywordEstimateQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.DmpArgusEstimateViewDTO;
import com.taobao.ad.brand.bp.client.enums.keyword.KeywordEstimateTypeEnum;
import com.taobao.ad.brand.bp.domain.keywordcenter.repository.KeywordRepository;
import com.taobao.ad.brand.bp.domain.memeber.MemberRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class KeywordRepositoryImpl implements KeywordRepository {

    private final KeywordCenterSAO keywordCenterSAO;

    private final DmpArgusSAO dmpArgusSAO;

    private final MemberRepository memberRepository;

    private WordViewDTO2DTOConvertProcessor PROCESSOR = OneBpConvertProcessorProvider.getViewDTO2DTOConvertProcessor(WordViewDTO2DTOConvertProcessor.class);
    private WordPackageViewDTO2DTOConvertProcessor wordPkgPROCESSOR = OneBpConvertProcessorProvider.getViewDTO2DTOConvertProcessor(WordPackageViewDTO2DTOConvertProcessor.class);

    @Override
    public Map<Long, CampaignKeywordViewDTO> selectByCampaignIds(ServiceContext serviceContext, List<Long> campaignIdList) {
        Map<Long, CampaignKeywordViewDTO> keywordMap = Maps.newHashMap();
        if(CollectionUtils.isEmpty(campaignIdList)){
            return keywordMap;
        }
        //关键词
        List<BidwordDTO> bidWordDTOList = keywordCenterSAO.findBidWordList(serviceContext, campaignIdList);
        if(CollectionUtils.isNotEmpty(bidWordDTOList)){
            Map<Long, List<BidwordDTO>> bidWordMap = bidWordDTOList.stream().collect(Collectors.groupingBy(BidwordDTO::getCampaignId));
            for (Map.Entry<Long, List<BidwordDTO>> entry : bidWordMap.entrySet()) {
                List<CampaignWordViewDTO> wordList = PROCESSOR.dtoList2ViewDTOList(entry.getValue());
                CampaignKeywordViewDTO campaignKeywordViewDTO = new CampaignKeywordViewDTO();
                campaignKeywordViewDTO.setCampaignWordViewDTOList(wordList);
                keywordMap.put(entry.getKey(), campaignKeywordViewDTO);
            }
        }
        //词包
        List<BrandBidwordPackageDTO> bidWordPackageDTOList = keywordCenterSAO.findWordPackageList(serviceContext, campaignIdList);
        if(CollectionUtils.isNotEmpty(bidWordPackageDTOList)){
            Map<Long, BrandBidwordPackageDTO> wordPackageMap = bidWordPackageDTOList.stream().collect(Collectors.toMap(BrandBidwordPackageDTO::getCampaignId, e->e, (v1, v2)->v2));
            for (Map.Entry<Long,BrandBidwordPackageDTO> entry : wordPackageMap.entrySet()) {
                CampaignWordPackageViewDTO wordPackage = wordPkgPROCESSOR.dto2ViewDTO(entry.getValue());
                if(keywordMap.containsKey(entry.getKey())){
                    keywordMap.get(entry.getKey()).setCampaignWordPackageViewDTO(wordPackage);
                }else{
                    CampaignKeywordViewDTO campaignKeywordViewDTO = new CampaignKeywordViewDTO();
                    campaignKeywordViewDTO.setCampaignWordPackageViewDTO(wordPackage);
                    keywordMap.put(entry.getKey(), campaignKeywordViewDTO);
                }
            }
        }
        return keywordMap;
    }
    @Override
    public void add(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList) {
        if(CollectionUtils.isEmpty(campaignViewDTOList)){
            return;
        }

        for(CampaignViewDTO campaignViewDTO : campaignViewDTOList){
            //词包
            BrandBidwordPackageDTO bidWordPackageDTO = buildWordPackage(campaignViewDTO.getCampaignKeywordViewDTO().getCampaignWordPackageViewDTO(), campaignViewDTO.getId());
            List<Long> wordPackageIdList = Lists.newArrayList();
            if(bidWordPackageDTO != null){
                wordPackageIdList = keywordCenterSAO.batchAddWordPackage(serviceContext, campaignViewDTO.getId(), Lists.newArrayList(bidWordPackageDTO));
            }
            //关键词
            Long wordPackageId = CollectionUtils.isEmpty(wordPackageIdList) ? null : wordPackageIdList.get(0);
            List<BidwordDTO> bidWordList = buildKeyword(campaignViewDTO.getCampaignKeywordViewDTO().getCampaignWordViewDTOList(), campaignViewDTO.getId(), wordPackageId);
            keywordCenterSAO.batchAddWords(serviceContext, bidWordList);

        }
    }

    @Override
    public void delete(ServiceContext serviceContext, List<Long> wordIdList, List<Long> wordPackageIdList) {
        if(CollectionUtils.isNotEmpty(wordIdList)){
            keywordCenterSAO.batchDelWords(serviceContext, wordIdList);
        }
        if(CollectionUtils.isNotEmpty(wordPackageIdList)){
            keywordCenterSAO.batchDelWordPackages(serviceContext, wordPackageIdList);
        }
    }

    @Override
    public Map<String, String> selectNormalWordList(ServiceContext serviceContext, List<String> wordList) {
        Map<String, String> normalWordMap = keywordCenterSAO.normalizeBatch(serviceContext, wordList);
        return normalWordMap;
    }

    @Override
    public Map<String, KeywordAccessViewDTO> wordAccess(ServiceContext serviceContext, List<String> wordList) {
        Map<String, BidwordAccessDTO> bidWordAccessMap = keywordCenterSAO.bidWordAccess(serviceContext, wordList);
        Map<String, KeywordAccessViewDTO> keywordAccessMap = Maps.newHashMap();
        for(Map.Entry<String, BidwordAccessDTO> entry : bidWordAccessMap.entrySet()){
            KeywordAccessViewDTO keywordAccessViewDTO = new KeywordAccessViewDTO();
            BeanUtils.copy(entry.getValue(), keywordAccessViewDTO);
            keywordAccessMap.put(entry.getKey(), keywordAccessViewDTO);
        }
        return keywordAccessMap;
    }

    @Override
    public Map<String, CampaignWordViewDTO> selectKeywordEstimateList(ServiceContext serviceContext, List<CampaignWordViewDTO> campaignWordViewDTOList) {
        DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO = new DmpArgusEstimateViewDTO();
        dmpArgusEstimateViewDTO.setKeywordEstimateType(KeywordEstimateTypeEnum.KW_PV.getCode());
        dmpArgusEstimateViewDTO.setCampaignWordViewDTOList(campaignWordViewDTOList);
        dmpArgusEstimateViewDTO.setServiceCode("OneSearchShow");
        RogerLogger.info("selectKeywordDayPrePv.campaignWordViewDTOList:{}, dmpArgusEstimateViewDTO:{}", JSON.toJSONString(campaignWordViewDTOList), JSON.toJSONString(dmpArgusEstimateViewDTO));
        CampaignKeywordEstimateViewDTO estimateViewDTO = dmpArgusSAO.estimateKeyword(serviceContext, dmpArgusEstimateViewDTO);
        RogerLogger.info("selectKeywordDayPrePv.estimateViewDTO:{}", JSON.toJSONString(estimateViewDTO));
        if(estimateViewDTO == null || estimateViewDTO.getKeywordViewDTO() == null || CollectionUtils.isEmpty(estimateViewDTO.getKeywordViewDTO().getCampaignWordViewDTOList())){
            return Maps.newHashMap();
        }
        return estimateViewDTO.getKeywordViewDTO().getCampaignWordViewDTOList().stream().collect(Collectors.toMap(CampaignWordViewDTO::getWord, e->e, (v1,v2)->v2));
    }

    @Override
    public CampaignKeywordEstimateViewDTO selectKeywordAllDayPrePv(ServiceContext serviceContext, List<CampaignWordViewDTO> campaignWordViewDTOList) {
        DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO = new DmpArgusEstimateViewDTO();
        dmpArgusEstimateViewDTO.setKeywordEstimateType(KeywordEstimateTypeEnum.KW_ESTIMATE_SCOPE.getCode());
        dmpArgusEstimateViewDTO.setCampaignWordViewDTOList(campaignWordViewDTOList);
        dmpArgusEstimateViewDTO.setServiceCode(ServiceCodeEnum.OneSearchShow.name());
        CampaignKeywordEstimateViewDTO estimateViewDTO = dmpArgusSAO.estimateKeyword(serviceContext, dmpArgusEstimateViewDTO);
        return estimateViewDTO;
    }

    @Override
    public List<CampaignWordViewDTO> selectKeywordRecommendList(ServiceContext serviceContext, CampaignKeywordEstimateQueryViewDTO queryViewDTO) {
        DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO = new DmpArgusEstimateViewDTO();
        dmpArgusEstimateViewDTO.setServiceCode(ServiceCodeEnum.OneSearchShow.name());
        dmpArgusEstimateViewDTO.setKeyword(queryViewDTO.getKeyword());
        dmpArgusEstimateViewDTO.setBrandId(queryViewDTO.getBrandId());
        dmpArgusEstimateViewDTO.setKeywordAssociateMethod(queryViewDTO.getAssociateMethod());
        dmpArgusEstimateViewDTO.setKeywordClassification(queryViewDTO.getClassification());
        //根据代理商member获取真实商家member
        dmpArgusEstimateViewDTO.setMemberId(memberRepository.getTargetMemberIdByMemberId(serviceContext.getMemberId()));
        return dmpArgusSAO.recommendKeyword(serviceContext, dmpArgusEstimateViewDTO);
    }

    @Override
    public CampaignWordPackageViewDTO selectWordPackageRecommend(ServiceContext serviceContext, CampaignKeywordEstimateQueryViewDTO queryViewDTO) {
        DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO = new DmpArgusEstimateViewDTO();
        dmpArgusEstimateViewDTO.setServiceCode(ServiceCodeEnum.OneSearchShow.name());
        dmpArgusEstimateViewDTO.setItemId(queryViewDTO.getItemId());
        dmpArgusEstimateViewDTO.setBrandId(queryViewDTO.getBrandId());
        dmpArgusEstimateViewDTO.setWordPackageType(queryViewDTO.getWordPackageType());
        //根据代理商member获取真实商家member
        dmpArgusEstimateViewDTO.setMemberId(memberRepository.getTargetMemberIdByMemberId(serviceContext.getMemberId()));
        return dmpArgusSAO.recommendWordPackage(serviceContext, dmpArgusEstimateViewDTO);
    }

    private List<BidwordDTO> buildKeyword(List<CampaignWordViewDTO> wordList, Long campaignId, Long wordPackageId) {
        if(CollectionUtils.isEmpty(wordList)){
            return Lists.newArrayList();
        }
        if(wordPackageId != null){
            wordList.forEach(item -> item.setWordPackageId(wordPackageId));
        }
        List<BidwordDTO> bidWordDTOList = PROCESSOR.viewDTOList2DTOList(wordList);
        bidWordDTOList.forEach(item -> item.setCampaignId(campaignId));
        return bidWordDTOList;
    }

    private BrandBidwordPackageDTO buildWordPackage(CampaignWordPackageViewDTO wordPackageViewDTO, Long campaignId){
        if(wordPackageViewDTO == null){
            return null;
        }
        BrandBidwordPackageDTO bidwordPackageDTO = wordPkgPROCESSOR.viewDTO2DTO(wordPackageViewDTO);
        bidwordPackageDTO.setCampaignId(campaignId);
        return bidwordPackageDTO;
    }
}
