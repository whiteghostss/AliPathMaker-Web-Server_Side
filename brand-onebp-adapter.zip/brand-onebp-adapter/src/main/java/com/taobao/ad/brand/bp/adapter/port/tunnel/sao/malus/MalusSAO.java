package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.malus;

import com.alibaba.fastjson.JSON;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alimama.cara.CreationServer;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;

/**
 * 海棠相关服务
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class MalusSAO {

    private final CreationServer creationServer;

    /**
     * 批量拓版图片
     * @param cropMapList
     * @param authMap
     * @return
     */
    public String asyncBatchCrop(Map<String,Object> authMap,List<Map<String, Object>> cropMapList,Map<String,Object> opts){
        //参数转换
        RogerLogger.info("asyncBatchCrop_param = {}",JSON.toJSONString(cropMapList));
        Map resultMap = creationServer.asyncBatchCrop(authMap, cropMapList,opts);
        RogerLogger.info("asyncBatchCrop_result = {}",JSON.toJSONString(resultMap));
        AssertUtil.assertTrue(MapUtils.isNotEmpty(resultMap),BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of("拓版服务返回结果为空"));
        Response response = JSON.parseObject(JSON.toJSONString(resultMap), Response.class);
        AssertUtil.assertTrue(response.getSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR.of(response.getMessage()));
        return response.getJobId();
    }

    @Data
    static class Response {
        private Boolean success;
        private String jobId;
        private String message;
    }
}
