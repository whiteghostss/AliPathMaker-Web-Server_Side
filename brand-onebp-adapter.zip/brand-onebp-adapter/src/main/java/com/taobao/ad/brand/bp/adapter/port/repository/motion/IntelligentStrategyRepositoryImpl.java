package com.taobao.ad.brand.bp.adapter.port.repository.motion;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.nb.packages.v2.client.dto.motion.IntelligentStrategyDTO;
import com.alibaba.ad.nb.packages.v2.client.dto.motion.query.StrategyQueryDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.motion.IntelligentStrategyDTOConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.resourcepackage.ResourcePackageSAO;
import com.taobao.ad.brand.bp.client.dto.motion.IntelligentStrategyViewDTO;
import com.taobao.ad.brand.bp.client.dto.motion.query.StrategyQueryViewDTO;
import com.taobao.ad.brand.bp.domain.motion.IntelligentStrategyRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/20
 **/
@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class IntelligentStrategyRepositoryImpl implements IntelligentStrategyRepository {

    private final ResourcePackageSAO resourcePackageSAO;
    private final IntelligentStrategyDTOConverter intelligentStrategyDTOConverter;


    @Override
    public List<IntelligentStrategyViewDTO> queryIntelligentStrategyList(ServiceContext serviceContext, StrategyQueryViewDTO strategyQueryViewDTO) {
        List<IntelligentStrategyDTO> intelligentStrategyDTOList = resourcePackageSAO.queryIntelligentStrategyList(serviceContext, convertStrategyQuery(strategyQueryViewDTO));
        return intelligentStrategyDTOConverter.convertDTO2ViewDTOList(intelligentStrategyDTOList);
    }

    @Override
    public Long saveIntelligentStrategy(ServiceContext serviceContext, IntelligentStrategyViewDTO strategyViewDTO) {
        IntelligentStrategyDTO strategyDTO = intelligentStrategyDTOConverter.convertViewDTO2DTO(strategyViewDTO);
        return resourcePackageSAO.saveIntelligentStrategy(serviceContext, strategyDTO);
    }

    @Override
    public void updateBasicIntelligentStrategy(ServiceContext serviceContext, IntelligentStrategyViewDTO strategyViewDTO) {
        IntelligentStrategyDTO strategyDTO = intelligentStrategyDTOConverter.convertViewDTO2DTO(strategyViewDTO);
        resourcePackageSAO.updatBasicIntelligentStrategy(serviceContext, strategyDTO);
    }

    private StrategyQueryDTO convertStrategyQuery(StrategyQueryViewDTO strategyQueryViewDTO) {
        return StrategyQueryDTO.builder()
                .idList(strategyQueryViewDTO.getIdList())
                .needProductStrategy(strategyQueryViewDTO.getNeedProductStrategy())
                .motionId(strategyQueryViewDTO.getMotionId())
                .build();
    }
}
