package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.inventory;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.alibaba.solar.common.dto.ResultDTO;
import com.alibaba.uad.wto.api.purchase.PurchaseOrderCommandService;
import com.alibaba.uad.wto.api.purchase.PurchaseOrderQueryService;
import com.alibaba.uad.wto.dto.purchase.UdContentPurchaseOrderCreationDTO;
import com.alibaba.uad.wto.dto.purchase.query.PurchaseOrderQueryDTO;
import com.alibaba.uad.wto.hsf.dto.PurchaseOrderDTO;
import com.alibaba.uad.wto.hsf.dto.inquiry.InquiryDTO;
import com.alibaba.uad.wto.hsf.dto.purchase.SystemCreateResourceScheduleDTO;
import com.alibaba.uad.wto.hsf.service.InquiryService;
import com.alibaba.uad.wto.hsf.service.PurchaseOrderService;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.alimama.inventory.api.NbInventoryUdService;
import com.alimama.inventory.api.universal.UniInventoryService;
import com.alimama.inventory.dto.ud.InventoryUdDetailsDTO;
import com.alimama.inventory.dto.ud.InventoryUdImprecisionDTO;
import com.alimama.inventory.dto.ud.InventoryUdInquiryDTO;
import com.alimama.inventory.dto.universal.UniCancelResponse;
import com.alimama.inventory.dto.universal.UniInquiryRequest;
import com.alimama.inventory.dto.universal.UniInquiryResponse;
import com.alimama.inventory.dto.universal.UniReleaseRequest;
import com.alimama.inventory.dto.universal.UniRequest;
import com.alimama.inventory.result.InventoryCenterResult;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Objects;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/03/08
 */
@BizTunnel

@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class InventorySAO extends BaseSAO {
    private static final Integer MAX_TRY_COUNT = 3;
    private final UniInventoryService uniInventoryService;
    private final NbInventoryUdService nbInventoryUdService;
    private final PurchaseOrderService purchaseOrderService;
    private final InquiryService inquiryService;
    private final PurchaseOrderCommandService purchaseOrderCommandService;
    private final PurchaseOrderQueryService purchaseOrderQueryService;


    public void search(UniInquiryRequest request) {
        InventoryCenterResult<Boolean> response = uniInventoryService.search(request);
        AssertUtil.notNull(response, "库存询量失败");
        AssertUtil.assertTrue(response.isSuccess() && Boolean.TRUE.equals(response.getResult()), "库存询量失败" + response.getMsg());
    }

    public void book(UniInquiryRequest request) {
        InventoryCenterResult<Boolean> response = uniInventoryService.book(request);
        AssertUtil.notNull(response, "库存锁量失败");
        AssertUtil.assertTrue(response.isSuccess() && Boolean.TRUE.equals(response.getResult()), "库存锁量失败" + response.getMsg());
    }

    public void release(UniReleaseRequest request) {
        InventoryCenterResult<Boolean> response = uniInventoryService.release(request);
        AssertUtil.notNull(response, "库存释量失败");
        AssertUtil.assertTrue(response.isSuccess() && Boolean.TRUE.equals(response.getResult()), "库存释量失败" + response.getMsg());
    }

    public void cancel(UniRequest uniRequest) {
        InventoryCenterResult<UniCancelResponse> response = uniInventoryService.cancel(uniRequest);
        RogerLogger.info("InventorySAO cancel inventory response :{}", JSON.toJSONString(response));
        AssertUtil.notNull(response, "库存取消询/锁量失败");
        // 调用库存的取消询/锁量接口 成功的计划存在 successList 里面 如果成功的列表里面 含有该计划id 则取消询/锁量成功
        AssertUtil.assertTrue(response.isSuccess() && response.getResult().getSuccessList().contains(uniRequest.getBusinessId()), "库存取消询/锁量失败" + response.getMsg());
    }

    public UniInquiryResponse dailyUpdate(UniInquiryRequest request) {
        for (int i = 0; i < MAX_TRY_COUNT; i++) {
            try {
                InventoryCenterResult<UniInquiryResponse> response = uniInventoryService.dailyUpdate(request);
                AssertUtil.notNull(response, "滚量日更错误");
                AssertUtil.assertTrue(response.isSuccess(), response.getMsg());
                return response.getResult();
            } catch (Exception e) {
                RogerLogger.error("滚量日更错误,i={},params={}", i, JSON.toJSONString(request), e);
            }
        }
        return null;
    }


    public InventoryUdDetailsDTO getBookDetail(InventoryUdInquiryDTO inventoryUdInquiryDTO) {
        InventoryCenterResult<InventoryUdDetailsDTO>  response = nbInventoryUdService.bookDetails(inventoryUdInquiryDTO);
        AssertUtil.notNull(response, "获取三环库存信息失败");
        AssertUtil.assertTrue(response.isSuccess() , "获取三环库存信息失败" + response.getMsg());
        return response.getResult();
    }



    public void confirmOrder(InventoryUdInquiryDTO inventoryUdInquiryDTO) {
        InventoryCenterResult<Boolean>  response = nbInventoryUdService.confirmOrder(inventoryUdInquiryDTO);
        AssertUtil.notNull(response, "获取三环库存信息失败");
        AssertUtil.assertTrue(response.isSuccess() && Boolean.TRUE.equals(response.getResult()), "获取三环库存信息失败" + response.getMsg());
    }




    public Long addPurchaseOrder(ServiceContext context, PurchaseOrderDTO purchaseOrderDTO, List<SystemCreateResourceScheduleDTO> systemCreateResourceScheduleDTOList){
        try {
            ResultDTO<Long> resultDTO = purchaseOrderService.newSystemCreatePurchaseOrder(context, purchaseOrderDTO, systemCreateResourceScheduleDTOList);
            RogerLogger.info("PurchaseOrderSAO purchaseOrderService.systemCreatePurchaseOrder 返回 :{}" , JSONObject.toJSONString(resultDTO));
            if (Objects.isNull(resultDTO) || !resultDTO.isSuccess()) {
                RogerLogger.error("PurchaseOrderSAO addPurchaseOrder 调用创建采购单接口失败, resultDTO:{}" + JSONObject.toJSONString(resultDTO));
                throw new BrandOneBPException(BrandOneBPBaseErrorCode.RPC_ERROR.getErrCode(),"发起采购失败"+resultDTO.getMsg());
            }
            return resultDTO.getResult();
        } catch (Exception e) {
            RogerLogger.error("PurchaseOrderSAO purchaseOrderService.systemCreatePurchaseOrder 报错，e.getMessage:{}", e.getMessage(), e);
            throw new BrandOneBPException(BrandOneBPBaseErrorCode.RPC_ERROR.getErrCode(),"发起采购失败"+e.getMessage());
        }
    }

    public Long mediaInquiry(InquiryDTO inquiryDTO) {
        RogerLogger.info("mediaInquiryWTO params:{}", JSON.toJSONString(inquiryDTO));
        com.alibaba.solar.common.dto.ServiceContext context = com.alibaba.solar.common.dto.ServiceContext.createServiceContext();
        ResultDTO<Long> resultDTO = inquiryService.newSystemInquiry(context, inquiryDTO);
        AssertUtil.assertTrue(resultDTO != null && resultDTO.isSuccess(), BrandOneBPBaseErrorCode.PARAM_REQUIRED, "媒体询量失败" + resultDTO.getMsg());
        RogerLogger.info("mediaInquiryWTO result:{}", resultDTO.getResult());
        return resultDTO.getResult();
    }

    /**
     * 根据子计划id获取打底日期
     * @param positionId
     * @return
     */
    public InventoryUdImprecisionDTO getBottomPurchaseOrder(Long positionId){
        InventoryCenterResult<InventoryUdImprecisionDTO> inventoryCenterResult = nbInventoryUdService.imprecisionDetails(positionId);

        AssertUtil.assertTrue(inventoryCenterResult != null && inventoryCenterResult.isSuccess(), BrandOneBPBaseErrorCode.EXTERNAL_ERROR, "查询打底信息失败" + inventoryCenterResult.getMsg());
        InventoryUdImprecisionDTO imprecisionDTO = inventoryCenterResult.getResult();
        if (null == inventoryCenterResult.getResult()){
            RogerLogger.info("brandonebp-purchaseOrder-imprecision 子计划查询不到打底采购行信息，子计划id = {}，result={}",positionId,JSON.toJSONString(inventoryCenterResult));
            throw new BrandOneBPException("查询打底单元异常");
        }
        return imprecisionDTO;
    }

    /**
     * 内容-发起采购单
     *
     * @return 采购单id
     */
    public Long addPurchaseOrderContent(ServiceContext serviceContext, UdContentPurchaseOrderCreationDTO orderDTO) {
        com.alibaba.uad.wto.context.ServiceContext wtoServiceContext = com.alibaba.uad.wto.context.ServiceContext.builder()
                .bizCode(serviceContext.getBizCode())
                .build();
        SingleResponse<Long> response = purchaseOrderCommandService.add(wtoServiceContext, orderDTO);
        AssertUtil.assertTrue(response);
        return response.getResult();
    }

    /**
     * 内容-查询采购单信息
     */
    public List<com.alibaba.uad.wto.dto.purchase.PurchaseOrderDTO> getPurchaseOrderContent(ServiceContext serviceContext, PurchaseOrderQueryDTO purchaseOrderQueryDTO) {
        com.alibaba.uad.wto.context.ServiceContext wtoServiceContext = com.alibaba.uad.wto.context.ServiceContext.builder()
            .bizCode(serviceContext.getBizCode())
            .build();
        MultiResponse<com.alibaba.uad.wto.dto.purchase.PurchaseOrderDTO> response = purchaseOrderQueryService.list(wtoServiceContext, purchaseOrderQueryDTO);
        AssertUtil.assertTrue(response);
        return response.getResult();
    }

}
