package com.taobao.ad.brand.bp.adapter.port.tunnel.sao.taojimu;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.fastjson.JSON;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.BaseSAO;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandShopWindowTjmSubscribeViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.taojimu.AlpPage;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/**
 * @author jixiu.lj
 * @date 2024/9/19 20:03
 */
@Component
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class TaoJiMuSAO extends BaseSAO {

    private final AlpPage alpPage;

    /**
     * 淘积木包装服务：淘宝开放平台三方isv订购
     * @param serviceContext
     * @param brandShopWindowTjmSubscribeViewDTO
     */
    public void subscribe(ServiceContext serviceContext, BrandShopWindowTjmSubscribeViewDTO brandShopWindowTjmSubscribeViewDTO) {
        Long loginMainTbNumId = brandShopWindowTjmSubscribeViewDTO.getLoginMainTbNumId();
        Map<String, Object> resultMap = alpPage.orderWidgetForShop(loginMainTbNumId, brandShopWindowTjmSubscribeViewDTO.getAppId(), brandShopWindowTjmSubscribeViewDTO.getAppVersion());
        AssertUtil.assertTrue(Objects.nonNull(resultMap), "订购失败，请重试");
        RogerLogger.info("淘积木isv订购回执信息,resultMap: {}", JSON.toJSONString(resultMap));
        AssertUtil.assertTrue(Objects.equals(resultMap.get("flag"), true), "订购失败，请重试");
    }


    /**
     * 淘积木包装服务：查询订购信息
     * @param serviceContext
     * @param brandShopWindowTjmSubscribeViewDTO
     * @return
     */
    public BrandShopWindowTjmSubscribeViewDTO querySubscribeInfo(ServiceContext serviceContext, BrandShopWindowTjmSubscribeViewDTO brandShopWindowTjmSubscribeViewDTO){
        Long loginMainTbNumId = brandShopWindowTjmSubscribeViewDTO.getLoginMainTbNumId();
        RogerLogger.info("淘积木isv订购查询信息，brandShopWindowTjmSubscribeViewDTO:{} serviceContext:{}", JSON.toJSONString(brandShopWindowTjmSubscribeViewDTO), JSON.toJSONString(serviceContext));
        Map<String, Object> resultMap = alpPage.searchOrderInfoForShop(loginMainTbNumId, brandShopWindowTjmSubscribeViewDTO.getAppId());
        AssertUtil.assertTrue(Objects.nonNull(resultMap), "查询订购信息失败，请重试");
        RogerLogger.info("淘积木isv订购查询信息，resultMap:{}", JSON.toJSONString(resultMap));
        AssertUtil.assertTrue(Objects.equals(resultMap.get("flag"), true), "查询订购信息失败，请重试");
        Map<String, Object> data = (Map<String, Object>)resultMap.get("data");
        if(Objects.nonNull(data)){
            BrandShopWindowTjmSubscribeViewDTO result = new BrandShopWindowTjmSubscribeViewDTO();
            result.setAppId(Optional.ofNullable(data.get("appId")).map(String::valueOf).orElse(null));
            result.setAppVersion(Optional.ofNullable(data.get("appVersion")).map(String::valueOf).orElse(null));
            result.setPageId(Optional.ofNullable(data.get("pageId")).map(String::valueOf).orElse(null));
            if(Objects.nonNull(data.get("endTime")) && data.get("endTime") instanceof Date) {
                result.setEndTime((Date) data.get("endTime"));
            }
            return result;
        }
        return null;
    }


}
