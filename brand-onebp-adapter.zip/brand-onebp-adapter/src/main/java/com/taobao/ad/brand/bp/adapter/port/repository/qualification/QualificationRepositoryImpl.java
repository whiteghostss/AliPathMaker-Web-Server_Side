package com.taobao.ad.brand.bp.adapter.port.repository.qualification;

import com.alibaba.abf.governance.context.ServiceContext;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.qualification.QualificationSAO;
import com.taobao.ad.brand.bp.client.dto.qualification.QualificationViewDTO;
import com.taobao.ad.brand.bp.domain.qualification.QualificationRepository;
import com.taobao.simba.qualification.api.dataobject.biz.QualificationQueryResultDTO;
import com.taobao.simba.qualification.api.dataobject.biz.QualificationTypeNewDTO;
import com.taobao.simba.qualification.api.dataobject.biz.QualificationVO;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.stream.Collectors;

@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class QualificationRepositoryImpl implements QualificationRepository {

    private final QualificationSAO qualificationSAO;

    @Override
    public List<String> findQualificationTypeList() {
        List<QualificationTypeNewDTO> qualificationTypeList = qualificationSAO.findQualificationTypeList();
        if(CollectionUtils.isEmpty(qualificationTypeList)){
            return Lists.newArrayList();
        }
        return qualificationTypeList.stream().map(QualificationTypeNewDTO::getTypeName).collect(Collectors.toList());
    }

    @Override
    public List<QualificationViewDTO> findQualificationList(Long tbUserId, List<String> qualificationTypeList) {
        List<QualificationQueryResultDTO> qualificationQueryResultDTOS = qualificationSAO.findQualificationList(tbUserId, qualificationTypeList);
        if(CollectionUtils.isEmpty(qualificationQueryResultDTOS)){
            return Lists.newArrayList();
        }
        List<QualificationViewDTO> qualificationViewDTOS = Lists.newArrayList();
        for(QualificationQueryResultDTO qualificationQueryResultDTO : qualificationQueryResultDTOS){
            for(QualificationVO qualificationVO : qualificationQueryResultDTO.getQualificationVOs()){
                QualificationViewDTO qualificationViewDTO = new QualificationViewDTO();
                BeanUtils.copyProperties(qualificationVO, qualificationViewDTO);
                qualificationViewDTO.setTypeName(qualificationQueryResultDTO.getTypeName());
                qualificationViewDTOS.add(qualificationViewDTO);
            }
        }
        return qualificationViewDTOS;
    }
}
