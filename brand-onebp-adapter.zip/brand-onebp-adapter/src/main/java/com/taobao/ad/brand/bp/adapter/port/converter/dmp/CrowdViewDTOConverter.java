package com.taobao.ad.brand.bp.adapter.port.converter.dmp;

import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.adapter.port.converter.dmp.mapstruct.CrowdViewDTOMapStruct;
import com.taobao.ad.brand.bp.client.dto.dmp.CrowdViewDTO;
import com.taobao.ad.brand.bp.common.constant.DmpConstant;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import com.taobao.ad.dmp.client.dto.CrowdDTO;
import com.taobao.ad.dmp.client.dto.CrowdFullStatusEnum;
import com.taobao.ad.dmp.client.dto.CrowdXAppDTO;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;

/**
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@Component
public class CrowdViewDTOConverter extends BaseViewDTOConverter<CrowdDTO, CrowdViewDTO> {

    @Override
    public BaseMapStructMapper<CrowdDTO, CrowdViewDTO> getBaseMapStructMapper() {
        return CrowdViewDTOMapStruct.INSTANCE;
    }

    @Override
    public List<CrowdViewDTO> convertDTO2ViewDTOList(List<CrowdDTO> crowdDTOList) {
        List<CrowdViewDTO> crowdViewDTOList = Lists.newArrayList();
        crowdDTOList.forEach(crowdDTO-> crowdViewDTOList.add(convertDTO2ViewDTO(crowdDTO)));
        return crowdViewDTOList;
    }

    @Override
    public CrowdViewDTO convertDTO2ViewDTO(CrowdDTO crowdDTO) {
        crowdDTO.setFullStatus(getCrowdSyncStatusFromDTO(crowdDTO));
        return super.convertDTO2ViewDTO(crowdDTO);
    }

    private Integer getCrowdSyncStatusFromDTO(CrowdDTO crowdDTO) {
        // 从xapp中判断人群是否已应用到百灵渠道
        if (CollectionUtils.isNotEmpty(crowdDTO.getXapps())) {
            for (CrowdXAppDTO xapp : crowdDTO.getXapps()) {
                if (DmpConstant.DELIVER_APP_ID_BRAND_DMP.equals(xapp.getAppId())
                        || DmpConstant.DELIVER_APP_ID_BRAND_RECOMMEND.equals(xapp.getAppId())
                        || DmpConstant.CREATIVE_PREVIEW_DMP_MASK_APP_ID.equals(xapp.getAppId())) {
                    // 人群已应用到百灵渠道，获取同步生效状态，2：已应用，11：同步中，12：已同步
                    return Objects.equals(xapp.getStatus(), 2) ?
                            CrowdFullStatusEnum.SYNCED.getValue() :
                            CrowdFullStatusEnum.SYNCHRONIZING.getValue();
                }
            }
        }
        // 人群未应用到百灵渠道，获取人群本身状态并映射
        if (Objects.nonNull(crowdDTO.getStatus())) {
            switch (crowdDTO.getStatus()) {
                case 1:
                    return CrowdFullStatusEnum.VALID.getValue();
                case 2:
                    return CrowdFullStatusEnum.EXPIRE.getValue();
                case 3:
                    return CrowdFullStatusEnum.DRAFT.getValue(); //线上基本已经没有这种了
                case 4:
                    return CrowdFullStatusEnum.INVALID.getValue(); //线上基本已经没有这种了
                default:
                    return CrowdFullStatusEnum.DELETE.getValue();
            }
        }

        return CrowdFullStatusEnum.DELETE.getValue();
    }
}
