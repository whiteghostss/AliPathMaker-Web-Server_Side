package com.taobao.ad.brand.bp.adapter.port.repository.shopwindow;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.adapter.port.converter.shopwindow.BrandSpuViewDTOConverter;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.perform.PerformSAO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandBundleViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSpuViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.query.BrandSpuQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.spu.SpuMarketingRuleResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.spu.SpuMarketingRuleViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.shopwindow.repository.BrandSpuRepository;
import com.taobao.ad.brand.perform.client.dto.shopwindow.spu.SpuQueryViewDTO;
import com.taobao.ad.brand.perform.client.dto.shopwindow.spu.SpuViewDTO;
import com.taobao.ad.brand.perform.client.dto.shopwindow.spu.marketingrule.SpuCheckMarketingRuleParamViewDTO;
import com.taobao.ad.brand.perform.client.dto.shopwindow.spu.marketingrule.SpuCheckMarketingRuleResultViewDTO;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/6/26
 **/
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BrandSpuRepositoryImpl implements BrandSpuRepository {

    private final PerformSAO performSAO;
    private final BrandSpuViewDTOConverter brandSpuViewDTOConverter;
    @Override
    public List<BrandSpuViewDTO> findSpuList(ServiceContext serviceContext, BrandSpuQueryViewDTO brandSpuQueryViewDTO) {
        SpuQueryViewDTO spuQueryViewDTO = brandSpuViewDTOConverter.convert2QueryViewDTO(brandSpuQueryViewDTO);
        List<SpuViewDTO> spuList = performSAO.findSpuList(serviceContext, spuQueryViewDTO);
        return brandSpuViewDTOConverter.convertDTO2ViewDTOList(spuList);
    }

    @Override
    public BrandSpuViewDTO get(ServiceContext serviceContext, Long id) {
        SpuQueryViewDTO spuQueryViewDTO = new SpuQueryViewDTO();
        spuQueryViewDTO.setSpuId(id);
        spuQueryViewDTO.setNeedConfig(true);
        return brandSpuViewDTOConverter.convertDTO2ViewDTO(performSAO.getSpuDetail(spuQueryViewDTO));
    }

    @Override
    public BrandSpuViewDTO getDetail(ServiceContext serviceContext, BrandSpuQueryViewDTO brandSpuQueryViewDTO) {
        if(CollectionUtils.isEmpty(brandSpuQueryViewDTO.getSpuIdList())){
            return null;
        }
        SpuQueryViewDTO spuQueryViewDTO = brandSpuViewDTOConverter.convert2QueryViewDTO(brandSpuQueryViewDTO);
        spuQueryViewDTO.setSpuId(brandSpuQueryViewDTO.getSpuIdList().get(0));
        return brandSpuViewDTOConverter.convertDTO2ViewDTO(performSAO.getSpuDetail(spuQueryViewDTO));
    }

    @Override
    public List<SpuMarketingRuleResultViewDTO> checkSpuMarketingRule(ServiceContext serviceContext, List<SpuMarketingRuleViewDTO> spuRuleParamList) {
        List<SpuCheckMarketingRuleParamViewDTO> marketingRuleParamViewDTOList = spuRuleParamList.stream().map(spuMarketingRuleViewDTO -> {
            SpuCheckMarketingRuleParamViewDTO marketingRuleParamViewDTO = new SpuCheckMarketingRuleParamViewDTO();
            marketingRuleParamViewDTO.setSpuId(spuMarketingRuleViewDTO.getSpuId());
            marketingRuleParamViewDTO.setBudget(spuMarketingRuleViewDTO.getBudget());
            return marketingRuleParamViewDTO;
        }).collect(Collectors.toList());
        SpuCheckMarketingRuleResultViewDTO marketingRuleResultViewDTO = performSAO.checkMarketingRule(serviceContext, marketingRuleParamViewDTOList);
        AssertUtil.notNull(marketingRuleResultViewDTO,"SPU投放门槛校验失败");

        if(CollectionUtils.isEmpty(marketingRuleResultViewDTO.getResultList())){
            SpuMarketingRuleResultViewDTO spuMarketingRuleResultViewDTO = new SpuMarketingRuleResultViewDTO();
            spuMarketingRuleResultViewDTO.setIsPass(marketingRuleResultViewDTO.getPassed() ? BrandBoolEnum.BRAND_TRUE.getCode() : BrandBoolEnum.BRAND_FALSE.getCode());
            return Lists.newArrayList(spuMarketingRuleResultViewDTO);
        }
        return marketingRuleResultViewDTO.getResultList().stream().map(spuCheckResultViewDTO -> {
            SpuMarketingRuleResultViewDTO spuMarketingRuleResultViewDTO = new SpuMarketingRuleResultViewDTO();
            spuMarketingRuleResultViewDTO.setRuleName(spuCheckResultViewDTO.getCheckRuleName());
            spuMarketingRuleResultViewDTO.setIsPass(spuCheckResultViewDTO.getPassed() ? BrandBoolEnum.BRAND_TRUE.getCode() : BrandBoolEnum.BRAND_FALSE.getCode());
            spuMarketingRuleResultViewDTO.setReason(spuCheckResultViewDTO.getCheckRuleReason());
            spuMarketingRuleResultViewDTO.setSpuIdList(spuCheckResultViewDTO.getSpuIdList());
            return spuMarketingRuleResultViewDTO;
        }).collect(Collectors.toList());
    }
}
