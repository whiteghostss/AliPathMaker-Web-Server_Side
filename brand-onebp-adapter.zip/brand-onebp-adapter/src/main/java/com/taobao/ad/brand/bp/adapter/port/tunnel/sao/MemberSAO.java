package com.taobao.ad.brand.bp.adapter.port.tunnel.sao;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.uic.api.AccessControlQueryService;
import com.alibaba.ad.uic.common.dto.accesscontrol.JoinResultDTO;
import com.alibaba.ad.uic.common.dto.accesscontrol.JoinScenceDTO;
import com.alibaba.ad.uic.common.dto.accesscontrol.JoinScenceResultDTO;
import com.alibaba.ad.uic.common.dto.accesscontrol.JoinUserDTO;
import com.alibaba.ad.uic.common.dto.accesscontrol.ssp.JoinSspDTO;
import com.alibaba.ad.uic.common.dto.accesscontrol.ssp.JoinSspResultDTO;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.tunnel.annotation.BizTunnel;
import com.alibaba.hermes.framework.tunnel.sao.SAO;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.simba.user.SimbaUic;
import com.taobao.ad.simba.user.consts.MemberExternalEnum;
import com.taobao.ad.simba.user.dataobject.MembersRoleDO;
import com.taobao.ad.simba.user.dataobject.RelMemberDO;
import com.taobao.ad.simba.user.dto.ShopInfoDTO;
import com.taobao.ad.simba.user.dto.UserBindDTO;
import com.taobao.ad.simba.user.dto.UserDTO;
import com.taobao.ad.simba.user.dto.XMemberDTO;
import com.taobao.ad.simba.user.newservice.MemberService;
import com.taobao.ad.simba.user.result.Result;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 投放账号相关SAO
 *
 * @author xuxianan
 */
@BizTunnel
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class MemberSAO implements SAO {

    private final MemberService memberService;

    private final AccessControlQueryService accessControlQueryService;

    /**
     * 权限码ID
     */
    private static final Integer SYS_CODE = 131;

    /**
     * 根据投放账号ID获取投放账号名称<br> 还有一种场景是从CRM中查，但现在没有HSF服务，如果辛巴中查不到的话需要加上对应处理：nbCustomerMemberService.getMemberById <br>
     *
     * @param memberId 投放账号
     * @return String 投放账号名称
     * @throws Exception e
     */
    public String getMemberNameById(Long memberId) {
        String memberName = memberId.toString();
        try {
            Result<String> nickResult = SimbaUic._member.getTbNickNameByMemberId(memberId);
            if (Objects.nonNull(nickResult) && nickResult.isSuccess() && org.apache.commons.lang3.StringUtils.isNotEmpty(
                nickResult.getModule())) {
                memberName = nickResult.getModule();
            } else {
                Result<UserBindDTO> bindResult = SimbaUic._member.getBindUserInfoByMemberId(memberId,
                    MemberExternalEnum.YOUKU.name());
                if (Objects.nonNull(nickResult) && bindResult.isSuccess()) {
                    memberName = bindResult.getModule().getExtNick();
                }
            }
        } catch (Exception e) {
            RogerLogger.error("获取MemberName失败：", e);
        }
        return memberName;
    }

    public Set<String> findRoleCodeByMemberId(Long memberId) {
        Result<List<MembersRoleDO>> result = SimbaUic._role.findRolesOfMemBySysId(memberId, SYS_CODE);
        if (!result.isSuccess()) {
            RogerLogger.error("查询memberId={}的adc角色失败, result={}", memberId, JSON.toJSONString(result));
            throw new RuntimeException("查询memberId=" + memberId + "的adc角色失败");
        }
        return Optional.ofNullable(result.getModule())
            .map(list -> list.stream().map(MembersRoleDO::getRolecode).filter(StringUtils::isNotBlank).collect(Collectors.toSet()))
            .orElse(Collections.emptySet());
    }

    /**
     * 根据tbUserId获取memberId
     * @param tbUserId
     * @return
     */
    public Long getMemberIdByTbNumId(Long tbUserId) {
        Result<Long> result = SimbaUic._member.getMemberIdByTbNumId(tbUserId);
        if (!result.isSuccess()) {
            throw new BrandOneBPException(result.getResultCode(), result.getResultMsg());
        }
        return result.getModule();
    }
    /**
     * 根据member获取店铺ID
     * @param memberId
     * @return
     */
    public Long getShopIdByMemberId(Long memberId) {
        Result<ShopInfoDTO> result = SimbaUic._shopInfo.getShopInfoByMemberId(memberId);
        if (!result.isSuccess()) {
            throw new BrandOneBPException(result.getResultCode(), result.getResultMsg());
        }
        return result.getModule().getShopId();
    }

    public ShopInfoDTO getShopByMemberId(Long memberId){
        Result<ShopInfoDTO> result = SimbaUic._shopInfo.getShopInfoByMemberId(memberId);
        if (!result.isSuccess()) {
            throw new BrandOneBPException(result.getResultCode(), result.getResultMsg());
        }
        return result.getModule();
    }

    public Long getTbNumIdByMemberId(Long memberId) {
        Result<Long> result = SimbaUic._member.getTbNumIdByMemberId(memberId);
        if (result.isSuccess()) {
            return result.getModule();
        }
        RogerLogger.error("getTbNumIdByMemberId error, memberId={}, result={}", memberId, JSON.toJSONString(result));
        throw new RuntimeException("查询member的tbNumId失败");
    }

    /**
     * @param memberIds 投放账号id
     * @return map<投放账号, 叉乘账号友好展示>
     */
    public Map<Long, String> queryXMemberDisplayNameMap(List<Long> memberIds) {
        Result<List<XMemberDTO>> result = memberService.queryXMemberDisplayName(memberIds);
        RogerLogger.info("查询叉乘账号名称 result :{}",  JSONObject.toJSONString(result));
        if (!result.isSuccess()) {
            RogerLogger.info("查询叉乘账号友好名称异常 memberIds :{}", JSONObject.toJSONString(memberIds));
        }
        if (CollectionUtils.isNotEmpty(result.getModule())) {
            return result.getModule().stream().collect(Collectors.toMap(RelMemberDO::getRelMemberId, XMemberDTO::getDisplayName, (v1, v2) -> v1));
        }
        return Maps.newHashMap();
    }

    public List<String> queryJoinResult(ServiceContext context,Long memberId, List<String> supportScenceCodeList) {
        JoinUserDTO joinUserDTO = assembleJoinUserDTO(memberId, supportScenceCodeList);
        SingleResponse<JoinResultDTO> response = accessControlQueryService.queryJoinInfo(context, joinUserDTO);
        List<String> bizJoinResultList = Lists.newArrayList();
        if(!response.isSuccess()){
            AssertUtil.assertTrue(response.isSuccess(),String.format("查询广告主（%s）业务场景准入结果异常",memberId));
        }
        if(response.getResult() != null && CollectionUtils.isNotEmpty(response.getResult().getJoinScenceResultDTOs())){
            bizJoinResultList = response.getResult().getJoinScenceResultDTOs().stream()
                    .filter(JoinScenceResultDTO::getPass)
                    .map(JoinScenceResultDTO::getScenceCode).distinct().collect(Collectors.toList());
        }
        RogerLogger.info("查询广告主业务场景准入结果，memberId={}, result :{}", memberId,JSONObject.toJSONString(bizJoinResultList));
        return bizJoinResultList;
    }

    /**
     * 查询ssp产品线准入结果
     * @param serviceContext
     * @param memberId
     * @param sspCodeList
     * @return
     */
    public List<String> querySspJoinResult(ServiceContext serviceContext, Long memberId, List<String> sspCodeList) {
        JoinSspDTO joinSspDTO = assembleSspJoinDTO(memberId, sspCodeList);
        SingleResponse<JoinSspResultDTO> response = accessControlQueryService.querySspJoinInfo(serviceContext, joinSspDTO);
        if(!response.isSuccess()){
            AssertUtil.assertTrue(response.isSuccess(),String.format("查询广告主（%s）ssp产品线准入结果异常",joinSspDTO.getMemberId()));
        }
        JoinSspResultDTO joinSspResultDTO = response.getResult();
        if (joinSspResultDTO == null || !Objects.equals(joinSspResultDTO.getPass(), Boolean.TRUE)) {
            RogerLogger.info("查询广告主（%s）ssp产品线未准入，memberId={}, result :{}", memberId,JSONObject.toJSONString(joinSspResultDTO));
            return Lists.newArrayList();
        }
        List<String> joinSspProductResultList = joinSspResultDTO.getSspProductResultDTOMap().entrySet().stream()
                .map(entry -> entry.getValue().getPass() ? entry.getKey() : null)
                .filter(Objects::nonNull).distinct().collect(Collectors.toList());
        RogerLogger.info("查询广告主ssp产品线准入结果，memberId={}, result :{}", memberId,JSONObject.toJSONString(joinSspProductResultList));

        return joinSspProductResultList;
    }

    /**
     * 查询memberid的类型
     *
     * @param memberId
     * @return
     * @see com.taobao.ad.simba.user.consts.RelMemberType
     */
    public Integer queryRelMemberType(Long memberId) {
        Result<Integer> result = SimbaUic._member.queryRelMemberType(memberId);
        if (result.isSuccess()) {
            return result.getModule();
        }
        RogerLogger.error("queryRelMemberType error, memberId={}, result={}", memberId, JSON.toJSONString(result));
        throw new RuntimeException("查询memberid的类型失败");
    }

    /**
     * 查询叉乘账号memberid关联的商家账号memberid（被代理）
     *
     * @param memberId
     * @return
     * @see com.taobao.ad.simba.user.consts.RelMemberType#AGENCY
     */
    public Long queryAgencyTargetMemberId(Long memberId) {
        Result<Long> result = SimbaUic._member.queryAgencyTargetMemberId(memberId);
        if (result.isSuccess()) {
            return result.getModule();
        }
        RogerLogger.error("queryAgencyTargetMemberId error, memberId={}, result={}", memberId, JSON.toJSONString(result));
        throw new RuntimeException("查询xmemberid对应的商家账号memberid失败");
    }

    /**
     * 查询叉乘账号memberid关联的商家账号memberid（被代理）
     *
     * @param memberId
     * @return
     * @see com.taobao.ad.simba.user.consts.RelMemberType#SEM_PROXY
     */
    public Long querySemTargetMemberId(Long memberId) {
        Result<Long> result = SimbaUic._member.querySemTargetMemberId(memberId);
        if (result.isSuccess()) {
            return result.getModule();
        }
        RogerLogger.error("querySemTargetMemberId error, memberId={}, result={}", memberId, JSON.toJSONString(result));
        throw new RuntimeException("查询xmemberid对应的商家账号memberid失败");
    }

    /**
     * 查询叉乘账号的目标账号
     * 如果非叉乘账号，将返回null
     * @param memberId
     * @return 目标账号（商家端）
     */
    public Long queryTargetMemberOfRelMember(Long memberId) {
        Result<Long> result = SimbaUic._member.queryTargetMemberOfRelMember(memberId);
        if (result.isSuccess()) {
            return result.getModule();
        }
        RogerLogger.error("queryTargetMemberOfRelMember error, memberId={}, result={}", memberId, JSON.toJSONString(result));
        throw new BrandOneBPException("查询xmemberid对应的真实账号memberid失败");
    }

    /**
     * 是否代理商叉乘用户
     *
     * @param memberId
     * @return
     */
    public Boolean isAgencyX(Long memberId) {
        Result<Boolean> result = memberService.isAgencyX(memberId);
        RogerLogger.info("判断是否代理商叉乘用户 result :{}",  JSONObject.toJSONString(result));
        if (!result.isSuccess()) {
            RogerLogger.info("判断是否代理商叉乘用户异常 memberId :{}", memberId);
            return false;
        }
        return result.getModule();
    }

    public Long queryAgencyMemberId(Long memberId) {
        Result<Long> result = memberService.queryAgencyMemberId(memberId);
        RogerLogger.info("查询代理商叉乘用户的代理用户  {}",  JSONObject.toJSONString(result));
        if (!result.isSuccess()) {
            RogerLogger.info("查询代理商叉乘用户的代理用户异常 memberId :{}", memberId);
            return null;
        }
        return result.getModule();
    }

    private JoinUserDTO assembleJoinUserDTO(Long memberId, List<String> supportScenceCodeList) {
        JoinUserDTO joinUserDTO = new JoinUserDTO();
        joinUserDTO.setBizCode(BizCodeEnum.BRANDONEBP.getBizCode());
        joinUserDTO.setTbNumId(getTbNumIdByMemberId(memberId));

        List<JoinScenceDTO> joinScenceDTOList = supportScenceCodeList.stream().map(bizCode -> {
            JoinScenceDTO joinScenceDTO = new JoinScenceDTO();
            joinScenceDTO.setScenceCode(bizCode);
            joinScenceDTO.setScenceLevel(JoinScenceDTO.SCENCE_LEVEL_ONE);
            return joinScenceDTO;
        }).collect(Collectors.toList());
        joinUserDTO.setJoinScenceDTOS(joinScenceDTOList);
        return joinUserDTO;
    }

    private JoinSspDTO assembleSspJoinDTO(Long memberId, List<String> sspCodeList) {
        JoinSspDTO joinSspDTO = new JoinSspDTO();
        joinSspDTO.setBizCode(BizCodeEnum.BRANDONEBP.getBizCode());
        joinSspDTO.setTbNumId(getTbNumIdByMemberId(memberId));
        joinSspDTO.setSspCodes(sspCodeList);
        return joinSspDTO;
    }
}
