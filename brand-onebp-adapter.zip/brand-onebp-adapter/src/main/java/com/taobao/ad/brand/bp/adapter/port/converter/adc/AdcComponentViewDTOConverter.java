package com.taobao.ad.brand.bp.adapter.port.converter.adc;

import com.alibaba.ad.nb.framework.adc.dto.AdcComponentDTO;
import com.taobao.ad.brand.bp.adapter.port.converter.adc.mapstruct.AdcComponentViewDTOMapStruct;
import com.taobao.ad.brand.bp.client.dto.adc.AdcComponentViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import com.taobao.ad.brand.bp.common.converter.base.BaseViewDTOConverter;
import org.springframework.stereotype.Component;

/**
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@Component
public class AdcComponentViewDTOConverter extends BaseViewDTOConverter<AdcComponentDTO, AdcComponentViewDTO> {


    @Override
    public BaseMapStructMapper<AdcComponentDTO, AdcComponentViewDTO> getBaseMapStructMapper() {
        return AdcComponentViewDTOMapStruct.INSTANCE;
    }
}
