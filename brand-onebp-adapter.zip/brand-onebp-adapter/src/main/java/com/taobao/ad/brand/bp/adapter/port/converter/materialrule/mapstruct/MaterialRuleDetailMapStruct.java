package com.taobao.ad.brand.bp.adapter.port.converter.materialrule.mapstruct;

import com.alibaba.ad.nb.ssp.dto.material.MaterialRuleDetailDTO;
import com.taobao.ad.brand.bp.client.dto.mr.MaterialRuleDetailViewDTO;
import com.taobao.ad.brand.bp.common.converter.base.BaseMapStructMapper;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author jixiu.lj
 * @date 2023/3/21 11:55
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface MaterialRuleDetailMapStruct extends BaseMapStructMapper<MaterialRuleDetailDTO, MaterialRuleDetailViewDTO> {
    MaterialRuleDetailMapStruct INSTANCE = Mappers.getMapper(MaterialRuleDetailMapStruct.class);
}
