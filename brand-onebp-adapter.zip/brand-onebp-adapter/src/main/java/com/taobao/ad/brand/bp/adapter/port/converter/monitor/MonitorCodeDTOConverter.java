package com.taobao.ad.brand.bp.adapter.port.converter.monitor;

import com.alibaba.ad.nb.basic.client.dto.monitor.BizMonitorCodeDTO;
import com.taobao.ad.brand.bp.client.dto.adgroup.AdgroupMonitorCodeViewDTO;
import org.springframework.stereotype.Component;

/**
 * @author 弈云
 * @date 2023/3/8
 **/
@Component
public class MonitorCodeDTOConverter /*extends BaseViewDTOConverter<BizMonitorCodeDTO, AdgroupMonitorCodeViewDTO>*/ {

//    @Override
//    public BaseMapStructMapper<BizMonitorCodeDTO, AdgroupMonitorCodeViewDTO> getBaseMapStructMapper() {
//        return MonitorCodeDTOMapStruct.INSTANCE;;
//    }

    public AdgroupMonitorCodeViewDTO convertDTO2ViewDTO(BizMonitorCodeDTO source) {
        if(source == null){
            return null;
        }
        AdgroupMonitorCodeViewDTO adgroupMonitorCodeViewDTO = new AdgroupMonitorCodeViewDTO();
        adgroupMonitorCodeViewDTO.setPvMonitorUrl(source.getPvMonitor());
        adgroupMonitorCodeViewDTO.setClickMonitorUrl(source.getClickMonitor());
        adgroupMonitorCodeViewDTO.setDeepLinkUrl(source.getDeepLinkUrl());
        adgroupMonitorCodeViewDTO.setUlkUrl(source.getUlkUrl());
        adgroupMonitorCodeViewDTO.setLandingUrl(source.getLandingUrl());
        adgroupMonitorCodeViewDTO.setClickUrl( source.getClickUrl() );

        return adgroupMonitorCodeViewDTO;
    }

    public BizMonitorCodeDTO targetToSource(AdgroupMonitorCodeViewDTO target) {
        if (target == null ) {
            return null;
        }
        BizMonitorCodeDTO bizMonitorCodeDTO = new BizMonitorCodeDTO();
        bizMonitorCodeDTO.setPvMonitor(target.getPvMonitorUrl());
        bizMonitorCodeDTO.setClickMonitor(target.getClickMonitorUrl());
        bizMonitorCodeDTO.setLandingUrl( target.getLandingUrl() );
        bizMonitorCodeDTO.setClickUrl( target.getClickUrl() );
        bizMonitorCodeDTO.setDeepLinkUrl( target.getDeepLinkUrl() );
        bizMonitorCodeDTO.setUlkUrl( target.getUlkUrl() );
        return bizMonitorCodeDTO;
    }
}
