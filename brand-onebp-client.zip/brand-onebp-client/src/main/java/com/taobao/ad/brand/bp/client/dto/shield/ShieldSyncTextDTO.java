package com.taobao.ad.brand.bp.client.dto.shield;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * 风控文本信息
 * @author gxg
 * @date 2023/10/16
 */
@Data
public class ShieldSyncTextDTO extends BaseViewDTO {


    /**
     * 文本内容，长度小于512
     */
    private String text;

    /**
     * 1:通过，2：拒绝，3：进审核，参见ActionCodeDTO
     */
    private Integer actionCode;

    /**
     * 拒绝原因
     */
    private String auditReason;
}
