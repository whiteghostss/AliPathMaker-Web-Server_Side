package com.taobao.ad.brand.bp.client.dto.report;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 报表基础对象
 * @author yuncheng.lyc
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReportBasicViewDTO extends BaseViewDTO {
    /**
     * id
     */
    private String id;
    /**
     * 维度名称
     */
    private String name;

}
