package com.taobao.ad.brand.bp.client.api.motion;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.CommandAPI;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.motion.IntelligentMotionViewDTO;

import java.util.List;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/18
 **/
public interface BizIntelligentMotionCommandService extends CommandAPI {

    String TAG = "IntelligentMotion";

    /**
     * 新建/编辑智能提案
     * @param serviceContext
     * @param intelligentMotionViewDTO
     * @return
     */
    @ProcessEntrance(name = "新建/编辑智能提案", desc = "新建/编辑智能提案", opType = OpType.add, tag = TAG)
    SingleResponse<Long> saveIntelligentMotion(ServiceContext serviceContext, IntelligentMotionViewDTO intelligentMotionViewDTO);

    /**
     * 新建/编辑智能提案
     * @param serviceContext
     * @param intelligentMotionViewDTO
     * @return
     */
    @ProcessEntrance(name = "提交智能提案计算", desc = "提交智能提案计算", opType = OpType.other, tag = TAG)
    SingleResponse<Long> submitIntelligentMotion(ServiceContext serviceContext, IntelligentMotionViewDTO intelligentMotionViewDTO);

    /**
     * 新建/编辑智能提案
     * @param serviceContext
     * @param idList
     * @return
     */
    @ProcessEntrance(name = "删除智能提案", desc = "删除智能提案", opType = OpType.add, tag = TAG)
    Response deleteIntelligentMotion(ServiceContext serviceContext, List<Long> idList);

    /**
     *
     * @param serviceContext
     * @param idList
     * @param status
     * @return
     */
    @ProcessEntrance(name = "更新提案状态", desc = "更新提案状态", opType = OpType.update, tag = TAG)
    Response updateIntelligentMotionListStatus(ServiceContext serviceContext, List<Long> idList, Integer status);

}
