package com.taobao.ad.brand.bp.client.dto.base;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;

import lombok.Data;

/**
 * 文件项
 * @author ximu
 * @date 2023/8/23
 */
@Data
public class FileItemViewDTO extends BaseViewDTO {
    /**
     * 原始文件名称
     */
    private String name;
    /**
     * 请求的文件内容(二进制)
     */
    private byte[] data;
    /**
     * 请求的文件内容(base64编码)
     */
    private String base64Data;
    /**
     * 请求的文件内容来源(临时oss地址)
     */
    private String tmpOssUrl;
    /**
     * 文件ID
     */
    private String uid;

    /**
     * false - 返回带有访问有效期的临时链接URL
     * true - 返回可访问的永久链接URL
     */
    private Boolean needPermanentUrl = false;

    /**
     * 配置的链接有效期
     *
     * @see #needPermanentUrl 当needPermanentUrl为false不需要关心，否则可以选择设置链接URL的有效时长
     */
    private Long expireTime;

    /**
     * 返回的文件cdn地址
     */
    private String url;
}
