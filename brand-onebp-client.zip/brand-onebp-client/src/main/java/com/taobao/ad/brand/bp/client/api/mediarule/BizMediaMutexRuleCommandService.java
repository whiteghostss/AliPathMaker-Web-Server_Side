package com.taobao.ad.brand.bp.client.api.mediarule;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.ad.brand.dto.media.mutex.MediaMutexRuleViewDTO;
import com.alibaba.hermes.framework.api.CommandAPI;
import com.alibaba.hermes.framework.dto.response.SingleResponse;

import java.util.List;

/**
 * 互斥规则操作服务类
 *
 * @author denglinhua
 * @date 2023-07-11
 */
public interface BizMediaMutexRuleCommandService extends CommandAPI {

    String TAG = "MediaMutexRule";

    @ProcessEntrance(name = "新增", desc = "新增", opType = OpType.add, tag = TAG)
    SingleResponse<Long> addMutexRule(ServiceContext context, MediaMutexRuleViewDTO viewDTO);

    @ProcessEntrance(name = "编辑", desc = "编辑", opType = OpType.update, tag = TAG)
    SingleResponse<Integer> updateMutexRule(ServiceContext serviceContext, MediaMutexRuleViewDTO viewDTO);

    @ProcessEntrance(name = "频控状态修改", desc = "互斥规则状态修改", opType = OpType.update, tag = TAG)
    SingleResponse<Integer> updateMutexRuleStatus(ServiceContext serviceContext, List<Long> ids, Integer status);


}
