package com.taobao.ad.brand.bp.client.dto.solution;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

@Data
public class CartItemSolutionOrderViewDTO extends BaseViewDTO {
    /**
     * 加购行id
     */
    private Long id;

    /**
     * 签约的排期表
     */
    private String signScheduleUrl;
    /**
     * 联系电话
     */
    private String contactPhone;
}
