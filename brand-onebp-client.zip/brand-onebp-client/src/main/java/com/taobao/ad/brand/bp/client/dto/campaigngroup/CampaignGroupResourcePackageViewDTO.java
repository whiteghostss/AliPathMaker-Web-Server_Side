package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.common.SchemaConfigViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupWakeupTypeEnum;

import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/03/02
 */
@Data
public class CampaignGroupResourcePackageViewDTO extends BaseViewDTO {
    /**
     * 订单ID
     */
    private Long id;
    /**
     * 订单名称
     */
    private String name;
    /**
     * 开始时间
     */
    private Date startTime;
    /**
     * 结束时间
     */
    private Date endTime;
    /**
     * 预算，单位分
     */
    private Long budget;
    /**
     * 订单状态
     */
    private Integer status;
    /**
     * 客户模版ID
     */
    private Long customerTemplateId;
    /**
     * 资源包售卖分组
     */
    private List<CampaignGroupSaleGroupPageViewDTO> saleGroupList;

    /**
     * 创建时间
     */
    private Date gmtCreate;
    /**
     * 修改时间
     */
    private Date gmtModified;
    /**
     * 唤端类型
     * @see BrandCampaignGroupWakeupTypeEnum
     */
    private Integer wakeupType;
//    /**
//     * 唤端appID
//     */
//    private List<Long> schemaIdList;

    /**
     * schema配置List
     * */
    private List<SchemaConfigViewDTO> schemaConfigList;
    /**
     * 客户memberId
     * */
    private Long memberId;
    /**
     * 合同客户信息
     * */
    private Long customerId;
    /**
     * 合同客户memberID
     */
    private Long cusMemberId;
    /**
     * 合同客户member名称
     */
    private String cusMemberName;

    /**
     * 已更新的售卖分组类型
     * @see BrandSaleTypeEnum
     * */
    private List<Integer> hasUpdateSaleGroupTypeList;
}
