package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquirySchedulePolicyViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignInquiryAssignTypeEnum;
import lombok.Data;

import java.util.List;

/**
 * 计划预定量周期策略
 * @author 石炎
 * @date 2023/08/30
 */
@Data
public class CampaignSchedulePolicyViewDTO extends BaseViewDTO {
    /**
     * 计划id列表
     */
    private List<Long> campaignIdList;
    /**
     * 区间分配策略
     * 1：分天 （BY_DAY）
     * 2：智能 （INTELLIGENCE）
     * 3：周期 （PERIOD）
     *
     * @see BrandCampaignInquiryAssignTypeEnum
     */
    private Integer inquiryAssignType;
    /**
     * 计划询量周期分配策略
     * inquiryAssignType = 3（周期）必填
     */
    private List<CampaignInquirySchedulePolicyViewDTO> schedulePolicyList;
}
