package com.taobao.ad.brand.bp.client.enums.message;

import com.taobao.ad.brand.bp.client.enums.CommonEnum;

public enum MessageSendTypeEnum implements CommonEnum {
    STATION_LETTER(1, "站内信"),
    EMAIL(2, "邮件"),
    DING_DING(3, "钉钉"),
    DING_GROUP(4, "钉群"),
    ;

    private final int value;
    private final String desc;

    MessageSendTypeEnum(int value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public static MessageSendTypeEnum getByValue(Integer value) {
        if (value == null) {
            return null;
        }

        MessageSendTypeEnum[] statusArray = MessageSendTypeEnum.values();
        for (MessageSendTypeEnum status : statusArray) {
            if (status.getValue() == value.intValue()) {
                return status;
            }
        }
        return null;
    }

    @Override
    public int getValue() {
        return value;
    }

    public byte getByteValue() {
        return (byte)value;
    }

    @Override
    public String getDesc() {
        return desc;
    }
}
