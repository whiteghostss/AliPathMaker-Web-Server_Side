package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * @author jixiu.lj
 * @date 2023/7/25 17:19
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class CampaignTargetCategoryPageViewDTO extends BaseViewDTO {

    /**
     * 二级类目id
     */
    private Long catId;

    /**
     * 二级类目名称
     */
    private String name;
    /**
     * 投中类目
     * @see com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCategorySceneEnum
     */
    private Integer scene;

    /**
     * 一级类目id
     */
    private Long mainCatId;

    /**
     * 一级类目名称
     */
    private String mainCatName;

    /**
     * 推荐理由
     */
    private String recommendReason;

    /**
     * 推荐标签
     * */
    private List<String> rcmdTagList;

    /**
     * 映射到分数 取值1-10
     * */
    private Integer ctr;

    /**
     * 映射到分数
     * */
    private Integer cvr;

    /**
     * 相关性数值评级 取值1~10
     */
    private Integer relevance;

    /**
     * 日均pv
     */
    private Long dayPerPv;

}
