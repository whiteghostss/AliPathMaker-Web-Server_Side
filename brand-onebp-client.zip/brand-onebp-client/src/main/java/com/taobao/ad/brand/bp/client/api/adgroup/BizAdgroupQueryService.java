package com.taobao.ad.brand.bp.client.api.adgroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.adgroup.AdgroupWarnViewDTO;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupExportMonitorQueryDTO;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryOption;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportTaskViewDTO;

import java.util.List;

public interface BizAdgroupQueryService extends QueryAPI {
    String TAG = "Adgroup";

    /**
     *
     * @param context
     * @param query
     * @return
     */
    @ProcessEntrance(name = "分页查询", desc = "分页查询", opType = OpType.query, tag = TAG)
    MultiResponse<AdgroupViewDTO> findAdgroupPage(ServiceContext context, AdgroupQueryViewDTO query, AdgroupQueryOption adgroupQueryOption);

    /**
     *
     * @param context
     * @param adgroupIds
     * @return
     */
    @ProcessEntrance(name = "分页查询", desc = "分页查询", opType = OpType.query, tag = TAG)
    MultiResponse<AdgroupWarnViewDTO> getCrossOpaqueSceneAdgroupWarn(ServiceContext context, List<Long> adgroupIds);


    /**
     *
     * @param context
     * @param query
     * @return
     */
    @ProcessEntrance(name = "不分页查询adgroupList", desc = "不分页查询", opType = OpType.query, tag = TAG)
    MultiResponse<AdgroupViewDTO> findAdgroupListNoPage(ServiceContext context, AdgroupQueryViewDTO query, AdgroupQueryOption adgroupQueryOption);

    /**
     * 获取单元详情
     *
     * @param context
     * @param adgroupId
     * @return
     */
    @ProcessEntrance(name = "获取单元", desc = "单元获取", opType = OpType.query, tag = TAG)
    SingleResponse<AdgroupViewDTO> getAdgroupById(ServiceContext context, Long adgroupId, AdgroupQueryOption adgroupQueryOption);
    /**
     * 根据名称查询单元
     * @param context
     * @param title
     * @param  excluAdgroupId 不包含的adgroupId
     * @param adgroupQueryOption
     * @return
     */
    @ProcessEntrance(name = "根据名称查询", desc = "不分页，取top one", opType = OpType.query, tag = TAG)
    SingleResponse<AdgroupViewDTO> queryAdgroupByName(ServiceContext context, String title,Long excluAdgroupId, AdgroupQueryOption adgroupQueryOption);
    /**
     * 下载单元监测
     * @param context
     * @param adgroupId
     * @return
     */
    @ProcessEntrance(name = "下载单元监测", desc = "下载单元监测", opType = OpType.query, tag = TAG)
    SingleResponse<String> exportMonitor(ServiceContext context, Long adgroupId);

    /**
     * 下载订单监测（for供应商平台）
     * @param context
     * @param queryDTO
     * @return
     */
    @ProcessEntrance(name = "下载订单监测", desc = "下载订单监测", opType = OpType.query, tag = TAG)
    SingleResponse<String> exportOrderMonitor(ServiceContext context, AdgroupExportMonitorQueryDTO queryDTO);

    /**
     * 查询订单x分组下的批量计划导入记录
     * @param context
     * @param query
     * @return
     */
    @ProcessEntrance(name = "查询订单下的单元批量导入监测记录", desc = "查询订单下的单元批量导入监测记录", opType = OpType.query, tag = TAG)
    MultiResponse<ReportTaskViewDTO> findAdgroupBatchImportTaskList(ServiceContext context, AdgroupQueryViewDTO query);
}
