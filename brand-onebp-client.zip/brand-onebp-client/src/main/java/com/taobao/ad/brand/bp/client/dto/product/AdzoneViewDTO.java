package com.taobao.ad.brand.bp.client.dto.product;

import lombok.Data;

import java.util.List;

/**
 * @description: AdzoneViewDTO
 * @date: 2023/3/2 16:00
 * @author: yuanxinxi
 * @version: 1.0
 */
@Data
public class AdzoneViewDTO {
    private Long memberId;
    private Long siteId;
    private Long adzoneId;
    private String adzoneName;
    private List<Long> sspTemplateIds;
    /**
     * 三段式PID，格式为：mm_{memberId}_{siteId}_{adzoneId}
     */
    private String pid;

    /**
     * 终端/设备类型，例如：0 - Pad、1 - Phone、2 - OTT、3 - PC、4 - OOH、......
     */
    private Integer terminal;
    /**
     * 系统类型，例如：0 - iOS、1 - Android、5 - 不限、......
     */
    private Integer os;

    private String osName;

    private Integer mediaScope;

    /**
     * 资源类型
     */
    private Integer resourceType;

    private String resourceTypeName;

    /**
     * 最大预定量(CPT)
     */
    private Integer maxReserveAmount;

    private String talentUserId;

}
