package com.taobao.ad.brand.bp.client.enums.dooh;

import lombok.Getter;

@Getter
public enum DoohStrategyPointTypeEnum {

    ADD(1, "指定点位", 1),
    REMOVE(2, "屏蔽点位", 2),
    ;

    private Integer code;

    private String desc;

    private Integer doohCode;

    DoohStrategyPointTypeEnum(Integer code, String desc, Integer doohCode){
        this.code = code;
        this.desc = desc;
        this.doohCode = doohCode;
    }

    public static DoohStrategyPointTypeEnum getStrategyPointOpTypeByDooh(Integer doohCode){
        if(doohCode == null){
            return null;
        }
        for(DoohStrategyPointTypeEnum pointOpTypeEnum : DoohStrategyPointTypeEnum.values()){
            if(pointOpTypeEnum.getDoohCode().equals(doohCode)){
                return pointOpTypeEnum;
            }
        }
        return null;
    }
}
