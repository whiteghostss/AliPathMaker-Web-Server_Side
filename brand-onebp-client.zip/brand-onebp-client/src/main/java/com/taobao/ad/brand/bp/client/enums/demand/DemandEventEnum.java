package com.taobao.ad.brand.bp.client.enums.demand;

/**
 * 诉求状态流转
 */
public enum DemandEventEnum {
    CREATE(1, "新建"),
    ORDER(2, "下单"),
    ASSIGN_ORDER(3, "派单"),
    SUBMIT_SOLUTION(4, "提交提案"),
    AUDIT_SOLUTION(5, "审核提案"),
    AUDIT_PRICE(6, "价审"),
    SELLER_CONFIRM_SOLUTION(7, "商家确认提案"),
    SELLER_REFUSE_SOLUTION(8, "商家拒绝提案"),
    SUPPLIER_REFUSE_ORDER(9, "供应商全部拒绝接单"),
    STOP_CAST(10, "停投"),
    AUDIT_PRICE_REFUSE(11, "价审拒绝"),

    SUPPLIER_SUPPLY_UPDATE_TALENT(12, "供应商申请更换cpm包内的达人"),

    SELLER_CONFIRM_UPDATE_TALENT(13, "商家确认更换达人"),

    SUPPLIER_CLOSE_ORDER(14, "供应商结束任务"),

    CAMPAIGN_GROUP_DELETE_SALE_GROUP(15, "分组删除(改单场景)"),

    SELLER_UNLOCK(16, "商家改单"),

    ;

    private final Integer value;
    private final String desc;

    DemandEventEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }


    public static DemandEventEnum of(Integer value) {
        DemandEventEnum[] var1 = values();
        int var2 = var1.length;

        for(int var3 = 0; var3 < var2; ++var3) {
            DemandEventEnum eventEnum = var1[var3];
            if (eventEnum.value.equals(value)) {
                return eventEnum;
            }
        }

        return null;
    }


    public Integer getValue() {
        return value;
    }

    public String getDesc() {
        return desc;
    }
}
