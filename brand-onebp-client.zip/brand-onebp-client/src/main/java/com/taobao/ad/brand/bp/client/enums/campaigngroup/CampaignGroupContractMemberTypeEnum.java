package com.taobao.ad.brand.bp.client.enums.campaigngroup;

import lombok.Getter;

/**
 * 订单ContractMember类型
 */
@Getter
public enum CampaignGroupContractMemberTypeEnum {
    CUSTOMER(1,"客户投放账号"),
    XMEMBER(2,"代理叉乘账号"),
    PROXY(3,"代投账号"),
    ;

    private Integer code;
    private String desc;

    CampaignGroupContractMemberTypeEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }
}
