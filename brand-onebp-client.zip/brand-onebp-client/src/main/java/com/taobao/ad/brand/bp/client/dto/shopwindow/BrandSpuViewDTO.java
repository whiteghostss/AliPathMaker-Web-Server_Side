package com.taobao.ad.brand.bp.client.dto.shopwindow;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/6/25
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class BrandSpuViewDTO extends BaseViewDTO {
    /**
     * 主键ID
     */
    private Long id;

    /**
     * spu名称
     */
    private String name;

    /**
     * 是否支持自助下单
     * com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum
     */
    @Deprecated
    private Integer supportAutoApply;

    /**
     * spu类型
     * @see com.taobao.ad.brand.perform.client.enums.shopwindow.SpuTypeEnum
     */
    private Integer type;
    /**
     * 营销场景
     * @see com.taobao.ad.brand.perform.client.enums.shopwindow.MarketSceneTypeEnum
     */
    private Integer marketScene;

    /**
     * 状态
     * com.taobao.ad.brand.perform.client.enums.shopwindow.SpuStatusEnum
     */
    private Integer status;

    /**
     * spu ref列表
     * com.taobao.ad.brand.perform.client.enums.shopwindow.SpuRefTypeEnum
     */
    private List<BrandSpuRefViewDTO> spuRefList;

    /**
     * spu配置信息
     */
    private BrandSpuConfigViewDTO spuConfig;

    /**
     * sku列表
     */
    private List<BrandSkuViewDTO> skuList;
}
