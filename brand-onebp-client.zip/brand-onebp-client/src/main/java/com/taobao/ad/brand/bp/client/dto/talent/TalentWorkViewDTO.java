package com.taobao.ad.brand.bp.client.dto.talent;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

@Data
public class TalentWorkViewDTO extends BaseViewDTO {

    /**
     * 达人ID
     */
    private String talentId;

    /**
     * 妈妈达人唯一标识
     */
    private String userId;

    /**
     * 媒体侧达人唯一标识
     */
    private String mediaUserId;

    /**
     * 作品ID
     */
    private String workId;

    /**
     * 作品渠道
     */
    private String channel;

    /**
     * 作品链接
     */
    private String url;

    /**
     * 作品名称/内容标题
     */
    private String name;

    /**
     * 曝光量7天
     */
    private Long pv7d;

    /**
     * 互动量7天
     */
    private Long interact7d;

    /**
     * 转发数7天
     */
    private Long forward7d;

    /**
     * 评论数7天
     */
    private Long comment7d;

    /**
     * 点赞数7天
     */
    private Long like7d;

    /**
     * 投放成本cpm7天
     */
    private Long costCpm7d;

    /**
     * 投放成本cpe7天
     */
    private Long costCpe7d;

    /**
     * 播放量（7天）
     */
    private Long play7d;

    /**
     * 在看数（7天）
     */
    private Long look7d;

    /**
     * 收藏量
     */
    private Long collect7d;

    /**
     * 投币数
     */
    private Long coin7d;

    /**
     * 阅读量
     */
    private Long read7d;

    /**
     * 作品类型：0-个人;1-商业
     */
    private Integer workType;
}
