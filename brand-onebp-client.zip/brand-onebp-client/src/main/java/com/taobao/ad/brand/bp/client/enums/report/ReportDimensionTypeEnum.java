package com.taobao.ad.brand.bp.client.enums.report;

/**
 * 报表维度类型
 * @author yuncheng.lyc
 * @date 2023/3/7
 **/
public enum ReportDimensionTypeEnum {
    ACTUAL_DIMENSION("actual", "具体维度"),
    VIRTUAL_DIMENSION("virtual", "占位维度");

    private final String name;
    private final String desc;

    ReportDimensionTypeEnum(String name, String desc) {
        this.name = name;
        this.desc = desc;
    }

    public String getName() {
        return name;
    }

    public String getDesc() {
        return desc;
    }

    public static ReportDimensionTypeEnum getByName(String name) {
        if (name == null) {
            return null;
        }

        ReportDimensionTypeEnum[] typeEnums = ReportDimensionTypeEnum.values();
        for (ReportDimensionTypeEnum typeEnum : typeEnums) {
            if (name.equals(typeEnum.getName())){
                return typeEnum;
            }
        }
        return null;
    }
}
