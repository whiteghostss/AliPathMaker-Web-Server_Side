package com.taobao.ad.brand.bp.client.dto.product;

import com.alibaba.ad.brand.dto.campaign.adzone.CampaignAdzoneViewDTO;
import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import lombok.Data;

import java.util.List;

/**
 * @description: ProductViewDTO
 * @date: 2023/3/2 15:55
 * @author: yuanxinxi
 * @version: 1.0
 */
@Data
public class ProductViewDTO extends BaseViewDTO {
    /**
     * 产品ID
     */
    private Long id;
    /**
     * 产品uuid
     */
    private Long uuid;
    /**
     * 产品状态：0-无效，1-有效
     *
     */
    private Integer status;
    /**
     * 是否原生产品：0-衍生产品，1-原生产品
     *
     */
    private Integer original;

    /**
     * 一级产品ID
     */
    private Long parentId;
    /**
     * 二级产品名称
     */
    private String name;
    /**
     * 流量域
     */
    private Integer mediaScope;
    /**
     * 跨域场景
     */
    private Integer crossScene;
    /**
     * 产品线 ssp产品线
     */
    private Integer productLineId;
    /**
     * 使用BP
     */
    private List<Integer> usedSystemList;
    /**
     * 刊例标签
     */
    private Long label;
    /**
     * 资源类型
     */
    private List<Integer> resourceTypeList;
    /**
     * 媒体名称对应的ID值（对客）
     */
    private Long customerOrientedMediaId;
    /**
     * 资源位名称（对客）
     */
    private String customerOrientedResourceName;
    /**
     * 广告位AdzoneID
     */
    private List<Long> adzoneIdList;
    /**
     * 资源位ID
     */
    private List<Long> resourceIdList;

    /**
     * 计费单位
     */
    private Integer sellUnit;
    /**
     * 预定方式
     */
    private List<Integer> registerMannerTypeList;
    /**
     * 控量方式
     */
    private Integer trafficControlType;
    /**
     * 是否承诺曝光
     *
     */
    private Integer promiseExposure;
    /**
     * 是否承诺点击
     *
     */
    private Integer promiseClick;
    /**
     * 单位CPM数量
     */
    private Integer unitExposure;
    /**
     * 单位点击量
     */
    private Integer unitClick;
    /**
     * 单位点击率
     */
    private Integer clickRate;
    /**
     * 产品定向
     */
    private List<ProductDirectionViewDTO> directionList;
    /**
     * 第三方监测类型
     */
    private List<Integer> nonAliInspectTypeList;

    /**
     * 数据回流方式
     */
    private Integer dataChannel;
    /**
     * 模板ID
     */
    private List<Long> templateIdList;

    /**
     * 模板名称
     */
    private List<CommonViewDTO> templateNameList;

    /**
     * 是否系统投放：0-否，1-是
     */
    private Integer programmatic;

    /**
     * 预定单位
     */
    private Integer registerUnit;
    /**
     * 是否联合媒体
     */
    private Integer unionMedia;
    /**
     * 是否投中扩量
     */
    private Integer castExpansionOpen;
    /**
     * 是否广告位联动
     */
    private Integer needPositionLinkage;
    /**
     * 是否全域联投
     */
    private Integer needJoint;
    /**
     * 是否支持分目标优化
     */
    private Integer targetOptimize;
    /**
     * 优化目标
     */
    private List<Integer> optimizeTargetList;

    /**
     * 优化目标
     *
     * @see #optimizeTargetList
     */
    private List<CommonViewDTO> optimizeTargetNameList;

    /**
     * 计费触发
     */
    private Integer chargeTrigger;
    /**
     * 广告跳过设置
     */
    private Integer skipSet;
    /**
     * 产品优先级
     */
    private Integer priority;

    /**
     * 当是跨域二级产品，这个字段一定会返回
     */
    private List<ProductViewDTO> associationProductList;


    /**
     * @see #adzoneIdList
     */
    private List<CampaignAdzoneViewDTO> adzoneList;

    /**
     * 如果不是跨域产品，返回 {@link #templateIdList}
     * 如果是跨域产品，返回全部子产品下的模板 {@link #associationProductList} {@link #templateIdList} 集合
     */
    public List<CommonViewDTO> templateSummary;



    /**
     * @see #mediaScopeName
     */
    private String mediaScopeName;
    /**
     * @see #productLineId
     */
    private String productLineName;

    /**
     * @see #usedSystemList
     */
    private List<CommonViewDTO> usedSystemNameList;
    /**
     * @see #resourceTypeList
     */
    private List<CommonViewDTO> resourceTypeNameList;
    /**
     * @see #customerOrientedMediaId
     */
    private String customerOrientedMediaName;
    /**
     * @see #sellUnit
     */
    private String sellUnitName;
    /**
     * @see #registerMannerTypeList
     */
    private List<CommonViewDTO> registerMannerTypeNameList;
    /**
     * @see #trafficControlType
     */
    private String trafficControlTypeName;

    /**
     * @see #dataChannel
     */
    private String dataChannelName;
    /**
     * @see #registerUnit
     */
    private String registerUnitName;
    /**
     * @see #chargeTrigger
     */
    private String chargeTriggerName;
    /**
     * @see #skipSet
     */
    private String skipSetName;

    // 下面这些字段：需要指定查询条件的 needXXX 才会返回

    /**
     * @see #parentId
     */
    private String parentName;
    /**
     * @see #label
     */
    private String labelName;

    /**
     * 主广告位id
     */
    private Long mainAdzoneId;

    /**
     * 智能预留
     */
    private Integer smartreserved;

    /**
     * 到达
     * */
    private Long arriveRate;

    private Long amountDiscount;

    /**
     * 竞争排名
     */
    private List<Integer> competExcludeList;

    private List<CommonViewDTO> competExcludeNameList;

}
