package com.taobao.ad.brand.bp.client.dto.mr.videorule;

import com.taobao.ad.brand.bp.client.dto.mr.FileSizeViewDTO;
import com.taobao.ad.brand.bp.client.dto.mr.FileStoreLimitViewDTO;
import com.taobao.ad.brand.bp.client.dto.mr.ItemContentViewDTO;
import lombok.Data;

import java.util.List;

/**
 * @author jixiu.lj
 * @date 2023/3/21 11:45
 */
@Data
public class VideoRuleViewDTO extends ItemContentViewDTO {
    private List<FileSizeViewDTO> fileSize;
    private FileStoreLimitViewDTO fileStoreLimit;
    private VideoTimeViewDTO videoTime;
    private VideoRateViewDTO videoRate;
    private Integer videoVoice;
    private Integer videoPlay;
}
