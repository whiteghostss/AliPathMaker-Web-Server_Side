package com.taobao.ad.brand.bp.client.enums.campaigngroup;

import com.taobao.ad.brand.bp.client.enums.CommonEnum;

/**
 * shema的Enum
 * */
public enum SchemaEnum implements CommonEnum {
    TAOBAO(1, "淘宝",3,0),
    ALIPAY(10, "支付宝",3,0),
    TRIP(7, "飞猪", 3, 0),
    GOOFISH(3, "闲鱼", 3, 0),
    WEIXIN_XIAOCHENGXU(58, "微信小程序",7,1);
    ;

    SchemaEnum(int value, String desc,int openType,int hostApp) {
        this.value = value;
        this.desc = desc;
        this.openType = openType;
        this.hostApp = hostApp;
    }

    private int value;
    private String desc;
    private int openType;
    private int hostApp;

    @Override
    public int getValue() {
        return value;
    }

    @Override
    public String getDesc() {
        return desc;
    }

    public int getOpenType() {
        return openType;
    }

    public void setOpenType(int openType) {
        this.openType = openType;
    }

    public int getHostApp() {
        return hostApp;
    }

    public void setHostApp(int hostApp) {
        this.hostApp = hostApp;
    }

    public static SchemaEnum getByValue(Integer value) {
        if (value == null) {
            return null;
        }
        for (SchemaEnum schemaEnum : SchemaEnum.values()) {
            if (schemaEnum.getValue() == value) {
                return schemaEnum;
            }
        }
        return null;
    }

}
