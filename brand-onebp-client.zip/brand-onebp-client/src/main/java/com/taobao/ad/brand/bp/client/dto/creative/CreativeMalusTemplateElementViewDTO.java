package com.taobao.ad.brand.bp.client.dto.creative;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/3/16 13:10
 * @description ：
 * @modified By：
 */
@Data
public class CreativeMalusTemplateElementViewDTO extends BaseViewDTO {
    private String key;
    private String url;
    private String value;
    private String width;
    private String height;
    private String duration;
    private Long fileSize;
    private Long bitrate;
    /**
     * 剧本库的模板id
     */
    private String popTemplateId;
    /**
     * 剧本库的模板名称
     */
    private String popTemplateName;
}
