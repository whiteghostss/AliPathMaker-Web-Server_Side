package com.taobao.ad.brand.bp.client.dto.motion;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/16
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class InsightDataViewDTO extends BaseViewDTO {

    /**
     * 媒体量级
     */
    private Long siteAmount;

    /**
     * TA媒体覆盖
     */
    private Long taMediaCoverage;

    /**
     * TA媒体浓度
     */
    private Long taMediaConcentration;

    /**
     * 资源产品量级
     */
    private Long resourceProductAmount;

    /**
     * TA资源产品覆盖
     */
    private Long taResourceProductCoverage;

    /**
     * TA资源产品浓度
     */
    private Long taResourceProductConcentration;

    /**
     * CPM单价
     */
    private Long cpmPrice;

    /**
     * 点击率
     */
    private Long clkMonitorRate;

    /**
     * 到达率
     */
    private Long landPvRate;

    /**
     * 回搜回访率
     */
    private Long searchAndVisitRate;

    /**
     * 收藏加购率
     */
    private Long collectAddPurchaseRate;

    /**
     * 成交率
     */
    private Long dealRate;
}
