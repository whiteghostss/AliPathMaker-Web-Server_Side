package com.taobao.ad.brand.bp.client.dto.base;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.Date;

/**
 * @author jixiu.lj
 * @date 2023/10/16 10:28
 */
@Data
public class TimeSpanViewDTO extends BaseViewDTO {
    /**
     * 开始时间
     */
    private Date startTime;

    /**
     * 结束时间
     */
    private Date endTime;
}
