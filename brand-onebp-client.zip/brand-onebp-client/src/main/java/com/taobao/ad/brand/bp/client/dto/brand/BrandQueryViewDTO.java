package com.taobao.ad.brand.bp.client.dto.brand;

import com.taobao.ad.brand.bp.client.dto.base.BaseQueryViewDTO;
import lombok.Data;

/**
 * @author yanjingang
 * @date 2025/5/12
 */
@Data
public class BrandQueryViewDTO extends BaseQueryViewDTO {

    private String keyword;
}
