package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import lombok.Data;

import java.util.List;

/**
 * 计划自动释量预警信息，按照订单维度预警
 */
@Data
public class CampaignInventoryAutoReleaseMsgViewDTO {

    /**
     * 计划信息
     */
    private List<CampaignViewDTO> campaignViewDTOList;

    /**
     * 订单信息
     */
    private CampaignGroupViewDTO campaignGroupViewDTO;


    /**
     * 预警类型
     */
    private Integer warningType;

    /**
     * 排期链接
     */
    private String cdnUrl;
}
