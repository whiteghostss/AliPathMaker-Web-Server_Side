package com.taobao.ad.brand.bp.client.api.strategy;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohStrategyPointQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohStrategyPointViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohStrategyRecommendReasonViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohStrategyViewDTO;

public interface BizStrategyQueryService extends QueryAPI {
    String TAG = "Strategy";

    @ProcessEntrance(name = "查询策略详情", desc = "查询策略详情", opType = OpType.query, tag = TAG)
    SingleResponse<DoohStrategyViewDTO> getStrategyById(ServiceContext context, Long id);

    @ProcessEntrance(name = "查询member维度策略列表", desc = "查询member维度策略列表", opType = OpType.query, tag = TAG)
    MultiResponse<DoohStrategyViewDTO> findStrategyList(ServiceContext context, Long resourcePackageProductId, Long campaignId);

    /**
     * 查询天攻策略点位列表
     * @param serviceContext
     * @param queryViewDTO
     * @return
     */
    @ProcessEntrance(name = "查询天攻策略点位列表", desc = "查询天攻策略点位列表", opType = OpType.query, tag = TAG)
    MultiResponse<DoohStrategyPointViewDTO> getDoohStrategyPointList(ServiceContext serviceContext, DoohStrategyPointQueryViewDTO queryViewDTO);

    /**
     * 查询天攻策略推荐理由
     * @param serviceContext
     * @param id
     * @return
     */
    @ProcessEntrance(name = "查询天攻策略推荐理由", desc = "查询天攻策略推荐理由", opType = OpType.query, tag = TAG)
    SingleResponse<DoohStrategyRecommendReasonViewDTO> getStrategyRecommendReason(ServiceContext serviceContext, Long id);
}
