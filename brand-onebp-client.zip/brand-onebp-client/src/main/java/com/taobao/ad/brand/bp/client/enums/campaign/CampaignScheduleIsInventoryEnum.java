package com.taobao.ad.brand.bp.client.enums.campaign;

import com.taobao.ad.brand.bp.client.enums.CommonEnum;

public enum CampaignScheduleIsInventoryEnum  implements CommonEnum {
    NEED_INVENTORY(1, "需要走库存"),
    NO_INVENTORY(0,"不需要走库存")
    ;
    private final int value;
    private final String desc;

    CampaignScheduleIsInventoryEnum(int value,String desc){
        this.value = value;
        this.desc = desc;
    }

    public static CampaignScheduleIsInventoryEnum getByValue(Integer value) {
        if (value == null) {
            return null;
        }
        CampaignScheduleIsInventoryEnum[] statusArray = CampaignScheduleIsInventoryEnum.values();
        for (CampaignScheduleIsInventoryEnum status : statusArray) {
            if (status.getValue() == value.intValue()) {
                return status;
            }
        }
        return null;
    }


    @Override
    public int getValue() {
        return value;
    }

    @Override
    public String getDesc() {
        return desc;
    }
}
