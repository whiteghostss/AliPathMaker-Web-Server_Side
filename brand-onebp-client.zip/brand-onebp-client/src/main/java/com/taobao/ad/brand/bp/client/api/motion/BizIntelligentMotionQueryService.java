package com.taobao.ad.brand.bp.client.api.motion;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.ad.brand.dto.frequency.FrequencyViewDTO;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.motion.IntelligentMotionViewDTO;
import com.taobao.ad.brand.bp.client.dto.motion.query.MotionQueryViewDTO;

import java.util.List;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/18
 **/
public interface BizIntelligentMotionQueryService extends QueryAPI {

    String TAG = "IntelligentMotion";

    /**
     * 提案列表不分页
     * @param serviceContext
     * @param queryViewDTO
     * @return
     */
    @ProcessEntrance(name = "提案列表不分页", desc = "提案列表不分页", opType = OpType.query, tag = TAG)
    MultiResponse<IntelligentMotionViewDTO> intelligentMotionList(ServiceContext serviceContext, MotionQueryViewDTO queryViewDTO);

    /**
     * 提案列表不分页
     * @param serviceContext
     * @param queryViewDTO
     * @return
     */
    @ProcessEntrance(name = "提案列表分页", desc = "提案列表分页", opType = OpType.query, tag = TAG)
    MultiResponse<IntelligentMotionViewDTO> intelligentMotionPageList(ServiceContext serviceContext, MotionQueryViewDTO queryViewDTO);

    @ProcessEntrance(name = "提案列表分页", desc = "提案列表分页", opType = OpType.query, tag = TAG)
    SingleResponse<String> getCustomerName(ServiceContext serviceContext, Long memberId);

    /**
     * 计算智能预算分配提案起投金额
     * @param serviceContext
     * @param cartItemIdList
     * @return
     */
    @ProcessEntrance(name = "计算智能预算分配提案起投金额", desc = "计算智能预算分配提案起投金额", opType = OpType.query, tag = TAG)
    SingleResponse<Long> getStartBudget(ServiceContext serviceContext, List<Long> cartItemIdList);
}
