package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.List;

/**
 * @Author: PhilipFry
 * @createTime: 2023年11月30日 19:23:22
 * @Description: 计划模版信息
 */
@Data
public class CampaignTemplateViewDTO extends BaseViewDTO {
    /**
     * 计划id
     */
    private Long campaignId;

    /**
     * 常规模版ID
     */
    private List<Long> templateIds;

    /**
     * 媒体直投（非精准）模版id
     */
    private List<Long> directTemplateIds;

}
