package com.taobao.ad.brand.bp.client.error;

import com.alibaba.hermes.framework.error.ErrorCodeAware;

/**
 * 基础错误码
 *
 * 错误码分类：
 * A表示错误来源于用户，比如参数错误
 * B表示错误来源于当前系统，往往是业务逻辑出错，或程序健壮性差等问题
 * C表示错误来源于第三方服务，比如CDN服务出错，消息投递超时等问题
 * 四位数字编号从0001到9999，大类之间的步长间距预留100
 *
 *
 * 如无特殊需求业务不需要再单独定义错误码。
 * 如需自定义，errorCode在原有错误码基础上再增加2位，如A0201 -> A0201-001，并维护在{@link BrandOneBPCustomErrorCode}
 *
 * @author huangying.cxd
 */
public enum BrandOneBPBaseErrorCode implements ErrorCodeAware {

    // 参数错误
    PARAM_REQUIRED("A1001", "参数必填"),
    PARAM_ILLEGAL("A1002", "参数非法"),
    PARAM_DUPLICATED("A1003", "参数重复"),
    PARAM_BREAK_RULE("A1004", "参数不符合规则"),

    // 业务错误
    BIZ_BREAK_RULE_ERROR("A2001", "不符合业务规则"),
    BIZ_DATA_EMPTY_ERROR("A2002", "数据不存在"),
    BIZ_DATA_EXIST_ERROR("A2003", "数据已存在"),
    BIZ_UN_SUPPORT_ERROR("A2004", "业务不支持"),
    BIZ_NEED_SECOND_CONFIRM("A2005", "业务二次确认"),
    BIZ_DATA_NOT_ENOUGH("A2006", "数据不足"),

    // 操作异常
    OPERATION_DENIED("A2005", "操作被拒绝"),
    OPERATION_FAILED("A2006", "操作失败"),
    OPERATION_FAILED_CALLBACK("A2007", "操作失败回调"),

    // 基础异常
    FORBIDDEN("A3001", "无操作权限"),
    UNSUPPORTED("A3002", "系统不支持"),
    CONFLICT("A3003", "资源冲突"),
    DISTLOCK("A3004", "数据不允许同时操作，请稍后重试"),

    // 系统异常，请稍后重试
    DB_ERROR("B4001", "系统异常，请稍后重试"),
    INTERNAL_ERROR("B4002", "系统异常，请稍后重试"),

    // 外部调用异常
    EXTERNAL_ERROR("C5001", "系统异常，请稍后重试"),
    RPC_ERROR("C5002", "系统异常，请稍后重试"),
    MAPI_ERROR("C5003", "mapi请求异常"),
    ITEM_SUPPORTED_SMART_ERROR("C5004", "宝贝不支持智能创意"),
    IMAGE_GENERATE_ERROR("C5005", "智能生图异常"),

    ;

    private final String code;
    private final String msg;

    BrandOneBPBaseErrorCode(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    @Override
    public String getErrCode() {
        return code;
    }

    @Override
    public String getErrMsg() {
        return msg;
    }

    public ErrorCodeAware of(String msg) {
        return Builder.build(code, msg);
    }
}
