package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupCancelOpTypeEnum;
import lombok.Data;

/**
 * @author yanjingang
 * @date 2023/03/14
 */
@Data
public class CampaignGroupCancelCommandViewDTO extends BaseViewDTO {

    /**
     * 订单ID
     */
    private Long id;

    /**
     * 操作方式
     * @see com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupCancelModeEnum
     */
    private Integer operateMode;

    /**
     * 操作类型
     * @see CampaignGroupCancelOpTypeEnum
     */
    private Integer operateType;
}
