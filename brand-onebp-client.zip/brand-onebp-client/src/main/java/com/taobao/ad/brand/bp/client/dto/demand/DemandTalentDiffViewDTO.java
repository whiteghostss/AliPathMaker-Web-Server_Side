package com.taobao.ad.brand.bp.client.dto.demand;

import lombok.Data;

@Data
public class DemandTalentDiffViewDTO {

    private Long campaignGroupId;

    private String campaignGroupName;

    private Integer updateType;

    private String updateTypeName;

    private String userId;

    private String talentId;

    private String nick;
}
