package com.taobao.ad.brand.bp.client.api.common;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.SingleResponse;

/**
 * @author ximu
 * @date 2023/8/23
 */
public interface OssFileQueryService extends QueryAPI {
    /**
     * 获取oss路径的临时下载地址
     * @param serviceContext
     * @param ossPath
     * @return
     */
    SingleResponse<String> getTempOssDownloadUrl(ServiceContext serviceContext, String ossPath);
}
