package com.taobao.ad.brand.bp.client.enums.campaigngroup;


import com.taobao.ad.brand.bp.client.enums.CommonEnum;

/**
 * 优化&交付场景枚举
 * @author yunhu.myh@taobao.com
 * @date 2023年07月20日
 * */
public enum SaleGroupGoalSceneEnum implements CommonEnum {
    N_REACH(1, "N+reach"),
    NO_REACH(2, "无N+reach"),
    OPTIMIZE_TARGET(3, "多目标"),
    NORMAL(4,"常规");

    private Integer value;
    private String desc;

    SaleGroupGoalSceneEnum(int value, String desc) {
        this.value = value;
        this.desc = desc;
    }



    @Override
    public int getValue() {
        return value;
    }

    public String getDesc() {
        return this.desc;
    }


}
