package com.taobao.ad.brand.bp.client.enums.insight;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 报表benchmark类型
 * @author yuncheng.lyc
 * @date 2023/3/7
 **/
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@Getter
public enum WinInsightDimenisonTypeEnum {

    /**
     * 账户粒度
     */
    MEMBER("member", "账户粒度"),

    /**
     * 品牌粒度
     */
    BRAND("brand", "品牌粒度"),
    ;

    private final String value;
    private final String desc;

    public static WinInsightDimenisonTypeEnum of(String value) {
        for (WinInsightDimenisonTypeEnum typeEnum : WinInsightDimenisonTypeEnum.values()) {
            if (typeEnum.getValue().equals(value)) {
                return typeEnum;
            }
        }
        return null;
    }
}
