package com.taobao.ad.brand.bp.client.dto.resourcepackage;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/03/03
 */
@Data
public class ResourcePackageCastTypeViewDTO extends BaseViewDTO {
    /**
     * 投放类型
     */
    private Integer type;

    /**
     * 投放类型名称
     */
    private String typeDesc;

    /**
     * PD类型：常规/优选
     */
    private Integer pdType;

    /**
     * PD类型名称
     */
    private String pdTypeDesc;

    /**
     * 退回率
     */
    private String returnRate;

    /**
     * 返还比（获取PDB推送比取的值）
     */
    private String returnRatio;
}
