package com.taobao.ad.brand.bp.client.enums.talent;

import java.util.LinkedHashMap;
import java.util.Map;

public enum SupplierDataExcelHeaderEnum {
    DATA("thedate", "日期"),
    MEDIA_ID("mediaId", "媒体ID"),
    MEDIA_NAME("mediaName", "媒体名称"),
    RESOURCE_TYPE("resourceTypeId", "资源位类型ID"),
    TALENT_ID("talentId", "达人ID"),
    USER_NAME("userName", "达人名称"),
    WORKS_URL("workUrl", "内容链接"),
    WORKS_TITLE("workTitle", "内容标题"),
    PV("pv", "曝光量"),
    READ_PV("readPv", "阅读量"),
    INTERACT_PV("interactPv", "互动量"),
    SHARE_PV("sharePv", "转发数"),
    COMMENT_PV("commentPv", "评论数"),
    LIKE_PV("likePv", "点赞数"),
    FOLLOW_PV("followPv", "关注数"),
    COLLECT_PV("collectPv", "收藏数"),
    BARRAGE_PV("barragePv", "弹幕数"),
    COIN_PV("coinPv", "投币数"),
    CLICK_PV("coinPv", "点击量");

    private String fieldName;

    private String fieldExcelName;

    SupplierDataExcelHeaderEnum(String fieldName, String fieldExcelName) {
        this.fieldName = fieldName;
        this.fieldExcelName = fieldExcelName;
    }

    /**
     * 供应商数据导出excel表头
     * @return
     */
    public static Map<String, String> getHeaderMap() {
        LinkedHashMap<String, String> map = new LinkedHashMap<>();
        for (SupplierDataExcelHeaderEnum header : SupplierDataExcelHeaderEnum.values()) {
            map.put(header.getFieldExcelName(), header.getFieldName());
        }
        return map;
    }

    public String getFieldName() {
        return fieldName;
    }

    public String getFieldExcelName() {
        return fieldExcelName;
    }
}
