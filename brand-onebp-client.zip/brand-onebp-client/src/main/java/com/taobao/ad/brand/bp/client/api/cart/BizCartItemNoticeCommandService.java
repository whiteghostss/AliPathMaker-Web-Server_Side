package com.taobao.ad.brand.bp.client.api.cart;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.CommandAPI;
import com.alibaba.hermes.framework.dto.response.Response;
import com.taobao.ad.brand.bp.client.dto.cartitem.CartItemStatusChangeViewDTO;

/**
 * 加购行消息
 * @author yanjingang
 * @date 2023/3/12
 */
public interface BizCartItemNoticeCommandService extends CommandAPI {

    String TAG = "CartItem";

    @ProcessEntrance(name = "通知加购行CartItem状态变更领域事件", desc = "通知加购行CartItem状态变更领域事件", opType = OpType.update, tag = TAG)
    Response noticeCartItemStatusUpdated(ServiceContext serviceContext, CartItemStatusChangeViewDTO cartItemStatusChangeViewDTO);
}
