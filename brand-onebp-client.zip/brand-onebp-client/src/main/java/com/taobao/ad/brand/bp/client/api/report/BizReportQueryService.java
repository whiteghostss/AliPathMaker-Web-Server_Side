package com.taobao.ad.brand.bp.client.api.report;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.ReportMultiResponse;
import com.taobao.ad.brand.bp.client.dto.report.ReportCampaignGroupBrandViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportDimensionConfigViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.query.ReportAttributionBrandQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.query.ReportQueryViewDTO;

import java.util.Map;

/**
 * 报表查询相关服务
 * @author yuncheng.lyc
 */
public interface BizReportQueryService extends QueryAPI {
    String TAG = "Report";

    @ProcessEntrance(name = "数据查询", desc = "数据查询", opType = OpType.query, tag = TAG)
    MultiResponse<Map<String, Object>> queryReport(ServiceContext context, Map<String, Object> queryMap);
    /**
     * 报表-通用数据查询服务
     * @param context
     * @param queryViewDTO
     * @return
     */
    @ProcessEntrance(name = "数据查询", desc = "数据查询", opType = OpType.query, tag = TAG)
    ReportMultiResponse<Map<String, Object>> queryReport(ServiceContext context, ReportQueryViewDTO queryViewDTO);

    /**
     * 报表-通用数据导出服务
     * @param context
     * @param queryViewDTO
     * @return
     */
    @ProcessEntrance(name = "数据异步下载", desc = "数据异步下载", opType = OpType.query, tag = TAG)
    SingleResponse<Long> asyncExportReport(ServiceContext context, ReportQueryViewDTO queryViewDTO);

    /**
     * 报表-通用数据导出服务
     * @param context
     * @param queryViewDTO
     * @return
     */
    @ProcessEntrance(name = "数据同步下载", desc = "数据同步下载", opType = OpType.query, tag = TAG)
    SingleResponse<String> exportReport(ServiceContext context, ReportQueryViewDTO queryViewDTO);

    /**
     * 报表-查询当下有权限的维度集合
     * @param context
     * @param queryViewDTO
     * @return
     */
    @ProcessEntrance(name = "查询有权限的维度", desc = "查询有权限的维度", opType = OpType.query, tag = TAG)
    MultiResponse<ReportDimensionConfigViewDTO> dimensionList(ServiceContext context, ReportQueryViewDTO queryViewDTO);

    /**
     * 报表-查询当下归因品牌集合
     * @param context
     * @param queryViewDTO
     * @return
     */
    @ProcessEntrance(name = "查询当下归因品牌", desc = "查询当下归因品牌", opType = OpType.query, tag = TAG)
    MultiResponse<CommonViewDTO> attributionBrandList(ServiceContext context, ReportAttributionBrandQueryViewDTO queryViewDTO);

    /**
     * 报表-查询品牌和订单
     * @param context
     * @param queryViewDTO
     * @return
     */
    @ProcessEntrance(name = "查询品牌和订单", desc = "查询品牌和订单", opType = OpType.query, tag = TAG)
    MultiResponse<ReportCampaignGroupBrandViewDTO> getCampaignGroupBrandList(ServiceContext context, ReportAttributionBrandQueryViewDTO queryViewDTO);

}
