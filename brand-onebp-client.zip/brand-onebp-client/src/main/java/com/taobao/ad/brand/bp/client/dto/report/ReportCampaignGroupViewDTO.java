package com.taobao.ad.brand.bp.client.dto.report;

import com.alibaba.solar.common.dto.BaseDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignGroupQueryViewDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReportCampaignGroupViewDTO extends CampaignGroupQueryViewDTO {
    List<Integer> talentConfigStatusList;
}
