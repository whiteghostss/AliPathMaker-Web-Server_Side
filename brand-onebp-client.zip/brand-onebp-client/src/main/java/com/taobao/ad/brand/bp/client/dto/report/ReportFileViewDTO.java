package com.taobao.ad.brand.bp.client.dto.report;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.excel.ExcelCatalogueViewDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 查询数据文件对象
 * @author yuncheng.lyc
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReportFileViewDTO extends BaseViewDTO {
    /**
     * 文件名称
     */
    private String fileName;
    /**
     * 目录信息
     */
    private List<ExcelCatalogueViewDTO> homePageList;
    /**
     * 是否需要字段说明
     * 1:需要，将adc配置的指标信息显示在目录页上
     */
    private Integer needMetricsInfo;
    /**
     * 是否需要维度说明
     * 1:需要，将adc配置的维度信息显示在目录页上
     */
    private Integer needDimensionInfo;
    /**
     * 维度信息是否需要超连接到对应的sheet上
     * needDimensionInfo=1的时候生效
     */
    private Integer needDimensionHyperlink;
}
