package com.taobao.ad.brand.bp.client.enums.message;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * 领域消息settingKey
 *
 * @author GXG
 * @date 2023/7/27
 */
public enum DomainMessageSettingKeyEnum {
    SALE_GROUPS("saleGroups", "售卖分组列表");
    private String key;
    private String desc;

    DomainMessageSettingKeyEnum(String key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    private static final Map<String, DomainMessageSettingKeyEnum> MAP = (Map) Arrays.stream(values()).collect(Collectors.toMap(DomainMessageSettingKeyEnum::getKey, Function.identity()));


    public String getKey() {
        return this.key;
    }

    public String getDesc() {
        return this.desc;
    }
}
