package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquirySchedulePolicyViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignInquiryAssignTypeEnum;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * 计划排期策略配置
 * @author 石炎
 * @date 2023/08/30
 */
@Data
public class CampaignSchedulePolicyConfigViewDTO extends BaseViewDTO {
    /**
     * 开始时间
     */
    private Date startTime;
    /**
     * 结束时间
     */
    private Date endTime;
    /**
     * 有效开始时间
     */
    private Date availableStartTime;
    /**
     * 有效结束时间
     */
    private Date availableEndTime;
    /**
     * 区间分配策略
     * 1：分天 （BY_DAY）
     * 2：智能 （INTELLIGENCE）
     * 3：周期 （PERIOD）
     *
     * @see BrandCampaignInquiryAssignTypeEnum
     */
    private Integer inquiryAssignType;
    /**
     * 可分配预定量
     */
    private Long availableAmount;
    /**
     * 预定单位
     */
    private Integer sspRegisterUnit;
    /**
     * 预定单位与pv转换系数
     */
    private Long sspRegisterRatio;
    /**
     * 计划询量周期分配策略
     * inquiryAssignType = 3（周期）必填
     */
    private List<CampaignInquirySchedulePolicyViewDTO> schedulePolicyList;
}
