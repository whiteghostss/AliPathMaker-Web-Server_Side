package com.taobao.ad.brand.bp.client.dto.base;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

@Data
public class SellerShieldProductlineViewDTO extends BaseViewDTO {
    Integer sspProducrline;
    Integer saleProductline;
    public SellerShieldProductlineViewDTO(Integer sspProducrline, Integer saleProductline) {
        this.saleProductline = saleProductline;
        this.sspProducrline = sspProducrline;
    }
}
