package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * @author yuncheng.lyc
 */
@Data
public class SalesContractBrandViewDTO extends BaseViewDTO {

    private Long brandId;
    private String brandName;
}
