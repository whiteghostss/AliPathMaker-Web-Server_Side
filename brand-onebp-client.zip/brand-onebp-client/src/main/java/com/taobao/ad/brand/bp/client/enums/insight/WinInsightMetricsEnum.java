package com.taobao.ad.brand.bp.client.enums.insight;

import com.google.common.collect.Lists;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.List;

/**
 * 报表benchmark类型
 *
 * @author yuncheng.lyc
 * @date 2023/3/7
 **/
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@Getter
public enum WinInsightMetricsEnum {

    /**
     * 曝光量
     */
    IMPRESSION("impression", "曝光量"),

    /**
     * 点击率
     */
    CTR("ctr", "点击率"),
    /**
     * 到达率
     */
    ARRIVE_RATE("arriveRate", "到达率"),
    /**
     * 兴趣互动量
     */
    INTEREST_ACT("interestAct", "兴趣互动量"),
    /**
     * 收藏关注量
     */
    COLLECT_FOLLOW("collectFollow", "收藏关注"),
    /**
     * 购买意向量
     */
    PURCHASE_INTENT("purchaseIntent", "购买意向量"),

    /**
     * 品牌词搜索量
     */
    BRAND_WORD_SEARCH_CNT("brandSearch", "品牌词搜索量"),

    /**
     * 搜索点击量
     */
    SEARCH_CLK("nonBrandSearchIndex", "搜索点击"),

    /**
     * w指数
     */
    W_INDEX("wIndex", "w指数"),

    /**
     * i指数
     */
    I_INDEX("iIndex", "i指数"),

    /**
     * n指数
     */
    N_INDEX("nIndex", "n指数"),

    /**
     * win指数
     */
    WIN_INDEX("winIndex", "win指数"),

    /**
     * 赛道信息
     */
    TOPIC_JSON("topicJson", "赛道信息"),

    /**
     * 赛道id
     */
    TOPIC_ID("topicId", "赛道Id"),

    /**
     * 赛道名称
     */
    TOPIC_NAME("topicName", "赛道信息"),

    /**
     * 品牌id
     */
    BRAND_ID("brandId", "品牌Id"),

    /**
     * 品牌名称
     */
    BRAND_NAME("brandName", "品牌名称"),

    /**
     * 一级类目
     */
    CATE_LEVEL_ONE_ID("cateLevelOneId", "一级类目Id"),

    /**
     * 一级类目名称
     */
    CATE_LEVEL_ONE_NAME("cateLevelOneName", "一级类目名称"),

    /**
     * 二级类目Id
     */
    CATE_LEVEL_TWO_ID("cateLevelTwoId", "二级类目Id"),

    /**
     * 二级类目名称
     */
    CATE_LEVEL_TWO_NAME("cateLevelTwoName", "二级类目名称"),

    /**
     * 叶子类目Id
     */
    CATE_LEVEL_LEAF_ID("cateLevelLeafId", "叶子类目Id"),

    /**
     * 叶子类目名称
     */
    CATE_LEVEL_LEAF_NAME("cateLevelLeafName", "叶子类目名称"),

    /**
     * GMV排名
     */
    RNK("rnk", "GMV排名")
    ;


    public static List<WinInsightMetricsEnum> getDataMetrics() {
        return Lists.newArrayList(IMPRESSION, CTR, ARRIVE_RATE, INTEREST_ACT, COLLECT_FOLLOW, PURCHASE_INTENT, BRAND_WORD_SEARCH_CNT, SEARCH_CLK, W_INDEX, I_INDEX, N_INDEX, WIN_INDEX);
    }

    public static List<WinInsightMetricsEnum> getRateDataMetrics() {
        return Lists.newArrayList(CTR, ARRIVE_RATE);
    }

    public static List<WinInsightMetricsEnum> getWindDataMetrics() {
        return Lists.newArrayList(WIN_INDEX, W_INDEX, I_INDEX, N_INDEX);
    }

    public static List<WinInsightMetricsEnum> getBasicDataMetrics() {
        return Lists.newArrayList(IMPRESSION, INTEREST_ACT, COLLECT_FOLLOW, PURCHASE_INTENT, BRAND_WORD_SEARCH_CNT, SEARCH_CLK);
    }



    private final String metricsName;
    private final String metricsDesc;

    public static WinInsightMetricsEnum of(String value) {
        for (WinInsightMetricsEnum typeEnum : WinInsightMetricsEnum.values()) {
            if (typeEnum.getMetricsName().equals(value)) {
                return typeEnum;
            }
        }
        return null;
    }

}
