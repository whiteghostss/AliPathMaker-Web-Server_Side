package com.taobao.ad.brand.bp.client.dto.resourcepackage;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/22
 */
@Data
public class ResourcePackageNoticeTemplateViewDTO extends BaseViewDTO {
    /**
     * 客户模板ID
     */
    private Long id;

    /**
     * 模板类型
     * @see com.taobao.ad.brand.bp.client.enums.resourcepackage.ResourcePackageTemplateTypeEnum
     */
    private Integer type;

    /**
     * 分组List
     */
    private List<ResourcePackageNoticeSaleGroupViewDTO> saleGroupList;

    /**
     * 售卖分组ID-盘量信息变动时传入设置了盘量信息的分组id
     */
    private List<Long> saleGroupIdList;

    /**
     * 客户模板盘量日期
     */
    private Date inquiryDate;

    /**
     * 客户模板盘量批次
     */
    private Integer inquiryBatch;
}