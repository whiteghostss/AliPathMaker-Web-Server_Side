package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.List;

@Data
public class CampaignSaleGroupMsgNoticeViewDTO extends BaseViewDTO {
    private String saleGroupName;
    private List<CampaignMsgNoticeViewDTO> campaignInfos;
}
