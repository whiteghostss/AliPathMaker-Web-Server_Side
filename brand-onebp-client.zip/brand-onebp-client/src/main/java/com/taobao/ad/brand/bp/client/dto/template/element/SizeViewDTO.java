package com.taobao.ad.brand.bp.client.dto.template.element;

import lombok.Data;

/**
 * @description:
 * @author: philipfry
 * @create: 2021-06-24 10:58
 **/
@Data
public class SizeViewDTO {
    private String width;

    private String height;
}
