package com.taobao.ad.brand.bp.client.enums;

/**
 * @author zhaorubing
 * @date 2024/5/8 15:14
 */
public enum AdStyleEnum {

    TB_STAR_PIC_POPVIEW(998, "popView-开屏不跳转"),

    TB_STAR_PIC_POPVIEW_JUMP(996, "popView-开屏可跳转"),

    TB_STAR_PIC_ONLY_POPVIEW(995, "手淘仅开屏"),

    TB_STAR_PIC_POPVIEW_FIRST_SHOW(993, "手淘开屏联动信息流1坑"),

    TB_STAR_PIC_WORD(999, "底纹词-开屏不跳转"),

    TB_STAR_PIC_WORD_NOT_JUMP(994, "底纹词-开屏可跳转"),

    TB_STAR_PIC_TOPVIEW(997, "topView-开屏可跳转"),

    YK_MOVIE_ADS_FOCUS_VIEW(202,"优酷聚焦贴片");

    private Integer value;
    private String desc;

    AdStyleEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public Integer getValue() {
        return value;
    }

    public String getDesc() {
        return desc;
    }

    public static AdStyleEnum getByValue(Integer value) {
        for (AdStyleEnum enums : AdStyleEnum.values()) {
            if (enums.getValue().equals(value)) {
                return enums;
            }
        }
        return null;
    }
}
