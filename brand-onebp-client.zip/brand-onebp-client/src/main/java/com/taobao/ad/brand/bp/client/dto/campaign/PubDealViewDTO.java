package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class PubDealViewDTO extends BaseViewDTO {
    private String pubDealId;

    /**
     * 打底日期
     *  yyyy-MM-dd
     */
    @JSONField(format = "yyyy-MM-dd")
    private List<Date> bottomDays;

}
