package com.taobao.ad.brand.bp.client.dto.shopwindow;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/6/26
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class BrandSpuTagRefViewDTO extends BaseViewDTO {

    /**
     * 标签名称
     */
    private String name;

    /**
     * 标签打标类型
     * TagSourceEnum
     */
    private Integer source;

    /**
     * 标签打标来源
     * TagProduceCodeEnum
     */
    private String produceCode;

    /**
     * 一级类目
     */
    private String firstCategory;

    /**
     * 二级类目
     */
    private String secondCategory;
}
