package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Builder;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author yanjingang
 * @date 2024/07/09
 */
@Data
public class ContractContentViewDTO extends BaseViewDTO {
    /**
     * 主订单ID
     */
    private Long mainCampaignGroupId;
    /**
     * 子订单ID
     */
    private Long campaignGroupId;
    /**
     * 子订单名称
     */
    private String campaignGroupName;
    /**
     * 开始时间
     */
    private Date startTime;
    /**
     * 结束时间
     */
    private Date endTime;
    /**
     * 订单金额，单位分
     */
    private Long budget;

    /**
     * 计划详情
     */
    private List<ContractContentCampaignViewDTO> campaignList;
}
