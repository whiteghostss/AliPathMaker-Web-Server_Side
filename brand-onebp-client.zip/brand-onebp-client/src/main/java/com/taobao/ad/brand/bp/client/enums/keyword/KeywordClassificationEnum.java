package com.taobao.ad.brand.bp.client.enums.keyword;

import lombok.Getter;

/**
 * 关键词分类
 */
@Getter
public enum KeywordClassificationEnum {
    BRAND(1, "品牌阵地词"),
    COMPETITIVE_PRODUCT(2, "竞品抢占词"),
    CATEGORY_PENETRATION(3, "类目渗透词"),
    ;

    private Integer code;
    private String desc;

    KeywordClassificationEnum(Integer code, String desc){
        this.code = code;
        this.desc = desc;
    }

    public static KeywordClassificationEnum getByCode(Integer code){
        if(code == null){
            return null;
        }
        for(KeywordClassificationEnum keywordClassificationEnum : KeywordClassificationEnum.values()){
            if(keywordClassificationEnum.getCode().equals(code)){
                return keywordClassificationEnum;
            }
        }
        return null;
    }
}
