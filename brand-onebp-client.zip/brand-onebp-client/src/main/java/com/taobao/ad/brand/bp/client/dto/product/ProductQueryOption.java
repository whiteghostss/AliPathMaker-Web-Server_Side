package com.taobao.ad.brand.bp.client.dto.product;/**
 * @author jiXiu.lj
 * @date 2024/9/12 13:15
 * @desc ssp产品查询参数
 */

import lombok.Builder;
import lombok.Data;

/**
 * @author jixiu.lj
 * @date 2024/9/12 13:15
 */
@Data
@Builder
public class ProductQueryOption {

    /**
     * 是否需要分页
     */
    private boolean needPage;

    /**
     * 是否需要定向
     */
    private boolean needDirection;
    /**
     * 是否只返回定向，不返回定向值
     */
    private boolean needDirectionFirstNode;

    /**
     * 是否需要广告位
     */
    private boolean needAdzone;

    /**
     * 是否需要资源
     */
    private boolean needResource;

    /**
     * 是否需要跨域二级产品
     */
    private boolean needAssociationProduct;

    /**
     * 是否需要父产品名称
     */
    private boolean needParentName;

    /**
     * 是否需要标签名称
     */
    private boolean needLabelName;

    /**
     * 是否需要模板名称
     */
    private boolean needTemplateName;
}
