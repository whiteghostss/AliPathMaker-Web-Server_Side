package com.taobao.ad.brand.bp.client.api.oplog;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.taobao.ad.brand.bp.client.dto.oplog.OpLogQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.oplog.OpLogViewDTO;

public interface OpLogQueryService extends QueryAPI {
    String TAG = "oplog";

    /**
     *
     * @param context
     * @param query
     * @return
     */
    @ProcessEntrance(name = "日志查询", desc = "日志查询", opType = OpType.query, tag = TAG)
    MultiResponse<OpLogViewDTO> queryOpList(ServiceContext context, OpLogQueryViewDTO query);
}
