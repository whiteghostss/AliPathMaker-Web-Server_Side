package com.taobao.ad.brand.bp.client.context;

import com.alibaba.abf.governance.context.ServiceContext;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class CampaignGroupCalculateContext {

    /**
     * 上下文
     */
    private ServiceContext serviceContext;

    /**
     * 订单id
     */
    private Long campaignGroupId;
}
