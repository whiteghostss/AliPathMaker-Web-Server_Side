package com.taobao.ad.brand.bp.client.dto.tag;

import com.taobao.ad.brand.bp.client.dto.base.BaseQueryViewDTO;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author: PhilipFry
 * @createTime: 2024年01月28日 15:23:55
 * @Description:
 */
@Data
public class TagQueryViewDTO extends BaseQueryViewDTO {

    /**
     * 广告用户ID
     */
    private Long memberId;

    /**
     * 产品ID
     */
    private Integer productId;


    /**
     * 类型
     */
    private Integer tagType;


    /**
     * 名称
     */
    private String tagName;


    /**
     * like 名称
     */
    private String likeTagName;


    /**
     * ID list
     */
    private List<Long> idList = new ArrayList<>();
}
