package com.taobao.ad.brand.bp.client.dto.mr;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.List;

/**
 * @author jixiu.lj
 * @date 2023/3/21 11:38
 */
@Data
public class MaterialRuleDetailViewDTO extends BaseViewDTO {
    private Long ruleId;
    private String ruleName;
    private Integer mediaScopeCode;
    private String mediaScope;
    private Long mediaId;
    private String mediaName;
    private Integer adStyle;
    private String adStyleName;
    private Integer materialType;
    private String materialTypeName;
    private Integer preDays;
    private String ruleDesc;
    private String demoUrl;
    private Integer isOnlineSameAsOffline;
    private Integer status;
    private List<String> designCodeUrls;
    private List<MaterialRuleItemDetailViewDTO> materialRuleItemDetailDTOList;
}
