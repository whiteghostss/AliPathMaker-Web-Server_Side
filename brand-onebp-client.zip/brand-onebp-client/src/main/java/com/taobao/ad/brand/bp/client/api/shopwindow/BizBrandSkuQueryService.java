package com.taobao.ad.brand.bp.client.api.shopwindow;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandBundleViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSkuViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.query.BrandBundleQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.query.BrandSkuQueryViewDTO;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/6/26
 **/
public interface BizBrandSkuQueryService extends QueryAPI {

    String TAG = "BrandSku";

    /**
     * 提案列表不分页
     * @param serviceContext
     * @param queryViewDTO
     * @return
     */
    @ProcessEntrance(name = "SKU列表不分页", desc = "SKU列表不分页", opType = OpType.query, tag = TAG)
    MultiResponse<BrandSkuViewDTO> queryBrandSkuList(ServiceContext serviceContext, BrandSkuQueryViewDTO queryViewDTO);

    /**
     * 查询套餐包列表页
     * @param serviceContext
     * @param queryViewDTO
     * @return
     */
    @ProcessEntrance(name = "套餐包列表不分页", desc = "套餐包列表不分页", opType = OpType.query, tag = TAG)
    MultiResponse<BrandBundleViewDTO> queryBrandBundleList(ServiceContext serviceContext, BrandBundleQueryViewDTO queryViewDTO);

    /**
     * 查询套餐包详情
     * @param serviceContext
     * @param bundleId
     * @return
     */
    @ProcessEntrance(name = "套餐包详情", desc = "套餐包详情", opType = OpType.query, tag = TAG)
    SingleResponse<BrandBundleViewDTO> getBrandBundleDetail(ServiceContext serviceContext, Long bundleId);
}
