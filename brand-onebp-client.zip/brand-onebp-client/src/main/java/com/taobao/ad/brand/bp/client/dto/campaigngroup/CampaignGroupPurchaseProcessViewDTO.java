package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupPurchaseStatusEnum;
import lombok.Data;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/03/02
 */
@Data
public class CampaignGroupPurchaseProcessViewDTO extends BaseViewDTO {

    /**
     * 采购状态
     */
    BrandCampaignGroupPurchaseStatusEnum brandCampaignGroupPurchaseStatusEnum;
    /**
     * 采购单id
     */
    private Long purchaseOrderId;
}
