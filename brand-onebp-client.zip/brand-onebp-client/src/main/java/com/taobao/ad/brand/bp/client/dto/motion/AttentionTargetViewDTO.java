package com.taobao.ad.brand.bp.client.dto.motion;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/18
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class AttentionTargetViewDTO extends BaseViewDTO {

    /**
     * 目标类型
     */
    private Integer attentionTarget;

    /**
     * 目标值
     */
    private Long attentionTargetValue;
}
