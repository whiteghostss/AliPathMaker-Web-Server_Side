package com.taobao.ad.brand.bp.client.api.solution;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.solution.CartItemSolutionViewDTO;
import com.taobao.ad.brand.bp.client.dto.solution.query.CartItemSolutionQueryOption;

public interface BizSolutionQueryService extends QueryAPI {

    String TAG = "Solution";

    /**
     * 查询加购行解决方案信息
     * @param context
     * @param cartItemId
     * @param queryOption
     * @return
     */
    @ProcessEntrance(name = "查询加购行解决方案信息", desc = "查询加购行解决方案信息", opType = OpType.query, tag = TAG)
    SingleResponse<CartItemSolutionViewDTO> getCartItemSolutionInfo(ServiceContext context, Long cartItemId, CartItemSolutionQueryOption queryOption);
}
