package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.enums.common.BizBpmsProcessStatusEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/03/06
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CampaignDelayLockProcessViewDTO extends BaseViewDTO {
    /**
     * 一级计划ID列表
     */
    private List<Long> campaignIds;

    /**
     * 流程实例ID
     */
    private String procInstId;

    /**
     * 结果
     */
    private BizBpmsProcessStatusEnum result;
}
