package com.taobao.ad.brand.bp.client.enums.report;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 报表指标类型
 * @author yuncheng.lyc
 * @date 2023/3/7
 **/
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@Getter
public enum ReportMetricsTypeEnum {
    BACKEND("2", "后链指标"),
    FRONTEND("1", "前链指标");


    private String code;
    private String desc;


    public static ReportMetricsTypeEnum of(String code) {
        for (ReportMetricsTypeEnum theEnum : ReportMetricsTypeEnum.values()) {
            if (theEnum.getCode().equals(code)) {
                return theEnum;
            }
        }
        return null;
    }
}
