package com.taobao.ad.brand.bp.client.enums.report;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;

/**
 * @author yuncheng.lyc
 */
@AllArgsConstructor(access = AccessLevel.PACKAGE)
public enum GuestTypeEnum {
    GUEST_NEW(0, "新客"),
    GUEST_OLD(1, "老客");


    private Integer value;
    private String name;



    public static GuestTypeEnum getByValue(Integer value) {
        GuestTypeEnum[] enums = GuestTypeEnum.values();
        for (GuestTypeEnum type : enums) {
            if (type.getValue().equals(value))
                return type;
        }
        return null;
    }


    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
