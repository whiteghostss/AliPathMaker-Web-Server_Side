package com.taobao.ad.brand.bp.client.enums.keyword;

import lombok.Getter;

/**
 * 关键词推荐方式
 */
@Getter
public enum KeywordRecommendMethodEnum {

    SMART_RECOMMEND(1, "关键词工具"),
    CUSTOM(2, "自定义")
    ;

    private Integer code;
    private String desc;

    KeywordRecommendMethodEnum(Integer code, String desc){
        this.code = code;
        this.desc = desc;
    }
}
