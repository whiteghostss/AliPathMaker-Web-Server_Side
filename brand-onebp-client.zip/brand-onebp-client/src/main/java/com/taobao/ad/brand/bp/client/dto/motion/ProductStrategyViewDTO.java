package com.taobao.ad.brand.bp.client.dto.motion;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.List;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/18
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class ProductStrategyViewDTO extends BaseViewDTO {

    /**
     * 产品id
     */
    private Long resourcePackageProductId;

    /**
     * ssp产品id
     */
    private Long sspProductId;

    /**
     * 加购行id
     */
    private Long cartItemId;

    /**
     * 投放方式
     */
    private Integer castType;

    /**
     * 产品所属类别
     */
    private String category;

    /**
     * 产品价格波段策略
     */
    private List<ProductBandPriceStrategyViewDTO> productBandPriceStrategyViewDTOList;
}
