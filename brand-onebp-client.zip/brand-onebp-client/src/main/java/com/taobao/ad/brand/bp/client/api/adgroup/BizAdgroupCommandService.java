package com.taobao.ad.brand.bp.client.api.adgroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.hermes.framework.api.CommandAPI;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.adgroup.AdgroupBatchImportParamViewDTO;
import com.taobao.ad.brand.bp.client.dto.adgroup.AdgroupEmailSendResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportTaskViewDTO;

import java.util.List;

/**
 * Campaign
 *
 * @author yuanxinxi
 * @date 2023/2/28
 */
public interface BizAdgroupCommandService extends CommandAPI {

    String TAG = "Adgroup";

    /**
     * 新建单元
     * @param context
     * @param campaignViewDTO
     * @return adgroupId
     */
    @ProcessEntrance(name = "新建单元", desc = "createAdgroup", opType = OpType.add, tag = TAG)
    SingleResponse<Long> addAdgroup(ServiceContext context, AdgroupViewDTO campaignViewDTO);

    /**
     * 批量新建单元
     * @param context
     * @param adgroupViewDTOList
     * @return adgroupId
     */
    @ProcessEntrance(name = "批量新建单元", desc = "batchCreateAdgroup", opType = OpType.add, tag = TAG)
    Response batchAddAdgroup(ServiceContext context, List<AdgroupViewDTO> adgroupViewDTOList,  List<Long> campaignIdList, Integer inheritTime);

    /**
     * 更新单元
     * @param context
     * @param campaignViewDTO
     * @return
     */
    @ProcessEntrance(name = "更新单元", desc = "modifyAdgroup", opType = OpType.update, tag = TAG)
    SingleResponse<Long> updateAdgroup(ServiceContext context, AdgroupViewDTO campaignViewDTO);

    /**
     * 更新单元状态
     * @param context
     * @param ids
     * @return
     */
    @ProcessEntrance(name = "批量更新单元状态", desc = "batchUpdateAdgroupStatus", opType = OpType.update, tag = TAG)
    SingleResponse<Long> batchUpdateAdgroupStatus(ServiceContext context, List<Long> ids,Integer status);
    /**
     * 更新单元名称
     * @param context
     * @param adgroupViewDTO
     * @return
     */
    @ProcessEntrance(name = "更新单元名称", desc = "updateAdgroupName", opType = OpType.update, tag = TAG)
    public SingleResponse<Long> updateAdgroupName(ServiceContext context, AdgroupViewDTO adgroupViewDTO) ;
    /**
     * 删除单元
     * @param context
     * @param id
     * @return
     */
    @ProcessEntrance(name = "删除单元", desc = "deleteAdgroup", opType = OpType.delete, tag = TAG)
    SingleResponse<Long> deleteAdgroup(ServiceContext context, Long id);

    /**
     * 批量发送非精准邮件
     * @param context
     * @param ids 单元IDs
     * @return
     */
    @ProcessEntrance(name = "批量发送非精准邮件", desc = "batchSendEmails", opType = OpType.other, tag = TAG)
    SingleResponse<AdgroupEmailSendResultViewDTO> batchSendEmails(ServiceContext context, List<Long> ids);


    /**
     * 批量单元关联创意
     *
     * @param context
     * @param adgroupIds
     * @param creativeIds
     * @return
     */
    @ProcessEntrance(name = "批量单元关联创意", desc = "批量单元关联创意", opType = OpType.add, tag = TAG)
    Response batchBindCreative(ServiceContext context, List<Long> adgroupIds, List<Long> creativeIds);
    /**
     * 批量单元解绑创意
     *
     * @param context
     * @param adgroupIds
     * @param creativeIds
     * @return
     */
    @ProcessEntrance(name = "批量单元解绑创意", desc = "批量单元解绑创意", opType = OpType.update, tag = TAG)
    Response batchUnBindCreative(ServiceContext context, List<Long> adgroupIds, List<Long> creativeIds);

    /**
     *批量单元保存为正式
     * @param context
     * @param adgroupIds
     * @return
     */
    @ProcessEntrance(name = "批量单元保存为正式", desc = "batchSetOnline", opType = OpType.update, tag = TAG)
    Response batchSetOnline(ServiceContext context, List<Long> adgroupIds);

    /**
     * 批量删除单元
     * @param context
     * @param ids
     * @return
     */
    @ProcessEntrance(name = "删除单元", desc = "deleteAdgroup", opType = OpType.delete, tag = TAG)
    SingleResponse<Long> batchDeleteAdgroup(ServiceContext context, List<Long> ids);

    /**
     * 拷贝创意作为媒体直投创意
     * @param context
     * @param adgroupId
     * @return
     */
    @ProcessEntrance(name = "拷贝创意作为媒体直投创意", desc = "拷贝创意作为媒体直投创意", opType = OpType.add, tag = TAG)
    Response copyCreativeAsDirect(ServiceContext context, Long adgroupId);

    /**
     * 保存单元批量导入监测任务
     * @param context
     * @param taskViewDTO
     * @return
     */
    @ProcessEntrance(name = "保存单元批量导入监测任务", desc = "保存单元批量导入监测任务", opType = OpType.add, tag = TAG)
    SingleResponse<Long> saveThirdMonitorBatchImportTask(ServiceContext context, ReportTaskViewDTO taskViewDTO);


    /**
     * 单元批量导入监测
     * @param context 上线文
     * @param adgroupBatchImportParamViewDTO 单元导入数据
     * @return 是否成功
     */
    @ProcessEntrance(name = "单元批量导入监测", desc = "单元批量导入监测", opType = OpType.add, tag = TAG)
    Response batchSaveThirdMonitor(ServiceContext context, AdgroupBatchImportParamViewDTO adgroupBatchImportParamViewDTO);
}
