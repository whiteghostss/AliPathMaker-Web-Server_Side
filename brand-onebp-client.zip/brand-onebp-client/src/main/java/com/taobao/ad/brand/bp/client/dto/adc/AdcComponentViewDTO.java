package com.taobao.ad.brand.bp.client.dto.adc;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.ToString;

import java.util.List;
import java.util.Map;

/**
 * ADC配置信息
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@Data
@ToString
public class AdcComponentViewDTO extends BaseViewDTO {
    /**
     * 组件id
     */
    private Long id;

    /**
     * 编码
     */
    private String code;

    /**
     * 名称
     */
    private String name;

    /**
     * 描述
     */
    private String description;

    /**
     * 状态（1：有效；0：无效）
     */
    private Integer status;

    /**
     * 前端类型
     */
    private String webType;

    /**
     * 帮助中心
     */
    private String assistant;

    /**
     * 组件类型（Menu；Block；BizComponent）
     * @see ComponentTypeEnum
     */
    private String type;

    /**
     * 规则JSON
     * @see UpgradeComponentRule
     */
    private String rule;

    /**
     * 排序
     */
    private Long sort;

    /**
     * 节点数值
     */
    private String value;

    /**
     * 节点默认值
     */
    private Object defaultValue;

    /**
     * 扩展数据
     */
    private Map<String, Object> properties;

    /**
     * 前端扩展数据
     */
    private Map<String, Object> webProperties;

    /**
     * 子组件
     */
    private List<AdcComponentViewDTO> subComponentList;

    /**
     * 数据
     */
    private List<AdcComponentMetaViewDTO> metaList;
}
