package com.taobao.ad.brand.bp.client.api.demand;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.CommandAPI;
import com.alibaba.hermes.framework.dto.response.Response;
import com.taobao.ad.brand.bp.client.context.DomainMetaqMessageBodyContext;

@Deprecated
public interface BizDemandNoticeCommandService extends CommandAPI {

    String TAG = "Demand";

    @ProcessEntrance(name = "内容子订单更新通知", desc = "内容子订单更新通知", opType = OpType.update, tag = TAG)
    Response noticeContentCampaignGroup(ServiceContext serviceContext, DomainMetaqMessageBodyContext bodyContext);

    @ProcessEntrance(name = "更新诉求状态通知", desc = "更新诉求状态通知", opType = OpType.update, tag = TAG)
    Response updateStatus(ServiceContext context, Long id, Integer eventValue);

    @ProcessEntrance(name = "物料制作类资源更新（小二审核通过）", desc = "物料制作类资源更新（小二审核通过）", opType = OpType.update, tag = TAG)
    Response confirmMaterialUpdate(ServiceContext context, Long id);
}
