package com.taobao.ad.brand.bp.client.dto.product;

import lombok.Data;

/**
 * 地域ViewDTO
 * @date: 2023/8/2 16:00
 * @author: shiyan
 */
@Data
public class AreaViewDTO {

    private  Integer id;
    /**
     * 父id
     */
    private Integer parentId;
    /**
     * 排序字段
     */
    private Integer sortCode;
    /**
     * 级别 最多四级 中国级别为：2
     */
    private Integer level;
    /**
     * 地域名称
     */
    private String name;
    /**
     * 地域编号
     */
    private Integer value;
    /**
     * 状态
     */
    private Integer status;
    /**
     * 地区类型：KAB的标记
     */
    private String type;
    /**
     * 备注
     */
    private String description;

}
