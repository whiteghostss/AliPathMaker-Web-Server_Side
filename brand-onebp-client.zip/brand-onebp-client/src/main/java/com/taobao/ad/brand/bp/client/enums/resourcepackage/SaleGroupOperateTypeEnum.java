package com.taobao.ad.brand.bp.client.enums.resourcepackage;

/**
 * @author yanjingang
 * @date 2023/5/6
 */
public enum SaleGroupOperateTypeEnum {

    ADD(1, "新增"),

    UPDATE(2, "更新"),

    DELETE(3, "删除");

    private Integer value;
    private String desc;

    SaleGroupOperateTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public Integer getValue() {
        return value;
    }

    public String getDesc() {
        return desc;
    }

    public static String getDesc(Integer code){
        for (SaleGroupOperateTypeEnum theEnum : SaleGroupOperateTypeEnum.values()){
            if (theEnum.getValue().equals(code)){
                return theEnum.getDesc();
            }
        }
        return null;
    }
}
