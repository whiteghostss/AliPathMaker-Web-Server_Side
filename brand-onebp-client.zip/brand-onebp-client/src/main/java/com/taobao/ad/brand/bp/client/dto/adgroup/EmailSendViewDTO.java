package com.taobao.ad.brand.bp.client.dto.adgroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.List;

@Data
public class EmailSendViewDTO extends BaseViewDTO {
    /**
     * 发送人
     * */
    private List<String> emailTos;

    /**
     * 标题
     * */
    private String title;
    /**
     * 内容
     * */
    private String content;

    private Long adgroupId;
}
