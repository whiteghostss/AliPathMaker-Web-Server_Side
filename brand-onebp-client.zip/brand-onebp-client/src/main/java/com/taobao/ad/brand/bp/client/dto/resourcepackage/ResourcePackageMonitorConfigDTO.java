package com.taobao.ad.brand.bp.client.dto.resourcepackage;

import com.alibaba.hermes.framework.dto.DTO;
import lombok.Data;

@Data
public class ResourcePackageMonitorConfigDTO implements DTO {
    /**
     * 支持三方监测链接
     * @see com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum
     */
    private Integer supportMonitor;

    /**
     *监测链接配置粒度
     * @see com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupMonitorDimensionEnum
     */
    private Integer monitorDimension;

    /**
     *分端配置
     * @see com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum
     */
    private Integer splitConfig;
}
