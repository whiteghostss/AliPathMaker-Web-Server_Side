package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaign.audience.CampaignTargetViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdViewDTO;
import com.alibaba.ad.brand.dto.campaign.dooh.CampaignDoohViewDTO;
import com.alibaba.ad.brand.dto.campaign.price.DayPriceViewDTO;
import com.alibaba.ad.brand.dto.campaign.creative.CampaignCreativeControllerViewDTO;
import com.alibaba.ad.brand.dto.campaign.realtime.CampaignRealTimeOptimizeViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignShowmaxCrowdViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryViewDTO;
import com.alibaba.ad.brand.dto.campaign.keyword.CampaignKeywordViewDTO;
import com.alibaba.ad.brand.dto.frequency.FrequencyViewDTO;
import com.alibaba.ad.brand.dto.monitor.ThirdMonitorUrlViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignInquiryAssignTypeEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignProductConfigTypeEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

/**
 * @author yuanxinxi
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CampaignPageViewDTO extends BaseViewDTO {

    private static final long serialVersionUID = -2349498856022254535L;
    /**
     * 计划id
     */
    private Long id;

    /**
     * 补量计划对应的主计划id
     */
    private Long sourceCampaignId;

    /**
     * 计划名称
     */
    private String name;
    /**
     * 分组id
     */
    private Long saleGroupId;
    /**
     * 刊例产品名称
     */
    private String publishProductName;

    /**
     * 高级分组类型
     * @see BrandCampaignProductConfigTypeEnum
     */
    private Integer productConfigType;

    /**
     * 订单id
     */
    private Long campaignGroupId;
    /**
     * 订单名称
     */
    private String campaignGroupName;
    /**
     * 资源类型
     */
    private String sspResourceType;
    /**
     * 资源类型名称
     */
    private String sspResourceTypeDesc;
    /**
     * 售卖类型  购买/赠送/补量
     */
    private  Integer saleType;
    /**
     * 售卖类型  购买/赠送/补量
     */
    private  String saleTypeDesc;
    /**
     * 是否联合控量  0：非联合 1：联合
     */
    private Integer isUnionControlFlow;

    /**
     * ssp产品id
     */
    private  Long sspProductId;
    /**
     * ssp产品uuid
     */
    private  Long sspProductUuid;
    /**
     * 预定单位
     */
    private  Integer sspRegisterUnit;
    /**
     * 预定单位描述
     */
    private  String sspRegisterUnitDesc;
    /**
     * 预定方式
     * 合约保量GD 1
     * 合约不保量 2
     * 独占 3
     * 程序化PDB 4
     * 程序化PD 5
     */
    private  Integer sspRegisterManner;
    /**
     * 预定方式
     */
    private  String sspRegisterMannerDesc;
    /**
     * 开始时间
     */
    private Date startTime;
    /**
     * 结束时间
     */
    private  Date endTime;
    /**
     * 状态
     */
    private  Integer status;
    /**
     * 状态
     */
    private  String statusDesc;
    /**
     * 预定量
     */
    private Long amount;
    /**
     * CPT预定量
     */
    private Long cptAmount;
    /**
     * 刊例价
     */
    private  List<DayPriceViewDTO> publishDayPriceViewDTOList;
    /**
     * 净价
     */
    private  List<DayPriceViewDTO> discountDayPriceViewDTOList;
    /**
     * 刊例总价
     */
    private Long publishTotalMoney;
    /**
     * 净总价
     */
    private Long discountTotalMoney;
    /**
     * 资源id
     */
    private Long  sspResourceId;
    /**
     * 资源名称
     */
    private String  sspResourceName;
    /**
     * 媒体名称
     */
    private String  sspMediaName;
    /**
     * ssp子业务线名称
     */
    private String  sspProductLineName;

    /**
     * 售卖产品线名称
     */
    private Integer  saleProductLine;
    /**
     * 售卖产品线名称
     */
    private String  saleProductLineName;
    /**
     * 预算比例
     */
    private Integer budgetRatio;

    /**
     * 1：一级计划
     * 2：二级计划
     * @see BrandCampaignLevelEnum
     */
    private Integer campaignLevel;
    /**
     * 业务线
     */
    private String businessLineName;
    /**
     * 区间分配策略
     * 1：分天 （BY_DAY）
     * 2：智能 （INTELLIGENCE ）
     * @see BrandCampaignInquiryAssignTypeEnum
     */
    private Integer inquiryAssignType;
    /**
     * 采购行IDs
     */
    private List<Long> purchaseRowIds;
    /**
     * 询量行IDs
     */
    private List<Long> inquiryRowIds;
    /**
     *  pdtype
     */
    private Integer pdType;

    /**
     *  timeLength
     */
    private Integer timeLength;
    /**
     * 推送比
     */
    private Integer sspPushSendRatio;
    /**
     * 推送比
     */
    private String subSplitCode;
    /**
     * 是否投中扩量
     */
    private Integer isCastingExpand;
    /**
     * 分目标优化
     */
    private Integer optimizeTarget;
    /**
     * 其他定向
     */
    private List<CampaignTargetViewDTO> campaignTargetViewDTOList;
    /**
     * 频控信息
     */
    private FrequencyViewDTO frequencyViewDTO;
    /**
     * 计划第一次上线时间
     */
    private Date firstOnlineTime;
    /**
     * 区间折后价
     */
    private Long settlePrice;

    private Integer sspMediaScope;
    private Integer sspProductLineId;
    /**
     * 风险安全IP
     */
    private Integer isSupportSafeIp;
    private String isSupportSafeIpDesc;

    /**
     * 人群定向
     */
    private List<CampaignCrowdViewDTO> campaignCrowdViewDTOList;
    /**
     * 二级计划列表
     */
    private List<CampaignPageViewDTO> subCampaignPageViewDTOList;
    /**
     * 询锁量信息
     */
    private List<CampaignInquiryViewDTO> campaignInquiryViewDTOList;
    /**
     *特秀实时优选
     */
    private CampaignRealTimeOptimizeViewDTO campaignRealTimeOptimizeViewDTO;
    /**
     * 创意控制属性
     */
    private CampaignCreativeControllerViewDTO campaignCreativeControllerViewDTO;

    /**
     * showmax效果预估
     */
    private CampaignShowmaxCrowdViewDTO campaignShowmaxCrowdViewDTO;

    /**
     * 计划锁量有效期
     */
    private Date lockExpireTime;

    /**
     * 计划锁量成功时间
     */
    private Date lockCallBackTime;

    /**
     * 自动释量状态
     */
    private InventoryAutoReleaseWarningInfoViewDTO inventoryAutoReleaseWarningInfoViewDTO;
    /**
     * 计划支持的频控类型
     * @see com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignFrequencyTargetEnum
     */
    private Integer campaignFrequencyTarget;

    /**
     * 一次请求多次曝光是否需过滤
     * @see com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignSessionFilterEnum
     */
    private Integer sessionFilter;

    /**
     * 资源产品ID（资源包商家模版包装二级产品后的ID）
     */
    private Long resourcePackageProductId;
    /**
     * 业务场景id
     */
    private Integer sceneId;

    /**
     * PDB场景-三方dsp_id
     */
    private Long dspId;

    /**
     * 监测链接配置粒度
     * 分组/计划/单元
     **/
    private Integer monitorDimension;

    /**
     * 是否支持分端监测
     * 是/否
     */
    private Integer splitConfig;

    /**
     * 第三方监测
     */
    private List<ThirdMonitorUrlViewDTO> thirdMonitorUrlList;

    /**
     * 加购行ID
     */
    private Long cartItemId;
    /**
     * SPU_ID
     */
    private Long spuId;
    /**
     * SKU_ID
     */
    private Long skuId;

    /**
     * pub_deal_id
     */
    private Long pubDealId;
    /**
     * 套餐包id
     */
    private Long bundleId;

    /**
     * 关键词
     */
    private CampaignKeywordViewDTO campaignKeywordViewDTO;

    /**
     * 天攻
     */
    private CampaignDoohViewDTO campaignDoohViewDTO;
}