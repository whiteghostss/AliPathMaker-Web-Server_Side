package com.taobao.ad.brand.bp.client.enums.report;

import com.taobao.ad.brand.bp.client.enums.CommonEnum;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;

/**
 * 异步任务类型
 * @author yuncheng.lyc
 * @date 2023/3/7
 **/
@AllArgsConstructor(access = AccessLevel.PACKAGE)
public enum ReportTaskTypeStatusEnum implements CommonEnum {

    /**
     * 自定义查询
     */
    TYPE_CUSTOM(1, "自定义查询"),
    /**
     * 大促归因
     */
    TYPE_PROMOTION(2, "大促归因"),
    /**
     * 直播归因
     */
    TYPE_LIVE(3, "直播归因");

    private final Integer value;
    private final String desc;

    @Override
    public int getValue() {
        return value;
    }

    @Override
    public String getDesc() {
        return desc;
    }
}
