package com.taobao.ad.brand.bp.client.dto.effect;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.Date;

/**
 * 效果广告主
 * */
@Data
public class DirectAdvertiserSettingViewDTO extends BaseViewDTO {

    /**
     * direct_advertiser.id
     */
    private Long id;
    /**
     * 代投的memberId
     */
    private Long customMemberId;
    /**
     * 计划ID
     */
    private Long campaignId;
    /**
     * 子计划ID
     */
    private Long subCampaignId;
}
