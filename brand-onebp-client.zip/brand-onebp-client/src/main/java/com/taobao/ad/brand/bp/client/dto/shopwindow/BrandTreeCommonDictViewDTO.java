package com.taobao.ad.brand.bp.client.dto.shopwindow;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/6/27
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class BrandTreeCommonDictViewDTO extends BrandCommonDictViewDTO {

    /**
     * 子节点
     * todo 注意填充name与previous的相关属性
     */
    private List<BrandTreeCommonDictViewDTO> childList;
}
