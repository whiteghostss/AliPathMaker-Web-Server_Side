package com.taobao.ad.brand.bp.client.enums.resource;

import lombok.Getter;

/**
 * 0ios 1安卓 5不限
 * @author ximu
 * @date 2023/7/20
 */
@Getter
public enum AdzoneOsEnum {
    IOS(0, "IOS"),
    ANDROID(1, "安卓"),
    ALL(5, "不限")
    ;
    private final Integer value;
    private final String desc;

    AdzoneOsEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }
}
