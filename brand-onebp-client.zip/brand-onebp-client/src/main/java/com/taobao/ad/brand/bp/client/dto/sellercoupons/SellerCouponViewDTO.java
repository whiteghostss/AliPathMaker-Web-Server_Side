package com.taobao.ad.brand.bp.client.dto.sellercoupons;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @Author: PhilipFry
 * @createTime: 2023年09月14日 11:40:45
 * @Description: 商家优惠券ViewDTO
 */
@Data
public class SellerCouponViewDTO extends BaseViewDTO {
    private Long id;             //id
    private Date gmtCreated;     //获取时间
    private Date gmtModified;    //修改时间
    private Long supplierId;     //商户ID
    private String activityIds;    //活动集
    private String title;          //券名称
    private String pictures;       //券图片
    private String skin;           //券皮肤
    private String instruction;    //使用说明
    private String memo;           //备注
    private Date applyStartTime; //上架时间
    private Date applyEndTime;   //下架时间
    private Integer supplierType;   //商户类型
    private Integer status;         //状态信息
    private Integer couponType;     //券类型
    private Integer businessUnit;   //所属商业单元
    private Long totalCount;     //券总量
    private Integer options;
    private String outCouponId;    //外部关联ID    关联模板ID
    private Integer outCouponType;  //外部关联类型
    private Long amount;         //面额
    private String extend2;        //其它
    private Long templateCode;
    private Long brandId;        //品牌ID
    private Integer brandType;      //品牌类型
    private String brandName;      //品牌名称
    private String providerKey;
    private String couponTag;      //券的标识
    private Date startTime;      //优惠的开始时间
    private Date endTime;        //优惠的结束时间
    private Long startFee;       //满足金额阀值
    private String terminals;
    private Long categoryId;
    private String categoryName;
    private Long shopId;
    private String shopName;
    private Integer sellerType;
    private String sellerNick;
    private List<Long> itemIds;        //商品集
    private Long applyCount;
    private Long personLimitCount;
    private Long reserveCount;
    private Long discountRate;
    private Long spreadId;
    private String applyPlace;
    private String uuid;           //券传播属性全局唯一（替代主键ID）
    private List<Long> outBinds;       //绑定集,卡券开放，绑定外部推广渠道，如ISVappkey
    private Integer effectiveInterval;  //生效时间间隔
    private Integer outStatus;      //外部状态
    private Integer fundIds;        //资金单
    private Integer groupNum; //分组用，分组数量
    private Map</** rangeType */Short, List</** participageId */String>> groupElements;
    private String participateIdMap;    //分组元素Id列表
    private List<String> poiIds; //门店ids
    private List<String> backItemIds; //后端商品ids
    private String marketPlace;   //市场来源
    private List<String> itemIdArray;//分组中商品集合
    private List<String> sellerIdArray;//分组中卖家集合
    private List<String> channels;//可用渠道集合

}
