package com.taobao.ad.brand.bp.client.enums.dmp;

import lombok.Getter;

/**
 * @author yanjingang
 * @date 2025/2/18
 */
@Getter
public enum DmpItemLevelEnum {
    HOT(1, "爆品"),
    POTENTIAL(2, "成长品"),
    TAIL(3, "平销品"),
    NEW(5, "新品");

    private Integer code;
    private String desc;
    DmpItemLevelEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }
    public static DmpItemLevelEnum getByCode(Integer code) {
        for (DmpItemLevelEnum itemLevel : DmpItemLevelEnum.values()) {
            if (itemLevel.code.equals(code)) {
                return itemLevel;
            }
        }
        return null;
    }
}
