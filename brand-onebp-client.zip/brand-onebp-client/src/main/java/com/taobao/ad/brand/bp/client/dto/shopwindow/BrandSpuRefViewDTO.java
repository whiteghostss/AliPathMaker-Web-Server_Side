package com.taobao.ad.brand.bp.client.dto.shopwindow;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/6/26
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class BrandSpuRefViewDTO extends BaseViewDTO {

    /**
     * 主键ID
     */
    private Long id;

    /**
     * 产品橱窗spu id
     */
    private Long spuId;

    /**
     * ref类型
     * @see com.taobao.ad.brand.perform.client.enums.shopwindow.SpuRefTypeEnum
     */
    private Integer refType;

    /**
     * ref id
     */
    private Long refId;

    /**
     * 样式ref
     */
    private BrandSpuCreativeStyleRefViewDTO creativeStyleRef;

    /**
     * spu tag ref
     */
    private BrandSpuTagRefViewDTO tagRef;

    /**
     * spu saleGroup ref
     */
    private BrandSpuSaleGroupRefViewDTO saleGroupRef;
}
