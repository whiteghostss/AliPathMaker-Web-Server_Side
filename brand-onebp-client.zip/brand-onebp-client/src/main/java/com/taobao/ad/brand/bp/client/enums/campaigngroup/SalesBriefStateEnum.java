package com.taobao.ad.brand.bp.client.enums.campaigngroup;

import com.taobao.ad.brand.bp.client.enums.CommonEnum;

/**
 * @author yanjingang
 * @date 2023/3/12
 */
public enum SalesBriefStateEnum implements CommonEnum {
    UNKNOWN(0, "未知"),
    DELETED(-1, "已删除"),
    EDITED(1, "草稿"),
    CONFIRMED(2, "配置完成"),
    EXECUTE_ING(3, "执行中"),
    UNLOCKED(4, "改单配置中"),
    UNLOCK_CONFIRMED(5, "改单配置完成"),
    EXECUTE_FINISHED(6, "执行完成"),
    CAST_STOP_ING(7, "停投中"),
    CAST_STOPPED(13, "停投待实结"),
    REAL_SETTLE_ING(8, "实结中"),
    REAL_SETTLED(9, "已实结"),
    COMPLETED(10, "已结案"),
    CANCEL_ING(11, "撤单中"),
    CANCELED(12, "已撤单");
    ;

    SalesBriefStateEnum(int value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private int value;
    private String desc;

    @Override
    public int getValue() {
        return value;
    }

    @Override
    public String getDesc() {
        return desc;
    }
}
