package com.taobao.ad.brand.bp.client.api.creative;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.ad.brand.dto.adgroup.CreativeRefViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.brand.dto.creative.materialgroup.MaterialGroupViewDTO;
import com.alibaba.hermes.framework.api.CommandAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeBatchImportParamViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeEngineViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeGenerateViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.crop.MalusCropResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.notice.CreativeRefCallbackNoticeViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.notice.CreativeRejectMsgViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportTaskViewDTO;

import java.util.List;
import java.util.Map;

public interface BizCreativeCommandService extends CommandAPI {
    String TAG = "Creative";

    /**
     * 新建创意
     *
     * @param context
     * @param creativeViewDTO
     * @return campaignGroupId
     */
    @ProcessEntrance(name = "新建创意", desc = "新建创意", opType = OpType.add, tag = TAG)
    SingleResponse<Long> addCreative(ServiceContext context, CreativeViewDTO creativeViewDTO);

    /**
     * 更新创意
     *
     * @param context
     * @param creativeViewDTO
     * @return
     */
    @ProcessEntrance(name = "更新创意", desc = "更新创意", opType = OpType.update, tag = TAG)
    SingleResponse<Integer> updateCreative(ServiceContext context, CreativeViewDTO creativeViewDTO);

    /**
     * 更新创意主信息（目前只支持修改名称和起止日期）
     *
     * @param context
     * @param creativeViewDTO
     * @return
     */
    @ProcessEntrance(name = "更新创意主信息", desc = "更新创意主信息", opType = OpType.update, tag = TAG)
    SingleResponse<Integer> updateCreativePart(ServiceContext context, CreativeViewDTO creativeViewDTO);

    /**
     * 创意预览保存
     *
     * @param context
     * @param creativeViewDTO
     * @return
     */
    @ProcessEntrance(name = "创意预览保存", desc = "创意预览保存", opType = OpType.update, tag = TAG)
    SingleResponse<Integer> updateCreativePreview(ServiceContext context, CreativeViewDTO creativeViewDTO);

    /**
     * 更新创意审核状态
     *
     * @param context
     * @param creativeViewDTO
     * @return
     */
    @ProcessEntrance(name = "更新创意审核状态", desc = "更新创意审核状态", opType = OpType.update, tag = TAG)
    SingleResponse<Integer> updateCreativeAudit(ServiceContext context, CreativeViewDTO creativeViewDTO);

    /**
     * 解除创意绑定单元
     *
     * @param context
     * @param adgroupIds
     * @param creativeId
     * @return
     */
    @ProcessEntrance(name = "解除创意绑定单元", desc = "解除创意绑定单元", opType = OpType.update, tag = TAG)
    SingleResponse<Integer> unBindCreative(ServiceContext context, List<Long> adgroupIds, Long creativeId);

    /**
     * 无视校验解除创意绑定单元
     *
     * @param context
     * @param adgroupIds
     * @param creativeId
     * @return
     */
    @ProcessEntrance(name = "无视校验解除创意绑定单元", desc = "无视校验解除创意绑定单元", opType = OpType.update, tag = TAG)
    SingleResponse<Integer> delBindCreative(ServiceContext context, List<Long> adgroupIds, Long creativeId);

    /**
     * 复制创意并设置为直接投创意
     *
     * @param context
     * @param creativeId
     * @return
     */
    @ProcessEntrance(name = "复制创意并设置为直接投创意", desc = "复制创意并设置为直接投创意", opType = OpType.update, tag = TAG)
    SingleResponse<Long> copyCreativeAsDirect(ServiceContext context, Long creativeId);


    /**
     * 批量创意绑定单元
     *
     * @param context
     * @param creativeRefViewDTOList
     * @return
     */
    @ProcessEntrance(name = "批量创意绑定单元", desc = "批量创意绑定单元", opType = OpType.update, tag = TAG)
    MultiResponse<CreativeRefViewDTO> addBatchCreativeRef(ServiceContext context, List<CreativeRefViewDTO> creativeRefViewDTOList);

    /**
     * 批量创意绑定单元
     *
     * @param context
     * @param creativeRefViewDTOList
     * @return
     */
    @ProcessEntrance(name = "批量创意绑定单元回调", desc = "批量创意绑定单元回调", opType = OpType.update, tag = TAG)
    MultiResponse<CreativeRefViewDTO> addBatchCreativeRefForCallBack(ServiceContext context, List<CreativeRefViewDTO> creativeRefViewDTOList);

    /**
     * 同步资质审核状态
     *
     * @param serviceContext
     * @param qualifyJson
     * @return
     */
    @ProcessEntrance(name = "同步资质审核状态", desc = "同步资质审核状态", opType = OpType.update, tag = TAG)
    Response syncQualificationAuditStatus(ServiceContext serviceContext, String qualifyJson);

    /**
     * 同步创意送审数据
     *
     * @param serviceContext
     * @param creativeJson
     * @return
     */
    @ProcessEntrance(name = "同步创意送审数据", desc = "同步创意送审数据", opType = OpType.update, tag = TAG)
    Response syncCreativeSwitch(ServiceContext serviceContext, String creativeJson);

    /**
     * @param context
     * @param creativeRejectMsgViewDTO
     * @return
     */
    @ProcessEntrance(name = "创意审核被拒", desc = "创意审核被拒", opType = OpType.update, tag = TAG)
    Response creativeReject(ServiceContext context, CreativeRejectMsgViewDTO creativeRejectMsgViewDTO);

    /**
     * @param context
     * @param creativeViewDTO
     * @return
     */
    @ProcessEntrance(name = "特秀加购创意同步主站库存中心", desc = "特秀加购创意同步主站库存中心", opType = OpType.update, tag = TAG)
    Response syncItemBizInfo(ServiceContext context, CreativeViewDTO creativeViewDTO);

    /**
     * 无视校验删除创意
     * 有白名单控制
     * 自动化用例中直接调用：删除创意，然后删除创意绑定关系
     *
     * @param context
     * @param creativeIds
     * @return
     */
    @ProcessEntrance(name = "删除创意", desc = "deleteCreative", opType = OpType.delete, tag = TAG)
    MultiResponse<Long> deleteCreatives(ServiceContext context, List<Long> creativeIds);

    /**
     * 同步主创意审核状态
     *
     * @param serviceContext
     * @param creativeId
     * @param memberId
     * @return
     */
    @ProcessEntrance(name = "同步主创意审核状态", desc = "同步主创意审核状态", opType = OpType.update, tag = TAG)
    Response creativeStatusQualityInfo(ServiceContext serviceContext, Long creativeId, Long memberId);

    /**
     * 新建、编辑创意批量导入任务
     *
     * @param context
     * @param taskViewDTO
     * @return
     */
    @ProcessEntrance(name = "新建、编辑创意批量导入任务", desc = "新建、编辑创意批量导入任务", opType = OpType.add, tag = TAG)
    SingleResponse<Long> addBatchImportTask(ServiceContext context, ReportTaskViewDTO taskViewDTO);

    @ProcessEntrance(name = "批量导入编辑创意", desc = "批量编辑创意", opType = OpType.add, tag = TAG)
    Response batchUpdateCreative(ServiceContext context, CreativeBatchImportParamViewDTO creativeBatchImportParamViewDTO);

    @ProcessEntrance(name = "创意单元绑定关系开关", desc = "创意单元绑定关系开关", opType = OpType.update, tag = TAG)
    SingleResponse<Boolean> creativeRefSwitch(ServiceContext context, List<CreativeRefViewDTO> creativeRefViewDTOList);

    @ProcessEntrance(name = "生成创意协议", desc = "生成创意协议", opType = OpType.add, tag = TAG)
    SingleResponse<CreativeEngineViewDTO> generateCreativeEngine(ServiceContext context, CreativeViewDTO creativeViewDTO);

    /**
     * 异步拓版素材
     * <p>并发控制：基于materialGroupId分布式锁</p>
     *
     * @param context
     * @param materialGroupId
     * @return
     */
    @ProcessEntrance(name = "拓版素材", desc = "拓版素材", opType = OpType.add, tag = TAG)
    SingleResponse<MaterialGroupViewDTO> cropMaterialGroup(ServiceContext context, Long materialGroupId);

    @ProcessEntrance(name = "拓版结果回调", desc = "拓版结果回调", opType = OpType.add, tag = TAG)
    SingleResponse<MalusCropResultViewDTO> cropMaterialGroupCallback(ServiceContext context, MalusCropResultViewDTO malusCropResultViewDTO);

    /**
     * 素材组审核回调
     * @param context
     * @param materialGroupId
     * @return
     */
    @ProcessEntrance(name = "素材组拓版成功回调", desc = "素材组拓版成功回调", opType = OpType.add, tag = TAG)
    SingleResponse<Long> cropMaterialGroupSuccessCallback(ServiceContext context, Long materialGroupId);

    @ProcessEntrance(name = "计算创意对客状态", desc = "计算创意对客状态", opType = OpType.add, tag = TAG)
    SingleResponse<Integer> calculateCreativeShowAuditStatus(ServiceContext context, CreativeViewDTO creativeViewDTO);

    @ProcessEntrance(name = "创意绑定操作回调用", desc = "创意绑定操作回调用", opType = OpType.add, tag = TAG)
    SingleResponse<Integer> creativeRefChangeCallback(ServiceContext context, CreativeRefCallbackNoticeViewDTO creativeRefCallbackNoticeViewDTO);

    @ProcessEntrance(name = "根据宝贝生成视觉", desc = "根据宝贝生成视觉", opType = OpType.add, tag = TAG)
    SingleResponse<CreativeGenerateViewDTO> generateImages(ServiceContext serviceContext, CreativeGenerateViewDTO creativeGenerateViewDTO);

    @ProcessEntrance(name = "根据视觉生成创意", desc = "根据视觉生成创意", opType = OpType.add, tag = TAG)
    SingleResponse<CreativeGenerateViewDTO> generateCreative(ServiceContext serviceContext, CreativeGenerateViewDTO creativeGenerateViewDTO);
}
