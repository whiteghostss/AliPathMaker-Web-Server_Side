package com.taobao.ad.brand.bp.client.api.motion;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.motion.IntelligentMotionViewDTO;
import com.taobao.ad.brand.bp.client.dto.motion.IntelligentStrategyViewDTO;
import com.taobao.ad.brand.bp.client.dto.motion.query.MotionQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.motion.query.StrategyQueryViewDTO;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/18
 **/
public interface BizIntelligentStrategyQueryService extends QueryAPI {

    String TAG = "IntelligentStrategy";

    /**
     * 智能策略详情
     * @param serviceContext
     * @param strategyId
     * @return
     */
    @ProcessEntrance(name = "策略详情", desc = "策略详情", opType = OpType.query, tag = TAG)
    SingleResponse<IntelligentStrategyViewDTO> getIntelligentStrategyById(ServiceContext serviceContext, Long strategyId);

    @ProcessEntrance(name = "策略列表不分页", desc = "策略列表不分页", opType = OpType.query, tag = TAG)
    MultiResponse<IntelligentStrategyViewDTO> intelligentStrategyList(ServiceContext serviceContext, StrategyQueryViewDTO queryViewDTO);
}
