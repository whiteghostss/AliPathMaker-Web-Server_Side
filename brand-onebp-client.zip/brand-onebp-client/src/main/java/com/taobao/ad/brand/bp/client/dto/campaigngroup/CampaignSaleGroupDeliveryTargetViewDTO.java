package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * BP设置的优化选项viewDTO
 * @author yunhu.myh@taobao.com
 * @date 2023年08月13日
 * */
@Data
public class CampaignSaleGroupDeliveryTargetViewDTO extends BaseViewDTO {
    /**
     * 交付指标
     * com.alibaba.ad.nb.ssp.constant.newproduct.DeliveryTargetEnum
     */
    private Integer deliveryTarget;
    /**
     * 资源包设置的值
     */
    private Integer resourceDeliveryTargetValue;
    /**
     * 资源包设置的开关
     */
    private Integer customerSwitch;

    /**
     * 数字或者比例(35.47% -> 3547)
     */
    private Integer deliveryTargetValue;

}
