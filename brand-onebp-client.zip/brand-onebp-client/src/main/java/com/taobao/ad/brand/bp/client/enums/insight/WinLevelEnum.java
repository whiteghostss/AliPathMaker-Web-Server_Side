package com.taobao.ad.brand.bp.client.enums.insight;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 报表benchmark类型
 *
 * @author yuncheng.lyc
 * @date 2023/3/7
 **/
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@Getter
public enum WinLevelEnum {

    /**
     * 初创
     */
    LEVEL_1(0d, 200d),

    /**
     * 成长
     */
    LEVEL_2(200d, 400d),

    /**
     * 成熟
     */
    LEVEL_3(400d, 600d),

    /**
     * 领先
     */
    LEVEL_4(600d, 800d),

    /**
     * 顶尖
     */
    LEVEL_5(800d, 1000d),

    ;

    private final Double from;
    private final Double to;

    /**
     * 判断value属于哪一个层级
     * @param value
     * @return
     */
    public static WinLevelEnum ofLevel(Double value) {
        for (WinLevelEnum typeEnum : WinLevelEnum.values()) {
            if (value >= typeEnum.getFrom() && value < typeEnum.getTo()) {
                return typeEnum;
            }
        }
        if (value >= LEVEL_5.getTo()) {
            return LEVEL_5;
        }
        return LEVEL_1;
    }
}
