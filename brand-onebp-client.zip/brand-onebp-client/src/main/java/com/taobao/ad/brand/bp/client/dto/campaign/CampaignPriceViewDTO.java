package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @description: PriceEnginePublishPriceViewDTO
 * @date: 2023/3/4 11:06
 * @author: yuanxinxi
 * @version: 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CampaignPriceViewDTO extends BaseViewDTO {

    /**
     * 一级计划ID
     */
    private Long campaignId;
    /**
     * 净总价
     */
    private Long discountTotalMoney;
    /**
     * 预算比例
     */
    private Integer budgetRatio;
    /**
     * 流量比例
     */
    private Long mediaFlowRatio;

    /**
     * cpt的总预订量
     */
    private Long cptAmount;

    /**
     * 价格信息（包含刊例价、折扣价）
     */
    private List<CampaignDayPriceViewDTO> priceInfos;
}
