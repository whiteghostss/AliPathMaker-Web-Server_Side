package com.taobao.ad.brand.bp.client.enums.keyword;

import lombok.Getter;

@Getter
public enum KeywordEstimateTypeEnum {
    KW_PV("kw_pv", "词维度"),
    KW_ESTIMATE_SCOPE("kw_estimate_scope", "全部词的日均预估pv范围");

    private String code;
    private String desc;

    KeywordEstimateTypeEnum(String code, String desc){
        this.code = code;
        this.desc = desc;
    }
}
