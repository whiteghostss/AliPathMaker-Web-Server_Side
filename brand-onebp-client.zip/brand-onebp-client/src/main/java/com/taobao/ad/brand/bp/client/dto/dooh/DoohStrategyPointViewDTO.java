package com.taobao.ad.brand.bp.client.dto.dooh;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.enums.dooh.DoohStrategyPointTypeEnum;
import lombok.Data;

import java.math.BigDecimal;

/**
 * 天攻点位
 */
@Data
public class DoohStrategyPointViewDTO extends BaseViewDTO {

    /**
     * 点位ID
     */
    private String id;

    /**
     * 点位名称
     */
    private String name;

    /**
     * 点位类型
     * @see DoohStrategyPointTypeEnum
     */
    private Integer type;

    /**
     * 户外资源场景
     */
    private Integer deviceType;

    private String deviceTypeName;

    /**
     * 点位地址
     */
    private String address;

    /**
     * 点位图片oss地址
     */
    private String url;

    /**
     * 点位tgi指数（权重）
     */
    private BigDecimal tgi;

    /**
     * 该点位是否被指定
     */
    private Integer isAdd;

    /**
     * 该点位是否被屏蔽
     */
    private Integer isRemove;
}
