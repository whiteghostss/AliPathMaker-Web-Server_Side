package com.taobao.ad.brand.bp.client.dto.mr.gif;

import com.taobao.ad.brand.bp.client.dto.mr.FileSizeViewDTO;
import com.taobao.ad.brand.bp.client.dto.mr.FileStoreLimitViewDTO;
import com.taobao.ad.brand.bp.client.dto.mr.ItemContentViewDTO;
import lombok.Data;

import java.util.List;

/**
 * @author jixiu.lj
 * @date 2023/3/21 11:51
 */
@Data
public class GifRuleViewDTO extends ItemContentViewDTO {
    private List<FileSizeViewDTO> fileSize;
    private FileStoreLimitViewDTO fileStoreLimit;
}
