package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

@Data
public class KeywordAccessViewDTO extends BaseViewDTO {

    private Boolean allowAccess;

    private String reason;
}
