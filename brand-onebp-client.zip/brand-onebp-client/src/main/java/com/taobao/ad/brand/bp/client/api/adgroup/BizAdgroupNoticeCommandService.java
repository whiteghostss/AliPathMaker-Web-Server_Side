package com.taobao.ad.brand.bp.client.api.adgroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.CommandAPI;
import com.alibaba.hermes.framework.dto.response.Response;
import com.taobao.ad.brand.bp.client.dto.base.DRCMessageViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignEventEnum;

/**
 * @author ximu
 * @date 2023/7/26
 */
public interface BizAdgroupNoticeCommandService extends CommandAPI {

    String TAG = "Adgroup";

    @ProcessEntrance(name = "内容campaign更新完成通知", desc = "内容campaign更新完成通知", opType = OpType.update, tag = TAG)
    Response noticeContentCampaignChanged(ServiceContext serviceContext, Long campaignId, CampaignEventEnum eventEnum);

    @ProcessEntrance(name = "内容场景供应商新增媒体，监测媒体同步更新", desc = "内容场景供应商新增媒体，监测媒体同步更新", opType = OpType.add, tag = TAG)
    Response noticeContentMonitorAddMedia(ServiceContext serviceContext, DRCMessageViewDTO drcMessageViewDTO);

    @ProcessEntrance(name = "生成计划打底单元", desc = "生成计划打底单元", opType = OpType.add, tag = TAG)
    Response noticeGenerateBottomAdgroup(ServiceContext context, Long campaignId,CampaignEventEnum eventEnum);

    @ProcessEntrance(name = "生成计划优选单元", desc = "生成计划优选单元", opType = OpType.add, tag = TAG)
    Response noticeGenerateNReachAdgroup(ServiceContext context, Long campaignId,CampaignEventEnum eventEnum);
}
