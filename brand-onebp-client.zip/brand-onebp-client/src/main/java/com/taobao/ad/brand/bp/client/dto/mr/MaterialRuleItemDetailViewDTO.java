package com.taobao.ad.brand.bp.client.dto.mr;

import com.taobao.ad.brand.bp.client.dto.mr.audiorule.AudioRuleViewDTO;
import com.taobao.ad.brand.bp.client.dto.mr.gif.GifRuleViewDTO;
import com.taobao.ad.brand.bp.client.dto.mr.picrule.PicRuleViewDTO;
import com.taobao.ad.brand.bp.client.dto.mr.textrule.TextRuleViewDTO;
import com.taobao.ad.brand.bp.client.dto.mr.videorule.VideoRuleViewDTO;
import lombok.Data;

import java.util.List;

/**
 * @author jixiu.lj
 * @date 2023/3/21 11:39
 */
@Data
public class MaterialRuleItemDetailViewDTO {
    private Integer isOnline;
    private List<TextRuleViewDTO> textRuleDTOList;
    private List<PicRuleViewDTO> picRuleDTOList;
    private List<VideoRuleViewDTO> videoRuleDTOList;
    private List<AudioRuleViewDTO> audioRuleDTOList;
    private List<GifRuleViewDTO> gifRuleDTOList;
}
