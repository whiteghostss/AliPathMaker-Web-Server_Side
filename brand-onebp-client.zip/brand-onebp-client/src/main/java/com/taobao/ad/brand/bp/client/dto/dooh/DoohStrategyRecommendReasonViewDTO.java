package com.taobao.ad.brand.bp.client.dto.dooh;

import lombok.Data;

import java.util.Date;

/**
 * 天攻推荐理由
 */
@Data
public class DoohStrategyRecommendReasonViewDTO {

    /**
     * 设计概要
     */
    private String summary;

    /**
     * 策略更新时间
     */
    private Date gmtModified;

    /**
     * 优化建议
     */
    private String optimizateSuggestion;

    /**
     * 推荐理由
     */
    private String recommendedReason;
}
