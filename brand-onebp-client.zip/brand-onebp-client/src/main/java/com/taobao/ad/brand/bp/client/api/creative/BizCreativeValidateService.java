package com.taobao.ad.brand.bp.client.api.creative;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeValidateViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.MemberPageCheckViewDTO;

public interface BizCreativeValidateService extends QueryAPI {
    String TAG = "CreativeValidate";

    @ProcessEntrance(name = "校验落地页是否合规", desc = "校验落地页是否合规", opType = OpType.query, tag = TAG)
    SingleResponse<Boolean> checkLandingPage(ServiceContext context, String landingPage);

    @ProcessEntrance(name = "校验创意是否合规", desc = "校验创意是否合规", opType = OpType.query, tag = TAG)
    SingleResponse<CreativeValidateViewDTO> checkCreative(ServiceContext context, CreativeViewDTO creativeViewDTO);

    @ProcessEntrance(name = "创意送审错误回显", desc = "创意送审错误回显", opType = OpType.query, tag = TAG)
    SingleResponse<CreativeValidateViewDTO> preCheckCreative(ServiceContext context, CreativeViewDTO creativeViewDTO);

    @ProcessEntrance(name = "会员中心页校验", desc = "会员中心页校验", opType = OpType.query, tag = TAG)
    SingleResponse<MemberPageCheckViewDTO> memberPageCheck(ServiceContext serviceContext, Long sellerId);
}
