package com.taobao.ad.brand.bp.client.dto.dooh;

import com.taobao.ad.brand.bp.client.dto.base.BaseQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.dooh.DoohStrategyPointTypeEnum;
import lombok.Data;

import java.util.List;

@Data
public class DoohStrategyPointQueryViewDTO extends BaseQueryViewDTO {

    /**
     * 策略ID
     */
    private Long strategyId;

    /**
     * 点位来源
     * @see com.taobao.ad.brand.bp.client.enums.dooh.DoohStrategyPointSourceEnum
     */
    private Integer source;

    /**
     * 地域定向列表
     */
    private List<Integer> areaList;

    /**
     * 户外资源场景列表
     */
    private List<Integer> deviceTypeList;

    /**
     * 点位地址/名称模糊查询
     */
    private String keyword;

    /**
     * 点位类型：指定点位/删除点位
     * @see DoohStrategyPointTypeEnum
     */
    private Integer type;
}
