package com.taobao.ad.brand.bp.client.dto.message;

import java.util.List;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;

import com.taobao.ad.brand.bp.client.enums.message.MessageSendTypeEnum;
import lombok.Data;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/05/15
 */
@Data
public class MessageViewDTO extends BaseViewDTO {
    /**
     * memberId
     */
    private Long memberId;
    /**
     * 主题
     */
    private String subject;
    /**
     * 内容
     */
    private String content;
    /**
     * 收件人
     */
    private List<String> sendTo;
    /**
     * token
     */
    private String dingGroupToken;
    /**
     * @see MessageSendTypeEnum
     */
    private List<Integer> sendType;
}
