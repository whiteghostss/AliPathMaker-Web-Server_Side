package com.taobao.ad.brand.bp.client.dto.shopwindow;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/6/27
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class BrandShopWindowTemplateViewDTO extends BaseViewDTO {
    /**
     * ID
     */
    private Long id;

    private String name;

    /**
     * SSP模板ID
     */
    private Long sspTemplateId;

    /**
     * SSP资源标签
     */
    private List<BrandTagViewDTO> tagList;

    /**
     * 状态
     * ShopWindowTemplateStatusEnum
     */
    private Integer status;

    /**
     * 封面
     */
    private BrandCoverConfigViewDTO cover;

    /**
     * 封面
     */
    private BrandCoverConfigViewDTO subCover;

    /**
     * 模板描述
     */
    private String mark;

    /**
     * 资源类型
     */
    private String resourceType;

    /**
     * 资源类型名称
     */
    private String resourceTypeName;

    /**
     * 物料类型
     */
    private String materialType;

    /**
     * 物料类型名称
     */
    private String materialTypeName;


    private String productLineName;

    private String effectName;

    /**
     * 媒体域
     */
    private Integer mediaScope;
}
