package com.taobao.ad.brand.bp.client.dto.effect;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

@Data
public class EffectAdvertiserContractFundViewDTO extends BaseViewDTO {
    /**
     * 媒体侧广告主ID
     * */
    private Long directAdvertiserId;
    /**
     * 媒体ID
     * */
    private Long directMediaId;
    /**
     * 子合同ID
     * */
    private Long subContractId;
    /**
     * 总转入
     * */
    private Long transferIn;
    /**
     * 总转出
     * */
    private Long transferOut;
}
