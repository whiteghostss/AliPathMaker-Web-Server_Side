package com.taobao.ad.brand.bp.client.dto.base;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/23
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SelectedViewDTO extends BaseViewDTO {
    /**
     * ID
     */
    private Long id;

    /**
     * Name
     */
    private String name;

    /**
     * value
     */
    private String value;

    /**
     * 是否选中
     */
    private Boolean selected;

    /**
     * 是否客户必选（只有打包平台跨域子产品的联投媒体才使用该字段）
     */
    private Boolean required;
}
