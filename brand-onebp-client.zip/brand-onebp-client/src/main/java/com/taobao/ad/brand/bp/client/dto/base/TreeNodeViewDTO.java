package com.taobao.ad.brand.bp.client.dto.base;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TreeNodeViewDTO extends BaseViewDTO {

    private Long id;

    private Long parentId;

    private String value;

    private String name;

    // 前端页面是否必选（目前只有跨域产品的媒体定向需要使用该字段）
    private Boolean required;

    private List<TreeNodeViewDTO> children;
}
