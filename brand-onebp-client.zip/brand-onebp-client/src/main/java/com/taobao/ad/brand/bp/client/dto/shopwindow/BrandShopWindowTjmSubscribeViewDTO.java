package com.taobao.ad.brand.bp.client.dto.shopwindow;

import lombok.Data;

import java.util.Date;

/**
 * @author jixiu.lj
 * @date 2024/9/19 19:56
 */
@Data
public class BrandShopWindowTjmSubscribeViewDTO {

    /**
     * appId
     */
    private String appId;

    /**
     * appVersion
     */
    private String appVersion;

    /**
     * 千牛店铺后台pageId
     */
    private String pageId;

    /**
     * 订阅结束时间
     */
    private Date endTime;

    /**
     * 直客主账号淘宝userId
     */
    private Long loginMainTbNumId;
}
