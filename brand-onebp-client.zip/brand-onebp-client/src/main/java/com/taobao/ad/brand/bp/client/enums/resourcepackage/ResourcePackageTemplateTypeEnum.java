package com.taobao.ad.brand.bp.client.enums.resourcepackage;

/**
 * @author yanjingang
 * @date 2023/3/28
 */
public enum ResourcePackageTemplateTypeEnum {

    MARKETING(1, "招商模板"),
    CUSTOMER(2, "客户模版");

    private Integer value;
    private String desc;
    ResourcePackageTemplateTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public Integer getValue() {
        return value;
    }

    public String getDesc() {
        return desc;
    }

}
