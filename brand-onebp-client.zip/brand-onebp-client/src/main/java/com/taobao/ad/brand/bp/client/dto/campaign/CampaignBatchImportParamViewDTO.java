package com.taobao.ad.brand.bp.client.dto.campaign;

import com.taobao.ad.brand.bp.client.dto.tool.BatchImportParamViewDTO;
import lombok.Data;

import java.util.List;

/**
 * 计划批量导出从Excel中解析到的原始信息
 * @author jixiu.lj
 * @date 2023/8/31 20:01
 */
@Data
public class CampaignBatchImportParamViewDTO extends BatchImportParamViewDTO {
    /**
     * 订单id
     */
    private Long campaignGroupId;
    /**
     * 订单分组id
     */
    private Long saleGroupId;
    /**
     * 批量计划信息
     */
    private List<CampaignBatchImportRawViewDTO> campaignBatchImportRawViewDTOList;
}
