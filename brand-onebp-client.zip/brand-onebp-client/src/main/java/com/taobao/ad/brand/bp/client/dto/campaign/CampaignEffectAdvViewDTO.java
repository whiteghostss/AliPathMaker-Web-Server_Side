package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * 效果adv viewDTO
 * @author yunhu.myh@taobao.com
 * @date 2023年07月26日
 * */
@Data
public class CampaignEffectAdvViewDTO extends BaseViewDTO {

    /**
     * adv主键ID
     * */
    private Long advId;
    /**
     * 媒体侧advId
     * */
    private Long directAdvertiserId;
    /**
     * 当前余额
     * */
    private Long balance;

    /**
     * 已转入金额
     * */
    private Long transAmount;

    /**
     * 渠道ID
     * */
    private Long channelId;

    /**
     * 一级计划ID
     * */
    private Long campaignId;
    /**
     * 二级计划ID
     * */
    private Long subCampaignId;
    /**
     * 子合同ID
     * */
    private Long subContractId;
}
