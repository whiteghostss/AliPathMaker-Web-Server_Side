package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.CrowdViewDTO;
import lombok.Data;

import java.util.List;

/**
 * 分组人群viewDTO
 * @author yunhu.myh@taobao.com
 * @date 2023年07月26日
 * */
@Data
public class CampaignGroupSaleGroupCrowdInfoViewDTO extends BaseViewDTO {
    /**
     * 覆盖人数
     * */
    private Long coverage;
    /**
     * 人群list
     * */
    private List<CrowdViewDTO> crowdViewDTOList;
}
