package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaign.audience.CampaignCategoryTargetViewDTO;
import com.alibaba.ad.brand.dto.campaign.keyword.CampaignWordViewDTO;
import com.alibaba.ad.brand.dto.campaign.realtime.CampaignRealTimeOptimizeViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.CrowdViewDTO;
import lombok.Data;

import java.util.List;

/**
 * @author yanjingang
 * @date 2024/9/2
 */
@Data
public class CampaignRealTimeOptimizeInfoViewDTO extends BaseViewDTO {
    /**
     * 计划ID
     */
    private Long campaignId;
    /**
     * 是否支持黑盒人群配置 1-是；0-否
     * 临时方案
     */
    private Integer canConfigOptimize;

    /**
     *
     */
    private CampaignRealTimeOptimizeViewDTO optimizeConfig;
    /**
     * 是否支持添加自定义人群 1-是；0-否
     */
    private Integer canAddCrowd;
    /**
     * 自定义人群 + 场景定制人群
     */
    private List<CrowdViewDTO> crowdList;

    /**
     * 是否支持添加屏蔽人群 1-是；0-否
     */
    private Integer canAddBlockCrowd;
    /**
     * 屏蔽人群信息
     */
    private List<CrowdViewDTO> blockCrowdList;
    /**
     * 是否支持添加类目 1-是；0-否
     */
    private Integer canAddCategory;
    /**
     * 类目信息
     */
    private List<CampaignCategoryTargetViewDTO> categoryList;

    /**
     * 是否支持添加关键词 1-是；0-否
     */
    private Integer canAddKeyword;
    /**
     * 关键词信息
     */
    private List<CampaignWordViewDTO> campaignKeywordList;
}
