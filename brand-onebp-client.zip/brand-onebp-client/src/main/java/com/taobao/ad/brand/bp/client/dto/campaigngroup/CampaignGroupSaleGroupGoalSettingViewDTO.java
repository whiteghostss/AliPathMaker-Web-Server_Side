package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.List;

/**
 * 订单分组优化部分viewDTO
 * @author yunhu.myn@taobao.com
 * @date 2023年07月25日
 * */
@Data
public class CampaignGroupSaleGroupGoalSettingViewDTO extends BaseViewDTO {

    /**
     * 订单分组ID
     * */
    private Long saleGroupId;
    /**
     * 交付指标list
     * */
    private List<CampaignSaleGroupDeliveryTargetViewDTO> deliveryTargetList;
    /**
     * 优化指标list
     * */
    private List<Integer> optimizeTargetList;

    /**
     * 订单ID
     * */
    private Long campaignGroupId;

}
