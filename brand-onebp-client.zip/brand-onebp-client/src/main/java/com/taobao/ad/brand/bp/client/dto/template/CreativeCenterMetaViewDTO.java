package com.taobao.ad.brand.bp.client.dto.template;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.Map;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/3/4 16:43
 * @description ：海棠中心模板动态渲染参数
 * @modified By：
 */
@Data
public class CreativeCenterMetaViewDTO extends BaseViewDTO {

    private Long templateId;

    private String tabName;

    /**
     * 页面元数据
     */
    private Map<String, Map<String, Map<String, Object>>> metadata;

    /**
     * 页面回填数据，或者是默认值
     */
    private Map<String, Object> data;
}
