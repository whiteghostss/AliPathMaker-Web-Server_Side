package com.taobao.ad.brand.bp.client.enums.report;

import com.taobao.ad.brand.bp.client.enums.CommonEnum;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;

/**
 * 归因周期，1 7 15 30
 * @author yuncheng.lyc
 * @date 2023/3/7
 **/
@AllArgsConstructor(access = AccessLevel.PACKAGE)
public enum ReportTimeSpanEnum implements CommonEnum {

    /**
     * 1天
     */
    ONE(1, "1天"),
    /**
     * 7天
     */
    SEVEN(7, "7天"),
    /**
     * 15天
     */
    FIFTEEN(15, "15天"),
    /**
     * 30天
     */
    THIRTY(30, "30天"),
    /**
     * 30天
     */
    SIXTY(60, "60天");

    private final Integer value;
    private final String desc;

    @Override
    public int getValue() {
        return value;
    }

    @Override
    public String getDesc() {
        return desc;
    }
}
