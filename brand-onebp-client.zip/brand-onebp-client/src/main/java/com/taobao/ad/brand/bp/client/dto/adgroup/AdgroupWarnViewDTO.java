package com.taobao.ad.brand.bp.client.dto.adgroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.List;

@Data
public class AdgroupWarnViewDTO extends BaseViewDTO {
    private Long adgroupId;
    private List<String> warnCodeList;
}
