package com.taobao.ad.brand.bp.client.context;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * 计划库存回调通知上下文
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SmartCreativeAddCallbackNoticeContext {

    private ServiceContext serviceContext;

    private CreativeViewDTO creativeViewDTO;

}
