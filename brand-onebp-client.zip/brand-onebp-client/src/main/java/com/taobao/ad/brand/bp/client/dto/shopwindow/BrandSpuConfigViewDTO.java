package com.taobao.ad.brand.bp.client.dto.shopwindow;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.DateViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/6/26
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class BrandSpuConfigViewDTO extends BaseViewDTO {

    /**
     * 预览图
     */
    private List<BrandCoverConfigViewDTO> coverList;

    /**
     * spu描述
     */
    private String mark;

    /**
     * showCase
     */
    private List<BrandSpuShowCaseViewDTO> showCaseList;

    /**
     * 属性
     * 注意有顺序表达
     */
    private List<BrandCommonDictViewDTO> propertyList;

    /**
     * spu审核信息
     */
    private BrandSpuAuditInfoViewDTO spuAuditInfo;

    /**
     * 屏蔽周期
     */
    private List<DateViewDTO> blockDateList;
}
