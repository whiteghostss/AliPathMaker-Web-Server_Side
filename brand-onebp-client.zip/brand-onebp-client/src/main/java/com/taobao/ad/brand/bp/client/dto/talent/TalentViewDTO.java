package com.taobao.ad.brand.bp.client.dto.talent;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.List;

@Data
public class TalentViewDTO extends BaseViewDTO {

    /**
     * 达人ID
     */
    private String talentId;

    /**
     * 妈妈达人唯一标识
     */
    private String userId;

    /**
     * 媒体侧达人唯一标识
     */
    private String mediaUserId;
    /**
     * 对客媒体id
     */
    private Long customerOrientedMediaId;

    /**
     * 对客媒体名称
     */
    private String customerOrientedMediaName;

    /**
     * 达人昵称
     */
    private String nick;

    /**
     * 达人头像
     */
    private String avatar;

    /**
     * 达人主页链接
     */
    private String homePageUrl;

    /**
     * 粉丝数
     */
    private Long fans;

    /**
     * 所在省
     */
    private String province;

    /**
     * 所在市
     */

    private String city;

    /**
     * 预期cpm
     */

    private Double preCpm;

    /**
     * 接单率
     */

    private Double orderRate;

    /**
     * 完单率
     */

    private Double finishOrderRate;

    /**
     * 账号简介
     */

    private String accountDesc;

    /**
     * 所属机构
     */

    private String institution;

    /**
     * 默认刊例价
     */

    private Long priceValue;

    /**
     * 默认内容形式
     */

    private String contentType;

    /**
     * 性价比指数
     */

    private Double talentPp;

    /**
     * 传播力指数
     */

    private Double talentCi;

    /**
     * 种草力指数
     */

    private Double talentFi;

    /**
     * 纯净值(阳光值)指数
     */

    private Double talentTrustIdx;

    /**
     * 是否U选达人
     */
    private Integer isPrefer;

    /**
     * 达人报价
     */
    private List<TalentPriceViewDTO> prices;

    /**
     * 作品信息
     */
    private List<TalentWorkViewDTO> works;

}
