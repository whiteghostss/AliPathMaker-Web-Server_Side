package com.taobao.ad.brand.bp.client.enums.monitor;

import lombok.Getter;

import java.util.Collections;
import java.util.List;

@Getter
public enum MonitorRuleXUnifiedMediaEnum {

    CONTENT_XINGTU_TALENT(1L, 0, 50L, "内容抖音星图达人"),
    CONTENT_XINGTU_TALENT_HOT(1L, 1, 32L, "内容抖音星图加热"),

    CONTENT_KUAISHOU(2L, 0, 51L, "内容快手"),
    CONTENT_KUAISHOU_HOT(2L, 1, 35L, "快手加热");

    private Long unifiedMediaId;
    private Integer mediaMonitorType;
    private Long monitorRuleId;

    private String desc;

    MonitorRuleXUnifiedMediaEnum(Long unifiedMediaId, Integer mediaMonitorType, Long monitorRuleId, String desc) {
        this.unifiedMediaId = unifiedMediaId;
        this.mediaMonitorType = mediaMonitorType;
        this.monitorRuleId = monitorRuleId;
        this.desc = desc;
    }

    public static List<MonitorRuleXUnifiedMediaEnum> findRuleByUnifiedMediaId(Long unifiedMediaId){
        List<MonitorRuleXUnifiedMediaEnum> result = Collections.emptyList();
        if (unifiedMediaId == null) {
            return result;
        }
        for (MonitorRuleXUnifiedMediaEnum monitorRuleXUnifiedMediaEnum : values()) {
            if (monitorRuleXUnifiedMediaEnum.unifiedMediaId.equals(unifiedMediaId)) {
                result.add(monitorRuleXUnifiedMediaEnum);
            }
        }
        return result;
    }
}
