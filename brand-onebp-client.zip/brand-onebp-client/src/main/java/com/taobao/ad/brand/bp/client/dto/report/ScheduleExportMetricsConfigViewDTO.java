package com.taobao.ad.brand.bp.client.dto.report;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 数据指标对象
 * @author yuncheng.lyc
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ScheduleExportMetricsConfigViewDTO extends ReportMetricsConfigViewDTO {
    /**
     * 列Code 对应枚举名
     */
    private String code;
    /**
     * 列名称
     */
    private String name;
    /**
     * 字段描述
     */
    private String description;

    /**
     * 一级标题
     */
    private String headTitle;

    /**
     * 列宽
     */
    private Integer colWidth;

    /**
     * 子标题
     */
    private String subTitle;

    /**
     * 是否动态列
     */
    private Boolean dynamic;

    /**
     * 是否商家版价格明细指标
     */
    private Boolean forPrice;

    /**
     * 是否需要合并列
     */
    private Boolean mergeColumn;

    /**
     * 合并行策略 -9999:该列全部行 其余：指定按照某列的值分组合并
     */
    private String mergeRow;

    /**
     * 合并策略 @see com.taobao.ad.brand.bp.client.enums.ExportMergeContentType
     */
    private String mergeContentType;

    /**
     * 是否定向信息列
     */
    private Boolean isTarget;
}
