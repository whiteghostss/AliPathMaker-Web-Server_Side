package com.taobao.ad.brand.bp.client.dto.cat;

import lombok.Data;

/**
 * @author yanjingang
 * @date 2024/11/20
 */
@Data
public class CategoryViewDTO {
    private Long catId;
    private String catName;
}
