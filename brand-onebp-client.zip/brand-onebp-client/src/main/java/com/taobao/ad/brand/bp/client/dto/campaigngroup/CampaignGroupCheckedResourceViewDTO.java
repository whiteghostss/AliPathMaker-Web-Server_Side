package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import java.util.List;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.common.SchemaConfigViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupWakeupTypeEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;

import lombok.Data;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/23
 */
@Data
public class CampaignGroupCheckedResourceViewDTO extends BaseViewDTO {

    /**
     * 订单ID
     */
    private Long id;
    /**
     * 订单名称
     */
    private String name;
    /**
     * @see BrandSaleTypeEnum
     */
    private Integer saleType;
    /**
     * 勾选的资源ID列表
     */
    private List<Long> checkedResourcePackageProductIdList;
    /**
     * 唤端类型
     * @see BrandCampaignGroupWakeupTypeEnum
     */
    private Integer wakeupType;

    /**
     * 唤端配置的app
     * */
    private List<SchemaConfigViewDTO> schemaConfigViewDTOList;
}
