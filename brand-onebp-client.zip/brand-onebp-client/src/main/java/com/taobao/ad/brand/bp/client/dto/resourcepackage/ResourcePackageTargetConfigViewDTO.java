package com.taobao.ad.brand.bp.client.dto.resourcepackage;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class ResourcePackageTargetConfigViewDTO extends BaseViewDTO {
    private String value;

    /**
     * 定向name
     */
    private String name;

    /**
     * 是否已选择
     */
    private boolean selected;

    /**
     * 定向属性
     * Map<属性名，具体值>
     */
    private Map<String, String> properties;

    /**
     * ssp定向属性
     * Map<属性名，具体值>
     */
    private Map<String, String> sspProperties;

    /**
     * 子定向
     */
    private List<ResourcePackageTargetConfigViewDTO> subDirectionList;
}
