package com.taobao.ad.brand.bp.client.dto.shop;

import lombok.Data;

/**
 * 店铺品牌信息
 */
@Data
public class ShopBrandViewDTO {
    /**
     * 店铺归宿商家tbUserid
     */
    private Long tbUserId;
    /**
     * 店铺id
     */
    private Long shopId;

    private String shopName;
    /**
     * 品牌id
     */
    private Long brandId;
    /**
     * 品牌名称
     */
    private String brandName;
}
