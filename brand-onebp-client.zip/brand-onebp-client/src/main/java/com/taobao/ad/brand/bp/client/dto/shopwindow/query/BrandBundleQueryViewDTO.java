package com.taobao.ad.brand.bp.client.dto.shopwindow.query;

import com.taobao.ad.brand.bp.client.dto.base.BaseQueryViewDTO;
import lombok.Data;

import java.util.List;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/6/25
 **/
@Data
public class BrandBundleQueryViewDTO extends BaseQueryViewDTO {
    /**
     * 套餐包ID
     */
    private Long id;
    /**
     * 套餐包状态
     * BundleStatusEnum
     */
    private List<Integer> statusList;
    /**
     * SPU状态
     * BundleStatusEnum
     */
    private List<Integer> spuStatusList;
    /**
     * skuId
     */
    private List<Long> skuIdList;

    /**
     * sku售卖平台
     * TargetPlatformEnum
     */
    private List<Integer> targetPlatformList;

    /**
     * spu营销场景，可支持spu灰度状态查询
     * @see com.taobao.ad.brand.perform.client.enums.shopwindow.SpuMarketSceneTypeEnum
     */
    private List<Integer> spuMarketSceneTypeList;

    /**
     * spu营销场景，可支持spu灰度状态查询
     * @see com.taobao.ad.brand.perform.client.enums.shopwindow.SpuMarketSceneTypeEnum
     */
    private List<Integer> excludeSpuMarketSceneTypeList;
}
