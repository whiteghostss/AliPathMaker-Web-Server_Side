package com.taobao.ad.brand.bp.client.enums.campaign;

import com.google.common.collect.Lists;
import lombok.Getter;

import java.util.List;
import java.util.Objects;

/**
 * dmp平台精选人群topicId
 */
@Getter
public enum RecommendCrowdTypeEnum {
    BRAND(1, "平台推荐人群-品牌实时人群", 984L),
    CATEGORY(2, "平台推荐人群-行业实时人群", 985L),
    GLOBAL(3, "平台推荐人群-全域追投人群", 986L),
    RECOMMEND(4, "平台推荐人群-专属特推人群", 987L),

    //实时优选中的场景定制人群
    SCENE_CUSTOMIZE(5, "场景定制人群", 1006L),

    MEMBER(6, "平台推荐人群-入会实时人群", 1575L),
    // 自助场景极简版行业定制人群
    CATEGORY_SELF_SERVICE_SLIM(7, "自助场景极简版行业定制人群", 1915L),
    // For自助
    SCENE_RECOMMEND(8, "场景推荐人群", 1987L),
    BRAND_ADDITION(9, "平台推荐人群-品牌追投人群", 1994L),
    CATEGORY_ADDITION(10, "平台推荐人群-品类追投人群", 1995L),
    CUSTOMIZE_TREND(2062, "平台推荐人群-定制趋势人群", 2062L),
    ;
    private final Integer code;
    private final String desc;
    //dmp分配
    private final Long topicId;

    RecommendCrowdTypeEnum(Integer code, String desc, Long topicId) {
        this.code = code;
        this.desc = desc;
        this.topicId = topicId;
    }

    private static final List<RecommendCrowdTypeEnum> SHOWMAX_CROWD_TYPE_ENUM_LIST = Lists.newArrayList();
    static {
        for (RecommendCrowdTypeEnum theEnum : RecommendCrowdTypeEnum.values()){
            if (theEnum != SCENE_CUSTOMIZE && theEnum != CATEGORY_SELF_SERVICE_SLIM) {
                SHOWMAX_CROWD_TYPE_ENUM_LIST.add(theEnum);
            }
        }
    }


    public static List<RecommendCrowdTypeEnum> getShowmaxCrowdTypeEnumList() {
        return SHOWMAX_CROWD_TYPE_ENUM_LIST;
    }

    public static boolean needBrandForQueryTemplateCrowd(Integer code) {
        if (Objects.isNull(code)) {
            return true;
        }
        return GLOBAL.getCode().equals(code) || MEMBER.getCode().equals(code);
    }

    public static boolean needLabelForQueryTemplateCrowd(Integer code) {
        if (Objects.isNull(code)) {
            return true;
        }
        return CATEGORY.getCode().equals(code) || BRAND.getCode().equals(code)
                || BRAND_ADDITION.getCode().equals(code) || CATEGORY_ADDITION.getCode().equals(code);
    }

    public static RecommendCrowdTypeEnum getRecommendCrowdTypeEnum(Integer code){
        for (RecommendCrowdTypeEnum theEnum : RecommendCrowdTypeEnum.values()){
            if (theEnum.getCode().equals(code)){
                return theEnum;
            }
        }
        return null;
    }

    public static String getDesc(Integer code){
        for (RecommendCrowdTypeEnum theEnum : RecommendCrowdTypeEnum.values()){
            if (theEnum.getCode().equals(code)){
                return theEnum.getDesc();
            }
        }
        return null;
    }

    public static boolean isTemplateCrowd(Long topicId) {
        if (topicId == null) {
            return false;
        }
        for (RecommendCrowdTypeEnum theEnum : RecommendCrowdTypeEnum.values()){
            if (theEnum.getTopicId().equals(topicId)) {
                return true;
            }
        }
        return false;
    }

}
