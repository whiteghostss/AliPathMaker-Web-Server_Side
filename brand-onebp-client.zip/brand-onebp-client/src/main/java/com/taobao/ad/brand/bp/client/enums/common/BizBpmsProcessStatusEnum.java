package com.taobao.ad.brand.bp.client.enums.common;

import lombok.Getter;

import java.util.Arrays;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author yanjingang
 * @date 2023/11/9
 */
@Getter
public enum BizBpmsProcessStatusEnum {

    EDITED(1,"草稿"),
    APPROVE_ING(2,"待审核"),
    AGREED(3,"审核通过"),
    REFUSED(4,"审核拒绝");

    private Integer code;
    private String desc;

    private static final Map<Integer, BizBpmsProcessStatusEnum> MAP;

    static {
        MAP = Arrays.stream(values()).collect(Collectors.toMap(BizBpmsProcessStatusEnum::getCode, Function.identity()));
    }

    BizBpmsProcessStatusEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public static BizBpmsProcessStatusEnum getByCode(Integer code) {
        return Optional.ofNullable(code).map(MAP::get).orElse(null);
    }

    public static boolean isFinish(Integer code) {
        if (code == null) {
            return false;
        }

        return code == AGREED.code.intValue() || code == REFUSED.code.intValue();
    }

    public static boolean isAgree(Integer code) {
        return code != null && code == AGREED.code.intValue();
    }

    public static boolean isRefuse(Integer code) {
        return code != null && code == REFUSED.code.intValue();
    }
}
