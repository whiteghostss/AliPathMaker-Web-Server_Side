package com.taobao.ad.brand.bp.client.enums.common;

/**
 * @author yanjingang
 * @date 2023/11/9
 */
public enum BizDomainTypeEnum {
    MAIN_CAMPAIGN_GROUP,

    SUB_CAMPAIGN_GROUP,

    CAMPAIGN,

    ;
}
