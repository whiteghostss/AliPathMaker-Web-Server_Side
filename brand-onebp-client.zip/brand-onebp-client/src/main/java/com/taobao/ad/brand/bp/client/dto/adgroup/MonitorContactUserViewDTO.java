package com.taobao.ad.brand.bp.client.dto.adgroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

@Data
public class MonitorContactUserViewDTO extends BaseViewDTO {
    private String email;
    private String name;

}
