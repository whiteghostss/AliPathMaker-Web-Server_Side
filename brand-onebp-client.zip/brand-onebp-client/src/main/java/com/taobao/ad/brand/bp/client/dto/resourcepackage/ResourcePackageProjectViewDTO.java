package com.taobao.ad.brand.bp.client.dto.resourcepackage;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.account.emp.AliEmpViewDTO;
import lombok.Data;

import java.util.List;

/**
 * 资源包项目的viewDTO
 * @author yanjingang
 * @date 2024/03/25
 */
@Data
public class ResourcePackageProjectViewDTO extends BaseViewDTO {
    /**
     * 项目id
     */
    private Long id;

    /**
     * 项目名称
     */
    private String name;

    /**
     * 项目状态
     * PACKAGE_PROJECT_STATUS_ENUM
     * 枚举状态：
     * 0 - 新建
     * 1 - 审批中
     * 2 - 审批通过
     * 3 - 招商中
     * 4 - 招商暂停
     * 5 - 招商完毕
     */
    private Integer status;

    /**
     * 状态名称
     */
    private String statusName;

    /**
     * 类型
     */
    private Integer type;

    /**
     * 类型名称
     */
    private String typeName;

    /**
     * 方案审批人
     */
    private List<AliEmpViewDTO> schemeApprovalEmpList;

}