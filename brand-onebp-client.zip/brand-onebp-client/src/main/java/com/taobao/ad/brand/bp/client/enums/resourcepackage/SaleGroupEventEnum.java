package com.taobao.ad.brand.bp.client.enums.resourcepackage;

import com.taobao.ad.brand.bp.client.enums.CommonEnum;

/**
 * 分组状态流转event
 * @author yanjingang
 * @date 2023/3/6
 */
public enum SaleGroupEventEnum implements CommonEnum {
    AUTO_CREATE_CAMPAIGN(1, "自动创建分组下计划");


    private final int value;
    private final String desc;

    SaleGroupEventEnum(int value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    @Override
    public int getValue() {
        return value;
    }

    @Override
    public String getDesc() {
        return desc;
    }
}
