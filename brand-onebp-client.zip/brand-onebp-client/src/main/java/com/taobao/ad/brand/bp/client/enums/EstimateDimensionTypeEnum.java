package com.taobao.ad.brand.bp.client.enums;

/**
 * 预估的维度
 * */
public enum EstimateDimensionTypeEnum {
    SALE_GROUP(1, "分组"),
    CAMPAIGN(2, "一级计划"),
    SUB_CAMPAIGN(3, "二级计划"),
    MOTION(4, "智能提案"),
    STRATEGY(5, "智能策略")
    /*结束*/
    ;
    private final Integer value;
    private final String name;

    EstimateDimensionTypeEnum(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    public Integer getValue() {
        return value;
    }

    public String getName() {
        return name;
    }

    public static EstimateDimensionTypeEnum getByValue(Integer value) {
        for (EstimateDimensionTypeEnum deliveryTargetEnum : EstimateDimensionTypeEnum.values()) {
            if (deliveryTargetEnum.getValue().equals(value)) {
                return deliveryTargetEnum;
            }
        }
        return null;
    }
}
