package com.taobao.ad.brand.bp.client.dto.agent;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * @author jx.lj
 * @date 2025/4/17 17:14
 * @desc
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class LlmAgentDirectCallParamViewDTO extends BaseViewDTO {

    private static final long serialVersionUID = 5181986414609857600L;
    /**
     * Agent标识
     */
    private String agentName;

    /**
     * 扩展交互参数
     */
    private Map<String, Object> ext;
}
