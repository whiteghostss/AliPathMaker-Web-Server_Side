package com.taobao.ad.brand.bp.client.dto.mr;

import lombok.Data;

/**
 * @author jixiu.lj
 * @date 2023/3/21 11:44
 */
@Data
public class FileSizeViewDTO {

    private Integer width;
    private Integer height;
    private String unit;
}
