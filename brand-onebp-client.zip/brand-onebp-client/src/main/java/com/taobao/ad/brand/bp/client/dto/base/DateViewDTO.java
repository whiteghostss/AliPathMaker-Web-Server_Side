package com.taobao.ad.brand.bp.client.dto.base;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.Date;

/**
 * @author yunhu.myh@alibaba-inc.com
 * @date 2023/03/14
 */
@Data
public class DateViewDTO extends BaseViewDTO {
    /**
     * 开始日期
     */
    private Date startDate;
    /**
     * 结束日期
     */
    private Date endDate;

    public static DateViewDTO build(Date startDate,Date endDate){
        DateViewDTO dateViewDTO = new DateViewDTO();
        dateViewDTO.setStartDate(startDate);
        dateViewDTO.setEndDate(endDate);
        return dateViewDTO;
    }
}
