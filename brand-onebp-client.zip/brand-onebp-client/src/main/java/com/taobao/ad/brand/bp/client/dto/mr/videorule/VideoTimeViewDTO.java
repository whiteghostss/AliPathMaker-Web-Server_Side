package com.taobao.ad.brand.bp.client.dto.mr.videorule;

import lombok.Data;

/**
 * @author jixiu.lj
 * @date 2023/3/21 11:46
 */
@Data
public class VideoTimeViewDTO {
    private String unit;
    private Integer min;
    private Integer max;
}
