package com.taobao.ad.brand.bp.client.api.shopwindow;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSpuViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.query.BrandSpuQueryViewDTO;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/6/26
 **/
public interface BizBrandSpuQueryService extends QueryAPI {

    String TAG = "BrandSpu";

    /**
     * 提案列表不分页
     * @param serviceContext
     * @param queryViewDTO
     * @return
     */
    @ProcessEntrance(name = "SPU列表不分页", desc = "SPU列表不分页", opType = OpType.query, tag = TAG)
    MultiResponse<BrandSpuViewDTO> queryBrandSpuList(ServiceContext serviceContext, BrandSpuQueryViewDTO queryViewDTO);

    /**
     * 新/老客户类型判断
     * @param serviceContext
     * @return
     */
    @ProcessEntrance(name = "新/老客户类型", desc = "新/老客户类型", opType = OpType.query, tag = TAG)
    SingleResponse<Integer> judgeCustomerType(ServiceContext serviceContext, Long customerMemberId);
}
