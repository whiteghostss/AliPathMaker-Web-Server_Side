package com.taobao.ad.brand.bp.client.enums;

/**
 * @author yuanxinxi
 */

public enum BizKeywordTypeEnum {


    //-------------------------Campaign--------------------
    CAMPAIGN_GROUP_ID("campaignGroupId", "订单ID"),
    CAMPAIGN_GROUP_NAME("campaignGroupName", "订单名称"),
    CAMPAIGN_ID("campaignId", "计划ID"),
    CAMPAIGN_NAME("campaignName", "计划名称"),
    CAMPAIGN_SSP_RESOURCE_ID("sspResourceId", "资源位id"),
    CAMPAIGN_SSP_PRODUCT_ID("sspProductId", "ssp产品id"),
    CAMPAIGN_SSP_PRODUCT_UUID("sspProductUuid", "ssp产品uuid"),
    CAMPAIGN_SSP_RESOURCE_NAME("sspResourceName", "资源名称"),
    CAMPAIGN_SSP_MEDIA_ID("sspMediaId", "ssp对客媒体id"),
    CAMPAIGN_SSP_MEDIA_NAME("sspMediaName", "ssp对客媒体名称"),
    ADGROUP_ID("adgroupId", "单元id"),
    ADGROUP_NAME("adgroupName", "单元名称"),
    CREATIVE_ID("creativeId", "创意id"),
    CREATIVE_NAME("creativeName", "创意名称"),
    CREATIVE_TAG_ID("creativeTagId", "创意版本id"),
    CREATIVE_TAG_NAME("creativeTagName", "创意版本名称"),
    CROWD_ID("crowdId", "人群id"),
    CROWD_NAME("crowdName", "人群名称"),
    TALENT_ID("talentId", "达人id"),
    TALENT_NAME("talentName", "达人名称"),
    MOTION_ID("motionId", "提案id"),
    MOTION_NAME("motionName", "提案名称"),
    CART_ID("cartId", "加购行id"),
    SKU_ID("skuId", "skuId"),
    SPU_ID("spuId", "spuId"),
    CONTENT_ID("contentId", "内容Id"),
    ;

    private final String name;
    private final String desc;


    public static BizKeywordTypeEnum getByName(String name) {
        if (name == null) {
            return null;
        }

        BizKeywordTypeEnum[] keywordTypeEnums = BizKeywordTypeEnum.values();
        for (BizKeywordTypeEnum keywordTypeEnum : keywordTypeEnums) {
            if (name.equals(keywordTypeEnum.getName())){
                return keywordTypeEnum;
            }
        }
        return null;
    }

    BizKeywordTypeEnum(String name, String desc) {
        this.name = name;
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }

    public String getName() {
        return name;
    }
}
