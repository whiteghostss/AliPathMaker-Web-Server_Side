package com.taobao.ad.brand.bp.client.dto.dooh;

import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignShowConfigViewDTO;
import lombok.Data;

import java.util.List;

@Data
public class DoohStrategyRecommendReasonQueryViewDTO {

    /**
     * 计划信息
     */
    private CampaignViewDTO campaignViewDTO;

    /**
     * 计划需要配置的定向
     */
    private List<CampaignShowConfigViewDTO> campaignShowConfigViewDTOList;

    /**
     * 天攻计划包含的点位数据
     */
    private List<DoohStrategyPointViewDTO> doohStrategyPointViewDTOList;

    /**
     * 天攻策略信息
     */
    private DoohStrategyViewDTO doohStrategyViewDTO;
}
