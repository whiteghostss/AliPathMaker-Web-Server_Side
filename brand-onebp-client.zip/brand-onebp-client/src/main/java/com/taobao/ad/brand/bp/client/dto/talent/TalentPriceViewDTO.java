package com.taobao.ad.brand.bp.client.dto.talent;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

@Data
public class TalentPriceViewDTO extends BaseViewDTO {
    /**
     * 妈妈达人唯一ID
     */
    private String userId;
    /**
     * 媒体侧达人唯一ID
     */
    private String mediaUserId;

    private Integer contentType;

    private String contentTypeName;

    private Long price;
}
