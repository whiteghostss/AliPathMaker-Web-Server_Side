package com.taobao.ad.brand.bp.client.enums.cart;

import lombok.Getter;

/**
 * 购物车动作类型
 */
@Getter
public enum CartActionEnum {
    ADD_TO_CART(1, "加入购物车"),
    ORDER(2, "下单"),

    ;

    private final Integer value;
    private final String name;

    CartActionEnum(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    public static CartActionEnum getByValue(Integer value) {
        if (value == null) {
            return null;
        }

        CartActionEnum[] statusArray = CartActionEnum.values();
        for (CartActionEnum action : statusArray) {
            if (action.getValue() == value.intValue()) {
                return action;
            }
        }
        return null;
    }
}
