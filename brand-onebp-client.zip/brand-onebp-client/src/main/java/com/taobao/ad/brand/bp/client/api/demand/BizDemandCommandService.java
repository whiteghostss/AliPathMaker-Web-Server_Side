package com.taobao.ad.brand.bp.client.api.demand;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.ad.brand.dto.demand.DemandViewDTO;
import com.alibaba.hermes.framework.api.CommandAPI;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.demand.DemandConfirmSolutionViewDTO;
import com.taobao.ad.brand.bp.client.dto.demand.DemandTalentDiffViewDTO;

import java.util.List;

@Deprecated
public interface BizDemandCommandService extends CommandAPI {

    String TAG = "Demand";

    @ProcessEntrance(name = "新建demand", desc = "新建demand", opType = OpType.add, tag = TAG)
    SingleResponse<Long> addDemand(ServiceContext context, DemandViewDTO demandViewDTO);

    @ProcessEntrance(name = "更新demand", desc = "更新demand", opType = OpType.update, tag = TAG)
    Response updateDemand(ServiceContext context, DemandViewDTO demandViewDTO);

    @ProcessEntrance(name = "部分更新demand", desc = "部分更新demand", opType = OpType.update, tag = TAG)
    Response updateDemandPart(ServiceContext context, DemandViewDTO demandViewDTO);

    @ProcessEntrance(name = "删除demand", desc = "删除demand", opType = OpType.delete, tag = TAG)
    Response deleteDemand(ServiceContext context, Long id);

    @ProcessEntrance(name = "方案确认/拒绝", desc = "方案确认/拒绝", opType = OpType.update, tag = TAG)
    Response confirmSolution(ServiceContext context, DemandConfirmSolutionViewDTO confirmSolutionViewDTO);

    @ProcessEntrance(name = "商家确认cpm资源包达人更新", desc = "商家确认cpm资源包达人更新", opType = OpType.update, tag = TAG)
    Response confirmTalentUpdate(ServiceContext context, List<DemandTalentDiffViewDTO> confirmUpdateTalentList);
}
