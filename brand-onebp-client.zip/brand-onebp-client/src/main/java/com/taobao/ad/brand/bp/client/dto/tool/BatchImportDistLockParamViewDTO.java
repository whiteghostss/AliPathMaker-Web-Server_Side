package com.taobao.ad.brand.bp.client.dto.tool;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * 批量导入分布式锁参数信息
 * @author shiyan
 */
@Data
public class BatchImportDistLockParamViewDTO extends BaseViewDTO {
    /**
     * 分布式key
     */
    private String lockKey;
    /**
     * 分布式key对应的value值
     */
    private String lockReqValue;
    /**
     * 过期时间（单位秒）
     */
    private Integer expireTime;
}
