package com.taobao.ad.brand.bp.client.dto.shopwindow;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/6/26
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class BrandSpuCreativeStyleRefViewDTO extends BaseViewDTO {
    /**
     * 是否主推样式
     * @see BrandBoolEnum
     */
    private Integer mainCreativeStyle;

    /**
     * 样式详情
     */
    private BrandShopWindowTemplateViewDTO shopWindowTemplateViewDTO;
}
