package com.taobao.ad.brand.bp.client.enums.campaign;

import lombok.Getter;

/**
 * 实时优选模式标签
 */
@Getter
public enum CampaignOptimizePolicyEnum {
    CTR_PRIORITY(1,"CTR优先"),
    BALANCED(2,"均衡"),
    TA_PRIORITY(3,"TA浓度优先"),
    ;

    private Integer code;
    private String desc;

    CampaignOptimizePolicyEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }
}
