package com.taobao.ad.brand.bp.client.context;

import java.util.List;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupEventEnum;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * CampaignGroup状态上下文
 *
 * @author yanjingang
 * @date 2023/3/6
 */
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class CampaignGroupStateContext {

    /**
     * 上下文
     */
    private ServiceContext serviceContext;

    /**
     * 前置状态
     */
    private BrandCampaignGroupStatusEnum fromStatusEnum;

    /**
     * 订单层级
     */
    private Integer campaignGroupLevel;

    /**
     * 订单
     */
    private CampaignGroupViewDTO campaignGroupViewDTO;

    /**
     * 主订单 - 特定场景需要
     */
    private CampaignGroupViewDTO mainCampaignGroupViewDTO;

    /**
     * 子订单列表 - 特定场景需要
     */
    private List<CampaignGroupViewDTO> subCampaignGroupViewDTOList;

    /**
     * 状态迁移Event
     */
    private CampaignGroupEventEnum eventEnum;

    /**
     * 下单、修改订单：勾选的售卖分组ID
     * 上线：需要上线的售卖分组ID
     */
    private List<Long> saleGroupIds;

    /**
     * 忽略不支持迁移的错误
     */
    private boolean ignoreNotAcceptError = false;
}
