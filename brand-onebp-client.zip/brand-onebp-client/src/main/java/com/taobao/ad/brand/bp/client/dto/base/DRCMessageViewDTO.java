package com.taobao.ad.brand.bp.client.dto.base;

import lombok.Data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @description: drc消息DTO
 * @author: philipfry
 * @create: 2021-02-24 10:02
 **/
@Data
public class DRCMessageViewDTO implements Serializable {

    /**
     * 数据库名称
     */
    private String dbName;

    /**
     * 表名称
     */
    private String tableName;

    /**
     * 操作类型，
     *
     * @see OpType
     */
    private String opType;

    /**
     * 对于update消息,为2个元素msg[0]=old和msg[1]=new，对于insert和delete只包含1个元素。
     */
    private List<Map<String, String>> msg = new ArrayList<>(2);

    /**
     * 仅对于update消息不为空，key为发生变化的字段，value是一个包含两个元素的List，第0个元素为old，第1个元素为new。
     */
    private Map<String, List<String>> diffFields = new HashMap<>();

    public enum OpType {
        INSERT, UPDATE, DELETE;
    }
}
