package com.taobao.ad.brand.bp.client.enums;

import com.alibaba.abf.governance.context.ServiceContext;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 系统操作类型
 *
 * @author duxiaokang
 * @date 2020/6/18
 */
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@Getter
public enum SystemOperType {

    /**
     * 系统操作类型
     */
    SYSTEM(0, "系统操作"),

    /**
     * 客户身份登录
     */
    MEMBER_USER(1, "主账号登录"),

    /**
     * 品销宝类型枚举：伪登录只读身份
     */
    PSEUDO_LOGIN_READ_USER(2, "一夜霸屏伪登陆读"),

    /**
     * 品销宝类型枚举：伪登录读写身份
     */
    PSEUDO_LOGIN_READ_WRITE_USER(3, "一夜霸屏伪登陆写"),
    ;

    private Integer index;

    private String desc;

    /**
     * 通过上下文判断操作类型
     *
     * @param context 上下文信息
     * @return 操作类型
     */
    public static Integer getOperTypeByNbServiceContext(ServiceContext context) {
        if (context == null) {
            return SYSTEM.getIndex();
        }
        if (context.getOperIdStr() == null) {
            return SYSTEM.getIndex();
        }
        return PSEUDO_LOGIN_READ_WRITE_USER.getIndex();
    }
}
