package com.taobao.ad.brand.bp.client.api.mediafreq;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.ad.brand.dto.media.freq.MediaFreqViewDTO;
import com.alibaba.hermes.framework.api.CommandAPI;
import com.alibaba.hermes.framework.dto.response.SingleResponse;

import java.util.List;

/**
 * 媒体频控控制服务
 *
 * @author shiyan
 * @date 2023/7/19
 **/
public interface BizMediaFreqCommandService extends CommandAPI {
    String TAG = "MediaFreq";

    @ProcessEntrance(name = "新增", desc = "新增", opType = OpType.add, tag = TAG)
    SingleResponse<Long> addMediaFreq(ServiceContext context, MediaFreqViewDTO viewDTO);

    @ProcessEntrance(name = "编辑", desc = "编辑", opType = OpType.update, tag = TAG)
    SingleResponse<Integer> updateMediaFreq(ServiceContext serviceContext, MediaFreqViewDTO viewDTO);

    @ProcessEntrance(name = "频控状态修改", desc = "频控状态修改", opType = OpType.update, tag = TAG)
    SingleResponse<Integer> updateMediaFreqStatus(ServiceContext serviceContext, List<Long> ids, Integer status);
}
