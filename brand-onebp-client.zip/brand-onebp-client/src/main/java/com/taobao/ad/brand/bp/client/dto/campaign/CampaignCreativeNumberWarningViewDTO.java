package com.taobao.ad.brand.bp.client.dto.campaign;

import lombok.Data;

@Data
public class CampaignCreativeNumberWarningViewDTO {

    /**
     * 是否预警
     */
    private Integer warningStatus;

    /**
     * 计划日平均预定量（PV）
     */
    private Long averageDailyAmount;

    /**
     * 推荐的计划最小创意数
     */
    private Integer recommendMinCreativeNumber;

    /**
     * 推荐的计划最大创意数
     */
    private Integer recommendMaxCreativeNumber;

}
