package com.taobao.ad.brand.bp.client.dto.site;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Getter;
import lombok.Setter;

import java.util.HashMap;
import java.util.Map;

/**
 * @author wangzhaoqing
 * @version 1.0
 * @desc Site信息
 * @date 2020/7/3 3:40 下午
 */
@Getter
@Setter
public class SiteViewDTO extends BaseViewDTO {

    private Long id;
    /**
     * member id
     */
    private Long memberId;
    /**
     * site id
     */
    private Long siteId;
    /**
     * 媒体名称
     */
    private String siteName;
    /**
     * 媒体类型
     */
    private Integer mediaType;
    /**
     * 媒体类型名称
     */
    private String mediaTypeName;
    /**
     * 媒体圈层
     */
    private Integer mediaScope;
    /**
     * site 状态
     */
    private Integer status;
    /**
     * site setting 属性信息
     */
    private Map<String, String> properties = new HashMap<>();

    /**
     * 采购平台中的 mediaId
     */
    private Long mediaId;

}
