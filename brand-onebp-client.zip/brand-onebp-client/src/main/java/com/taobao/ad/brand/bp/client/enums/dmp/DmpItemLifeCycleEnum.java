package com.taobao.ad.brand.bp.client.enums.dmp;

import lombok.Getter;

/**
 * @author yanjingang
 * @date 2025/2/18
 */
@Getter
public enum DmpItemLifeCycleEnum {
    NEW_BEGIN(1, "冷启期", "近30日GMV排名在叶子类目55%以下的新品"),
    GROW(4, "成长期", "近30日GMV排名在叶子类目5～55%的货品"),
    BAOPIN(5, "爆品期", "近30日GMV排名在叶子类目5%以内的货品"),
    PINGXIAO(6, "平销期","近30日GMV排名在叶子类目55%以下的非新品");

    private Integer type;
    private String name;
    private String tips;

    DmpItemLifeCycleEnum(Integer type, String name, String tips) {
        this.type = type;
        this.name = name;
        this.tips = tips;
    }

    /**
     * 根据type获取对应枚举
     * @param type
     * @return
     */
    public static DmpItemLifeCycleEnum getByCode(Integer type) {
        for (DmpItemLifeCycleEnum elem: DmpItemLifeCycleEnum.values()) {
            if (elem.getType().equals(type)) {
                return elem;
            }
        }
        return null;
    }
}
