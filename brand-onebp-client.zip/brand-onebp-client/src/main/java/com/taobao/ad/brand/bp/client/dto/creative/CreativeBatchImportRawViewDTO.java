package com.taobao.ad.brand.bp.client.dto.creative;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import lombok.Data;

/**
 * 创意批量导入从Excel中解析到的原始信息
 * @author jixiu.lj
 * @date 2023/8/31 20:01
 */
@Data
public class CreativeBatchImportRawViewDTO extends BaseViewDTO {
    private String errorMessage;
    private Boolean isFiltered;
    private CreativeViewDTO creativeViewDTO;
}
