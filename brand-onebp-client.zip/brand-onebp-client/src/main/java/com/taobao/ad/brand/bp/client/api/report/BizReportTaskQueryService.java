package com.taobao.ad.brand.bp.client.api.report;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.report.ReportTaskViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.query.ReportTaskQueryViewDTO;

/**
 * 报表异步任务查询相关服务
 * @author yuncheng.lyc
 */
public interface BizReportTaskQueryService extends QueryAPI {
    String TAG = "ReportTask";

    /**
     * 报表-查询异步任务列表
     * @param context
     * @param queryViewDTO
     * @return
     */
    @ProcessEntrance(name = "查询异步任务列表", desc = "查询异步任务列表", opType = OpType.query, tag = TAG)
    MultiResponse<ReportTaskViewDTO> queryReportTaskList(ServiceContext context, ReportTaskQueryViewDTO queryViewDTO);

    /**
     * 报表-查询异步任务信息
     * @param context
     * @param queryViewDTO
     * @return
     */
    @ProcessEntrance(name = "查询异步任务信息", desc = "查询异步任务信息", opType = OpType.query, tag = TAG)
    SingleResponse<ReportTaskViewDTO> getReportTask(ServiceContext context, ReportTaskQueryViewDTO queryViewDTO);

    /**
     * 报表-导出异步任务数据
     * @param context
     * @param queryViewDTO
     * @return
     */
    @ProcessEntrance(name = "导出异步任务数据", desc = "导出异步任务数据", opType = OpType.query, tag = TAG)
    SingleResponse<String> exportReportTask(ServiceContext context, ReportTaskQueryViewDTO queryViewDTO);

}
