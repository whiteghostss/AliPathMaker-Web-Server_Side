package com.taobao.ad.brand.bp.client.api.mediarule;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.media.mutex.MediaMutexRuleViewDTO;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.mediarule.query.MediaMutexRuleQueryViewDTO;

/**
 * 互斥规则查询服务类
 *
 * @author denglinhua
 * @date 2023-07-11
 */
public interface BizMediaMutexRuleQueryService extends QueryAPI {
    String TAG = "MediaMutexRule";

    /**
     * 查询互斥规则
     *
     * @param context
     * @param queryDTO
     * @return
     */
    MultiResponse<MediaMutexRuleViewDTO> findMutexList(ServiceContext context, MediaMutexRuleQueryViewDTO queryDTO);

    /**
     * 互斥详情查询
     *
     * @param context 必须提供memberId字段
     * @param mutexId     互斥id
     */
    SingleResponse<MediaMutexRuleViewDTO> getMutexRule(ServiceContext context, Long mutexId);

}
