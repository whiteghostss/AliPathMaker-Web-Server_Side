package com.taobao.ad.brand.bp.client.enums;

public interface ValueAndNameEnum<VALUE, ENUM extends ValueAndNameEnum> {

    VALUE value();

    String name();

    ENUM[] allEnums();

    default ENUM getByValue(VALUE value) {
        for (ENUM baseDomainEnum : allEnums()) {
            if (baseDomainEnum.value() != null && baseDomainEnum.value().equals(value)) {
                return baseDomainEnum;
            }
        }
        return null;
    }

    default ENUM getByName(String name) {
        for (ENUM baseDomainEnum : allEnums()) {
            if (baseDomainEnum.name() != null && baseDomainEnum.name().equalsIgnoreCase(name)) {
                return baseDomainEnum;
            }
        }
        return null;
    }

    default VALUE getValueByName(String name) {
        ENUM oneEnum = getByName(name);
        return oneEnum != null ?  (VALUE)oneEnum.value() : null;
    }

    default VALUE getValueByNameIgnoreNotExistsAndNull(String name) {
        if (name == null || name.length() == 0) {
            return null;
        }
        ENUM oneEnum = getByName(name);
        if (oneEnum == null) {
            return null;
        }
        return (VALUE)oneEnum.value();
    }

    default VALUE getValueByNameIgnoreNull(String name) {
        if (name == null || name.length() == 0) {
            return null;
        }
        return getValueByName(name);
    }

    default String getShowNameByValue(VALUE value) {
        ENUM oneEnum = getByValue(value);
        if (null == oneEnum) {
            return null;
        }
        return oneEnum.getShowName();
    }

    default String getShowNameByValueIgnoreNull(VALUE value) {
        if(value == null){
            return null;
        }
        return getShowNameByValue(value);
    }

    default String getShowName(){
        return name().toLowerCase();
    }
}

