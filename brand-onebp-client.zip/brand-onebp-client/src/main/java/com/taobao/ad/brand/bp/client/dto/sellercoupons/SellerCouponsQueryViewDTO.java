package com.taobao.ad.brand.bp.client.dto.sellercoupons;

import com.taobao.ad.brand.bp.client.dto.base.BaseQueryViewDTO;
import lombok.Data;

import java.util.List;

/**
 * @Author: PhilipFry
 * @createTime: 2023年09月14日 10:34:21
 * @Description: 商家优惠券查询DTO
 */
@Data
public class SellerCouponsQueryViewDTO extends BaseQueryViewDTO {
    /**
     * 商家ID
     */
    private Long sellerId;

    /**
     * 优惠券ID
     */
    private Long spreadId;

    /**
     * 排序
     */
    private String sortField;

    /**
     * 是否不过期
     */
    private Integer noExpire;

    private List<Long> templateIds;

    /**
     * tag值是卡券平台申请渠道值
     */
    private Integer	couponTag;
}
