package com.taobao.ad.brand.bp.client.dto.template.element;


import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.List;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/4/12 10:16
 * @description ：
 * @modified By：
 */
@Data
public class TemplateElementViewDTO extends BaseViewDTO {
    /**
     * 元素id
     */
    private Long elementId;

    /**
     * 是否必填
     */
    private Integer mustFull;

    /**
     * 是否需要审核
     */
    private Integer needAudit;

    /**
     * 是否只读
     */
    private Integer readOnly;

    /**
     * 备注
     */
    private String remark;

    /**
     * 是否主元素
     */
    private Integer mainProtocol;

    /**
     * 元素类型ID
     */
    private Long elementTypeId;

    /**
     * 元素类型CODE
     */
    private String elementTypeCode;

    /**
     * 元素KEY
     */
    private String elementKey;

    /**
     * 元素名称
     */
    private String elementName;

    private Integer isLandingPage;

    private List<ElementTypePropertyViewDTO> propertyList;

    private List<ElementTypePropertyViewDTO> protocolPropertyList;
}
