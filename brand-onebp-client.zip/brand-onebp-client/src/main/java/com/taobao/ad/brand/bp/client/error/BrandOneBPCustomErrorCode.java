package com.taobao.ad.brand.bp.client.error;

import com.alibaba.hermes.framework.error.ErrorCodeAware;

/**
 * 自定义错误码
 *
 * 如无特殊需求, 不需要单独定义错误码
 *
 * @author huangying.cxd
 */
public enum BrandOneBPCustomErrorCode implements ErrorCodeAware {

    BIZ_UN_SUPPORT_INQUIRY_DEFAULT_ERROR_ERROR("A2004-001", "业务不支持"),
    BIZ_UN_SUPPORT_INQUIRY_PART_ERROR_ERROR("A2004-002", "业务不支持"),
    BIZ_UN_SUPPORT_INQUIRY_ALL_ERROR_ERROR("A2004-003", "业务不支持"),

    BIZ_UN_FINISH_DEMAND_DEFAULT_ERROR("A2004-004", "资源诉求未表达"),

    ;

    private final String code;
    private final String msg;

    BrandOneBPCustomErrorCode(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    @Override
    public String getErrCode() {
        return code;
    }

    @Override
    public String getErrMsg() {
        return msg;
    }

    public ErrorCodeAware of(String message) {
        return Builder.build(code, msg);
    }
}
