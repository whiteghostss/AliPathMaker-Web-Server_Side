package com.taobao.ad.brand.bp.client.dto.solution;

import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.common.BrandViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import lombok.Data;

import java.util.List;

@Data
public class CartItemSolutionViewDTO extends BaseViewDTO {
    /**
     * 加购行id
     */
    private Long id;
    /**
     * 购物车数据来源：1：百灵、2：千牛
     * BrandCartSourceEnum
     */
    private Integer cartSource;
    /**
     * 加购行类型
     * BrandCartItemTypeEnum
     */
    private Integer type;
    /**
     * spuId
     */
    private Long spuId;
    /**
     * skuId
     */
    private Long skuId;
    /**
     * 套餐包id
     */
    private Long bundleId;
    /**
     * 加购行状态：0：未下单、4：已下单
     * BrandCartStatusEnum
     */
    private Integer status;
    /**
     * 功能操作必填
     * CartItemSolutionOperateEnum
     */
    private Integer operate;
    /**
     * 订单ID
     */
    private Long campaignGroupId;
    /**
     * 主订单ID
     */
    private Long mainCampaignGroupId;
    /**
     * 计划
     */
    private CampaignViewDTO campaignViewDTO;
    /**
     * 单元
     */
    private AdgroupViewDTO adgroupViewDTO;
    /**
     * 创意列表
     */
    private List<CreativeViewDTO> creativeViewDTOList;
    /**
     * 支付方式
     * @see com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupContractPayModelEnum
     */
    private Integer payMode;
    /**
     * 折前价（用户输入）
     */
    private Long publishTotalMoney;
    /**
     * 品牌信息List
     */
    private List<BrandViewDTO> brandViewDTOList;
    /**
     * 下单ErrorCode
     */
    private String orderErrorCode;

    /**
     * 宝贝ID
     */
    private Long itemId;
}
