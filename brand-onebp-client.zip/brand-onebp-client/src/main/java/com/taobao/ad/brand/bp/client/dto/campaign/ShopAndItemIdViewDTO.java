package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

@Data
public class ShopAndItemIdViewDTO extends BaseViewDTO {
    /**
     * 商品ID
     * */
    private Long itemId;
    /**
     * 店铺ID
     * */
    private Long shopId;
}
