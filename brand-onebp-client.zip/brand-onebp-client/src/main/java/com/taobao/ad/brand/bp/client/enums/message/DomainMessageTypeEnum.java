package com.taobao.ad.brand.bp.client.enums.message;

/**
 * 领域消息类型
 * @author ximu
 * @date 2023/7/18
 */
public enum DomainMessageTypeEnum {
    MAIN_CAMPAIGN_GROUP,
    SUB_CAMPAIGN_GROUP,
    MAIN_CAMPAIGN,
    DEMAND,
    MATERIAL_GROUP,
    SALE_GROUP
}
