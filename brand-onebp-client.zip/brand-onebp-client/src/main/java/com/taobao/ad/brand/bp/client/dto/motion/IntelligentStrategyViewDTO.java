package com.taobao.ad.brand.bp.client.dto.motion;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignSaleGroupResourceDeliveryTargetViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/17
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class IntelligentStrategyViewDTO extends BaseViewDTO {

    /**
     * 主键id
     */
    private Long id;

    /**
     * 策略名称
     */
    private String name;

    /**
     * 提案id
     */
    private Long motionId;

    /**
     * 策略目标
     */
    private Integer strategyTarget;

    /**
     * 策略状态
     */
    private Integer status;

    /**
     * 策略来源（1-算法生成，兜底生成）
     * com.alibaba.ad.nb.packages.v2.client.constant.motion.StrategySourceEnum
     */
    private Integer source;

    /**
     * 策略类型 1-全自动(可设置产品和金额)   --后两者暂无使用 2-半自动(可设置金额) 3-智能
     * 非必传 仅自定义创建策略场景有值
     */
    private Integer strategyType;

    /**
     * 该策略产品最小数量
     */
    private Integer minQuality;

    /**
     * 该策略产品最大数量
     */
    private Integer maxQuality;

    /**
     * 产品策略数据
     */
    private List<IntelligentDistributionRuleViewDTO> distributionRuleDTOList;

    /**
     * 交付指标
     */
    private List<CampaignSaleGroupResourceDeliveryTargetViewDTO> newDeliveryTargetList;

    /**
     * 策略总览预估数据
     */
    private PredictDataViewDTO predictDataViewDTO;

    /**
     * 媒体洞察数据
     */
    private List<MediaStrategyViewDTO> mediaStrategyViewDTOList;

    /**
     * 资源产品洞察数据
     */
    private List<ResourceProductStrategyViewDTO> resourceProductStrategyViewDTOList;

    /**
     * 营销阶段预算分配数据
     */
    private List<MarketingStageViewDTO> marketingStageViewDTOList;

    /**
     * 产品策略数据
     * 暂时保留,防止上线中异常, 后续删除
     */
    private List<ProductStrategyViewDTO> productStrategyViewDTOList;
}
