package com.taobao.ad.brand.bp.client.enums.demand;

import com.taobao.ad.brand.bp.client.enums.CommonEnum;

public enum DemandTalentUpdateTypeEnum{

    CREATE(1, "新建"),
    DELETE(2, "删除")
    ;

    private final Integer value;
    private final String desc;

    DemandTalentUpdateTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public Integer getValue() {
        return value;
    }

    public String getDesc() {
        return desc;
    }
}
