package com.taobao.ad.brand.bp.client.dto.resourcepackage;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * @author yanjingang
 * @date 2023/9/19
 */
@Data
public class ResourcePackageSaleGroupAuditViewDTO extends BaseViewDTO {

    /**
     * 分组价审状态
     * @see com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupPriceAuditStatusEnum
     */
    private Integer priceAuditStatus;
    /**
     * 价审工作流ID
     */
    private String priceAuditWorkflowInstanceId;

    /**
     * 补量配送分组审批状态
     * @see com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupAuditStatusEnum
     */
    private Integer auditStatus;
    /**
     * 补量配送工作流id
     */
    private String auditWorkflowInstanceId;

}
