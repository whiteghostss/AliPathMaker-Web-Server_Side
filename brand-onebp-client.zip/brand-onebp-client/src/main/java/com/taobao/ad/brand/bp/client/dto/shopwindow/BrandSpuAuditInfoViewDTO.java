package com.taobao.ad.brand.bp.client.dto.shopwindow;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/6/26
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class BrandSpuAuditInfoViewDTO extends BaseViewDTO {

    /**
     *  审批流实例ID
     */
    private String processInstanceId;

    /**
     *  首次审批时间
     */
    private Date firstSubmitTime;

    /**
     *  最后审批时间
     */
    private Date lastSubmitTime;
}
