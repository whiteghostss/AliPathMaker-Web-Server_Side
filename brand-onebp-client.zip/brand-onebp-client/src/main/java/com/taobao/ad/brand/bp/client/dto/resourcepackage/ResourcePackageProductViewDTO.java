package com.taobao.ad.brand.bp.client.dto.resourcepackage;

import java.util.Date;
import java.util.List;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.SelectedViewDTO;
import lombok.Data;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/22
 */
@Data
public class ResourcePackageProductViewDTO extends BaseViewDTO {
    /**
     * 主键
     */
    private Long id;
    /**
     * 补量场景下，补量产品关联的资源包主产品id（资源包产品主键ID）
     */
    private Long mainProductId;
    /**
     * ssp产品id
     */
    private Long sspProductId;

    /**
     * ssp产品uuid
     */
    private Long sspProductUuid;

    /**
     * ssp产品name
     */
    private String sspProductName;
    /**
     * ssp对客产品名称
     */
    private String customerOrientedProductName;
    /**
     * 刊例产品id
     */
    private Long publicationProductId;

    /**
     * 前端标识资源唯一性id
     */
    private String encryptionId;

    /**
     * 媒体名称
     */
    private String mediaName;

    /**
     * 资源位名称
     */
    private String resourcePositionName;

    /**
     * 进度状态名称
     */
    private String approachStatusName;

    /**
     * 是否支持第三方监测
     * 1-是 0-否
     */
    private Boolean sOnAliSerialInspect;

    /**
     * 资源类型名称
     */
    private List<String> resourceTypeNameList;

    /**
     * 资源类型集合
     */
    private List<Integer> resourceTypeValueList;

    /**
     * 单位CPM数量
     */
    private Integer unitExposure;

    /**
     * 单位点击量
     */
    private Integer unitClick;

    /**
     * 原始ctr 0.57 -> 0.57%
     */
    private Double originalCtr;

    /**
     * 是否原生产品
     */
    private String originalName;

    /**
     * 有效价格政策区间
     */
    private List<ResourcePackageValidPeriodViewDTO> validPeriodDTOList;

    /**
     * 产品所属类别
     */
    private String category;

    /**
     * 所属模板id
     */
    private Long templateId;

    /**
     * 所属售卖分组id
     */
    private Long saleGroupId;

    /**
     * 单位
     */
    private Integer saleUnit;

    /**
     * 售卖单位名称
     */
    private String saleUnitName;

    /**
     * 流量域
     */
    private Integer mediaScope;

    /**
     * 定向集合
     */
    private List<CommonViewDTO> targetList;
    /**
     * 定向配置集合
     */
    private List<ResourcePackageTargetConfigViewDTO> targetConfigList;

    /**
     * 人群定向（普通分组）
     */
    private Integer crowdInfo;

    /**
     * 人群定向名称（普通分组）
     */
    private String crowdInfoName;

    /**
     * 投放方式
     */
    private ResourcePackageCastTypeViewDTO castType;

    /**
     * 投放方式选项
     */
    private ResourcePackageCastTypeOptionViewDTO castTypeOption;

    /**
     * 是否被移除
     */
    private Integer isDeleted;

    /**
     * 备注
     */
    private String remark;

    /**
     * 所属跨域二级产品id（只有跨域二级产品的子产品才有该id）
     */
    private Long superiorProductId;

    /**
     * 产品波段价格相关参数
     */
    private List<ResourcePackageProductPriceViewDTO> bandPriceList;

    /**
     * 收否必选资源
     */
    private Integer isNecessary;
    /**
     * 是否支持智能创意
     */
    private Integer supportSmartCreative;

    /**
     * 联投子二级产品预订量占比
     */
    private Long bookingAmountRatio;

    /**
     * 联投子二级产品库存占量占比
     */
    private Long inventoryRatio;

    /**
     * 联投媒体（联投子一二环二级产品需要确定联投媒体）
     */
    private List<SelectedViewDTO> unionMediaList;

    /**
     * 联投子二环二级产品模版列表
     */
    private List<CommonViewDTO> sspTemplateList;

    /**
     * 是否承诺曝光
     */
    private Integer promiseExposure;

    /**
     * 是否承诺点击
     */
    private Integer promiseClick;

    /**
     * 跨域二级产品子产品列表
     */
    private List<ResourcePackageProductViewDTO> subResourcePackageProductList;

    private Date startTime;

    private Date endTime;

    /**
     * CPM成本
     */
    private Long cpmCost;

    /**
     * CPC成本
     */
    private Long cpcCost;

    /**
     * 注意：资源包不返回
     * ssp产品 ctr(点击率)
     */
    private Long ctr;

    /**
     * 资源包预估点击率
     */
    private Long predictCtr;

    /**
     * 跨域产品下二级产品数量
     */
    private Integer productSubAmount;

    /**
     * 子二级产品名称列表
     */
    private List<String> productSubTypeNameList;

    /**
     * 子二级产品uuid列表
     */
    private List<Long> productSubUuidList;

    /**
     * 资源是否超出分组日期范围之外
     */
    private Boolean offScale;

    /**
     * 是否允许拆分计划
     */
    private Integer allowSplitCampaign;


    /**
     * 创意模版配置 0-常规模版  1-聚合模版
     */
    private Integer creativeTemplateType;

    /**
     * 二级产品对应的skuId
     */
    private Long skuId;

    /**
     * 客户必投媒体数量（跨域产品专有字段）
     */
    private Integer requiredUnionMediaCount;

    /**
     * 首坑竞排
     */
    private List<CommonViewDTO> competExcludeNameList;
}
