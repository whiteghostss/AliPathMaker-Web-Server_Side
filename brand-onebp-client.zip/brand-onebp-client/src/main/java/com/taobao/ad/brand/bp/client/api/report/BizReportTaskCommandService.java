package com.taobao.ad.brand.bp.client.api.report;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.CommandAPI;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.report.query.ReportTaskQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportTaskViewDTO;

/**
 * 报表操作相关服务
 * @author yuncheng.lyc
 */
public interface BizReportTaskCommandService extends CommandAPI {

    String TAG = "ReportTask";

    /**
     * 报表-新建异步任务
     * @param context
     * @param taskViewDTO
     * @return
     */
    @ProcessEntrance(name = "新建异步任务", desc = "新建异步任务", opType = OpType.add, tag = TAG)
    SingleResponse<Long> addReportTask(ServiceContext context, ReportTaskViewDTO taskViewDTO);

    /**
     * 报表-编辑异步任务
     * @param context
     * @param taskViewDTO
     * @return
     */
    @ProcessEntrance(name = "编辑异步任务", desc = "编辑异步任务", opType = OpType.add, tag = TAG)
    SingleResponse<Long> modifyReportTask(ServiceContext context, ReportTaskViewDTO taskViewDTO);

    /**
     * 报表-删除异步任务
     * @param context
     * @param queryViewDTO
     * @return
     */
    @ProcessEntrance(name = "删除异步任务", desc = "删除异步任务", opType = OpType.delete, tag = TAG)
    SingleResponse<Long> deleteReportTask(ServiceContext context, ReportTaskQueryViewDTO queryViewDTO);

    /**
     * 报表-运行异步任务
     * @param context
     * @param queryViewDTO
     * @return
     */
    @ProcessEntrance(name = "运行异步任务", desc = "运行异步任务", opType = OpType.update, tag = TAG)
    SingleResponse<Long> runReportTask(ServiceContext context, ReportTaskQueryViewDTO queryViewDTO);


}
