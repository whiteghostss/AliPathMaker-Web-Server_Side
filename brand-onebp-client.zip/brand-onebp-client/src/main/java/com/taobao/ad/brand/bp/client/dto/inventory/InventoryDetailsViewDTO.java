package com.taobao.ad.brand.bp.client.dto.inventory;

import com.alibaba.abf.governance.dto.BaseViewDTO;
import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * @author jixiu.lj
 * @date 2023/3/21 08:56
 */
@Data
public class InventoryDetailsViewDTO extends BaseViewDTO {

    private Long subCampaignId;
    private List<InventoryDetailsDayAmountViewDTO> dayAmountList;

//    private InventoryDetailsResourceViewDTO inventoryDetailsResourceViewDTO;
//    private Map<String, InventoryDetailsResourceViewDTO> detailsResourceMap;
}
