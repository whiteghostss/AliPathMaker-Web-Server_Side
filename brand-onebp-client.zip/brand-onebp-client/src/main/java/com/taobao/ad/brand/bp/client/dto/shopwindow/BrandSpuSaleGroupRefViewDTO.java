package com.taobao.ad.brand.bp.client.dto.shopwindow;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/6/26
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class BrandSpuSaleGroupRefViewDTO extends BaseViewDTO {

    /**
     * 名称
     */
    private String name;

    /**
     * 售卖产品线
     *
     * @see com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleProductLineEnum
     */
    private Integer saleProductLine;

    /**
     * 售卖ssp二级产品
     */
    private List<ResourcePackageProductViewDTO> resourcePackageProductViewDTOList;
}
