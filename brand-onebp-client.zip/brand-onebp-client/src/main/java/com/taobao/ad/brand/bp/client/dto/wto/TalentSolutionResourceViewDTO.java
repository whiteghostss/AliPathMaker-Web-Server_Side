package com.taobao.ad.brand.bp.client.dto.wto;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * 方案达人资源信息
 * @author ximu
 * @date 2023/8/16
 */
@Data
public class TalentSolutionResourceViewDTO extends BaseViewDTO {
    /**
     * 方案id
     */
    private Long solutionId;
    /**
     * SSP二级产品ID
     */
    private Long sspProductId;
    /**
     * 达人id
     */
    private String talentId;
    /**
     * 达人UserID
     */
    private String talentUserId;
    /**
     * 达人昵称
     */
    private String talentNick;
}
