package com.taobao.ad.brand.bp.client.context;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 订单分组重新计算分组预定量、单价等数据
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SaleGroupResetCalculateUpdateContext {
    /**
     * 上下文
     */
    private ServiceContext serviceContext;
    /**
     * 分组信息
     */
    private List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList;
}
