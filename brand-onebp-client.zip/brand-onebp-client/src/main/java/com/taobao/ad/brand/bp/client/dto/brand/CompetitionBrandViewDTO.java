package com.taobao.ad.brand.bp.client.dto.brand;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author jixiu.lj
 * @date 2024/3/20 11:44
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CompetitionBrandViewDTO extends BaseViewDTO {
    /**
     * 品牌ID
     */
    private Long brandId;

    /**
     * 品牌名称
     */
    private String brandName;

    /**
     * 新力值
     */
    private Long winIndex;

    /**
     * 竞争热度
     */
    private Integer competitiveHeat;

}
