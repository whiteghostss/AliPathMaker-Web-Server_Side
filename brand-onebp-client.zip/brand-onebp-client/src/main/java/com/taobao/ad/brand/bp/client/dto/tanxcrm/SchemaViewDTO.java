package com.taobao.ad.brand.bp.client.dto.tanxcrm;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/4/14 16:32
 * @description ：
 * @modified By：
 */
@Data
public class SchemaViewDTO extends BaseViewDTO {

    /**
     * 主键
     */
    private Long id;

    /**
     * schema信息
     */
    private String schemaValue;

    /**
     * schema名称
     */
    private String schemaName;

    /**
     * ios包名
     */
    private String iosPackage;

    /**
     * android包名
     */
    private String androidPackage;

    /**
     * ulk对应schema信息
     */
    private String schemaUlkValue;

    /**
     * 集团中台人群id
     */
    private Long centerCrowdId;

    /**
     * 人群说明
     */
    private String crowdDesc;
}
