package com.taobao.ad.brand.bp.client.dto.media;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

@Data
public class MediaBusinessManagerViewDTO extends BaseViewDTO {

    private String name;
    private String email;
}
