package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.Date;

/**
 * @author yanjingang
 * @date 2023/3/14
 */
@Data
public class SalesContractViewDTO extends BaseViewDTO {

    /**
     * 合同ID
     */
    private Long contractId;
    /**
     * 投放账号
     */
    private Long memberId;

    private Integer productId;

    /**
     * 合同名称
     */
    private String name;

    /**
     * 合同号
     */
    private String  contractNum;

    /**
     * 客户昵称
     */
    private String nick;
    /**
     * 开始时间
     */
    private Date startTime;
    /**
     * 结束时间
     */
    private Date endTime;
    /**
     * 1:全扣，2：季扣（3个月）
     */
    private Integer paymentType;
    /**
     * 结算状态  -95 草稿 -90提交审核 0-未付款、1-已付款、2-欠费失效、3-违约失效
     */
    private Integer settleStatus;
    /**
     * 合同创建者
     */
    private String operator;
    /**
     * 合同总金额单位元
     */
    private Long totalmount;

    /**
     * 合同折扣价
     */
    private Long discountAmount;
    /**
     * 合同现金金额
     */
    private Long cashAmount;

    /**
     * 直销业绩归属json
     */
    private String directSalesJson;

    /**
     * 渠道业绩归属json
     */
    private String channelSalesJson;
    /**
     * 合同版本号
     */
    private Long version;

}
