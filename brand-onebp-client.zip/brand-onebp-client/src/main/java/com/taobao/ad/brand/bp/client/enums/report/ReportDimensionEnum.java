package com.taobao.ad.brand.bp.client.enums.report;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;

/**
 * adc上配置的维度枚举
 * @author yuncheng.lyc
 */
@AllArgsConstructor(access = AccessLevel.PACKAGE)
public enum ReportDimensionEnum {
    DIMENSION_All("mRptDimensionAll", "整体维度"),
    DIMENSION_MEMBER("mRptDimensionMember", "账户维度"),
    DIMENSION_CAMPAIGN_GROUP("mRptDimensionCampaignGroup", "订单维度"),
    DIMENSION_SALE_GROUP("mRptDimensionSaleGroup", "售卖分组维度"),
    DIMENSION_SALE_PRODUCT_LINE("mRptDimensionSaleProductLine", "售卖产品线维度"),
    DIMENSION_SPU("mRptDimensionSpu", "spu维度"),
    DIMENSION_RESOURCE_TYPE("mRptDimensionResourceType", "资源类型维度"),
    DIMENSION_CAMPAIGN("mRptDimensionCampaign", "计划维度"),
    DIMENSION_SUB_CAMPAIGN("mRptDimensionSubCampaign", "子计划维度"),
    DIMENSION_MERGE_CAMPAIGN("mRptDimensionMergeCampaign", "主补合并计划维度"),
    DIMENSION_ADGROUP("mRptDimensionAdgroup", "单元维度"),
    DIMENSION_SUB_CREATIVE("mRptDimensionSubCreative", "子创意维度"),
    DIMENSION_CREATIVE("mRptDimensionCreative", "创意维度"),
    DIMENSION_CREATIVE_TAG("mRptDimensionCreativeTag", "创意版本维度"),
    DIMENSION_CROWD("mRptDimensionCrowd", "人群维度"),
    DIMENSION_TERMINAL("mRptDimensionTerminal", "终端维度"),
    DIMENSION_FREQUENCY("mRptDimensionFrequency", "频次维度"),
    DIMENSION_IS_CLICK("mRptDimensionIsClick", "是否点击维度"),
    DIMENSION_MEDIA("mRptDimensionMedia", "媒体维度"),
    DIMENSION_PID_MEDIA("mRptDimensionPidMedia", "媒体（pid）维度"),
    DIMENSION_RESOURCE("mRptDimensionResource", "资源维度"),
    DIMENSION_IS_GUEST("mRptDimensionIsGuest", "新老客维度"),
    DIMENSION_SEX("mRptDimensionSex", "性别维度"),
    DIMENSION_AGE("mRptDimensionAge", "年龄维度"),
    DIMENSION_BUY_LEVEL("mRptDimensionBuyLevel", "购买力维度"),
    DIMENSION_IS_GUEST_CROWD("mRptDimensionIsGuestCrowd", "新老客x人群"),
    DIMENSION_LIVE_ANCHOR("mRptDimensionLiveAnchor", "主播"),
    DIMENSION_LIVE_ROOM("mRptDimensionLiveRoom", "直播间"),
    DIMENSION_LIVE_LAND_PAGE("mRptDimensionLiveSource", "落地页"),
    DIMENSION_TAO_RATE_BRAND("mRptDimensionTaoBrand", "淘内市占率品牌维度"),
    DIMENSION_TAO_RATE_CATEGORY("mRptDimensionTaoCategory", "淘内市占率类目维度"),
    @Deprecated
    DIMENSION_TALENT("mRptDimensionTalent", "达人维度"),
    DIMENSION_PROVINCE("mRptDimensionProvince", "省份维度"),
    DIMENSION_CITY("mRptDimensionCity", "城市维度"),
    @Deprecated
    DIMENSION_CONTENT("mRptDimensionContent", "内容维度"),

    DIMENSION_CATEGORY("mRptDimensionCategory", "类目维度"),
    DIMENSION_KEYWORD("mRptDimensionKeyword", "关键词维度(自定义)"),
    DIMENSION_KEYWORD_CLASSIFICATION("mRptDimensionKeywordClassification", "关键词类型维度"),
    DIMENSION_WORD_PACKAGE("mRptDimensionWordPackage", "智能词包维度"),
    DIMENSION_KEYWORD_BLACK("mRptDimensionKeywordBlack", "关键词维度(黑盒)"),
    DIMENSION_KEYWORD_GREY("mRptDimensionKeywordGrey", "关键词维度(灰盒)"),

    ;


    private String code;
    private String desc;



    public static ReportDimensionEnum getByValue(String code) {
        ReportDimensionEnum[] enums = ReportDimensionEnum.values();
        for (ReportDimensionEnum type : enums) {
            if (type.getCode().equals(code))
                return type;
        }
        return null;
    }


    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
