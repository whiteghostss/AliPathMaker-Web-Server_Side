package com.taobao.ad.brand.bp.client.dto.wto;

import lombok.Data;

import java.util.Date;

@Data
public class SupplierSolutionTalentConfigViewDTO {
    private Long id;

    private Long solutionResourceDetailId;

    private Long solutionId;

    /**
     * 归一化的媒体ID
     */
    private Integer unifiedMediaId;
    /**
     * 达人UserID
     */
    private String talentUserId;
    /**
     * 达人作品的内容类型
     */
    private Integer contentType;

    /**
     * 作品发布日期
     */
    private Date publishDate;

    private String contentTypeName;
}
