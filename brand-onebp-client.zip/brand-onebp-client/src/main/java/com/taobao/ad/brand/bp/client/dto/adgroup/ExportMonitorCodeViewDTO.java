package com.taobao.ad.brand.bp.client.dto.adgroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.DateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.PubDealViewDTO;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * 导出用
 * @author 弈云
 * @date 2023年04月04日
 * */
@Data
public class ExportMonitorCodeViewDTO extends BaseViewDTO {
    /**
     * 推广位名称
     * */
    private String adzoneName;

    /**
     * 资源位名称
     * */
    private String resourceName;
    /**
     * 资源位类型名称
     */
    private String resourceTypeName;
    /**
     * 资源位ID
     * */
    private Long resourceId;
    /**
     * 推广位ID
     * */
    private Long adzoneId;
    /**
     * 媒体名称
     * */
    private String mediaName;
    /**
     * 媒体SITEID
     * */
    private Long siteId;
    /**
     * 媒体ID
     * */
    private Long mediaId;
    /**
     * 端的名称
     * */
    private String osName;
    /**
     * 0ios 1安卓 5不限
     * */
    private Integer os;
    /**
     * 生成时间
     * */
    private Date gmtModified;
    /**
     * 曝光监测
     * */
    private String pvMonitorUrl;
    /**
     * 落地页点击
     * */
    private String clickUrl;
    /**
     * 点击监测
     * */
    private String clickMonitorUrl;
    /**
     * deeplink唤端链接
     * */
    private String deepLinkUrl;
    /**
     * ulk唤端
     * */
    private String ulkUrl;
    /**
     * 创意上的落地页
     * */
    private String landingPage;
    /**
     * 创意上的落地页
     * */
    private String landingUrl;
    /**
     * 采购行ID
     * */
    private Long purchaseRowId;
    /**
     * 创意ID
     * */
    private Long creativeId;
    /**
     * 创意名称
     * */
    private String creativeName;
    /**
     * 子计划ID
     * */
    private Long subCampaignId;
    /**
     * 创意打底日期（客户设置的）
     * */
    private List<DateViewDTO> bottomDateViewList;
    /**
     * 监测对应的采购行对应的客户设置的打底日期对应的pubdealList
     * 日期list是与客户填写的打底日期的交集
     * */
    private List<PubDealViewDTO> pubDealViewList;

    /**
     * email使用
     * */
    private String bottomConfig;


    private List<Integer> resourceSupportWakeUpList;
    private List<Integer> purchaseRowSupportWakeUpList;

    /**
     * 订单ID
     * */
    private Long campaignGroupId;
    /**
     * 单元ID
     * */
    private Long adgroupId;
    /**
     * 计划ID
     * */
    private Long campaignId;

    /**
     * 妈妈三段式PID
     * */
    private String pid;
    /**
     * 产品id
     */
    private Long sspProductId;
    /**
     * 达人id
     */
    private String talentUserId;
    /**
     * 达人昵称
     */
    private String talentNickName;

}
