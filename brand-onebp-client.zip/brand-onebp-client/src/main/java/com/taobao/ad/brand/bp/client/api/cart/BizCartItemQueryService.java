package com.taobao.ad.brand.bp.client.api.cart;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.cartitem.CartItemConsistencyCheckResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.cartitem.CartItemOrderViewDTO;
import com.taobao.ad.brand.bp.client.dto.rule.RuleCheckResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.cartitem.query.CartItemQueryOption;
import com.taobao.ad.brand.bp.client.dto.cartitem.query.CartItemQueryViewDTO;

import java.util.List;

/**
 * 加购行query
 * @author shiyan
 * @date 2024/6/26
 */
public interface BizCartItemQueryService extends QueryAPI {
    String TAG = "CartItem";

    /**
     * 列表查询（当前memberId下的加购行数据）
     * @param context
     * @param query
     * @return
     */
    @ProcessEntrance(name = "列表查询", desc = "列表查询", opType = OpType.query, tag = TAG)
    MultiResponse<CartItemViewDTO> findCartItemList(ServiceContext context, CartItemQueryViewDTO query, CartItemQueryOption adgroupQueryOption);

    /**
     * 获取加购行详情
     * @param context
     * @param id
     * @param type
     * @return
     */
    @ProcessEntrance(name = "获取加购行", desc = "加购行获取", opType = OpType.query, tag = TAG)
    SingleResponse<CartItemViewDTO> getCartItemById(ServiceContext context, Long id, Integer type);
    /**
     * 加购行一致性校验
     * @param context
     * @param ids
     * @return
     */
    @ProcessEntrance(name = "加购行一致性校验", desc = "加购行一致性校验", opType = OpType.query, tag = TAG)
    MultiResponse<CartItemConsistencyCheckResultViewDTO> checkCartItemConsistency(ServiceContext context, List<Long> ids);
    /**
     * 加购行下单校验
     * @param context
     * @param cartItemOrderViewDTO
     * @return
     */
    @ProcessEntrance(name = "加购行下单校验", desc = "加购行下单校验", opType = OpType.query, tag = TAG)
    MultiResponse<RuleCheckResultViewDTO> checkCartItemOrder(ServiceContext context, CartItemOrderViewDTO cartItemOrderViewDTO);
}
