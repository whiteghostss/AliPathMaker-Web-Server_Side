package com.taobao.ad.brand.bp.client.enums.report;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;

/**
 * 报表指标格式
 * @author yuncheng.lyc
 * @date 2023/3/7
 **/
@AllArgsConstructor(access = AccessLevel.PACKAGE)
public enum ReportMetricsFormatEnum {

//    /**
//     * 乘100+%
//     */
//    PERCENT,
//    /**
//     * 小时格式
//     */
//    HH,
//    /**
//     * 日期格式
//     */
//    YYYY_MM_DD,
//    /**
//     * 保留两位小数
//     */
//    SCALE_2,
//    /**
//     * 保留4位小数
//     */
//    SCALE_4,
//    /**
//     * 字符串
//     */
//    NORMAL,
//    /**
//     * 四舍五入取整
//     */
//    BIGINT_ROUND
}
