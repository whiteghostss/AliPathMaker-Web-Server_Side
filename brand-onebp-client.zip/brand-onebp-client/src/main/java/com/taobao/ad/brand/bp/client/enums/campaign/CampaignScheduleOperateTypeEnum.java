package com.taobao.ad.brand.bp.client.enums.campaign;

import com.taobao.ad.brand.bp.client.enums.CommonEnum;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/03/07
 */
public enum CampaignScheduleOperateTypeEnum implements CommonEnum {
    INQUIRY(1, "询量"),

    LOCK(2, "锁量"),

    RELEASE(3, "释量"),

    MEDIA_INQUIRY(4, "媒体询量"),

    MANDATORY_LOCK(5, "超接"),

    INQUIRY_CALLBACK(6, "询量回调"),

    LOCK_CALLBACK(7, "锁量回调"),

    RELEASE_CALLBACK(8, "释量回调"),

    SCROLL_DAILY_UPDATE(9, "滚量日更"),

    CANCEL(10, "取消询/锁量")

    ;

    private final int value;
    private final String desc;

    CampaignScheduleOperateTypeEnum(int value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public static CampaignScheduleOperateTypeEnum getByValue(Integer value) {
        if (value == null) {
            return null;
        }
        CampaignScheduleOperateTypeEnum[] statusArray = CampaignScheduleOperateTypeEnum.values();
        for (CampaignScheduleOperateTypeEnum status : statusArray) {
            if (status.getValue() == value.intValue()) {
                return status;
            }
        }
        return null;
    }

    @Override
    public int getValue() {
        return value;
    }

    @Override
    public String getDesc() {
        return desc;
    }
}
