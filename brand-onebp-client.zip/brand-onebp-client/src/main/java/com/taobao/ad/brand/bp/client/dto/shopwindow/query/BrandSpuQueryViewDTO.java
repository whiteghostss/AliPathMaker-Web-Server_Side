package com.taobao.ad.brand.bp.client.dto.shopwindow.query;

import com.taobao.ad.brand.bp.client.dto.base.BaseQueryViewDTO;
import lombok.*;

import java.util.List;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/6/25
 **/
@Data
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class BrandSpuQueryViewDTO extends BaseQueryViewDTO {
    /**
     * 主键ID列表
     */
    private List<Long> spuIdList;

    /**
     * 售卖产品线
     * @see com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleProductLineEnum
     */
    private List<Integer> saleProductLineList;

    /**
     * 售卖分组ID
     */
    private List<Long> resourcePackageSaleGroupIdList;

    /**
     * SSP 标签ID
     */
    private List<Long> tagIdList;

    /**
     * 样式ID列表
     */
    private List<Long> shopWindowTemplateIdList;

    /**
     * 状态
     * @see com.taobao.ad.brand.perform.client.enums.shopwindow.SpuStatusEnum
     */
    private List<Integer> statusList;

    /**
     * id name查询
     */
    private String keyword;

    /**
     * 是否支持自助下单
     */
    private Integer supportAutoApply;

    /**
     * spu类型
     * @see SpuTypeEnum
     */
    private List<Integer> typeList;

    /**
     * 营销场景
     * @see SpuMarketSceneTypeEnum
     */
    private List<Integer> marketSceneList;

    /**
     * 排除spu类型
     * @see SpuTypeEnum
     */
    private List<Integer> excludeTypeList;

    /**
     * 排除spu类型
     * @see SpuMarketSceneTypeEnum
     */
    private List<Integer> excludeMarketSceneList;

    /**
     * 售卖平台
     * TargetPlatformEnum
     */
    private List<Integer> targetPlatformList;

    /**
     * 是否拆分sku
     */
    private Integer hasSku;

    /**
     * 是否需要分页
     */
    private Boolean needPage = false;

    /**
     * 是否需要查询sku信息
     */
    private Boolean needSku = false;

    /**
     * 是否需要查询配置信息
     * e.g. 预览图、副预览图、spu描述、showCase、属性
     */
    private Boolean needConfig = false;


    /**
     * 是否需要查询关联关系
     * e.g. spu关联售卖分组、spu关联样式、spu关联标签、spu关联售卖产品线
     */
    private Boolean needRef = false;

    /**
     * 是否需要ssp产品线准入校验
     * spu列表页不需要，spu详情页需要
     */
    private Boolean needSspProductLineAuthJudge = false;

    /**
     * 是否查询套餐包
     */
    private boolean needBundleInfo = false;

    /**
     * 是否查询sku样式
     */
    private boolean needSkuCreativeStyle = true;

    /**
     * 是否需要spu展示规则控制，for新客（首单）
     */
    private boolean needSpuDisplayRuleControl = false;
}
