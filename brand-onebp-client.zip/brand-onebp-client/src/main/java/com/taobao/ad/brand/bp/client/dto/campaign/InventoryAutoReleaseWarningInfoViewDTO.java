package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author jixiu.lj
 * @date 2023/8/7 19:58
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InventoryAutoReleaseWarningInfoViewDTO extends BaseViewDTO {

    /**
     * 是否触发自动释量预警
     * @see com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum
     */
    private Integer autoReleaseWarning;

    /**
     * 是否已申请延期
     * @see com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum
     */
    private Integer isApply;
}
