package com.taobao.ad.brand.bp.client.dto.product;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.List;

/**
 * 资源排期
 * */
@Data
public class ResourceScheduleViewDTO extends BaseViewDTO {
    /**
     * 采购行ID
     * */
    private Long id;

    /**
     * 支持的唤端
     * */
    private List<Integer> wakeUpList;



}
