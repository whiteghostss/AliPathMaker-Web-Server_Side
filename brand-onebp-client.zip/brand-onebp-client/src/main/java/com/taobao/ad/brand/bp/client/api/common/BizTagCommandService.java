package com.taobao.ad.brand.bp.client.api.common;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.ad.brand.dto.common.TagViewDTO;
import com.alibaba.hermes.framework.api.CommandAPI;
import com.alibaba.hermes.framework.dto.response.SingleResponse;

/**
 * @Author: PhilipFry
 * @createTime: 2024年02月27日 20:09:15
 * @Description:
 */
public interface BizTagCommandService extends CommandAPI {
    String TAG = "tag";

    /**
     * 新增创意标签
     *
     * @param serviceContext
     * @param tagViewDTO
     * @return
     */
    @ProcessEntrance(name = "新增标签", desc = "新增标签", opType = OpType.add, tag = TAG)
    SingleResponse<Long> addTag(ServiceContext serviceContext, TagViewDTO tagViewDTO);

    /**
     * 更新创意标签
     *
     * @param serviceContext
     * @param tagViewDTO
     * @return
     */
    @ProcessEntrance(name = "更新标签", desc = "更新标签", opType = OpType.update, tag = TAG)
    SingleResponse<Integer> updateTag(ServiceContext serviceContext, TagViewDTO tagViewDTO);

    /**
     * 删除标签
     *
     * @param serviceContext
     * @param tagId
     * @return
     */
    @ProcessEntrance(name = "删除标签", desc = "删除标签", opType = OpType.update, tag = TAG)
    SingleResponse<Integer> deleteTag(ServiceContext serviceContext, Long tagId);
}
