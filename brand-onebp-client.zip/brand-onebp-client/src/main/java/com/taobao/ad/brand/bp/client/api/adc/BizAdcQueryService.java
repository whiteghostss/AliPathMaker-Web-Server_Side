package com.taobao.ad.brand.bp.client.api.adc;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.adc.AdcCdnViewDTO;
import com.taobao.ad.brand.bp.client.dto.adc.AdcComponentViewDTO;
import com.taobao.ad.brand.bp.client.dto.adc.query.AdcQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.adc.query.AdcRoleQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.adc.query.BasicVisibleComponentQueryViewDTO;

/**
 * ADC相关服务
 *
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
public interface BizAdcQueryService extends QueryAPI {
    String TAG = "Adc";

    /**
     * 查询菜单
     *
     * @param context
     * @param queryViewDTO
     * @return
     */
    @ProcessEntrance(name = "查询菜单", desc = "查询菜单", opType = OpType.query, tag = TAG)
    MultiResponse<AdcComponentViewDTO> findMenuList(ServiceContext context, AdcQueryViewDTO queryViewDTO);

    /**
     * 查询组件
     *
     * @param context
     * @param queryViewDTO
     * @return
     */
    @ProcessEntrance(name = "查询组件", desc = "查询组件", opType = OpType.query, tag = TAG)
    MultiResponse<AdcComponentViewDTO> findComponentList(ServiceContext context, AdcQueryViewDTO queryViewDTO);

    @ProcessEntrance(name = "查询oneSiteCdn配置", desc = "查询oneSiteCdn配置", opType = OpType.query, tag = TAG)
    MultiResponse<AdcCdnViewDTO> findOneSiteCdnList(ServiceContext context);

    @ProcessEntrance(name = "查询oneSiteCdn配置", desc = "查询oneSiteCdn配置", opType = OpType.query, tag = TAG)
    MultiResponse<AdcCdnViewDTO> findOneSiteCdnListByUrl(ServiceContext context,String domain);
    /**
     * 查询memberid拥有的adc角色roleCode
     *
     * @param context
     * @param queryViewDTO 需要是商家账号/代理商账号，不可以是叉乘账号
     * @return
     */
    @ProcessEntrance(name = "查询拥有的adc角色roleCode", desc = "查询拥有的adc角色roleCode", opType = OpType.query, tag = TAG)
    MultiResponse<String> findBoundAdcRole(ServiceContext context, AdcRoleQueryViewDTO queryViewDTO);

    /**
     * 查询 商家/生态伙伴/内部小二 基础可见的ADC菜单节点
     *
     * @param context
     * @param queryViewDTO
     * @return
     */
    @ProcessEntrance(name = "查询可见的基础ADC节点", desc = "查询可见的基础ADC节点", opType = OpType.query, tag = TAG)
    MultiResponse<AdcComponentViewDTO> findBasicVisibleComponentList(ServiceContext context, BasicVisibleComponentQueryViewDTO queryViewDTO);

    /**
     * 查询memberid是否是支持topshow自建创意的白名单客户
     *
     * @param context
     * @return
     */
    @ProcessEntrance(name = "查询是否是支持topshow自建创意的白名单客户", desc = "查询是否是支持topshow自建创意的白名单客户", opType = OpType.query, tag = TAG)
    SingleResponse<Boolean> queryIsTopShowWhiteCustomer(ServiceContext context);
}
