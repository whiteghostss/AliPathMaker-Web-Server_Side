package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaign.keyword.CampaignKeywordViewDTO;
import lombok.Data;

import java.util.List;

@Data
public class CampaignKeywordEstimateViewDTO extends BaseViewDTO {

    /**
     * 关键词列表
     */
    private CampaignKeywordViewDTO keywordViewDTO;

    /**
     * 提示文案
     */
    private String promptMsg;

    /**
     * 最小日均预估pv
     */
    private Long minDayPerPv;

    /**
     * 最大日均预估pv
     */
    private Long maxDayPerPv;
}
