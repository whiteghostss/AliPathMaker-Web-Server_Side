package com.taobao.ad.brand.bp.client.dto.mr.audiorule;

import lombok.Data;

/**
 * @author jixiu.lj
 * @date 2023/3/21 11:46
 */
@Data
public class AudioTimeViewDTO {
    private String unit;
    private Integer min;
    private Integer max;
}
