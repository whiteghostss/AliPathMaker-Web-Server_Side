package com.taobao.ad.brand.bp.client.api.creative;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.ad.brand.dto.adgroup.CreativeRefViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.adgroup.ExportMonitorCodeViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.DRCMessageViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.*;
import com.taobao.ad.brand.bp.client.dto.creative.notice.CreativeScoreResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.monitor.MonitorCodeQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportTaskViewDTO;

import java.util.List;
import java.util.Map;

public interface BizCreativeQueryService extends QueryAPI {
    String TAG = "Creative";

    /**
     * 分页列表查询
     *
     * @param context
     * @param query
     * @return
     */
    @ProcessEntrance(name = "分页列表查询", desc = "分页列表查询", opType = OpType.query, tag = TAG)
    MultiResponse<CreativePageViewDTO> findCreativePage(ServiceContext context, CreativeQueryViewDTO query);


    /**
     * 列表查询
     *
     * @param context
     * @param query
     * @return
     */
    @ProcessEntrance(name = "列表查询", desc = "列表查询", opType = OpType.query, tag = TAG)
    MultiResponse<CreativePageViewDTO> findCreativeNoPage(ServiceContext context, CreativeQueryViewDTO query);

    /**
     * 创意详情
     *
     * @param context
     * @param creativeId
     * @return
     */
    @ProcessEntrance(name = "创意详情", desc = "创意详情", opType = OpType.query, tag = TAG)
    SingleResponse<CreativePageViewDTO> getCreativeById(ServiceContext context, Long creativeId);


    /**
     * 创意详情
     *
     * @param context
     * @param creativeId
     * @return
     */
    @ProcessEntrance(name = "创意详情", desc = "创意详情", opType = OpType.query, tag = TAG)
    SingleResponse<CreativeViewDTO> getCreativeViewDTOById(ServiceContext context, Long creativeId);

    /**
     * 通过id列表查询创意
     *
     * @param serviceContext
     * @param idList
     * @return
     */
    @ProcessEntrance(name = "创意查询", desc = "创意查询", opType = OpType.query, tag = TAG)
    MultiResponse<CreativePageViewDTO> findCreativeByIdList(ServiceContext serviceContext, List<Long> idList);

    /**
     * 获取创意单元绑定关系
     *
     * @param context
     * @param queryViewDTO
     * @return
     */
    @ProcessEntrance(name = "查询创意CreativeRef", desc = "创意creativeRef", opType = OpType.query, tag = TAG)
    MultiResponse<CreativeRefViewDTO> findCreativeRefList(ServiceContext context, CreativeQueryViewDTO queryViewDTO);

    @ProcessEntrance(name = "创意协议对比", desc = "创意协议对比", opType = OpType.query, tag = TAG)
    Response compareProtocol(ServiceContext serviceContext, DRCMessageViewDTO drcMessageViewDTO);

    /**
     * 基于海棠创意数据拆分创意
     *
     * @param context
     * @param creativeSaveViewDTO
     * @return
     */
    @ProcessEntrance(name = "创意转换", desc = "创意转换", opType = OpType.add, tag = TAG)
    MultiResponse<CreativeViewDTO> convertCreative(ServiceContext context, CreativeSaveViewDTO creativeSaveViewDTO);

    /**
     * 非精准监测详情
     *
     * @param context
     * @param queryViewDTO
     * @return
     */
    @ProcessEntrance(name = "非精准监测详情", desc = "非精准监测详情", opType = OpType.query, tag = TAG)
    MultiResponse<ExportMonitorCodeViewDTO> getContentVersionById(ServiceContext context, MonitorCodeQueryViewDTO queryViewDTO);

    @ProcessEntrance(name = "查询批量修改创意异步任务", desc = "查询批量修改创意异步任务", opType = OpType.query, tag = TAG)
    MultiResponse<ReportTaskViewDTO> findBatchImportTaskList(ServiceContext context, CreativeQueryViewDTO creativeQueryViewDTO);

    @ProcessEntrance(name = "宝贝详情", desc = "宝贝详情", opType = OpType.query, tag = TAG)
    SingleResponse<Long> getItemById(ServiceContext context, List<Long> itemIds);

    @ProcessEntrance(name = "创意AI打分", desc = "创意AI打分", opType = OpType.query, tag = TAG)
    MultiResponse<CreativeScoreResultViewDTO> predictCreativeScore(ServiceContext context, List<CreativeScoreUnitViewDTO> creativeScoreUnitViewDTOList);

}
