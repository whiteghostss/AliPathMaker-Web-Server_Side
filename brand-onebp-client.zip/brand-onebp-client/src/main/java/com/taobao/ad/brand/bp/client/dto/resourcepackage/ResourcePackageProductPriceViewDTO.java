package com.taobao.ad.brand.bp.client.dto.resourcepackage;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/03/02
 */
@Data
public class ResourcePackageProductPriceViewDTO extends BaseViewDTO {
    /**
     * 所属资源包产品id
     */
    private Long resourcePackageProductId;

    /**
     * 产品刊例价格
     */
    private Long publishPrice;

    /**
     * 产品单价
     */
    private Long price;

    /**
     * 产品价格折扣
     */
    private Long priceRatio;

    /**
     * 产品预订量
     */
    private Long bookingAmount;

    /**
     * 产品金额设置类型：1-最小比例、2-固定金额、3-起投金额
     */
    private Integer type;

    /**
     * 产品金额最小比例
     */
    private Integer minRatio;

    /**
     * 产品固定金额/起投金额（分）
     */
    private Long castAmount;

    /**
     * 产品实际金额（分）
     */
    private Long actualAmount;

    /**
     * 产品实际净单价
     */
    private Long actualPrice;
    /**
     * 该价格波段下产品开始日期
     */
    private Date startDate;

    /**
     * 该价格波段下产品结束日期
     */
    private Date endDate;
    /**
     * 阶段预定量周期比例
     */
    private List<ResoucePackageProductReserveRatioViewDTO> reserveList;


}
