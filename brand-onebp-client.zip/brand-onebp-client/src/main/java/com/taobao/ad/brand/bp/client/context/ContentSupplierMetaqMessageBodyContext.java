package com.taobao.ad.brand.bp.client.context;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 内容供应商平台事件
 */
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class ContentSupplierMetaqMessageBodyContext implements Serializable {

    /**
     * 订单ID
     */
    private Long campaignGroupId;

    /**
     * 诉求ID
     */
    private Long demandId;

    private String tag;
}
