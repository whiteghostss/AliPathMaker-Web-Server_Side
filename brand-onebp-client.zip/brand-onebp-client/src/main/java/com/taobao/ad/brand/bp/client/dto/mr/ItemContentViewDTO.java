package com.taobao.ad.brand.bp.client.dto.mr;

import com.alibaba.hermes.framework.dto.DTO;
import lombok.Data;

import java.util.List;

/**
 * @author jixiu.lj
 * @date 2023/3/21 12:04
 */
@Data
public class ItemContentViewDTO implements DTO{
    private String itemName;
    private Integer itemType;
    private String itemDesc;
    private List<String> fileFormat;

}
