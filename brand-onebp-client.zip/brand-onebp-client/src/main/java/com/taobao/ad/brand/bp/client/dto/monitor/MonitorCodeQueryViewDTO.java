package com.taobao.ad.brand.bp.client.dto.monitor;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * 监测代码查询VO
 * 参数简称，防止透出具体的参数
 */
@Data
public class MonitorCodeQueryViewDTO extends BaseViewDTO {
    /**
     * bizCode
     */
    private String bizCode;
    /**
     * 单元id标识
     */
    private String a;
    /**
     * 版本id标识
     */
    private String v;
    /**
     * 广告主标识（memberid）
     */
    private String m;
    /**
     * 校验码标识（秘钥）
     */
    private String s;
    /**
     * 子计划标识（不参与加密）
     */
    private String c;
}
