package com.taobao.ad.brand.bp.client.dto.template.element;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/4/12 10:26
 * @description ：
 * @modified By：
 */
@Data
public class ElementTypePropertyViewDTO extends BaseViewDTO {

    private String elementTypeCode;

    private String elementTypeName;

    /**
     * 属性CODE
     */
    private String code;

    /**
     * 属性名称
     */
    private String name;

    /**
     * 属性值
     */
    private String value;
}
