package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.List;

/**
 * @author yanjingang
 * @date 2024/10/31
 */
@Data
public class CampaignTargetPageViewDTO extends BaseViewDTO {

    /**
     * 定向类型
     */
    private String targetType;

    /**
     * 定向值
     */
    private List<String> values;

}
