package com.taobao.ad.brand.bp.client.dto.creative;

import lombok.Data;

/**
 * @description:
 * @author: philipfry
 * @create: 2020-06-13 18:15
 **/
@Data
public class CreativeProtocolViewDTO {
    /**
     * 素材类型，比如图片
     */
    private Integer type;

    /**
     * 协议内容
     */
    private String content;

    /**
     * 高
     */
    private String height;

    /**
     * 宽
     */
    private String width;

    /**
     * 时长
     */
    private String duration;

    /**
     * 设备
     */
    private String device;

    /**
     * 媒体
     */
    private String media;

    private String templateId;

    private String contentType;

}
