package com.taobao.ad.brand.bp.client.dto.resource;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.sql.Time;
import java.util.List;

/**
 * @author jixiu.lj
 * @date 2023/3/29 17:48
 */
@Data
public class MediaResourceViewDTO extends BaseViewDTO {
    /**
     * 资源位ID
     * */
    private Long id;
    private Time resourcePutStartTime;
    /**
     * 资源位名称
     * */
    private String resourceName;

    private List<Integer> wakeUpList;

    private String resourceTypeName;

    private Long memberId;

    private String materialRuleIds;
}
