package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * @author jixiu.lj
 * @date 2023/8/10 16:23
 * 合同上的业绩归属信息
 */
@Data
public class SalesContractPerformanceEmployeeViewDTO extends BaseViewDTO {


    private static final long serialVersionUID = 4137602580329684389L;

    private String nick;
    private String empId;
    private String displayString;
    private String name;
}
