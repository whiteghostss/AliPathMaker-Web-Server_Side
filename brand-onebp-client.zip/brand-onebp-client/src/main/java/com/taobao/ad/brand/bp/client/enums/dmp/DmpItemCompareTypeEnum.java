package com.taobao.ad.brand.bp.client.enums.dmp;

import lombok.Getter;

/**
 * @author yanjingang
 * @date 2025/2/18
 */
@Getter
public enum DmpItemCompareTypeEnum {
    SELF(0, "自身"),
    BENCHMARK(1, "对比叶子类目平均"),
    ;

    private Integer code;
    private String desc;
    DmpItemCompareTypeEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }
    public static DmpItemCompareTypeEnum getByCode(Integer code) {
        for (DmpItemCompareTypeEnum itemLevel : DmpItemCompareTypeEnum.values()) {
            if (itemLevel.code.equals(code)) {
                return itemLevel;
            }
        }
        return null;
    }
}
