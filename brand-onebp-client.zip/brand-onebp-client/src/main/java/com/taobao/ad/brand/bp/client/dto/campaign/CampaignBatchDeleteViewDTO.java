package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import lombok.Data;

import java.util.List;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/03/06
 */
@Data
public class CampaignBatchDeleteViewDTO extends BaseViewDTO {
    /**
     * 待删除父子计划ID列表
     */
    private List<Long> campaignIds;
    /**
     * 二次确认
     */
    private Integer confirm;

    /**
     * 待删除父子计划实体列表
     */
    private List<CampaignViewDTO> deleteCampaignViewDTOList;
}
