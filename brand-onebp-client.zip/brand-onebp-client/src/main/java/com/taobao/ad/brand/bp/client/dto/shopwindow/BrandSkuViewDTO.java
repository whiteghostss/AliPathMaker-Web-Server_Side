package com.taobao.ad.brand.bp.client.dto.shopwindow;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/6/26
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class BrandSkuViewDTO extends BaseViewDTO {
    /**
     * 主键ID
     */
    private Long id;

    /**
     * 默认使用属性拼接
     */
    private String name;

    /**
     * 产品橱窗spu id
     */
    private Long spuId;

    /**
     * 售卖产品ID
     */
    private Long resourcePackageProductId;


    /**
     * ssp二级产品UUID
     */
    private Long sspProductUuid;

    /**
     * 售卖分组ID
     */
    private Long resourcePackageSaleGroupId;


    /**
     * sku状态
     * @see com.taobao.ad.brand.perform.client.enums.shopwindow.SkuStatusEnum
     */
    private Integer status;

    /**
     * 属性
     * 属性-属性值
     */
    private List<BrandCommonDictViewDTO> propertyList;


    /**
     * sku下的全量上架橱窗模板(sku二级产品下的可投模板与spu绑定模板样式的交集)
     */
    private List<BrandShopWindowTemplateViewDTO> creativeStyleList;


    /**
     * sku二级产品下所有可投模板
     */
    private List<BrandShopWindowTemplateViewDTO> templateList;

    /**
     * 风控准入
     */
    private Boolean authJudge;

    /**
     * 0元试用信息
     */
    private BrandSkuFreeTrailInfoViewDTO freeTrailInfo;

    /**
     * 套餐包
     */
    private List<BrandBundleViewDTO> bundleList;
    /**
     * sku售卖平台
     * TargetPlatformEnum
     */
    private List<Integer> targetPlatformList;
}
