package com.taobao.ad.brand.bp.client.enums;

import java.util.EnumSet;
import java.util.Objects;

public interface CommonEnum {
    int getValue();

    String getDesc();

    /**
     * 通过key获取枚举
     * @param value
     * @param clazz
     * @param <E>
     * @return
     */
    static <E extends Enum<E> & CommonEnum> E of(Integer value, Class<E> clazz) {
        if (value == null) {
            return null;
        }
        return EnumSet.allOf(clazz).stream().filter(e -> e.getValue() == value.intValue()).findFirst().orElse(null);
    }

    /**
     * 通过描述获取枚举
     * @param desc
     * @param clazz
     * @param <E>
     * @return
     */
    static <E extends Enum<E> & CommonEnum> E of(String desc, Class<E> clazz) {
        if (desc == null) {
            return null;
        }
        return EnumSet.allOf(clazz).stream().filter(e -> e.getDesc().equals(desc)).findFirst().orElse(null);
    }

    /**
     * 获取枚举描述列表
     * @param clazz
     * @param <E>
     * @return
     */
    static <E extends Enum<E> & CommonEnum> String[] getDescArray(Class<E> clazz) {
        return EnumSet.allOf(clazz).stream().map(e -> e.getDesc()).toArray(String[]::new);
    }

    /**
     * 通过值判断
     * @param value
     * @return
     */
    default boolean isSelf(Integer value) {
        if (value == null) {
            return false;
        }
        return getValue() == value;
    }

    /**
     * 通过描述判断
     * @param desc
     * @return
     */
    default boolean isSelf(String desc) {
        Objects.requireNonNull(desc);
        return getDesc().equals(desc);
    }
}
