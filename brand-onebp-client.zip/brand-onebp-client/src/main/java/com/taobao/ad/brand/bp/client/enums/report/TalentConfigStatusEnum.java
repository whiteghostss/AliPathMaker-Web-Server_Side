package com.taobao.ad.brand.bp.client.enums.report;


import com.taobao.ad.brand.bp.client.enums.CommonEnum;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;

@AllArgsConstructor(access = AccessLevel.PACKAGE)
public enum TalentConfigStatusEnum implements CommonEnum {

    UN_CONFIGURED(0, "未配置"),
    PARTIAL_CONFIGURED(2, "部分未配置"),
    CONFIGURED(1, "已配置");


    private final Integer value;
    private final String desc;

    @Override
    public int getValue() {
        return value;
    }

    @Override
    public String getDesc() {
        return desc;
    }

    public static String getDesc(Integer value) {
        for (TalentConfigStatusEnum statusEnum : TalentConfigStatusEnum.values()) {
            if (statusEnum.getValue() == value) {
                return  statusEnum.getDesc();
            }
        }
        return null;
    }

}
