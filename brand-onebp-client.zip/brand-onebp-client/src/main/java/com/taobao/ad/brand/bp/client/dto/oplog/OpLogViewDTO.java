package com.taobao.ad.brand.bp.client.dto.oplog;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

/**
 * @author jixiu.lj
 * @date 2024/3/20 14:47
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class OpLogViewDTO extends BaseViewDTO {
    private static final long serialVersionUID = -4155102731201617718L;

    /**
     * 业务场景
     */
    private String bizCode;

    /**
     * 实体类型
     */
    private String entityCode;

    /**
     * 操作类型
     */
    private String operateCode;

    /**
     * 用户所选操作详情
     */
    private String operateDetailCode;

    /**
     * 实体ID
     */
    private Long entityId;

    /**
     * 操作时间
     */
    private Date timestamp;

    /**
     * 操作人
     */
    private String operName;

    /**
     * 日志模板Key
     */
    private Long templateKey;

    /**
     * 日志traceId
     */
    private String traceId;

    /**
     * 日志文案
     */
    private String content;

    /**
     * 计划ID
     */
    private Long campaignId;

    /**
     * 单元ID
     */
    private Long adgroupId;
}
