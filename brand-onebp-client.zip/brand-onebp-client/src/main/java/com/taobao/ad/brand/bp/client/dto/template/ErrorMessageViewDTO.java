package com.taobao.ad.brand.bp.client.dto.template;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/4/12 17:14
 * @description ：
 * @modified By：
 */
@Data
public class ErrorMessageViewDTO extends BaseViewDTO {
    String key;
    String message;

    public ErrorMessageViewDTO(String key, String message) {
        this.key = key;
        this.message = message;
    }
}
