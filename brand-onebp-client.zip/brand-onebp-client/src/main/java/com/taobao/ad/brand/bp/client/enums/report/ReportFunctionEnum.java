package com.taobao.ad.brand.bp.client.enums.report;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;

/**
 * adc上配置的功能枚举
 * @author yuncheng.lyc
 */
@AllArgsConstructor(access = AccessLevel.PACKAGE)
public enum ReportFunctionEnum {
    FUNCTION_OVERVIEW_OFFLINE("mRptOverViewOffline", "首页-账户汇总"),
    FUNCTION_BASIC_ONLINE("mRptBasicOnline", "订单结案-实时数据"),
    FUNCTION_BASIC_OFFLINE("mRptBasicOffline", "订单结案-离线数据-总览"),
    FUNCTION_BASIC_OFFLINE_REACH("mRptBasicOfflineReach", "订单结案-离线数据-触达与传播"),
    FUNCTION_BASIC_OFFLINE_RECOMMEND("mRptBasicOfflineToRecommend", "订单结案-离线数据-种草心智"),
    FUNCTION_BASIC_OFFLINE_ITEM_HEATING("mRptBasicOfflineItemHeating", "订单结案-离线数据-新品加热"),
    FUNCTION_BASIC_ONLINE_EXPORT("mRptBasicOnlineExport", "订单结案-实时数据导出"),
    FUNCTION_BASIC_OFFLINE_EXPORT("mRptBasicOfflineExport", "订单结案-离线数据导出"),
    FUNCTION_MULTI_CUSTOM("mRptMultiCustom", "自定义查询任务"),
    FUNCTION_MULTI_PROMOTION("mRptMultiPromotion", "大促归因任务"),
    FUNCTION_MULTI_LIVE("mRptMultiLive", "直播归因任务"),
    FUNCTION_MULTI_COMMON("mRptMultiCommon", "常规导出任务"),
    FUNCTION_FAST_FINAL_OFFLINE("mRptFastFinalOffline", "快捷结案"),
    FUNCTION_AD_LIST_ONLINE("mRptAdListOnline", "投放列表-实时数据"),
    FUNCTION_AD_LIST_OFFLINE("mRptAdListOffline", "投放列表-离线数据"),
    FUNCTION_TAO_RATE_OFFLINE("mRptTaoRateOffline", "淘内市占率");




    private String code;
    private String desc;



    public static ReportFunctionEnum getByValue(String code) {
        ReportFunctionEnum[] enums = ReportFunctionEnum.values();
        for (ReportFunctionEnum type : enums) {
            if (type.getCode().equals(code))
                return type;
        }
        return null;
    }


    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
