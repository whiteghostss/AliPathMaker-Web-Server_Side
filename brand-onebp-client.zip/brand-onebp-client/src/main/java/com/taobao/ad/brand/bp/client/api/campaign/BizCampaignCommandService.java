package com.taobao.ad.brand.bp.client.api.campaign;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.realtime.CampaignRealTimeOptimizeViewDTO;
import com.alibaba.ad.brand.dto.frequency.FrequencyViewDTO;
import com.alibaba.ad.brand.sdk.constant.audience.field.BrandTargetTypeEnum;
import com.alibaba.hermes.framework.api.CommandAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.campaign.*;
import com.taobao.ad.brand.bp.client.dto.report.ReportTaskViewDTO;
import com.taobao.ad.brand.bp.client.enums.SwitchEnum;

import java.util.List;

/**
 * Campaign
 *
 * @author yuanxinxi
 * @date 2023/2/28
 */
public interface BizCampaignCommandService extends CommandAPI {

    String TAG = "Campaign";

    /**
     * 新建Campaign
     *
     * @param context
     * @param campaignViewDTO
     * @return campaignId
     */
    @ProcessEntrance(name = "新建Campaign", desc = "新建Campaign", opType = OpType.add, tag = TAG)
    MultiResponse<Long> addCampaign(ServiceContext context, CampaignViewDTO campaignViewDTO);

    /**
     * 批量新建计划
     * @param context
     * @param campaignViewDTOList
     * @return
     */
    @ProcessEntrance(name = "批量新建Campaign", desc = "批量新建Campaign", opType = OpType.add, tag = TAG)
    MultiResponse<Long> batchAddCampaign(ServiceContext context, List<CampaignViewDTO> campaignViewDTOList);
    /**
     * 更新CampaignGroup
     *
     * @param context
     * @param campaignViewDTO
     * @return
     */
    @ProcessEntrance(name = "更新Campaign", desc = "更新Campaign名称", opType = OpType.update, tag = TAG)
    SingleResponse<Long> updateCampaign(ServiceContext context, CampaignViewDTO campaignViewDTO);

    /**
     * 部分更新Campaign
     *
     * @param context
     * @param campaignViewDTO
     * @param updateSubCampaign 是否更新子计划，比如上下线开关，更新主计划时需要级联更新子计划状态
     * @return
     */
    @ProcessEntrance(name = "部分更新Campaign", desc = "部分更新Campaign", opType = OpType.update, tag = TAG)
    Response updateCampaignPart(ServiceContext context, CampaignViewDTO campaignViewDTO, boolean updateSubCampaign);

    /**
     * 部分更新Campaign定向
     *
     * @param context
     * @param campaignViewDTO
     * @param updateSubCampaign 是否更新子计划
     * @return
     */
    @ProcessEntrance(name = "部分更新Campaign定向", desc = "部分更新Campaign定向", opType = OpType.update, tag = TAG)
    Response updateCampaignTargetPart(ServiceContext context, CampaignViewDTO campaignViewDTO, boolean updateSubCampaign);

    /**
     * 指定类型删除Campaign定向
     */
    @ProcessEntrance(name = "指定类型删除Campaign定向", desc = "指定类型删除Campaign定向", opType = OpType.delete, tag = TAG)
    Response deleteCampaignTargetPart(ServiceContext context, Long campaignId, BrandTargetTypeEnum targetTypeEnum);

    /**
     * 更新CampaignGroup
     *
     * @param context
     * @param campaignViewDTO
     * @return
     */
    @ProcessEntrance(name = "更新Campaign名称", desc = "更新Campaign名称", opType = OpType.update, tag = TAG)
    SingleResponse<String> updateCampaignNameWithResp(ServiceContext context, CampaignViewDTO campaignViewDTO);

    @Deprecated
    @ProcessEntrance(name = "更新Campaign名称", desc = "更新Campaign名称", opType = OpType.update, tag = TAG)
    Response updateCampaignName(ServiceContext context, CampaignViewDTO campaignViewDTO);
    /**
     *
     * @param context
     * @param settingKey
     * @param SettingValue
     * @param campaignId
     * @return
     */
    @ProcessEntrance(name = "更新CampaignSetting", desc = "更新CampaignSetting", opType = OpType.update, tag = TAG)
    Response updateCampaignSetting(ServiceContext context, String settingKey,String SettingValue,Long campaignId);

    /**
     * 
     * @param context
     * @param settingKey
     * @param settingValue
     * @param campaignIds
     * @return
     */
    @ProcessEntrance(name = "批量更新CampaignSetting", desc = "批量更新CampaignSetting", opType = OpType.update, tag = TAG)
    Response batchUpdateCampaignSetting(ServiceContext context, String settingKey, String settingValue, List<Long> campaignIds );
    /**
     * 重设计划预算
     * @param context
     * @param campaignViewDTO
     * @return
     */
    @ProcessEntrance(name = "重设计划预算", desc = "重设计划预算", opType = OpType.update, tag = TAG)
    Response resetCampaignBudget(ServiceContext context, CampaignViewDTO campaignViewDTO);

    /**
     * 重设二级计划预算
     * @param context
     * @param campaignViewDTOList
     * */
    @ProcessEntrance(name = "重设二级计划预算", desc = "重设二级计划预算", opType = OpType.update, tag = TAG)
    Response resetSubCampaignBudget(ServiceContext context, List<CampaignViewDTO> campaignViewDTOList) ;
    /**
     * 更新计划排期
     * @param context
     * @param campaignScheduleViewDTO
     * @return
     */
    @ProcessEntrance(name = "更新计划排期", desc = "更新计划排期", opType = OpType.update, tag = TAG)
    Response updateCampaignSchedule(ServiceContext context, CampaignScheduleViewDTO campaignScheduleViewDTO);

    /**
     * 计划批量更新预定量
     * @param context
     * @return
     */
    @ProcessEntrance(name = "计划批量更新预定量", desc = "计划批量更新预定量", opType = OpType.update, tag = TAG)
    Response batchUpdateCampaignSchedule(ServiceContext context, CampaignSchedulePolicyViewDTO schedulePolicyViewDTO);
    /**
     * 排期询量
     *
     * @param context
     * @param inquiryOperateViewDTO
     * @return
     */
    @ProcessEntrance(name = "排期询量", desc = "排期询量", opType = OpType.update, tag = TAG)
    Response inquiry(ServiceContext context, CampaignInquiryOperateViewDTO inquiryOperateViewDTO);

    /**
     * 排期锁量
     *
     * @param context
     * @param inquiryOperateViewDTO
     * @return
     */
    @ProcessEntrance(name = "排期锁量", desc = "排期锁量", opType = OpType.update, tag = TAG)
    Response lock(ServiceContext context, CampaignInquiryOperateViewDTO inquiryOperateViewDTO);

    /**
     * 排期释量
     *
     * @param serviceContext
     * @param inquiryOperateViewDTO
     * @return
     */
    @ProcessEntrance(name = "排期释量", desc = "排期释量", opType = OpType.update, tag = TAG)
    Response release(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO);

    /**
     * 排期释量
     *
     * @param serviceContext
     * @param inquiryOperateViewDTO
     * @return
     */
    @ProcessEntrance(name = "按可用量库存锁量", desc = "按可用量库存锁量", opType = OpType.update, tag = TAG)
    Response availAmountLock(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO);
    /**
     * 排期取消询/锁量
     *
     * @param serviceContext
     * @param inquiryOperateViewDTO
     * @return
     */
    @ProcessEntrance(name = "排期取消询/锁量", desc = "排期取消询/锁量", opType = OpType.update, tag = TAG)
    Response cancel(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO);

    /**
     * 媒体询量
     *
     * @param serviceContext
     * @param inquiryOperateViewDTO
     * @return
     */
    @ProcessEntrance(name = "媒体询量", desc = "媒体询量", opType = OpType.update, tag = TAG)
    Response mediaInquiry(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO);

    /**
     * 强制占量
     *
     * @param serviceContext
     * @param inquiryOperateViewDTO
     * @return
     */
    @ProcessEntrance(name = "强制占量", desc = "强制占量", opType = OpType.update, tag = TAG)
    Response mandatoryLock(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO);

    /**
     * 审批流回调
     */
    @ProcessEntrance(name = "审批流回调", desc = "审批流回调", opType = OpType.update, tag = TAG)
    Response processFinishCallback(String processCode, String procInstId, Integer result, String extInfo);

    /**
     *计划开启暂停
     * @param context
     * @param campaignId
     * @param switchEnum
     * @return
     */
    @ProcessEntrance(name = "计划开启暂停", desc = "计划开启暂停", opType = OpType.update, tag = TAG)
    Response switchCampaign(ServiceContext context, Long campaignId, SwitchEnum switchEnum);

    /**
     * 批量开启暂停计划
     * @param context
     * @param campaignIds
     * @param switchEnum
     * @return
     */
    @ProcessEntrance(name = "批量计划开启暂停", desc = "批量计划开启暂停", opType = OpType.update, tag = TAG)
    Response batchSwitchCampaign(ServiceContext context, List<Long> campaignIds, SwitchEnum switchEnum);
    /**
     *计划开启暂停
     * @param context
     * @param campaignId
     * @return
     */
    @ProcessEntrance(name = "计划删除", desc = "计划删除", opType = OpType.update, tag = TAG)
    Response deleteCampaign(ServiceContext context, Long campaignId);

    @ProcessEntrance(name = "计划批量删除", desc = "计划批量删除", opType = OpType.update, tag = TAG)
    Response batchDeleteCampaign(ServiceContext context, CampaignBatchDeleteViewDTO campaignBatchDeleteViewDTO);

    @ProcessEntrance(name = "库存回调询量结果", desc = "库存回调询量结果", opType = OpType.update, tag = TAG)
    Response noticeInquiryResult(ServiceContext context, String inventoryResult);

    @ProcessEntrance(name = "库存回调锁量结果", desc = "库存回调锁量结果", opType = OpType.update, tag = TAG)
    Response noticeLockResult(ServiceContext context, String inventoryResult);

    @ProcessEntrance(name = "库存回调释量结果", desc = "库存回调释量结果", opType = OpType.update, tag = TAG)
    Response noticeReleaseResult(ServiceContext context, String inventoryResult);

    /**
     *
     * @param context memberId,optype = 0 ,lineid 136001
     * @param resourceProductId
     * @param sspTemplateIds
     * @return
     */
    @ProcessEntrance(name = "资源包更新计划模板信息", desc = "资源包更新计划模板信息", opType = OpType.update, tag = TAG)
    Response updateCampaignTemplate(ServiceContext context, Long resourceProductId, List<Long> sspTemplateIds);

    /**
     * 滚量日更
     */
    Response noticeScrollDailyUpdate();

    /**
     * 执行计划滚量（测试）
     * @param context
     * @param ids
     * @return
     */
    MultiResponse<Long> executeScrollDailyUpdate(ServiceContext context, List<Long> ids);

    /**
     *物理删除计划（自动化测试使用，有白名单）
     * @param context
     * @param campaignId
     * @return
     */
    @ProcessEntrance(name = "计划删除", desc = "计划删除", opType = OpType.update, tag = TAG)
    Response  physicsDeleteCampaign(ServiceContext context, Long campaignId);


    /**
     *
     * @param context memberId,optype = 0 ,lineid 136001
     * @param campaignDealNoticeViewDTO
     * @return
     */
    @ProcessEntrance(name = "tandeal发生变化", desc = "tandeal发生变化", opType = OpType.update, tag = TAG)
    Response tanxdealChange(ServiceContext context, CampaignDealNoticeViewDTO campaignDealNoticeViewDTO);



    /**
     *
     * @param context memberId,optype = 0 ,lineid 136001
     * @param campaignDealNoticeViewDTO
     * @return
     */
    @ProcessEntrance(name = "打底日期发生变化", desc = "打底日期发生变化", opType = OpType.update, tag = TAG)
    Response bottomDateChange(ServiceContext context, CampaignDealNoticeViewDTO campaignDealNoticeViewDTO);


    /**
     *
     * @param context
     * @param campaignInventoryAutoReleaseMsgViewDTOList
     * @return
     */
    @ProcessEntrance(name = "锁量库存自动释放预警触发", desc = "锁量库存自动释放预警触发", opType = OpType.update, tag = TAG)
    Response inventoryAutoRelease(ServiceContext context, List<CampaignInventoryAutoReleaseMsgViewDTO> campaignInventoryAutoReleaseMsgViewDTOList);

    /**
     * 计划开启关闭风险IP库开关
     * @param context
     * @param campaignId
     * @param isSupportSafeIp 1：开启，0：关闭
     * @param safeIpThreshold 风险IP库阈值
     * @return
     */
    @ProcessEntrance(name = "计划开启暂停风险IP库", desc = "计划开启暂停风险IP库", opType = OpType.update, tag = TAG)
    Response switchSafeIp(ServiceContext context, Long campaignId, Integer isSupportSafeIp, Integer safeIpThreshold);

    /**
     * 计划绑定ADV
     * @param serviceContext
     * @param campaignId
     * @param advIds
     */
    @ProcessEntrance(name = "计划绑定ADV", desc = "计划添加效果ADV", opType = OpType.update, tag = TAG)
    Response bindEffectAdv(ServiceContext serviceContext, Long campaignId, List<Long> advIds);

    /**
     * 计划解绑ADV
     * @param serviceContext
     * @param campaignId
     * @param advIds
     */
    @ProcessEntrance(name = "计划解绑ADV", desc = "计划解绑效果ADV", opType = OpType.update, tag = TAG)
    Response unBindEffectAdv(ServiceContext serviceContext, Long campaignId, List<Long> advIds);


    /**
     * 批量计划智能人群配置
     * @param serviceContext
     * @param campaignIdList
     * @param campaignRealTimeOptimizeViewDTO
     */
    @ProcessEntrance(name = "批量计划智能人群配置", desc = "批量计划智能人群配置", opType = OpType.update, tag = TAG)
    Response batchOptimizeConfig(ServiceContext serviceContext, List<Long> campaignIdList, CampaignRealTimeOptimizeViewDTO campaignRealTimeOptimizeViewDTO);

    /**
     * 保存实时优选信息
     * @param serviceContext
     * @param realTimeOptimizeInfoViewDTO
     */
    @ProcessEntrance(name = "保存实时优选信息", desc = "保存实时优选信息", opType = OpType.update, tag = TAG)
    Response saveRealTimeOptimizeInfo(ServiceContext serviceContext, CampaignRealTimeOptimizeInfoViewDTO realTimeOptimizeInfoViewDTO);

    /**
     * 计划锁量有效期延期申请
     *
     * @param serviceContext
     * @param delayLockApplyViewDTO
     * @return
     */
    @ProcessEntrance(name = "计划锁量有效期延期申请", desc = "计划锁量有效期延期申请", opType = OpType.update, tag = TAG)
    Response delayLock(ServiceContext serviceContext, CampaignDelayLockApplyViewDTO delayLockApplyViewDTO);

    /**
     * @deprecated
     * com.taobao.ad.brand.bp.client.api.frequency.BizFrequencyCommandService#saveDeliveredFrequency(com.alibaba.abf.governance.context.ServiceContext, com.alibaba.ad.brand.dto.frequency.FrequencyViewDTO, java.util.List)
     */
    @ProcessEntrance(name = "新建/编辑联合频控", desc = "新建/编辑联合频控", opType = OpType.update, tag = TAG)
    SingleResponse<Long> saveUnionFrequency(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO, List<Long> campaignIdList);

    /**
     * @deprecated
     * com.taobao.ad.brand.bp.client.api.frequency.BizFrequencyCommandService#frequencySwitch(com.alibaba.abf.governance.context.ServiceContext, com.alibaba.ad.brand.dto.frequency.FrequencyViewDTO)
     */
    @ProcessEntrance(name = "优化型频控上下线", desc = "优化型频控上下线", opType = OpType.update, tag = TAG)
    Response frequencySwitch(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO);

    /**
     * 新建、编辑计划批量导入任务
     * @param context
     * @param taskViewDTO
     * @return
     */
    @ProcessEntrance(name = "新建、编辑计划批量导入任务", desc = "新建计划批量导入任务", opType = OpType.add, tag = TAG)
    SingleResponse<Long> addBatchImportTask(ServiceContext context, ReportTaskViewDTO taskViewDTO);


    /**
     * 计划批量创建、编辑
     * @param context
     * @param campaignBatchImportParamViewDTO
     * @return
     */
    @ProcessEntrance(name = "计划批量创建、编辑", desc = "计划批量创建、编辑", opType = OpType.add, tag = TAG)
    Response addBatchCampaign(ServiceContext context, CampaignBatchImportParamViewDTO campaignBatchImportParamViewDTO);
    /**
     * 计划预订量批量导入任务
     * @param context
     * @param taskViewDTO
     * @return
     */
    @ProcessEntrance(name = "计划预订量批量导入任务", desc = "计划预订量批量导入任务", opType = OpType.add, tag = TAG)
    SingleResponse<Long> batchImportCampaignBookingAmountTask(ServiceContext context, ReportTaskViewDTO taskViewDTO);
    /**
     * 计划预订量批量导入
     * @param context
     * @param campaignBookingAmountBatchImportParamViewDTO
     * @return
     */
    @ProcessEntrance(name = "计划预订量批量创导入", desc = "计划预订量批量创导入", opType = OpType.update, tag = TAG)
    Response batchImportCampaignBookingAmount(ServiceContext context, CampaignBookingAmountBatchImportParamViewDTO campaignBookingAmountBatchImportParamViewDTO);

    /**
     * 特秀和showmax计划黑盒人群,AMB调用
     * @param campaignViewDTO
     * @return
     */
    @ProcessEntrance(name = "特秀和showmax计划黑盒人群", desc = "特秀和showmax计划黑盒人群", opType = OpType.update, tag = TAG)
    Response bindTXCampaignOptimizeCrowds(CampaignViewDTO campaignViewDTO);

    /**
     * 修改投放周期
     * @param context
     * @param campaignViewDTO
     * @return
     */
    @ProcessEntrance(name = "修改投放周期", desc = "修改投放周期", opType = OpType.update, tag = TAG)
    Response updateCampaignCastDate(ServiceContext context, CampaignViewDTO campaignViewDTO);



    /**
     * 修改投放周期
     * @param context
     * @param campaignViewDTO
     * @return
     */
    @ProcessEntrance(name = "重置结算单价", desc = "修改投放周期", opType = OpType.update, tag = TAG)
    Response updateCampaignSettlePrice(ServiceContext context, CampaignViewDTO campaignViewDTO);


    /**
     * 新建Campaign
     *
     * @param context
     * @param campaignViewDTO
     * @return campaignId
     */
    @ProcessEntrance(name = "自定义默认分配计划排期", desc = "自定义默认分配计划排期", opType = OpType.update, tag = TAG)
    MultiResponse<CampaignViewDTO> systemAssignCustomSchedule(ServiceContext context, CampaignViewDTO campaignViewDTO);


}
