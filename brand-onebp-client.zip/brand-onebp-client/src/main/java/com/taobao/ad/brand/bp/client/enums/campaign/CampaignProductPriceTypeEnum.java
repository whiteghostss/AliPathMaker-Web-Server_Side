package com.taobao.ad.brand.bp.client.enums.campaign;

import com.taobao.ad.brand.bp.client.enums.CommonEnum;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/03/08
 */
public enum CampaignProductPriceTypeEnum implements CommonEnum {
    MIN_RATE(1, "最小比例"),
    FIXED_AMOUNT(2, "固定金额"),
    START_AMOUNT(3, "起投金额");

    private final int value;
    private final String desc;

    CampaignProductPriceTypeEnum(int value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public static CampaignProductPriceTypeEnum getByValue(Integer value) {
        if (value == null) {
            return null;
        }
        CampaignProductPriceTypeEnum[] statusArray = CampaignProductPriceTypeEnum.values();
        for (CampaignProductPriceTypeEnum status : statusArray) {
            if (status.getValue() == value.intValue()) {
                return status;
            }
        }
        return null;
    }

    @Override
    public int getValue() {
        return value;
    }

    @Override
    public String getDesc() {
        return desc;
    }
}
