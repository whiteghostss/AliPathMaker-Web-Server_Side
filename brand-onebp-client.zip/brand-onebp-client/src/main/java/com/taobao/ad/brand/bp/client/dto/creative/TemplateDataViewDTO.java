package com.taobao.ad.brand.bp.client.dto.creative;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

@Data
public class TemplateDataViewDTO extends BaseViewDTO {
    private Long itemid;
    private Long shopid;

}
