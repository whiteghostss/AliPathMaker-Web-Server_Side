package com.taobao.ad.brand.bp.client.enums.campaign;

import lombok.Getter;

@Getter
public enum CampaignCrowdSceneEnum {
    CASTING(1,"实时优选人群");

    private Integer code;
    private String desc;

    CampaignCrowdSceneEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }
}
