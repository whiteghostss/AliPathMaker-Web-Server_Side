package com.taobao.ad.brand.bp.client.api.strategy;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.CommandAPI;
import com.alibaba.hermes.framework.dto.response.Response;

import java.util.List;

public interface BizStrategyCommandService extends CommandAPI {
    String TAG = "Strategy";

    /**
     * 天攻策略重新计算
     * @param context
     * @param strategyId
     * @return
     */
    @ProcessEntrance(name = "策略重新计算", desc = "策略重新计算", opType = OpType.update, tag = TAG)
    Response recalDoohStrategy(ServiceContext context, Long strategyId);

    /**
     * 保存点位
     * @param context
     * @param strategyId
     * @param type
     * @param pointIdList
     * @return
     */
    @ProcessEntrance(name = "保存策略点位", desc = "保存天攻策略点位", opType = OpType.update, tag = TAG)
    Response saveDoohStrategyPoint(ServiceContext context, Long strategyId, Integer type, List<String> pointIdList);

}
