package com.taobao.ad.brand.bp.client.enums.campaign;

import com.taobao.ad.brand.bp.client.enums.CommonEnum;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/03/08
 */
public enum CampaignPricePeroidAssignTacticEnum implements CommonEnum {
    MIN_RATE(1, "最小比例"),
    FIXED_AMOUNT(2, "固定金额"),
    START_AMOUNT(3, "起投金额"),
    CAST_DAY_RATIO(4, "投放日期比例");

    private final int value;
    private final String desc;

    CampaignPricePeroidAssignTacticEnum(int value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public static CampaignPricePeroidAssignTacticEnum getByValue(Integer value) {
        if (value == null) {
            return null;
        }
        CampaignPricePeroidAssignTacticEnum[] statusArray = CampaignPricePeroidAssignTacticEnum.values();
        for (CampaignPricePeroidAssignTacticEnum status : statusArray) {
            if (status.getValue() == value.intValue()) {
                return status;
            }
        }
        return null;
    }

    @Override
    public int getValue() {
        return value;
    }

    @Override
    public String getDesc() {
        return desc;
    }
}
