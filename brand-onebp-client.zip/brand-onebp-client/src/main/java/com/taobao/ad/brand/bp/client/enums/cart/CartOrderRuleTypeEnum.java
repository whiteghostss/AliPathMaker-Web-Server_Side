package com.taobao.ad.brand.bp.client.enums.cart;

/**
 * 购物车下单规则类型
 */
public enum CartOrderRuleTypeEnum {
    START_BUDGET_RULE(1, "起投金额规则"),
    SKU_ONLINE_RULE(2, "SKU上线规则"),
    CAMPAIGN_STATUS_RULE(3, "计划状态规则"),
    CAMPAIGN_INQUIRY_TIME_RULE(4, "计划询量时间规则"),
    CART_ITEM_CONSISTENCY_RULE(5, "加购行数据变更规则"),

    ;

    private final Integer value;
    private final String name;

    CartOrderRuleTypeEnum(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    public Integer getValue() {
        return value;
    }

    public String getName() {
        return name;
    }
}
