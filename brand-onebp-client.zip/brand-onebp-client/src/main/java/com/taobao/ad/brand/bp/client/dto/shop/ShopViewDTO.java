package com.taobao.ad.brand.bp.client.dto.shop;

import lombok.Data;

@Data
public class ShopViewDTO {

    private Long id;

    private String name;
}
