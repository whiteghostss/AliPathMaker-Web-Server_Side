package com.taobao.ad.brand.bp.client.enums.solution;


import lombok.Getter;

import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;

/**
 * 自助方案下单ErrorCode
 */
@Getter
public enum CartItemSolutionOrderErrorCodeEnum {
    // 系统异常，请稍后重试
    CAMPAIGN_GROUP_CREATE_ERROR("B4101", "订单创建失败，请稍后重试"),
    CAMPAIGN_GROUP_PROCESS_ERROR("B4102", "订单处理失败，请稍后重试"),

    ;

    private final String errorCode;
    private final String errorMsg;

    CartItemSolutionOrderErrorCodeEnum(String errorCode, String errorMsg) {
        this.errorCode = errorCode;
        this.errorMsg = errorMsg;
    }

    public static CartItemSolutionOrderErrorCodeEnum getOperateEnumByCode(String errorCode) {
        if (StringUtils.isBlank(errorCode)) {
            return null;
        }
        CartItemSolutionOrderErrorCodeEnum operateEnum = Arrays.stream(CartItemSolutionOrderErrorCodeEnum.values())
                .filter(cartItemSolutionOperateEnum -> cartItemSolutionOperateEnum.getErrorCode().equals(errorCode)).findFirst().orElse(null);
        return operateEnum;
    }
}
