package com.taobao.ad.brand.bp.client.dto.campaign;

import java.util.Date;
import java.util.List;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.fastjson.annotation.JSONField;

import lombok.Data;

@Data
public class CampaignDealNoticeViewDTO extends BaseViewDTO {

    /**
     * memberId
     */
    private Long memberId;
    /**
     * 二级计划id
     */
    private Long subCampaignId;
    /**
     * 打底日期
     * yyyy-MM-dd
     */
    @JSONField(format = "yyyy-MM-dd")
    private List<Date> bottomDays;

    private List<TanxDealDayChangeViewDTO> tanxDealDayChangeList;
}
