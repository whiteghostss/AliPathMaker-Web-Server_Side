package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;

import lombok.Builder;
import lombok.Data;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/03/02
 */
@Data
@Builder
public class CampaignGroupSchemaViewDTO extends BaseViewDTO {
    /**
     * schema id
     */
    private Long id;
    /**
     * schema名称
     */
    private String name;

    /**
     * 打开方式
     * 7= 小程序
     * 3= 阿里系原生
     * */
    private Integer openType;
}
