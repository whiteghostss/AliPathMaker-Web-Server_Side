package com.taobao.ad.brand.bp.client.dto.adgroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

@Data
public class AdgroupMonitorCodeViewDTO extends BaseViewDTO {
    private String pvMonitorUrl;
    private String landingUrl;
    private String clickMonitorUrl;
    private String clickUrl;
    private String deepLinkUrl;
    private String ulkUrl;
    private Long adzoneId;
    private Long subCampaignId;
    private Long purchaseRowId;
}
