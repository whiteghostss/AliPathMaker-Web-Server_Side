package com.taobao.ad.brand.bp.client.enums.creative;

import java.util.Arrays;

public enum CreativeCenterFrameEnum {
    TWO("2", "frame2", "creation2"),

    THREE("3", "frame3", "creation3"),
    ;
    private String code;
    private String clickArea;
    private String key;

    CreativeCenterFrameEnum(String code, String clickArea, String key) {
        this.code = code;
        this.clickArea = clickArea;
        this.key = key;
    }

    public static CreativeCenterFrameEnum getByCode(String code) {
        return Arrays.stream(CreativeCenterFrameEnum.values()).filter(one -> one.code.equals(code)).findAny().orElse(null);
    }

    public String getCode() {
        return code;
    }

    public String getClickArea() {
        return clickArea;
    }

    public String getKey() {
        return key;
    }
}
