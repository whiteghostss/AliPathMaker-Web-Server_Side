package com.taobao.ad.brand.bp.client.dto.motion;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/18
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class PredictDataViewDTO extends BaseViewDTO {
    /**
     * 曝光量
     */
    private Long impPv;
    /**
     * 点击量
     */
    private Long clkMonitorPv;
    /**
     * 到达量
     */
    private Long landPv;
    /**
     * 回搜回访量
     */
    private Long searchAndVisit;
    /**
     * 收藏加购量
     */
    private Long collectAddPurchase;
    /**
     * 成交量
     */
    private Long dealPv;
}
