package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FrequencyRefViewDTO extends BaseViewDTO {
    /**
     * 频控Id
     */
    private Long freqId;

    /**
     * 关联计划id
     */
    private List<Long> campaignIdList;

    /**
     * 关联单元id
     */
    private List<Long> adgroupIdList;
}
