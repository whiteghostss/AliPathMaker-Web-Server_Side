package com.taobao.ad.brand.bp.client.context;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.demand.DemandViewDTO;
import com.alibaba.ad.brand.sdk.constant.demand.field.ContentDemandStatusEnum;
import com.taobao.ad.brand.bp.client.enums.demand.DemandEventEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class DemandStateContext {

    /**
     * 上下文
     */
    private ServiceContext serviceContext;

    /**
     * 前置状态
     */
    private ContentDemandStatusEnum fromStatusEnum;

    private DemandViewDTO demandViewDTO;

    /**
     * 状态迁移Event
     */
    private DemandEventEnum eventEnum;

    /**
     * 忽略不支持迁移的错误
     */
    private boolean ignoreNotAcceptError = false;
}
