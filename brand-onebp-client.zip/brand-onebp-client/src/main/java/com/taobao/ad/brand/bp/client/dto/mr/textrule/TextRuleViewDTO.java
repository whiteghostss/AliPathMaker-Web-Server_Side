package com.taobao.ad.brand.bp.client.dto.mr.textrule;

import com.taobao.ad.brand.bp.client.dto.mr.ItemContentViewDTO;
import lombok.Data;

/**
 * @author jixiu.lj
 * @date 2023/3/21 11:41
 */
@Data
public class TextRuleViewDTO extends ItemContentViewDTO {
    private TextLengthLimitViewDTO textLengthLimit;
}
