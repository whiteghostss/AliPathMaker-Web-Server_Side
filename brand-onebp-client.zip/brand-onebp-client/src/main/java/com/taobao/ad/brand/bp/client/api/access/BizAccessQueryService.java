package com.taobao.ad.brand.bp.client.api.access;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.rule.RuleCheckResultViewDTO;

/**
 * 百灵准入判断查询
 * @author 石炎
 * @date 2024/8/15
 */
public interface BizAccessQueryService extends QueryAPI {
    String TAG = "Access";

    @ProcessEntrance(name = "商品准入判断", desc = "商品准入判断", opType = OpType.query, tag = TAG)
    SingleResponse<RuleCheckResultViewDTO> feedAccessJudge(ServiceContext context,Long itemId);

    @ProcessEntrance(name = "商品智能投放判断", desc = "商品智能投放判断", opType = OpType.query, tag = TAG)
    SingleResponse<RuleCheckResultViewDTO> feedSmartJudge(ServiceContext context,Long itemId);

    @ProcessEntrance(name = "sku产品线准入判断",desc = "sku产品线准入判断", opType = OpType.query, tag = TAG)
    SingleResponse<RuleCheckResultViewDTO> skuAccessJudge(ServiceContext context,Long skuId);


}
