package com.taobao.ad.brand.bp.client.enums;

import java.util.Arrays;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

public enum SwitchEnum {


    //-------------------------Campaign--------------------
    OPEN(1, "开启"),
    CLOSE(0, "关闭"),
    ;
    private static final Map<Integer, SwitchEnum> MAP;

    static {
        MAP = Arrays.stream(values()).collect(Collectors.toMap(SwitchEnum::getCode, Function.identity()));
    }

    private final Integer code;
    private final String desc;


    SwitchEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }

    public Integer getCode() {
        return code;
    }

    public static SwitchEnum getByCode(Integer code) {
        return Optional.ofNullable(code).map(MAP::get).orElse(null);
    }

}
