package com.taobao.ad.brand.bp.client.dto.wto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class SupplierSolutionViewDTO {
    private Long id;
    private Long solutionGroupId;
    private Long orderId;
    private BigDecimal budget;
    private Integer sspProductLineId;
    private Integer resourceType;
    private List<SupplierSolutionResourceDetailViewDTO> resourceDetailList;
//    private FileAttachDTO fileAttach;
    private String description;
    private Integer supplyAmount;
    private Boolean cpmSellUnit;
    private SupplierSolutionViewDTO candidate;
}
