package com.taobao.ad.brand.bp.client.enums.template;

import com.taobao.ad.brand.bp.client.enums.CommonEnum;

public enum OperationEnum implements CommonEnum {
    ADD(1, "新增"),
    EDIT(2, "编辑"),
    DETAIL(3, "详情"),
    COPY(4, "复制"),
    ;

    private final int value;
    private final String desc;

    OperationEnum(int value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public static OperationEnum getByValue(Integer value) {
        if (value == null) {
            return null;
        }

        OperationEnum[] statusArray = OperationEnum.values();
        for (OperationEnum status : statusArray) {
            if (status.getValue() == value.intValue()) {
                return status;
            }
        }
        return null;
    }


    @Override
    public int getValue() {
        return value;
    }

    public byte getByteValue() {
        return (byte) value;
    }

    @Override
    public String getDesc() {
        return desc;
    }
}
