package com.taobao.ad.brand.bp.client.dto.creative;

import com.google.common.collect.Lists;
import lombok.Data;

import java.util.List;

@Data
public class CreativeScoreUnitViewDTO {

    private Long creativeId;

    private List<Long> crowdIds;

    private Long adgroupId;

    private Long campaignId;

    private String creativeImageUrl;

    private String creativeTemplateName;

    private String uniqueKey;

}
