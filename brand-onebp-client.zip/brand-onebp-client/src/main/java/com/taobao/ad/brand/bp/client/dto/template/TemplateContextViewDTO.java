package com.taobao.ad.brand.bp.client.dto.template;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.*;

/**
 * @description:
 * @author: philipfry
 * @create: 2021-06-21 19:18
 **/
@Data
public class TemplateContextViewDTO extends BaseViewDTO {

    private Map<String, String> safeMap = new HashMap<>();

    private Map<Long, Map<String, String>> packageSafeMap =new HashMap<>();

    private Map<String, Object> properties = new HashMap<>();

    private LinkedHashMap<String, Map<String, Object>> columnMap = new LinkedHashMap<>();

    private Map<String, Map<String, Object>> bizMap = new HashMap<>();

    private List<Map<String, Object>> sizeList = new ArrayList<>();

    private Map<String, Object> data = new HashMap<>();

    private Map<String, MetaObject> engine2key = new HashMap<>();

    private List<Map<String, Object>> checkMap = new ArrayList<>();

    private Map<String, List<Map<String, String>>> relationMap = new HashMap<>();

    private TemplateViewDTO templateViewDTO;

    public String getKey(String engine){
        return Optional.ofNullable(engine2key.get(engine)).flatMap(MetaObject::getKey).orElse("");
    }

    public String getLabel(String engine){
        return Optional.ofNullable(engine2key.get(engine)).flatMap(MetaObject:: getLabel).orElse("");
    }

    @Data
    public static class MetaObject{
        private Optional<String> key;
        private Optional<String> label;

        public MetaObject(Optional<String> key, Optional<String> label) {
            this.key = key;
            this.label = label;
        }
    }
}
