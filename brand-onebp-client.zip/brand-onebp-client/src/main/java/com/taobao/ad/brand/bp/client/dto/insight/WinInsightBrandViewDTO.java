package com.taobao.ad.brand.bp.client.dto.insight;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author jixiu.lj
 * @date 2024/3/20 11:44
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class WinInsightBrandViewDTO extends BaseViewDTO {

    /**
     * 品牌Id
     */
    private Long brandId;
    /**
     * 品牌名称
     */
    private String brandName;

    /**
     * 一级类目id
     */
    private Long cateLevelOneId;
    /**
     * 一级类目名称
     */
    private String cateLevelOneName;

}
