package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.abf.governance.dto.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import lombok.Data;

import java.util.List;

@Data
public class CampaignDiffViewDTO extends BaseViewDTO {

    private List<CampaignViewDTO> addCampaignViewDTOList;

    private List<CampaignViewDTO> updateCampaignViewDTOList;

    private List<CampaignViewDTO> deleteCampaignViewDTOList;

//    /**
//     * 预算不一致
//     */
//    private Boolean diffBudget;
//    /**
//     * 人群不一致
//     */
//    private Boolean diffCrowd;
//    /**
//     * 投放时间不一致
//     */
//    private Boolean diffCastDate;
//    /**
//     * 单价不一致
//     */
//    private Boolean diffPrice;


}
