package com.taobao.ad.brand.bp.client.dto.adgroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import lombok.Data;

import java.util.List;

@Data
public class AdgroupEmailSendResultViewDTO extends BaseViewDTO {

    /**
     * 过滤后，需要发送的ids， 过滤掉程序化的
     * */
    private List<Long> needSendAdgroupIds;
    /**
     * 过滤后，需要发送的viewDTO
     * */
    private List<CommonViewDTO> needSendAdgroupList;
    /**
     * 成功的Ids
     * */
    private List<Long> succeedIds;
    /**
     * 发送成功的adgroupViewDTO
     * */
    private List<CommonViewDTO> succeedAgroupList;
    /**
     * 失败的Ids
     * */
    private List<Long> failedIds;
    /**
     * 发送失败的adgroupViewDTO
     * */
    private List<CommonViewDTO> failedAgroupList;
    /**
     * 接口传过来，需要发送的ids
     * */
    private List<Long> sendAdgroupIds;
    /**
     * 发送失败的adgroupViewDTO
     * */
    private List<CommonViewDTO> sendAgroupList;


}
