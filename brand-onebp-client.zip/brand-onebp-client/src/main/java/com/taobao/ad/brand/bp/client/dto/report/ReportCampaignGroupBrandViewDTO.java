package com.taobao.ad.brand.bp.client.dto.report;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReportCampaignGroupBrandViewDTO extends BaseViewDTO {
    /**
     * 账户id
     */
    @JSONField(name="memberid")
    private Long memberId;
    /**
     * 订单id
     */
    @JSONField(name="campaigngroupid")
    private Long campaignGroupId;
    /**
     * 品牌id
     */
    @JSONField(name="brandid")
    private Long brandId;
    /**
     * 品牌
     */
    @JSONField(name="brandname")
    private String brandName;
}
