package com.taobao.ad.brand.bp.client.dto.resourcepackage;


import com.alibaba.ad.universal.sdk.view.ViewDTO;
import lombok.Data;

import java.util.Date;

/**
 * @author gxg
 * Created on 2023/08/29.
 * 阶段预定量周期比例
 */
@Data
public class ResoucePackageProductReserveRatioViewDTO implements ViewDTO {

    /**
     * 开始时间
     */
    private Date startDate;

    /**
     * 结束时间
     */
    private Date endDate;

    /**
     * 预定量
     */
    private Long ratio;

}
