package com.taobao.ad.brand.bp.client.api.common;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.taobao.ad.brand.bp.client.dto.shield.ShieldSyncTextDTO;

import java.util.List;

/**
 * 风控校验相关
 *
 * @author gxg
 */
public interface ShieldAccessQueryService extends QueryAPI {

    /**
     * 风控校验名称
     * 计划/单元/创意 名称
     *
     * @param textList 名称列表
     * @return 校验结果
     */
    @ProcessEntrance(name = "风控校验名称", desc = "风控校验名称", opType = OpType.query, tag = "shield")
    MultiResponse<ShieldSyncTextDTO> textAccessBatchCheck(ServiceContext context, List<String> textList);


}
