package com.taobao.ad.brand.bp.client.enums.report;

import com.taobao.ad.brand.bp.client.enums.CommonEnum;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;

/**
 * 淘内市占率指标类型
 * 1-品牌搜索占比；2-品牌IPV占比；3-品牌成交类行为占比；4-人群渗透率；空值NULL-无弱势维度
 * @author yuncheng.lyc
 * @date 2023/3/7
 **/
@AllArgsConstructor(access = AccessLevel.PACKAGE)
public enum ReportTaoRateMetricsTypeEnum implements CommonEnum {

    /**
     * 品牌搜索占比
     */
    SEARCH_RATE(1, "搜索指数", "E2人群","「品牌定制_TOP」「Topshow_通投」「品牌专区」「品牌特秀」「Nreach类产品」", ""),
    /**
     * 品牌IPV占比
     */
    IPV_RATE(2, "进店指数","DE1人群","「品牌定制_进店U选包」「超级全域通_进店包」「超级互动城」",""),
    /**
     * 品牌成交类行为占比
     */
    GMV_RATE(3, "成交转化指数","P人群","「Topshow轻互动样式（领券&加购包）」「品牌互动率优化指标类产品」",""),
    /**
     * 人群渗透率
     */
    CROWD_RATE(4, "行业人群渗透","D人群","「品牌定制_曝光U选包」「品牌定制_TOP」「超级全域通」","");

    private final Integer value;
    private final String desc;

    private final String recommendCrowdName;

    private final String recommendProductName;

    private final String productLarkUrl;

    @Override
    public int getValue() {
        return value;
    }

    @Override
    public String getDesc() {
        return desc;
    }

    public String getRecommendCrowdName() {
        return recommendCrowdName;
    }

    public String getRecommendProductName() {
        return recommendProductName;
    }

    public String getProductLarkUrl() {
        return productLarkUrl;
    }
}
