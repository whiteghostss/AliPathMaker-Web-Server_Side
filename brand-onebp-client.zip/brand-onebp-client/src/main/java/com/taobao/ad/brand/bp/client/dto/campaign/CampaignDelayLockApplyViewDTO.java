package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.List;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/03/06
 */
@Data
public class CampaignDelayLockApplyViewDTO extends BaseViewDTO {
    /**
     * 一级计划ID列表
     */
    private List<Long> campaignIdList;

    /**
     * 二次确认
     */
    private Integer confirm;

    /**
     * 延期申请理由
     */
    private String reason;

    /**
     * 操作人ID
     */
    private String creatorId;
}
