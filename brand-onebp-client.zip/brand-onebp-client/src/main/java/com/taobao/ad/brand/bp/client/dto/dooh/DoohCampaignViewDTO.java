package com.taobao.ad.brand.bp.client.dto.dooh;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class DoohCampaignViewDTO extends BaseViewDTO {

    /**
     * 百灵客户memberID
     */
    private Long memberId;

    /**
     * 天攻计划ID
     */
    private Long id;

    /**
     * 天攻计划名称
     */
    private String name;

    /**
     * 百灵计划ID
     */
    private Long brandCampaignId;

    /**
     * 天攻策略ID
     */
    private Long strategyId;

    /**
     * 计划明细状态
     */
    private Integer status;

    /**
     * 分配预算
     */
    private Double budget;

    /**
     * 计划开始时间
     */
    private Date startDate;

    /**
     * 计划结束时间
     */
    private Date endDate;

    /**
     * 锁量结果下载包
     */
    private String lockResultOssUrl;

    /**
     * 询量结果下载包
     */
    private String searchResultOssUrl;

    /**
     * 计划要求的mr
     */
    private List<DoohCreativeMaterialViewDTO> materials;

    /*
     *需要的mr规范打包地址
     */
    private String mrOssUrl;


}
