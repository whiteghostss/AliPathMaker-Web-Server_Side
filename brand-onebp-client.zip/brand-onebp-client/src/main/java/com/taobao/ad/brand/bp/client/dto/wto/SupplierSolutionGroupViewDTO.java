package com.taobao.ad.brand.bp.client.dto.wto;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class SupplierSolutionGroupViewDTO extends BaseViewDTO {
    private Long id;
    private Long orderId;
    private Long demandId;
    private Long saleGroupId;
    private Long campaignGroupId;
    private BigDecimal budget;
//    private ValidPeriodDTO validPeriod;
    private List<SupplierSolutionViewDTO> solutionList;
    private BigDecimal totalValuePrice;
    private BigDecimal totalSettlementPrice;
}
