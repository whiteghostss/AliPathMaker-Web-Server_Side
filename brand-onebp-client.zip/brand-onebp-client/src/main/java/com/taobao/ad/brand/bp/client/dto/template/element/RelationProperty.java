package com.taobao.ad.brand.bp.client.dto.template.element;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * @author zhaorubing
 * @date 2024/8/14 17:24
 */
@Data
public class RelationProperty extends BaseViewDTO {

    /**
     * 关联属性code
     */
    private String property;

    /**
     * 关联元素elementId
     */
    private Long relationElement;
}
