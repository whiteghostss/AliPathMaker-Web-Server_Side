package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.*;

/**
 * 计划打底的采购行的信息
 * @author 弈云
 * @date 2023年03月28日
 * */
@Data
public class CampaignBottomInfoViewDTO extends BaseViewDTO {
    /**
     * 采购行id
     */
    private Long purchaseRowId;
    private Long subCampaignId;
    private List<PubDealViewDTO> pubDealList;
    private List<Integer> wakeUpList;
}
