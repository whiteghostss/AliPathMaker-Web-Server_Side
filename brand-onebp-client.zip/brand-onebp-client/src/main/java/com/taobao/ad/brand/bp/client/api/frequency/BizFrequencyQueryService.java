package com.taobao.ad.brand.bp.client.api.frequency;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.ad.brand.dto.frequency.FrequencyViewDTO;
import com.alibaba.ad.brand.sdk.constant.frequency.field.BrandFrequencyBizTypeEnum;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.campaign.FrequencyQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.FrequencyRefViewDTO;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/1/16
 **/
public interface BizFrequencyQueryService extends QueryAPI {
    String TAG = "Frequency";

    /**
     * 频控详情
     * @param serviceContext
     * @param frequencyId
     * @return
     */
    @ProcessEntrance(name = "频控详情", desc = "频控详情", opType = OpType.query, tag = TAG)
    SingleResponse<FrequencyViewDTO> getFrequencyById(ServiceContext serviceContext, Long frequencyId);

    /**
     * 频控列表
     * @param serviceContext
     * @param queryViewDTO
     * @return
     */
    @ProcessEntrance(name = "频控列表", desc = "频控列表", opType = OpType.query, tag = TAG)
    MultiResponse<FrequencyViewDTO> frequencyList(ServiceContext serviceContext, FrequencyQueryViewDTO queryViewDTO);

    /**
     * 查询频控ID关联的计划id
     * @param serviceContext
     * @param frequencyId
     * @return
     */
    @ProcessEntrance(name = "查询频控ID关联的实体id", desc = "查询频控ID关联的实体id", opType = OpType.query, tag = TAG)
    SingleResponse<FrequencyRefViewDTO> findFrequencyRefByFreqId(ServiceContext serviceContext, Long frequencyId, Integer frequencyBizType);
}
