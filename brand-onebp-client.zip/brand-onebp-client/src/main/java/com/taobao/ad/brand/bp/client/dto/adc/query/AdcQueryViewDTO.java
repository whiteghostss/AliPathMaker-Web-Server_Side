package com.taobao.ad.brand.bp.client.dto.adc.query;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.ToString;

import java.util.List;
import java.util.Map;

/**
 * ADC查询参数
 *
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@Data
@ToString
public class AdcQueryViewDTO extends BaseViewDTO {
    /**
     * adc业务编码
     */
    private String bizCode;
    /**
     * 组件码
     */
    private String componentCode;
    /**
     * 过滤map，配合 filter 使用， filter用的字段不要再全部平铺加了，太多了。
     */
    private Map<String, Object> filterMap;
    /**
     * adc权限角色
     */
    private List<String> adcRoles;
}
