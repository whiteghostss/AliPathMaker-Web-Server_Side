package com.taobao.ad.brand.bp.client.dto.resourcepackage;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;

import lombok.Data;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/22
 */
@Data
public class ResourcePackageNoticeSaleGroupViewDTO extends BaseViewDTO {

    private Long id;

    /**
     * 主分组id(补、配分组才有该id)
     */
    private Long mainGroupId;

    /**
     * 分组来源
     */
    private Integer source;

    /**
     * 模板*分组 状态
     */
    private Integer status;

    /**
     * 投放账号ID
     */
    private Long memberId;

    /**
     * 操作类型
     * @see com.taobao.ad.brand.bp.client.enums.resourcepackage.SaleGroupOperateTypeEnum
     */
    private Integer operateType;
}