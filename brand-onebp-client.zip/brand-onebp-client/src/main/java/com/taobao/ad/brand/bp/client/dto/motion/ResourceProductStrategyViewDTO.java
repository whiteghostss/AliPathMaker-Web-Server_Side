package com.taobao.ad.brand.bp.client.dto.motion;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/18
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class ResourceProductStrategyViewDTO extends BaseViewDTO {

    /**
     * 二级产品id
     */
    private Long resourceProductId;

    /**
     * 投放方式
     * @see com.alibaba.ad.nb.packages.v2.client.constant.product.CastTypeEnum
     */
    private Integer castType;

    /**
     * 二级产品洞察数据
     */
    private InsightDataViewDTO insightDataViewDTO;
}
