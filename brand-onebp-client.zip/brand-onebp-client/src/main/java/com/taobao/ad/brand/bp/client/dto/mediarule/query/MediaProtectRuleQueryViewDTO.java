package com.taobao.ad.brand.bp.client.dto.mediarule.query;

import com.taobao.ad.brand.bp.client.dto.base.BaseQueryViewDTO;
import lombok.Data;

import java.util.List;

/**
 * 保护规则查询DTO
 */
@Data
public class MediaProtectRuleQueryViewDTO extends BaseQueryViewDTO {

    /**
     * 状态 1:开启 0:关闭
     */
    private Integer status;

    /**
     * 媒体ID
     */
    private Long siteId;

    /**
     * 广告位idList
     */
    private List<String> pidList;

    /**
     * ID列表
     */
    private List<Long> ids;

    /**
     * 关键词
     */
    private String keyword;

    /**
     * 关键词类型
     */
    private Integer keywordType;
    /**
     * 资源类型
     */
    private Integer resourceType;
}
