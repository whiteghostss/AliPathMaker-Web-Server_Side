package com.taobao.ad.brand.bp.client.dto.spu;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * SPU起投门槛
 */
@Data
public class SpuMarketingRuleViewDTO extends BaseViewDTO {
    /**
     * spuId
     */
    private Long spuId;
    /**
     * 金额
     */
    private Long budget;
}
