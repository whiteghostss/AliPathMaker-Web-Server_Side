package com.taobao.ad.brand.bp.client.dto.tag;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.Map;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/3/4 18:53
 * @description ：
 * @modified By：
 */
@Data
public class TagViewDTO extends BaseViewDTO {

    /**
     * 标签id
     */
    private Long id;

    /**
     * 标签名称
     */
    private String tagName;

    /**
     * 对象类型
     */
    private Integer targetType;

    /**
     * 一级类目
     */
    private String firstCategory;

    /**
     * 二级类目
     */
    private String secondCategory;

    /**
     * 来源
     */
    private Integer source;

    /**
     * 使用场景
     */
    private Integer sceneType;


    /**
     * 计算规则
     */
    private String computeRule;

    /**
     * 状态
     */
    private Integer status;

    /**
     * 行业
     */
    private Long industry;

    /**
     * 扩展属性
     */
    private Map<String, String> properties;

    /**
     * 备注
     */
    private String description;

}
