package com.taobao.ad.brand.bp.client.context;

import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportMetricsConfigViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.export.CampaignExportEnum;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.export.CampaignGroupExportEnum;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.export.MaterialRuleExportEnum;
import lombok.Data;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author jixiu.lj
 * @date 2023/3/28 17:52
 */
@Data
public class ScheduleExportContext {

    /**
     * 订单ID
     */
    private Long campaignGroupId;

    /**
     * 订单
     */
    private CampaignGroupViewDTO campaignGroupViewDTO;


    /**
     * 全量计划
     */
    private List<CampaignViewDTO> campaignViewDTOList;

    /**
     * 产品map
     */
    private Map<Long, ProductViewDTO> productDTOMap;

    /**
     * 子合同ID
     */
    private Long subContractId;

    /**
     * 存储前缀
     */
    private String prefix;

    /**
     * 扩展名
     */
    private String extension;

    /**
     * 身份Code
     */
    private String identityTypeCode;
    /**
     * 计划ID列表
     */
    private List<Long> campaignIdList;
    /**
     * 是否为公共读url
     */
    private boolean publicReadUrl;

    /**
     * 是否需要购买价格明细sheet
     */
    private boolean needPurchasePriceDetail;

    /**
     * 是否需要补量价格明细sheet
     */
    private boolean needReplenishPriceDetail;

    /**
     * 是否需要配送价格明细sheet
     */
    private boolean needDistributionPriceDetail;

    /**
     * 计划-MR
     */
    private Map<Long, Set<Long>> campaignMaterialRuleMap;

    /**
     * 跨域计划是否使用了跨域模板
     */
    private Map<Long, Boolean> campaignHasCrossTemplate;

    /**
     * 是否需要获取永久生效的导出url
     */
    private boolean needPermanentExportUrl = false;


    /**
     * ADC列配置
     */
    private Map<MaterialRuleExportEnum, ReportMetricsConfigViewDTO> mrMetricsMap;
    private Map<MaterialRuleExportEnum, ReportMetricsConfigViewDTO> doohMrMetricsCodeMap;
    private Map<CampaignGroupExportEnum, ReportMetricsConfigViewDTO> campaignGroupMetricsMap;
    private Map<CampaignExportEnum, ReportMetricsConfigViewDTO> campaignMetricsMap;
    private Map<CampaignExportEnum, ReportMetricsConfigViewDTO> backupMetricsCodeMap;


}
