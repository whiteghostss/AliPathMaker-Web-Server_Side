package com.taobao.ad.brand.bp.client.dto.creative;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.template.ErrorMessageViewDTO;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/4/12 22:04
 * @description ：
 * @modified By：
 */
@Data
public class CreativeValidateViewDTO extends BaseViewDTO {

    /**
     * ssp模版ID
     */
    private Long sspTemplateId;

    /**
     * ssp模版名称
     */
    private String sspTemplateName;

    /**
     * 异常原因
     */
    private List<ErrorMessageViewDTO> errorList = new ArrayList<>();
}
