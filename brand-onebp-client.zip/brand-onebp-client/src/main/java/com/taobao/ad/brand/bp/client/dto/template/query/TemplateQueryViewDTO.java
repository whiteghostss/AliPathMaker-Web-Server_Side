package com.taobao.ad.brand.bp.client.dto.template.query;

import com.taobao.ad.brand.bp.client.dto.base.BaseQueryViewDTO;
import lombok.Data;

import java.util.List;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/3/4 18:55
 * @description ：
 * @modified By：
 */
@Data
public class TemplateQueryViewDTO extends BaseQueryViewDTO {

    private String keyword;

    private Long templateId;

    private List<Long> templateIds;

}
