package com.taobao.ad.brand.bp.client.dto.report;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 查询数据任务对象
 * @author yuncheng.lyc
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReportTaskViewDTO extends BaseViewDTO {
    /**
     * bizCode
     */
    private String bizCode;
    /**
     * 任务类型
     */
    private String functionCode;
    /**
     * 投放账号
     */
    private Long memberId;
    /**
     * 订单id
     */
    private Long campaignGroupId;
    /**
     * 任务id
     */
    private Long taskId;
    /**
     * 任务名称
     */
    private String taskName;
    /**
     * 任务参数
     */
    private Map<String, Object> taskParams;
    /**
     * 下载的，文件相关信息
     */
    private ReportFileViewDTO fileViewDTO;
    /**
     *  维度code
     */
    private List<String> dimensionCodes;
    /**
     *  维度code
     */
    private List<ReportDimensionConfigViewDTO> dimensionList;
    /**
     * 创建时间
     */
    private Date gmtCreate;
    /**
     * 修改时间
     */
    private Date gmtModified;
    /**
     * 任务状态
     * @see com.taobao.ad.brand.bp.client.enums.report.ReportTaskStatusEnum
     */
    private Integer status;
    /**
     * 任务状态
     */
    private String statusName;
    /**
     * oss地址
     */
    private String ossUrl;
    /**
     * 错误信息
     */
    private String errorMsg;
    /**
     * traceId
     */
    private String traceId;
    /**
     * 创建者
     */
    private String createBy;
    /**
     * 最后修改者
     */
    private String lastModifyBy;
    /**
     * 任务最后计算时间
     */
    private Date lastCalDate;
    /**
     * 人群列表id（自定义分析，增加过滤人群）
     */
    private List<Long> crowdIds;

    /**
     * 任务执行结果--json存储
     */
    private String data;
}
