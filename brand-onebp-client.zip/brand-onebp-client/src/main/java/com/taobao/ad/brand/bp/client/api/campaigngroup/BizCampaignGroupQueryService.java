package com.taobao.ad.brand.bp.client.api.campaigngroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.*;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.export.ScheduleExportQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignGroupBrandQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignGroupQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignGroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignGroupRealSettleQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignGroupSaleGroupBaseQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignGroupSaleGroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignGroupSettleQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.SaleGroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.sales.CampaignGroupBriefViewDTO;
import com.taobao.ad.brand.bp.client.dto.shop.ShopViewDTO;
import com.taobao.ad.brand.bp.client.dto.talent.TalentViewDTO;

import java.util.List;
import java.util.Map;

/**
 * CampaignGroup
 *
 * @author yanjingang
 * @date 2023/2/28
 */
public interface BizCampaignGroupQueryService extends QueryAPI {

    String TAG = "CampaignGroup";

    /**
     * 查询CampaignGroup分页列表
     *
     * @param context
     * @param campaignGroupQueryViewDTO
     * @param queryOption
     *
     * @return campaignGroupViewDTO
     */
    @ProcessEntrance(name = "获取CampaignGroup", desc = "获取CampaignGroup", opType = OpType.query, tag = TAG)
    MultiResponse<CampaignGroupViewDTO> findCampaignGroupPageList(ServiceContext context, CampaignGroupQueryViewDTO campaignGroupQueryViewDTO, CampaignGroupQueryOption queryOption);

    /**
     * 查询CampaignGroup列表
     *
     * @param context
     * @param campaignGroupQueryViewDTO
     *
     * @return campaignGroupViewDTO
     */
    @ProcessEntrance(name = "获取CampaignGroup", desc = "获取CampaignGroup", opType = OpType.query, tag = TAG)
    MultiResponse<CampaignGroupViewDTO> findCampaignGroupList(ServiceContext context, CampaignGroupQueryViewDTO campaignGroupQueryViewDTO);

    /**
     * 获取CampaignGroup
     *
     * @param context
     * @param id
     * @return campaignGroupViewDTO
     */
    @ProcessEntrance(name = "获取CampaignGroup", desc = "获取CampaignGroup", opType = OpType.query, tag = TAG)
    SingleResponse<CampaignGroupViewDTO> getCampaignGroupById(ServiceContext context, Long id);

    /**
     * 查询CampaignGroup列表
     * 支持品牌查询
     * @param context
     * @param campaignGroupQueryViewDTO
     *
     * @return campaignGroupViewDTO
     */
    @ProcessEntrance(name = "获取CampaignGroup", desc = "获取CampaignGroup", opType = OpType.query, tag = TAG)
    MultiResponse<CampaignGroupViewDTO> findCampaignGroupListByBrandInfos(ServiceContext context, CampaignGroupBrandQueryViewDTO campaignGroupQueryViewDTO);

    /**
     * 获取实结配置信息
     *
     * @param context
     * @param realSettleQueryViewDTO
     * @return
     */
    @ProcessEntrance(name = "获取实结配置信息", desc = "获取实结配置信息", opType = OpType.query, tag = TAG)
    SingleResponse<CampaignGroupSettleInfoViewDTO> getCampaignGroupRealSettleInfos(ServiceContext context, CampaignGroupRealSettleQueryViewDTO realSettleQueryViewDTO);

    /**
     * 获取订单结算信息
     * For结算
     *
     * @param context
     * @param settleQueryViewDTO
     * @return
     */
    @ProcessEntrance(name = "获取订单结算信息For结算", desc = "获取订单结算信息For结算", opType = OpType.query, tag = TAG)
    SingleResponse<CampaignGroupSettleInfoViewDTO> getCampaignGroupSettleInfoForSettle(ServiceContext context, CampaignGroupSettleQueryViewDTO settleQueryViewDTO);

    @ProcessEntrance(name = "获取订单及其售卖分组", desc = "获取订单及其售卖分组", opType = OpType.query, tag = TAG)
    SingleResponse<CampaignGroupResourcePackageViewDTO> getCampaignGroupWithSaleGroup(ServiceContext context, CampaignGroupSaleGroupQueryViewDTO saleGroupQueryViewDTO);

    @ProcessEntrance(name = "校验分组是否可以删除", desc = "校验分组是否可以删除", opType = OpType.query, tag = TAG)
    SingleResponse<Map<Long, SaleGroupCanDeleteViewDTO>> checkSaleGroupCanDelete(ServiceContext context, CampaignGroupSaleGroupBaseQueryViewDTO saleGroupQueryViewDTO);

    /**
     * 查询可选择的售卖分组信息
     *
     * @param context
     * @param campaignGroupQueryViewDTO
     *
     * @return CampaignGroupSaleGroupViewDTO
     */
    @ProcessEntrance(name = "查询可选择的售卖分组信息", desc = "查询可选择的售卖分组信息", opType = OpType.query, tag = TAG)
    MultiResponse<CampaignGroupSaleGroupPageViewDTO> findSaleGroupListWithCanSelectStatus(ServiceContext context, CampaignGroupSaleGroupQueryViewDTO campaignGroupQueryViewDTO);

    /**
     * 校验是否可以下单
     *
     * @param context
     * @param campaignGroupOrderCommandViewDTO
     * @return
     */
    @ProcessEntrance(name = "校验是否可以下单", desc = "校验是否可以下单", opType = OpType.query, tag = TAG)
    Response canOrder(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO);

    /**
     * 校验订单是否可以撤销改单
     *
     * @param context
     * @param id
     * @return
     */
    @ProcessEntrance(name = "校验订单是否可以撤销改单", desc = "校验订单是否可以撤销改单", opType = OpType.query, tag = TAG)
    Response canUnlockRevert(ServiceContext context, Long id);

    /**
     * 订单全部计划排期导出
     *
     * @param context
     * @param scheduleExportQueryViewDTO
     * @return campaignGroupViewDTO
     */
    @ProcessEntrance(name = "订单全部计划排期导出", desc = "订单全部计划排期导出", opType = OpType.query, tag = TAG)
    SingleResponse<String> exportSchedule(ServiceContext context, ScheduleExportQueryViewDTO scheduleExportQueryViewDTO);

    @ProcessEntrance(name = "订单唤端APPSchema", desc = "订单唤端APPSchema", opType = OpType.query, tag = TAG)
    MultiResponse<CampaignGroupSchemaViewDTO> findCampaignGroupSchemaList(ServiceContext context, CampaignGroupQueryViewDTO queryViewDTO);

    @ProcessEntrance(name = "获取分组绑定的人群信息", desc = "获取分组绑定的人群信息", opType = OpType.query, tag = TAG)
    SingleResponse<CampaignGroupSaleGroupCrowdInfoViewDTO> getSaleGroupCrowdList(ServiceContext context,Long campaignGroupId, Long saleGroupId);

    /**
     * 查询订单售卖分组
     * @param serviceContext
     * @param campaignGroupId
     * @param resourceSaleGroupId 资源包售卖分组id
     * @return
     */
    @ProcessEntrance(name = "获取订单售卖分组", desc = "获取订单售卖分组", opType = OpType.query, tag = TAG)
    SingleResponse<SaleGroupInfoViewDTO> getSaleGroup(ServiceContext serviceContext, Long campaignGroupId, Long resourceSaleGroupId);

    /**
     * 查询订单售卖分组
     * @param serviceContext
     * @param saleGroupQueryViewDTO
     * @return
     */
    @ProcessEntrance(name = "获取订单售卖分组", desc = "获取订单售卖分组", opType = OpType.query, tag = TAG)
    MultiResponse<SaleGroupInfoViewDTO> findSaleGroupList(ServiceContext serviceContext, SaleGroupQueryViewDTO saleGroupQueryViewDTO);

    @ProcessEntrance(name = "根据主订单获取查看报表url", desc = "根据主订单获取查看报表url", opType = OpType.query, tag = TAG)
    SingleResponse<String> getCampaignGroupReportUrlForSale(ServiceContext context, Long campaignGroupId);

    @ProcessEntrance(name = "获取生成合同文本协议必要的信息", desc = "获取生成合同文本协议必要的信息", opType = OpType.query, tag = TAG)
    SingleResponse<ContractContentViewDTO> getContractContentInfo(ServiceContext context, Long mainCampaignGroupId);

    /**
     * 查询订单包含的达人列表
     * @param serviceContext
     * @param campaignGroupId
     * @return
     */
    @Deprecated
    @ProcessEntrance(name = "获取订单包含的达人列表", desc = "获取订单包含的达人列表", opType = OpType.query, tag = TAG)
    MultiResponse<TalentViewDTO> findTalentList(ServiceContext serviceContext, Long campaignGroupId);

    /**
     * 根据订单ID获取店铺信息
     * @param serviceContext
     * @param campaignGroupId
     * @return
     */
    @ProcessEntrance(name = "获取订单对应店铺信息", desc = "获取订单对应店铺信息", opType = OpType.query, tag = TAG)
    SingleResponse<ShopViewDTO> getShopByCampaignGroupId(ServiceContext serviceContext, Long campaignGroupId);

    @ProcessEntrance(name = "订单询锁量结果下载", desc = "订单询锁量结果下载", opType = OpType.query, tag = TAG)
    SingleResponse<String> exportScheduleInquiryResult(ServiceContext context, ScheduleExportQueryViewDTO scheduleExportQueryViewDTO);

    @ProcessEntrance(name = "获取创建/更新Brief所需信息", desc = "获取创建/更新Brief所需信息", opType = OpType.query, tag = TAG)
    SingleResponse<CampaignGroupBriefViewDTO> getCampaignGroupBriefInfo(ServiceContext context, Long campaignGroupId);

    @ProcessEntrance(name = "获取店铺下的品牌", desc = "获取店铺下的品牌", opType = OpType.query, tag = TAG)
    MultiResponse<SalesContractBrandViewDTO> findCompleteBrandByShopId(ServiceContext context, Long shopId);

    @ProcessEntrance(name = "获取合同付款信息", desc = "获取合同付款信息", opType = OpType.query, tag = TAG)
    MultiResponse<SalesContractAmountViewDTO> getContractAmountInfoList(ServiceContext context, List<Long> contractIds);

    /**
     * 根据订单ID获取店铺信息
     * @param serviceContext
     * @param campaignGroupId
     * @return
     */
    @ProcessEntrance(name = "获取合同支付链接", desc = "获取合同支付链接", opType = OpType.query, tag = TAG)
    SingleResponse<String> getPaymentUrlByCampaignGroupId(ServiceContext serviceContext, Long campaignGroupId);
}
