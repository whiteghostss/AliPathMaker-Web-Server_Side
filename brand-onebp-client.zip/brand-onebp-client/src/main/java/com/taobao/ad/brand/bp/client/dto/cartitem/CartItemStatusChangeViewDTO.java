package com.taobao.ad.brand.bp.client.dto.cartitem;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * @author yanjingang
 * @date 2024/12/20
 */
@Data
public class CartItemStatusChangeViewDTO extends BaseViewDTO {
    private Long id;
    private Integer oldStatus;
    private Integer newStatus;
}
