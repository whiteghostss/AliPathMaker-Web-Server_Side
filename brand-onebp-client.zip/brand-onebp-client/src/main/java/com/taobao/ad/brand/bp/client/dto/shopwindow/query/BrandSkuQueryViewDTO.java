package com.taobao.ad.brand.bp.client.dto.shopwindow.query;

import com.taobao.ad.brand.bp.client.dto.base.BaseQueryViewDTO;
import lombok.*;

import java.util.List;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/6/25
 **/
@Data
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class BrandSkuQueryViewDTO extends BaseQueryViewDTO {
    /**
     * 主键Id
     */
    private List<Long> idList;

    /**
     * spuId列表
     */
    private List<Long> spuIdList;

    /**
     * 售卖产品ID
     */
    private List<Long> resourcePackageProductIdList;

    /**
     * 状态列表
     */
    private List<Integer> statusList;

    /**
     * 是否需要查询sku 绑定的橱窗样式信息
     */
    private Boolean needCreativeStyle = false;

    /**
     * 是否需要根据spu状态与是否支持自助售卖过滤sku
     */
    private boolean needFilterBySpu = true;
    /**
     * 是否查询套餐包
     */
    private boolean needBundleInfo = false;
}
