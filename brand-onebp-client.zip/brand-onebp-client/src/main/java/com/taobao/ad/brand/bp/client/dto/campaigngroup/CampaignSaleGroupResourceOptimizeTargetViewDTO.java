package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

@Data
public class CampaignSaleGroupResourceOptimizeTargetViewDTO extends BaseViewDTO {
    /**
     * 优化目标值
     * com.alibaba.ad.nb.ssp.constant.newproduct.OptimizeTargetEnum
     */
    private Integer optimizeTarget;

    /**
     * 是否必选
     */
    private Integer isNecessary;
}
