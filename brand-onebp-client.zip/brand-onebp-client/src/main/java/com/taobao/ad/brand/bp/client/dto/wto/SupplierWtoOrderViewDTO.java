package com.taobao.ad.brand.bp.client.dto.wto;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class SupplierWtoOrderViewDTO extends BaseViewDTO {
    private Long id;
    private String name;
    private Long memberId;
    private Long adMemberId;
    private Long campaignGroupId;
    private Long shopId;
    private List<Long> demandIdList;
    private BigDecimal budget;
    private Integer status;
    private String statusName;
    private List<SupplierSolutionGroupViewDTO> solutionGroupList;
}
