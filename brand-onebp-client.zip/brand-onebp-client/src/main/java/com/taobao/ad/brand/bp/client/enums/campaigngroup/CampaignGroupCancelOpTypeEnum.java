package com.taobao.ad.brand.bp.client.enums.campaigngroup;

import com.google.common.collect.Maps;

import java.util.Map;

/**
 * 撤单操作类型
 * @author yanjingang
 * @date 2023/3/6
 */
public enum CampaignGroupCancelOpTypeEnum {
    EXECUTE_CANCEL(1, "执行撤单"),
    WARNING_CANCEL(2, "撤单预警"),
    ;


    private final Integer value;
    private final String desc;

    CampaignGroupCancelOpTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public Integer getValue() {
        return value;
    }

    public String getDesc() {
        return desc;
    }

    private final static Map<Integer, CampaignGroupCancelOpTypeEnum> TYPE_2_ENUM_MAP = Maps.newHashMap();
    static {
        for (CampaignGroupCancelOpTypeEnum typeEnum : CampaignGroupCancelOpTypeEnum.values()) {
            TYPE_2_ENUM_MAP.put(typeEnum.getValue(), typeEnum);
        }
    }

    public static CampaignGroupCancelOpTypeEnum getByValue(Integer value) {
        if (value == null) {
            return null;
        }
        return TYPE_2_ENUM_MAP.get(value);
    }
}
