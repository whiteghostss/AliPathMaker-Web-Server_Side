package com.taobao.ad.brand.bp.client.dto.adgroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.PubDealViewDTO;
import lombok.Data;

import java.util.List;

/**
 * 采购行ViewDTO
 * */
@Data
public class PurchaseOrderViewDTO extends BaseViewDTO {
    /**
     * 采购行ID
     * */
    private Long purchaseRowId;
    /**
     * 采购行关联的pubdealId相关信息
     * */
    private List<PubDealViewDTO> pubDealViewDTOList;
}
