package com.taobao.ad.brand.bp.client.enums.campaign;

import com.taobao.ad.brand.bp.client.enums.CommonEnum;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/03/08
 */
public enum CampaignPVAssignSceneEnum implements CommonEnum {
    LAST_SUB_ROUND_UP(1, "最后一个倒减且PV上浮"),
    NORMAL_ROWND_DOWN(2, "常规往下抹除");

    private final int value;
    private final String desc;

    CampaignPVAssignSceneEnum(int value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public static CampaignPVAssignSceneEnum getByValue(Integer value) {
        if (value == null) {
            return null;
        }
        CampaignPVAssignSceneEnum[] statusArray = CampaignPVAssignSceneEnum.values();
        for (CampaignPVAssignSceneEnum status : statusArray) {
            if (status.getValue() == value.intValue()) {
                return status;
            }
        }
        return null;
    }

    @Override
    public int getValue() {
        return value;
    }

    @Override
    public String getDesc() {
        return desc;
    }
}
