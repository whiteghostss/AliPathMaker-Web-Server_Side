package com.taobao.ad.brand.bp.client.dto.campaign;

import lombok.Data;

import java.util.Date;

/**
 * 分天的计划库存打底配置信息
 * @author jixiu.lj
 * @date 2023/5/25 18:55
 */
@Data
public class CampaignImpressionViewDTO {

    /**
     * 日期
     * */
    private Date date;

    /**
     * @see CampaignImpressionStatusEnum
     * */
    private CampaignImpressionStatusEnum status;
    /**
     * 子计划ID
     * */
    private Long subCampaignId;

    /**
     * 计划库存打底配置状态
     */
    public enum CampaignImpressionStatusEnum {

        /**
         * 还未下单
         */
        NOT_ORDER,

        /**
         * 不需要配置媒体打底
         */
        UNQUALIFIED,

        /**
         * 待定（媒体pubdeal未录入等等）
         */
        NOT_READY,

        /**
         * 需要配置媒体打底
         */
        QUALIFIED;
    }

}
