package com.taobao.ad.brand.bp.client.dto.creative;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * 全域通黑盒使用
 * 每个日期对应的媒体直投创意和程序化创意
 * 用于程序化创意->媒体直投创意的创建
 * */
@Data
public class CreativeGenerateViewDTO extends BaseViewDTO {
    /**
     * 模版中心ID
     */
    private Long sspTemplateId;

    /**
     * 图片列表
     */
    private List<String> images;

    /**
     * 宝贝ID
     */
    private Long itemId;


    private String templateData;

    private Integer count;
}
