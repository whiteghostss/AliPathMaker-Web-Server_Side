package com.taobao.ad.brand.bp.client.enums;

import lombok.Getter;

/**
 * @author zhaorubing
 * @date 2024/8/23 17:12
 */
@Getter
public enum PeriodRangeTypeEnum {

    INTERVAL(0, "区间"),

    INTERSECTION(1, "交集");

    private final Integer value;
    private final String desc;

    PeriodRangeTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public static PeriodRangeTypeEnum getByValue(Integer value) {
        if (value == null) {
            return null;
        }

        PeriodRangeTypeEnum[] statusArray = PeriodRangeTypeEnum.values();
        for (PeriodRangeTypeEnum status : statusArray) {
            if (status.getValue() == value.intValue()) {
                return status;
            }
        }
        return null;
    }
}
