package com.taobao.ad.brand.bp.client.dto.cartitem;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 购物车下单
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CartItemOrderViewDTO extends BaseViewDTO {
    /**
     * 加购行id
     */
    private List<Long> cartItemIds;

}
