package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.List;


/**
 * 黑盒人群参数ViewDTO
 * */
@Data
public class OptimizeCrowdsParamsViewDTO extends BaseViewDTO {
    private Long campaignId;
    private List<OptimizeCrowdsAdgroupParamsViewDTO> optimizeCrowdsAdgroupParamsViewDTOList;
}
