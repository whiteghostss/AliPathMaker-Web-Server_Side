package com.taobao.ad.brand.bp.client.api.dmp;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.CrowdViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.query.CrowdQueryViewDTO;

import java.util.List;

/**
 * @Description:
 * @Author: dongyang
 * @Date: 2023/3/13
 */
public interface BizCrowdQueryService extends QueryAPI {

    String TAG = "Crowd";

    /**
     * 分页查询人群
     * @param context
     * @param query
     * @return
     */
    @ProcessEntrance(name = "分页查询", desc = "分页查询", opType = OpType.query, tag = TAG)
    MultiResponse<CrowdViewDTO> findCrowdPage(ServiceContext context, CrowdQueryViewDTO query);

    /**
     * 根据id查询人群(白盒统一)
     * @param context
     * @param ids
     * @return
     */
    @ProcessEntrance(name = "id查询", desc = "id查询", opType = OpType.query, tag = TAG)
    MultiResponse<CrowdViewDTO> findCrowdByIds(ServiceContext context, List<Long> ids);
    /**
     * 根据人群IDs查询覆盖人数
     * @param context
     * @param crowdIds
     * @return
     */
    @ProcessEntrance(name = "查询人群覆盖人数", desc = "查询人群覆盖人数", opType = OpType.query, tag = TAG)
    SingleResponse<Long> getCrowdCoverage(ServiceContext context, List<Long> crowdIds);
    /**
     * 预估新增人数
     * @param serviceContext
     * @param campaignId
     * @param crowdIdList
     * @return
     */
    @ProcessEntrance(name = "预估新增人数", desc = "预估新增人数", opType = OpType.query, tag = TAG)
    SingleResponse<Long> increaseCalculate(ServiceContext serviceContext, Long campaignId, List<Long> crowdIdList);
    /**
     * 查询showmax标签
     * @param serviceContext
     * @param campaignGroupId 可选参数
     * @param showmaxCrowdType
     * @return
     */
    @ProcessEntrance(name = "查询showmax标签", desc = "查询showmax标签", opType = OpType.query, tag = TAG)
    MultiResponse<CommonViewDTO> queryShowmaxCrowdTagList(ServiceContext serviceContext, Long campaignGroupId, Integer showmaxCrowdType);

    /**
     * 查询showmax人群
     * @param serviceContext
     * @param campaignGroupId
     * @param showmaxCrowdType
     * @return
     */
    @ProcessEntrance(name = "查询showmax人群", desc = "查询showmax人群", opType = OpType.query, tag = TAG)
    SingleResponse<CrowdViewDTO> getShowmaxCrowd(ServiceContext serviceContext, Long campaignGroupId, Integer showmaxCrowdType, List<Long> showmaxCrowdLabelIdList);


    /**
     * 定制逻辑：极简版支持行业定制人群售卖，对于命中白名单的套餐包，需要查询填充定制人群信息
     * @param serviceContext
     * @return
     */
    @ProcessEntrance(name = "查询行业定制人群", desc = "查询行业定制人群", opType = OpType.query, tag = TAG)
    MultiResponse<CrowdViewDTO> findShopWindowSlimCategoryCrowdList(ServiceContext serviceContext);

    /**
     * 分页查询创意预览人群
     * @param context
     * @param query
     * @return
     */
    @ProcessEntrance(name = "分页查询创意预览人群", desc = "分页查询创意预览人群", opType = OpType.query, tag = TAG)
    MultiResponse<CrowdViewDTO> findCreativePreviewCrowdPageList(ServiceContext context, CrowdQueryViewDTO query);
}
