package com.taobao.ad.brand.bp.client.dto.insight;

import com.taobao.ad.brand.bp.client.dto.base.BaseQueryViewDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author jixiu.lj
 * @date 2024/3/20 11:44
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class WinInsightBrandQueryViewDTO extends BaseQueryViewDTO {

    /**
     * 开始时间
     */
    private String startTime;

    /**
     * 结束时间
     */
    private String endTime;

    /**
     * 品牌Id
     */
    private Long brandId;

    /**
     * 一级类目id
     */
    private Long cateLevelOneId;

}
