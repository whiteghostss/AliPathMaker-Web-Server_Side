package com.taobao.ad.brand.bp.client.api.cart;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.alibaba.hermes.framework.api.CommandAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.cartitem.CartItemOrderViewDTO;
import com.taobao.ad.brand.bp.client.dto.cartitem.CustomerContactViewDTO;

import java.util.List;

/**
 * 加购行command
 * @author shiyan
 * @date 2024/6/26
 */
public interface BizCartItemCommandService extends CommandAPI {

    String TAG = "CartItem";
    /**
     * 新建加购行
     * @param context
     * @param cartViewDTO
     * @return CartId
     */
    @ProcessEntrance(name = "新建加购行", desc = "addCartItem", opType = OpType.add, tag = TAG)
    SingleResponse<Long> addCartItem(ServiceContext context, CartItemViewDTO cartViewDTO);
    /**
     * 删除加购行
     * @param context
     * @param ids
     * @return
     */
    @ProcessEntrance(name = "批量删除加购行", desc = "batchDeleteCartItem", opType = OpType.delete, tag = TAG)
    MultiResponse<Long> batchDeleteCartItem(ServiceContext context, List<Long> ids);

    /**
     * 加购行下单
     * @param context
     * @param cartItemOrderViewDTO
     * @return
     */
    @ProcessEntrance(name = "加购行下单", desc = "cartItemOrder", opType = OpType.add, tag = TAG)
    SingleResponse<Long> cartItemOrder(ServiceContext context, CartItemOrderViewDTO cartItemOrderViewDTO);

    /**
     * 保存新客次单客户联系方式
     * @param context
     * @param customerContactViewDTO
     * @return
     */
    @ProcessEntrance(name = "保存新客次单客户联系方式", desc = "保存新客次单客户联系方式", opType = OpType.add, tag = TAG)
    Response saveCustomerContact(ServiceContext context, CustomerContactViewDTO customerContactViewDTO);
}
