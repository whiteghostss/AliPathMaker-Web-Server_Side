package com.taobao.ad.brand.bp.client.enums.campaigngroup;

import java.util.Map;

import com.google.common.collect.Maps;

/**
 * 订单操作类型
 * @author yanjingang
 * @date 2023/3/6
 */
public enum CampaignGroupOpTypeEnum {
    ORDER(1, "下单"),
    MODIFY_ORDER(2, "申请改单"),
    ;


    private final Integer value;
    private final String desc;

    CampaignGroupOpTypeEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public Integer getValue() {
        return value;
    }

    public String getDesc() {
        return desc;
    }

    private final static Map<Integer, CampaignGroupOpTypeEnum> TYPE_2_ENUM_MAP = Maps.newHashMap();
    static {
        for (CampaignGroupOpTypeEnum typeEnum : CampaignGroupOpTypeEnum.values()) {
            TYPE_2_ENUM_MAP.put(typeEnum.getValue(), typeEnum);
        }
    }

    public static CampaignGroupOpTypeEnum getByValue(Integer value) {
        if (value == null) {
            return null;
        }
        return TYPE_2_ENUM_MAP.get(value);
    }
}
