package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * 计划展示项查询参数
 */
@Data
public class CampaignShowConfigQueryViewDTO extends BaseViewDTO {
//    /**
//     * 计划id
//     */
//    private Long campaignId;
    /**
     * 资源包二级产品id
     */
    private Long resourcePackageProductId;
}
