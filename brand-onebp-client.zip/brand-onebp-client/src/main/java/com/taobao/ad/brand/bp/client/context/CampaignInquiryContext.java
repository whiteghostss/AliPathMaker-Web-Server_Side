package com.taobao.ad.brand.bp.client.context;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignEventEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class CampaignInquiryContext {

    /**
     * 上下文
     */
    private ServiceContext serviceContext;

    /**
     * 计划列表
     */
    private List<CampaignViewDTO> campaignViewDTOList;

    /**
     * 计划操作
     */
    private CampaignEventEnum campaignEventEnum;
}
