package com.taobao.ad.brand.bp.client.enums.mediarule;

import com.taobao.ad.brand.bp.client.enums.CommonEnum;

public enum MediaRuleQueryEnum implements CommonEnum {
    ID(1, "id"),
    NAME(2, "名称"),
    ;

    private final int value;
    private final String desc;

    MediaRuleQueryEnum(int value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    public static MediaRuleQueryEnum getByValue(Integer value) {
        if (value == null) {
            return null;
        }

        MediaRuleQueryEnum[] statusArray = MediaRuleQueryEnum.values();
        for (MediaRuleQueryEnum status : statusArray) {
            if (status.getValue() == value.intValue()) {
                return status;
            }
        }
        return null;
    }

    @Override
    public int getValue() {
        return value;
    }

    @Override
    public String getDesc() {
        return desc;
    }
}
