package com.taobao.ad.brand.bp.client.dto.dooh;

import lombok.Data;

/**
 * 天攻点位分类
 */
@Data
public class DoohPointClassificationViewDTO {

    /**
     * 分类ID
     */
    private Integer id;

    /**
     * 分类名称
     */
    private String name;

    /**
     * 对应点位数量
     */
    private Integer pointCount;
}
