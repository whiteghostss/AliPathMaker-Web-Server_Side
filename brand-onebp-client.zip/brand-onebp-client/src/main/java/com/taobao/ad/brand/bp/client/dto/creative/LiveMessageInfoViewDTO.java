package com.taobao.ad.brand.bp.client.dto.creative;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * @author zhaorubing
 * @date 2024/12/10 14:26
 */
@Data
public class LiveMessageInfoViewDTO extends BaseViewDTO {

    /**
     * 投放账号
     */
    private Long memberId;

    /**
     * 订单（逗号分隔）
     */
    private String campaignGroupList;

    /**
     * 创意（逗号分隔）
     */
    private String creativeList;

    /**
     * 直播间ID
     */
    private Long liveId;

    /**
     * 拒审原因
     */
    private String newReason;

    /**
     * 宝贝ID
     */
    private Long itemId;

    /**
     * 审核时间
     */
    private String auditTime;
}
