package com.taobao.ad.brand.bp.client.context;

import com.taobao.ad.brand.bp.client.enums.message.DomainMessageTypeEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Map;

/**
 * @author ximu
 * @date 2023/7/18
 */
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class DomainMetaqMessageBodyContext implements Serializable {
    /**
     * 消息领域类型
     */
    private DomainMessageTypeEnum domainType;
    /**
     * 消息领域事件
     */
    private String domainEvent;
    /**
     * 广告主member
     */
    private Long memberId;
    /**
     * bizCode
     * 对应消息tag
     */
    private String bizCode;
    /**
     * 实体id
     */
    private Long entityId;

    /**
     * 预发环境路由使用，生产环境无需关注
     */
    private String env;
    /**
     * 扩展属性
     */
    private Map<String, String> properties;
}
