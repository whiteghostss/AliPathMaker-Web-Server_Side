package com.taobao.ad.brand.bp.client.dto.monitor;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

@Data
public class MonitorRuleXMediaViewDTO extends BaseViewDTO {

    private Long monitorRuleId;
    private Long mediaMemberId;
    private Long mediaId;
    private String abilityCode;
    private Integer mediaMonitorType;
}
