package com.taobao.ad.brand.bp.client.api.common;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.hermes.framework.api.CommandAPI;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.base.FileItemViewDTO;

/**
 * @author ximu
 * @date 2023/8/23
 */
public interface OssFileCommandService extends CommandAPI {
    /**
     * 文件上传
     * @param serviceContext - 上下文
     * @param fileItemViewDTO - 文件信息
     * @return
     */
    SingleResponse<FileItemViewDTO> upload(ServiceContext serviceContext, FileItemViewDTO fileItemViewDTO);
}
