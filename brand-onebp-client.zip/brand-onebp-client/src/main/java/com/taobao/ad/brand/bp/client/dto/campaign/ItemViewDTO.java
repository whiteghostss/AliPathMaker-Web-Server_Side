package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ItemViewDTO extends BaseViewDTO {
    /**
     * 宝贝id
     */
    private Long id;

    /**
     * 宝贝名称
     */
    private String name;

    /**
     * 价格(分)
     */
    private Double price;

    /**
     * 图片url
     */
    private String picUrl;
}
