package com.taobao.ad.brand.bp.client.dto.creative;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.common.BottomDateViewDTO;
import com.alibaba.ad.brand.dto.monitor.MonitorCodeViewDTO;
import lombok.Data;

import java.util.List;

/**
 * @Author: PhilipFry
 * @createTime: 2024年03月07日 15:12:58
 * @Description:
 */
@Data
public class CreativeRefPageViewDTO  extends BaseViewDTO {
    private Long id;
    /**
     * 广告组id
     */
    private Long adgroupId;
    /**
     * 组名称
     */
    private String adgroupName;
    /**
     * 创意id
     */
    private Long creativeId;
    /**
     * 创意名称
     */
    private String creativeName;

    /**
     * 计划id
     */
    private Long campaignId;

    /**
     * 打底时间
     * */
    private List<BottomDateViewDTO> bottomDateViewDTOList;
    /**
     * 监测链接
     * */
    private List<MonitorCodeViewDTO> monitorCodeViewDTOList;
    /**
     * 创意包id
     */
    private Long creativePackageId;

    /**
     * 创意包类型
     * {@link com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativePackageTypeEnum}
     */
    private Integer packageType;

    /**
     * 状态
     */
    private Integer onlineStatus;

    /**
     * 广告组所属业务场景
     */
    private Integer sceneId;
}
