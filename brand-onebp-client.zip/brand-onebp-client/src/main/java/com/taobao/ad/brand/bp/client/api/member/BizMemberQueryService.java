package com.taobao.ad.brand.bp.client.api.member;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CrmAdvInfoViewDTO;

/**
 * Member的信息查询
 */
public interface BizMemberQueryService extends QueryAPI {


    SingleResponse<CrmAdvInfoViewDTO> getCrmAdvInfo(ServiceContext context, Long customerMemberId);
}
