package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignSaleUnitEnum;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author yanjingang
 * @date 2024/07/09
 */
@Data
public class ContractContentCampaignViewDTO extends BaseViewDTO {
    /**
     * 计划ID
     */
    private Long campaignId;
    /**
     * 计划类型
     */
    private String saleTypeDesc;
    /**
     * 媒体名称
     */
    private String  sspMediaName;
    /**
     * 资源名称(对客)
     */
    private String  sspResourceName;
    /**
     * 售卖单位
     * @see BrandCampaignSaleUnitEnum
     */
    private Integer saleUnit;
    private String saleUnitDesc;

    /**
     * 计划开始时间
     */
    private Date startTime;
    /**
     * 计划结束时间
     */
    private Date endTime;
    /**
     * 计划金额，单位分
     */
    private Long budget;
    /**
     * saleUnit = 4或11时，获取此属性
     * 其他取amount
     */
    private Long cptAmount;
    /**
     * 投放数量
     * 单位PV，展示时除以1000
     */
    private Long amount;

    /**
     * 最终展示的预定量，扩大了1000倍
     */
    private Long displayAmount;

    /**
     * 刊例价，单位为分
     */
    private List<Long> publisherPriceList;
    /**
     * 折扣比例，扩大10000倍，8000=80%
     */
    private List<Long> discountRatioList;
    /**
     * 折后净价，单位为分
     */
    private List<Long> discountPriceList;

}
