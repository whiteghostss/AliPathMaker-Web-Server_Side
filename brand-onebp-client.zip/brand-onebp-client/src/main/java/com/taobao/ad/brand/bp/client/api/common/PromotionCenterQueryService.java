package com.taobao.ad.brand.bp.client.api.common;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.taobao.ad.brand.bp.client.dto.sellercoupons.SellerCouponViewDTO;
import com.taobao.ad.brand.bp.client.dto.sellercoupons.SellerCouponsQueryViewDTO;

/**
 * @Author: PhilipFry
 * @createTime: 2023年09月14日 10:27:56
 * @Description: 推广中心查询接口
 */
public interface PromotionCenterQueryService extends QueryAPI {
    String TAG = "PromotionCenter";

    /**
     * 分页查询数据
     *
     * @param context
     * @param queryViewDTO
     * @return
     */
    @ProcessEntrance(name = "查询卖家卡券数据列表", desc = "查询卖家卡券数据列表", opType = OpType.query, tag = TAG)
    MultiResponse<SellerCouponViewDTO> querySellerCouponsList(ServiceContext context, SellerCouponsQueryViewDTO queryViewDTO);
}
