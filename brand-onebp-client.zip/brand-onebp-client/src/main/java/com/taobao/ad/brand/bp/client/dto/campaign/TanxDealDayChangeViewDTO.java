package com.taobao.ad.brand.bp.client.dto.campaign;

import java.util.Date;
import java.util.List;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;

import lombok.Data;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/05/15
 */
@Data
public class TanxDealDayChangeViewDTO extends BaseViewDTO {
    /**
     * 日期
     */
    private Date day;
    /**
     * 是否发生tanxDealId变更
     */
    private boolean changed;
    /**
     * 更新前tanxDealId列表
     */
    private List<Long> tanxDealIdsBeforeChange;
    /**
     * 更新后tanxDealId列表
     */
    private List<Long> tanxDealIdsAfterChange;

}
