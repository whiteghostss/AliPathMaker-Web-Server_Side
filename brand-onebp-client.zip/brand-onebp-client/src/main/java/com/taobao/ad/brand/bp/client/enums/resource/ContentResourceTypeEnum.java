package com.taobao.ad.brand.bp.client.enums.resource;

import lombok.Getter;

/**
 * @author ximu
 * @date 2023/7/20
 */
@Getter
public enum ContentResourceTypeEnum {
    COMMON("defaults", "常规资源"),
    TALENT("talent", "达人资源");

    private final String spiCode;
    private final String desc;

    ContentResourceTypeEnum(String spiCode, String desc) {
        this.spiCode = spiCode;
        this.desc = desc;
    }

}
