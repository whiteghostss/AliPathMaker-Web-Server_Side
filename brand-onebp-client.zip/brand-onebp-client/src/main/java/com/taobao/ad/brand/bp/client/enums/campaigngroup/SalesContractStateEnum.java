package com.taobao.ad.brand.bp.client.enums.campaigngroup;

/**
 * @author yanjingang
 * @date 2023/3/12
 */
public enum SalesContractStateEnum {
    WAIT_APPROVE_AFTER_CREATE(1100, "待审核"),
    WAIT_APPROVE_MODIFY(1130, "修改合同后提审"),
    WAIT_APPROVE_MODIFY_AFTER_LAUNCH(1140, "已付款修改后提审"),
    WAIT_PAYMENT_AFTER_CREATE(1101, "待扣款"),
    PAYED(1102, "已扣款上线"),
    WAIT_PAYMENT_AFTER_PAYED(1131, "待扣款"),
    WAIT_PAYMENT_AFTER_LAUNCH(1141, "投放中修改后待扣款"),
    WAIT_ONLINE_CONFIRM(1105, "待线上签约"),
    WAIT_RECEIPT_APPROVAL(1103, "凭证审核中"),

    ;

    SalesContractStateEnum(Integer value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private Integer value;
    private String desc;

    public Integer getValue() {
        return value;
    }

    public String getDesc() {
        return desc;
    }
}
