package com.taobao.ad.brand.bp.client.api.demand;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.ad.brand.dto.demand.DemandResourceTypeViewDTO;
import com.alibaba.ad.brand.dto.demand.DemandViewDTO;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.demand.DemandTalentDiffViewDTO;
import com.taobao.ad.brand.bp.client.dto.demand.query.DemandQueryOption;
import com.taobao.ad.brand.bp.client.dto.demand.query.DemandQueryViewDTO;

@Deprecated
public interface BizDemandQueryService extends QueryAPI {

    String TAG = "Demand";

    @ProcessEntrance(name = "获取Demand", desc = "获取Demand", opType = OpType.query, tag = TAG)
    SingleResponse<DemandViewDTO> getDemandById(ServiceContext serviceContext, Long id);

    @ProcessEntrance(name = "查询Demand列表", desc = "查询Demand列表", opType = OpType.query, tag = TAG)
    MultiResponse<DemandViewDTO> findDemandList(ServiceContext serviceContext, DemandQueryViewDTO queryViewDTO, DemandQueryOption queryOption);

    @ProcessEntrance(name = "查询服务类型列表", desc = "查询服务类型列表", opType = OpType.query, tag = TAG)
    MultiResponse<DemandResourceTypeViewDTO> findDemandResourceTypeList(ServiceContext serviceContext, Integer sspProductLineId);

    @ProcessEntrance(name = "查询CPM包变更达人列表", desc = "查询CPM包变更达人列表", opType = OpType.query, tag = TAG)
    MultiResponse<DemandTalentDiffViewDTO> findDemandTalentDiffList(ServiceContext serviceContext);

}
