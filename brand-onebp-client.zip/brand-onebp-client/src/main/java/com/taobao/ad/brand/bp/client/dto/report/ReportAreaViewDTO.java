package com.taobao.ad.brand.bp.client.dto.report;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 报表地域维度对象 - 国家 省份 城市
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReportAreaViewDTO extends BaseViewDTO {

    @JSONField(name="country_id")
    private String countryId;

    @JSONField(name="country_name")
    private String countryName;

    @JSONField(name="province_id")
    private String provinceId;

    @JSONField(name="province_name")
    private String provinceName;

    @JSONField(name="city_id")
    private String cityId;

    @JSONField(name="city_name")
    private String cityName;
}
