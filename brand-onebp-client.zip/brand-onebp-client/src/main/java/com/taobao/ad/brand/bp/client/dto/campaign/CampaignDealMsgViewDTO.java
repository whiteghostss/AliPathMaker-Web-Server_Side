package com.taobao.ad.brand.bp.client.dto.campaign;

import java.util.List;

import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;

import lombok.Data;

@Data
public class CampaignDealMsgViewDTO extends CampaignDealNoticeViewDTO {

    private CampaignViewDTO campaignViewDTO;
    /**
     * 相关订单信息
     */
    private CampaignGroupViewDTO campaignGroupViewDTO;
}
