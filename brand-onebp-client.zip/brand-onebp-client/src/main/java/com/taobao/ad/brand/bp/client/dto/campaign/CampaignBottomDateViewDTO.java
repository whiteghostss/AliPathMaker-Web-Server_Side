package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.DateViewDTO;
import lombok.Data;

import java.util.List;

/**
 * 子计划打底的信息
 * @author 弈云
 * @date 2024年01月12日
 * */
@Data
public class CampaignBottomDateViewDTO extends BaseViewDTO {

    /**
     * 子计划ID
     * */
    private Long subCampaignId;
    /**
     * 子计划的打底时间
     * */
    private List<DateViewDTO> bottomDateList;
}
