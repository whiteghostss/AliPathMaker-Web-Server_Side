package com.taobao.ad.brand.bp.client.enums.adgroup;

import lombok.Getter;

@Getter
public enum AdgroupWarnEnum {
    UN_SAVE_OFFICIAL("Un_Save_Official","不满足打底单元变为「正式」的条件（创意未覆盖单元有效期）"),
    UN_INQUIRED_DATE("Un_Inquired_Date","计划无可投放日期");

    private String code;
    private String desc;

    AdgroupWarnEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }
}
