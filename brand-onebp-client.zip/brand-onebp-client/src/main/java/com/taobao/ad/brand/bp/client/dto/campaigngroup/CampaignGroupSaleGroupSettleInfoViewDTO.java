package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.settle.CampaignSettleBaseViewDTO;

import lombok.Data;

import java.util.List;

/**
 * 订单实结/结案结算信息
 *
 * @author yanjingang
 * @date 2023/3/24
 */
@Data
public class CampaignGroupSaleGroupSettleInfoViewDTO extends BaseViewDTO {

    /**
     * 分组ID
     */
    private Long saleGroupId;

    /**
     * 分组名称
     */
    private String saleGroupName;

    /**
     * 产品线
     */
    private Integer saleProductLine;

    /**
     * 业务线
     */
    private Integer saleBusinessLine;

    /**
     * 子合同ID
     */
    private Long subContractId;

    /**
     * 分组预算
     */
    private Long budget;

    /**
     * 分组类型
     * @see com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum
     */
    private Integer saleType;

    /**
     * 分组来源
     * @see com.alibaba.ad.brand.sdk.constant.common.BrandSaleGroupSourceEnum
     */
    private Integer source;

    /**
     * 主分组ID
     */
    private Long mainSaleGroupId;

    /**
     * 计收金额，单位分
     */
    private Long incomePrice;

    /**
     * 实际流量金额，单位分
     */
    private Long realCastPrice;

    /**
     * 实结金额，单位分
     */
    private Long realSettlePrice;

    /**
     * 分组的一级计划List
     */
    private List<CampaignSettleBaseViewDTO> campaignList;
}
