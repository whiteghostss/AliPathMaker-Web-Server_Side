package com.taobao.ad.brand.bp.client.dto.adgroup.query;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 查询adgroup扩展的信息
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AdgroupQueryOption {


    /**
     * 是否需要创意
     */
    private boolean needCreative = false;


    /**
     * 是否需要查询定向信息
     */
    private boolean needTarget = false;

    /**
     * 是否需要查询频控信息
     */
    private boolean needFrequency = false;
}
