package com.taobao.ad.brand.bp.client.enums.insight;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 报表benchmark类型
 * @author yuncheng.lyc
 * @date 2023/3/7
 **/
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@Getter
public enum WinInsightBenchMarkTypeEnum {

    /**
     * 同类目品牌均值
     */
    CATEGORY_AVERAGE(1, "同类目品牌均值"),

    /**
     * 同类目Top10品牌均值
     */
    TOP_TEN_CATEGORY_AVERAGE(2, "同类目top10品牌均值"),

    /**
     * 同类目同等级品牌均值
     */
    CATEGORY_X_LEVEL_AVERAGE(3, "同类目同等级品牌均值"),
    ;

    private final Integer value;
    private final String desc;

    public static WinInsightBenchMarkTypeEnum of(Integer value) {
        for (WinInsightBenchMarkTypeEnum typeEnum : WinInsightBenchMarkTypeEnum.values()) {
            if (typeEnum.getValue().equals(value)) {
                return typeEnum;
            }
        }
        return null;
    }
}
