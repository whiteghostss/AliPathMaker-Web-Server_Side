package com.taobao.ad.brand.bp.client.dto.dmp.query;

import com.taobao.ad.brand.bp.client.dto.base.BaseQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.BizKeywordTypeEnum;
import lombok.Data;
import lombok.ToString;

import java.util.List;

/**
 * 人群查询参数
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@SuppressWarnings("ALL")
@Data
@ToString
public class CrowdQueryViewDTO extends BaseQueryViewDTO {
    /**
     * 投放账户member
     */
    private Long memberId;
    /**
     * 人群id
     */
    private Long crowdId;
    /**
     * 人群ids
     */
    private List<Long> crowdIds;
    /**
     * 人群来源
     * @see com.taobao.ad.dmp.client.dto.BusinessTypeEnum
     */
    private Integer businessType;
    /**
     * 人群来源
     * @see com.taobao.ad.dmp.client.dto.BusinessTypeEnum
     */
    private List<Integer> businessTypes;
    /**
     * 人群状态
     * 过期失效:2,未同步:3;同步中:11,已同步:12,正常状态：10（等于11+12）
     * @see com.taobao.ad.dmp.client.dto.CrowdFullStatusEnum
     */
    private Integer pullStatus;
    /**
     * 关键词搜索，支持id和name模糊
     */
    private String keyword;
    /**
     * 关键词搜索，支持id和name模糊
     * @see BizKeywordTypeEnum
     */
    private String keywordType;
    /**
     * 是否包含删除
     */
    private Integer includeExpire;

}
