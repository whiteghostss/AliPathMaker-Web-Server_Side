package com.taobao.ad.brand.bp.client.dto.report;

import com.alibaba.abf.governance.dto.BaseViewDTO;
import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;

@Data
public class WorksConfigNoticeDTO extends BaseViewDTO {
    /**
     * 日期
     */
    private String publishDate;

    /**
     * 订单ID
     */
    @JSONField(name = "orderId")
    private Long campaignGroupId;

    /**
     * 媒体ID
     */
    private Long mediaId;

    /**
     * 达人唯一标识
     */
    private String userId;

    /**
     * 落地页链接
     */
    private String landingPageUrl;

    /**
     * 作品链接
     */
    private String workUrl;
}

