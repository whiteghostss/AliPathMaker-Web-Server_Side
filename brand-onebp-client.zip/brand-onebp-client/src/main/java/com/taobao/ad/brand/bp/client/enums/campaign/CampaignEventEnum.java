package com.taobao.ad.brand.bp.client.enums.campaign;

import com.taobao.ad.brand.bp.client.enums.CommonEnum;

/**
 * 计划状态流转event
 */
public enum CampaignEventEnum implements CommonEnum {
    CREATE(1, "新建"),
    UPDATE(2, "更新"),
    DELETE(3, "删除"),
    LOCK_SUCCESS(4, "锁量成功"),
    LOCK_FAILED(5, "锁量失败"),
    /**
     * TODO 后续改个名
     */
    ONLINE(6, "计划上线"),
    CAMPAIGN_GROUP_ONLINE(7, "订单计划上线"),
    LOCK(8, "发起锁量"),
    REAL_TIME_OPTIMIZE_CONFIG(9, "配置实时优选算法推荐人群"),

    AUTO_BUDGET_ALLOCATION(10, "预算分配")

    ;

    private final int value;
    private final String desc;

    CampaignEventEnum(int value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    @Override
    public int getValue() {
        return 0;
    }

    @Override
    public String getDesc() {
        return null;
    }
}
