package com.taobao.ad.brand.bp.client.dto.creative;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.List;

/**
 * 海棠创意数据结构
 * @author ：PhilipFry
 * @date ：Created in 2023/3/6 15:45
 */
@Data
public class CreativeSaveViewDTO extends BaseViewDTO {

    /**
     * 创意id
     */
    private Long id;

    /**
     * 创意名称
     */
    private String name;

    /**
     * 资源类型
     */
    private Integer resourceType;

    /**
     * 创意投放类型
     */
    private Integer targetType;

    /**
     * 创意来源
     * BrandCreativeSourceEnum
     */
    private Integer creativeSource;

    /**
     * 是否TOP
     *
     * @see BrandBoolEnum
     */
    private Integer isTop;

    /**
     * 创意送审类型
     * @see com.alibaba.ad.brand.sdk.constant.creative.field.BrandAdReviewTypeEnum
     */
    private Integer adReviewType;

    /**
     * 是否topshow白名单客户
     * @see BrandBoolEnum
     */
    private Integer isTopShowWhiteCustomer;

    /**
     * 创意开始时间，用户设置
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date startTime;

    /**
     * 创意结束时间，用户设置
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date endTime;

    /**
     * 是否精确到时间
     * 0-精确到日期
     * 1-精确到时分秒
     */
    private Integer accurateTime;

    /**
     * 个性化setting
     * 注意，通用的setting已抽象为具体的领域模型中的属性，一些个性化的属性可以放在这个map中
     * 如果该map中存放了与通用setting冲突的key，则以通用setting为准，
     * 通用setting有哪些，可参考SettingKey
     */
    private List<CreativeMalusTemplateViewDTO> templateDatum;

    /**
     * 复制创意id
     */
    private Long copyId;

    /**
     * 创意所属域
     */
    private Integer creativeScope;

    /**
     * 模版中心ID
     */
    private Long templateId;

    /**
     *  广告主设置的状态
     */
    private Integer onlineStatus;

    /**
     * 预览设置
     */
    private String previewSettings;

    /**
     * 落地页
     */
    private String landingPageUrl;

    /**
     * 落地页id
     */
    private Long landingPageId;

    /**
     * 创意标签ID
     */
    private Long tagId;

    /**
     * 资质类型列表
     */
    private List<String> qualificationTypeList;

    //============== 智能创意必须在计划单元下创建 ====================
    /**
     * 计划id
     */
    private Long campaignId;
    /**
     * 单元id
     */
    private Long adgroupId;
}
