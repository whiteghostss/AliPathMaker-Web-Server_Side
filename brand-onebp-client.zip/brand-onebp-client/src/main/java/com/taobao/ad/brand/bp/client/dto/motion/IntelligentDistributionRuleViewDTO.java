package com.taobao.ad.brand.bp.client.dto.motion;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class IntelligentDistributionRuleViewDTO extends BaseViewDTO {

    /**
     * 资源包产品所属类别（N、A、B、C、D）
     */
    private String category;

    /**
     * 资源包产品所属类别名称
     */
    private String categoryName;

    /**
     * 该类别产品所占比例
     */
    private Integer ratio;

    /**
     * 该类别产品最小数量
     */
    private Integer minQuality;

    /**
     * 该类别产品最大数量
     */
    private Integer maxQuality;

    /**
     * 产品策略数据
     * 自定义策略时有值 ,智能策略时为空
     */
    private List<ProductStrategyViewDTO> productStrategyList;
}
