package com.taobao.ad.brand.bp.client.api.campaign;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.ad.brand.dto.campaign.keyword.CampaignWordPackageViewDTO;
import com.alibaba.ad.brand.dto.common.BottomDateViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.frequency.FrequencyViewDTO;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.campaign.*;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignInventoryAutoReleaseQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignKeywordEstimateQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignEffectAdvQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.effect.EffectAdvertiserViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportTaskViewDTO;

import java.util.List;
import java.util.Map;

public interface BizCampaignQueryService extends QueryAPI {
    String TAG = "Campaign";

    /**
     *
     * @param context
     * @param query
     * @param queryOption
     * @return
     */
    @ProcessEntrance(name = "分页查询", desc = "分页查询", opType = OpType.query, tag = TAG)
    MultiResponse<CampaignPageViewDTO> findCampaignPage(ServiceContext context, CampaignQueryViewDTO query, CampaignQueryOption queryOption);

    @ProcessEntrance(name = "根据人群Id查询是否绑定了计划", desc = "根据人群Ids查询计划", opType = OpType.query, tag = TAG)
    MultiResponse<Boolean> queryIsBindCampaignByCrowdId(ServiceContext context, Long crowdId);

    /**
     *
     * @param context
     * @param query
     * @return
     */
    @ProcessEntrance(name = "计划查询", desc = "计划查询", opType = OpType.query, tag = TAG)
    MultiResponse<CampaignViewDTO> findCampaignList(ServiceContext context, CampaignQueryViewDTO query);


    /**
     * 增加了定向和二级计划.频控的查询
     * @param context
     * @param query
     * @param queryOption
     * @return
     */
    @ProcessEntrance(name = "计划查询", desc = "计划查询", opType = OpType.query, tag = TAG)
    MultiResponse<CampaignViewDTO> findCampaignList(ServiceContext context, CampaignQueryViewDTO query, CampaignQueryOption queryOption);

    @ProcessEntrance(name = "查询计划展示项", desc = "查询计划展示项", opType = OpType.query, tag = TAG)
    MultiResponse<CampaignShowConfigViewDTO> getCampaignShowConfig(ServiceContext serviceContext, CampaignShowConfigQueryViewDTO queryViewDTO);

    /**
     *  获取计划的打底信息，用来判断是否可以创建媒体直投
     * @param context
     * @param campaignId
     * @return
     */
    @ProcessEntrance(name = "获取计划打底日期", desc = "获取计划的打底日期", opType = OpType.query, tag = TAG)
    MultiResponse<BottomDateViewDTO> getCampaignBottomDateList(ServiceContext context, Long campaignId);

    /**
     * 获取计划详情
     * @param context
     * @param campaignId
     * @param option
     * @return
     */
    @ProcessEntrance(name = "计划获取", desc = "计划获取", opType = OpType.query, tag = TAG)
    SingleResponse<CampaignViewDTO> getCampaignById(ServiceContext context, Long campaignId, CampaignQueryOption option);


    /**
     *查询今日之前的预算 含今天
     * @param context
     * @param saleGroupId
     * @return budget （分）
     */
    @ProcessEntrance(name = "查询今日之前的预算", desc = "查询今日之前的预算", opType = OpType.query, tag = TAG)
    SingleResponse<Long> getHistoryBudget(ServiceContext context, Long saleGroupId);

    /**
     * @deprecated
     * com.taobao.ad.brand.bp.client.api.frequency.BizFrequencyQueryService#getFrequencyById(com.alibaba.abf.governance.context.ServiceContext, java.lang.Long)
     */
    @ProcessEntrance(name = "频控详情", desc = "频控详情", opType = OpType.query, tag = TAG)
    SingleResponse<FrequencyViewDTO> getFrequencyById(ServiceContext serviceContext, Long frequencyId);

    /**
     * @deprecated
     * com.taobao.ad.brand.bp.client.api.frequency.BizFrequencyQueryService#frequencyList(com.alibaba.abf.governance.context.ServiceContext, com.taobao.ad.brand.bp.client.dto.campaign.FrequencyQueryViewDTO)
     */
    @ProcessEntrance(name = "频控列表", desc = "频控列表", opType = OpType.query, tag = TAG)
    MultiResponse<FrequencyViewDTO> frequencyList(ServiceContext serviceContext, FrequencyQueryViewDTO queryViewDTO);

    /**
     * @deprecated
     * com.taobao.ad.brand.bp.client.api.frequency.BizFrequencyQueryService#findFrequencyRefByFreqId(com.alibaba.abf.governance.context.ServiceContext, java.lang.Long, com.alibaba.ad.brand.sdk.constant.frequency.field.BrandFrequencyBizTypeEnum)
     */
    @ProcessEntrance(name = "查询频控ID关联的计划id", desc = "查询频控ID关联的计划id", opType = OpType.query, tag = TAG)
    SingleResponse<FrequencyRefViewDTO> findFrequencyRefByFreqId(ServiceContext serviceContext, Long frequencyId);

    /**
     * 查询宝贝详情
     * @param serviceContext
     * @param idList
     * @return
     */
    @ProcessEntrance(name = "查询宝贝详情", desc = "查询宝贝详情", opType = OpType.query, tag = TAG)
    MultiResponse<ItemViewDTO> getItemByIdList(ServiceContext serviceContext, List<Long> idList);

    /**
     * 批量计算计划自动释量的预警状态 for履约平台
     * @return
     */
    @ProcessEntrance(name = "批量计算计划自动释量的预警状态", desc = "批量计算计划自动释量的预警状态", opType = OpType.query, tag = TAG)
    MultiResponse<CampaignInventoryAutoReleaseStatusViewDTO> calculateInventoryWarningStatus(ServiceContext serviceContext, CampaignInventoryAutoReleaseQueryViewDTO campaignInventoryAutoReleaseQueryViewDTO);

    /**
     * 批量计算计划自动释量的准入状态 for履约平台
     * @param serviceContext
     * @param campaignInventoryAutoReleaseQueryViewDTO
     * @return
     */
    @ProcessEntrance(name = "批量计算计划自动释量的准入状态", desc = "批量计算计划自动释量的准入状态", opType = OpType.query, tag = TAG)
    MultiResponse<CampaignInventoryAutoReleaseStatusViewDTO> calculateInventoryReleaseStatus(ServiceContext serviceContext, CampaignInventoryAutoReleaseQueryViewDTO campaignInventoryAutoReleaseQueryViewDTO);

    /**
     * 批量查询一级计划三环库存有效期并更新锁量有效期 for履约平台
     * @param serviceContext
     * @param campaignInventoryAutoReleaseQueryViewDTO
     * @return
     */
    @ProcessEntrance(name = "批量查询一级计划三环库存有效期并更新锁量有效期", desc = "批量查询一级计划三环库存有效期并更新锁量有效期", opType = OpType.query, tag = TAG)
    MultiResponse<CampaignInventoryAutoReleaseStatusViewDTO> calculateInventoryExpireTime(ServiceContext serviceContext, CampaignInventoryAutoReleaseQueryViewDTO campaignInventoryAutoReleaseQueryViewDTO);

    /**
     * 根据分组ID查询计划绑定的adv信息
     * @param context
     * @param campaignEffectAdvQueryViewDTO
     * */
    @ProcessEntrance(name = "查询adv账号信息", desc = "查询adv账号信息", opType = OpType.query, tag = TAG)
    MultiResponse<CampaignEffectAdvViewDTO> findCampaignEffectAdvList(ServiceContext context, CampaignEffectAdvQueryViewDTO campaignEffectAdvQueryViewDTO);

    /**
     * 查询自动释量配置项
     * @param serviceContext
     * @return
     */
    @ProcessEntrance(name = "查询自动释量配置项", desc = "查询自动释量配置项", opType = OpType.query, tag = TAG)
    SingleResponse<CampaignInventoryAutoReleaseConfigViewDTO> getLockExpireConfig(ServiceContext serviceContext);

    /**
     *
     * @param context
     * @param campaignInventoryAutoReleaseQueryViewDTO
     * @return
     */
    @ProcessEntrance(name = "计划查询补全预警信息", desc = "计划查询补全预警信息", opType = OpType.query, tag = TAG)
    MultiResponse<CampaignInventoryAutoReleaseStatusViewDTO> findCampaignWarnInfoList(ServiceContext context, CampaignInventoryAutoReleaseQueryViewDTO campaignInventoryAutoReleaseQueryViewDTO);

    /**
     * 查询计划分配策略汇总数据
     * @param context
     * @param query
     * @return
     */
    @ProcessEntrance(name = "查询计划分配策略汇总数据", desc = "查询计划分配策略汇总数据", opType = OpType.query, tag = TAG)
    SingleResponse<CampaignSchedulePolicyConfigViewDTO> findCampaignSchedulePolicyConfig(ServiceContext context, CampaignQueryViewDTO query);


    /**
     * 计划查询advList
     * @param serviceContext
     * @param campaignId 一级计划ID
     */
    @ProcessEntrance(name = "计划查询advList", desc = "计划查询advList", opType = OpType.query, tag = TAG)
    MultiResponse<EffectAdvertiserViewDTO> findEffectAdvList(ServiceContext serviceContext, Long campaignId);


    /**
     * 子合同advList
     * @param serviceContext
     * @param subContractId 子合同ID
     */
    @ProcessEntrance(name = "子合同查询advIdList", desc = "子合同查询advIdList", opType = OpType.query, tag = TAG)
    MultiResponse<Long> findEffectAdvListBySubContractId(ServiceContext serviceContext, Long subContractId);
    /**
     * 子合同advList
     * @param serviceContext
     * @param subContractId 子合同ID
     */
    @ProcessEntrance(name = "主合同查询advIdList", desc = "主合同查询advIdList", opType = OpType.query, tag = TAG)
    MultiResponse<Long> findEffectAdvListByContractId(ServiceContext serviceContext, Long contractId);

    /**
     * 计划查询advList
     * @param serviceContext
     * @param campaignIds 一级计划IDs
     */
    @ProcessEntrance(name = "查询子合同List", desc = "查询子合同List", opType = OpType.query, tag = TAG)
    MultiResponse<Long> findEffectSubContractIdList(ServiceContext serviceContext, List<Long> campaignIds);


    /**
     * 查询订单x分组下的批量计划导入记录
     * @param context
     * @param query
     * @return
     */
    @ProcessEntrance(name = "查询订单x分组下的批量计划导入记录", desc = "查询订单x分组下的批量计划导入记录", opType = OpType.query, tag = TAG)
    MultiResponse<ReportTaskViewDTO> findCampaignBatchImportTaskList(ServiceContext context, CampaignQueryViewDTO query);
    /**
     * 查询当前订单下的批量导入计划预订量记录
     * @param context
     * @param query
     * @return
     */
    @ProcessEntrance(name = "查询当前订单下的批量导入计划预订量记录", desc = "查询当前订单下的批量导入计划预订量记录", opType = OpType.query, tag = TAG)
    MultiResponse<ReportTaskViewDTO> findBatchImportCampaignBookingAmountTaskList(ServiceContext context, CampaignQueryViewDTO query);
    /**
     * 查询计划人群定向
     * @param serviceContext
     * @param campaignIds campaignIds
     */
    @ProcessEntrance(name = "查询计划人群定向", desc = "查询计划人群定向", opType = OpType.query, tag = TAG)
    SingleResponse<Map<Long,CampaignViewDTO>> findCampaignCrowdMap(ServiceContext serviceContext, List<Long> campaignIds);

    /**
     * 查询计划支持模版
     * @param serviceContext
     * @param campaignViewDTOList
     * @return
     */
    @ProcessEntrance(name = "查询计划支持模版", desc = "查询计划支持模版", opType = OpType.query, tag = TAG)
    MultiResponse<CampaignTemplateViewDTO> getCampaignTemplateIds(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList);

    /**
     * 查询关键词日均预估pv
     * @param serviceContext
     * @param queryViewDTO
     * @return
     */
    @ProcessEntrance(name = "查询关键词日均预估pv", desc = "查询关键词日均预估pv", opType = OpType.query, tag = TAG)
    SingleResponse<CampaignKeywordEstimateViewDTO> getCampaignKeywordEstimateList(ServiceContext serviceContext, CampaignKeywordEstimateQueryViewDTO queryViewDTO);

    /**
     * 查询所有关键词总的日均预估pv
     * @param serviceContext
     * @param queryViewDTO
     * @return
     */
    @ProcessEntrance(name = "查询所有关键词总的日均预估pv", desc = "查询所有关键词总的日均预估pv", opType = OpType.query, tag = TAG)
    SingleResponse<CampaignKeywordEstimateViewDTO> getCampaignAllKeywordEstimateScope(ServiceContext serviceContext, CampaignKeywordEstimateQueryViewDTO queryViewDTO);

    /**
     * 检查计划下创意数量是否过多/过少
     * @param serviceContext
     * @param campaignId
     * @return
     */
    @ProcessEntrance(name = "计划创意数预警", desc = "计划创意数预警", opType = OpType.query, tag = TAG)
    SingleResponse<CampaignCreativeNumberWarningViewDTO> checkCreativeNumber(ServiceContext serviceContext, Long campaignId);


    /**
     * 查询词包日均预估pv
     * @param serviceContext
     * @param queryViewDTO
     * @return
     */
    @ProcessEntrance(name = "查询词包日均预估pv", desc = "查询词包日均预估pv", opType = OpType.query, tag = TAG)
    SingleResponse<CampaignWordPackageViewDTO> getCampaignWordPackageEstimateList(ServiceContext serviceContext, CampaignKeywordEstimateQueryViewDTO queryViewDTO);


}
