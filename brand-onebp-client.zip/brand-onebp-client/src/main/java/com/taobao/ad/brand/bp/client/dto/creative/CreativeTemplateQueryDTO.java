package com.taobao.ad.brand.bp.client.dto.creative;


import com.taobao.ad.brand.bp.client.dto.base.BaseQueryViewDTO;
import lombok.Data;
import lombok.ToString;

import java.util.List;

/**
 * @author jixiu.lj
 * @date 2023/12/2 15:13
 */
@Data
@ToString
public class CreativeTemplateQueryDTO extends BaseQueryViewDTO {
    private List<Long> templateIdList;
    private List<Long> excludeTemplateIdList;
    private boolean needSetting;
    private boolean needAssociation;
    private boolean needTag;
}
