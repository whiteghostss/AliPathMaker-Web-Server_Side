package com.taobao.ad.brand.bp.client.dto.shopwindow;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/6/27
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class BrandCommonDictViewDTO extends BaseViewDTO {

    /**
     * 主键ID
     */
    private Long id;

    /**
     * 名称
     */
    private String name;

    /**
     * 值
     */
    private String value;

    /**
     * 上一层级的属性
     * @see BrandCommonDictViewDTO#valueList
     */
    private BrandCommonDictViewDTO previous;

    /**
     * 多值
     */
    private List<BrandCommonDictViewDTO> valueList;

    /**
     * 属性类型
     *
     * @see com.taobao.ad.brand.perform.client.enums.common.CommonDictTypeEnum
     */
    private Integer type;

    /**
     * 是否可用
     * @see com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum
     */
    private Integer status;

    /**
     * 使用场景
     * @see com.taobao.ad.brand.perform.client.enums.common.CommonDictSceneEnum
     */
    private Integer scene;
}
