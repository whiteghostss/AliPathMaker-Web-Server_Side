package com.taobao.ad.brand.bp.client.api.frequency;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.ad.brand.dto.frequency.FrequencyViewDTO;
import com.alibaba.hermes.framework.api.CommandAPI;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.campaign.FrequencyRefViewDTO;

import java.util.List;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/1/16
 **/
public interface BizFrequencyCommandService extends CommandAPI {
    String TAG = "Frequency";

    /**
     * 新建/编辑交付型频控
     * @param serviceContext
     * @param frequencyViewDTO
     * @return
     */
    @ProcessEntrance(name = "新建/编辑交付型频控", desc = "新建/编辑交付型频控", opType = OpType.update, tag = TAG)
    SingleResponse<Long> saveDeliveredFrequency(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO, List<Long> campaignIdList);

    /**
     * 新建/编辑优化型频控
     * @param serviceContext
     * @param frequencyViewDTO
     * @return
     */
    @ProcessEntrance(name = "新建/编辑优化型频控", desc = "新建/编辑优化型频控", opType = OpType.update, tag = TAG)
    SingleResponse<Long> saveOptimizedFrequency(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO, List<Long> adgroupIdList);

    /**
     * 优化型频控上下线
     * @param serviceContext
     * @param frequencyViewDTO
     * @return
     */
    @ProcessEntrance(name = "优化型频控上下线", desc = "优化型频控上下线", opType = OpType.update, tag = TAG)
    Response frequencySwitch(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO);

    /**
     * 计划/单元绑定已有频控
     * @param serviceContext
     * @param frequencyRefViewDTO
     * @return
     */
    @ProcessEntrance(name = "计划/单元绑定已有频控", desc = "计划/单元绑定已有频控", opType = OpType.update, tag = TAG)
    Response bindFrequency(ServiceContext serviceContext, FrequencyRefViewDTO frequencyRefViewDTO);

    /**
     * 计划/单元解绑已有频控
     * @param serviceContext
     * @param frequencyRefViewDTO
     * @return
     */
    @ProcessEntrance(name = "计划/单元解绑已有频控", desc = "计划/单元解绑已有频控", opType = OpType.update, tag = TAG)
    Response relieveFrequency(ServiceContext serviceContext, FrequencyRefViewDTO frequencyRefViewDTO);
}
