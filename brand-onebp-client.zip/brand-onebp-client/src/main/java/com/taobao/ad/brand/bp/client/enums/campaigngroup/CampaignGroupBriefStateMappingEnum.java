package com.taobao.ad.brand.bp.client.enums.campaigngroup;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupEventEnum.*;

/**
 * @author yanjingang
 * @date 2023/3/12
 */
public enum CampaignGroupBriefStateMappingEnum {

    EXECUTE_ING_ON_APPROVE(SalesBriefEventEnum.APPROVE.getValue(), SalesBriefStateEnum.EXECUTE_ING.getValue(), CONTRACT_PAY),
    UNLOCKED_ON_UNLOCK(SalesBriefEventEnum.UNLOCK.getValue(), SalesBriefStateEnum.UNLOCKED.getValue(), UNLOCK),
    EXECUTE_ING_ON_ROLLBACK(SalesBriefEventEnum.ROLLBACK.getValue(), SalesBriefStateEnum.EXECUTE_ING.getValue(), UNLOCK_REVERT),
    EXECUTE_FINISHED_ON_ROLLBACK(SalesBriefEventEnum.ROLLBACK.getValue(), SalesBriefStateEnum.EXECUTE_FINISHED.getValue(), UNLOCK_REVERT),
    CAST_STOPPED_ON_STOP_CAST(SalesBriefEventEnum.APPROVE.getValue(), SalesBriefStateEnum.CAST_STOPPED.getValue(), STOP_CAST),

    CAST_STOPPED_ON_REAL_SETTLE_REFUSE(SalesBriefEventEnum.REFUSE.getValue(), SalesBriefStateEnum.CAST_STOPPED.getValue(), REAL_SETTLE_REFUSE),
    CAST_STOPPED_ON_REAL_SETTLE_TERMINATE(SalesBriefEventEnum.TERMINATE.getValue(), SalesBriefStateEnum.CAST_STOPPED.getValue(), REAL_SETTLE_REFUSE),

    EXECUTE_FINISHED_ON_REAL_SETTLE_REFUSE(SalesBriefEventEnum.REFUSE.getValue(), SalesBriefStateEnum.EXECUTE_FINISHED.getValue(), REAL_SETTLE_REFUSE),
    EXECUTE_FINISHED_ON_REAL_SETTLE_TERMINATE(SalesBriefEventEnum.TERMINATE.getValue(), SalesBriefStateEnum.EXECUTE_FINISHED.getValue(), REAL_SETTLE_REFUSE),

    REAL_SETTLE_ING_ON_REAL_SETTLE(SalesBriefEventEnum.REAL_SETTLE.getValue(), SalesBriefStateEnum.REAL_SETTLE_ING.getValue(), REAL_SETTLE),
    REAL_SETTLED_ON_REAL_SETTLE_APPROVE(SalesBriefEventEnum.APPROVE.getValue(), SalesBriefStateEnum.REAL_SETTLED.getValue(), REAL_SETTLE_APPROVE),
    COMPLETED_ON_COMPLETE(SalesBriefEventEnum.COMPLETE.getValue(), SalesBriefStateEnum.COMPLETED.getValue(), COMPLETE),
    EXECUTE_FINISHED_ON_COMPLETE_REVERT(SalesBriefEventEnum.COMPLETE_REVERT.getValue(), SalesBriefStateEnum.EXECUTE_FINISHED.getValue(), COMPLETE_REVERT),

    /**
     * campaignGroup所有状态都支持撤单
     */
    CANCELED_ON_CANCEL(null, SalesBriefStateEnum.CANCELED.getValue(), CANCEL),
    ;

    CampaignGroupBriefStateMappingEnum(Integer briefEventCode, Integer briefStatus, CampaignGroupEventEnum campaignGroupEvent) {
        this.briefEventCode = briefEventCode;
        this.briefStatus = briefStatus;
        this.campaignGroupEvent = campaignGroupEvent;
    }

    private Integer briefEventCode;
    private Integer briefStatus;
    private CampaignGroupEventEnum campaignGroupEvent;

    public Integer getBriefEventCode() {
        return briefEventCode;
    }

    public Integer getBriefStatus() {
        return briefStatus;
    }

    public CampaignGroupEventEnum getCampaignGroupEvent() {
        return campaignGroupEvent;
    }


    private final static Map<Integer, List<CampaignGroupBriefStateMappingEnum>> BRIEF_STATE_2_ENUM_LIST;
    static {
        BRIEF_STATE_2_ENUM_LIST = Arrays.stream(CampaignGroupBriefStateMappingEnum.values())
                .collect(Collectors.groupingBy(CampaignGroupBriefStateMappingEnum::getBriefStatus));
    }

    public static List<CampaignGroupBriefStateMappingEnum> getByBriefStatus(int briefStatus) {
        return BRIEF_STATE_2_ENUM_LIST.get(briefStatus);
    }

    public static CampaignGroupBriefStateMappingEnum targetByBriefEventAndStatus(Integer briefEventCode, Integer briefStatus) {
        List<CampaignGroupBriefStateMappingEnum> stateMappingEnums = getByBriefStatus(briefStatus);
        if (stateMappingEnums == null) {
            return null;
        }
        for (CampaignGroupBriefStateMappingEnum briefStateMappingEnum : stateMappingEnums) {
            // 撤单时，默认返回
            if (briefStatus == SalesBriefStateEnum.CANCELED.getValue()) {
                return briefStateMappingEnum;
            }
            if (briefStateMappingEnum.getBriefEventCode().equals(briefEventCode)) {
                return briefStateMappingEnum;
            }
        }

        return null;
    }

    public static boolean containsBriefStatus(int briefStatus) {
        // 不存在时返回未知
        return BRIEF_STATE_2_ENUM_LIST.containsKey(briefStatus);
    }
}
