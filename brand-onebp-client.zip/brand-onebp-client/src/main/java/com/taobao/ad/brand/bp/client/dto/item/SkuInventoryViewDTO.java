package com.taobao.ad.brand.bp.client.dto.item;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * @Author: PhilipFry
 * @createTime: 2024年04月24日 21:06:44
 * @Description:
 */
@Data
public class SkuInventoryViewDTO extends BaseViewDTO {
    /**
     * 库存ID
     */
    private long inventoryId;

    /**
     * item ID
     */
    private Long itemId;

    /**
     * SKU ID
     */
    private long skuId;

    /**
     * serviceSkuId
     */
    private String serviceSkuId;

    /**
     * SKU的可售总库存
     */
    private int sellableQuantity;

    /**
     * 预扣库存数
     */
    private int withholdingQuantity;
}
