package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.Date;

/**
 * @author yanjingang
 * @date 2025/3/10
 */
@Data
public class SalesBriefSaleGroupViewDTO extends BaseViewDTO {
    /**
     * 产品分组ID
     */
    private Long id;

    /**
     * 分组产品线，品牌 OB 二期改用分组产品线作为拆分子合同的依据
     */
    private String groupProductLine;

    /**
     * 预算
     */
    private Long budget;

    /**
     * 产品分组类型，1：购买，2：补量，3：赠送
     */
    private Integer saleType;

    /**
     * 开始时间
     */
    private Date startDate;

    /**
     * 结束时间
     */
    private Date endDate;

    /**
     * 分组来源,1:来自售卖，2：来自资源打包
     */
    private Integer source;

    /**
     * 特秀保量 PV
     */
    private Long signPv;
}
