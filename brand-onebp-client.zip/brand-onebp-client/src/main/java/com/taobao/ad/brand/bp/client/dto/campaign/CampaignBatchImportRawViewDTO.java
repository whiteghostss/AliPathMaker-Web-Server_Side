package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.ErrorMessageDTO;
import lombok.Data;

/**
 * 计划批量导出从Excel中解析到的原始信息
 * @author jixiu.lj
 * @date 2023/8/31 20:01
 */
@Data
public class CampaignBatchImportRawViewDTO extends BaseViewDTO {
    private ErrorMessageDTO errorMessage;
    private Boolean isFiltered;
    private CampaignViewDTO campaignViewDTO;
}
