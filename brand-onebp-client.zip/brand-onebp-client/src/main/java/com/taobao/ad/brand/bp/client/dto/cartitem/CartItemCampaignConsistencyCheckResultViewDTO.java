package com.taobao.ad.brand.bp.client.dto.cartitem;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.rule.RuleCheckResultViewDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 计划对比结果（如计划单价、人群定向）
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CartItemCampaignConsistencyCheckResultViewDTO extends BaseViewDTO {
    /**
     * 加购行id
     */
    private Long cartItemId;
    /**
     * campaignId
     */
    private Long campaignId;
    /**
     * 是否通过
     * BooleanEnum
     */
    private Integer isPass;
    /**
     * 不通过原因
     */
    private String reason;
    /**
     * 规则执行结果
     */
    private List<RuleCheckResultViewDTO> ruleCheckResultViewDTOList;
}
