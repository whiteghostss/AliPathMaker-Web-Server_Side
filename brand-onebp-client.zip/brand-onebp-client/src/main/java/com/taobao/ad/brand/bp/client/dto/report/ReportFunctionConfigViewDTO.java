package com.taobao.ad.brand.bp.client.dto.report;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 数据功能对象
 * @author yuncheng.lyc
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReportFunctionConfigViewDTO extends BaseViewDTO {
    /**
     * 指标字段
     */
    private String code;
    /**
     * 指标名称
     */
    private String name;
    /**
     * 字段描述
     */
    private String description;
    /**
     * 报表中心API，优先使用参数传递中的api，再次选择维度上配置的api，最后看功能上配置的api
     */
    private String adrUniqueKey;
    /**
     * 该报表功能是否是占位，动态组装维度
     */
    private Boolean autoDimension;
}
