package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;

import lombok.Data;

/**
 * @author yanjingang
 * @date 2023/3/20
 */
@Data
public class SalesCustomerViewDTO extends BaseViewDTO {

    /**
     * 客户ID
     */
    private Long id;
    /**
     * 客户名称
     */
    private String name;

    /**
     * 客户优先级
     */
    private String level;

    /**
     * 行业ID
     */
    private Long industryId;

    /**
     * 行业名称
     */
    private String industryName;

    /**
     * 子行业
     */
    private Long subIndustryId;

    /**
     * 子行业名称
     */
    private String subIndustryName;

    /**
     * gm工号
     */
    private String gmId;

    /**
     * 品牌ID
     */
    private Long brandId;

    /**
     * 品牌名称
     */
    private String brandName;

}
