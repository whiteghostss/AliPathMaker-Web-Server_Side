package com.taobao.ad.brand.bp.client.context;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * 计划事件处理
 * */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CampaignNoticeContext {
    private CampaignViewDTO campaignViewDTO;
    private ServiceContext serviceContext;
}
