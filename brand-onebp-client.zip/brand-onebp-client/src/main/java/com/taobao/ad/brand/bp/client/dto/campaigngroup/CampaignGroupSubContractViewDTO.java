package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author yanjingang
 * @date 2023/3/10
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class CampaignGroupSubContractViewDTO extends BaseViewDTO {

    private Long subContractId;

    /**
     * 售卖产品线
     */
    private Integer saleProductLine;

}
