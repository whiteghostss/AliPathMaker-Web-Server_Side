package com.taobao.ad.brand.bp.client.dto.tianhe;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.Date;

/**
 * @author yanjingang
 * @date 2024/8/5
 */
@Data
public class TianheCoinTransactionViewDTO extends BaseViewDTO {
    /**
     * 商家ID
     */
    private Long sellerId;
    /**
     * 金额，单位分（关联了同一个购买分组的反哺分组汇总金额）
     */
    private Long budget;
    /**
     * 周期（关联了同一个购买分组的反哺分组汇总周期）
     */
    private Date startDate;
    private Date endDate;
    /**
     * 反哺订单信息
     */
    private Long campaignGroupId;
    private String campaignGroupName;
    /**
     * 投放账号信息
     */
    private Long memberId;
    private String memberName;
    /**
     * 投放账号类型：1-客户投放账号, 2-代理叉乘账号, 3-代投账号
     */
    private Integer memberType;


    /**
     * 实际购买的订单信息
     */
    private Long actualPurchaseCampaignGroupId;
    private String actualPurchaseCampaignGroupName;

    public String getOutTransactionId() {
        return actualPurchaseCampaignGroupId + "_" + campaignGroupId;
    }

}
