package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.ConfidenceInfoViewDTO;
import lombok.Data;

/**
 * 订单分组预估结果viewDTO
 * @author yunhu.myh@taobao.com
 * @date 2023年07月20日
 * */
@Data
public class CampaignGroupSaleGroupEstimateResultViewDTO extends BaseViewDTO {
    /**
     * 这里返回的是算法的+Bp自己算的，存储的是算法的
     * @see
     * */
    private Integer deliveryTarget;
    /**
     * 算法预估最大值
     * */
    private Long max;
    /**
     * 算法预估最小值
     * */
    private Long min;
    /**
     * 交付预估最小值（算法原始）
     * */
    private Long algoMin;
    /**
     * 交付预估的最大值（算法原始）
     * */
    private Long algoMax;
    /**
     * 交付预估最终值
     * */
    private Long finalValue;
    /**
     * 兼容showmax的最大值
     * */
    private Long finalValueMax;

    /**
     * 资源包设定的值
     * 若没设置，则返回null。
     * */
    private Long resourceValue;

    /**
     * 置信度
     */
    private ConfidenceInfoViewDTO confidenceInfoViewDTO;

}
