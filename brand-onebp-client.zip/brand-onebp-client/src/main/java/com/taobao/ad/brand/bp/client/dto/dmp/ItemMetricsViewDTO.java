package com.taobao.ad.brand.bp.client.dto.dmp;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.enums.dmp.DmpItemLifeCycleEnum;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @author yanjingang
 * @date 2025/2/18
 */
@Data
public class ItemMetricsViewDTO extends BaseViewDTO {

    /** 业务日期yyyymmdd */
    private String logDate;

    /** 宝贝id*/
    private Long itemId;
    /** 宝贝标题 */
    private String name;
    /** 宝贝图片url */
    private String pictUrl;
    /** 宝贝详情页链接(由宝贝ID根据固定规则生成) */
    private String detailUrl;
    /** 上架天数 */
    private Long onlineDays;
    /** 货品等级（新/潜/爆/尾）code，详见枚举:{@link ItemLevelEnum} */
    private Integer itemLevel;
    /**
     * 生命周期类型code，详见枚举:{@link DmpItemLifeCycleEnum}
     * */
    private Integer lifeCycleType;

    /**
     * 流量规模指标
     */
    /** IPV(商品详情页PV) */
    private Long ipv;

    private Long benchmarkIpv;

    /**
     * 深种草
     */
    private Long v2Uv;
    /**
     * 深种草行业
     */
    private Long benchmarkV2Uv;
    /** 自然搜索曝光量 */
    private Long searchFreePv;

    /** 自然搜索点击量 */
    private Long searchFreeClk;

    /** 收藏加购量 */
    private Long colAndCartCnt;

    /** 收藏加购率=收藏加购率/IPV */
    private BigDecimal colAndCartRate;

}
