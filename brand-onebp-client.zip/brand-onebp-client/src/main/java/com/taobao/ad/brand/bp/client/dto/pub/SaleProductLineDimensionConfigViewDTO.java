package com.taobao.ad.brand.bp.client.dto.pub;

import lombok.Data;

import java.util.List;

@Data
public class SaleProductLineDimensionConfigViewDTO {

    /**
     * 产品线ID
     * @see com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleProductLineEnum
     * */
    private Integer saleProductLineId;

    private List<DimensionConfigRuleViewDTO> dimensionConfigRules;

}
