package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.Date;

/**
 * @author gxg
 *
 */
@Data
public class SalesProjectViewDTO extends BaseViewDTO {

    /**
     * 主键
     */
    private Long id;

    /**
     * 项目名称
     */
    private String name;

    /**
     * 项目编号
     */
    private String projectNum;

    /**
     * 客户id
     */
    private Long customerId;

    /**
     * 预算
     */
    private Long budget;

    /**
     * 意向投放开始日期
     */
    private Date startDate;

    /**
     * 意向投放结束日期
     */
    private Date endDate;

    /**
     * 实际下单金额
     */
    private Long amount;

    /**
     * 实际投放开始日期
     */
    private Date castStartDate;

    /**
     * 实际投放结束日期
     */
    private Date castEndDate;

    /**
     * 所属营销活动
     */
    private String activity;

    /**
     * 项目阶段
     */
    private Integer stage;

    /**
     * 项目描述
     */
    private String description;

    /**
     * 文件
     */
    private String files;

    /**
     * 责任人
     */
    private String owner;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建时间
     */
    private Date gmtCreate;

    /**
     * 修改时间
     */
    private Date gmtModified;

    /**
     * 外部联系人
     */
    private String outsideLinkman;

    /**
     * 客户名称
     */
    private String customerName;

    /**
     * 客户片区
     */
    private String customerArea;

    /**
     * 责任人昵称
     */
    private String ownerNick;

    /**
     * 责任人名称
     */
    private String ownerName;

    /**
     * 创建人昵称
     */
    private String creatorNick;

    /**
     * 创建人名称
     */
    private String creatorName;

    /**
     * 项目阶段
     */
    private String stageName;

    /**
     * 可设置的拜访目的
     */
    private Integer visitPurpose;

    /**
     * 行业id
     */
    private Long industryId;

    /**
     * 行业名称
     */
    private String industryName;

    /**
     * 类型-品专、资源包、散投
     */
    private Integer type;

    /**
     * 招商项目id
     */
    private Long merchantProjectId;

    /**
     * 招商项目名称
     */
    private String merchantProjectName;

    /**
     * 资源包父包id
     */
    private Long modelPackageId;

    /**
     * 资源包名称
     */
    private String modelPackageName;

    /**
     * 资源包档位
     */
    private Integer grade;

    /**
     * 是否在招商项目重复的情况下仍创建
     */
    private Boolean forceCreate;

}
