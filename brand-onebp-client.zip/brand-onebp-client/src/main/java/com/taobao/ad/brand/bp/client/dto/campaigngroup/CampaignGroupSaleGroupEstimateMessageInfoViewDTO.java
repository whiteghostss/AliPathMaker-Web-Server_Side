package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * 分组预估结果消息
 *
 * @author gxg
 */
@Data
public class CampaignGroupSaleGroupEstimateMessageInfoViewDTO extends BaseViewDTO {

    /**
     * 投放账号
     */
    private Long memberId;
    /**
     * 投放账号名称
     */
    private String memberName;

    /**
     * 投放账号名称
     */
    private String advName;

    /**
     * 订单ID
     */
    private Long campaignGroupId;

    /**
     * 订单名称
     */
    private String campaignGroupName;

    /**
     * 分组ID
     */
    private Long saleGroupId;

    /**
     * 分组名称
     */
    private String saleGroupName;
    /**
     * 交付指标
     */
    private String deliveryTarget;

    /**
     * 指标预估
     */
    private String finalValue;

    /**
     * 预估置信度
     */
    private String confidence;

}
