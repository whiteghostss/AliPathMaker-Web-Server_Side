package com.taobao.ad.brand.bp.client.enums.dooh;

import com.google.common.collect.Lists;
import lombok.Getter;

import java.util.List;

@Getter
public enum DoohStrategyStatusEnum {

    CALCULATION_COMPLETED(1, "计算完成", Lists.newArrayList(200)),
    CALCULATING(2, "计算中", Lists.newArrayList(300)),
    /**
     * 计算失败 - 可重试
     */
    CALCULATION_TAILED_RETRY(3, "计算失败", Lists.newArrayList(-1,-2,-3)),
    /**
     * 计算失败 - 业务错误
     */
    CALCULATION_TAILED_BUSINESS_ERROR(4, "计算失败", Lists.newArrayList(200000, 300000)),
    ;

    private Integer code;

    private String desc;

    private List<Integer> doohCodeList;

    DoohStrategyStatusEnum(Integer code, String desc, List<Integer> doohCodeList){
        this.code = code;
        this.desc = desc;
        this.doohCodeList = doohCodeList;
    }

    public static DoohStrategyStatusEnum getStatusByDoohStatus(Integer doohCode){
        if(doohCode == null){
            return null;
        }
        for(DoohStrategyStatusEnum statusEnum : DoohStrategyStatusEnum.values()){
            if(statusEnum.getDoohCodeList().contains(doohCode)){
                return statusEnum;
            }
        }
        return null;
    }
}
