package com.taobao.ad.brand.bp.client.dto.base;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * @Description 错误实体信息
 * @author gxg 2020/12/2 15:26
 */

@Data
public class ErrorMessageDTO extends BaseViewDTO {

    private Integer serialId;
    private Long id;
    private String name;
    private String errorMessage;
}
