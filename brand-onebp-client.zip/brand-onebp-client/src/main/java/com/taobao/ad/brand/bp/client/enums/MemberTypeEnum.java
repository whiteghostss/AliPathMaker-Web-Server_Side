package com.taobao.ad.brand.bp.client.enums;

/**
 * @author 虫洞 <liuming.liu@alibaba-inc.com>
 * @date 2023/3/2
 */
public enum MemberTypeEnum {
    /**
     * 生态伙伴（代理商/服务商）
     */
    PARTNER(1, "生态伙伴"),
    /**
     * 商家（直客）
     */
    SELLER(2, "商家"),
    ALI_EMP(3, "内部小二"),
    ;

    private final Integer value;
    private final String name;

    MemberTypeEnum(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    public Integer getValue() {
        return value;
    }

    public String getName() {
        return name;
    }
}
