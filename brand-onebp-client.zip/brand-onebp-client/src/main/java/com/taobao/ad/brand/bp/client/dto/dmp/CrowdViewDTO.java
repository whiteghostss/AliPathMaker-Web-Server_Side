package com.taobao.ad.brand.bp.client.dto.dmp;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CrowdViewDTO extends BaseViewDTO {

    /**
     * 人群ID
     */
    private Long crowdId;
    /**
     * 人群名称
     */
    private String crowdName;
    /**
     * 人群数据来源
     */
    private Integer businessType;
    /**
     * 人群数据来源
     */
    private String businessTypeName;
    /**
     * 人群数量
     */
    private Long coverage;
    /**
     * 创建时间
     */
    private Date createDate;
    /**
     * 过期时间
     */
    private Date validDate;
    /**
     * 人群状态
     */
    private Integer fullStatus;
    /**
     * 人群状态
     */
    private String fullStatusName;
    /**
     * 人群锁定热度
     */
    private Map<String, String> extra;

    public Long getTopicId() {
        if (MapUtils.isNotEmpty(extra) && extra.containsKey("__topic_id")) {
            String topicId = extra.get("__topic_id");
            if (StringUtils.isNumeric(topicId)) {
                return Long.parseLong(topicId);
            }
        }
        return null;
    }
}