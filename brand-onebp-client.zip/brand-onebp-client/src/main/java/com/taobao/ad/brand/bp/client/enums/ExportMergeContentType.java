package com.taobao.ad.brand.bp.client.enums;

/**
 * @author jixiu.lj
 * @date 2023/12/7 10:24
 */
public enum ExportMergeContentType {
    OVERALL,
    AVERAGE,
    SUM
}
