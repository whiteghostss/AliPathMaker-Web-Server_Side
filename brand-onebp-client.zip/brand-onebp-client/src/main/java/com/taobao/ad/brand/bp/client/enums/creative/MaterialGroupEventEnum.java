package com.taobao.ad.brand.bp.client.enums.creative;

import com.taobao.ad.brand.bp.client.enums.CommonEnum;

/**
 * 素材组状态流转event
 */
public enum MaterialGroupEventEnum implements CommonEnum {
    CROP_SUCCESS(1, "拓版成功"),

    ;

    private final int value;
    private final String desc;

    MaterialGroupEventEnum(int value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    @Override
    public int getValue() {
        return 0;
    }

    @Override
    public String getDesc() {
        return null;
    }
}
