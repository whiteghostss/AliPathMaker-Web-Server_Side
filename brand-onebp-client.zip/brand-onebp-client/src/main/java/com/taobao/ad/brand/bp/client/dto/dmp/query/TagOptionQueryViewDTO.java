package com.taobao.ad.brand.bp.client.dto.dmp.query;

import com.taobao.ad.brand.bp.client.dto.base.BaseQueryViewDTO;
import lombok.Data;
import lombok.ToString;

import java.util.List;

/**
 * 人群标签查询参数
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@SuppressWarnings("ALL")
@Data
@ToString
public class TagOptionQueryViewDTO extends BaseQueryViewDTO {
    /**
     * tagId
     */
    private Long tagId;
    /**
     * optionIds
     */
    private List<Long> optionIds;

}
