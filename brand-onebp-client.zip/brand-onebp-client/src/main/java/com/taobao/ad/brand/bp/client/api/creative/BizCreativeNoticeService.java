package com.taobao.ad.brand.bp.client.api.creative;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.dto.response.Response;
import com.taobao.ad.brand.bp.client.dto.creative.notice.LiveRejectMsgViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.notice.LiveRepassedMsgViewDTO;

public interface BizCreativeNoticeService {
    String TAG = "Creative";

    @ProcessEntrance(name = "直播拒审通知", desc = "直播拒审通知", opType = OpType.update, tag = TAG)
    Response liveRejectNotice(ServiceContext context, LiveRejectMsgViewDTO liveMessage);

    @ProcessEntrance(name = "直播重新过审通知", desc = "直播重新过审通知", opType = OpType.update, tag = TAG)
    Response liveRepassedNotice(ServiceContext context, LiveRepassedMsgViewDTO liveMessage);
}
