package com.taobao.ad.brand.bp.client.dto.industry;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

@Data
public class IndustryViewDTO extends BaseViewDTO {

    /**
     * 店铺id
     */
    private Long shopId;

    /**
     * 主营行业大组ID（按照天猫行业结构打开）
     */
    private Long industryId;

    /**
     * 主营行业大组名称（按照天猫行业结构打开）
     */
    private String industryName;

    /**
     * 主营一级大类ID（按照天猫行业结构打开）
     */
    private Long subIndustryId;

    /**
     * 主营一级大类名称（按照天猫行业结构打开）
     */
    private String subIndustryName;
}
