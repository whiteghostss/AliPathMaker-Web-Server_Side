package com.taobao.ad.brand.bp.client.api.campaigngroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.dto.response.Response;
import com.taobao.ad.brand.bp.client.context.DomainMetaqMessageBodyContext;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupDomainEventViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesBriefViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageNoticeTemplateViewDTO;

/**
 * @author yanjingang
 * @date 2023/3/12
 */
public interface BizCampaignGroupNoticeCommandService {

    String TAG = "CampaignGroup";

    @ProcessEntrance(name = "CampaignGroup采购状态更新时间变更通知", desc = "CampaignGroup采购状态更新时间变更通知", opType = OpType.update, tag = TAG)
    Response noticeCampaignGroupPurchaseStatusModifyTimeUpdated(ServiceContext serviceContext, Long id);

    // 对应AMB任务:brief_state_transit
    @ProcessEntrance(name = "CampaignGroup Brief状态变更通知", desc = "CampaignGroup Brief状态变更通知", opType = OpType.update, tag = TAG)
    Response noticeCampaignGroupBriefStatusUpdated(ServiceContext serviceContext, SalesBriefViewDTO salesBriefViewDTO);

    // 对应AMB任务:campaign_group_domain_event
    @ProcessEntrance(name = "CampaignGroup领域事件通知", desc = "CampaignGroup领域事件通知", opType = OpType.update, tag = TAG)
    Response noticeCampaignGroupDomainEvent(ServiceContext serviceContext, CampaignGroupDomainEventViewDTO campaignGroupDomainEventViewDTO);

    // 对应AMB任务:campaign_event_for_group
    @ProcessEntrance(name = "Campaign领域事件通知", desc = "Campaign领域事件通知", opType = OpType.update, tag = TAG)
    Response noticeCampaignDomainEvent(ServiceContext serviceContext, DomainMetaqMessageBodyContext bodyContext);

    @ProcessEntrance(name = "资源包客户模板添加新可用分组通知", desc = "资源包客户模板添加新可用分组通知", opType = OpType.update, tag = TAG)
    Response noticeCustomerTemplateSaleGroupUpdated(ServiceContext serviceContext, ResourcePackageNoticeTemplateViewDTO noticeTemplateViewDTO);

    // 对应AMB任务:campaign_group_send_msg
    @ProcessEntrance(name = "CampaignGroup message领域事件通知", desc = "CampaignGroup message领域事件通知", opType = OpType.update, tag = TAG)
    Response noticeCampaignGroupMessageDomainEvent(ServiceContext serviceContext, CampaignGroupDomainEventViewDTO domainEventViewDTO);

    @ProcessEntrance(name = "资源包客户模板设置盘量信息通知", desc = "资源包客户模板设置盘量信息通知", opType = OpType.update, tag = TAG)
    Response noticeCustomerTemplateSaleGroupInquiryInfoUpdated(ServiceContext serviceContext, ResourcePackageNoticeTemplateViewDTO noticeTemplateViewDTO);

    @ProcessEntrance(name = "订单分组自动生成计划通知", desc = "订单分组自动生成计划通知", opType = OpType.update, tag = TAG)
    Response noticeSaleGroupCampaignAutoCreated(ServiceContext serviceContext, DomainMetaqMessageBodyContext bodyContext);
}
