package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * @author yanjingang
 * @date 2024/9/2
 */
@Data
@Builder
public class CampaignRealTimeBatchOperateResultViewDTO extends BaseViewDTO {

    /**
     * 不支持的失败
     */
    private List<Long> unSupportFailIds;

    /**
     * 校验失败
     */
    private List<Long> validateFailIds;
    /**
     * 操作失败
     */
    private List<Long> operateFailIds;
    /**
     * 操作成功
     */
    private List<Long> operateSuccessIds;

}
