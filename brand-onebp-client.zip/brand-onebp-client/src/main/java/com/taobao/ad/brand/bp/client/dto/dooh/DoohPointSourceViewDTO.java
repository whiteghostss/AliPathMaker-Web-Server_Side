package com.taobao.ad.brand.bp.client.dto.dooh;

import lombok.Data;

import java.util.List;

/**
 * 天攻点位来源
 */
@Data
public class DoohPointSourceViewDTO {

    /**
     * 点位来源ID
     */
    private Integer id;

    /**
     * 点位来源名称
     */
    private String name;

    /**
     * 对应点位数量
     */
    private Integer pointCount;

    /**
     * 对应的分类列表
     */
    private List<DoohPointClassificationViewDTO> pointClassificationList;
}
