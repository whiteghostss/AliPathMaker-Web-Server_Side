package com.taobao.ad.brand.bp.client.dto.template;

import lombok.Data;

/**
 * 海棠中心回传参数
 */
@Data
public class CreativeCenterParaViewDTO {
    /**
     * 模版中心ID
     */
    private Long sspTemplateId;

    /**
     * 外部ID
     */
    private Long outerId;

    /**
     * 个性化setting
     * 注意，通用的setting已抽象为具体的领域模型中的属性，一些个性化的属性可以放在这个map中
     * 如果该map中存放了与通用setting冲突的key，则以通用setting为准，
     * 通用setting有哪些，可参考SettingKey
     */
    private String templateData;

    /**
     * 缩略图
     */
    private String thumb;

    /**
     * 预览地址
     */
    private String jsInHtml;
}
