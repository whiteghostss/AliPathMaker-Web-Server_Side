package com.taobao.ad.brand.bp.client.dto.resourcepackage;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/03/03
 */
@Data
public class ResourcePackageAmountSettingViewDTO extends BaseViewDTO {
    /**
     * 金额类型
     */
    private Integer type;

    /**
     * 金额
     */
    private Long amount;

    /**
     * 最大金额(type为区间模式时)
     */
    private Long maxAmount;
}
