package com.taobao.ad.brand.bp.client.dto.campaign;

import lombok.Data;

import java.util.List;

/**
 * 黑盒人群参数ViewDTO
 * */
@Data
public class OptimizeCrowdsAdgroupParamsViewDTO {
    /**
     * 单元ID
     * */
    private Long adgroupId;
    /**
     * 店铺和商品
     * */
    private List<ShopAndItemIdViewDTO> shopAndItemIdViewDTOList;
}
