package com.taobao.ad.brand.bp.client.dto.motion;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.List;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/18
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class MarketingStageViewDTO extends BaseViewDTO {

    /**
     * 阶段名称
     */
    private String name;
    /**
     * 阶段比例
     */
    private Integer ratio;
    /**
     * 开始时间
     */
    private Date startTime;
    /**
     * 结束时间
     */
    private Date endTime;
    /**
     * 阶段标签
     */
    private Integer label;

    private List<MediaStrategyViewDTO> mediaStrategyViewDTOList;
    private List<ResourceTypeStrategyViewDTO> resourceTypeStrategyViewDTOList;
}
