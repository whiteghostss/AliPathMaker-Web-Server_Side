package com.taobao.ad.brand.bp.client.dto.dooh;

import lombok.Data;

@Data
public class DoohCreativeMaterialViewDTO {
    /**
     * 宽
     */
    private Integer width;
    /**
     * 高
     */
    private Integer height;
    /**
     * 分辨率 width * height
     */
    private String resolution;
    /**
     * 时长
     */
    private Integer duration;
    /**
     * 文件类型
     */
    private String fileType;
    /**
     * 文件地址
     */
    private String fileUrl;
    /**
     * 文件名称
     */
    private String fileName;
    /**
     * 文件大小
     */
    private Double fileSize;
    /**
     * 扩展文件名称
     */
    private String extFileName;
}
