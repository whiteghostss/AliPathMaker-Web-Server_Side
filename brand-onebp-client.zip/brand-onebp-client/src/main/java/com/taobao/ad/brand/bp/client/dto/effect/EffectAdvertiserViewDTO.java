package com.taobao.ad.brand.bp.client.dto.effect;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * 效果adv viewDTO
 * @author yunhu.myh
 * @date 2023年08月29日
 * */
@Data
public class EffectAdvertiserViewDTO extends BaseViewDTO {
    /**
     * 品牌名称
     */
    private String brandName;
    /**
     * 广告主ID
     */
    private Long id;
    /**
     * 客户ID
     */
    private Long customerId;
    /**
     * 客户名称
     */
    private String customerName;
    private Integer customerType;
    private String customerTypeName;
    /**
     * 广告主memberId
     */
    private Long advMemberId;
    private String channelName;

    /**
     * 直投媒体名称
     */
    private String directMediaName;

    /**
     * 直投媒体广告主ID
     */
    private Long directAdvertiserId;

    /**
     * 媒体广告主id（vivo）
     */
    private String directAdvertiserUuid;

    /**
     * 直投媒体广告主名称
     */
    private String name;

    /**
     * 直投媒体广告主昵称
     */
    private String nickName;

    /**
     * 归因店铺ID
     */
    private Long shopId;

    /**
     * 归因店铺名称
     */
    private String shopName;

    /**
     * 归因类型 1店铺 2直播间
     */
    private Integer effectType;



    /**
     * 广告主状态
     */
    private Integer status;


    /**
     * 是否有效：1-启用 0-停用
     */
    private Integer invalid;

    /**
     * 账户有效期
     */
    private Date startTime;
    private Date endTime;

    /**
     * 归因店铺对应的sellerid
     */
    private Long sellerId;


    private Long channelId;


    /**
     * 当日消耗
     */
    private Long cost;

    /**
     * 总余额
     */
    private Long balance;

    /**
     * 现金余额
     */
    private Long cashBalance;

    /**
     * 赠款余额
     */
    private Long grantBalance;

    /**
     * 返货余额
     */
    private Long rewardBalance;

    /**
     * 空间ID
     * */
    private Long spaceId;
    /**
     * 空间名称
     * */
    private String spaceName;

    /**
     * 所属账号Id
     * */
    private Long masterId;
    /**
     * 所属账号名称
     * */
    private String masterName;

    /**
     * 关联的子合同信息
     * */
    private List<Long> contractIds;
}
