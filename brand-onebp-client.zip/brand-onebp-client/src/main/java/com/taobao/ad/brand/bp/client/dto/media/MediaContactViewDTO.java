package com.taobao.ad.brand.bp.client.dto.media;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;


/**
 * 媒体联系人ViewDTO
 * @author 弈云
 * @date 2023年04月04日
 * */
@Data
public class MediaContactViewDTO extends BaseViewDTO {
    /**
     * id
     * */
    private Long id;

    /**
     * 名称
     * */
    private String name;
    /**
     * 邮箱
     * */
    private String email;

    private Long mediaId;

}
