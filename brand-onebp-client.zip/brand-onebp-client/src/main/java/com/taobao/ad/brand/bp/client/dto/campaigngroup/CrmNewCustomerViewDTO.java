package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author yanjingang
 * @date 2023/3/20
 */
@Data
public class CrmNewCustomerViewDTO extends BaseViewDTO {

    /**
     * 客户id
     */
    private Long customerId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 客户名称
     */
    private String customerName;

    /**
     * 状态
     */
    private Integer status;

    /**
     * 客户下包含的广告主id列表
     */
    private List<Long> advIdList;

    /**
     * 服务优先级
     * @see ServePriorityEnum
     */
    private String servePriority;


    /**
     * 查询条件带广告主投放账号条件时，返回对应的advId
     */
    private Long queryAdvId;

    /**
     * 查询条件带广告主投放账号条件时，返回对应的userId
     */
    private Long queryUserId;

    /**
     * 查询条件带广告主投放账号条件时，返回对应的memberId
     */
    private Long queryMemberId;

}
