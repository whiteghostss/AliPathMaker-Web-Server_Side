package com.taobao.ad.brand.bp.client.error;

import com.alibaba.hermes.framework.error.ErrorCodeAware;
import com.alibaba.solar.common.constants.ErrorCode;
import com.alibaba.solar.common.exception.SystemException;

public class BrandOneBPException extends SystemException {
    private static final String BRAND_ERROR_KEY = "brand.biz.msg";

    private ErrorCodeAware errorCodeAware;

    public BrandOneBPException() {
        super(ErrorCode.EXTERNAL_ERROR,BRAND_ERROR_KEY);
    }

    public BrandOneBPException(String message, Throwable cause) {
        super(ErrorCode.EXTERNAL_ERROR,BRAND_ERROR_KEY,cause);
        this.errorCodeAware = BrandOneBPBaseErrorCode.INTERNAL_ERROR.of(message);
    }

    public BrandOneBPException(String message) {
        super(ErrorCode.EXTERNAL_ERROR,BRAND_ERROR_KEY);
        this.errorCodeAware = BrandOneBPBaseErrorCode.INTERNAL_ERROR.of(message);
    }

    public BrandOneBPException(ErrorCodeAware errorCodeAware) {
        super(ErrorCode.EXTERNAL_ERROR,BRAND_ERROR_KEY);
        this.errorCodeAware = errorCodeAware;
    }

    public BrandOneBPException(String code, String message) {
        super(ErrorCode.EXTERNAL_ERROR,BRAND_ERROR_KEY);
        this.errorCodeAware = ErrorCodeAware.Builder.build(code, message);
    }

    public BrandOneBPException(ErrorCodeAware errorCodeAware, String message) {
        super(ErrorCode.EXTERNAL_ERROR,BRAND_ERROR_KEY);
        this.errorCodeAware = ErrorCodeAware.Builder.build(errorCodeAware.getErrCode(), message);
    }

    public BrandOneBPException(Throwable cause) {
        super(ErrorCode.EXTERNAL_ERROR,BRAND_ERROR_KEY,cause);
        this.errorCodeAware = BrandOneBPBaseErrorCode.INTERNAL_ERROR;
    }

    /**
     * 获取异常信息
     * @param e
     * @return
     */
    public static ErrorCodeAware getErrorCodeFromException(Exception e){
        ErrorCodeAware errorCodeAware = BrandOneBPBaseErrorCode.INTERNAL_ERROR;
        if (e instanceof BrandOneBPException) {
            errorCodeAware = ((BrandOneBPException) e).getErrorCodeAware();
        }
        else if (e.getCause() != null && e.getCause().getCause() != null) {
            if (e.getCause().getCause() instanceof BrandOneBPException) {
                errorCodeAware = ((BrandOneBPException) e.getCause().getCause()).getErrorCodeAware();
            }
        }
        return errorCodeAware;
    }

    @Override
    public String getMessage() {
        return errorCodeAware.getErrMsg();
    }

    public ErrorCodeAware getErrorCodeAware() {
        return errorCodeAware;
    }
}
