package com.taobao.ad.brand.bp.client.dto.effect;

import lombok.Data;


/**
 * 效果adv viewDTO
 * @author yunhu.myh
 * @date 2023年08月29日
 * */
@Data
public class CampaignEffectAdvertiserViewDTO extends EffectAdvertiserViewDTO {
    private Long campaignId;
    private String campaignName;
    private Long parentCampaignId;
    private String parentCampaignName;
}
