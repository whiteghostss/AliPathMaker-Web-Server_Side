package com.taobao.ad.brand.bp.client.dto.creative;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.creative.element.ElementViewDTO;
import com.alibaba.ad.brand.dto.creative.malus.CreativeMalusViewDTO;
import com.alibaba.ad.brand.dto.creative.preview.CreativePreviewViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativeSourceEnum;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.audit.AuditPageViewDTO;
import com.taobao.ad.brand.bp.client.dto.tag.TagViewDTO;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/3/4 12:25
 * @description ：
 * @modified By：
 */
@Data
public class CreativePageViewDTO extends BaseViewDTO {
    /**
     * 主键
     */
    private Long id;

    /**
     * 创意名称
     */
    private String name;

    /**
     * 创意所属Member
     */
    private Long memberId;

    /**
     * 订单的客户投放账号ID（订单创建时，从售卖侧传过来）
     * 代投账号或叉乘账号下单时，此属性记录为真实的客户投放账号
     */
    private Long customerMemberId;

    /**
     * 产品id
     */
    private Integer productId;

    /**
     * 广告主设置的状态 默认1上线
     */
    private Integer onlineStatus;

    /**
     * 创意联动方式
     */
    private Integer linkageMode;

    /**
     * 模版中心ID
     */
    private Long sspTemplateId;

    /**
     * 模版中心名称
     */
    private String sspTemplateName;

    /**
     * 模版中心封面
     */
    private String sspTemplateThumb;

    /**
     * 模版中心模板尺寸
     */
    private String sspTemplateSize;

    /**
     * 起始时间
     */
    private Date startTime;

    /**
     * 结束时间
     */
    private Date endTime;

    /**
     * 是否精确到时间
     * 0-精确到日期
     * 1-精确到时分秒
     */
    private Integer accurateTime;

    /**
     * 创意所属域
     */
    private Integer creativeScope;

    /**
     * 创意来源
     * {@link BrandCreativeSourceEnum}
     */
    private Integer creativeSource;

    /**
     * 创意投放类型
     */
    private Integer targetType;

    /**
     * 创意投放类型描述
     */
    private String targetTypeDesc;

    /**
     * SSP资源类型
     */
    private Integer sspResourceType;

    /**
     * 资源类型详情
     */
    private String sspResourceTypeDesc;

    /**
     * 广告样式
     */
    private String sspAdType;

    /**
     * 创意预览
     */
    private CreativePreviewViewDTO creativePreviewView;

    /**
     * 海棠相关属性
     */
    private CreativeMalusViewDTO creativeMalus;

    /**
     * 审核信息
     */
    private AuditPageViewDTO creativeAudit;

    /**
     * 创意物料
     */
    private List<ElementViewDTO> elementList;

    /**
     * 创意绑定的adgroupList
     */
    @Deprecated
    private List<CommonViewDTO> adgroupList;

    /**
     * 创意绑定关系List
     */
    private List<CreativeRefPageViewDTO> creativeRefList;

    /**
     * 创意包id
     */
    private Long creativePackageId;


    /**
     * 创意包类型
     * {@link com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativePackageTypeEnum}
     */
    private Integer packageType;

    /**
     * 是否必须 子创意绑定单元前都是非必须
     *
     * @see BrandBoolEnum
     */
    private Integer isRequired;

    /**
     * 子创意列表
     */
    private List<CreativePageViewDTO> subCreativeViewDTOList;

    /**
     * 创意标签
     */
    private Long creativeTagId;

    private String creativeTagName;

    /**
     * 资质类型列表
     */
    private List<String> qualificationTypeList;

    private List<String> visualImages;

    /**
     * 标签列表
     */
    private List<TagViewDTO> tagList;
}
