package com.taobao.ad.brand.bp.client.api.common;

import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.CommandAPI;
import com.alibaba.hermes.framework.dto.response.Response;

/**
 * BPMS工作流
 *
 * @author yanjingang
 * @date 2023/11/9
 */
public interface BizBpmsCommandService extends CommandAPI {

    String TAG = "Common";

    @ProcessEntrance(name = "审核流程回调", desc = "审核流程回调", opType = OpType.update, tag = TAG)
    Response processFinishCallback(String processCode, String procInstId, Long entityId, Integer result, String extInfo);

    @ProcessEntrance(name = "审核流程回调", desc = "审核流程回调", opType = OpType.update, tag = TAG)
    Response processFinishCallback(String processCode, String procInstId, Integer result, String extInfo);
}
