package com.taobao.ad.brand.bp.client.dto.resourcepackage;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;

import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignSaleGroupResourceDeliveryTargetViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignSaleGroupResourceOptimizeTargetViewDTO;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * 资源包分组的viewDTO
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/22
 */
@Data
public class ResourcePackageSaleGroupViewDTO extends BaseViewDTO {
    private Long id;

    /**
     * 售卖分组名称
     */
    private String name;

    /**
     * 是否全局分组（1-是，0-否）
     */
    private Integer isGlobalType;

    /**
     * 推送bp渠道（1 - 新品牌BP）
     */
    private Integer targetBP;

    /**
     * 售卖分组类型
     */
    private Integer type;

    /**
     * 分组售卖类型
     *
     * @see BrandSaleTypeEnum
     */
    private Integer saleType;

    /**
     * 产品配置类型
     */
    private Integer productConfigType;

    /**
     * 创建时间
     */
    private Date gmtCreate;

    /**
     * 修改时间
     */
    private Date gmtModified;

    /**
     * 开始时间
     */
    private Date startDate;

    /**
     * 结束时间
     */
    private Date endDate;

    /**
     * 所属模板id
     */
    private Long templateId;

    /**
     * 主分组id(补、配分组才有该id)
     */
    private Long mainGroupId;

    /**
     * 客户分组对应的招商分组id
     */
    private Long superiorGroupId;

    /**
     * 客户模版上的该分组是否被销售选中
     */
    private Integer isSelected;
    /**
     * 金额设置
     */
    private ResourcePackageAmountSettingViewDTO amountConfigure;
    /**
     * ssp二级分配列表
     */
    private List<ResourceDistributionRuleViewDTO> distributionRuleList;

    /**
     * 分组是否必选（1-是， 0-否）
     */
    private Integer isNecessary;

    /**
     * 分组预定点击率
     */
    private Integer predictClickRate;

    /**
     * 分组预计曝光量折扣
     */
    private Integer predictExposureRate;

    /**
     * 分组最小产品个数
     */
    private Integer minQuality;

    /**
     * 分组最小产品个数
     */
    private Integer maxQuality;

    /**
     * 分组cpm单价
     */
    private Long cpmUnitPrice;

    /**
     * 业务场景（子订单标识）
     *
     */
    private Integer businessLine;

    /**
     * 售卖产品线
     */
    private Integer saleProductLine;

    /**
     * 所属售卖产品
     */
    private Integer productCategory;

    /**
     * 智能投放类型
     */
    private Integer optimizationType;

    /**
     * 分组折扣
     */
    private Integer discount;

    /**
     * 用户生成客户模板包的映射关系（售卖中心分组落库的主键id）
     */
    private Long detailId;

    /**
     * 售卖金额（单位：分）
     */
    private Long budget;

    /**
     * 是否互动产品（1：是  0：否）
     */
    private Integer isInteractProduct;

    /**
     * 人群定向（普通分组）
     */
    private Integer crowdInfo;

    /**
     * 分组来源
     */
    private Integer source;
    /**
     * 模板*分组 状态
     * 1-未生效；2-已生效；99-已作废
     */
    private Integer status;

    /**
     * 补量配送分组审批状态
     * @see com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupAuditStatusEnum
     */
    private Integer auditStatus;

    /**
     * 限制修改版本
     */
    private Integer editMode;

    /**
     * 流程审核信息
     */
    private ResourcePackageSaleGroupAuditViewDTO processAuditInfo;

    /**
     * 投放账号ID
     */
    private Long memberId;

    /**
     * 操作类型
     * @see com.taobao.ad.brand.bp.client.enums.resourcepackage.SaleGroupOperateTypeEnum
     */
    private Integer operateType;


    /****解析资源分组所得************/
    /**
     * 购买分组对应得补量分组ID
     */
    private List<Long> replenishGroupIds;
    /**
     * 购买分组对应得配送分组ID
     */
    private List<Long> distributionGroupIds;

    /**
     * 回流渠道
     */
    private Integer dataChannel;

//    /**
//     * 分组均价配置列表
//     */
//    @Deprecated
//    private List<ResourcePackageUnitPriceViewDTO> unitPriceConfigList;

    /**
     * 这里是从资源包返回的信息
     * 交付指标（多个）
     * 这里资源包的命名是newDeliveryTargetList
     */
    private List<CampaignSaleGroupResourceDeliveryTargetViewDTO> resourceDeliveryTargetList;

    /**
     * 优化指标（多个）
     * 这里是从资源包返回的信息
     */
    private List<CampaignSaleGroupResourceOptimizeTargetViewDTO> resourceOptimizeTargetList;

    /**
     * 相关人/负责人列表
     */
    private List<ResourcePackageEmpViewDTO> chargeEmpList;

    /**
     * 是否进行盘量优先级管控
     * @see com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum
     */
    private Integer hasInquiryPriority;

    /**
     * 客户模板盘量日期
     */
    private Date inquiryDate;

    /**
     * 客户模板盘量批次
     */
    private Integer inquiryBatch;

    /**
     * 派单/非派单（内容专用）
     */
    private Integer supplyType;

    /**
     * ssp产品线
     */
    private Integer sspProductLine;

    /**
     * 下载二级计划明细开关
     * @see com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum
     */
    private Integer downloadSubCampaignInfo;

    /**
     * 监测配置
     */
    private ResourcePackageMonitorConfigDTO monitorConfig;

    /**
     * 支持优化型频控
     * @see com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum
     */
    private Integer supportOptimizedFrequency;

    /**
     * 关联实际购买资源审批工作流id（天合反哺）
     */
    private String actualPurchaseAuditWorkflowInstanceId;

    /**
     * 关联实际购买资源审批状态（天合反哺）
     * @see com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupAuditStatusEnum
     */
    private Integer actualPurchaseAuditStatus;

    /**
     * 关联实际购买资源购买分组id
     */
    private Long actualPurchaseSaleGroupId;

    /**
     * 业务类型
     * @see com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupBusinessTypeEnum
     */
    private Integer businessType;

    /**
     * 配送分组业务类型
     * @see com.alibaba.ad.brand.sdk.constant.salegroup.field.SaleGroupDistributionTypeEnum
     */
    private Integer distributionType;
}