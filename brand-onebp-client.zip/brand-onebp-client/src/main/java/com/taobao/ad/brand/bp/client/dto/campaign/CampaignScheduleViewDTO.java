package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.DayAmountViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignShowmaxCrowdViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquirySchedulePolicyViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignInquiryAssignTypeEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignScheduleOperateTypeEnum;
import lombok.Data;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/03/06
 */
@Data
public class CampaignScheduleViewDTO extends BaseViewDTO {
    /**
     * 订单ID
     */
    private Long campaignGroupId;
    private String campaignGroupName;
    private Long customerMemberId;
    /**
     * 订单状态
     *
     * @see com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum
     */
    private Integer campaignGroupStatus;
    /**
     * 计划id
     */
    private Long id;
    /**
     * 计划名称
     */
    private String title;
    /**
     * 计划对应的分组ID
     */
    private Long saleGroupId;
    /**
     * 媒体域
     */
    private Integer sspMediaScope;
    /**
     * 售卖产品线
     */
    private Integer saleProductLine;
    /**
     * 状态
     *
     * @see BrandCampaignStatusEnum
     */
    private Integer status;

    private Integer saleType;
    private Date startTime;
    private Date endTime;
    /**
     * 总预定量
     */
    private Long amount;
    /**
     * 未来预定量
     */
    private Long futureAmount;
    /**
     * 总cpt预定量
     */
    private Long cptAmount;
    /**
     * 未来cpt预定量
     */
    private Long futureCptAmount;

    /**
     * 预定单位
     */
    private Integer sspRegisterUnit;
    /**
     * 询锁量计划ID
     */
    private List<Long> operateSubCampaignIds;
    /**
     * @see CampaignScheduleOperateTypeEnum
     */
    private Integer operateType;
    /**
     * 区间分配策略
     * 1：分天 （BY_DAY）
     * 2：智能 （INTELLIGENCE ）
     *
     * @see BrandCampaignInquiryAssignTypeEnum
     */
    private Integer inquiryAssignType;
    /**
     * 是否系统投放
     * @see com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignProgrammaticEnum
     */
    private Integer sspProgrammatic;
    /**
     * 采购行IDs
     */
    private List<Long> purchaseRowIds;
    /**
     * 询量行IDs
     */
    private List<Long> inquiryRowIds;
    /**
     * 媒体第一次询量时间
     */
    private Date mediaFirstInquiryTime;
    /**
     * 媒体询量单ID
     */
    private Long mediaInquiryOrderId;
    /**
     * 询锁量信息
     */
    private List<CampaignInquiryViewDTO> inquiryViewDTOList;
    /**
     * 根据inquiryViewDTOList拆分的未来的Inquiry
     */
    private List<CampaignInquiryViewDTO> futureInquiryList;
    /**
     * 根据inquiryViewDTOList拆分的历史的Inquiry
     */
    private List<CampaignInquiryViewDTO> historyInquiryList;

    /**
     * 二级计划列表
     */
    private List<CampaignScheduleViewDTO> subCampaignList;

    /**
     * 是否强制预定
     */
    private Integer isCompulsive;
    /**
     * 采购单id列表
     */
    private List<Long> purchaseOrderIds;
    /**
     * 询量单id列表
     */
    private List<Long> inquiryOrderIds;

    private String creatorId;
    private String creatorName;
    /**
     * 媒体询量预定量
     */
    private List<DayAmountViewDTO> mediaInquiryDemandAmountList;
    /**
     * SSP单位CPM数量
     */
    private Integer unitExposure;
    /**
     * 媒体占比 for 全域通 询锁量
     */
    private Map<Integer, Integer> mediaScopeBudgetRatioMap;
    /**
     * 计划第一次上线时间
     */
    private Date firstOnlineTime;

    private List<Long> sspResourceIds;

    private CampaignShowmaxCrowdViewDTO campaignShowmaxCrowdViewDTO;
    /**
     * 询量周期分配策略
     * inquiryAssignType = 3（周期）必填
     */
    private List<CampaignInquirySchedulePolicyViewDTO> schedulePolicyList;
    /**
     * 计划排期未设置时，是否自动分配周期预定量
     */
    private Boolean isAutoAssign = false;

    /**
     * 计划总预算
     */
    private Long discountTotalMoney;

    private Integer sspProductLineId;
}
