package com.taobao.ad.brand.bp.client.dto.cartitem;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 购物车下单规则判断
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CartItemConsistencyCheckResultViewDTO extends BaseViewDTO {
    /**
     * 加购行id
     */
    private Long cartItemId;
    /**
     * skuId
     */
    private Long skuId;
    /**
     * 是否通过
     * BooleanEnum
     */
    private Integer isPass;
    /**
     * 不通过原因
     */
    private String reason;
    /**
     * 加购行计划校验结果
     */
    private List<CartItemCampaignConsistencyCheckResultViewDTO> campaignCheckResultViewDTOList;
}
