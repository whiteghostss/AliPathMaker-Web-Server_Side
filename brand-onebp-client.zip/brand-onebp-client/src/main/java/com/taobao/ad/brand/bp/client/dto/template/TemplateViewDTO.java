package com.taobao.ad.brand.bp.client.dto.template;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.site.SiteViewDTO;
import com.taobao.ad.brand.bp.client.dto.tag.TagViewDTO;
import com.taobao.ad.brand.bp.client.dto.template.element.TemplateElementViewDTO;
import lombok.Data;

import java.util.List;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/3/4 18:53
 * @description ：
 * @modified By：
 */
@Data
public class TemplateViewDTO extends BaseViewDTO {

    /**
     * 主键
     */
    private Long id;

    /**
     * 媒体域
     */
    private Integer mediaScope;

    /**
     * 模版名称
     */
    private String name;

    /**
     * 资源类型
     */
    private String resourceType;

    /**
     * 资源类型名称
     */
    private String resourceTypeName;

    /**
     * 备注
     */
    private String remark;

    /**
     * 模版尺寸
     */
    private String templateSize;

    /**
     * 外部模版ID
     */
    private String externalTemplateId;

    /**
     * 物料类型
     */
    private String materialType;

    /**
     * 物料类型名称
     */
    private String materialTypeName;

    /**
     * 协议模版ID
     */
    private Integer sspTemplateId;

    private Integer status;

    /**
     * 媒体列表
     */
    private List<SiteViewDTO> mediaList;

    /**
     * 广告样式列表
     * 字典值type为ad_style
     */
    private List<CommonViewDTO> effectList;

    /**
     * 流量适用类型
     * 字典值type为traffic_type
     */
    private List<CommonViewDTO> trafficTypeList;

    /**
     * 终端列表
     */
    private List<CommonViewDTO> deviceList;

    /**
     * 是否子模版
     */
    private Integer subTemplate;

    /**
     * 关联监测包id
     */
    private Long monitorBagId;

    /**
     * 是否支持智能创意
     */
    private Integer intelligentIdea;

    /**
     * 模版类型
     */
    private Integer templateType;

    /**
     * 是否需要媒体送审
     * @see com.alibaba.ad.nb.ssp.constant.template.TemplateApprovalTypeEnum
     */
    private Integer needApproval;

    /**
     * 是否区分使用方
     */
    private Integer differentiatedMedia;

    /**
     * 海棠模版ID
     */
    private String malusTemplateId;

    /**
     * 优先级
     */
    private Integer priority;

    private List<TemplateViewDTO> crossMediaScopeTemplateList;

    private List<TemplateViewDTO> interactTemplateList;

    private List<CommonViewDTO> materialRuleList;

    /**
     * 创意类型
     */
    private Integer creativeType;

    /**
     * 联动方式
     */
    private Integer linkageMode;

    /**
     * subType
     */
    private String subType;

    /**
     * 元素
     */
    private List<TemplateElementViewDTO> protocolList;
    /**
     * @see com.alibaba.ad.nb.ssp.constant.common.TemplateAccurateEnum
     * */
    private Integer isAccurate;

    /**
     * 附加类型
     */
    private Integer additionalStatus;

    /**
     * 标签列表
     */
    private List<TagViewDTO> tagList;
}
