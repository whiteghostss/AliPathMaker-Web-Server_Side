package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import java.util.List;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.order.ConfirmedAgreementInfoViewDTO;

import lombok.Data;

/**
 * @author yanjingang
 * @date 2023/03/14
 */
@Data
public class CampaignGroupOrderCommandViewDTO extends BaseViewDTO {

    /**
     * 订单ID
     */
    private Long id;

    /**
     * 勾选的售卖分组ID列表
     */
    private List<Long> saleGroupIds;

    /**
     * 确认协议
     */
    private ConfirmedAgreementInfoViewDTO confirmedAgreementInfoViewDTO;

    /**
     * 申请发起人
     */
    private String creatorId;

    private Boolean needTransit = Boolean.TRUE;
    /**
     * 忽略不支持迁移的错误
     */
    private boolean ignoreNotTransitError = false;

    /******************* 自助onepage使用 ************/

    /**
     * 签约的排期表
     */
    private String signScheduleUrl;
    /**
     * 联系电话
     */
    private String contactPhone;
}
