package com.taobao.ad.brand.bp.client.dto.mr;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.template.TemplateViewDTO;
import lombok.Data;

import java.util.List;

/**
 * @author yunhu.myh
 * @date 2023年09月30日
 * mr
 * */
@Data
public class MaterialRuleViewDTO extends BaseViewDTO {
    private Long id;
    private String ruleName;
    private String ruleDesc;
    private Integer preDays;
    private String demoUrl;
    private Long mediaId;
    private Integer mediaScope;
    private List<MaterialRuleItemDetailViewDTO> materialRuleItemList;
    private String opEmpId;
    private Integer adStyle;
    private String adStyleName;
    private Integer materialType;
    private String materialTypeName;
    private Integer status;
    private Integer isOnlineSameAsOffline;
    private String templateName;
    private List<TemplateViewDTO> templateList;
}