package com.taobao.ad.brand.bp.client.dto.creative;

import lombok.Data;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author: PhilipFry
 * @createTime: 2024年04月02日 10:41:43
 * @Description: 创意协议
 */
@Data
public class CreativeEngineViewDTO {
    private List<EngineContent> contentList;

    @Data
    public static class EngineContent {
        /**
         * db: creative_element.field_name
         */
        private String key;
        /**
         * db:creative_element.element_text_value
         */
        private String content;

        /**
         * db:
         * Map<String, String>	creative_element_setting
         * setting_key: map.key
         * setting_value: map.value
         */
        private Map<String, String> props;

        public void addProperty(String key, String value) {
            if (this.props == null) {
                this.props = new HashMap();
            }

            this.props.put(key, value);
        }
    }
}
