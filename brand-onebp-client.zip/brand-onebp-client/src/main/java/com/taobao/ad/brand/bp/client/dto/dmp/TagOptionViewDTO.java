package com.taobao.ad.brand.bp.client.dto.dmp;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TagOptionViewDTO extends BaseViewDTO {

    /**
     * tagId
     */
    private Long tagId;
    /**
     * tagId
     */
    private Long optionId;
    /**
     * 标签名称
     */
    private String optionName;
    /**
     * 标签值
     */
    private String optionValue;
}