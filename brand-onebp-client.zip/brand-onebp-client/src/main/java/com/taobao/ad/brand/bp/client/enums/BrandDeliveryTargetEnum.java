package com.taobao.ad.brand.bp.client.enums;
import lombok.Getter;
/**
 * ssp枚举增加一个
 * 算法只预估 人群浓度、点击量、到达量、N次触达率、点击率
 * */
@Getter
public enum BrandDeliveryTargetEnum {
    TA(1, "人群浓度"),
    CLICK_COST(2, "点击成本"),
    ARRIVE_COST(3, "到达成本"),
    CLICK_AMOUNT(4, "点击量"),
    ARRIVE_AMOUNT(5, "到达量"),
    N_REACH(6, "N次触达率"),
    NEW_CUSTOMER(7, "新客浓度"),
    UV_AMOUNT(8, "UV量"),
    CLICK_RATE(9, "点击率"),
    INTERACT_AMOUNT(10, "品牌互动量"),
    INTERACT_RATE(11, "品牌互动率"),
    EXPOSURE(12, "曝光量"),
    COLLECT_ADD_PURCHASE(13, "收藏加购量"),
    ADD_PURCHASE_SUCCESS(16, "商品加购量"),
    /**
     * 商品互动量
     * */
    ITEM_INTERACT_AMOUNT(17, "商品互动量"),
    /**
     * 引导入会人数
     * */
    MEMBERSHIP_SIGN_UPS(19, "引导入会人数"),
    /**
     * 心智激发率
     */
    MIND_STIMULATION_RATE(20, "心智激发率"),

    /*开始*/
    /**
     * 这里是为了临时存储，为了逻辑保持一致，临时增加
     * */
    PV(10000,"曝光"),
    CPM_PRICE(10001,"CPM成本"),
    CLICK_PRICE(10002,"点击成本"),
    ARRIVE_PRICE(10003,"到达成本"),
    COLLECT_ADD_PURCHASE_PRICE(100013, "收藏加购成本"),
    /*结束*/
    ;
    private final Integer value;
    private final String name;

    BrandDeliveryTargetEnum(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    public static BrandDeliveryTargetEnum getByValue(Integer value) {
        for (BrandDeliveryTargetEnum deliveryTargetEnum : BrandDeliveryTargetEnum.values()) {
            if (deliveryTargetEnum.getValue().equals(value)) {
                return deliveryTargetEnum;
            }
        }
        return null;
    }
}
