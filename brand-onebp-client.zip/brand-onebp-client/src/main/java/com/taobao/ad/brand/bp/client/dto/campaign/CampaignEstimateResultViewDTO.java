package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.ConfidenceInfoViewDTO;
import lombok.Data;

import java.util.Date;

/**
 * 计划成效预估
 */
@Data
public class CampaignEstimateResultViewDTO  extends BaseViewDTO {
    /**
     * 这里返回的是算法的+Bp自己算的，存储的是算法的
     * @see
     * */
    private Integer deliveryTarget;
    /**
     * 算法预估最大值
     * */
    private Long max;
    /**
     * 算法预估最小值
     * */
    private Long min;
    /**
     * 交付预估最终值
     * */
    private Long finalValue;
    /**
     * 兼容showmax的最大值
     * */
    private Long finalValueMax;

    /**
     * 资源包设定的值
     * 若没设置，则返回null。
     * */
    private Long resourceValue;

    /**
     * 推荐开始日期
     */
    private Date startDate;

    /**
     * 推荐结束日期
     */
    private Date endDate;
    /**
     * 一级计划id
     */
    private Long campaignId;

    /**
     * 置信度
     */
    private ConfidenceInfoViewDTO confidenceInfoViewDTO;
}
