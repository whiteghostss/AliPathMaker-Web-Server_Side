package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import java.util.Map;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupEventEnum;
import com.taobao.ad.brand.bp.client.enums.message.DomainMessageTypeEnum;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author yanjingang
 * @date 2023/7/20
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class CampaignGroupDomainEventViewDTO extends BaseViewDTO {

    /**
     * 消息类型
     */
    private DomainMessageTypeEnum domainType;
    /**
     * 消息事件类型
     */
    private CampaignGroupEventEnum event;

    /**
     * 广告主member
     */
    private Long memberId;
    /**
     * bizCode
     */
    private String bizCode;
    /**
     * 订单ID
     */
    private Long campaignGroupId;

    /**
     * 扩展属性
     */
    private Map<String, String> properties;

}
