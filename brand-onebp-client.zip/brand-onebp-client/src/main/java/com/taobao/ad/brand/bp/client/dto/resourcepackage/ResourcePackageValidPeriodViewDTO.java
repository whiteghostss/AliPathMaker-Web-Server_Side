package com.taobao.ad.brand.bp.client.dto.resourcepackage;

import java.util.Date;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;

import lombok.Data;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/03/14
 */
@Data
public class ResourcePackageValidPeriodViewDTO extends BaseViewDTO {

    /**
     * 价格政策有效开始日期
     */
    private Date beginDate;

    /**
     * 价格政策有效结束日期
     */
    private Date endDate;

}
