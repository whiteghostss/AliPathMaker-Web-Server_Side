package com.taobao.ad.brand.bp.client.dto.pub;

import com.taobao.ad.brand.bp.client.enums.DimensionTypeEnum;
import lombok.Data;

import java.util.List;

@Data
public class DimensionConfigRuleViewDTO {
    /**
     * @see DimensionTypeEnum
     * */
    private Integer dimensionType;
    /**
     * 最大数量，-1代表不限，null 代表不限
     * */
    private Long maxCount;
    /**
     * 规则豁免的memberId
     * */
    private List<Long> excludeMemberIds;
}
