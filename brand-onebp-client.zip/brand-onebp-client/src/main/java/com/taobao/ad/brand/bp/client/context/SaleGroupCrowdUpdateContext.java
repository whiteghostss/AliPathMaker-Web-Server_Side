package com.taobao.ad.brand.bp.client.context;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


/**
 * 订单分组人群更新事件
 * */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SaleGroupCrowdUpdateContext {
    private ServiceContext serviceContext;
    private SaleGroupInfoViewDTO saleGroupInfoViewDTO;
}
