package com.taobao.ad.brand.bp.client.dto.template.query;

import com.taobao.ad.brand.bp.client.dto.base.BaseQueryViewDTO;
import lombok.Data;

import java.util.List;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/3/4 18:03
 * @description ：
 * @modified By：
 */
@Data
public class CreativeCenterMetaQueryViewDTO extends BaseQueryViewDTO {
   private List<Long> templateIds;
   private Integer operation;
}
