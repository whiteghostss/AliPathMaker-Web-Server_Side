package com.taobao.ad.brand.bp.client.dto.creative;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * @author zhaorubing
 * @date 2025/2/24 16:01
 */
@Data
public class MemberPageCheckViewDTO extends BaseViewDTO {

    /**
     * 商家是否已开通会员体系
     */
    private boolean memberCheck;

    /**
     * 商家入会是否未被冻结
     */
    private boolean notFreezeCheck;
}
