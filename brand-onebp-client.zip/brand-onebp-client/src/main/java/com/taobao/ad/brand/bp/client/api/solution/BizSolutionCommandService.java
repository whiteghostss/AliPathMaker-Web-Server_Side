package com.taobao.ad.brand.bp.client.api.solution;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.CommandAPI;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.solution.CartItemSolutionOrderViewDTO;
import com.taobao.ad.brand.bp.client.dto.solution.CartItemSolutionViewDTO;

public interface BizSolutionCommandService extends CommandAPI {

    String TAG = "Solution";

    /**
     * onePage模式新建解决方案
     * @param context
     * @param viewDTO
     * @return
     */
    @ProcessEntrance(name = "新增", desc = "新增", opType = OpType.add, tag = TAG)
    SingleResponse<Long> addCartItemSolution(ServiceContext context, CartItemSolutionViewDTO viewDTO);

    /**
     * onePage模式修改解决方案
     * @param context
     * @param viewDTO
     * @return
     */
    @ProcessEntrance(name = "修改", desc = "修改", opType = OpType.update, tag = TAG)
    SingleResponse<Long> updateCartItemSolution(ServiceContext context, CartItemSolutionViewDTO viewDTO);

    /**
     * onePage模式-下单解决方案
     * @param context
     * @param solutionOrderViewDTO
     * @return
     */
    @ProcessEntrance(name = "下单", desc = "下单", opType = OpType.update, tag = TAG)
    SingleResponse<Long> orderCartItemSolution(ServiceContext context, CartItemSolutionOrderViewDTO solutionOrderViewDTO);
    /**
     * onePage模式-返回修改
     * @param context
     * @param id
     * @return
     */
    @ProcessEntrance(name = "删除方案", desc = "删除方案", opType = OpType.update, tag = TAG)
    Response deleteCartItemSolution(ServiceContext context, Long id);
}
