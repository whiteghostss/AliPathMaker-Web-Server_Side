package com.taobao.ad.brand.bp.client.dto.resourcepackage;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * @author gxg
 */
@Data
public class ResourcePackageEmpViewDTO extends BaseViewDTO {
    /**
     * 小二姓名
     */
    private String name;
    /**
     * 小二花名
     */
    private String nick;
    /**
     * 小二工号
     */
    private String empId;

    /**
     * 邮箱
     */
    private String email;

    /**
     * 状态，I-离职，A-在职
     */
    private String status;

    /**
     * 手机号
     */
    private String mobile;

    /**
     * 实线主管
     */
    private ResourcePackageEmpViewDTO superEmp;

    /**
     * 部门名称
     */
    private String deptName;
}
