package com.taobao.ad.brand.bp.client.enums;

public enum DimensionTypeEnum {
    ADGROUP(2, "单元"),
    ADGROUP_X_CREATIVE(3, "单元绑定创意")
    /*结束*/
    ;
    private final Integer value;
    private final String name;

    DimensionTypeEnum(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    public Integer getValue() {
        return value;
    }

    public String getName() {
        return name;
    }

    public static DimensionTypeEnum getByValue(Integer value) {
        for (DimensionTypeEnum typeEnum : DimensionTypeEnum.values()) {
            if (typeEnum.getValue().equals(value)) {
                return typeEnum;
            }
        }
        return null;
    }
}
