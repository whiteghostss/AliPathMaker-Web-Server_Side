package com.taobao.ad.brand.bp.client.dto.creative;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

@Data
public class CreativeLandingPageAnalysisViewDTO extends BaseViewDTO {
    private Long itemId;
    private Long liveId;
    private Long shopId;
}
