package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author yanjingang
 * @date 2023/9/20
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SaleGroupCanDeleteViewDTO extends BaseViewDTO {

    /**
     * 分组ID
     */
    private Long saleGroupId;
    /**
     * 是否支持删除
     */
    private Boolean canDelete;
    /**
     * 不能删除的原因
     */
    private String reason;

}
