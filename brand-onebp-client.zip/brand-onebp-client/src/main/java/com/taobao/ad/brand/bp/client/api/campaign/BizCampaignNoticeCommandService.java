package com.taobao.ad.brand.bp.client.api.campaign;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.CommandAPI;
import com.alibaba.hermes.framework.dto.response.Response;
import com.taobao.ad.brand.bp.client.context.DomainMetaqMessageBodyContext;

public interface BizCampaignNoticeCommandService extends CommandAPI {

    String TAG = "Campaign";

    // 对应AMB任务:content_campaign_event
    @ProcessEntrance(name = "子订单更新通知", desc = "子订单更新通知", opType = OpType.update, tag = TAG)
    Response noticeCampaignGroup(ServiceContext serviceContext, DomainMetaqMessageBodyContext bodyContext);

    // 对应AMB任务:campaign_event
    @ProcessEntrance(name = "计划新建编辑通知", desc = "计划新建编辑通知", opType = OpType.update, tag = TAG)
    Response noticeCampaign(ServiceContext serviceContext, DomainMetaqMessageBodyContext bodyContext);

    @ProcessEntrance(name = "通知新增算法人群", desc = "通知新增算法人群", opType = OpType.update, tag = TAG)
    Response noticeCampaignAddAlgoCrowd(ServiceContext serviceContext, DomainMetaqMessageBodyContext bodyContext);
}
