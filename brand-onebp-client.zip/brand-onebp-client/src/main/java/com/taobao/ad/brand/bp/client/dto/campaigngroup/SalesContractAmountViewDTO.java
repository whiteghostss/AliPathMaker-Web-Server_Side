package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * 合同金额信息
 *
 * @author yanjingang
 * @date 2024/7/18
 */
@Data
public class SalesContractAmountViewDTO extends BaseViewDTO {

    /**
     * 合同ID
     */
    private Long contractId;

    /** 合同总金额，含红包 */
    private Long discountAmount;

    /** 合同现金金额 */
    private Long cashAmount;

    /** 合同已付款金额 */
    private Long repayTotalAmount;

    /** 合同剩余未付款金额 */
    private Long waitRepayAmount;

}
