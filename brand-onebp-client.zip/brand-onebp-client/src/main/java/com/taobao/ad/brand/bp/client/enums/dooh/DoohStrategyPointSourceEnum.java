package com.taobao.ad.brand.bp.client.enums.dooh;

import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

@Getter
public enum DoohStrategyPointSourceEnum {
    RECOMMEND(1, "推荐点位", "recommend"),
    USER_DEFINED(2, "自定义点位","userDefined"),
    ;

    private Integer code;

    private String desc;

    private String doohCode;

    DoohStrategyPointSourceEnum(Integer code, String desc, String doohCode){
        this.code = code;
        this.desc = desc;
        this.doohCode = doohCode;
    }

    public static DoohStrategyPointSourceEnum getPointSourceByDooh(String doohCode){
        if(StringUtils.isEmpty(doohCode)){
            return null;
        }
        for(DoohStrategyPointSourceEnum pointSourceEnum : DoohStrategyPointSourceEnum.values()){
            if(pointSourceEnum.getDoohCode().equals(doohCode)){
                return pointSourceEnum;
            }
        }
        return null;
    }

    public static String getDoohPointSource(Integer code){
        if(code == null){
            return null;
        }
        for(DoohStrategyPointSourceEnum pointSourceEnum : DoohStrategyPointSourceEnum.values()){
            if(pointSourceEnum.getCode().equals(code)){
                return pointSourceEnum.getDoohCode();
            }
        }
        return null;
    }
}
