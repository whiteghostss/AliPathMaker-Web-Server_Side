package com.taobao.ad.brand.bp.client.dto.resourcepackage;

import java.util.List;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import lombok.Data;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/03/03
 */
@Data
public class ResourcePackageCastTypeOptionViewDTO extends BaseViewDTO {
    /**
     * 投放方式 PDB/PD
     */
    private List<CommonViewDTO> pdbPdList;

    /**
     * 推送比
     */
    private List<CommonViewDTO> returnRatioList;

    /**
     * PD类型
     */
    private List<CommonViewDTO> pdTypeList;
}
