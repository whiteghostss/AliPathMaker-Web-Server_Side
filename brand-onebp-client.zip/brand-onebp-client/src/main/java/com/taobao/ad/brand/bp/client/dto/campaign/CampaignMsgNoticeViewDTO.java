package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.List;

@Data
public class CampaignMsgNoticeViewDTO extends BaseViewDTO {

    private Long memberId;

    private String memberName;

    /**
     * 对客展示名称
     */
    private String memberDisplayName;

    private String customerName;

    private Long customerTemplateId;

    private String customerTemplateName;

    private Long saleProjectId;

    private String saleProjectName;

    private Long campaignGroupId;

    private String campaignGroupName;

    private Long campaignId;

    private String campaignName;

    private String budget;

    private String productLine;

    private String productNames;

    private String campaignGroupStartTime;

    private String campaignGroupEndTime;

    private String sales;

    private String channelSales;

    private String directSales;

    private String pe;

    private String gm;

    private String status;

    private List<CampaignSaleGroupMsgNoticeViewDTO> saleGroupList;

    private List<CampaignMsgNoticeViewDTO> warningCampaignGroupList;

    private String releaseTime;

    private Integer warningCampaignCount;

    private String cdnUrl;

    /**
     * ssp对客产品名称
     */
    private String customerOrientedProductName;
    /**
     * ssp对客媒体名称
     */
    private String customerOrientedMediaName;

    private String bottomDateStr;
}
