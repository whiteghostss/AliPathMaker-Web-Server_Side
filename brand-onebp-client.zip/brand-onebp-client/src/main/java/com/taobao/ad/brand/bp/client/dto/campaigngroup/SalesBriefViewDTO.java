package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.SalesBriefEventEnum;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.SalesBriefStateEnum;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author yanjingang
 * @date 2023/3/10
 */
@Data
public class SalesBriefViewDTO extends BaseViewDTO {

    /**
     * Brief状态变更消息体属性
     */
    private Long briefId;

    /**
     * Brief状态
     * Brief状态变更消息体属性
     * @see SalesBriefStateEnum
     */
    private Integer status;

    /**
     * 合同ID，双向绑定
     * Brief状态变更消息体属性
     */
    private Long contractId;

    /**
     * 合同状态
     * Brief状态变更消息体属性
     */
    private Integer contractStatus;

    /**
     * Brief状态变更消息体属性
     * @see SalesBriefEventEnum
     */
    private Integer eventCode;

    /**
     * brief名称
     */
    private String name;

    /**
     * 项目ID
     */
    private Long projectId;


    /**
     * 订单ID，双向绑定
     */
    private Long orderId;


    /**
     * 投放账号ID，可能是客户投放账号，也可能是代理虚拟投放账号
     */
    private Long memberId;

    /**
     * 折前金额，单位分
     */
    private Long totalAmount;

    /**
     * 折后最终金额，单位分
     */
    private Long discountAmount;

    /**
     * 实结前原定金额，单位分
     */
    private Long originalAmount;

    /**
     * 意向投放开始日期
     */
    private Date startDate;

    /**
     * 意向投放结束日期
     */
    private Date endDate;

    /**
     * 子合同映射关系
     */
    private List<CampaignGroupSubContractViewDTO> subContractViewDTOList;

    /**
     * 分组List
     */
    private List<SalesBriefSaleGroupViewDTO> saleGroupList;

    /**
     * brief发起人工号
     */
    private String creator;
}
