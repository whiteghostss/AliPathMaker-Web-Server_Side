package com.taobao.ad.brand.bp.client.api.creative;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.taobao.ad.brand.bp.client.dto.qualification.QualificationViewDTO;

import java.util.List;

public interface BizQualificationQueryService extends QueryAPI {
    String TAG = "Qualification";

    @ProcessEntrance(name = "资质一级类型列表查询", desc = "分页列表查询", opType = OpType.query, tag = TAG)
    MultiResponse<String> findQualificationTypeList();
}
