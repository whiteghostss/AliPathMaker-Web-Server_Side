package com.taobao.ad.brand.bp.client.dto.report;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 数据指标对象
 * @author yuncheng.lyc
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReportMetricsConfigViewDTO extends BaseViewDTO {
    /**
     * 所属功能信息
     */
    private ReportFunctionConfigViewDTO function;
    /**
     * 所属维度信息
     */
    private ReportDimensionConfigViewDTO dimension;
    /**
     * 指标字段
     */
    private String code;
    /**
     * 指标名称
     */
    private String name;
    /**
     * 字段描述
     */
    private String description;
    /**
     * 分组
     */
    private String group;

    /**
     * 分组
     * @see ReportMetricsTypeEnum
     */
    private String type;

    /**
     * 字段格式
     */
    private String format;
    /**
     * 关联的字段code，用于通过实体翻译实体其他属性
     */
    private String relationCode;
    /**
     * 不合法值
     */
    private List<String> illegalValues;
    /**
     * 默认值
     */
    private Object defaultValue;
    /**
     * 内存计算的第一个指标的key
     */
    private String firstMetricsKey;
    /**
     * 内存计算的第二个指标的key
     */
    private String secondMetricsKey;
    /**
     * 内存计算的计算规则
     */
    private String flag;
    /**
     * 前端指标格式
     */
    private String webFormat;
    /**
     * 前端是否支持排序
     */
    private String supportOrder;
}
