package com.taobao.ad.brand.bp.client.dto.resourcepackage.query;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author yanjingang
 * @date 2023/3/13
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ResourcePackageQueryOption {
    private Boolean needSetting = Boolean.TRUE;

    private Boolean needProduct = Boolean.TRUE;

    private Boolean needInquiryPriority = Boolean.TRUE;
}
