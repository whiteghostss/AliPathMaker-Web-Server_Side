package com.taobao.ad.brand.bp.client.enums.common;

import lombok.Getter;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * 异步任务类型
 */
@Getter
public enum BizTaskFunctionEnum {

    ADGROUP_BATCH_MONITOR_UPDATE("adgroupBatchMonitorUpdate", "单元批量导入监测代码"),

    ;

    BizTaskFunctionEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    private static final Map<String, BizTaskFunctionEnum> MAP;

    static {
        MAP = Arrays.stream(values()).collect(Collectors.toMap(BizTaskFunctionEnum::getCode, Function.identity()));
    }

    private String code;
    private String desc;

}
