package com.taobao.ad.brand.bp.client.api.shopwindow;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.CommandAPI;
import com.alibaba.hermes.framework.dto.response.Response;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandShopWindowTjmSubscribeViewDTO;

import java.util.List;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/6/26
 **/
public interface BizBrandSpuCommandService extends CommandAPI {

    String TAG = "BrandSpu";

    /**
     * 0元试用小组件调用淘积木服务生成订阅关系
     * @param serviceContext
     * @param subscribeViewDTO
     * @return
     */
    @ProcessEntrance(name = "0元试用淘积木小组件订阅", desc = "0元试用淘积木小组件订阅", opType = OpType.update, tag = TAG)
    Response freeTrailApply(ServiceContext serviceContext, BrandShopWindowTjmSubscribeViewDTO subscribeViewDTO);

    /**
     * 0元试用淘积木小组件订阅信息通知
     * @param serviceContext
     * @param subscribeViewDTOList
     * @return
     */
    @ProcessEntrance(name = "0元试用淘积木小组件订阅信息通知", desc = "0元试用淘积木小组件订阅信息通知", opType = OpType.update, tag = TAG)
    Response freeTrailNotify(ServiceContext serviceContext, List<BrandShopWindowTjmSubscribeViewDTO> subscribeViewDTOList);
}
