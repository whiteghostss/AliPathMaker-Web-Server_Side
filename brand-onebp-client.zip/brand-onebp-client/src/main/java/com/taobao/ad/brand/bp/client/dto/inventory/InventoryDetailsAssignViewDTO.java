package com.taobao.ad.brand.bp.client.dto.inventory;

import com.alibaba.abf.governance.dto.BaseViewDTO;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author yanjingang
 * @date 2025/3/12
 */
@Data
public class InventoryDetailsAssignViewDTO extends BaseViewDTO {

    /**
     * 库存供应明细主键ID
     */
    private Long supplyId;

    /**
     * 预占订单ID，预占库存场景必填
     */
    private Long reserveOrderId;

    /**
     * @see com.alimama.inventory.dto.ud.InventoryUdBaseDTO.SellType
     */
    private Integer sellType;

    /**
     * 预占组ID，预占库存场景必填
     */
    private Long reserveGroupId;

    /**
     * 确认库存采购订单id
     */
    private Long confirmOrderId;

    /**
     * 确认库存采购单行id
     */
    private Long confirmRowId;

    /**
     * 预占库存过期时间
     */
    private Date expireTime;

    /**
     * 预占库存是否过期
     */
    private Boolean reserveExpired;

    /**
     * 媒体订单ID或者创意ID集合，确认库存场景必填，逗号分隔
     */
    private String confirmDealIds;

    /**
     * 已分配库存量
     */
    private Integer assignCpmAmount;

    /**
     * 已确认库存量
     */
    private Integer confirmCpmAmount;

    /**
     * 待购买库存量，如果大于0且预占库存未过期业务侧需要发起流量采购(单位与supplySellType类型保持一致)
     */
    private Integer toBuyAmount;

}
