package com.taobao.ad.brand.bp.client.dto.resourcepackage;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;

import lombok.Data;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/06/20
 */
@Data
@Deprecated
public class ResourcePackageUnitPriceViewDTO extends BaseViewDTO {

    /**
     * 指标单位
     */
    private Integer metricUnit;

    /**
     * 总售卖量
     */
    private Long totalAmount;

    /**
     * 分组均价
     */
    private Long averagePrice;

    /**
     * 总售卖量折扣
     */
    private Integer amountDiscount;

    /**
     * 面客分组总量
     */
    private Long customerTotalAmount;

    /**
     * 面客分组均价
     */
    private Long customerAveragePrice;

    /**
     * 面客展示开关
     * 1-开
     * 0-关
     */
    private Integer customerSwitch;

}
