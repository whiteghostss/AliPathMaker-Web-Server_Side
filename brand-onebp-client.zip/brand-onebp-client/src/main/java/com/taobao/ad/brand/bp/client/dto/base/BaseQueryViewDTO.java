package com.taobao.ad.brand.bp.client.dto.base;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BaseQueryViewDTO extends BaseViewDTO {


    /**
     * 页码,从1开始
     */
    private int pageNo = 1;
    /**
     * 分页时，一页条数
     */
    private int pageSize = 20;
    /**
     * 从数据库中检索开始条数
     */
    private int start;
    /**
     * 总页数
     */
    private int totalPageNo;
    /**
     * 总条数
     */
    private int pageCount;

    public BaseQueryViewDTO(int pageNo, int pageSize){
        this.pageNo = pageNo;
        this.pageSize = pageSize;
    }


    public int getPageSize() {
        return pageSize;
    }
    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }
    public int getStart() {
        int start = pageSize*pageNo - pageSize;
        if(start>0){
            return start;
        }else {
            return 0;
        }
    }
    public void setStart(int start) {
        this.start = start;
    }
    public int getTotalPageNo() {
        if(pageCount > 0){
            return (int)Math.ceil((double)pageCount/pageSize);
        }
        return 0;
    }
    public void setTotalPageNo(int totalPageNo) {

        this.totalPageNo = totalPageNo;
    }
    public int getPageCount() {
        return pageCount;
    }
    public void setPageCount(int pageCount) {
        this.pageCount = pageCount;
    }
    public int getPageNo() {
        return pageNo;
    }
    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }

}