package com.taobao.ad.brand.bp.client.dto.adgroup;

import com.taobao.ad.brand.bp.client.dto.tool.BatchImportParamViewDTO;
import lombok.Data;

import java.util.List;

/**
 * 单元批量导出从Excel中解析到的原始信息
 *
 * @author gxg
 */
@Data
public class AdgroupBatchImportParamViewDTO extends BatchImportParamViewDTO {
    /**
     * 订单id
     */
    private Long campaignGroupId;

    /**
     * 批量单元信息
     */
    private List<AdgroupBatchImportRawViewDTO> adgroupBatchImportRawViewDTOS;
}
