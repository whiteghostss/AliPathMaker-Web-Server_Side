package com.taobao.ad.brand.bp.client.dto.creative;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/3/16 13:10
 * @description ：
 * @modified By：
 */
@Data
public class CreativeMalusTemplateLandingPageElementViewDTO extends BaseViewDTO {
    private String url;
    private String liveId;
    private String itemId;
    private String shopId;
}
