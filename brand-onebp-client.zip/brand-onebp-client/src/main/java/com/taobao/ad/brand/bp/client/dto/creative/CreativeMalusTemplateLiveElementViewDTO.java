package com.taobao.ad.brand.bp.client.dto.creative;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/3/16 13:10
 * @description ：
 * @modified By：
 */
@Data
public class CreativeMalusTemplateLiveElementViewDTO extends BaseViewDTO {
    private String url;
    /**
     * 直播id
     */
    private Long liveId;
    /**
     * sellerId
     */
    private Long sellerId;
}
