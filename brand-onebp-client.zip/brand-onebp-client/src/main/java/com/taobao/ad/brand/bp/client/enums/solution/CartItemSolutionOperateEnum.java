package com.taobao.ad.brand.bp.client.enums.solution;


import lombok.Getter;

import java.util.Arrays;
import java.util.Optional;

/**
 * 解决方案细化操作
 */
@Getter
public enum CartItemSolutionOperateEnum {
    SLIM_SAVE(1,"极简化保存"),
    CAMPAIGN_SAVE(2,"计划保存"),
    ADGROUP_SAVE(3,"单元保存"),
    ;

    private Integer code;
    private String desc;

    CartItemSolutionOperateEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public static CartItemSolutionOperateEnum getOperateEnumByCode(Integer code){
        if(code == null){
            return null;
        }
        CartItemSolutionOperateEnum operateEnum = Arrays.stream(CartItemSolutionOperateEnum.values())
                .filter(cartItemSolutionOperateEnum -> cartItemSolutionOperateEnum.getCode().equals(code)).findFirst().orElse(null);
        return operateEnum;
    }
}
