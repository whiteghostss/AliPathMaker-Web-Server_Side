package com.taobao.ad.brand.bp.client.dto.insight;

import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.base.BaseQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.insight.WinInsightBenchMarkTypeEnum;
import com.taobao.ad.brand.bp.client.enums.report.ReportTotalTypeEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

/**
 * 查询数据对象
 * @author yuncheng.lyc
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class WinInsightQueryViewDTO extends BaseQueryViewDTO {
    private static final long serialVersionUID = -6328232249563104954L;
    /**
     * 开始时间
     */
    private String startTime;

    /**
     * 结束时间
     */
    private String endTime;

    /**
     * 品牌Id
     */
    private Long brandId;

    /**
     * 子行业Id
     */
    @Deprecated
    private Long industryId;

    /**
     * 赛道Id
     */
    private Long topicId;

    /**
     * 对比基准类型
     * @see WinInsightBenchMarkTypeEnum
     */
    private Integer benchmarkType;

    /**
     * 分天或汇总
     * @see ReportTotalTypeEnum
     */
    private Integer totalType;

    /**
     * 维度
     * @see public enum WinInsightDimenisonTypeEnum
     */
    private String dimension;

    /**
     * 选定指标
     */
    private String customIndex;

    /**
     * 价格带左边界
     */
    private Double startPrice;

    /**
     * 价格带右边界
     */
    private Double endPrice;

    /**
     * 一级类目id
     */
    private Long cateLevelOneId;

    /**
     * 二级类目id
     */
    private Long cateLevelTwoId;

    /**
     * 叶子类目id
     */
    private Long cateLevelLeafId;

    public List<String> getCustomIndexList() {
        if(StringUtils.isEmpty(customIndex)) {
            return Lists.newArrayList();
        }
        return Lists.newArrayList(customIndex.split(","));
    }
}
