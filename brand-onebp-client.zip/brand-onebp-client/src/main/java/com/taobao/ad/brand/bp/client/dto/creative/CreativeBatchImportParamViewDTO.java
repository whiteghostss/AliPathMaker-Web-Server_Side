package com.taobao.ad.brand.bp.client.dto.creative;

import com.taobao.ad.brand.bp.client.dto.tool.BatchImportParamViewDTO;
import lombok.Data;

import java.util.List;

/**
 * 创意批量导入从Excel中解析到的原始信息
 * @author jixiu.lj
 * @date 2023/8/31 20:01
 */
@Data
public class CreativeBatchImportParamViewDTO extends BatchImportParamViewDTO {
    /**
     * 订单id
     */
    private Long campaignGroupId;
    /**
     * 计划id
     */
    private Long campaignId;
    /**
     * 单元id
     */
    private Long adgroupId;
    /**
     * 批量创意信息
     */
    private List<CreativeBatchImportRawViewDTO> creativeBatchImportRawViewDTOList;
}
