package com.taobao.ad.brand.bp.client.dto.creative;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.creative.materialgroup.MaterialBleedingViewDTO;
import lombok.Data;

import java.util.List;

/**
 * 海棠文件元素
 * @author ：PhilipFry
 * @date ：Created in 2023/3/16 13:10
 * @description ：
 * @modified By：
 */
@Data
public class CreativeMalusTemplateFileElementViewDTO extends BaseViewDTO {
    private String key;
    private String url;
    private Integer width;
    private Integer height;
    private Long fileSize;
    /**
     * mrId
     */
    private Long mrId;

    private Integer duration;
    private Long bitrate;

    /**
     * 出血区
     */
    private MaterialBleedingViewDTO bleeding;
    /**
     * 拓版子图
     */
    private List<CreativeMalusTemplateFileElementViewDTO> extendImages;
}
