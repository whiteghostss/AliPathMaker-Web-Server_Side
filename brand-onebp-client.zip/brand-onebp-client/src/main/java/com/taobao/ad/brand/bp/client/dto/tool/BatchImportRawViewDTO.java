package com.taobao.ad.brand.bp.client.dto.tool;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.ErrorMessageDTO;
import lombok.Data;

/**
 * 批量导入每行原始信息
 * @author shiyan
 * @date 2024/7/8 20:01
 */
@Data
public class BatchImportRawViewDTO extends BaseViewDTO {
    private ErrorMessageDTO errorMessage;
    private Boolean isFiltered;
}
