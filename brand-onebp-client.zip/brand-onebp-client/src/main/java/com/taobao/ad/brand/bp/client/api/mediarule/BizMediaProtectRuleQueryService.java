package com.taobao.ad.brand.bp.client.api.mediarule;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.media.protect.MediaProtectRuleViewDTO;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.mediarule.query.MediaProtectRuleQueryViewDTO;

/**
 * 保护规则查询服务类
 *
 * @author denglinhua
 * @date 2023-07-11
 */
public interface BizMediaProtectRuleQueryService extends QueryAPI {
    String TAG = "MediaProtectRule";

    /**
     * 分页查询保护规则
     *
     * @param serviceContext
     * @param queryDTO
     * @return
     */
    MultiResponse<MediaProtectRuleViewDTO> findProtectList(ServiceContext serviceContext, MediaProtectRuleQueryViewDTO queryDTO);

    /**
     * 保护规则详情查询
     *
     * @param serviceContext 必须提供memberId字段
     * @param protectId     互斥id
     */
    SingleResponse<MediaProtectRuleViewDTO> getProtectRule(ServiceContext serviceContext, Long protectId);

}
