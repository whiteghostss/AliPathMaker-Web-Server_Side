package com.taobao.ad.brand.bp.client.api.priceengine;


import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.campaign.PriceEnginePublishPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;

import java.util.Date;
import java.util.List;
import java.util.Map;

public interface PriceEngineQueryService extends QueryAPI {

    String TAG = "PriceEngine";

    @ProcessEntrance(name = "产品加收价格", desc = "产品加收价格", opType = OpType.query, tag = TAG)
    public MultiResponse<PriceEnginePublishPriceViewDTO> getPublishPriceByProduct(Long publicationProductId, Integer saleUnit, List<Integer> resourceTypeValueList, Date startDate, Date endDate);

    @ProcessEntrance(name = "获取产品加收价格", desc = "获取产品加收价格", opType = OpType.query, tag = TAG)
    public SingleResponse<Map<String, Map<String, ResourcePackageProductPriceViewDTO>>> getProductBandPriceList(List<ResourcePackageProductViewDTO> resourcePackageProductList, Map<Long, ProductViewDTO> sspProductMap);

    }
