package com.taobao.ad.brand.bp.client.api.campaigngroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.alibaba.hermes.framework.api.CommandAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.*;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.calculate.CampaignGroupSaleGroupCalViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.CampaignGroupSaleGroupEstimateQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.settle.CampaignGroupRealSettleSaveViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupEventEnum;

import java.util.List;

/**
 * CampaignGroup
 *
 * @author yanjingang
 * @date 2023/2/28
 */
public interface BizCampaignGroupCommandService extends CommandAPI {

    String TAG = "CampaignGroup";

    /**
     *
     * 新建CampaignGroup For销售订单
     * 仅支持新增主订单
     *
     * @param context
     * @param campaignGroupViewDTO
     * @return campaignGroupId
     */
    @ProcessEntrance(name = "新建CampaignGroupFor销售订单", desc = "新建CampaignGroupFor销售订单", opType = OpType.add, tag = TAG)
    SingleResponse<Long> addCampaignGroupForSale(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO);

    /**
     *
     * 新建CampaignGroup(暂无调用方)
     * 仅支持新增主订单
     *
     * @param context
     * @param campaignGroupViewDTO
     * @return campaignGroupId
     */
    @ProcessEntrance(name = "新建CampaignGroup", desc = "新建CampaignGroup", opType = OpType.add, tag = TAG)
    SingleResponse<Long> addCampaignGroup(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO);

    /**
     * 部分更新CampaignGroup For 销售订单(主订单)
     *
     * @param context
     * @param campaignGroupViewDTO
     * @return
     */
    @ProcessEntrance(name = "部分更新CampaignGroupFor销售订单", desc = "部分更新CampaignGroupFor销售订单", opType = OpType.update, tag = TAG)
    SingleResponse<Integer> updateCampaignGroupPartForSale(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO);

    /**
     * 更新部分CampaignGroup
     *
     * @param context
     * @param campaignGroupViewDTO
     * @return
     */
    @ProcessEntrance(name = "部分更新CampaignGroup", desc = "部分更新CampaignGroup", opType = OpType.update, tag = TAG)
    SingleResponse<Integer> updateCampaignGroupPart(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO);

    /**
     * 禁止调用
     *
     * @param context
     * @param id
     * @param eventEnum
     * @return
     */
    @ProcessEntrance(name = "CampaignGroup状态流转ById", desc = "CampaignGroup状态迁移", opType = OpType.update, tag = TAG)
    SingleResponse<BrandCampaignGroupStatusEnum> transit(ServiceContext context, Long id, CampaignGroupEventEnum eventEnum);

    /**
     * 自助营销订单【下单Step1】下单分2步
     * 1. 执行PRE_ORDER：通知售卖中心去创建Brief、客户模板、客户分组
     * 2. 执行ORDER，同步订单信息至Brief，同时生成合同
     *
     * @param context
     * @param campaignGroupOrderCommandViewDTO
     * @return
     */
    @ProcessEntrance(name = "CampaignGroup预下单", desc = "CampaignGroup预下单", opType = OpType.update, tag = TAG)
    Response preOrder(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO);

    /**
     * 销售子订单
     * 
     * 交付指标若全部不对客展示，则需要后台自动预估
     * @param context
     * @param campaignGroupOrderCommandViewDTO
     * @return
     */
    @ProcessEntrance(name = "CampaignGroup下单", desc = "CampaignGroup下单", opType = OpType.update, tag = TAG)
    Response order(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO);

    /**
     * 子订单
     *
     * @param context
     * @param campaignGroupOrderCommandViewDTO
     * @return
     */
    @ProcessEntrance(name = "申请修改", desc = "申请修改", opType = OpType.update, tag = TAG)
    Response applyModify(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO);

    /**
     * 自助链路发起撤单（页面发起，针对子订单）
     * @param context
     * @param id
     * @return
     */
    @ProcessEntrance(name = "申请撤单", desc = "申请撤单", opType = OpType.update, tag = TAG)
    Response cancel(ServiceContext context, Long id);

    /**
     * 子订单
     *
     * @param context
     * @param id
     * @return
     */
    @ProcessEntrance(name = "完成订单", desc = "完成订单", opType = OpType.update, tag = TAG)
    Response finish(ServiceContext context, Long id);

    /**
     * 子订单
     *
     * @param context
     * @param id
     * @return
     */
    @ProcessEntrance(name = "完成撤回", desc = "完成撤回", opType = OpType.update, tag = TAG)
    Response finishRevert(ServiceContext context, Long id);

    /**
     * 自助子订单
     *
     * @param context
     * @param id
     * @return
     */
    @ProcessEntrance(name = "结案", desc = "结案", opType = OpType.update, tag = TAG)
    Response complete(ServiceContext context, Long id);

    /**
     * 子订单
     *
     * @param context
     * @param campaignGroupRealSettleSaveViewDTO
     * @return
     */
    @ProcessEntrance(name = "保存实结配置信息", desc = "保存实结配置信息", opType = OpType.update, tag = TAG)
    Response saveRealSettleInfo(ServiceContext context, CampaignGroupRealSettleSaveViewDTO campaignGroupRealSettleSaveViewDTO);

    /**
     * 子订单
     *
     * @param processCode
     * @param procInstId
     * @param id
     * @param result
     * @param extInfo
     * @return
     */
    @ProcessEntrance(name = "审核流程回调", desc = "审核流程回调", opType = OpType.update, tag = TAG)
    Response processFinishCallback(String processCode, String procInstId, Long id, Integer result, String extInfo);

    /**
     * 子订单
     *
     * @param context
     * @param calViewDTO
     * @return
     */
    @ProcessEntrance(name = "订单分组计算", desc = "订单分组计算", opType = OpType.update, tag = TAG)
    SingleResponse<CampaignGroupSaleGroupCalViewDTO> calculate(ServiceContext context, CampaignGroupSaleGroupCalViewDTO calViewDTO);

    /**
     * 子订单
     *
     * @param context
     * @param campaignGroupCheckedResourceViewDTO
     * @return
     */
    @ProcessEntrance(name = "保存用户勾选资源", desc = "保存用户勾选资源", opType = OpType.update, tag = TAG)
    Response updateCheckedResources(ServiceContext context, CampaignGroupCheckedResourceViewDTO campaignGroupCheckedResourceViewDTO);

    /**
     * 子订单
     *
     * @param context
     * @param id
     * @return
     */
    @ProcessEntrance(name = "发起采购单", desc = "发起采购单", opType = OpType.update, tag = TAG)
    Response addPurchaseOrder(ServiceContext context, Long id);

    /**
     * 子订单
     *
     * @param context
     * @param id
     * @return
     */
    @ProcessEntrance(name = "更新CampaignGroup采购状态", desc = "更新CampaignGroup采购状态", opType = OpType.update, tag = TAG)
    Response updateCampaignGroupPurchaseStatus(ServiceContext context, Long id);

    /**
     * 子订单
     *
     * @param context
     * @param cancelViewDTO
     * @return
     */
    @ProcessEntrance(name = "定时任务-CampaignGroup自动撤单/预警", desc = "定时任务-CampaignGroup自动撤单/预警", opType = OpType.update, tag = TAG)
    Response autoCancelCampaignGroup(ServiceContext context, CampaignGroupCancelCommandViewDTO cancelViewDTO);

    /**
     * 子订单
     *
     * @param context
     * @param campaignGroupViewDTO
     * @return
     */
    @ProcessEntrance(name = "更新CampaignGroup采购单询量单", desc = "更新CampaignGroup采购单询量单", opType = OpType.update, tag = TAG)
    SingleResponse<Integer> updateCampaignGroupOrders(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO);

    /**
     * 物理删除
     * @param context
     * @param id
     * @return
     */
    SingleResponse<Integer> physicalDeleteCampaignGroup(ServiceContext context, Long id, boolean needDeleteTree);

    @ProcessEntrance(name = "交付或者成效预估", desc = "交付或者成效预估", opType = OpType.add, tag = TAG)
    MultiResponse<CampaignGroupSaleGroupEstimateInfoViewDTO> estimateSaleGroup(ServiceContext context, CampaignGroupSaleGroupEstimateQueryViewDTO campaignGroupSaleGroupEstimateQueryViewDTO);

    /**
     * @param context
     * @param campaignGroupSaleGroupGoalSettingViewDTO
     * @return
     */
    @ProcessEntrance(name = "更新分组优化设置信息", desc = "更新分组优化设置信息", opType = OpType.update, tag = TAG)
    SingleResponse<Integer> updateSaleGroupGoalSetting(ServiceContext context, CampaignGroupSaleGroupGoalSettingViewDTO campaignGroupSaleGroupGoalSettingViewDTO);
    /**
     * @param context
     * @param campaignGroupSaleGroupCrowdViewDTO
     * @return
     */
    @ProcessEntrance(name = "更新分组人群", desc = "更新分组人群", opType = OpType.update, tag = TAG)
    SingleResponse<Integer> updateSaleGroupCrowdIds(ServiceContext context, CampaignGroupSaleGroupCrowdViewDTO campaignGroupSaleGroupCrowdViewDTO) ;

    /**
     *
     * @param context 上下文
     * @param campaignGroupSaleGroupPageViewDTOS 监测信息
     * @return 结果
     */
    @ProcessEntrance(name = "更新分组监测信息", desc = "更新分组监测信息", opType = OpType.update, tag = TAG)
    Response updateCampaignGroupSaleGroupThirdMonitor(ServiceContext context, Long campaignGroupId, List<CampaignGroupSaleGroupPageViewDTO> campaignGroupSaleGroupPageViewDTOS);

    @ProcessEntrance(name = "更新订单配送及补量状态", desc = "更新订单配送及补量状态", opType = OpType.update, tag = TAG)
    Response updateCampaignGroupGiveAndBoostStatus(ServiceContext context, Long id);

    /**
     * 更新campaignGroup的派单状态
     * @param context - 上下文
     * @param id - 订单id
     * @param assignOrderStatus - 派单状态
     * @return
     */
    @ProcessEntrance(name = "更新CampaignGroup派单状态", desc = "更新CampaignGroup派单状态", opType = OpType.update, tag = TAG)
    Response updateCampaignGroupAssignOrderStatus(ServiceContext context, Long id, Integer assignOrderStatus);

    /**
     * 删除订单
     * @param context--上下文
     * @param id--主订单/子订单ID
     * @return
     */
    @ProcessEntrance(name = "删除订单", desc = "删除订单", opType = OpType.delete, tag = TAG)
    Response deleteCampaignGroupById(ServiceContext context, Long id);

    /**
     * @param context
     * @param campaignGroupViewDTO 子订单
     * @return
     */
    @ProcessEntrance(name = "保存结案回流账号配置信息", desc = "保存结案回流账号配置信息", opType = OpType.update, tag = TAG)
    Response saveCompleteInfo(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO);
}
