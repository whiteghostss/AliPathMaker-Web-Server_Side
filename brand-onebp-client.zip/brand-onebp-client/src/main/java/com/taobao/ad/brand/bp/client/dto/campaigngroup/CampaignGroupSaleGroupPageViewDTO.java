package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignProductConfigTypeEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSaleOrderStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleGroupBudgetSettingTypeEnum;

import com.taobao.ad.brand.bp.client.dto.monitor.MonitorInfoDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupAuditViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.SaleGroupGoalSceneEnum;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/03/02
 */
@Data
public class CampaignGroupSaleGroupPageViewDTO extends BaseViewDTO {
    /**
     * 资源分组ID
     */
    private Long saleGroupId;
    /**
     * 主分组id(补、配分组才有该id)
     */
    private Long mainGroupId;
    /**
     * 资源分组名称
     */
    private String saleGroupName;
    /**
     * 开始时间
     */
    private Date startTime;
    /**
     * 结束时间
     */
    private Date endTime;
    /**
     * 资源包类型名称:智选、标准
     * @see BrandCampaignProductConfigTypeEnum
     */
    private Integer productConfigType;
    /**
     * 是否能编辑分组（该字段具体用来控制分组下是否可以新建计划、导入计划、保存指标设置、成效预估、人群推荐策略等）
     * @see com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum
     */
    private Integer canEdit;

    /**
     * 是否能编辑分组申请信息（补量配送申请的基础信息的编辑）
     */
    private Integer canEditSaleGroupApply;

    /**
     * 分组审核状态，1-未生效，2-生效，99-已作废
     */
    private Integer saleGroupStatus;
    /**
     * 流程审核信息
     */
    private ResourcePackageSaleGroupAuditViewDTO processAuditInfo;
    /**
     * 售卖类型,1-购买，2-补量，3-配送
     * @see com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum
     */
    private Integer saleType;

    /**
     * 是否可以选择分组
     * @see com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum
     */
    private Integer canSelect;

    /**
     * 是否支持下载申请信息，1-是，0-否
     * @see com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum
     */
    private Integer canDownloadApplyInfo;

    /**
     * 是否支持删除，1-是，0-否
     * @see com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum
     */
    private Integer canDelete;

    /**
     * 支持勾选/不支持勾选的原因类型
     * @see com.taobao.ad.brand.bp.client.enums.campaigngroup.SaleGroupSelectReasonTypeEnum
     */
    private Integer selectReasonType;

    /**
     * 售卖分组来源
     * @see com.alibaba.ad.brand.sdk.constant.common.BrandSaleGroupSourceEnum
     */
    private Integer source;
    /**
     * 计算后的预算
     */
    private Long calcBudget;
    /**
     * 预算
     */
    private Long budget;
    /**
     * 预算设置类型：1-按比例设置，2-按金额设置
     * @see BrandSaleGroupBudgetSettingTypeEnum
     */
    private Integer budgetSettingType;
    /**
     * 售卖产品线
     *
     */
    private Integer saleProductLine;
    /**
     * 单价
     */
    private Long unitPrice;
    /**
     * 预定曝光量
     */
    private Long amount;
    /**
     * 是否分组有更新，1-是，0-否
     */
    private Integer hasUpdate;
    /**
     * 是否有补量的分组,1-是，0-否
     */
    private Integer isReplenish;
    /**
     * 是否可以补量,1-是，0-否
     */
    private Integer canReplenish;
    /**
     * 是否有配送的分组,1-是，0-否
     */
    private Integer isDistribution;
    /**
     * 是否可以配送,1-是，0-否
     */
    private Integer canDistribution;

    /**
     * 产品分配规则列表
     */
    private List<CampaignGroupDistributionRuleViewDTO> distributionRuleList;
    /* 交付目标优化指标相关 start */
    /**
     * 资源包设置的交付指标
     * */
    private List<CampaignSaleGroupResourceDeliveryTargetViewDTO> resourceDeliveryTargetList;
    /**
     * BP设置的交付指标
     * */
    private List<CampaignSaleGroupDeliveryTargetViewDTO> deliveryTargetList;
    /**
     * 资源包设置信息
     * */
    private List<CampaignSaleGroupResourceOptimizeTargetViewDTO> resourceOptimizeTargetList;
    /**
     * bp选择值优化指标
     * */
    private List<Integer> optimizeTargetIdList;

    /**
     * 人群信息
     * */
    private List<Long> crowdIdList;
    /**
     * 覆盖人数
     * */
    private Long coverage;

    /**
     * 优化场景
     * @see SaleGroupGoalSceneEnum
     * */
    private Integer goalScene;
    /**
     * 真实优化场景
     * @see SaleGroupGoalSceneEnum
     * */
    private Integer realGoalScene;
    /* 交付目标优化指标相关 end */
    /**
     * 预估结果
     * */
    private CampaignGroupSaleGroupEstimateInfoViewDTO estimateResult;

    /**
     * 算法预估状态
     * @see com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum
     * */
    private Integer algoEstimateStatus;

    /**
     * 诉求ID
     */
    private Long demandId;

    private Integer sspProductLineId;

    /**
     * 派单/非派单
     */
    private Integer supplyType;

    /**
     * 监测链接配置粒度
     * 分组/计划/单元
     *
     * @see com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupMonitorDimensionEnum
     */
    private Integer monitorDimension;

    /**
     * 第三方监测类型
     */
    private List<Integer> nonAliInspectTypeList;

    /**
     * 是否支持分端监测
     * 是/否
     */
    private Integer splitConfig;

    /**
     * 第三方监测信息
     */
    private List<MonitorInfoDTO> monitors;
    /**
     * 售卖分组下单状态
     * @see BrandCampaignGroupSaleOrderStatusEnum
     */
    private Integer orderStatus;

    /**
     * 所属售卖产品
     * 从资源包实时获取
     *
     */
    private Integer productCategory;

    /**
     * 分组首次下单时间
     */
    private Date firstOrderTime;

    /**
     * 配送分组业务类型
     * @see com.alibaba.ad.brand.sdk.constant.salegroup.field.SaleGroupDistributionTypeEnum
     */
    private Integer distributionType;
}
