package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

/**
 * 资源包产品配置
 * @date: 2023/3/4 11:06
 * @author: yuanxinxi
 * @version: 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BizPackageProductPriceViewDTO extends BaseViewDTO {
    /**
     * 净总价
     */
    private Long discountTotalMoney;
    /**
     * 开始时间
     */
    private Date startDate;
    /**
     * 结束时间
     */
    private Date endDate;
    /**
     * 预算比例
     */
    private Integer budgetRatio;
//    /**
//     * 流量比例
//     */
    private Long mediaFlowRatio;


    /**
     * cpt的总预订量
     */
    private Long cptAmount;
    ///**
    // * 刊例价信息
    // */
    //private List<CampaignDayPriceViewDTO> publishPriceInfos;
    //
    ///**
    // * 折后信息
    // */
    //private List<CampaignDayPriceViewDTO> discountPriceInfos;

    /**
     * 价格信息（包含刊例价、折扣价）
     */
    private List<CampaignDayPriceViewDTO> priceInfos;
}
