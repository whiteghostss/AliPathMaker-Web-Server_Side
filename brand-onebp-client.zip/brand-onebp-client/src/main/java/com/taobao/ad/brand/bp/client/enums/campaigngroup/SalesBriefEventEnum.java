package com.taobao.ad.brand.bp.client.enums.campaigngroup;

import com.taobao.ad.brand.bp.client.enums.CommonEnum;

/**
 * @author yanjingang
 * @date 2023/3/13
 */
public enum SalesBriefEventEnum implements CommonEnum {

    /**
     * 未知
     */
    UNKNOWN(0, "未知"),

    DELETE(-1, "删除"),
    NEW(1, "新建"),
    CONFIRM_ORDER(2, "下单完毕"),
    MODIFY_ORDER(12, "修改执行单"),
    APPROVE(3, "审批完成"),
    REFUSE(13, "审批拒绝"),
    TERMINATE(14, "终止流程"),
    UNLOCK(4, "改单"),
    ROLLBACK(5, "还原"),
    EXE_COMPLETE(6, "执行完成"),
    STOP_CAST(7, "申请停投"),
    REAL_SETTLE(8, "申请实结"),
    COMPLETE(9, "结案"),
    COMPLETE_REVERT(10, "结案打回"),
    CANCEL(11, "申请撤单"),
    FINISH_REVERT(12, "完成撤回"),
    CONTRACT_STATUS_CHANGE(15, "合同状态变更")

    ;

    SalesBriefEventEnum(int value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    private int value;
    private String desc;

    @Override
    public int getValue() {
        return value;
    }

    @Override
    public String getDesc() {
        return desc;
    }

    public static boolean isContractEvent(Integer eventCode) {
        return eventCode != null && eventCode == CONTRACT_STATUS_CHANGE.value;
    }
}
