package com.taobao.ad.brand.bp.client.dto.dooh;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * 天攻策略信息
 */
@Data
public class DoohStrategyViewDTO extends BaseViewDTO {

    /**
     * 策略ID
     */
    private Long id;

    /**
     * 策略名称
     */
    private String name;

    /**
     * 策略预算，单位分
     */
    private Long budget;

    /**
     * 策略开始时间
     */
    private Date startDate;
    /**
     * 策略结束时间
     */
    private Date endDate;

    private Date gmtCreate;

    private Date gmtModified;

    /**
     * 状态
     * @see com.taobao.ad.brand.bp.client.enums.dooh.DoohStrategyStatusEnum
     */
    private Integer status;

    /**
     * 预计完成时间
     */
    private Date completeDate;

    /**
     * 最晚锁量时间
     */
    private Date lockDeadlineDate;

    /**
     * 计算失败原因
     */
    private String calculateFailedReason;

    /**
     * 点位来源列表
     */
    private List<DoohPointSourceViewDTO> pointSourceList;
}
