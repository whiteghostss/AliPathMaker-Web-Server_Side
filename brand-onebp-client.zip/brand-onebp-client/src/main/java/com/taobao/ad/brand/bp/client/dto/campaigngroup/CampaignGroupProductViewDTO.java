package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import java.util.Date;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignModelEnum;

import lombok.Data;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/03/02
 */
@Data
public class CampaignGroupProductViewDTO extends BaseViewDTO {
    /**
     * 资源包产品主键ID
     */
    private Long resourcePackageProductId;
    /**
     * 补量场景下，补量产品关联的资源包主产品id（资源包产品主键ID）
     */
    private Long mainProductId;
    /**
     * ssp产品id
     */
    private Long sspProductId;
    /**
     * ssp产品uuid
     */
    private Long sspProductUuid;
    /**
     * 资源售卖分组id
     */
    private Long saleGroupId;
    /**
     * 流量域
     */
    private Integer mediaScope;
    /**
     * 是否必选资源
     */
    private Integer isNecessary;
    /**
     * 开始时间
     */
    private Date startTime;
    /**
     * 结束时间
     */
    private Date endTime;

    /**
     * 媒体ID
     */
    private Long mediaId;
    /**
     * 媒体名称
     */
    private String mediaName;
    /**
     * 备注
     */
    private String remark;
    /**
     * 售卖单位
     */
    private Integer registerUnit;
    /**
     * 预定方式（使用该字段需注意，因为是从打包平台的castType转过来的，可能有PD/PDB这种模糊选项）
     */
    private Integer sspRegisterManner;
    /**
     * 预算
     */
    private Long budget;
    /**
     * 是否勾选，1-是，0-否
     */
    private Integer checked;
    /**
     * 产品下计划数量
     */
    private Integer campaignCount;
    /**
     * 退回率
     */
    private String returnRate;

    /**
     * 返还比（获取PDB推送比取的值）
     */
    private String returnRatio;

    /**
     * 是否允许拆分计划
     */
    private Integer allowSplitCampaign;
}
