package com.taobao.ad.brand.bp.client.dto.shopwindow;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author jixiu.lj
 * @date 2024/9/19 15:54
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class BrandSkuFreeTrailInfoViewDTO extends BaseViewDTO {

    private static final long serialVersionUID = -5015836730592641279L;
    /**
     * 0元试用场景 appId
     */
    private String appId;

    /**
     * 0元试用场景 appVersion
     */
    private String appVersion;

}
