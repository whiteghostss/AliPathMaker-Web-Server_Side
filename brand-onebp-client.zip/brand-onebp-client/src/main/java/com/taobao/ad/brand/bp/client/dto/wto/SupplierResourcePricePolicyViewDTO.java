package com.taobao.ad.brand.bp.client.dto.wto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class SupplierResourcePricePolicyViewDTO {

    private Long id;
    private Long versionId;
    private String name;
    private Long resourceId;
//    private List<ValidPeriodDTO> validPeriodList;
    private Integer sellUnit;
    private Long unitAmount;
    private Long unitCpmAmount;
    private BigDecimal publicationPrice;
    private BigDecimal discount;
    private BigDecimal originalPrice;
    private Integer auditStatus;
    private Integer createType;
    private Integer contentType;
    private Integer talentReport;
    private Long copiedOriginalVersionId;
    private String sellUnitName;
    private String auditStatusName;
    private String contentTypeName;
//    private ResourceDTO resource;
}
