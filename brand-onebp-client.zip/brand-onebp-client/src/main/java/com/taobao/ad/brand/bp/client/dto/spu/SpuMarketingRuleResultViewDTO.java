package com.taobao.ad.brand.bp.client.dto.spu;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.List;

/**
 * SPU起投门槛校验结果
 */
@Data
public class SpuMarketingRuleResultViewDTO extends BaseViewDTO {
    /**
     * 规则名称
     */
    private String ruleName;
    /**
     * 是否通过
     * BooleanEnum
     */
    private Integer isPass;
    /**
     * 不通过原因
     */
    private String reason;
    /**
     * 不通过的spuId
     */
    private List<Long> spuIdList;
}
