package com.taobao.ad.brand.bp.client.dto.shopwindow;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/6/27
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class BrandShopWindowCaseViewDTO extends BaseViewDTO {
    private String src;
    private String json;
    // @see ShopWindowTemplateShowCaseTypeEnum
    private Integer type;
}
