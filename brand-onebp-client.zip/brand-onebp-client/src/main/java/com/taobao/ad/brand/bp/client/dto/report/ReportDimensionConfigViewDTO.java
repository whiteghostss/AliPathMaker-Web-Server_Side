package com.taobao.ad.brand.bp.client.dto.report;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 查询数据维度对象
 * @author yuncheng.lyc
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReportDimensionConfigViewDTO extends BaseViewDTO {
    /**
     * 所属功能信息
     */
    private ReportFunctionConfigViewDTO function;
    /**
     * 维度字段
     */
    private String code;
    /**
     * 维度名称
     */
    private String name;
    /**
     * 字段描述
     */
    private String description;
    /**
     * 维度类型
     */
    private String dimensionType;
    /**
     * 维度对应字段id
     */
    private String dimensionIdCode;
    /**
     * 维度差乘的最大数限制
     */
    private Integer maxCartesianDimensionCount;
    /**
     * 报表中心API，优先使用参数传递中的api，再次选择维度上配置的api，最后看功能上配置的api
     */
    private String adrUniqueKey;
    /**
     * 互斥维度配置，多个逗号分隔
     */
    private String exclusionDimensions;
}
