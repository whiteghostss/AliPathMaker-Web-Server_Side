package com.taobao.ad.brand.bp.client.dto.campaign;

import com.taobao.ad.brand.bp.client.dto.base.BaseQueryViewDTO;
import lombok.*;

@Data
@SuppressWarnings("ALL")
@ToString
public class FrequencyQueryViewDTO extends BaseQueryViewDTO {
    /**
     * 计划id
     */
    private Long campaignId;

    /**
     * 父计划id
     */
    private Long sourceCampaignId;
    /**
     * 查询关键字，id/name
     */
    private String keyword;
    /**
     * 交付/优化
     * @see com.alibaba.ad.brand.sdk.constant.frequency.field.BrandFrequencyTargetEnum
     */
    private Integer frequencyTarget;
    /**
     * 频控id
     */
    private Long frequencyId;

    /**
     * 联合频控
     * @see com.alibaba.ad.brand.sdk.constant.frequency.field.BrandFrequencyUnionTypeEnum
     */
    private Integer frequencyUnionType;
}
