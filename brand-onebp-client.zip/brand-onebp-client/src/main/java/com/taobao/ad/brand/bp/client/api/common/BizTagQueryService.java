package com.taobao.ad.brand.bp.client.api.common;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.ad.brand.dto.common.TagViewDTO;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.taobao.ad.brand.bp.client.dto.tag.TagQueryViewDTO;

/**
 * @Author: PhilipFry
 * @createTime: 2024年02月27日 20:08:47
 * @Description:
 */
public interface BizTagQueryService extends QueryAPI {
    String TAG = "tag";

    /**
     * 创意标签分页列表查询
     *
     * @param context
     * @param query
     * @return
     */
    @ProcessEntrance(name = "标签分页列表查询", desc = "标签分页列表查询", opType = OpType.query, tag = TAG)
    MultiResponse<TagViewDTO> findTagPage(ServiceContext context, TagQueryViewDTO query);
}
