package com.taobao.ad.brand.bp.client.dto.cartitem;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.enums.cart.CartActionEnum;
import lombok.Data;

/**
 * 客户联系方式
 */
@Data
public class CustomerContactViewDTO extends BaseViewDTO {
    /**
     * 称呼
     */
    private String name;
    /**
     * 联系电话
     */
    private String phone;
    /**
     * email
     */
    private String email;

    /**
     * 动作：
     * @see CartActionEnum
     */
    private Integer action;
}
