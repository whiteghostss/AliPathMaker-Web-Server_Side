package com.taobao.ad.brand.bp.client.dto.demand;

import lombok.Data;

import java.util.List;

@Data
public class DemandConfirmSolutionViewDTO {
    /**
     * 订单ID
     */
    private Long id;

    /**
     * 是否接受提案：1-接受；0-拒绝
     */
    private Integer isAccept;

    /**
     * 拒绝理由
     */
    private  String refuseReason;

    /**
     * 选中分组ID列表
     */
    private List<Long> saleGroupIdList;
}
