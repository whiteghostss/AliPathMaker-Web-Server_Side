package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * @description: PriceEnginePublishPriceViewDTO
 * @date: 2023/3/4 11:06
 * @author: yuanxinxi
 * @version: 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PriceEnginePublishPriceViewDTO extends BaseViewDTO {

    /**
     * 业务ID
     * TODO 什么概念？
     * 对应到onebp是
     */
    private Long serviceId;

    /**
     * 日期
     */
    private Date date;

    /**
     * 基础定价，单位：分
     */
    private Long definePrice;

    //    /**
    //     * 加收系数
    //     * 计算方式 =（Σ（累加项）+1）*∏（累乘项）
    //     */
    //    private List<AdditionDTO> additionList;

    /**
     * 加收系数,扩大10000倍
     */
    private Integer additionRatio;

    /**
     * 折前价，单位：分
     * 基础定价*加收系数
     */
    private Long publishPrice;
}
