package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

@Data
public class CampaignSaleGroupResourceDeliveryTargetViewDTO extends BaseViewDTO {
    /**
     * 交付指标
     * com.alibaba.ad.nb.ssp.constant.newproduct.DeliveryTargetEnum
     */
    private Integer deliveryTarget;

    /**
     * 交付指标描述
     */
    private String label;

    /**
     * 数字或者比例(35.47% -> 3547)
     */
    private Integer deliveryTargetValue;

    /**
     * 指标值类型
     * @see com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupDeliveryTargetValueTypeEnum
     */
    private Integer valueType;

    /**
     * 是否对客交付
     * @see com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum
     * */
    private Integer customerSwitch;

    /**
     * 分组指标面客均价
     * 仅曝光量、点击量、到达量有
     * 单位分
     */
    private Long deliveryTargetAveragePrice;

    /**
     * 计算/参考分组总售卖量
     * 仅曝光量、点击量、到达量有
     * 是数量不是钱的概念
     */
    private Long totalAmount;
    /**
     * 折扣系数  80%存储的是8000
     * 总售卖量折扣
     * 仅曝光量、点击量、到达量有
     * */
    private Integer amountDiscount;



    /**
     * 计算/参考分组均价
     * 仅曝光量、点击量、到达量有
     */
    private Long averagePrice;


}
