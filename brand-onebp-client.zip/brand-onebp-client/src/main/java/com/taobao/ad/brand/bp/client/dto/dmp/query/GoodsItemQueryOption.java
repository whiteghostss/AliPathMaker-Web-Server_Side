package com.taobao.ad.brand.bp.client.dto.dmp.query;

import lombok.Data;

/**
 * @author yanjingang
 * @date 2025/2/19
 */
@Data
public class GoodsItemQueryOption {

    /**
     * 是否过滤未准入的宝贝
     * */
    private boolean filterItemAccess;

    /**
     * 是否需要指标行业对比
     */
    private boolean needBenchmarkCompare;

}
