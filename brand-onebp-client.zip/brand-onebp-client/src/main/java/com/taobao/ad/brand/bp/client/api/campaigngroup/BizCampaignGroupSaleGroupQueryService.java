package com.taobao.ad.brand.bp.client.api.campaigngroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.salegroup.CampaignGroupSaleGroupBoostGiveApplyAuditViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.salegroup.CampaignGroupSaleGroupBoostGiveApplyViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.salegroup.SaleGroupBoostCalculateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.salegroup.SaleGroupBoostCalculateResultViewDTO;

/**
 * CampaignGroupSaleGroup
 *  *
 *  * @author yanjingang
 *  * @date 2023/9/16
 */
public interface BizCampaignGroupSaleGroupQueryService extends QueryAPI {

    String TAG = "CampaignGroupSaleGroup";

    @ProcessEntrance(name = "下载申请的补量/配送申请", desc = "下载申请的补量/配送申请", opType = OpType.query, tag = TAG)
    SingleResponse<String> downloadApplySaleGroup(ServiceContext context, CampaignGroupSaleGroupBoostGiveApplyViewDTO applyViewDTO);

    @ProcessEntrance(name = "获取补量/配送申请的审核信息", desc = "获取补量/配送申请的审核信息", opType = OpType.query, tag = TAG)
    SingleResponse<CampaignGroupSaleGroupBoostGiveApplyAuditViewDTO> getApplyAuditInfos(ServiceContext context, CampaignGroupSaleGroupBoostGiveApplyViewDTO applyViewDTO);

    @ProcessEntrance(name = "发起补量-计算补量金额", desc = "发起补量-计算补量金额", opType = OpType.query, tag = TAG)
    SingleResponse<SaleGroupBoostCalculateResultViewDTO> calculateBoostSaleGroup(ServiceContext context, SaleGroupBoostCalculateViewDTO calculateViewDTO);
}
