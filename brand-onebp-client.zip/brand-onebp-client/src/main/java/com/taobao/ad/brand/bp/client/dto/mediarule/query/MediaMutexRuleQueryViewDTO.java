package com.taobao.ad.brand.bp.client.dto.mediarule.query;

import com.taobao.ad.brand.bp.client.dto.base.BaseQueryViewDTO;
import lombok.Data;

import java.util.List;

/**
 * 互斥规则查询DTO
 */
@Data
public class MediaMutexRuleQueryViewDTO extends BaseQueryViewDTO {

    /**
     * 状态 1:开启 0:关闭
     */
    private Integer status;

    /**
     * 媒体ID
     */
    private Long siteId;

    /**
     * 关键词
     */
    private String keyword;

    /**
     * 关键词类型
     */
    private Integer keywordType;
}
