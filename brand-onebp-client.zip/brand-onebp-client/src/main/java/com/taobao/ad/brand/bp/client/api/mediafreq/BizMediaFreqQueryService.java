package com.taobao.ad.brand.bp.client.api.mediafreq;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.ad.brand.dto.media.freq.MediaFreqViewDTO;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.mediafreq.query.MediaFreqQueryViewDTO;

/**
 * 媒体频控查询服务
 *
 * @author shiyan
 * @date 2023/7/19
 **/
public interface BizMediaFreqQueryService extends QueryAPI {
    String TAG = "MediaFreq";

    /**
     * 分页查询数据
     *
     * @param context
     * @param queryViewDTO
     * @return
     */
    @ProcessEntrance(name = "分页查询数据", desc = "分页查询数据", opType = OpType.query, tag = TAG)
    MultiResponse<MediaFreqViewDTO> findListWithPage(ServiceContext context, MediaFreqQueryViewDTO queryViewDTO);

    /**
     * 查询单条数据
     *
     * @param context
     * @param id
     * @return
     */
    @ProcessEntrance(name = "查询单条数据", desc = "查询单条数据", opType = OpType.query, tag = TAG)
    SingleResponse<MediaFreqViewDTO> getMediaFreq(ServiceContext context, Long id);
}
