package com.taobao.ad.brand.bp.client.enums.campaigngroup;

import java.util.Map;

import com.google.common.collect.Maps;

/**
 * @author yanjingang
 * @date 2023/7/17
 */
public enum SaleGroupSelectReasonTypeEnum {

    ORDER_ING_OR_FINISHED(1, "下单完成"),
    MODIFY_LAST_REFUSE(2, "改单拒绝"),
    CAST_ING(3, "推广中"),
    WAIT_ORDER(4, "待下单"),
    ;

    SaleGroupSelectReasonTypeEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    private Integer code;
    private String desc;

    public Integer getCode() {
        return code;
    }
    public String getDesc() {
        return desc;
    }

    private final static Map<Integer, SaleGroupSelectReasonTypeEnum> TYPE_2_ENUM_LIST = Maps.newHashMap();
    static {
        for (SaleGroupSelectReasonTypeEnum typeEnum : SaleGroupSelectReasonTypeEnum.values()) {
            TYPE_2_ENUM_LIST.put(typeEnum.getCode(), typeEnum);
        }
    }
}
