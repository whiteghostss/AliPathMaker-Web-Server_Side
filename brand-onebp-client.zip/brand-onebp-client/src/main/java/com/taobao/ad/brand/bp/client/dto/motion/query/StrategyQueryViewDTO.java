package com.taobao.ad.brand.bp.client.dto.motion.query;

import com.taobao.ad.brand.bp.client.dto.base.BaseQueryViewDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/18
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class StrategyQueryViewDTO extends BaseQueryViewDTO {

    /**
     * 策略id列表
     */
    private List<Long> idList;

    /**
     * 提案id
     */
    private Long motionId;

    /**
     * 是否需要获取产品策略
     */
    private Boolean needProductStrategy;
}
