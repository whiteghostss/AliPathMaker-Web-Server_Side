package com.taobao.ad.brand.bp.client.enums.report;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;

/**
 * @author yuncheng.lyc
 */
@AllArgsConstructor(access = AccessLevel.PACKAGE)
public enum FrequencyTypeEnum {
    ONE_FREQUENCY(1, "1次"),
    TWO_FREQUENCY(2, "2次"),
    THREE_FREQUENCY(3, "3次"),
    FOUR_FREQUENCY(4, "4次"),
    FIVE_FREQUENCY(5, "5次"),
    SIX_FREQUENCY(6, "6次"),
    SEVEN_FREQUENCY(7, "7次"),
    EIGHT_FREQUENCY(8, "8次"),
    NINE_FREQUENCY(9, "9次"),
    TEN_FREQUENCY(10, "10次及以上");


    private Integer value;
    private String name;



    public static FrequencyTypeEnum getByValue(Integer value) {
        FrequencyTypeEnum[] enums = FrequencyTypeEnum.values();
        for (FrequencyTypeEnum type : enums) {
            if (type.getValue().equals(value))
                return type;
        }
        return null;
    }


    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
