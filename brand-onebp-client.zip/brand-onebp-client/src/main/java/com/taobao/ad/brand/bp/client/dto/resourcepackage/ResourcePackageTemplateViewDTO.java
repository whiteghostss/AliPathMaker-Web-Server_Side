package com.taobao.ad.brand.bp.client.dto.resourcepackage;

import java.util.List;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;

import lombok.Data;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/22
 */
@Data
public class ResourcePackageTemplateViewDTO extends BaseViewDTO {

    private Long id;

    private Long memberId;

    private Long customerTemplateId;

    private String customerTemplateName;

    /**
     * 招商模板ID
     */
    private Long marketingTemplateId;

    /**
     * 招商项目ID
     */
    private Long projectId;

    /**
     * 模板类型
     *
     * @see com.taobao.ad.brand.bp.client.enums.resourcepackage.ResourcePackageTemplateTypeEnum
     */
    private Integer type;
    /**
     * 创建人
     */
    private String creator;
    /**
     * 分组List
     */
    private List<ResourcePackageSaleGroupViewDTO> saleGroupList;

    /**
     * 权益模板id列表
     */
    private List<Long> rightsTemplateIdList;
}