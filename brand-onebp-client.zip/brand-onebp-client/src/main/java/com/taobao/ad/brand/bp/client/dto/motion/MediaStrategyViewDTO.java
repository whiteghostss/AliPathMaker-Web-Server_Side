package com.taobao.ad.brand.bp.client.dto.motion;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/18
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class MediaStrategyViewDTO extends BaseViewDTO {

    /**
     * 媒体id
     */
    private Long siteId;
    /**
     * 预算
     */
    private Long budget;

    /**
     * 预估数据（实际只有曝光量需要展示，无其他数据）
     */
    private PredictDataViewDTO predictDataViewDTO;

    /**
     * 媒体洞察数据（媒体固定预估数据，非通过产品策略计算）
     */
    private InsightDataViewDTO mediaInsightDataViewDTO;
}
