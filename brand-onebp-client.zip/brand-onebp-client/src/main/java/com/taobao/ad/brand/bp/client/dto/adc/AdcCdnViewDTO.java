package com.taobao.ad.brand.bp.client.dto.adc;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.ToString;

import java.util.Map;

/**
 * ADC-cdn配置信息
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@Data
@ToString
public class AdcCdnViewDTO extends BaseViewDTO {
    /**
     * 项目名称
     */
    private String projectName;
    /**
     * cdn地址
     */
    private String source;

    /**
     * 域名host
     */
    private String apiHost;

    /**
     * 分域名的域名host
     */
    private Map<String, String> apiHostDomain;
}
