package com.taobao.ad.brand.bp.client.api.dooh;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;

public interface BizDoohQueryService {
    String TAG = "Strategy";

    @ProcessEntrance(name = "查询天攻行业列表", desc = "查询天攻行业列表", opType = OpType.query, tag = TAG)
    MultiResponse<CommonViewDTO> getPriorityIndustryList(ServiceContext context);
}
