package com.taobao.ad.brand.bp.client.enums.message;

/**
 * 领域消息TAG类型
 * @author GXG
 * @date 2023/7/27
 */
public enum DomainMessageTagTypeEnum {
    NOTIC
}
