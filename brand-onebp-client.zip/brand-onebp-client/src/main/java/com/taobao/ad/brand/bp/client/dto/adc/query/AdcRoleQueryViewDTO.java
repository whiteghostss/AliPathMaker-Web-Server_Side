package com.taobao.ad.brand.bp.client.dto.adc.query;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author 虫洞 <liuming.liu@alibaba-inc.com>
 * @date 2023/3/29
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AdcRoleQueryViewDTO extends BaseViewDTO {
    /**
     * @see com.taobao.ad.brand.bp.client.enums.MemberTypeEnum#PARTNER
     * @see com.taobao.ad.brand.bp.client.enums.MemberTypeEnum#SELLER
     */
    private Integer memberType;
    private Long memberId;

    /**
     * 准入场景
     */
    private List<String> joinScenceCodeList;
}
