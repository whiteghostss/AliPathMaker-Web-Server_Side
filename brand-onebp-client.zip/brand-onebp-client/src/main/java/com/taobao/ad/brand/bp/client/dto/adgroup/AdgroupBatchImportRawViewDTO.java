package com.taobao.ad.brand.bp.client.dto.adgroup;

import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.ErrorMessageDTO;
import lombok.Data;

/**
 * 单元批量导出从Excel中解析到的原始信息
 * @author gxg
 */
@Data
public class AdgroupBatchImportRawViewDTO extends BaseViewDTO {
    private ErrorMessageDTO errorMessage;
    private Boolean isFiltered;
    private AdgroupViewDTO adgroupViewDTO;
}
