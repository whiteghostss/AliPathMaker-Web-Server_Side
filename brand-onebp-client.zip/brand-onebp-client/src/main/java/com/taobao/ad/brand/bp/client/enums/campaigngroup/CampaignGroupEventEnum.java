package com.taobao.ad.brand.bp.client.enums.campaigngroup;

import com.taobao.ad.brand.bp.client.enums.CommonEnum;

/**
 * 订单状态流转event
 * @author yanjingang
 * @date 2023/3/6
 */
public enum CampaignGroupEventEnum implements CommonEnum {
    CREATE(1, "新建"),
    ORDER(2, "下单"),
    CONTRACT_PAY(3, "合同已上线"),
    RESOURCE_CONFIRM(4, "资源已确认"),
    ONLINE(5, "上线"),
    NEXT(6, "下一步"),
    UNLOCK(8, "改单"),
    UNLOCK_REVERT(18, "撤销改单"),
    STOP_CAST(9, "停投"),
    FINISH(10, "完成"),
    FINISH_REVERT(11, "完成撤回"),
    REAL_SETTLE(12, "申请实结"),
    REAL_SETTLE_APPROVE(13, "实结通过"),
    REAL_SETTLE_REFUSE(14, "实结拒绝"),
    COMPLETE(15, "结案"),
    COMPLETE_REVERT(16, "结案打回"),
    CANCEL(17, "撤单"),

    MODIFY_ORDER(19, "修改订单"),

    SUB_CONTRACT_GENERATE(20, "子合同生成"),

    BOOST_OR_GIVE_ORDER(21, "补量/配送下单"),

    REAL_SETTLE_CONFIG(22, "实结信息配置"),

    UPDATE(23, "更新（来自主订单的更新）"),
    DELETE(-1, "删除"),
    /**
     * 自助营销订单下单分2步
     * 1. 执行PRE_ORDER生成Brief和客户模板、分组
     * 2. 执行ORDER，同步信息至售卖，同时生成合同
     */
    PRE_ORDER(24, "下单"),
    COMPLETE_INFO_CONFIG(25, "订单结案账号配置"),

    ORDER_NOTICE_MSG(26, "下单通知"),
    CANCEL_NOTICE_MSG(27, "自动撤单通知"),
    WAIT_SIGN_NOTICE_MSG(28, "合同待签约通知"),
    WAIT_PAYMENT_NOTICE_MSG(29, "合同待付款通知"),

    SALE_GROUP_ESTIMATE(31, "分组交付指标置信度预警通知"),
    ;


    private final int value;
    private final String desc;

    CampaignGroupEventEnum(int value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    @Override
    public int getValue() {
        return value;
    }

    @Override
    public String getDesc() {
        return desc;
    }
}
