package com.taobao.ad.brand.bp.client.api.campaigngroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.CommandAPI;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.salegroup.CampaignGroupSaleGroupBoostGiveApplyViewDTO;

/**
 * CampaignGroupSaleGroup
 *
 * @author yanjingang
 * @date 2023/9/16
 */
public interface BizCampaignGroupSaleGroupCommandService extends CommandAPI {

    String TAG = "CampaignGroupSaleGroup";

    @ProcessEntrance(name = "发起补量/配送申请", desc = "发起补量/配送申请", opType = OpType.add, tag = TAG)
    SingleResponse<Long> applySaleGroup(ServiceContext context, CampaignGroupSaleGroupBoostGiveApplyViewDTO applyViewDTO);

    @ProcessEntrance(name = "删除申请的补量/配送分组", desc = "删除申请的补量/配送分组", opType = OpType.delete, tag = TAG)
    SingleResponse<Long> deleteApplySaleGroup(ServiceContext context, CampaignGroupSaleGroupBoostGiveApplyViewDTO applyViewDTO);
}
