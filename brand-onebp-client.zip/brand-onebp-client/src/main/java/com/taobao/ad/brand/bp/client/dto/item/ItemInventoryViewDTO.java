package com.taobao.ad.brand.bp.client.dto.item;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.List;

/**
 * @Author: PhilipFry
 * @createTime: 2024年04月24日 21:06:03
 * @Description:
 */
@Data
public class ItemInventoryViewDTO extends BaseViewDTO {

    /**
     * 库存ID
     */
    private long inventoryId;

    /**
     * 宝贝ID
     */
    private long itemId;

    /**
     * 宝贝的可售总库存（有sku时，是可售库存总数）
     */
    private int sellableQuantity;

    /**
     * 预扣库存数（有sku时，是预扣库存总数）
     */
    private int withholdingQuantity;

    /**
     * SKU详情列表
     */
    private List<SkuInventoryViewDTO> skuList;
}
