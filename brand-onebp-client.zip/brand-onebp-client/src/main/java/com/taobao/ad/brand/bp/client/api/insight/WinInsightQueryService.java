package com.taobao.ad.brand.bp.client.api.insight;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.brand.CompetitionBrandViewDTO;
import com.taobao.ad.brand.bp.client.dto.insight.WinInsightBrandQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.insight.WinInsightBrandViewDTO;
import com.taobao.ad.brand.bp.client.dto.insight.WinInsightQueryViewDTO;

import java.util.Map;

/**
 * 洞察查询相关服务
 *
 * @author yuncheng.lyc
 */
public interface WinInsightQueryService extends QueryAPI {

    String TAG = "Insight";

    @ProcessEntrance(name = "Win度量查询可选维度", desc = "Win度量查询可选维度", opType = OpType.query, tag = TAG)
    MultiResponse<Map<String, Object>> dimensionList(ServiceContext serviceContext, WinInsightQueryViewDTO winInsightQueryViewDTO);

    @ProcessEntrance(name = "Win度量数据查询", desc = "Win度量数据查询", opType = OpType.query, tag = TAG)
    MultiResponse<Map<String, Object>> query(ServiceContext serviceContext, WinInsightQueryViewDTO winInsightQueryViewDTO);

    @ProcessEntrance(name = "Win度量数据导出", desc = "Win度量数据导出", opType = OpType.query, tag = TAG)
    SingleResponse<String> basicExport(ServiceContext serviceContext, WinInsightQueryViewDTO winInsightQueryViewDTO);


    @ProcessEntrance(name = "Win度量同行数据导出", desc = "Win度量同行数据导出", opType = OpType.query, tag = TAG)
    SingleResponse<String> industryExport(ServiceContext serviceContext, WinInsightQueryViewDTO winInsightQueryViewDTO);


    @ProcessEntrance(name = "Win度量win指标智能解读", desc = "Win度量win指标智能解读", opType = OpType.query, tag = TAG)
    SingleResponse<Map<String, String>> smartExplain(ServiceContext serviceContext, WinInsightQueryViewDTO winInsightQueryViewDTO);

    @ProcessEntrance(name = "Win度量win指标智能解读数据查询For QueryTool", desc = "Win度量win指标智能解读数据查询For QueryTool", opType = OpType.query, tag = TAG)
    SingleResponse<Map<String, Object>> smartExplainQuery(ServiceContext serviceContext, WinInsightQueryViewDTO winInsightQueryViewDTO);

    @ProcessEntrance(name = "查询Win度量品牌List", desc = "查询Win度量品牌List", opType = OpType.query, tag = TAG)
    MultiResponse<WinInsightBrandViewDTO> queryBrandList(ServiceContext serviceContext, WinInsightBrandQueryViewDTO brandQueryViewDTO);

    @ProcessEntrance(name = "查询Win度量竞对品牌List", desc = "查询Win度量竞对品牌List", opType = OpType.query, tag = TAG)
    MultiResponse<CompetitionBrandViewDTO> queryCompetitionBrandList(ServiceContext serviceContext, WinInsightBrandQueryViewDTO brandQueryViewDTO);

}
