package com.taobao.ad.brand.bp.client.context;

import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;


/**
 * 单元事件处理相关context
 * */
@Builder
@Data
public class AdgroupNoticeContext implements Serializable {
    private AdgroupViewDTO adgroupViewDTO;
}
