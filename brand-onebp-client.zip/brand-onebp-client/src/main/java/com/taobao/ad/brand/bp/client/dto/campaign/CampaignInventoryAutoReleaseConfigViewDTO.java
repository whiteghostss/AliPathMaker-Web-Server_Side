package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * @author jixiu.lj
 * @date 2023/8/4 13:58
 */
@Data
public class CampaignInventoryAutoReleaseConfigViewDTO extends BaseViewDTO {
    /**
     * 锁量有效期计算阈值
     */
    private Integer expireTimeThreshold;

    /**
     * 常规锁量有效期阈值
     */
    private Integer expireTimeNormalThreshold;

    /**
     * 临近投放期锁量有效期阈值
     */
    private Integer expireTimeEdgeThreshold;

    /**
     * 单计划预警阈值
     */
    private Integer singleWarningThreshold;

    /**
     * 临近投放期单计划预警阈值
     */
    private Integer singleWarningEdgeThreshold;

    /**
     * 批量计划预警阈值
     */
    private Integer multipleWarningThreshold;

    /**
     * 临近投放期批量计划预警阈值
     */
    private Integer multipleWarningEdgeThreshold;

    /**
     * 延期申请后延长的锁量有效期天数
     */
    private Integer delayLockApplyValue;

    /**
     * 全局是否开启自动释量(预警不受影响)
     * @see com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum
     */
    private Integer globalReleaseSwitch;
}
