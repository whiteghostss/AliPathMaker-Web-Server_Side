package com.taobao.ad.brand.bp.client.dto.base;

import lombok.Getter;

/**
 * 查询场景
 */
@Getter
public enum QuerySceneEnum {
    PAGE("分页查询"),
    LIST("列表查询"),
    GET("详情查询"),
    ;
    private final String desc;

    QuerySceneEnum(String desc) {
        this.desc = desc;
    }
}
