package com.taobao.ad.brand.bp.client.dto.dmp.query;

import com.taobao.ad.brand.bp.client.dto.base.BaseQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.dmp.DmpItemLevelEnum;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author yanjingang
 * @date 2025/2/19
 */
@Data
public class GoodsItemQueryViewDTO extends BaseQueryViewDTO {

    /** 开始日期 */
    private Date startDate;
    /** 结束日期 */
    private Date endDate;
    /**
     * 货品等级（新/潜/爆/尾）code，详见枚举:
     * @see DmpItemLevelEnum
     * */
    private Integer itemLevel;
    /** 查询关键字
     * 根据宝贝名称或者宝贝id进行查询
     * */
    private String keyword;
    /**
     * 宝贝ID
     */
    private List<Long> itemIds;
    /** 比较类型  0或不传-宝贝自身数据; 1-对比叶子类目平均*/
    private Integer compareType;

}
