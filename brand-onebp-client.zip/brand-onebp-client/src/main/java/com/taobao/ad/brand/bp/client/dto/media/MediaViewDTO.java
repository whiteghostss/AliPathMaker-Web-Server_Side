package com.taobao.ad.brand.bp.client.dto.media;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.List;

@Data
public class MediaViewDTO extends BaseViewDTO {
    /**
     * 媒体ID
     * */
    private Long id;
    /**
     * 媒体MemberId
     * */
    private Long memberId;
    /**
     * 媒体site_id
     * */
    private Long siteId;
    private Long supplierNo;
    /**
     * 媒体名称
     * */
    private String mediaName;
    private Integer mediaStatus;
    private Long mediaType;
    private String androidPkgName;
    private String androidSchema;
    private String androidBcAppkey;
    private String androidSourceId;
    private String iosBundleId;
    private String iosSchema;
    private String iosBcAppkey;
    private String iosSourceId;

    private Long unifiedMediaId;

//
//    /**
//     * 媒体联系人
//     * */
//    private List<MediaContactViewDTO> mediaContactList;
}
