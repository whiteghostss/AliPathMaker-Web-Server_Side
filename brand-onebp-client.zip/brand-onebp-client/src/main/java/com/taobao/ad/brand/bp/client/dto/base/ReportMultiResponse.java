package com.taobao.ad.brand.bp.client.dto.base;

import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.taobao.ad.brand.bp.client.dto.report.ReportMetricsConfigViewDTO;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * NB报表统一报表结果对象
 * @author haicheng
 */
@Getter
@Setter
public class ReportMultiResponse<T>  extends MultiResponse<T> {

    private List<ReportMetricsConfigViewDTO> header;

    public ReportMultiResponse() {

    }

    public static <T> ReportMultiResponse<T> of(List<T> result, int total, List<ReportMetricsConfigViewDTO> header) {
        ReportMultiResponse model = new ReportMultiResponse();
        model.setResult(result);
        model.setTotal(total);
        model.setHeader(header);
        model.setSuccess(true);
        return model;
    }

}
