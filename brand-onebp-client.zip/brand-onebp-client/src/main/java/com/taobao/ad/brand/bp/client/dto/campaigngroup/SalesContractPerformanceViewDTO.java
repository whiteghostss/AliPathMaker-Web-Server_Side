package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * @author jixiu.lj
 * @date 2023/8/10 16:23
 * 合同上的业绩归属信息
 */
@Data
public class SalesContractPerformanceViewDTO extends BaseViewDTO {

    private static final long serialVersionUID = 4372970296608667403L;

    // 销售
    private SalesContractPerformanceEmployeeViewDTO sale;

    private SalesContractPerformanceEmployeeViewDTO saleLeader;

    // 业务经理
    private SalesContractPerformanceEmployeeViewDTO businessManager;

    // 区域经理
    private SalesContractPerformanceEmployeeViewDTO areaManager;

    private Integer ratio;

}
