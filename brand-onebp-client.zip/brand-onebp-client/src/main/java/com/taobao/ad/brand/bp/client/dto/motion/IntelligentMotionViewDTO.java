package com.taobao.ad.brand.bp.client.dto.motion;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.List;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/17
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class IntelligentMotionViewDTO extends BaseViewDTO {

    /**
     * 主键id
     */
    private Long id;

    /**
     * 提案名称
     */
    private String name;

    /**
     * 提案状态
     * com.taobao.ad.brand.bp.client.enums.motion.IntelligentMotionStatusEnum
     */
    private Integer status;

    /**
     * cartId列表
     */
    private List<Long> cartItemIdList;

    /**
     * 投放账号
     */
    private Long memberId;

    /**
     * 招商分组id
     */
    private Long saleGroupId;

    /**
     * 营销场景
     */
    private Integer marketingScene;

    /**
     * 开始时间
     */
    private Date startTime;
    /**
     * 结束时间
     */
    private Date endTime;

    /**
     * 提案预算
     */
    private Long budget;

    /**
     * 营销阶段
     */
    private List<MarketingStageViewDTO> marketingStageViewDTOList;

    /**
     * 关注目标列表
     */
    private List<AttentionTargetViewDTO> attentionTargetViewDTOList;

    /**
     * 人群策略选的人群
     * */
    private List<Long> crowdIdList;

    /**
     * 必投媒体列表
     */
    private List<Long> includeMediaList;

    /**
     * 排除媒体列表
     */
    private List<Long> excludeMediaList;

    /**
     * 资源类型比例
     */
    private List<ResourceTypeRatioViewDTO> resourceTypeRatioViewDTOList;

    /**
     * 投放方式列表
     */
    private List<Integer> castTypeList;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建时间
     */
    private Date gmtCreate;

    /**
     * 错误原因
     */
    private String errorReason;

    /**
     * 提案来源
     * com.alibaba.ad.nb.packages.v2.client.constant.motion.MotionSourceEnum
     */
    private Integer source;
}
