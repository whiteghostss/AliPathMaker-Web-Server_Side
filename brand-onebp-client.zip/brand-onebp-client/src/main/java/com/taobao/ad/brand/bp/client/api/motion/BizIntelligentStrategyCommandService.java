package com.taobao.ad.brand.bp.client.api.motion;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.CommandAPI;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.dto.motion.IntelligentMotionViewDTO;
import com.taobao.ad.brand.bp.client.dto.motion.IntelligentStrategyViewDTO;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/18
 **/
public interface BizIntelligentStrategyCommandService extends CommandAPI {

    String TAG = "IntelligentStrategy";

    /**
     * 引擎同步智能策略
     * @param serviceContext
     * @param strategyResponse
     * @return
     */
    @ProcessEntrance(name = "同步智能策略", desc = "引擎同步智能策略", opType = OpType.add, tag = TAG)
    Response noticeIntelligentStrategyResult(ServiceContext serviceContext, String strategyResponse);

    /**
     * 计算智能策略
     * @param serviceContext
     * @param strategyViewDTO
     * @return
     */
    @ProcessEntrance(name = "生成新策略", desc = "计算生成新的自定义智能策略", opType = OpType.add, tag = TAG)
    Response calculateNewIntelligentStrategy(ServiceContext serviceContext, IntelligentStrategyViewDTO strategyViewDTO);

    @ProcessEntrance(name = "刷新已有策略", desc = "刷新已有智能策略的预估值", opType = OpType.add, tag = TAG)
    Response refreshIntelligentStrategy(ServiceContext serviceContext, IntelligentStrategyViewDTO strategyViewDTO);

    @ProcessEntrance(name = "编辑智能策略基础信息", desc = "编辑智能策略基础信息", opType = OpType.add, tag = TAG)
    Response updateBasicIntelligentStrategy(ServiceContext serviceContext, IntelligentStrategyViewDTO strategyViewDTO);

    @ProcessEntrance(name = "保存策略", desc = "保存策略", opType = OpType.add, tag = TAG)
    SingleResponse<Long> saveIntelligentStrategy(ServiceContext serviceContext, IntelligentStrategyViewDTO strategyViewDTO);

    @ProcessEntrance(name = "优选/非优选智能策略", desc = "优选/非优选智能策略", opType = OpType.add, tag = TAG)
    Response preferIntelligentStrategy(ServiceContext serviceContext, IntelligentStrategyViewDTO strategyViewDTO);
}
