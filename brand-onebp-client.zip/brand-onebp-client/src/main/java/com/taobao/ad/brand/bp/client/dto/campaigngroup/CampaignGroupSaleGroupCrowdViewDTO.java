package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.List;

/**
 * 分组人群保存
 * @author yunhu.myh@taobao.com
 * @date 2023年07月25日
 * */
@Data
public class CampaignGroupSaleGroupCrowdViewDTO extends BaseViewDTO {

    /**
     * 订单分组ID
     * */
    private Long saleGroupId;
    /**
     * dmp人群IDs
     * */
    private List<Long> crowdIdList;

    /**
     * 订单Id
     * */
    private Long campaignGroupId;
}
