package com.taobao.ad.brand.bp.client.dto.campaign;

import com.taobao.ad.brand.bp.client.dto.tool.BatchImportParamViewDTO;
import lombok.Data;

import java.util.List;
@Data
public class CampaignBookingAmountBatchImportParamViewDTO extends BatchImportParamViewDTO {
    /**
     * 订单id
     */
    private Long campaignGroupId;
    /**
     * 批量计划信息
     */
    private List<CampaignBookingAmountBatchImportRawViewDTO> campaignBookingAmountBatchImportRawViewDTOList;
}