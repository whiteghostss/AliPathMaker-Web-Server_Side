package com.taobao.ad.brand.bp.client.enums.report;

import com.taobao.ad.brand.bp.client.enums.CommonEnum;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;

/**
 * 异步任务状态 1待运行/ 2运行中/ 3运行成功/ 4运行失败
 * @author yuncheng.lyc
 * @date 2023/3/7
 **/
@AllArgsConstructor(access = AccessLevel.PACKAGE)
public enum ReportTaskStatusEnum implements CommonEnum {

    /**
     * 待运行
     */
    WAITING(1, "待运行"),
    /**
     * 运行中
     */
    RUNNING(2, "运行中"),
    /**
     * 运行成功
     */
    SUCCEED(3, "运行成功"),
    /**
     * 运行成功
     */
    FAIL(4, "运行失败"),

    /**
     * 品牌OB批量计划导入使用
     */
    PARTIAL_SUCCESS(5, "部分成功"),
    ;

    private final Integer value;
    private final String desc;

    @Override
    public int getValue() {
        return value;
    }

    @Override
    public String getDesc() {
        return desc;
    }

}
