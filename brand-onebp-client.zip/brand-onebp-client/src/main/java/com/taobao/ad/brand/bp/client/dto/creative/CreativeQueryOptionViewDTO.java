package com.taobao.ad.brand.bp.client.dto.creative;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 查询创意时设置需要返回的数据信息
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CreativeQueryOptionViewDTO {

    /**
     * 是否需要查询子创意
     */
    private boolean needChildren;

}
