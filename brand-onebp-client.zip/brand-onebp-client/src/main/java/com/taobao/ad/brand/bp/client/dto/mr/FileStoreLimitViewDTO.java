package com.taobao.ad.brand.bp.client.dto.mr;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * @author jixiu.lj
 * @date 2023/3/21 11:43
 */
@Data
public class FileStoreLimitViewDTO {

    private Integer value;
    private String unit;


}
