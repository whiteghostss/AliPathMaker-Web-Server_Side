package com.taobao.ad.brand.bp.client.dto.mr.textrule;

import lombok.Data;

/**
 * @author jixiu.lj
 * @date 2023/3/21 11:41
 */
@Data
public class TextLengthLimitViewDTO {
    private Integer pinyinType;
    private Integer min;
    private Integer max;
}
