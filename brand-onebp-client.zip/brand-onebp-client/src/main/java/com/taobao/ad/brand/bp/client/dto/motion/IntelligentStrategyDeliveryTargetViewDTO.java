package com.taobao.ad.brand.bp.client.dto.motion;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2023/7/20
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class IntelligentStrategyDeliveryTargetViewDTO extends BaseViewDTO {

    /**
     * 交付指标
     * <p>
     * com.alibaba.ad.nb.ssp.constant.newproduct.DeliveryTargetEnum
     */
    private Integer deliveryTarget;

    /**
     * 交付指标描述
     */
    private String label;

    /**
     * 计算/参考分组总售卖量
     * 仅曝光量、点击量、到达量有
     */
    private Long totalAmount;
    /**
     * 计算/参考分组均价
     * 仅曝光量、点击量、到达量有
     */
    private Long averagePrice;

    /**
     * 总售卖量折扣
     * 仅曝光量、点击量、到达量有
     */
    private Integer amountDiscount;

    /**
     * 数字或者比例(35.47% -> 3547)
     */
    private Integer deliveryTargetValue;

    /**
     * 指标值类型
     * <p>
     * com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupDeliveryTargetValueTypeEnum
     */
    private Integer valueType;

    /**
     * 分组指标面客均价
     * 仅曝光量、点击量、到达量有
     */
    private Long deliveryTargetAveragePrice;
    /**
     * 面客展示开关
     */
    private Integer customerSwitch;
}
