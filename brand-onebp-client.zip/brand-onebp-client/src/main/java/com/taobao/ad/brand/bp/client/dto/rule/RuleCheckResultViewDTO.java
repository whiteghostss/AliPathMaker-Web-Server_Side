package com.taobao.ad.brand.bp.client.dto.rule;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 规则执行结果集
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RuleCheckResultViewDTO extends BaseViewDTO {
    /**
     * 规则类型
     * CartOrderRuleTypeEnum
     */
    private Integer ruleType;
    /**
     * 规则名称
     */
    private String ruleName;
    /**
     * 是否通过
     * BooleanEnum
     */
    private Integer isPass;
    /**
     * 不通过原因
     */
    private String reason;

    /**
     * 规则校验结果
     */
    private List<RuleCheckResultViewDTO> ruleCheckResultViewDTOList;
}
