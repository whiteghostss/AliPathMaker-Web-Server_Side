package com.taobao.ad.brand.bp.client.dto.base;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/23
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CommonViewDTO extends BaseViewDTO {
    /**
     * ID
     */
    private Long id;

    /**
     * Name
     */
    private String name;

    /**
     * value
     */
    private String value;

    /**
     * 是否选中
     * */
    private Boolean selected;

    /**
     * parentValue
     */
    private String parentValue;

    private String parentType;

    public CommonViewDTO(Long id, String name){
        this.id = id;
        this.name = name;
    }
}
