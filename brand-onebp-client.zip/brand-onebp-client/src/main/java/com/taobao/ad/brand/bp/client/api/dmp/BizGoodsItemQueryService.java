package com.taobao.ad.brand.bp.client.api.dmp;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.taobao.ad.brand.bp.client.dto.dmp.ItemMetricsViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.query.GoodsItemQueryOption;
import com.taobao.ad.brand.bp.client.dto.dmp.query.GoodsItemQueryViewDTO;

/**
 * 商品查询服务
 * @author yanjingang
 * @date 2025/2/19
 */
public interface BizGoodsItemQueryService extends QueryAPI {

    String TAG = "GoodsItem";

    /**
     * 分页查询Item
     *
     * @param context
     * @param query
     * @return
     */
    @ProcessEntrance(name = "分页查询", desc = "分页查询", opType = OpType.query, tag = TAG)
    MultiResponse<ItemMetricsViewDTO> findGoodsItemList(ServiceContext context, GoodsItemQueryViewDTO query, GoodsItemQueryOption option);

    /**
     * 查询Item对比指标
     *
     * @param context
     * @return
     */
    @ProcessEntrance(name = "id查询", desc = "id查询", opType = OpType.query, tag = TAG)
    MultiResponse<ItemMetricsViewDTO> findItemMetrics(ServiceContext context, GoodsItemQueryViewDTO query, GoodsItemQueryOption option);
}
