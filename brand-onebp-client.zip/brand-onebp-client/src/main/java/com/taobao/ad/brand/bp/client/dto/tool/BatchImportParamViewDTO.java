package com.taobao.ad.brand.bp.client.dto.tool;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.adgroup.AdgroupBatchImportRawViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportTaskViewDTO;
import lombok.Data;

import java.util.List;

/**
 * 批量导入参数信息
 * @author shiyan
 */
@Data
public class BatchImportParamViewDTO extends BaseViewDTO {
    /**
     * 任务id
     */
    private Long taskId;
    /**
     * 任务实体
     */
    private ReportTaskViewDTO taskViewDTO;

}
