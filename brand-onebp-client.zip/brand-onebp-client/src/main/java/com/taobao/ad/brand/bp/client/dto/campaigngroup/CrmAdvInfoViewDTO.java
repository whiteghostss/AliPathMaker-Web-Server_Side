package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author yanjingang
 * @date 2023/3/20
 */
@Data
public class CrmAdvInfoViewDTO extends BaseViewDTO {

    /**
     * 主键
     */
    private Long id;

    /**
     * 创建时间
     */
    private Date gmtCreate;

    /**
     * 修改时间
     */
    private Date gmtModified;

    /********************************************** 广告主信息 ********************************************/

    /**
     * 广告主id
     */
    private Long advId;

    /**
     * 广告主名称
     */
    private String advName;

    /**
     * 广告主（多身份逗号隔开）1-生态伙伴，2-商家，3-集团/BU客户，4-DSP（tanx）
     */
    private List<Integer> advRoleTypeList;

    /**
     * 外部用户数字ID
     */
    private Long extId;

    /**
     * 外部用户数字类型
     */
    private String extType;

    /**
     * 广告主状态：0-初始、1-未激活、2-已激活、3-风险、4-失效
     */
    private Integer advStatus;

    /**
     * 广告主入驻时间
     */
    private Date advEnterTime;

    /**
     * 广告主激活时间
     */
    private Date advActiveTime;

    /********************************************** 店铺信息 ********************************************/

    /**
     * 主投放账户id
     */
    private Long memberId;

    /**
     * 主投放账户userid
     */
    private Long userId;

    /**
     * 主投放账户nickname/旺旺
     */
    private String wangwang;

    /**
     * 是否有销售报备：1-是 0-否
     */
    private Integer hasSales;

    /**
     * 业务线创建时间
     * Map<业务线alias, 时间>
     * @see com.taobao.ad.mm.crm.service.enums.BizCodeEnum
     */
    private Map<String, Date> productLineCreateTime;

    /**
     * 店铺id
     */
    private Long shopId;

    /**
     * 店铺名称
     */
    private String shopName;
    /**
     * 品牌信息，格式：brandName-brandId
     */
    private List<SalesContractBrandViewDTO> brandInfos;

    /**
     * 主营行业大组ID
     */
    private Long industryId;

    /**
     * 主营行业大组名称
     */
    private String industryName;

    /**
     * 主营一级大类ID
     */
    private Long subIndustryId;

    /**
     * 主营一级大类名称
     */
    private String subIndustryName;

    /**
     * 主营类目id
     */
    private Long mainCateId;

    /**
     * 主营类目名称
     */
    private String mainCateName;

    /**
     * B/C客户（1=b店，2=c店）
     */
    private Integer bcType;

    /**
     * 天猫旗舰店/专营店/专卖店(1.旗舰店，2.专卖，3.专营店)
     */
    private Integer b2cType;

    /**
     * 阿里妈妈客户分层
     */
    private Integer mmLevel;

    /**
     * 天猫KA分层（新），1=sska、2=ska、3=ka、4=核腰、5=普腰、6=长尾、7=底部
     */
    private Integer tmKaLevel;

    /**
     * 淘宝分层体系，按过去1年整体gmv计算，1=1000w以上，2=500w-1000w，3=250ww-500w，4=100w-250w，5=30w-100w，6=10w-30w，7=1w-10w，8=5000-1w，9=0-5000
     */
    private Integer tbLevel;

    /**
     * 是否国际店 1-是 0-否
     */
    private Integer global;

    /**
     * 是否i_fashion 1-是 0-否
     */
    private Integer iFashion;

    /**
     * 服务优先级
     * @see ServePriorityEnum
     */
    private String servePriority;

    /**
     * 客户信息
     */
    private CrmNewCustomerViewDTO newCustomer;

}
