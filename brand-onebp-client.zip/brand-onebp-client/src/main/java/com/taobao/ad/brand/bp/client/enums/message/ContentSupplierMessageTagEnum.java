package com.taobao.ad.brand.bp.client.enums.message;

public enum ContentSupplierMessageTagEnum {
    talent_update,
    campaign_group_stop,
    campaign_group_order_again,
    demand_update,
}
