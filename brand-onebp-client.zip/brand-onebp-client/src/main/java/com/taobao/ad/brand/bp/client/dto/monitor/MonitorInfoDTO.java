package com.taobao.ad.brand.bp.client.dto.monitor;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * @Description: 第三方监测配置
 * @Author: dongyang
 * @Date: 2023/2/25
 */
@Data
public class MonitorInfoDTO  extends BaseViewDTO {

    /**
     * 第三方点击监测
     */
    private String clkMonitorUrl;

    /**
     * 第三方曝光监测
     */
    private String pvMonitorUrl;

    /**
     * 设备类型
     * @see com.alibaba.ad.brand.sdk.constant.monitor.BrandThirdMonitorDeviceTypeEnum
     */
    private Integer deviceType;
}
