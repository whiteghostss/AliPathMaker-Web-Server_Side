package com.taobao.ad.brand.bp.client.dto.creative;

import lombok.Data;

/**
 * @author jixiu.lj
 * @date 2024/2/25 18:23
 */
@Data
public class CreativeBatchUpdateErrorMessageViewDTO {
    private Long creativeId;
    private String creativeName;
    private String errorMessage;
    private Integer status;
}
