package com.taobao.ad.brand.bp.client.enums.campaign;

import lombok.Getter;

/**
 * 计划排期导出身份类型
 *
 */
@Getter
public enum CampaignScheduleExportIdentityTypeEnum {

    SELLER("SELLER","商家"),
    ALI_EMPLOYEE("ALI_EMPLOYEE","内部小二");

    private String code;
    private String desc;

    CampaignScheduleExportIdentityTypeEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }
}
