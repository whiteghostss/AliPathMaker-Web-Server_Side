package com.taobao.ad.brand.bp.client.dto.solution.query;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 查询解决方案返回数据结构
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CartItemSolutionQueryOption {
    /**
     * 是否需要删除的方案
     */
    private boolean needDeleted = false;
    /**
     * 是否需要查询单元
     */
    private boolean needAdgroup = false;
}
