package com.taobao.ad.brand.bp.client.context;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignInquiryOperateViewDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * 计划库存回调通知上下文
 * */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CampaignInventoryCallbackNoticeContext {

    private ServiceContext serviceContext;

    private CampaignViewDTO campaignViewDTO;

    private CampaignInquiryOperateViewDTO campaignInquiryOperateViewDTO;



}
