package com.taobao.ad.brand.bp.client.enums.report;

import com.taobao.ad.brand.bp.client.enums.CommonEnum;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;

/**
 * 分天or汇总，1分天；2汇总
 * @author yuncheng.lyc
 * @date 2023/3/7
 **/
@AllArgsConstructor(access = AccessLevel.PACKAGE)
public enum ReportTotalTypeEnum implements CommonEnum {

    /**
     * 明细数据
     */
    DETAIL(1, "明细数据"),
    /**
     * 汇总数据
     */
    TOTAL(2, "汇总数据");

    private final Integer value;
    private final String desc;

    @Override
    public int getValue() {
        return value;
    }

    @Override
    public String getDesc() {
        return desc;
    }
}
