package com.taobao.ad.brand.bp.client.dto.resourcepackage.query;

import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.taobao.ad.brand.bp.client.dto.base.BaseQueryViewDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/25
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ResourcePackageQueryViewDTO extends BaseQueryViewDTO {
    /**
     * 分组状态
     */
    private Integer status;
    /**
     * 客户模版ID
     */
    private Long templateId;
    /**
     * 主分组ID
     */
    private List<Long> saleGroupIdList;
    /**
     * @see BrandSaleTypeEnum
     */
    private Integer saleType;
    /**
     * 配送或补量的主分组ID
     */
    private Long mainGroupId;

    /**
     * 是否设置盘量优先级
     */
    private Integer hasInquiryPriority;

    /**
     * 投放账号id
     */
    private Long memberId;

}
