package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.sdk.constant.salegroup.field.SaleGroupEstimateTypeEnum;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignEstimateResultViewDTO;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * 分组预估结果viewDTO
 * @author yunhu.myh@alibaba-inc.com
 * @date 2023年07月20日
 * */
@Data
public class CampaignGroupSaleGroupEstimateInfoViewDTO extends BaseViewDTO {

    /**
     * 订单分组ID
     * */
    private Long saleGroupId;

    /**
     * 计算时间
     * */
    private Date estimateTime;
    /**
     * 过期时间
     * */
    private Date expireTime;
    /**
     * @see
     * SaleGroupEstimateTypeEnum
     * */
    private Integer estimateType;

    /**
     * 是否showMax
     * @see com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum
     * */
    private Integer isShowMax;

    /**
     * 预估信息返回
     * */
    private List<CampaignGroupSaleGroupEstimateResultViewDTO> estimateResult;

    /**
     * 一级计划预估信息返回
     * */
    private List<CampaignEstimateResultViewDTO> campaignEstimateResultList;
}
