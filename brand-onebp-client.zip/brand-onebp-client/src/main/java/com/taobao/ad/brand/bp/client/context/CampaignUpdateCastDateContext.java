package com.taobao.ad.brand.bp.client.context;

import com.alibaba.abf.governance.context.ServiceContext;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class CampaignUpdateCastDateContext {

    /**
     * 上下文
     */
    private ServiceContext serviceContext;

    /**
     * 计划id
     */
    private Long campaignId;

}
