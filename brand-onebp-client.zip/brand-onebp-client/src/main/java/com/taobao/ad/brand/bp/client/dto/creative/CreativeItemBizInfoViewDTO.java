package com.taobao.ad.brand.bp.client.dto.creative;

import lombok.Data;

/**
 * @author jixiu.lj
 * @date 2024/5/20 13:51
 * 加购创意库存信息
 */
@Data
public class CreativeItemBizInfoViewDTO {

    /**
     * 商品ID
     */
    private Long itemId;

    /**
     * skuId
     */
    private Long skuId;

    /**
     * 业务类型 2:品牌特秀一键加购业务
     */
    private Integer bizType;

    /**
     * 状态 1 生效  0 失效
     */
    private Integer status;
}
