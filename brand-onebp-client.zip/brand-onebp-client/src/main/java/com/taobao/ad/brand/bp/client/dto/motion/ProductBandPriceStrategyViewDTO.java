package com.taobao.ad.brand.bp.client.dto.motion;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/5/10
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class ProductBandPriceStrategyViewDTO extends BaseViewDTO {

    /**
     * 开始时间
     */
    private Date startTime;

    /**
     * 结束时间
     */
    private Date endTime;

    /**
     * 产品分配预算
     */
    private Long budget;

    /**
     * 产品售价
     */
    private Long price;

    /**
     * 产品金额设置类型：1-最小比例、2-固定金额、3-起投金额
     * @see com.alibaba.ad.nb.packages.v2.client.constant.product.ProductAmountSettingTypeEnum
     */
    private Integer type;

    /**
     * 产品金额最小比例
     */
    private Integer minRatio;

    /**
     * 产品固定金额/起投金额（分）（页面上填写的产品金额，或者通过最小比例转换过来的金额）
     */
    private Long castAmount;


    /**
     * 策略预估数据
     */
    private PredictDataViewDTO predictDataViewDTO;
}
