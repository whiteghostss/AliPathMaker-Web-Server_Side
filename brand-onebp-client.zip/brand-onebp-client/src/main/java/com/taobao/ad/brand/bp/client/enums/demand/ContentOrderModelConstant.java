package com.taobao.ad.brand.bp.client.enums.demand;

public class ContentOrderModelConstant {

    /**
     * 先下单后确认资源
     */
    public static final String ORDER_FIRST_THEN_CONFIRM_RESOURCES = "order_first_then_confirm_resources";

    /**
     * 先确认资源后下单
     */
    public static final String CONFIRM_RESOURCES_FIRST_THEN_ORDER = "confirm_resources_first_then_order";
}
