package com.taobao.ad.brand.bp.client.dto.resourcepackage;

import java.util.List;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/02/22
 */
@Data
public class ResourceDistributionRuleViewDTO extends BaseViewDTO {
    /**
     * 产品组类别（N，A，B，C，D）
     */
    private String category;
    /**
     * 产品组类别名称
     */
    private String categoryName;
    /**
     * 产品组预算占比
     */
    private Integer ratio;
    /**
     * 最小产品个数
     */
    private Integer minQuality;
    /**
     * 最大产品个数
     */
    private Integer maxQuality;
    /**
     * 资源包产品列表
     */
    private List<ResourcePackageProductViewDTO> resourcePackageProductList;
}
