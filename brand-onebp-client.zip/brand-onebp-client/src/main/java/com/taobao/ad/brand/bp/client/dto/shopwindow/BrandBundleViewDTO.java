package com.taobao.ad.brand.bp.client.dto.shopwindow;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 套餐包
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class BrandBundleViewDTO extends BaseViewDTO {
    /**
     * 主键ID
     */
    private Long id;
    /**
     * 名称
     */
    private String name;
    /**
     * 文案描述
     */
    private String mark;
    /**
     * spuId
     */
    private Long spuId;
    /**
     * skuId
     */
    private Long skuId;
    /**
     * 最少预算
     */
    private Long minTotalBudget;
    /**
     * 最大预算
     */
    private Long maxTotalBudget;
    /**
     * 投放天数：最少几天
     */
    private Integer minDay;
    /**
     * 投放天数：最多几天
     */
    private Integer maxDay;
    /**
     * 套餐包状态，1：上线、-1：已删除
     */
    private Integer status;
}
