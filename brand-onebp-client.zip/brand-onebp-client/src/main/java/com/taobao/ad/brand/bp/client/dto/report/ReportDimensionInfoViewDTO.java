package com.taobao.ad.brand.bp.client.dto.report;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.fastjson.JSON;
import com.google.common.collect.Maps;
import lombok.*;

import java.util.Map;

/**
 * 报表维度属性对象
 * @author haicheng
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReportDimensionInfoViewDTO extends BaseViewDTO {

    /**
     * id
     */
    private String code;

    /**
     * 其他属性
     */
    private Map<String, Object> propertyMap;

    public static ReportDimensionInfoViewDTO of(String code, Map<String, Object> propertyMap) {
        ReportDimensionInfoViewDTO dto = new ReportDimensionInfoViewDTO();
        dto.setCode(code);
        dto.setPropertyMap(propertyMap);
        return dto;
    }

    public static ReportDimensionInfoViewDTO of(String code) {
        ReportDimensionInfoViewDTO model = new ReportDimensionInfoViewDTO();
        model.setCode(code);
        return model;
    }

    /**
     * 添加扩展属性
     * @param key
     * @param val
     */
    public void addProperty(String key , Object val) {
        if (val == null) {
            return;
        }
        if (key == null || key.equals("")) {
            return;
        }
        if (propertyMap == null) {
            propertyMap = Maps.newHashMap();
        }
        propertyMap.put(key, val);
    }


    /**
     * 获取扩展属性
     * @param key
     */
    public Object getPropertyVal(String key) {
        if (key == null || key.equals("") || propertyMap == null) {
            return null;
        }
        if (propertyMap.get(key) != null) {
            return propertyMap.get(key);
        }
        return null;
    }

    /**
     * 获取扩展属性
     * @param key
     */
    public <T> T getPropertyVal(String key, Class<T> clazz) {
        if (key == null || key.equals("") || propertyMap == null) {
            return null;
        }
        if(propertyMap.get(key) != null){
            String json = JSON.toJSONString(propertyMap.get(key));
            return JSON.parseObject(json, clazz);
        }
        return null;
    }

}
