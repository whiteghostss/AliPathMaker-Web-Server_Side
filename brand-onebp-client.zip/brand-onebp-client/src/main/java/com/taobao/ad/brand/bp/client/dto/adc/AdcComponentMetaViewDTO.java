package com.taobao.ad.brand.bp.client.dto.adc;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.ToString;

import java.util.Map;

/**
 * ADC配置信息
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@Data
@ToString
public class AdcComponentMetaViewDTO extends BaseViewDTO {
    /**
     * 组件id
     */
    private Long componentId;

    /**
     * 数据编码，对应enum-code
     */
    private String code;

    /**
     * 数据值，对应enum-value
     */
    private String value;

    /**
     * 数据名称
     */
    private String name;

    /**
     * 描述
     */
    private String description;

    /**
     * 帮助中心
     */
    private String assistant;

    /**
     * 规则JSON
     * @see UpgradeComponentRule
     */
    private String rule;

    /**
     * 排序
     */
    private Long sort;

    /**
     * 状态（1：有效；0：无效）
     */
    private Integer status;

    /**
     * 扩展信息
     */
    private Map<String, String> properties;
}
