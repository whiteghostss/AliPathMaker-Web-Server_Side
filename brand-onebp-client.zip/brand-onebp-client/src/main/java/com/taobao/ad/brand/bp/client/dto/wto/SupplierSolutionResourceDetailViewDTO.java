package com.taobao.ad.brand.bp.client.dto.wto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Data
public class SupplierSolutionResourceDetailViewDTO {
    private Long id;
    private Long solutionId;
    private Long resourceId;
    private Long pricePolicyVersionId;
    private Long sspProductId;
    private Date publishDate;
    private List<SupplierSolutionTalentConfigViewDTO> talentConfigList;
    private SupplierResourcePricePolicyViewDTO pricePolicy;
    private BigDecimal budget;
    private BigDecimal originalPrice;
    private Long unifiedMediaId;
}
