package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 下单客户信息
 *
 * @author 虫洞 <liuming.liu@alibaba-inc.com>
 * @date 2023/4/26
 */
@Getter
@Setter
@ToString
public class CampaignGroupCustomerMemberViewDTO extends BaseViewDTO {
    /**
     * 下单
     */
    private Long memberId;
    private Long customerMemberId;
    /**
     * @see com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupContractMemberTypeEnum
     */
    private Integer memberType;
}
