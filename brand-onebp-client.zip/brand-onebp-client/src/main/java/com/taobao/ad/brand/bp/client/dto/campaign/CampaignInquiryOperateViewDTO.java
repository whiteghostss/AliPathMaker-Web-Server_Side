package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.List;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/03/06
 */
@Data
public class CampaignInquiryOperateViewDTO extends BaseViewDTO {
    /**
     * 操作父子计划ID列表
     */
    private List<Long> campaignIdList;

    private String creatorId;

    private String creatorName;
    /**
     * 二次确认
     */
    private Integer confirm;
    /**
     * 强制占量原因
     */
    private String reason;
    /**
     * 排期文件url
     */
    private String url;

    /**
     * 库存操作方式
     * CampaignScheduleOperateTypeEnum
     */
    private Integer operateType;
    /**
     * 库存回调请求参数
     */
    private String inventoryResult;


}
