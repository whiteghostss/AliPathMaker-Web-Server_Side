package com.taobao.ad.brand.bp.client.context;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;
import java.util.List;


/**
 * 单元事件处理相关context
 * */
@Builder
@Data
public class AdgroupWakeUpUpdateContext implements Serializable {
    /**
     * 单元对象
     */
    private AdgroupViewDTO adgroupViewDTO;
    /**
     * 数据库单元对象
     */
    private AdgroupViewDTO dbAdgroupViewDTO;
    /**
     * 上下文
     */
    private ServiceContext serviceContext;
    /**
     * 创意集合
     */
    private List<CreativeViewDTO> creativeViewDTOList;

}
