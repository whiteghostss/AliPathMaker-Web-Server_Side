package com.taobao.ad.brand.bp.client.dto.qualification;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class QualificationViewDTO extends BaseViewDTO {

    /**
     * 一级-类别名称
     */
    private String typeName;
    /**
     * 资质id
     */
    private Long id;
    /**
     * 资质材料名称(资质模板，元素中的name就是他的值)
     */
    private String name;
    /**
     * 资质模板元素id
     */
    private Long elementId;
    /**
     * 上传该资质所用的模板
     */
    private Long templateId;
    /**
     * 资质内容列表。
     */
    private List<String> contentList;
    /**
     * 资质内容，是个contentList转化成的json字符串
     */
    private String content;
    /**
     * 资质审核状态 ：-3=未上传，-2=已过期，-1=拒绝，0=待审核，1=通过，2=即将过期，3=草稿
     */
    private Integer auditStatus = -3;
    /**
     * 资质是否固化，-1=删除，0=非固化，1=固化
     */
    private Integer effectStatus = 0;
    /**
     * 资质数据来源产品线
     */
    private Long productId;
    /**
     * dspid,淘系内部产品也统一成dsp
     */
    private Long dspId;

    /**
     * 资质生效时间
     */
    private Date startTime;
    /**
     * 资质失效时间
     */
    private Date endTime;
    /**
     * 资质创建时间
     */
    private Date createTime;
    /**
     * 资质修改时间
     */
    private Date updateTime;
    /**
     * 资质审核时间
     */
    private Date auditTime;
    /**
     * 审核员id
     */
    private Long operId;
    /**
     * 审核原因
     */
    private String reason;
    /**
     * 审核原因
     */
    private String newReason;
    /**
     * 审核备注
     */
    private String remark;
    /**
     * 提示信息
     */
    private String hint;
    /**
     * 是否必填(0-否,1-是)
     */
    private Integer optional;
    /**
     * 是否核心资质(0-否,1-是)
     */
    private Integer core;
    /**
     * 用户附加内容
     */
    private String supplement;
    /**
     * 主站标准品牌库品牌ID，品牌资质使用
     */
    private Long brandId;
}
