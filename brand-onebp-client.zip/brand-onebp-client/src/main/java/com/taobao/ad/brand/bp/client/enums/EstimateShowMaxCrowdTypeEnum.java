package com.taobao.ad.brand.bp.client.enums;

/**
 * 预估的showmax的人群类型
 * */
public enum EstimateShowMaxCrowdTypeEnum {
    BRAND(1, "品牌"),
    CATE(2, "类目")
    /*结束*/
    ;
    private final Integer value;
    private final String name;

    EstimateShowMaxCrowdTypeEnum(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    public Integer getValue() {
        return value;
    }

    public String getName() {
        return name;
    }

    public static EstimateShowMaxCrowdTypeEnum getByValue(Integer value) {
        for (EstimateShowMaxCrowdTypeEnum deliveryTargetEnum : EstimateShowMaxCrowdTypeEnum.values()) {
            if (deliveryTargetEnum.getValue().equals(value)) {
                return deliveryTargetEnum;
            }
        }
        return null;
    }
}
