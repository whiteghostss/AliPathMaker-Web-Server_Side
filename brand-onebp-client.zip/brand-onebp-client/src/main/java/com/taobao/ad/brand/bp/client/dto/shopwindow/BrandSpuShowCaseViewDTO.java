package com.taobao.ad.brand.bp.client.dto.shopwindow;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/6/27
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class BrandSpuShowCaseViewDTO extends BaseViewDTO {

    /**
     * 模板信息
     */
    private String src;

    /**
     * 配置信息
     */
    private String json;

    /**
     * showCase类型
     * @see com.taobao.ad.brand.perform.client.enums.shopwindow.ShowCaseTypeEnum
     */
    private Integer type;
}
