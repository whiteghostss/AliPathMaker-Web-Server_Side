package com.taobao.ad.brand.bp.client.enums;

/**
 * 协议
 */
public enum AgreementEnum {

    BRAND_SOFTWARE_SERVICE_AGREEMENT("产品服务协议", "阿里妈妈百灵软件服务协议");

    private String type;
    private String name;

    AgreementEnum(String type, String name) {
        this.type = type;
        this.name = name;
    }

    public String getType() { return type; }

    public String getName() { return name; }
}
