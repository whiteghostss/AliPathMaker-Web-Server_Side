package com.taobao.ad.brand.bp.client.dto.product;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.google.common.collect.Maps;
import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * @description: ProductDirectionViewDTO
 * @date: 2023/3/2 15:57
 * @author: yuanxinxi
 * @version: 1.0
 */
@Data
//TODO Direction->Target
public class ProductDirectionViewDTO extends BaseViewDTO {

        /**
         * 定向类型
         */
        private String type;
        private String typeName;
        /**
         * 定向值
         */
        private String value;
        private String name;
        /**
         * 子定向
         */
        private List<ProductDirectionViewDTO> subDirectionList;

        /**
         * 扩展属性
         */
        private Map<String, String> properties;
}
