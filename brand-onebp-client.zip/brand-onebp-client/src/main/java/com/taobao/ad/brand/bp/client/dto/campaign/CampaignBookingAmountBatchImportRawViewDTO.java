package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.ErrorMessageDTO;
import lombok.Data;

@Data
public class CampaignBookingAmountBatchImportRawViewDTO extends BaseViewDTO {
    private ErrorMessageDTO errorMessage;
    private Boolean isFiltered;
    private CampaignScheduleViewDTO campaignScheduleViewDTO;
}
