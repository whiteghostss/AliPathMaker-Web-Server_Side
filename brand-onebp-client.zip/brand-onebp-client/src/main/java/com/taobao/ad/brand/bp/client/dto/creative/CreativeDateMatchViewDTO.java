package com.taobao.ad.brand.bp.client.dto.creative;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import lombok.Data;

import java.util.Date;

/**
 * 全域通黑盒使用
 * 每个日期对应的媒体直投创意和程序化创意
 * 用于程序化创意->媒体直投创意的创建
 * */
@Data
public class CreativeDateMatchViewDTO extends BaseViewDTO {
    /**
     * 日期
     * */
    private Date date;
    /**
     * 媒体直投创意
     * */
    private CreativeViewDTO directCreativeViewDTO;
    /**
     * 程序化创意
     * */
    private CreativeViewDTO programCreativeViewDTO;


}
