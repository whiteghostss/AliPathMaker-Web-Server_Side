package com.taobao.ad.brand.bp.client.dto.campaigngroup;

import java.util.List;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;

import lombok.Data;

/**
 * 订单实结/结案结算信息
 *
 * @author yanjingang
 * @date 2023/3/24
 */
@Data
public class CampaignGroupSettleInfoViewDTO extends BaseViewDTO {

    /**
     * 订单ID
     */
    private Long id;

    /**
     * 订单状态
     * @see com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum
     */
    private Integer status;

    /**
     * 主合同ID
     */
    private Long contractId;

    /**
     * 投放账号ID
     */
    private Long memberId;

    /**
     * 实结内部流程状态
     * @see com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupProcessStatusEnum
     */
    private Integer realSettleProcessStatus;

    /**
     * 纯赠送子合同ID列表
     */
    private List<Long> giveSubContractIds;

    /**
     * 分组结算信息
     */
    private List<CampaignGroupSaleGroupSettleInfoViewDTO> saleGroupSettleInfoViewDTOList;
}
