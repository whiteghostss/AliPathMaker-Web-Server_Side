package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignInventoryAutoReleaseWarningTypeEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignProcessStatusEnum;
import lombok.Data;
import lombok.ToString;

import java.util.Date;

/**
 * @author jixiu.lj
 * @date 2023/8/4 15:23
 */
@Data
@ToString
public class CampaignInventoryAutoReleaseStatusViewDTO extends BaseViewDTO {

    /**
     * 计划ID
     */
    private Long campaignId;

    /**
     * 预警状态
     * @see com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum
     */
    private Integer warningStatus;

    /**
     * 预警类型
     * @see BrandCampaignInventoryAutoReleaseWarningTypeEnum
     */
    private Integer warningType;

    /**
     * 释量状态
     * @see com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum
     */
    private Integer releaseStatus;

    /**
     * 锁量有效期，用于回执履约更新与前端展示
     */
    private Date lockExpireTime;

    /**
     * 是否已申请延期（是：已申请延期或不可申请延期，否：可以申请但未申请）
     */
    private Integer delayApplyQualifyStatus;


    /**
     * 延期申请状态
     * @see BrandCampaignProcessStatusEnum
     */
    private Integer delayReleaseProcessStatus;
}
