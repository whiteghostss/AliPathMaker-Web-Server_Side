package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;

import com.taobao.ad.brand.bp.client.enums.campaign.CampaignProductPriceTypeEnum;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

/**
 * @author <wangxin> chuxian.wx@alibaba-inc.com
 * @date 2023/2/27
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class CampaignDayPriceViewDTO extends BaseViewDTO {
    /**
     * 开始时间
     */
    private Date startDate;
    /**
     * 日期
     */
    private Date endDate;
    /**
     * 折后价，单位为分
     */
    private Long discountPrice;
    /**
     * 刊例价，单位为分
     */
    private Long publishPrice;
    /**
     * 预算分配方式
     *
     * @see CampaignProductPriceTypeEnum
     */
    private Integer budgetAssignMode;
    /**
     * 最小折扣比例
     */
    private Integer minBudgetRatio;
    /**
     * 固定金额
     */
    private Long fixedBudget;
    /**
     * 最小起投金额
     */
    private Long minCastBudget;

    /**
     * 价格折扣
     */
    private Long discountRatio;

    /**
     * cpt预定量
     */
    private Long cptAmount;

}
