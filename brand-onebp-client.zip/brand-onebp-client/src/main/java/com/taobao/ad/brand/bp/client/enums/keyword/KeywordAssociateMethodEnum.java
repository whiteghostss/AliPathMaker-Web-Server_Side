package com.taobao.ad.brand.bp.client.enums.keyword;

import lombok.Getter;

/**
 * 关键词联想方式
 */
@Getter
public enum KeywordAssociateMethodEnum {
    BRAND_ASSOCIATE(1, "品牌联想"),
    KEYWORD_ASSOCIATE(2, "关键词联想"),
    ;

    private Integer code;
    private String desc;

    KeywordAssociateMethodEnum(Integer code, String desc){
        this.code = code;
        this.desc = desc;
    }
}
