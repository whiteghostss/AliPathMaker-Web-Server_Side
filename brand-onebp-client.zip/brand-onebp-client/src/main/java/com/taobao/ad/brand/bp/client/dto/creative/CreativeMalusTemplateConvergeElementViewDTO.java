package com.taobao.ad.brand.bp.client.dto.creative;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;

import java.util.List;

/**
 * 海棠智能聚合元素
 * @date 2024/8/13 13:10
 */
@Data
public class CreativeMalusTemplateConvergeElementViewDTO extends BaseViewDTO {
    /**
     * 主图片
     */
    private CreativeMalusTemplateFileElementViewDTO mainImage;
    /**
     * 扩展图片
     */
    private List<CreativeMalusTemplateFileElementViewDTO> extendImages;

    /**
     * 主视频
     */
    private CreativeMalusTemplateFileElementViewDTO mainVideo;
    /**
     * 扩展视频
     */
    private List<CreativeMalusTemplateFileElementViewDTO> extendVideos;
}
