package com.taobao.ad.brand.bp.client.dto.campaign;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.TreeNodeViewDTO;
import lombok.Data;

import java.util.List;

@Data
public class CampaignShowConfigViewDTO extends BaseViewDTO {
    /**
     * 定向类型（取SSP产品定向Key）
     * age_plus：年龄、gender_plus：性别、area：地域、model：设备机型、channel：频道、
     * timeLeng_plus：素材时长、pushPge：PDB推送、terminal：设备类型、app：应用类型、
     * os：操作系统、saleUnit：预定方式、processExpand：投中扩量、targetOptimization：分目标优化、
     * multi_media：媒体  third_monitor 第三方监测(0-常规,1-分端), 全域标签
     */
    private String type;
    /**
     * 定向值
     */
    private List<String> values;
    /**
     * 定向具体值（展示用）
     */
    private List<TreeNodeViewDTO> configs;
}
