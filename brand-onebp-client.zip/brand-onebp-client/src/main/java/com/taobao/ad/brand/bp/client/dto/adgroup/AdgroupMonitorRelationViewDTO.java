package com.taobao.ad.brand.bp.client.dto.adgroup;

import com.alibaba.ad.brand.dto.common.BottomDateViewDTO;
import lombok.Data;

import java.util.List;

/**
 * 用来请求监测的临时ViewDTO
 * @author 弈云
 * @data 2023年04月04日
 * */
@Data
public class AdgroupMonitorRelationViewDTO {
    /**
     * 订单ID
     * */
    private Long campaignGroupId;
    /**
     * 单元ID
     * */
    private Long adgroupId;
    /**
     * 计划ID
     * */
    private Long campaignId;
    /**
     * 子计划ID
     * */
    private Long subCampaignId;
    /**
     * 创意打底日期
     * */
    private List<BottomDateViewDTO> bottomDateViewDTOList;
    /**
     * 创意ID
     * */
    private Long creativeId;
    /**
     * 推广位ID
     * */
    private Long adzoneId;
    /**
     * 妈妈三段式PID
     * */
    private String pid;

    /**
     * 采购行id
     */
    private Long purchaseRowId;


    /**
     * 生成的监测存储，用于过程
     * */
    private AdgroupMonitorCodeViewDTO monitorCodeViewDTO;

}
