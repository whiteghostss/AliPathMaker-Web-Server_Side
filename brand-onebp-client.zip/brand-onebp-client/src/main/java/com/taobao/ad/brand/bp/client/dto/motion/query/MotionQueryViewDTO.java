package com.taobao.ad.brand.bp.client.dto.motion.query;

import com.taobao.ad.brand.bp.client.dto.base.BaseQueryViewDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/18
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MotionQueryViewDTO extends BaseQueryViewDTO {

    private List<Long> idList;
    private String name;
    private Long memberId;
    private String creator;
    private List<Integer> statusList;
    /**
     * 开始时间
     */
    private Date startTime;

    /**
     * 结束时间
     */
    private Date endTime;
    private Integer source;
}
