package com.taobao.ad.brand.bp.client.dto.creative;

import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.creative.setting.BrandCreativeSettingKeyEnum;
import com.taobao.ad.brand.bp.client.dto.base.BaseQueryViewDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/3/14 16:35
 * @description ：
 * @modified By：
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CreativeQueryViewDTO extends BaseQueryViewDTO {
    /**
     * 创意id集合
     * 查询优先级：ids > adgroupId > campaignId > campaignGroupId
     */
    private List<Long> ids;
    /**
     * 订单ID
     */
    private Long campaignGroupId;

    /**
     * 计划ID
     */
    private List<Long> campaignIds;

    /**
     * 单元ID
     */
    private List<Long> adgroupIds;

    /**
     * 仅支持name模糊查询
     */
    private String name;

    /**
     * 创意模板
     */
    private List<Long> sspTemplateIds;

    /**
     * 创意审核状态（聚合后审核状态：包含风控和媒体审核状态）
     */
    private List<Integer> showAuditStatusList;

    /**
     * 资源类型
     */
    private Integer resourceType;

    /**
     * 投放类型
     *
     * @see com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativeTargetTypeEnum
     */
    private Integer targetType;

    /**
     * 是否关联单元
     */
    private Integer hadBoundAdgroup;

    /**
     * 是否TOP
     *
     * @see BrandBoolEnum
     */
    private Integer isTop;

    /**
     * 开始时间
     */
    private Date startTime;
    /**
     * 结束时间
     */
    private Date endTime;

    /**
     * DB小于等于 创意结束时间&&创意过期时间，用户设置
     * 传入当前时间表示获取已过期创意
     */
    private Date leEndTime;

    /**
     * 指定创建时间之后的数据
     */
    private Date queryAfterGmtCreateTime;

    /**
     * 大于创意结束时间
     */
    private Date queryAfterEndTime;

    /**
     * 广告主设置的状态
     */
    private Integer onlineStatus;

    /**
     * 创意联动方式
     */
    private Integer linkageMode;

    /**
     * 创意包ID集合
     */
    private List<Long> creativePackageIdList;


    /**
     * 创意包类型
     * {@link com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativePackageTypeEnum}
     */
    private Integer packageType;


    private Boolean creativeIdEqCreativePackageId = Boolean.TRUE;


    /**
     * {@link  BrandCreativeSettingKeyEnum#IS_REQUIRED}
     */
    private Integer isRequired;


    /**
     * 创意标签版本ID集合
     */
    private List<Long> creativeTagIdList;
}
