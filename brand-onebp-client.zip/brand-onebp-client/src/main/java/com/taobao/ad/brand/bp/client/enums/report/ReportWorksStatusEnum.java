package com.taobao.ad.brand.bp.client.enums.report;


import com.taobao.ad.brand.bp.client.enums.CommonEnum;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;

@AllArgsConstructor(access = AccessLevel.PACKAGE)
public enum ReportWorksStatusEnum implements CommonEnum {

    CONFIGURED(1, "已配置"),
    UN_CONFIGURED(0, "未配置");

    private final Integer value;
    private final String desc;

    @Override
    public int getValue() {
        return value;
    }

    @Override
    public String getDesc() {
        return desc;
    }

    public static String getDescById(int value) {
        for (ReportWorksStatusEnum work : ReportWorksStatusEnum.values()) {
            if (work.getValue() == value) {
                return work.getDesc();
            }
        }

        return null;
    }
}
