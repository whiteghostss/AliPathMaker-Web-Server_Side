package com.taobao.ad.brand.bp.client.api.brand;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.ad.brand.dto.common.BrandViewDTO;
import com.alibaba.hermes.framework.api.QueryAPI;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.taobao.ad.brand.bp.client.dto.brand.BrandQueryViewDTO;

import java.util.List;

/**
 * @author yanjingang
 * @date 2025/5/12
 */
public interface BizBrandQueryService extends QueryAPI {
    String TAG = "Brand";
    /**
     *
     * @param context
     * @param query
     * @return
     */
    @ProcessEntrance(name = "分页查询", desc = "分页查询", opType = OpType.query, tag = TAG)
    MultiResponse<BrandViewDTO> findBrandList(ServiceContext context, BrandQueryViewDTO query);

    /**
     *
     * @param context
     * @param brandIds
     * @return
     */
    @ProcessEntrance(name = "根据品牌ID查询", desc = "根据品牌ID查询", opType = OpType.query, tag = TAG)
    MultiResponse<BrandViewDTO> getBrandList(ServiceContext context, List<Long> brandIds);

}
