package com.taobao.ad.brand.bp.client.dto.oplog;

import com.taobao.ad.brand.bp.client.dto.base.BaseQueryViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.List;

/**
 * @author jixiu.lj
 * @date 2024/3/20 14:46
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class OpLogQueryViewDTO extends BaseQueryViewDTO {
    private static final long serialVersionUID = -84322395430839710L;
    /**
     * 查询开始时间
     */
    private Date startTime;

    /**
     * 查询结束时间
     */
    private Date endTime;

    /**
     * 业务场景
     */
    private String bizCode;

    /**
     * 操作类型
     * @see "BaseServiceContext#operType"
     */
    private Integer operType;

    /**
     *  操作类型 in 查询
     */
    private List<Integer> operTypeList;

    /**
     * 用户所选实体类型
     */
    private String entityCode;

    /**
     * 用户所选操作类型
     */
    private String operateCode;

    /**
     * 用户所选操作详情
     */
    private String operateDetailCode;

    /**
     * 实体ID筛选
     */
    private List<Long> entityIds;

    /**
     * 实体类型
     * @see "EntityTypecom.alibaba.ad.oplog.job.sdk.constants.EntityType#value"
     */
    private List<Integer> entityTypes;

    /**
     * 日志模板key
     */
    private List<Long> templateKeys;

    /**
     * 计划ID查询
     */
    private List<Long> campaignIdIn;

    /**
     * 单元ID查询
     */
    private List<Long> adgroupIdIn;
}
