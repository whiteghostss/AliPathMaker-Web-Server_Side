package com.taobao.ad.brand.bp.client.dto.shopwindow;

import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/7/1
 **/
@EqualsAndHashCode(callSuper = true)
@Data
public class BrandCoverConfigViewDTO extends BaseViewDTO {

    /**
     * 封面图
     */
    private String coverUrl;

    /**
     * 封面图类型
     * com.taobao.ad.brand.perform.client.enums.shopwindow.CoverTypeEnum
     */
    private String coverType;

    /**
     * 视频首帧图，用于百灵展示性能优化
     */
    private String thumb;
}
