package com.taobao.ad.brand.bp.client.dto.inventory;

import com.alibaba.abf.governance.dto.BaseViewDTO;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author jixiu.lj
 * @date 2023/3/21 09:02
 */
@Data
public class InventoryDetailsDayAmountViewDTO extends BaseViewDTO {
    /**
     * @see com.alimama.inventory.dto.ud.InventoryUdBaseDTO.ProgramMode
     */
    private Integer programMode;
    /**
     * 天
     */
    private Date day;

    /**
     * 量
     */
    private Integer amount;

//    /**
//     * 库存分配明细列表
//     */
//    private List<InventoryDetailsAssignViewDTO> assignDetailsList;
}
