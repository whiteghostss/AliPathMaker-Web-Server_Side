package com.taobao.ad.brand.bp.app.workflow.solution;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.selfservice.CampaignSelfServiceViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.brand.dto.creative.malus.CreativeMalusViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignOnlineStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupLevelEnum;
import com.alibaba.ad.brand.sdk.constant.cartitem.BrandCartItemStatusEnum;
import com.alibaba.ad.brand.sdk.constant.cartitem.BrandCartItemTypeEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativeTargetTypeEnum;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativeTemplateDataSourceEnum;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.app.businessability.MultiTargetDeliverBusinessAbility;
import com.taobao.ad.brand.bp.app.spi.campaign.inventory.BizCampaignInventorySpi;
import com.taobao.ad.brand.bp.app.spi.solution.CartItemSolutionCommandOperateSpi;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignCommandWorkflow;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignInventoryWorkflow;
import com.taobao.ad.brand.bp.app.workflow.campaigngroup.BizCampaignGroupCommandWorkflow;
import com.taobao.ad.brand.bp.app.workflow.cartitem.BizCartItemCommandWorkflow;
import com.taobao.ad.brand.bp.app.workflow.creative.BizCreativeCommandWorkflow;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupOrderCommandViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupEstimateInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeMalusTemplateViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeSaveViewDTO;
import com.taobao.ad.brand.bp.client.dto.solution.CartItemSolutionOrderViewDTO;
import com.taobao.ad.brand.bp.client.dto.solution.CartItemSolutionViewDTO;
import com.taobao.ad.brand.bp.client.dto.solution.query.CartItemSolutionQueryOption;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignScheduleIsInventoryEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.converter.solution.CartItemSolutionViewDTOConverter;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.cart.repository.CartItemRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbilityRouteContext;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.inventory.ICampaignInquiryChannelGetForCampaignInventoryOperateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignInventoryOperateChannelGetAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupInitForCartItemSolutionAddOrUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupInitForCartItemSolutionAddOrUpdateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.businessability.ICartItemSolutionPreOrderBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.ICreativeNameInitAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeNameInitAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.solution.atomability.ISolutionCommandInitForAddCartItemSolutionAbility;
import com.taobao.ad.brand.bp.domain.sdk.solution.atomability.param.CartItemSolutionCommandAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

import static com.alibaba.abf.isolation.utils.AbilityInvoker.invoke;
import static com.taobao.ad.brand.bp.common.spi.ExtensionPointsFactory.runAbilitySpi;

@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizSolutionCommandWorkflow {

    private final BizCartItemCommandWorkflow bizCartItemCommandWorkflow;
    private final BizCampaignGroupCommandWorkflow bizCampaignGroupCommandWorkflow;
    private final BizCampaignCommandWorkflow bizCampaignCommandWorkflow;
    private final BizSolutionQueryWorkWorkflow bizSolutionQueryWorkWorkflow;
    private final BizCreativeCommandWorkflow bizCreativeCommandWorkflow;
    private final BizCampaignInventoryWorkflow bizCampaignInventoryWorkflow;
    private final ISolutionCommandInitForAddCartItemSolutionAbility solutionCommandInitForAddCartItemSolutionAbility;
    private final ICampaignGroupInitForCartItemSolutionAddOrUpdateAbility campaignGroupInitForCartItemSolutionAddOrUpdateAbility;
    private final ICampaignInquiryChannelGetForCampaignInventoryOperateAbility campaignInquiryChannelGetForCampaignInventoryOperateAbility;
    private final ICampaignStructureQueryAbility campaignStructureQueryAbility;
    private final ICreativeNameInitAbility creativeNameInitAbility;
    private final CartItemRepository cartItemRepository;
    private final CampaignGroupRepository campaignGroupRepository;
    private final CartItemSolutionViewDTOConverter cartItemSolutionViewDTOConverter;

    /**
     * 自助化场景一站式解决方案（新建场景）
     * @param serviceContext
     * @param solutionCommandViewDTO
     * @return
     */
    public Long addCartItemSolution(ServiceContext serviceContext, CartItemSolutionViewDTO solutionCommandViewDTO){
        try {
            //新增校验
            runAbilitySpi(CartItemSolutionCommandOperateSpi.class,
                    extension -> extension.validateForAddCartItemSolution(serviceContext, solutionCommandViewDTO),
                    CartItemSolutionCommandOperateSpi.getSpiCode(solutionCommandViewDTO));
            //初始化
            solutionCommandInitForAddCartItemSolutionAbility.handle(serviceContext,
                    CartItemSolutionCommandAbilityParam.builder().abilityTarget(solutionCommandViewDTO).build());
            //保存加购行
            CartItemViewDTO cartItemViewDTO = cartItemSolutionViewDTOConverter.convertDTO2ViewDTO(solutionCommandViewDTO);
            Long cartItemId = bizCartItemCommandWorkflow.addCartItem(serviceContext, cartItemViewDTO);
            solutionCommandViewDTO.setId(cartItemId);
            RogerLogger.info("极简版加购行创建成功，cartItemId={}",cartItemId);
            //保存计划
            CampaignViewDTO campaignViewDTO = solutionCommandViewDTO.getCampaignViewDTO();
            CampaignSelfServiceViewDTO campaignSelfServiceViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignSelfServiceViewDTO()).orElse(new CampaignSelfServiceViewDTO());
            campaignSelfServiceViewDTO.setCartItemId(cartItemId);
            campaignViewDTO.setCampaignSelfServiceViewDTO(campaignSelfServiceViewDTO);
            bizCampaignCommandWorkflow.addCampaign(serviceContext, campaignViewDTO);
            RogerLogger.info("极简版加购行关联计划创建成功，cartItemId={}，campaignId={}",cartItemId,campaignViewDTO.getId());
            //计划锁量成功后，保存单元/创意
            return cartItemId;
        } catch (Exception exception) {
            RogerLogger.error("极简版投放创建失败",exception);
            Optional.ofNullable(solutionCommandViewDTO.getId()).ifPresent(cartItemId ->
                    cartItemRepository.deleteCartItem(serviceContext, Collections.singletonList(cartItemId)));
            throw exception;
        }
    }

    /**
     * 自助化场景一站式解决方案（修改场景）
     * @param serviceContext
     * @param solutionCommandViewDTO
     * @return
     */
    public Long updateCartItemSolution(ServiceContext serviceContext, CartItemSolutionViewDTO solutionCommandViewDTO){
        Long cartItemId = solutionCommandViewDTO.getId();
        AssertUtil.notNull(cartItemId,"参数ID不允许为空");

        CartItemSolutionViewDTO dbSolutionCommandViewDTO = bizSolutionQueryWorkWorkflow.getCartItemSolutionInfo(serviceContext, cartItemId,
                CartItemSolutionQueryOption.builder().needAdgroup(false).build());
        AssertUtil.notNull(dbSolutionCommandViewDTO,String.format("数据不存在，id=%s", cartItemId));
        //数据校验
        runAbilitySpi(CartItemSolutionCommandOperateSpi.class,
                extension -> extension.validateForUpdateCartItemSolution(serviceContext, dbSolutionCommandViewDTO,
                        solutionCommandViewDTO), CartItemSolutionCommandOperateSpi.getSpiCode(solutionCommandViewDTO));
        //数据初始化
        runAbilitySpi(CartItemSolutionCommandOperateSpi.class,
                extension -> extension.initForUpdateCartItemSolution(serviceContext, dbSolutionCommandViewDTO,
                        solutionCommandViewDTO), CartItemSolutionCommandOperateSpi.getSpiCode(solutionCommandViewDTO));

        //数据保存
        runAbilitySpi(CartItemSolutionCommandOperateSpi.class,
                extension -> extension.executeForUpdateCartItemSolution(serviceContext, dbSolutionCommandViewDTO,
                        solutionCommandViewDTO), CartItemSolutionCommandOperateSpi.getSpiCode(solutionCommandViewDTO));

        return cartItemId;
    }

    public List<CampaignGroupSaleGroupEstimateInfoViewDTO> estimateForSelfServiceSlimOrder(ServiceContext context, CartItemViewDTO cartItemViewDTO, CampaignGroupViewDTO campaignGroupViewDTO, List<CampaignViewDTO> campaignViewDTOList) {
        BusinessAbilityRouteContext businessAbilityRouteContext = BusinessAbilityRouteContext.builder().specifiedBusinessAbilityCodes(Lists.newArrayList(MultiTargetDeliverBusinessAbility.ABILITY_CODE)).build();
        return invoke(ICartItemSolutionPreOrderBusinessAbilityPoint.class, businessAbilityRouteContext,
                callBack -> callBack.invokeForCartItemSolutionPreOrder(context, cartItemViewDTO, campaignGroupViewDTO, campaignViewDTOList, businessAbilityRouteContext));

    }

    public Long orderCartItemSolution(ServiceContext serviceContext, CartItemSolutionOrderViewDTO solutionOrderViewDTO) {
        AssertUtil.notNull(solutionOrderViewDTO.getId(),"参数ID不允许为空");
        CartItemViewDTO cartItemViewDTO = cartItemRepository.getCartById(serviceContext, solutionOrderViewDTO.getId());
        AssertUtil.notNull(cartItemViewDTO,"加购行不存在");
        CampaignGroupViewDTO campaignGroup = campaignGroupRepository.getCampaignGroup(serviceContext, cartItemViewDTO.getCampaignGroupId());
        AssertUtil.notNull(campaignGroup,"订单不存在");
        CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder().cartItemIds(Lists.newArrayList(solutionOrderViewDTO.getId()))
                .campaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode()).onlineStatusList(BizCampaignToolsHelper.getCampaignOnlineStatusList()).build();
        List<CampaignViewDTO> campaignViewDTOList = campaignStructureQueryAbility.handle(serviceContext,
                CampaignStructureQueryAbilityParam.builder().abilityTarget(campaignQueryViewDTO).queryOption(CampaignQueryOption.builder().needChildren(true).build()).build());
        AssertUtil.notEmpty(campaignViewDTOList,"计划不存在");
        // 1.校验
        validateCartItemSolutionOrder(serviceContext, solutionOrderViewDTO, cartItemViewDTO, campaignGroup, campaignViewDTOList);
        // 2.订单下单
        CampaignGroupOrderCommandViewDTO campaignGroupOrderViewDTO = new CampaignGroupOrderCommandViewDTO();
        campaignGroupOrderViewDTO.setId(campaignGroup.getId());
        campaignGroupOrderViewDTO.setSaleGroupIds(campaignGroup.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream()
                .map(SaleGroupInfoViewDTO::getSaleGroupId)
                .collect(Collectors.toList()));
        campaignGroupOrderViewDTO.setSignScheduleUrl(solutionOrderViewDTO.getSignScheduleUrl());
        campaignGroupOrderViewDTO.setContactPhone(solutionOrderViewDTO.getContactPhone());
        bizCampaignGroupCommandWorkflow.orderForCartItemSolution(serviceContext, campaignGroupOrderViewDTO, campaignGroup, campaignViewDTOList);
        // 3. 更新计划对客可见
        bizCampaignCommandWorkflow.updateCampaignOnlineStatus(serviceContext, campaignViewDTOList, BrandCampaignOnlineStatusEnum.ONLINE);
        // 4. 设置加购行下单状态
        updateCartItemOrderStatus(serviceContext, cartItemViewDTO);

        return campaignGroup.getId();
    }

    /**
     * 删除方案
     *
     * @param serviceContext
     * @param id
     */
    public void deleteCartItemSolution(ServiceContext serviceContext, Long id) {
        AssertUtil.notNull(id,"参数ID不允许为空");
        CartItemViewDTO cartItemViewDTO = cartItemRepository.getCartById(serviceContext, id);
        if (cartItemViewDTO != null) {
            AssertUtil.assertTrue(!BrandCartItemStatusEnum.ORDER_SUCCESS.getCode().equals(cartItemViewDTO.getStatus()), "商品已购买，如需再次购买请刷新页面后重新操作。");
            cartItemRepository.deleteCartItem(serviceContext, Lists.newArrayList(id));
        }
    }

    public void unbindCartItemSolution(ServiceContext serviceContext, Long cartItemId) {
        AssertUtil.notNull(cartItemId,"参数ID不允许为空");
        // 1、查询加购行
        CartItemSolutionViewDTO dbSolutionCommandViewDTO = bizSolutionQueryWorkWorkflow.getCartItemSolutionInfo(serviceContext, cartItemId, CartItemSolutionQueryOption.builder().needDeleted(true).needAdgroup(false).build());
        AssertUtil.notNull(dbSolutionCommandViewDTO,String.format("数据不存在，id=%s", cartItemId));

        // 2、计划释量
        if (dbSolutionCommandViewDTO.getCampaignViewDTO() != null) {
            List<CampaignViewDTO> campaignTreeList = Lists.newArrayList(dbSolutionCommandViewDTO.getCampaignViewDTO());
            if (BrandCampaignStatusEnum.LOCK_SUCCESS.getCode().equals(dbSolutionCommandViewDTO.getCampaignViewDTO().getStatus())) {
                // 计划释量
                try {
                    // 对计划按是否走库存拆分，然后进行SPI扩展释量
                    Map<Integer, List<CampaignViewDTO>> isInventoryCampaignMap = campaignInquiryChannelGetForCampaignInventoryOperateAbility.handle(serviceContext, CampaignInventoryOperateChannelGetAbilityParam.builder().abilityTargets(campaignTreeList).build());
                    for (Map.Entry<Integer, List<CampaignViewDTO>> isInventoryCampaignEntry : isInventoryCampaignMap.entrySet()) {
                        runAbilitySpi(BizCampaignInventorySpi.class, extension -> extension.releaseCampaign(serviceContext, isInventoryCampaignEntry.getValue()), CampaignScheduleIsInventoryEnum.getByValue(isInventoryCampaignEntry.getKey()).name());
                    }
                } catch (Exception e) {
                    RogerLogger.info("释量失败： {}", e);
                }
            }
        }

        // 3、删除订单
        if (dbSolutionCommandViewDTO.getCampaignGroupId() != null && dbSolutionCommandViewDTO.getCampaignGroupId() != 0L) {
            bizCampaignGroupCommandWorkflow.deleteSelfServiceCampaignGroup(serviceContext, dbSolutionCommandViewDTO.getCampaignGroupId());
        }
    }

    private void updateCartItemOrderStatus(ServiceContext serviceContext, CartItemViewDTO cartItemViewDTO) {
        CartItemViewDTO updateCartItemViewDTO = new CartItemViewDTO();
        updateCartItemViewDTO.setId(cartItemViewDTO.getId());
        updateCartItemViewDTO.setStatus(BrandCartItemStatusEnum.ORDER_SUCCESS.getCode());
        cartItemRepository.updateCartPart(serviceContext, updateCartItemViewDTO);
    }

    private void validateCartItemSolutionOrder(ServiceContext serviceContext, CartItemSolutionOrderViewDTO solutionOrderViewDTO, CartItemViewDTO cartItemViewDTO, CampaignGroupViewDTO campaignGroup, List<CampaignViewDTO> campaignViewDTOList) {
        AssertUtil.notNull(solutionOrderViewDTO.getContactPhone(),"联系电话不允许为空");
        // 加购行下单校验
        bizCartItemCommandWorkflow.validateCartItemOrder(serviceContext, Lists.newArrayList(cartItemViewDTO), campaignViewDTOList);
    }

    /**
     * 极简版下单-保存创意
     * @param serviceContext
     * @param campaignViewDTO
     * @return
     */
    public List<Long> saveCreative(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {
        Long cartItemId = campaignViewDTO.getCampaignSelfServiceViewDTO().getCartItemId();
        if (cartItemId == null) {
            return Lists.newArrayList();
        }
        CartItemViewDTO cartItemViewDTO = cartItemRepository.getCartById(serviceContext, cartItemId);
        AssertUtil.notNull(cartItemViewDTO, String.format("计划关联加购行不存在，计划id：%s", campaignViewDTO.getId()));
        if(!BrandCartItemTypeEnum.SLIM_ORDER.getCode().equals(cartItemViewDTO.getType())){
            RogerLogger.info("加购行非极简版类型不进行创意创建，cartItemId={}",cartItemId);
            return Lists.newArrayList();
        }
        List<CreativeViewDTO> creativeViewDTOList = cartItemViewDTO.getCreativeViewDTOList();
        if (CollectionUtils.isEmpty(creativeViewDTOList)) {
            return Lists.newArrayList();
        }
        //基于临时创意构建正式创意，统一构建完成后在进行创建
        List<CreativeViewDTO> realCreativeViewDTOList = creativeViewDTOList.stream().flatMap(tmpCreativeViewDTO ->
                buildRealCreative(serviceContext, campaignViewDTO, tmpCreativeViewDTO).stream()).collect(Collectors.toList());
        List<Long> creativeIds = Lists.newArrayList();
        for (CreativeViewDTO viewDTO : realCreativeViewDTOList) {
            viewDTO.setBizUniqueKey(String.format("solution_%s",getSolutionCreativeUniqueKey(viewDTO.getCreativeMalus())));
            Long creativeId = bizCreativeCommandWorkflow.addCreative(serviceContext, viewDTO);
            creativeIds.add(creativeId);
        }
        return creativeIds;
    }

    public List<CampaignGroupViewDTO> addCampaignGroup(ServiceContext serviceContext, CartItemViewDTO cartItemViewDTO) {
        // 创建订单
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupInitForCartItemSolutionAddOrUpdateAbility.handle(serviceContext,
                CampaignGroupInitForCartItemSolutionAddOrUpdateAbilityParam.builder().abilityTarget(cartItemViewDTO).build());
        AssertUtil.notNull(campaignGroupViewDTO , BrandOneBPBaseErrorCode.INTERNAL_ERROR,"构建订单信息失败");

        List<CampaignGroupViewDTO> campaignGroupViewDTOList = bizCampaignGroupCommandWorkflow.addCampaignGroupForSelfService(serviceContext, campaignGroupViewDTO);
        CampaignGroupViewDTO subCampaignGroup = campaignGroupViewDTOList.stream().filter(campaignGroup -> BrandCampaignGroupLevelEnum.LEVEL_TWO.getCode()
                .equals(campaignGroup.getCampaignGroupLevel())).findFirst().orElse(null);
        AssertUtil.notNull(subCampaignGroup , BrandOneBPBaseErrorCode.INTERNAL_ERROR,"订单创建失败");

        return campaignGroupViewDTOList;
    }

    /**
     * 读取创意预览链接
     * 如：http://kb-render.alicdn.com/html/451925/2024/10/17/27e526a3-a46f5ff3-291928802.html
     * @param creativeMalus
     * @return 27e526a3-a46f5ff3-291928802.html
     */
    private String getSolutionCreativeUniqueKey(CreativeMalusViewDTO creativeMalus) {
        String jsInHtml = creativeMalus.getJsInHtml();
        Integer templateDataSource = Objects.nonNull(creativeMalus.getTemplateDataSource()) ? creativeMalus.getTemplateDataSource() : BrandCreativeTemplateDataSourceEnum.MALUS.getCode();
        if (StringUtils.isBlank(jsInHtml) && StringUtils.isNotBlank(creativeMalus.getCcParaString())) {
            List<CreativeMalusTemplateViewDTO> creativeMalusTemplateList =
                    JSON.parseArray(creativeMalus.getCcParaString(), CreativeMalusTemplateViewDTO.class);
            jsInHtml = creativeMalusTemplateList.get(0).getJsInHtml();
        }
        if (BrandCreativeTemplateDataSourceEnum.BRAND.getCode().equals(templateDataSource)) {
            return DigestUtils.md5Hex(creativeMalus.getTemplateData());
        } else {
            AssertUtil.notNull(jsInHtml, "创意预览配置为空，请检查创意");
            int start = jsInHtml.lastIndexOf("/");
            if (start != -1) {
                return jsInHtml.substring(start + 1);
            }
        }
        return jsInHtml;
    }

    private List<CreativeViewDTO> buildRealCreative(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, CreativeViewDTO creativeViewDTO) {
        CreativeSaveViewDTO creativeSaveViewDTO = new CreativeSaveViewDTO();
        creativeSaveViewDTO.setCreativeSource(creativeViewDTO.getCreativeSource());
        creativeSaveViewDTO.setCreativeScope(creativeViewDTO.getCreativeScope());
        creativeSaveViewDTO.setIsTop(BrandBoolEnum.BRAND_FALSE.getCode());
        creativeSaveViewDTO.setTargetType(BrandCreativeTargetTypeEnum.PROGRAM.getCode());
        creativeSaveViewDTO.setTemplateId(creativeViewDTO.getCreativeTemplate().getSspTemplateId());
        creativeSaveViewDTO.setStartTime(campaignViewDTO.getStartTime());
        creativeSaveViewDTO.setEndTime(campaignViewDTO.getEndTime());
        String ccParaString = creativeViewDTO.getCreativeMalus().getCcParaString();
        List<CreativeMalusTemplateViewDTO> creativeMalusTemplateViewDTOList =
                JSON.parseArray(ccParaString, CreativeMalusTemplateViewDTO.class);
        creativeSaveViewDTO.setTemplateDatum(creativeMalusTemplateViewDTOList);
        //构建创意名称
        String creativeName = creativeNameInitAbility.handle(serviceContext, CreativeNameInitAbilityParam.builder()
                .abilityTarget(creativeSaveViewDTO).campaignViewDTO(campaignViewDTO).build());
        creativeSaveViewDTO.setName(creativeName);

        return bizCreativeCommandWorkflow.convertCreative(serviceContext, creativeSaveViewDTO);
    }

}
