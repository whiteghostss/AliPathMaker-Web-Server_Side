package com.taobao.ad.brand.bp.app.workflow.insight;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.dto.agent.LlmAgentDirectCallParamViewDTO;
import com.taobao.ad.brand.bp.client.dto.insight.WinInsightQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.insight.WinInsightDimenisonTypeEnum;
import com.taobao.ad.brand.bp.client.enums.insight.WinInsightMetricsEnum;
import com.taobao.ad.brand.bp.client.enums.report.ReportTotalTypeEnum;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.agent.AgentRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * 加购行流程
 *
 * @author shiyan
 * @date 2024/06/26
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class WinSmartInsightWorkflow {

    private final WinInsightQueryWorkflow winInsightQueryWorkflow;
    private final AgentRepository agentRepository;

    private static final String agentName = "brandWinIndexDataInterpretationAgent";

    /**
     * 智能解读交互
     *
     * @param serviceContext
     * @param winInsightQueryViewDTO
     * @return
     */
    public Map<String, String> smartExplain(ServiceContext serviceContext, WinInsightQueryViewDTO winInsightQueryViewDTO) {
        validate(winInsightQueryViewDTO);
        Map<String, Object> queryMap = buildQueryMap(winInsightQueryViewDTO);
        LlmAgentDirectCallParamViewDTO llmAgentDirectCallParamViewDTO = new LlmAgentDirectCallParamViewDTO();
        llmAgentDirectCallParamViewDTO.setAgentName(agentName);
        llmAgentDirectCallParamViewDTO.setExt(queryMap);
        String llmOutput = agentRepository.directCall(serviceContext, llmAgentDirectCallParamViewDTO);
        if (StringUtils.isNotBlank(llmOutput)) {
            return JSON.parseObject(llmOutput, new TypeReference<Map<String, String>>() {
            });
        }
        return Maps.newHashMap();
    }

    /**
     * 智能解读Agent 数据查询Tool
     *
     * @param serviceContext
     * @param winInsightQueryViewDTO
     * @return
     */
    public Map<String, Object> smartExplainQuery(ServiceContext serviceContext, WinInsightQueryViewDTO winInsightQueryViewDTO) {
        RogerLogger.info("smartExplainQuery, serviceContext:{}, winInsightQueryViewDTO:{}", JSONObject.toJSONString(serviceContext), JSONObject.toJSONString(winInsightQueryViewDTO));
        validate(winInsightQueryViewDTO);
        Map<String, Object> result = Maps.newHashMap();
        // 多次查询组装结构化数据
        // 1. 当前品牌数据
        List<Map<String, Object>> selfDataList = selfDataQuery(serviceContext, winInsightQueryViewDTO);
        if (CollectionUtils.isNotEmpty(selfDataList)) {
            Map<String, Object> selfData = selfDataList.get(0);
            result.put("self", JSON.toJSONString(selfData));
        } else {
            result.put("self", "{}");
        }
        // 2. 趋势数据 固定过去三个月
        List<Map<String, Object>> trendingData = trendingDataQuery(serviceContext, winInsightQueryViewDTO);
        if (CollectionUtils.isNotEmpty(trendingData)) {
            result.put("trending", JSON.toJSONString(trendingData));
        } else {
            result.put("trending", "[]");
        }
        // 3. 竞对数据
        List<Map<String, Object>> competingData = competingDataQuery(serviceContext, winInsightQueryViewDTO);
        if (CollectionUtils.isNotEmpty(competingData)) {
            List<Map<String, Object>> filterCompetingData = filterCompetingData(competingData, winInsightQueryViewDTO);
            result.put("competing", JSON.toJSONString(filterCompetingData));
        } else {
            result.put("competing", "[]");
        }
        // 4. 同行品牌力均值
        result.put("winIndexCategoryAverage", calculateCategoryWinIndex(competingData));
        result.put("brandId", winInsightQueryViewDTO.getBrandId());
        RogerLogger.info("smartExplainQuery result:{}", JSON.toJSONString(result));
        return result;
    }

    private List<Map<String, Object>> selfDataQuery(ServiceContext serviceContext, WinInsightQueryViewDTO winInsightQueryViewDTO) {
        WinInsightQueryViewDTO selfQuery = new WinInsightQueryViewDTO();
        selfQuery.setStartTime(winInsightQueryViewDTO.getStartTime());
        selfQuery.setEndTime(winInsightQueryViewDTO.getEndTime());
        selfQuery.setDimension(WinInsightDimenisonTypeEnum.MEMBER.getValue());
        String customIndex = String.join(Constant.CHAR_SPLIT_KEY_DOT, Lists.newArrayList(WinInsightMetricsEnum.WIN_INDEX.getMetricsName(), WinInsightMetricsEnum.W_INDEX.getMetricsName(), WinInsightMetricsEnum.I_INDEX.getMetricsName(), WinInsightMetricsEnum.N_INDEX.getMetricsName()));
        selfQuery.setCustomIndex(customIndex);
        selfQuery.setBrandId(winInsightQueryViewDTO.getBrandId());
        selfQuery.setCateLevelOneId(winInsightQueryViewDTO.getCateLevelOneId());
        selfQuery.setCateLevelTwoId(winInsightQueryViewDTO.getCateLevelTwoId());
        selfQuery.setCateLevelLeafId(winInsightQueryViewDTO.getCateLevelLeafId());
        selfQuery.setStartPrice(winInsightQueryViewDTO.getStartPrice());
        selfQuery.setEndPrice(winInsightQueryViewDTO.getEndPrice());
        selfQuery.setTotalType(ReportTotalTypeEnum.TOTAL.getValue());
        List<Map<String, Object>> dataList = winInsightQueryWorkflow.query(serviceContext, selfQuery);
        return reformat(dataList);
    }

    private List<Map<String, Object>> trendingDataQuery(ServiceContext serviceContext, WinInsightQueryViewDTO winInsightQueryViewDTO) {
        List<Map<String, Object>> trendingDataList = Lists.newArrayList();
        WinInsightQueryViewDTO trendingQuery = new WinInsightQueryViewDTO();
        String selectStartTime = winInsightQueryViewDTO.getStartTime();
        Date selectedDate = BrandDateUtil.string2Date(selectStartTime, BrandDateUtil.DATE_FORMAT_YYYYMMDD_TYPE_2);

        // 前3个月
        String lastThreeFirstDayOfMonth = BrandDateUtil.getDiffMonthFirstDay(-3, selectedDate);
        String lastThreeEndDayOfMonth = BrandDateUtil.getDiffMonthEndDay(-3, selectedDate);
        trendingQuery.setStartTime(lastThreeFirstDayOfMonth);
        trendingQuery.setEndTime(lastThreeEndDayOfMonth);

        trendingQuery.setDimension(WinInsightDimenisonTypeEnum.MEMBER.getValue());
        String customIndex = String.join(Constant.CHAR_SPLIT_KEY_DOT, Lists.newArrayList(WinInsightMetricsEnum.WIN_INDEX.getMetricsName(), WinInsightMetricsEnum.W_INDEX.getMetricsName(), WinInsightMetricsEnum.I_INDEX.getMetricsName(), WinInsightMetricsEnum.N_INDEX.getMetricsName()));
        trendingQuery.setCustomIndex(customIndex);
        trendingQuery.setBrandId(winInsightQueryViewDTO.getBrandId());
        trendingQuery.setCateLevelOneId(winInsightQueryViewDTO.getCateLevelOneId());
        trendingQuery.setCateLevelTwoId(winInsightQueryViewDTO.getCateLevelTwoId());
        trendingQuery.setCateLevelLeafId(winInsightQueryViewDTO.getCateLevelLeafId());
        trendingQuery.setStartPrice(winInsightQueryViewDTO.getStartPrice());
        trendingQuery.setEndPrice(winInsightQueryViewDTO.getEndPrice());
        trendingQuery.setTotalType(ReportTotalTypeEnum.TOTAL.getValue());
        List<Map<String, Object>> currentMonthDataList = winInsightQueryWorkflow.query(serviceContext, trendingQuery);
        List<Map<String, Object>> reformatCurrentMonthDataList = reformat(currentMonthDataList);
        if (CollectionUtils.isNotEmpty(reformatCurrentMonthDataList)) {
            Map<String, Object> currentMonthData = reformatCurrentMonthDataList.get(0);
            currentMonthData.put("month", BrandDateUtil.getDiffMonth(-3, selectedDate));
            trendingDataList.add(currentMonthData);
        }
        // 前2个月
        String lastTwoFirstDayOfMonth = BrandDateUtil.getDiffMonthFirstDay(-2, selectedDate);
        String lastTwoEndDayOfMonth = BrandDateUtil.getDiffMonthEndDay(-2, selectedDate);
        trendingQuery.setStartTime(lastTwoFirstDayOfMonth);
        trendingQuery.setEndTime(lastTwoEndDayOfMonth);

        List<Map<String, Object>> lastMonthDataList = winInsightQueryWorkflow.query(serviceContext, trendingQuery);
        List<Map<String, Object>> reformatLastMonthDataList = reformat(lastMonthDataList);
        if (CollectionUtils.isNotEmpty(reformatLastMonthDataList)) {
            Map<String, Object> lastMonthData = reformatLastMonthDataList.get(0);
            lastMonthData.put("month", BrandDateUtil.getDiffMonth(-2, selectedDate));
            trendingDataList.add(lastMonthData);
        }
        // 前1个月
        String lastOneFirstDayOfMonth = BrandDateUtil.getDiffMonthFirstDay(-1, selectedDate);
        String lastOneEndDayOfMonth = BrandDateUtil.getDiffMonthEndDay(-1, selectedDate);
        trendingQuery.setStartTime(lastOneFirstDayOfMonth);
        trendingQuery.setEndTime(lastOneEndDayOfMonth);
        List<Map<String, Object>> beforeLastMonthDataList = winInsightQueryWorkflow.query(serviceContext, trendingQuery);
        List<Map<String, Object>> reformatBeforeLastMonthDataList = reformat(beforeLastMonthDataList);
        if (CollectionUtils.isNotEmpty(reformatBeforeLastMonthDataList)) {
            Map<String, Object> beforeLastMonthData = reformatBeforeLastMonthDataList.get(0);
            beforeLastMonthData.put("month", BrandDateUtil.getDiffMonth(-1, selectedDate));
            trendingDataList.add(beforeLastMonthData);
        }
        return trendingDataList;
    }

    private List<Map<String, Object>> competingDataQuery(ServiceContext serviceContext, WinInsightQueryViewDTO winInsightQueryViewDTO) {
        WinInsightQueryViewDTO competingDataQuery = new WinInsightQueryViewDTO();
        competingDataQuery.setStartTime(winInsightQueryViewDTO.getStartTime());
        competingDataQuery.setEndTime(winInsightQueryViewDTO.getEndTime());
        competingDataQuery.setDimension(WinInsightDimenisonTypeEnum.BRAND.getValue());
        String customIndex = String.join(Constant.CHAR_SPLIT_KEY_DOT, Lists.newArrayList(WinInsightMetricsEnum.WIN_INDEX.getMetricsName(), WinInsightMetricsEnum.W_INDEX.getMetricsName(), WinInsightMetricsEnum.I_INDEX.getMetricsName(), WinInsightMetricsEnum.N_INDEX.getMetricsName()));
        competingDataQuery.setCustomIndex(customIndex);
        competingDataQuery.setCateLevelOneId(winInsightQueryViewDTO.getCateLevelOneId());
        competingDataQuery.setCateLevelTwoId(winInsightQueryViewDTO.getCateLevelTwoId());
        competingDataQuery.setCateLevelLeafId(winInsightQueryViewDTO.getCateLevelLeafId());
        competingDataQuery.setStartPrice(winInsightQueryViewDTO.getStartPrice());
        competingDataQuery.setEndPrice(winInsightQueryViewDTO.getEndPrice());
        competingDataQuery.setTotalType(ReportTotalTypeEnum.TOTAL.getValue());
        List<Map<String, Object>> dataList = winInsightQueryWorkflow.query(serviceContext, competingDataQuery);
        return reformat(dataList);
    }

    private List<Map<String, Object>> filterCompetingData(List<Map<String, Object>> competingDataList, WinInsightQueryViewDTO winInsightQueryViewDTO) {
        Long brandId = winInsightQueryViewDTO.getBrandId();
        List<Map<String, Object>> result = Lists.newArrayList();
        // 去除数据中无品牌Id\win_index的脏数据
        if (CollectionUtils.isNotEmpty(competingDataList)) {
            List<Map<String, Object>> filteredCompetingData = competingDataList.stream()
                    .filter(competingData -> Objects.nonNull(competingData.get(WinInsightMetricsEnum.BRAND_ID.getMetricsName())) && Objects.nonNull(competingData.get(WinInsightMetricsEnum.WIN_INDEX.getMetricsName())))
                    .sorted((a, b) -> {
                        Double bWindex = Double.parseDouble(String.valueOf(b.get(WinInsightMetricsEnum.WIN_INDEX.getMetricsName())));
                        Double aWindex = Double.parseDouble(String.valueOf(a.get(WinInsightMetricsEnum.WIN_INDEX.getMetricsName())));
                        return bWindex.compareTo(aWindex);
                    }).collect(Collectors.toList());
            List<Long> brandIdIndexList = filteredCompetingData.stream().map(competingData -> {
                Object brandIdObj = competingData.get(WinInsightMetricsEnum.BRAND_ID.getMetricsName());
                return Long.parseLong(String.valueOf(brandIdObj));
            }).collect(Collectors.toList());
            // 当前品牌所在的次序
            int currentBrandIndex = brandIdIndexList.indexOf(brandId);
            if (currentBrandIndex >= 2) {
                // 取前两名竞品
                result.addAll(filteredCompetingData.subList(currentBrandIndex - 2, currentBrandIndex + 1));
            } else if (currentBrandIndex >= 0) {
                // 取前3名竞品
                result.addAll(filteredCompetingData.subList(0, 3));
            }
        }
        return result;
    }

    private Double calculateCategoryWinIndex(List<Map<String, Object>> competingDataList) {
        if (CollectionUtils.isEmpty(competingDataList)) {
            return null;
        }
        double categoryWinIndex = 0.0;
        int size = 0;
        for (Map<String, Object> competingData : competingDataList) {
            if (Objects.nonNull(competingData.get(WinInsightMetricsEnum.WIN_INDEX.getMetricsName()))) {
                categoryWinIndex += Double.parseDouble(String.valueOf(competingData.get(WinInsightMetricsEnum.WIN_INDEX.getMetricsName())));
                size++;
            }
        }
        if (size != 0) {
            BigDecimal divideDecimal = new BigDecimal(String.valueOf(categoryWinIndex)).divide(new BigDecimal(String.valueOf(size)), 2, RoundingMode.HALF_UP);
            return divideDecimal.doubleValue();
        }
        return null;
    }

    // 构建brand-ai交互参数
    private Map<String, Object> buildQueryMap(WinInsightQueryViewDTO winInsightQueryViewDTO) {
        Map<String, Object> result = Maps.newHashMap();
        if (Objects.nonNull(winInsightQueryViewDTO.getBrandId())) {
            result.put("brandId", winInsightQueryViewDTO.getBrandId());
        }
        if (Objects.nonNull(winInsightQueryViewDTO.getCateLevelOneId())) {
            result.put("cateLevelOneId", winInsightQueryViewDTO.getCateLevelOneId());
        }
        if (Objects.nonNull(winInsightQueryViewDTO.getCateLevelTwoId())) {
            result.put("cateLevelTwoId", winInsightQueryViewDTO.getCateLevelTwoId());
        }
        if (Objects.nonNull(winInsightQueryViewDTO.getCateLevelLeafId())) {
            result.put("cateLevelLeafId", winInsightQueryViewDTO.getCateLevelLeafId());
        }
        if (Objects.nonNull(winInsightQueryViewDTO.getStartPrice())) {
            result.put("startPrice", winInsightQueryViewDTO.getStartPrice());
        }
        if (Objects.nonNull(winInsightQueryViewDTO.getEndPrice())) {
            result.put("endPrice", winInsightQueryViewDTO.getEndPrice());
        }
        if (StringUtils.isNotBlank(winInsightQueryViewDTO.getStartTime()) && StringUtils.isNotBlank(winInsightQueryViewDTO.getEndTime())) {
            result.put("startTime", winInsightQueryViewDTO.getStartTime());
            result.put("endTime", winInsightQueryViewDTO.getEndTime());
        }
        return result;
    }

    private void validate(WinInsightQueryViewDTO winInsightQueryViewDTO) {
        AssertUtil.notNull(winInsightQueryViewDTO);
        AssertUtil.notNull(winInsightQueryViewDTO.getBrandId());
        AssertUtil.notNull(winInsightQueryViewDTO.getStartTime());
        AssertUtil.notNull(winInsightQueryViewDTO.getEndTime());
        AssertUtil.notNull(winInsightQueryViewDTO.getCateLevelOneId());
    }

    /**
     * 数据格式化
     *
     * @param dataList
     * @return
     */
    private List<Map<String, Object>> reformat(List<Map<String, Object>> dataList) {
        // 所有数据指标保留两位小数
        if (CollectionUtils.isNotEmpty(dataList)) {
            dataList.forEach(data -> {
                data.forEach((key, value) -> {
                    if (WinInsightMetricsEnum.getDataMetrics().contains(WinInsightMetricsEnum.of(key))) {
                        if (Objects.nonNull(value)) {
                            BigDecimal bigDecimal = new BigDecimal(String.valueOf(value)).setScale(2, RoundingMode.HALF_UP);
                            data.put(key, bigDecimal.doubleValue());
                        }
                    }
                });
            });
        }
        return dataList;
    }
}
