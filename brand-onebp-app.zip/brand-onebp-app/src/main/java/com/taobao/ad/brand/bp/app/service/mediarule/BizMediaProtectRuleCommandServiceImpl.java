package com.taobao.ad.brand.bp.app.service.mediarule;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.media.protect.MediaProtectRuleViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.api.mediarule.BizMediaProtectRuleCommandService;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.mediarule.MediaProtectRuleRepository;
import com.taobao.ad.brand.bp.domain.mediarule.ability.MediaProtectRuleAbility;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Optional;

/**
 * 保护规则服务
 *
 * @author linhua.deng
 */
@HSFProvider(serviceInterface = BizMediaProtectRuleCommandService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizMediaProtectRuleCommandServiceImpl implements BizMediaProtectRuleCommandService {

    private final MediaProtectRuleRepository mediaProtectRuleRepository;
    private final MediaProtectRuleAbility mediaProtectRuleAbility;

    @Override
    public SingleResponse<Long> addProtectRule(ServiceContext context, MediaProtectRuleViewDTO viewDTO) {
        AssertUtil.notNull(viewDTO,"参数不允许为空");

        mediaProtectRuleAbility.initProtectRule(viewDTO, null);
        mediaProtectRuleAbility.validateProtectRule(context, viewDTO, null);

        Long freqId = mediaProtectRuleRepository.addProtectRule(context, viewDTO);
        return SingleResponse.of(freqId);
    }

    @Override
    public SingleResponse<Integer> updateProtectRule(ServiceContext context, MediaProtectRuleViewDTO viewDTO) {
        AssertUtil.notNull(Optional.ofNullable(viewDTO).map(MediaProtectRuleViewDTO::getId).orElse(null),"保护规则ID不能位空");

        MediaProtectRuleViewDTO mediaProtectRuleViewDTO = mediaProtectRuleRepository.getProtectRule(context, viewDTO.getId());
        AssertUtil.notNull(mediaProtectRuleViewDTO, String.format("保护规则不存在，id=%s",viewDTO.getId()));

        mediaProtectRuleAbility.initProtectRule(viewDTO, mediaProtectRuleViewDTO);
        mediaProtectRuleAbility.validateProtectRule(context, viewDTO, mediaProtectRuleViewDTO);

        Integer count = mediaProtectRuleRepository.updateProtectRule(context, viewDTO);
        return SingleResponse.of(count);
    }

    @Override
    public SingleResponse<Integer> updateProtectRuleStatus(ServiceContext context, List<Long> ids, Integer status) {
        AssertUtil.notEmpty(ids, "保护规则ids不能为空");
        AssertUtil.notNull(BrandBoolEnum.getByCode(status), "操作状态不合法");

        Integer count = mediaProtectRuleRepository.updateProtectRuleStatus(context,ids, status);
        return SingleResponse.of(count);
    }
}