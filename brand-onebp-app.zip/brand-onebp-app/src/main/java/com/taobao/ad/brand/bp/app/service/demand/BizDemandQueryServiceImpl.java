package com.taobao.ad.brand.bp.app.service.demand;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.demand.DemandResourceTypeViewDTO;
import com.alibaba.ad.brand.dto.demand.DemandViewDTO;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.api.demand.BizDemandQueryService;
import com.taobao.ad.brand.bp.client.dto.demand.DemandTalentDiffViewDTO;
import com.taobao.ad.brand.bp.client.dto.demand.query.DemandQueryOption;
import com.taobao.ad.brand.bp.client.dto.demand.query.DemandQueryViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

@Deprecated
@HSFProvider(serviceInterface = BizDemandQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizDemandQueryServiceImpl implements BizDemandQueryService {

    @Override
    public SingleResponse<DemandViewDTO> getDemandById(ServiceContext serviceContext, Long id) {
        return SingleResponse.failureOf(BrandOneBPBaseErrorCode.BIZ_UN_SUPPORT_ERROR);
    }

    @Override
    public MultiResponse<DemandViewDTO> findDemandList(ServiceContext serviceContext, DemandQueryViewDTO queryViewDTO, DemandQueryOption queryOption) {
        return MultiResponse.failureOf(BrandOneBPBaseErrorCode.BIZ_UN_SUPPORT_ERROR);
    }

    @Override
    public MultiResponse<DemandResourceTypeViewDTO> findDemandResourceTypeList(ServiceContext serviceContext, Integer sspProductLineId) {
        return MultiResponse.failureOf(BrandOneBPBaseErrorCode.BIZ_UN_SUPPORT_ERROR);
    }

    @Override
    public MultiResponse<DemandTalentDiffViewDTO> findDemandTalentDiffList(ServiceContext serviceContext) {
        return MultiResponse.failureOf(BrandOneBPBaseErrorCode.BIZ_UN_SUPPORT_ERROR);
    }
}
