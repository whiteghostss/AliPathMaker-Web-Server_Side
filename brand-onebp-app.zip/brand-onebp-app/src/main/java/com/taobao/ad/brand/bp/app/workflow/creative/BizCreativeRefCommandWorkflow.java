package com.taobao.ad.brand.bp.app.workflow.creative;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityInject;
import com.alibaba.abf.isolation.spec.common.ReduceType;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.adgroup.CreativeRefViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.brand.dto.creative.template.CreativeTemplateViewDTO;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupOnlineStatusEnum;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupStatusEnum;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupTargetTypeEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativePackageTypeEnum;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativeTargetTypeEnum;
import com.alibaba.ad.nb.ssp.constant.common.CrossSceneEnum;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.error.ErrorCodeAware;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignTemplateViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeTemplateQueryDTO;
import com.taobao.ad.brand.bp.client.dto.tag.TagViewDTO;
import com.taobao.ad.brand.bp.client.dto.template.TemplateViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.helper.creative.BizCreativeToolsHelper;
import com.taobao.ad.brand.bp.common.threadpooltask.AdgroupValidateCreativeRefTaskIdentifier;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.adgroup.repository.AdgroupRepository;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.config.AutoTestMemberDiamondConfig;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeRepository;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeTemplateRepository;
import com.taobao.ad.brand.bp.domain.creative.spi.BizCreativeTagValidateSpi;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupBindCreativeQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.query.IAdgroupBindCreativeQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.workflow.BizAdgroupCommandWorkflowExt;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.workflow.param.BizAdgroupBindWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.base.workflow.Workflow;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.*;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.*;
import com.taobao.ad.brand.bp.domain.sdk.creative.workflow.param.CreativeRefWorkflowParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.BIZ_DATA_EMPTY_ERROR;
import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_REQUIRED;
import static com.taobao.ad.brand.bp.common.helper.creative.BizCreativeToolsHelper.MAX_PAGE_COUNT;
import static com.taobao.ad.brand.bp.common.spi.ExtensionPointsFactory.runAbilitySpi;

/**
 * 创意业务流程
 *
 * @author yunhu.myh
 * @date 2023年12月22日
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizCreativeRefCommandWorkflow extends Workflow {

    private final CreativeRepository creativeRepository;
    private final CampaignRepository campaignRepository;
    private final AutoTestMemberDiamondConfig autoTestMemberDiamondConfig;
    private final AdgroupRepository adgroupRepository;
    private final CreativeTemplateRepository creativeTemplateRepository;

    @AbilityInject(reduce = ReduceType.FIRST)
    private final BizAdgroupCommandWorkflowExt bizAdgroupCommandWorkflowExt;

    private final AdgroupValidateCreativeRefTaskIdentifier adgroupValidateCreativeRefTaskIdentifier;
    private final ICreativeRefBatchOperateValidateAbility creativeRefBatchOperateValidateAbility;
    private final IAdgroupBindCreativeQueryAbility adgroupBindCreativeQueryAbility;

    private final ICreativeRefCreativeCountValidateAbility creativeRefCreativeCountValidateAbility ;
    private final ICreativeRefCreativeBottomDateValidateAbility creativeRefCreativeBottomDateValidateAbility;
    private final ICreativeRefCreativeDealValidateAbility creativeRefCreativeDealValidateAbility ;
    private final ICreativeRefCreativeDurationValidateAbility   creativeRefCreativeDurationValidateAbility ;
    private final ICreativeRefCreativeSchemaValidateAbility   creativeRefCreativeSchemaValidateAbility ;
    private final ICreativeRefCreativeStatusValidateAbility   creativeRefCreativeStatusValidateAbility ;
    private final ICreativeRefCreativeTemplateValidateAbility   creativeRefCreativeTemplateValidateAbility ;
    private final ICreativeRefDoohCreativeValidateAbility   creativeRefDoohCreativeValidateAbility ;
    private final ICreativeRefTopCreativeValidateAbility   creativeRefTopCreativeValidateAbility ;
    private final ICreativeRefCreativeCastDateValidateAbility   creativeRefCreativeCastDateValidateAbility ;
    private final ICreativeRefCrossOpaqueCreativeBindValidateAbility creativeRefCrossOpaqueCreativeBindValidateAbility;
    private final static String BIND_CREATIVE_PREFIX = "创意绑定";
    private final static String UNBIND_CREATIVE_PREFIX = "创意解绑";

    /**
     * 批量绑定创意
     *
     * @param context
     * @param adgroupViewDTOList
     * @param creativeIds
     * @return
     */
    public Response batchBindCreative(ServiceContext context, List<AdgroupViewDTO> adgroupViewDTOList, List<Long> creativeIds) {
        //创意批量绑定操作校验
        creativeRefBatchOperateValidateAbility.handle(context, CreativeRefBatchOperateValidateAbilityParam.builder().abilityTargets(adgroupViewDTOList).build());

        List<CreativeViewDTO> creativeViewDTOList = creativeRepository.findCreativeByIds(context, creativeIds);
        AssertUtil.notEmpty(creativeViewDTOList, "查询不到创意");
        Map<Long, CreativeViewDTO> creativeMap = creativeViewDTOList.stream().collect(Collectors.toMap(CreativeViewDTO::getId, Function.identity()));

        List<AdgroupViewDTO> needUpdateAdgroupList = Lists.newArrayList();
        List<CreativeRefViewDTO> addCreativeRefList = Lists.newArrayList();
        for (AdgroupViewDTO adgroupViewDTO : adgroupViewDTOList) {
            List<CreativeRefViewDTO> dbCreativeRefList =
                    Optional.ofNullable(adgroupViewDTO.getCreativeRefViewDTOList()).orElse(Lists.newArrayList());
            List<CreativeRefViewDTO> newCreativeRefList = Lists.newArrayList(dbCreativeRefList);
            Map<Long, CreativeRefViewDTO> dbCreativeRefMap = dbCreativeRefList.stream().collect(Collectors.toMap(CreativeRefViewDTO::getCreativeId, Function.identity()));
            boolean hasNewBind = false;
            for (Long creativeId : creativeIds) {
                if (!dbCreativeRefMap.containsKey(creativeId) && creativeMap.containsKey(creativeId)) {
                    CreativeRefViewDTO creativeRefViewDTO = new CreativeRefViewDTO();
                    creativeRefViewDTO.setCreativeId(creativeId);
                    creativeRefViewDTO.setCreativePackageId(creativeMap.get(creativeId).getCreativePackageId());
                    creativeRefViewDTO.setPackageType(creativeMap.get(creativeId).getPackageType());
                    creativeRefViewDTO.setAdgroupId(adgroupViewDTO.getId());
                    creativeRefViewDTO.setCampaignId(adgroupViewDTO.getCampaignId());
                    newCreativeRefList.add(creativeRefViewDTO);
                    addCreativeRefList.add(creativeRefViewDTO);
                    hasNewBind = true;
                }
            }
            if (hasNewBind) {
                adgroupViewDTO.setCreativeRefViewDTOList(newCreativeRefList);
                needUpdateAdgroupList.add(adgroupViewDTO);
            }
        }
        //校验
        batchValidate(context, needUpdateAdgroupList, BIND_CREATIVE_PREFIX);
        if (CollectionUtils.isNotEmpty(addCreativeRefList)) {
            creativeRepository.addBatchCreativeRef(context, addCreativeRefList);
        }
        return Response.success();
    }

    /**
     * 批量解绑创意
     *
     * @param context
     * @param adgroupViewDTOList
     * @param creativeIds
     * @return
     */
    public Response batchUnBindCreative(ServiceContext context, List<AdgroupViewDTO> adgroupViewDTOList, List<Long> creativeIds) {
        //创意批量绑定操作校验
        creativeRefBatchOperateValidateAbility.handle(context, CreativeRefBatchOperateValidateAbilityParam.builder().abilityTargets(adgroupViewDTOList).build());

        //查询单元创意分组
        Map<Long, List<CreativeViewDTO>> adgroupCreativeGroupMap = adgroupBindCreativeQueryAbility.handle(context,
                AdgroupBindCreativeQueryAbilityParam.builder().abilityTargets(adgroupViewDTOList).build());
        List<AdgroupViewDTO> needUpdateAdgroupList = Lists.newArrayList();
        for (AdgroupViewDTO adgroupViewDTO : adgroupViewDTOList) {
            if (CollectionUtils.isNotEmpty(adgroupViewDTO.getCreativeRefViewDTOList())) {
                List<CreativeViewDTO> creativeViewDTOList = adgroupCreativeGroupMap.getOrDefault(adgroupViewDTO.getId(), Lists.newArrayList());
                List<Long> needBindCreativeIds = creativeViewDTOList.stream().filter(item -> !creativeIds.contains(item.getId()) && !creativeIds.contains(item.getCreativePackageId()))
                        .map(CreativeViewDTO::getId).collect(Collectors.toList());
                List<CreativeRefViewDTO> creativeRefViewDTOList = adgroupViewDTO.getCreativeRefViewDTOList().stream()
                        .filter(creativeRefViewDTO -> needBindCreativeIds.contains(creativeRefViewDTO.getCreativeId())).collect(Collectors.toList());
                if (creativeRefViewDTOList.size() != adgroupViewDTO.getCreativeRefViewDTOList().size()) {
                    adgroupViewDTO.setCreativeRefViewDTOList(creativeRefViewDTOList);
                    needUpdateAdgroupList.add(adgroupViewDTO);
                }
            }
        }
        if (CollectionUtils.isNotEmpty(needUpdateAdgroupList)) {
            //校验
            batchValidate(context, needUpdateAdgroupList, UNBIND_CREATIVE_PREFIX);
            creativeRepository.unBindCreative(context, needUpdateAdgroupList.stream().map(AdgroupViewDTO::getId).collect(Collectors.toList()), creativeIds);
        }
        return Response.success();
    }

    /**
     * @param context
     * @param adgroupViewDTOList
     */
    private void batchValidate(ServiceContext context, List<AdgroupViewDTO> adgroupViewDTOList, String tipPrefix) {
        if (CollectionUtils.isEmpty(adgroupViewDTOList)) {
            return;
        }
        List<SingleResponse<Long>> validateResponseList = TaskStream
                .execute(adgroupValidateCreativeRefTaskIdentifier, adgroupViewDTOList, (adgroupViewDTO, index) -> {
                    SingleResponse<Long> response = SingleResponse.of(adgroupViewDTO.getId());
                    try {
                        //创意绑定单元场景，bizCode传递的是brandOneBP，需要根据单元的场景，重设上下文
                        ServiceContext serviceContext = context;
                        if (Objects.equals(BizCodeEnum.BRANDONEBP.getBizCode(), context.getBizCode())) {
                            serviceContext = ServiceContextUtil.getNewServiceContext(context, adgroupViewDTO.getSceneId());
                        }
                        BizAdgroupBindWorkflowParam bizAdgroupBindWorkflowParam =
                                bizAdgroupCommandWorkflowExt.buildParamForAdgroupBind(serviceContext, adgroupViewDTO);

                        CreativeRefWorkflowParam creativeRefWorkflowParam = CreativeRefWorkflowParam.builder()
                                .campaignGroupViewDTO(bizAdgroupBindWorkflowParam.getCampaignGroupViewDTO())
                                .campaignViewDTO(bizAdgroupBindWorkflowParam.getCampaignViewDTO())
                                .adgroupViewDTO(adgroupViewDTO)
                                .creativeViewDTOList(bizAdgroupBindWorkflowParam.getCreativeViewDTOList())
                                .bottomDateViewDTOList(bizAdgroupBindWorkflowParam.getBottomDateViewDTOList()).build();
                        this.validateCreativeRef(serviceContext, creativeRefWorkflowParam);
                        return response;
                    } catch (Exception e) {
                        RogerLogger.error(String.format("%s校验失败，单元ID=%s", tipPrefix, adgroupViewDTO.getId()), e);
                        ErrorCodeAware errorCodeAware = BrandOneBPException.getErrorCodeFromException(e);
                        response.setErrorCode(errorCodeAware.getErrCode());
                        response.setErrorMsg(errorCodeAware.getErrMsg());
                        response.setSuccess(false);
                        return response;
                    }
                })
                .commit()
                .getResultList();

        //失败的单元
        Map<Long, String> failAdgroupMap = validateResponseList.stream().filter(validateResponse -> !validateResponse.isSuccess())
                .collect(Collectors.toMap(SingleResponse::getResult, validateResponse ->
                        String.format("(%s:%s)", validateResponse.getResult(), validateResponse.getErrorMsg())));

        //局部异常信息抛出
        if (MapUtils.isNotEmpty(failAdgroupMap)) {
            String errorMessage = String.format("部分单元%s失败，原因：%s", tipPrefix, String.join(",", failAdgroupMap.values()));
            throw new BrandOneBPException(BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR.of(errorMessage));
        }
    }

    /**
     * 删除创意绑定关系
     * @param context
     * @param adgroupIds
     * @param creativeId
     * @return
     */
    public Integer delBindCreative(ServiceContext context, List<Long> adgroupIds, Long creativeId){
        RogerLogger.info("delBindCreative,adgroupIds:{},creativeId:{}", JSONObject.toJSONString(adgroupIds), creativeId);
        AssertUtil.assertTrue(org.apache.commons.collections.CollectionUtils.isNotEmpty(autoTestMemberDiamondConfig.getInnerMemberList()), "未配置白名单，不可物理操作");
        AssertUtil.assertTrue(autoTestMemberDiamondConfig.getInnerMemberList().contains(context.getMemberId()), "未命中白名单，不可物理操作");

        //校验单元
        AdgroupQueryViewDTO adgroupQueryViewDTO = new AdgroupQueryViewDTO();
        adgroupQueryViewDTO.setIds(adgroupIds);
        List<AdgroupViewDTO> adgroupViewDTOList = adgroupRepository.queryAdgroupListNoPage(context, adgroupQueryViewDTO);
        AssertUtil.notEmpty(adgroupViewDTOList, "未查询到单元信息");
        List<Long> dbAdgroupIds = adgroupViewDTOList.stream().map(AdgroupViewDTO::getId).collect(Collectors.toList());
        List<Long> unFindAdgroupIds =
                adgroupIds.stream().filter(item -> !dbAdgroupIds.contains(item)).collect(Collectors.toList());
        AssertUtil.assertTrue(CollectionUtils.isEmpty(unFindAdgroupIds), "单元%s,不存在，请检查后重试", StringUtils.join(unFindAdgroupIds, ","));

        CreativeViewDTO creativeViewDTO = creativeRepository.getCreativeById(context, creativeId);
        AssertUtil.notNull(creativeViewDTO, "创意不存在");

        return creativeRepository.unBindCreative(context, adgroupIds, Lists.newArrayList(creativeId));
    }


    public void validateCreativeRef(ServiceContext serviceContext,  CreativeRefWorkflowParam creativeRefWorkflowParam) {
        CampaignViewDTO campaignViewDTO = creativeRefWorkflowParam.getCampaignViewDTO();
        AdgroupViewDTO adgroupViewDTO = creativeRefWorkflowParam.getAdgroupViewDTO();
        List<CreativeViewDTO> creativeViewDTOList = creativeRefWorkflowParam.getCreativeViewDTOList();
        //校验基础参数
        validateParam(creativeRefWorkflowParam);
        if(CollectionUtils.isEmpty(creativeViewDTOList)){
            return;
        }
        //校验创意绑定数量
        creativeRefCreativeCountValidateAbility.handle(serviceContext,CreativeRefValidateAbilityParam.builder().abilityTargets(creativeRefWorkflowParam.getCreativeViewDTOList()).campaignViewDTO(creativeRefWorkflowParam.getCampaignViewDTO()).adgroupViewDTO(adgroupViewDTO).build());
        //全域通黑盒创意特殊校验
        creativeRefCrossOpaqueCreativeBindValidateAbility.handle(serviceContext,CreativeRefCrossOpaqueCreativeBindValidateAbilityParam.builder().abilityTargets(creativeRefWorkflowParam.getCreativeViewDTOList()).campaignViewDTO(creativeRefWorkflowParam.getCampaignViewDTO()).build());
        //查询计划下所有模板
        List<CampaignTemplateViewDTO> allCampaignTemplateViewDTOS = campaignRepository.getCampaignTemplateIds(serviceContext, Lists.newArrayList(creativeRefWorkflowParam.getCampaignViewDTO()));
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(allCampaignTemplateViewDTOS), "单元所属计划(%s:%s)未设置模板信息，请联系小二", creativeRefWorkflowParam.getCampaignViewDTO().getId(), campaignViewDTO.getTitle());
        List<CreativeViewDTO> allCreativeViewDTOS = getAllCreativeViewDTO(serviceContext,creativeRefWorkflowParam,allCampaignTemplateViewDTOS);

        if(BrandAdgroupTargetTypeEnum.PROGRAM.getCode().equals(adgroupViewDTO.getTargetType())){
            validateProgramAdgroupRef(serviceContext,creativeRefWorkflowParam,allCreativeViewDTOS,allCampaignTemplateViewDTOS);
        }else{
            validateDirectAdgroupRef(serviceContext,creativeRefWorkflowParam,allCreativeViewDTOS,allCampaignTemplateViewDTOS);
        }
    }

    private void validateProgramAdgroupRef(ServiceContext serviceContext,  CreativeRefWorkflowParam creativeRefWorkflowParam,List<CreativeViewDTO> creativeViewDTOList,List<CampaignTemplateViewDTO> campaignTemplateViewDTOList){
        CampaignGroupViewDTO campaignGroupViewDTO = creativeRefWorkflowParam.getCampaignGroupViewDTO();
        CampaignViewDTO campaignViewDTO = creativeRefWorkflowParam.getCampaignViewDTO();
        AdgroupViewDTO adgroupViewDTO = creativeRefWorkflowParam.getAdgroupViewDTO();
        List<CreativeRefViewDTO> creativeRefViewDTOList = adgroupViewDTO.getCreativeRefViewDTOList();

        //全域通黑盒下存在复制的媒体直投创意（保留）,其他场景不允许存在
        if(!Objects.equals(CrossSceneEnum.CROSS_OPAQUE_SCENE.getValue(),campaignViewDTO.getCampaignResourceViewDTO().getSspCrossScene())){
            List<CreativeViewDTO> targetCreativeViewDTOList = creativeViewDTOList.stream().filter(t -> t.getTargetType().equals(BrandCreativeTargetTypeEnum.DIRECT.getCode())).collect(Collectors.toList());
            AssertUtil.assertTrue(CollectionUtils.isEmpty(targetCreativeViewDTOList), "创意%s不是程序化创意，请检查后重试", BizCreativeToolsHelper.creativeMessage(targetCreativeViewDTOList));
        }

        if(BrandAdgroupStatusEnum.DRAFT.getCode().equals(creativeRefWorkflowParam.getAdgroupViewDTO().getOnlineStatus())){
           return;
        }
        //校验基础参数
        CreativeRefValidateAbilityParam creativeRefValidateAbilityParam = CreativeRefValidateAbilityParam.builder().abilityTargets(creativeRefWorkflowParam.getCreativeViewDTOList()).campaignViewDTO(creativeRefWorkflowParam.getCampaignViewDTO()).adgroupViewDTO(adgroupViewDTO).build();
        //创意优惠卷校验
        validateProgramAdgroupRefTag(serviceContext, creativeViewDTOList, campaignGroupViewDTO,campaignViewDTO,creativeRefViewDTOList);
        //根据模版标签校验
        creativeRefCreativeStatusValidateAbility.handle(serviceContext,creativeRefValidateAbilityParam);
        //模板校验
        creativeRefCreativeTemplateValidateAbility.handle(serviceContext, CreativeRefCreativeTemplateValidateAbilityParam.builder().abilityTargets(creativeViewDTOList).adgroupViewDTO(adgroupViewDTO).campaignTemplateViewDTOList(campaignTemplateViewDTOList).campaignViewDTO(campaignViewDTO).creativeRefViewDTOList(creativeRefViewDTOList).build());
        //top创意逻辑校验
        creativeRefTopCreativeValidateAbility.handle(serviceContext,creativeRefValidateAbilityParam);
        //创意时长校验
        creativeRefCreativeDurationValidateAbility.handle(serviceContext,creativeRefValidateAbilityParam);
        //创意有效期校验
        creativeRefCreativeCastDateValidateAbility.handle(serviceContext,creativeRefValidateAbilityParam);
        //创意deal送审校验
        creativeRefCreativeDealValidateAbility.handle(serviceContext,CreativeRefCreativeDealValidateAbilityParam.builder().abilityTargets(creativeViewDTOList).campaignTemplateViewDTOList(campaignTemplateViewDTOList).campaignViewDTO(campaignViewDTO).build());
        //创意唤端校验
        creativeRefCreativeSchemaValidateAbility.handle(serviceContext,creativeRefValidateAbilityParam);
        //天攻创意校验
        creativeRefDoohCreativeValidateAbility.handle(serviceContext,CreativeRefDoohCreativeValidateAbilityParam.builder().abilityTargets(creativeViewDTOList).campaignViewDTO(campaignViewDTO).campaignGroupViewDTO(campaignGroupViewDTO).build());
    }

    /**
     * 根据标签校验
     */
    private void validateProgramAdgroupRefTag(ServiceContext serviceContext, List<CreativeViewDTO> creativeViewDTOList, CampaignGroupViewDTO campaignGroupViewDTO, CampaignViewDTO campaignViewDTO, List<CreativeRefViewDTO> creativeRefViewDTOList) {
        CreativeTemplateQueryDTO creativeTemplateQueryDTO = new CreativeTemplateQueryDTO();
        creativeTemplateQueryDTO.setNeedTag(true);
        creativeTemplateQueryDTO.setTemplateIdList(creativeViewDTOList.stream().map(CreativeViewDTO::getCreativeTemplate).map(CreativeTemplateViewDTO::getSspTemplateId).distinct().collect(Collectors.toList()));
        List<TemplateViewDTO> creativeTemplates = creativeTemplateRepository.getTemplateList(serviceContext, creativeTemplateQueryDTO);
        // 增加对 creativeTemplateRepository.getTemplateList 返回结果的非空检查
        if (CollectionUtils.isEmpty(creativeTemplates)) {
            return;
        }
        Map<Long, TemplateViewDTO> templateViewDTOMap = creativeTemplates.stream().collect(Collectors.toMap(TemplateViewDTO::getId, Function.identity()));
        Map<Long, List<CreativeViewDTO>> collect = creativeViewDTOList.stream().collect(Collectors.groupingBy(creativeViewDTO -> creativeViewDTO.getCreativeTemplate().getSspTemplateId()));
        collect.entrySet().stream().filter(entry -> templateViewDTOMap.containsKey(entry.getKey()) &&
                CollectionUtils.isNotEmpty(templateViewDTOMap.get(entry.getKey()).getTagList())).forEach(entry -> {
            List<TagViewDTO> tagList = templateViewDTOMap.get(entry.getKey()).getTagList();
            for (TagViewDTO tagViewDTO : tagList) {
                runAbilitySpi(BizCreativeTagValidateSpi.class,
                        extension -> extension.checkCreativeTagForBind(serviceContext, entry.getValue(), campaignViewDTO, creativeRefViewDTOList, campaignGroupViewDTO), BizCreativeTagValidateSpi.getSpiBizCode(tagViewDTO));
            }
        });
    }
    private void validateDirectAdgroupRef(ServiceContext serviceContext, CreativeRefWorkflowParam creativeRefWorkflowParam,List<CreativeViewDTO> creativeViewDTOList,List<CampaignTemplateViewDTO> campaignTemplateViewDTOList){
        CampaignViewDTO campaignViewDTO = creativeRefWorkflowParam.getCampaignViewDTO();
        AdgroupViewDTO adgroupViewDTO = creativeRefWorkflowParam.getAdgroupViewDTO();
        List<CreativeRefViewDTO> creativeRefViewDTOList = adgroupViewDTO.getCreativeRefViewDTOList();
        CreativeRefValidateAbilityParam creativeRefValidateAbilityParam = CreativeRefValidateAbilityParam.builder().abilityTargets(creativeViewDTOList).campaignViewDTO(creativeRefWorkflowParam.getCampaignViewDTO()).adgroupViewDTO(adgroupViewDTO).build();
        //创意模板校验
        creativeRefCreativeTemplateValidateAbility.handle(serviceContext, CreativeRefCreativeTemplateValidateAbilityParam.builder().abilityTargets(creativeViewDTOList).adgroupViewDTO(adgroupViewDTO).campaignTemplateViewDTOList(campaignTemplateViewDTOList).campaignViewDTO(campaignViewDTO).creativeRefViewDTOList(creativeRefViewDTOList).build());
        //TOP创意规则校验
        creativeRefTopCreativeValidateAbility.handle(serviceContext,creativeRefValidateAbilityParam);
        //创意状态校验
        creativeRefCreativeStatusValidateAbility.handle(serviceContext,creativeRefValidateAbilityParam);
        //创意投放有效期校验
        creativeRefCreativeCastDateValidateAbility.handle(serviceContext,creativeRefValidateAbilityParam);
        //创意打底时间校验
        creativeRefCreativeBottomDateValidateAbility.handle(serviceContext,CreativeRefCreativeBottomValidateAbilityParam.builder().abilityTargets(creativeViewDTOList).adgroupViewDTO(adgroupViewDTO).bottomDateViewDTOList(creativeRefWorkflowParam.getBottomDateViewDTOList()).campaignViewDTO(campaignViewDTO).build());
    }

    private List<CreativeViewDTO>getAllCreativeViewDTO(ServiceContext serviceContext,CreativeRefWorkflowParam creativeRefWorkflowParam, List<CampaignTemplateViewDTO> campaignTemplateViewDTOS){

        CampaignViewDTO campaignViewDTO = creativeRefWorkflowParam.getCampaignViewDTO();
        AdgroupViewDTO adgroupViewDTO = creativeRefWorkflowParam.getAdgroupViewDTO();
        List<CreativeViewDTO> creativeViewDTOList = Lists.newArrayList(creativeRefWorkflowParam.getCreativeViewDTOList());

        Map<Long, CampaignTemplateViewDTO> campaignTemplateMap = campaignTemplateViewDTOS.stream().collect(Collectors.toMap(CampaignTemplateViewDTO::getCampaignId, Function.identity()));
        List<Long> allSubTemplateIds = Lists.newArrayList();
        if(BrandAdgroupTargetTypeEnum.PROGRAM.getCode().equals(adgroupViewDTO.getTargetType())){
            campaignViewDTO.getSubCampaignViewDTOList().stream().filter(item ->
                    campaignTemplateMap.containsKey(item.getId())).forEach(item->{
                CampaignTemplateViewDTO campaignTemplateViewDTO  =  campaignTemplateMap.get(item.getId());
                if(CollectionUtils.isNotEmpty(campaignTemplateViewDTO.getTemplateIds())){
                    allSubTemplateIds.addAll(campaignTemplateViewDTO.getTemplateIds());
                }
            });
        }else{
            //媒体直投需要查询程序化的模板和非程序化模板
            campaignViewDTO.getSubCampaignViewDTOList().stream().filter(item ->
                    campaignTemplateMap.containsKey(item.getId())).forEach(item->{
                CampaignTemplateViewDTO campaignTemplateViewDTO  =  campaignTemplateMap.get(item.getId());
                if(CollectionUtils.isNotEmpty(campaignTemplateViewDTO.getDirectTemplateIds())){
                    allSubTemplateIds.addAll(campaignTemplateViewDTO.getDirectTemplateIds());
                }
                if(CollectionUtils.isNotEmpty(campaignTemplateViewDTO.getTemplateIds())){
                    allSubTemplateIds.addAll(campaignTemplateViewDTO.getTemplateIds());
                }
            });
        }

        List<CreativeViewDTO> subCreativeViewDTOList =  fillSubCreatives(serviceContext,creativeViewDTOList, allSubTemplateIds);
        //全域通黑盒下存在复制的媒体直投创意（保留）,其他场景不允许存在
        if(Objects.equals(CrossSceneEnum.CROSS_OPAQUE_SCENE.getValue(),campaignViewDTO.getCampaignResourceViewDTO().getSspCrossScene())){
            //需要过滤出全域通下复制出的媒体直投子创意
            creativeViewDTOList = creativeViewDTOList.stream().filter(t -> !BizCreativeToolsHelper.isCrossDirectSubCreative(t)).collect(Collectors.toList());
        }
        creativeViewDTOList.addAll(subCreativeViewDTOList);
        return creativeViewDTOList;
    }
    private void validateParam(CreativeRefWorkflowParam creativeRefWorkflowParam){
        List<CreativeRefViewDTO> creativeRefViewDTOList = creativeRefWorkflowParam.getAdgroupViewDTO().getCreativeRefViewDTOList();
        List<CreativeViewDTO> creativeViewDTOList = creativeRefWorkflowParam.getCreativeViewDTOList();
        AdgroupViewDTO adgroupViewDTO = creativeRefWorkflowParam.getAdgroupViewDTO();
        //非草稿状态，创意必须要关联
        if(!BrandAdgroupOnlineStatusEnum.DRAFT.getCode().equals(adgroupViewDTO.getOnlineStatus())){
            AssertUtil.notEmpty(creativeRefViewDTOList.stream()
                    .filter(creativeRefViewDTO -> BrandBoolEnum.BRAND_TRUE.getCode().equals(creativeRefViewDTO.getOnlineStatus()))
                    .collect(Collectors.toList()), BIZ_DATA_EMPTY_ERROR,"单元关联创意不能为空");
        }
        //参数合法性校验
        if(CollectionUtils.isNotEmpty(creativeRefViewDTOList)){
            for (CreativeRefViewDTO creativeRefViewDTO : creativeRefViewDTOList){
                AssertUtil.notNull(creativeRefViewDTO.getCreativeId(),PARAM_REQUIRED,"创意ID参数不正确");
            }
            //创意是否已存在校验
            Map<Long,CreativeViewDTO> creativeViewDTOMap = creativeViewDTOList.stream().collect(Collectors.toMap(CreativeViewDTO::getId, Function.identity(), (v1, v2) -> v2));
            List<Long> notIndbCreativeIds = creativeRefViewDTOList.stream().map(CreativeRefViewDTO::getCreativeId).filter(creativeId ->!creativeViewDTOMap.containsKey(creativeId)).collect(Collectors.toList());
            AssertUtil.assertTrue(CollectionUtils.isEmpty(notIndbCreativeIds),"创意(ID：%s)不存在，请修改后重新提交", org.apache.commons.lang.StringUtils.join(notIndbCreativeIds,","));

        }
    }
    private List<CreativeViewDTO> fillSubCreatives(ServiceContext serviceContext, List<CreativeViewDTO> creativeViewDTOList, List<Long> subTemplateIds) {
        List<CreativeViewDTO> subCreativeViewDTOList = Lists.newArrayList();
        List<Long> creativePackageIds = creativeViewDTOList.stream().filter(creativeViewDTO -> BrandCreativePackageTypeEnum.PACKAGE.getValue().equals(creativeViewDTO.getPackageType())).
                map(CreativeViewDTO::getId).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(creativePackageIds)) {
            CreativeQueryViewDTO queryViewDTO = new CreativeQueryViewDTO();
            queryViewDTO.setCreativePackageIdList(creativePackageIds);
            queryViewDTO.setCreativeIdEqCreativePackageId(Boolean.FALSE);
            queryViewDTO.setPageSize(MAX_PAGE_COUNT);
            queryViewDTO.setPackageType(BrandCreativePackageTypeEnum.COMMON.getValue());
            PageResultViewDTO<CreativeViewDTO> pageResultViewDTO = creativeRepository.findListWithPage(serviceContext, queryViewDTO);
            if (CollectionUtils.isNotEmpty(pageResultViewDTO.getList())) {
                List<CreativeViewDTO> subCreativeViewDTOS = pageResultViewDTO.getList().stream().filter(creativeViewDTO -> subTemplateIds.contains(creativeViewDTO.getCreativeTemplate().getSspTemplateId())).collect(Collectors.toList());
                if (CollectionUtils.isNotEmpty(subCreativeViewDTOS)) {
                    subCreativeViewDTOList.addAll(subCreativeViewDTOS);
                }
            }
        }
        return subCreativeViewDTOList;
    }
}
