package com.taobao.ad.brand.bp.app.workflow.campaign;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityInject;
import com.alibaba.abf.isolation.spec.common.ReduceType;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.budget.CampaignBudgetViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.*;
import com.alibaba.ad.brand.dto.campaign.price.CampaignPriceViewDTO;
import com.alibaba.ad.brand.dto.campaign.price.DayPriceViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.salegroup.CampaignGroupSaleGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.*;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSaleOrderStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.error.ErrorCodeAware;
import com.alibaba.hermes.framework.utils.DateUtils;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.alimama.inventory.dto.universal.UniResponse;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.app.spi.campaign.inventory.BizCampaignInventoryOperateSpi;
import com.taobao.ad.brand.bp.app.spi.campaign.inventory.BizCampaignInventorySpi;
import com.taobao.ad.brand.bp.app.workflow.campaigngroup.BizScheduleExportWorkflow;
import com.taobao.ad.brand.bp.client.context.CampaignNoticeContext;
import com.taobao.ad.brand.bp.client.context.ScheduleExportContext;
import com.taobao.ad.brand.bp.client.dto.campaign.*;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignInventoryAutoReleaseQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.export.ScheduleExportQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignScheduleIsInventoryEnum;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignScheduleOperateTypeEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.constant.ReportConstant;
import com.taobao.ad.brand.bp.common.converter.campaign.CampaignScrollDailyUpdateConverter;
import com.taobao.ad.brand.bp.common.converter.campaign.CampaignViewPageConverter;
import com.taobao.ad.brand.bp.common.enums.BpmsProcessCodeEnum;
import com.taobao.ad.brand.bp.common.enums.distlock.DistLockEnum;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.common.threadpooltask.CampaignAssignUnProgrammaticOrCptScheduleTaskIdentifier;
import com.taobao.ad.brand.bp.common.threadpooltask.CampaignAutoAssignScheduleTaskIdentifier;
import com.taobao.ad.brand.bp.common.util.*;
import com.taobao.ad.brand.bp.domain.bpms.BpmsRepository;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.campaign.spi.BizCampaignSplitSpi;
import com.taobao.ad.brand.bp.domain.config.CampaignInventoryAutoReleaseDiamondConfig;
import com.taobao.ad.brand.bp.domain.event.campaign.CampaignLockExpireTimeInitEvent;
import com.taobao.ad.brand.bp.domain.perform.PerformRepository;
import com.taobao.ad.brand.bp.domain.report.ability.BizReportQueryAbility;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignOnlineStatusUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignOperateDistLockGetAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignUpdatePartAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.inventory.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.BizCampaignInventoryWorkflowExt;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignAutoReleaseWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignInventoryWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupOperateDistLockGetAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupOperateDistLockAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.IMessageSyncSendAbility;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.param.MessageSyncSendAbilityParam;
import com.taobao.brand.BrandConstants;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.common.constant.Constant.*;
import static com.taobao.ad.brand.bp.common.spi.ExtensionPointsFactory.runAbilitySpi;
import static com.taobao.ad.brand.bp.common.util.BrandDateUtil.DATE_FORMAT_YYYYMMDD_TYPE_2;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/03/11
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))

public class BizCampaignInventoryWorkflow {
    private final BizReportQueryAbility bizReportQueryAbility;
    private final CampaignScrollDailyUpdateConverter campaignScrollDailyUpdateConverter;
    private final BizScheduleExportWorkflow bizScheduleExportWorkflow;
    private final BizCampaignMessageWorkflow bizCampaignMessageWorkflow;
    private final CampaignViewPageConverter campaignViewPageConverter;

    private final ISaleGroupOperateDistLockGetAbility saleGroupOperateDistLockGetAbility;

    @AbilityInject(reduce = ReduceType.FIRST)
    private final BizCampaignInventoryWorkflowExt bizCampaignInventoryWorkflowExt;

    private final ICampaignFutureAmountCalculateAbility campaignFutureAmountCalculateAbility;
    private final ICampaignScheduleFutureInquiryAssignAbility campaignScheduleFutureInquiryAssignAbility;
    private final ICampaignInquiryAmountEqualsValidateAbility campaignInquiryAmountEqualsValidateAbility;
    private final ICampaignInquiryChannelGetForCampaignInventoryOperateAbility campaignInquiryChannelGetForCampaignInventoryOperateAbility;
    private final ICampaignStatusConvertForCampaignInventoryOperateAbility campaignStatusConvertForCampaignInventoryOperateAbility;
    private final ICampaignInventoryResponseParseForCampaignInventoryCallbackAbility campaignInventoryResponseParseForCampaignInventoryCallbackAbility;
    private final ICampaignInventoryResponseValidateForCampaignInventoryCallbackAbility campaignInventoryResponseValidateForCampaignInventoryCallbackAbility;
    private final ICampaignRebuildParentCampaignScheduleAbility campaignRebuildParentCampaignScheduleAbility;
    private final ICampaignInquiryLockBuildForUpdateCampaignScheduleAbility campaignInquiryLockBuildForUpdateCampaignScheduleAbility;
    private final ICampaignInquiryLockBatchUpdateAbility campaignInquiryLockBatchUpdateAbility;
    private final ICampaignUpdateForCampaignInventoryOperateAbility campaignUpdateForCampaignInventoryOperateAbility;
    private final ICampaignOnlineStatusUpdateAbility campaignOnlineStatusUpdateAbility;
    private final ICampaignScheduleScrollBuildAbility campaignScheduleScrollBuildAbility;
    private final ICampaignScheduleScrollUpdateAbility campaignScheduleScrollUpdateAbility;
    private final ICampaignStructureQueryAbility campaignStructureQueryAbility;
    private final ICampaignScheduleUpdateAbility campaignScheduleUpdateAbility;
    private final ICampaignInventoryMandatoryLockProcessParamBuildAbility campaignInventoryMandatoryLockProcessParamBuildAbility;
    private final IMessageSyncSendAbility messageSyncSendAbility;
    private final ICampaignUpdatePartAbility campaignUpdatePartAbility;
    private final ICampaignLockExpireTimeCalculateAbility campaignLockExpireTimeCalculateAbility;
    private final ICampaignLockExpireTimeRecalculateAbility campaignLockExpireTimeRecalculateAbility;
    private final ICampaignMediaInventoryLockExpireTimeCalculateAbility campaignMediaInventoryLockExpireTimeCalculateAbility;
    private final ICampaignFilterForAutoReleaseDelayLockAbility campaignFilterForAutoReleaseDelayLockAbility;
    private final ICampaignInventoryAutoReleaseWarningBuildAbility campaignInventoryAutoReleaseWarningBuildAbility;
    private final ICampaignValidateForAutoReleaseDelayLockAbility campaignValidateForAutoReleaseDelayLockAbility;
    private final ICampaignBuildBPMSParamsForAutoReleaseDelayLockAbility campaignBuildBPMSParamsForAutoReleaseDelayLockAbility;
    private final ICampaignValidateForAutoReleaseDelayLockProcessAbility campaignValidateForAutoReleaseDelayLockProcessAbility;
    private final ICampaignUpdateForAutoReleaseDelayLockProcessAbility campaignUpdateForAutoReleaseDelayLockProcessAbility;
    private final ICampaignScheduleValidateAbility campaignScheduleValidateAbility;
    private final ICampaignScheduleResetAbility campaignScheduleResetAbility;
    private final ICampaignReAssignParentScheduleJudgeForUpdateCampaignSchemaAbility campaignReAssignParentScheduleJudgeForUpdateCampaignSchemaAbility;
    private final CampaignViewPageConverter campaignViewConverter;
    private final CampaignAssignUnProgrammaticOrCptScheduleTaskIdentifier campaignAssignUnProgrammaticOrCptScheduleTaskIdentifier;
    private final CampaignAutoAssignScheduleTaskIdentifier campaignAutoAssignScheduleTaskIdentifier;
    private final CampaignInventoryAutoReleaseDiamondConfig campaignInventoryAutoReleaseDiamondConfig;
    private final ICampaignOperateDistLockGetAbility campaignOperateDistLockGetAbility;

    private final ResourcePackageRepository resourcePackageRepository;
    private final CampaignRepository campaignRepository;
    private final PerformRepository performRepository;
    private final BpmsRepository bpmsRepository;

    public void stopAndReleaseCampaign(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList) {
        if(CollectionUtils.isEmpty(campaignViewDTOList)){
            return;
        }
        // 计划下线
        campaignOnlineStatusUpdateAbility.handle(serviceContext, CampaignOnlineStatusUpdateAbilityParam.builder()
                .abilityTargets(campaignViewDTOList).targetOnlineStatus(BrandCampaignOnlineStatusEnum.OFFLINE.getCode()).build());

        // 对计划按是否走库存拆分，然后进行SPI扩展释量
        Map<Integer, List<CampaignViewDTO>> isInventoryCampaignMap = campaignInquiryChannelGetForCampaignInventoryOperateAbility.handle(serviceContext, CampaignInventoryOperateChannelGetAbilityParam.builder().abilityTargets(campaignViewDTOList).build());
        for (Map.Entry<Integer, List<CampaignViewDTO>> isInventoryCampaignEntry : isInventoryCampaignMap.entrySet()) {
            runAbilitySpi(BizCampaignInventorySpi.class, extension -> extension.releaseCampaign(serviceContext, isInventoryCampaignEntry.getValue()), CampaignScheduleIsInventoryEnum.getByValue(isInventoryCampaignEntry.getKey()).name());
        }
    }

    /**
     * 询锁量
     * @param serviceContext        上下文
     * @param inquiryOperateViewDTO   需要的父计划及其子计划信息
     */
    public void inventoryInquiryOrLock(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO) {
        //构建扩展参数
        BizCampaignInventoryWorkflowParam inventoryWorkflowParam = bizCampaignInventoryWorkflowExt.buildParamForInventory(serviceContext, inquiryOperateViewDTO);

        //获取订单分组操作并发锁
        List<Long> saleGroupIdList = Optional.ofNullable(inventoryWorkflowParam.getCampaignTreeViewDTOList()).orElse(Lists.newArrayList())
                .stream().map(campaignViewDTO -> campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId()).distinct().collect(Collectors.toList());
        saleGroupOperateDistLockGetAbility.handle(serviceContext,
                SaleGroupOperateDistLockAbilityParam.builder().abilityTargets(saleGroupIdList).build());

        //如果是锁量等相关操作，需要加锁(对一级计划)
        if (BizCampaignToolsHelper.needDistLockCampaign(inquiryOperateViewDTO.getOperateType())) {
            DistLockEnum distLockEnum = DistLockEnum.CAMPAIGN_LOCKING_KEY;
            List<String> lockKeyList = inventoryWorkflowParam.getCampaignTreeViewDTOList().stream().map(campaignViewDTO -> distLockEnum.formatLockKey(campaignViewDTO.getId())).collect(Collectors.toList());
            RogerLogger.info("BizCampaignInventoryWorkflow inventoryInquiryOrLock lockKeyList:{}", JSON.toJSONString(lockKeyList));
            String lockValue = distLockEnum.formatLockValue(DateUtils.currentTime(), serviceContext.getOperName());
            DistLockUtil.execute(lockKeyList, lockValue, distLockEnum.getExpireTime(), () -> {
                inventoryInquiryOrLock(serviceContext, inquiryOperateViewDTO, inventoryWorkflowParam);
                return null;
            },
            lockCurValue -> {
                String tryLockFailTip = String.format("计划正在发起锁量/释量/取消/超接等操作:%s，请稍后操作!", lockCurValue);
                throw new BrandOneBPException(BrandOneBPBaseErrorCode.DISTLOCK.of(tryLockFailTip));
            });
        } else {
            inventoryInquiryOrLock(serviceContext, inquiryOperateViewDTO, inventoryWorkflowParam);
        }
    }

    private void inventoryInquiryOrLock(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO, BizCampaignInventoryWorkflowParam inventoryWorkflowParam) {
        //step1、构建计划排期数据
        CampaignScheduleOperateTypeEnum operateTypeEnum = CampaignScheduleOperateTypeEnum.getByValue(inquiryOperateViewDTO.getOperateType());
        List<CampaignScheduleViewDTO> campaignScheduleViewDTOList = runAbilitySpi(BizCampaignInventoryOperateSpi.class,
                extension -> extension.convertToCampaignSchedule(serviceContext, inquiryOperateViewDTO, inventoryWorkflowParam), operateTypeEnum.name());
        inventoryWorkflowParam.setCampaignScheduleViewDTOList(campaignScheduleViewDTOList);

        //step2、计划排期校验
        ErrorCodeAware errorCodeAware = runAbilitySpi(BizCampaignInventoryOperateSpi.class,
                extension -> extension.validateCampaignInventoryOperate(serviceContext, inquiryOperateViewDTO, inventoryWorkflowParam), operateTypeEnum.name());

        //step3、库存操作
        RogerLogger.info("inquiryOperateViewDTO:{}, inventoryWorkflowParam:{}", JSON.toJSONString(inquiryOperateViewDTO), JSON.toJSONString(inventoryWorkflowParam));
        runAbilitySpi(BizCampaignInventoryOperateSpi.class,
                extension -> extension.inventoryRequest(serviceContext, inquiryOperateViewDTO, inventoryWorkflowParam), operateTypeEnum.name());

        //不为空则报错（业务允许部分成功）
        AssertUtil.assertTrue(Objects.isNull(errorCodeAware), errorCodeAware);
        // 后置
        bizCampaignInventoryWorkflowExt.afterInventoryInquiryOrLock(serviceContext, inventoryWorkflowParam, operateTypeEnum);
    }

    /**
     * 计划强制预定
     * @param serviceContext
     * @param inquiryOperateViewDTO
     */
    public void mandatoryLock(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO){
        //构建流程参数
        BizCampaignInventoryWorkflowParam inventoryWorkflowParam = bizCampaignInventoryWorkflowExt.buildParamForInventory(serviceContext, inquiryOperateViewDTO);
        //校验是否计划是否已提交流程
        if (CollectionUtils.isNotEmpty(inventoryWorkflowParam.getCampaignTreeViewDTOList())) {
            List<Long> approveCampaignIds = Lists.newArrayList();
            approveCampaignIds.addAll(inventoryWorkflowParam.getCampaignTreeViewDTOList().stream()
                    .filter(v -> BrandCampaignProcessStatusEnum.APPROVE_ING.getCode().equals(v.getCampaignInquiryLockViewDTO().getCampaignMandatoryLockViewDTO().getMandatoryLockProcessStatus()))
                    .map(campaignViewDTO -> campaignViewDTO.getId()).collect(Collectors.toList()));
            approveCampaignIds.addAll(inventoryWorkflowParam.getCampaignTreeViewDTOList().stream()
                    .filter(campaignViewDTO -> CollectionUtils.isNotEmpty(campaignViewDTO.getSubCampaignViewDTOList()))
                    .flatMap(campaignViewDTO -> campaignViewDTO.getSubCampaignViewDTOList().stream())
                    .filter(v -> {
                        Integer mandatoryLockProcessStatus = Optional.ofNullable(v.getCampaignInquiryLockViewDTO()).map(CampaignInquiryLockViewDTO::getCampaignMandatoryLockViewDTO).map(CampaignMandatoryLockViewDTO::getMandatoryLockProcessStatus).orElse(null);
                        return BrandCampaignProcessStatusEnum.APPROVE_ING.getCode().equals(mandatoryLockProcessStatus);
                    })
                    .map(campaignViewDTO -> campaignViewDTO.getParentCampaignId()).filter(Objects::nonNull).collect(Collectors.toList()));
            AssertUtil.assertTrue(approveCampaignIds.isEmpty(), "下列计划已提交超接审批，请重新选择计划：" + StringUtils.join(approveCampaignIds, BrandConstants.COMMA));
        }
        //step2、获取订单分组操作并发锁
        List<Long> saleGroupIdList = Optional.ofNullable(inventoryWorkflowParam.getCampaignTreeViewDTOList()).orElse(Lists.newArrayList())
                .stream().map(campaignViewDTO -> campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId()).distinct().collect(Collectors.toList());

        saleGroupOperateDistLockGetAbility.handle(serviceContext,SaleGroupOperateDistLockAbilityParam.builder().abilityTargets(saleGroupIdList).build());

        CampaignScheduleOperateTypeEnum operateTypeEnum = CampaignScheduleOperateTypeEnum.getByValue(inquiryOperateViewDTO.getOperateType());
        //构建计划排期
        List<CampaignScheduleViewDTO> campaignScheduleViewDTOList = runAbilitySpi(BizCampaignInventoryOperateSpi.class,
                extension -> extension.convertToCampaignSchedule(serviceContext, inquiryOperateViewDTO, inventoryWorkflowParam), operateTypeEnum.name());
        inventoryWorkflowParam.setCampaignScheduleViewDTOList(campaignScheduleViewDTOList);
        //计划库存操作校验
        ErrorCodeAware errorCodeAware = runAbilitySpi(BizCampaignInventoryOperateSpi.class,
                extension -> extension.validateCampaignInventoryOperate(serviceContext, inquiryOperateViewDTO, inventoryWorkflowParam), operateTypeEnum.name());
        AssertUtil.assertTrue(Objects.isNull(errorCodeAware), errorCodeAware);
        //导出计划排期
        ScheduleExportQueryViewDTO scheduleExportQueryViewDTO = new ScheduleExportQueryViewDTO();
        scheduleExportQueryViewDTO.setCampaignGroupId(inventoryWorkflowParam.getCampaignGroupViewDTOList().get(0).getId());
        scheduleExportQueryViewDTO.setIdentityTypeCode("ALI_EMPLOYEE");
        scheduleExportQueryViewDTO.setCampaignIdList(inquiryOperateViewDTO.getCampaignIdList());
        ScheduleExportContext scheduleExportContext = bizScheduleExportWorkflow.initContext(scheduleExportQueryViewDTO);
        scheduleExportContext.setNeedPermanentExportUrl(true);
        String ossUrl = bizScheduleExportWorkflow.exportSchedule(serviceContext, scheduleExportContext);
        inquiryOperateViewDTO.setUrl(ossUrl);
        //强制占量审批流
        mandatoryLockApplyProcessInstance(serviceContext, inventoryWorkflowParam.getCampaignGroupViewDTOList(),inventoryWorkflowParam.getCampaignTreeViewDTOList(), inquiryOperateViewDTO);
    }

    /**
     * 库存询锁量回调
     *
     * @param context
     * @param inquiryOperateViewDTO
     */
    public void inventoryInquiryOrLockCallback(ServiceContext context, CampaignInquiryOperateViewDTO inquiryOperateViewDTO) {
        try {
            //解析库存回调响应数据
            UniResponse uniResponse = campaignInventoryResponseParseForCampaignInventoryCallbackAbility.handle(context,
                    CampaignInventoryResponseParseAbilityParam.builder().abilityTarget(inquiryOperateViewDTO).build());
            inquiryOperateViewDTO.setCampaignIdList(Lists.newArrayList(uniResponse.getBusinessId()));
            //查询计划信息
            CampaignViewDTO campaignTreeViewDTO = getCampaignTreeViewDTO(context, uniResponse);
            //校验库存回调结果，未分配需要将状态进行回退，如询量中回退到询量失败
            campaignInventoryResponseValidateForCampaignInventoryCallbackAbility.handle(context, CampaignInventoryResponseValidateAbilityParam.builder()
                    .abilityTarget(campaignTreeViewDTO).response(uniResponse).operateType(inquiryOperateViewDTO.getOperateType()).build());

            //构建查询数据
            BizCampaignInventoryWorkflowParam inventoryWorkflowParam = bizCampaignInventoryWorkflowExt.buildParamForInventory(context, inquiryOperateViewDTO);
            //获取订单分组操作并发锁
            List<Long> saleGroupIdList = Optional.ofNullable(inventoryWorkflowParam.getCampaignTreeViewDTOList()).orElse(Lists.newArrayList())
                    .stream().map(campaignViewDTO -> campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId()).distinct().collect(Collectors.toList());
            saleGroupOperateDistLockGetAbility.handle(context,SaleGroupOperateDistLockAbilityParam.builder().abilityTargets(saleGroupIdList).build());

            CampaignScheduleOperateTypeEnum operateTypeEnum = CampaignScheduleOperateTypeEnum.getByValue(inquiryOperateViewDTO.getOperateType());
            //构建计划排期
            List<CampaignScheduleViewDTO> campaignScheduleViewDTOList = runAbilitySpi(BizCampaignInventoryOperateSpi.class,
                    extension -> extension.convertToCampaignSchedule(context, inquiryOperateViewDTO, inventoryWorkflowParam), operateTypeEnum.name());
            inventoryWorkflowParam.setCampaignScheduleViewDTOList(campaignScheduleViewDTOList);
            //库存回调操作校验
            runAbilitySpi(BizCampaignInventoryOperateSpi.class,
                    extension -> extension.validateCampaignInventoryOperate(context, inquiryOperateViewDTO, inventoryWorkflowParam), operateTypeEnum.name());
            //库存询锁量结果处理
            runAbilitySpi(BizCampaignInventoryOperateSpi.class,
                    extension -> extension.inventoryRequest(context, inquiryOperateViewDTO, inventoryWorkflowParam), operateTypeEnum.name());
            //后置链路处理
            bizCampaignInventoryWorkflowExt.afterInventoryCallback(context, inquiryOperateViewDTO, inventoryWorkflowParam, campaignScheduleViewDTOList);
        } catch (Exception e) {
            if (e instanceof BrandOneBPException) {
                ErrorCodeAware errorCodeEnum = BrandOneBPException.getErrorCodeFromException(e);
                //「参数异常」AMB不重试，需要报警；
                if (PARAM_ERROR_CODE_SET.contains(errorCodeEnum.getErrCode())) {
                    // 故意将日志和异常堆栈分开打印，因为合在一起发到报警群，内容太多
                    RogerLogger.error(String.format("inventoryInquiryOrLockCallback param error, message: %s", e.getMessage()));
                    RogerLogger.error(String.format("param error, message: %s", e.getMessage()), e);
                //「系统异常」「外部调用异常」AMB重试，需要报警；
                } else if (SYSTEM_ERROR_CODE_SET.contains(errorCodeEnum.getErrCode()) || EXTERNAL_ERROR_CODE_SET.contains(errorCodeEnum.getErrCode())) {
                    RogerLogger.error(String.format("inventoryInquiryOrLockCallback system or external error, message: %s", e.getMessage()));
                    RogerLogger.error(String.format("system or external error, message: %s", e.getMessage()), e);
                    throw e;
                //「操作异常」AMB重试，不需要报警；
                } else if (OPERATION_ERROR_CODE_SET.contains(errorCodeEnum.getErrCode())) {
                    RogerLogger.info("inventoryInquiryOrLockCallback operate error, message:{}", e.getMessage(), e);
                    throw e;
                //「业务异常」AMB不重试，不需要报警；
                } else if(BIZ_UN_SUPPORT_ERROR_CODE_SET.contains(errorCodeEnum.getErrCode())){
                    RogerLogger.error("inventoryInquiryOrLockCallback biz error, message:{}", e.getMessage(), e);
                }else {
                    RogerLogger.info("inventoryInquiryOrLockCallback biz error, message:{}", e.getMessage(), e);
                }
            // 非BrandOneBPException，AMB重试，且需要报警
            } else {
                RogerLogger.error(String.format("inventoryInquiryOrLockCallback other error, message: %s", e.getMessage()));
                RogerLogger.error(String.format("other error, message: %s", e.getMessage()), e);
                throw e;
            }
        }
    }

    /**
     * 滚量日更
     */
    public void dailyUpdate(ServiceContext context, CampaignInquiryOperateViewDTO inquiryOperateViewDTO, List<CampaignViewDTO> scrollDailyFlatCampaignList) {
        //构建查询数据
        BizCampaignInventoryWorkflowParam inventoryWorkflowParam = bizCampaignInventoryWorkflowExt.buildParamForInventory(context, inquiryOperateViewDTO);
        List<CampaignViewDTO> originalDbCampaignTreeList = campaignViewPageConverter.convertCampaignSelf(inventoryWorkflowParam.getCampaignTreeViewDTOList());
        //构建滚量数据
        List<CampaignViewDTO> filterTreeList = campaignScheduleScrollBuildAbility.handle(context, CampaignScheduleScrollBuildAbilityParam.builder().abilityTarget(inquiryOperateViewDTO)
                .sourceCampaignViewDTOList(scrollDailyFlatCampaignList).targetCampaignViewDTOList(originalDbCampaignTreeList).build());
        inventoryWorkflowParam.setCampaignTreeViewDTOList(filterTreeList);

        CampaignScheduleOperateTypeEnum operateTypeEnum = CampaignScheduleOperateTypeEnum.getByValue(inquiryOperateViewDTO.getOperateType());

        List<CampaignScheduleViewDTO> campaignScheduleViewDTOList = runAbilitySpi(BizCampaignInventoryOperateSpi.class,
                extension -> extension.convertToCampaignSchedule(context, inquiryOperateViewDTO, inventoryWorkflowParam), operateTypeEnum.name());
        inventoryWorkflowParam.setCampaignScheduleViewDTOList(campaignScheduleViewDTOList);
        //请求库存
        runAbilitySpi(BizCampaignInventoryOperateSpi.class,
                extension -> extension.inventoryRequest(context, inquiryOperateViewDTO, inventoryWorkflowParam), operateTypeEnum.name());
        //更新父子计划,存在用merge的dbCampaignTreeList，不用filterTreeList
//        bizCampaignInventoryWorkflowExt.updateCampaignScroll(context, originalDbCampaignTreeList);
        campaignScheduleScrollUpdateAbility.handle(context,CampaignScheduleScrollAbilityParam.builder().abilityTargets(originalDbCampaignTreeList).build());
    }

    /**
     * 库存自动释量预计
     * @param context
     * @param campaignInventoryAutoReleaseMsgViewDTOList
     */
    public void inventoryAutoReleaseWarning(ServiceContext context, List<CampaignInventoryAutoReleaseMsgViewDTO> campaignInventoryAutoReleaseMsgViewDTOList){
        //参数校验
        bizCampaignInventoryWorkflowExt.beforeInventoryAutoReleaseWarning(context,campaignInventoryAutoReleaseMsgViewDTOList);
        //排期导出
        for (CampaignInventoryAutoReleaseMsgViewDTO campaignInventoryAutoReleaseMsgViewDTO : campaignInventoryAutoReleaseMsgViewDTOList) {
            BrandCampaignInventoryAutoReleaseWarningTypeEnum releaseWarningTypeEnum =
                    BrandCampaignInventoryAutoReleaseWarningTypeEnum.getByCode(campaignInventoryAutoReleaseMsgViewDTO.getWarningType());
            if(releaseWarningTypeEnum == BrandCampaignInventoryAutoReleaseWarningTypeEnum.SINGLE
                    || releaseWarningTypeEnum == BrandCampaignInventoryAutoReleaseWarningTypeEnum.RELEASE){
                try{
                    ScheduleExportQueryViewDTO scheduleExportQueryViewDTO = new ScheduleExportQueryViewDTO();
                    CampaignGroupViewDTO campaignGroupViewDTO = campaignInventoryAutoReleaseMsgViewDTO.getCampaignGroupViewDTO();
                    scheduleExportQueryViewDTO.setCampaignGroupId(campaignGroupViewDTO.getId());
                    scheduleExportQueryViewDTO.setIdentityTypeCode("ALI_EMPLOYEE");
                    ScheduleExportContext scheduleExportContext = bizScheduleExportWorkflow.initContext(scheduleExportQueryViewDTO);
                    ServiceContext serviceContext = ServiceContextUtil.buildServiceContextForSceneId(campaignGroupViewDTO.getMemberId(), campaignGroupViewDTO.getSceneId());
                    String ossUrl = bizScheduleExportWorkflow.exportSchedule(serviceContext, scheduleExportContext);
                    campaignInventoryAutoReleaseMsgViewDTO.setCdnUrl(ossUrl);
                } catch (Exception e) {
                    RogerLogger.error("自动释量预警邮件导出排期文件链接失败 {}", e.getMessage(), e);
                }
            }
        }
        //发送释量预警消息
        bizCampaignMessageWorkflow.sendInventoryAutoReleaseWarningMessage(context,campaignInventoryAutoReleaseMsgViewDTOList);
    }

    /**
     * 筛选符合条件的计划
     * 1. 一级锁量计划
     * 2. 计划所属分组在订单上的下单状态是未下单
     *
     * @param campaignInventoryAutoReleaseQueryViewDTO
     * @return
     */
    private List<CampaignViewDTO> findSpecifiedCampaignViewDTOList(CampaignInventoryAutoReleaseQueryViewDTO campaignInventoryAutoReleaseQueryViewDTO) {
        List<CampaignViewDTO> campaignViewDTOList = campaignInventoryAutoReleaseQueryViewDTO.getCampaignViewDTOList();
        Map<Long, CampaignGroupViewDTO> campaignGroupViewDTOMap = campaignInventoryAutoReleaseQueryViewDTO.getCampaignGroupViewDTOList().stream().collect(Collectors.toMap((campaignGroupViewDTO -> campaignGroupViewDTO.getId()), Function.identity(), (v1, v2) -> v1));
        return campaignViewDTOList.stream()
                .filter(campaignViewDTO -> BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode().equals(campaignViewDTO.getCampaignLevel()))
                .filter(campaignViewDTO -> BrandCampaignStatusEnum.LOCK_SUCCESS.getCode().equals(campaignViewDTO.getStatus()))
                .filter(campaignViewDTO -> Objects.nonNull(campaignViewDTO.getCampaignSaleViewDTO()))
                .filter(campaignViewDTO -> {
                    Map<Long, SaleGroupInfoViewDTO> saleGroupInfoViewDTOMap = Optional.ofNullable(campaignGroupViewDTOMap.get(campaignViewDTO.getCampaignGroupId()))
                            .map(CampaignGroupViewDTO::getCampaignGroupSaleGroupViewDTO)
                            .map(CampaignGroupSaleGroupViewDTO::getSaleGroupInfoViewDTOList)
                            .map(saleGroupInfoViewDTOS -> saleGroupInfoViewDTOS.stream().collect(Collectors.toMap((SaleGroupInfoViewDTO::getSaleGroupId), Function.identity(), (v1, v2) -> v1)))
                            .orElse(Maps.newHashMap());
                    return Optional.ofNullable(saleGroupInfoViewDTOMap.get(campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId()))
                            .map(saleGroupInfoViewDTO -> BrandCampaignGroupSaleOrderStatusEnum.WAIT_ORDER.getCode().equals(saleGroupInfoViewDTO.getSaleGroupStatus()))
                            .orElse(false);
                })
                .collect(Collectors.toList());
    }

    public Response availAmountLock(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO) {
        AssertUtil.notNull(inquiryOperateViewDTO, "查询参数不能为空");
        AssertUtil.notEmpty(inquiryOperateViewDTO.getCampaignIdList(), "锁量计划不能为空");

        CampaignQueryViewDTO query = CampaignQueryViewDTO.builder().campaignIds(inquiryOperateViewDTO.getCampaignIdList()).build();
        CampaignQueryOption option = CampaignQueryOption.builder().needCampaignTree(true).needTarget(true).needFrequency(true).build();
        List<CampaignViewDTO> campaignViewDTOList = campaignStructureQueryAbility.handle(serviceContext,CampaignStructureQueryAbilityParam.builder().abilityTarget(query).queryOption(option).build());

        resetAvailAmountLockParam(serviceContext,campaignViewDTOList,inquiryOperateViewDTO);
        inquiryOperateViewDTO.setOperateType(CampaignScheduleOperateTypeEnum.LOCK.getValue());
        inventoryInquiryOrLock(serviceContext,inquiryOperateViewDTO);
        return Response.success();
    }

    /**
     * 非系统投放和二环CPT场景，预分配计划库存预定量
     * @param serviceContext
     * @param campaignViewDTOList
     */
    public void preAssignUnProgrammaticOrCptCampaignSchedule(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList) {
        List<CampaignViewDTO> unProgrammaticOrCptCampaignList = campaignViewDTOList.stream().filter(campaignViewDTO -> {
            Boolean isUnProgrammatic = BizCampaignToolsHelper.isUnProgrammatic(campaignViewDTO.getSspProgrammatic(), campaignViewDTO.getCampaignType());
            if(isUnProgrammatic){
                return true;
            }
            return BizCampaignToolsHelper.isTwoCPT(campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope(), campaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterUnit());
        }).collect(Collectors.toList());

        //自动设置一级计划和二级计划预定量
        for (CampaignViewDTO campaignViewDTO : unProgrammaticOrCptCampaignList) {
            preAssignUnProgrammaticOrCptCampaignSchedule(serviceContext, campaignViewDTO);
            if (CollectionUtils.isNotEmpty(campaignViewDTO.getSubCampaignViewDTOList())) {
                for (CampaignViewDTO subViewDTO : campaignViewDTO.getSubCampaignViewDTOList()) {
                    preAssignUnProgrammaticOrCptCampaignSchedule(serviceContext, subViewDTO);
                }
            }
        }
    }

    /**
     * 非系统投放和二环CPT场景，分配计划排期预定量
     * @param serviceContext
     * @param campaignViewDTOList
     */
    public void executeAssignUnProgrammaticOrCptCampaignSchedule(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList){
        List<CampaignViewDTO> unProgrammaticOrCptCampaignList = campaignViewDTOList.stream().filter(campaignViewDTO -> {
            Boolean isUnProgrammatic = BizCampaignToolsHelper.isUnProgrammatic(campaignViewDTO.getSspProgrammatic(),
                    campaignViewDTO.getCampaignType());
            if(isUnProgrammatic){
                return isUnProgrammatic;
            }
            return BizCampaignToolsHelper.isTwoCPT(campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope(), campaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterUnit());
        }).collect(Collectors.toList());
        //更新CPT计划询锁量排期及设置信息
        if(CollectionUtils.isNotEmpty(unProgrammaticOrCptCampaignList)){
            List<Long> unProgrammaticOrCptCampaignIdList = TaskStream.execute(campaignAssignUnProgrammaticOrCptScheduleTaskIdentifier, unProgrammaticOrCptCampaignList, (campaignViewDTO, index) -> {
                campaignScheduleUpdateAbility.handle(serviceContext, CampaignScheduleUpdateAbilityParam.builder().abilityTarget(campaignViewDTO).build());
                return campaignViewDTO.getId();
            }).commit().getResultList();
            RogerLogger.info("非系统投放和二环CPT场景每天库存预定量设置成功，campaignIds={}", JSON.toJSONString(unProgrammaticOrCptCampaignIdList));
        }
    }

    /**
     * 预设计划排期预定量
     * @param serviceContext
     * @param campaignViewDTO
     */
    public void preAssignUnProgrammaticOrCptCampaignSchedule(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {
        CampaignScheduleViewDTO campaignScheduleViewDTO = new CampaignScheduleViewDTO();
        campaignScheduleViewDTO.setId(campaignViewDTO.getId());
        campaignScheduleViewDTO.setInquiryAssignType(BrandCampaignInquiryAssignTypeEnum.BY_DAY.getCode());
        campaignScheduleViewDTO.setIsAutoAssign(true);

        //已有过预定量设置的占位计划，不进行自动分配预定量
        Boolean isUnProgrammatic = BizCampaignToolsHelper.isUnProgrammatic(campaignViewDTO.getSspProgrammatic(), campaignViewDTO.getCampaignType());
        if(isUnProgrammatic){
            List<CampaignInquiryViewDTO> campaignInquiryViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignInquiryLockViewDTO())
                    .map(CampaignInquiryLockViewDTO::getCampaignInquiryViewDTOList).orElse(Lists.newArrayList());
            campaignScheduleViewDTO.setInquiryViewDTOList(campaignInquiryViewDTOList);
        }
        List<CampaignInquiryViewDTO> campaignInquiryViewDTOList = this.autoAssignCampaignSchedule(serviceContext, campaignViewDTO, campaignScheduleViewDTO);

        CampaignInquiryLockViewDTO campaignInquiryLockViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignInquiryLockViewDTO()).orElse(new CampaignInquiryLockViewDTO());
        campaignInquiryLockViewDTO.setCampaignInquiryViewDTOList(campaignInquiryViewDTOList);
        campaignViewDTO.setCampaignInquiryLockViewDTO(campaignInquiryLockViewDTO);
    }

    /**
     * 自动分配库存预定量排期，分配策略如下：
     * <p>
     *     <h3>scheduleViewDTO.inquiryViewDTOList.isNotEmpty：按照设置的分天预定量进行分配</h3>
     *     <h3>scheduleViewDTO.inquiryViewDTOList.isEmpty：按照设置的区间分配策略（inquiryAssignType）进行自动分配 </h3>
     * </p>
     * <p>
     *     <h3>scheduleViewDTO核心参数：</h3>
     *     scheduleViewDTO.setId(subCampaignViewDTO.getId()); 计划id
     *     scheduleViewDTO.setInquiryAssignType(BrandCampaignInquiryAssignTypeEnum); 分配策略
     *     scheduleViewDTO.setSchedulePolicyList(inquiryAvailableScheduleDateList); 周期分配比例(周期策略时有效)
     *     scheduleViewDTO.setInquiryViewDTOList(inquiryViewDTOList); 周期预定量
     *     scheduleViewDTO.setIsAutoAssign(true/false); 未来预定量为空时，是否自动设置周期预定量
     * </p>
     * @param serviceContext
     * @param campaignViewDTO
     * @param campaignScheduleViewDTO
     */
    public List<CampaignInquiryViewDTO> autoAssignCampaignSchedule(ServiceContext serviceContext,CampaignViewDTO campaignViewDTO,CampaignScheduleViewDTO campaignScheduleViewDTO){
        if(!Constant.CAN_INQUIRY_LOCK_STATUS.contains(campaignViewDTO.getStatus())){
            RogerLogger.info("计划（{}）已处于锁量状态={}，不允许更改预定量",campaignViewDTO.getId(),campaignViewDTO.getStatus());
            return Optional.ofNullable(campaignViewDTO.getCampaignInquiryLockViewDTO()).map(CampaignInquiryLockViewDTO::getCampaignInquiryViewDTOList).orElse(Lists.newArrayList());
        }
        RogerLogger.info("计划排期预定量自动设置：{}", JSON.toJSONString(campaignScheduleViewDTO));
        CampaignScheduleCalculateAbilityParam calculateAbilityParam =
                CampaignScheduleCalculateAbilityParam.builder().abilityTarget(campaignScheduleViewDTO).campaignViewDTO(campaignViewDTO).build();
        //1、计算计划未来可用预定量
        campaignFutureAmountCalculateAbility.handle(serviceContext,calculateAbilityParam);
        //2、计划分天未来预定量
        campaignScheduleFutureInquiryAssignAbility.handle(serviceContext,calculateAbilityParam);
        //3、计划全部预定量：历史的预定量+未来的预定量
        List<CampaignInquiryViewDTO> campaignInquiryViewDTOList = Lists.newArrayList();
        if(CollectionUtils.isNotEmpty(campaignScheduleViewDTO.getHistoryInquiryList())){
            campaignInquiryViewDTOList.addAll(campaignScheduleViewDTO.getHistoryInquiryList());
        }
        if(CollectionUtils.isNotEmpty(campaignScheduleViewDTO.getFutureInquiryList())){
            campaignInquiryViewDTOList.addAll(campaignScheduleViewDTO.getFutureInquiryList());
        }
        campaignScheduleViewDTO.setInquiryViewDTOList(campaignInquiryViewDTOList);
        //4、校验分配总预定量和计划预定量是否相等
        campaignInquiryAmountEqualsValidateAbility.handle(serviceContext,calculateAbilityParam);
        return campaignInquiryViewDTOList;
    }

    /**
     * 更新库存询锁量操作计划状态
     * @param serviceContext
     * @param campaignScheduleViewDTOList
     */
    public void updateInventoryOperateCampaignStatus(ServiceContext serviceContext, List<CampaignScheduleViewDTO> campaignScheduleViewDTOList) {
        if (CollectionUtils.isEmpty(campaignScheduleViewDTOList)) {
            return;
        }
        Integer globalOperateType = campaignScheduleViewDTOList.get(0).getOperateType();
        if (CampaignScheduleOperateTypeEnum.SCROLL_DAILY_UPDATE.isSelf(globalOperateType)) {
            return;
        }
        //计划状态转换
        for (CampaignScheduleViewDTO campaignScheduleViewDTO : campaignScheduleViewDTOList) {
            campaignStatusConvertForCampaignInventoryOperateAbility.handle(serviceContext,
                    CampaignInventoryOperateStatusConvertAbilityParam.builder().abilityTarget(campaignScheduleViewDTO).build());
        }
        //计划库存操作更新
        for (CampaignScheduleViewDTO campaignScheduleViewDTO : campaignScheduleViewDTOList) {
            List<Long> operateSubCampaignIds = campaignScheduleViewDTO.getOperateSubCampaignIds();
            if(CollectionUtils.isNotEmpty(operateSubCampaignIds)) {
                for (CampaignScheduleViewDTO subScheduleViewDTO : campaignScheduleViewDTO.getSubCampaignList()) {
                    if (operateSubCampaignIds.contains(subScheduleViewDTO.getId())) {
                        campaignUpdateForCampaignInventoryOperateAbility.handle(serviceContext,
                                CampaignInventoryOperateUpdateAbilityParam.builder().abilityTarget(subScheduleViewDTO).build());
                    }
                }
                campaignUpdateForCampaignInventoryOperateAbility.handle(serviceContext,
                        CampaignInventoryOperateUpdateAbilityParam.builder().abilityTarget(campaignScheduleViewDTO).build());
                // 锁量回调中一级计划锁量成功时设置锁量有效期
                fire(serviceContext, campaignScheduleViewDTO);
            }
        }
    }

    /**
     * 锁量回调中一级计划锁量成功时设置锁量有效期
     * TODO 该操作移到库存询锁量回调链路中
     */
    private void fire(ServiceContext serviceContext, CampaignScheduleViewDTO campaignScheduleViewDTO) {
        if(CampaignScheduleOperateTypeEnum.LOCK_CALLBACK.isSelf(campaignScheduleViewDTO.getOperateType())
                && BrandCampaignStatusEnum.LOCK_SUCCESS.getCode().equals(campaignScheduleViewDTO.getStatus())) {
            // CampaignScheduleViewDTO转CampaignViewDTO，二级计划也会同步转
            CampaignViewDTO campaignViewDTO = campaignViewConverter.convertScheduleViewDTO2View(campaignScheduleViewDTO);
            CampaignNoticeContext noticeContext = CampaignNoticeContext.builder().serviceContext(serviceContext).campaignViewDTO(campaignViewDTO).build();
            RogerLogger.info("一级计划锁量有效期初始化 " + campaignViewDTO.getId() + " fire start");
            messageSyncSendAbility.handle(serviceContext, MessageSyncSendAbilityParam.builder()
                    .abilityTarget(CampaignLockExpireTimeInitEvent.of(noticeContext)).build());

            RogerLogger.info("一级计划锁量有效期初始化 " + campaignViewDTO.getId() + " fire success");
        }
    }

    /**
     * 获取计划信息
     * @param serviceContext
     * @param uniResponse
     * @return
     */
    private CampaignViewDTO getCampaignTreeViewDTO(ServiceContext serviceContext,UniResponse uniResponse){
        serviceContext.setMemberId(uniResponse.getMemberId());
        CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder().campaignIds(Lists.newArrayList(uniResponse.getBusinessId())).build();
        List<CampaignViewDTO> campaignViewDTOList = campaignStructureQueryAbility.handle(serviceContext, CampaignStructureQueryAbilityParam.builder().abilityTarget(campaignQueryViewDTO)
                .queryOption(CampaignQueryOption.builder().needCampaignTree(true).build()).build());
        AssertUtil.notEmpty(campaignViewDTOList,"计划不存在");

        CampaignViewDTO campaignTreeViewDTO = campaignViewDTOList.get(0);
        //重新设置上下文
        ServiceContextUtil.reAssignServiceContext(serviceContext,campaignTreeViewDTO.getSceneId());
        return campaignTreeViewDTO;
    }
    /**
     * 强制锁量申请工作流
     * @param serviceContext
     * @param campaignGroupViewDTOList
     * @param campaignTreeViewDTOList
     * @param inquiryOperateViewDTO
     */
    private void mandatoryLockApplyProcessInstance(ServiceContext serviceContext, List<CampaignGroupViewDTO> campaignGroupViewDTOList,
                                                   List<CampaignViewDTO> campaignTreeViewDTOList, CampaignInquiryOperateViewDTO inquiryOperateViewDTO) {
        // initData
        Map<String, String> initDataMap = campaignInventoryMandatoryLockProcessParamBuildAbility.handle(serviceContext,CampaignInventoryMandatoryLockProcessAbilityParam.builder()
                .abilityTarget(inquiryOperateViewDTO).campaignGroupViewDTO(campaignGroupViewDTOList.get(0)).campaignTreeViewDTOList(campaignTreeViewDTOList).build());
        // title
        String title = initDataMap.get("customerName") + "-" + initDataMap.get("memberName") + initDataMap.get("name") + "-的超接申请";
        String titleEn = "Brand OneBP Mandatory Lock Apply";
        String processInstanceId = bpmsRepository.startProcessInstance(title, titleEn, inquiryOperateViewDTO.getCreatorId(), initDataMap,
                BpmsProcessCodeEnum.CAMPAIGN_MANDATORY_LOCK_APPLY);
        RogerLogger.info("mandatoryLockApply processInstanceId={},initDataMap={}", processInstanceId, JSON.toJSONString(initDataMap));
        //流程id统一放在子计划上
        List<CampaignViewDTO> campaignViewDTOList = campaignTreeViewDTOList.stream().map(campaignViewDTO -> {
            List<CampaignViewDTO> campaigns = Lists.newArrayList();
            if (inquiryOperateViewDTO.getCampaignIdList().contains(campaignViewDTO.getId())) {
                campaigns.addAll(campaignViewDTO.getSubCampaignViewDTOList());
                return campaigns;
            }
            if (org.apache.commons.collections4.CollectionUtils.isNotEmpty(campaignViewDTO.getSubCampaignViewDTOList())) {
                campaigns.addAll(campaignViewDTO.getSubCampaignViewDTOList()
                        .stream().filter(v -> inquiryOperateViewDTO.getCampaignIdList().contains(v.getId())).collect(Collectors.toList()));
            }
            return campaigns;
        }).flatMap(Collection::stream).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(campaignViewDTOList)) {
            List<CampaignViewDTO> updatedCampaignViewDTOList = campaignViewDTOList.stream().map(campaignViewDTO -> {
                CampaignViewDTO updatedCampaignViewDTO = new CampaignViewDTO();
                updatedCampaignViewDTO.setId(campaignViewDTO.getId());

                CampaignMandatoryLockViewDTO mandatoryLockViewDTO = new CampaignMandatoryLockViewDTO();
                mandatoryLockViewDTO.setMandatoryLockProcessStatus(BrandCampaignProcessStatusEnum.APPROVE_ING.getCode());
                mandatoryLockViewDTO.setMandatoryLockProcessId(processInstanceId);

                CampaignInquiryLockViewDTO campaignInquiryLockViewDTO = new CampaignInquiryLockViewDTO();
                campaignInquiryLockViewDTO.setCampaignMandatoryLockViewDTO(mandatoryLockViewDTO);

                updatedCampaignViewDTO.setCampaignInquiryLockViewDTO(campaignInquiryLockViewDTO);
                return updatedCampaignViewDTO;
            }).collect(Collectors.toList());
            campaignRepository.updateCampaignPart(serviceContext, updatedCampaignViewDTOList);
        }
    }

    /**
     * 锁量成功时计算一级计划锁量有效期
     */
    public Date calculateLockExpireTime(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {
        Date mediaInventoryLockExpireTime = campaignMediaInventoryLockExpireTimeCalculateAbility.handle(serviceContext,
                CampaignMediaInventoryLockExpireTimeCalculateAbilityParam.builder().abilityTarget(campaignViewDTO).build());
        return campaignLockExpireTimeCalculateAbility.handle(serviceContext,
                CampaignLockExpireTimeCalculateAbilityParam.builder().mediaInventoryLockExpireTime(mediaInventoryLockExpireTime).abilityTarget(campaignViewDTO).build());
    }

    /**
     * 重新计算一级计划锁量有效期
     */
    public Date recalculateLockExpireTime(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {
        Date mediaInventoryLockExpireTime = campaignMediaInventoryLockExpireTimeCalculateAbility.handle(serviceContext,
                CampaignMediaInventoryLockExpireTimeCalculateAbilityParam.builder().abilityTarget(campaignViewDTO).build());
        return campaignLockExpireTimeRecalculateAbility.handle(serviceContext, CampaignLockExpireTimeRecalculateAbilityParam.builder()
                .abilityTarget(campaignViewDTO.getCampaignInquiryLockViewDTO())
                .mediaInventoryLockExpireTime(mediaInventoryLockExpireTime)
                .campaignId(campaignViewDTO.getId()).build()
        );
    }

    /**
     * 构建单计划的释量预警/锁量延期申请信息
     */
    private CampaignInventoryAutoReleaseStatusViewDTO buildCampaignInventoryAutoReleaseStatusViewDTO(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {
        Date updateLockExpireTime = recalculateLockExpireTime(serviceContext, campaignViewDTO);
        return campaignInventoryAutoReleaseWarningBuildAbility.handle(serviceContext, CampaignInventoryAutoReleaseWarningBuildAbilityParam.builder()
                .abilityTarget(campaignViewDTO.getCampaignInquiryLockViewDTO()).campaignViewDTO(campaignViewDTO)
                .calculateLockExpireTime(updateLockExpireTime).build());
    }

    /**
     * 批量计算锁量有效期、预警状态、延期审批状态 for前端渲染以及锁量延期状态判断
     */
    public List<CampaignInventoryAutoReleaseStatusViewDTO> calculateAutoReleaseStatus(ServiceContext serviceContext, CampaignInventoryAutoReleaseQueryViewDTO campaignInventoryAutoReleaseQueryViewDTO) {
        List<CampaignInventoryAutoReleaseStatusViewDTO> result = Lists.newArrayList();

        // 1. 筛选符合条件的计划(一级计划并且所属分组的下单状态是未下单，并且计划是锁量状态)
        List<CampaignViewDTO> campaignViewDTOList = findSpecifiedCampaignViewDTOList(campaignInventoryAutoReleaseQueryViewDTO);

        if (CollectionUtils.isNotEmpty(campaignViewDTOList)) {
            campaignViewDTOList.forEach(campaignViewDTO -> {
                // 2. 实时计算预警状态，注意页面实时渲染使用的查库的锁量有效期，而不是这里可能更新的锁量有效期（仅供定时任务更新使用）
                CampaignInventoryAutoReleaseStatusViewDTO campaignInventoryAutoReleaseStatusViewDTO = buildCampaignInventoryAutoReleaseStatusViewDTO(serviceContext, campaignViewDTO);
                if (Objects.nonNull(campaignInventoryAutoReleaseStatusViewDTO)) {
                    // 3. 补全是否可申请延期信息
                    Integer delayReleaseProcessStatus = Optional.ofNullable(campaignViewDTO.getCampaignInquiryLockViewDTO())
                            .map(CampaignInquiryLockViewDTO::getCampaignDelayReleaseViewDTO).map(CampaignDelayReleaseViewDTO::getDelayReleaseProcessStatus)
                            .orElse(null);
                    campaignInventoryAutoReleaseStatusViewDTO.setDelayReleaseProcessStatus(delayReleaseProcessStatus);
                    // 是预警状态并且不是审批中的才可以重新申请
                    if (BrandBoolEnum.BRAND_TRUE.getCode().equals(campaignInventoryAutoReleaseStatusViewDTO.getWarningStatus())
                            && !BrandCampaignProcessStatusEnum.APPROVE_ING.getCode().equals(delayReleaseProcessStatus)) {
                        campaignInventoryAutoReleaseStatusViewDTO.setDelayApplyQualifyStatus(BrandBoolEnum.BRAND_FALSE.getCode());
                    } else {
                        campaignInventoryAutoReleaseStatusViewDTO.setDelayApplyQualifyStatus(BrandBoolEnum.BRAND_TRUE.getCode());
                    }

                    result.add(campaignInventoryAutoReleaseStatusViewDTO);
                }
            });
        }
        RogerLogger.info("预警状态、延期申请状态计算 for 前端渲染计算与延期申请 {}", result);
        return result;
    }

    /**
     * 计算释量预警状态
     */
    public List<CampaignInventoryAutoReleaseStatusViewDTO> calculateInventoryWarningStatus(ServiceContext serviceContext, CampaignInventoryAutoReleaseQueryViewDTO campaignInventoryAutoReleaseQueryViewDTO) {

        List<CampaignInventoryAutoReleaseStatusViewDTO> result = Lists.newArrayList();

        // 1. 筛选符合条件的计划(一级计划并且所属分组的下单状态是未下单，并且计划是锁量状态)
        List<CampaignViewDTO> campaignViewDTOList = findSpecifiedCampaignViewDTOList(campaignInventoryAutoReleaseQueryViewDTO);
        // 2. 计算锁量有效期信息是否满足预警条件，注意区分预警类型
        if (CollectionUtils.isNotEmpty(campaignViewDTOList)) {
            RogerLogger.info("符合条件的计划为 {}", JSON.toJSONString(campaignViewDTOList));
            campaignViewDTOList.forEach(campaignViewDTO -> {
                CampaignInventoryAutoReleaseStatusViewDTO autoReleaseStatusViewDTO = buildCampaignInventoryAutoReleaseStatusViewDTO(serviceContext, campaignViewDTO);
                if (Objects.nonNull(autoReleaseStatusViewDTO)) {
                    result.add(autoReleaseStatusViewDTO);
                }
            });
        }
        return result;
    }

    /**
     * 计算释量状态
     */
    public List<CampaignInventoryAutoReleaseStatusViewDTO> calculateInventoryReleaseStatus(ServiceContext serviceContext, CampaignInventoryAutoReleaseQueryViewDTO campaignInventoryAutoReleaseQueryViewDTO) {
        List<CampaignInventoryAutoReleaseStatusViewDTO> result = Lists.newArrayList();

        // 如果关闭了自动释量开关则不进行释量状态的判断
        CampaignInventoryAutoReleaseConfigViewDTO autoReleaseConfigViewDTO = campaignInventoryAutoReleaseDiamondConfig.getCampaignInventoryAutoReleaseConfig();
        if (autoReleaseConfigViewDTO != null) {
            if (BrandBoolEnum.BRAND_FALSE.getCode().equals(autoReleaseConfigViewDTO.getGlobalReleaseSwitch())) {
                return result;
            }
        } else {
            return result;
        }
        // 1. 筛选符合条件的计划(一级计划并且所属分组的下单状态是未下单，并且计划是锁量状态)
        List<CampaignViewDTO> campaignViewDTOList = findSpecifiedCampaignViewDTOList(campaignInventoryAutoReleaseQueryViewDTO);
        // 2. 校验锁量有效期信息是否满足释放条件，注意再次查询三环子计划的媒体询量有效期，并再次更新一级计划的媒体询量有效期
        if (CollectionUtils.isNotEmpty(campaignViewDTOList)) {
            campaignViewDTOList.forEach(campaignViewDTO -> {
                result.add(calculateReleaseStatusByCampaign(serviceContext, campaignViewDTO));
            });
        }
        return result;
    }

    /**
     * 计算单计划的释量状态
     * 注意再次查询三环子计划的媒体询量有效期，并再次更新一级计划的媒体询量有效期
     */
    private CampaignInventoryAutoReleaseStatusViewDTO calculateReleaseStatusByCampaign(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {
        CampaignInventoryAutoReleaseStatusViewDTO result = new CampaignInventoryAutoReleaseStatusViewDTO();
        result.setCampaignId(campaignViewDTO.getId());
        Optional.ofNullable(campaignViewDTO.getCampaignInquiryLockViewDTO())
                .map(CampaignInquiryLockViewDTO::getLockExpireTime)
                .ifPresent(lockExpireTime -> {
                    // 如果一级计划是三环或跨域则需要检查二级计划的媒体库存询量有效期并重新计算一级计划的锁量有效期
                    Date updateLockExpireTime = recalculateLockExpireTime(serviceContext, campaignViewDTO);
                    // 仅释放判定当前日期是释放日期的计划，忽略历史未释放的计划，避免影响投中改单的操作
                    if (BrandDateUtil.isSameDay(BrandDateUtil.getCurrentDate(), updateLockExpireTime)) {
                        result.setReleaseStatus(BrandBoolEnum.BRAND_TRUE.getCode());
                    }
                    // 更新一级计划的锁量有效期
                    if (!BrandDateUtil.isSameDay(lockExpireTime, updateLockExpireTime)) {
                        result.setLockExpireTime(updateLockExpireTime);
                    }
                });
        RogerLogger.info("释量状态计算结果为 {}", result);
        return result;
    }

    /**
     * 计划锁量延期申请
     * @param serviceContext
     * @param delayLockApplyViewDTO
     * @return
     */
    public Void delayLock(ServiceContext serviceContext, CampaignDelayLockApplyViewDTO delayLockApplyViewDTO) {
        // 组装参数
        List<BizCampaignAutoReleaseWorkflowParam> bizCampaignAutoReleaseWorkflowParams = bizCampaignInventoryWorkflowExt.buildAutoReleaseDelayLockParamExt(serviceContext,delayLockApplyViewDTO);

        // 过滤非法参数
        List<BizCampaignAutoReleaseWorkflowParam> filterBizCampaignAutoReleaseWorkflowParams = bizCampaignAutoReleaseWorkflowParams.stream().filter(param -> {
            return campaignFilterForAutoReleaseDelayLockAbility.handle(serviceContext, CampaignFilterForAutoReleaseDelayLockAbilityParam.builder()
                    .abilityTarget(param.getCampaignViewDTO().getCampaignInquiryLockViewDTO())
                    .campaignViewDTO(param.getCampaignViewDTO()).saleGroupInfoViewDTO(param.getSaleGroupInfoViewDTO()).build());
        }).collect(Collectors.toList());

        // 填充参数
        for (BizCampaignAutoReleaseWorkflowParam param : filterBizCampaignAutoReleaseWorkflowParams) {
            param.setAutoReleaseStatusViewDTO(buildCampaignInventoryAutoReleaseStatusViewDTO(serviceContext, param.getCampaignViewDTO()));
        }

        //业务校验
        campaignValidateForAutoReleaseDelayLockAbility.handle(serviceContext, CampaignValidateForAutoReleaseDelayLockAbilityParam.builder()
                .campaignDelayLockApplyViewDTO(delayLockApplyViewDTO).bizCampaignAutoReleaseWorkflowParamList(filterBizCampaignAutoReleaseWorkflowParams).build());

        //发起工作流
        dealDelayLockProcessInstance(serviceContext,filterBizCampaignAutoReleaseWorkflowParams, delayLockApplyViewDTO.getCreatorId(), delayLockApplyViewDTO.getReason());

        //更新计划
        List<CampaignViewDTO> updateList = Lists.newArrayList();
        for(BizCampaignAutoReleaseWorkflowParam bizCampaignAutoReleaseWorkflowParam : filterBizCampaignAutoReleaseWorkflowParams){
            CampaignViewDTO campaignViewDTO = bizCampaignAutoReleaseWorkflowParam.getCampaignViewDTO();
            CampaignViewDTO updateCampaignViewDTO = new CampaignViewDTO();
            updateCampaignViewDTO.setId(campaignViewDTO.getId());

            String delayReleaseProcessId = campaignViewDTO.getCampaignInquiryLockViewDTO().getCampaignDelayReleaseViewDTO().getDelayReleaseProcessId();

            CampaignDelayReleaseViewDTO campaignDelayReleaseViewDTO = new CampaignDelayReleaseViewDTO();
            campaignDelayReleaseViewDTO.setDelayReleaseProcessStatus(BrandCampaignProcessStatusEnum.APPROVE_ING.getCode());
            campaignDelayReleaseViewDTO.setDelayReleaseProcessId(delayReleaseProcessId);

            CampaignInquiryLockViewDTO campaignInquiryLockViewDTO = new CampaignInquiryLockViewDTO();
            campaignInquiryLockViewDTO.setCampaignDelayReleaseViewDTO(campaignDelayReleaseViewDTO);

            updateCampaignViewDTO.setCampaignInquiryLockViewDTO(campaignInquiryLockViewDTO);
            updateList.add(updateCampaignViewDTO);
        }
        campaignUpdatePartAbility.handle(serviceContext, CampaignBatchAbilityParam.builder().abilityTargets(updateList).build());
        return null;
    }


    private void dealDelayLockProcessInstance(ServiceContext serviceContext, List<BizCampaignAutoReleaseWorkflowParam> bizCampaignAutoReleaseWorkflowParams, String creatorId, String reason) {
        //按照售卖分组汇总.优化申请流程数
        Map<Long, List<BizCampaignAutoReleaseWorkflowParam>> saleGroupToParamMap = bizCampaignAutoReleaseWorkflowParams.stream()
                .collect(Collectors.groupingBy(bizCampaignAutoReleaseWorkflowParam -> bizCampaignAutoReleaseWorkflowParam.getSaleGroupInfoViewDTO().getSaleGroupId()));
        List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupViewDTOS = resourcePackageRepository.getSaleGroupList(serviceContext
                , ResourcePackageQueryViewDTO.builder().saleGroupIdList(Lists.newArrayList(saleGroupToParamMap.keySet())).build(),
                ResourcePackageQueryOption.builder().needSetting(Boolean.FALSE).needProduct(Boolean.FALSE).needInquiryPriority(Boolean.FALSE).build());
        Map<Long, ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupViewDTOMap = Maps.newHashMap();
        if (org.apache.commons.collections.CollectionUtils.isNotEmpty(resourcePackageSaleGroupViewDTOS)) {
            resourcePackageSaleGroupViewDTOMap = resourcePackageSaleGroupViewDTOS.stream().collect(Collectors.toMap(ResourcePackageSaleGroupViewDTO::getId, Function.identity()));
        }

        Map<Long, ResourcePackageSaleGroupViewDTO> finalResourcePackageSaleGroupViewDTOMap = resourcePackageSaleGroupViewDTOMap;
        saleGroupToParamMap.keySet().forEach(saleGroupId -> {
            CampaignInventoryAutoReleaseQueryViewDTO campaignInventoryAutoReleaseQueryViewDTO = new CampaignInventoryAutoReleaseQueryViewDTO();
            campaignInventoryAutoReleaseQueryViewDTO.setCreatorId(creatorId);
            campaignInventoryAutoReleaseQueryViewDTO.setReason(reason);
            List<CampaignViewDTO> campaignViewDTOS = saleGroupToParamMap.get(saleGroupId).stream().map(BizCampaignAutoReleaseWorkflowParam::getCampaignViewDTO).collect(Collectors.toList());
            Map<String, String> initDataMap = campaignBuildBPMSParamsForAutoReleaseDelayLockAbility.handle(serviceContext, CampaignBuildBPMSParamsForAutoReleaseDelayLockAbilityParam.builder()
                    .campaignViewDTOList(campaignViewDTOS)
                    .campaignGroupViewDTO(saleGroupToParamMap.get(saleGroupId).get(0).getCampaignGroupViewDTO())
                    .campaignInventoryAutoReleaseQueryViewDTO(campaignInventoryAutoReleaseQueryViewDTO)
                    .finalResourcePackageSaleGroupViewDTOMap(finalResourcePackageSaleGroupViewDTOMap).build()
            );
            String title = new StringBuilder().append("分组-").append(saleGroupId)
                    .append(finalResourcePackageSaleGroupViewDTOMap.containsKey(saleGroupId) ? finalResourcePackageSaleGroupViewDTOMap.get(saleGroupId).getName() : "")
                    .append("-锁量延期流程").toString();
            String titleEn = "Brand OneBP Campaign DelayLock Apply";
            RogerLogger.info("提起BPMS审批流 计划 {} 请求参数 {}", saleGroupToParamMap.get(saleGroupId).get(0).getCampaignViewDTO().getId(), initDataMap);
            String processId = bpmsRepository.startProcessInstance(title, titleEn, campaignInventoryAutoReleaseQueryViewDTO.getCreatorId(), initDataMap, BpmsProcessCodeEnum.CAMPAIGN_DELAY_LOCK_APPLY);
            //设置流程ID
            bizCampaignAutoReleaseWorkflowParams.forEach(bizCampaignAutoReleaseWorkflowParam -> {
                if (saleGroupId.equals(bizCampaignAutoReleaseWorkflowParam.getSaleGroupInfoViewDTO().getSaleGroupId())) {
                    CampaignViewDTO campaignViewDTO = bizCampaignAutoReleaseWorkflowParam.getCampaignViewDTO();

                    CampaignInquiryLockViewDTO campaignInquiryLockViewDTO =
                            Optional.ofNullable(campaignViewDTO.getCampaignInquiryLockViewDTO()).orElse(new CampaignInquiryLockViewDTO());
                    campaignViewDTO.setCampaignInquiryLockViewDTO(campaignInquiryLockViewDTO);

                    CampaignDelayReleaseViewDTO campaignDelayReleaseViewDTO =
                            Optional.ofNullable(campaignInquiryLockViewDTO.getCampaignDelayReleaseViewDTO()).orElse(new CampaignDelayReleaseViewDTO());
                    campaignInquiryLockViewDTO.setCampaignDelayReleaseViewDTO(campaignDelayReleaseViewDTO);

                    campaignDelayReleaseViewDTO.setDelayReleaseProcessId(processId);
                }
            });
        });
    }

    /**
     * 计划锁量延期申请回调
     * @param serviceContext
     * @param processViewDTO
     */
    public void delayLockProcess(ServiceContext serviceContext, CampaignDelayLockProcessViewDTO processViewDTO) {
        // 查询计划
        List<CampaignViewDTO> campaignTreeViewDTOList = campaignStructureQueryAbility.handle(serviceContext, CampaignStructureQueryAbilityParam.builder()
                .queryOption(CampaignQueryOption.builder().needChildren(true).build())
                .abilityTarget(CampaignQueryViewDTO.builder().campaignIds(processViewDTO.getCampaignIds()).build())
                .build()
        );
        // 业务校验
        campaignValidateForAutoReleaseDelayLockProcessAbility.handle(serviceContext, CampaignValidateForAutoReleaseDelayLockProcessAbilityParam.builder()
                .processViewDTO(processViewDTO)
                .campaignViewDTOList(campaignTreeViewDTOList).build()
        );
        // 更新结果
        Map<Long, Date> lockExpireTimeMap = Maps.newHashMap();
        for (CampaignViewDTO campaignViewDTO : campaignTreeViewDTOList) {
            Date lockExpireTime = recalculateLockExpireTime(serviceContext, campaignViewDTO);
            lockExpireTimeMap.put(campaignViewDTO.getId(), lockExpireTime);
        }
        List<CampaignViewDTO> updateCampaignViewDTOList = campaignUpdateForAutoReleaseDelayLockProcessAbility.handle(serviceContext, CampaignUpdateForAutoReleaseDelayLockProcessAbilityParam.builder()
                .lockExpireTimeMap(lockExpireTimeMap)
                .campaignDelayLockProcessViewDTO(processViewDTO)
                .campaignViewDTOList(campaignTreeViewDTOList).build()
        );
        campaignUpdatePartAbility.handle(serviceContext, CampaignBatchAbilityParam.builder().abilityTargets(updateCampaignViewDTOList).build());
    }

    public void noticeScrollDailyUpdate(ServiceContext serviceContext) {
        // 查询报表计划
        List<CampaignViewDTO> allCampaignList = fetchScrollDailyUpdateCampaignList(serviceContext);
        // 异步执行
        RunTask runTask = new RunTask() {
            @Override
            public void doRun() {
                executeScrollDailyUpdate(allCampaignList);
            }
        };
        CompletableFuture.runAsync(runTask);
    }

    private List<CampaignViewDTO> fetchScrollDailyUpdateCampaignList(ServiceContext serviceContext) {
        Map<String, Object> queryMap = Maps.newHashMap();
        queryMap.put(ReportConstant.ADR_UNIQUE_KEY, "brand_onebp.common.common.queryAutoScrollCastInfoApi");
        queryMap.put(ReportConstant.DS_EQUAL, BrandDateUtil.date2String(new Date(), DATE_FORMAT_YYYYMMDD_TYPE_2));
        List<CampaignViewDTO> allCampaignList = Lists.newArrayList();
        try {
            List<Map<String, Object>> scrollDailyUpdateList = bizReportQueryAbility.findDataList(serviceContext, queryMap);
            allCampaignList.addAll(campaignScrollDailyUpdateConverter.convertFrom(scrollDailyUpdateList));
            RogerLogger.info("日更待滚量数据:{}", JSONObject.toJSONString(scrollDailyUpdateList));
        } catch (Exception e) {
            RogerLogger.error("日更待滚量计划查询失败, 错误信息: %s", e.getMessage());
        }
        return allCampaignList;
    }

    public void executeScrollDailyUpdate(List<CampaignViewDTO> allCampaignList) {
        if (CollectionUtils.isEmpty(allCampaignList)) {
            return;
        }
        Map<Long, List<CampaignViewDTO>> memberCampaignMap = allCampaignList.stream().collect(
                Collectors.groupingBy(v -> v.getMemberId()));
        RogerLogger.info("scrollDailyUpdate total={},convert after={},memberCampaignMap={}", allCampaignList.size(), allCampaignList.size(),
                memberCampaignMap.size());
        int index = 1;
        for (Map.Entry<Long, List<CampaignViewDTO>> entry : memberCampaignMap.entrySet()) {
            RogerLogger.info("第{}个member({})相关计划开始滚。。。", index, entry.getKey());
            for (CampaignViewDTO campaignViewDTO : entry.getValue()) {
                try {
                    // 重新设置serviceContext
                    ServiceContext newContext = ServiceContextUtil.buildServiceContextForBizCode(entry.getKey(), BizCodeEnum.BRANDONEBP.getBizCode());
                    List<CampaignViewDTO> dbCampaignList = campaignStructureQueryAbility.handle(newContext, CampaignStructureQueryAbilityParam.builder()
                            .abilityTarget(CampaignQueryViewDTO.builder().campaignIds(Lists.newArrayList(campaignViewDTO.getId())).build())
                            .queryOption(CampaignQueryOption.builder().build()).build());
                    AssertUtil.notEmpty(dbCampaignList,String.format("二级计划不存在，id=%s",campaignViewDTO.getId()));
                    ServiceContextUtil.reAssignServiceContext(newContext, dbCampaignList.get(0).getSceneId());

                    List<CampaignViewDTO> flatCampaignList = Lists.newArrayList(campaignViewDTO);
                    List<Long> campaignIdList = flatCampaignList.stream().map(v -> v.getId()).collect(
                            Collectors.toList());
                    CampaignInquiryOperateViewDTO inquiryOperateViewDTO = new CampaignInquiryOperateViewDTO();
                    inquiryOperateViewDTO.setCampaignIdList(campaignIdList);
                    inquiryOperateViewDTO.setOperateType(CampaignScheduleOperateTypeEnum.SCROLL_DAILY_UPDATE.getValue());
                    // 执行日更
                    this.dailyUpdate(newContext, inquiryOperateViewDTO, flatCampaignList);
                    index++;
                } catch (Exception e) {
                    RogerLogger.error("member({})相关计划滚量失败", entry.getKey(), e);
                }
            }
        }
        performRepository.doCampaignDailyEnd();
        RogerLogger.info("计划滚量日更结束");
    }

    public Void resetAvailAmountLockParam(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList,
                                          CampaignInquiryOperateViewDTO inquiryOperateViewDTO) {
        List<CampaignViewDTO> needUpdateList = Lists.newArrayList();
        List<Long> operatorCampaignIds = Lists.newArrayList();
        for(CampaignViewDTO campaignViewDTO : campaignViewDTOList){
            if (!this.validDateAvailAmountLock(campaignViewDTO)) {
                continue;
            }
            if(CollectionUtils.isEmpty(campaignViewDTO.getSubCampaignViewDTOList())){
                continue;
            }
            //判断是否操作的父计划
            boolean parentOperate = inquiryOperateViewDTO.getCampaignIdList().contains(campaignViewDTO.getId());
            if(parentOperate){
                operatorCampaignIds.add(campaignViewDTO.getId());
            }
            //按照询量金额重新初始化需要更新的二级计划
            List<CampaignViewDTO> needUpadteSubList = resetSubCampaignAmountAndMoney(campaignViewDTO,inquiryOperateViewDTO,parentOperate);
            //不为空的部分，说明是需要更新，需要刷新一级计划的预定量和钱
            if(org.apache.commons.collections4.CollectionUtils.isNotEmpty(needUpadteSubList)){
                CampaignViewDTO updateParentCampaign = this.reAssignParentCampaignInquiryAmount(serviceContext,campaignViewDTO,Lists.newArrayList());
                resetParentCampaignAmountAndMoney(campaignViewDTO, updateParentCampaign);
                needUpdateList.add(updateParentCampaign);
                needUpadteSubList.stream().filter(item->inquiryOperateViewDTO.getCampaignIdList().contains(item.getId())).forEach(item->{
                    operatorCampaignIds.add(item.getId());
                });
            }
            needUpdateList.addAll(needUpadteSubList);
        }
        //根据过滤后的数据重新设置操作对象，后续锁量结果需要使用
        inquiryOperateViewDTO.setCampaignIdList(operatorCampaignIds);
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(needUpdateList),"所选的计划中没有符合条件的计划，不能执行确认询量结果的操作。");

        //更新计划和预定量
        campaignRepository.updateCampaignPartWithoutInquiry(serviceContext, needUpdateList);
        for (CampaignViewDTO campaignViewDTO : needUpdateList) {
            List<CampaignInquiryViewDTO> inquiryViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignInquiryLockViewDTO())
                    .map(CampaignInquiryLockViewDTO::getCampaignInquiryViewDTOList).orElse(Lists.newArrayList());
            campaignRepository.updateCampaignInquiryAll(serviceContext, campaignViewDTO.getId(), inquiryViewDTOList);
        }
        return null;
    }

    /**
     * 自动设置计划周期预定量策略
     * @param serviceContext
     * @param campaignTreeViewDTOList
     */
    public void autoAssignCampaignInquiryAmountSync(ServiceContext serviceContext, List<CampaignViewDTO> campaignTreeViewDTOList){
        List<List<CampaignViewDTO>> allAutoAssignCampaignList = Lists.newArrayList();
        allAutoAssignCampaignList.add(campaignTreeViewDTOList);
        TaskStream.consume(campaignAutoAssignScheduleTaskIdentifier, allAutoAssignCampaignList, (assignCampaignTreeViewDTOList, index) -> {
                    RogerLogger.info("自动设置计划周期预定量策略 异步处理 -> start");
                    autoAssignCampaignInquiryAmount(serviceContext,assignCampaignTreeViewDTOList);
                    RogerLogger.info("自动设置计划周期预定量策略 异步处理 -> end");
                }).asyncHandle((r, e) -> {
                    if (Objects.nonNull(e)) {
                        RogerLogger.error("自动设置计划周期预定量策略失败", e);
                    }
                }).commit();
    }

    /**
     * 自动设置计划周期预定量策略
     * @param serviceContext
     * @param campaignTreeViewDTOList
     */
    public void autoAssignCampaignInquiryAmount(ServiceContext serviceContext,List<CampaignViewDTO> campaignTreeViewDTOList){
        List<CampaignViewDTO> parentTreeCampaignViewDTOList = campaignTreeViewDTOList.stream()
                .filter(campaignViewDTO -> !BizCampaignToolsHelper.isTwoCPT(campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope(),campaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterUnit()))
                .collect(Collectors.toList());
        //需要更新预定量的计划
        List<CampaignViewDTO> updateCampaignViewDTOList = Lists.newArrayList();
        for (CampaignViewDTO parentCampaignViewDTO : parentTreeCampaignViewDTOList) {
            //子计划不存在，不做处理
            if(CollectionUtils.isEmpty(parentCampaignViewDTO.getSubCampaignViewDTOList())){
                continue;
            }
            try {
                //查询资源包
                com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO resourcePackageProductViewDTO = getResourcePackageProductViewDTO(serviceContext, parentCampaignViewDTO);
                boolean hasReAssign = false;
                for (CampaignViewDTO subCampaignViewDTO : parentCampaignViewDTO.getSubCampaignViewDTOList()) {
                    boolean subHasReAssign = reAssignSubCampaignInquiryScheduleAmount(serviceContext, resourcePackageProductViewDTO, subCampaignViewDTO);
                    RogerLogger.info("子计划(parentId={},id={})周期预算是否重新分配：subHasReAssign={}",parentCampaignViewDTO.getId(), subCampaignViewDTO.getId(),subHasReAssign);
                    if(subHasReAssign){
                        hasReAssign = true;
                    }
                }
                RogerLogger.info("主计划(id={})周期预算是否重新分配：hasReAssign={}",parentCampaignViewDTO.getId(), hasReAssign);
                if(hasReAssign){
                    for (CampaignViewDTO subCampaignViewDTO : parentCampaignViewDTO.getSubCampaignViewDTOList()) {
                        CampaignInquiryLockViewDTO campaignInquiryLockViewDTO = Optional.ofNullable(subCampaignViewDTO.getCampaignInquiryLockViewDTO()).orElse(new CampaignInquiryLockViewDTO());
                        CampaignInquiryPolicyViewDTO campaignInquiryPolicyViewDTO = Optional.ofNullable(campaignInquiryLockViewDTO.getCampaignInquiryPolicyViewDTO()).orElse(new CampaignInquiryPolicyViewDTO());

                        CampaignScheduleViewDTO subCampaignScheduleViewDTO = new CampaignScheduleViewDTO();
                        subCampaignScheduleViewDTO.setId(subCampaignViewDTO.getId());
                        subCampaignScheduleViewDTO.setInquiryRowIds(campaignInquiryPolicyViewDTO.getInquiryRowIds());
                        subCampaignScheduleViewDTO.setPurchaseRowIds(campaignInquiryPolicyViewDTO.getPurchaseRowIds());
                        subCampaignScheduleViewDTO.setInquiryViewDTOList(campaignInquiryLockViewDTO.getCampaignInquiryViewDTOList());
                        subCampaignScheduleViewDTO.setInquiryAssignType(campaignInquiryPolicyViewDTO.getInquiryAssignType());

                        CampaignInquiryLockViewDTO subCampaignInquiryLockViewDTO = campaignInquiryLockBuildForUpdateCampaignScheduleAbility.handle(serviceContext, CampaignInquiryLockBuildAbilityParam.builder()
                                .abilityTarget(subCampaignScheduleViewDTO).dbCampaignInquiryLockViewDTO(subCampaignViewDTO.getCampaignInquiryLockViewDTO()).build());
                        subCampaignViewDTO.setCampaignInquiryLockViewDTO(subCampaignInquiryLockViewDTO);
                        updateCampaignViewDTOList.add(subCampaignViewDTO);
                    }
                    CampaignViewDTO campaignViewDTO = this.reAssignParentCampaignInquiryAmount(serviceContext, parentCampaignViewDTO, Lists.newArrayList());
                    updateCampaignViewDTOList.add(campaignViewDTO);
                }
            } catch (Exception e) {
                RogerLogger.error(String.format("计划=%s预定量分配异常",parentCampaignViewDTO.getId()),e);
            }
        }
        //更新计划预定量
        campaignInquiryLockBatchUpdateAbility.handle(serviceContext,CampaignInquiryLockUpdateAbilityParam.builder().abilityTargets(updateCampaignViewDTOList).build());
    }


    /**
     * 重新设置计划周期排期预定量
     * @param serviceContext
     * @param resourcePackageProductViewDTO
     * @param subCampaignViewDTO
     * @return
     */
    private boolean reAssignSubCampaignInquiryScheduleAmount(ServiceContext serviceContext, com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO resourcePackageProductViewDTO, CampaignViewDTO subCampaignViewDTO){
        if(!Constant.CAN_INQUIRY_LOCK_STATUS.contains(subCampaignViewDTO.getStatus())){
            RogerLogger.info("计划（{}）已处于锁量状态={}",subCampaignViewDTO.getId(),subCampaignViewDTO.getStatus());
            return false;
        }
        CampaignScheduleViewDTO scheduleViewDTO = new CampaignScheduleViewDTO();
        scheduleViewDTO.setId(subCampaignViewDTO.getId());
        scheduleViewDTO.setStartTime(subCampaignViewDTO.getStartTime());
        scheduleViewDTO.setEndTime(subCampaignViewDTO.getEndTime());
        scheduleViewDTO.setSaleType(subCampaignViewDTO.getCampaignSaleViewDTO().getSaleType());
        scheduleViewDTO.setFirstOnlineTime(subCampaignViewDTO.getCampaignInquiryLockViewDTO().getFirstOnlineTime());
        scheduleViewDTO.setInquiryAssignType(subCampaignViewDTO.getCampaignInquiryLockViewDTO().getCampaignInquiryPolicyViewDTO().getInquiryAssignType());
        scheduleViewDTO.setInquiryViewDTOList(Lists.newArrayList());//强制清空未来周期预定量
        scheduleViewDTO.setIsAutoAssign(false);//预定量为空，不自动分配预定量

        List<CampaignInquirySchedulePolicyViewDTO> inquiryAvailableScheduleDateList = getInquiryAvailableSchedulePolicy(subCampaignViewDTO,resourcePackageProductViewDTO);
        if(org.apache.commons.collections4.CollectionUtils.isNotEmpty(inquiryAvailableScheduleDateList)){
            scheduleViewDTO.setInquiryAssignType(subCampaignViewDTO.getCampaignInquiryLockViewDTO().getCampaignInquiryPolicyViewDTO().getInquiryAssignType() == null ?
                    BrandCampaignInquiryAssignTypeEnum.PERIOD.getCode()
                    : subCampaignViewDTO.getCampaignInquiryLockViewDTO().getCampaignInquiryPolicyViewDTO().getInquiryAssignType());
            scheduleViewDTO.setSchedulePolicyList(inquiryAvailableScheduleDateList);
            scheduleViewDTO.setIsAutoAssign(true);//自动分配
        }
        //自动设置周期预算
        autoAssignCampaignSchedule(serviceContext,subCampaignViewDTO,scheduleViewDTO);

        CampaignInquiryLockViewDTO newCampaignInquiryLockViewDTO = campaignInquiryLockBuildForUpdateCampaignScheduleAbility.handle(serviceContext, CampaignInquiryLockBuildAbilityParam.builder()
                .abilityTarget(scheduleViewDTO).dbCampaignInquiryLockViewDTO(subCampaignViewDTO.getCampaignInquiryLockViewDTO()).build());
        subCampaignViewDTO.setCampaignInquiryLockViewDTO(newCampaignInquiryLockViewDTO);
//        CampaignInquiryLockViewDTO campaignInquiryLockViewDTO = Optional.ofNullable(subCampaignViewDTO.getCampaignInquiryLockViewDTO()).orElse(new CampaignInquiryLockViewDTO());
//        List<CampaignInquiryViewDTO> inquiryViewDTOList = copyInquiryList(subCampaignViewDTO.getId(),
//                scheduleViewDTO.getInquiryViewDTOList(), campaignInquiryLockViewDTO.getCampaignInquiryViewDTOList());
//        campaignInquiryLockViewDTO.setCampaignInquiryViewDTOList(inquiryViewDTOList);
//        subCampaignViewDTO.setCampaignInquiryLockViewDTO(campaignInquiryLockViewDTO);
//        subCampaignViewDTO.getCampaignInquiryLockViewDTO().getCampaignInquiryPolicyViewDTO().setInquiryAssignType(scheduleViewDTO.getInquiryAssignType());
//        subCampaignViewDTO.getCampaignInquiryLockViewDTO().getCampaignInquiryPolicyViewDTO().setSchedulePolicyList(scheduleViewDTO.getSchedulePolicyList());
        return true;
    }


    /**
     * 更新计划排期预定量
     * @param serviceContext
     * @param campaignScheduleViewDTO
     * @return
     */
    public SingleResponse<Long> updateCampaignSchedule(ServiceContext serviceContext, CampaignScheduleViewDTO campaignScheduleViewDTO){
        AssertUtil.assertTrue(campaignScheduleViewDTO != null && campaignScheduleViewDTO.getId() != null, "计划id不允许为空");
        campaignScheduleViewDTO.setIsAutoAssign(true);//周期预定量未设置，采用自动分配策略
        CampaignViewDTO campaignTree = this.getCampaignInfoByOption(serviceContext,campaignScheduleViewDTO.getId(),CampaignQueryOption.builder().needCampaignTree(true).build());
        AssertUtil.notNull(campaignTree, "关联计划不存在");
        // 可以获取到计划粒度的分布式锁，才可以继续
        campaignOperateDistLockGetAbility.handle(serviceContext, CampaignOperateDistLockAbilityParam.builder().abilityTargets(Lists.newArrayList(campaignTree.getId())).build());
        validateSaleGroupCalculating(serviceContext,Lists.newArrayList(campaignTree));
        CampaignViewDTO operateCampaign = BizCampaignToolsHelper.getOperateCampaign(campaignTree, campaignScheduleViewDTO.getId());
        AssertUtil.notNull(operateCampaign, "操作计划不存在");
        //step1、计划排期更新数据校验
        campaignScheduleValidateAbility.handle(serviceContext,CampaignScheduleCalculateAbilityParam.builder()
                .abilityTarget(campaignScheduleViewDTO).campaignViewDTO(operateCampaign).build());
        //step2、重置计划排期区间策略
        campaignScheduleResetAbility.handle(serviceContext, CampaignScheduleCalculateAbilityParam.builder()
                .abilityTarget(campaignScheduleViewDTO).campaignViewDTO(operateCampaign).build());
        //step3、分配计划排期预定量
        this.autoAssignCampaignSchedule(serviceContext,operateCampaign,campaignScheduleViewDTO);
        //step4、构建计划询锁量排期及设置信息
        List<CampaignViewDTO> campaignViewDTOList = buildUpdateInquiryCampaignList(serviceContext, campaignTree, campaignScheduleViewDTO);
        //step5、反向更新主计划预定量
        Boolean reAssignParentScheduleJudge = campaignReAssignParentScheduleJudgeForUpdateCampaignSchemaAbility.handle(serviceContext,
                CampaignScheduleCalculateAbilityParam.builder().abilityTarget(campaignScheduleViewDTO).campaignViewDTO(operateCampaign).build());
        if(Boolean.TRUE.equals(reAssignParentScheduleJudge)){
            CampaignViewDTO campaignViewDTO = this.reAssignParentCampaignInquiryAmount(serviceContext, campaignTree,Lists.newArrayList(campaignScheduleViewDTO));
            campaignViewDTOList.add(campaignViewDTO);
        }
        //step6、批量更新计划询锁量排期及设置信息
        for (CampaignViewDTO campaignViewDTO: campaignViewDTOList) {
            //变更预订量后计划状态改为草稿
            campaignViewDTO.setStatus(BrandCampaignStatusEnum.NEW.getCode());
        }
        campaignInquiryLockBatchUpdateAbility.handle(serviceContext,CampaignInquiryLockUpdateAbilityParam.builder().abilityTargets(campaignViewDTOList).needUpdateRowId(true).build());
        return SingleResponse.of(campaignScheduleViewDTO.getId());
    }

    /**
     * 批量更新计划排期预定量策略
     * @param serviceContext
     * @param schedulePolicyViewDTO
     * @return
     */
    public MultiResponse<Long> batchUpdateCampaignSchedulePolicy(ServiceContext serviceContext, CampaignSchedulePolicyViewDTO schedulePolicyViewDTO) {
        AssertUtil.assertTrue(schedulePolicyViewDTO != null && org.apache.commons.collections4.CollectionUtils.isNotEmpty(schedulePolicyViewDTO.getCampaignIdList()),"计划id不允许为空");
        AssertUtil.notNull(schedulePolicyViewDTO.getInquiryAssignType(),"计划区间分配策略不允许为空");
        //全域通和多价格波段使用二级计划id,其他场景使用一级计划id
        List<CampaignViewDTO> campaignTreeList = campaignStructureQueryAbility.handle(serviceContext,CampaignStructureQueryAbilityParam.builder()
                .abilityTarget(CampaignQueryViewDTO.builder().campaignIds(schedulePolicyViewDTO.getCampaignIdList()).build())
                .queryOption(CampaignQueryOption.builder().needCampaignTree(true).build()).build());
        AssertUtil.notEmpty(campaignTreeList,"计划不存在");
        validateSaleGroupCalculating(serviceContext,campaignTreeList);
        // 可以获取到计划粒度的分布式锁，才可以继续
        campaignOperateDistLockGetAbility.handle(serviceContext, CampaignOperateDistLockAbilityParam.builder().abilityTargets(campaignTreeList.stream().map(CampaignViewDTO::getId).collect(Collectors.toList())).build());
        List<CampaignViewDTO> allCampaignViewDTOList = Lists.newArrayList();
        for (CampaignViewDTO campaignTree : campaignTreeList) {
            List<CampaignScheduleViewDTO> subCampaignInventoryList = Lists.newArrayList();
            for (Long campaignId : schedulePolicyViewDTO.getCampaignIdList()) {
                CampaignViewDTO subCampaign = BizCampaignToolsHelper.getOperateCampaign(campaignTree, campaignId);
                if(subCampaign == null){
                    continue;
                }
                CampaignScheduleViewDTO campaignScheduleViewDTO = new CampaignScheduleViewDTO();
                campaignScheduleViewDTO.setId(campaignId);
                campaignScheduleViewDTO.setInquiryAssignType(schedulePolicyViewDTO.getInquiryAssignType());
                campaignScheduleViewDTO.setSchedulePolicyList(schedulePolicyViewDTO.getSchedulePolicyList());
                campaignScheduleViewDTO.setIsAutoAssign(true);//周期预定量未设置，采用自动分配策略
                //step1、计划排期更新数据校验
                campaignScheduleValidateAbility.handle(serviceContext,CampaignScheduleCalculateAbilityParam.builder()
                        .abilityTarget(campaignScheduleViewDTO).campaignViewDTO(subCampaign).build());
                //step2、重置计划排期区间策略
                campaignScheduleResetAbility.handle(serviceContext, CampaignScheduleCalculateAbilityParam.builder()
                        .abilityTarget(campaignScheduleViewDTO).campaignViewDTO(subCampaign).build());
                //step3、分配计划排期预定量
                this.autoAssignCampaignSchedule(serviceContext,subCampaign,campaignScheduleViewDTO);
                //step4、构建计划询锁量排期及设置信息
                List<CampaignViewDTO> campaignViewDTOList = buildUpdateInquiryCampaignList(serviceContext, campaignTree, campaignScheduleViewDTO);
                allCampaignViewDTOList.addAll(campaignViewDTOList);
                //step5、反向更新主计划预定量
                Boolean reAssignJudge = campaignReAssignParentScheduleJudgeForUpdateCampaignSchemaAbility.handle(serviceContext,
                        CampaignScheduleCalculateAbilityParam.builder().abilityTarget(campaignScheduleViewDTO).campaignViewDTO(subCampaign).build());
                if(Boolean.TRUE.equals(reAssignJudge)){
                    subCampaignInventoryList.add(campaignScheduleViewDTO);
                }
            }
            //反向更新主计划预定量
            if(CollectionUtils.isNotEmpty(subCampaignInventoryList)){
                CampaignViewDTO campaignViewDTO = this.reAssignParentCampaignInquiryAmount(serviceContext, campaignTree, subCampaignInventoryList);
                allCampaignViewDTOList.add(campaignViewDTO);
            }
        }
        //变更预订量后计划状态改为草稿
        for (CampaignViewDTO campaignViewDTO: allCampaignViewDTOList) {
            campaignViewDTO.setStatus(BrandCampaignStatusEnum.NEW.getCode());
        }
        campaignInquiryLockBatchUpdateAbility.handle(serviceContext,CampaignInquiryLockUpdateAbilityParam.builder().abilityTargets(allCampaignViewDTOList).build());
        return MultiResponse.of(schedulePolicyViewDTO.getCampaignIdList());
    }

    /**
     * 计算链路阻塞锁校验
     * @param campaignViewDTOList
     */
    private void validateSaleGroupCalculating(ServiceContext serviceContext,List<CampaignViewDTO> campaignViewDTOList){
        if(org.apache.commons.collections4.CollectionUtils.isNotEmpty(campaignViewDTOList)){
            List<Long> saleGroupList = campaignViewDTOList.stream().map(item->item.getCampaignSaleViewDTO().getSaleGroupId()).distinct().collect(Collectors.toList());
            saleGroupOperateDistLockGetAbility.handle(serviceContext,
                    SaleGroupOperateDistLockAbilityParam.builder().abilityTargets(saleGroupList).build());
        }
    }

    /**
     * 优先使用客户历史设置的预定量，获取不到使用资源包设置的有效周期比例
     * @param campaignViewDTO
     * @param resourcePackageProductViewDTO
     * @return
     */
    public List<CampaignInquirySchedulePolicyViewDTO> getInquiryAvailableSchedulePolicy(CampaignViewDTO campaignViewDTO, com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO resourcePackageProductViewDTO){
        Date availableStartTime = BizCampaignToolsHelper.inquiryDeadline(campaignViewDTO);
        Date availableEndTime = BrandDateUtil.getDateMidnight(campaignViewDTO.getEndTime());

        List<CampaignInquirySchedulePolicyViewDTO> campaignHistoryInquirySchedule = Optional.ofNullable(campaignViewDTO.getCampaignInquiryLockViewDTO())
                .map(CampaignInquiryLockViewDTO::getCampaignInquiryPolicyViewDTO).map(CampaignInquiryPolicyViewDTO::getSchedulePolicyList).orElse(Lists.newArrayList());
        List<CampaignInquirySchedulePolicyViewDTO> inquiryAvailableScheduleDateList = getInquiryAvailableSchedulePolicy(campaignHistoryInquirySchedule,availableStartTime,availableEndTime);
        if(org.apache.commons.collections4.CollectionUtils.isEmpty(inquiryAvailableScheduleDateList)){
            RogerLogger.info("计划（{}）对应计划时段（startTime={},endTime={}）客户历史未设置预定量或设置预定量已过期",
                    campaignViewDTO.getId(),BrandDateUtil.date2String(availableStartTime),BrandDateUtil.date2String(availableEndTime));
            List<CampaignInquirySchedulePolicyViewDTO> productSchedulePolicyList = resourcePackageRepository.getResourcePackageProductSchedulePolicyList(resourcePackageProductViewDTO, availableStartTime, availableEndTime);
            inquiryAvailableScheduleDateList = getInquiryAvailableSchedulePolicy(productSchedulePolicyList,availableStartTime,availableEndTime);
        }
        RogerLogger.info("计划（{}）对应计划时段（startTime={},endTime={}），是否满足计划继承条件={},计划排期预定比例={}",
                campaignViewDTO.getId(),BrandDateUtil.date2String(availableStartTime),BrandDateUtil.date2String(availableEndTime),
                org.apache.commons.collections4.CollectionUtils.isNotEmpty(inquiryAvailableScheduleDateList),JSON.toJSONString(inquiryAvailableScheduleDateList));
        return inquiryAvailableScheduleDateList;
    }

    /**
     * 获取可用的预定量周期
     *
     * @param inquirySchedulePolicyList
     * @param startTime
     * @param endTime
     * @return
     */
    private List<CampaignInquirySchedulePolicyViewDTO> getInquiryAvailableSchedulePolicy(List<CampaignInquirySchedulePolicyViewDTO> inquirySchedulePolicyList, Date startTime, Date endTime) {
        if(CollectionUtils.isEmpty(inquirySchedulePolicyList)){
            return Lists.newArrayList();
        }
        //计划有效的周期范围
        List<Date> availableDayList = BrandDateUtil.getDayList(startTime, endTime);
        //计划预定量周期范围
        for (CampaignInquirySchedulePolicyViewDTO policyViewDTO : inquirySchedulePolicyList) {
            List<Date> policyDateList = BrandDateUtil.getDayList(policyViewDTO.getStartTime(), policyViewDTO.getEndTime());
            //取交集，计划有效周期，至少有一天在预定量周期比例范围内
            policyDateList.retainAll(availableDayList);
            if(policyDateList.isEmpty()){
                RogerLogger.info(String.format("计划预定量周期比例设置=%s，不能涵盖计划的有效周期范围(startTime=%s,endTime=%s)",
                        JSON.toJSONString(inquirySchedulePolicyList), BrandDateUtil.date2String(startTime), BrandDateUtil.date2String(endTime)));
                return Lists.newArrayList();
            }
        }
        List<CampaignInquirySchedulePolicyViewDTO> availableSchedulePolicyList = Lists.newArrayList();
        for (CampaignInquirySchedulePolicyViewDTO policyViewDTO : inquirySchedulePolicyList) {
            //已结束
            if (policyViewDTO.getEndTime().compareTo(startTime) < 0) {
                continue;
            }
            if (policyViewDTO.getStartTime().compareTo(startTime) <= 0) {
                CampaignInquirySchedulePolicyViewDTO availablePolicyViewDTO = new CampaignInquirySchedulePolicyViewDTO();
                availablePolicyViewDTO.setAmountRatio(policyViewDTO.getAmountRatio());
                availablePolicyViewDTO.setStartTime(startTime);
                availablePolicyViewDTO.setEndTime(BrandDateUtil.minDate(policyViewDTO.getEndTime(), endTime));
                availableSchedulePolicyList.add(availablePolicyViewDTO);
            } else {
                CampaignInquirySchedulePolicyViewDTO availablePolicyViewDTO = new CampaignInquirySchedulePolicyViewDTO();
                availablePolicyViewDTO.setAmountRatio(policyViewDTO.getAmountRatio());
                availablePolicyViewDTO.setStartTime(policyViewDTO.getStartTime());
                availablePolicyViewDTO.setEndTime(BrandDateUtil.minDate(policyViewDTO.getEndTime(), endTime));
                availableSchedulePolicyList.add(availablePolicyViewDTO);
            }
        }
        RogerLogger.info(String.format("有效周期范围(startTime=%s,endTime=%s)匹配到的历史预定量周期比例=%s，",
                BrandDateUtil.date2String(startTime), BrandDateUtil.date2String(endTime), JSON.toJSONString(availableSchedulePolicyList)));
        return availableSchedulePolicyList;
    }

    /**
     * 重新分配一级计划预定量
     * @param serviceContext
     * @param parentCampaign
     * @param changeSubCampaignScheduleList
     * @return
     */
    public CampaignViewDTO reAssignParentCampaignInquiryAmount(ServiceContext serviceContext, CampaignViewDTO parentCampaign, List<CampaignScheduleViewDTO> changeSubCampaignScheduleList) {
        AssertUtil.notEmpty(parentCampaign.getSubCampaignViewDTOList(),"关联计划不存在");
        CampaignScheduleViewDTO parentCampaignScheduleViewDTO = campaignRebuildParentCampaignScheduleAbility.handle(serviceContext, CampaignRebuildParentCampaignScheduleParam.builder()
                .abilityTarget(parentCampaign).changeSubCampaignScheduleViewDTOList(changeSubCampaignScheduleList).build());
        AssertUtil.notNull(parentCampaignScheduleViewDTO,"一级计划排期不能为空");
        CampaignInquiryLockViewDTO newCampaignInquiryLockViewDTO = campaignInquiryLockBuildForUpdateCampaignScheduleAbility.handle(serviceContext, CampaignInquiryLockBuildAbilityParam.builder()
                .abilityTarget(parentCampaignScheduleViewDTO).dbCampaignInquiryLockViewDTO(parentCampaign.getCampaignInquiryLockViewDTO()).build());
        parentCampaign.setCampaignInquiryLockViewDTO(newCampaignInquiryLockViewDTO);
        return parentCampaign;
    }

    private List<CampaignViewDTO> resetSubCampaignAmountAndMoney(CampaignViewDTO campaignViewDTO,CampaignInquiryOperateViewDTO inquiryOperateViewDTO,boolean parentOperate){
        List<CampaignViewDTO> needUpadteSubList = Lists.newArrayList();

        for(CampaignViewDTO subCampaignViewDTO : campaignViewDTO.getSubCampaignViewDTOList()){
            //如果操作对象不是一级计划，那子计划有可能是操作的二级计划对应的一级计划下的其他子计划需要过滤掉
            if(!parentOperate && !inquiryOperateViewDTO.getCampaignIdList().contains(subCampaignViewDTO.getId())){
                continue;
            }
            if(!this.validDateAvailAmountLock(subCampaignViewDTO)){
                continue;
            }
            if(!Constant.CAN_AVAILAMOUNT_LOCK_LOCK_STATUS.contains(subCampaignViewDTO.getStatus())){
                continue;
            }
            List<CampaignInquiryViewDTO>  campaignInquiryViewDTOS = Optional.ofNullable(subCampaignViewDTO.getCampaignInquiryLockViewDTO())
                    .map(CampaignInquiryLockViewDTO::getCampaignInquiryViewDTOList).orElse(Lists.newArrayList());
            Date deadLineDate = BizCampaignToolsHelper.inquiryDeadline(subCampaignViewDTO.getCampaignSaleViewDTO().getSaleType(), campaignInquiryViewDTOS, subCampaignViewDTO.getCampaignInquiryLockViewDTO().getFirstOnlineTime());
            long discountTotalMoney = 0L;
            long publishTotalMoney = 0L;
            long totalPv =0L;

            for(CampaignInquiryViewDTO campaignInquiryViewDTO : campaignInquiryViewDTOS){
                Long discountDayPrice = 0L;
                Long publishDayPrice = 0L;
                for (DayPriceViewDTO dayPriceViewDTO : campaignViewDTO.getCampaignPriceViewDTO().getDiscountPriceInfoList()) {
                    if(BrandDateUtil.isBeforeAndEqual(dayPriceViewDTO.getStartDate(),campaignInquiryViewDTO.getDate())
                            && BrandDateUtil.isAfterAndEqual(dayPriceViewDTO.getEndDate(),campaignInquiryViewDTO.getDate()) ){
                        discountDayPrice = dayPriceViewDTO.getPrice();
                    }
                }
                for (DayPriceViewDTO dayPriceViewDTO : campaignViewDTO.getCampaignPriceViewDTO().getPublishPriceInfoList()) {
                    if(BrandDateUtil.isBeforeAndEqual(dayPriceViewDTO.getStartDate(),campaignInquiryViewDTO.getDate())
                            && BrandDateUtil.isAfterAndEqual(dayPriceViewDTO.getEndDate(),campaignInquiryViewDTO.getDate()) ){
                        publishDayPrice = dayPriceViewDTO.getPrice();
                    }
                }
                if(BrandDateUtil.isAfterAndEqual(campaignInquiryViewDTO.getDate(),deadLineDate)){
                    //如果总库存没有或者小于0
                    if(campaignInquiryViewDTO.getStockTotalAmount() == null || !NumberUtil.greaterThanZero(campaignInquiryViewDTO.getStockTotalAmount() )){
                        campaignInquiryViewDTO.setBookAmount(null);
                    }else{
                        campaignInquiryViewDTO.setBookAmount(Math.min(campaignInquiryViewDTO.getBookAmount() ,campaignInquiryViewDTO.getStockTotalAmount()));
                    }
                }
                if(NumberUtil.greaterThanZero(campaignInquiryViewDTO.getBookAmount()) ){
                    Long discountDayBudget = BizCampaignToolsHelper.reCalCpmTotalMoney(subCampaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope(),subCampaignViewDTO.getCampaignResourceViewDTO().getSspProductLineId(),campaignInquiryViewDTO.getBookAmount(),discountDayPrice);
                    Long publishDayBudget = BizCampaignToolsHelper.reCalCpmTotalMoney(subCampaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope(),subCampaignViewDTO.getCampaignResourceViewDTO().getSspProductLineId(),campaignInquiryViewDTO.getBookAmount(),publishDayPrice);
                    discountTotalMoney += discountDayBudget;
                    publishTotalMoney += publishDayBudget;
                    totalPv+=campaignInquiryViewDTO.getBookAmount();
                }
                RogerLogger.info(" {} day {} bookAmount {} price {} budget {}",campaignViewDTO.getId(),campaignInquiryViewDTO.getDate(),campaignInquiryViewDTO.getBookAmount(),discountDayPrice,discountTotalMoney);
            }
            if(totalPv <= 0){
                continue;
            }
            List<CampaignInquiryViewDTO> afterFilterList = campaignInquiryViewDTOS.stream().filter(item -> NumberUtil.greaterThanZero(item.getBookAmount())).collect(
                    Collectors.toList());

            CampaignInquiryLockViewDTO campaignInquiryLockViewDTO = Optional.ofNullable(subCampaignViewDTO.getCampaignInquiryLockViewDTO()).orElse(new CampaignInquiryLockViewDTO());
            campaignInquiryLockViewDTO.setCampaignInquiryViewDTOList(afterFilterList);
            subCampaignViewDTO.setCampaignInquiryLockViewDTO(campaignInquiryLockViewDTO);

            subCampaignViewDTO.getCampaignBudgetViewDTO().setDiscountTotalMoney(discountTotalMoney);
            subCampaignViewDTO.getCampaignBudgetViewDTO().setPublishTotalMoney(publishTotalMoney);
            subCampaignViewDTO.getCampaignGuaranteeViewDTO().setAmount(totalPv);

            CampaignInquiryPolicyViewDTO campaignInquiryPolicyViewDTO = Optional.ofNullable(campaignInquiryLockViewDTO.getCampaignInquiryPolicyViewDTO()).orElse(new CampaignInquiryPolicyViewDTO());
            campaignInquiryPolicyViewDTO.setInquiryAssignType(BrandCampaignInquiryAssignTypeEnum.BY_DAY.getCode());
            campaignInquiryPolicyViewDTO.setSchedulePolicyList(Lists.newArrayList());

            campaignInquiryLockViewDTO.setCampaignInquiryPolicyViewDTO(campaignInquiryPolicyViewDTO);
            subCampaignViewDTO.setCampaignInquiryLockViewDTO(campaignInquiryLockViewDTO);

            needUpadteSubList.add(subCampaignViewDTO);
        }
        return needUpadteSubList;
    }

    private void resetParentCampaignAmountAndMoney(CampaignViewDTO campaignViewDTO, CampaignViewDTO updateParentCampaign) {
        long parentPv = 0L;
        long parentDiscountTotalMoney = 0L;
        long parentPublishTotalMoney = 0L;
        boolean isPeriodPrice = false;
        for(CampaignViewDTO subCampaignViewDTO : campaignViewDTO.getSubCampaignViewDTOList()){
            parentPv += subCampaignViewDTO.getCampaignGuaranteeViewDTO().getAmount();
            parentDiscountTotalMoney += subCampaignViewDTO.getCampaignBudgetViewDTO().getDiscountTotalMoney();
            parentPublishTotalMoney += subCampaignViewDTO.getCampaignBudgetViewDTO().getPublishTotalMoney();
            isPeriodPrice = BizCampaignSplitSpi.CAMPAIGN_SPLIT_PRICE_PERIOD.equals(subCampaignViewDTO.getCampaignExtViewDTO().getSubSplitCode());
        }
        updateParentCampaign.getCampaignGuaranteeViewDTO().setAmount(parentPv);

        CampaignPriceViewDTO campaignPriceViewDTO = new CampaignPriceViewDTO();
        if(isPeriodPrice){
            long  parentSettlePrice =  BigDecimal.valueOf(parentDiscountTotalMoney).divide(( BigDecimal.valueOf(parentPv).divide( BigDecimal.valueOf(1000),3,BigDecimal.ROUND_DOWN)),0, BigDecimal.ROUND_DOWN).longValue();
            campaignPriceViewDTO.setSettlePrice(parentSettlePrice);
        }
        updateParentCampaign.setCampaignPriceViewDTO(campaignPriceViewDTO);

        CampaignBudgetViewDTO campaignBudgetViewDTO = new CampaignBudgetViewDTO();
        campaignBudgetViewDTO.setDiscountTotalMoney(parentDiscountTotalMoney);
        campaignBudgetViewDTO.setPublishTotalMoney(parentPublishTotalMoney);
        updateParentCampaign.setCampaignBudgetViewDTO(campaignBudgetViewDTO);
    }

    /**
     * 获取排期策略关联资源包产品id
     * 全域通产品：获取一级产品ID，其他获取计划对应的产品id
     * @param serviceContext
     * @param campaignViewDTO
     * @return
     */
    public Long getSchedulePolicyResourcePackageProductId(ServiceContext serviceContext,CampaignViewDTO campaignViewDTO){
        //全域通二级计划，获取一级资源包产品id
        if(BrandCampaignLevelEnum.LEVEL_TWO_CAMPAIGN.getCode().equals(campaignViewDTO.getCampaignLevel())){
            if(BizCampaignSplitSpi.CAMPAIGN_SPLIT_CROSS.equals(campaignViewDTO.getCampaignExtViewDTO().getSubSplitCode())
            || BizCampaignSplitSpi.CAMPAIGN_CROSS_SPLIT_PRICE_PERIOD.equals(campaignViewDTO.getCampaignExtViewDTO().getSubSplitCode())){
                Long parentCampaignId = campaignViewDTO.getParentCampaignId();
                CampaignViewDTO parentCampaignViewDTO = campaignRepository.getCampaignById(serviceContext, parentCampaignId);
                AssertUtil.notNull(parentCampaignViewDTO,String.format("计划不存在，id=%s",parentCampaignId));
                return parentCampaignViewDTO.getCampaignSaleViewDTO().getResourcePackageProductId();
            }
        }
        return campaignViewDTO.getCampaignSaleViewDTO().getResourcePackageProductId();
    }

    /**
     * 获取资源包产品信息
     * @param context
     * @param campaignViewDTO
     * @return
     */
    private com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO getResourcePackageProductViewDTO(ServiceContext context, CampaignViewDTO campaignViewDTO){
        ResourcePackageQueryOption packageQueryOption = ResourcePackageQueryOption.builder().needProduct(true).needSetting(true).build();
        ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO = resourcePackageRepository.getSaleGroupById(context, campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId(), packageQueryOption);
        Long resourcePackageProductId = getSchedulePolicyResourcePackageProductId(context,campaignViewDTO);
        com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO resourcePackageProductViewDTO = resourcePackageRepository.getResourcePackageProduct(context,packageSaleGroupViewDTO,resourcePackageProductId);
        AssertUtil.notNull(resourcePackageProductViewDTO, "售卖分组资源位不存在");
        return resourcePackageProductViewDTO;
    }

    /**
     * 构建需要更新预定量的计划
     * @param serviceContext
     * @param parentCampaign
     * @param scheduleViewDTO
     * @return
     */
    private List<CampaignViewDTO> buildUpdateInquiryCampaignList(ServiceContext serviceContext,CampaignViewDTO parentCampaign, CampaignScheduleViewDTO scheduleViewDTO) {
        List<CampaignViewDTO> updateInquiryCampaignList = Lists.newArrayList();

        CampaignViewDTO operateCampaignViewDTO = BizCampaignToolsHelper.getOperateCampaign(parentCampaign,scheduleViewDTO.getId());
        AssertUtil.notNull(operateCampaignViewDTO, "操作计划不存在");

        CampaignInquiryLockViewDTO campaignInquiryLockViewDTO = campaignInquiryLockBuildForUpdateCampaignScheduleAbility.handle(serviceContext, CampaignInquiryLockBuildAbilityParam.builder()
                .abilityTarget(scheduleViewDTO).dbCampaignInquiryLockViewDTO(operateCampaignViewDTO.getCampaignInquiryLockViewDTO()).build());
        operateCampaignViewDTO.setCampaignInquiryLockViewDTO(campaignInquiryLockViewDTO);
        updateInquiryCampaignList.add(operateCampaignViewDTO);
        //复制场景子计划直接拷的预定量数据
        if(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode().equals(operateCampaignViewDTO.getCampaignLevel())
                && org.apache.commons.collections4.CollectionUtils.isNotEmpty(operateCampaignViewDTO.getSubCampaignViewDTOList())){
            if(BizCampaignToolsHelper.isCopyParentCampaign(operateCampaignViewDTO.getSubCampaignViewDTOList().get(0))){
                CampaignViewDTO subCampaignViewDTO = operateCampaignViewDTO.getSubCampaignViewDTOList().get(0);

                CampaignScheduleViewDTO subCampaignScheduleViewDTO = new CampaignScheduleViewDTO();
                subCampaignScheduleViewDTO.setId(subCampaignViewDTO.getId());
                subCampaignScheduleViewDTO.setInquiryRowIds(scheduleViewDTO.getInquiryRowIds());
                subCampaignScheduleViewDTO.setPurchaseRowIds(scheduleViewDTO.getPurchaseRowIds());
                subCampaignScheduleViewDTO.setInquiryAssignType(scheduleViewDTO.getInquiryAssignType());
                subCampaignScheduleViewDTO.setInquiryViewDTOList(campaignInquiryLockViewDTO.getCampaignInquiryViewDTOList());

                CampaignInquiryLockViewDTO subCampaignInquiryLockViewDTO = campaignInquiryLockBuildForUpdateCampaignScheduleAbility.handle(serviceContext, CampaignInquiryLockBuildAbilityParam.builder()
                        .abilityTarget(subCampaignScheduleViewDTO).dbCampaignInquiryLockViewDTO(subCampaignViewDTO.getCampaignInquiryLockViewDTO()).build());
                subCampaignViewDTO.setCampaignInquiryLockViewDTO(subCampaignInquiryLockViewDTO);
                updateInquiryCampaignList.add(subCampaignViewDTO);
            }
        }
        return updateInquiryCampaignList;
    }

    /**
     * 可用量金额校验是否合法
     * @param campaignViewDTO
     * @return
     */
    private  boolean validDateAvailAmountLock(CampaignViewDTO campaignViewDTO) {
        if(!BrandCampaignProductConfigTypeEnum.CUSTOM.getCode().equals(campaignViewDTO.getCampaignSaleViewDTO().getProductConfigType())){
            return false;
        }
        if(!BizCampaignToolsHelper.isTXorShowmaxCampaign(campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope(),
                campaignViewDTO.getCampaignResourceViewDTO().getSspProductLineId())){
            return false;
        }
        if(BizCampaignToolsHelper.isCPT(campaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterUnit())){
            return false;
        }
        return true;
    }

    /**
     * 获取计划信息
     * @param serviceContext
     * @param id
     * @param option
     * @return
     */
    private CampaignViewDTO getCampaignInfoByOption(ServiceContext serviceContext,Long id,CampaignQueryOption option){
        CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder().campaignIds(Collections.singletonList(id)).build();
        List<CampaignViewDTO> dbCampaignViewDTOList = campaignStructureQueryAbility.handle(serviceContext,
                CampaignStructureQueryAbilityParam.builder().abilityTarget(campaignQueryViewDTO).queryOption(option).build());
        return CollectionUtils.isNotEmpty(dbCampaignViewDTOList) ? dbCampaignViewDTOList.get(0) : null;
    }
}
