package com.taobao.ad.brand.bp.app.workflow.salegroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupBoostGiveApplyInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.salegroup.CampaignGroupSaleGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.fastjson.JSON;
import com.alibaba.hermes.framework.event.SimpleEventEngine;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.app.businessability.MultiTargetDeliverBusinessAbility;
import com.taobao.ad.brand.bp.client.context.SaleGroupCrowdUpdateContext;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupCrowdViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupGoalSettingViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.calculate.CampaignCalViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.calculate.CampaignGroupSaleGroupCalViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.calculate.ProductCampaignCalViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.calculate.SaleGroupProductBudgetViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.salegroup.CampaignGroupSaleGroupBoostGiveApplyViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourceDistributionRuleViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.event.salegroup.SaleGroupCrowdUpdateEvent;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbilityRouteContext;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignCalculateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.workflow.param.BizCampaignGroupCalculateWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.*;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.calculate.ISaleGroupAssignForCalculateAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.calculate.ISaleGroupProductBudgetAssignForCalculateAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.calculate.ISaleGroupProductBudgetAssignValidateForCalculateAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.calculate.ISaleGroupPvAssignForCalculateAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.calculate.ISaleGroupResourceCategoryBudgetAssignForCalculateAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.ResourcePackageSaleGroupCalculateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupApplyInfoAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupBudgetAssignAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupCrowdInitForUpdateSaleGroupAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupStatusValidateForUpdateSaleGroupAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.businessability.ISaleGroupCrowdUpdateBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.businessability.ISaleGroupEstimateResultClearBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.businessability.ISaleGroupGoalSettingUpdateBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.workflow.param.BizSaleGroupUpdateWorkflowParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.alibaba.abf.isolation.utils.AbilityInvoker.invokeAll;

/**
 * 订单分组workflow
 *
 * @author yunhu.myh@taobao.com
 * @date 2023年07月25日
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizSaleGroupCommandWorkflow {

    private final ResourcePackageRepository resourcePackageRepository;
    private final CampaignGroupRepository campaignGroupRepository;
    private final SimpleEventEngine simpleEventEngine;
    private final ISaleGroupStatusValidateForUpdateSaleGroupAbility saleGroupStatusValidateForUpdateSaleGroupAbility;
    private final ISaleGroupResourceCategoryBudgetAssignForCalculateAbility saleGroupResourceCategoryBudgetAssignForCalculateAbility;
    private final ISaleGroupProductBudgetAssignForCalculateAbility saleGroupProductBudgetAssignForCalculateAbility;
    private final ISaleGroupProductBudgetAssignValidateForCalculateAbility saleGroupProductBudgetAssignValidateForCalculateAbility;
    private final ISaleGroupAssignForCalculateAbility saleGroupAssignForCalculateAbility;
    private final ISaleGroupPvAssignForCalculateAbility saleGroupPvAssignForCalculateAbility;
    private final ISaleGroupApplyInfoValidateForApplySaleGroupAbility saleGroupApplyInfoValidateForApplySaleGroupAbility;
    private final ISaleGroupApplyInfoValidateForUpdateSaleGroupAbility saleGroupApplyInfoValidateForUpdateSaleGroupAbility;
    private final ISaleGroupApplyInfoValidateForDeleteSaleGroupAbility saleGroupApplyInfoValidateForDeleteSaleGroupAbility;
    private final ISaleGroupApplyInfoInitForApplySaleGroupAbility saleGroupApplyInfoInitForApplySaleGroupAbility;
    private final ISaleGroupApplyInfoInitForUpdateSaleGroupAbility saleGroupApplyInfoInitForUpdateSaleGroupAbility;
    private final ISaleGroupSubmitForApplySaleGroupAbility saleGroupSubmitForApplySaleGroupAbility;
    private final ISaleGroupApplyInfoSaveForApplySaleGroupAbility saleGroupApplyInfoSaveForApplySaleGroupAbility;
    private final ISaleGroupApplyInfoSaveForDeleteSaleGroupAbility saleGroupApplyInfoSaveForDeleteSaleGroupAbility;
    private final ISaleGroupCrowdInitForUpdateSaleGroupAbility saleGroupCrowdInitForUpdateSaleGroupAbility;

    /**
     * 售卖分组交付优化目标设置
     * @param serviceContext
     * @param saleGroupGoalSettingViewDTO
     * @return
     */
    public Integer updateSaleGroupGoalSetting(ServiceContext serviceContext, CampaignGroupSaleGroupGoalSettingViewDTO saleGroupGoalSettingViewDTO) {
        AssertUtil.notNull(saleGroupGoalSettingViewDTO, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "参数不能为空");
        //商业能力挂载
        BusinessAbilityRouteContext businessAbilityRouteContext = BusinessAbilityRouteContext.builder().specifiedBusinessAbilityCodes(Lists.newArrayList(MultiTargetDeliverBusinessAbility.ABILITY_CODE)).build();
        invokeAll(ISaleGroupGoalSettingUpdateBusinessAbilityPoint.class, businessAbilityRouteContext,
                callback -> callback.invokeForSaleGroupGoalSetting(serviceContext,saleGroupGoalSettingViewDTO));
        return 1;
    }

    /**
     * 更新人群+人群覆盖人数
     * N+场景下人群最多15个
     */
    public Integer updateSaleGroupCrowdIds(ServiceContext serviceContext, CampaignGroupSaleGroupCrowdViewDTO saleGroupCrowdViewDTO) {
        AssertUtil.notNull(saleGroupCrowdViewDTO, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "参数不能为空");
        AssertUtil.notEmpty(saleGroupCrowdViewDTO.getCrowdIdList(),BrandOneBPBaseErrorCode.PARAM_REQUIRED,"人群不能为空");
        //构建流程参数
        BizSaleGroupUpdateWorkflowParam bizSaleGroupUpdateWorkflowParam = buildParamForSaleGroupUpdate(serviceContext, saleGroupCrowdViewDTO.getCampaignGroupId(), saleGroupCrowdViewDTO.getSaleGroupId());

        CampaignGroupViewDTO campaignGroupViewDTO = bizSaleGroupUpdateWorkflowParam.getCampaignGroupViewDTO();
        SaleGroupInfoViewDTO saleGroupInfoViewDTO = bizSaleGroupUpdateWorkflowParam.getSaleGroupInfoViewDTO();
//        ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO = bizSaleGroupUpdateWorkflowParam.getPackageSaleGroupViewDTO();
        //订单分组状态校验
        saleGroupStatusValidateForUpdateSaleGroupAbility.handle(serviceContext, SaleGroupStatusValidateForUpdateSaleGroupAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO).saleGroupInfoViewDTO(saleGroupInfoViewDTO).build());
        //校验分组人群
//        bizSaleGroupAbility.validateSaleGroupCrowd(serviceContext, saleGroupCrowdViewDTO, campaignGroupViewDTO, saleGroupInfoViewDTO, packageSaleGroupViewDTO);
//        AssertUtil.assertTrue(Objects.equals(saleGroupInfoViewDTO.getSaleGroupStatus(),BrandCampaignGroupSaleOrderStatusEnum.WAIT_ORDER.getCode()),
//                BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR,"分组在未下单的情况下，才可以修改指标/人群");
        //填充分组人群信息
//        bizSaleGroupAbility.fillSaleGroupCrowd(serviceContext, saleGroupCrowdViewDTO, saleGroupInfoViewDTO);
        saleGroupCrowdInitForUpdateSaleGroupAbility.handle(serviceContext, SaleGroupCrowdInitForUpdateSaleGroupAbilityParam.builder()
                .abilityTarget(saleGroupInfoViewDTO)
                .saleGroupCrowdViewDTO(saleGroupCrowdViewDTO).build());
        //商业能力挂载
        BusinessAbilityRouteContext businessAbilityRouteContext = BusinessAbilityRouteContext.builder().packageSaleGroupViewDTO(bizSaleGroupUpdateWorkflowParam.getPackageSaleGroupViewDTO()).build();
        invokeAll(ISaleGroupCrowdUpdateBusinessAbilityPoint.class, businessAbilityRouteContext,
                callback -> callback.invokeForSaleGroupCrowd(serviceContext,saleGroupCrowdViewDTO, saleGroupInfoViewDTO, businessAbilityRouteContext));
        //保存分组人群
        campaignGroupRepository.updateSaleGroupAll(serviceContext, Lists.newArrayList(saleGroupInfoViewDTO));
        //更新分组单元关联人群
        SaleGroupCrowdUpdateEvent saleGroupCrowdUpdateEvent = SaleGroupCrowdUpdateEvent.of(
                SaleGroupCrowdUpdateContext.builder().serviceContext(serviceContext)
                        .saleGroupInfoViewDTO(saleGroupInfoViewDTO)
                        .build()
        );
        simpleEventEngine.fire(saleGroupCrowdUpdateEvent);
        return 1;
    }

    /**
     * 清空订单分组预估结果
     * @param serviceContext
     * @param campaignGroupId
     * @param saleGroupIds
     */
    public void clearSaleGroupEstimateResult(ServiceContext serviceContext, Long campaignGroupId, List<Long> saleGroupIds){
        //商业能力挂载
        BusinessAbilityRouteContext businessAbilityRouteContext = BusinessAbilityRouteContext.builder().specifiedBusinessAbilityCodes(Lists.newArrayList(MultiTargetDeliverBusinessAbility.ABILITY_CODE)).build();
        invokeAll(ISaleGroupEstimateResultClearBusinessAbilityPoint.class, businessAbilityRouteContext,
                callback -> callback.invokeForClearSaleGroupEstimateResult(serviceContext, campaignGroupId, saleGroupIds));

//        bizSaleGroupAbility.clearEstimateResult(serviceContext, campaignGroupId, saleGroupIds);
    }

    /**
     * 发起补量/配送申请
     * @param context
     * @param applyCommandViewDTO
     * @return
     */
    public Long applySaleGroup(ServiceContext context, SaleGroupBoostGiveApplyInfoViewDTO saleGroupBoostGiveApplyInfoViewDTO, CampaignGroupSaleGroupBoostGiveApplyViewDTO applyCommandViewDTO) {
        CampaignGroupViewDTO campaignGroup = campaignGroupRepository.getCampaignGroup(context, applyCommandViewDTO.getId());
        AssertUtil.notNull(campaignGroup, BrandOneBPBaseErrorCode.BIZ_DATA_EMPTY_ERROR, "订单不存在");
        AssertUtil.notNull(applyCommandViewDTO.getMainGroupId(), "主分组不能为空");
        SaleGroupInfoViewDTO mainSaleGroupInfoViewDTO = campaignGroup.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream()
                .filter(saleGroup -> applyCommandViewDTO.getMainGroupId().equals(saleGroup.getSaleGroupId()))
                .findFirst().get();
        AssertUtil.notNull(mainSaleGroupInfoViewDTO, "未查询到订单主分组");
        // 校验
//        bizSaleGroupAbility.validateSaleGroupApplyInfo(context, campaignGroup, applyCommandViewDTO);
        saleGroupApplyInfoValidateForApplySaleGroupAbility.handle(context, SaleGroupApplyInfoAbilityParam.builder()
                .abilityTarget(saleGroupBoostGiveApplyInfoViewDTO)
                .mainSaleGroupInfoViewDTO(mainSaleGroupInfoViewDTO)
                .campaignGroup(campaignGroup)
                .build());

        // 初始化
//        bizSaleGroupAbility.initSaleGroupApplyInfo(campaignGroup, applyCommandViewDTO);
        if (Objects.isNull(saleGroupBoostGiveApplyInfoViewDTO.getSaleGroupId())) {
            saleGroupApplyInfoInitForApplySaleGroupAbility.handle(context, SaleGroupApplyInfoAbilityParam.builder()
                    .abilityTarget(saleGroupBoostGiveApplyInfoViewDTO)
                    .mainSaleGroupInfoViewDTO(mainSaleGroupInfoViewDTO)
                    .build());
        } else {
            saleGroupApplyInfoValidateForUpdateSaleGroupAbility.handle(context, SaleGroupApplyInfoAbilityParam.builder()
                    .abilityTarget(saleGroupBoostGiveApplyInfoViewDTO)
                    .mainSaleGroupInfoViewDTO(mainSaleGroupInfoViewDTO)
                    .campaignGroup(campaignGroup)
                    .build());
            saleGroupApplyInfoInitForUpdateSaleGroupAbility.handle(context, SaleGroupApplyInfoAbilityParam.builder()
                    .abilityTarget(saleGroupBoostGiveApplyInfoViewDTO)
                    .mainSaleGroupInfoViewDTO(mainSaleGroupInfoViewDTO)
                    .build());
        }

        // 提交申请
//        bizSaleGroupAbility.submitApplyBoostGiveSaleGroup(context, applyCommandViewDTO);
        saleGroupSubmitForApplySaleGroupAbility.handle(context, SaleGroupApplyInfoAbilityParam.builder()
                .abilityTarget(saleGroupBoostGiveApplyInfoViewDTO)
                .mainSaleGroupInfoViewDTO(mainSaleGroupInfoViewDTO)
                .build());
        // 保存
//        bizSaleGroupAbility.saveBoostGiveSaleGroupApplyInfo(context, campaignGroup, applyCommandViewDTO);
        saleGroupApplyInfoSaveForApplySaleGroupAbility.handle(context, SaleGroupApplyInfoAbilityParam.builder()
                .abilityTarget(saleGroupBoostGiveApplyInfoViewDTO)
                .mainSaleGroupInfoViewDTO(mainSaleGroupInfoViewDTO)
                .build());

        return saleGroupBoostGiveApplyInfoViewDTO.getSaleGroupId();
    }

    /**
     * 删除发起的补量/配送申请
     * @param context
     * @param saleGroupBoostGiveApplyInfoViewDTO
     * @param applyCommandViewDTO
     * @return
     */
    public Long deleteSaleGroup(ServiceContext context, SaleGroupBoostGiveApplyInfoViewDTO saleGroupBoostGiveApplyInfoViewDTO, CampaignGroupSaleGroupBoostGiveApplyViewDTO applyCommandViewDTO) {
        CampaignGroupViewDTO campaignGroup = campaignGroupRepository.getCampaignGroup(context, applyCommandViewDTO.getId());
        AssertUtil.notNull(campaignGroup, BrandOneBPBaseErrorCode.BIZ_DATA_EMPTY_ERROR, "订单不存在");
        AssertUtil.notNull(applyCommandViewDTO.getMainGroupId(), "主分组不能为空");
        SaleGroupInfoViewDTO mainSaleGroupInfoViewDTO = campaignGroup.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream()
                .filter(saleGroup -> applyCommandViewDTO.getMainGroupId().equals(saleGroup.getSaleGroupId()))
                .findFirst().get();
        AssertUtil.notNull(mainSaleGroupInfoViewDTO, "未查询到订单主分组");
//        bizSaleGroupAbility.validateSaleGroupDeleteInfo(context, campaignGroup, applyViewDTO);
        saleGroupApplyInfoValidateForDeleteSaleGroupAbility.handle(context, SaleGroupApplyInfoAbilityParam.builder()
                .abilityTarget(saleGroupBoostGiveApplyInfoViewDTO)
                .mainSaleGroupInfoViewDTO(mainSaleGroupInfoViewDTO)
                .campaignGroup(campaignGroup)
                .build());
        resourcePackageRepository.deleteSaleGroup(context, saleGroupBoostGiveApplyInfoViewDTO, mainSaleGroupInfoViewDTO.getSaleGroupId());
//        bizSaleGroupAbility.deleteSaleGroupApplyInfo(context, campaignGroup, applyViewDTO);
        saleGroupApplyInfoSaveForDeleteSaleGroupAbility.handle(context, SaleGroupApplyInfoAbilityParam.builder()
                .abilityTarget(saleGroupBoostGiveApplyInfoViewDTO)
                .mainSaleGroupInfoViewDTO(mainSaleGroupInfoViewDTO)
                .campaignGroup(campaignGroup)
                .build());
        return saleGroupBoostGiveApplyInfoViewDTO.getSaleGroupId();
    }

    /**
     * 订单分组计算
     * @param context
     * @param saleGroupCalViewDTO
     * @param calculateWorkflowParam
     * @return 分组计算结果
     */
    public CampaignGroupSaleGroupCalViewDTO assignSaleGroupProductCampaignBudget(ServiceContext context, CampaignGroupSaleGroupCalViewDTO saleGroupCalViewDTO, BizCampaignGroupCalculateWorkflowParam calculateWorkflowParam) {
        Long resourceSaleGroupId = saleGroupCalViewDTO.getSaleGroupId();
        List<CampaignViewDTO> campaignTreeViewDTOList = calculateWorkflowParam.getCampaignTreeViewDTOList();
        ResourcePackageSaleGroupViewDTO resourcePackageSaleGroup = calculateWorkflowParam.getPackageSaleGroupViewDTO();
        CampaignGroupViewDTO campaignGroup = calculateWorkflowParam.getCampaignGroupViewDTO();

        //产品-计划映射，key:资源产品id，value：计划列表
        Map<Long, List<CampaignCalViewDTO>> productCampaignCalMap = saleGroupCalViewDTO.getProductCampaignList().stream()
                .collect(Collectors.toMap(ProductCampaignCalViewDTO::getResourcePackageProductId, ProductCampaignCalViewDTO::getCampaignList,(v1, v2) -> v2));

        //计算资源分类预算，key:资源分类，value:资源分类预算
        Map<String, Long> resourceCategoryBudgetMap = saleGroupResourceCategoryBudgetAssignForCalculateAbility.handle(context, SaleGroupBudgetAssignAbilityParam.builder().abilityTarget(calculateWorkflowParam.getPackageSaleGroupViewDTO()).build());
        RogerLogger.info("calculate-resourceSaleGroupId={} category-budget {}",resourceSaleGroupId, JSON.toJSONString(resourceCategoryBudgetMap));

        //分配资源产品预算
        List<ProductCampaignCalViewDTO> productCampaignCalViewDTOList = Lists.newArrayList();
        for (ResourceDistributionRuleViewDTO ruleViewDTO : resourcePackageSaleGroup.getDistributionRuleList()) {
            if(Objects.isNull(ruleViewDTO.getRatio())){
                continue;
            }
            //资源分类预算
            Long resourceCategoryBudget = resourceCategoryBudgetMap.get(ruleViewDTO.getCategory());
            //计算产品信息
            List<ResourcePackageProductViewDTO> calcProductList = ruleViewDTO.getResourcePackageProductList()
                    .stream().filter(v -> productCampaignCalMap.containsKey(v.getId())).collect(Collectors.toList());

            //参与计算的售卖产品id
            List<Long> calcProductIdList = calcProductList.stream().map(ResourcePackageProductViewDTO::getId).collect(Collectors.toList());

            //产品关联计划树
            List<CampaignViewDTO> calcCampaignTreeList = campaignTreeViewDTOList.stream()
                    .filter(campaign -> calcProductIdList.contains(campaign.getCampaignSaleViewDTO().getResourcePackageProductId()))
                    .collect(Collectors.toList());
            //产品关联计划计算配置
            Map<Long, List<CampaignCalViewDTO>> calcCampaignMap = productCampaignCalMap.entrySet().stream()
                    .filter(entry -> calcProductIdList.contains(entry.getKey()))
                    .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

            //计算资源产品预算
            SaleGroupProductBudgetViewDTO productBudgetViewDTO = assignProductBudget(context, campaignGroup, resourcePackageSaleGroup,
                    resourceCategoryBudget, calcProductList, calcCampaignTreeList, calcCampaignMap);

            RogerLogger.info("calculate-resourceSaleGroupId={} resourceCategoryBudget={} productBudget {}",resourceSaleGroupId,resourceCategoryBudget,JSON.toJSONString(productBudgetViewDTO));

            //计算一级计划预算
            List<ProductCampaignCalViewDTO> productCampaignBudgetResultList = saleGroupAssignForCalculateAbility.handle(context, CampaignCalculateAbilityParam.builder().abilityTarget(saleGroupCalViewDTO).packageSaleGroupViewDTO(resourcePackageSaleGroup).productBudgetViewDTO(productBudgetViewDTO).campaignTreeList(calcCampaignTreeList).calcCampaignMap(calcCampaignMap).build());

            RogerLogger.info("calculate-resourceSaleGroupId={} resourceCategoryBudget={} campaignBudget {}",resourceSaleGroupId,resourceCategoryBudget,JSON.toJSONString(productCampaignBudgetResultList));

            productCampaignCalViewDTOList.addAll(productCampaignBudgetResultList);
        }
        CampaignGroupSaleGroupCalViewDTO campaignGroupSaleGroupCalViewDTO = new CampaignGroupSaleGroupCalViewDTO();
        campaignGroupSaleGroupCalViewDTO.setCampaignGroupId(saleGroupCalViewDTO.getCampaignGroupId());
        campaignGroupSaleGroupCalViewDTO.setSaleGroupId(saleGroupCalViewDTO.getSaleGroupId());
        campaignGroupSaleGroupCalViewDTO.setBudget(resourcePackageSaleGroup.getBudget());
        campaignGroupSaleGroupCalViewDTO.setBudgetSettingType(saleGroupCalViewDTO.getBudgetSettingType());
        campaignGroupSaleGroupCalViewDTO.setProductCampaignList(productCampaignCalViewDTOList);
        RogerLogger.info("calculate-resourceSaleGroupId={} result={}",resourceSaleGroupId ,JSON.toJSONString(campaignGroupSaleGroupCalViewDTO));
        return campaignGroupSaleGroupCalViewDTO;
    }

    /**
     * 计算分组总预定pv和cpm单价
     * 分组预计曝光量折扣来打折曝光量
     */
    public void calculateSaleGroup(ServiceContext context, List<CampaignViewDTO> campaignViewDTOList,
                                   CampaignGroupSaleGroupCalViewDTO calculatedResult, ResourcePackageSaleGroupViewDTO saleGroup) {
        List<CampaignViewDTO> oneLevelCampaignList = campaignViewDTOList.stream()
                .filter(v -> BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode().equals(v.getCampaignLevel()))
                .collect(Collectors.toList());
        long pv = saleGroupPvAssignForCalculateAbility.handle(context, ResourcePackageSaleGroupCalculateAbilityParam.builder().abilityTarget(saleGroup).campaignTreeList(oneLevelCampaignList).build());
        calculatedResult.setAmount(pv);
        Long budget = calculatedResult.getBudget();
        //转化cpm单价
        Long unitPrice = new BigDecimal(budget).multiply(new BigDecimal(1000)).divide(new BigDecimal(pv), 0, RoundingMode.HALF_UP).longValue();
        calculatedResult.setUnitPrice(unitPrice);
    }


    private BizSaleGroupUpdateWorkflowParam buildParamForSaleGroupUpdate(ServiceContext serviceContext, Long campaignGroupId, Long saleGroupId) {
        AssertUtil.notNull(campaignGroupId, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "订单不能为空");
        AssertUtil.notNull(saleGroupId, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "分组不能为空");
        //订单
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(serviceContext, campaignGroupId);
        AssertUtil.notNull(campaignGroupViewDTO, BrandOneBPBaseErrorCode.BIZ_DATA_EMPTY_ERROR, "订单未查到");

        SaleGroupInfoViewDTO saleGroupInfoViewDTO = Optional.ofNullable(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO()).map(CampaignGroupSaleGroupViewDTO::getSaleGroupInfoViewDTOList).orElse(Lists.newArrayList())
                .stream().filter(saleGroupInfo -> Objects.equals(saleGroupId, saleGroupInfo.getSaleGroupId())).findFirst().orElse(null);
        AssertUtil.notNull(saleGroupInfoViewDTO, BrandOneBPBaseErrorCode.BIZ_DATA_EMPTY_ERROR, "售卖分组不存在，请检查");

        ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO = resourcePackageRepository.getSaleGroupById(serviceContext, saleGroupId,
                ResourcePackageQueryOption.builder().needProduct(true).needSetting(true).build());
        AssertUtil.notNull(packageSaleGroupViewDTO, BrandOneBPBaseErrorCode.BIZ_DATA_EMPTY_ERROR, "资源售卖分组不存在，请检查");

        return BizSaleGroupUpdateWorkflowParam.builder().campaignGroupViewDTO(campaignGroupViewDTO).saleGroupInfoViewDTO(saleGroupInfoViewDTO)
                .packageSaleGroupViewDTO(packageSaleGroupViewDTO).build();
    }

    /**
     * 计算资源产品预算
     *
     * @param campaignGroup
     * @param resourcePackageSaleGroup
     * @param resourceCategoryBudget
     * @param resourcePackageProductList
     * @param campaignTreeList
     * @param campaignCalMap
     * @return
     */
    private SaleGroupProductBudgetViewDTO assignProductBudget(ServiceContext context, CampaignGroupViewDTO campaignGroup, ResourcePackageSaleGroupViewDTO resourcePackageSaleGroup,
                                                              Long resourceCategoryBudget, List<ResourcePackageProductViewDTO> resourcePackageProductList,
                                                              List<CampaignViewDTO> campaignTreeList, Map<Long, List<CampaignCalViewDTO>> campaignCalMap) {

        RogerLogger.info("calculate-resourceSaleGroupId={} calculateProductBudget productConfigType={}",
                resourcePackageSaleGroup.getId(),resourcePackageSaleGroup.getProductConfigType());
        //自定义分组校验
        saleGroupProductBudgetAssignValidateForCalculateAbility.handle(context, SaleGroupBudgetAssignAbilityParam.builder().abilityTarget(resourcePackageSaleGroup).campaignGroupViewDTO(campaignGroup).resourceCategoryBudget(resourceCategoryBudget).resourcePackageProductViewDTOList(resourcePackageProductList).campaignViewDTOList(campaignTreeList).calcCampaignMap(campaignCalMap).build());
        return saleGroupProductBudgetAssignForCalculateAbility.handle(context, SaleGroupBudgetAssignAbilityParam.builder().abilityTarget(resourcePackageSaleGroup).campaignGroupViewDTO(campaignGroup).resourcePackageProductViewDTOList(resourcePackageProductList).calcCampaignMap(campaignCalMap).resourceCategoryBudget(resourceCategoryBudget).campaignViewDTOList(campaignTreeList).build());
    }

}
