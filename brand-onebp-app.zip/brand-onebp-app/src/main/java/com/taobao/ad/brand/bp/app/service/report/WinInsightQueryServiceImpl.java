package com.taobao.ad.brand.bp.app.service.report;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.app.workflow.insight.WinInsightExportWorkflow;
import com.taobao.ad.brand.bp.app.workflow.insight.WinInsightQueryWorkflow;
import com.taobao.ad.brand.bp.app.workflow.insight.WinSmartInsightWorkflow;
import com.taobao.ad.brand.bp.client.api.insight.WinInsightQueryService;
import com.taobao.ad.brand.bp.client.dto.brand.CompetitionBrandViewDTO;
import com.taobao.ad.brand.bp.client.dto.insight.WinInsightBrandQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.insight.WinInsightBrandViewDTO;
import com.taobao.ad.brand.bp.client.dto.insight.WinInsightQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.insight.WinInsightMetricsEnum;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * 报表查询相关服务
 * @author yuncheng.lyc
 */
@HSFProvider(serviceInterface = WinInsightQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class WinInsightQueryServiceImpl implements WinInsightQueryService {

    private final WinInsightQueryWorkflow winInsightQueryWorkflow;
    private final WinInsightExportWorkflow winInsightExportWorkflow;
    private final WinSmartInsightWorkflow winSmartInsightWorkflow;

    @Override
    public MultiResponse<Map<String, Object>> dimensionList(ServiceContext serviceContext, WinInsightQueryViewDTO winInsightQueryViewDTO) {
        List<Map<String, Object>> dimensionList = winInsightQueryWorkflow.dimensionList(serviceContext, winInsightQueryViewDTO);
        if(CollectionUtils.isEmpty(dimensionList)){
            return MultiResponse.of(dimensionList, 0);
        }
        return MultiResponse.of(dimensionList, dimensionList.size());
    }

    @Override
    public MultiResponse<Map<String, Object>> query(ServiceContext serviceContext, WinInsightQueryViewDTO winInsightQueryViewDTO) {
        List<Map<String, Object>> queryResult = winInsightQueryWorkflow.query(serviceContext, winInsightQueryViewDTO);
        List<Map<String, Object>> reformatDataList = reformat(queryResult);
        if(CollectionUtils.isEmpty(reformatDataList)){
            return MultiResponse.of(reformatDataList, 0);
        }
        return MultiResponse.of(reformatDataList, reformatDataList.size());
    }

    /**
     * 数据格式化
     * @param dataList
     * @return
     */
    private List<Map<String, Object>> reformat(List<Map<String, Object>> dataList) {
        // 所有数据指标保留两位小数
        if(CollectionUtils.isNotEmpty(dataList)) {
            dataList.forEach(data -> {
                data.forEach((key, value) -> {
                    // 率值x10000取整
                    if(WinInsightMetricsEnum.getRateDataMetrics().contains(WinInsightMetricsEnum.of(key))) {
                        if(Objects.nonNull(value)) {
                            BigDecimal bigDecimal = new BigDecimal(String.valueOf(value)).multiply(new BigDecimal(10000)).setScale(0, RoundingMode.HALF_UP);
                            data.put(key, bigDecimal.doubleValue());
                        }
                    }

                    // win指标x100取整
                    if(WinInsightMetricsEnum.getWindDataMetrics().contains(WinInsightMetricsEnum.of(key))) {
                        if(Objects.nonNull(value)) {
                            BigDecimal bigDecimal = new BigDecimal(String.valueOf(value)).multiply(new BigDecimal(100)).setScale(0, RoundingMode.HALF_UP);
                            data.put(key, bigDecimal.doubleValue());
                        }
                    }

                    // 其余数据指标直接取整
                    if(WinInsightMetricsEnum.getBasicDataMetrics().contains(WinInsightMetricsEnum.of(key))) {
                        if(Objects.nonNull(value)) {
                            BigDecimal bigDecimal = new BigDecimal(String.valueOf(value)).setScale(0, RoundingMode.HALF_UP);
                            data.put(key, bigDecimal.doubleValue());
                        }
                    }
                });
            });
        }
        return dataList;
    }


    @Override
    public SingleResponse<String> basicExport(ServiceContext serviceContext, WinInsightQueryViewDTO winInsightQueryViewDTO) {
        String ossUrl = winInsightExportWorkflow.basicExport(serviceContext, winInsightQueryViewDTO);
        return SingleResponse.of(ossUrl);
    }

    @Override
    public SingleResponse<String> industryExport(ServiceContext serviceContext, WinInsightQueryViewDTO winInsightQueryViewDTO) {
        String ossUrl = winInsightExportWorkflow.industryExport(serviceContext, winInsightQueryViewDTO);
        return SingleResponse.of(ossUrl);
    }

    @Override
    public SingleResponse<Map<String, String>> smartExplain(ServiceContext serviceContext, WinInsightQueryViewDTO winInsightQueryViewDTO) {
        Map<String, String> result = winSmartInsightWorkflow.smartExplain(serviceContext, winInsightQueryViewDTO);
        return SingleResponse.of(result);
    }

    @Override
    public SingleResponse<Map<String, Object>> smartExplainQuery(ServiceContext serviceContext, WinInsightQueryViewDTO winInsightQueryViewDTO) {
        Map<String, Object> result = winSmartInsightWorkflow.smartExplainQuery(serviceContext, winInsightQueryViewDTO);
        return SingleResponse.of(result);
    }

    @Override
    public MultiResponse<WinInsightBrandViewDTO> queryBrandList(ServiceContext serviceContext, WinInsightBrandQueryViewDTO brandQueryViewDTO) {
        List<WinInsightBrandViewDTO> brandList = winInsightQueryWorkflow.queryBrandList(serviceContext, brandQueryViewDTO);
        return MultiResponse.of(brandList, brandList.size());
    }

    @Override
    public MultiResponse<CompetitionBrandViewDTO> queryCompetitionBrandList(ServiceContext serviceContext, WinInsightBrandQueryViewDTO brandQueryViewDTO) {
        List<CompetitionBrandViewDTO> competitionBrandViewDTOS = winInsightQueryWorkflow.queryCompetitionBrandList(serviceContext, brandQueryViewDTO);
        return MultiResponse.of(competitionBrandViewDTOS, competitionBrandViewDTOS.size());
    }
}