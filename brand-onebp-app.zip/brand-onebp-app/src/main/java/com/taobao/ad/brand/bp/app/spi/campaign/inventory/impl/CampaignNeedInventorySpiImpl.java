package com.taobao.ad.brand.bp.app.spi.campaign.inventory.impl;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.nb.framework.core.annotation.AbilitySpiInstance;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alibaba.fastjson.JSONObject;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.app.spi.campaign.inventory.BizCampaignInventorySpi;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignInventoryWorkflow;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignInquiryOperateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignScheduleViewDTO;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.threadpooltask.CampaignInventoryReuqestTaskIdentifier;
import com.taobao.ad.brand.bp.domain.inventory.InventoryRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.inventory.ICampaignDoohReleaseForCampaignInventoryOperateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.inventory.ICampaignInventoryRpcInvokeAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.inventory.ICampaignStopForInventoryReleaseAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignDoohReleaseAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignInventoryRpcInvokeAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignStopForInventoryReleaseAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.delivery.ISaleGroupEstimateResultClearForSaleGroupEstimateAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupEstimateResultClearForSaleGroupEstimateAbilityParam;
import org.apache.commons.collections.CollectionUtils;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@AbilitySpiInstance(bizCodes = {BizCampaignInventorySpi.NEED_INVENTORY}, name = "campaignNeedInventorySpiImpl", desc = "库存询量/锁量实现")
public class CampaignNeedInventorySpiImpl extends DefaultBizCampaignInventorySpiImpl {
    @Resource
    private InventoryRepository inventoryRepository;
    @Resource
    private ISaleGroupEstimateResultClearForSaleGroupEstimateAbility saleGroupEstimateResultClearForSaleGroupEstimateAbility;
    @Resource
    private ICampaignStopForInventoryReleaseAbility campaignStopForInventoryReleaseAbility;
    @Resource
    private ICampaignDoohReleaseForCampaignInventoryOperateAbility campaignDoohReleaseForCampaignInventoryOperateAbility;
    @Resource
    private ICampaignInventoryRpcInvokeAbility campaignInventoryRpcInvokeAbility;
    @Resource
    private BizCampaignInventoryWorkflow bizCampaignInventoryWorkflow;
    @Resource
    private CampaignInventoryReuqestTaskIdentifier campaignInventoryReuqestTaskIdentifier;


//    private static final ThreadPoolExecutor THREAD_POOL = new ThreadPoolExecutor(
//            Runtime.getRuntime().availableProcessors(), Runtime.getRuntime().availableProcessors(), 60L, TimeUnit.SECONDS, new ArrayBlockingQueue<>(200),
//            new ThreadFactoryBuilder().setNameFormat("campaign_inventory_task-%d").build());

    @Override
    public Void inventoryRequest(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO,
                                 List<CampaignViewDTO> campaignTreeViewDTOList, List<CampaignScheduleViewDTO> campaignScheduleViewDTOList) {
        if (CollectionUtils.isEmpty(campaignScheduleViewDTOList)) {
            return null;
        }
        //更新计划status后置，防止单个计划有问题影响其他的计划操作
        Map<Long, CampaignViewDTO> campaignTreeMap = campaignTreeViewDTOList.stream()
                .collect(Collectors.toMap(v -> v.getId(), v -> v));
        TaskStream.consume(campaignInventoryReuqestTaskIdentifier, campaignScheduleViewDTOList, (campaignScheduleViewDTO, index) -> {
            CampaignViewDTO campaignViewDTO = campaignTreeMap.get(campaignScheduleViewDTO.getId());
            //先更新父子计划status，失败后需要回滚：因为回调可能会先于库的更新
            bizCampaignInventoryWorkflow.updateInventoryOperateCampaignStatus(serviceContext, Lists.newArrayList(campaignScheduleViewDTO));
            //执行库存服务调用
            CampaignInventoryRpcInvokeAbilityParam rpcInvokeAbilityParam = CampaignInventoryRpcInvokeAbilityParam.builder()
                    .abilityTarget(campaignScheduleViewDTO).campaignViewDTO(campaignViewDTO).build();
            campaignInventoryRpcInvokeAbility.handle(serviceContext,rpcInvokeAbilityParam);
        }).commit().handle();
        return null;
    }

    @Override
    public Void releaseCampaign(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList) {
        // 计划暂停
        campaignStopForInventoryReleaseAbility.handle(serviceContext, CampaignStopForInventoryReleaseAbilityParam.builder().abilityTargets(campaignViewDTOList).build());
        //获取需要执行释量的计划
        List<CampaignViewDTO> needReleaseSubCampaignList = getNeedReleaseSubCampaignList(campaignViewDTOList);
        if(CollectionUtils.isNotEmpty(needReleaseSubCampaignList)){
            RogerLogger.info("need release list {}", JSONObject.toJSONString(needReleaseSubCampaignList));
            //天攻计划释量
            campaignDoohReleaseForCampaignInventoryOperateAbility.handle(serviceContext, CampaignDoohReleaseAbilityParam.builder().abilityTargets(needReleaseSubCampaignList).build());
            //库存释量操作
            needReleaseSubCampaignList.forEach(subCampaignViewDTO -> {
                inventoryRepository.release(serviceContext, subCampaignViewDTO);
            });
            //清空交付预估结果
            Map<Long, List<Long>> campaignGroup2SaleGroupMap = needReleaseSubCampaignList.stream()
                    .filter(campaignViewDTO -> campaignViewDTO.getCampaignGroupId() != null && campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId() != null)
                    .collect(Collectors.groupingBy(campaignViewDTO -> campaignViewDTO.getCampaignGroupId(),
                    Collectors.mapping(campaignViewDTO -> campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId(), Collectors.toList())));
            campaignGroup2SaleGroupMap.forEach((campaignGroupId,saleGroupIdList) -> {
                saleGroupEstimateResultClearForSaleGroupEstimateAbility.handle(serviceContext,
                        SaleGroupEstimateResultClearForSaleGroupEstimateAbilityParam.builder().abilityTarget(campaignGroupId).saleGroupIds(saleGroupIdList).build());
            });
        }
        return null;
    }

    /**
     * 获取需要进行释量
     * @param campaignViewDTOList
     * @return
     */
    private List<CampaignViewDTO> getNeedReleaseSubCampaignList(List<CampaignViewDTO> campaignViewDTOList){
        return campaignViewDTOList.stream().filter(campaignViewDTO -> CollectionUtils.isNotEmpty(campaignViewDTO.getSubCampaignViewDTOList()))
                .flatMap(campaignViewDTO -> campaignViewDTO.getSubCampaignViewDTOList().stream())
                .filter(subCampaignViewDTO -> Constant.CAN_RELEASE_STATUS.contains(subCampaignViewDTO.getStatus()))
                .collect(Collectors.toList());
    }
}
