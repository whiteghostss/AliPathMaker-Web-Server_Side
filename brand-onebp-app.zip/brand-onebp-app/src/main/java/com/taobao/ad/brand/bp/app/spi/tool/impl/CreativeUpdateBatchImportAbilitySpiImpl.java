package com.taobao.ad.brand.bp.app.spi.tool.impl;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.utils.AbilityInvoker;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.nb.framework.core.annotation.AbilitySpiInstance;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alibaba.ad.nb.tpp.exception.TppException;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.taobao.ad.brand.bp.app.businessability.SmartCreativeBusinessAbility;
import com.taobao.ad.brand.bp.app.spi.tool.BatchImportAbilitySpi;
import com.taobao.ad.brand.bp.app.workflow.creative.BizCreativeCommandWorkflow;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeBatchImportParamViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeBatchImportRawViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeBatchUpdateErrorMessageViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportTaskViewDTO;
import com.taobao.ad.brand.bp.client.dto.tool.BatchImportDistLockParamViewDTO;
import com.taobao.ad.brand.bp.client.dto.tool.BatchImportParamViewDTO;
import com.taobao.ad.brand.bp.client.enums.report.ReportTaskStatusEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.enums.BooleanEnum;
import com.taobao.ad.brand.bp.common.enums.distlock.DistLockEnum;
import com.taobao.ad.brand.bp.common.threadpooltask.CreativeBatchUpdateTaskIdentifier;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.report.repository.ReportSyncTaskRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbilityRouteContext;
import com.taobao.ad.brand.bp.domain.sdk.creative.businessability.ICreativeBatchImportUpdateBusinessAbilityPoint;
import com.taobao.eagleeye.EagleEye;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@AbilitySpiInstance(bizCode = BatchImportAbilitySpi.BATCH_IMPORT_CREATIVE_UPDATE, name = "CreativeUpdateBatchImportAbilitySpiImpl", desc = "创意批量编辑")
public class CreativeUpdateBatchImportAbilitySpiImpl extends DefaultBatchImportAbilitySpiImpl {
    @Resource
    private ReportSyncTaskRepository reportSyncTaskRepository;
    @Resource
    private BizCreativeCommandWorkflow bizCreativeCommandWorkflow;
    @Resource
    private CreativeBatchUpdateTaskIdentifier creativeBatchUpdateTaskIdentifier;

    private static final ThreadPoolExecutor THREAD_POOL = new ThreadPoolExecutor(
            20, 20, 60L, TimeUnit.SECONDS, new ArrayBlockingQueue<>(5120),
            new ThreadFactoryBuilder().setNameFormat("creative_batch_update-%d").build());

    @Override
    public Void validateImportParam(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO) {
        CreativeBatchImportParamViewDTO creativeBatchImportParamViewDTO = (CreativeBatchImportParamViewDTO) batchImportParamViewDTO;
        AssertUtil.notNull(creativeBatchImportParamViewDTO, "创意批量编辑参数不能为空");
        AssertUtil.notNull(creativeBatchImportParamViewDTO.getTaskId(), "创意批量编辑参数-任务ID不能为空");
        AssertUtil.notEmpty(creativeBatchImportParamViewDTO.getCreativeBatchImportRawViewDTOList(), "创意批量编辑参数-待解析参数为空");
        AssertUtil.notNull(creativeBatchImportParamViewDTO.getTaskViewDTO(), "查询创意批量编辑任务失败");
        return null;
    }

    @Override
    public BatchImportDistLockParamViewDTO buildImportDisLockParam(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO) {
        CreativeBatchImportParamViewDTO creativeBatchImportParamViewDTO = (CreativeBatchImportParamViewDTO) batchImportParamViewDTO;
        Long taskId = creativeBatchImportParamViewDTO.getTaskId();

        DistLockEnum distLockEnum = DistLockEnum.CREATIVE_BATCH_UPDATE_KEY;
        BatchImportDistLockParamViewDTO distLockParamViewDTO = new BatchImportDistLockParamViewDTO();
        distLockParamViewDTO.setLockKey(distLockEnum.formatLockKey(context.getMemberId()));
        distLockParamViewDTO.setLockReqValue(distLockEnum.formatLockValue(taskId));
        distLockParamViewDTO.setExpireTime(distLockEnum.getExpireTime());
        return distLockParamViewDTO;
    }

    @Override
    public String tryDisLockErrorMessage(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO, String distCurValue) {
        CreativeBatchImportParamViewDTO creativeBatchImportParamViewDTO = (CreativeBatchImportParamViewDTO) batchImportParamViewDTO;
        //建错误信息
        StringBuilder errorMessage = new StringBuilder();
        errorMessage.append(String.format("当前账号 %s 下已有正在执行中的批量创意导入任务 [%s] ", context.getMemberId(), distCurValue));
        if (Objects.nonNull(creativeBatchImportParamViewDTO.getCampaignGroupId())) {
            errorMessage.append(String.format("订单ID %d ", creativeBatchImportParamViewDTO.getCampaignGroupId()));
        }
        if (Objects.nonNull(creativeBatchImportParamViewDTO.getCampaignId())) {
            errorMessage.append(String.format("计划ID %d ", creativeBatchImportParamViewDTO.getCampaignId()));
        }
        if (Objects.nonNull(creativeBatchImportParamViewDTO.getAdgroupId())) {
            errorMessage.append(String.format("单元ID %d ", creativeBatchImportParamViewDTO.getAdgroupId()));
        }
        errorMessage.append(String.format("trace: %s", EagleEye.getTraceId()));
        return errorMessage.toString();
    }

    @Override
    public Void invokeImport(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO) {
        RogerLogger.info("创意批量编辑开始执行，taskViewDTO=" + JSON.toJSONString(batchImportParamViewDTO.getTaskViewDTO()));
        CreativeBatchImportParamViewDTO creativeBatchImportParamViewDTO = (CreativeBatchImportParamViewDTO) batchImportParamViewDTO;
        List<CreativeBatchImportRawViewDTO> creativeBatchImportRawViewDTOList = creativeBatchImportParamViewDTO.getCreativeBatchImportRawViewDTOList();
        TaskStream.consume(creativeBatchUpdateTaskIdentifier, creativeBatchImportRawViewDTOList, (creativeBatchImportRawViewDTO, i) -> {
            if (Boolean.TRUE.equals(creativeBatchImportRawViewDTO.getIsFiltered())) {
                // 本条计划被预检查过滤
                return;
            }
            CreativeViewDTO creativeViewDTO = creativeBatchImportRawViewDTO.getCreativeViewDTO();
            try {
                //商业能力挂载
                AbilityInvoker.invokeAll(ICreativeBatchImportUpdateBusinessAbilityPoint.class,
                        BusinessAbilityRouteContext.builder().specifiedBusinessAbilityCodes(Lists.newArrayList(SmartCreativeBusinessAbility.ABILITY_CODE)).build() ,
                        callback -> callback.invokeForCreativeBatchImportUpdate(context,creativeViewDTO));
                bizCreativeCommandWorkflow.updateCreative(context, creativeViewDTO);
            } catch (Exception e) {
                // 执行批量编辑异常，写入执行信息
                if (e instanceof TppException) {
                    if (e.getCause() != null && e.getCause() instanceof BrandOneBPException) {
                        e = (BrandOneBPException) e.getCause();
                    }
                }
                RogerLogger.error("批量编辑创意失败 {}", JSON.toJSONString(creativeViewDTO), e);
                String errorMessage = String.format("第 %d 条创意编辑失败: %s traceId: %s", i + 1, e, EagleEye.getTraceId());
                creativeBatchImportRawViewDTO.setIsFiltered(true);
                creativeBatchImportRawViewDTO.setErrorMessage(errorMessage);
            }
        })
        .commit()
        .handle();
        RogerLogger.info("创意批量编辑结束执行，taskViewDTO=" + JSON.toJSONString(batchImportParamViewDTO.getTaskViewDTO()));
        return null;
    }

    @Override
    public Void updateImportResult(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO) {
        CreativeBatchImportParamViewDTO creativeBatchImportParamViewDTO = (CreativeBatchImportParamViewDTO) batchImportParamViewDTO;
        ReportTaskViewDTO taskViewDTO = creativeBatchImportParamViewDTO.getTaskViewDTO();
        List<CreativeBatchUpdateErrorMessageViewDTO> errorMessageViewDTOS = creativeBatchImportParamViewDTO.getCreativeBatchImportRawViewDTOList().stream()
                .map(creativeBatchImportRawViewDTO -> {
                    CreativeBatchUpdateErrorMessageViewDTO errorMessageViewDTO = new CreativeBatchUpdateErrorMessageViewDTO();
                    if (Objects.nonNull(creativeBatchImportRawViewDTO.getCreativeViewDTO())) {
                        errorMessageViewDTO.setCreativeId(creativeBatchImportRawViewDTO.getCreativeViewDTO().getId());
                        errorMessageViewDTO.setCreativeName(creativeBatchImportRawViewDTO.getCreativeViewDTO().getName());
                    }
                    if(Boolean.TRUE.equals(creativeBatchImportRawViewDTO.getIsFiltered())) {
                        errorMessageViewDTO.setErrorMessage(creativeBatchImportRawViewDTO.getErrorMessage());
                        errorMessageViewDTO.setStatus(BooleanEnum.FALSE.getValue());
                    } else {
                        errorMessageViewDTO.setStatus(BooleanEnum.TRUE.getValue());
                    }
                    return errorMessageViewDTO;
                }).collect(Collectors.toList());
        taskViewDTO.setErrorMsg(JSON.toJSONString(errorMessageViewDTOS));

        long failedUpdateCreativeCount = creativeBatchImportParamViewDTO.getCreativeBatchImportRawViewDTOList().stream()
                .filter(creativeBatchImportRawViewDTO -> Boolean.TRUE.equals(creativeBatchImportRawViewDTO.getIsFiltered()))
                .count();
        if (failedUpdateCreativeCount == creativeBatchImportParamViewDTO.getCreativeBatchImportRawViewDTOList().size()) {
            // 全部异常，任务置为失败
            reportSyncTaskRepository.runFail(context, taskViewDTO);
        } else if (failedUpdateCreativeCount == 0) {
            // 没有异常记录，任务设置为成功
            taskViewDTO.setStatus(ReportTaskStatusEnum.SUCCEED.getValue());
            reportSyncTaskRepository.modifyStatus(context, taskViewDTO);
        } else if (failedUpdateCreativeCount < creativeBatchImportParamViewDTO.getCreativeBatchImportRawViewDTOList().size()) {
            // 过滤出的失败的计划条数小于总条数时设置状态为部分成功
            taskViewDTO.setStatus(ReportTaskStatusEnum.PARTIAL_SUCCESS.getValue());
            reportSyncTaskRepository.modifyStatus(context, taskViewDTO);
        }
        return null;
    }

    @Override
    public String invokeImportExceptionMessage(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO, String exceptionMeg) {
        return "创意批量编辑失败: " + exceptionMeg + " trace: " + EagleEye.getTraceId();
    }
}
