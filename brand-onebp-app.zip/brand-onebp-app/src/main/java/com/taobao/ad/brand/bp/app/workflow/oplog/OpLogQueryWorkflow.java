package com.taobao.ad.brand.bp.app.workflow.oplog;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.oplog.job.sdk.constants.EntityType;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.dto.adc.AdcComponentViewDTO;
import com.taobao.ad.brand.bp.client.dto.adc.query.AdcQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.oplog.OpLogQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.oplog.OpLogViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.enums.BooleanEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.adc.repository.AdcRepository;
import com.taobao.ad.brand.bp.domain.oplog.repository.OpLogRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author jixiu.lj
 * @date 2024/3/20 14:59
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class OpLogQueryWorkflow {

    private final OpLogRepository opLogRepository;
    private final AdcRepository adcRepository;

    private final static String OP_LOG_ADC_ROOT_COMPONENT_CODE = "oplog_template_rel";
    private final static String OP_LOG_ADC_BIZ_CODE_FILTER_CODE = "bizCode";
    private final static String OP_LOG_ADC_IS_TEMPLATE_COMPONENT_FILTER_CODE = "templateIdComponent";
    private final static String OP_LOG_ADC_NEED_CAMPAIGN_ID_PROPERTY_CODE = "needCampaignId";
    private final static String OP_LOG_ADC_NEED_ADGROUP_ID_PROPERTY_CODE = "needAdgroupId";

    private final static List<EntityType> campaignIdEntityOpTypes = Lists.newArrayList(EntityType.CAMPAIGN_TARGETING_CROWD, EntityType.UNI_CAMPAIGN_INQUIRY);
    private final static List<EntityType> adgroupIdEntityOpTypes = Lists.newArrayList(EntityType.ADGROUP_TARGETING_TAG);

    /**
     * 查询操作日志
     *
     * @param context
     * @param queryViewDTO
     * @return
     */
    public List<OpLogViewDTO> queryOpLog(ServiceContext context, OpLogQueryViewDTO queryViewDTO) {
        RogerLogger.info("queryOpLog.queryViewDTO {}", queryViewDTO);
        // 1. 参数校验
        validate(queryViewDTO);
        // 2. 构建查询参数
        initQueryParam(context, queryViewDTO);
        // 3. 日志查询
        List<OpLogViewDTO> opLogViewDTOList = opLogRepository.queryOpLog(context, queryViewDTO);
        // 4. 日志信息补全
        fillOpLogViewDTO(context, queryViewDTO, opLogViewDTOList);
        return opLogViewDTOList;
    }

    /**
     * 参数校验
     *
     * @param queryViewDTO
     */
    private void validate(OpLogQueryViewDTO queryViewDTO) {
        AssertUtil.notNull(queryViewDTO, "queryViewDTO is null");
        AssertUtil.notNull(queryViewDTO.getStartTime(), "startTime is null");
        AssertUtil.notNull(queryViewDTO.getEndTime(), "endTime is null");
        AssertUtil.notNull(queryViewDTO.getBizCode(), "bizCode is null");
        AssertUtil.assertTrue(CollectionUtils.isEmpty(queryViewDTO.getEntityIds())
                || (CollectionUtils.isNotEmpty(queryViewDTO.getEntityTypes()) && queryViewDTO.getEntityTypes().stream().noneMatch(type -> EntityType.of(type) == EntityType.UNKNOWN)), "invalid entityType");
    }

    /**
     * 构建查询参数
     *
     * @param queryViewDTO
     */
    private void initQueryParam(ServiceContext serviceContext, OpLogQueryViewDTO queryViewDTO) {

        List<Long> templateKey = parseTemplateKey(serviceContext, queryViewDTO);
        queryViewDTO.setTemplateKeys(templateKey);

        /**
         * 如果是小二伪登录则不设置operType查询
         * 非小二登录，只能查到当前登录态的operType
         */
        if (ServiceContextUtil.isAliStaff(serviceContext)) {
            queryViewDTO.setOperType(null);
        } else if (Integer.valueOf(ServiceContext.OPERTYPE_NORMAL).equals(serviceContext.getOperType())) {
            //商家账号可以看到 子账号和员工账号的日志
            queryViewDTO.setOperType(null);
            queryViewDTO.setOperTypeList(Lists.newArrayList(serviceContext.getOperType(), ServiceContext.OPERTYPE_SUBUSER, ServiceContext.OPERTYPE_READWRITE_CRM));
        } else if (Integer.valueOf(ServiceContext.OPERTYPE_READWRITE_AGENCY_X).equals(serviceContext.getOperType())) {
            //叉乘帐号可以查询到系统自动流转的日志
            queryViewDTO.setOperType(null);
            queryViewDTO.setOperTypeList(Lists.newArrayList(serviceContext.getOperType(), ServiceContext.OPERTYPE_NORMAL));
        } else {
            queryViewDTO.setOperType(serviceContext.getOperType());
        }

        // id查询参数转换：历史已接入表entityId无法再修改，只能使用显式参数查询实体ID(campaignId与entityId查询是交集，因此查询互斥)
        if(CollectionUtils.isNotEmpty(queryViewDTO.getEntityIds())) {
            if(CollectionUtils.isNotEmpty(queryViewDTO.getEntityTypes())
                    && queryViewDTO.getEntityTypes().stream().allMatch(type -> campaignIdEntityOpTypes.contains(EntityType.of(type)))) {
                queryViewDTO.setCampaignIdIn(queryViewDTO.getEntityIds());
                queryViewDTO.setEntityIds(null);
            }
            if(CollectionUtils.isNotEmpty(queryViewDTO.getEntityTypes())
                    && queryViewDTO.getEntityTypes().stream().allMatch(type -> adgroupIdEntityOpTypes.contains(EntityType.of(type)))) {
                queryViewDTO.setAdgroupIdIn(queryViewDTO.getEntityIds());
                queryViewDTO.setEntityIds(null);
            }
        }
    }

    /**
     * 根据用户筛选的日志层级解析映射模板key
     *
     * @param queryViewDTO
     * @return
     */
    private List<Long> parseTemplateKey(ServiceContext serviceContext, OpLogQueryViewDTO queryViewDTO) {
        AdcComponentViewDTO componentViewDTO = querySpecifiedComponent(serviceContext, queryViewDTO);
        Map<String, List<AdcComponentViewDTO>> templateKeyAdcComponentViewDTOMap = parseMetricsConfigMap(componentViewDTO);
        Set<String> templateKeys = templateKeyAdcComponentViewDTOMap.keySet();
        RogerLogger.info("parseTemplateKey.templateList {}", templateKeys);
        return templateKeys.stream().map(Long::valueOf).distinct().collect(Collectors.toList());
    }

    /**
     * 解析配置
     * 找出以rootComponent为根节点的全部树路径，并组成以叶子节点的templateKey属性为key，树径为value的map
     * @param rootComponent
     * @return
     */
    private Map<String, List<AdcComponentViewDTO>> parseMetricsConfigMap(AdcComponentViewDTO rootComponent) {
        Map<String, List<AdcComponentViewDTO>> componentMap = new HashMap<>();
        traverseComponent(rootComponent, Lists.newArrayList(), componentMap);
        return componentMap;
    }

    private void traverseComponent(AdcComponentViewDTO currentComponent, List<AdcComponentViewDTO> path, Map<String, List<AdcComponentViewDTO>> leafComponents) {
        path.add(currentComponent);

        if (currentComponent.getSubComponentList().isEmpty()) {
            Optional.ofNullable(currentComponent.getCode())
                    .ifPresent(templateKey -> {
                        leafComponents.put(templateKey, new ArrayList<>(path));
                    });
        } else {
            for (AdcComponentViewDTO subComponent : currentComponent.getSubComponentList()) {
                traverseComponent(subComponent, path, leafComponents);
            }
        }

        path.remove(path.size() - 1);
    }

    /**
     * 根据查询条件，定位日志ADC树中的最小树
     * @param serviceContext
     * @param queryViewDTO
     * @return
     */
    private AdcComponentViewDTO querySpecifiedComponent(ServiceContext serviceContext, OpLogQueryViewDTO queryViewDTO) {
        AdcQueryViewDTO adcQueryViewDTO = new AdcQueryViewDTO();
        adcQueryViewDTO.setBizCode(BizCodeEnum.BRANDONEBP.getBizCode());
        adcQueryViewDTO.setComponentCode(OP_LOG_ADC_ROOT_COMPONENT_CODE);

        Map<String, Object> filterMap = Maps.newHashMap();
        filterMap.put(OP_LOG_ADC_BIZ_CODE_FILTER_CODE, queryViewDTO.getBizCode());
        filterMap.put(OP_LOG_ADC_IS_TEMPLATE_COMPONENT_FILTER_CODE, BrandBoolEnum.BRAND_TRUE.getCode());
        adcQueryViewDTO.setFilterMap(filterMap);

        List<AdcComponentViewDTO> componentList = adcRepository.findComponentList(serviceContext, adcQueryViewDTO);
        AssertUtil.notEmpty(componentList, "invalid adc componentList query");
        AdcComponentViewDTO componentViewDTO = componentList.get(0);
        AssertUtil.notEmpty(componentViewDTO.getSubComponentList(), "invalid oplog root component");
        return searchSpecifiedComponent(componentViewDTO, queryViewDTO);
    }

    /**
     * 根据查询条件，定位日志ADC树中的最小树
     * @param root
     * @param queryViewDTO
     * @return
     */
    private AdcComponentViewDTO searchSpecifiedComponent(AdcComponentViewDTO root, OpLogQueryViewDTO queryViewDTO) {
        AdcComponentViewDTO componentViewDTO = root.getSubComponentList().stream()
                .filter(subComponent -> subComponent.getCode().equals(queryViewDTO.getBizCode()))
                .findFirst()
                .orElseThrow(() -> new BrandOneBPException("invalid bizCode component"));

        AdcQueryViewDTO adcQueryViewDTO = new AdcQueryViewDTO();
        Optional.ofNullable(queryViewDTO.getEntityCode()).map(String::valueOf).ifPresent(adcQueryViewDTO::setComponentCode);
        Optional.ofNullable(queryViewDTO.getOperateCode()).ifPresent(adcQueryViewDTO::setComponentCode);
        Optional.ofNullable(queryViewDTO.getOperateDetailCode()).ifPresent(adcQueryViewDTO::setComponentCode);
        if(Objects.nonNull(adcQueryViewDTO.getComponentCode())) {
            AdcComponentViewDTO component = findComponentByCode(adcQueryViewDTO.getComponentCode(), componentViewDTO);
            AssertUtil.notNull(component, "invalid adc component");
            return component;
        }
        return componentViewDTO;
    }

    private static AdcComponentViewDTO findComponentByCode(String code, AdcComponentViewDTO root) {
        if (root.getCode().equals(code)) {
            return root;
        }
        if (CollectionUtils.isNotEmpty(root.getSubComponentList())) {
            for (AdcComponentViewDTO subComponent : root.getSubComponentList()) {
                AdcComponentViewDTO found = findComponentByCode(code, subComponent);
                if (Objects.nonNull(found)) {
                    return found;
                }
            }
        }
        return null;
    }


    /**
     * 日志信息补全
     * 1. 操作场景补全
     * 2. 实体ID替换
     * @param serviceContext
     * @param opLogViewDTOList
     */
    private void fillOpLogViewDTO(ServiceContext serviceContext, OpLogQueryViewDTO opLogQueryViewDTO, List<OpLogViewDTO> opLogViewDTOList) {
        OpLogQueryViewDTO queryViewDTO = new OpLogQueryViewDTO();
        queryViewDTO.setBizCode(opLogQueryViewDTO.getBizCode());
        AdcComponentViewDTO componentViewDTO = querySpecifiedComponent(serviceContext, queryViewDTO);
        Map<String, List<AdcComponentViewDTO>> templatKeyAdcComponentViewDTOMap = parseMetricsConfigMap(componentViewDTO);
        opLogViewDTOList.stream()
                .filter(opLogViewDTO -> Objects.nonNull(opLogViewDTO.getTemplateKey()))
                .filter(opLogViewDTO -> templatKeyAdcComponentViewDTOMap.containsKey(String.valueOf(opLogViewDTO.getTemplateKey())))
                .forEach(opLogViewDTO -> {
                    List<AdcComponentViewDTO> adcComponentViewDTOS = templatKeyAdcComponentViewDTOMap.get(String.valueOf(opLogViewDTO.getTemplateKey()));
                    AdcComponentViewDTO leafComponent = adcComponentViewDTOS.get(3);
                    opLogViewDTO.setBizCode(adcComponentViewDTOS.get(0).getName());
                    opLogViewDTO.setEntityCode(adcComponentViewDTOS.get(1).getName());
                    opLogViewDTO.setOperateCode(adcComponentViewDTOS.get(2).getName());
                    opLogViewDTO.setOperateDetailCode(leafComponent.getName());

                    Optional.ofNullable(leafComponent.getProperties())
                            .map(property -> property.get(OP_LOG_ADC_NEED_CAMPAIGN_ID_PROPERTY_CODE))
                            .map(v -> Integer.valueOf(v.toString()))
                            .filter(v -> BooleanEnum.TRUE.getValue().equals(v))
                            .ifPresent( property -> {
                                opLogViewDTO.setEntityId(opLogViewDTO.getCampaignId());
                            });
                    Optional.ofNullable(leafComponent.getProperties())
                            .map(property -> property.get(OP_LOG_ADC_NEED_ADGROUP_ID_PROPERTY_CODE))
                            .map(v -> Integer.valueOf(v.toString()))
                            .filter(v -> BooleanEnum.TRUE.getValue().equals(v))
                            .ifPresent( property -> {
                                opLogViewDTO.setEntityId(opLogViewDTO.getAdgroupId());
                            });
                });
    }
}
