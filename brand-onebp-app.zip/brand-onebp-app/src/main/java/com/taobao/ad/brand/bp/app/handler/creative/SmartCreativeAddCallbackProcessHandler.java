package com.taobao.ad.brand.bp.app.handler.creative;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.fastjson.JSON;
import com.alibaba.hermes.framework.ddd.event.annotation.DomainEventHandler;
import com.alibaba.hermes.framework.event.EventHandler;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.app.workflow.creative.BizCreativeCommandWorkflow;
import com.taobao.ad.brand.bp.domain.event.creative.SmartCreativeAddCallbackEvent;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 计划库存回调通知链路
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@DomainEventHandler(topic = "smart_creative_add_success_callback_topic", event = SmartCreativeAddCallbackEvent.class)
public class SmartCreativeAddCallbackProcessHandler implements EventHandler<SmartCreativeAddCallbackEvent> {
    private final BizCreativeCommandWorkflow bizCreativeCommandWorkflow;

    @Override
    public Response handle(SmartCreativeAddCallbackEvent smartCreativeAddCallbackEvent) {
        RogerLogger.info("smart_creative_add_success_callback_topic start:{}", JSON.toJSONString(smartCreativeAddCallbackEvent));
        CreativeViewDTO creativeViewDTO = smartCreativeAddCallbackEvent.getContext().getCreativeViewDTO();
        ServiceContext serviceContext = smartCreativeAddCallbackEvent.getContext().getServiceContext();
        bizCreativeCommandWorkflow.generateTaoInnerSmartSubCreative(serviceContext, creativeViewDTO);
        return Response.success();
    }
}
