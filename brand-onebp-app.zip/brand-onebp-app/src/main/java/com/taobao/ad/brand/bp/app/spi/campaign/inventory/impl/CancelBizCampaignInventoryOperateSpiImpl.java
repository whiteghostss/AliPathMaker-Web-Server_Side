package com.taobao.ad.brand.bp.app.spi.campaign.inventory.impl;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.alibaba.ad.nb.framework.core.annotation.AbilitySpiInstance;
import com.alibaba.hermes.framework.error.ErrorCodeAware;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignInquiryOperateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignScheduleViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.app.spi.campaign.inventory.BizCampaignInventoryOperateSpi;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignInventoryWorkflowParam;
import org.apache.commons.collections4.CollectionUtils;

import java.util.Arrays;
import java.util.List;

@AbilitySpiInstance(bizCode = BizCampaignInventoryOperateSpi.CANCEL, name = "cancelBizCampaignInventoryOperateSpiImpl", desc = "取消询/锁量操作实现")
public class CancelBizCampaignInventoryOperateSpiImpl extends DefaultBizCampaignInventoryOperateSpiImpl {

    @Override
    public ErrorCodeAware validateCampaignInventoryOperate(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO, BizCampaignInventoryWorkflowParam inventoryWorkflowParam) {
        if (CollectionUtils.isNotEmpty(inventoryWorkflowParam.getCampaignScheduleViewDTOList())) {
            List<Integer> campaignStatusList = Arrays.asList(BrandCampaignStatusEnum.INQUIRING.getCode(), BrandCampaignStatusEnum.LOCKING.getCode());
            AssertUtil.assertTrue(inventoryWorkflowParam.getCampaignScheduleViewDTOList().stream().map(CampaignScheduleViewDTO::getStatus).allMatch(campaignStatusList::contains),
                    "已勾选计划，存在计划不在询/锁量中，无法批量操作，请重新选择");
        }
        return null;
    }
}

