package com.taobao.ad.brand.bp.app.service.report;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.batch.BatchInvoker;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.api.report.BizReportQueryService;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.ReportMultiResponse;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignGroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportCampaignGroupBrandViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportDimensionConfigViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportMetricsConfigViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportTaskViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.excel.ExcelCatalogueViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.excel.ExcelOutputViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.query.ReportAttributionBrandQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.query.ReportQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.report.ReportDimensionEnum;
import com.taobao.ad.brand.bp.client.enums.report.ReportFunctionEnum;
import com.taobao.ad.brand.bp.client.enums.report.ReportTaskStatusEnum;
import com.taobao.ad.brand.bp.common.spi.ExtensionPointsFactory;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.oss.OssRepository;
import com.taobao.ad.brand.bp.domain.report.ability.BizReportQueryAbility;
import com.taobao.ad.brand.bp.domain.report.ability.BizReportTaskAbility;
import com.taobao.ad.brand.bp.domain.report.repository.EasyExcelRepository;
import com.taobao.ad.brand.bp.domain.report.repository.ReportAdcRepository;
import com.taobao.ad.brand.bp.domain.report.repository.ReportBrandRepository;
import com.taobao.ad.brand.bp.domain.report.repository.ReportSyncTaskRepository;
import com.taobao.ad.brand.bp.domain.report.spi.export.BizReportExportSpi;
import com.taobao.ad.brand.bp.domain.report.spi.report.query.BizReportQuerySpi;
import com.taobao.eagleeye.EagleEye;
import com.taobao.unifiedsession.core.json.JSON;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import static com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleProductLineEnum.PURCHASE_APPEAR;

/**
 * 报表查询相关服务
 * @author yuncheng.lyc
 */
@HSFProvider(serviceInterface = BizReportQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizReportQueryServiceImpl implements BizReportQueryService {
    private final BizReportQueryAbility bizReportQueryAbility;
    private final ReportAdcRepository reportAdcRepository;
    private final ReportSyncTaskRepository reportSyncTaskRepository;
    private final EasyExcelRepository easyExcelRepository;
    private final OssRepository ossRepository;
    private final ReportBrandRepository reportBrandRepository;
    private final BizReportTaskAbility bizReportTaskAbility;
    private final CampaignGroupRepository campaignGroupRepository;

    @Override
    public MultiResponse<Map<String, Object>> queryReport(ServiceContext context, Map<String, Object> queryMap) {
        List<Map<String, Object>> dataList = bizReportQueryAbility.findDataList(context, queryMap);
        if(CollectionUtils.isEmpty(dataList)){
            return MultiResponse.of(Lists.newArrayList(), 0);
        }
        return MultiResponse.of(dataList, dataList.size());
    }

    @Override
    public ReportMultiResponse<Map<String, Object>> queryReport(ServiceContext context, ReportQueryViewDTO queryViewDTO) {
        //参数验证
        ExtensionPointsFactory.runAbilitySpi(BizReportQuerySpi.class, extension->extension.validateParams(context, queryViewDTO), queryViewDTO.getFunctionCode());
        //获取ADC配置的指标信息
        List<ReportMetricsConfigViewDTO> metricsList = reportAdcRepository.findMetricsConfig(context, queryViewDTO);
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(metricsList), "报表未获取到对应ADC的配置指标信息");
        //参数预处理
        ExtensionPointsFactory.runAbilitySpi(BizReportQuerySpi.class, extension->extension.initParams(context, queryViewDTO), queryViewDTO.getFunctionCode());
        //获取数据总条数
        int totalCount = ExtensionPointsFactory.runAbilitySpi(BizReportQuerySpi.class, extension->extension.findDataTotalCount(context, queryViewDTO, metricsList), queryViewDTO.getFunctionCode());
        if(totalCount == 0){
            return ReportMultiResponse.of(Lists.newArrayList(), 0, metricsList);
        }
        //获取数据
        List<Map<String, Object>> originalDataList = ExtensionPointsFactory.runAbilitySpi(BizReportQuerySpi.class, extension->extension.findDataList(context, queryViewDTO, metricsList), queryViewDTO.getFunctionCode());
        //数据清洗&加工&处理
        List<Map<String, Object>> processedDataList = ExtensionPointsFactory.runAbilitySpi(BizReportQuerySpi.class, extension->extension.processDataList(context, queryViewDTO, originalDataList, metricsList), queryViewDTO.getFunctionCode());
        //数据指标权限过滤
        List<Map<String, Object>> finalDataList = bizReportQueryAbility.metricsPermissionFilter(context, processedDataList, metricsList);
        //完成，返回数据
        return ReportMultiResponse.of(finalDataList, totalCount, metricsList);
    }

    @Override
    public SingleResponse<Long> asyncExportReport(ServiceContext context, ReportQueryViewDTO queryViewDTO) {
        ReportTaskViewDTO taskViewDTO = buildReportTaskViewDTO(context, queryViewDTO);
        Long taskId = reportSyncTaskRepository.add(context, taskViewDTO);
        taskViewDTO.setTaskId(taskId);
        //默认是待运行状态，该功能默认运行中，更新为运行中
        taskViewDTO.setStatus(ReportTaskStatusEnum.RUNNING.getValue());
        reportSyncTaskRepository.modifyStatus(context, taskViewDTO);
        BatchInvoker.Context batchInvokerContext = BatchInvoker.fetch();

        CompletableFuture.runAsync(() -> {
            BatchInvoker.run(batchInvokerContext, () -> {
                try {
                    queryViewDTO.setMultiThreadMode(false);
                    SingleResponse<String> exportResponse = exportReport(context, queryViewDTO);
                    AssertUtil.assertTrue(exportResponse.isSuccess(), exportResponse.getErrorMsg());
                    taskViewDTO.setStatus(ReportTaskStatusEnum.SUCCEED.getValue());
                    taskViewDTO.setOssUrl(exportResponse.getResult());
                    taskViewDTO.setTraceId(EagleEye.getTraceId());
                    reportSyncTaskRepository.runSucceed(context, taskViewDTO);
                }catch (Exception e) {
                    taskViewDTO.setErrorMsg(e.getMessage());
                    taskViewDTO.setTraceId(EagleEye.getTraceId());
                    reportSyncTaskRepository.runFail(context, taskViewDTO);
                    RogerLogger.error("异步任务运行失败，", e);
                }
            });
        });
        return SingleResponse.of(taskId);
    }

    private ReportTaskViewDTO buildReportTaskViewDTO(ServiceContext context, ReportQueryViewDTO queryViewDTO){
        ReportTaskViewDTO taskViewDTO = new ReportTaskViewDTO();
        taskViewDTO.setFunctionCode(ReportFunctionEnum.FUNCTION_MULTI_COMMON.getCode());
        taskViewDTO.setBizCode(queryViewDTO.getBizCode());
        taskViewDTO.setFileViewDTO(queryViewDTO.getFileViewDTO());
        if(MapUtils.isEmpty(taskViewDTO.getTaskParams())){
            taskViewDTO.setTaskParams(Maps.newHashMap());
        }
        taskViewDTO.getTaskParams().putAll(queryViewDTO.getConditions());
        taskViewDTO.setMemberId(queryViewDTO.getMemberId());
        if(Objects.isNull(queryViewDTO.getMemberId())){
            taskViewDTO.setMemberId(context.getMemberId());
        }

        taskViewDTO.setTaskName(queryViewDTO.getFileViewDTO().getFileName());
        taskViewDTO.setDimensionCodes(queryViewDTO.getDimensionCodes());
        taskViewDTO.setCreateBy(context.getOperName());
        taskViewDTO.setLastModifyBy(context.getOperName());
        taskViewDTO.setGmtModified(new Date());
        taskViewDTO.setErrorMsg("");
        taskViewDTO.setStatus(ReportTaskStatusEnum.WAITING.getValue());
        return taskViewDTO;
    }

    @Override
    public SingleResponse<String> exportReport(ServiceContext context, ReportQueryViewDTO queryViewDTO) {
        //参数验证
        ExtensionPointsFactory.runAbilitySpi(BizReportExportSpi.class, extension -> extension.validateParams(context, queryViewDTO), queryViewDTO.getFunctionCode());
        //参数预处理
        ExtensionPointsFactory.runAbilitySpi(BizReportExportSpi.class, extension -> extension.initParams(context, queryViewDTO), queryViewDTO.getFunctionCode());
        //获取ADC配置的维度&指标信息
        Map<String, ReportDimensionConfigViewDTO> dimensionMap = reportAdcRepository.findDimensionConfigMap(context, queryViewDTO);
        AssertUtil.assertTrue(MapUtils.isNotEmpty(dimensionMap), "报表未获取到对应ADC的配置信息");
        Map<String, List<ReportMetricsConfigViewDTO>> metricsMap = reportAdcRepository.findMetricsConfigMap(context, queryViewDTO);
        AssertUtil.assertTrue(MapUtils.isNotEmpty(metricsMap), "报表未获取到对应ADC的配置信息");
        //生成excel文件名称
        String fileName = ExtensionPointsFactory.runAbilitySpi(BizReportExportSpi.class, extension->extension.processFileName(context, queryViewDTO), queryViewDTO.getFunctionCode());
        //构造sheet名称
        Map<String, String> sheetNameMap = ExtensionPointsFactory.runAbilitySpi(BizReportExportSpi.class, extension->extension.processSheetName(context, queryViewDTO, dimensionMap), queryViewDTO.getFunctionCode());
        //构造目录信息
        List<ExcelCatalogueViewDTO> homePageList = ExtensionPointsFactory.runAbilitySpi(BizReportExportSpi.class, extension->extension.processCatalog(context, queryViewDTO, dimensionMap, metricsMap), queryViewDTO.getFunctionCode());
        //构造sheet表头信息
        Map<String, Map<String, String>> fieldMap = ExtensionPointsFactory.runAbilitySpi(BizReportExportSpi.class, extension->extension.processSheetFieldMap(context, queryViewDTO, metricsMap), queryViewDTO.getFunctionCode());
        //查询数据(默认多线程)
        Map<String, List<Map<String, Object>>> dataMap = ExtensionPointsFactory.runAbilitySpi(BizReportExportSpi.class, extension->extension.findDataListMap(context, queryViewDTO, metricsMap), queryViewDTO.getFunctionCode());
        //生成excel文件流
        ExcelOutputViewDTO outputViewDTO = easyExcelRepository.listToExcel(fileName, sheetNameMap, homePageList, fieldMap, dataMap);
        //上传
        ossRepository.upload(outputViewDTO.getFileName(), outputViewDTO.getOutputStream().toByteArray());
        String ossUrl = ossRepository.getTemporaryDownloadUrl(outputViewDTO.getFileName(), OssRepository.EXPIRE_TIME_THREE_MONTH);
        AssertUtil.assertTrue(StringUtils.isNotEmpty(ossUrl), "数据生成文件地址不能为空");
        return SingleResponse.of(ossUrl);
    }

    @Override
    public MultiResponse<ReportDimensionConfigViewDTO> dimensionList(ServiceContext context, ReportQueryViewDTO queryViewDTO) {
        AssertUtil.assertTrue(StringUtils.isNotBlank(queryViewDTO.getBizCode()), "bizCode不能为空");
        Map<String, ReportDimensionConfigViewDTO> dimensionMap = reportAdcRepository.findDimensionConfigMap(context, queryViewDTO);
        AssertUtil.assertTrue(MapUtils.isNotEmpty(dimensionMap), "报表未获取到对应ADC的配置信息");
        List<ReportDimensionConfigViewDTO> dimensionConfigList = new ArrayList<>(dimensionMap.values());
        return MultiResponse.of(dimensionConfigList);
    }

//    @Override
//    public MultiResponse<CommonViewDTO> attributionBrandList(ServiceContext context, ReportAttributionBrandQueryViewDTO queryViewDTO) {
//        Set<Long> contractIds = Sets.newHashSet();
//        if(Objects.nonNull(queryViewDTO.getCampaignGroupId())){
//            CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(context, queryViewDTO.getCampaignGroupId());
//            contractIds.add(campaignGroupViewDTO.getContractViewDTO().getContractId());
//        }else{
//            CampaignGroupQueryViewDTO query = new CampaignGroupQueryViewDTO();
//            query.setStartTime(queryViewDTO.getStartDate());
//            query.setEndTime(queryViewDTO.getEndDate());
//            List<CampaignGroupViewDTO> campaignGroupList = campaignGroupRepository.findCampaignGroupList(context, query);
//            if(CollectionUtils.isNotEmpty(campaignGroupList)){
//                contractIds.addAll(campaignGroupList.stream().filter(m->Objects.nonNull(m.getContractViewDTO().getContractId())).map(m->m.getContractViewDTO().getContractId()).distinct().collect(Collectors.toList()));
//            }
//        }
//        List<CommonViewDTO> brandList = Lists.newArrayList();
//        List<SalesContractBrandViewDTO> contractBrandList = salesContractRepository.getContractBrandList(Lists.newArrayList(contractIds));
//        for(SalesContractBrandViewDTO contractBrand: contractBrandList){
//            CommonViewDTO commonViewDTO = new CommonViewDTO();
//            commonViewDTO.setId(contractBrand.getBrandId());
//            commonViewDTO.setName(contractBrand.getBrandName());
//            brandList.add(commonViewDTO);
//        }
//        return MultiResponse.of(brandList, brandList.size());
//    }

    @Override
    public MultiResponse<CommonViewDTO> attributionBrandList(ServiceContext context, ReportAttributionBrandQueryViewDTO queryViewDTO) {
        ReportAttributionBrandQueryViewDTO brandQueryViewDTO = new ReportAttributionBrandQueryViewDTO();
        brandQueryViewDTO.setCampaignGroupId(queryViewDTO.getCampaignGroupId());
        brandQueryViewDTO.setMemberId(context.getMemberId());
        List<ReportCampaignGroupBrandViewDTO> brandViewDTOS = reportBrandRepository.getContractBrandList(context, brandQueryViewDTO);

//        if(Objects.nonNull(queryViewDTO.getCampaignGroupId())){
//            ReportAttributionBrandQueryViewDTO brandQueryViewDTO = new ReportAttributionBrandQueryViewDTO();
//            brandQueryViewDTO.setCampaignGroupId(queryViewDTO.getCampaignGroupId());
//            brandViewDTOS = reportBrandRepository.getContractBrandList(context, brandQueryViewDTO);
//        }else{
//            CampaignGroupQueryViewDTO query = new CampaignGroupQueryViewDTO();
//            query.setStartTime(queryViewDTO.getStartDate());
//            query.setEndTime(queryViewDTO.getEndDate());
//            query.setNoInStatusList(Lists.newArrayList(BrandCampaignGroupStatusEnum.DELETED.getCode(),BrandCampaignGroupStatusEnum.CANCELED.getCode(),BrandCampaignGroupStatusEnum.EDITED.getCode()));
//            if(BizCodeEnum.BRANDONEBP.getBizCode().equals(context.getBizCode())) {
//                query.setSceneIds(Lists.newArrayList(SaleGroupBusinessLineEnum.BRAND_AD.getValue(), SaleGroupBusinessLineEnum.TAO_BRAND_AD.getValue(), SaleGroupBusinessLineEnum.CONTENT_AD.getValue()));
//            }
//            List<CampaignGroupViewDTO> campaignGroupList = campaignGroupRepository.findCampaignGroupList(context, query);
//            if(CollectionUtils.isNotEmpty(campaignGroupList)){
//                ReportAttributionBrandQueryViewDTO brandQueryViewDTO = new ReportAttributionBrandQueryViewDTO();
//                brandQueryViewDTO.setCampaignGroupIds(campaignGroupList.stream().map(m->m.getId()).distinct().collect(Collectors.toList()));
//                brandViewDTOS = reportBrandRepository.getContractBrandList(context, brandQueryViewDTO);
//            }
//        }
        List<Long> brandIds = Lists.newArrayList();
        List<CommonViewDTO> commonViewDTOList =Lists.newArrayList();
        brandViewDTOS.forEach(m->{
            if(brandIds.contains(m.getBrandId())){
                return;
            }
            commonViewDTOList.add(new CommonViewDTO(m.getBrandId(), m.getBrandName()));
            brandIds.add(m.getBrandId());
        });
        return MultiResponse.of(commonViewDTOList, commonViewDTOList.size());
    }

    @Override
    public MultiResponse<ReportCampaignGroupBrandViewDTO> getCampaignGroupBrandList(ServiceContext context, ReportAttributionBrandQueryViewDTO queryViewDTO) {
        List<ReportCampaignGroupBrandViewDTO> campaignGroupBrandViewDTOS = reportBrandRepository.getContractBrandList(context, queryViewDTO);
        return MultiResponse.of(campaignGroupBrandViewDTOS, campaignGroupBrandViewDTOS.size());
    }

}