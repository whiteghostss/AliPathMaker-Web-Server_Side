package com.taobao.ad.brand.bp.app.service.adc;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.app.workflow.account.permission.BizPermissionWorkflow;
import com.taobao.ad.brand.bp.client.api.adc.BizAdcQueryService;
import com.taobao.ad.brand.bp.client.dto.adc.AdcCdnViewDTO;
import com.taobao.ad.brand.bp.client.dto.adc.AdcComponentViewDTO;
import com.taobao.ad.brand.bp.client.dto.adc.query.AdcQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.adc.query.AdcRoleQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.adc.query.BasicVisibleComponentQueryViewDTO;
import com.taobao.ad.brand.bp.common.constant.AdcRoleConstant;
import com.taobao.ad.brand.bp.common.util.URLUtil;
import com.taobao.ad.brand.bp.domain.adc.repository.AdcRepository;
import com.taobao.ad.brand.bp.domain.memeber.MemberRepository;
import com.taobao.ad.brand.bp.domain.sdk.account.atomability.IAccountAdcRoleGetAbility;
import com.taobao.ad.brand.bp.domain.sdk.account.atomability.IAccountJoinBizCodeGetAbility;
import com.taobao.ad.brand.bp.domain.sdk.account.atomability.param.AccountAdcRoleGetAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.account.atomability.param.AccountJoinBizCodeGetAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * ADC相关服务
 *
 * @author yuncheng.lyc
 * @date 2023/3/8
 **/
@HSFProvider(serviceInterface = BizAdcQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizAdcQueryServiceImpl implements BizAdcQueryService {
    private final AdcRepository adcRepository;
    private final MemberRepository memberRepository;
    private final BizPermissionWorkflow bizPermissionWorkflow;
    private final IAccountAdcRoleGetAbility accountAdcRoleGetAbility;
    private final IAccountJoinBizCodeGetAbility accountJoinBizCodeGetAbility;

    @Override
    public MultiResponse<AdcComponentViewDTO> findMenuList(ServiceContext context, AdcQueryViewDTO queryViewDTO) {
        return MultiResponse.of(adcRepository.findMenuList(context, queryViewDTO));
    }

    @Override
    public MultiResponse<AdcComponentViewDTO> findComponentList(ServiceContext context, AdcQueryViewDTO queryViewDTO) {
        return MultiResponse.of(adcRepository.findComponentList(context, queryViewDTO));
    }

    @Override
    public MultiResponse<AdcCdnViewDTO> findOneSiteCdnList(ServiceContext context) {
        List<AdcCdnViewDTO> adcCdnViewDTOList= adcRepository.findOneSiteCdnList(context);
        return MultiResponse.of(adcCdnViewDTOList);
    }
    @Override
    public MultiResponse<AdcCdnViewDTO> findOneSiteCdnListByUrl(ServiceContext context,String domain) {
        String domainName = URLUtil.getTopDomainName(domain);
        List<AdcCdnViewDTO> adcCdnViewDTOList= adcRepository.findOneSiteCdnListByUrl(context,domainName);
        return MultiResponse.of(adcCdnViewDTOList);
    }

    @Override
    public MultiResponse<String> findBoundAdcRole(ServiceContext context, AdcRoleQueryViewDTO queryViewDTO) {
        BasicVisibleComponentQueryViewDTO basicVisibleComponentQueryViewDTO = BasicVisibleComponentQueryViewDTO.builder()
            .memberType(queryViewDTO.getMemberType())
            .memberId(queryViewDTO.getMemberId())
            .joinScenceCodeList(queryViewDTO.getJoinScenceCodeList())
            .build();
        //准入场景为空，则根据memberid查询已准入场景
        if(CollectionUtils.isEmpty(queryViewDTO.getJoinScenceCodeList())){
            List<String> joinScenceCodeList = accountJoinBizCodeGetAbility.handle(context,
                    AccountJoinBizCodeGetAbilityParam.builder().abilityTarget(queryViewDTO.getMemberId()).build());
            basicVisibleComponentQueryViewDTO.setJoinScenceCodeList(joinScenceCodeList);
        }
        Set<String> ownedAdcRoleSet = accountAdcRoleGetAbility.handle(context, AccountAdcRoleGetAbilityParam.builder()
                .abilityTarget(basicVisibleComponentQueryViewDTO).build());
        return MultiResponse.of(Lists.newArrayList(ownedAdcRoleSet));
    }

    @Override
    public MultiResponse<AdcComponentViewDTO> findBasicVisibleComponentList(ServiceContext context, BasicVisibleComponentQueryViewDTO queryViewDTO) {
        if(queryViewDTO == null){
            queryViewDTO = new BasicVisibleComponentQueryViewDTO();
        }
        //查询memberid转入场景，memberid不传则全部场景准入
        List<String> joinBizCodeList = accountJoinBizCodeGetAbility.handle(context,
                AccountJoinBizCodeGetAbilityParam.builder().abilityTarget(queryViewDTO.getMemberId()).build());
        queryViewDTO.setJoinScenceCodeList(joinBizCodeList);
        List<AdcComponentViewDTO> result = bizPermissionWorkflow.getBasicVisibleComponentList(context, queryViewDTO);
        if(CollectionUtils.isEmpty(result)){
            return MultiResponse.empty();
        }
        //去除根节点
        return MultiResponse.of(result.get(0).getSubComponentList());
    }

    @Override
    public SingleResponse<Boolean> queryIsTopShowWhiteCustomer(ServiceContext context) {
        // 查询拥有的白名单权限角色
        boolean isTopShowWhiteCustomer = false;
        if (context.getMemberId() != null) {
            Set<String> uicRoleCodeSet = memberRepository.findRoleCodeByMemberId(context.getMemberId());
            RogerLogger.info("queryIsWhiteCustomer uicRoleCodeSet={}", JSONObject.toJSONString(uicRoleCodeSet));
            isTopShowWhiteCustomer = Optional.ofNullable(uicRoleCodeSet).orElse(Sets.newHashSet()).stream()
                    .anyMatch(AdcRoleConstant.TOPSHOW_CREATE_CREATIVE_WHITE_CODE::equals);
        }
        return SingleResponse.of(isTopShowWhiteCustomer);
    }
}