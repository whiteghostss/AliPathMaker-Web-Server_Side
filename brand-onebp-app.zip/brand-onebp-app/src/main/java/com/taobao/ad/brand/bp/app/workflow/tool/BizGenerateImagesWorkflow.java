package com.taobao.ad.brand.bp.app.workflow.tool;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.biz.definition.constants.Product;
import com.alibaba.ad.nb.ssp.constant.template.ElementTypeEnum;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alibaba.aladdin.lamp.domain.response.GeneralItem;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeGenerateViewDTO;
import com.taobao.ad.brand.bp.client.dto.mr.FileSizeViewDTO;
import com.taobao.ad.brand.bp.client.dto.template.TemplateContextViewDTO;
import com.taobao.ad.brand.bp.common.constant.TemplateConstant;
import com.taobao.ad.brand.bp.common.threadpooltask.CreativeImageGenerateTaskIdentifier;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.aigc.GenerateImagesRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.workflow.Workflow;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.ITEM_SUPPORTED_SMART_ERROR;
import static com.taobao.ad.brand.bp.common.constant.GenerateImageConstant.*;

@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizGenerateImagesWorkflow extends Workflow {

    private final GenerateImagesRepository generateImagesRepository;
    private final CreativeImageGenerateTaskIdentifier creativeImageGenerateTaskIdentifier;
    private final static String ITEM_ID = "item_id";
    /**
     * 执行批量导入
     *
     * @param serviceContext
     * @param creativeGenerateViewDTO
     */
    public void executeGenerate(ServiceContext serviceContext, CreativeGenerateViewDTO creativeGenerateViewDTO, TemplateContextViewDTO templateContextViewDTO) {
        List<FileSizeViewDTO> sizeViewDTOS = templateContextViewDTO.getColumnMap().entrySet().stream().filter(entry -> {
            Map<String, Object> valueMap = entry.getValue();
            String typeStr = (String) valueMap.get(TemplateConstant.CONSTANT_KEY_TYPE);
            return ElementTypeEnum.VISUAL_IMAGE_EXTEND.getCode().equals(typeStr);
        }).map(entry -> {
            Map<String, Object> valueMap = entry.getValue();
            Map<String, Object> visualMainMap = (Map<String, Object>) valueMap.get(TemplateConstant.MAIN_IMAGE);
            FileSizeViewDTO sizeViewDTO = new FileSizeViewDTO();
            sizeViewDTO.setWidth((Integer) visualMainMap.get(TemplateConstant.CONSTANT_KEY_WIDTH));
            sizeViewDTO.setHeight((Integer) visualMainMap.get(TemplateConstant.CONSTANT_KEY_HEIGHT));
            return sizeViewDTO;
        }).collect(Collectors.toList());
        GeneralItem generalItem = generateImagesRepository.getItem(creativeGenerateViewDTO.getItemId());
        AssertUtil.notNull(generalItem, ITEM_SUPPORTED_SMART_ERROR,"商品信息不允许为空");

        Object result = generateImagesRepository.getMagicTemplate(creativeGenerateViewDTO.getItemId(), sizeViewDTOS.get(0).getWidth(), sizeViewDTOS.get(0).getHeight());
        AssertUtil.notNull(result, ITEM_SUPPORTED_SMART_ERROR,"模板信息不允许为空");
        List<HashMap<String, String>> params = new ArrayList<>();
        JSONArray templateArray = JSON.parseArray(JSON.toJSONString(result));
        List<JSONObject> templateList = templateArray.stream().map(obj -> (JSONObject) obj).filter(templateJsonObject -> {
            Map<String, Object> tempMap = templateJsonObject.getInnerMap();
            return Objects.nonNull(tempMap.get(ID)) && Objects.nonNull(tempMap.get(SILL_YVG_TEMPLATE_ID));
        }).collect(Collectors.toList());
        AssertUtil.notEmpty(templateList, ITEM_SUPPORTED_SMART_ERROR,"模板信息不允许为空");

        for (int i = 0; i < creativeGenerateViewDTO.getCount(); i++) {
            // 使用Random类生成一个介于0到列表大小减1之间的随机索引
            Random random = new Random();
            int randomIndex = random.nextInt(templateList.size());
            // 通过随机索引从列表中获取元素
            JSONObject templateJsonObject = templateList.get(randomIndex);
            // 将JSONObject转换为Map<String, String>
            Map<String, Object> tempMap = templateJsonObject.getInnerMap();
            params.add(buildParam(generalItem, tempMap.get(ID).toString(), tempMap.get(SILL_YVG_TEMPLATE_ID).toString()));
        }

        List<String> picByItemIds = TaskStream.execute(creativeImageGenerateTaskIdentifier, params, (param, index) ->
                generateImagesRepository.creativeImage(param)).commit().getResultList().stream().flatMap(image -> image.stream()).collect(Collectors.toList());
        creativeGenerateViewDTO.setImages(picByItemIds);

    }

    private HashMap<String, String> buildParam(GeneralItem generalItem, String id, String sillyvgTemplateId) {
        HashMap<String, String> params = new HashMap<>();

        Object transparent = generalItem.get(ITEM_KEY_PRE + SC_ITEM_IMG);
        AssertUtil.notNull(transparent, ITEM_SUPPORTED_SMART_ERROR, "商品主图信息不存在");

        Object logo = generalItem.get(ITEM_KEY_PRE + SC_ITEM_IMG_BRAND_LOGO);
        Object distinctId = generalItem.get(DISTINCT_ID);

        params.put(SCENE_ID, SCENE_ID_NUM);
        params.put(PRODUCT_ID, Product.BRAND_ONEBP_BRAND.getId().toString());
        params.put(ENTITY_TYPE, ITEM_ID);
        params.put(ENTITY_ID, distinctId.toString());

        JSONObject images = new JSONObject();
        images.put(AI_ITEM_IMAGE_KEY, "https:" + transparent);
        if (Objects.nonNull(logo)) {
            images.put(AI_ITEM_LOGO_KEY, "https:" + logo);
        }
        params.put(IMAGES, images.toJSONString());

        JSONObject text = new JSONObject();
        String title = getTitle(generalItem);
        if (StringUtils.isNotBlank(title)) {
            text.put(AI_ITEM_TITLE_KEY, Lists.newArrayList(title));
        }
        String point = getPoint(generalItem);
        if (StringUtils.isNotBlank(point)) {
            text.put(AI_ITEM_SELL_POINT_KEY, Lists.newArrayList(point));
        }
        params.put(TEXT, text.toJSONString());

        JSONObject extra = new JSONObject();
        extra.put(CHANNEL, CHANNEL_ID);
        extra.put(TEMPLATE_ID_LIST, Lists.newArrayList(Integer.valueOf(sillyvgTemplateId)));
        extra.put(MAIGC_TEMPLATE_ID_LIST, new HashMap<String, String>() {{
            put(id, sillyvgTemplateId);
        }});
        params.put(EXTRA_INFO, extra.toJSONString());
        return params;
    }

    private String getTitle(GeneralItem generalItem) {
        Object title8 = generalItem.get(ITEM_KEY_PRE + "itemTitle8");
        Object title10 = generalItem.get(ITEM_KEY_PRE + "sc_item_title_10");
        List<String> titles = new ArrayList<>();
        titles.add(AI_GENERATE);
        if (Objects.nonNull(title8)) {
            titles.add(title8.toString());
        }
        if (Objects.nonNull(title10)) {
            titles.add(title10.toString());
        }
        Random random = new Random();
        int randomIndex = random.nextInt(titles.size());

        return AI_GENERATE.equals(titles.get(randomIndex)) ? null : titles.get(randomIndex);
    }

    private String getPoint(GeneralItem generalItem) {
        Object point1 = generalItem.get(ITEM_KEY_PRE + "sellPoint1");
        Object point2 = generalItem.get(ITEM_KEY_PRE + "sellPoint2");
        List<String> points = new ArrayList<>();
        points.add(AI_GENERATE);
        if (Objects.nonNull(point1)) {
            points.add(point1.toString());
        }
        if (Objects.nonNull(point2)) {
            points.add(point2.toString());
        }
        Random random = new Random();
        int randomIndex = random.nextInt(points.size());

        return AI_GENERATE.equals(points.get(randomIndex)) ? null : points.get(randomIndex);
    }
}
