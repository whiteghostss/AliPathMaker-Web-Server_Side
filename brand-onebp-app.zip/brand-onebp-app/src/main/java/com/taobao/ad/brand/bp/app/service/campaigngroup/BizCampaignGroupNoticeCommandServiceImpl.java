package com.taobao.ad.brand.bp.app.service.campaigngroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.order.CampaignGroupOrderViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.salegroup.CampaignGroupSaleGroupViewDTO;
import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignOnlineStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.setting.BrandCampaignSettingKeyEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupCancelModeEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSourceEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupTypeEnum;
import com.alibaba.ad.brand.sdk.constant.cartitem.BrandCartItemTypeEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleGroupBudgetSettingTypeEnum;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.fastjson.JSON;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.tool.lock.annotation.DistLock;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignCommandWorkflow;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignQueryWorkflow;
import com.taobao.ad.brand.bp.app.workflow.campaigngroup.BizCampaignGroupCommandWorkflow;
import com.taobao.ad.brand.bp.app.workflow.solution.BizSolutionCommandWorkflow;
import com.taobao.ad.brand.bp.client.api.campaigngroup.BizCampaignGroupNoticeCommandService;
import com.taobao.ad.brand.bp.client.context.CampaignGroupStateContext;
import com.taobao.ad.brand.bp.client.context.DomainMetaqMessageBodyContext;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupCancelCommandViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupDomainEventViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupOrderCommandViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesBriefViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.calculate.CampaignCalViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.calculate.CampaignGroupSaleGroupCalViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.calculate.ProductCampaignCalViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignGroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.settle.CampaignGroupRealSettleSaveViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourceDistributionRuleViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageNoticeTemplateViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageTemplateViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignEventEnum;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupEventEnum;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.settle.CampaignGroupRealSettleOpTypeEnum;
import com.taobao.ad.brand.bp.client.enums.message.DomainMessageSettingKeyEnum;
import com.taobao.ad.brand.bp.client.enums.message.DomainMessageTypeEnum;
import com.taobao.ad.brand.bp.client.enums.resourcepackage.ResourcePackageTemplateTypeEnum;
import com.taobao.ad.brand.bp.client.enums.resourcepackage.SaleGroupEventEnum;
import com.taobao.ad.brand.bp.client.enums.solution.CartItemSolutionOrderErrorCodeEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.cart.repository.CartItemRepository;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignAutoLockJudgeForLockCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignBindCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignAutoLockAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignBindCampaignGroupAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupCancelSendNoticeAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupContractCompleteBrandSyncForOrderAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupContractWaitPaymentSendNoticeAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupContractWaitSignSendNoticeAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupEstimateResultWarningSendNoticeAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupInquiryInfoUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupMessageAsyncSendAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupOrderSendNoticeAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupContractCompleteBrandSyncForOrderAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupInquiryInfoUpdateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupMessageAsyncSendAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupNoticeAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupInquiryInfoUpdateForNoticeSaleGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupInquiryInfoUpdateForNoticeSaleGroupAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.IMessageAsyncSendAbility;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.param.MessageAsyncSendAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.client.enums.campaigngroup.SalesBriefEventEnum.isContractEvent;
import static com.taobao.ad.brand.bp.client.enums.message.DomainMessageTypeEnum.MAIN_CAMPAIGN;
import static com.taobao.ad.brand.bp.client.enums.message.DomainMessageTypeEnum.MAIN_CAMPAIGN_GROUP;
import static com.taobao.ad.brand.bp.client.enums.message.DomainMessageTypeEnum.SUB_CAMPAIGN_GROUP;
import static com.taobao.ad.brand.bp.common.constant.Constant.CAN_INQUIRY_LOCK_STATUS;
import static com.taobao.ad.brand.bp.common.constant.campaigngroup.CampaignGroupConstant.MAIN_CAMPAIGN_GROUP_ID_KEY;
import static com.taobao.ad.brand.bp.common.util.BrandDateUtil.DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_1;

/**
 * @author yanjingang
 * @date 2023/3/12
 */
@HSFProvider(serviceInterface = BizCampaignGroupNoticeCommandService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizCampaignGroupNoticeCommandServiceImpl implements BizCampaignGroupNoticeCommandService {
    private final CampaignGroupRepository campaignGroupRepository;
    private final BizCampaignQueryWorkflow bizCampaignQueryWorkflow;
    private final ResourcePackageRepository resourcePackageRepository;
    private final BizCampaignGroupCommandWorkflow bizCampaignGroupCommandWorkflow;
    private final BizSolutionCommandWorkflow bizSolutionCommandWorkflow;
    private final BizCampaignCommandWorkflow bizCampaignCommandWorkflow;
    private final ICampaignGroupContractCompleteBrandSyncForOrderAbility campaignGroupContractCompleteBrandSyncForOrderAbility;
    private final ICampaignBindCampaignGroupAbility campaignBindCampaignGroupAbility;
    private final ISaleGroupInquiryInfoUpdateForNoticeSaleGroupAbility saleGroupInquiryInfoUpdateForNoticeSaleGroupAbility;
    private final ICampaignGroupInquiryInfoUpdateAbility campaignGroupInquiryInfoUpdateAbility;
    private final CartItemRepository cartItemRepository;
    private final ICampaignGroupMessageAsyncSendAbility campaignGroupMessageAsyncSendAbility;
    private final ICampaignStructureQueryAbility campaignStructureQueryAbility;
    private final ICampaignGroupOrderSendNoticeAbility campaignGroupOrderSendNoticeAbility;
    private final ICampaignGroupCancelSendNoticeAbility campaignGroupCancelSendNoticeAbility;
    private final ICampaignGroupContractWaitSignSendNoticeAbility campaignGroupContractWaitSignSendNoticeAbility;
    private final ICampaignGroupContractWaitPaymentSendNoticeAbility campaignGroupContractWaitPaymentSendNoticeAbility;
    private final ICampaignGroupEstimateResultWarningSendNoticeAbility campaignGroupEstimateResultWarningSendNoticeAbility;
    private final IMessageAsyncSendAbility messageAsyncSendAbility;
    private final ICampaignAutoLockJudgeForLockCampaignAbility campaignAutoLockJudgeForLockCampaignAbility;

    private static List<String> validSelfServiceCampaignDomainEventForPreOrderList = Lists.newArrayList(CampaignEventEnum.LOCK_SUCCESS.name(), CampaignEventEnum.LOCK_FAILED.name());

    @Override
    public Response noticeCampaignGroupPurchaseStatusModifyTimeUpdated(ServiceContext serviceContext, Long id) {
        CampaignGroupViewDTO campaignGroup = campaignGroupRepository.getCampaignGroup(serviceContext, id);
        if (campaignGroup == null) {
            return Response.success();
        }
        ServiceContext context = ServiceContextUtil.getNewServiceContext(serviceContext, campaignGroup.getSceneId());
        bizCampaignGroupCommandWorkflow.resourceConfirmed(context, campaignGroup);
        return Response.success();
    }

    @Override
//    @DistLock(value = "CAMPAIGN_GROUP_BRIEF_EVENT_NOTICE,1#getBriefId(),1#getEventCode()")
    public Response noticeCampaignGroupBriefStatusUpdated(ServiceContext context, SalesBriefViewDTO noticeSalesBriefViewDTO) {
        // 合同状态变更事件 or Brief状态变更事件
        if (noticeSalesBriefViewDTO.getOrderId() == null) {
            return Response.success();
        }
        // 合同状态变更时，仅处理目标合同状态；Brief状态变更时，仅处理需要的状态
        if (isContractEvent(noticeSalesBriefViewDTO.getEventCode())) {
            bizCampaignGroupCommandWorkflow.handleContractEvent(context, noticeSalesBriefViewDTO);
        } else  {
            bizCampaignGroupCommandWorkflow.handleBriefEvent(context, noticeSalesBriefViewDTO);
        }
        return Response.success();
    }
    /**
     * 分组发生变动时，资源包调用
     * */
    @Override
    @DistLock(value = "CAMPAIGN_GROUP_DOMAIN_EVENT_NOTICE,1#getDomainType(),1#getCampaignGroupId(),1#getEvent()")
    public Response noticeCampaignGroupDomainEvent(ServiceContext serviceContext, CampaignGroupDomainEventViewDTO domainEventViewDTO) {
        // 仅处理订单领域事件
        if (domainEventViewDTO.getDomainType() == null || domainEventViewDTO.getDomainType() != MAIN_CAMPAIGN_GROUP && domainEventViewDTO.getDomainType() != SUB_CAMPAIGN_GROUP) {
            return Response.success();
        }

        // 处理主订单领域事件
        if (domainEventViewDTO.getDomainType() == MAIN_CAMPAIGN_GROUP) {
            handleMainCampaignGroupDomainEvent(serviceContext, domainEventViewDTO);
        } else {
            handleSubCampaignGroupDomainEvent(serviceContext, domainEventViewDTO);
        }

        return Response.success();
    }

    @Override
    @DistLock(value = "CAMPAIGN_GROUP_CAMPAIGN_DOMAIN_EVENT_NOTICE,1#getDomainType(),1#getEntityId(),1#getDomainEvent()")
    public Response noticeCampaignDomainEvent(ServiceContext serviceContext, DomainMetaqMessageBodyContext bodyContext) {
        // 仅处理一级计划领域事件
        if (bodyContext.getDomainType() == null || bodyContext.getDomainType() != MAIN_CAMPAIGN) {
            return Response.success();
        }
        if (CampaignEventEnum.DELETE.name().equals(bodyContext.getDomainEvent())) {
            if (BizCodeEnum.SELFSERVICEAD.getBizCode().equals(bodyContext.getBizCode())
                    && MapUtils.isNotEmpty(bodyContext.getProperties())
                    && bodyContext.getProperties().containsKey(BrandCampaignSettingKeyEnum.CAMPAIGN_GROUP_ID.getKey())) {
                handleSelfServiceCampaignDomainEventForDelete(serviceContext, Long.parseLong(bodyContext.getProperties().get(BrandCampaignSettingKeyEnum.CAMPAIGN_GROUP_ID.getKey())));
            }
            return Response.success();
        }
        // 查询计划
        CampaignViewDTO campaignTreeViewDTO = bizCampaignQueryWorkflow.getCampaignInfoByOption(serviceContext, bodyContext.getEntityId(), CampaignQueryOption.builder().needChildren(true).build());
        AssertUtil.notNull(campaignTreeViewDTO, "计划不存在");
        if (BizCodeEnum.SELFSERVICEAD.getBizCode().equals(bodyContext.getBizCode())) {
            CartItemViewDTO cartItemViewDTO = cartItemRepository.getCartById(serviceContext, campaignTreeViewDTO.getCampaignSelfServiceViewDTO().getCartItemId());
            if (cartItemViewDTO == null) {
                RogerLogger.info("加购行已删除，忽略，campaignId {}, cartItemId {}", bodyContext.getEntityId(), campaignTreeViewDTO.getCampaignSelfServiceViewDTO().getCartItemId());
                return Response.success();
            }
            if (BrandCartItemTypeEnum.SLIM_ORDER.getCode().equals(cartItemViewDTO.getType())) {
                if (CampaignEventEnum.CREATE.name().equals(bodyContext.getDomainEvent())) {
                    handleSelfServiceSolutionCampaignCreateDomainEvent(serviceContext, cartItemViewDTO, campaignTreeViewDTO);
                } else if (CampaignEventEnum.LOCK_SUCCESS.name().equals(bodyContext.getDomainEvent())) {
                    handleSelfServiceSolutionCampaignLockSuccessDomainEvent(serviceContext, cartItemViewDTO, campaignTreeViewDTO);
                }
            } else { // 普通版
                // 执行预下单
                if (validSelfServiceCampaignDomainEventForPreOrderList.contains(bodyContext.getDomainEvent())) {
                    handleSelfServiceCampaignDomainEventForPreOrder(serviceContext, campaignTreeViewDTO);
                }
            }
        }

        return Response.success();
    }

    @Override
    public Response noticeSaleGroupCampaignAutoCreated(ServiceContext serviceContext, DomainMetaqMessageBodyContext bodyContext) {
        if (SaleGroupEventEnum.AUTO_CREATE_CAMPAIGN.name().equals(bodyContext.getDomainEvent())) {
            doHandleCampaignGroupAutoCreateCampaignDomainEvent(serviceContext, bodyContext);
        }
        return Response.success();
    }

    private void handleSelfServiceSolutionCampaignLockSuccessDomainEvent(ServiceContext serviceContext, CartItemViewDTO cartItemViewDTO, CampaignViewDTO campaignTreeViewDTO) {
        // 查询订单
        if (campaignTreeViewDTO.getCampaignGroupId() == null || campaignTreeViewDTO.getCampaignGroupId() == 0L) {
            return;
        }
        CampaignGroupViewDTO campaignGroup = campaignGroupRepository.getCampaignGroup(serviceContext, campaignTreeViewDTO.getCampaignGroupId());
        AssertUtil.notNull(campaignGroup, "订单不存在");
        // 重新查询计划
        CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder()
                .campaignGroupId(campaignGroup.getId())
                .onlineStatusList(Arrays.stream(BrandCampaignOnlineStatusEnum.values()).map(BrandCampaignOnlineStatusEnum::getCode).collect(Collectors.toList()))
                .campaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode()).build();
        List<CampaignViewDTO> campaignViewDTOList = campaignStructureQueryAbility.handle(serviceContext, CampaignStructureQueryAbilityParam.builder()
                .abilityTarget(campaignQueryViewDTO).queryOption(CampaignQueryOption.builder().needCampaignTree(true).build()).build());
        if (CollectionUtils.isNotEmpty(campaignViewDTOList)) {
            bizSolutionCommandWorkflow.estimateForSelfServiceSlimOrder(serviceContext, cartItemViewDTO,  campaignGroup, campaignViewDTOList);
        }
    }

    private void handleSelfServiceSolutionCampaignCreateDomainEvent(ServiceContext serviceContext, CartItemViewDTO cartItemViewDTO, CampaignViewDTO campaignViewDTO) {
        RogerLogger.info("cost time create campaignGroup cartItemId {} start : {}", cartItemViewDTO.getId(), BrandDateUtil.date2String(new Date(), DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_1));
        try {
            // 1. 创建订单
            List<CampaignGroupViewDTO> addCampaignGroupList = bizSolutionCommandWorkflow.addCampaignGroup(serviceContext, cartItemViewDTO);
            // 2. 更新订单和计划的关系
            CampaignGroupViewDTO subCampaignGroup = addCampaignGroupList.stream().filter(campaignGroup -> BrandCampaignGroupLevelEnum.LEVEL_TWO.getCode()
                    .equals(campaignGroup.getCampaignGroupLevel())).findFirst().orElse(null);
            campaignBindCampaignGroupAbility.handle(serviceContext, CampaignBindCampaignGroupAbilityParam.builder()
                    .abilityTargets(Lists.newArrayList(campaignViewDTO)).campaignGroupViewDTO(subCampaignGroup).build());
            // 3. 发送预下单事件
            CampaignGroupViewDTO mainCampaignGroup = addCampaignGroupList.stream().filter(campaignGroup -> BrandCampaignGroupLevelEnum.LEVEL_ONE.getCode()
                    .equals(campaignGroup.getCampaignGroupLevel())).findFirst().orElse(null);
            campaignGroupMessageAsyncSendAbility.handle(serviceContext, CampaignGroupMessageAsyncSendAbilityParam.builder()
                    .abilityTarget(mainCampaignGroup).domainEvent(CampaignGroupEventEnum.PRE_ORDER.name()).build());
        } catch (Exception e) {
            RogerLogger.error("订单创建失败，加购行id={}， e={}", cartItemViewDTO.getId(), e);
            if (cartItemViewDTO.getId() != null) {
                CartItemViewDTO updateCartItem = new CartItemViewDTO();
                updateCartItem.setId(cartItemViewDTO.getId());
                updateCartItem.setOrderErrorCode(CartItemSolutionOrderErrorCodeEnum.CAMPAIGN_GROUP_CREATE_ERROR.getErrorCode());
                cartItemRepository.updateCartPart(serviceContext, updateCartItem);
            }
        }
        RogerLogger.info("cost time create campaignGroup cartItemId {} end : {}", cartItemViewDTO.getId(), BrandDateUtil.date2String(new Date(), DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_1));
    }

    private void handleSelfServiceCampaignDomainEventForDelete(ServiceContext serviceContext, Long campaignGroupId) {
        // 仅处理草稿状态订单
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(serviceContext, campaignGroupId);
        if (!BrandCampaignGroupStatusEnum.EDITED.getCode().equals(campaignGroupViewDTO.getStatus())) {
            return;
        }

        // 查询订单下是否有计划，无计划时自动撤单
        CampaignQueryViewDTO query = new CampaignQueryViewDTO();
        query.setCampaignGroupId(campaignGroupId);
        query.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
        List<CampaignViewDTO> campaignViewDTOList = bizCampaignQueryWorkflow.getCampaignInfoListByOption(serviceContext, query, new CampaignQueryOption());
        if (CollectionUtils.isEmpty(campaignViewDTOList)) {
            CampaignGroupCancelCommandViewDTO cancelViewDTO = new CampaignGroupCancelCommandViewDTO();
            cancelViewDTO.setId(campaignGroupId);
            cancelViewDTO.setOperateMode(BrandCampaignGroupCancelModeEnum.MANUAL.getCode());
            bizCampaignGroupCommandWorkflow.cancelSelfServiceCampaignGroup(serviceContext, cancelViewDTO, campaignGroupViewDTO);
        }
    }

    private void handleSelfServiceCampaignDomainEventForPreOrder(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {
        // 仅关注锁量成功和锁量失败
        if (!BrandCampaignStatusEnum.LOCK_SUCCESS.getCode().equals(campaignViewDTO.getStatus())
                && !BrandCampaignStatusEnum.LOCK_FAIL.getCode().equals(campaignViewDTO.getStatus())) {
            return;
        }
        // 订单不支持自动下单则直接返回
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(serviceContext, campaignViewDTO.getCampaignGroupId());
        if (BrandBoolEnum.BRAND_FALSE.getCode().equals(campaignGroupViewDTO.getCampaignGroupOrderViewDTO().getCanAutoOrder())) {
            return;
        }
        // 计划锁量失败后不支持自动下单
        if (BrandCampaignStatusEnum.LOCK_FAIL.getCode().equals(campaignViewDTO.getStatus())) {
            if(BrandCampaignGroupSourceEnum.CART.getCode().equals(campaignGroupViewDTO.getSource())){
                campaignGroupViewDTO.getCampaignGroupOrderViewDTO().setCanAutoOrder(BrandBoolEnum.BRAND_FALSE.getCode());
//                bizCampaignGroupAbility.updateCanAutoOrderFlag(serviceContext, campaignGroupViewDTO);
                CampaignGroupViewDTO updateCampaignGroup = new CampaignGroupViewDTO();
                updateCampaignGroup.setId(campaignGroupViewDTO.getId());
                updateCampaignGroup.setCampaignGroupOrderViewDTO(new CampaignGroupOrderViewDTO());
                updateCampaignGroup.getCampaignGroupOrderViewDTO().setCanAutoOrder(campaignGroupViewDTO.getCampaignGroupOrderViewDTO().getCanAutoOrder());
                campaignGroupRepository.updateCampaignGroupPart(serviceContext, updateCampaignGroup);
            }
            return;
        }

        // 查询订单下的全部计划，全部成功时则自动下单
        CampaignQueryViewDTO query = new CampaignQueryViewDTO();
        query.setCampaignGroupId(campaignViewDTO.getCampaignGroupId());
        query.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
        List<CampaignViewDTO> campaignViewDTOList = bizCampaignQueryWorkflow.getCampaignInfoListByOption(serviceContext, query, new CampaignQueryOption());
        boolean allSuccess = campaignViewDTOList.stream().map(CampaignViewDTO::getStatus).allMatch(status -> BrandCampaignStatusEnum.LOCK_SUCCESS.getCode().equals(status));
        if (allSuccess) {
            bizCampaignGroupCommandWorkflow.preOrder(serviceContext, campaignGroupViewDTO);
        }
    }

    /**
     * 处理主订单领域事件
     * @param serviceContext
     * @param domainEventViewDTO
     */
    private void handleMainCampaignGroupDomainEvent(ServiceContext serviceContext, CampaignGroupDomainEventViewDTO domainEventViewDTO) {
        // 查询订单
        CampaignGroupViewDTO mainCampaignGroup = campaignGroupRepository.getCampaignGroup(serviceContext, domainEventViewDTO.getCampaignGroupId());
        if (mainCampaignGroup == null) {
            return;
        }
        // 子合同生成事件
        if (domainEventViewDTO.getEvent() == CampaignGroupEventEnum.SUB_CONTRACT_GENERATE) {
            bizCampaignGroupCommandWorkflow.bindCampaignGroupSubContractIds(serviceContext, mainCampaignGroup);
            return;
        }
        if (!BizCampaignGroupToolsHelper.isNeedConsumeCampaignGroupSyncDomainEvent(mainCampaignGroup, domainEventViewDTO.getEvent())) {
            return;
        }
        CampaignGroupEventEnum targetEventEnum = BizCampaignGroupToolsHelper.getTargetCampaignGroupEvent(mainCampaignGroup, domainEventViewDTO.getEvent());
        // 查询子订单
        List<CampaignGroupViewDTO> subCampaignGroupList = campaignGroupRepository.findSubCampaignGroupList(serviceContext, domainEventViewDTO.getCampaignGroupId());
        for (CampaignGroupViewDTO subCampaignGroup : subCampaignGroupList) {
            doHandleMainCampaignGroupDomainEvent(mainCampaignGroup, subCampaignGroup, targetEventEnum);
        }
    }
    private void doHandleMainCampaignGroupDomainEvent(CampaignGroupViewDTO mainCampaignGroup, CampaignGroupViewDTO subCampaignGroup, CampaignGroupEventEnum subCampaignGroupEvent) {
        ServiceContext subContext = ServiceContextUtil.buildServiceContextForSceneId(subCampaignGroup.getMemberId(), subCampaignGroup.getSceneId());
        // 迁移子订单
        bizCampaignGroupCommandWorkflow.transitCampaignGroup(subContext, subCampaignGroup, subCampaignGroupEvent, context -> {
            CampaignGroupStateContext transitContext = (CampaignGroupStateContext) context;
            transitContext.setMainCampaignGroupViewDTO(mainCampaignGroup);
            transitContext.setIgnoreNotAcceptError(true);
        });
    }

    /**
     * 处理子订单领域事件
     *
     * @param serviceContext
     * @param domainEventViewDTO
     */
    private void handleSubCampaignGroupDomainEvent(ServiceContext serviceContext, CampaignGroupDomainEventViewDTO domainEventViewDTO) {
        if (CampaignGroupEventEnum.DELETE == domainEventViewDTO.getEvent()) {
            doHandleSubCampaignGroupDeleteDomainEvent(serviceContext, domainEventViewDTO);
            return;
        } else if (CampaignGroupEventEnum.UPDATE == domainEventViewDTO.getEvent()) {
            doHandleSubCampaignGroupUpdateDomainEvent(serviceContext, domainEventViewDTO);
            return;
        } else if (CampaignGroupEventEnum.CREATE == domainEventViewDTO.getEvent()) {
            doHandleSubCampaignGroupCreateDomainEvent(serviceContext, domainEventViewDTO);
            return;
        }
        // ===================== 状态变更处理 start =====================
        // 查询子订单
        CampaignGroupViewDTO subCampaignGroup = campaignGroupRepository.getCampaignGroup(serviceContext, domainEventViewDTO.getCampaignGroupId());
        if (subCampaignGroup == null) {
            return;
        }
        if (!BizCampaignGroupToolsHelper.isNeedConsumeCampaignGroupSyncDomainEvent(subCampaignGroup, domainEventViewDTO.getEvent())) {
            return;
        }
        CampaignGroupEventEnum targetEventEnum = BizCampaignGroupToolsHelper.getTargetCampaignGroupEvent(subCampaignGroup, domainEventViewDTO.getEvent());
        // 查询主订单
        CampaignGroupViewDTO mainCampaignGroup = campaignGroupRepository.getCampaignGroup(serviceContext, subCampaignGroup.getParentId());
        AssertUtil.notNull(mainCampaignGroup, "主订单不存在");
        // 执行处理
        doHandleSubCampaignGroupDomainEventForMain(serviceContext, mainCampaignGroup, targetEventEnum);
        // ===================== 状态变更处理 end =====================
    }

    private void doHandleSubCampaignGroupUpdateDomainEvent(ServiceContext serviceContext, CampaignGroupDomainEventViewDTO domainEventViewDTO) {
        RogerLogger.info("cost time calculate campaignGroup {} start : {}",domainEventViewDTO.getCampaignGroupId(), BrandDateUtil.date2String(new Date(), DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_1));
        // 查询订单
        CampaignGroupViewDTO subCampaignGroup = campaignGroupRepository.getCampaignGroup(serviceContext, domainEventViewDTO.getCampaignGroupId());
        AssertUtil.notNull(subCampaignGroup, "订单不存在");
        if (!BrandCampaignGroupTypeEnum.SELF.getCode().equals(subCampaignGroup.getType())) {
            return;
        }
        List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupList = Lists.newArrayList();
        // 1. 计划绑定分组信息
        List<Long> saleGroupIds = Optional.ofNullable(subCampaignGroup.getCampaignGroupSaleGroupViewDTO()).map(CampaignGroupSaleGroupViewDTO::getSaleGroupInfoViewDTOList).orElse(Lists.newArrayList())
                .stream().map(SaleGroupInfoViewDTO::getSaleGroupId).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(saleGroupIds)) {
            ResourcePackageQueryViewDTO queryViewDTO = new ResourcePackageQueryViewDTO();
            queryViewDTO.setSaleGroupIdList(saleGroupIds);
            queryViewDTO.setPageSize(saleGroupIds.size());
            resourcePackageSaleGroupList = resourcePackageRepository.getSaleGroupList(serviceContext, queryViewDTO,
                    ResourcePackageQueryOption.builder().needSetting(true).needProduct(true).needInquiryPriority(false).build());
        }
        bizCampaignCommandWorkflow.afterSelfServiceOrder(serviceContext, subCampaignGroup, resourcePackageSaleGroupList);

        // 2. 设置分组计算信息
        bizCampaignGroupCommandWorkflow.setSaleGroupCalculateInfo(serviceContext, subCampaignGroup, resourcePackageSaleGroupList);

        // 3. 执行下单
        if (BrandCampaignGroupSourceEnum.CART.getCode().equals(subCampaignGroup.getSource())) {
            CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO = new CampaignGroupOrderCommandViewDTO();
            campaignGroupOrderCommandViewDTO.setId(subCampaignGroup.getId());
            campaignGroupOrderCommandViewDTO.setSaleGroupIds(subCampaignGroup.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream().map(SaleGroupInfoViewDTO::getSaleGroupId).collect(Collectors.toList()));
            bizCampaignGroupCommandWorkflow.order(serviceContext, campaignGroupOrderCommandViewDTO);
        } else {
            CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder()
                    .campaignGroupId(subCampaignGroup.getId())
                    .onlineStatusList(Arrays.stream(BrandCampaignOnlineStatusEnum.values()).map(BrandCampaignOnlineStatusEnum::getCode).collect(Collectors.toList()))
                    .campaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode()).build();
            List<CampaignViewDTO> campaignViewDTOList = campaignStructureQueryAbility.handle(serviceContext, CampaignStructureQueryAbilityParam.builder()
                    .abilityTarget(campaignQueryViewDTO).queryOption(CampaignQueryOption.builder().needCampaignTree(true).build()).build());
            if (CollectionUtils.isNotEmpty(campaignViewDTOList)) {
                CartItemViewDTO cartItemViewDTO = cartItemRepository.getCartById(serviceContext, subCampaignGroup.getSourceIds().get(0));
                bizSolutionCommandWorkflow.estimateForSelfServiceSlimOrder(serviceContext, cartItemViewDTO, subCampaignGroup, campaignViewDTOList);
            }
        }
        RogerLogger.info("cost time calculate campaignGroup {} end : {}", domainEventViewDTO.getCampaignGroupId(), BrandDateUtil.date2String(new Date(), DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_1));
     }

    private void doHandleSubCampaignGroupCreateDomainEvent(ServiceContext serviceContext, CampaignGroupDomainEventViewDTO domainEventViewDTO) {
        //查询订单
        CampaignGroupViewDTO subCampaignGroup = campaignGroupRepository.getCampaignGroup(serviceContext, domainEventViewDTO.getCampaignGroupId());
        AssertUtil.notNull(subCampaignGroup, "订单不存在");
        //触发妈妈crm结案品牌同步UMP
        campaignGroupContractCompleteBrandSyncForOrderAbility.handle(serviceContext,
                CampaignGroupContractCompleteBrandSyncForOrderAbilityParam.builder().abilityTarget(subCampaignGroup.getCampaignGroupCustomerViewDTO().getCustomerMemberId()).build());
    }

    private void doHandleCampaignGroupAutoCreateCampaignDomainEvent(ServiceContext serviceContext, DomainMetaqMessageBodyContext bodyContext) {
        AssertUtil.notNull(bodyContext.getProperties().get(BrandCampaignSettingKeyEnum.CAMPAIGN_GROUP_ID.getKey()), "自动计算流程中订单id不能为空");
        AssertUtil.notNull(bodyContext.getEntityId(), "自动计算流程中分组id不能为空");
        Long campaignGroupId = Long.parseLong(bodyContext.getProperties().get(BrandCampaignSettingKeyEnum.CAMPAIGN_GROUP_ID.getKey()));
        CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder()
                .campaignGroupId(campaignGroupId)
                .saleGroupId(bodyContext.getEntityId())
                .campaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode())
                .build();
        CampaignQueryOption queryOption = CampaignQueryOption.builder().needCampaignTree(false).needFrequency(false).needTarget(false).build();
        List<CampaignViewDTO> campaignViewDTOList = campaignStructureQueryAbility.handle(serviceContext, CampaignStructureQueryAbilityParam.builder().abilityTarget(campaignQueryViewDTO).queryOption(queryOption).build());
        ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO = resourcePackageRepository.getSaleGroupById(serviceContext, bodyContext.getEntityId(), ResourcePackageQueryOption.builder().needProduct(true).needSetting(true).build());
        Boolean allowAutoLockJudge = campaignAutoLockJudgeForLockCampaignAbility.handle(serviceContext, CampaignAutoLockAbilityParam.builder().resourcePackageSaleGroupViewDTO(resourcePackageSaleGroupViewDTO).abilityTargets(campaignViewDTOList).build());
        if (allowAutoLockJudge) {
            CampaignGroupSaleGroupCalViewDTO campaignGroupSaleGroupCalViewDTO = buildCampaignGroupSaleGroupCalViewDTO(campaignGroupId, resourcePackageSaleGroupViewDTO, campaignViewDTOList);
            bizCampaignGroupCommandWorkflow.calculate(serviceContext, campaignGroupSaleGroupCalViewDTO);
            // 分组经过预算分配和计算后，只对分组下的处于「草稿、锁量失败、询量失败、询量成功」的计划发送自动锁量消息
            for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
                if (CAN_INQUIRY_LOCK_STATUS.contains(campaignViewDTO.getStatus())) {
                    DomainMetaqMessageBodyContext msgBodyContext = DomainMetaqMessageBodyContext.builder()
                            .bizCode(serviceContext.getBizCode())
                            .domainType(DomainMessageTypeEnum.MAIN_CAMPAIGN)
                            .domainEvent(CampaignEventEnum.AUTO_BUDGET_ALLOCATION.name())
                            .entityId(campaignViewDTO.getId())
                            .memberId(serviceContext.getMemberId())
                            .build();
                    messageAsyncSendAbility.handle(serviceContext, MessageAsyncSendAbilityParam.builder().abilityTarget(msgBodyContext).build());
                }
            }
        }
    }

    private CampaignGroupSaleGroupCalViewDTO buildCampaignGroupSaleGroupCalViewDTO(Long campaignGroupId, ResourcePackageSaleGroupViewDTO saleGroupViewDTO, List<CampaignViewDTO> campaignViewDTOList) {
        CampaignGroupSaleGroupCalViewDTO campaignGroupSaleGroupCalViewDTO = new CampaignGroupSaleGroupCalViewDTO();
        Map<Long, List<CampaignViewDTO>> resourcePackageCampaignViewDTOMap = campaignViewDTOList.stream().collect(Collectors.groupingBy(it -> it.getCampaignSaleViewDTO().getResourcePackageProductId()));
        List<ProductCampaignCalViewDTO> productCampaignList = Lists.newArrayList();
        for (ResourceDistributionRuleViewDTO resourceDistributionRuleViewDTO : saleGroupViewDTO.getDistributionRuleList()) {
            if (CollectionUtils.isEmpty(resourceDistributionRuleViewDTO.getResourcePackageProductList())) {
                continue;
            }
            for (ResourcePackageProductViewDTO resourcePackageProductViewDTO : resourceDistributionRuleViewDTO.getResourcePackageProductList()) {
                ProductCampaignCalViewDTO productCampaignCalViewDTO = new ProductCampaignCalViewDTO();
                productCampaignCalViewDTO.setResourcePackageProductId(resourcePackageProductViewDTO.getId());
                List<CampaignViewDTO> campaignViewDTOS = resourcePackageCampaignViewDTOMap.get(resourcePackageProductViewDTO.getId());
                if (CollectionUtils.isEmpty(campaignViewDTOS)) {
                    continue;
                }
                List<CampaignCalViewDTO> campaignList = campaignViewDTOS.stream().map(campaignViewDTO -> {
                    CampaignCalViewDTO campaignCalViewDTO = new CampaignCalViewDTO();
                    campaignCalViewDTO.setCampaignId(campaignViewDTO.getId());
                    if (Objects.nonNull(campaignViewDTO.getCampaignBudgetViewDTO().getBudgetRatio()) && Objects.nonNull(campaignViewDTO.getCampaignBudgetViewDTO().getDiscountTotalMoney())) {
                        campaignCalViewDTO.setBudget(campaignViewDTO.getCampaignBudgetViewDTO().getDiscountTotalMoney());
                        campaignCalViewDTO.setBudgetRatio(campaignViewDTO.getCampaignBudgetViewDTO().getBudgetRatio());
                    } else {
                        campaignCalViewDTO.setBudget(0L);
                        campaignCalViewDTO.setBudgetRatio(Constant.RATIO_100_INT);
                    }
                    campaignCalViewDTO.setStartTime(campaignViewDTO.getStartTime());
                    campaignCalViewDTO.setEndTime(campaignViewDTO.getEndTime());
                    return campaignCalViewDTO;
                }).collect(Collectors.toList());
                productCampaignCalViewDTO.setCampaignList(campaignList);
                productCampaignList.add(productCampaignCalViewDTO);
            }
        }
        campaignGroupSaleGroupCalViewDTO.setProductCampaignList(productCampaignList);
        campaignGroupSaleGroupCalViewDTO.setCampaignGroupId(campaignGroupId);
        campaignGroupSaleGroupCalViewDTO.setSaleGroupId(saleGroupViewDTO.getId());
        campaignGroupSaleGroupCalViewDTO.setBudget(saleGroupViewDTO.getBudget());
        campaignGroupSaleGroupCalViewDTO.setBudgetSettingType(BrandSaleGroupBudgetSettingTypeEnum.RATIO.getCode());
        return campaignGroupSaleGroupCalViewDTO;
    }


    private void doHandleSubCampaignGroupDeleteDomainEvent(ServiceContext serviceContext, CampaignGroupDomainEventViewDTO domainEventViewDTO) {
        if (MapUtils.isEmpty(domainEventViewDTO.getProperties()) || !domainEventViewDTO.getProperties().containsKey(MAIN_CAMPAIGN_GROUP_ID_KEY)) {
            return;
        }
        Long mainCampaignGroupId = Long.parseLong(domainEventViewDTO.getProperties().get(MAIN_CAMPAIGN_GROUP_ID_KEY));
        // 查询主订单
        CampaignGroupViewDTO mainCampaignGroup = campaignGroupRepository.getCampaignGroup(serviceContext, mainCampaignGroupId);
        AssertUtil.notNull(mainCampaignGroup, "主订单不存在");
        ServiceContext mainContext = ServiceContextUtil.buildServiceContextForSceneId(serviceContext.getMemberId(), mainCampaignGroup.getSceneId());
        CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO = buildMainCampaignGroupOrderParam(mainCampaignGroup, true);
        bizCampaignGroupCommandWorkflow.order(mainContext, campaignGroupOrderCommandViewDTO);
    }

    private void doHandleSubCampaignGroupDomainEventForMain(ServiceContext serviceContext, CampaignGroupViewDTO mainCampaignGroup, CampaignGroupEventEnum mainCampaignGroupEvent) {
        if (mainCampaignGroupEvent == null) {
            return;
        }
        ServiceContext mainContext = ServiceContextUtil.buildServiceContextForSceneId(mainCampaignGroup.getMemberId(), mainCampaignGroup.getSceneId());
        if (mainCampaignGroupEvent == CampaignGroupEventEnum.ORDER || mainCampaignGroupEvent == CampaignGroupEventEnum.BOOST_OR_GIVE_ORDER) {
            boolean needTransit = mainCampaignGroupEvent == CampaignGroupEventEnum.ORDER;
            CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO = buildMainCampaignGroupOrderParam(mainCampaignGroup, needTransit);
            bizCampaignGroupCommandWorkflow.order(mainContext, campaignGroupOrderCommandViewDTO);
        } else if (mainCampaignGroupEvent == CampaignGroupEventEnum.PRE_ORDER) {
            bizCampaignGroupCommandWorkflow.preOrder(mainContext, mainCampaignGroup);
        } else if (mainCampaignGroupEvent == CampaignGroupEventEnum.MODIFY_ORDER) {
            CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO = buildMainCampaignGroupUnlockParam(mainCampaignGroup);
            bizCampaignGroupCommandWorkflow.modifyCampaignGroup(mainContext, campaignGroupOrderCommandViewDTO, mainCampaignGroup);
        } else if (mainCampaignGroupEvent == CampaignGroupEventEnum.REAL_SETTLE_CONFIG) {
            CampaignGroupRealSettleSaveViewDTO realSettleSaveViewDTO = buildMainCampaignGroupRealSettleParam(mainCampaignGroup);
            bizCampaignGroupCommandWorkflow.saveRealSettleInfo(mainContext, realSettleSaveViewDTO);
        } else if (mainCampaignGroupEvent == CampaignGroupEventEnum.FINISH) {
            bizCampaignGroupCommandWorkflow.finish(mainContext, mainCampaignGroup);
        } else if (mainCampaignGroupEvent == CampaignGroupEventEnum.FINISH_REVERT) {
            bizCampaignGroupCommandWorkflow.finishRevert(mainContext, mainCampaignGroup);
        } else {
            List<CampaignGroupViewDTO> subCampaignGroupList = campaignGroupRepository.findSubCampaignGroupList(mainContext, mainCampaignGroup.getId());
            bizCampaignGroupCommandWorkflow.transitCampaignGroup(mainContext, mainCampaignGroup, mainCampaignGroupEvent, stateContext -> {
                CampaignGroupStateContext transitContext = (CampaignGroupStateContext) stateContext;
                transitContext.setSubCampaignGroupViewDTOList(subCampaignGroupList);
                transitContext.setIgnoreNotAcceptError(true);
            });
        }
    }

    private CampaignGroupRealSettleSaveViewDTO buildMainCampaignGroupRealSettleParam(CampaignGroupViewDTO mainCampaignGroup) {
        CampaignGroupRealSettleSaveViewDTO realSettleSaveViewDTO = new CampaignGroupRealSettleSaveViewDTO();
        realSettleSaveViewDTO.setId(mainCampaignGroup.getId());
        realSettleSaveViewDTO.setRealSettleOpTypeEnum(CampaignGroupRealSettleOpTypeEnum.SYNC);
        return realSettleSaveViewDTO;
    }

    private CampaignGroupOrderCommandViewDTO buildMainCampaignGroupUnlockParam(CampaignGroupViewDTO mainCampaignGroup) {
        CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO = new CampaignGroupOrderCommandViewDTO();
        campaignGroupOrderCommandViewDTO.setId(mainCampaignGroup.getId());
        return campaignGroupOrderCommandViewDTO;
    }

    private CampaignGroupOrderCommandViewDTO buildMainCampaignGroupOrderParam(CampaignGroupViewDTO mainCampaignGroup, boolean needTransit) {
        CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO = new CampaignGroupOrderCommandViewDTO();
        campaignGroupOrderCommandViewDTO.setId(mainCampaignGroup.getId());
        campaignGroupOrderCommandViewDTO.setNeedTransit(needTransit);
        campaignGroupOrderCommandViewDTO.setIgnoreNotTransitError(true);
        return campaignGroupOrderCommandViewDTO;
    }

    @Override
    public Response noticeCustomerTemplateSaleGroupUpdated(ServiceContext serviceContext, ResourcePackageNoticeTemplateViewDTO noticeTemplateViewDTO) {
        // 仅处理客户模板的变动
        if (!ResourcePackageTemplateTypeEnum.CUSTOMER.getValue().equals(noticeTemplateViewDTO.getType()) || CollectionUtils.isEmpty(noticeTemplateViewDTO.getSaleGroupList())) {
            return Response.success();
        }
        bizCampaignGroupCommandWorkflow.handleCustomerTemplateSaleGroupNotice(serviceContext, noticeTemplateViewDTO);
        return Response.success();
    }

    @Override
    public Response noticeCampaignGroupMessageDomainEvent(ServiceContext serviceContext, CampaignGroupDomainEventViewDTO domainEventViewDTO) {
        RogerLogger.info("noticeCampaignGroupMessageDomainEvent  serviceContext {} domainEventViewDTO {}  ", JSON.toJSONString(serviceContext), JSON.toJSONString(domainEventViewDTO));
        // 仅处理订单发送消息通知领域事件
        if (domainEventViewDTO.getDomainType() == null || domainEventViewDTO.getDomainType() != SUB_CAMPAIGN_GROUP) {
            return Response.success();
        }
        if (domainEventViewDTO.getEvent() != CampaignGroupEventEnum.ORDER_NOTICE_MSG
                && domainEventViewDTO.getEvent() != CampaignGroupEventEnum.CANCEL_NOTICE_MSG
                && domainEventViewDTO.getEvent() != CampaignGroupEventEnum.WAIT_SIGN_NOTICE_MSG
                && domainEventViewDTO.getEvent() != CampaignGroupEventEnum.WAIT_PAYMENT_NOTICE_MSG
                && domainEventViewDTO.getEvent() != CampaignGroupEventEnum.SALE_GROUP_ESTIMATE
        ) {
            return Response.success();
        }
        // 查询订单
        CampaignGroupViewDTO campaignGroup = campaignGroupRepository.getCampaignGroup(serviceContext, domainEventViewDTO.getCampaignGroupId());
        AssertUtil.notNull(campaignGroup, BrandOneBPBaseErrorCode.BIZ_DATA_EMPTY_ERROR, "订单不存在");
        if (domainEventViewDTO.getEvent() == CampaignGroupEventEnum.ORDER_NOTICE_MSG) {
            List<Long> saleGroupIds = Lists.newArrayList();
            if (MapUtils.isNotEmpty(domainEventViewDTO.getProperties()) && domainEventViewDTO.getProperties().containsKey(DomainMessageSettingKeyEnum.SALE_GROUPS.getKey())) {
                String saleGroupIdsStr = domainEventViewDTO.getProperties().get(DomainMessageSettingKeyEnum.SALE_GROUPS.getKey());
                saleGroupIds = Arrays.stream(saleGroupIdsStr.split(Constant.CHAR_SPLIT_KEY_DOT)).map(Long::valueOf).collect(Collectors.toList());
            }
            campaignGroupOrderSendNoticeAbility.handle(serviceContext, CampaignGroupNoticeAbilityParam.builder().abilityTarget(campaignGroup).saleGroupIds(saleGroupIds).build());
//            bizCampaignGroupMessageAbility.orderNotice(serviceContext, campaignGroup, saleGroupIds);
        } else if (domainEventViewDTO.getEvent() == CampaignGroupEventEnum.CANCEL_NOTICE_MSG) {
//            bizCampaignGroupMessageAbility.sendAutoCancelledMessageNotice(serviceContext, campaignGroup);
            campaignGroupCancelSendNoticeAbility.handle(serviceContext, CampaignGroupNoticeAbilityParam.builder().abilityTarget(campaignGroup).build());
        } else if (domainEventViewDTO.getEvent() == CampaignGroupEventEnum.WAIT_SIGN_NOTICE_MSG && BrandCampaignGroupTypeEnum.SELF.getCode().equals(campaignGroup.getType())) {
//            bizCampaignGroupMessageAbility.sendContractWaitSignMessageNotice(serviceContext, campaignGroup);
            campaignGroupContractWaitSignSendNoticeAbility.handle(serviceContext, CampaignGroupNoticeAbilityParam.builder().abilityTarget(campaignGroup).build());
        } else if (domainEventViewDTO.getEvent() == CampaignGroupEventEnum.WAIT_PAYMENT_NOTICE_MSG && BrandCampaignGroupTypeEnum.SELF.getCode().equals(campaignGroup.getType())) {
//            bizCampaignGroupMessageAbility.sendContractWaitPaymentMessageNotice(serviceContext, campaignGroup);
            campaignGroupContractWaitPaymentSendNoticeAbility.handle(serviceContext, CampaignGroupNoticeAbilityParam.builder().abilityTarget(campaignGroup).build());
        } else if (domainEventViewDTO.getEvent() == CampaignGroupEventEnum.SALE_GROUP_ESTIMATE) {
            List<Long> saleGroupIds = Lists.newArrayList();
            if (MapUtils.isNotEmpty(domainEventViewDTO.getProperties()) && domainEventViewDTO.getProperties().containsKey(DomainMessageSettingKeyEnum.SALE_GROUPS.getKey())) {
                String saleGroupIdsStr = domainEventViewDTO.getProperties().get(DomainMessageSettingKeyEnum.SALE_GROUPS.getKey());
                saleGroupIds = Arrays.stream(saleGroupIdsStr.split(Constant.CHAR_SPLIT_KEY_DOT)).map(Long::valueOf).collect(Collectors.toList());
            }
            campaignGroupEstimateResultWarningSendNoticeAbility.handle(serviceContext, CampaignGroupNoticeAbilityParam.builder().abilityTarget(campaignGroup).saleGroupIds(saleGroupIds).build());
//            bizCampaignGroupMessageAbility.sendEstimateResultWarningMessageNotice(serviceContext, campaignGroup, saleGroupIds);
        }

        return Response.success();
    }

    @Override
    public Response noticeCustomerTemplateSaleGroupInquiryInfoUpdated(ServiceContext serviceContext, ResourcePackageNoticeTemplateViewDTO noticeTemplateViewDTO) {
        if (CollectionUtils.isEmpty(noticeTemplateViewDTO.getSaleGroupIdList())) {
            return Response.success();
        }
        List<Long> memberIds = getResourcePackageTemplateMemberIdList(serviceContext, noticeTemplateViewDTO);
        for (Long memberId : memberIds) {
            ServiceContext newServiceContext = ServiceContextUtil.buildServiceContextForBizCodeNoSession(memberId, BizCodeEnum.BRANDONEBP.getBizCode());
            CampaignGroupQueryViewDTO campaignGroupQueryViewDTO = new CampaignGroupQueryViewDTO();
            campaignGroupQueryViewDTO.setSaleGroupIds(noticeTemplateViewDTO.getSaleGroupIdList());
            List<CampaignGroupViewDTO> campaignGroupViewDTOS = campaignGroupRepository.findCampaignGroupList(newServiceContext, campaignGroupQueryViewDTO);

            for (CampaignGroupViewDTO campaignGroupViewDTO : campaignGroupViewDTOS) {
                List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList();
                if (CollectionUtils.isEmpty(saleGroupInfoViewDTOList)) {
                    continue;
                }
                ServiceContext campaignGroupServiceContext = ServiceContextUtil.buildServiceContextForSceneId(memberId, campaignGroupViewDTO.getSceneId());
                saleGroupInquiryInfoUpdateForNoticeSaleGroupAbility.handle(campaignGroupServiceContext, SaleGroupInquiryInfoUpdateForNoticeSaleGroupAbilityParam.builder()
                        .abilityTargets(saleGroupInfoViewDTOList)
                        .noticeTemplateViewDTO(noticeTemplateViewDTO)
                        .build());
                // 2. 计算订单状态
                campaignGroupInquiryInfoUpdateAbility.handle(campaignGroupServiceContext, CampaignGroupInquiryInfoUpdateAbilityParam.builder()
                        .abilityTarget(campaignGroupViewDTO.getCampaignGroupInquiryViewDTO())
                        .campaignGroupViewDTO(campaignGroupViewDTO)
                        .build());
            }

        }
        return Response.success();
    }

    /**
     * 获取资源包模板关联的客户memberId
     * @param serviceContext
     * @param noticeTemplateViewDTO
     * @return
     */
    private List<Long> getResourcePackageTemplateMemberIdList(ServiceContext serviceContext, ResourcePackageNoticeTemplateViewDTO noticeTemplateViewDTO) {
        ResourcePackageTemplateViewDTO resourcePackageTemplateViewDTO = resourcePackageRepository.getCustomerTemplateById(serviceContext, noticeTemplateViewDTO.getId());
        if (Objects.isNull(resourcePackageTemplateViewDTO)) {
            return Lists.newArrayList();
        }
        //获取售卖分组
        ResourcePackageQueryViewDTO resourcePackageQueryViewDTO = new ResourcePackageQueryViewDTO();
        resourcePackageQueryViewDTO.setSaleGroupIdList(noticeTemplateViewDTO.getSaleGroupIdList());
        resourcePackageQueryViewDTO.setTemplateId(noticeTemplateViewDTO.getId());
        List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupViewDTOList = resourcePackageRepository.getSaleGroupList(serviceContext, resourcePackageQueryViewDTO
                , ResourcePackageQueryOption.builder().needInquiryPriority(true).needProduct(false).needSetting(true).build());

        List<Long> memberIds = Optional.ofNullable(resourcePackageSaleGroupViewDTOList).orElse(Lists.newArrayList()).stream()
                .map(ResourcePackageSaleGroupViewDTO::getMemberId).filter(Objects::nonNull).distinct().collect(Collectors.toList());

        return CollectionUtils.isNotEmpty(memberIds) ? memberIds : Lists.newArrayList(resourcePackageTemplateViewDTO.getMemberId());
    }
}
