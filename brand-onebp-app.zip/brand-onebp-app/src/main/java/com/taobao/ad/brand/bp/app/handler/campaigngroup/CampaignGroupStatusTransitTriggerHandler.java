package com.taobao.ad.brand.bp.app.handler.campaigngroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.hermes.framework.ddd.event.annotation.DomainEventHandler;
import com.alibaba.hermes.framework.event.EventHandler;
import com.taobao.ad.brand.bp.app.workflow.campaigngroup.BizCampaignGroupCommandWorkflow;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupEventEnum;
import com.taobao.ad.brand.bp.domain.event.campaigngroup.CampaignGroupStatusTransitTriggerEvent;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author yanjingang
 * @date 2024/7/4
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@DomainEventHandler(topic = "campaign_group_status_transit_trigger", event = CampaignGroupStatusTransitTriggerEvent.class)
public class CampaignGroupStatusTransitTriggerHandler implements EventHandler<CampaignGroupStatusTransitTriggerEvent> {

    private final BizCampaignGroupCommandWorkflow bizCampaignGroupCommandWorkflow;

    @Override
    public Response handle(CampaignGroupStatusTransitTriggerEvent triggerEvent) {
        ServiceContext serviceContext = triggerEvent.getContext().getServiceContext();
        CampaignGroupViewDTO campaignGroupViewDTO = triggerEvent.getContext().getCampaignGroupViewDTO();
        CampaignGroupEventEnum eventEnum = triggerEvent.getContext().getEventEnum();
        bizCampaignGroupCommandWorkflow.transitCampaignGroup(serviceContext, campaignGroupViewDTO, eventEnum);
        return Response.success();
    }
}
