package com.taobao.ad.brand.bp.app.service.shopwindow;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.fastjson.JSON;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.api.shopwindow.BizBrandSpuCommandService;
import com.taobao.ad.brand.bp.client.dto.message.MessageViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandShopWindowTjmSubscribeViewDTO;
import com.taobao.ad.brand.bp.client.enums.message.MessageSendTypeEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.memeber.MemberRepository;
import com.taobao.ad.brand.bp.domain.message.MessageRepository;
import com.taobao.ad.brand.bp.domain.taojimu.TaoJiMuRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/6/26
 **/
@HSFProvider(serviceInterface = BizBrandSpuCommandService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizBrandSpuCommandServiceImpl implements BizBrandSpuCommandService {

    private final TaoJiMuRepository taoJiMuRepository;

    private final MessageRepository messageRepository;

    private final MemberRepository memberRepository;

    private final String FREE_TRAIL_SUBSCRIBE_SUBJECT = "恭喜你完成店铺破框授权，距离失效还有30天，请尽快前去配置";
    private final String FREE_TRAIL_SUBSCRIBE_CONTENT = "尊敬的客户，恭喜你完成店铺破框授权，距离授权失效还有30天，请尽快前往旺铺后台配置创意。配置方法：品牌橱窗-特惠尝鲜包-店铺破框创意特效-0元试用按钮-旺铺后台";
    private final String FREE_TRAIL_URGE_SUBJECT = "已完成店铺破框授权，距离失效还有%d天，请尽快前去配置";
    private final String FREE_TRAIL_URGE_CONTENT = "尊敬的客户，恭喜你完成店铺破框授权，请尽快前往旺铺后台配置创意。配置方法：品牌橱窗-特惠尝鲜包-店铺破框创意特效-0元试用按钮-旺铺后台-页面装修-配置页面入会引导小部件-配置动画，具体方法详见配置SOP：https://www.yuque.com/u2314598/kb/hfhh07iylbwn4uqu";
    private final String FREE_TRAIL_FINISH_SUBJECT = "店铺破框试用期已结束，若有续用需求请联系小二";
    private final String FREE_TRAIL_FINISH_CONTENT = "尊敬的客户，店铺破框试用期已结束，若有续用需求请联系小二，钉钉群：97765010088";


    @Override
    public Response freeTrailApply(ServiceContext serviceContext, BrandShopWindowTjmSubscribeViewDTO subscribeViewDTO) {
        AssertUtil.notNull(subscribeViewDTO, "subscribeViewDTO is null");
        // 调用淘积木接口执行订购
        taoJiMuRepository.subscribe(serviceContext, subscribeViewDTO);
        // 订购成功发送站内信通知
        messageRepository.sendMessage(buildMessageViewDTO(serviceContext, subscribeViewDTO));
        return Response.success();
    }

    @Override
    public Response freeTrailNotify(ServiceContext serviceContext, List<BrandShopWindowTjmSubscribeViewDTO> subscribeViewDTOList) {
        if (CollectionUtils.isEmpty(subscribeViewDTOList)) {
            return Response.success();
        }
        List<MessageViewDTO> messageViewDTOList = buildMessageViewDTOList(serviceContext, subscribeViewDTOList);
        messageViewDTOList.forEach(messageRepository::sendMessage);
        return Response.success();
    }

    private List<MessageViewDTO> buildMessageViewDTOList(ServiceContext serviceContext, List<BrandShopWindowTjmSubscribeViewDTO> subscribeViewDTOList) {
        List<MessageViewDTO> result = Lists.newArrayList();
        Date now = new Date();
        subscribeViewDTOList.stream().filter(subscribeViewDTO -> Objects.nonNull(subscribeViewDTO.getEndTime())
                        && subscribeViewDTO.getEndTime().after(now)
                        && Objects.isNull(subscribeViewDTO.getPageId()))
                .forEach(subscribeViewDTO -> {
                    try {
                        Long memberId = memberRepository.getMemberIdByTbNumId(subscribeViewDTO.getLoginMainTbNumId());
                        if (Objects.isNull(memberId)) {
                            RogerLogger.error("freeTrailSubscribeNotify.getMemberIdByTbNumId error subscribeViewDTO {}", JSON.toJSONString(subscribeViewDTO));
                            return;
                        }
                        MessageViewDTO messageViewDTO = new MessageViewDTO();
                        messageViewDTO.setMemberId(memberId);
                        messageViewDTO.setSubject(String.format(FREE_TRAIL_URGE_SUBJECT, BrandDateUtil.getNumOfDaysBetweenDate(now, subscribeViewDTO.getEndTime())));
                        messageViewDTO.setContent(FREE_TRAIL_URGE_CONTENT);
                        messageViewDTO.setSendType(Lists.newArrayList(MessageSendTypeEnum.STATION_LETTER.getValue()));
                        result.add(messageViewDTO);
                    } catch (Exception e) {
                        RogerLogger.error("freeTrailSubscribeNotify.getMemberIdByTbNumId error subscribeViewDTO {}", e, JSON.toJSONString(subscribeViewDTO));
                    }
                });
        subscribeViewDTOList.stream().filter(subscribeViewDTO -> Objects.nonNull(subscribeViewDTO.getEndTime())
                        && subscribeViewDTO.getEndTime().before(now))
                .forEach(subscribeViewDTO -> {
                    try {
                        Long memberId = memberRepository.getMemberIdByTbNumId(subscribeViewDTO.getLoginMainTbNumId());
                        MessageViewDTO messageViewDTO = new MessageViewDTO();
                        messageViewDTO.setMemberId(memberId);
                        messageViewDTO.setSubject(FREE_TRAIL_FINISH_SUBJECT);
                        messageViewDTO.setContent(FREE_TRAIL_FINISH_CONTENT);
                        messageViewDTO.setSendType(Lists.newArrayList(MessageSendTypeEnum.STATION_LETTER.getValue()));
                        result.add(messageViewDTO);
                    } catch (Exception e) {
                        RogerLogger.error("freeTrailSubscribeNotify.getMemberIdByTbNumId error subscribeViewDTO {}", e, JSON.toJSONString(subscribeViewDTO));
                    }
                });
        return result;
    }

    private MessageViewDTO buildMessageViewDTO(ServiceContext serviceContext, BrandShopWindowTjmSubscribeViewDTO subscribeViewDTO) {
        MessageViewDTO messageViewDTO = new MessageViewDTO();
        messageViewDTO.setMemberId(serviceContext.getMemberId());
        messageViewDTO.setSubject(FREE_TRAIL_SUBSCRIBE_SUBJECT);
        messageViewDTO.setContent(FREE_TRAIL_SUBSCRIBE_CONTENT);
        messageViewDTO.setSendType(Lists.newArrayList(MessageSendTypeEnum.STATION_LETTER.getValue()));
        return messageViewDTO;
    }
}
