package com.taobao.ad.brand.bp.app.workflow.campaign;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.biz.definition.constants.Product;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignInventoryAutoReleaseWarningTypeEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.alibaba.ad.nb.order.dto.common.EmpDTO;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleProductLineEnum;
import com.alibaba.fastjson.JSON;
import com.alibaba.solar.common.dto.BaseServiceContext;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.client.dto.base.DateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignDealMsgViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignInventoryAutoReleaseMsgViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignMsgNoticeViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignSaleGroupMsgNoticeViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesBriefViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SalesCustomerViewDTO;
import com.taobao.ad.brand.bp.client.dto.message.MessageViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageEmpViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageTemplateViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.enums.message.MessageSendTypeEnum;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.util.*;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CustomerRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.SalesBriefRepository;
import com.taobao.ad.brand.bp.domain.memeber.MemberRepository;
import com.taobao.ad.brand.bp.domain.message.MessageRepository;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.ssp.ProductRepository;
import com.taobao.ad.brand.bp.domain.uic.SimbaUicRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cglib.beans.BeanMap;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/05/15
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizCampaignMessageWorkflow {
    private static final String TANX_DEAL_CHANGE_SUBJECT = "【dealid变更通知】投放账号：%s   订单：%s";
    private static final String BOTTOM_DATE_CHANGE_SUBJECT = "【媒体打底变更通知】投放账号：%s   订单：%s";
    private static final String TANX_DEAL_CHANGE_VM = "vm/dealchange.vm";
    private static final String BOTTOM_DATE_CHANGE_VM = "vm/bottomdatechange.vm";

    private static final String CAMPAIGN_INVENTORY_AUTORELEASE_SUBJECT = "【品牌自动释量预警】投放账号：%s   订单：%s";
    private static final String MULTIPLE_CAMPAIGN_INVENTORY_AUTORELEASE_SUBJECT = "【品牌自动释量预警】%s 即将自动释量订单";
    private static final String SINGLE_CAMPAIGN_INVENTORY_AUTORELEASE_VM = "vm/singleCampaignGroupAutorelease.vm";
    private static final String CUSTOMER_SINGLE_CAMPAIGN_INVENTORY_AUTORELEASE_VM = "vm/customerSingleCampaignGroupAutorelease.vm";
    private static final String CAMPAIGN_INVENTORY_AUTORELEASE_VM = "vm/campaignAutorelease.vm";
    private static final String CUSTOMER_CAMPAIGN_INVENTORY_AUTORELEASE_VM = "vm/customerCampaignAutorelease.vm";
    private static final String MULTIPLE_CAMPAIGN_INVENTORY_AUTORELEASE_VM = "vm/multipleCampaignGroupAutorelease.vm";
    private static final String MULTIPLE_WARNING_EMAIL_GROUP = "shiliangtongzhi@list.alibaba-inc.com";

    private final MessageRepository messageRepository;
    private final SimbaUicRepository simbaUicRepository;
    private final ResourcePackageRepository resourcePackageRepository;
    private final MemberRepository memberRepository;
    private final ProductRepository productRepository;
    private final SalesBriefRepository salesBriefRepository;
    private final CustomerRepository customerRepository;


    public void tanxdealChangeNotice(ServiceContext context, CampaignDealMsgViewDTO campaignDealMsgViewDTO) {
        if (CollectionUtils.isEmpty(campaignDealMsgViewDTO.getTanxDealDayChangeList())) {
            return;
        }
        long changeCount = campaignDealMsgViewDTO.getTanxDealDayChangeList().stream().filter(v -> Boolean.TRUE.equals(v.isChanged())).count();
        List<String> sendTo = getSendTo(context, campaignDealMsgViewDTO);
        if (CollectionUtils.isEmpty(sendTo) || !NumberUtil.greaterThanZero(changeCount)) {
            return;
        }
        MessageViewDTO messageViewDTO = buildMessageViewDTO(context, sendTo, TANX_DEAL_CHANGE_SUBJECT,
                campaignDealMsgViewDTO, TANX_DEAL_CHANGE_VM,
                Lists.newArrayList(MessageSendTypeEnum.STATION_LETTER.getValue(), MessageSendTypeEnum.EMAIL.getValue()));
        messageRepository.sendMessage(messageViewDTO);
    }

    public void bottomDateChangeNotice(ServiceContext context, CampaignDealMsgViewDTO campaignDealMsgViewDTO) {
        List<String> sendTo = getSendTo(context, campaignDealMsgViewDTO);
        if (CollectionUtils.isEmpty(sendTo) || CollectionUtils.isEmpty(campaignDealMsgViewDTO.getBottomDays())) {
            return;
        }
        MessageViewDTO messageViewDTO = buildMessageViewDTO(context, sendTo, BOTTOM_DATE_CHANGE_SUBJECT,
                campaignDealMsgViewDTO, BOTTOM_DATE_CHANGE_VM,
                Lists.newArrayList(MessageSendTypeEnum.STATION_LETTER.getValue(), MessageSendTypeEnum.EMAIL.getValue()));
        messageRepository.sendMessage(messageViewDTO);
    }

    /**
     * 发送释量预警消息
     * @param context
     * @param inventoryAutoReleaseMsgViewDTOList
     * @return
     */
    public Void sendInventoryAutoReleaseWarningMessage(ServiceContext context, List<CampaignInventoryAutoReleaseMsgViewDTO> inventoryAutoReleaseMsgViewDTOList) {
        Map<Integer, List<CampaignInventoryAutoReleaseMsgViewDTO>> inventoryAutoReleaseGroupMap = inventoryAutoReleaseMsgViewDTOList.stream().collect(Collectors.groupingBy(CampaignInventoryAutoReleaseMsgViewDTO::getWarningType));
        // 释量预警循环发送
        List<CampaignInventoryAutoReleaseMsgViewDTO> releaseCampaignInventoryList = inventoryAutoReleaseGroupMap.getOrDefault(
                BrandCampaignInventoryAutoReleaseWarningTypeEnum.RELEASE.getCode(), Lists.newArrayList());
        for (CampaignInventoryAutoReleaseMsgViewDTO inventoryAutoReleaseMsgViewDTO : releaseCampaignInventoryList) {
            this.inventoryReleaseWarning(context, inventoryAutoReleaseMsgViewDTO);
        }
        // 单订单预警循环发送
        List<CampaignInventoryAutoReleaseMsgViewDTO> singleReleaseCampaignInventoryList = inventoryAutoReleaseGroupMap.getOrDefault(
                BrandCampaignInventoryAutoReleaseWarningTypeEnum.SINGLE.getCode(), Lists.newArrayList());
        for (CampaignInventoryAutoReleaseMsgViewDTO inventoryAutoReleaseMsgViewDTO : singleReleaseCampaignInventoryList) {
            this.singleInventoryAutoReleaseWarning(context, inventoryAutoReleaseMsgViewDTO);
        }
        // 批量订单预警一次发送
        List<CampaignInventoryAutoReleaseMsgViewDTO> multipleReleaseCampaignInventoryList = inventoryAutoReleaseGroupMap.getOrDefault(
                BrandCampaignInventoryAutoReleaseWarningTypeEnum.MULTIPLE.getCode(), Lists.newArrayList());
        this.multipleInventoryAutoReleaseWarning(context, multipleReleaseCampaignInventoryList);
        return null;
    }

    /**
     * 单订单预警
     *
     * @param context
     * @param campaignInventoryAutoReleaseMsgViewDTO
     */
    private void singleInventoryAutoReleaseWarning(ServiceContext context, CampaignInventoryAutoReleaseMsgViewDTO campaignInventoryAutoReleaseMsgViewDTO) {
        RogerLogger.info("单订单预警发送 {}", campaignInventoryAutoReleaseMsgViewDTO.getCampaignGroupViewDTO().getId());
        inventoryReleaseWarning(context, campaignInventoryAutoReleaseMsgViewDTO, SINGLE_CAMPAIGN_INVENTORY_AUTORELEASE_VM, CUSTOMER_SINGLE_CAMPAIGN_INVENTORY_AUTORELEASE_VM);
    }

    /**
     * 释量预警
     *
     * @param context
     * @param campaignInventoryAutoReleaseMsgViewDTO
     */
    private void inventoryReleaseWarning(ServiceContext context, CampaignInventoryAutoReleaseMsgViewDTO campaignInventoryAutoReleaseMsgViewDTO) {
        RogerLogger.info("释量预警发送 {}", campaignInventoryAutoReleaseMsgViewDTO.getCampaignGroupViewDTO().getId());
        inventoryReleaseWarning(context, campaignInventoryAutoReleaseMsgViewDTO, CAMPAIGN_INVENTORY_AUTORELEASE_VM, CUSTOMER_CAMPAIGN_INVENTORY_AUTORELEASE_VM);
    }

    /**
     * 批量预警
     *
     * @param context
     * @param campaignInventoryAutoReleaseMsgViewDTOList
     */
    private void multipleInventoryAutoReleaseWarning(ServiceContext context, List<CampaignInventoryAutoReleaseMsgViewDTO> campaignInventoryAutoReleaseMsgViewDTOList) {

        if(CollectionUtils.isEmpty(campaignInventoryAutoReleaseMsgViewDTOList)) {
            return;
        }
        // 批量预警的释量时间相同，取其中一个即可
        CampaignInventoryAutoReleaseMsgViewDTO campaignInventoryAutoReleaseMsgViewDTO = campaignInventoryAutoReleaseMsgViewDTOList.get(0);
        CampaignViewDTO campaignViewDTO = campaignInventoryAutoReleaseMsgViewDTO.getCampaignViewDTOList().get(0);
        Date lockExpireTime = campaignViewDTO.getCampaignInquiryLockViewDTO().getLockExpireTime();
        // 构建发送人
        List<String> sendTo = getSendTo(campaignInventoryAutoReleaseMsgViewDTOList.get(0));
        if (CollectionUtils.isEmpty(sendTo)) {
            return;
        }
        // 构建消息体
        MessageViewDTO messageViewDTO = new MessageViewDTO();

        String subject = String.format(MULTIPLE_CAMPAIGN_INVENTORY_AUTORELEASE_SUBJECT, BrandDateUtil.date2String(lockExpireTime) + " 23:30:00");
        messageViewDTO.setSubject(subject);
        messageViewDTO.setContent(buildMessageContent(context, campaignInventoryAutoReleaseMsgViewDTOList, MULTIPLE_CAMPAIGN_INVENTORY_AUTORELEASE_VM));
        messageViewDTO.setSendTo(sendTo);
        messageViewDTO.setSendType(Lists.newArrayList(MessageSendTypeEnum.EMAIL.getValue()));
        Set<Long> warningCampaignGroupIds = campaignInventoryAutoReleaseMsgViewDTOList.stream().map(autoReleaseMsgViewDTO -> autoReleaseMsgViewDTO.getCampaignGroupViewDTO().getId()).collect(Collectors.toSet());
        RogerLogger.info("批量预警发送 {}", warningCampaignGroupIds);
        // 调用邮件发送能力
        messageRepository.sendMessage(messageViewDTO);
    }

    private void inventoryReleaseWarning(ServiceContext context, CampaignInventoryAutoReleaseMsgViewDTO campaignInventoryAutoReleaseMsgViewDTO, String vm, String customerVm) {
        CampaignGroupViewDTO campaignGroupViewDTO = campaignInventoryAutoReleaseMsgViewDTO.getCampaignGroupViewDTO();
        // 构建发送人
        List<String> sendTo = getSendTo(campaignInventoryAutoReleaseMsgViewDTO);
        if (CollectionUtils.isEmpty(sendTo)) {
            return;
        }

        // 构建消息体
        MessageViewDTO messageViewDTO = new MessageViewDTO();

        String subject = String.format(CAMPAIGN_INVENTORY_AUTORELEASE_SUBJECT, memberRepository.getMemberDisplayNameById(campaignGroupViewDTO.getMemberId()),
                campaignGroupViewDTO.getName());
        messageViewDTO.setSubject(subject);
        messageViewDTO.setContent(buildMessageContent(context, campaignInventoryAutoReleaseMsgViewDTO, vm, MessageSendTypeEnum.EMAIL));
        messageViewDTO.setSendTo(sendTo);
        messageViewDTO.setSendType(Lists.newArrayList(MessageSendTypeEnum.EMAIL.getValue()));
        // 调用邮件发送能力
        messageRepository.sendMessage(messageViewDTO);

        // 站内信发送，需要区分发送内容
        messageViewDTO.setMemberId(campaignGroupViewDTO.getMemberId());
        messageViewDTO.setSendType(Lists.newArrayList(MessageSendTypeEnum.STATION_LETTER.getValue()));
        messageViewDTO.setContent(buildMessageContent(context, campaignInventoryAutoReleaseMsgViewDTO, customerVm, MessageSendTypeEnum.STATION_LETTER));
        // 调用站内信发送能力
        messageRepository.sendMessage(messageViewDTO);
    }

    /**
     * 构建自动释量消息通知接收人
     *
     * @param campaignInventoryAutoReleaseMsgViewDTO
     * @return
     */
    private List<String> getSendTo(CampaignInventoryAutoReleaseMsgViewDTO campaignInventoryAutoReleaseMsgViewDTO) {
        Set<String> emails = Sets.newHashSet();

        // 根据预警类型选定不同的消息接收人
        if (BrandCampaignInventoryAutoReleaseWarningTypeEnum.SINGLE.getCode().equals(campaignInventoryAutoReleaseMsgViewDTO.getWarningType())
                || BrandCampaignInventoryAutoReleaseWarningTypeEnum.RELEASE.getCode().equals(campaignInventoryAutoReleaseMsgViewDTO.getWarningType())) {

            // 仅单订单预警需要构建发送人
            CampaignGroupViewDTO campaignGroupViewDTO = campaignInventoryAutoReleaseMsgViewDTO.getCampaignGroupViewDTO();

            // 销售，取brief创建人
            List<String> saleEmails = Lists.newArrayList();
            Long briefId = campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getBriefId();
            SalesBriefViewDTO brief = salesBriefRepository.getBrief(briefId);

            Map<String, String> empEmails = simbaUicRepository.getEmpEmails(Lists.newArrayList(brief.getCreator()));
            saleEmails.addAll(empEmails.values());

            // GM 直接取brief的 +1+2主管，邮箱信息不会嵌套传回，并且只传一级，因此需要多次查询
            List<String> gmEmails = Lists.newArrayList();
            EmpDTO briefCreator = simbaUicRepository.getEmp(brief.getCreator());
            EmpDTO superEmp = simbaUicRepository.getEmp(briefCreator.getSuperEmp().getEmpId());
            if (Objects.nonNull(superEmp) && Objects.nonNull(superEmp.getEmail())) {
                gmEmails.add(superEmp.getEmail());
                EmpDTO superEmpPlus = simbaUicRepository.getEmp(superEmp.getSuperEmp().getEmpId());
                if (Objects.nonNull(superEmpPlus) && Objects.nonNull(superEmpPlus.getEmail())) {
                    gmEmails.add(superEmpPlus.getEmail());
                }
            }

            // 订单运营 PE
            List<String> operators = campaignGroupViewDTO.getOperators();
            List<String> operatorEmails = Lists.newArrayList();
            if (CollectionUtils.isNotEmpty(operators)) {
                Map<String, String> empEmailMap = simbaUicRepository.getEmpEmails(operators);
                operatorEmails = Lists.newArrayList(empEmailMap.values());
            }

            // PE 销售 GM
            emails.addAll(saleEmails);
            emails.addAll(operatorEmails);
            // emails.addAll(gmEmails);
        }
        if (BrandCampaignInventoryAutoReleaseWarningTypeEnum.MULTIPLE.getCode().equals(campaignInventoryAutoReleaseMsgViewDTO.getWarningType())) {
            // 邮件组
            emails.add(MULTIPLE_WARNING_EMAIL_GROUP);
        }
        // 测试使用
        if (!Env.isProd()) {
            emails.add("wb-yf863178@alibaba-inc.com");
            emails.add("wb-whf239014@alibaba-inc.com");
            emails.add("thl01663029@alibaba-inc.com");
            emails.add("wtt01663028@alibaba-inc.com");
            emails.add("wb-sgs368661@alibaba-inc.com");
            emails.add("zzy01006086@alibaba-inc.com");
            emails.add("jixiu.lj@alibaba-inc.com");
            emails.add("wb-hb534083@alibaba-inc.com");
        }
        return Lists.newArrayList(emails);
    }

    private String buildMessageContent(ServiceContext context, List<CampaignInventoryAutoReleaseMsgViewDTO> campaignInventoryAutoReleaseMsgViewDTOList, String vm) {
        Map<String, Object> params = buildVMParam(context, campaignInventoryAutoReleaseMsgViewDTOList);
        return VelocityUtils.merge(vm, params);
    }

    private String buildMessageContent(ServiceContext context, CampaignInventoryAutoReleaseMsgViewDTO campaignInventoryAutoReleaseMsgViewDTO, String vm, MessageSendTypeEnum messageSendTypeEnum) {
        Map<String, Object> params = buildVMParam(context, campaignInventoryAutoReleaseMsgViewDTO, messageSendTypeEnum);
        return VelocityUtils.merge(vm, params);
    }

    /**
     * 批量订单预警
     * @param context
     * @param campaignInventoryAutoReleaseMsgViewDTOList
     * @return
     */
    private Map<String, Object> buildVMParam(ServiceContext context, List<CampaignInventoryAutoReleaseMsgViewDTO> campaignInventoryAutoReleaseMsgViewDTOList) {
        CampaignMsgNoticeViewDTO campaignMsgNoticeViewDTO = new CampaignMsgNoticeViewDTO();

        CampaignViewDTO campaignViewDTO = campaignInventoryAutoReleaseMsgViewDTOList.get(0).getCampaignViewDTOList().get(0);
        Date lockExpireTime = campaignViewDTO.getCampaignInquiryLockViewDTO().getLockExpireTime();
        campaignMsgNoticeViewDTO.setReleaseTime(BrandDateUtil.date2String(lockExpireTime) + " 23:30:00");
        campaignMsgNoticeViewDTO.setWarningCampaignCount(campaignInventoryAutoReleaseMsgViewDTOList.size());

        List<CampaignMsgNoticeViewDTO> warningCampaignGroupList = campaignInventoryAutoReleaseMsgViewDTOList.stream().map(campaignInventoryAutoReleaseMsgViewDTO -> {
            CampaignGroupViewDTO campaignGroupViewDTO = campaignInventoryAutoReleaseMsgViewDTO.getCampaignGroupViewDTO();
            CampaignMsgNoticeViewDTO msgNoticeViewDTO = new CampaignMsgNoticeViewDTO();
            msgNoticeViewDTO.setMemberName(memberRepository.getMemberNameById(campaignGroupViewDTO.getMemberId()));
            msgNoticeViewDTO.setMemberDisplayName(memberRepository.getMemberDisplayNameById(campaignGroupViewDTO.getMemberId()));
            Long customerId = campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getCustomerId();
            SalesCustomerViewDTO customer = customerRepository.getCustomerById(customerId);
            msgNoticeViewDTO.setCustomerName(customer.getName());
            msgNoticeViewDTO.setCampaignGroupId(campaignGroupViewDTO.getId());
            msgNoticeViewDTO.setCampaignGroupName(campaignGroupViewDTO.getName());
            msgNoticeViewDTO.setBudget("￥ "  + FenYuanUtil.getYuanFromFen(campaignGroupViewDTO.getBudget()).toPlainString());
            // 取所有分组产品线
            if (Objects.nonNull(campaignGroupViewDTO.getCampaignGroupSaleViewDTO()) && CollectionUtils.isNotEmpty(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList())) {
                Set<String> productLineSet = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream().map(saleGroupInfoViewDTO -> {
                    return SaleProductLineEnum.getDesc(saleGroupInfoViewDTO.getSaleProductLine());
                }).collect(Collectors.toSet());
                msgNoticeViewDTO.setProductLine(StringUtils.join(productLineSet, Constant.CHAR_SPLIT_KEY_DOT));
            }

            Long briefId = campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getBriefId();
            SalesBriefViewDTO brief = salesBriefRepository.getBrief(briefId);
            msgNoticeViewDTO.setSales(getEmpNameList(Lists.newArrayList(brief.getCreator())));
            msgNoticeViewDTO.setPe(getEmpNameList(campaignGroupViewDTO.getOperators()));

            msgNoticeViewDTO.setCampaignGroupStartTime(BrandDateUtil.date2String(campaignGroupViewDTO.getStartTime()));
            msgNoticeViewDTO.setCampaignGroupEndTime(BrandDateUtil.date2String(campaignGroupViewDTO.getEndTime()));
            msgNoticeViewDTO.setStatus(BrandCampaignGroupStatusEnum.getByCode(campaignGroupViewDTO.getStatus()).getDesc());

            // GM 直接取brief的 +1+2主管，邮箱信息不会嵌套传回，并且只传一级，因此需要多次查询
            List<String> gmList = Lists.newArrayList();
            EmpDTO briefCreator = simbaUicRepository.getEmp(brief.getCreator());
            EmpDTO superEmp = simbaUicRepository.getEmp(briefCreator.getSuperEmp().getEmpId());
            if (Objects.nonNull(superEmp)) {
                gmList.add(superEmp.getEmpId());
                gmList.add(superEmp.getSuperEmp().getEmpId());
            }
            msgNoticeViewDTO.setGm(getEmpNameList(gmList));
            return msgNoticeViewDTO;
        }).collect(Collectors.toList());
        campaignMsgNoticeViewDTO.setWarningCampaignGroupList(warningCampaignGroupList);

        BeanMap beanMap = BeanMap.create(campaignMsgNoticeViewDTO);
        return beanMap;
    }

    /**
     * 单订单预警
     *
     * @param context
     * @param campaignInventoryAutoReleaseMsgViewDTO
     * @return
     */
    private Map<String, Object> buildVMParam(ServiceContext context, CampaignInventoryAutoReleaseMsgViewDTO campaignInventoryAutoReleaseMsgViewDTO, MessageSendTypeEnum messageSendTypeEnum) {
        CampaignMsgNoticeViewDTO campaignMsgNoticeViewDTO = new CampaignMsgNoticeViewDTO();

        List<CampaignViewDTO> campaignViewDTOList = campaignInventoryAutoReleaseMsgViewDTO.getCampaignViewDTOList();
        CampaignGroupViewDTO campaignGroupViewDTO = campaignInventoryAutoReleaseMsgViewDTO.getCampaignGroupViewDTO();

        campaignMsgNoticeViewDTO.setMemberName(memberRepository.getMemberNameById(campaignGroupViewDTO.getMemberId()));
        campaignMsgNoticeViewDTO.setMemberDisplayName(memberRepository.getMemberDisplayNameById(campaignGroupViewDTO.getMemberId()));
        campaignMsgNoticeViewDTO.setCampaignGroupId(campaignGroupViewDTO.getId());
        campaignMsgNoticeViewDTO.setCampaignGroupName(campaignGroupViewDTO.getName());
        campaignMsgNoticeViewDTO.setCampaignGroupStartTime(BrandDateUtil.date2String(campaignGroupViewDTO.getStartTime()));
        campaignMsgNoticeViewDTO.setCampaignGroupEndTime(BrandDateUtil.date2String(campaignGroupViewDTO.getEndTime()));
        Long briefId = campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getBriefId();
        SalesBriefViewDTO brief = salesBriefRepository.getBrief(briefId);
        campaignMsgNoticeViewDTO.setSales(getEmpNameList(Lists.newArrayList(brief.getCreator())));
        campaignMsgNoticeViewDTO.setPe(getEmpNameList(campaignGroupViewDTO.getOperators()));

        // GM 直接取brief的 +1+2主管，邮箱信息不会嵌套传回，并且只传一级，因此需要多次查询
        List<String> gmList = Lists.newArrayList();
        EmpDTO briefCreator = simbaUicRepository.getEmp(brief.getCreator());
        EmpDTO superEmp = simbaUicRepository.getEmp(briefCreator.getSuperEmp().getEmpId());
        if (Objects.nonNull(superEmp)) {
            gmList.add(superEmp.getEmpId());
            gmList.add(superEmp.getSuperEmp().getEmpId());
        }
        campaignMsgNoticeViewDTO.setGm(getEmpNameList(gmList));


        // 计划按照分组聚合
        Map<Long, List<CampaignViewDTO>> saleGroupCampaignMap = campaignViewDTOList.stream().collect(Collectors.groupingBy(campaignViewDTO -> campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId()));
        List<CampaignSaleGroupMsgNoticeViewDTO> saleGroupList = Lists.newArrayList();
        for (Long saleGroupId : saleGroupCampaignMap.keySet()) {
            CampaignSaleGroupMsgNoticeViewDTO campaignSaleGroupMsgNoticeViewDTO = new CampaignSaleGroupMsgNoticeViewDTO();
            ResourcePackageQueryOption packageQueryOption = ResourcePackageQueryOption.builder().build();
            ResourcePackageSaleGroupViewDTO saleGroup = resourcePackageRepository.getSaleGroupById(buildServiceContext(campaignGroupViewDTO.getMemberId(), null), saleGroupId, packageQueryOption);
            campaignSaleGroupMsgNoticeViewDTO.setSaleGroupName(saleGroup.getName());
            List<CampaignMsgNoticeViewDTO> campaignInfos = Lists.newArrayList();
            List<CampaignViewDTO> campaignList = saleGroupCampaignMap.get(saleGroupId);
            campaignList.forEach(campaignViewDTO -> {
                CampaignMsgNoticeViewDTO msgNoticeViewDTO = new CampaignMsgNoticeViewDTO();
                msgNoticeViewDTO.setCampaignName(campaignViewDTO.getTitle());
                if (Objects.nonNull(campaignViewDTO.getCampaignExtViewDTO()) && Objects.nonNull(campaignViewDTO.getCampaignInquiryLockViewDTO().getLockExpireTime())) {
                    msgNoticeViewDTO.setReleaseTime(BrandDateUtil.date2String(campaignViewDTO.getCampaignInquiryLockViewDTO().getLockExpireTime()) + " 23:30:00");
                }
                campaignInfos.add(msgNoticeViewDTO);
            });
            campaignSaleGroupMsgNoticeViewDTO.setCampaignInfos(campaignInfos);
            saleGroupList.add(campaignSaleGroupMsgNoticeViewDTO);
        }
        campaignMsgNoticeViewDTO.setSaleGroupList(saleGroupList);
        // 站内信通知中不添加排期附件
        if (messageSendTypeEnum == MessageSendTypeEnum.EMAIL) {
            campaignMsgNoticeViewDTO.setCdnUrl(campaignInventoryAutoReleaseMsgViewDTO.getCdnUrl());
        }

        BeanMap beanMap = BeanMap.create(campaignMsgNoticeViewDTO);
        return beanMap;
    }

    private String getEmpNameList(List<String> empIdList) {
        if (CollectionUtils.isEmpty(empIdList)) {
            return "";
        }
        Map<String, EmpDTO> empMap = simbaUicRepository.getEmp(empIdList);
        if(MapUtils.isEmpty(empMap)) {
            return "";
        }
        return empMap.values().stream()
                .filter(empDTO -> StringUtils.isNotBlank(empDTO.getName()) || StringUtils.isNotBlank(empDTO.getNick()))
                .map(empDTO -> {
                    if(StringUtils.isNotBlank(empDTO.getNick())) {
                        return empDTO.getNick();
                    }
                    return empDTO.getName();
                })
                .collect(Collectors.joining(Constant.CHAR_SPLIT_KEY_DOT));

    }

    private ServiceContext buildServiceContext(Long memberId, Integer sceneId) {
        ServiceContext context = new ServiceContext();
        context.setOperType(BaseServiceContext.OPERTYPE_INNER_OPT);
        context.setProductLineId(Product.BRAND_ONEBP_BRAND.getProductLineId());
        context.setMemberId(memberId);
        context.setBizCode(ServiceContextUtil.getBizCode(sceneId));
        context.setProductId(ServiceContextUtil.getProductId(context.getBizCode()));
        return context;
    }

    private MessageViewDTO buildMessageViewDTO(ServiceContext context, List<String> sendTo, String subjectTemplate,
                                               CampaignDealMsgViewDTO campaignDealMsgViewDTO, String vmTemplate, List<Integer> sendType) {
        MessageViewDTO messageViewDTO = new MessageViewDTO();
        CampaignGroupViewDTO campaignGroupViewDTO = campaignDealMsgViewDTO.getCampaignGroupViewDTO();
        String subject = String.format(subjectTemplate, memberRepository.getMemberDisplayNameById(campaignGroupViewDTO.getMemberId()),
                campaignGroupViewDTO.getName());
        messageViewDTO.setMemberId(campaignDealMsgViewDTO.getMemberId());
        messageViewDTO.setSubject(subject);
        messageViewDTO.setContent(buildMessageContent(context, campaignDealMsgViewDTO, vmTemplate));
        messageViewDTO.setSendTo(sendTo);
        messageViewDTO.setSendType(sendType);
        return messageViewDTO;
    }


    private List<String> getSendTo(ServiceContext context, CampaignDealMsgViewDTO campaignDealMsgViewDTO) {
        List<String> sendToIds = Lists.newArrayList();
        List<String> operatorEmails = Lists.newArrayList(MailUtils.rdRecipients);
        if (Env.isProd()) {
            //运营
            Optional.ofNullable(campaignDealMsgViewDTO.getCampaignGroupViewDTO().getOperators()).ifPresent(sendToIds::addAll);
            //运营相关人
            Optional.ofNullable(campaignDealMsgViewDTO.getCampaignGroupViewDTO().getRelevantOperators()).ifPresent(sendToIds::addAll);
            //分组负责人
            ResourcePackageQueryOption packageQueryOption = ResourcePackageQueryOption.builder().needProduct(false).needSetting(false).build();
            ResourcePackageSaleGroupViewDTO saleGroupViewDTO =
                    resourcePackageRepository.getSaleGroupById(context, campaignDealMsgViewDTO.getCampaignViewDTO().getCampaignSaleViewDTO().getSaleGroupId(), packageQueryOption);
            if (saleGroupViewDTO != null && CollectionUtils.isNotEmpty(saleGroupViewDTO.getChargeEmpList())) {
                sendToIds.addAll(saleGroupViewDTO.getChargeEmpList().stream().map(ResourcePackageEmpViewDTO::getEmpId).collect(Collectors.toSet()));
            }
            //获取邮箱
            Map<String, String> empEmailMap = simbaUicRepository.getEmpEmails(sendToIds);
            RogerLogger.info("sendToIds={},empEmailMap={}", JSON.toJSONString(sendToIds), JSON.toJSONString(empEmailMap));
            operatorEmails.addAll(empEmailMap.values());
        }
        return operatorEmails;
    }

    private String buildMessageContent(ServiceContext context, CampaignDealMsgViewDTO campaignDealMsgViewDTO, String vm) {
        Map<String, Object> params = buildVMParam(context, campaignDealMsgViewDTO);
        String content = VelocityUtils.merge(vm, params);
        return content;
    }

    private Map<String, Object> buildVMParam(ServiceContext context, CampaignDealMsgViewDTO campaignDealMsgViewDTO) {
        CampaignMsgNoticeViewDTO campaignMsgNoticeViewDTO = new CampaignMsgNoticeViewDTO();

        CampaignViewDTO campaignViewDTO = campaignDealMsgViewDTO.getCampaignViewDTO();
        campaignMsgNoticeViewDTO.setMemberId(campaignViewDTO.getMemberId());
        campaignMsgNoticeViewDTO.setMemberName(memberRepository.getMemberNameById(campaignViewDTO.getMemberId()));
        campaignMsgNoticeViewDTO.setMemberDisplayName(memberRepository.getMemberDisplayNameById(campaignViewDTO.getMemberId()));
        campaignMsgNoticeViewDTO.setCampaignId(campaignViewDTO.getId());
        campaignMsgNoticeViewDTO.setCampaignName(campaignViewDTO.getTitle());
        campaignMsgNoticeViewDTO.setCustomerTemplateId(campaignDealMsgViewDTO.getCampaignViewDTO().getCampaignSaleViewDTO().getCustomerTemplateId());

        ResourcePackageTemplateViewDTO resourcePackageTemplate = getResourcePackageTemplate(context,
                campaignDealMsgViewDTO.getCampaignViewDTO().getCampaignSaleViewDTO().getCustomerTemplateId());
        if (resourcePackageTemplate != null) {
            campaignMsgNoticeViewDTO.setCustomerTemplateName(resourcePackageTemplate.getCustomerTemplateName());
        }

        ProductViewDTO product = getProduct(campaignDealMsgViewDTO.getCampaignViewDTO().getCampaignResourceViewDTO().getSspProductId());
        if (product != null) {
            campaignMsgNoticeViewDTO.setCustomerOrientedProductName(product.getCustomerOrientedResourceName());
            campaignMsgNoticeViewDTO.setCustomerOrientedMediaName(product.getCustomerOrientedMediaName());
        }
        if (CollectionUtils.isNotEmpty(campaignDealMsgViewDTO.getBottomDays())) {
            List<DateViewDTO> dateViewDTOList = BrandDateUtil.formatDateQuantum(campaignDealMsgViewDTO.getBottomDays());
            String bottomDateStr = dateViewDTOList.stream().map(
                    v -> BrandDateUtil.date2String(v.getStartDate()) + "~" + BrandDateUtil.date2String(v.getEndDate())).collect(
                    Collectors.joining(","));
            campaignMsgNoticeViewDTO.setBottomDateStr(bottomDateStr);
        }
        BeanMap beanMap = BeanMap.create(campaignMsgNoticeViewDTO);
        return beanMap;
    }

    private ResourcePackageTemplateViewDTO getResourcePackageTemplate(ServiceContext context, Long customerTemplateId) {
        return resourcePackageRepository.getCustomerTemplateById(context, customerTemplateId);
    }

    private ProductViewDTO getProduct(Long productId) {
        if (productId == null) {
            return null;
        }
        return productRepository.getProductById(productId);
    }

}
