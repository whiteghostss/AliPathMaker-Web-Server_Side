package com.taobao.ad.brand.bp.app.workflow.adgroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityInject;
import com.alibaba.abf.isolation.spec.common.ReduceType;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.adgroup.monitor.AdgroupMonitorViewDTO;
import com.alibaba.ad.brand.dto.adgroup.resource.AdgroupResourceViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.sale.CampaignSaleViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.creative.ContentVersionViewDTO;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupOnlineStatusEnum;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupTargetTypeEnum;
import com.alibaba.ad.nb.ssp.constant.common.CrossSceneEnum;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.adgroup.ExportMonitorCodeViewDTO;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupExportMonitorQueryDTO;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryOption;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.common.threadpooltask.AdgroupGenerateMonitorTaskIdentifier;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.adgroup.ability.BizAdgroupMonitorAbility;
import com.taobao.ad.brand.bp.domain.adgroup.repository.AdgroupRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.ability.param.BizAdgroupMonitorAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.query.IAdgroupStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.workflow.BizAdgroupMonitorWorkflowExt;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.workflow.param.BizAdgroupMonitorWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.base.workflow.Workflow;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Description:单元监测业务流程
 * <p>
 * date: 2023/10/24 11:13 PM
 *
 * @author shiyan
 * @version 1.0
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizAdgroupMonitorWorkflow extends Workflow {

    @AbilityInject(reduce = ReduceType.FIRST)
    private final BizAdgroupMonitorWorkflowExt bizAdgroupMonitorWorkflowExt;

    private final AdgroupRepository adgroupRepository;
    private final CampaignGroupRepository campaignGroupRepository;
    private final BizAdgroupMonitorAbility bizAdgroupMonitorAbility;
    private final AdgroupGenerateMonitorTaskIdentifier adgroupGenerateMonitorTaskIdentifier;
    private final ICampaignStructureQueryAbility campaignStructureQueryAbility;
    private final IAdgroupStructureQueryAbility adgroupStructureQueryAbility;

    /**
     * 批量发送非精准邮件
     * @param context
     * @param adgroupViewDTOList
     * @return
     */
    public List<Long> batchSendMonitorEmail(ServiceContext context, List<AdgroupViewDTO> adgroupViewDTOList){
        //生成监测代码
        List<ImmutablePair<AdgroupViewDTO, List<ExportMonitorCodeViewDTO>>> immutablePairList = TaskStream.execute(adgroupGenerateMonitorTaskIdentifier, adgroupViewDTOList, (adgroupViewDTO, index) -> {
            List<ExportMonitorCodeViewDTO> monitorCodeViewDTOList = this.generateAdgroupMonitor(context, adgroupViewDTO);
            return ImmutablePair.of(adgroupViewDTO, monitorCodeViewDTOList);
        }).commit().getResultList();
        //发送监测代码邮件
        List<Long> monitorVersionList = Lists.newArrayList();
        for (ImmutablePair<AdgroupViewDTO, List<ExportMonitorCodeViewDTO>> immutablePair : immutablePairList) {
            AdgroupViewDTO adgroupViewDTO = immutablePair.getKey();
            List<ExportMonitorCodeViewDTO> monitorCodeViewDTOList = immutablePair.getValue();
            //保存监测信息
            //check是否需要重新保存，或者重新发送

            List<Long> hasChangeSubCampaignIds = bizAdgroupMonitorWorkflowExt.getNeedToSendEmailSubCampaignIds(context,adgroupViewDTO, monitorCodeViewDTOList);

            List<Long> finalHasChangeSubCampaignIds = hasChangeSubCampaignIds;
            RogerLogger.info("batchSendMonitorEmail finalHasChangeSubCampaignIds:{}", JSON.toJSONString(finalHasChangeSubCampaignIds));
            List<ExportMonitorCodeViewDTO> needToSendMonitorCodeViewDTOList = monitorCodeViewDTOList.stream().filter(item-> finalHasChangeSubCampaignIds.contains(item.getSubCampaignId())).collect(Collectors.toList());
            ContentVersionViewDTO contentVersionViewDTO = bizAdgroupMonitorAbility.saveAdgroupMonitorContent(context, adgroupViewDTO, monitorCodeViewDTOList);

            AdgroupMonitorViewDTO adgroupMonitorViewDTO = Optional.ofNullable(adgroupViewDTO.getAdgroupMonitorViewDTO()).orElse(new AdgroupMonitorViewDTO());
            adgroupViewDTO.setAdgroupMonitorViewDTO(adgroupMonitorViewDTO);
            adgroupViewDTO.getAdgroupMonitorViewDTO().setMonitorContentId(contentVersionViewDTO.getContentId());
            //发送监测邮件（生成监测cdnUrl、发送邮件）
            bizAdgroupMonitorWorkflowExt.sendAdgroupMonitorEmail(context,adgroupViewDTO,contentVersionViewDTO,needToSendMonitorCodeViewDTOList);
            //更新单元监测发送时间(更新最后发送时间 & 监测id)
            adgroupViewDTO.getAdgroupMonitorViewDTO().setLastSendTime(new Date());
            adgroupRepository.updateAdgroupLastSendTime(context, adgroupViewDTO);
            monitorVersionList.add(contentVersionViewDTO.getId());

        }
        return monitorVersionList;
    }

    /**
     * 下载单元监测
     * @param context
     * @param adgroupViewDTO
     * @return
     */
    public String exportMonitor(ServiceContext context, AdgroupViewDTO adgroupViewDTO){
        //1、生成监测代码
        List<ExportMonitorCodeViewDTO> monitorCodeViewDTOList = generateAdgroupMonitor(context, adgroupViewDTO);
        //2、保存监测信息
        ContentVersionViewDTO contentVersionViewDTO = bizAdgroupMonitorAbility.saveAdgroupMonitorContent(context, adgroupViewDTO, monitorCodeViewDTOList);

        AdgroupMonitorViewDTO adgroupMonitorViewDTO = Optional.ofNullable(adgroupViewDTO.getAdgroupMonitorViewDTO()).orElse(new AdgroupMonitorViewDTO());
        adgroupViewDTO.setAdgroupMonitorViewDTO(adgroupMonitorViewDTO);
        adgroupViewDTO.getAdgroupMonitorViewDTO().setMonitorContentId(contentVersionViewDTO.getContentId());
        //3、生成下载cdnUrl
        String fileName = String.format("%s_%s_监测代码.xlsx",adgroupViewDTO.getTitle(),System.currentTimeMillis()+"");
        String downloadCdnUrl = bizAdgroupMonitorAbility.getMonitorDownloadCdnUrl(context, fileName, monitorCodeViewDTOList);
        //4、更新单元监测信息（导出不更新最后发送时间）
        adgroupViewDTO.getAdgroupMonitorViewDTO().setLastSendTime(null);
        adgroupRepository.updateAdgroupLastSendTime(context, adgroupViewDTO);
        return downloadCdnUrl;
    }

    /**
     * 导出订单监测
     * @param context
     * @param queryDTO
     * @return
     */
    public String exportOrderMonitor(ServiceContext context,AdgroupExportMonitorQueryDTO queryDTO){
        List<AdgroupViewDTO> adgroupViewDTOList = findMonitorAdgroupByCampaignGroupId(context, queryDTO);
        //生成监测代码
        List<ImmutablePair<AdgroupViewDTO, List<ExportMonitorCodeViewDTO>>> immutablePairList =TaskStream.execute(adgroupGenerateMonitorTaskIdentifier, adgroupViewDTOList, (adgroupViewDTO, index) -> {
            List<ExportMonitorCodeViewDTO> monitorCodeViewDTOList = this.generateAdgroupMonitor(context, adgroupViewDTO);
            return ImmutablePair.of(adgroupViewDTO, monitorCodeViewDTOList);
        }).commit().getResultList();

        List<ExportMonitorCodeViewDTO> allMonitorCodeViewDTOList = Lists.newArrayList();
        for (ImmutablePair<AdgroupViewDTO, List<ExportMonitorCodeViewDTO>> immutablePair : immutablePairList) {
            allMonitorCodeViewDTOList.addAll(immutablePair.getValue());
        }
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(context, queryDTO.getCampaignGroupId());
        //3、生成下载cdnUrl
        String fileName = String.format("%s_%s_监测代码.xlsx",campaignGroupViewDTO.getName(),System.currentTimeMillis()+"");
        String downloadCdnUrl = bizAdgroupMonitorAbility.getMonitorDownloadCdnUrl(context, fileName, allMonitorCodeViewDTOList);
        return downloadCdnUrl;
    }

    /**
     * 生成单元监测代码
     * @param context
     * @param adgroupViewDTO
     * @return
     */
    private List<ExportMonitorCodeViewDTO> generateAdgroupMonitor(ServiceContext context, AdgroupViewDTO adgroupViewDTO) {
        //1、构建查询参数
        BizAdgroupMonitorWorkflowParam workflowParam = bizAdgroupMonitorWorkflowExt.buildParamForMonitor(context, adgroupViewDTO);
        BizAdgroupMonitorAbilityParam abilityParam = BizAdgroupMonitorAbilityParam.convertToAbilityParam(workflowParam);
        //2、业务逻辑校验
        bizAdgroupMonitorAbility.validateAdgroupMonitor(context, adgroupViewDTO, abilityParam);
        //3、监测服务调用
        return bizAdgroupMonitorAbility.generateAdgroupMonitor(context, adgroupViewDTO, abilityParam);
    }


    /**
     * 查询订单下满足要求的单元（媒体直投 && 非草稿）
     * @param context
     * @param queryDTO
     * @return
     */
    public List<AdgroupViewDTO> findMonitorAdgroupByCampaignGroupId(ServiceContext context, AdgroupExportMonitorQueryDTO queryDTO){
        AssertUtil.notNull(queryDTO, "参数不允许为空");
        Long campaignGroupId = queryDTO.getCampaignGroupId();
        Long saleGroupId = queryDTO.getSaleGroupId();
        AssertUtil.notNull(campaignGroupId, "订单id参数不允许为空");
        AdgroupQueryViewDTO adgroupQueryViewDTO = new AdgroupQueryViewDTO();
        adgroupQueryViewDTO.setCampaignGroupId(campaignGroupId);
        List<AdgroupViewDTO> adgroupViewDTOList = adgroupStructureQueryAbility.handle(context, AdgroupStructureQueryAbilityParam.builder()
                .abilityTarget(adgroupQueryViewDTO).queryOption(AdgroupQueryOption.builder().needCreative(true).build()).build());

        AssertUtil.notEmpty(adgroupViewDTOList,"订单下未创建单元，不能执行该操作");
        //如果分组ID不为空，按照分组过滤单元以后再生成监测
        if(saleGroupId != null){
            List<AdgroupViewDTO> filterAdgroupList = Lists.newArrayList();
            CampaignQueryViewDTO campaignQueryViewDTO= new CampaignQueryViewDTO();
            campaignQueryViewDTO.setCampaignGroupId(campaignGroupId);
            campaignQueryViewDTO.setSaleGroupId(saleGroupId);
            List<CampaignViewDTO> campaignViewDTOList = campaignStructureQueryAbility.handle(context, CampaignStructureQueryAbilityParam.builder()
                    .abilityTarget(campaignQueryViewDTO).queryOption(CampaignQueryOption.builder().build()).build());
            if(CollectionUtils.isNotEmpty(campaignViewDTOList)){
                Map<Long, CampaignViewDTO> campaignMap = campaignViewDTOList.stream().collect(Collectors.toMap(e->e.getId(), e->e));
                for(AdgroupViewDTO adgroupViewDTO:adgroupViewDTOList){
                    CampaignViewDTO campaignViewDTO= campaignMap.get(adgroupViewDTO.getCampaignId());
                    Long campaignSaleGroupId = Optional.ofNullable(campaignViewDTO).map(CampaignViewDTO::getCampaignSaleViewDTO)
                            .map(CampaignSaleViewDTO::getSaleGroupId).orElse(null);
                    if(Objects.equals(campaignSaleGroupId,saleGroupId)){
                        filterAdgroupList.add(adgroupViewDTO);
                    }
                }
            }
            adgroupViewDTOList = filterAdgroupList;
        }
        adgroupViewDTOList = adgroupViewDTOList.stream()
                .filter(adgroupViewDTO -> Objects.equals(CrossSceneEnum.CROSS_OPAQUE_SCENE.getValue(),
                        Optional.ofNullable(adgroupViewDTO.getAdgroupResourceViewDTO()).map(AdgroupResourceViewDTO::getSspCrossScene).orElse(null))
                        || Objects.equals(adgroupViewDTO.getTargetType(), BrandAdgroupTargetTypeEnum.DIRECT.getCode()))
                .filter(adgroupViewDTO -> !BrandAdgroupOnlineStatusEnum.DRAFT.getCode().equals(adgroupViewDTO.getOnlineStatus()))
                .collect(Collectors.toList());
        AssertUtil.notEmpty(adgroupViewDTOList,String.format("当前订单(id=%s)下无满足要求的媒体直投单元",campaignGroupId));
        return adgroupViewDTOList;
    }
}
