package com.taobao.ad.brand.bp.app.service.account.agreement;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.api.account.agreement.BizAgreementCommandService;
import com.taobao.ad.brand.bp.client.dto.account.agreement.AgreementSignRequestViewDTO;
import com.taobao.ad.brand.bp.client.dto.account.agreement.AgreementSignResultViewDTO;
import com.taobao.ad.brand.bp.domain.account.repository.AgreementRepository;

import lombok.RequiredArgsConstructor;

/**
 * @author 虫洞 <liuming.liu@alibaba-inc.com>
 * @date 2023/4/4
 */
@HSFProvider(serviceInterface = BizAgreementCommandService.class)
@RequiredArgsConstructor
public class BizAgreementCommandServiceImpl implements BizAgreementCommandService {
    private final AgreementRepository agreementRepository;

    @Override
    public SingleResponse<AgreementSignResultViewDTO> sign(ServiceContext serviceContext, AgreementSignRequestViewDTO requestViewDTO) {
        AgreementSignResultViewDTO signResultViewDTO = agreementRepository.sign(requestViewDTO);
        return SingleResponse.of(signResultViewDTO);
    }
}
