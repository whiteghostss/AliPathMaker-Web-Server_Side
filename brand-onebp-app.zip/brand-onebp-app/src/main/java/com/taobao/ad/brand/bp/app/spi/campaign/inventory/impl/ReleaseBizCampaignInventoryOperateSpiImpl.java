package com.taobao.ad.brand.bp.app.spi.campaign.inventory.impl;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.nb.framework.core.annotation.AbilitySpiInstance;
import com.alibaba.hermes.framework.error.ErrorCodeAware;
import com.taobao.ad.brand.bp.app.spi.campaign.inventory.BizCampaignInventoryOperateSpi;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignInquiryOperateViewDTO;
import com.taobao.ad.brand.bp.common.enums.InquiryErrorTypeEnum;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.inventory.ICampaignDoohReleaseForCampaignInventoryOperateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.inventory.ICampaignErrorMsgBuildForCampaignInventoryOperateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.inventory.ICampaignIllegalFilterForCampaignInventoryOperateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.inventory.ICampaignStatusValidateForCampaignInventoryOperateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignDoohReleaseAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignInventoryOperateErrorMsgBuildAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignInventoryOperateIllegalAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignInventoryOperateValidateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignInventoryWorkflowParam;

import javax.annotation.Resource;
import java.util.Map;
import java.util.Set;

@AbilitySpiInstance(bizCode = BizCampaignInventoryOperateSpi.RELEASE, name = "releaseBizCampaignInventoryOperateSpiImpl", desc = "库存释量操作实现")
public class ReleaseBizCampaignInventoryOperateSpiImpl extends DefaultBizCampaignInventoryOperateSpiImpl {

    @Resource
    private ICampaignStatusValidateForCampaignInventoryOperateAbility campaignStatusValidateForCampaignInventoryOperateAbility;
    @Resource
    private ICampaignErrorMsgBuildForCampaignInventoryOperateAbility campaignErrorMsgBuildForCampaignInventoryOperateAbility;
    @Resource
    private ICampaignIllegalFilterForCampaignInventoryOperateAbility campaignIllegalFilterForCampaignInventoryOperateAbility;
    @Resource
    private ICampaignDoohReleaseForCampaignInventoryOperateAbility campaignDoohReleaseForCampaignInventoryOperateAbility;

    @Override
    public ErrorCodeAware validateCampaignInventoryOperate(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO, BizCampaignInventoryWorkflowParam inventoryWorkflowParam) {
        //计划校验
//        Map<InquiryErrorTypeEnum, Set<Long>> illegalBudgetCampaignMap = validateCampaignReleaseStatus(serviceContext, inventoryAbilityParam.getCampaignGroupViewDTOList(),inventoryAbilityParam.getCampaignScheduleViewDTOList());

//        ErrorCodeAware errorCodeAware = convertToErrorMsg(serviceContext, illegalBudgetCampaignMap, inquiryOperateViewDTO.getOperateType(),
//                inventoryAbilityParam.getCampaignTreeViewDTOList(), inventoryAbilityParam.getCampaignScheduleViewDTOList(), inquiryOperateViewDTO.getConfirm());
//        filterIllegalCampaign(inventoryAbilityParam.getCampaignScheduleViewDTOList(), illegalBudgetCampaignMap);

        Map<InquiryErrorTypeEnum, Set<Long>> illegalBudgetCampaignMap = campaignStatusValidateForCampaignInventoryOperateAbility.handle(serviceContext,
                CampaignInventoryOperateValidateAbilityParam.builder().abilityTargets(inventoryWorkflowParam.getCampaignScheduleViewDTOList())
                        .campaignGroupViewDTOList(inventoryWorkflowParam.getCampaignGroupViewDTOList()).build());

        CampaignInventoryOperateErrorMsgBuildAbilityParam errorMsgBuildAbilityParam = CampaignInventoryOperateErrorMsgBuildAbilityParam.builder()
                .abilityTargets(inventoryWorkflowParam.getCampaignScheduleViewDTOList()).illegalCampaignMap(illegalBudgetCampaignMap)
                .campaignViewDTOList(inventoryWorkflowParam.getCampaignTreeViewDTOList())
                .operateType(inquiryOperateViewDTO.getOperateType()).confirm(inquiryOperateViewDTO.getConfirm()).build();
        ErrorCodeAware errorCodeAware = campaignErrorMsgBuildForCampaignInventoryOperateAbility.handle(serviceContext,errorMsgBuildAbilityParam);

        campaignIllegalFilterForCampaignInventoryOperateAbility.handle(serviceContext,
                CampaignInventoryOperateIllegalAbilityParam.builder().abilityTargets(inventoryWorkflowParam.getCampaignScheduleViewDTOList())
                        .illegalCampaignMap(illegalBudgetCampaignMap).build());

        return errorCodeAware;
    }

//    @Override
//    public Void beforeInventoryRequest(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO, List<CampaignViewDTO> campaignTreeViewDTOList){
//        //计划释量前需要校验天攻计划的状态，如果已经下单则取消订单
//        if(CollectionUtils.isEmpty(campaignTreeViewDTOList)){
//            return null;
//        }
//        List<CampaignViewDTO> doohCampaignList = campaignTreeViewDTOList.stream().filter(e-> BizCampaignToolsHelper.isDoohCampaign(e.getSspResourceViewDTO().getSspProductLineId())).collect(Collectors.toList());
//        if(CollectionUtils.isEmpty(doohCampaignList)){
//            return null;
//        }
//        //天攻计划目前实际场景中，一个订单只有一个，代码兼容多个的场景
//        for(CampaignViewDTO doohCampaign : doohCampaignList){
//            DoohCampaignViewDTO doohCampaignViewDTO = doohRepository.getCampaignById(doohCampaign.getCampaignSaleViewDTO().getDoohCampaignId());
//            if(getNeedCancelDoohCampaignStatusList().contains(doohCampaignViewDTO.getStatus())){
//                doohRepository.cancel(doohCampaignViewDTO.getId());
//            }
//        }
//        return null;
//    }

    @Override
    public Void inventoryRequest(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO, BizCampaignInventoryWorkflowParam inventoryWorkflowParam) {
        campaignDoohReleaseForCampaignInventoryOperateAbility.handle(serviceContext,
                CampaignDoohReleaseAbilityParam.builder().abilityTargets(inventoryWorkflowParam.getCampaignTreeViewDTOList()).build());
        return super.inventoryRequest(serviceContext, inquiryOperateViewDTO, inventoryWorkflowParam);
    }

    //    /**
//     * 校验释量计划状态
//     */
//    private Map<InquiryErrorTypeEnum, Set<Long>> validateCampaignReleaseStatus(ServiceContext serviceContext, List<CampaignGroupViewDTO> campaignGroupViewDTOList, List<CampaignScheduleViewDTO> campaignScheduleViewDTOList) {
//        AssertUtil.assertTrue(campaignGroupViewDTOList.size() == 1, "仅支持单个订单的计划释量");
//        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupViewDTOList.get(0);
//        CampaignGroupBaseViewDTO campaignGroupBase = campaignGroupViewDTO.getBaseViewDTO();
//        Map<Long, Integer> saleGroupStatusMap = Maps.newHashMap();
//        if (campaignGroupViewDTO.getGroupSaleViewDTO() != null && CollectionUtils.isNotEmpty(
//                campaignGroupViewDTO.getGroupSaleViewDTO().getSaleGroupInfoViewDTOList())) {
//            saleGroupStatusMap = campaignGroupViewDTO.getGroupSaleViewDTO().getSaleGroupInfoViewDTOList().stream().collect(
//                    Collectors.toMap(SaleGroupInfoViewDTO::getSaleGroupId, SaleGroupInfoViewDTO::getSaleGroupStatus));
//        }
//        ResourcePackageQueryViewDTO queryViewDTO = new ResourcePackageQueryViewDTO();
//        queryViewDTO.setTemplateId(campaignGroupViewDTO.getGroupSaleViewDTO().getCustomerTemplateId());
//        ResourcePackageQueryOption queryOption = ResourcePackageQueryOption.builder().needSetting(false).needSetting(false).build();
//        List<ResourcePackageSaleGroupViewDTO> saleGroupList = resourcePackageRepository.getSaleGroupList(serviceContext, queryViewDTO, queryOption);
//        Map<Long, Integer> saleGroupTypeMap = saleGroupList.stream().collect(
//                Collectors.toMap(ResourcePackageSaleGroupViewDTO::getId, ResourcePackageSaleGroupViewDTO::getSaleType));
//
//        Map<InquiryErrorTypeEnum, Set<Long>> illegalCampaignMap = Maps.newHashMap();
//        for (CampaignScheduleViewDTO campaignScheduleViewDTO : campaignScheduleViewDTOList) {
//            List<Long> operateCampaignIds = campaignScheduleViewDTO.getOperateSubCampaignIds();
//            for (CampaignScheduleViewDTO subCampaign : campaignScheduleViewDTO.getSubCampaignList()) {
//                Integer sspMediaScope = subCampaign.getSspMediaScope();
//                Integer status = subCampaign.getStatus();
//                if (!operateCampaignIds.contains(subCampaign.getId())) {
//                    continue;
//                }
//                Long saleGroupId = subCampaign.getSaleGroupId();
//                Integer saleGroupStatus = saleGroupStatusMap.get(saleGroupId);
//                if (MediaScopeEnum.SITE_OUT.getCode().equals(sspMediaScope)) {
//                    //三环场景，下单完成的分组不允许释量
//                    if (BrandCampaignGroupSaleOrderStatusEnum.ORDER_FINISH.getCode().equals(saleGroupStatus)) {
//                        illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.RELEASE_SALE_GROUP_STATUS_ERROR, k -> Sets.newHashSet()).add(
//                                subCampaign.getId());
//                    }
//                } else {
//                    //非三环场景，下单中、下单完成的分组不允许释量
//                    if (BrandCampaignGroupSaleOrderStatusEnum.ORDER_ING.getCode().equals(saleGroupStatus) ||
//                            BrandCampaignGroupSaleOrderStatusEnum.ORDER_FINISH.getCode().equals(saleGroupStatus)) {
//                        illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.RELEASE_SALE_GROUP_STATUS_ERROR, k -> Sets.newHashSet()).add(
//                                subCampaign.getId());
//                    }
//                }
//                //购买分组需根据订单状态释量
//                if (saleGroupTypeMap.get(saleGroupId) != null && BrandSaleTypeEnum.BUY.getCode().equals(saleGroupTypeMap.get(saleGroupId))) {
//                    if (MediaScopeEnum.SITE_OUT.getCode().equals(sspMediaScope)) {
//                        //三环场景，非草稿、非改单配置、非正在下单状态不允许释量
//                        //正在下单状态运营侧期望可以调整采购行或者询量行重新锁量，且不影响订单状态
//                        if (!BrandCampaignGroupStatusEnum.EDITED.getCode().equals(campaignGroupBase.getStatus()) &&
//                                !BrandCampaignGroupStatusEnum.UNLOCKED.getCode().equals(campaignGroupBase.getStatus()) &&
//                                !BrandCampaignGroupStatusEnum.ORDER_ING.getCode().equals(campaignGroupBase.getStatus()) &&
//                                !BrandCampaignGroupStatusEnum.RESOURCE_CONFIRM_ING.getCode().equals(campaignGroupBase.getStatus())) {
//                            illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.RELEASE_CAMPAIGN_GROUP_STATUS_ERROR_FOR_SITE_OUT, k -> Sets.newHashSet()).add(
//                                    subCampaign.getId());
//                        }
//                    } else {
//                        //非三环场景，非草稿、非改单配置状态不允许释量
//                        if (!BrandCampaignGroupStatusEnum.EDITED.getCode().equals(campaignGroupBase.getStatus()) &&
//                                !BrandCampaignGroupStatusEnum.UNLOCKED.getCode().equals(campaignGroupBase.getStatus())) {
//                            illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.RELEASE_CAMPAIGN_GROUP_STATUS_ERROR, k -> Sets.newHashSet()).add(
//                                    subCampaign.getId());
//                        }
//                    }
//                }
//                if (!Constant.LOCKED_CAMPAIGN_STATUS_LIST.contains(subCampaign.getStatus())) {
//                    illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.RELEASE_CAMPAIGN_STATUS_ERROR, k -> Sets.newHashSet()).add(
//                            subCampaign.getId());
//                }
//                if (CollectionUtils.isEmpty(subCampaign.getFutureInquiryList())) {
//                    illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.CAMPAIGN_NOT_FUTURE_INQUIRY_ERROR, k -> Sets.newHashSet()).add(
//                            subCampaign.getId());
//                }
//                //改单配置补量分组的计划不能释当天
//                long count = subCampaign.getFutureInquiryList().stream().filter(
//                        v -> BrandDateUtil.isAfter(v.getDate(), BrandDateUtil.getCurrentDate())).count();
//                if ((BrandCampaignStatusEnum.CASTING.getCode().equals(status) || BrandCampaignStatusEnum.PAUSING.getCode().equals(status)) &&
//                        !NumberUtil.greaterThanZero(count)) {
//                    illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.CAMPAIGN_NOT_FUTURE_INQUIRY_ERROR, k -> Sets.newHashSet()).add(
//                            subCampaign.getId());
//                }
//            }
//        }
//        return illegalCampaignMap;
//    }
    
//    private List<Integer> getNeedCancelDoohCampaignStatusList(){
//        List<Integer> statusList = Lists.newArrayList(
//                DspPlanScheduleStateEnum.ORDERING.getCode(),
//                DspPlanScheduleStateEnum.MATERIELING.getCode(),
//                DspPlanScheduleStateEnum.MATERIELCHECKING.getCode(),
//                DspPlanScheduleStateEnum.MATERIELCHECKFAIL.getCode(),
//                DspPlanScheduleStateEnum.MATERIELCHECKSUCCESS.getCode(),
//                DspPlanScheduleStateEnum.WAITEXECUTE.getCode());
//        return statusList;
//    }
}

