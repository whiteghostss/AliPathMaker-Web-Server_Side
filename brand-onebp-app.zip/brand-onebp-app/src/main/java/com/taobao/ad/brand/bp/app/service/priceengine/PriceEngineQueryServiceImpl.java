package com.taobao.ad.brand.bp.app.service.priceengine;

import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.api.priceengine.PriceEngineQueryService;
import com.taobao.ad.brand.bp.client.dto.campaign.PriceEnginePublishPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.domain.motion.ability.BizIntelligentMotionEstimateAbility;
import com.taobao.ad.brand.bp.domain.priceEngine.PriceEngineRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;

@HSFProvider(serviceInterface = PriceEngineQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class PriceEngineQueryServiceImpl implements PriceEngineQueryService {

    private final PriceEngineRepository priceEngineRepository;

    private final BizIntelligentMotionEstimateAbility bizIntelligentMotionEstimateAbility;

    @Override
    public MultiResponse<PriceEnginePublishPriceViewDTO> getPublishPriceByProduct(Long publicationProductId, Integer saleUnit, List<Integer> resourceTypeValueList, Date startDate, Date endDate) {

        List<PriceEnginePublishPriceViewDTO> priceEnginePublishPriceViewDTOS = priceEngineRepository.getAdditionPublishPrice(publicationProductId, saleUnit, resourceTypeValueList, startDate, endDate);

        return MultiResponse.of(priceEnginePublishPriceViewDTOS);
    }

    @Override
    public SingleResponse<Map<String, Map<String, ResourcePackageProductPriceViewDTO>>> getProductBandPriceList(List<ResourcePackageProductViewDTO> resourcePackageProductList, Map<Long, ProductViewDTO> sspProductMap) {
        return SingleResponse.of(bizIntelligentMotionEstimateAbility.getProductBandPriceList(resourcePackageProductList, sspProductMap));
    }
}
