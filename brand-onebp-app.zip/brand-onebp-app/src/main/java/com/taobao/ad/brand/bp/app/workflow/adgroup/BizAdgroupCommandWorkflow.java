package com.taobao.ad.brand.bp.app.workflow.adgroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityInject;
import com.alibaba.abf.isolation.spec.common.ReduceType;
import com.alibaba.abf.isolation.utils.AbilityInvoker;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.adgroup.CreativeRefViewDTO;
import com.alibaba.ad.brand.dto.adgroup.crowd.AdgroupCrowdScenarioViewDTO;
import com.alibaba.ad.brand.dto.adgroup.crowd.AdgroupCrowdViewDTO;
import com.alibaba.ad.brand.dto.adgroup.resource.AdgroupResourceViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryLockViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupBottomTypeEnum;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupOnlineStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandInquiryStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativePackageTypeEnum;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativeShowAuditStatusEnum;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativeTargetTypeEnum;
import com.alibaba.ad.nb.ssp.constant.common.CrossSceneEnum;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alibaba.fastjson.JSON;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.error.ErrorCodeAware;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.app.businessability.MultiTargetDeliverBusinessAbility;
import com.taobao.ad.brand.bp.app.businessability.TargetBusinessAbility;
import com.taobao.ad.brand.bp.app.businessability.ThirdMonitorSupportBusinessAbility;
import com.taobao.ad.brand.bp.app.workflow.creative.BizCreativeCommandWorkflow;
import com.taobao.ad.brand.bp.app.workflow.creative.BizCreativeRefCommandWorkflow;
import com.taobao.ad.brand.bp.client.dto.adgroup.AdgroupWarnViewDTO;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryOption;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignBottomDateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignImpressionViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignTemplateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.enums.adgroup.AdgroupWarnEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.converter.adgroup.mapstruct.AdgroupViewMapStruct;
import com.taobao.ad.brand.bp.common.threadpooltask.AdgroupAddTaskIdentifier;
import com.taobao.ad.brand.bp.common.threadpooltask.AdgroupBatchOnlineTaskIdentifier;
import com.taobao.ad.brand.bp.common.threadpooltask.AdgroupGetWarningInfoTaskIdentifier;
import com.taobao.ad.brand.bp.common.threadpooltask.CreativeCopyAsDirectTaskIdentifier;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.BrandLocalDateTimeUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.adgroup.repository.AdgroupRepository;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeRepository;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.ability.param.BizAdgroupAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.*;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.*;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.query.IAdgroupStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.businessability.*;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.workflow.BizAdgroupCommandWorkflowExt;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.workflow.param.BizAdgroupDirectCreativeGenerateWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.workflow.param.BizAdgroupWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbilityRouteContext;
import com.taobao.ad.brand.bp.domain.sdk.base.workflow.Workflow;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignBottomDateGetAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignBottomDirectCreativeBuildAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignBottomDirectCreativeRefBuildAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignBottomSubCampaignGetAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.workflow.param.CreativeRefWorkflowParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizAdgroupCommandWorkflow extends Workflow {
    
    @AbilityInject(reduce = ReduceType.FIRST)
    private final BizAdgroupCommandWorkflowExt bizAdgroupCommandWorkflowExt;

    private final BizCreativeRefCommandWorkflow bizCreativeRefCommandWorkflow;
    private final BizCreativeCommandWorkflow bizCreativeCommandWorkflow;

    private final AdgroupRepository adgroupRepository;
    
    private final CampaignRepository campaignRepository;
    
    private final CreativeRepository creativeRepository;
    
    private final ResourcePackageRepository resourcePackageRepository;
    
    private final AdgroupBatchOnlineTaskIdentifier adgroupBatchOnlineTaskIdentifier;
    
    private final IAdgroupBottomJudgeAbility adgroupBottomJudgeAbility;
    
    private final CreativeCopyAsDirectTaskIdentifier creativeCopyAsDirectTaskIdentifier;
    
    private final AdgroupAddTaskIdentifier adgroupAddTaskIdentifier;
    
    private final AdgroupGetWarningInfoTaskIdentifier adgroupGetWarningInfoTaskIdentifier;
    
    private final IAdgroupBottomTitleInitAbility adgroupBottomTitleInitAbility;
    private final ICampaignStructureQueryAbility campaignStructureQueryAbility;
    private final IAdgroupPermissionDeleteValidateAbility adgroupPermissionDeleteValidateAbility;
    private final IAdgroupStructureQueryAbility adgroupStructureQueryAbility;
    private final IAdgroupBaseInitForAddBottomAdgroupAbility adgroupBaseInitForAddBottomAdgroupAbility;
    private final IAdgroupBaseInitForUpdateBottomAdgroupAbility adgroupBaseInitForUpdateBottomAdgroupAbility;
    private final IAdgroupBottomCrowdInitAbility adgroupBottomCrowdInitAbility;
    private final IAdgroupOnlineStatusUpdateValidateAbility adgroupOnlineStatusUpdateValidateAbility;
    private final IAdgroupDirectCreativeJudgeAbility adgroupDirectCreativeJudgeAbility;
    private final IAdgroupDirectCreativeGenerateValidateAbility adgroupDirectCreativeGenerateValidateAbility;
    private final ICampaignBottomSubCampaignGetAbility campaignBottomSubCampaignGetAbility;
    private final ICampaignBottomDateGetAbility campaignBottomDateGetAbility;
    private final ICampaignBottomDirectCreativeBuildAbility campaignBottomDirectCreativeBuildAbility;
    private final ICampaignBottomDirectCreativeRefBuildAbility campaignBottomDirectCreativeRefBuildAbility;
    private final IAdgroupUpdateAbility adgroupUpdateAbility;
    private final IAdgroupAddAbility adgroupAddAbility;

    /**
     * 添加单元
     *
     * @param context
     * @param adgroupViewDTO
     * @return 单元ID
     */
    public SingleResponse<Long> addAdgroup(ServiceContext context, AdgroupViewDTO adgroupViewDTO) {
        adgroupViewDTO.setSceneId(ServiceContextUtil.getSceneId(context));
        BizAdgroupWorkflowParam bizAdgroupWorkflowParam = bizAdgroupCommandWorkflowExt.buildParamForAddOrUpdate(context,
            adgroupViewDTO);
        bizAdgroupCommandWorkflowExt.beforeAdgroupAdd(context, adgroupViewDTO, bizAdgroupWorkflowParam);
        CreativeRefWorkflowParam creativeRefWorkflowParam = CreativeRefWorkflowParam.builder().campaignGroupViewDTO(bizAdgroupWorkflowParam.getCampaignGroupViewDTO())
                .campaignViewDTO(bizAdgroupWorkflowParam.getCampaignViewDTO())
                .adgroupViewDTO(adgroupViewDTO)
                .creativeViewDTOList(bizAdgroupWorkflowParam.getCreativeViewDTOList())
                .bottomDateViewDTOList(bizAdgroupWorkflowParam.getBottomDateViewDTOList()).build();
        bizCreativeRefCommandWorkflow.validateCreativeRef(context,creativeRefWorkflowParam);

        //商业能力挂载（前置）
        BusinessAbilityRouteContext businessAbilityRouteContext = BusinessAbilityRouteContext.builder()
                .packageSaleGroupViewDTO(bizAdgroupWorkflowParam.getPackageSaleGroupViewDTO())
                .resourcePackageProductViewDTO(bizAdgroupWorkflowParam.getResourcePackageProductViewDTO())
                .productViewDTO(bizAdgroupWorkflowParam.getProductViewDTO())
                .specifiedBusinessAbilityCodes(Lists.newArrayList(TargetBusinessAbility.ABILITY_CODE))
                .build();
        AbilityInvoker.invokeAll(IAdgroupAddBusinessAbilityPoint.class, businessAbilityRouteContext,
                callback -> callback.invokeForAdgroupAdd(context,adgroupViewDTO, bizAdgroupWorkflowParam.getCampaignViewDTO(), businessAbilityRouteContext));
        Long adgroupId = adgroupAddAbility.handle(context, AdgroupAddAbilityParam.builder().abilityTarget(adgroupViewDTO).build());

        //商业能力挂载（后置）
        AbilityInvoker.invokeAll(IAdgroupAddBusinessAbilityPoint.class, businessAbilityRouteContext,
                callback -> callback.invokeForAfterAdgroupAdd(context,adgroupViewDTO, bizAdgroupWorkflowParam.getCampaignViewDTO(), businessAbilityRouteContext));

        return SingleResponse.of(adgroupId);
    }

    /**
     * 添加单元
     *
     * @param context
     * @param adgroupViewDTO
     * @return 单元ID
     */
    public SingleResponse<Long> updateAdgroup(ServiceContext context, AdgroupViewDTO adgroupViewDTO) {
        adgroupViewDTO.setSceneId(ServiceContextUtil.getSceneId(context));
        BizAdgroupWorkflowParam bizAdgroupWorkflowParam = bizAdgroupCommandWorkflowExt.buildParamForAddOrUpdate(context,
            adgroupViewDTO);
        bizAdgroupCommandWorkflowExt.beforeAdgroupUpdate(context, adgroupViewDTO, bizAdgroupWorkflowParam);

        CreativeRefWorkflowParam creativeRefWorkflowParam = CreativeRefWorkflowParam.builder().campaignGroupViewDTO(bizAdgroupWorkflowParam.getCampaignGroupViewDTO())
                .campaignViewDTO(bizAdgroupWorkflowParam.getCampaignViewDTO())
                .adgroupViewDTO(adgroupViewDTO)
                .creativeViewDTOList(bizAdgroupWorkflowParam.getCreativeViewDTOList())
                .bottomDateViewDTOList(bizAdgroupWorkflowParam.getBottomDateViewDTOList()).build();
        bizCreativeRefCommandWorkflow.validateCreativeRef(context,creativeRefWorkflowParam);

        //商业能力挂载（前置）
        BusinessAbilityRouteContext businessAbilityRouteContext = BusinessAbilityRouteContext.builder()
                .packageSaleGroupViewDTO(bizAdgroupWorkflowParam.getPackageSaleGroupViewDTO())
                .resourcePackageProductViewDTO(bizAdgroupWorkflowParam.getResourcePackageProductViewDTO())
                .productViewDTO(bizAdgroupWorkflowParam.getProductViewDTO())
                .specifiedBusinessAbilityCodes(Lists.newArrayList(TargetBusinessAbility.ABILITY_CODE))
                .build();
        AbilityInvoker.invokeAll(IAdgroupUpdateBusinessAbilityPoint.class, businessAbilityRouteContext,
                callback -> callback.invokeForAdgroupUpdate(context,adgroupViewDTO, bizAdgroupWorkflowParam.getCampaignViewDTO(), businessAbilityRouteContext));

        BizAdgroupAbilityParam bizAdgroupAbilityParam = BizAdgroupAbilityParam.builder().dbAdgroupViewDTO(
                bizAdgroupWorkflowParam.getDbAdgroupViewDTO()).campaignViewDTO(bizAdgroupWorkflowParam.getCampaignViewDTO())
            .creativeViewDTOList(bizAdgroupWorkflowParam.getCreativeViewDTOList()).campaignGroupViewDTO(
                bizAdgroupWorkflowParam.getCampaignGroupViewDTO()).build();

        Long adgroupId = adgroupUpdateAbility.handle(context, AdgroupUpdateAbilityParam.builder().abilityTarget(adgroupViewDTO).campaignViewDTO(bizAdgroupWorkflowParam.getCampaignViewDTO()).build());

        //商业能力挂载（后置）
        AbilityInvoker.invokeAll(IAdgroupUpdateBusinessAbilityPoint.class, businessAbilityRouteContext,
                callback -> callback.invokeForAfterAdgroupUpdate(context,adgroupViewDTO, bizAdgroupWorkflowParam.getCampaignViewDTO(), businessAbilityRouteContext));

        bizAdgroupCommandWorkflowExt.afterAdgroupUpdate(context, adgroupViewDTO, bizAdgroupAbilityParam);
        return SingleResponse.of(adgroupId);
    }

    /**
     * 删除单元
     * @param context
     * @param id
     */
    public void deleteAdgroup(ServiceContext context, Long id) {
        AssertUtil.notNull(id,"参数不能为空");

        AdgroupViewDTO adgroupViewDTO= adgroupRepository.getAdgroupById(context,id);
        AssertUtil.assertTrue(null!=adgroupViewDTO,"未找到单元");

        this.batchDeleteAdgroup(context,Lists.newArrayList(id));
    }

    /**
     * 批量删除单元
     * @param context
     * @param ids
     * @return
     */
    public SingleResponse<Long> batchDeleteAdgroup(ServiceContext context, List<Long> ids) {
        AssertUtil.notNull(ids,"参数不能为空");
        //删除权限校验
        adgroupPermissionDeleteValidateAbility.handle(context, AdgroupPermissionDeleteValidateAbilityParam.builder().build());

        adgroupRepository.batchDeleteAdgroup(context,ids);
        creativeRepository.unBindCreative(context, ids);
        return SingleResponse.of(1L);
    }

    /**
     * 生成打底单元
     * @param serviceContext
     * @param campaignViewDTO
     * @return
     */
    public MultiResponse<AdgroupViewDTO> generateBottomAdgroup(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO){
        //1、是否构建打底单元
        Boolean needBottomAdgroup = adgroupBottomJudgeAbility.handle(serviceContext,
                AdgroupBottomJudgeAbilityParam.builder().abilityTarget(campaignViewDTO).build());

        MultiResponse<AdgroupViewDTO> response = MultiResponse.of(Lists.newArrayList());
        if(!needBottomAdgroup){
            response.setErrorMsg(String.format("计划ID:%s 无需创建打底单元",campaignViewDTO.getId()));
            return response;
        }
        //2、执行新建打底单元
        //先查询是否有打底单元,若有则直接返回
        List<AdgroupViewDTO> adgroupViewDTOList = adgroupStructureQueryAbility.handle(serviceContext, AdgroupStructureQueryAbilityParam.builder()
                .abilityTarget(AdgroupQueryViewDTO.builder().campaignId(campaignViewDTO.getId()).bottomType(BrandAdgroupBottomTypeEnum.BOTTOM.getCode()).build())
                .queryOption(AdgroupQueryOption.builder().needCreative(true).build()).build());
        if (CollectionUtils.isNotEmpty(adgroupViewDTOList)){
            RogerLogger.info("计划ID:{}下打底单元已经存在,单元ID:{}",campaignViewDTO.getId(),adgroupViewDTOList.get(0).getId());
            //存在打底单元则更新 更新日期和人群
            List<Long> errorAdgroupIdList = Lists.newArrayList();
            for (AdgroupViewDTO bottomAdgroupViewDTO : adgroupViewDTOList){
                try {
                    adgroupBaseInitForUpdateBottomAdgroupAbility.handle(serviceContext,
                            AdgroupBottomBaseInitAbilityParam.builder().abilityTarget(bottomAdgroupViewDTO).campaignViewDTO(campaignViewDTO).build());
                    bottomAdgroupViewDTO.setAdgroupCrowdScenarioViewDTO(Optional.ofNullable(bottomAdgroupViewDTO.getAdgroupCrowdScenarioViewDTO()).orElse(new AdgroupCrowdScenarioViewDTO()));
                    adgroupBottomCrowdInitAbility.handle(serviceContext, AdgroupBottomCrowdInitAbilityParam.builder().abilityTarget(bottomAdgroupViewDTO.getAdgroupCrowdScenarioViewDTO()).build());
                    this.updateAdgroup(serviceContext,bottomAdgroupViewDTO);
                    RogerLogger.info(String.format("计划ID:%s修改打底单元成功,单元ID:%s",campaignViewDTO.getId(),bottomAdgroupViewDTO.getId()));
                } catch (Exception e) {
                    errorAdgroupIdList.add(bottomAdgroupViewDTO.getId());
                    RogerLogger.error(String.format("计划ID:%s修改打底单元失败,单元ID:%s",campaignViewDTO.getId(),bottomAdgroupViewDTO.getId()),e);
                }
            }
            AssertUtil.assertTrue(errorAdgroupIdList.isEmpty(),String.format("打底单元（%s）修改失败，请稍后重试", JSON.toJSONString(errorAdgroupIdList)));
            response.setResult(adgroupViewDTOList);
            return response;
        }
        //新建打底单元
        AdgroupViewDTO adgroupViewDTO = new AdgroupViewDTO();
        adgroupBaseInitForAddBottomAdgroupAbility.handle(serviceContext,
                AdgroupBottomBaseInitAbilityParam.builder().abilityTarget(adgroupViewDTO).campaignViewDTO(campaignViewDTO).build());
        //打底单元无人群
        adgroupViewDTO.setAdgroupCrowdScenarioViewDTO(new AdgroupCrowdScenarioViewDTO());
        adgroupBottomCrowdInitAbility.handle(serviceContext, AdgroupBottomCrowdInitAbilityParam.builder().abilityTarget(adgroupViewDTO.getAdgroupCrowdScenarioViewDTO()).build());

        //生成单元标题
        String title = adgroupBottomTitleInitAbility.handle(serviceContext, AdgroupTitleInitAbilityParam.builder().abilityTarget(adgroupViewDTO)
                .dbCampaignViewDTO(campaignViewDTO).build());
        adgroupViewDTO.setTitle(title);

        SingleResponse<Long> addResponse = this.addAdgroup(serviceContext,adgroupViewDTO);
        AssertUtil.assertTrue(addResponse.isSuccess(),addResponse.getErrorMsg());
        RogerLogger.info("计划ID:{}创建打底单元成功,单元优化:{}",campaignViewDTO.getId(),addResponse.getResult());

        response.setResult(Lists.newArrayList(adgroupViewDTO));
        return response;
    }

    /**
     * 生成优化单元
     * <p>计划下需要自动创建一个优先级=1的默认单元，并将人群推荐策略中的所有人群默认挂在单元中</p>
     * @param serviceContext
     * @param campaignViewDTO
     * @return
     */
    public Response generateNReachAdgroup(ServiceContext serviceContext,CampaignViewDTO campaignViewDTO){
        BusinessAbilityRouteContext businessAbilityRouteContext = BusinessAbilityRouteContext.builder().specifiedBusinessAbilityCodes(Lists.newArrayList(MultiTargetDeliverBusinessAbility.ABILITY_CODE)).build();
        AdgroupViewDTO nReachAdgroupViewDTO = AbilityInvoker.invoke(IAdgroupNReachGenerateBusinessAbilityPoint.class, businessAbilityRouteContext,
                callback -> callback.invokeForGenerateNReachAdgroup(serviceContext, campaignViewDTO));
        if(Objects.isNull(nReachAdgroupViewDTO)){
            return Response.success(String.format("计划ID:%s 无需创建优化单元",campaignViewDTO.getId()));
        }
        if(nReachAdgroupViewDTO.getId() == null){
            SingleResponse<Long> response = this.addAdgroup(serviceContext,nReachAdgroupViewDTO);
            AssertUtil.assertTrue(response.isSuccess(),response.getErrorMsg());
            RogerLogger.info("计划ID:{}创建优化单元成功,单元ID:{}",campaignViewDTO.getId(),response.getResult());
        }else{
            this.updateAdgroup(serviceContext,nReachAdgroupViewDTO);
            RogerLogger.info(String.format("计划ID:%s修改优化单元成功,单元ID:%s",campaignViewDTO.getId(),nReachAdgroupViewDTO.getId()));
        }
        return Response.success();
    }

    /**
     * N+场景下，批量更新订单下单元人群定向
     * @param serviceContext
     * @param saleGroupInfoViewDTO
     */
    public void batchUpdateNReachAdgroupCrowd(ServiceContext serviceContext, SaleGroupInfoViewDTO saleGroupInfoViewDTO){
        //查询资源包分组
        ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO = resourcePackageRepository.getSaleGroupById(serviceContext, saleGroupInfoViewDTO.getSaleGroupId(),
                ResourcePackageQueryOption.builder().needSetting(true).needProduct(false).needInquiryPriority(false).build());
        AssertUtil.notNull(packageSaleGroupViewDTO, BrandOneBPBaseErrorCode.BIZ_DATA_EMPTY_ERROR, "资源售卖分组不存在，请检查");

        //执行商业能力挂载
        BusinessAbilityRouteContext businessAbilityRouteContext = BusinessAbilityRouteContext.builder().packageSaleGroupViewDTO(packageSaleGroupViewDTO).build();
        AbilityInvoker.invokeAll(IAdgroupNReachCrowdUpdateBusinessAbilityPoint.class, businessAbilityRouteContext,
                callback -> callback.invokeForUpdateNReachAdgroupCrowd(serviceContext,saleGroupInfoViewDTO, businessAbilityRouteContext));
    }

    /**
     * 批量设置单元为正式状态（草稿 -》正式）
     *
     * @param context
     * @param adgroupIds
     * @return 单元ID
     */
    public Response batchSetAdgroupOnline(ServiceContext context, List<Long> adgroupIds) {
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(adgroupIds), "单元id不允许为空");
        List<AdgroupViewDTO> adgroupList = adgroupStructureQueryAbility.handle(context, AdgroupStructureQueryAbilityParam.builder()
                .abilityTarget(AdgroupQueryViewDTO.builder().ids(adgroupIds).build())
                .queryOption(AdgroupQueryOption.builder().needTarget(true).needCreative(true).build())
                .build());
        AssertUtil.notEmpty(adgroupList, "查询单元不存在");

        List<SingleResponse<AdgroupViewDTO>> validateResponseList = TaskStream.execute(adgroupBatchOnlineTaskIdentifier, adgroupList, (adgroupViewDTO, index) -> {
            SingleResponse<AdgroupViewDTO> response = SingleResponse.of(adgroupViewDTO);
            try {
                adgroupViewDTO.setOnlineStatus(BrandAdgroupOnlineStatusEnum.ONLINE.getCode());
                BizAdgroupWorkflowParam bizAdgroupWorkflowParam = bizAdgroupCommandWorkflowExt.buildParamForAddOrUpdate(context, adgroupViewDTO);
                //校验单元
                bizAdgroupCommandWorkflowExt.beforeSetAdgroupOnline(context, adgroupViewDTO, bizAdgroupWorkflowParam);
                //校验创意
                CreativeRefWorkflowParam creativeRefWorkflowParam = CreativeRefWorkflowParam.builder().campaignGroupViewDTO(bizAdgroupWorkflowParam.getCampaignGroupViewDTO())
                        .campaignViewDTO(bizAdgroupWorkflowParam.getCampaignViewDTO())
                        .adgroupViewDTO(adgroupViewDTO)
                        .creativeViewDTOList(bizAdgroupWorkflowParam.getCreativeViewDTOList())
                        .bottomDateViewDTOList(bizAdgroupWorkflowParam.getBottomDateViewDTOList()).build();
                bizCreativeRefCommandWorkflow.validateCreativeRef(context, creativeRefWorkflowParam);

                //商业能力挂载
                BusinessAbilityRouteContext businessAbilityRouteContext = BusinessAbilityRouteContext.builder()
                        .specifiedBusinessAbilityCodes(Lists.newArrayList(TargetBusinessAbility.ABILITY_CODE)).build();
                AbilityInvoker.invokeAll(IAdgroupUpdateBusinessAbilityPoint.class, businessAbilityRouteContext,
                        callback -> callback.invokeForAdgroupUpdate(context,adgroupViewDTO, bizAdgroupWorkflowParam.getCampaignViewDTO(), businessAbilityRouteContext));

                return response;
            } catch (Exception e) {
                RogerLogger.error(String.format("batchSetOnline fail,memberId:%s, campaignId:%s, adgroupId：%s",
                        adgroupViewDTO.getMemberId(), adgroupViewDTO.getCampaignId(), adgroupViewDTO.getId()), e);
                ErrorCodeAware errorCodeAware = BrandOneBPException.getErrorCodeFromException(e);
                response.setErrorCode(errorCodeAware.getErrCode());
                response.setErrorMsg(errorCodeAware.getErrMsg());
                response.setSuccess(false);
                return response;
            }
        }).commit().getResultList();
        //校验成功、失败的单元
        List<AdgroupViewDTO> validAdgroupList = Lists.newArrayList();
        List<Long> inValidAdgroupIdList = Lists.newArrayList();
        List<String> errorMessageList = Lists.newArrayList();
        for (SingleResponse<AdgroupViewDTO> validateResponse : validateResponseList) {
            AdgroupViewDTO adgroupViewDTO = validateResponse.getResult();
            if(validateResponse.isSuccess()){
                validAdgroupList.add(adgroupViewDTO);
            }else{
                String errorMessage = String.format("【单元】%s%s",validateResponse.getResult().getId(),validateResponse.getErrorMsg());
                errorMessageList.add(errorMessage);
                inValidAdgroupIdList.add(adgroupViewDTO.getId());
            }
        }

        //更新单元
        if (CollectionUtils.isNotEmpty(validAdgroupList)) {
            List<Long> validAdgroupIdList = validAdgroupList.stream().map(AdgroupViewDTO::getId).collect(Collectors.toList());
            adgroupRepository.batchUpdateAdgroupStatus(context, validAdgroupIdList, BrandAdgroupOnlineStatusEnum.ONLINE.getCode());
            adgroupRepository.batchUpdateAdgroupViewDTOCrowdTag(context, validAdgroupList);
            RogerLogger.info("batchSetOnline success,ids={},status={}", JSON.toJSONString(validAdgroupIdList),
                BrandAdgroupOnlineStatusEnum.ONLINE.getCode());
        }
        AssertUtil.assertTrue(inValidAdgroupIdList.isEmpty(),
            String.format("已操作%s个单元，%s个成功，%s个失败,失败原因：%s", adgroupIds.size(), validAdgroupList.size(),
                inValidAdgroupIdList.size(), StringUtils.join(errorMessageList, ",")));
        return Response.success();
    }

    /**
     * 批量更新单元状态（开启、关闭）
     * @param context
     * @param adgroupList
     */
    public void batchUpdateAdgroupOnlineStatus(ServiceContext context, List<AdgroupViewDTO> adgroupList, Integer status){
        AssertUtil.notNull(BrandAdgroupOnlineStatusEnum.getByCode(status), "单元状态不合法");
        //上下线状态判断
        adgroupOnlineStatusUpdateValidateAbility.handle(context, AdgroupOnlineValidateAbilityParam.builder().abilityTargets(adgroupList).build());
        //更新单元 & 单元人群标识
        List<Long> ids = adgroupList.stream().map(AdgroupViewDTO::getId).collect(Collectors.toList());
        adgroupRepository.batchUpdateAdgroupStatus(context,ids, status);
        adgroupRepository.batchUpdateAdgroupCrowdTag(context,ids);
        RogerLogger.info("单元状态更新成功,ids={},status={}",JSON.toJSONString(ids),status);
    }

    /**
     * 添加单元
     * @param context
     * @param adgroupViewDTOList
     * @return 单元ID
     * */
    public Response batchAddAdgroup(ServiceContext context, List<AdgroupViewDTO> adgroupViewDTOList,  List<Long> campaignIdList, Integer inheritTime) {

        validateForBatchAdd(adgroupViewDTOList, campaignIdList);

        List<CampaignViewDTO> campaignViewDTOList = campaignRepository.queryCampaignList(context, CampaignQueryViewDTO.builder().campaignIds(campaignIdList).build());
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(campaignViewDTOList), BrandOneBPBaseErrorCode.PARAM_ILLEGAL,"未找到对应一级计划");

        Set<Long> failureCampaignIdSet = new HashSet<>();
        //计划与关联组的笛卡尔积，填充计划id、单元名称、时间
        List<AdgroupViewDTO> newAdgroupViewDTOList = initBatchAddAdgroupList(context, adgroupViewDTOList, inheritTime, campaignViewDTOList);

        //复用新建单元流程
        List<Long> list = TaskStream.execute(adgroupAddTaskIdentifier, newAdgroupViewDTOList, (adgroupViewDTO, index) -> {
            Long id = null;
            try {
                SingleResponse<Long> response = addAdgroup(context, adgroupViewDTO);
                id = response.getResult();
            } catch (BrandOneBPException e) {
                if (Objects.nonNull(adgroupViewDTO.getId())) {
                    //单元主表保存成功，人群、创意保存异常的情况，删除单元
                    adgroupRepository.deleteAdgroup(context, adgroupViewDTO.getId());
                }
                RogerLogger.error(String.format("batchAddAdgroup fail adgroupViewDTO: %s",JSON.toJSONString(adgroupViewDTO)), e);
                failureCampaignIdSet.add(adgroupViewDTO.getCampaignId());
            }
            return id;
        }).commit().getResultList();
        int num = (int) list.stream().filter(Objects::nonNull).count();
        AssertUtil.assertTrue(CollectionUtils.isEmpty(failureCampaignIdSet), String.format("已为您操作%s个单元批量绑定到%s个计划上，其中%s个单元保存成功，%s个单元保存失败。失败单元对应的计划ID为%s",
            adgroupViewDTOList.size()*campaignIdList.size(),campaignIdList.size(), num, adgroupViewDTOList.size()*campaignIdList.size()-num, StringUtils.join(failureCampaignIdSet, ",")));
        return Response.success();
    }

    /**
     * 生成单元打底创意（全域通黑盒PDB/GD场景）
     * @param serviceContext
     * @param adgroupViewDTO
     * @return
     */
    public Response generateAdgroupDirectCreative(ServiceContext serviceContext,AdgroupViewDTO adgroupViewDTO){
        //是否支持生成直投创意
        Boolean supportJudge = adgroupDirectCreativeJudgeAbility.handle(serviceContext, AdgroupDirectCreativeJudgeAbilityParam.builder().abilityTarget(adgroupViewDTO).build());
        if(!supportJudge){
            return Response.success();
        }
        //构建查询上下文参数
        BizAdgroupDirectCreativeGenerateWorkflowParam generateWorkflowParam = bizAdgroupCommandWorkflowExt.buildParamForGenerateDirectCreative(serviceContext, adgroupViewDTO);
        AssertUtil.notNull(generateWorkflowParam,"媒体直投创意生成依赖参数不能为空");

        CampaignViewDTO campaignTreeViewDTO = generateWorkflowParam.getCampaignTreeViewDTO();

        //直投创意生成校验
        adgroupDirectCreativeGenerateValidateAbility.handle(serviceContext, AdgroupDirectCreativeGenerateValidateAbilityParam.builder()
                .abilityTarget(adgroupViewDTO).campaignTreeViewDTO(campaignTreeViewDTO)
                .creativeViewDTOList(generateWorkflowParam.getCreativeViewDTOList()).build());

        //获取需要打底子计划
        List<CampaignViewDTO> subCampaignViewDTOList = campaignBottomSubCampaignGetAbility.handle(serviceContext, CampaignBottomSubCampaignGetAbilityParam.builder()
                .abilityTarget(campaignTreeViewDTO).campaignTemplateMap(generateWorkflowParam.getCampaignTemplateMap()).build());
        AssertUtil.notEmpty(subCampaignViewDTOList,String.format("计划下无三环PDB子计划，不做处理，计划id=%s",campaignTreeViewDTO.getId()));

        //获取子计划打底周期
        List<CampaignImpressionViewDTO.CampaignImpressionStatusEnum> noReadyStatusList = Lists.newArrayList(CampaignImpressionViewDTO.CampaignImpressionStatusEnum.NOT_ORDER,
                CampaignImpressionViewDTO.CampaignImpressionStatusEnum.UNQUALIFIED, CampaignImpressionViewDTO.CampaignImpressionStatusEnum.NOT_READY);
        List<CampaignBottomDateViewDTO> campaignBottomViewDTOList = campaignBottomDateGetAbility.handle(serviceContext, CampaignBottomDateGetAbilityParam.builder()
                .abilityTargets(subCampaignViewDTOList).noReadyStatusList(noReadyStatusList).build());

        //生成媒体直投创意&绑定到单元
        Map<Long, CampaignTemplateViewDTO> campaignTemplateMap = generateWorkflowParam.getCampaignTemplateMap();
        for (CampaignBottomDateViewDTO bottomDateViewDTO : campaignBottomViewDTOList) {
            if (CollectionUtils.isEmpty(bottomDateViewDTO.getBottomDateList())){
                RogerLogger.info("子计划ID:{}未查到打底日期，单元ID:{},计划ID:{}",bottomDateViewDTO.getSubCampaignId(),adgroupViewDTO.getId(),adgroupViewDTO.getCampaignId());
                continue;
            }
            CampaignViewDTO subCampaignViewDTO = campaignTreeViewDTO.getSubCampaignViewDTOList().stream()
                    .filter(subCampaign->subCampaign.getId().equals(bottomDateViewDTO.getSubCampaignId())).findFirst().orElse(null);
            CampaignTemplateViewDTO campaignTemplateViewDTO = campaignTemplateMap.get(bottomDateViewDTO.getSubCampaignId());
            List<CreativeViewDTO> creativeViewDTOList = generateWorkflowParam.getCreativeViewDTOList();
            try {
                List<CreativeViewDTO> allSubDirectCreativeList = this.generateDirectCreative(serviceContext, bottomDateViewDTO,subCampaignViewDTO,campaignTemplateViewDTO,creativeViewDTOList);
                if(CollectionUtils.isNotEmpty(allSubDirectCreativeList)){
                    this.bindDirectCreativeRefList(serviceContext, adgroupViewDTO,bottomDateViewDTO,allSubDirectCreativeList);
                }
            } catch (Exception e) {
                RogerLogger.error(String.format("单元媒体直投创意生成失败，单元id=%s,子计划id=%s,message=%s",
                        adgroupViewDTO.getId(),bottomDateViewDTO.getSubCampaignId(),e.getMessage()),e);
            }
        }
        return Response.success();
    }

    /**
     * 复制的程序化创意(全域黑盒)
     * 可用的创意，需要按照日期进行匹配，能匹配到哪天算哪天
     * 前置已经校验了，每天都需要有创意可以匹配到。但是并不一定可以审核通过。
     * @param serviceContext
     * @param campaignBottomDateViewDTO
     * @param campaignTreeViewDTO
     * @param campaignTemplateViewDTO
     * @param creativeViewDTOList
     */
    private List<CreativeViewDTO> generateDirectCreative(ServiceContext serviceContext,
                                                         CampaignBottomDateViewDTO bottomDateViewDTO,
                                                         CampaignViewDTO subCampaignViewDTO,
                                                         CampaignTemplateViewDTO  campaignTemplateViewDTO,
                                                         List<CreativeViewDTO> creativeViewDTOList){

        List<CreativeViewDTO> needAddDirectCreativeList = campaignBottomDirectCreativeBuildAbility.handle(serviceContext,
                CampaignBottomDirectCreativeBuildAbilityParam.builder().abilityTarget(bottomDateViewDTO).subCampaignViewDTO(subCampaignViewDTO)
                        .campaignTemplateViewDTO(campaignTemplateViewDTO).creativeViewDTOList(creativeViewDTOList)
                        .build());
        //新增媒体直投创意
        if(CollectionUtils.isNotEmpty(needAddDirectCreativeList)){
            List<Long> newDirectCreativeIds = TaskStream.execute(creativeCopyAsDirectTaskIdentifier, needAddDirectCreativeList, (creativeViewDTO, index) -> {
                Long subCreativeId = bizCreativeCommandWorkflow.copyCreativeAsDirect(serviceContext, creativeViewDTO);
                creativeViewDTO.setId(subCreativeId);
                return subCreativeId;
            }).commit().getResultList();
            RogerLogger.info("计划本次操作新增媒体直投创意，子计划ID:{},子创意id={}",bottomDateViewDTO.getSubCampaignId(),JSON.toJSONString(newDirectCreativeIds));
        }else{
            RogerLogger.info("计划本次操作不需要新增媒体直投创意，子计划ID:{}",bottomDateViewDTO.getSubCampaignId());
        }
        //根据模板匹配到的媒体审核通过的直投子创意
        List<CreativeViewDTO> allSubDirectCreativeList = creativeViewDTOList.stream()
                .filter(creativeViewDTO -> Objects.equals(BrandCreativePackageTypeEnum.PACKAGE.getValue(),creativeViewDTO.getPackageType()))
                .filter(creativeViewDTO -> CollectionUtils.isNotEmpty(creativeViewDTO.getSubCreativeViewDTOList()))
                .flatMap(creativeViewDTO -> creativeViewDTO.getSubCreativeViewDTOList().stream())
                .filter(subCreativeViewDTO -> campaignTemplateViewDTO.getTemplateIds().contains(subCreativeViewDTO.getCreativeTemplate().getSspTemplateId()))
                .filter(subCreativeViewDTO->Objects.equals(subCreativeViewDTO.getTargetType(), BrandCreativeTargetTypeEnum.DIRECT.getCode()))
                .filter(subCreativeViewDTO->Objects.equals(subCreativeViewDTO.getCreativeAudit().getShowAuditStatus(), BrandCreativeShowAuditStatusEnum.AUDIT_PASS.getCode()))
                .collect(Collectors.toList());
        allSubDirectCreativeList.addAll(needAddDirectCreativeList);

        return allSubDirectCreativeList;
    }

    /**
     * 绑定媒体直投创意
     * @param serviceContext
     * @param adgroupViewDTO
     * @param bottomDateViewDTO
     * @param subDirectCreativeViewDTOList
     */
    private void bindDirectCreativeRefList(ServiceContext serviceContext,AdgroupViewDTO adgroupViewDTO,CampaignBottomDateViewDTO bottomDateViewDTO,List<CreativeViewDTO> subDirectCreativeViewDTOList){
        List<CreativeRefViewDTO> creativeRefViewDTOList = campaignBottomDirectCreativeRefBuildAbility.handle(serviceContext, CampaignBottomDirectCreativeRefBuildAbilityParam.builder()
                .abilityTarget(bottomDateViewDTO).adgroupViewDTO(adgroupViewDTO).subCreativeViewDTOList(subDirectCreativeViewDTOList).build());
        RogerLogger.info("bindDirectCreativeRefList :{}",JSON.toJSONString(creativeRefViewDTOList));
        if (CollectionUtils.isNotEmpty(creativeRefViewDTOList)){
            creativeRepository.addBatchCreativeRefAndSetting(serviceContext,creativeRefViewDTOList);
            RogerLogger.info("主计划（id={}）单元（id={}）保存成功，打底创意={}",adgroupViewDTO.getCampaignId(),adgroupViewDTO.getId(), JSON.toJSONString(creativeRefViewDTOList));
        }
    }

    /**
     * 更新第三方监测
     * @param context
     * @param adgroupViewDTO
     */
    public void updateAdgroupMonitor(ServiceContext context, AdgroupViewDTO adgroupViewDTO){
        AbilityInvoker.invoke(IAdgroupThirdMonitorUpdateBusinessAbilityPoint.class,
                BusinessAbilityRouteContext.builder().specifiedBusinessAbilityCodes(Lists.newArrayList(ThirdMonitorSupportBusinessAbility.ABILITY_CODE)).build(),
                callback -> callback.invokeForUpdateThirdMonitor(context,adgroupViewDTO));
    }

    /**
     * 获取预警信息，
     * 目前只适用于草稿单元
     * @param context
     * @param
     * @return
     */
    public List<AdgroupWarnViewDTO> batchGetWarnList(ServiceContext context, List<Long> adgroupIds){
        if (CollectionUtils.isEmpty(adgroupIds)){
            return Lists.newArrayList();
        }
        AdgroupQueryOption queryOption = AdgroupQueryOption.builder().needCreative(true).needTarget(true).build();
        List<AdgroupViewDTO> adgroupViewDTOList = adgroupStructureQueryAbility.handle(context, AdgroupStructureQueryAbilityParam.builder()
                .abilityTarget(AdgroupQueryViewDTO.builder().ids(adgroupIds).build()).queryOption(queryOption).build());

        if(CollectionUtils.isEmpty(adgroupViewDTOList)){
            return Lists.newArrayList();
        }
        //草稿和全域通才走这个逻辑
        List<Integer> crossSceneList = Lists.newArrayList(CrossSceneEnum.CROSS_SCENE.getValue(), CrossSceneEnum.CROSS_OPAQUE_SCENE.getValue());
        List<AdgroupViewDTO> needToCheckAdgroupViewDTO =
                adgroupViewDTOList.stream()
                        .filter(item -> item.getAdgroupResourceViewDTO() != null && item.getAdgroupResourceViewDTO().getSspCrossScene() != null)
                        .filter(item -> crossSceneList.contains(item.getAdgroupResourceViewDTO().getSspCrossScene()))
                        .collect(Collectors.toList());
        if(CollectionUtils.isEmpty(needToCheckAdgroupViewDTO)){
            return Lists.newArrayList();
        }

        //按照计划ID分组
        List<AdgroupWarnViewDTO> adgroupWarnViewDTOList = TaskStream.execute(adgroupGetWarningInfoTaskIdentifier, needToCheckAdgroupViewDTO, (adgroupViewDTO, index) -> {
            adgroupViewDTO.setSceneId(ServiceContextUtil.getSceneId(context));
            BizAdgroupWorkflowParam bizAdgroupWorkflowParam = this.buildParamForAdgroupWarn(context,
                    adgroupViewDTO);
        AdgroupWarnEnum adgroupWarnEnum =  checkCrossOpaqueSceneBottomCreativeDateMix(bizAdgroupWorkflowParam.getCampaignViewDTO(),adgroupViewDTO,bizAdgroupWorkflowParam.getCreativeViewDTOList());
        if (Objects.nonNull(adgroupWarnEnum)) {
            AdgroupWarnViewDTO adgroupWarnViewDTO = new AdgroupWarnViewDTO();
            adgroupWarnViewDTO.setAdgroupId(adgroupViewDTO.getId());
            adgroupWarnViewDTO.setWarnCodeList(Lists.newArrayList(adgroupWarnEnum.getCode()));
            return adgroupWarnViewDTO;
        }
           return null;
        }).commit().getResultList().stream().filter(Objects::nonNull).collect(Collectors.toList());

        return adgroupWarnViewDTOList;

    }

    private BizAdgroupWorkflowParam buildParamForAdgroupWarn(ServiceContext serviceContext,
                                                            AdgroupViewDTO adgroupViewDTO) {
        BizAdgroupWorkflowParam bizAdgroupWorkflowParam = new BizAdgroupWorkflowParam();
        AssertUtil.notNull(adgroupViewDTO.getCampaignId(),"计划id不能为空");
        CampaignViewDTO campaignViewDTO = this.getCampaignInfoByOption(serviceContext,adgroupViewDTO.getCampaignId(), CampaignQueryOption.builder().needChildren(true).needTarget(true).build());
        AssertUtil.notNull(campaignViewDTO,"计划不能为空");
        bizAdgroupWorkflowParam.setCampaignViewDTO(campaignViewDTO);
        if (CollectionUtils.isNotEmpty(adgroupViewDTO.getCreativeRefViewDTOList())){
            List<Long> creativeIds = adgroupViewDTO.getCreativeRefViewDTOList().stream().map(CreativeRefViewDTO::getCreativeId).collect(Collectors.toList());
            List<CreativeViewDTO> creativeViewDTOList =  creativeRepository.findCreativeByIds(serviceContext,creativeIds);
            if(CollectionUtils.isNotEmpty(creativeViewDTOList)){
                bizAdgroupWorkflowParam.setCreativeViewDTOList(creativeViewDTOList);
            }
        }
        return bizAdgroupWorkflowParam;
    }

    @NotNull
    private List<AdgroupViewDTO> initBatchAddAdgroupList(ServiceContext context, List<AdgroupViewDTO> adgroupViewDTOList,
                                                         Integer inheritTime, List<CampaignViewDTO> campaignViewDTOList) {
        List<AdgroupViewDTO> newAdgroupViewDTOList = new ArrayList<>();
        int i = 0;
        for (CampaignViewDTO campaignViewDTO: campaignViewDTOList) {
            for (AdgroupViewDTO adgroupViewDTO: adgroupViewDTOList) {
                adgroupViewDTO.setSceneId(context.getAppId());
                AdgroupViewDTO newAdgroupViewDTO = AdgroupViewMapStruct.INSTANCE.sourceToTarget(adgroupViewDTO);
                newAdgroupViewDTO.setCampaignId(campaignViewDTO.getId());
                //单元名称
                formatBatchAdgroupTitle(campaignViewDTO, newAdgroupViewDTO, i);
                i++;
                //继承计划投放时间
                if (BrandBoolEnum.BRAND_TRUE.getCode().equals(inheritTime)) {
                    newAdgroupViewDTO.setStartTime(campaignViewDTO.getStartTime());
                    newAdgroupViewDTO.setEndTime(campaignViewDTO.getEndTime());
                }
                newAdgroupViewDTOList.add(newAdgroupViewDTO);

            }
        }
        return newAdgroupViewDTOList;
    }

    private static void validateForBatchAdd(List<AdgroupViewDTO> adgroupViewDTOList, List<Long> campaignIdList) {
        AssertUtil.assertTrue(campaignIdList.size()<=10, BrandOneBPBaseErrorCode.PARAM_ILLEGAL,"计划数量不能超过10个");
        AssertUtil.assertTrue(adgroupViewDTOList.size()<=10, BrandOneBPBaseErrorCode.PARAM_ILLEGAL,"关联组数量不能超过10个");
        for (AdgroupViewDTO adgroupViewDTO: adgroupViewDTOList) {
            if (BrandAdgroupOnlineStatusEnum.ONLINE.getCode().equals(adgroupViewDTO.getOnlineStatus())) {
                AssertUtil.assertTrue(CollectionUtils.isNotEmpty(adgroupViewDTO.getCreativeRefViewDTOList()),BrandOneBPBaseErrorCode.PARAM_ILLEGAL,"您未选择创意！请选择至少1个创意才能保存为正式");
            }
        }
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(campaignIdList), BrandOneBPBaseErrorCode.PARAM_ILLEGAL, "请选择计划");
    }

    private void formatBatchAdgroupTitle(CampaignViewDTO campaignViewDTO, AdgroupViewDTO newAdgroupViewDTO, int i) {
        String distinctValue = String.format("%02d", i)+"_"+System.currentTimeMillis();
        String campaignTitle = campaignViewDTO.getTitle();
        String adgroupTitle = "";

        //人群
        List<AdgroupCrowdViewDTO> adgroupCrowdViewDTOList = Optional.ofNullable(newAdgroupViewDTO.getAdgroupCrowdScenarioViewDTO())
                .map(AdgroupCrowdScenarioViewDTO::getAdgroupCrowdViewDTOList).orElse(null);

        if(StringUtils.isNotBlank(newAdgroupViewDTO.getTitle())) {
            adgroupTitle = newAdgroupViewDTO.getTitle();
        } else if (CollectionUtils.isNotEmpty(adgroupCrowdViewDTOList)) {
            if (adgroupCrowdViewDTOList.size() == 1) {
                adgroupTitle = newAdgroupViewDTO.getAdgroupCrowdScenarioViewDTO().getAdgroupCrowdViewDTOList().get(0).getCrowdName();
            } else {
                adgroupTitle = "多人群";
            }
        }
        //计划名称_单元名称后缀_日期_自增数字,长度超过100，优先删计划名称，其次删单元名称后缀
        if((campaignTitle +
            Constant.UNDERLINE + adgroupTitle +
            Constant.UNDERLINE + BrandDateUtil.date2String(new Date()) +
            Constant.UNDERLINE + distinctValue).length()<=100){
            String title = campaignTitle +
                Constant.UNDERLINE + adgroupTitle +
                Constant.UNDERLINE + BrandDateUtil.date2String(new Date()) +
                Constant.UNDERLINE + distinctValue;
            newAdgroupViewDTO.setTitle(title);
        } else if ((Constant.UNDERLINE + adgroupTitle +
            Constant.UNDERLINE + BrandDateUtil.date2String(new Date()) +
            Constant.UNDERLINE + distinctValue).length()<=100) {
            String title = Constant.UNDERLINE + adgroupTitle +
                Constant.UNDERLINE + BrandDateUtil.date2String(new Date()) +
                Constant.UNDERLINE + distinctValue;
            title = campaignTitle.substring(0,100-title.length()) + title;
            newAdgroupViewDTO.setTitle(title);
        } else {
            String title = Constant.UNDERLINE + BrandDateUtil.date2String(new Date()) +
                Constant.UNDERLINE + distinctValue;
            title = adgroupTitle.substring(0,100-title.length()) + title;
            newAdgroupViewDTO.setTitle(title);
        }
    }

    /**
     * 获取计划信息
     * @param serviceContext
     * @param id
     * @param option
     * @return
     */
    private CampaignViewDTO getCampaignInfoByOption(ServiceContext serviceContext,Long id,CampaignQueryOption option){
        CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder().campaignIds(Collections.singletonList(id)).build();
        List<CampaignViewDTO> dbCampaignViewDTOList = campaignStructureQueryAbility.handle(serviceContext,
                CampaignStructureQueryAbilityParam.builder().abilityTarget(campaignQueryViewDTO).queryOption(option).build());
        return CollectionUtils.isNotEmpty(dbCampaignViewDTOList) ? dbCampaignViewDTOList.get(0) : null;
    }



    public AdgroupWarnEnum checkCrossOpaqueSceneBottomCreativeDateMix(CampaignViewDTO campaignViewDTO, AdgroupViewDTO adgroupViewDTO,List<CreativeViewDTO> creativeViewDTOList){
        List<Integer> crossSceneList = Lists.newArrayList(CrossSceneEnum.CROSS_SCENE.getValue(), CrossSceneEnum.CROSS_OPAQUE_SCENE.getValue());
        Integer sspCrossScene = Optional.ofNullable(adgroupViewDTO.getAdgroupResourceViewDTO()).map(AdgroupResourceViewDTO::getSspCrossScene).orElse(null);
        if (sspCrossScene != null && crossSceneList.contains(sspCrossScene) && Objects.equals(BrandAdgroupBottomTypeEnum.BOTTOM.getCode(),adgroupViewDTO.getBottomType())){
            Set<String> creativeDateRangeSet = new HashSet<>();
            if (CollectionUtils.isEmpty(creativeViewDTOList)){
                return AdgroupWarnEnum.UN_SAVE_OFFICIAL;
            }
            for (CreativeViewDTO creativeViewDTO : creativeViewDTOList) {
                creativeDateRangeSet.addAll(BrandLocalDateTimeUtil.getBetweenDatesDateResult(creativeViewDTO.getStartTime(), creativeViewDTO.getEndTime()).stream().map(BrandLocalDateTimeUtil::date2String).collect(Collectors.toList()));
            }
            RogerLogger.info("checkCrossOpaqueSceneBottomCreativeDateMix creativeDateRangeSet:{}",JSON.toJSONString(creativeDateRangeSet));
            //查询计划的可投日期
            Set<String>  inquiryDateList = Optional.ofNullable(campaignViewDTO.getCampaignInquiryLockViewDTO())
                    .map(CampaignInquiryLockViewDTO::getCampaignInquiryViewDTOList).orElse(Lists.newArrayList())
                    .stream().filter(item-> BrandInquiryStatusEnum.SUCCESS.getCode().equals(item.getStatus()))
                    .filter(item->BrandDateUtil.isAfterAndEqual(item.getDate(),BrandDateUtil.getCurrentDate()))
                    .map(CampaignInquiryViewDTO::getDate).map(BrandDateUtil::date2String).collect(Collectors.toSet());
            RogerLogger.info("checkCrossOpaqueSceneBottomCreativeDateMix inquiryDateList:{}",JSON.toJSONString(inquiryDateList));

            if (CollectionUtils.isEmpty(inquiryDateList)){
                return AdgroupWarnEnum.UN_INQUIRED_DATE;
            }
            boolean result = CollectionUtils.containsAll(creativeDateRangeSet, inquiryDateList);
            RogerLogger.info("checkCrossOpaqueSceneBottomCreativeDateMix result:{}",result);

            if (!result){
                return AdgroupWarnEnum.UN_SAVE_OFFICIAL;
            }

        }
        return null;
    }


}
