package com.taobao.ad.brand.bp.app.handler.salegroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.fastjson.JSON;
import com.alibaba.hermes.framework.ddd.event.annotation.DomainEventHandler;
import com.alibaba.hermes.framework.event.EventHandler;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignCommandWorkflow;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.event.salegroup.SaleGroupResetCalculateUpdateEvent;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 订单分组重新计算分组预定量、单价等数据事件处理器
 * @author shiyan
 **/
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@DomainEventHandler(topic = "salegroup_reset_calculate_update_event", event = SaleGroupResetCalculateUpdateEvent.class)
public class SaleGroupResetCalculateUpdateProcessHandler implements EventHandler<SaleGroupResetCalculateUpdateEvent> {

    private final BizCampaignCommandWorkflow bizCampaignCommandWorkflow;
    private final ICampaignStructureQueryAbility campaignStructureQueryAbility;
    private final ResourcePackageRepository resourcePackageRepository;
    private final CampaignGroupRepository campaignGroupRepository;

    @Override
    public Response handle(SaleGroupResetCalculateUpdateEvent calculateUpdateEvent) {
        RogerLogger.info("salegroup_reset_calculate_update_event start:"+ JSON.toJSONString(calculateUpdateEvent));
        if (null == calculateUpdateEvent.getContext() || calculateUpdateEvent.getContext().getServiceContext() == null){
           return Response.success();
        }
        ServiceContext serviceContext = calculateUpdateEvent.getContext().getServiceContext();
        List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList = calculateUpdateEvent.getContext().getSaleGroupInfoViewDTOList();
        if(CollectionUtils.isEmpty(saleGroupInfoViewDTOList)){
            return Response.success();
        }
        List<Long> saleGroupIds = saleGroupInfoViewDTOList.stream().map(SaleGroupInfoViewDTO::getSaleGroupId).distinct().collect(Collectors.toList());
        if(CollectionUtils.isEmpty(saleGroupIds)){
            return Response.success();
        }
        CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder()
                .saleGroupIds(saleGroupIds).campaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode()).build();
        List<CampaignViewDTO> levelOneCampaignList = campaignStructureQueryAbility.handle(serviceContext, CampaignStructureQueryAbilityParam.builder()
                .abilityTarget(campaignQueryViewDTO).queryOption(CampaignQueryOption.builder().build()).build());
        if(CollectionUtils.isEmpty(levelOneCampaignList)){
            RogerLogger.info("一级计划不存在，分组id={}",JSON.toJSONString(saleGroupIds));
            return Response.success();
        }
        Map<Long, List<CampaignViewDTO>> saleGroupCampaignGroupMap = levelOneCampaignList.stream()
                .collect(Collectors.groupingBy(campaignViewDTO -> campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId()));

        for (SaleGroupInfoViewDTO saleGroupInfoViewDTO : saleGroupInfoViewDTOList) {
            List<CampaignViewDTO> campaignViewDTOList = saleGroupCampaignGroupMap.get(saleGroupInfoViewDTO.getSaleGroupId());
            if(CollectionUtils.isEmpty(campaignViewDTOList)){
                continue;
            }
            ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO =
                    resourcePackageRepository.getSaleGroupById(serviceContext,saleGroupInfoViewDTO.getSaleGroupId(), ResourcePackageQueryOption.builder().build());
            AssertUtil.notNull(resourcePackageSaleGroupViewDTO, "资源分组不存在");

            bizCampaignCommandWorkflow.rebuildCalSaleGroupInfo(serviceContext,resourcePackageSaleGroupViewDTO,saleGroupInfoViewDTO,campaignViewDTOList);
            campaignGroupRepository.addOrUpdateSaleGroupPart(serviceContext,saleGroupInfoViewDTO.getCampaignGroupId(),Lists.newArrayList(saleGroupInfoViewDTO));
        }
        return Response.success();
    }
}
