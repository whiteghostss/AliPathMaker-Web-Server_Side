package com.taobao.ad.brand.bp.app.workflow.motion;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.alibaba.ad.nb.packages.v2.client.constant.motion.MotionAttentionTargetEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.motion.StrategySourceEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.motion.StrategyStatusEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleProductLineEnum;
import com.alibaba.ad.nb.packages.v2.client.dto.salegroup.SaleGroupDeliveryTargetDTO;
import com.alimama.faas.brand.engine.entity.constant.BizType;
import com.alimama.faas.brand.engine.entity.domain.*;
import com.alimama.faas.brand.engine.entity.request.PreStrategyRcmdRequest;
import com.alimama.faas.brand.engine.entity.response.PreStrategyRcmdResponse;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignSaleGroupResourceDeliveryTargetViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.DmpArgusEstimateViewDTO;
import com.taobao.ad.brand.bp.client.dto.cartitem.query.CartItemQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.motion.*;
import com.taobao.ad.brand.bp.client.dto.motion.query.StrategyQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourceDistributionRuleViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSkuViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.query.BrandSkuQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.BrandDeliveryTargetEnum;
import com.taobao.ad.brand.bp.client.enums.EstimateDimensionTypeEnum;
import com.taobao.ad.brand.bp.common.enums.BooleanEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.CalculateUtil;
import com.taobao.ad.brand.bp.domain.cart.repository.CartItemRepository;
import com.taobao.ad.brand.bp.domain.config.SelfServiceTestMemberConfig;
import com.taobao.ad.brand.bp.domain.motion.IntelligentMotionRepository;
import com.taobao.ad.brand.bp.domain.motion.IntelligentStrategyRepository;
import com.taobao.ad.brand.bp.domain.motion.ability.BizIntelligentMotionEstimateAbility;
import com.taobao.ad.brand.bp.domain.perform.PerformRepository;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.workflow.Workflow;
import com.taobao.ad.brand.bp.domain.sdk.motion.workflow.param.BizIntelligentStrategyWorkflowParam;
import com.taobao.ad.brand.bp.domain.shopwindow.repository.BrandSkuRepository;
import com.taobao.ad.brand.perform.client.dto.shopwindow.spu.marketingrule.SpuCheckMarketingRuleViewDTO;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/25
 **/
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizIntelligentStrategyCommandWorkflow extends Workflow {

    private final IntelligentMotionRepository intelligentMotionRepository;
    private final IntelligentStrategyRepository intelligentStrategyRepository;
    private final ResourcePackageRepository resourcePackageRepository;
    private final PerformRepository performRepository;
    private final CartItemRepository cartItemRepository;
    private final BrandSkuRepository brandSkuRepository;
    private final BizIntelligentMotionEstimateAbility bizIntelligentMotionEstimateAbility;
    private final SelfServiceTestMemberConfig selfServiceTestMemberConfig;

    public void supplyPreStrategyRcmdResponse(ServiceContext serviceContext, IntelligentMotionViewDTO intelligentMotionViewDTO, PreStrategyRcmdResponse strategyRcmdResponse) {
        BizIntelligentStrategyWorkflowParam workflowParam = buildParamForSupplyPreStrategyRcmdResponse(serviceContext, intelligentMotionViewDTO.getCartItemIdList());
        List<SpuCheckMarketingRuleViewDTO> spuCheckMarketingRuleViewDTOList = performRepository.getCheckMarketingRule(serviceContext);
        Boolean testMemberId = CollectionUtils.isNotEmpty(selfServiceTestMemberConfig.getSelfSpuMarketingRuleMemberList()) && selfServiceTestMemberConfig.getSelfSpuMarketingRuleMemberList().contains(serviceContext.getMemberId());
        List<CartItemViewDTO> cartItemViewDTOList = workflowParam.getCartItemViewDTOList();
        Map<Long, Long> cartItemBudgetMap = Maps.newHashMap();
        //step1:门槛分配逻辑
        for (SpuCheckMarketingRuleViewDTO spuCheckMarketingRuleViewDTO : spuCheckMarketingRuleViewDTOList) {
            List<CartItemViewDTO> marketRuleCartItemList = cartItemViewDTOList.stream().filter(it -> spuCheckMarketingRuleViewDTO.getSpuIdList().contains(it.getSpuId())).collect(Collectors.toList());
            if (CollectionUtils.isNotEmpty(marketRuleCartItemList)) {
                Long totalBudget = 0L;
                for (CartItemViewDTO cartItemViewDTO : marketRuleCartItemList) {
                    cartItemBudgetMap.put(cartItemViewDTO.getId(), spuCheckMarketingRuleViewDTO.getBudget() / marketRuleCartItemList.size());
                    totalBudget += spuCheckMarketingRuleViewDTO.getBudget() / marketRuleCartItemList.size();
                }
                // 做倒减,加到第一个加购行上
                Long surplusBudget = spuCheckMarketingRuleViewDTO.getBudget() - totalBudget;
                AssertUtil.assertTrue(surplusBudget >= 0, "待分配金额为负数，门槛金额设置过低");
                cartItemBudgetMap.put(marketRuleCartItemList.get(0).getId(), cartItemBudgetMap.get(marketRuleCartItemList.get(0).getId()) + surplusBudget);
            }
        }

        List<CartItemViewDTO> superUniverseCartItemViewDTOList = cartItemViewDTOList.stream().filter(cartItemViewDTO -> judgeSuperUniverseSaleProductLine(serviceContext, workflowParam, cartItemViewDTO)).collect(Collectors.toList());

        //step2:剩余全域通分配逻辑
        if (!testMemberId && CollectionUtils.isNotEmpty(superUniverseCartItemViewDTOList)) {
            superUniverseCartItemViewDTOList.forEach(it -> cartItemBudgetMap.put(it.getId(), (cartItemBudgetMap.containsKey(it.getId()) ? Math.max(cartItemBudgetMap.get(it.getId()), 10000000L) : 10000000L)));
        }

        Long allocateBudget = MapUtils.isEmpty(cartItemBudgetMap) ? intelligentMotionViewDTO.getBudget() : intelligentMotionViewDTO.getBudget() - cartItemBudgetMap.values().stream().reduce(0L, Long::sum);
        AssertUtil.assertTrue(allocateBudget >= 0, "剩余全域通分配后，待分配金额为负数");
        //step3:剩余金额均分逻辑
        for (CartItemViewDTO cartItemViewDTO : workflowParam.getCartItemViewDTOList()) {
            if (cartItemBudgetMap.containsKey(cartItemViewDTO.getId())) {
                cartItemBudgetMap.put(cartItemViewDTO.getId(), cartItemBudgetMap.get(cartItemViewDTO.getId()) + allocateBudget / cartItemViewDTOList.size());
            } else {
                cartItemBudgetMap.put(cartItemViewDTO.getId(), allocateBudget / cartItemViewDTOList.size());
            }
        }
        // 做倒减,加到第一个加购行上
        Long surplusBudget = intelligentMotionViewDTO.getBudget() - cartItemBudgetMap.values().stream().reduce(0L, Long::sum);
        AssertUtil.assertTrue(surplusBudget >= 0, "待分配金额为负数，提案金额设置过低");
        cartItemBudgetMap.put(cartItemViewDTOList.get(0).getId(), cartItemBudgetMap.get(cartItemViewDTOList.get(0).getId()) + surplusBudget);


        List<ResourceConfig> resourcePackageConfigList = cartItemViewDTOList.stream().map(it -> getResourceConfig(workflowParam, intelligentMotionViewDTO, it, cartItemBudgetMap.get(it.getId()))).collect(Collectors.toList());

        PreStrategyRcmdRequest preStrategyRcmdRequest = new PreStrategyRcmdRequest();
        preStrategyRcmdRequest.setProposalId(strategyRcmdResponse.getProposalId());
        preStrategyRcmdRequest.setResourcePackageConfigList(resourcePackageConfigList);
        strategyRcmdResponse.setProposalList(Lists.newArrayList(preStrategyRcmdRequest));
    }

    public Boolean judgeSuperUniverseSaleProductLine(ServiceContext serviceContext, BizIntelligentStrategyWorkflowParam workflowParam, CartItemViewDTO cartItemViewDTO) {
        Long skuId = workflowParam.getCartAndSkuMap().get(cartItemViewDTO.getId());
        AssertUtil.assertTrue(workflowParam.getSkuAndResourceProductMap().containsKey(skuId) && workflowParam.getResourcePackageProductViewDTOMap().containsKey(workflowParam.getSkuAndResourceProductMap().get(skuId)), "加购行对应的SKU不存在，或者SKU对应的招商分组二级产品不存在");
        ResourcePackageProductViewDTO resourcePackageProductViewDTO = workflowParam.getResourcePackageProductViewDTOMap().get(workflowParam.getSkuAndResourceProductMap().get(skuId));
        Integer saleProductLine = workflowParam.getSaleGroupSaleProductLineMap().get(resourcePackageProductViewDTO.getSaleGroupId());
        return SaleProductLineEnum.SUPER_UNIVERSE.getValue().equals(saleProductLine);
    }

    private ResourceConfig getResourceConfig(BizIntelligentStrategyWorkflowParam workflowParam, IntelligentMotionViewDTO intelligentMotionViewDTO, CartItemViewDTO cartItemViewDTO, Long budget) {
        Long skuId = workflowParam.getCartAndSkuMap().get(cartItemViewDTO.getId());
        AssertUtil.assertTrue(workflowParam.getSkuAndResourceProductMap().containsKey(skuId) && workflowParam.getResourcePackageProductViewDTOMap().containsKey(workflowParam.getSkuAndResourceProductMap().get(skuId)), "加购行对应的SKU不存在，或者SKU对应的招商分组二级产品不存在");
        ResourcePackageProductViewDTO resourcePackageProductViewDTO = workflowParam.getResourcePackageProductViewDTOMap().get(workflowParam.getSkuAndResourceProductMap().get(skuId));
        ResourceConfig resourceConfig = new ResourceConfig();
        resourceConfig.setResourceProductId(resourcePackageProductViewDTO.getId());
        resourceConfig.setSspProductId(resourcePackageProductViewDTO.getSspProductId());
        AssertUtil.assertTrue(Objects.nonNull(resourcePackageProductViewDTO.getCastType()) && Objects.nonNull(resourcePackageProductViewDTO.getCastType().getType()), "加购行对应的SKU对应的招商分组二级产品未设置投放方式");
        resourceConfig.setCastType(resourcePackageProductViewDTO.getCastType().getType());
        resourceConfig.setCartId(cartItemViewDTO.getId());
        resourceConfig.setBudget(budget);
        // 是否有重叠日期
        List<ResourcePackageProductPriceViewDTO> bandPriceList = resourcePackageProductViewDTO.getBandPriceList().stream().filter(bandPrice -> BrandDateUtil.getMixedDate(bandPrice.getStartDate(), bandPrice.getEndDate(), intelligentMotionViewDTO.getStartTime(), intelligentMotionViewDTO.getEndTime()).size() > 0).collect(Collectors.toList());
        List<PriceStageConfig> priceStageList = bandPriceList.stream().map(bandPrice -> {
            PriceStageConfig priceStageConfig = new PriceStageConfig();
            priceStageConfig.setResourceStartTime(bandPrice.getStartDate().before(intelligentMotionViewDTO.getStartTime()) ? intelligentMotionViewDTO.getStartTime() : bandPrice.getStartDate());
            priceStageConfig.setResourceEndTime(bandPrice.getEndDate().after(intelligentMotionViewDTO.getEndTime()) ? intelligentMotionViewDTO.getEndTime() : bandPrice.getEndDate());
            priceStageConfig.setBudget(resourceConfig.getBudget() / bandPriceList.size());
            priceStageConfig.setSettlePrice(bandPrice.getPrice());
            return priceStageConfig;
        }).collect(Collectors.toList());
        // 做倒减,加到第一个加购行上
        Long surplusBudget = resourceConfig.getBudget() - priceStageList.stream().mapToLong(PriceStageConfig::getBudget).sum();
        AssertUtil.assertTrue(surplusBudget >= 0, "待分配金额为负数，产品预算设置过低");
        priceStageList.get(0).setBudget(priceStageList.get(0).getBudget() + surplusBudget);
        resourceConfig.setPriceStageList(priceStageList);
        return resourceConfig;
    }

    public BizIntelligentStrategyWorkflowParam buildParamForSupplyPreStrategyRcmdResponse(ServiceContext serviceContext, List<Long> cartItemIdList) {
        AssertUtil.notEmpty(cartItemIdList, "加购行不允许为空");
        List<CartItemViewDTO> cartItemViewDTOList = cartItemRepository.findCartList(serviceContext, CartItemQueryViewDTO.builder().idList(cartItemIdList).build());
        AssertUtil.notEmpty(cartItemViewDTOList, "加购行列表不允许为空");
        Map<Long, Long> cartAndSkuMap = cartItemViewDTOList.stream().collect(Collectors.toMap(CartItemViewDTO::getId, CartItemViewDTO::getSkuId, (v1, v2) -> v1));
        List<BrandSkuViewDTO> brandSkuViewDTOList = brandSkuRepository.findSkuList(serviceContext, BrandSkuQueryViewDTO.builder().idList(cartItemViewDTOList.stream().map(CartItemViewDTO::getSkuId).collect(Collectors.toList())).build());
        AssertUtil.notEmpty(brandSkuViewDTOList, "加购行对应sku列表不允许为空");
        Map<Long, Long> skuAndResourceProductMap = brandSkuViewDTOList.stream().collect(Collectors.toMap(BrandSkuViewDTO::getId, BrandSkuViewDTO::getResourcePackageProductId, (v1, v2) -> v1));

        List<ResourcePackageProductViewDTO> resourcePackageProductViewDTOList = resourcePackageRepository.getLevelOneResourcePackageProductList(serviceContext, brandSkuViewDTOList.stream().map(BrandSkuViewDTO::getResourcePackageProductId).collect(Collectors.toList()));
        AssertUtil.notEmpty(resourcePackageProductViewDTOList, "sku对应打包平台二级产品列表不允许为空");
        Map<Long, ResourcePackageProductViewDTO> resourcePackageProductViewDTOMap = resourcePackageProductViewDTOList.stream().collect(Collectors.toMap(ResourcePackageProductViewDTO::getId, Function.identity(), (v1, v2) -> v1));
        List<Long> resourcePackageSaleGroupIdList = resourcePackageProductViewDTOList.stream().map(ResourcePackageProductViewDTO::getSaleGroupId).distinct().collect(Collectors.toList());
        Map<Long, Integer> saleGroupSaleProductLineMap = resourcePackageRepository.getSaleGroupList(serviceContext, resourcePackageSaleGroupIdList, ResourcePackageQueryOption.builder().needProduct(Boolean.FALSE).needInquiryPriority(Boolean.FALSE).needSetting(Boolean.FALSE).build()).stream().collect(Collectors.toMap(ResourcePackageSaleGroupViewDTO::getId, ResourcePackageSaleGroupViewDTO::getSaleProductLine));

        BizIntelligentStrategyWorkflowParam strategyWorkflowParam = new BizIntelligentStrategyWorkflowParam();
        strategyWorkflowParam.setCartItemViewDTOList(cartItemViewDTOList);
        strategyWorkflowParam.setCartAndSkuMap(cartAndSkuMap);
        strategyWorkflowParam.setBrandSkuViewDTOList(brandSkuViewDTOList);
        strategyWorkflowParam.setSkuAndResourceProductMap(skuAndResourceProductMap);
        strategyWorkflowParam.setSaleGroupSaleProductLineMap(saleGroupSaleProductLineMap);
        strategyWorkflowParam.setResourcePackageProductViewDTOMap(resourcePackageProductViewDTOMap);

        return strategyWorkflowParam;
    }

    public void saveIntelligentStrategyResult(ServiceContext context, PreStrategyRcmdResponse strategyRcmdResponse) {
        List<PreStrategyRcmdRequest> strategyList = strategyRcmdResponse.getProposalList();
        AssertUtil.notEmpty(strategyList, "策略列表不能为空");
        AssertUtil.notNull(strategyRcmdResponse.getProposalId(), "智能提案不能为空");
        strategyList.forEach(strategy -> {
            BizType bizType = strategyRcmdResponse.getBizType();
            IntelligentStrategyViewDTO strategyViewDTO = new IntelligentStrategyViewDTO();
            //自定义策略预先创建策略实体,需要更新到现有策略实体
            if (strategy.getStrategyId() != null) {
                List<IntelligentStrategyViewDTO> intelligentStrategyViewDTOList = intelligentStrategyRepository.queryIntelligentStrategyList(context
                        , StrategyQueryViewDTO.builder().idList(Lists.newArrayList(strategy.getStrategyId())).build());
                if (CollectionUtils.isNotEmpty(intelligentStrategyViewDTOList)) {
                    strategyViewDTO.setId(strategy.getStrategyId());
                    strategyViewDTO.setName(intelligentStrategyViewDTOList.get(0).getName());
                }
            }
            strategyViewDTO.setSource(!BooleanEnum.FALSE.getValue().equals(strategyRcmdResponse.getErrorCode()) ? StrategySourceEnum.SYSTEM_RULE.getValue() : StrategySourceEnum.CALCULATE.getValue());
            fillStrategyViewDTOBaseInfo(bizType, strategy, strategyViewDTO);
            if (!BizType.BRAND_WINDOW_RECOMMEND.equals(bizType)) {
                strategyViewDTO.setPredictDataViewDTO(buildPredictDataViewDTO(strategy.getDeliverTargetResult()));
                strategyViewDTO.setMarketingStageViewDTOList(getMarketingStageViewDTOList(strategy.getMarketingStageList()));
                strategyViewDTO.setMediaStrategyViewDTOList(getMediaStrategyViewDTOList(strategy.getMediaEffectList()));
                strategyViewDTO.setResourceProductStrategyViewDTOList(getResourceProductStrategyViewDTOList(strategy.getResourceEffectList()));
            }
            strategyViewDTO.setDistributionRuleDTOList(getDistributionRuleViewDTOList(strategy.getResourcePackageConfigList(),strategy.getClassificationResourceList()));

            IntelligentMotionViewDTO motionViewDTO = intelligentMotionRepository.getIntelligentMotionById(context, strategyRcmdResponse.getProposalId());
            AssertUtil.notNull(motionViewDTO, "智能提案不存在");
            if (motionViewDTO.getSaleGroupId() != null) {
                ResourcePackageSaleGroupViewDTO saleGroupViewDTO = resourcePackageRepository.getSaleGroupById(context, motionViewDTO.getSaleGroupId(), ResourcePackageQueryOption.builder().needProduct(Boolean.TRUE).needSetting(Boolean.TRUE).build());
                AssertUtil.notNull(motionViewDTO, "售卖分组不存在");
                strategyViewDTO.setNewDeliveryTargetList(saleGroupViewDTO.getResourceDeliveryTargetList());
                Map<String, String> categoryNameMap = saleGroupViewDTO.getDistributionRuleList().stream()
                        .collect(Collectors.toMap(ResourceDistributionRuleViewDTO::getCategory, ResourceDistributionRuleViewDTO::getCategoryName, (a, b) -> a));
                strategyViewDTO.getDistributionRuleDTOList().forEach(it -> {
                    it.setCategoryName(categoryNameMap.getOrDefault(it.getCategory(), it.getCategory()));
                });
            }
            intelligentStrategyRepository.saveIntelligentStrategy(context, strategyViewDTO);
        });
    }

    private List<ResourceProductStrategyViewDTO> getResourceProductStrategyViewDTOList(List<ResourceEffect> resourceEffectList) {
        AssertUtil.notEmpty(resourceEffectList, "资源产品集合不能为空");
        List<ResourceProductStrategyViewDTO> resourceProductStrategyViewDTOList = Lists.newArrayList();
        resourceEffectList.forEach(it -> {
            ResourceProductStrategyViewDTO resourceProductStrategy = new ResourceProductStrategyViewDTO();
            resourceProductStrategy.setResourceProductId(it.getProductId());
            resourceProductStrategy.setCastType(it.getCastType());
            InsightDataViewDTO insightDataViewDTO = new InsightDataViewDTO();
            resourceProductStrategy.setInsightDataViewDTO(insightDataViewDTO);
            it.getSiteEffect().forEach((key, value) -> {
                switch (key) {
                    case TA_C:
                        insightDataViewDTO.setTaResourceProductCoverage(value);
                        break;
                    case TA_R:
                        insightDataViewDTO.setTaResourceProductConcentration(value);
                        break;
                    case CPM:
                        insightDataViewDTO.setCpmPrice(value);
                        break;
                    case CLK_R:
                        insightDataViewDTO.setClkMonitorRate(value);
                        break;
                    case ARR_R:
                        insightDataViewDTO.setLandPvRate(value);
                        break;
                    case SV_R:
                        insightDataViewDTO.setSearchAndVisitRate(value);
                        break;
                    case CC_R:
                        insightDataViewDTO.setCollectAddPurchaseRate(value);
                        break;
                    case DAL_R:
                        insightDataViewDTO.setDealRate(value);
                        break;
                    case MD_C:
                        insightDataViewDTO.setResourceProductAmount(value);
                    default:
                        break;
                }
            });
            resourceProductStrategyViewDTOList.add(resourceProductStrategy);
        });
        return resourceProductStrategyViewDTOList;
    }

    private void fillStrategyViewDTOBaseInfo(BizType bizType, PreStrategyRcmdRequest strategy, IntelligentStrategyViewDTO strategyViewDTO) {
        if (BizType.PRE_RESOURCE_RECOMMEND_PRICE_STAGE.equals(bizType)) {
            strategyViewDTO.setName("策略" + "-" + MotionAttentionTargetEnum.getDesc(strategy.getProposalTarget().getId()));
        }
        //页面创建自定义策略设置了名称
        if (BizType.PRE_RESOURCE_ESTIMATE_PRICE_STAGE.equals(bizType) && StringUtils.isBlank(strategyViewDTO.getName())) {
            strategyViewDTO.setName("自定义策略" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm-ss")));
        }
        if (BizType.BRAND_WINDOW_RECOMMEND.equals(bizType)) {
            strategyViewDTO.setName("智能预算分配策略" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm-ss")));
        }
        if (Objects.nonNull(strategy.getProposalTarget())) {
            strategyViewDTO.setStrategyTarget(strategy.getProposalTarget().getId());
        }
        strategyViewDTO.setStatus(StrategyStatusEnum.NEW.getValue());
        strategyViewDTO.setMotionId(strategy.getProposalId());
    }

    private List<MarketingStageViewDTO> getMarketingStageViewDTOList(List<MarketingStageConfig> marketingStageList) {
        List<MarketingStageViewDTO> marketingStageViewDTOList = Lists.newArrayList();
        if (CollectionUtils.isEmpty(marketingStageList)) {
            return marketingStageViewDTOList;
        }
        for (MarketingStageConfig marketingStageConfig : marketingStageList) {
            MarketingStageViewDTO marketingStageViewDTO = new MarketingStageViewDTO();
            marketingStageViewDTO.setName(marketingStageConfig.getStageName());
            marketingStageViewDTO.setRatio(marketingStageConfig.getStageRatio());
            marketingStageViewDTO.setStartTime(marketingStageConfig.getStartTime());
            marketingStageViewDTO.setEndTime(marketingStageConfig.getEndTime());

            if (Objects.nonNull(marketingStageConfig.getMediaBudget()) && !marketingStageConfig.getMediaBudget().isEmpty()) {
                List<MediaStrategyViewDTO> mediaStrategyViewDTOList = Lists.newArrayList();
                Set<Long> siteIds = new HashSet<>(marketingStageConfig.getMediaBudget().keySet());
                siteIds.addAll(marketingStageConfig.getMediaAmount().keySet());
                siteIds.forEach(siteId -> {
                    MediaStrategyViewDTO mediaStrategyViewDTO = new MediaStrategyViewDTO();
                    mediaStrategyViewDTO.setSiteId(siteId);
                    mediaStrategyViewDTO.setBudget(marketingStageConfig.getMediaBudget().get(siteId));
                    mediaStrategyViewDTO.setPredictDataViewDTO(new PredictDataViewDTO());
                    mediaStrategyViewDTO.getPredictDataViewDTO().setImpPv(marketingStageConfig.getMediaAmount().get(siteId));
                    mediaStrategyViewDTOList.add(mediaStrategyViewDTO);
                });
                marketingStageViewDTO.setMediaStrategyViewDTOList(mediaStrategyViewDTOList);
            }
            if (Objects.nonNull(marketingStageConfig.getResourceBudget()) && !marketingStageConfig.getResourceBudget().isEmpty()) {
                List<ResourceTypeStrategyViewDTO> resourceTypeStrategyViewDTOList = Lists.newArrayList();
                Set<Integer> resourceTypeSet = new HashSet<>(marketingStageConfig.getResourceBudget().keySet());
                resourceTypeSet.addAll(marketingStageConfig.getResourceAmount().keySet());
                resourceTypeSet.forEach(resourceType -> {
                    ResourceTypeStrategyViewDTO resourceTypeStrategyViewDTO = new ResourceTypeStrategyViewDTO();
                    resourceTypeStrategyViewDTO.setResourceType(resourceType);
                    resourceTypeStrategyViewDTO.setBudget(marketingStageConfig.getResourceBudget().get(resourceType));
                    resourceTypeStrategyViewDTO.setPredictDataViewDTO(new PredictDataViewDTO());
                    resourceTypeStrategyViewDTO.getPredictDataViewDTO().setImpPv(marketingStageConfig.getResourceAmount().get(resourceType));
                    resourceTypeStrategyViewDTOList.add(resourceTypeStrategyViewDTO);
                });
                marketingStageViewDTO.setResourceTypeStrategyViewDTOList(resourceTypeStrategyViewDTOList);
                marketingStageViewDTOList.add(marketingStageViewDTO);
            }
        }
        return marketingStageViewDTOList;
    }

    private List<MediaStrategyViewDTO> getMediaStrategyViewDTOList(List<AdvertisingEffect> mediaEffectList) {
        Set<Long> siteIds = mediaEffectList.stream().flatMap(it -> it.getSiteEffect().keySet().stream()).collect(Collectors.toSet());
        AssertUtil.notEmpty(siteIds, "媒体集合不能为空");
        Map<Long, MediaStrategyViewDTO> mediaStrategyViewDTOMap = siteIds.stream().map(it -> {
            MediaStrategyViewDTO mediaStrategyViewDTO = new MediaStrategyViewDTO();
            mediaStrategyViewDTO.setMediaInsightDataViewDTO(new InsightDataViewDTO());
            mediaStrategyViewDTO.setSiteId(it);
            return mediaStrategyViewDTO;
        }).collect(Collectors.toMap(MediaStrategyViewDTO::getSiteId, it -> it, (v1, v2) -> v1));
        if (CollectionUtils.isNotEmpty(mediaEffectList)) {
            mediaEffectList.forEach(it -> {
                switch (it.getEffectId()) {
                    case TA_C:
                        it.getSiteEffect().forEach((key, value) -> {
                            MediaStrategyViewDTO mediaStrategyViewDTO = mediaStrategyViewDTOMap.get(key);
                            if (Objects.nonNull(mediaStrategyViewDTO)) {
                                mediaStrategyViewDTO.getMediaInsightDataViewDTO().setTaMediaCoverage(value);
                            }
                        });
                        break;
                    case TA_R:
                        it.getSiteEffect().forEach((key, value) -> {
                            MediaStrategyViewDTO mediaStrategyViewDTO = mediaStrategyViewDTOMap.get(key);
                            if (Objects.nonNull(mediaStrategyViewDTO)) {
                                mediaStrategyViewDTO.getMediaInsightDataViewDTO().setTaMediaConcentration(value);
                            }
                        });
                        break;
                    case CPM:
                        it.getSiteEffect().forEach((key, value) -> {
                            MediaStrategyViewDTO mediaStrategyViewDTO = mediaStrategyViewDTOMap.get(key);
                            if (Objects.nonNull(mediaStrategyViewDTO)) {
                                mediaStrategyViewDTO.getMediaInsightDataViewDTO().setCpmPrice(value);
                            }
                        });
                        break;
                    case CLK_R:
                        it.getSiteEffect().forEach((key, value) -> {
                            MediaStrategyViewDTO mediaStrategyViewDTO = mediaStrategyViewDTOMap.get(key);
                            if (Objects.nonNull(mediaStrategyViewDTO)) {
                                mediaStrategyViewDTO.getMediaInsightDataViewDTO().setClkMonitorRate(value);
                            }
                        });
                        break;
                    case ARR_R:
                        it.getSiteEffect().forEach((key, value) -> {
                            MediaStrategyViewDTO mediaStrategyViewDTO = mediaStrategyViewDTOMap.get(key);
                            if (Objects.nonNull(mediaStrategyViewDTO)) {
                                mediaStrategyViewDTO.getMediaInsightDataViewDTO().setLandPvRate(value);
                            }
                        });
                        break;
                    case SV_R:
                        it.getSiteEffect().forEach((key, value) -> {
                            MediaStrategyViewDTO mediaStrategyViewDTO = mediaStrategyViewDTOMap.get(key);
                            if (Objects.nonNull(mediaStrategyViewDTO)) {
                                mediaStrategyViewDTO.getMediaInsightDataViewDTO().setSearchAndVisitRate(value);
                            }
                        });
                        break;
                    case CC_R:
                        it.getSiteEffect().forEach((key, value) -> {
                            MediaStrategyViewDTO mediaStrategyViewDTO = mediaStrategyViewDTOMap.get(key);
                            if (Objects.nonNull(mediaStrategyViewDTO)) {
                                mediaStrategyViewDTO.getMediaInsightDataViewDTO().setCollectAddPurchaseRate(value);
                            }
                        });
                        break;
                    case DAL_R:
                        it.getSiteEffect().forEach((key, value) -> {
                            MediaStrategyViewDTO mediaStrategyViewDTO = mediaStrategyViewDTOMap.get(key);
                            if (Objects.nonNull(mediaStrategyViewDTO)) {
                                mediaStrategyViewDTO.getMediaInsightDataViewDTO().setDealRate(value);
                            }
                        });
                        break;
                    case MD_C:
                        it.getSiteEffect().forEach((key, value) -> {
                            MediaStrategyViewDTO mediaStrategyViewDTO = mediaStrategyViewDTOMap.get(key);
                            if (Objects.nonNull(mediaStrategyViewDTO)) {
                                mediaStrategyViewDTO.getMediaInsightDataViewDTO().setSiteAmount(value);
                            }
                        });
                        break;
                    default:
                        break;
                }
            });
        }
        return new ArrayList<>(mediaStrategyViewDTOMap.values());
    }

    private List<IntelligentDistributionRuleViewDTO> getDistributionRuleViewDTOList(List<ResourceConfig> resourcePackageConfigList, List<ClassifiedResourceConfig> classificationResourceList) {
        List<IntelligentDistributionRuleViewDTO> distributionRuleViewDTOList = Lists.newArrayList();
        Map<String, List<ResourceConfig>> resourceConfigMap = resourcePackageConfigList.stream()
                .collect(Collectors.groupingBy(resourceConfig -> StringUtils.isBlank(resourceConfig.getCategory()) ? "N" : resourceConfig.getCategory()));
        Map<String, ClassifiedResourceConfig> classifiedResourceConfigMap = Maps.newHashMap();
        if (CollectionUtils.isNotEmpty(classificationResourceList)) {
            classifiedResourceConfigMap = classificationResourceList.stream().collect(Collectors.toMap(ClassifiedResourceConfig::getCategory, it -> it));
        } else {
            //兼容历史的预算分配没有分类的资源包，默认为N
            ClassifiedResourceConfig config = new ClassifiedResourceConfig();
            config.setCategory("N");
            config.setRatio(10000);
            config.setMinProductNum(1);
            config.setMaxProductNum(999);
            classifiedResourceConfigMap.put("N", config);
        }

        Map<String, ClassifiedResourceConfig> finalClassifiedResourceConfigMap = classifiedResourceConfigMap;
        finalClassifiedResourceConfigMap.keySet().forEach(category -> {
            IntelligentDistributionRuleViewDTO intelligentDistributionRuleViewDTO = new IntelligentDistributionRuleViewDTO();
            ClassifiedResourceConfig classifiedResourceConfig = finalClassifiedResourceConfigMap.get(category);

            intelligentDistributionRuleViewDTO.setCategory(classifiedResourceConfig.getCategory());
            intelligentDistributionRuleViewDTO.setCategoryName(classifiedResourceConfig.getCategory());
            intelligentDistributionRuleViewDTO.setRatio(classifiedResourceConfig.getRatio());
            intelligentDistributionRuleViewDTO.setMinQuality(classifiedResourceConfig.getMinProductNum());
            intelligentDistributionRuleViewDTO.setMaxQuality(classifiedResourceConfig.getMaxProductNum());

            List<ProductStrategyViewDTO> productStrategyViewDTOList = new ArrayList<>();
            if (CollectionUtils.isEmpty(resourceConfigMap.get(classifiedResourceConfig.getCategory()))) {
                return;
            }
            for (ResourceConfig resourceConfig : resourceConfigMap.get(classifiedResourceConfig.getCategory())) {
                ProductStrategyViewDTO productStrategyViewDTO = new ProductStrategyViewDTO();
                productStrategyViewDTO.setResourcePackageProductId(resourceConfig.getResourceProductId());
                productStrategyViewDTO.setSspProductId(resourceConfig.getSspProductId());
                productStrategyViewDTO.setCartItemId(resourceConfig.getCartId());
                productStrategyViewDTO.setCastType(resourceConfig.getCastType());
                productStrategyViewDTO.setCategory(resourceConfig.getCategory());
                if (CollectionUtils.isNotEmpty(resourceConfig.getPriceStageList())) {
                    List<ProductBandPriceStrategyViewDTO> productBandPriceStrategyViewDTOList = resourceConfig.getPriceStageList().stream().map(it -> {
                        ProductBandPriceStrategyViewDTO productBandPriceStrategyViewDTO = new ProductBandPriceStrategyViewDTO();
                        productBandPriceStrategyViewDTO.setStartTime(it.getResourceStartTime());
                        productBandPriceStrategyViewDTO.setEndTime(it.getResourceEndTime());
                        productBandPriceStrategyViewDTO.setBudget(it.getBudget());
                        productBandPriceStrategyViewDTO.setPrice(it.getSettlePrice());
                        productBandPriceStrategyViewDTO.setType(it.getType());
                        productBandPriceStrategyViewDTO.setMinRatio(it.getMinRatio());
                        productBandPriceStrategyViewDTO.setCastAmount(it.getCastAmount());
                        if (CollectionUtils.isNotEmpty(it.getDeliverTargetResult())) {
                            productBandPriceStrategyViewDTO.setPredictDataViewDTO(buildPredictDataViewDTO(it.getDeliverTargetResult()));
                        }
                        return productBandPriceStrategyViewDTO;
                    }).collect(Collectors.toList());
                    productStrategyViewDTO.setProductBandPriceStrategyViewDTOList(productBandPriceStrategyViewDTOList);
                }
                productStrategyViewDTOList.add(productStrategyViewDTO);
            }
            intelligentDistributionRuleViewDTO.setProductStrategyList(productStrategyViewDTOList);
            distributionRuleViewDTOList.add(intelligentDistributionRuleViewDTO);
        });

        return distributionRuleViewDTOList;
    }

    public DmpArgusEstimateViewDTO buildEstimateViewDTOBaseOnStrategy(ServiceContext serviceContext, IntelligentStrategyViewDTO strategyViewDTO) {
        Long totalProductBudget = strategyViewDTO.getDistributionRuleDTOList().stream()
                .flatMap(it -> it.getProductStrategyList().stream())
                .flatMap(it -> it.getProductBandPriceStrategyViewDTOList().stream())
                .mapToLong(bandPrice -> Optional.ofNullable(bandPrice.getBudget()).orElse(0L)).sum();
        IntelligentMotionViewDTO intelligentMotionViewDTO = intelligentMotionRepository.getIntelligentMotionById(serviceContext, strategyViewDTO.getMotionId());
        AssertUtil.assertTrue(totalProductBudget.equals(intelligentMotionViewDTO.getBudget()), "策略总预算不等于提案总预算");
        List<ResourcePackageSaleGroupViewDTO> saleGroupViewDTOList = resourcePackageRepository.getSaleGroupList(serviceContext, Lists.newArrayList(intelligentMotionViewDTO.getSaleGroupId()), ResourcePackageQueryOption.builder().needProduct(Boolean.TRUE).needSetting(Boolean.TRUE).build());
        return bizIntelligentMotionEstimateAbility.buildEstimateViewDTOList(serviceContext, intelligentMotionViewDTO, saleGroupViewDTOList.get(0), strategyViewDTO, EstimateDimensionTypeEnum.STRATEGY.getValue());
    }

    public PredictDataViewDTO buildPredictDataViewDTO(List<TargetResult> deliverTargetResult) {
        PredictDataViewDTO predictDataViewDTO = new PredictDataViewDTO();
        if (CollectionUtils.isNotEmpty(deliverTargetResult)) {
            deliverTargetResult.forEach(it -> {
                //TODO 下次推进交付指标枚举改数字
//                it.getTargetTypeId();
                switch (it.getTargetId()) {
                    case EXPOSURE:
                        predictDataViewDTO.setImpPv(it.getEstimateMin());
                        break;
                    case CLICK:
                        predictDataViewDTO.setClkMonitorPv(it.getEstimateMin());
                        break;
                    case ARRIVE:
                        predictDataViewDTO.setLandPv(it.getEstimateMin());
                        break;
                    case SEARCH_VISIT_AGAIN_AMOUNT:
                        predictDataViewDTO.setSearchAndVisit(it.getEstimateMin());
                        break;
                    case COLLECT_ADD_PURCHASE:
                        predictDataViewDTO.setCollectAddPurchase(it.getEstimateMin());
                        break;
                    case DEAL_AMOUNT:
                        predictDataViewDTO.setDealPv(it.getEstimateMin());
                        break;
                    default:
                        break;
                }
            });
        }
        return predictDataViewDTO;
    }
}
