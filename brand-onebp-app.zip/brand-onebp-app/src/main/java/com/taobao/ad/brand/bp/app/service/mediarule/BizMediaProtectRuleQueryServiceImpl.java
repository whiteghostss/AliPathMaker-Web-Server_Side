package com.taobao.ad.brand.bp.app.service.mediarule;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.media.protect.MediaProtectRuleViewDTO;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.api.mediarule.BizMediaProtectRuleQueryService;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.mediarule.query.MediaProtectRuleQueryViewDTO;
import com.taobao.ad.brand.bp.domain.mediarule.MediaProtectRuleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 保护规则服务
 *
 * @author linhua.deng
 **/
@HSFProvider(serviceInterface = BizMediaProtectRuleQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizMediaProtectRuleQueryServiceImpl implements BizMediaProtectRuleQueryService {

    private final MediaProtectRuleRepository mediaProtectRuleRepository;

    @Override
    public MultiResponse<MediaProtectRuleViewDTO> findProtectList(ServiceContext context, MediaProtectRuleQueryViewDTO queryDTO) {
        PageResultViewDTO<MediaProtectRuleViewDTO> pageResultViewDTO = mediaProtectRuleRepository.findProtectRuleList(context, queryDTO);
        return MultiResponse.of(pageResultViewDTO.getList(),pageResultViewDTO.getCount());
    }

    @Override
    public SingleResponse<MediaProtectRuleViewDTO> getProtectRule(ServiceContext context, Long mutexId) {
        return SingleResponse.of(mediaProtectRuleRepository.getProtectRule(context, mutexId));
    }
}