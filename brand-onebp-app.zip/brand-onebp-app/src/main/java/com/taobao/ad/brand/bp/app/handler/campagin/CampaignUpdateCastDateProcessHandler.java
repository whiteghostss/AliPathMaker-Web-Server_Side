package com.taobao.ad.brand.bp.app.handler.campagin;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.hermes.framework.ddd.event.annotation.DomainEventHandler;
import com.alibaba.hermes.framework.event.EventHandler;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignInventoryWorkflow;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.dooh.repository.DoohRepository;
import com.taobao.ad.brand.bp.domain.event.campaign.CampaignUpdateCastDateNoticeEvent;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;

@Component
@RequiredArgsConstructor(onConstructor_ = @Autowired)
@DomainEventHandler(topic = "brand_self_campaign_update_cast_date_topic", event = CampaignUpdateCastDateNoticeEvent.class)
public class CampaignUpdateCastDateProcessHandler implements EventHandler<CampaignUpdateCastDateNoticeEvent> {

    private final ICampaignStructureQueryAbility campaignStructureQueryAbility;
    private final BizCampaignInventoryWorkflow bizCampaignInventoryWorkflow;
    private final DoohRepository doohRepository;

    @Override
    public Response handle(CampaignUpdateCastDateNoticeEvent campaignUpdateCastDateNoticeEvent) {
        ServiceContext serviceContext = campaignUpdateCastDateNoticeEvent.getContext().getServiceContext();
        Long campaignId = campaignUpdateCastDateNoticeEvent.getContext().getCampaignId();
        RogerLogger.info("CampaignUpdateCastDateProcessHandler execute start, campaignId : {}", campaignId);
        CampaignViewDTO afterUpdateViewDTO = getCampaignInfoByOption(serviceContext, campaignId, CampaignQueryOption.builder().needChildren(true).needTarget(true).build());
        bizCampaignInventoryWorkflow.autoAssignCampaignInquiryAmount(serviceContext, Lists.newArrayList(afterUpdateViewDTO));
        RogerLogger.info("CampaignUpdateCastDateProcessHandler execute end, campaignId : {}", campaignId);

        //天攻的计划需要同步天攻更新计划
        if(BizCampaignToolsHelper.isDoohCampaign(afterUpdateViewDTO.getCampaignResourceViewDTO().getSspProductLineId()) && (BrandDateUtil.isBefore(BrandDateUtil.getCurrentDate(), afterUpdateViewDTO.getStartTime()) || afterUpdateViewDTO.getCampaignInquiryLockViewDTO().getFirstOnlineTime() == null )){
            List<CampaignViewDTO> subCampaignViewDTOList = afterUpdateViewDTO.getSubCampaignViewDTOList();
            doohRepository.updateCampaign(serviceContext, subCampaignViewDTOList);
        }

        return Response.success();
    }

    /**
     * 获取计划信息
     * @param serviceContext
     * @param id
     * @param option
     * @return
     */
    private CampaignViewDTO getCampaignInfoByOption(ServiceContext serviceContext, Long id, CampaignQueryOption option){
        CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder().campaignIds(Collections.singletonList(id)).build();
        List<CampaignViewDTO> dbCampaignViewDTOList = campaignStructureQueryAbility.handle(serviceContext,
                CampaignStructureQueryAbilityParam.builder().abilityTarget(campaignQueryViewDTO).queryOption(option).build());
        return CollectionUtils.isNotEmpty(dbCampaignViewDTOList) ? dbCampaignViewDTOList.get(0) : null;
    }
}
