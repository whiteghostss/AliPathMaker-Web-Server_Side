package com.taobao.ad.brand.bp.app.service.access;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.app.workflow.cartitem.BizCartItemQueryWorkflow;
import com.taobao.ad.brand.bp.client.api.access.BizAccessQueryService;
import com.taobao.ad.brand.bp.client.dto.rule.RuleCheckResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSkuViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.feed.FeedRepository;
import com.taobao.ad.brand.bp.domain.shield.ShieldAccessRepository;
import com.taobao.ad.brand.bp.domain.shopwindow.repository.BrandSkuRepository;
import lombok.RequiredArgsConstructor;

/**
 * 百灵准入判断查询
 * @author 石炎
 * @date 2024/8/15
 */
@HSFProvider(serviceInterface = BizAccessQueryService.class)
@RequiredArgsConstructor
public class BizAccessQueryServiceImpl implements BizAccessQueryService {

    private final FeedRepository feedRepository;
    private final ShieldAccessRepository shieldAccessRepository;
    private final BrandSkuRepository brandSkuRepository;
    private final BizCartItemQueryWorkflow bizCartItemQueryWorkflow;

    @Override
    public SingleResponse<RuleCheckResultViewDTO> feedAccessJudge(ServiceContext context, Long itemId) {
        RuleCheckResultViewDTO checkResultViewDTO = feedRepository.checkAccess(context, itemId);
        return SingleResponse.of(checkResultViewDTO);
    }

    @Override
    public SingleResponse<RuleCheckResultViewDTO> feedSmartJudge(ServiceContext context, Long itemId) {
        RuleCheckResultViewDTO checkResultViewDTO = shieldAccessRepository.checkFeedSmartAccess(context, itemId);
        return SingleResponse.of(checkResultViewDTO);
    }

    @Override
    public SingleResponse<RuleCheckResultViewDTO> skuAccessJudge(ServiceContext serviceContext, Long skuId) {
        BrandSkuViewDTO skuViewDTO = brandSkuRepository.get(serviceContext, skuId);
        if(skuViewDTO == null){
            return SingleResponse.of(RuleCheckResultViewDTO.builder()
                    .isPass(BrandBoolEnum.BRAND_FALSE.getCode()).reason("数据不存在或已被删除").build());
        }
        //加购行ssp产品线准入
        RuleCheckResultViewDTO skuAccessCheckResult = bizCartItemQueryWorkflow.judgeSkuAccess(serviceContext, skuViewDTO);
        return SingleResponse.of(skuAccessCheckResult);
    }
}
