package com.taobao.ad.brand.bp.app.businessability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.abf.spec.common.annotation.SwitchContext;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.adgroup.crowd.AdgroupCrowdScenarioViewDTO;
import com.alibaba.ad.brand.dto.adgroup.crowd.AdgroupCrowdViewDTO;
import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.salegroup.CampaignGroupSaleGroupViewDTO;
import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupBottomTypeEnum;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupTargetTypeEnum;
import com.alibaba.ad.brand.sdk.constant.audience.field.BrandTargetTypeEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.salegroup.field.SaleGroupEstimateTypeEnum;
import com.alibaba.ad.model.definition.brand.property.value.enums.SaleGroupInfoSaleGroupStatusFieldEnum;
import com.alibaba.ad.nb.ssp.constant.newproduct.DeliveryTargetEnum;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryOption;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.*;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.CampaignGroupSaleGroupEstimateQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.SaleGroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.CrowdViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.enums.BrandDeliveryTargetEnum;
import com.taobao.ad.brand.bp.client.enums.EstimateDimensionTypeEnum;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.SaleGroupGoalSceneEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.converter.campaigngroup.CampaignSaleGroupDeliveryTargetConverter;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizSaleGroupToolsHelper;
import com.taobao.ad.brand.bp.common.threadpooltask.NReachAdgroupUpdateCrowdTaskIdentifier;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.common.util.differ.Differs;
import com.taobao.ad.brand.bp.domain.adgroup.repository.AdgroupRepository;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupInitForAddNReachAdgroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupInitForUpdateNReachAdgroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupNReachJudgeAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.*;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.query.IAdgroupStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.realtime.IAdgroupAlgoControlCrowdAddAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.realtime.IAdgroupAlgoControlCrowdDeleteAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.targets.IAdgroupAlgoTaCrowdInitForAddAdgroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.businessability.IAdgroupAddBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.businessability.IAdgroupNReachCrowdUpdateBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.businessability.IAdgroupNReachGenerateBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.businessability.IAdgroupUpdateBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbilityRouteContext;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.targets.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.businessability.ICampaignAddBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.campaign.businessability.ICampaignAlgoControlCrowdAddBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.campaign.businessability.ICampaignUpdateBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupAutoEstimateSaleGroupGetForOrderAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupSaleGroupEstimateValidateForOrderAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupAutoEstimateSaleGroupGetForOrderAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupSaleGroupEstimateValidateForOrderAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.businessability.ICampaignGroupEstimateBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.businessability.ICampaignGroupOrderBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.businessability.ICartItemSolutionPreOrderBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupCrowdQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupStatusValidateForUpdateSaleGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.delivery.*;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.*;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.businessability.*;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
@BusinessAbility(tag = MultiTargetDeliverBusinessAbility.ABILITY_CODE, name = "多目标交付商业能力", desc = "多目标交付商业能力结构化实现类")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class MultiTargetDeliverBusinessAbility implements
        ICartItemSolutionPreOrderBusinessAbilityPoint,
        ICampaignGroupOrderBusinessAbilityPoint, ICampaignGroupEstimateBusinessAbilityPoint,
        ISaleGroupSyncBusinessAbilityPoint, ISaleGroupAddBusinessAbilityPoint, ISaleGroupUpdateBusinessAbilityPoint, ISaleGroupGoalSettingUpdateBusinessAbilityPoint,
        ISaleGroupCrowdUpdateBusinessAbilityPoint, ISaleGroupEstimateResultClearBusinessAbilityPoint, ISaleGroupQueryBusinessAbilityPoint, ISaleGroupCanSelectStatusQueryBusinessAbilityPoint,
        ICampaignAddBusinessAbilityPoint, ICampaignUpdateBusinessAbilityPoint, ICampaignAlgoControlCrowdAddBusinessAbilityPoint,
        IAdgroupAddBusinessAbilityPoint, IAdgroupUpdateBusinessAbilityPoint, IAdgroupNReachGenerateBusinessAbilityPoint, IAdgroupNReachCrowdUpdateBusinessAbilityPoint {

    public static final String ABILITY_CODE = "BUSINESS_ABILITY_MULTI_TARGET_DELIVER";

    private final CampaignRepository campaignRepository;
    private final ResourcePackageRepository resourcePackageRepository;
    private final CampaignGroupRepository campaignGroupRepository;
    private final AdgroupRepository adgroupRepository;

    private final ISaleGroupStatusValidateForUpdateSaleGroupAbility saleGroupStatusValidateForUpdateSaleGroupAbility;
    private final ISaleGroupEstimateParamBuildForSaleGroupEstimateAbility saleGroupEstimateParamBuildForSaleGroupEstimateAbility;
    private final ISaleGroupEstimateParamValidateForSaleGroupEstimateAbility saleGroupEstimateValidateForSaleGroupEstimateAbility;
    private final ISaleGroupEstimateCampaignValidateForSaleGroupEstimateAbility saleGroupEstimateCampaignValidateForSaleGroupEstimateAbility;
    private final ISaleGroupEstimateJudgeForCartItemSolutionPreOrderAbility saleGroupEstimateJudgeForCartItemSolutionPreOrderAbility;
    private final ISaleGroupEstimateInvokeForSaleGroupEstimateAbility saleGroupEstimateInvokeForSaleGroupEstimateAbility;
    private final ISaleGroupEstimateResultProcessForSaleGroupEstimateAbility saleGroupEstimateResultProcessForSaleGroupEstimateAbility;
    private final ISaleGroupEstimateResultSaveForSaleGroupEstimateAbility saleGroupEstimateResultSaveForSaleGroupEstimateAbility;
    private final ISaleGroupEstimateResultWarnSendMessageAbility saleGroupEstimateResultWarnSendMessageAbility;
    private final ISaleGroupEstimateResultClearForSaleGroupEstimateAbility saleGroupEstimateResultClearForSaleGroupEstimateAbility;
    private final ISaleGroupDeliveryTargetInitForAddSaleGroupAbility saleGroupDeliveryTargetInitForAddSaleGroupAbility;
    private final ICampaignGroupAutoEstimateSaleGroupGetForOrderAbility campaignGroupAutoEstimateSaleGroupGetForOrderAbility;
    private final ICampaignGroupSaleGroupEstimateValidateForOrderAbility campaignGroupSaleGroupEstimateValidateForOrderAbility;
    private final ISaleGroupCrowdQueryAbility saleGroupCrowdQueryAbility;
    private final ISaleGroupGoalSettingInitForUpdateGoalSettingAbility saleGroupGoalSettingInitForUpdateGoalSettingAbility;
    private final ISaleGroupGoalSettingValidateForUpdateGoalSettingAbility saleGroupGoalSettingValidateForUpdateGoalSettingAbility;
    private final ISaleGroupGoalSettingFillForUpdateGoalSettingAbility saleGroupGoalSettingFillForUpdateGoalSettingAbility;
    private final ICampaignStructureQueryAbility campaignStructureQueryAbility;
    private final ICampaignTaCrowdValidateForAddCampaignAbility campaignTaCrowdValidateForAddCampaignAbility;
    private final ICampaignAlgoTaCrowdInitForAddCampaignAbility campaignAlgoTaCrowdInitForAddCampaignAbility;
    private final ICampaignAlgoControlCrowdJudgeForAddOrUpdateCampaignAbility campaignAlgoControlCrowdJudgeForAddOrUpdateCampaignAbility;
    private final ICampaignAlgoControlCrowdInitForAddCrowdAbility campaignAlgoControlCrowdInitForAddCrowdAbility;
    private final ICampaignAlgoControlCrowdAddAbility campaignAlgoControlCrowdAddAbility;
    private final ICampaignAlgoControlCrowdDeleteAbility campaignAlgoControlCrowdDeleteAbility;
    private final IAdgroupNReachJudgeAbility adgroupNReachJudgeAbility;
    private final IAdgroupInitForAddNReachAdgroupAbility adgroupInitForAddNReachAdgroupAbility;
    private final IAdgroupInitForUpdateNReachAdgroupAbility adgroupInitForUpdateNReachAdgroupAbility;
    private final IAdgroupAlgoTaCrowdInitForAddAdgroupAbility adgroupAlgoTaCrowdInitForAddAdgroupAbility;
    private final IAdgroupStructureQueryAbility adgroupStructureQueryAbility;
    private final IAdgroupAlgoControlCrowdDeleteAbility adgroupAlgoControlCrowdDeleteAbility;
    private final IAdgroupAlgoControlCrowdAddAbility adgroupAlgoControlCrowdAddAbility;
    private final ISaleGroupDeliveryTargetUpdateJudgeAbility groupDeliveryTargetUpdateJudgeAbility;
    private final ISaleGroupOptimizeTargetUpdateJudgeAbility saleGroupOptimizeTargetUpdateJudgeAbility;
    private final ISaleGroupDeliveryTargetInitForSyncSaleGroupAbility saleGroupDeliveryTargetInitForSyncSaleGroupAbility;
    private final ISaleGroupOptimizeTargetInitForSyncSaleGroupAbility saleGroupOptimizeTargetInitForSyncSaleGroupAbility;
    private final ISaleGroupGoalSceneGetAbility saleGroupGoalSceneGetAbility;
    private final IResourcePackageSaleGroupGoalSceneGetAbility resourcePackageSaleGroupGoalSceneGetAbility;
    private final ISaleGroupEstimateResultRebuildAbility saleGroupRebuildEstimateResultAbility;
    private final NReachAdgroupUpdateCrowdTaskIdentifier nReachAdgroupUpdateCrowdTaskIdentifier;
    private final CampaignSaleGroupDeliveryTargetConverter campaignSaleGroupDeliveryTargetConverter;

    @Override
    public boolean routeChecking(String bizCode, BaseViewDTO baseViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        List<String> specifiedBusinessCodes = businessAbilityRouteContext.getSpecifiedBusinessAbilityCodes();
        if (CollectionUtils.isNotEmpty(specifiedBusinessCodes) && specifiedBusinessCodes.contains(ABILITY_CODE)) {
            return true;
        }
        if (businessAbilityRouteContext.getPackageSaleGroupViewDTO() != null) {
            return CollectionUtils.isNotEmpty(businessAbilityRouteContext.getPackageSaleGroupViewDTO().getResourceDeliveryTargetList());
        }
        return false;
    }

    @Override
    @SwitchContext
    public Void invokeForSyncSaleGroup(ServiceContext serviceContext, List<ResourcePackageSaleGroupViewDTO> updateSaleGroupList) {
        Map<Long, ResourcePackageSaleGroupViewDTO> updatePackageSaleGroupMap = updateSaleGroupList.stream().collect(Collectors.toMap(ResourcePackageSaleGroupViewDTO::getId, Function.identity(), (v1, v2) -> v1));
        Map<Long, List<ResourcePackageSaleGroupViewDTO>> memberPackageSaleGroupMap = updateSaleGroupList.stream().collect(Collectors.groupingBy(ResourcePackageSaleGroupViewDTO::getMemberId));
        for (Map.Entry<Long, List<ResourcePackageSaleGroupViewDTO>> memberPackageSaleGroupEntry : memberPackageSaleGroupMap.entrySet()) {
            serviceContext.setMemberId(memberPackageSaleGroupEntry.getKey());
            List<Long> saleGroupIds = memberPackageSaleGroupEntry.getValue().stream().map(ResourcePackageSaleGroupViewDTO::getId).collect(Collectors.toList());

            //这里可能是跨分组的，比对的时候需要按照分组进行比对
            SaleGroupQueryViewDTO saleGroupQueryViewDTO = new SaleGroupQueryViewDTO();
            saleGroupQueryViewDTO.setSaleGroupIds(saleGroupIds);
            saleGroupQueryViewDTO.setSaleGroupStatus(SaleGroupInfoSaleGroupStatusFieldEnum.WAIT_ORDER.getCode());//取未下单的分组
            List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList = campaignGroupRepository.findSaleGroupList(serviceContext, saleGroupQueryViewDTO);
            if (CollectionUtils.isEmpty(saleGroupInfoViewDTOList)) {
                continue;
            }
            //查询订单分组关联的计划
            CampaignQueryViewDTO campaignQueryViewDTO = new CampaignQueryViewDTO();
            campaignQueryViewDTO.setSaleGroupIds(saleGroupIds);
            List<CampaignViewDTO> campaignViewDTOList = campaignRepository.queryCampaignList(serviceContext, campaignQueryViewDTO);
            Map<Long, List<CampaignViewDTO>> saleGroupCampaignGroupMap = Optional.ofNullable(campaignViewDTOList).orElse(Lists.newArrayList())
                    .stream().collect(Collectors.groupingBy(item -> item.getCampaignSaleViewDTO().getSaleGroupId()));

            //订单分组下如果有计划不更新，直接过滤
            List<SaleGroupInfoViewDTO> needToUpdateList = Lists.newArrayList();
            for (SaleGroupInfoViewDTO saleGroupInfoViewDTO : saleGroupInfoViewDTOList) {
                if (saleGroupCampaignGroupMap.containsKey(saleGroupInfoViewDTO.getSaleGroupId())) {
                    continue;
                }
                ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO = updatePackageSaleGroupMap.get(saleGroupInfoViewDTO.getSaleGroupId());
                //构建具体业务场景上下文
                ServiceContext sceneServiceContext = ServiceContextUtil.getNewServiceContext(serviceContext, resourcePackageSaleGroupViewDTO.getBusinessLine());
                boolean needUpdateDeliveryTarget = groupDeliveryTargetUpdateJudgeAbility.handle(sceneServiceContext,
                        SaleGroupDeliveryTargetUpdateJudgeAbilityParam.builder().abilityTargets(saleGroupInfoViewDTO.getDeliveryTargetViewDTOList()).resourceDeliveryTargetList(resourcePackageSaleGroupViewDTO.getResourceDeliveryTargetList()).build());
                if (needUpdateDeliveryTarget) {
                    saleGroupDeliveryTargetInitForSyncSaleGroupAbility.handle(sceneServiceContext, SaleGroupDeliveryTargetInitForSyncSaleGroupAbilityParam.builder()
                            .abilityTarget(saleGroupInfoViewDTO).packageSaleGroupViewDTO(resourcePackageSaleGroupViewDTO).build());
                }
                List<Integer> dbOptimizeTargetList = Optional.ofNullable(saleGroupInfoViewDTO.getOptimizeTargetList()).orElse(Lists.newArrayList());
                boolean needUpdateOptimizeTarget = saleGroupOptimizeTargetUpdateJudgeAbility.handle(sceneServiceContext, SaleGroupOptimizeTargetUpdateJudgeAbilityParam.builder()
                        .abilityTargets(dbOptimizeTargetList).resourceOptimizeTargetList(resourcePackageSaleGroupViewDTO.getResourceOptimizeTargetList()).build());
                //2023年09月09日升级逻辑，若需要更新，则再次更新客户的选项
                if (needUpdateOptimizeTarget) {
                    saleGroupOptimizeTargetInitForSyncSaleGroupAbility.handle(sceneServiceContext,
                            SaleGroupOptimizeTargetInitForSyncSaleGroupAbilityParam.builder().abilityTarget(saleGroupInfoViewDTO).packageSaleGroupViewDTO(resourcePackageSaleGroupViewDTO).build());
                }
                needToUpdateList.add(saleGroupInfoViewDTO);
            }
            //更新需要by订单
            if (CollectionUtils.isNotEmpty(needToUpdateList)) {
                campaignGroupRepository.updateSaleGroupAll(serviceContext, needToUpdateList);
            }
        }
        return null;
    }

    @Override
    public Void invokeForAddSaleGroup(ServiceContext serviceContext, SaleGroupInfoViewDTO saleGroupInfoViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        saleGroupDeliveryTargetInitForAddSaleGroupAbility.handle(serviceContext, SaleGroupDeliveryTargetInitForAddSaleGroupAbilityParam.builder().abilityTarget(saleGroupInfoViewDTO)
                .packageSaleGroupViewDTO(businessAbilityRouteContext.getPackageSaleGroupViewDTO()).build());

        return null;
    }

    @Override
    public Void invokeForUpdateSaleGroup(ServiceContext serviceContext, SaleGroupInfoViewDTO saleGroupViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        //订单分组不存在时，进行数据初始化
        if (Objects.isNull(saleGroupViewDTO.getId())) {
            invokeForAddSaleGroup(serviceContext, saleGroupViewDTO, businessAbilityRouteContext);
        }
        return null;
    }

    @Override
    public List<CampaignGroupSaleGroupEstimateInfoViewDTO> invokeForCartItemSolutionPreOrder(ServiceContext serviceContext, CartItemViewDTO cartItemViewDTO,
                                                                                             CampaignGroupViewDTO campaignGroupViewDTO,
                                                                                             List<CampaignViewDTO> campaignViewDTOList,
                                                                                             BusinessAbilityRouteContext businessAbilityRouteContext) {
        Boolean needEstimate = saleGroupEstimateJudgeForCartItemSolutionPreOrderAbility.handle(serviceContext, SaleGroupEstimateJudgeForCartItemSolutionPreOrderAbilityParam.builder()
                .abilityTarget(cartItemViewDTO).campaignGroupViewDTO(campaignGroupViewDTO).campaignViewDTOList(campaignViewDTOList).build());
        if (needEstimate == null || !needEstimate) {
            return Lists.newArrayList();
        }
        List<Long> saleGroupIds = Optional.ofNullable(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO())
                .map(CampaignGroupSaleGroupViewDTO::getSaleGroupInfoViewDTOList).orElse(Lists.newArrayList())
                .stream().map(SaleGroupInfoViewDTO::getSaleGroupId).collect(Collectors.toList());

        CampaignGroupSaleGroupEstimateQueryViewDTO saleGroupEstimateQueryViewDTO = new CampaignGroupSaleGroupEstimateQueryViewDTO();
        saleGroupEstimateQueryViewDTO.setCampaignGroupId(campaignGroupViewDTO.getId());
        saleGroupEstimateQueryViewDTO.setSaleGroupIds(saleGroupIds);
        saleGroupEstimateQueryViewDTO.setEstimateDimensionType(EstimateDimensionTypeEnum.SALE_GROUP.getValue());
        saleGroupEstimateQueryViewDTO.setEstimateType(SaleGroupEstimateTypeEnum.DELIVERY_TARGET.getCode());

        return invokeForCampaignGroupEstimate(serviceContext, saleGroupEstimateQueryViewDTO);
    }

    @Override
    public List<CampaignGroupSaleGroupEstimateInfoViewDTO> invokeForCampaignGroupEstimate(ServiceContext context, CampaignGroupSaleGroupEstimateQueryViewDTO saleGroupEstimateQueryViewDTO) {
        //构建预估基础参数
        BaseSaleGroupEstimateParam baseEstimateParam = saleGroupEstimateParamBuildForSaleGroupEstimateAbility.handle(context,
                SaleGroupEstimateParamBuildForSaleGroupEstimateAbilityParam.builder().abilityTarget(saleGroupEstimateQueryViewDTO).build());
        if (baseEstimateParam == null) {
            return Lists.newArrayList();
        }
        //分组预估校验
        saleGroupEstimateValidateForSaleGroupEstimateAbility.handle(context, SaleGroupEstimateParamValidateForSaleGroupEstimateAbilityParam.builder()
                .abilityTarget(saleGroupEstimateQueryViewDTO).baseSaleGroupEstimateParam(baseEstimateParam).build());

        CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder().campaignGroupId(saleGroupEstimateQueryViewDTO.getCampaignGroupId())
                .saleGroupIds(saleGroupEstimateQueryViewDTO.getSaleGroupIds()).campaignIds(saleGroupEstimateQueryViewDTO.getCampaignIds()).build();
        CampaignQueryOption queryOption = CampaignQueryOption.builder().needTarget(true).needFrequency(true).needCampaignTree(true).build();
        List<CampaignViewDTO> campaignTreeViewDTOList = campaignStructureQueryAbility.handle(context, CampaignStructureQueryAbilityParam.builder()
                .abilityTarget(campaignQueryViewDTO).queryOption(queryOption).build());
        baseEstimateParam.setCampaignTreeViewDTOList(campaignTreeViewDTOList);

        //分组计划预估校验
        saleGroupEstimateCampaignValidateForSaleGroupEstimateAbility.handle(context, SaleGroupEstimateCampaignValidateForSaleGroupEstimateAbilityParam.builder()
                .abilityTarget(saleGroupEstimateQueryViewDTO).baseSaleGroupEstimateParam(baseEstimateParam).build());

        //执行分组预估
        List<CampaignGroupSaleGroupEstimateInfoViewDTO> saleGroupEstimateInfoViewDTOList = saleGroupEstimateInvokeForSaleGroupEstimateAbility.handle(context,
                SaleGroupEstimateInvokeForSaleGroupEstimateAbilityParam.builder().abilityTarget(saleGroupEstimateQueryViewDTO).baseSaleGroupEstimateParam(baseEstimateParam).build());

        //预估结果处理
        baseEstimateParam.setSave(true);
        saleGroupEstimateResultProcessForSaleGroupEstimateAbility.handle(context, SaleGroupEstimateResultProcessForSaleGroupEstimateAbilityParam.builder()
                .abilityTargets(saleGroupEstimateInfoViewDTOList).baseSaleGroupEstimateParam(baseEstimateParam).build());

        //交付预估结果保存
        saleGroupEstimateResultSaveForSaleGroupEstimateAbility.handle(context, SaleGroupEstimateResultSaveForSaleGroupEstimateAbilityParam.builder()
                .abilityTarget(saleGroupEstimateQueryViewDTO).saleGroupEstimateInfoViewDTOList(saleGroupEstimateInfoViewDTOList).build());

        //交付预估结果置信度预警通知
        saleGroupEstimateResultWarnSendMessageAbility.handle(context, SaleGroupEstimateResultSaveForSaleGroupEstimateAbilityParam.builder()
                .abilityTarget(saleGroupEstimateQueryViewDTO).saleGroupEstimateInfoViewDTOList(saleGroupEstimateInfoViewDTOList).build());

        //交付预估结果透出
        baseEstimateParam.setSave(false);
        saleGroupEstimateResultProcessForSaleGroupEstimateAbility.handle(context, SaleGroupEstimateResultProcessForSaleGroupEstimateAbilityParam.builder()
                .abilityTargets(saleGroupEstimateInfoViewDTOList).baseSaleGroupEstimateParam(baseEstimateParam).build());

        return saleGroupEstimateInfoViewDTOList;
    }

    @Override
    public Void invokeForCampaignGroupOrder(ServiceContext serviceContext, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO,
                                            CampaignGroupViewDTO campaignGroupViewDTO, List<CampaignViewDTO> campaignList,
                                            List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupList, BusinessAbilityRouteContext businessAbilityRouteContext) {
        // 1. 自动预估（对一些交付目标不对客的分组需要执行自动预估）
        List<Long> autoEstimateSaleGroupIds = campaignGroupAutoEstimateSaleGroupGetForOrderAbility.handle(serviceContext, CampaignGroupAutoEstimateSaleGroupGetForOrderAbilityParam.builder()
                .abilityTarget(campaignGroupOrderCommandViewDTO).campaignGroupViewDTO(campaignGroupViewDTO).build());
        if (CollectionUtils.isNotEmpty(autoEstimateSaleGroupIds)) {
            CampaignGroupSaleGroupEstimateQueryViewDTO saleGroupEstimateQueryViewDTO = new CampaignGroupSaleGroupEstimateQueryViewDTO();
            saleGroupEstimateQueryViewDTO.setCampaignGroupId(campaignGroupOrderCommandViewDTO.getId());
            saleGroupEstimateQueryViewDTO.setSaleGroupIds(autoEstimateSaleGroupIds);
            saleGroupEstimateQueryViewDTO.setEstimateDimensionType(EstimateDimensionTypeEnum.SALE_GROUP.getValue());
            saleGroupEstimateQueryViewDTO.setEstimateType(SaleGroupEstimateTypeEnum.DELIVERY_TARGET.getCode());

            invokeForCampaignGroupEstimate(serviceContext, saleGroupEstimateQueryViewDTO);
        }

        // 2. 校验预估结果
        campaignGroupSaleGroupEstimateValidateForOrderAbility.handle(serviceContext, CampaignGroupSaleGroupEstimateValidateForOrderAbilityParam.builder()
                .abilityTarget(campaignGroupOrderCommandViewDTO).campaignGroupViewDTO(campaignGroupViewDTO).resourcePackageSaleGroupList(resourcePackageSaleGroupList).build());


        return null;
    }

    @Override
    public Void invokeForSaleGroupCrowd(ServiceContext serviceContext, CampaignGroupSaleGroupCrowdViewDTO saleGroupCrowdViewDTO, SaleGroupInfoViewDTO saleGroupInfoViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO = businessAbilityRouteContext.getPackageSaleGroupViewDTO();
        //N+场景下人群最多15个
        if (CollectionUtils.isNotEmpty(packageSaleGroupViewDTO.getResourceDeliveryTargetList())) {
            boolean isNReach = packageSaleGroupViewDTO.getResourceDeliveryTargetList().stream()
                    .anyMatch(item -> item.getDeliveryTarget().equals(DeliveryTargetEnum.N_REACH.getValue()));
            if (isNReach) {
                AssertUtil.assertTrue(saleGroupCrowdViewDTO.getCrowdIdList().size() <= 15, BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR, "N次触达率场景下，人群最多15个");
            }
        }
        //n+清空预估结果
        List<Long> dbCrowdIds = Lists.newArrayList(Optional.ofNullable(saleGroupInfoViewDTO.getCrowdIds()).orElse(Lists.newArrayList()));
        List<Long> diffCrowdIds = Differs.diff(dbCrowdIds, saleGroupCrowdViewDTO.getCrowdIdList(), String::valueOf);
        boolean isNReach = Optional.ofNullable(packageSaleGroupViewDTO.getResourceDeliveryTargetList()).orElse(Lists.newArrayList())
                .stream().anyMatch(item -> item.getDeliveryTarget().equals(DeliveryTargetEnum.N_REACH.getValue()));
        if (isNReach && CollectionUtils.isNotEmpty(diffCrowdIds)) {
            saleGroupInfoViewDTO.setSaleGroupEstimateInfoViewDTO(null);
        }
        return null;
    }

    @Override
    public Void invokeForUpdateNReachAdgroupCrowd(ServiceContext serviceContext, SaleGroupInfoViewDTO saleGroupInfoViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        //更新n+单元的人群定向
        AdgroupQueryViewDTO adgroupQueryViewDTO = new AdgroupQueryViewDTO();
        adgroupQueryViewDTO.setCampaignGroupId(saleGroupInfoViewDTO.getCampaignGroupId());
        adgroupQueryViewDTO.setSaleGroupIds(Collections.singletonList(saleGroupInfoViewDTO.getSaleGroupId()));
        adgroupQueryViewDTO.setBottomType(BrandAdgroupBottomTypeEnum.N_REACH.getCode());
        List<AdgroupViewDTO> adgroupViewDTOList = adgroupRepository.queryAdgroupListNoPage(serviceContext, adgroupQueryViewDTO);
        if (CollectionUtils.isNotEmpty(adgroupViewDTOList)) {
            List<CrowdViewDTO> crowdViewDTOList = saleGroupCrowdQueryAbility.handle(serviceContext, SaleGroupCrowdQueryAbilityParam.builder()
                    .abilityTarget(saleGroupInfoViewDTO).build());
            List<AdgroupCrowdViewDTO> adgroupCrowdViewDTOList = crowdViewDTOList.stream().map(crowdViewDTO -> {
                AdgroupCrowdViewDTO crowdBaseViewDTO = new AdgroupCrowdViewDTO();
                crowdBaseViewDTO.setCrowdId(crowdViewDTO.getCrowdId());
                crowdBaseViewDTO.setCrowdName(crowdViewDTO.getCrowdName());
                crowdBaseViewDTO.setTargetType(BrandTargetTypeEnum.DMP_CROWD.getCode().longValue());
                return crowdBaseViewDTO;
            }).collect(Collectors.toList());

            TaskStream.consume(nReachAdgroupUpdateCrowdTaskIdentifier, adgroupViewDTOList, (adgroupViewDTO, index) -> {
                AdgroupViewDTO updateAdgroupViewDTO = new AdgroupViewDTO();
                updateAdgroupViewDTO.setId(adgroupViewDTO.getId());
                updateAdgroupViewDTO.setCampaignId(adgroupViewDTO.getCampaignId());

                AdgroupCrowdScenarioViewDTO crowdScenarioViewDTO = new AdgroupCrowdScenarioViewDTO();
                crowdScenarioViewDTO.setAdgroupCrowdViewDTOList(adgroupCrowdViewDTOList);
                updateAdgroupViewDTO.setAdgroupCrowdScenarioViewDTO(crowdScenarioViewDTO);

                adgroupRepository.updateAdgroupCrowdTarget(serviceContext, updateAdgroupViewDTO);

                adgroupRepository.batchUpdateAdgroupViewDTOCrowdTag(serviceContext, Lists.newArrayList(updateAdgroupViewDTO));
            }).commit().handle();
        }
        return null;
    }

    @Override
    public Void invokeForSaleGroupGoalSetting(ServiceContext serviceContext, CampaignGroupSaleGroupGoalSettingViewDTO saleGroupGoalSettingViewDTO) {
        BaseSaleGroupGoalSettingParam goalSettingAbilityParam = buildAbilityParamForGoalSetting(serviceContext, saleGroupGoalSettingViewDTO);
        //订单状态校验
        saleGroupStatusValidateForUpdateSaleGroupAbility.handle(serviceContext, SaleGroupStatusValidateForUpdateSaleGroupAbilityParam.builder()
                .abilityTarget(goalSettingAbilityParam.getCampaignGroupViewDTO()).saleGroupInfoViewDTO(goalSettingAbilityParam.getSaleGroupInfoViewDTO()).build());
        //前置数据处理（设置默认值）
        saleGroupGoalSettingInitForUpdateGoalSettingAbility.handle(serviceContext, SaleGroupGoalSettingInitForUpdateGoalSettingAbilityParam.builder()
                .abilityTarget(saleGroupGoalSettingViewDTO).baseSaleGroupGoalSettingParam(goalSettingAbilityParam).build());
        //数据校验
        saleGroupGoalSettingValidateForUpdateGoalSettingAbility.handle(serviceContext, SaleGroupGoalSettingValidateForUpdateGoalSettingAbilityParam.builder()
                .abilityTarget(saleGroupGoalSettingViewDTO).baseSaleGroupGoalSettingParam(goalSettingAbilityParam).build());
        //填充数据
        SaleGroupInfoViewDTO saleGroupInfoViewDTO = saleGroupGoalSettingFillForUpdateGoalSettingAbility.handle(serviceContext, SaleGroupGoalSettingFillForUpdateGoalSettingAbilityParam.builder()
                .abilityTarget(saleGroupGoalSettingViewDTO).baseSaleGroupGoalSettingParam(goalSettingAbilityParam).build());
        //保存
        if (saleGroupInfoViewDTO != null) {
            campaignGroupRepository.updateSaleGroupAll(serviceContext, Lists.newArrayList(saleGroupInfoViewDTO));
        }
        return null;
    }

    private BaseSaleGroupGoalSettingParam buildAbilityParamForGoalSetting(ServiceContext serviceContext, CampaignGroupSaleGroupGoalSettingViewDTO saleGroupGoalSettingViewDTO) {
        Long campaignGroupId = saleGroupGoalSettingViewDTO.getCampaignGroupId();
        Long saleGroupId = saleGroupGoalSettingViewDTO.getSaleGroupId();
        AssertUtil.notNull(campaignGroupId, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "订单不能为空");
        AssertUtil.notNull(saleGroupId, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "分组不能为空");
        //订单
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(serviceContext, campaignGroupId);
        AssertUtil.notNull(campaignGroupViewDTO, BrandOneBPBaseErrorCode.BIZ_DATA_EMPTY_ERROR, "订单未查到");

        SaleGroupInfoViewDTO dbSaleGroupInfoViewDTO = Optional.ofNullable(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO()).map(CampaignGroupSaleGroupViewDTO::getSaleGroupInfoViewDTOList).orElse(Lists.newArrayList())
                .stream().filter(saleGroupInfo -> Objects.equals(saleGroupId, saleGroupInfo.getSaleGroupId())).findFirst().orElse(null);
        AssertUtil.notNull(dbSaleGroupInfoViewDTO, BrandOneBPBaseErrorCode.BIZ_DATA_EMPTY_ERROR, "售卖分组不存在，请检查");

        ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO = resourcePackageRepository.getSaleGroupById(serviceContext, saleGroupGoalSettingViewDTO.getSaleGroupId(),
                ResourcePackageQueryOption.builder().needSetting(true).needProduct(false).needInquiryPriority(false).build());
        AssertUtil.notNull(packageSaleGroupViewDTO, BrandOneBPBaseErrorCode.BIZ_DATA_EMPTY_ERROR, "资源售卖分组不存在，请检查");

        return BaseSaleGroupGoalSettingParam.builder().campaignGroupViewDTO(campaignGroupViewDTO).resourcePackageSaleGroupViewDTO(packageSaleGroupViewDTO).saleGroupInfoViewDTO(dbSaleGroupInfoViewDTO).build();
    }

    @Override
    public Void invokeForClearSaleGroupEstimateResult(ServiceContext serviceContext, Long campaignGroupId, List<Long> saleGroupIds) {
        saleGroupEstimateResultClearForSaleGroupEstimateAbility.handle(serviceContext, SaleGroupEstimateResultClearForSaleGroupEstimateAbilityParam.builder()
                .abilityTarget(campaignGroupId).saleGroupIds(saleGroupIds).build());
        return null;
    }

    @Override
    public Void invokeForQuerySaleGroup(ServiceContext context, CampaignGroupSaleGroupPageViewDTO saleGroup, SaleGroupInfoViewDTO dbSaleGroupInfoViewDTO, List<CampaignViewDTO> campaignViewDTOList, BusinessAbilityRouteContext businessAbilityRouteContext) {
        ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO = businessAbilityRouteContext.getPackageSaleGroupViewDTO();

        Optional<CampaignSaleGroupResourceDeliveryTargetViewDTO> priceOptional = resourcePackageSaleGroupViewDTO.getResourceDeliveryTargetList().stream().filter(
                v -> BrandDeliveryTargetEnum.EXPOSURE.getValue().equals(v.getDeliveryTarget())).findFirst();
        if (priceOptional.isPresent()) {
            saleGroup.setUnitPrice(priceOptional.get().getDeliveryTargetAveragePrice());
            //资源包曝光量设置值=CPM，百灵对外服务统一转为PV
            saleGroup.setAmount(priceOptional.get().getDeliveryTargetValue().longValue()*1000);
        }
        //db不存在
        if (Objects.isNull(dbSaleGroupInfoViewDTO)) {
            Integer goalScene = resourcePackageSaleGroupGoalSceneGetAbility.handle(context, ResourcePackageSaleGroupGoalSceneGetAbilityParam.builder()
                    .abilityTarget(resourcePackageSaleGroupViewDTO).needReal(false).build());
            Integer realGoalScene = resourcePackageSaleGroupGoalSceneGetAbility.handle(context, ResourcePackageSaleGroupGoalSceneGetAbilityParam.builder()
                    .abilityTarget(resourcePackageSaleGroupViewDTO).needReal(true).build());
            saleGroup.setGoalScene(goalScene);
            saleGroup.setRealGoalScene(realGoalScene);
            return null;
        }
        //BP设置的交付指标
        saleGroup.setDeliveryTargetList(campaignSaleGroupDeliveryTargetConverter.convertViewDTO2DTOList(dbSaleGroupInfoViewDTO.getDeliveryTargetViewDTOList()));
        saleGroup.setCrowdIdList(dbSaleGroupInfoViewDTO.getCrowdIds());
        saleGroup.setCoverage(dbSaleGroupInfoViewDTO.getCoverage());
        saleGroup.setGoalScene(saleGroupGoalSceneGetAbility.handle(context, SaleGroupGoalSceneGetAbilityParam.builder()
                .abilityTarget(dbSaleGroupInfoViewDTO).needReal(false).build()));
        saleGroup.setRealGoalScene(saleGroupGoalSceneGetAbility.handle(context, SaleGroupGoalSceneGetAbilityParam.builder()
                .abilityTarget(dbSaleGroupInfoViewDTO).needReal(true).build()));
        //先设置预估状态，再改写返回值
        saleGroup.setAlgoEstimateStatus(BizSaleGroupToolsHelper.getAlgoEstimateStatus(dbSaleGroupInfoViewDTO));
        //这里代表了做过交付预估，因此需要进行交付预估的重新构建
        if (Objects.nonNull(dbSaleGroupInfoViewDTO.getSaleGroupEstimateInfoViewDTO())) {
            CampaignGroupSaleGroupEstimateInfoViewDTO estimateInfoViewDTO = saleGroupRebuildEstimateResultAbility.handle(context, SaleGroupEstimateResultRebuildAbilityParam.builder()
                    .abilityTarget(dbSaleGroupInfoViewDTO).packageSaleGroupViewDTO(resourcePackageSaleGroupViewDTO).build());
            saleGroup.setEstimateResult(estimateInfoViewDTO);
        } else {
            //没有做过交付预估，但是需要将pv等计算结果返回
            //这里代表做过计算了
            if (CollectionUtils.isNotEmpty(campaignViewDTOList) && null != dbSaleGroupInfoViewDTO.getCalcBudget()) {
                CampaignGroupSaleGroupEstimateInfoViewDTO estimateInfoViewDTO = saleGroupRebuildEstimateResultAbility.handle(context, SaleGroupEstimateResultRebuildAbilityParam.builder()
                        .abilityTarget(dbSaleGroupInfoViewDTO).packageSaleGroupViewDTO(resourcePackageSaleGroupViewDTO).build());
                saleGroup.setEstimateResult(estimateInfoViewDTO);
            }
        }
        return null;
    }

    @Override
    public Void invokeForFindCanSelectStatusSaleGroup(ServiceContext context, CampaignGroupSaleGroupPageViewDTO campaignGroupSaleGroupPageViewDTO,
                                                      SaleGroupInfoViewDTO dbSaleGroupInfoViewDTO, List<CampaignViewDTO> campaignViewDTOList,
                                                      BusinessAbilityRouteContext businessAbilityRouteContext) {

        ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO = businessAbilityRouteContext.getPackageSaleGroupViewDTO();
        campaignGroupSaleGroupPageViewDTO.setResourceDeliveryTargetList(resourcePackageSaleGroupViewDTO.getResourceDeliveryTargetList());
        //db不存在
        if (Objects.isNull(dbSaleGroupInfoViewDTO)) {
            Integer goalScene = resourcePackageSaleGroupGoalSceneGetAbility.handle(context, ResourcePackageSaleGroupGoalSceneGetAbilityParam.builder()
                    .abilityTarget(resourcePackageSaleGroupViewDTO).needReal(false).build());
            Integer realGoalScene = resourcePackageSaleGroupGoalSceneGetAbility.handle(context, ResourcePackageSaleGroupGoalSceneGetAbilityParam.builder()
                    .abilityTarget(resourcePackageSaleGroupViewDTO).needReal(true).build());
            campaignGroupSaleGroupPageViewDTO.setGoalScene(goalScene);
            campaignGroupSaleGroupPageViewDTO.setRealGoalScene(realGoalScene);
            campaignGroupSaleGroupPageViewDTO.setAlgoEstimateStatus(BrandBoolEnum.BRAND_FALSE.getCode());
            return null;
        }
        //db存在情况
        Integer goalScene = saleGroupGoalSceneGetAbility.handle(context, SaleGroupGoalSceneGetAbilityParam.builder()
                .abilityTarget(dbSaleGroupInfoViewDTO).needReal(false).build());
        Integer realGoalScene = saleGroupGoalSceneGetAbility.handle(context, SaleGroupGoalSceneGetAbilityParam.builder()
                .abilityTarget(dbSaleGroupInfoViewDTO).needReal(true).build());
        campaignGroupSaleGroupPageViewDTO.setGoalScene(goalScene);
        campaignGroupSaleGroupPageViewDTO.setRealGoalScene(realGoalScene);
        //有交付场景
        List<Integer> goalSceneList = Lists.newArrayList(SaleGroupGoalSceneEnum.N_REACH.getValue(), SaleGroupGoalSceneEnum.NO_REACH.getValue());
        if (goalSceneList.contains(realGoalScene) && dbSaleGroupInfoViewDTO.getAmount() != null && CollectionUtils.isNotEmpty(campaignViewDTOList)) {
            CampaignGroupSaleGroupEstimateInfoViewDTO estimateInfoViewDTO = saleGroupRebuildEstimateResultAbility.handle(context, SaleGroupEstimateResultRebuildAbilityParam.builder()
                    .abilityTarget(dbSaleGroupInfoViewDTO).packageSaleGroupViewDTO(resourcePackageSaleGroupViewDTO).build());
            campaignGroupSaleGroupPageViewDTO.setEstimateResult(estimateInfoViewDTO);
        }
        //分组预估状态
        Long budget = Optional.ofNullable(resourcePackageSaleGroupViewDTO.getBudget()).orElse(0L);
        if (budget > 0 && CollectionUtils.isNotEmpty(campaignViewDTOList)) {
            campaignGroupSaleGroupPageViewDTO.setAlgoEstimateStatus(BizSaleGroupToolsHelper.getAlgoEstimateStatus(campaignGroupSaleGroupPageViewDTO));
        } else if (budget == 0) {
            campaignGroupSaleGroupPageViewDTO.setAlgoEstimateStatus(BrandBoolEnum.BRAND_TRUE.getCode());
        }
        return null;
    }

    @Override
    public Void invokeForCampaignAdd(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        SaleGroupInfoViewDTO saleGroupInfoViewDTO = campaignGroupRepository.getSaleGroup(serviceContext, campaignViewDTO.getCampaignGroupId(),
                campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId());
        if(Objects.isNull(saleGroupInfoViewDTO)){
            return null;
        }
        //TA人群校验
        campaignTaCrowdValidateForAddCampaignAbility.handle(serviceContext, CampaignTaCrowdValidateForAddCampaignAbilityParam.builder()
                .abilityTarget(campaignViewDTO).saleGroupInfoViewDTO(saleGroupInfoViewDTO).build());
        //初始化品牌算法人群
        campaignAlgoTaCrowdInitForAddCampaignAbility.handle(serviceContext, CampaignAlgoTaCrowdInitForAddCampaignAbilityParam.builder()
                .abilityTarget(campaignViewDTO).saleGroupInfoViewDTO(saleGroupInfoViewDTO).build());
        return null;
    }

    @Override
    public Void invokeForCampaignAlgoControlCrowdAdd(ServiceContext serviceContext, CampaignViewDTO campaignTreeViewDTO) {
        // 二三环
        if (BizCampaignToolsHelper.isTXorShowmaxCampaign(campaignTreeViewDTO.getCampaignResourceViewDTO().getSspMediaScope(), campaignTreeViewDTO.getCampaignResourceViewDTO().getSspProductLineId())) {
            return null;
        }
        SaleGroupInfoViewDTO saleGroupInfoViewDTO = campaignGroupRepository.getSaleGroup(serviceContext, campaignTreeViewDTO.getCampaignGroupId(),
                campaignTreeViewDTO.getCampaignSaleViewDTO().getSaleGroupId());
        if(Objects.isNull(saleGroupInfoViewDTO)){
            return null;
        }
        // 删除
        campaignAlgoControlCrowdDeleteAbility.handle(serviceContext, CampaignAlgoControlCrowdDeleteAbilityParam.builder().abilityTarget(campaignTreeViewDTO).build());
        // 查询单元
        AdgroupQueryViewDTO queryViewDTO = new AdgroupQueryViewDTO();
        queryViewDTO.setCampaignId(campaignTreeViewDTO.getId());
        queryViewDTO.setTargetType(BrandAdgroupTargetTypeEnum.PROGRAM.getCode());
        AdgroupQueryOption queryOption = new AdgroupQueryOption();
        queryOption.setNeedTarget(true);
        List<AdgroupViewDTO> adgroupViewDTOList = adgroupStructureQueryAbility.handle(serviceContext, AdgroupStructureQueryAbilityParam.builder().abilityTarget(queryViewDTO).queryOption(queryOption).build());
        // 删除单元投前黑盒人群
        adgroupAlgoControlCrowdDeleteAbility.handle(serviceContext, AdgroupAlgoControlCrowdDeleteAbilityParam.builder()
                .abilityTargets(adgroupViewDTOList).build());

        // "算法调控通投"人群
        boolean needAddAlgoControlCrowd = campaignAlgoControlCrowdJudgeForAddOrUpdateCampaignAbility.handle(serviceContext, CampaignAlgoControlCrowdJudgeForAddOrUpdateCampaignAbilityParam.builder()
                .abilityTarget(campaignTreeViewDTO).saleGroupInfoViewDTO(saleGroupInfoViewDTO).build());
        if (!needAddAlgoControlCrowd) {
            return null;
        }
        // 初始化计划算法调控人群
        campaignAlgoControlCrowdInitForAddCrowdAbility.handle(serviceContext, CampaignAlgoControlCrowdInitForAddCrowdAbilityParam.builder()
                .abilityTarget(campaignTreeViewDTO).build());
        // 新增计划算法调控人群
        campaignAlgoControlCrowdAddAbility.handle(serviceContext, CampaignAlgoControlCrowdAddAbilityParam.builder()
                .abilityTarget(campaignTreeViewDTO).build());

        // 新增单元算法调控人群
        if (CollectionUtils.isNotEmpty(adgroupViewDTOList)) {
            adgroupAlgoControlCrowdAddAbility.handle(serviceContext, AdgroupAlgoControlCrowdAddAbilityParam.builder()
                    .abilityTargets(adgroupViewDTOList).campaignViewDTO(campaignTreeViewDTO).build());
        }

        return null;
    }

    @Override
    public Void invokeForCampaignUpdate(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, CampaignViewDTO dbCampaignTreeViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        return invokeForCampaignAdd(serviceContext, campaignViewDTO, businessAbilityRouteContext);
    }

    @Override
    public Void invokeForAdgroupAdd(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, CampaignViewDTO campaignViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        List<AdgroupCrowdViewDTO> adgroupCrowdViewDTOList = Optional.ofNullable(adgroupViewDTO.getAdgroupCrowdScenarioViewDTO())
                .map(AdgroupCrowdScenarioViewDTO::getAdgroupCrowdViewDTOList).orElse(null);
        if (CollectionUtils.isEmpty(adgroupCrowdViewDTOList)) {
            return null;
        }
        return adgroupAlgoTaCrowdInitForAddAdgroupAbility.handle(serviceContext, AdgroupAlgoTaCrowdInitForAddAdgroupAbilityParam.builder()
                .abilityTarget(adgroupViewDTO).campaignViewDTO(campaignViewDTO).build());
    }
    /**
     * 执行商业能力调用
     * @param serviceContext
     * @param adgroupViewDTO
     * @param campaignViewDTO
     * @param businessAbilityRouteContext
     * @return
     */
    @Override
    public Void invokeForAfterAdgroupAdd(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, CampaignViewDTO campaignViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        // 删除
        adgroupAlgoControlCrowdDeleteAbility.handle(serviceContext, AdgroupAlgoControlCrowdDeleteAbilityParam.builder()
                .abilityTargets(Lists.newArrayList(adgroupViewDTO)).build());
        // 新增
        adgroupAlgoControlCrowdAddAbility.handle(serviceContext, AdgroupAlgoControlCrowdAddAbilityParam.builder()
                .abilityTargets(Lists.newArrayList(adgroupViewDTO)).campaignViewDTO(campaignViewDTO).build());
        return null;
    }

    @Override
    public Void invokeForAdgroupUpdate(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, CampaignViewDTO campaignViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        return invokeForAdgroupAdd(serviceContext, adgroupViewDTO, campaignViewDTO, businessAbilityRouteContext);
    }
    /**
     * 执行商业能力调用
     * @param serviceContext
     * @param adgroupViewDTO
     * @param campaignViewDTO
     * @param businessAbilityRouteContext
     * @return
     */
    @Override
    public Void invokeForAfterAdgroupUpdate(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, CampaignViewDTO campaignViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        return invokeForAfterAdgroupAdd(serviceContext, adgroupViewDTO, campaignViewDTO, businessAbilityRouteContext);
    }

    @Override
    public AdgroupViewDTO invokeForGenerateNReachAdgroup(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {
        SaleGroupInfoViewDTO saleGroupInfoViewDTO = campaignGroupRepository.getSaleGroup(serviceContext, campaignViewDTO.getCampaignGroupId(),
                campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId());
        AssertUtil.notNull(saleGroupInfoViewDTO, "订单分组不存在");
        //1、是否构建优化单元
        Boolean needNReachAdgroup = adgroupNReachJudgeAbility.handle(serviceContext, AdgroupNReachJudgeAbilityParam.builder()
                .abilityTarget(campaignViewDTO).saleGroupInfoViewDTO(saleGroupInfoViewDTO).build());
        if (!needNReachAdgroup) {
            RogerLogger.info(String.format("计划ID:%s 无需创建优化单元", campaignViewDTO.getId()));
            return null;
        }
        //2、要增加分组的全部人群
        List<CrowdViewDTO> crowdViewDTOList = saleGroupCrowdQueryAbility.handle(serviceContext, SaleGroupCrowdQueryAbilityParam.builder()
                .abilityTarget(saleGroupInfoViewDTO).build());
        List<AdgroupCrowdViewDTO> crowdBaseViewDTOList = Optional.ofNullable(crowdViewDTOList).orElse(Lists.newArrayList()).stream().map(item -> {
            AdgroupCrowdViewDTO crowdBaseViewDTO = new AdgroupCrowdViewDTO();
            crowdBaseViewDTO.setCrowdId(item.getCrowdId());
            crowdBaseViewDTO.setCrowdName(item.getCrowdName());
            crowdBaseViewDTO.setTargetType(BrandTargetTypeEnum.DMP_CROWD.getCode().longValue());
            return crowdBaseViewDTO;
        }).collect(Collectors.toList());
        //3、生成优化单元
        AdgroupViewDTO nReachAdgroupViewDTO = new AdgroupViewDTO();

        AdgroupQueryViewDTO adgroupQueryViewDTO = new AdgroupQueryViewDTO();
        adgroupQueryViewDTO.setCampaignId(campaignViewDTO.getId());
        adgroupQueryViewDTO.setBottomType(BrandAdgroupBottomTypeEnum.N_REACH.getCode());
        List<AdgroupViewDTO> adgroupViewDTOList = adgroupRepository.queryAdgroupListNoPage(serviceContext, adgroupQueryViewDTO);
        if (CollectionUtils.isNotEmpty(adgroupViewDTOList)) {
            RogerLogger.info("计划ID:{}下优化单元已经存在,单元ID:{}", campaignViewDTO.getId(), adgroupViewDTOList.get(0).getId());
            nReachAdgroupViewDTO = adgroupViewDTOList.get(0);
            adgroupInitForUpdateNReachAdgroupAbility.handle(serviceContext, AdgroupInitForUpdateNReachAdgroupAbilityParam.builder()
                    .abilityTarget(nReachAdgroupViewDTO).campaignViewDTO(campaignViewDTO).build());
        } else {
            adgroupInitForAddNReachAdgroupAbility.handle(serviceContext, AdgroupInitForAddNReachAdgroupAbilityParam.builder()
                    .abilityTarget(nReachAdgroupViewDTO).campaignViewDTO(campaignViewDTO).build());
        }

        AdgroupCrowdScenarioViewDTO crowdScenarioViewDTO = new AdgroupCrowdScenarioViewDTO();
        crowdScenarioViewDTO.setAdgroupCrowdViewDTOList(crowdBaseViewDTOList);
        nReachAdgroupViewDTO.setAdgroupCrowdScenarioViewDTO(crowdScenarioViewDTO);

        return nReachAdgroupViewDTO;
    }
}
