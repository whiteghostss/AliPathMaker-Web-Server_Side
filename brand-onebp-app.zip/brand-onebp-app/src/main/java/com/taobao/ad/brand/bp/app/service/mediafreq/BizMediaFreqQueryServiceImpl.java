package com.taobao.ad.brand.bp.app.service.mediafreq;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.media.freq.MediaFreqViewDTO;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.api.mediafreq.BizMediaFreqQueryService;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.mediafreq.query.MediaFreqQueryViewDTO;
import com.taobao.ad.brand.bp.domain.mediafreq.MediaFreqRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 媒体频控查询服务
 *
 * @author shiyan
 * @date 2023/7/20
 **/
@HSFProvider(serviceInterface = BizMediaFreqQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizMediaFreqQueryServiceImpl implements BizMediaFreqQueryService {
    private final MediaFreqRepository mediaFreqRepository;

    @Override
    public MultiResponse<MediaFreqViewDTO> findListWithPage(ServiceContext context, MediaFreqQueryViewDTO queryViewDTO) {
        PageResultViewDTO<MediaFreqViewDTO> pageResultViewDTO = mediaFreqRepository.findListWithPage(context, queryViewDTO);
        return MultiResponse.of(pageResultViewDTO.getList(),pageResultViewDTO.getCount());
    }

    @Override
    public SingleResponse<MediaFreqViewDTO> getMediaFreq(ServiceContext context, Long id) {
        return SingleResponse.of(mediaFreqRepository.getMediaFreq(context,id));
    }
}