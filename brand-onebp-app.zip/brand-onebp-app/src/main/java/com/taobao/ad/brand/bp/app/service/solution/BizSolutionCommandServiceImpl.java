package com.taobao.ad.brand.bp.app.service.solution;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.app.workflow.solution.BizSolutionCommandWorkflow;
import com.taobao.ad.brand.bp.client.api.solution.BizSolutionCommandService;
import com.taobao.ad.brand.bp.client.dto.solution.CartItemSolutionOrderViewDTO;
import com.taobao.ad.brand.bp.client.dto.solution.CartItemSolutionViewDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

@HSFProvider(serviceInterface = BizSolutionCommandService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizSolutionCommandServiceImpl implements BizSolutionCommandService {

    private final BizSolutionCommandWorkflow bizSolutionCommandWorkflow;

    @Override
    public SingleResponse<Long> addCartItemSolution(ServiceContext context, CartItemSolutionViewDTO solutionCommandViewDTO) {
        Long cartItemId = bizSolutionCommandWorkflow.addCartItemSolution(context, solutionCommandViewDTO);
        return SingleResponse.of(cartItemId);
    }

    @Override
    public SingleResponse<Long> updateCartItemSolution(ServiceContext context, CartItemSolutionViewDTO solutionCommandViewDTO) {
        Long cartItemId = bizSolutionCommandWorkflow.updateCartItemSolution(context, solutionCommandViewDTO);
        return SingleResponse.of(cartItemId);
    }

    @Override
    public SingleResponse<Long> orderCartItemSolution(ServiceContext context, CartItemSolutionOrderViewDTO solutionOrderViewDTO) {
        Long campaignGroupId = bizSolutionCommandWorkflow.orderCartItemSolution(context, solutionOrderViewDTO);
        return SingleResponse.of(campaignGroupId);
    }

    @Override
    public Response deleteCartItemSolution(ServiceContext context, Long id) {
        bizSolutionCommandWorkflow.deleteCartItemSolution(context, id);
        return Response.success();
    }
}
