package com.taobao.ad.brand.bp.app.service.campaigngroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupBoostGiveApplyInfoViewDTO;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.app.workflow.salegroup.BizSaleGroupCommandWorkflow;
import com.taobao.ad.brand.bp.client.api.campaigngroup.BizCampaignGroupSaleGroupCommandService;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.salegroup.CampaignGroupSaleGroupBoostGiveApplyViewDTO;
import com.taobao.ad.brand.bp.domain.salegroup.converter.BizSaleGroupBoostGiveApplyConverter;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author yanjingang
 * @date 2023/9/16
 */
@HSFProvider(serviceInterface = BizCampaignGroupSaleGroupCommandService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizCampaignGroupSaleGroupCommandServiceImpl implements BizCampaignGroupSaleGroupCommandService {

    private final BizSaleGroupCommandWorkflow bizSaleGroupCommandWorkflow;
    private final BizSaleGroupBoostGiveApplyConverter bizSaleGroupBoostGiveApplyConverter;

    @Override
    public SingleResponse<Long> applySaleGroup(ServiceContext context, CampaignGroupSaleGroupBoostGiveApplyViewDTO applyViewDTO) {
        SaleGroupBoostGiveApplyInfoViewDTO saleGroupBoostGiveApplyInfoViewDTO = bizSaleGroupBoostGiveApplyConverter.convertViewDTO2DTO(applyViewDTO);
        return SingleResponse.of(bizSaleGroupCommandWorkflow.applySaleGroup(context, saleGroupBoostGiveApplyInfoViewDTO, applyViewDTO));
    }

    @Override
    public SingleResponse<Long> deleteApplySaleGroup(ServiceContext context, CampaignGroupSaleGroupBoostGiveApplyViewDTO applyViewDTO) {
        SaleGroupBoostGiveApplyInfoViewDTO saleGroupBoostGiveApplyInfoViewDTO = bizSaleGroupBoostGiveApplyConverter.convertViewDTO2DTO(applyViewDTO);
        return SingleResponse.of(bizSaleGroupCommandWorkflow.deleteSaleGroup(context, saleGroupBoostGiveApplyInfoViewDTO, applyViewDTO));
    }
}
