package com.taobao.ad.brand.bp.app.workflow.campaigngroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityInject;
import com.alibaba.abf.isolation.spec.common.ReduceType;
import com.alibaba.abf.isolation.utils.AbilityInvoker;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.price.DayPriceViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.ResourcePackageProductViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.salegroup.CampaignGroupSaleGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignSaleUnitEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSaleOrderStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupStatusEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleProductLineEnum;
import com.alibaba.ad.nb.ssp.constant.newproduct.DeliveryTargetEnum;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignQueryWorkflow;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupDistributionRuleViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupResourcePackageViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupPageViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSettleInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.ContractContentCampaignViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.ContractContentViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.SaleGroupCanDeleteViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignGroupRealSettleQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignGroupSaleGroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.SaleGroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.sales.CampaignGroupBriefSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.sales.CampaignGroupBriefViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourceDistributionRuleViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSkuViewDTO;
import com.taobao.ad.brand.bp.common.converter.campaigngroup.CampaignGroupConverter;
import com.taobao.ad.brand.bp.common.converter.campaigngroup.CampaignGroupSaleGroupConverter;
import com.taobao.ad.brand.bp.common.converter.campaigngroup.CampaignGroupSettleConverter;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizSaleGroupToolsHelper;
import com.taobao.ad.brand.bp.common.threadpooltask.SaleGroupEstimateTaskIdentifier;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.NumberUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.ability.BizCampaignGroupProcessAbility;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.memeber.MemberRepository;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbilityRouteContext;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.workflow.BizCampaignGroupQueryWorkflowExt;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.businessability.ISaleGroupQueryBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.shopwindow.repository.BrandSkuRepository;
import com.taobao.ad.brand.bp.domain.ssp.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/04/13
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizCampaignGroupQueryWorkflow {
    private final BizCampaignGroupProcessAbility bizCampaignGroupProcessAbility;
    private final CampaignGroupRepository campaignGroupRepository;
    private final ResourcePackageRepository resourcePackageRepository;
    private final BizCampaignQueryWorkflow bizCampaignQueryWorkflow;
    private final BrandSkuRepository brandSkuRepository;
    private final ProductRepository productRepository;
    private final MemberRepository memberRepository;

    private final CampaignGroupConverter campaignGroupConverter;
    private final CampaignGroupSettleConverter campaignGroupSettleConverter;
    private final CampaignGroupSaleGroupConverter campaignGroupSaleGroupConverter;

    @AbilityInject(reduce = ReduceType.FIRST)
    private final BizCampaignGroupQueryWorkflowExt bizCampaignGroupQueryWorkflowExt;

    private final SaleGroupEstimateTaskIdentifier saleGroupEstimateTaskIdentifier;

//    private static final ThreadPoolExecutor SALEGROUP_ESTIMATE_THREAD_POOL = new ThreadPoolExecutor(
//            30, 30, 60L, TimeUnit.SECONDS, new ArrayBlockingQueue<>(4096),
//            new ThreadFactoryBuilder().setNameFormat("saleGroup_estimate-%d").build());


    /**
     * 构建订单资源详情
     */
    public CampaignGroupResourcePackageViewDTO buildCampaignGroupResourcePackage(ServiceContext serviceContext,
                                                                                 CampaignGroupViewDTO campaignGroup,
                                                                                 List<ResourcePackageSaleGroupViewDTO> resourceSaleGroupList,
                                                                                 List<CampaignViewDTO> campaignList,
                                                                                 CampaignGroupSaleGroupQueryViewDTO queryViewDTO) {
        //比对资源包分组和本地分组
        CampaignGroupResourcePackageViewDTO campaignGroupResourcePackageViewDTO = campaignGroupConverter.convertBaseInfo(campaignGroup);
        // 设置客户memberName
        campaignGroupResourcePackageViewDTO.setCusMemberName(memberRepository.getMemberNameById(campaignGroupResourcePackageViewDTO.getCusMemberId()));

        //构建包分组信息
        List<CampaignGroupSaleGroupPageViewDTO> campaignGroupSaleGroupList = campaignGroupSaleGroupConverter.convertDTO2ViewDTOList(resourceSaleGroupList);
        if (CollectionUtils.isEmpty(campaignGroupSaleGroupList)) {
            return campaignGroupResourcePackageViewDTO;
        }
        //补充分组计算字段值、是否能编辑、是否更新信息
        campaignGroupSaleGroupList = this.fillCampaignGroupSaleGroupInfo(serviceContext,campaignGroup, resourceSaleGroupList,
            campaignGroupSaleGroupList, campaignList, queryViewDTO);
        //补充资源产品计划信息
        fillResourcePackageProductCampaignCount(campaignGroupSaleGroupList, campaignList);
        //补充分组勾选信息
        fillCheckedResourcePackageProductList(campaignGroup.getCampaignGroupSaleGroupViewDTO(), campaignGroupSaleGroupList);
        //获取更新的分组ID
        List<Long> updatedSaleGroupIds = getUpdatedSaleGroupIds(serviceContext, resourceSaleGroupList, campaignGroup);
        for (CampaignGroupSaleGroupPageViewDTO campaignGroupSaleGroupPageViewDTO : campaignGroupSaleGroupList) {
            int hasUpdate = updatedSaleGroupIds.contains(campaignGroupSaleGroupPageViewDTO.getSaleGroupId()) ? BrandBoolEnum.BRAND_TRUE.getCode() :
                BrandBoolEnum.BRAND_FALSE.getCode();
            campaignGroupSaleGroupPageViewDTO.setHasUpdate(hasUpdate);
            if (CollectionUtils.isNotEmpty(campaignGroupSaleGroupPageViewDTO.getDeliveryTargetList())){
                campaignGroupSaleGroupPageViewDTO.getDeliveryTargetList().removeIf(item->item.getDeliveryTarget().equals(DeliveryTargetEnum.EXPOSURE.getValue()));
            }

        }
        //内容场景下补充分组信息
        bizCampaignGroupQueryWorkflowExt.fillOtherInfo(serviceContext, campaignGroupSaleGroupList, resourceSaleGroupList);
        campaignGroupResourcePackageViewDTO.setSaleGroupList(campaignGroupSaleGroupList);
        return campaignGroupResourcePackageViewDTO;
    }

    /**
     * 补充计划数量
     * @param campaignGroupSaleGroupPageViewDTOS
     */
    private void fillResourcePackageProductCampaignCount(List<CampaignGroupSaleGroupPageViewDTO> campaignGroupSaleGroupPageViewDTOS,
                                                        List<CampaignViewDTO> campaignList) {
        Map<Long, List<CampaignViewDTO>> productCampaignMap = Optional.ofNullable(campaignList).orElse(Lists.newArrayList()).stream().collect(
                Collectors.groupingBy(v -> v.getCampaignSaleViewDTO().getResourcePackageProductId()));
        for (CampaignGroupSaleGroupPageViewDTO campaignGroupSaleGroupPageViewDTO : campaignGroupSaleGroupPageViewDTOS) {
            List<CampaignGroupDistributionRuleViewDTO> distributionRuleList = campaignGroupSaleGroupPageViewDTO.getDistributionRuleList();
            if (CollectionUtils.isEmpty(distributionRuleList)) {
                continue;
            }
            for (CampaignGroupDistributionRuleViewDTO campaignGroupDistributionRuleViewDTO : distributionRuleList) {
                List<CampaignGroupProductViewDTO> resourcePackageProductList = campaignGroupDistributionRuleViewDTO
                        .getResourcePackageProductList();
                if (CollectionUtils.isEmpty(resourcePackageProductList)) {
                    continue;
                }
                for (CampaignGroupProductViewDTO productViewDTO : resourcePackageProductList) {
                    List<CampaignViewDTO> campaignViewDTOList = productCampaignMap.get(productViewDTO.getResourcePackageProductId());
                    int campaignCount = CollectionUtils.isEmpty(campaignViewDTOList) ? 0 : campaignViewDTOList.size();
                    productViewDTO.setCampaignCount(campaignCount);
                }
            }
        }
    }

    /**
     * 补充订单编辑页勾选的资源产品
     */
    private void fillCheckedResourcePackageProductList(CampaignGroupSaleGroupViewDTO saleGroupViewDTO,
                                                      List<CampaignGroupSaleGroupPageViewDTO> campaignGroupSaleGroupPageViewDTOS) {
        Set<Long> checkedProductIdList = saleGroupViewDTO.getCheckedResourcePackageProductIdList() == null ? Sets.newHashSet() : Sets.newHashSet(
                saleGroupViewDTO.getCheckedResourcePackageProductIdList());
        for (CampaignGroupSaleGroupPageViewDTO campaignGroupSaleGroupPageViewDTO : campaignGroupSaleGroupPageViewDTOS) {
            List<CampaignGroupDistributionRuleViewDTO> distributionRuleList = campaignGroupSaleGroupPageViewDTO.getDistributionRuleList();
            if (CollectionUtils.isEmpty(distributionRuleList)) {
                continue;
            }
            for (CampaignGroupDistributionRuleViewDTO campaignGroupDistributionRuleViewDTO : distributionRuleList) {
                List<CampaignGroupProductViewDTO> resourcePackageProductList = campaignGroupDistributionRuleViewDTO
                        .getResourcePackageProductList();
                if (CollectionUtils.isEmpty(resourcePackageProductList)) {
                    continue;
                }
                for (CampaignGroupProductViewDTO productViewDTO : resourcePackageProductList) {
                    boolean checked = checkedProductIdList.contains(productViewDTO.getResourcePackageProductId());
                    boolean isNecessary = BrandBoolEnum.BRAND_TRUE.getCode().equals(productViewDTO.getIsNecessary());
                    boolean hasCampaign = productViewDTO.getCampaignCount() > 0;
                    if (checked || isNecessary || hasCampaign) {
                        productViewDTO.setChecked(BrandBoolEnum.BRAND_TRUE.getCode());
                    } else {
                        productViewDTO.setChecked(BrandBoolEnum.BRAND_FALSE.getCode());
                    }
                }
            }
        }
    }

    /**
     * 获取金额和单价已经更新的分组ID
     */
    private List<Long> getUpdatedSaleGroupIds(ServiceContext serviceContext,
                                             List<ResourcePackageSaleGroupViewDTO> saleGroupList,
                                             CampaignGroupViewDTO campaignGroup) {
        RogerLogger.info("saleGroupList:{}, campaignGroup:{}", JSON.toJSONString(saleGroupList), JSON.toJSONString(campaignGroup));
        //订单上的
        List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList = campaignGroup.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList();
        if (CollectionUtils.isEmpty(saleGroupInfoViewDTOList)) {
            return Lists.newArrayList();
        }
        //主订单
        SaleGroupQueryViewDTO saleGroupQueryViewDTO = new SaleGroupQueryViewDTO();
        saleGroupQueryViewDTO.setCampaignGroupIds(Lists.newArrayList(campaignGroup.getParentId()));
        List<SaleGroupInfoViewDTO> parentCampaignGroupSaleGroupList = campaignGroupRepository.findSaleGroupList(serviceContext, saleGroupQueryViewDTO);
        RogerLogger.info("parentCampaignGroupSaleGroupList:{}", JSON.toJSONString(parentCampaignGroupSaleGroupList));
        Map<Long, SaleGroupInfoViewDTO> parentSaleGroupMap = parentCampaignGroupSaleGroupList.stream()
                .collect(Collectors.toMap(SaleGroupInfoViewDTO::getSaleGroupId, Function.identity(), (v1, v2) -> v1));
        //资源包
        Map<Long, ResourcePackageSaleGroupViewDTO> saleGroupMap = saleGroupList.stream().collect(
                Collectors.toMap(ResourcePackageSaleGroupViewDTO::getId, Function.identity()));
        List<Long> updatedSaleGroupIds = Lists.newArrayList();
        for (SaleGroupInfoViewDTO calculateInfo : saleGroupInfoViewDTOList) {
            ResourcePackageSaleGroupViewDTO saleGroupViewDTO = saleGroupMap.get(calculateInfo.getSaleGroupId());
            // 下单情况只需要校验当前下单分组，saleGroupMap中只有当前下单分组
            if (Objects.isNull(saleGroupViewDTO)) {
                continue;
            }
            SaleGroupInfoViewDTO parentCamSaleGroup = parentSaleGroupMap.get(calculateInfo.getSaleGroupId());

            //新场景中，计算分组budget=null表示：新增，未计算过
            //新场景中，计算分组calcBudget=null表示：新增，未计算过
            boolean hasUpdate = Objects.nonNull(calculateInfo.getCalcBudget())
                    && Objects.nonNull(parentCamSaleGroup) && Objects.nonNull(parentCamSaleGroup.getBudget())
                    && !Objects.equals(parentCamSaleGroup.getBudget(), calculateInfo.getCalcBudget());
            hasUpdate = hasUpdate || validateProductPriceChanges(saleGroupViewDTO, calculateInfo.getResourcePackageProductViewDTOList());
            if (hasUpdate) {
                updatedSaleGroupIds.add(calculateInfo.getSaleGroupId());
            }
        }
        return updatedSaleGroupIds;
    }


    /**
     * 资源包单价是否已更新
     * 1-是，0-否
     */
    private boolean validateProductPriceChanges(ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO,
                                                List<ResourcePackageProductViewDTO> campaignGroupResourcePackageProductViewDTOList) {
        RogerLogger.info("resourcePackageSaleGroupViewDTO:{}, campaignGroupResourcePackageProductViewDTOList:{}", JSON.toJSONString(resourcePackageSaleGroupViewDTO), JSON.toJSONString(campaignGroupResourcePackageProductViewDTOList));
        Map<String, Long> productUnitPriceMap = Maps.newHashMap();
        for (ResourceDistributionRuleViewDTO resourceDistributionRuleViewDTO : resourcePackageSaleGroupViewDTO.getDistributionRuleList()) {
            if (CollectionUtils.isEmpty(resourceDistributionRuleViewDTO.getResourcePackageProductList())) {
                continue;
            }
            for (com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO resourcePackageProductViewDTO :
                    resourceDistributionRuleViewDTO.getResourcePackageProductList()) {
                for (ResourcePackageProductPriceViewDTO priceViewDTO : resourcePackageProductViewDTO.getBandPriceList()) {
                    Set<Date> betweenDates = BrandDateUtil.getBetweenDatesDateResult(priceViewDTO.getStartDate(),
                            priceViewDTO.getEndDate());
                    for (Date date : betweenDates) {
                        productUnitPriceMap.put(getUniqueKey(resourcePackageProductViewDTO.getId(), date), priceViewDTO.getPrice());
                    }
                }
            }
        }
        if(CollectionUtils.isNotEmpty(campaignGroupResourcePackageProductViewDTOList)){
            for (ResourcePackageProductViewDTO productViewDTO : campaignGroupResourcePackageProductViewDTOList) {
                for (DayPriceViewDTO dayPriceViewDTO : productViewDTO.getDiscountDayPriceInfoViewDTOList()) {
                    Set<Date> betweenDates = BrandDateUtil.getBetweenDatesDateResult(dayPriceViewDTO.getStartDate(),
                            dayPriceViewDTO.getEndDate());
                    for (Date date : betweenDates) {
                        String uniqueKey = getUniqueKey(productViewDTO.getResourcePackageProductId(), date);
                        boolean equal = dayPriceViewDTO.getPrice().equals(productUnitPriceMap.get(uniqueKey));
                        if (!equal) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    private String getUniqueKey(Long resourcePackageProductId, Date date) {
        return resourcePackageProductId + "_" + BrandDateUtil.date2String(date);
    }

    /**
     * 补充订单分组信息
     *
     * @param campaignGroup
     * @param resourceSaleGroupList          资源包的saleGroupList
     * @param campaignGroupSaleGroupPageViewDTOS
     * @param campaignList
     * @param queryViewDTO
     */
    public List<CampaignGroupSaleGroupPageViewDTO> fillCampaignGroupSaleGroupInfo(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroup,
                                                                                  List<ResourcePackageSaleGroupViewDTO> resourceSaleGroupList,
                                                                                  List<CampaignGroupSaleGroupPageViewDTO> campaignGroupSaleGroupPageViewDTOS,
                                                                                  List<CampaignViewDTO> campaignList,
                                                                                  CampaignGroupSaleGroupQueryViewDTO queryViewDTO) {
        CampaignGroupSaleGroupViewDTO saleGroupViewDTO = campaignGroup.getCampaignGroupSaleGroupViewDTO();
        //DB里的
        Map<Long, SaleGroupInfoViewDTO> dbSaleGroupMap = Optional.ofNullable(saleGroupViewDTO.getSaleGroupInfoViewDTOList()).orElse(Lists.newArrayList()).stream()
                .filter(saleGroupInfoViewDTO -> Objects.nonNull(saleGroupInfoViewDTO.getBudget())).collect(Collectors.toMap(SaleGroupInfoViewDTO::getSaleGroupId, v -> v, (o1, o2) -> o2));
        Map<Long, List<Long>> dbMain2BoostSaleGroupIdMap = Optional.ofNullable(saleGroupViewDTO.getSaleGroupInfoViewDTOList()).orElse(Lists.newArrayList()).stream()
                .filter(saleGroupInfoViewDTO -> BrandSaleTypeEnum.BOOST.getCode().equals(saleGroupInfoViewDTO.getSaleType()))
                .filter(saleGroupInfoViewDTO -> saleGroupInfoViewDTO.getMainSaleGroupId() != null)
                .collect(Collectors.groupingBy(SaleGroupInfoViewDTO::getMainSaleGroupId, Collectors.mapping(SaleGroupInfoViewDTO::getSaleGroupId, Collectors.toList())));
        Map<Long, List<Long>> dbMain2GiveSaleGroupIdMap = Optional.ofNullable(saleGroupViewDTO.getSaleGroupInfoViewDTOList()).orElse(Lists.newArrayList()).stream()
                .filter(saleGroupInfoViewDTO -> BrandSaleTypeEnum.PRESENT.getCode().equals(saleGroupInfoViewDTO.getSaleType()))
                .filter(saleGroupInfoViewDTO -> saleGroupInfoViewDTO.getMainSaleGroupId() != null)
                .collect(Collectors.groupingBy(SaleGroupInfoViewDTO::getMainSaleGroupId, Collectors.mapping(SaleGroupInfoViewDTO::getSaleGroupId, Collectors.toList())));
        //售卖分组-计划映射map
        Map<Long, List<CampaignViewDTO>> dbSaleGroupCampaignMap = Optional.ofNullable(campaignList).orElse(Lists.newArrayList()).stream()
                .filter(campaignViewDTO -> campaignViewDTO.getCampaignSaleViewDTO() != null && campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId() != null)
                .collect(Collectors.groupingBy(campaignViewDTO -> campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId()));
        //售卖分组-状态map
        Map<Long, Integer> dbSaleGroupOrderStatusMap = saleGroupViewDTO.getSaleGroupInfoViewDTOList().stream().collect(
                Collectors.toMap(SaleGroupInfoViewDTO::getSaleGroupId, SaleGroupInfoViewDTO::getSaleGroupStatus));

        //资源包售卖分组-状态map
        Map<Long, Integer> resourcePackageSaleGroupStatusMap = resourceSaleGroupList.stream().collect(Collectors.toMap(ResourcePackageSaleGroupViewDTO::getId, ResourcePackageSaleGroupViewDTO::getStatus,(v1,v2) -> v2));
        Map<Long, ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupViewDTOMap = resourceSaleGroupList.stream().collect(Collectors.toMap(ResourcePackageSaleGroupViewDTO::getId, Function.identity(),(v1, v2) -> v2));

        Set<Long> hasDistributionSaleGroupIdSet = resourceSaleGroupList.stream()
                .filter(v -> {
                    if (CollectionUtils.isEmpty(v.getDistributionGroupIds())) {
                        return false;
                    }
                    if (queryViewDTO.isNeedNoBindSaleGroups()) {
                        return true;
                    }
                    return v.getDistributionGroupIds().stream().anyMatch(dbSaleGroupMap::containsKey);
                }).map(ResourcePackageSaleGroupViewDTO::getId).collect(Collectors.toSet());
        Set<Long> hasReplenishSaleGroupIdSet = resourceSaleGroupList.stream()
                .filter(v -> {
                    if (CollectionUtils.isEmpty(v.getReplenishGroupIds())) {
                        return false;
                    }
                    if (queryViewDTO.isNeedNoBindSaleGroups()) {
                        return true;
                    }
                    return v.getReplenishGroupIds().stream().anyMatch(dbSaleGroupMap::containsKey);
                }).map(ResourcePackageSaleGroupViewDTO::getId).collect(Collectors.toSet());

        Set<Long> saleGroupIdSet = resourceSaleGroupList.stream().filter(v -> dbSaleGroupOrderStatusMap.containsKey(v.getId()) ||
                dbSaleGroupOrderStatusMap.containsKey(v.getMainGroupId())).map(ResourcePackageSaleGroupViewDTO::getId).collect(Collectors.toSet());

        List<CampaignGroupSaleGroupPageViewDTO> needOperateSaleGroupViewDTOList = campaignGroupSaleGroupPageViewDTOS.stream().filter(saleGroup -> {
            Long saleGroupId = saleGroup.getSaleGroupId();
            if (!saleGroupIdSet.contains(saleGroupId)) {
                return false;
            }
            // 商家只展示绑定到订单上的分组
            if (!queryViewDTO.isNeedNoBindSaleGroups() && !dbSaleGroupOrderStatusMap.containsKey(saleGroupId)) {
                return false;
            }
            SaleGroupInfoViewDTO dbSaleGroupInfo = dbSaleGroupMap.get(saleGroup.getSaleGroupId());
            if(dbSaleGroupInfo != null && CollectionUtils.isEmpty(saleGroup.getDistributionRuleList())){
                return false;
            }
            return true;
        }).collect(Collectors.toList());

        //填充售卖分组操作预估
        TaskStream.consume(saleGroupEstimateTaskIdentifier, needOperateSaleGroupViewDTOList, (saleGroup, index) -> {
            //商业能力挂载
            ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO = resourcePackageSaleGroupViewDTOMap.get(saleGroup.getSaleGroupId());
            SaleGroupInfoViewDTO dbSaleGroupInfoViewDTO = dbSaleGroupMap.get(saleGroup.getSaleGroupId());
            List<CampaignViewDTO> campaignViewDTOList = dbSaleGroupCampaignMap.getOrDefault(saleGroup.getSaleGroupId(), Lists.newArrayList());

            BusinessAbilityRouteContext routeContext = BusinessAbilityRouteContext.builder().packageSaleGroupViewDTO(resourcePackageSaleGroupViewDTO).build();
            AbilityInvoker.invokeAll(ISaleGroupQueryBusinessAbilityPoint.class,routeContext,
                    callback -> callback.invokeForQuerySaleGroup(serviceContext,saleGroup,dbSaleGroupInfoViewDTO,campaignViewDTOList,routeContext));
            if (Objects.nonNull(dbSaleGroupInfoViewDTO)) {
                saleGroup.setFirstOrderTime(dbSaleGroupInfoViewDTO.getFirstOrderTime());
            }
            //填充操作信息
            fillSaleGroupOperateViewDTO(serviceContext, campaignGroup, saleGroup, dbSaleGroupMap, hasDistributionSaleGroupIdSet, hasReplenishSaleGroupIdSet,
                    resourcePackageSaleGroupStatusMap, dbSaleGroupOrderStatusMap, dbMain2BoostSaleGroupIdMap, dbMain2GiveSaleGroupIdMap);
        }).commit().handle();

        return needOperateSaleGroupViewDTOList;
    }

    /**
     * 填充售卖分组操作信息
     *
     * @param serviceContext
     * @param campaignGroup
     * @param saleGroup
     * @param dbSaleGroupMap
     * @param hasDistributionSaleGroupIdSet
     * @param hasReplenishSaleGroupIdSet
     * @param resourcePackageSaleGroupStatusMap
     * @param dbSaleGroupOrderStatusMap
     * @param dbMain2BoostSaleGroupIdMap
     * @param dbMain2GiveSaleGroupIdMap
     */
    private void fillSaleGroupOperateViewDTO(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroup, CampaignGroupSaleGroupPageViewDTO saleGroup,
                                             Map<Long, SaleGroupInfoViewDTO> dbSaleGroupMap, Set<Long> hasDistributionSaleGroupIdSet, Set<Long> hasReplenishSaleGroupIdSet,
                                             Map<Long, Integer> resourcePackageSaleGroupStatusMap, Map<Long, Integer> dbSaleGroupOrderStatusMap,
                                             Map<Long, List<Long>> dbMain2BoostSaleGroupIdMap, Map<Long, List<Long>> dbMain2GiveSaleGroupIdMap) {
        Long saleGroupId = saleGroup.getSaleGroupId();
        SaleGroupInfoViewDTO calculateSaleGroupInfo = dbSaleGroupMap.get(saleGroup.getSaleGroupId());

        // 是否有配送的分组
        int isDistribution = hasDistributionSaleGroupIdSet.contains(saleGroupId) ? BrandBoolEnum.BRAND_TRUE.getCode()
                : BrandBoolEnum.BRAND_FALSE.getCode();
        saleGroup.setIsDistribution(isDistribution);
        // 是否有补量的分组
        int isReplenish = hasReplenishSaleGroupIdSet.contains(saleGroupId) ? BrandBoolEnum.BRAND_TRUE.getCode() : BrandBoolEnum.BRAND_FALSE.getCode();
        saleGroup.setIsReplenish(isReplenish);

        Integer campaignGroupSaleGroupOrderStatus = dbSaleGroupOrderStatusMap.get(saleGroupId);
        Integer saleGroupEffectiveStatus = resourcePackageSaleGroupStatusMap.get(saleGroupId);

        List<Integer> inValidEditSaleGroupCampaignGroupStatusList = Lists.newArrayList(
                BrandCampaignGroupStatusEnum.FINISHED.getCode(),
                BrandCampaignGroupStatusEnum.REAL_SETTLE_ING.getCode(),
                BrandCampaignGroupStatusEnum.REAL_SETTLED.getCode(),
                BrandCampaignGroupStatusEnum.COMPLETED.getCode(),
                BrandCampaignGroupStatusEnum.CANCELED.getCode()
        );

        boolean currentUserCanEdit = currentUserCanEdit(serviceContext, saleGroup);
        // 是否可以编辑
        if (currentUserCanEdit && dbSaleGroupMap.containsKey(saleGroupId)
                && BrandCampaignGroupSaleOrderStatusEnum.WAIT_ORDER.getCode().equals(campaignGroupSaleGroupOrderStatus)
                && SaleGroupStatusEnum.EFFECTIVE.getValue().equals(saleGroupEffectiveStatus)
                && !inValidEditSaleGroupCampaignGroupStatusList.contains(campaignGroup.getStatus())) {
            saleGroup.setCanEdit(BrandBoolEnum.BRAND_TRUE.getCode());
        } else {
            saleGroup.setCanEdit(BrandBoolEnum.BRAND_FALSE.getCode());
        }

        // 是否可编辑补配申请信息
        if (BizSaleGroupToolsHelper.isBpApplyBoostGiveSaleGroup(saleGroup, dbSaleGroupMap)
                && BizSaleGroupToolsHelper.boostGiveSaleGroupIsNotAuditIng(saleGroup)) {
            //补量配送分组
            saleGroup.setCanEditSaleGroupApply(BrandBoolEnum.BRAND_TRUE.getCode());
        } else {
            saleGroup.setCanEditSaleGroupApply(BrandBoolEnum.BRAND_FALSE.getCode());
        }

        // 是否可补量， 可配送
        if (BrandSaleTypeEnum.BUY.getCode().equals(saleGroup.getSaleType())
                && !inValidEditSaleGroupCampaignGroupStatusList.contains(campaignGroup.getStatus())
        ) {
            saleGroup.setCanReplenish(buildCanReplenishOrDistribution(saleGroupId, dbSaleGroupMap, dbMain2BoostSaleGroupIdMap, isReplenish));
            saleGroup.setCanDistribution(buildCanReplenishOrDistribution(saleGroupId, dbSaleGroupMap, dbMain2GiveSaleGroupIdMap, isDistribution));
        } else {
            saleGroup.setCanReplenish(BrandBoolEnum.BRAND_FALSE.getCode());
            saleGroup.setCanDistribution(BrandBoolEnum.BRAND_FALSE.getCode());
        }

        // 是否可以下载
        saleGroup.setCanDownloadApplyInfo(BrandBoolEnum.BRAND_FALSE.getCode());
        // 是否可以删除
        if (BizSaleGroupToolsHelper.isBpApplyBoostGiveSaleGroup(saleGroup, dbSaleGroupMap)
                && BizSaleGroupToolsHelper.boostGiveSaleGroupIsNotAuditIng(saleGroup)) {
            // 补量配送删除控制
            saleGroup.setCanDelete(BrandBoolEnum.BRAND_TRUE.getCode());
        } else {
            saleGroup.setCanDelete(BrandBoolEnum.BRAND_FALSE.getCode());
        }
        if (calculateSaleGroupInfo != null) {
            saleGroup.setOptimizeTargetIdList(calculateSaleGroupInfo.getOptimizeTargetList());
            saleGroup.setBudget(calculateSaleGroupInfo.getBudget());
            saleGroup.setCalcBudget(calculateSaleGroupInfo.getCalcBudget());
            saleGroup.setUnitPrice(calculateSaleGroupInfo.getUnitPrice());
            saleGroup.setAmount(calculateSaleGroupInfo.getAmount());
            saleGroup.setBudgetSettingType(calculateSaleGroupInfo.getBudgetSettingType());
            saleGroup.setSaleProductLine(calculateSaleGroupInfo.getSaleProductLine());
            //分组下单状态
            saleGroup.setOrderStatus(calculateSaleGroupInfo.getSaleGroupStatus());

            List<CampaignGroupDistributionRuleViewDTO> distributionRuleList = saleGroup.getDistributionRuleList();
            if (CollectionUtils.isNotEmpty(distributionRuleList)) {
                Map<Long, Long> productBudgetMap = calculateSaleGroupInfo.getResourcePackageProductViewDTOList() == null ?
                        Maps.newHashMap() : calculateSaleGroupInfo.getResourcePackageProductViewDTOList().stream().collect(
                        Collectors.toMap(ResourcePackageProductViewDTO::getResourcePackageProductId, ResourcePackageProductViewDTO::getBudget,(v1,v2) -> v2));

                for (CampaignGroupDistributionRuleViewDTO campaignGroupDistributionRuleViewDTO : distributionRuleList) {
                    List<CampaignGroupProductViewDTO> resourcePackageProductList = campaignGroupDistributionRuleViewDTO
                            .getResourcePackageProductList();
                    if (CollectionUtils.isEmpty(resourcePackageProductList)) {
                        continue;
                    }
                    for (CampaignGroupProductViewDTO productViewDTO : resourcePackageProductList) {
                        productViewDTO.setBudget(productBudgetMap.get(productViewDTO.getResourcePackageProductId()));
                    }
                }
            }
        } else {
            saleGroup.setHasUpdate(BrandBoolEnum.BRAND_FALSE.getCode());
            if (saleGroup.getBudget() != null && NumberUtil.greaterThanZero(saleGroup.getUnitPrice())) {
                saleGroup.setAmount(saleGroup.getBudget() * 1000 / saleGroup.getUnitPrice());
            }
        }
    }

    private boolean currentUserCanEdit(ServiceContext serviceContext, CampaignGroupSaleGroupPageViewDTO saleGroup) {
        if (!SaleProductLineEnum.IP_MARKETING_AD.getValue().equals(saleGroup.getSaleProductLine())) {
            return true;
        }
        return ServiceContextUtil.isAliStaff(serviceContext);
    }

    private Integer buildCanReplenishOrDistribution(Long mainSaleGroupId, Map<Long, SaleGroupInfoViewDTO> dbSaleGroupMap,
                                                 Map<Long, List<Long>> dbMain2BoostGiveSaleGroupIdMap, int isReplenishOrDistribution) {
        if (!dbMain2BoostGiveSaleGroupIdMap.containsKey(mainSaleGroupId) || BrandBoolEnum.BRAND_FALSE.getCode().equals(isReplenishOrDistribution)) {
            return BrandBoolEnum.BRAND_FALSE.getCode();
        }
        List<Long> dbSaleGroupIds = Lists.newArrayList(dbSaleGroupMap.keySet());
        dbSaleGroupIds.retainAll(dbMain2BoostGiveSaleGroupIdMap.get(mainSaleGroupId));
        return CollectionUtils.isNotEmpty(dbSaleGroupIds) ? BrandBoolEnum.BRAND_TRUE.getCode() : BrandBoolEnum.BRAND_FALSE.getCode();
    }

    public CampaignGroupResourcePackageViewDTO getCampaignGroupDetailWithSaleGroup(ServiceContext context,
                                                                                    CampaignGroupSaleGroupQueryViewDTO queryViewDTO){
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(context, queryViewDTO.getId());
        AssertUtil.notNull(campaignGroupViewDTO, "订单不存在");
        // 防止传入的bizCode不正确，后面有扩展点逻辑
        ServiceContextUtil.reAssignServiceContext(context, campaignGroupViewDTO.getSceneId());
        //从资源包拿的分组信息
        List<ResourcePackageSaleGroupViewDTO> resourceSaleGroupList = findResourcePackageSaleGroupList(context, queryViewDTO, campaignGroupViewDTO,
                new ResourcePackageQueryOption());
        //过滤受盘量管控且未到盘量时间的分组
        resourceSaleGroupList = filterHasInquirySaleGroups(resourceSaleGroupList);
        //获取订单下的一级计划
        List<CampaignViewDTO> campaignList = findCampaignList(context, campaignGroupViewDTO.getId());

        return this.buildCampaignGroupResourcePackage(
                context,campaignGroupViewDTO, resourceSaleGroupList, campaignList, queryViewDTO);
    }

    public void fillSaleGroupHasUpdate(ServiceContext context,
                                       CampaignGroupViewDTO campaignGroupViewDTO,
                                       List<CampaignGroupSaleGroupPageViewDTO> campaignGroupSaleGroupPageViewDTOList,
                                       List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupList) {
        //获取更新的分组ID
        List<Long> updatedSaleGroupIds = getUpdatedSaleGroupIds(context, resourcePackageSaleGroupList, campaignGroupViewDTO);
        // 设置分组是否有更新
        campaignGroupSaleGroupPageViewDTOList.forEach(campaignGroupSaleGroupViewDTO -> {
            int hasUpdate = updatedSaleGroupIds.contains(campaignGroupSaleGroupViewDTO.getSaleGroupId()) ? BrandBoolEnum.BRAND_TRUE.getCode() :
                    BrandBoolEnum.BRAND_FALSE.getCode();
            campaignGroupSaleGroupViewDTO.setHasUpdate(hasUpdate);
        });
    }

    /**
     * 过滤受盘量管控且未到盘量时间的分组
     * @param resourceSaleGroupList
     * @return
     */
    private List<ResourcePackageSaleGroupViewDTO> filterHasInquirySaleGroups(List<ResourcePackageSaleGroupViewDTO> resourceSaleGroupList) {
        List<Long> hasInquirySaleGroupIdS = resourceSaleGroupList.stream()
                .filter(resourcePackageSaleGroupViewDTO ->
                        BrandBoolEnum.BRAND_TRUE.getCode().equals(resourcePackageSaleGroupViewDTO.getHasInquiryPriority())
                                && (resourcePackageSaleGroupViewDTO.getInquiryDate() == null
                                || resourcePackageSaleGroupViewDTO.getInquiryDate().after(new Date()))
                ).map(ResourcePackageSaleGroupViewDTO::getId)
                .collect(Collectors.toList());
        //不展示受管控的分组及其配送分组
        if (CollectionUtils.isNotEmpty(hasInquirySaleGroupIdS)) {
            return resourceSaleGroupList.stream()
                    .filter(resourcePackageSaleGroupViewDTO -> !hasInquirySaleGroupIdS.contains(resourcePackageSaleGroupViewDTO.getId())
                            && !hasInquirySaleGroupIdS.contains(resourcePackageSaleGroupViewDTO.getMainGroupId())).collect(Collectors.toList());
        }
        return resourceSaleGroupList;
    }

    public List<CampaignViewDTO> findCampaignList(ServiceContext context, Long campaignGroupId) {
        CampaignQueryViewDTO query = new CampaignQueryViewDTO();
        query.setCampaignGroupId(campaignGroupId);
        query.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
        CampaignQueryOption option = new CampaignQueryOption();
        return bizCampaignQueryWorkflow.getCampaignInfoListByOption(context, query, option);
    }
    public List<ResourcePackageSaleGroupViewDTO> findResourcePackageSaleGroupList(ServiceContext context,
                                                                                   CampaignGroupSaleGroupQueryViewDTO queryViewDTO,
                                                                                   CampaignGroupViewDTO campaignGroup,
                                                                                   ResourcePackageQueryOption queryOption) {
        if (campaignGroup.getCampaignGroupSaleViewDTO().getCustomerTemplateId() == null && CollectionUtils.isEmpty(queryViewDTO.getSaleGroupIds()) && queryViewDTO.getMainGroupId() == null) {
            return Lists.newArrayList();
        }
        ResourcePackageQueryViewDTO resourcePackageQueryViewDTO = new ResourcePackageQueryViewDTO();
        resourcePackageQueryViewDTO.setTemplateId(campaignGroup.getCampaignGroupSaleViewDTO().getCustomerTemplateId());
        resourcePackageQueryViewDTO.setSaleGroupIdList(queryViewDTO.getSaleGroupIds());
        resourcePackageQueryViewDTO.setSaleType(queryViewDTO.getSaleType());
        resourcePackageQueryViewDTO.setMainGroupId(queryViewDTO.getMainGroupId());
        return resourcePackageRepository.getSaleGroupList(context, resourcePackageQueryViewDTO, queryOption);
    }

    public Map<Long, SaleGroupCanDeleteViewDTO> checkSaleGroupCanDelete(ServiceContext context, List<CampaignGroupViewDTO> subCampaignGroupList, List<Long> saleGroupIds) {
        Map<Long, SaleGroupCanDeleteViewDTO> saleGroupDeleteMap = Maps.newHashMap();
        for (CampaignGroupViewDTO subCampaignGroup : subCampaignGroupList) {
            ServiceContext subContext = ServiceContextUtil.getNewServiceContext(context, subCampaignGroup.getSceneId());
            Map<Long, SaleGroupCanDeleteViewDTO> subDeleteMap = bizCampaignGroupQueryWorkflowExt.checkSaleGroupCanDelete(subContext, subCampaignGroup, saleGroupIds);
            saleGroupDeleteMap.putAll(subDeleteMap);
        }

        return saleGroupDeleteMap;
    }

    public CampaignGroupSettleInfoViewDTO getCampaignGroupRealSettleInfos(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, CampaignGroupRealSettleQueryViewDTO realSettleQueryViewDTO) {
        // 校验是否支持
        bizCampaignGroupProcessAbility.validateQueryRealSettleData(context, campaignGroupViewDTO);
        // 查询资源包分组详情信息
        List<ResourcePackageSaleGroupViewDTO> saleGroupList = getResourcePackageSaleGroupList(context, campaignGroupViewDTO);

        if (CollectionUtils.isNotEmpty(campaignGroupViewDTO.getCampaignGroupRealSettleViewDTO().getRealSettleInfoViewDTOList()) && !realSettleQueryViewDTO.isReloadSettleInfo()) {
            return campaignGroupSettleConverter.convertRealSettleViewDTOFromCampaignGroup(campaignGroupViewDTO, saleGroupList);
        } else {
            return bizCampaignGroupQueryWorkflowExt.getCampaignGroupRealSettleInfos(context, campaignGroupViewDTO, saleGroupList);
        }
    }

    private List<ResourcePackageSaleGroupViewDTO> getResourcePackageSaleGroupList(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO) {
        List<Long> saleGroupIds = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream()
                .map(SaleGroupInfoViewDTO::getSaleGroupId).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(saleGroupIds)) {
            return Lists.newArrayList();
        }
        ResourcePackageQueryViewDTO resourcePackageQueryViewDTO = new ResourcePackageQueryViewDTO();
        resourcePackageQueryViewDTO.setTemplateId(campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getCustomerTemplateId());
        resourcePackageQueryViewDTO.setSaleGroupIdList(saleGroupIds);
        return resourcePackageRepository.getSaleGroupList(context, resourcePackageQueryViewDTO, ResourcePackageQueryOption.builder().needSetting(false).needProduct(false).build());
    }

    public CampaignGroupBriefViewDTO getCampaignGroupBriefInfo(ServiceContext context, Long campaignGroupId) {
        AssertUtil.notNull(campaignGroupId, "订单ID不能为空");
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(context, campaignGroupId);
        AssertUtil.notNull(campaignGroupViewDTO, "订单不存在");
        // 组装返回数据
        CampaignGroupBriefViewDTO briefViewDTO = new CampaignGroupBriefViewDTO();
        // 基础信息
        buildCampaignGroupInfo(campaignGroupViewDTO, briefViewDTO);
        // 分组信息
        buildSaleGroupInfo(context, campaignGroupViewDTO, briefViewDTO);

        return briefViewDTO;
    }

    private void buildSaleGroupInfo(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, CampaignGroupBriefViewDTO briefViewDTO) {
        // 查询计划
        CampaignQueryViewDTO query = new CampaignQueryViewDTO();
        query.setMainCampaignGroupId(campaignGroupViewDTO.getId());
        query.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
        CampaignQueryOption option = new CampaignQueryOption();
        List<CampaignViewDTO> campaignViewDTOList = bizCampaignQueryWorkflow.getCampaignInfoListByOption(context, query, option);
        // 查询SKU
        List<BrandSkuViewDTO> skuViewDTOList;
        List<Long> skuIds = campaignViewDTOList.stream().filter(item -> item.getCampaignSelfServiceViewDTO() != null)
                .map(item -> item.getCampaignSelfServiceViewDTO().getSkuId()).distinct().collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(skuIds)) {
            skuViewDTOList = brandSkuRepository.findSkuList(context, skuIds);
        } else {
            skuViewDTOList = Lists.newArrayList();
        }

        Map<Long, List<CampaignViewDTO>> skuCampaignsMap = campaignViewDTOList.stream().filter(item -> item.getCampaignSelfServiceViewDTO() != null)
                .collect(Collectors.groupingBy(item -> item.getCampaignSelfServiceViewDTO().getSkuId()));
        List<CampaignGroupBriefSaleGroupViewDTO> saleGroupViewDTOList = Lists.newArrayList();
        for (BrandSkuViewDTO skuViewDTO : skuViewDTOList) {
            CampaignGroupBriefSaleGroupViewDTO briefSaleGroupViewDTO = new CampaignGroupBriefSaleGroupViewDTO();
            briefSaleGroupViewDTO.setSkuIds(Lists.newArrayList(skuViewDTO.getId()));
            // 汇总预算、实际开始结束日期
            List<CampaignViewDTO> skuCampaignList = skuCampaignsMap.getOrDefault(skuViewDTO.getId(), Lists.newArrayList());
            briefSaleGroupViewDTO.setBudget(BizCampaignGroupToolsHelper.getBuyCampaignBudgetTotal(skuCampaignList));
            briefSaleGroupViewDTO.setActualStartDate(BrandDateUtil.getDateMidnight(BizCampaignGroupToolsHelper.getCampaignMinTime(skuCampaignList)));
            briefSaleGroupViewDTO.setActualEndDate(BrandDateUtil.getDateMidnight(BizCampaignGroupToolsHelper.getCampaignMaxTime(skuCampaignList)));
            // 招商分组
            briefSaleGroupViewDTO.setMarketingSaleGroupId(skuViewDTO.getResourcePackageSaleGroupId());
            // 客户分组
            if (CollectionUtils.isNotEmpty(skuCampaignList) && Objects.nonNull(skuCampaignList.get(0).getCampaignSaleViewDTO().getSaleGroupId())) {
                briefSaleGroupViewDTO.setCustomerSaleGroupId(skuCampaignList.get(0).getCampaignSaleViewDTO().getSaleGroupId());
            }

            saleGroupViewDTOList.add(briefSaleGroupViewDTO);
        }
        briefViewDTO.setSaleGroupViewDTOList(saleGroupViewDTOList);
    }

    private void buildCampaignGroupInfo(CampaignGroupViewDTO campaignGroupViewDTO, CampaignGroupBriefViewDTO briefViewDTO) {
        briefViewDTO.setCampaignGroupId(campaignGroupViewDTO.getId());
        briefViewDTO.setMemberId(campaignGroupViewDTO.getMemberId());
        briefViewDTO.setContractMemberType(campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getContractMemberType());
        briefViewDTO.setCustomerMemberId(campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getCustomerMemberId());
        briefViewDTO.setBudget(campaignGroupViewDTO.getBudget());
        briefViewDTO.setBriefId(campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getBriefId());
        briefViewDTO.setProposalId(campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getProposalId());
        briefViewDTO.setProjectId(campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getSalesProjectId());
        briefViewDTO.setMarketingTemplateId(campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getMarketingTemplateId());
        briefViewDTO.setCustomerTemplateId(campaignGroupViewDTO.getCampaignGroupSaleViewDTO().getCustomerTemplateId());
    }

    /**
     * 获取生成合同文本信息
     * @param context
     * @param subCampaignGroupViewDTO
     * @return
     */
    public ContractContentViewDTO getContractContentInfo(ServiceContext context, CampaignGroupViewDTO subCampaignGroupViewDTO) {
        // 查询计划信息
        CampaignQueryViewDTO campaignQueryViewDTO = new CampaignQueryViewDTO();
        campaignQueryViewDTO.setCampaignGroupId(subCampaignGroupViewDTO.getId());
        campaignQueryViewDTO.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
        List<CampaignViewDTO> campaignList = bizCampaignQueryWorkflow.getCampaignInfoListByOption(context, campaignQueryViewDTO, new CampaignQueryOption());
        // 查询ssp产品信息
        Map<Long, ProductViewDTO> productViewDTOMap = Maps.newHashMap();
        if (CollectionUtils.isNotEmpty(campaignList)) {
            List<Long> productIdList = campaignList.stream().map(item->item.getCampaignResourceViewDTO().getSspProductId()).distinct().collect(Collectors.toList());
            List<ProductViewDTO> productViewDTOList = productRepository.getProductByIds(productIdList);
            productViewDTOMap = productViewDTOList.stream().collect(Collectors.toMap(ProductViewDTO::getId, Function.identity(), (v1, v2) -> v2));
        }
        ContractContentViewDTO contentViewDTO = new ContractContentViewDTO();
        buildCampaignGroupInfoForContractContent(subCampaignGroupViewDTO, contentViewDTO);
        buildCampaignInfoForContractContent(campaignList, productViewDTOMap, contentViewDTO);
        return contentViewDTO;
    }

    private void buildCampaignInfoForContractContent(List<CampaignViewDTO> campaignList, Map<Long, ProductViewDTO> productViewDTOMap, ContractContentViewDTO contentViewDTO) {
        List<ContractContentCampaignViewDTO> contentCampaignList = Lists.newArrayList();
        for (CampaignViewDTO campaignViewDTO : campaignList) {
            ContractContentCampaignViewDTO contentCampaignViewDTO = new ContractContentCampaignViewDTO();
            contentCampaignViewDTO.setCampaignId(campaignViewDTO.getId());
            // 计划类型
            contentCampaignViewDTO.setSaleTypeDesc(Optional.ofNullable(BrandSaleTypeEnum.getByCode(campaignViewDTO.getCampaignSaleViewDTO().getSaleType())).map(BrandSaleTypeEnum::getDesc).orElse(null));
            // 售卖单位
            Integer saleUnit = campaignViewDTO.getCampaignSaleViewDTO().getSaleUnit();
            contentCampaignViewDTO.setSaleUnit(saleUnit);
            contentCampaignViewDTO.setSaleUnitDesc(Optional.ofNullable(BrandCampaignSaleUnitEnum.getByCode(saleUnit)).map(BrandCampaignSaleUnitEnum::getDesc).orElse(null));
            // 周期
            contentCampaignViewDTO.setStartTime(campaignViewDTO.getStartTime());
            contentCampaignViewDTO.setEndTime(campaignViewDTO.getEndTime());
            // 预定量
            contentCampaignViewDTO.setAmount(campaignViewDTO.getCampaignGuaranteeViewDTO().getAmount());
            if (BizCampaignToolsHelper.isCPT(saleUnit)) {
                contentCampaignViewDTO.setCptAmount(campaignViewDTO.getCampaignGuaranteeViewDTO().getCptAmount());
                contentCampaignViewDTO.setDisplayAmount(campaignViewDTO.getCampaignGuaranteeViewDTO().getCptAmount() * 1000);
            } else {
                contentCampaignViewDTO.setDisplayAmount(campaignViewDTO.getCampaignGuaranteeViewDTO().getAmount());
            }

            // 资源信息
            ProductViewDTO productViewDTO = productViewDTOMap.get(campaignViewDTO.getCampaignResourceViewDTO().getSspProductId());
            if (productViewDTO != null) {
                contentCampaignViewDTO.setSspMediaName(productViewDTO.getCustomerOrientedMediaName());
                contentCampaignViewDTO.setSspResourceName(productViewDTO.getCustomerOrientedResourceName());
            }

            // 价格
            contentCampaignViewDTO.setBudget(campaignViewDTO.getCampaignBudgetViewDTO().getDiscountTotalMoney());
            if (CollectionUtils.isNotEmpty(campaignViewDTO.getCampaignPriceViewDTO().getPublishPriceInfoList())) {
                contentCampaignViewDTO.setPublisherPriceList(campaignViewDTO.getCampaignPriceViewDTO().getPublishPriceInfoList().stream().map(DayPriceViewDTO::getPrice).distinct().collect(Collectors.toList()));
            }
            if (CollectionUtils.isNotEmpty(campaignViewDTO.getCampaignPriceViewDTO().getDiscountPriceInfoList())) {
                contentCampaignViewDTO.setDiscountRatioList(campaignViewDTO.getCampaignPriceViewDTO().getDiscountPriceInfoList().stream().map(DayPriceViewDTO::getDiscountRatio).distinct().collect(Collectors.toList()));
                contentCampaignViewDTO.setDiscountPriceList(campaignViewDTO.getCampaignPriceViewDTO().getDiscountPriceInfoList().stream().map(DayPriceViewDTO::getPrice).distinct().collect(Collectors.toList()));
            }

            contentCampaignList.add(contentCampaignViewDTO);
        }
        contentViewDTO.setCampaignList(contentCampaignList);
    }

    private void buildCampaignGroupInfoForContractContent(CampaignGroupViewDTO subCampaignGroupViewDTO, ContractContentViewDTO contentViewDTO) {
        contentViewDTO.setCampaignGroupId(subCampaignGroupViewDTO.getId());
        contentViewDTO.setMainCampaignGroupId(subCampaignGroupViewDTO.getParentId());
        contentViewDTO.setCampaignGroupName(subCampaignGroupViewDTO.getName());
        contentViewDTO.setStartTime(subCampaignGroupViewDTO.getStartTime());
        contentViewDTO.setEndTime(subCampaignGroupViewDTO.getEndTime());
        contentViewDTO.setBudget(subCampaignGroupViewDTO.getBudget());
    }
}
