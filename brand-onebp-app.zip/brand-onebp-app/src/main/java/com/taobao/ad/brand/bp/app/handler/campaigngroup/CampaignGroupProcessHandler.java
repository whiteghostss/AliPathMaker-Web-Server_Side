package com.taobao.ad.brand.bp.app.handler.campaigngroup;

import com.alibaba.hermes.framework.event.EventHandler;
import com.taobao.ad.brand.bp.domain.event.campaigngroup.CampaignGroupStatusTransitEvent;

/**
 * 状态发生变更的handler
 *
 * @author duxiaokang
 */
public interface CampaignGroupProcessHandler extends EventHandler<CampaignGroupStatusTransitEvent>  {

    /**
     * 事件需满足条件
     *
     * @param event 事件上下文
     * @return 是否满足
     */
    boolean onCondition(CampaignGroupStatusTransitEvent event);
}
