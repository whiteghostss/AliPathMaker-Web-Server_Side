package com.taobao.ad.brand.bp.app.handler.campaigngroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleGroupSourceEnum;
import com.alibaba.ad.nb.ssp.constant.common.MediaScopeEnum;
import com.alibaba.hermes.framework.ddd.event.annotation.DomainEventHandler;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupEventEnum;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.event.campaigngroup.CampaignGroupStatusTransitEvent;
import com.taobao.ad.brand.bp.domain.inventory.InventoryRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 资源已确认Handler
 *
 * @author yanjingang
 * @date 2023/3/18
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@DomainEventHandler(topic = "campaign_group_status_change", event = CampaignGroupStatusTransitEvent.class)
public class CampaignGroupProcessResourceConfirmedHandler implements CampaignGroupProcessHandler {
    private final CampaignRepository campaignRepository;
    private final InventoryRepository inventoryRepository;
    @Override
    public boolean onCondition(CampaignGroupStatusTransitEvent event) {
        CampaignGroupEventEnum campaignGroupEventEnum = event.getContext().getEventEnum();
        if (CampaignGroupEventEnum.RESOURCE_CONFIRM.equals(campaignGroupEventEnum)) {
            return true;
        }
        return false;
    }

    @Override
    public Response handle(CampaignGroupStatusTransitEvent campaignGroupStatusTransitEvent) {
        if (!onCondition(campaignGroupStatusTransitEvent)) {
            return Response.success();
        }
        ServiceContext serviceContext = campaignGroupStatusTransitEvent.getContext().getServiceContext();
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupStatusTransitEvent.getContext().getCampaignGroupViewDTO();
        List<Long> saleGroupIds = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream().filter(item-> BrandSaleGroupSourceEnum.SALE_PLATFORM.getCode().equals(item.getSource())).map(item->item.getSaleGroupId()).collect(
            Collectors.toList());
        if(CollectionUtils.isEmpty(saleGroupIds)){
            return Response.success();
        }
        // 确认三环采购状态
        CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder()
            .campaignGroupId(campaignGroupViewDTO.getId())
            .saleGroupIds(saleGroupIds)
            .campaignLevel(BrandCampaignLevelEnum.LEVEL_TWO_CAMPAIGN.getCode())
            .build();
        List<CampaignViewDTO> campaignViewDTOList = campaignRepository.queryCampaignList(serviceContext, campaignQueryViewDTO);

        List<CampaignViewDTO> filterList =  campaignViewDTOList.stream()
            .filter(t -> t.getStatus() != BrandCampaignStatusEnum.DELETE.getCode().intValue() && MediaScopeEnum.SITE_OUT.getCode().equals(t.getCampaignResourceViewDTO().getSspMediaScope()))
            .collect(Collectors.toList());
        inventoryRepository.confirmOrder(serviceContext, filterList);
        return Response.success();
    }
}
