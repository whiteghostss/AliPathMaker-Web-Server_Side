package com.taobao.ad.brand.bp.app.workflow.insight;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.fastjson.JSONArray;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.dto.brand.CompetitionBrandViewDTO;
import com.taobao.ad.brand.bp.client.dto.insight.WinInsightBrandQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.insight.WinInsightBrandViewDTO;
import com.taobao.ad.brand.bp.client.dto.insight.WinInsightQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.insight.WinInsightBenchMarkTypeEnum;
import com.taobao.ad.brand.bp.client.enums.insight.WinInsightDimenisonTypeEnum;
import com.taobao.ad.brand.bp.client.enums.insight.WinInsightMetricsEnum;
import com.taobao.ad.brand.bp.client.enums.insight.WinLevelEnum;
import com.taobao.ad.brand.bp.client.enums.report.ReportTotalTypeEnum;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.constant.ReportConstant;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.report.ability.BizReportQueryAbility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * 加购行流程
 *
 * @author shiyan
 * @date 2024/06/26
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class WinInsightQueryWorkflow {

    private final BizReportQueryAbility bizReportQueryAbility;

    private static final String winDimensionAdrUniqueKey = "brand_onebp.common.common.rptWinDataDimensionApi";
    private static final String winDimensionV1AdrUniqueKey = "brand_onebp.common.common.rptWinDataDimensionV1Api";
    private static final String winDataAdrUniqueKey = "brand_onebp.common.common.rptWinDataApi";
    private static final String winDataV1AdrUniqueKey = "brand_onebp.common.common.rptWinDataV1Api";
    private static final String winBenchMarkDataAdrUniqueKey = "brand_onebp.common.common.rptWinBenchmarkDataApi";
    private static final String winBenchMarkDataV1AdrUniqueKey = "brand_onebp.common.common.rptWinBenchmarkDataV1Api";
    private static final String winTopicAdrUniqueKey = "brand_onebp.common.common.rptWinTopicApi";
    private static final String winMainCategoryAdrUniqueKey = "brand_onebp.common.common.rptWinMainCateApi";


    public List<Map<String, Object>> dimensionList(ServiceContext serviceContext, WinInsightQueryViewDTO winInsightQueryViewDTO) {
        // 从数据反推可选筛选项
        Map<String, Object> queryMap = buildQueryMap(serviceContext, winInsightQueryViewDTO);
        queryMap.put(ReportConstant.ADR_UNIQUE_KEY, winDimensionV1AdrUniqueKey);
        List<Map<String, Object>> dataList = bizReportQueryAbility.findDataList(serviceContext, queryMap);
        if (CollectionUtils.isEmpty(dataList)) {
            return Lists.newArrayList();
        }
        // 筛选出所有可用品牌
        List<Long> brandIdList = parseBrandIdList(dataList);
        // 查询当前投放账号下绑定的主营一级类目与主营二级类目作为默认的一二级类目选中
        List<Map<String, Object>> brandCateInfo = queryMainCateInfo(serviceContext, brandIdList);
        // 格式化维度数据，数据限定在给定的5个赛道中
        List<Map<String, Object>> filteredDataList = filterDimensionDataByMainCate(dataList, brandCateInfo);
        // 补充赛道信息,并对赛道信息扩大（原始数据结构中topic按照聚合json的形式存储）
        return expandTopicInfo(serviceContext, filteredDataList);
    }


    /**
     * 处理查询
     *
     * @param serviceContext
     * @param winInsightQueryViewDTO
     * @return
     */
    public List<Map<String, Object>> query(ServiceContext serviceContext, WinInsightQueryViewDTO winInsightQueryViewDTO) {
        // benchmark查询
        if (Objects.nonNull(winInsightQueryViewDTO.getBenchmarkType())) {
            return queryBenchMark(serviceContext, winInsightQueryViewDTO);
        }
        // 普通查询
        Map<String, Object> queryMap = buildQueryMap(serviceContext, winInsightQueryViewDTO);
        queryMap.put(ReportConstant.ADR_UNIQUE_KEY, winDataV1AdrUniqueKey);
        return bizReportQueryAbility.findDataList(serviceContext, queryMap);
    }

    /**
     * 查询基准
     *
     * @param serviceContext
     * @param winInsightQueryViewDTO
     * @return
     */
    private List<Map<String, Object>> queryBenchMark(ServiceContext serviceContext, WinInsightQueryViewDTO winInsightQueryViewDTO) {
        if (Objects.nonNull(winInsightQueryViewDTO.getBenchmarkType())) {
            if (WinInsightBenchMarkTypeEnum.CATEGORY_AVERAGE.getValue().equals(winInsightQueryViewDTO.getBenchmarkType())) {
                AssertUtil.notNull(winInsightQueryViewDTO.getCateLevelOneId(), "一级类目ID不能为空");
                Map<String, Object> queryMap = buildQueryMap(serviceContext, winInsightQueryViewDTO);
                queryMap.put(ReportConstant.ADR_UNIQUE_KEY, winBenchMarkDataV1AdrUniqueKey);
                queryMap.put("benchmarkTypeEqual", WinInsightBenchMarkTypeEnum.CATEGORY_AVERAGE.name());
                return bizReportQueryAbility.findDataList(serviceContext, queryMap);
            }
            if (WinInsightBenchMarkTypeEnum.TOP_TEN_CATEGORY_AVERAGE.getValue().equals(winInsightQueryViewDTO.getBenchmarkType())) {
                AssertUtil.notNull(winInsightQueryViewDTO.getCateLevelOneId(), "一级类目ID不能为空");
                Map<String, Object> queryMap = buildQueryMap(serviceContext, winInsightQueryViewDTO);
                queryMap.put(ReportConstant.ADR_UNIQUE_KEY, winBenchMarkDataV1AdrUniqueKey);
                queryMap.put("benchmarkTypeEqual", WinInsightBenchMarkTypeEnum.TOP_TEN_CATEGORY_AVERAGE.name());
                return bizReportQueryAbility.findDataList(serviceContext, queryMap);
            }
            if (WinInsightBenchMarkTypeEnum.CATEGORY_X_LEVEL_AVERAGE.getValue().equals(winInsightQueryViewDTO.getBenchmarkType())) {
                // 首先查询当前品牌的win，计算等级区间
                AssertUtil.notNull(winInsightQueryViewDTO.getCateLevelOneId(), "一级类目ID不能为空");
                AssertUtil.notNull(winInsightQueryViewDTO.getBrandId(), "品牌ID不能为空");
                Map<String, Object> queryMap = buildQueryMap(serviceContext, winInsightQueryViewDTO);
                queryMap.put(ReportConstant.ADR_UNIQUE_KEY, winDataV1AdrUniqueKey);
                List<Map<String, Object>> selfDataList = bizReportQueryAbility.findDataList(serviceContext, queryMap);
                if (CollectionUtils.isNotEmpty(selfDataList)) {
                    Map<String, Object> selfData = selfDataList.get(0);
                    Object winIndex = selfData.get(WinInsightMetricsEnum.WIN_INDEX.getMetricsName());
                    if (Objects.nonNull(winIndex)) {
                        WinLevelEnum winLevelEnum = WinLevelEnum.ofLevel(Double.parseDouble(String.valueOf(winIndex)));
                        queryMap.put("benchmarkTypeEqual", WinInsightBenchMarkTypeEnum.CATEGORY_X_LEVEL_AVERAGE.name());
                        queryMap.put("levelStartEqual", winLevelEnum.getFrom());
                        queryMap.put("levelEndEqual", winLevelEnum.getTo());
                        queryMap.put(ReportConstant.ADR_UNIQUE_KEY, winBenchMarkDataV1AdrUniqueKey);
                        return bizReportQueryAbility.findDataList(serviceContext, queryMap);
                    }
                }
            }
        }
        return Lists.newArrayList();
    }


    /**
     * 解析第一个品牌ID
     *
     * @param resultList
     * @return
     */
    private List<Long> parseBrandIdList(List<Map<String, Object>> resultList) {
        return resultList.stream()
                .filter(data -> Objects.nonNull(data.get(WinInsightMetricsEnum.BRAND_ID.getMetricsName())))
                .map(data -> data.get(WinInsightMetricsEnum.BRAND_ID.getMetricsName()))
                .map(obj -> Long.parseLong(String.valueOf(obj)))
                .distinct()
                .collect(Collectors.toList());
    }

    /**
     * 格式化维度数据: 圈定到选定的类目，并将主营类目置顶
     *
     * @param dimensionDataList
     * @param mainCateInfo
     */
    private List<Map<String, Object>> filterDimensionDataByMainCate(List<Map<String, Object>> dimensionDataList, List<Map<String, Object>> mainCateInfo) {
        List<Map<String, Object>> result = Lists.newArrayList();
        if (CollectionUtils.isNotEmpty(mainCateInfo)) {
            // 品牌类目信息Map 品牌x类目, 理论上不会出现key冲突
            Map<String, Map<String, Object>> brandCateMap = mainCateInfo.stream().collect(Collectors.toMap(data -> {
                // SQL查询已过滤脏数据
                long brandId = Long.parseLong(String.valueOf(data.get(WinInsightMetricsEnum.BRAND_ID.getMetricsName())));
                long cateLevelOneId = Long.parseLong(String.valueOf(data.get(WinInsightMetricsEnum.CATE_LEVEL_ONE_ID.getMetricsName())));
                return brandId + "_" + cateLevelOneId;
            }, Function.identity(), (v1, v2) -> v1));
            // 筛选出指定类目&品牌的数据
            List<Map<String, Object>> parsedDataList = dimensionDataList.stream().filter(data -> {
                Long cateLevelOneId = Objects.isNull(data.get(WinInsightMetricsEnum.CATE_LEVEL_ONE_ID.getMetricsName())) ? null : Long.parseLong(String.valueOf(data.get(WinInsightMetricsEnum.CATE_LEVEL_ONE_ID.getMetricsName())));
                Long brandId = Objects.isNull(data.get(WinInsightMetricsEnum.BRAND_ID.getMetricsName())) ? null : Long.parseLong(String.valueOf(data.get(WinInsightMetricsEnum.BRAND_ID.getMetricsName())));
                return brandCateMap.containsKey(brandId + "_" + cateLevelOneId);
            }).collect(Collectors.toList());

            // 按照品牌分组后排序
            Map<Long, List<Map<String, Object>>> brandDataMap = parsedDataList.stream()
                    .collect(Collectors.groupingBy(data -> Long.parseLong(String.valueOf(data.get(WinInsightMetricsEnum.BRAND_ID.getMetricsName())))));

            brandDataMap.forEach((brandId, brandDataList) -> {
                brandDataList.sort((d1, d2) -> {
                    long d1CateLevelOneId = Long.parseLong(String.valueOf(d1.get(WinInsightMetricsEnum.CATE_LEVEL_ONE_ID.getMetricsName())));
                    Map<String, Object> d1CateInfo = brandCateMap.get(brandId + "_" + d1CateLevelOneId);

                    long d2CateLevelOneId = Long.parseLong(String.valueOf(d2.get(WinInsightMetricsEnum.CATE_LEVEL_ONE_ID.getMetricsName())));
                    Map<String, Object> d2CateInfo = brandCateMap.get(brandId + "_" + d2CateLevelOneId);

                    if (Objects.isNull(d1CateInfo.get(WinInsightMetricsEnum.RNK.getMetricsName())) || Objects.isNull(d2CateInfo.get(WinInsightMetricsEnum.RNK.getMetricsName()))) {
                        return 0;
                    }
                    Double d1Rank = Double.parseDouble(String.valueOf(d1CateInfo.get(WinInsightMetricsEnum.RNK.getMetricsName())));
                    Double d2Rank = Double.parseDouble(String.valueOf(d2CateInfo.get(WinInsightMetricsEnum.RNK.getMetricsName())));
                    return d1Rank.compareTo(d2Rank);
                });
                result.addAll(brandDataList);
            });
            return result;
        }
        // 未做有效排序，理论上不会到这里
        return dimensionDataList;
    }


    private List<Map<String, Object>> expandTopicInfo(ServiceContext serviceContext, List<Map<String, Object>> dataList) {
        List<Map<String, Object>> resultList = Lists.newArrayList();
        if (CollectionUtils.isNotEmpty(dataList)) {
            Map<Long, String> topicNameMap = Maps.newHashMap();
            List<Long> topicIdList = dataList.stream()
                    .filter(data -> Objects.nonNull(data.get(WinInsightMetricsEnum.TOPIC_JSON.getMetricsName())))
                    .map(data -> data.get(WinInsightMetricsEnum.TOPIC_JSON.getMetricsName()))
                    .map(String::valueOf)
                    .filter(StringUtils::isNotBlank)
                    .flatMap(topicJsonStr -> Arrays.stream(topicJsonStr.split(Constant.CHAR_SPLIT_KEY_DOT)))
                    .filter(this::isValidTopicId)
                    .map(Long::parseLong)
                    .distinct()
                    .collect(Collectors.toList());
            if (CollectionUtils.isNotEmpty(topicIdList)) {
                // 批量查询赛道名称信息
                List<Map<String, Object>> topicInfoList = fillTopicInfo(serviceContext, topicIdList);
                if (CollectionUtils.isNotEmpty(topicInfoList)) {
                    topicInfoList.forEach(topicInfo -> {
                        Long topicId = Long.parseLong(String.valueOf(topicInfo.get("topic_id")));
                        String topicName = String.valueOf(topicInfo.get("topic_name"));
                        topicNameMap.put(topicId, topicName);
                    });
                }
            }
            // 补全赛道信息
            for (int i = 0; i < dataList.size(); i++) {
                Map<String, Object> data = dataList.get(i);
                Object topicJson = data.get(WinInsightMetricsEnum.TOPIC_JSON.getMetricsName());
                data.remove(WinInsightMetricsEnum.TOPIC_JSON.getMetricsName());
                if (Objects.nonNull(topicJson)) {
                    String topicJsonStr = String.valueOf(topicJson);
                    if (StringUtils.isNotBlank(topicJsonStr)) {
                        String[] topicIdStr = topicJsonStr.split(Constant.CHAR_SPLIT_KEY_DOT);
                        // 去除唯一的无效赛道数据
                        if (topicIdStr.length == 1 && ("-1".equals(topicIdStr[0]) || StringUtils.isBlank(topicIdStr[0]))) {
                            data.put(WinInsightMetricsEnum.TOPIC_ID.getMetricsName(), null);
                            data.put(WinInsightMetricsEnum.TOPIC_NAME.getMetricsName(), null);
                            resultList.add(data);
                            continue;
                        }
                        Arrays.stream(topicIdStr).forEach(topicId -> {
                            HashMap<String, Object> newResult = Maps.newHashMap(data);
                            // 去除无效赛道
                            if (!isValidTopicId(topicId)) {
                                return;
                            }
                            newResult.put(WinInsightMetricsEnum.TOPIC_ID.getMetricsName(), topicId);
                            // 理论上赛道名称一定可查
                            newResult.put(WinInsightMetricsEnum.TOPIC_NAME.getMetricsName(), topicNameMap.getOrDefault(Long.parseLong(topicId), ""));
                            resultList.add(newResult);
                        });
                    } else {
                        // 无有效赛道信息
                        data.put(WinInsightMetricsEnum.TOPIC_ID.getMetricsName(), null);
                        data.put(WinInsightMetricsEnum.TOPIC_NAME.getMetricsName(), null);
                        resultList.add(data);
                    }
                } else {
                    // 无有效赛道信息
                    data.put(WinInsightMetricsEnum.TOPIC_ID.getMetricsName(), null);
                    data.put(WinInsightMetricsEnum.TOPIC_NAME.getMetricsName(), null);
                    resultList.add(data);
                }
            }
        }
        return resultList;
    }


    /**
     * 填充赛道信息(topic_name) by 赛道Id
     *
     * @param serviceContext
     * @param topicIdList
     * @return
     */
    private List<Map<String, Object>> fillTopicInfo(ServiceContext serviceContext, List<Long> topicIdList) {
        Map<String, Object> paramMap = Maps.newHashMap();
        paramMap.put(ReportConstant.ADR_UNIQUE_KEY, winTopicAdrUniqueKey);
        paramMap.put("topicIdIn", topicIdList);
        List<Map<String, Object>> winTopicList = bizReportQueryAbility.findDataList(serviceContext, paramMap);
        if (CollectionUtils.isEmpty(winTopicList)) {
            return Lists.newArrayList();
        }
        return winTopicList;
    }

    /**
     * 查询选定品牌的类目信息（选取按照GMV排序的Top5类目）
     *
     * @param serviceContext
     * @return
     */
    private List<Map<String, Object>> queryMainCateInfo(ServiceContext serviceContext, List<Long> brandIdList) {
        if (CollectionUtils.isEmpty(brandIdList)) {
            return Lists.newArrayList();
        }
        Map<String, Object> paramMap = Maps.newHashMap();
        paramMap.put("brandIdIn", brandIdList);
        paramMap.put(ReportConstant.ADR_UNIQUE_KEY, winMainCategoryAdrUniqueKey);
        List<Map<String, Object>> dataList = bizReportQueryAbility.findDataList(serviceContext, paramMap);
        if (CollectionUtils.isEmpty(dataList)) {
            return Lists.newArrayList();
        }
        return dataList;
    }

    /**
     * 构建维度查询Map
     *
     * @param serviceContext
     * @param winInsightQueryViewDTO
     * @return
     */
    private Map<String, Object> buildQueryMap(ServiceContext serviceContext, WinInsightQueryViewDTO winInsightQueryViewDTO) {
        Map<String, Object> result = Maps.newHashMap();
        result.put("memberIdEqual", serviceContext.getMemberId());
        if (Objects.nonNull(winInsightQueryViewDTO.getBrandId())) {
            result.put("brandIdEqual", winInsightQueryViewDTO.getBrandId());
        }
        //if (Objects.nonNull(winInsightQueryViewDTO.getIndustryId())) {
        //    result.put("industryIdEqual", winInsightQueryViewDTO.getIndustryId());
        //}
        if (Objects.nonNull(winInsightQueryViewDTO.getCateLevelOneId())) {
            result.put("cateLevelOneIdEqual", winInsightQueryViewDTO.getCateLevelOneId());
        }
        if (Objects.nonNull(winInsightQueryViewDTO.getCateLevelTwoId())) {
            result.put("cateLevelTwoIdEqual", winInsightQueryViewDTO.getCateLevelTwoId());
        }
        if (Objects.nonNull(winInsightQueryViewDTO.getCateLevelLeafId())) {
            result.put("cateLevelLeafIdEqual", winInsightQueryViewDTO.getCateLevelLeafId());
        }
        if (Objects.nonNull(winInsightQueryViewDTO.getStartPrice())) {
            result.put("startPriceEqual", winInsightQueryViewDTO.getStartPrice());
        }
        if (Objects.nonNull(winInsightQueryViewDTO.getEndPrice())) {
            result.put("endPriceEqual", winInsightQueryViewDTO.getEndPrice());
        }
        if (Objects.nonNull(winInsightQueryViewDTO.getTopicId())) {
            result.put("topicIdEqual", winInsightQueryViewDTO.getTopicId());
        }
        if (Objects.nonNull(winInsightQueryViewDTO.getStartTime())) {
            result.put("startTimeEqual", winInsightQueryViewDTO.getStartTime());
        }
        if (Objects.nonNull(winInsightQueryViewDTO.getEndTime())) {
            result.put("endTimeEqual", winInsightQueryViewDTO.getEndTime());
        }
        if (Objects.nonNull(winInsightQueryViewDTO.getTotalType()) && ReportTotalTypeEnum.DETAIL.getValue() == winInsightQueryViewDTO.getTotalType()) {
            result.put("dateGroupBy", true);
        }
        if (Objects.nonNull(winInsightQueryViewDTO.getDimension()) && WinInsightDimenisonTypeEnum.BRAND.getValue().equals(winInsightQueryViewDTO.getDimension())) {
            result.put("brandIdEqual", null);
            result.put("memberIdEqual", null);
            result.put("limitEqual", 500);
        }
        if (CollectionUtils.isNotEmpty(winInsightQueryViewDTO.getCustomIndexList())) {
            winInsightQueryViewDTO.getCustomIndexList().forEach(index -> {
                result.put(index, true);
            });
        }
        return result;
    }

    /**
     * 判断赛道Id是否有效
     *
     * @param topicId
     * @return
     */
    private boolean isValidTopicId(String topicId) {
        return !StringUtils.isBlank(topicId) && !"-1".equals(topicId);
    }

    /**
     * 查询竞对品牌List
     *
     * @param serviceContext
     * @param brandQueryViewDTO
     * @return
     */
    public List<CompetitionBrandViewDTO> queryCompetitionBrandList(ServiceContext serviceContext, WinInsightBrandQueryViewDTO brandQueryViewDTO) {
        // 普通查询
        Map<String, Object> queryMap = buildCompetitionBrandQueryMap(serviceContext, brandQueryViewDTO);
        queryMap.put(ReportConstant.ADR_UNIQUE_KEY, winDataV1AdrUniqueKey);
        List<Map<String, Object>> dataList = bizReportQueryAbility.findDataList(serviceContext, queryMap);
        if (CollectionUtils.isEmpty(dataList)) {
            return Lists.newArrayList();
        }
        List<Map<String, Object>> competitionBrandMapList = reformat(dataList);
        List<CompetitionBrandViewDTO>  competitionBrandViewDTOS = JSONArray.parseArray(JSONArray.toJSONString(competitionBrandMapList), CompetitionBrandViewDTO.class);
        competitionBrandViewDTOS = competitionBrandViewDTOS.stream()
                .filter(competitionBrandViewDTO -> !brandQueryViewDTO.getBrandId().equals(competitionBrandViewDTO.getBrandId())).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(competitionBrandViewDTOS)) {
            return competitionBrandViewDTOS;
        }
        if (competitionBrandViewDTOS.size() > brandQueryViewDTO.getPageSize()) {
            competitionBrandViewDTOS = competitionBrandViewDTOS.subList(0, brandQueryViewDTO.getPageSize());
        }

        int competitiveHeat = 5;
        for (int i = 0; i < competitionBrandViewDTOS.size(); i++) {
            CompetitionBrandViewDTO competitionBrandViewDTO = competitionBrandViewDTOS.get(i);
            competitionBrandViewDTO.setCompetitiveHeat(Math.max(competitiveHeat - (i / 4), 1));
        }

        return competitionBrandViewDTOS;
    }

    /**
     * 数据格式化
     * @param dataList
     * @return
     */
    private List<Map<String, Object>> reformat(List<Map<String, Object>> dataList) {
        // 所有数据指标保留两位小数
        if(CollectionUtils.isNotEmpty(dataList)) {
            dataList.forEach(data -> {
                data.forEach((key, value) -> {
                    // 率值x10000取整
                    if(WinInsightMetricsEnum.getRateDataMetrics().contains(WinInsightMetricsEnum.of(key))) {
                        if(Objects.nonNull(value)) {
                            BigDecimal bigDecimal = new BigDecimal(String.valueOf(value)).multiply(new BigDecimal(10000)).setScale(0, RoundingMode.HALF_UP);
                            data.put(key, bigDecimal.longValue());
                        }
                    }

                    // win指标x100取整
                    if(WinInsightMetricsEnum.getWindDataMetrics().contains(WinInsightMetricsEnum.of(key))) {
                        if(Objects.nonNull(value)) {
                            BigDecimal bigDecimal = new BigDecimal(String.valueOf(value)).multiply(new BigDecimal(100)).setScale(0, RoundingMode.HALF_UP);
                            data.put(key, bigDecimal.longValue());
                        }
                    }

                    // 其余数据指标直接取整
                    if(WinInsightMetricsEnum.getBasicDataMetrics().contains(WinInsightMetricsEnum.of(key))) {
                        if(Objects.nonNull(value)) {
                            BigDecimal bigDecimal = new BigDecimal(String.valueOf(value)).setScale(0, RoundingMode.HALF_UP);
                            data.put(key, bigDecimal.longValue());
                        }
                    }
                });
            });
        }
        return dataList;
    }

    /**
     * 构建维度查询Map
     *
     * @param serviceContext
     * @param brandQueryViewDTO
     * @return
     */
    private Map<String, Object> buildCompetitionBrandQueryMap(ServiceContext serviceContext, WinInsightBrandQueryViewDTO brandQueryViewDTO) {
        Map<String, Object> result = Maps.newHashMap();
        if (Objects.nonNull(brandQueryViewDTO.getCateLevelOneId())) {
            result.put("cateLevelOneIdEqual", brandQueryViewDTO.getCateLevelOneId());
        }
        if (Objects.nonNull(brandQueryViewDTO.getStartTime())) {
            result.put("startTimeEqual", brandQueryViewDTO.getStartTime());
        }
        if (Objects.nonNull(brandQueryViewDTO.getEndTime())) {
            result.put("endTimeEqual", brandQueryViewDTO.getEndTime());
        }
        result.put("memberIdEqual", null);
        result.put("brandIdEqual", null);
        // 分页
        result.put("limitEqual", brandQueryViewDTO.getPageSize() + 1);
        // 排序
        result.put("winIndex", true);

        return result;
    }

    /**
     * 构建维度查询Map
     *
     * @param serviceContext
     * @param brandQueryViewDTO
     * @return
     */
    private Map<String, Object> buildBrandQueryMap(ServiceContext serviceContext, WinInsightBrandQueryViewDTO brandQueryViewDTO) {
        Map<String, Object> result = Maps.newHashMap();
        // 个性化必填参数
        result.put("memberIdEqual", serviceContext.getMemberId());
        if (Objects.nonNull(brandQueryViewDTO.getCateLevelOneId())) {
            result.put("cateLevelOneIdEqual", brandQueryViewDTO.getCateLevelOneId());
        }
        if (Objects.nonNull(brandQueryViewDTO.getStartTime())) {
            result.put("startTimeEqual", brandQueryViewDTO.getStartTime());
        }
        if (Objects.nonNull(brandQueryViewDTO.getEndTime())) {
            result.put("endTimeEqual", brandQueryViewDTO.getEndTime());
        }

        return result;
    }

    public List<WinInsightBrandViewDTO> queryBrandList(ServiceContext serviceContext, WinInsightBrandQueryViewDTO brandQueryViewDTO) {
        // 从数据反推可选筛选项
        Map<String, Object> queryMap = buildBrandQueryMap(serviceContext, brandQueryViewDTO);
        queryMap.put(ReportConstant.ADR_UNIQUE_KEY, winDimensionV1AdrUniqueKey);
        List<Map<String, Object>> dataList = bizReportQueryAbility.findDataList(serviceContext, queryMap);
        if (CollectionUtils.isEmpty(dataList)) {
            return Lists.newArrayList();
        }
        // 筛选出所有可用品牌
        List<Long> brandIdList = parseBrandIdList(dataList);
        // 查询当前投放账号下绑定的主营一级类目与主营二级类目作为默认的一二级类目选中
        List<Map<String, Object>> brandCateInfo = queryMainCateInfo(serviceContext, brandIdList);
        // 格式化维度数据
        List<Map<String, Object>> filterBrandMapList = filterDimensionDataByMainCate(dataList, brandCateInfo);
        Map<Long, List<WinInsightBrandViewDTO>> winInsightBrandViewDTOMap = JSONArray.parseArray(JSONArray.toJSONString(filterBrandMapList), WinInsightBrandViewDTO.class)
                .stream().collect(Collectors.groupingBy(WinInsightBrandViewDTO::getBrandId));
        List<WinInsightBrandViewDTO> winInsightBrandViewDTOS = Lists.newArrayList();
        // 以品牌维度取rnk最高的
        winInsightBrandViewDTOMap.forEach((brandId, brandList) -> {
            if (CollectionUtils.isNotEmpty(brandList)) {
                winInsightBrandViewDTOS.add(brandList.get(0));
            }
        });

        return winInsightBrandViewDTOS;
    }
}
