package com.taobao.ad.brand.bp.app.handler.adgroup;

import com.alibaba.hermes.framework.ddd.event.annotation.DomainEventHandler;
import com.alibaba.hermes.framework.event.EventHandler;
import com.taobao.ad.brand.bp.domain.adgroup.repository.AdgroupRepository;
import com.taobao.ad.brand.bp.domain.event.adgroup.AdgroupNoticeEvent;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Description:单元更新事件
 * <p>
 * date: 2022/1/21 2:56 下午
 *
 * @author shiyan
 * @version 1.0
 */
@Component
@RequiredArgsConstructor(onConstructor_ = @Autowired)
@DomainEventHandler(topic = "adgroup_handler_topic", event = AdgroupNoticeEvent.class)
public class AdgroupProcessHandler implements EventHandler<AdgroupNoticeEvent> {

    private final AdgroupRepository adgroupRepository;




    @Override
    public Response handle(AdgroupNoticeEvent adgroupNoticeEvent) {
        return null;
    }
}
