package com.taobao.ad.brand.bp.app.workflow.tool;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.nb.framework.core.AbilityFactory;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.app.spi.tool.BatchImportAbilitySpi;
import com.taobao.ad.brand.bp.client.dto.adgroup.AdgroupBatchImportParamViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignBatchImportParamViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignBookingAmountBatchImportParamViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeBatchImportParamViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportTaskViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.query.ReportTaskQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.tool.BatchImportDistLockParamViewDTO;
import com.taobao.ad.brand.bp.client.dto.tool.BatchImportParamViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.DistLockUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.workflow.Workflow;
import com.taobao.ad.brand.bp.domain.report.repository.ReportSyncTaskRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Objects;

import static com.taobao.ad.brand.bp.common.spi.ExtensionPointsFactory.runAbilitySpi;

@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizBatchImportWorkflow extends Workflow {

    private final ReportSyncTaskRepository reportSyncTaskRepository;

    /**
     * 执行批量导入
     * @param serviceContext
     * @param batchImportParamViewDTO
     */
    public void executeBatchImport(ServiceContext serviceContext, BatchImportParamViewDTO batchImportParamViewDTO){
        AssertUtil.notNull(batchImportParamViewDTO, "参数不能为空");
        AssertUtil.notNull(batchImportParamViewDTO.getTaskId(),"批量导入任务参数缺失");
        String spiBizCode = getSpiBizCode(batchImportParamViewDTO);
        //1、查询任务实体
        ReportTaskViewDTO taskViewDTO = getSyncTask(serviceContext,batchImportParamViewDTO);
        batchImportParamViewDTO.setTaskViewDTO(taskViewDTO);
        //2、参数校验
        runAbilitySpi(BatchImportAbilitySpi.class, extension -> extension.validateImportParam(serviceContext, batchImportParamViewDTO), spiBizCode);
        //3、构建分布式锁参数
        BatchImportDistLockParamViewDTO distLockParamViewDTO = runAbilitySpi(BatchImportAbilitySpi.class,
                extension -> extension.buildImportDisLockParam(serviceContext, batchImportParamViewDTO), spiBizCode);
        if(Objects.isNull(distLockParamViewDTO)){
            return;
        }
        DistLockUtil.execute(distLockParamViewDTO.getLockKey(),distLockParamViewDTO.getLockReqValue(), distLockParamViewDTO.getExpireTime(),
                () -> {
                    try {
                        RogerLogger.info("开始执行导入任务，taskViewDTO=" + JSON.toJSONString(taskViewDTO));
                        // 4、执行导入
                        runAbilitySpi(BatchImportAbilitySpi.class,
                                extension -> extension.invokeImport(serviceContext, batchImportParamViewDTO), spiBizCode);
                        // 5、更新导入结果
                        runAbilitySpi(BatchImportAbilitySpi.class,
                                extension -> extension.updateImportResult(serviceContext, batchImportParamViewDTO), spiBizCode);
                        RogerLogger.info("导入任务成功执行，taskViewDTO=" + JSON.toJSONString(taskViewDTO));
                    } catch (Exception e) {
                        RogerLogger.error(String.format("导入任务运行失败，%s", e.getMessage()), e);
                        String errorMsg = runAbilitySpi(BatchImportAbilitySpi.class,
                                extension -> extension.invokeImportExceptionMessage(serviceContext, batchImportParamViewDTO, e.getMessage()), spiBizCode);
                        taskViewDTO.setErrorMsg(errorMsg);
                        reportSyncTaskRepository.runFail(serviceContext, taskViewDTO);
                    }
                    return null;
                },
                distCurValue -> {
                    RogerLogger.error(String.format("任务导入分布式锁获取失败，spiBizCode=%s",spiBizCode));
                    String tryDisLockErrorMessage = runAbilitySpi(BatchImportAbilitySpi.class,
                            extension -> extension.tryDisLockErrorMessage(serviceContext, batchImportParamViewDTO,distCurValue), spiBizCode);
                    taskViewDTO.setErrorMsg(tryDisLockErrorMessage);
                    reportSyncTaskRepository.runFail(serviceContext, taskViewDTO);
                }
        );
    }


    /**
     * 获取bizCode
     * @param batchImportParamViewDTO
     * @return
     */
    private String getSpiBizCode(BatchImportParamViewDTO batchImportParamViewDTO){
        if(batchImportParamViewDTO instanceof CreativeBatchImportParamViewDTO){
            return BatchImportAbilitySpi.BATCH_IMPORT_CREATIVE_UPDATE;
        }else if(batchImportParamViewDTO instanceof CampaignBatchImportParamViewDTO){
            return BatchImportAbilitySpi.BATCH_IMPORT_CAMPAIGN_INSERT;
        }else if(batchImportParamViewDTO instanceof AdgroupBatchImportParamViewDTO){
            return BatchImportAbilitySpi.BATCH_IMPORT_ADGROUP_MONITOR;
        }else if(batchImportParamViewDTO instanceof CampaignBookingAmountBatchImportParamViewDTO){
            return BatchImportAbilitySpi.BATCH_IMPORT_CAMPAIGN_BOOKING_AMOUNT;
        }
        return AbilityFactory.DEFAULT_BIZ_CODE;
    }

    /**
     * 查询异步任务实体
     * @param serviceContext
     * @param batchImportParamViewDTO
     * @return
     */
    private ReportTaskViewDTO getSyncTask(ServiceContext serviceContext,BatchImportParamViewDTO batchImportParamViewDTO){
        String spiBizCode = getSpiBizCode(batchImportParamViewDTO);
        if(Objects.equals(AbilityFactory.DEFAULT_BIZ_CODE,spiBizCode)){
            return null;
        }
        ReportTaskQueryViewDTO queryViewDTO = new ReportTaskQueryViewDTO();
        queryViewDTO.setMemberId(serviceContext.getMemberId());
        queryViewDTO.setTaskId(batchImportParamViewDTO.getTaskId());
        queryViewDTO.setFunctionCode(getSpiBizCode(batchImportParamViewDTO));
        return reportSyncTaskRepository.get(serviceContext, queryViewDTO);
    }
}
