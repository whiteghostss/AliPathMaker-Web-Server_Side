package com.taobao.ad.brand.bp.app.handler.campaigngroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.hermes.framework.ddd.event.annotation.DomainEventHandler;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignCommandWorkflow;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupEventEnum;
import com.taobao.ad.brand.bp.domain.event.campaigngroup.CampaignGroupStatusTransitEvent;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 
 * @description: CampaignProcessHandler
 * @date: 2023/3/10 18:29
 * @author: yuanxinxi
 * @version: 1.0
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@DomainEventHandler(topic = "campaign_group_status_change", event = CampaignGroupStatusTransitEvent.class)
public class CampaignGroupProcessCancelHandler implements CampaignGroupProcessHandler {
    private final BizCampaignCommandWorkflow bizCampaignCommandWorkflow;

    @Override
    public boolean onCondition(CampaignGroupStatusTransitEvent event) {
        CampaignGroupEventEnum campaignGroupEventEnum = event.getContext().getEventEnum();
        return CampaignGroupEventEnum.CANCEL.equals(campaignGroupEventEnum);
    }

    @Override
    public Response handle(CampaignGroupStatusTransitEvent campaignGroupStatusTransitEvent) {
        if (!onCondition(campaignGroupStatusTransitEvent)) {
            return Response.success();
        }
        ServiceContext serviceContext = campaignGroupStatusTransitEvent.getContext().getServiceContext();
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupStatusTransitEvent.getContext().getCampaignGroupViewDTO();
        bizCampaignCommandWorkflow.handleAfterCancelCampaignGroup(serviceContext, campaignGroupViewDTO);
        return Response.success();
    }
}
