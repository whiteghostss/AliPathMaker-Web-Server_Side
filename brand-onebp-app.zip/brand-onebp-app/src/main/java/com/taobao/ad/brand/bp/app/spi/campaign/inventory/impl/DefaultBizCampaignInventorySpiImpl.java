package com.taobao.ad.brand.bp.app.spi.campaign.inventory.impl;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.nb.framework.core.AbilityFactory;
import com.alibaba.ad.nb.framework.core.annotation.AbilitySpiInstance;
import com.taobao.ad.brand.bp.app.spi.campaign.inventory.BizCampaignInventorySpi;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignInquiryOperateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignScheduleViewDTO;

import java.util.List;

@AbilitySpiInstance(bizCode = AbilityFactory.DEFAULT_BIZ_CODE, name = "defaultBizCampaignInventorySpiImpl", desc = "库存默认扩展")
public class DefaultBizCampaignInventorySpiImpl implements BizCampaignInventorySpi {

    @Override
    public Void inventoryRequest(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO, List<CampaignViewDTO> campaignTreeViewDTOList, List<CampaignScheduleViewDTO> campaignScheduleViewDTOList) {
        return null;
    }

    @Override
    public Void releaseCampaign(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList){
        return null;
    }
}
