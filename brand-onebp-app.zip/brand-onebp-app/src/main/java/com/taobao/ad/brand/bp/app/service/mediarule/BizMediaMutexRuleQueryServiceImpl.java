package com.taobao.ad.brand.bp.app.service.mediarule;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.media.mutex.MediaMutexRuleViewDTO;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.api.mediarule.BizMediaMutexRuleQueryService;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.mediarule.query.MediaMutexRuleQueryViewDTO;
import com.taobao.ad.brand.bp.domain.mediarule.MediaMutexRuleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 互斥规则相关服务
 *
 * @author linhua.deng
 **/
@HSFProvider(serviceInterface = BizMediaMutexRuleQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizMediaMutexRuleQueryServiceImpl implements BizMediaMutexRuleQueryService {

    private final MediaMutexRuleRepository mediaMutexRuleRepository;

    @Override
    public MultiResponse<MediaMutexRuleViewDTO> findMutexList(ServiceContext context, MediaMutexRuleQueryViewDTO queryDTO) {
        PageResultViewDTO<MediaMutexRuleViewDTO> pageResultViewDTO = mediaMutexRuleRepository.findMutexRuleList(context, queryDTO);
        return MultiResponse.of(pageResultViewDTO.getList(),pageResultViewDTO.getCount());
    }

    @Override
    public SingleResponse<MediaMutexRuleViewDTO> getMutexRule(ServiceContext context, Long mutexId) {
        return SingleResponse.of(mediaMutexRuleRepository.getMutexRule(context, mutexId));
    }
}