package com.taobao.ad.brand.bp.app.service.motion;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.nb.packages.v2.client.constant.motion.MotionSourceEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.motion.MotionStatusEnum;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.api.motion.BizIntelligentMotionCommandService;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.DmpArgusEstimateViewDTO;
import com.taobao.ad.brand.bp.client.dto.motion.IntelligentMotionViewDTO;
import com.taobao.ad.brand.bp.client.dto.motion.query.MotionQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.enums.EstimateDimensionTypeEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.dmpargus.DmpArgusRepository;
import com.taobao.ad.brand.bp.domain.motion.IntelligentMotionRepository;
import com.taobao.ad.brand.bp.domain.motion.ability.BizIntelligentMotionEstimateAbility;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Objects;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/18
 **/
@HSFProvider(serviceInterface = BizIntelligentMotionCommandService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizIntelligentMotionCommandServiceImpl implements BizIntelligentMotionCommandService {

    private final BizIntelligentMotionEstimateAbility bizIntelligentMotionEstimateAbility;

    private final ResourcePackageRepository resourcePackageRepository;

    private final IntelligentMotionRepository intelligentMotionRepository;

    private final DmpArgusRepository dmpArgusRepository;

    @Override
    public SingleResponse<Long> saveIntelligentMotion(ServiceContext context, IntelligentMotionViewDTO motionViewDTO) {
        bizIntelligentMotionEstimateAbility.validateBaseInfoIntelligentMotion(motionViewDTO);
        ResourcePackageSaleGroupViewDTO saleGroupViewDTO = resourcePackageRepository.getSaleGroupById(context, motionViewDTO.getSaleGroupId(), ResourcePackageQueryOption.builder().needProduct(Boolean.TRUE).needSetting(Boolean.TRUE).build());
        bizIntelligentMotionEstimateAbility.validateIntelligentMotionBaseOnSaleGroup(motionViewDTO, saleGroupViewDTO);
        if (Objects.isNull(motionViewDTO.getId()) || MotionStatusEnum.CALCULATE_FAILED.getValue().equals(motionViewDTO.getStatus())) {
            motionViewDTO.setStatus(MotionStatusEnum.EDITED.getValue());
        }
        return SingleResponse.of(intelligentMotionRepository.saveOrUpdateIntelligentMotion(context, motionViewDTO));
    }

    @Override
    @Transactional
    public SingleResponse<Long> submitIntelligentMotion(ServiceContext context, IntelligentMotionViewDTO motionViewDTO) {
        ResourcePackageSaleGroupViewDTO saleGroupViewDTO = null;
        if (MotionSourceEnum.PRE_STRATEGY.getValue().equals(motionViewDTO.getSource())) {
            bizIntelligentMotionEstimateAbility.validateBaseInfoIntelligentMotion(motionViewDTO);
            saleGroupViewDTO = resourcePackageRepository.getSaleGroupById(context, motionViewDTO.getSaleGroupId(), ResourcePackageQueryOption.builder().needProduct(Boolean.TRUE).needSetting(Boolean.TRUE).build());
            bizIntelligentMotionEstimateAbility.validateIntelligentMotionBaseOnSaleGroup(motionViewDTO, saleGroupViewDTO);
        }
        motionViewDTO.setStatus(MotionStatusEnum.CALCULATE.getValue());
        Long id = intelligentMotionRepository.saveOrUpdateIntelligentMotion(context, motionViewDTO);
        if (Objects.isNull(motionViewDTO.getId())) {
            motionViewDTO.setId(id);
        }
        DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO = bizIntelligentMotionEstimateAbility.buildEstimateViewDTOList(context, motionViewDTO, saleGroupViewDTO, null, EstimateDimensionTypeEnum.MOTION.getValue());
        if (MotionSourceEnum.PRE_STRATEGY.getValue().equals(motionViewDTO.getSource())) {
            // 该字段后续要作为产品粒度的预算传给算法进行计算，针对不同场景有不同的设置逻辑，对于现在这种「提交提案计算策略」的场景，需要设置为null
            dmpArgusEstimateViewDTO.getSaleGroupBaseViewDTO().getSaleGroupProductViewDTOList().forEach(saleGroupProductViewDTO -> saleGroupProductViewDTO.getBandPriceList().forEach(it -> it.setActualAmount(null)));
        }
        dmpArgusRepository.calculateIntelligentMotionAndStrategy(context, dmpArgusEstimateViewDTO);
        return SingleResponse.of(id);
    }

    @Override
    public Response deleteIntelligentMotion(ServiceContext context, List<Long> idList) {
        AssertUtil.notEmpty(idList, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "未传入提案id");
        List<IntelligentMotionViewDTO> intelligentMotionViewDTOList = intelligentMotionRepository.queryIntelligentMotionList(context, MotionQueryViewDTO.builder().idList(idList).build());
        AssertUtil.notEmpty(intelligentMotionViewDTOList, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "未查到需要删除的提案");
        intelligentMotionViewDTOList.forEach(it -> AssertUtil.assertTrue(!MotionStatusEnum.CALCULATE.getValue().equals(it.getStatus()) && !MotionStatusEnum.STRATEGY_SELECTED.getValue().equals(it.getStatus()), BrandOneBPBaseErrorCode.BIZ_DATA_EMPTY_ERROR, "提案状态为计算中或已优选，不能删除"));
        intelligentMotionRepository.updateIntelligentMotionListStatus(context, idList, MotionStatusEnum.DELETED.getValue());
        return Response.success();
    }

    @Override
    public Response updateIntelligentMotionListStatus(ServiceContext serviceContext, List<Long> idList, Integer status) {
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(idList) && status != null, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "未传入提案id或状态");
        intelligentMotionRepository.updateIntelligentMotionListStatus(serviceContext, idList, status);
        return Response.success();
    }
}
