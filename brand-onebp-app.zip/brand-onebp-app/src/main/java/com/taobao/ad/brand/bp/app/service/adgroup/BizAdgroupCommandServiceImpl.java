package com.taobao.ad.brand.bp.app.service.adgroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.adgroup.resource.AdgroupResourceViewDTO;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupBottomTypeEnum;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupOnlineStatusEnum;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupTargetTypeEnum;
import com.alibaba.ad.nb.ssp.constant.common.CrossSceneEnum;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.fastjson.JSON;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.app.workflow.adgroup.BizAdgroupCommandWorkflow;
import com.taobao.ad.brand.bp.app.workflow.adgroup.BizAdgroupMonitorWorkflow;
import com.taobao.ad.brand.bp.app.workflow.creative.BizCreativeRefCommandWorkflow;
import com.taobao.ad.brand.bp.app.workflow.tool.BizBatchImportWorkflow;
import com.taobao.ad.brand.bp.client.api.adgroup.BizAdgroupCommandService;
import com.taobao.ad.brand.bp.client.dto.adgroup.AdgroupBatchImportParamViewDTO;
import com.taobao.ad.brand.bp.client.dto.adgroup.AdgroupEmailSendResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryOption;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportTaskViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.adgroup.repository.AdgroupRepository;
import com.taobao.ad.brand.bp.domain.report.repository.ReportSyncTaskRepository;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupTitleValidateAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupTitleValidateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.query.IAdgroupStructureQueryAbility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * 单元相关的command实现
 * @author 弈云
 * @date 2023年03月08日
 */
@HSFProvider(serviceInterface = BizAdgroupCommandService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizAdgroupCommandServiceImpl implements BizAdgroupCommandService {

    private final AdgroupRepository adgroupRepository;
    private final BizAdgroupMonitorWorkflow bizAdgroupMonitorWorkflow;
    private final BizCreativeRefCommandWorkflow bizCreativeRefCommandWorkflow;
    private final BizAdgroupCommandWorkflow bizAdgroupCommandWorkflow;
    private final BizBatchImportWorkflow bizBatchImportWorkflow;
    private final ReportSyncTaskRepository reportSyncTaskRepository;
    private final IAdgroupStructureQueryAbility adgroupStructureQueryAbility;
    private final IAdgroupTitleValidateAbility adgroupTitleValidateAbility;
    /**
     * 添加单元
     * @param context
     * @param adgroupViewDTO
     * @return 单元ID
     * */
    @Override
    public SingleResponse<Long> addAdgroup(ServiceContext context, AdgroupViewDTO adgroupViewDTO) {
       return bizAdgroupCommandWorkflow.addAdgroup(context,adgroupViewDTO);
    }

    /**
     * 添加单元
     * @param context
     * @param adgroupViewDTOList
     * @return 单元ID
     * */
    @Override
    public Response batchAddAdgroup(ServiceContext context, List<AdgroupViewDTO> adgroupViewDTOList,  List<Long> campaignIdList, Integer inheritTime) {
        for (AdgroupViewDTO adgroupViewDTO: adgroupViewDTOList) {
            adgroupViewDTO.setSceneId(context.getAppId());
        }
        return bizAdgroupCommandWorkflow.batchAddAdgroup(context,adgroupViewDTOList,campaignIdList,inheritTime);
    }
    /**
     * 批量单元保存为正式
     * @param context
     * @param adgroupIds
     * @return 单元ID
     * */
    @Override
    public Response batchSetOnline(ServiceContext context, List<Long> adgroupIds) {
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(adgroupIds), "单元id不允许为空");

        return bizAdgroupCommandWorkflow.batchSetAdgroupOnline(context,adgroupIds);

    }


    /**
     * 更新单元
     * @param context
     * @param adgroupViewDTO
     * @return 单元ID
     * */
    @Override
    public SingleResponse<Long> updateAdgroup(ServiceContext context, AdgroupViewDTO adgroupViewDTO) {
        return bizAdgroupCommandWorkflow.updateAdgroup(context,adgroupViewDTO);
    }

    /**
     * 更新单元名称
     * @param context
     * @param adgroupViewDTO
     * @return 单元ID
     * */
    @Override
    public SingleResponse<Long> updateAdgroupName(ServiceContext context, AdgroupViewDTO adgroupViewDTO) {
        adgroupTitleValidateAbility.handle(context, AdgroupTitleValidateAbilityParam.builder().abilityTarget(adgroupViewDTO).build());
        adgroupRepository.updateAdgroupPart(context,adgroupViewDTO);
        return SingleResponse.of(adgroupViewDTO.getId());
    }

    /**
     * 批量更新单元状态（开启 or 暂停）
     * @param context
     * @param ids 单元IDs
     * @param status @see BrandAdgroupStatusEnum
     * @return
     * */
    @Override
    public SingleResponse<Long> batchUpdateAdgroupStatus(ServiceContext context, List<Long> ids,Integer status) {
        AssertUtil.notEmpty(ids, "单元id不允许为空");
        AssertUtil.notNull(status, "单元状态不合法");
        AssertUtil.notNull(BrandAdgroupOnlineStatusEnum.getByCode(status), "单元状态不合法");
        //查询单元
        List<AdgroupViewDTO> adgroupList = adgroupStructureQueryAbility.handle(context, AdgroupStructureQueryAbilityParam.builder()
                .abilityTarget(AdgroupQueryViewDTO.builder().ids(ids).build()).queryOption(AdgroupQueryOption.builder().build()).build());
        AssertUtil.notEmpty(adgroupList, String.format("单元不存在，id=%s", JSON.toJSONString(ids)));

        bizAdgroupCommandWorkflow.batchUpdateAdgroupOnlineStatus(context,adgroupList, status);
        return SingleResponse.of(1L);
    }

    @Override
    public SingleResponse<Long> deleteAdgroup(ServiceContext context, Long id) {
        bizAdgroupCommandWorkflow.deleteAdgroup(context,id);
        return SingleResponse.of(1L);
    }


    @Override
    public SingleResponse<Long> batchDeleteAdgroup(ServiceContext context, List<Long> ids) {
        AssertUtil.notNull(ids,"参数不能为空");
        bizAdgroupCommandWorkflow.batchDeleteAdgroup(context,ids);
        return SingleResponse.of(1L);
    }
    /**
     * 批量发送非精准邮件
     * @param context
     * @param adgroupIds 单元IDs
     * @return
     */
    @Override
    public SingleResponse<AdgroupEmailSendResultViewDTO> batchSendEmails(ServiceContext context, List<Long> adgroupIds){
        AssertUtil.notEmpty(adgroupIds,"单元id不允许为空");
        AssertUtil.assertTrue(adgroupIds.size() <= 20, "单次发送邮件，单元数量不能超过20");

        List<AdgroupViewDTO> adgroupViewDTOList = adgroupStructureQueryAbility.handle(context, AdgroupStructureQueryAbilityParam.builder()
                .abilityTarget(AdgroupQueryViewDTO.builder().ids(adgroupIds).build()).queryOption(AdgroupQueryOption.builder().needCreative(true).build()).build());


        AssertUtil.notEmpty(adgroupViewDTOList,"单元查询不存在");
        //草稿状态推广组
        List<Long> draftAdgroupIds = adgroupViewDTOList.stream()
                .filter(adgroupViewDTO -> BrandAdgroupOnlineStatusEnum.DRAFT.getCode().equals(adgroupViewDTO.getOnlineStatus()))
                .map(AdgroupViewDTO::getId).collect(Collectors.toList());
        AssertUtil.isEmpty(draftAdgroupIds, "草稿状态单元，不支持该操作");
        //全域通黑盒单元
        List<AdgroupViewDTO> crossSceneAdgroupList = adgroupViewDTOList.stream().filter(adgroupViewDTO -> Objects.equals(Optional.ofNullable(adgroupViewDTO.getAdgroupResourceViewDTO())
                .map(AdgroupResourceViewDTO::getSspCrossScene).orElse(null), CrossSceneEnum.CROSS_OPAQUE_SCENE.getValue())).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(crossSceneAdgroupList)){
            String illegalAdgroupIds = adgroupViewDTOList.stream().filter(adgroupViewDTO -> !Objects.equals(adgroupViewDTO.getBottomType(), BrandAdgroupBottomTypeEnum.BOTTOM.getCode()))
                    .map(adgroupViewDTO -> adgroupViewDTO.getId().toString())
                    .collect(Collectors.joining(","));
            AssertUtil.assertTrue(StringUtils.isBlank(illegalAdgroupIds),String.format("程序化单元不支持该操作，ids=%s",illegalAdgroupIds));
        }
        //常规单元
        List<AdgroupViewDTO> normalAdgroupList = adgroupViewDTOList.stream()
                .filter(adgroupViewDTO -> !Objects.equals(Optional.ofNullable(adgroupViewDTO.getAdgroupResourceViewDTO())
                        .map(AdgroupResourceViewDTO::getSspCrossScene).orElse(null), CrossSceneEnum.CROSS_OPAQUE_SCENE.getValue()))
                .collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(normalAdgroupList)){
            String illegalAdgroupIds = adgroupViewDTOList.stream().filter(adgroupViewDTO ->  !Objects.equals(adgroupViewDTO.getTargetType(), BrandAdgroupTargetTypeEnum.DIRECT.getCode()))
                    .map(adgroupViewDTO -> adgroupViewDTO.getId().toString())
                    .collect(Collectors.joining(","));
            AssertUtil.assertTrue(StringUtils.isBlank(illegalAdgroupIds),String.format("程序化单元不支持该操作，ids=%s",illegalAdgroupIds));
        }

        List<Long> resultVersionList = bizAdgroupMonitorWorkflow.batchSendMonitorEmail(context, adgroupViewDTOList);
        AdgroupEmailSendResultViewDTO sendResultViewDTO = new AdgroupEmailSendResultViewDTO();
        sendResultViewDTO.setSucceedIds(resultVersionList);
        return SingleResponse.of(sendResultViewDTO);
    }

    @Override
    public Response batchBindCreative(ServiceContext context, List<Long> adgroupIds, List<Long> creativeIds) {

        RogerLogger.info("batchBindCreative adgroupIds: {}  creativeIds: {}", adgroupIds, creativeIds);
        AssertUtil.notNull(adgroupIds,"单元id不允许为空");
        AssertUtil.notNull(creativeIds,"创意id不允许为空");

        List<AdgroupViewDTO> adgroupViewDTOList = adgroupStructureQueryAbility.handle(context, AdgroupStructureQueryAbilityParam.builder()
                .abilityTarget(AdgroupQueryViewDTO.builder().ids(adgroupIds).build()).queryOption(AdgroupQueryOption.builder().needCreative(true).build()).build());

        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(adgroupViewDTOList),"查询不到单元");

        return bizCreativeRefCommandWorkflow.batchBindCreative(context,adgroupViewDTOList,creativeIds);
    }
    @Override
    public Response batchUnBindCreative(ServiceContext context, List<Long> adgroupIds, List<Long> creativeIds) {
        AssertUtil.notNull(adgroupIds,"单元id不允许为空");
        AssertUtil.notNull(creativeIds,"创意id不允许为空");
        List<AdgroupViewDTO> adgroupViewDTOList = adgroupStructureQueryAbility.handle(context, AdgroupStructureQueryAbilityParam.builder()
                .abilityTarget(AdgroupQueryViewDTO.builder().ids(adgroupIds).build()).queryOption(AdgroupQueryOption.builder().needCreative(true).build()).build());
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(adgroupViewDTOList),"查询不到单元");

        return bizCreativeRefCommandWorkflow.batchUnBindCreative(context,adgroupViewDTOList,creativeIds);
    }

    @Override
    public Response copyCreativeAsDirect(ServiceContext context, Long adgroupId) {
        AdgroupViewDTO adgroupViewDTO = adgroupRepository.getAdgroupById(context,adgroupId);
        AssertUtil.notNull(adgroupViewDTO,String.format("单元不存在，id=%s",adgroupId));
        ServiceContext serviceContext = ServiceContextUtil.buildServiceContextForSceneId(adgroupViewDTO.getMemberId(),adgroupViewDTO.getSceneId());
        return bizAdgroupCommandWorkflow.generateAdgroupDirectCreative(serviceContext,adgroupViewDTO);
    }

    @Override
    public SingleResponse<Long> saveThirdMonitorBatchImportTask(ServiceContext context, ReportTaskViewDTO taskViewDTO) {
        // 校验任务参数
        validateAdgroupBatchImportMonitorTask(taskViewDTO);
        if (Objects.isNull(taskViewDTO.getTaskId())) {
            Long taskId = reportSyncTaskRepository.add(context, taskViewDTO);
            return SingleResponse.of(taskId);
        }
        reportSyncTaskRepository.modify(context, taskViewDTO);
        return SingleResponse.of(taskViewDTO.getTaskId());
    }

    @Override
    public Response batchSaveThirdMonitor(ServiceContext context, AdgroupBatchImportParamViewDTO adgroupBatchImportParamViewDTO) {
//        bizAdgroupCommandWorkFlow.batchSaveAdgroupMonitor(context, adgroupBatchImportParamViewDTO);
        bizBatchImportWorkflow.executeBatchImport(context,adgroupBatchImportParamViewDTO);
        return Response.success();
    }

    private void validateAdgroupBatchImportMonitorTask(ReportTaskViewDTO taskViewDTO) {
        AssertUtil.notNull(taskViewDTO);
        AssertUtil.notNull(taskViewDTO.getFunctionCode(), "单元批量导入任务参数缺失");
        AssertUtil.notEmpty(taskViewDTO.getTaskParams(), "单元批量导入任务参数缺失");
        // 校验params内部信息
        AssertUtil.notNull(taskViewDTO.getTaskParams().get("fileName"), "单元批量导入任务参数：导入文件名称缺失");
        AssertUtil.notNull(taskViewDTO.getTaskParams().get("ossUrl"), "单元批量导入任务参数: 导入文件OSS链接缺失");

        AssertUtil.notNull(taskViewDTO.getCampaignGroupId(), "订单ID不能为空");
        AssertUtil.hasLength(taskViewDTO.getTaskName(), "任务名称不能为空");
        AssertUtil.maxLength(taskViewDTO.getTaskName(), 50, "任务名称最长不能超过50");
        AssertUtil.notNull(taskViewDTO.getMemberId(), "MemberId不能为空");
    }
}