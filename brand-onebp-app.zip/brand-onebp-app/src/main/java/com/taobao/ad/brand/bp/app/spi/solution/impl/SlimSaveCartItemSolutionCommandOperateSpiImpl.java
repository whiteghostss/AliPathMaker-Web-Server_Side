package com.taobao.ad.brand.bp.app.spi.solution.impl;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.alibaba.ad.brand.sdk.constant.cartitem.BrandCartItemStatusEnum;
import com.alibaba.ad.nb.framework.core.annotation.AbilitySpiInstance;
import com.taobao.ad.brand.bp.app.spi.solution.CartItemSolutionCommandOperateSpi;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignCommandWorkflow;
import com.taobao.ad.brand.bp.app.workflow.cartitem.BizCartItemCommandWorkflow;
import com.taobao.ad.brand.bp.client.dto.solution.CartItemSolutionViewDTO;
import com.taobao.ad.brand.bp.common.converter.solution.CartItemSolutionViewDTOConverter;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.solution.atomability.ISolutionCommandInitForUpdateCartItemSolutionAbility;
import com.taobao.ad.brand.bp.domain.sdk.solution.atomability.param.CartItemSolutionCommandUpdateAbilityParam;

import javax.annotation.Resource;
import java.util.Objects;

@AbilitySpiInstance(bizCode = CartItemSolutionCommandOperateSpi.SLIM_SAVE, name = "slimSaveCartItemSolutionCommandOperateSpiImpl", desc = "自助化极简版保存解决方案扩展")
public class SlimSaveCartItemSolutionCommandOperateSpiImpl extends DefaultCartItemSolutionCommandOperateSpiImpl {
    @Resource
    private ISolutionCommandInitForUpdateCartItemSolutionAbility solutionCommandInitForUpdateCartItemSolutionAbility;
    @Resource
    private BizCartItemCommandWorkflow bizCartItemCommandWorkflow;
    @Resource
    private BizCampaignCommandWorkflow bizCampaignCommandWorkflow;
    @Resource
    private CartItemSolutionViewDTOConverter cartItemSolutionViewDTOConverter;

    @Override
    public Void validateForUpdateCartItemSolution(ServiceContext serviceContext, CartItemSolutionViewDTO dbSolutionCommandViewDTO, CartItemSolutionViewDTO solutionCommandViewDTO) {
        AssertUtil.assertTrue(Objects.equals(BrandCartItemStatusEnum.ORDER_WAIT.getCode(),dbSolutionCommandViewDTO.getStatus()),"已下单套餐包不允许修改");
        return super.validateForUpdateCartItemSolution(serviceContext,dbSolutionCommandViewDTO,solutionCommandViewDTO);
    }

    @Override
    public Void initForUpdateCartItemSolution(ServiceContext serviceContext, CartItemSolutionViewDTO dbSolutionCommandViewDTO, CartItemSolutionViewDTO solutionCommandViewDTO) {
        solutionCommandInitForUpdateCartItemSolutionAbility.handle(serviceContext,
                CartItemSolutionCommandUpdateAbilityParam.builder().abilityTarget(solutionCommandViewDTO).dbCartItemSolutionViewDTO(dbSolutionCommandViewDTO).build());
        return null;
    }

    @Override
    public Void executeForUpdateCartItemSolution(ServiceContext serviceContext, CartItemSolutionViewDTO dbSolutionCommandViewDTO, CartItemSolutionViewDTO solutionCommandViewDTO) {
        //修改加购行
        CartItemViewDTO cartItemViewDTO = cartItemSolutionViewDTOConverter.convertDTO2ViewDTO(solutionCommandViewDTO);
        bizCartItemCommandWorkflow.updateCart(serviceContext,cartItemViewDTO);
        //修改计划
//        bizCampaignCommandWorkflow.updateCampaign(serviceContext,solutionCommandViewDTO.getCampaignViewDTO());
        // 新增计划
        bizCampaignCommandWorkflow.addCampaign(serviceContext,solutionCommandViewDTO.getCampaignViewDTO());
        return null;
    }
}

