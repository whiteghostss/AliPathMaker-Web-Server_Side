package com.taobao.ad.brand.bp.app.interceptor;

import com.alibaba.ad.adc.business.starter.utils.ConfigurationUtils;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.eagleeye.EagleEye;
import org.aopalliance.aop.Advice;
import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.apache.commons.lang.StringUtils;
import org.springframework.aop.Pointcut;
import org.springframework.aop.support.AbstractPointcutAdvisor;
import org.springframework.aop.support.StaticMethodMatcherPointcut;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

/**
 * Description:adc拦截器
 * <p>
 * date: 2023/6/5 7:05 PM
 *
 * @author shiyan
 * @version 1.0
 */
@Component
public class BrandOneBPAdcInterceptor extends AbstractPointcutAdvisor {
    private final static String ADC_HOST_KEY = "host";
    private final static String ADC_REFERER_KEY = "referer";

    @Value("${bp.adc.site.domain}")
    private String adcSiteDomain;

    private final StaticMethodMatcherPointcut pointcut = new StaticMethodMatcherPointcut() {
        @Override
        public boolean matches(Method method, Class<?> targetClass) {
            return AnnotationUtils.findAnnotation(targetClass, HSFProvider.class) != null;
        }
    };

    @Override
    public Pointcut getPointcut() {
        return this.pointcut;
    }

    @Override
    public Advice getAdvice() {
        return this.getInterceptor();
    }

    protected MethodInterceptor getInterceptor() {
        return this::process;
    }

    private Object process(MethodInvocation invocation) throws Throwable {
        RogerLogger.info("BrandOneBPAdcInterceptor in.");
        this.preHandle();
        return invocation.proceed();
    }

    /**
     * adc环境标识注入
     */
    private void preHandle() {
        try {
            //线上环境不做任何处理
            if (ConfigurationUtils.isDemotion() || ConfigurationUtils.isOnline()) {
                RogerLogger.info("BrandOneBPAdcInterceptor#preHandle is online.");
                return;
            }
            //adc预发环境标识有设置，则直接返回
            RogerLogger.info("BrandOneBPAdcInterceptor#preHandle adcSiteDomain={}.",adcSiteDomain);
            String host = EagleEye.getUserData(ADC_HOST_KEY);
            String referer = EagleEye.getUserData(ADC_REFERER_KEY);
            if(StringUtils.isNotBlank(host) || StringUtils.isNotBlank(referer)){
                RogerLogger.info("BrandOneBPAdcInterceptor#preHandle adcSiteDomain is exist, currentAdcSiteDomain={}.",host);
                return ;
            }
            EagleEye.putUserData(ADC_HOST_KEY, adcSiteDomain);
            EagleEye.putUserData(ADC_REFERER_KEY, adcSiteDomain);
            RogerLogger.info("BrandOneBPAdcInterceptor#preHandle adcSiteDomain is not exist, putAdcSiteDomain={}.",adcSiteDomain);
        } catch (Exception exception) {
            RogerLogger.error("BrandOneBPAdcInterceptor#preHandle exception.", exception);
        }
    }
}
