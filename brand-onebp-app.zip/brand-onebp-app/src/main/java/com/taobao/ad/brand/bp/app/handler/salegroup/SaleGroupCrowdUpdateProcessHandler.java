package com.taobao.ad.brand.bp.app.handler.salegroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.fastjson.JSON;
import com.alibaba.hermes.framework.ddd.event.annotation.DomainEventHandler;
import com.alibaba.hermes.framework.event.EventHandler;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.app.workflow.adgroup.BizAdgroupCommandWorkflow;
import com.taobao.ad.brand.bp.domain.event.salegroup.SaleGroupCrowdUpdateEvent;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 订单分组人群更新handler
 * @author shiyan
 **/
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@DomainEventHandler(topic = "salegroup_crowd_update_event", event = SaleGroupCrowdUpdateEvent.class)
public class SaleGroupCrowdUpdateProcessHandler implements EventHandler<SaleGroupCrowdUpdateEvent> {

    private final BizAdgroupCommandWorkflow bizAdgroupCommandWorkflow;

    @Override
    public Response handle(SaleGroupCrowdUpdateEvent saleGroupCrowdUpdateEvent) {
        RogerLogger.info("salegroup_crowd_update_event start:"+ JSON.toJSONString(saleGroupCrowdUpdateEvent));
        if (null == saleGroupCrowdUpdateEvent.getContext() || saleGroupCrowdUpdateEvent.getContext().getSaleGroupInfoViewDTO() == null){
           return Response.success();
        }
        ServiceContext serviceContext = saleGroupCrowdUpdateEvent.getContext().getServiceContext();
        SaleGroupInfoViewDTO saleGroupInfoViewDTO = saleGroupCrowdUpdateEvent.getContext().getSaleGroupInfoViewDTO();
        bizAdgroupCommandWorkflow.batchUpdateNReachAdgroupCrowd(serviceContext,saleGroupInfoViewDTO);
        return Response.success();
    }
}
