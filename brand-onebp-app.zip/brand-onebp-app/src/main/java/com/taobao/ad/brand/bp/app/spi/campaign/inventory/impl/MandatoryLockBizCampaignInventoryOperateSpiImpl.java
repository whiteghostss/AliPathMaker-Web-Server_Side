package com.taobao.ad.brand.bp.app.spi.campaign.inventory.impl;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.nb.framework.core.annotation.AbilitySpiInstance;
import com.alibaba.hermes.framework.error.ErrorCodeAware;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignInquiryOperateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignScheduleViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.app.spi.campaign.inventory.BizCampaignInventoryOperateSpi;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignInventoryWorkflowParam;
import org.apache.commons.collections4.CollectionUtils;

import java.util.List;
import java.util.Set;

@AbilitySpiInstance(bizCode = BizCampaignInventoryOperateSpi.MANDATORY_LOCK, name = "mandatoryLockBizCampaignInventoryOperateSpiImpl", desc = "超接(强制占量)操作实现")
public class MandatoryLockBizCampaignInventoryOperateSpiImpl extends DefaultBizCampaignInventoryOperateSpiImpl {

    @Override
    public ErrorCodeAware validateCampaignInventoryOperate(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO, BizCampaignInventoryWorkflowParam inventoryWorkflowParam) {
        AssertUtil.assertTrue(inventoryWorkflowParam.getCampaignGroupViewDTOList().size() == 1, "仅支持单个订单的计划操作");
        AssertUtil.assertTrue(inventoryWorkflowParam.getCampaignTreeViewDTOList().stream()
                        .map(campaignViewDTO -> campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope()).distinct().count() == 1
                , "仅支持同一媒体流量域的计划操作");
        ErrorCodeAware errorCodeAware = super.validateCampaignInventoryOperate(serviceContext,inquiryOperateViewDTO, inventoryWorkflowParam);
        resetOperateCampaignIds(inventoryWorkflowParam.getCampaignScheduleViewDTOList(), inquiryOperateViewDTO);
        return errorCodeAware;
    }

    /**
     * 重置操作计划id
     * @param campaignScheduleViewDTOList
     * @param inquiryOperateViewDTO
     */
    private void resetOperateCampaignIds(List<CampaignScheduleViewDTO> campaignScheduleViewDTOList,
                                         CampaignInquiryOperateViewDTO inquiryOperateViewDTO) {
        Set<Long> campaignIdSet = Sets.newHashSet(inquiryOperateViewDTO.getCampaignIdList());
        Set<Long> result = Sets.newHashSet();
        for (CampaignScheduleViewDTO scheduleViewDTO : campaignScheduleViewDTOList) {
            if (CollectionUtils.isEmpty(scheduleViewDTO.getOperateSubCampaignIds())) {
                continue;
            }
            for (Long operateSubCampaignId : scheduleViewDTO.getOperateSubCampaignIds()) {
                if (campaignIdSet.contains(operateSubCampaignId)) {
                    result.add(operateSubCampaignId);
                } else {
                    result.add(scheduleViewDTO.getId());
                }
            }
        }
        inquiryOperateViewDTO.setCampaignIdList(Lists.newArrayList(result));
    }
}

