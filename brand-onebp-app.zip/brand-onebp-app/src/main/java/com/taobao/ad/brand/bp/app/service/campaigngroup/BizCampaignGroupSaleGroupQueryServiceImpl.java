package com.taobao.ad.brand.bp.app.service.campaigngroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.price.DayPriceViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryLockViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupBoostGiveApplyCampaignDetailViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupBoostGiveApplyInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupAuditStatusEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleProductLineEnum;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.client.api.campaigngroup.BizCampaignGroupSaleGroupQueryService;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignGroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.salegroup.*;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.report.ability.BizReportQueryAbility;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.salegroup.converter.BizSaleGroupBoostGiveApplyConverter;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.common.constant.ReportConstant.ADR_UNIQUE_KEY;
import static java.util.stream.Collectors.reducing;

/**
 * @author yanjingang
 * @date 2023/9/16
 */
@HSFProvider(serviceInterface = BizCampaignGroupSaleGroupQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizCampaignGroupSaleGroupQueryServiceImpl implements BizCampaignGroupSaleGroupQueryService {
    private final CampaignGroupRepository campaignGroupRepository;
    private final CampaignRepository campaignRepository;
    private final ResourcePackageRepository resourcePackageRepository;
    private final BizReportQueryAbility bizReportQueryAbility;
    private final BizSaleGroupBoostGiveApplyConverter bizSaleGroupBoostGiveApplyConverter;

    private static final int BOOK_TYPE_HISTORY = 1;
    private static final int BOOK_TYPE_FUTURE = 2;
    private static final int BOOK_TYPE_FUTURE_TWO_WEEK = 3;

    private static final List<Integer> inValidSubCampaignGroupStatusList = Lists.newArrayList(
            BrandCampaignGroupStatusEnum.DELETED.getCode(),
            BrandCampaignGroupStatusEnum.CANCELED.getCode()
    );

    @Override
    public SingleResponse<String> downloadApplySaleGroup(ServiceContext context, CampaignGroupSaleGroupBoostGiveApplyViewDTO applyViewDTO) {
        return SingleResponse.of(null);
    }

    @Override
    public SingleResponse<CampaignGroupSaleGroupBoostGiveApplyAuditViewDTO> getApplyAuditInfos(ServiceContext context, CampaignGroupSaleGroupBoostGiveApplyViewDTO applyViewDTO) {
        // 1. 校验
        validateGetApplyAuditInfoParam(context, applyViewDTO);
        // 2. 查询订单
        CampaignGroupViewDTO campaignGroup = findSubCampaignGroupByMainSaleGroupId(context, applyViewDTO.getMainGroupId());
        context = ServiceContextUtil.getNewServiceContext(context, campaignGroup.getSceneId());
        // 3. 查询计划
        List<CampaignViewDTO> campaignList = getSaleGroupCampaignList(context, campaignGroup, applyViewDTO.getMainGroupId());
        // 4. 查询资源包侧主分组的补量分组信息
        List<ResourcePackageSaleGroupViewDTO> boostSaleGroupViewDTOList = findResourcePackageSaleGroupList(context, campaignGroup, applyViewDTO.getMainGroupId());
        // 5. 查询报表
        List<SaleGroupCampaignReportViewDTO> campaignReportList = getCampaignReportList(context, campaignList);
        // 6. 计算预订金额&历史消耗
        computeReportCostInfo(campaignReportList, campaignList);
        // 7. 构建返回结果
        CampaignGroupSaleGroupBoostGiveApplyAuditViewDTO applyAuditViewDTO = buildSaleGroupBoostGiveApplyAuditInfo(campaignGroup, campaignList, campaignReportList, boostSaleGroupViewDTOList, applyViewDTO);
        return SingleResponse.of(applyAuditViewDTO);
    }

    @Override
    public SingleResponse<SaleGroupBoostCalculateResultViewDTO> calculateBoostSaleGroup(ServiceContext context, SaleGroupBoostCalculateViewDTO calculateViewDTO) {
        // 1. 校验
        validateCalculateBoostSaleGroupParam(context, calculateViewDTO);
        // 2. 查询订单
        CampaignGroupViewDTO campaignGroup = getCampaignGroupById(context, calculateViewDTO.getId());
        // 3. 查询计划
        List<CampaignViewDTO> campaignList = getSaleGroupCampaignList(context, campaignGroup, calculateViewDTO.getMainGroupId());
        // 5. 查询报表
        List<SaleGroupCampaignReportViewDTO> campaignReportList = getCampaignReportList(context, campaignList);
        // 6. 计算历史消耗
        computeReportCostInfo(campaignReportList, campaignList);
        // 7. 构建返回结果
        SaleGroupBoostCalculateResultViewDTO calculateViewResultDTO = buildSaleGroupBoostCalculateViewResult(campaignGroup, campaignList, campaignReportList, calculateViewDTO);
        return SingleResponse.of(calculateViewResultDTO);
    }

    private SaleGroupBoostCalculateResultViewDTO buildSaleGroupBoostCalculateViewResult(CampaignGroupViewDTO campaignGroup, List<CampaignViewDTO> campaignList, List<SaleGroupCampaignReportViewDTO> campaignReportList, SaleGroupBoostCalculateViewDTO calculateViewDTO) {
        // 主分组
        SaleGroupInfoViewDTO mainSaleGroupInfo = campaignGroup.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream()
                .filter(saleGroup -> calculateViewDTO.getMainGroupId().equals(saleGroup.getSaleGroupId()))
                .findFirst().get();
        SaleGroupBoostCalculateResultViewDTO viewResultDTO = new SaleGroupBoostCalculateResultViewDTO();
        viewResultDTO.setId(calculateViewDTO.getId());
        viewResultDTO.setMainGroupId(calculateViewDTO.getMainGroupId());

        // 计算计划维度数据明细
        List<CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO> campaignDetailList = buildBoostGiveApplyCampaignDataDetailInfos(mainSaleGroupInfo, campaignList, campaignReportList, calculateViewDTO.getCampaignIds());
        for (CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO detailViewDTO : campaignDetailList) {
            detailViewDTO.setBoostAmount(detailViewDTO.getHistoryBookAmount() - detailViewDTO.getImpPv());
            detailViewDTO.setBoostBudget(detailViewDTO.getHistoryBookBudget() - detailViewDTO.getImpCostBudget());
        }
//
//        // 过滤相关的计划
//        List<CampaignViewDTO> filterCampaignList = campaignList.stream().filter(item -> {
//            if (SaleProductLineEnum.SINGLE_MEDIA_MARKING.getValue().equals(mainSaleGroupInfo.getSaleProductLine())) {
//                return calculateViewDTO.getCampaignIds().contains(item.getId())
//                        || calculateViewDTO.getCampaignIds().contains(item.getSourceCampaignId());
//            }
//            return true;
//        }).collect(Collectors.toList());
//
//        // 主计划List和补量计划map
//        List<CampaignViewDTO> mainCampaignList = filterCampaignList.stream().filter(t -> BrandSaleTypeEnum.BUY.getCode().equals(t.getCampaignSaleViewDTO().getSaleType())).collect(Collectors.toList());
//        Map<Long/*主计划ID*/, List<CampaignViewDTO>> boostCampaignMap = filterCampaignList.stream()
//                .filter(t -> BrandSaleTypeEnum.BOOST.getCode().equals(t.getCampaignSaleViewDTO().getSaleType()))
//                .collect(Collectors.groupingBy(t -> t.getSourceCampaignId()));
//
//        // 计划曝光信息
//        Map<Long, List<SaleGroupCampaignReportViewDTO>> campaignReportMap = campaignReportList.stream()
//                .collect(Collectors.groupingBy(SaleGroupCampaignReportViewDTO::getCampaignId));

//        List<CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO> campaignDetailList = Lists.newArrayList();
//        Date today = BrandDateUtil.getCurrentDate();
//        for (CampaignViewDTO campaignViewDTO : mainCampaignList) {
//            CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO detailViewDTO = new CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO();
//            detailViewDTO.setCampaignId(campaignViewDTO.getId());
//            // 预订信息
//            List<CampaignInquiryViewDTO> campaignInquiryViewDTOS = campaignViewDTO.getInquiryViewDTOList();
//            Map<Date, Long> dayDiscountPriceMap = getCampaignDayPriceMap(campaignViewDTO.getPriceViewDTO().getDiscountPriceInfoList());
//            // 设置历史预订信息
//            setHistoryBookInfo(detailViewDTO, campaignInquiryViewDTOS, dayDiscountPriceMap, today);
//            // 设置历史消耗
//            setHistoryCostInfo(detailViewDTO, campaignViewDTO, boostCampaignMap.getOrDefault(campaignViewDTO.getId(), Lists.newArrayList()), campaignReportMap, today);
//            detailViewDTO.setBoostAmount(detailViewDTO.getHistoryBookAmount() - detailViewDTO.getImpPv());
//            detailViewDTO.setBoostBudget(detailViewDTO.getHistoryBookBudget() - detailViewDTO.getImpCostBudget());
//
//            campaignDetailList.add(detailViewDTO);
//        }
        List<CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO> filterCampaignDetailList;
        if (SaleProductLineEnum.SINGLE_MEDIA_MARKING.getValue().equals(mainSaleGroupInfo.getSaleProductLine())) {
            filterCampaignDetailList = campaignDetailList.stream().filter(detail -> calculateViewDTO.getCampaignIds().contains(detail.getCampaignId())).collect(Collectors.toList());
        } else {
            filterCampaignDetailList = campaignDetailList;
            Long budget = filterCampaignDetailList.stream().mapToLong(CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO::getBoostBudget).sum();
            viewResultDTO.setBudget(budget);
        }
        viewResultDTO.setCampaignDetailList(filterCampaignDetailList);

        return viewResultDTO;
    }

    private CampaignGroupViewDTO getCampaignGroupById(ServiceContext context, Long id) {
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(context, id);
        AssertUtil.notNull(campaignGroupViewDTO, "订单不存在");
        return campaignGroupViewDTO;
    }

    private void validateCalculateBoostSaleGroupParam(ServiceContext context, SaleGroupBoostCalculateViewDTO calculateViewDTO) {
        AssertUtil.notNull(context.getMemberId(), "memberId不能为空");
        AssertUtil.notNull(calculateViewDTO.getId(), "订单ID不能为空");
        AssertUtil.notNull(calculateViewDTO.getMainGroupId(), "主分组ID不能为空");
    }

    private CampaignGroupSaleGroupBoostGiveApplyAuditViewDTO buildSaleGroupBoostGiveApplyAuditInfo(CampaignGroupViewDTO campaignGroup,
                                                                                                   List<CampaignViewDTO> campaignList,
                                                                                                   List<SaleGroupCampaignReportViewDTO> campaignReportList,
                                                                                                   List<ResourcePackageSaleGroupViewDTO> boostSaleGroupList,
                                                                                                   CampaignGroupSaleGroupBoostGiveApplyViewDTO applyViewDTO) {
        CampaignGroupSaleGroupBoostGiveApplyAuditViewDTO auditViewDTO = new CampaignGroupSaleGroupBoostGiveApplyAuditViewDTO();
        // 主分组
        SaleGroupInfoViewDTO mainSaleGroupInfo = campaignGroup.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream()
                .filter(saleGroup -> applyViewDTO.getMainGroupId().equals(saleGroup.getSaleGroupId()))
                .findFirst().get();
        // 申请信息
        SaleGroupBoostGiveApplyInfoViewDTO saleGroupBoostGiveApplyInfoViewDTO = null;
        if (CollectionUtils.isNotEmpty(mainSaleGroupInfo.getBoostGiveApplyInfoList()) && mainSaleGroupInfo.getBoostGiveApplyInfoList().stream().anyMatch(campaignGroupApplyInfo -> applyViewDTO.getSaleGroupId().equals(campaignGroupApplyInfo.getSaleGroupId()))) {
            saleGroupBoostGiveApplyInfoViewDTO = mainSaleGroupInfo.getBoostGiveApplyInfoList().stream()
                    .filter(campaignGroupApplyInfo -> applyViewDTO.getSaleGroupId().equals(campaignGroupApplyInfo.getSaleGroupId()))
                    .findFirst().orElse(null);
            auditViewDTO.setApplyViewDTO(bizSaleGroupBoostGiveApplyConverter.convertDTO2ViewDTO(saleGroupBoostGiveApplyInfoViewDTO));
        }

        // 数据明细
        List<CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO> applyAuditDataDetailViewDTOS = buildBoostGiveApplyAuditDataDetailInfos(mainSaleGroupInfo, saleGroupBoostGiveApplyInfoViewDTO, campaignList, campaignReportList, boostSaleGroupList);
        auditViewDTO.setDataDetailViewDTOList(applyAuditDataDetailViewDTOS);

        return auditViewDTO;
    }

    private List<CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO> buildBoostGiveApplyAuditDataDetailInfos(SaleGroupInfoViewDTO mainSaleGroupInfo,
                                                                                                                     SaleGroupBoostGiveApplyInfoViewDTO saleGroupBoostGiveApplyInfoViewDTO,
                                                                                                                     List<CampaignViewDTO> campaignList,
                                                                                                                     List<SaleGroupCampaignReportViewDTO> campaignReportList, List<ResourcePackageSaleGroupViewDTO> boostSaleGroupList) {
        // 本次申请的主分组计划数据明细
        List<Long> applyMainCampaignIdList;
        if (SaleProductLineEnum.SINGLE_MEDIA_MARKING.getValue().equals(mainSaleGroupInfo.getSaleProductLine()) && saleGroupBoostGiveApplyInfoViewDTO != null) {
            applyMainCampaignIdList = saleGroupBoostGiveApplyInfoViewDTO.getCampaignDetailList().stream().map(SaleGroupBoostGiveApplyCampaignDetailViewDTO::getCampaignId).collect(Collectors.toList());
        } else {
            applyMainCampaignIdList = Lists.newArrayList();
        }
        // 计算计划维度数据明细
        List<CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO> campaignDataDetailList = buildBoostGiveApplyCampaignDataDetailInfos(mainSaleGroupInfo, campaignList, campaignReportList, applyMainCampaignIdList);
        // 单媒体营销或其他场景时汇总
        if (SaleProductLineEnum.SINGLE_MEDIA_MARKING.getValue().equals(mainSaleGroupInfo.getSaleProductLine())) {
            // 设置计划维度补量金额
            setSingleMediaMarketingBoostBudget(mainSaleGroupInfo, saleGroupBoostGiveApplyInfoViewDTO, campaignDataDetailList, boostSaleGroupList);
            // 设置计划信息
            setSingleMediaMarketingSaleGroupBaseInfo(campaignDataDetailList, campaignList);
            return campaignDataDetailList;
        } else {
            // 合并至分组维度
            CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO saleGroupAuditDataDetailViewDTO = mergeNotSingleMediaMarketingBoostAuditDataDetailInfo(mainSaleGroupInfo, campaignDataDetailList);
            // 设置分组维度补量金额
            setNotSingleMediaMarketingBoostBudget(saleGroupBoostGiveApplyInfoViewDTO, saleGroupAuditDataDetailViewDTO, boostSaleGroupList);
            return Lists.newArrayList(saleGroupAuditDataDetailViewDTO);
        }
    }

    private void setNotSingleMediaMarketingBoostBudget(SaleGroupBoostGiveApplyInfoViewDTO saleGroupBoostGiveApplyInfoViewDTO,
                                                       CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO saleGroupAuditDataDetailViewDTO,
                                                       List<ResourcePackageSaleGroupViewDTO> boostSaleGroupList) {
        Long currentBoostBudget = saleGroupBoostGiveApplyInfoViewDTO != null ? saleGroupBoostGiveApplyInfoViewDTO.getBudget() : 0L;
        Long historyBoostBudget = 0L;
        if (CollectionUtils.isNotEmpty(boostSaleGroupList)) {
            List<ResourcePackageSaleGroupViewDTO> filterBoostSaleGroupList = boostSaleGroupList.stream()
                    .filter(t -> saleGroupBoostGiveApplyInfoViewDTO == null || !t.getId().equals(saleGroupBoostGiveApplyInfoViewDTO.getSaleGroupId())) // 其他补量
                    .filter(t -> t.getProcessAuditInfo() != null && !SaleGroupAuditStatusEnum.AUDIT_FAILED.getValue().equals(t.getProcessAuditInfo().getAuditStatus()))
                    .collect(Collectors.toList());
            if (CollectionUtils.isNotEmpty(filterBoostSaleGroupList)) {
                historyBoostBudget = filterBoostSaleGroupList.stream().mapToLong(ResourcePackageSaleGroupViewDTO::getBudget).sum();
            }
        }
        saleGroupAuditDataDetailViewDTO.setBoostBudget(currentBoostBudget);
        saleGroupAuditDataDetailViewDTO.setHistoryBoostBudget(historyBoostBudget);
    }

    private CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO mergeNotSingleMediaMarketingBoostAuditDataDetailInfo(SaleGroupInfoViewDTO mainSaleGroupInfo,
                                                                                                                            List<CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO> campaignDataDetailList) {
        CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO saleGroupAuditDataDetailViewDTO = new CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO();
        saleGroupAuditDataDetailViewDTO.setMainGroupId(mainSaleGroupInfo.getMainSaleGroupId());
        saleGroupAuditDataDetailViewDTO.setBookBudget(mainSaleGroupInfo.getBudget());
        Long historyBookBudget = 0L;
        Long impCostBudget = 0L;
        Long futureTwoWeekBookBudget = 0L;
        if (CollectionUtils.isNotEmpty(campaignDataDetailList)) {
            for (CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO campaignDataDetailViewDTO : campaignDataDetailList) {
                if (campaignDataDetailViewDTO.getHistoryBookBudget() != null) {
                    historyBookBudget += campaignDataDetailViewDTO.getHistoryBookBudget();
                }
                if (campaignDataDetailViewDTO.getImpCostBudget() != null) {
                    impCostBudget += campaignDataDetailViewDTO.getImpCostBudget();
                }
                if (campaignDataDetailViewDTO.getFutureTwoWeekBookBudget() != null) {
                    futureTwoWeekBookBudget += campaignDataDetailViewDTO.getFutureTwoWeekBookBudget();
                }
            }
        }
        saleGroupAuditDataDetailViewDTO.setHistoryBookBudget(historyBookBudget);
        saleGroupAuditDataDetailViewDTO.setImpCostBudget(impCostBudget);
        saleGroupAuditDataDetailViewDTO.setFutureTwoWeekBookBudget(futureTwoWeekBookBudget);

        return saleGroupAuditDataDetailViewDTO;
    }

    private void setSingleMediaMarketingSaleGroupBaseInfo(List<CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO> campaignDataDetailList, List<CampaignViewDTO> campaignList) {
        Map<Long, CampaignViewDTO> campaignMap = campaignList.stream().collect(Collectors.toMap(t -> t.getId(), Function.identity()));
        for (CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO campaignDataDetail : campaignDataDetailList) {
            CampaignViewDTO campaignViewDTO = campaignMap.get(campaignDataDetail.getCampaignId());
            campaignDataDetail.setCampaignName(campaignViewDTO.getTitle());
            campaignDataDetail.setSspProductUuid(campaignViewDTO.getCampaignResourceViewDTO().getSspProductUuid());
            campaignDataDetail.setSspResourceTypes(campaignViewDTO.getCampaignResourceViewDTO().getSspResourceTypes());
        }
    }

    /**
     * 设置单媒体营销计划维度的本次补量金额和历史累积补量金额
     *
     * @param mainSaleGroupInfo
     * @param saleGroupBoostGiveApplyInfoViewDTO
     * @param campaignDataDetailList
     * @param boostSaleGroupList
     */
    private void setSingleMediaMarketingBoostBudget(SaleGroupInfoViewDTO mainSaleGroupInfo,
                                                    SaleGroupBoostGiveApplyInfoViewDTO saleGroupBoostGiveApplyInfoViewDTO,
                                                    List<CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO> campaignDataDetailList,
                                                    List<ResourcePackageSaleGroupViewDTO> boostSaleGroupList) {
        if (saleGroupBoostGiveApplyInfoViewDTO == null) {
            return;
        }
        Map<Long, ResourcePackageSaleGroupViewDTO> boostSaleGroupMap = boostSaleGroupList.stream().collect(Collectors.toMap(ResourcePackageSaleGroupViewDTO::getId, Function.identity()));

        Map<Long, Long> currentBoostBudgetMap = saleGroupBoostGiveApplyInfoViewDTO.getCampaignDetailList().stream().collect(Collectors.toMap(SaleGroupBoostGiveApplyCampaignDetailViewDTO::getCampaignId, SaleGroupBoostGiveApplyCampaignDetailViewDTO::getBudget, (a1, a2) -> a2));
        Map<Long, Long> historyBoostBudgetMap = mainSaleGroupInfo.getBoostGiveApplyInfoList().stream()
                .filter(t -> !t.getSaleGroupId().equals(saleGroupBoostGiveApplyInfoViewDTO.getSaleGroupId()) && BrandSaleTypeEnum.BOOST.getCode().equals(t.getSaleType())) // 剔除当前补量的 其他补量
                .filter(t -> { // 补量流程不为拒绝
                    ResourcePackageSaleGroupViewDTO resourcePackageSaleGroup = boostSaleGroupMap.get(t.getSaleGroupId());
                    if (resourcePackageSaleGroup != null
                            && resourcePackageSaleGroup.getProcessAuditInfo() != null
                            && !SaleGroupAuditStatusEnum.AUDIT_FAILED.getValue().equals(resourcePackageSaleGroup.getProcessAuditInfo().getAuditStatus())) {
                        return true;
                    }
                    return false;
                })
                .filter(t -> t.getCampaignDetailList() != null)
                .flatMap(t -> t.getCampaignDetailList().stream())
                .filter(campaignDetail -> currentBoostBudgetMap.containsKey(campaignDetail.getCampaignId())) // 主计划当前计划
                .collect(Collectors.groupingBy(SaleGroupBoostGiveApplyCampaignDetailViewDTO::getCampaignId, reducing(0L, SaleGroupBoostGiveApplyCampaignDetailViewDTO::getBudget, Long::sum)));

        campaignDataDetailList.forEach(campaignDataDetail -> {
            campaignDataDetail.setBoostBudget(currentBoostBudgetMap.getOrDefault(campaignDataDetail.getCampaignId(), 0L));
            campaignDataDetail.setHistoryBoostBudget(historyBoostBudgetMap.getOrDefault(campaignDataDetail.getCampaignId(), 0L));
        });
    }

    /**
     * 构建计划维度的
     *
     * @param mainSaleGroupInfo
     * @param campaignList
     * @param campaignReportList
     * @param applyMainCampaignIdList
     * @return
     */
    private List<CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO> buildBoostGiveApplyCampaignDataDetailInfos(SaleGroupInfoViewDTO mainSaleGroupInfo,
                                                                                                                        List<CampaignViewDTO> campaignList,
                                                                                                                        List<SaleGroupCampaignReportViewDTO> campaignReportList,
                                                                                                                        List<Long> applyMainCampaignIdList) {
        List<CampaignViewDTO> filterCampaignList = campaignList.stream().filter(item -> {
            if (SaleProductLineEnum.SINGLE_MEDIA_MARKING.getValue().equals(mainSaleGroupInfo.getSaleProductLine())) {
                return applyMainCampaignIdList.contains(item.getId())
                        || applyMainCampaignIdList.contains(item.getCampaignBoostViewDTO().getSourceCampaignId());
            }
            return true;
        }).collect(Collectors.toList());
        // 过滤相关的计划
        List<CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO> campaignDataDetailList = initCampaignDataDetailList(filterCampaignList);
        Map<Long, CampaignViewDTO> filterCampaignMap = campaignList.stream().collect(Collectors.toMap(t -> t.getId(), Function.identity()));
        // 设置计划预订信息
        setCampaignsBookInfo(campaignDataDetailList, filterCampaignMap);
        // 设置历史消耗信息
        setCampaignsHistoryCostInfo(campaignDataDetailList, filterCampaignList, campaignReportList);

//        List<CampaignViewDTO> filterCampaignList = campaignList.stream().filter(item -> {
//            if (SaleProductLineEnum.SINGLE_MEDIA_MARKING.getValue().equals(mainSaleGroupInfo.getSaleProductLine())) {
//                return applyMainCampaignIdList.contains(item.getId())
//                        || applyMainCampaignIdList.contains(item.getSourceCampaignId());
//            }
//            return true;
//        }).collect(Collectors.toList());
        // 主计划List和补量计划map
//        List<CampaignViewDTO> mainCampaignList = filterCampaignList.stream().filter(t -> BrandSaleTypeEnum.BUY.getCode().equals(t.getCampaignSaleViewDTO().getSaleType())).collect(Collectors.toList());
//        Map<Long/*主计划ID*/, List<CampaignViewDTO>> boostCampaignMap = filterCampaignList.stream()
//                .filter(t -> BrandSaleTypeEnum.BOOST.getCode().equals(t.getCampaignSaleViewDTO().getSaleType()))
//                .collect(Collectors.groupingBy(t -> t.getSourceCampaignId()));
//
//        // 计划曝光信息
//        Map<Long, List<SaleGroupCampaignReportViewDTO>> campaignReportMap = campaignReportList.stream()
//                .collect(Collectors.groupingBy(SaleGroupCampaignReportViewDTO::getCampaignId));
//
//        List<CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO> campaignDataDetailList = Lists.newArrayList();
//        Date today = BrandDateUtil.getCurrentDate();
//        for (CampaignViewDTO campaignViewDTO : mainCampaignList) {
//
//            CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO detailViewDTO = new CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO();
//            detailViewDTO.setCampaignId(campaignViewDTO.getId());
//            detailViewDTO.setBookBudget(campaignViewDTO.getPriceViewDTO().getDiscountTotalMoney());
//            // 预订信息
//            List<CampaignInquiryViewDTO> campaignInquiryViewDTOS = campaignViewDTO.getInquiryViewDTOList();
//            Map<Date, Long> dayDiscountPriceMap = getCampaignDayPriceMap(campaignViewDTO.getPriceViewDTO().getDiscountPriceInfoList());
//            // 设置历史预订金额
//            detailViewDTO.setHistoryBookBudget(getBookBudget(campaignInquiryViewDTOS, dayDiscountPriceMap, today, BOOK_TYPE_HISTORY));
//            // 设置未来两周预订信息
//            detailViewDTO.setFutureTwoWeekBookBudget(getBookBudget(campaignInquiryViewDTOS, dayDiscountPriceMap, today, BOOK_TYPE_FUTURE_TWO_WEEK));
//            // 设置历史消耗
//            setHistoryCostInfo(detailViewDTO, campaignViewDTO, boostCampaignMap.getOrDefault(campaignViewDTO.getId(), Lists.newArrayList()), campaignReportMap, today);
//
//            campaignDataDetailList.add(detailViewDTO);
//        }

        return campaignDataDetailList;
    }

    private void setCampaignsHistoryCostInfo(List<CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO> campaignDataDetailList, List<CampaignViewDTO> filterCampaignList, List<SaleGroupCampaignReportViewDTO> campaignReportList) {
        // 主计划List和补量计划map
        Map<Long/*主计划ID*/, List<CampaignViewDTO>> boostCampaignMap = filterCampaignList.stream()
                .filter(t -> BrandSaleTypeEnum.BOOST.getCode().equals(t.getCampaignSaleViewDTO().getSaleType()))
                .collect(Collectors.groupingBy(t -> t.getCampaignBoostViewDTO().getSourceCampaignId()));
        // 计划曝光信息
        Map<Long, List<SaleGroupCampaignReportViewDTO>> campaignReportMap = campaignReportList.stream()
                .collect(Collectors.groupingBy(SaleGroupCampaignReportViewDTO::getCampaignId));
        Map<Long, CampaignViewDTO> campaignMap = filterCampaignList.stream().collect(Collectors.toMap(t -> t.getId(), Function.identity()));
        Date today = BrandDateUtil.getCurrentDate();
        for (CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO detailViewDTO : campaignDataDetailList) {
            CampaignViewDTO campaignViewDTO = campaignMap.get(detailViewDTO.getCampaignId());
            // 设置历史消耗
            setHistoryCostInfo(detailViewDTO, campaignViewDTO, boostCampaignMap.getOrDefault(campaignViewDTO.getId(), Lists.newArrayList()), campaignReportMap, today);
        }
    }

    private void setCampaignsBookInfo(List<CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO> campaignDataDetailList, Map<Long, CampaignViewDTO> campaignMap) {
        Date today = BrandDateUtil.getCurrentDate();
        for (CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO detailViewDTO : campaignDataDetailList) {
            CampaignViewDTO campaignViewDTO = campaignMap.get(detailViewDTO.getCampaignId());
            detailViewDTO.setBookBudget(campaignViewDTO.getCampaignBudgetViewDTO().getDiscountTotalMoney());
            detailViewDTO.setBookAmount(campaignViewDTO.getCampaignGuaranteeViewDTO().getAmount());
            // 预订信息
            List<CampaignInquiryViewDTO> campaignInquiryViewDTOS = Optional.ofNullable(campaignViewDTO.getCampaignInquiryLockViewDTO())
                    .map(CampaignInquiryLockViewDTO::getCampaignInquiryViewDTOList).orElse(Lists.newArrayList());
            Map<Date, Long> dayDiscountPriceMap = getCampaignDayPriceMap(campaignViewDTO.getCampaignPriceViewDTO().getDiscountPriceInfoList());
            // 设置历史预订信息
            setHistoryBookInfo(detailViewDTO, campaignInquiryViewDTOS, dayDiscountPriceMap, today);
            // 设置未来两周预订信息
            setFutureTwoWeekBookInfo(detailViewDTO, campaignInquiryViewDTOS, dayDiscountPriceMap, today);
//            // 设置未来两周预订信息
//            detailViewDTO.setFutureTwoWeekBookBudget(getBookBudget(campaignInquiryViewDTOS, dayDiscountPriceMap, today, BOOK_TYPE_FUTURE_TWO_WEEK));
        }
    }


    private List<CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO> initCampaignDataDetailList(List<CampaignViewDTO> filterCampaignList) {
        // 过滤主计划
        List<CampaignViewDTO> mainCampaignList = filterCampaignList.stream().filter(t -> BrandSaleTypeEnum.BUY.getCode().equals(t.getCampaignSaleViewDTO().getSaleType())).collect(Collectors.toList());
        List<CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO> campaignDataDetailList = Lists.newArrayList();
        for (CampaignViewDTO campaignViewDTO : mainCampaignList) {
            CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO detailViewDTO = new CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO();
            detailViewDTO.setCampaignId(campaignViewDTO.getId());
//            detailViewDTO.setCampaignName(campaignViewDTO.getTitle());

            campaignDataDetailList.add(detailViewDTO);
        }

        return campaignDataDetailList;
    }

    private void setHistoryCostInfo(CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO detailViewDTO,
                                    CampaignViewDTO campaignViewDTO,
                                    List<CampaignViewDTO> boostCampaignList,
                                    Map<Long, List<SaleGroupCampaignReportViewDTO>> campaignReportMap,
                                    Date today) {
        // 主计划消耗金额
        Long campaignCostPrice = getCostPriceSum(campaignReportMap.get(campaignViewDTO.getId()), today);
        Long campaignCostPv = getCostAmountSum(campaignReportMap.get(campaignViewDTO.getId()), today);
        // 补量计划消耗金额
        if (CollectionUtils.isNotEmpty(boostCampaignList)) {
            campaignCostPrice += boostCampaignList.stream()
                    .mapToLong(t -> getCostPriceSum(campaignReportMap.get(t.getId()), today))
                    .sum();
            campaignCostPv += boostCampaignList.stream()
                    .mapToLong(t -> getCostAmountSum(campaignReportMap.get(t.getId()), today))
                    .sum();
        }
        detailViewDTO.setImpCostBudget(campaignCostPrice);
        detailViewDTO.setImpPv(campaignCostPv);
    }

    private Long getCostPriceSum(List<SaleGroupCampaignReportViewDTO> campaignReportViewDTOS, Date today) {
        if (CollectionUtils.isEmpty(campaignReportViewDTOS)) {
            return 0L;
        }
        return campaignReportViewDTOS.stream()
                .filter(t -> BrandDateUtil.isBefore(t.getDate(), today) && t.getCostPrice() != null)
                .mapToLong(SaleGroupCampaignReportViewDTO::getCostPrice)
                .sum();
    }
    private Long getCostAmountSum(List<SaleGroupCampaignReportViewDTO> campaignReportViewDTOS, Date today) {
        if (CollectionUtils.isEmpty(campaignReportViewDTOS)) {
            return 0L;
        }
        return campaignReportViewDTOS.stream()
                .filter(t -> BrandDateUtil.isBefore(t.getDate(), today) && t.getImpPv() != null)
                .mapToLong(SaleGroupCampaignReportViewDTO::getImpPv)
                .sum();
    }

    private Map<Date, Long> getCampaignDayPriceMap(List<DayPriceViewDTO> discountPriceInfoList) {
        if (CollectionUtils.isEmpty(discountPriceInfoList)) {
            return Maps.newHashMap();
        }
        Map<Date, Long> dayDiscountPriceMap = Maps.newHashMap();
        for (DayPriceViewDTO dayPriceViewDTO : discountPriceInfoList) {
            List<Date> dayList = BrandDateUtil.getDayList(dayPriceViewDTO.getStartDate(), dayPriceViewDTO.getEndDate());
            for (Date day : dayList) {
                dayDiscountPriceMap.put(day, dayPriceViewDTO.getSettlePrice());
            }
        }

        return dayDiscountPriceMap;
    }

    private boolean inquiryCondition(Date inquiryDate, Date today, int type) {
        if (type == BOOK_TYPE_HISTORY) {
            return BrandDateUtil.isBefore(inquiryDate, today);
        } else if (type == BOOK_TYPE_FUTURE_TWO_WEEK) {
            Date twoWeekAfterDate = BrandDateUtil.getAfterDate(today, 13);
            return BrandDateUtil.isAfterAndEqual(inquiryDate, today) && BrandDateUtil.isBeforeAndEqual(inquiryDate, twoWeekAfterDate);
        } else {
            return BrandDateUtil.isAfterAndEqual(inquiryDate, today);
        }
    }

//    private Long getBookBudget(List<CampaignInquiryViewDTO> campaignInquiryViewDTOS, Map<Date, Long> dayDiscountPriceMap, Date today, int type) {
//        if (CollectionUtils.isEmpty(campaignInquiryViewDTOS)) {
//            return 0L;
//        }
//        List<CampaignInquiryViewDTO> filterInquiryInfos = campaignInquiryViewDTOS.stream()
//                .filter(inquiry -> inquiryCondition(inquiry.getDate(), today, type)).collect(Collectors.toList());
//        if (CollectionUtils.isEmpty(filterInquiryInfos)) {
//            return 0L;
//        }
//        Long bookBudget = filterInquiryInfos.stream()
//                .filter(inquiry -> inquiry.getBookAmount() != null && dayDiscountPriceMap.containsKey(inquiry.getDate()))
//                .mapToLong(inquiry -> dayDiscountPriceMap.get(inquiry.getDate()) * inquiry.getBookAmount())
//                .sum();
//
//        return new BigDecimal(bookBudget).divide(new BigDecimal(1000), 0, BigDecimal.ROUND_HALF_UP).longValue();
//    }

    private void setHistoryBookInfo(CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO detailViewDTO, List<CampaignInquiryViewDTO> campaignInquiryViewDTOS, Map<Date, Long> dayDiscountPriceMap, Date today) {
        if (CollectionUtils.isEmpty(campaignInquiryViewDTOS)) {
            detailViewDTO.setHistoryBookBudget(0L);
            detailViewDTO.setHistoryBookAmount(0L);
            return;
        }
        List<CampaignInquiryViewDTO> filterInquiryInfos = campaignInquiryViewDTOS.stream()
                .filter(inquiry -> inquiryCondition(inquiry.getDate(), today, BOOK_TYPE_HISTORY)).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(filterInquiryInfos)) {
            detailViewDTO.setHistoryBookBudget(0L);
            detailViewDTO.setHistoryBookAmount(0L);
            return;
        }

        Long bookBudget = filterInquiryInfos.stream()
                .filter(inquiry -> inquiry.getBookAmount() != null && dayDiscountPriceMap.containsKey(inquiry.getDate()))
                .mapToLong(inquiry -> dayDiscountPriceMap.get(inquiry.getDate()) * inquiry.getBookAmount())
                .sum();
        Long bookAmount = filterInquiryInfos.stream().filter(inquiry -> inquiry.getBookAmount() != null)
                .mapToLong(CampaignInquiryViewDTO::getBookAmount).sum();
        detailViewDTO.setHistoryBookBudget(new BigDecimal(bookBudget).divide(new BigDecimal(1000), 0, BigDecimal.ROUND_HALF_UP).longValue());
        detailViewDTO.setHistoryBookAmount(bookAmount);
    }

    private void setFutureTwoWeekBookInfo(CampaignGroupSaleGroupBoostGiveApplyAuditDataDetailViewDTO detailViewDTO, List<CampaignInquiryViewDTO> campaignInquiryViewDTOS, Map<Date, Long> dayDiscountPriceMap, Date today) {
        if (CollectionUtils.isEmpty(campaignInquiryViewDTOS)) {
            detailViewDTO.setFutureTwoWeekBookBudget(0L);
            detailViewDTO.setFutureTwoWeekBookAmount(0L);
            return;
        }
        List<CampaignInquiryViewDTO> filterInquiryInfos = campaignInquiryViewDTOS.stream()
                .filter(inquiry -> inquiryCondition(inquiry.getDate(), today, BOOK_TYPE_FUTURE_TWO_WEEK)).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(filterInquiryInfos)) {
            detailViewDTO.setFutureTwoWeekBookBudget(0L);
            detailViewDTO.setFutureTwoWeekBookAmount(0L);
            return;
        }

        Long bookBudget = filterInquiryInfos.stream()
                .filter(inquiry -> inquiry.getBookAmount() != null && dayDiscountPriceMap.containsKey(inquiry.getDate()))
                .mapToLong(inquiry -> dayDiscountPriceMap.get(inquiry.getDate()) * inquiry.getBookAmount())
                .sum();
        Long bookAmount = filterInquiryInfos.stream().filter(inquiry -> inquiry.getBookAmount() != null)
                .mapToLong(CampaignInquiryViewDTO::getBookAmount).sum();
        detailViewDTO.setFutureTwoWeekBookBudget(new BigDecimal(bookBudget).divide(new BigDecimal(1000), 0, BigDecimal.ROUND_HALF_UP).longValue());
        detailViewDTO.setFutureTwoWeekBookAmount(bookAmount);
    }

    /**
     * 查询计划报表+消耗信息
     *
     * @param context
     * @param campaignList
     * @return
     */
    private List<SaleGroupCampaignReportViewDTO> getCampaignReportList(ServiceContext context, List<CampaignViewDTO> campaignList) {
        List<Long> campaignIds = campaignList.stream().map(t -> t.getId()).collect(Collectors.toList());
        Map<String, Object> queryMap = Maps.newHashMap();
        queryMap.put(ADR_UNIQUE_KEY, "brand_onebp.common.common.rptOfflineDataLtpApi");
        // select
        queryMap.put("impPv", true);
        // where
        queryMap.put("memberIdEqual", context.getMemberId());
        queryMap.put("campaignIdIn", campaignIds);
        // orderBy
        queryMap.put("campaignIdGroupBy", true);
        queryMap.put("dateGroupBy", true);
        List<Map<String, Object>> reportMapList = bizReportQueryAbility.findDataList(context, queryMap);
        return convertCampaignReportMap2ViewDTOS(reportMapList);
    }

    /**
     * 计算历史消耗(消耗日以计划预订日为准)
     * 日消耗pv*日settlePrice
     *
     * @param campaignReportViewDTOS
     * @param campaignList
     */
    private void computeReportCostInfo(List<SaleGroupCampaignReportViewDTO> campaignReportViewDTOS, List<CampaignViewDTO> campaignList) {
        if (CollectionUtils.isEmpty(campaignReportViewDTOS)) {
            return;
        }
        RogerLogger.info("主补历史报表数据 {}", JSONObject.toJSONStringWithDateFormat(campaignReportViewDTOS, BrandDateUtil.DATE_FORMAT_YYYYMMDD_TYPE_1, SerializerFeature.WriteDateUseDateFormat));
        // 预订信息
        Map<Long, Set<Date>> campaignInquiryDateMap = Maps.newHashMap();
        Map<Long, Map<Date, Long>> campaignDatePriceMap = Maps.newHashMap();
        for (CampaignViewDTO campaignViewDTO : campaignList) {
            List<CampaignInquiryViewDTO> campaignInquiryViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignInquiryLockViewDTO())
                    .map(CampaignInquiryLockViewDTO::getCampaignInquiryViewDTOList).orElse(Lists.newArrayList());
            if (CollectionUtils.isNotEmpty(campaignInquiryViewDTOList)) {
                campaignInquiryDateMap.put(campaignViewDTO.getId(), campaignInquiryViewDTOList.stream().map(CampaignInquiryViewDTO::getDate).collect(Collectors.toSet()));
            }
            if (CollectionUtils.isNotEmpty(campaignViewDTO.getCampaignPriceViewDTO().getDiscountPriceInfoList())) {
                Map<Date, Long> discountDayPriceMap = getCampaignDayPriceMap(campaignViewDTO.getCampaignPriceViewDTO().getDiscountPriceInfoList());
                campaignDatePriceMap.put(campaignViewDTO.getId(), discountDayPriceMap);
            }
        }
        // 计算消耗金额信息
        for (SaleGroupCampaignReportViewDTO reportViewDTO : campaignReportViewDTOS) {
            Set<Date> inquiryDateSet = campaignInquiryDateMap.getOrDefault(reportViewDTO.getCampaignId(), Sets.newHashSet());
            Map<Date, Long> discountDayPriceMap = campaignDatePriceMap.getOrDefault(reportViewDTO.getCampaignId(), Maps.newHashMap());
            // 清空非预订天的消耗
            if (!inquiryDateSet.contains(reportViewDTO.getDate())) {
                reportViewDTO.setImpPv(0L);
                reportViewDTO.setCostPrice(0L);
                reportViewDTO.setUnitPrice(0L);
                continue;
            }
            Long unitPrice = discountDayPriceMap.getOrDefault(reportViewDTO.getDate(), 0L);
            reportViewDTO.setUnitPrice(unitPrice);
            reportViewDTO.setCostPrice(new BigDecimal(unitPrice * reportViewDTO.getImpPv()).divide(new BigDecimal(1000), 0, RoundingMode.HALF_UP).longValue());
        }
        RogerLogger.info("主补历史消耗数据 {}", JSONObject.toJSONStringWithDateFormat(campaignReportViewDTOS, BrandDateUtil.DATE_FORMAT_YYYYMMDD_TYPE_1, SerializerFeature.WriteDateUseDateFormat));
    }

    private List<SaleGroupCampaignReportViewDTO> convertCampaignReportMap2ViewDTOS(List<Map<String, Object>> reportMapList) {
        if (CollectionUtils.isEmpty(reportMapList)) {
            return Lists.newArrayList();
        }
        List<SaleGroupCampaignReportViewDTO> campaignReportViewDTOS = Lists.newArrayList();
        for (Map<String, Object> reportMap : reportMapList) {
            SaleGroupCampaignReportViewDTO campaignInventoryViewDTO = new SaleGroupCampaignReportViewDTO();
            if (Objects.nonNull(reportMap.get("campaignId"))) {
                campaignInventoryViewDTO.setCampaignId(Long.valueOf(String.valueOf(reportMap.get("campaignId"))));
            }
            if (Objects.nonNull(reportMap.get("impPv"))) {
                campaignInventoryViewDTO.setImpPv(Long.valueOf(String.valueOf(reportMap.get("impPv"))));
            }
            if (Objects.nonNull(reportMap.get("date"))) {
                Date date = BrandDateUtil.string2Date(String.valueOf(reportMap.get("date")), BrandDateUtil.DATE_FORMAT_YYYYMMDD_TYPE_2);
                campaignInventoryViewDTO.setDate(date);
            }
            campaignReportViewDTOS.add(campaignInventoryViewDTO);
        }
        return campaignReportViewDTOS;
    }

    private List<CampaignViewDTO> getSaleGroupCampaignList(ServiceContext context, CampaignGroupViewDTO campaignGroup, Long mainGroupId) {
        List<Long> querySaleGroupIds = campaignGroup.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream()
                .filter(saleGroup -> mainGroupId.equals(saleGroup.getSaleGroupId())
                        || mainGroupId.equals(saleGroup.getMainSaleGroupId()) && BrandSaleTypeEnum.BOOST.getCode().equals(saleGroup.getSaleType()))
                .map(SaleGroupInfoViewDTO::getSaleGroupId)
                .collect(Collectors.toList());
        CampaignQueryViewDTO query = new CampaignQueryViewDTO();
        query.setCampaignGroupId(campaignGroup.getId());
        query.setSaleGroupIds(querySaleGroupIds);
        query.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
        return campaignRepository.queryCampaignList(context, query);
    }

    private CampaignGroupViewDTO findSubCampaignGroupByMainSaleGroupId(ServiceContext context, Long mainGroupId) {
        CampaignGroupQueryViewDTO queryViewDTO = new CampaignGroupQueryViewDTO();
        queryViewDTO.setSaleGroupIds(Lists.newArrayList(mainGroupId));
        queryViewDTO.setCampaignGroupLevel(BrandCampaignGroupLevelEnum.LEVEL_TWO.getCode());
        List<CampaignGroupViewDTO> campaignGroupList = campaignGroupRepository.findCampaignGroupList(context, queryViewDTO);
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(campaignGroupList), "订单不存在");
        if (campaignGroupList.size() == 1) {
            return campaignGroupList.get(0);
        }
        return campaignGroupList.stream()
                .filter(t -> !inValidSubCampaignGroupStatusList.contains(t.getStatus()))
                .findFirst().orElse(campaignGroupList.get(0));
    }

    private List<ResourcePackageSaleGroupViewDTO> findResourcePackageSaleGroupList(ServiceContext context, CampaignGroupViewDTO campaignGroup, Long mainGroupId) {
        ResourcePackageQueryViewDTO resourcePackageQueryViewDTO = new ResourcePackageQueryViewDTO();
        resourcePackageQueryViewDTO.setTemplateId(campaignGroup.getCampaignGroupSaleViewDTO().getCustomerTemplateId());
        resourcePackageQueryViewDTO.setMainGroupId(mainGroupId);
        resourcePackageQueryViewDTO.setSaleType(BrandSaleTypeEnum.BOOST.getCode());
        return resourcePackageRepository.getSaleGroupList(context, resourcePackageQueryViewDTO, ResourcePackageQueryOption.builder().needSetting(true).build());
    }

    private void validateGetApplyAuditInfoParam(ServiceContext context, CampaignGroupSaleGroupBoostGiveApplyViewDTO applyViewDTO) {
        AssertUtil.notNull(context.getMemberId(), "memberId不能为空");
        AssertUtil.notNull(applyViewDTO.getMainGroupId(), "主分组ID不能为空");
        AssertUtil.notNull(applyViewDTO.getSaleGroupId(), "分组ID不能为空");
    }

//    public static void main(String[] args) {
//        String re = "[{\"campaignId\":69044575064,\"costPrice\":0,\"date\":1695225600000,\"impPv\":0},{\"campaignId\":69045550564,\"costPrice\":788,\"date\":1695139200000,\"impPv\":75},{\"campaignId\":69045542568,\"costPrice\":567,\"date\":1695139200000,\"impPv\":54},{\"campaignId\":69045540563,\"costPrice\":1554,\"date\":1695139200000,\"impPv\":222},{\"campaignId\":69045540562,\"costPrice\":1428,\"date\":1695139200000,\"impPv\":136},{\"campaignId\":69044575064,\"costPrice\":1736,\"date\":1695139200000,\"impPv\":248},{\"campaignId\":69043077556,\"costPrice\":1680,\"date\":1695139200000,\"impPv\":240},{\"campaignId\":69045550564,\"costPrice\":193662,\"date\":1695052800000,\"impPv\":18444},{\"campaignId\":69045542568,\"costPrice\":263834,\"date\":1695052800000,\"impPv\":25127},{\"campaignId\":69045540563,\"costPrice\":194481,\"date\":1695052800000,\"impPv\":27783},{\"campaignId\":69045540562,\"costPrice\":258384,\"date\":1695052800000,\"impPv\":24608},{\"campaignId\":69044575064,\"costPrice\":194635,\"date\":1695052800000,\"impPv\":27805},{\"campaignId\":69043077556,\"costPrice\":259420,\"date\":1695052800000,\"impPv\":37060},{\"campaignId\":69045550564,\"costPrice\":213087,\"date\":1694966400000,\"impPv\":20294},{\"campaignId\":69045542569,\"costPrice\":0,\"date\":1694966400000,\"impPv\":0},{\"campaignId\":69045542568,\"costPrice\":265419,\"date\":1694966400000,\"impPv\":25278},{\"campaignId\":69045540563,\"costPrice\":205716,\"date\":1694966400000,\"impPv\":29388},{\"campaignId\":69045540562,\"costPrice\":282702,\"date\":1694966400000,\"impPv\":26924},{\"campaignId\":69044575064,\"costPrice\":205387,\"date\":1694966400000,\"impPv\":29341},{\"campaignId\":69044575062,\"costPrice\":0,\"date\":1694966400000,\"impPv\":0},{\"campaignId\":69044567057,\"costPrice\":0,\"date\":1694966400000,\"impPv\":0},{\"campaignId\":69044567056,\"costPrice\":0,\"date\":1694966400000,\"impPv\":0},{\"campaignId\":69043077556,\"costPrice\":273357,\"date\":1694966400000,\"impPv\":39051},{\"campaignId\":69043077555,\"costPrice\":0,\"date\":1694966400000,\"impPv\":0},{\"campaignId\":69042525585,\"costPrice\":0,\"date\":1694966400000,\"impPv\":0},{\"campaignId\":69045542569,\"costPrice\":157017,\"date\":1694880000000,\"impPv\":22431},{\"campaignId\":69044575062,\"costPrice\":172333,\"date\":1694880000000,\"impPv\":24619},{\"campaignId\":69044567057,\"costPrice\":137529,\"date\":1694880000000,\"impPv\":13098},{\"campaignId\":69044567056,\"costPrice\":152124,\"date\":1694880000000,\"impPv\":14488},{\"campaignId\":69043077555,\"costPrice\":156625,\"date\":1694880000000,\"impPv\":22375},{\"campaignId\":69042525585,\"costPrice\":120698,\"date\":1694880000000,\"impPv\":11495},{\"campaignId\":69045542569,\"costPrice\":166068,\"date\":1694793600000,\"impPv\":23724},{\"campaignId\":69044575062,\"costPrice\":182532,\"date\":1694793600000,\"impPv\":26076},{\"campaignId\":69044567057,\"costPrice\":148985,\"date\":1694793600000,\"impPv\":14189},{\"campaignId\":69044567056,\"costPrice\":164409,\"date\":1694793600000,\"impPv\":15658},{\"campaignId\":69043077555,\"costPrice\":166243,\"date\":1694793600000,\"impPv\":23749},{\"campaignId\":69042525585,\"costPrice\":131492,\"date\":1694793600000,\"impPv\":12523},{\"campaignId\":69045542569,\"costPrice\":163408,\"date\":1694707200000,\"impPv\":23344},{\"campaignId\":69044575062,\"costPrice\":179683,\"date\":1694707200000,\"impPv\":25669},{\"campaignId\":69044567057,\"costPrice\":143997,\"date\":1694707200000,\"impPv\":13714},{\"campaignId\":69044567056,\"costPrice\":158256,\"date\":1694707200000,\"impPv\":15072},{\"campaignId\":69043077555,\"costPrice\":163436,\"date\":1694707200000,\"impPv\":23348},{\"campaignId\":69042525585,\"costPrice\":126273,\"date\":1694707200000,\"impPv\":12026},{\"campaignId\":69045542569,\"costPrice\":176568,\"date\":1694620800000,\"impPv\":25224},{\"campaignId\":69044575062,\"costPrice\":194257,\"date\":1694620800000,\"impPv\":27751},{\"campaignId\":69044567057,\"costPrice\":159212,\"date\":1694620800000,\"impPv\":15163},{\"campaignId\":69044567056,\"costPrice\":176106,\"date\":1694620800000,\"impPv\":16772},{\"campaignId\":69043077555,\"costPrice\":176785,\"date\":1694620800000,\"impPv\":25255},{\"campaignId\":69042525585,\"costPrice\":141047,\"date\":1694620800000,\"impPv\":13433},{\"campaignId\":69045542569,\"costPrice\":172767,\"date\":1694534400000,\"impPv\":24681},{\"campaignId\":69044575062,\"costPrice\":190239,\"date\":1694534400000,\"impPv\":27177},{\"campaignId\":69044567057,\"costPrice\":157983,\"date\":1694534400000,\"impPv\":15046},{\"campaignId\":69044567056,\"costPrice\":174888,\"date\":1694534400000,\"impPv\":16656},{\"campaignId\":69043077555,\"costPrice\":172669,\"date\":1694534400000,\"impPv\":24667},{\"campaignId\":69042525585,\"costPrice\":140133,\"date\":1694534400000,\"impPv\":13346},{\"campaignId\":69045542569,\"costPrice\":164479,\"date\":1694448000000,\"impPv\":23497},{\"campaignId\":69044575062,\"costPrice\":181083,\"date\":1694448000000,\"impPv\":25869},{\"campaignId\":69044567057,\"costPrice\":152534,\"date\":1694448000000,\"impPv\":14527},{\"campaignId\":69044567056,\"costPrice\":174510,\"date\":1694448000000,\"impPv\":16620},{\"campaignId\":69043077555,\"costPrice\":164535,\"date\":1694448000000,\"impPv\":23505},{\"campaignId\":69042525585,\"costPrice\":140490,\"date\":1694448000000,\"impPv\":13380}]";
//        List<SaleGroupCampaignReportViewDTO> reportList = JSONObject.parseArray(re, SaleGroupCampaignReportViewDTO.class);
//        Map<Long, List<SaleGroupCampaignReportViewDTO>> reportMap = reportList.stream().collect(Collectors.groupingBy(SaleGroupCampaignReportViewDTO::getCampaignId));
//        reportMap.forEach((campaignId, campaignReportList) -> {
//            Long sumPV = campaignReportList.stream().mapToLong(SaleGroupCampaignReportViewDTO::getImpPv).sum();
//            Long sumMoney = campaignReportList.stream().mapToLong(SaleGroupCampaignReportViewDTO::getCostPrice).sum();
//            System.out.println(campaignId + " : " + sumPV + " : " + sumMoney );
//        });
//    }
}
