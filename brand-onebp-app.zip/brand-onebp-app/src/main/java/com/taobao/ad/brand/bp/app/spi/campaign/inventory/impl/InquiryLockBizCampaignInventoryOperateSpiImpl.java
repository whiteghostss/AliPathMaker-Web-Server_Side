package com.taobao.ad.brand.bp.app.spi.campaign.inventory.impl;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.nb.framework.core.annotation.AbilitySpiInstance;
import com.alibaba.hermes.framework.error.ErrorCodeAware;
import com.taobao.ad.brand.bp.app.spi.campaign.inventory.BizCampaignInventoryOperateSpi;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignInventoryWorkflow;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignInquiryOperateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignScheduleViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.inventory.ICampaignDoohValidateForCampaignInventoryOperateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignInventoryWorkflowParam;

import javax.annotation.Resource;
import java.util.List;

@AbilitySpiInstance(bizCodes = {BizCampaignInventoryOperateSpi.INQUIRY,BizCampaignInventoryOperateSpi.LOCK},
        name = "inquiryLockBizCampaignInventoryOperateSpiImpl", desc = "库存询量/锁量操作实现")
public class InquiryLockBizCampaignInventoryOperateSpiImpl extends DefaultBizCampaignInventoryOperateSpiImpl {

    @Resource
    private BizCampaignInventoryWorkflow bizCampaignInventoryWorkflow;
    @Resource
    private ICampaignDoohValidateForCampaignInventoryOperateAbility campaignDoohValidateForCampaignInventoryOperateAbility;;

    @Override
    public ErrorCodeAware validateCampaignInventoryOperate(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO, BizCampaignInventoryWorkflowParam inventoryWorkflowParam) {
        ErrorCodeAware errorCodeAware = super.validateCampaignInventoryOperate(serviceContext, inquiryOperateViewDTO, inventoryWorkflowParam);
        if(errorCodeAware != null){
            return errorCodeAware;
        }
        //天攻的计划，锁量之前必须询量  接口放开,天攻支持直接锁量
        /*campaignDoohValidateForCampaignInventoryOperateAbility.handle(serviceContext,
                CampaignDoohInventoryOperateValidateAbilityParam.builder().abilityTarget(inquiryOperateViewDTO).campaignTreeViewDTOList(inventoryWorkflowParam.getCampaignTreeViewDTOList()).build());*/
        return null;
    }

    @Override
    public List<CampaignScheduleViewDTO> convertToCampaignSchedule(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO, BizCampaignInventoryWorkflowParam inventoryWorkflowParam) {
        //非系统投放和二环CPT场景，询量和锁量提前预分配每天库存预定量
        bizCampaignInventoryWorkflow.preAssignUnProgrammaticOrCptCampaignSchedule(serviceContext, inventoryWorkflowParam.getCampaignTreeViewDTOList());
        return super.convertToCampaignSchedule(serviceContext,inquiryOperateViewDTO, inventoryWorkflowParam);
    }

    @Override
    public Void inventoryRequest(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO, BizCampaignInventoryWorkflowParam inventoryWorkflowParam) {
        //非系统投放和二环CPT场景，询量和锁量自动分配每天库存预定量
        bizCampaignInventoryWorkflow.executeAssignUnProgrammaticOrCptCampaignSchedule(serviceContext, inventoryWorkflowParam.getCampaignTreeViewDTOList());
        return super.inventoryRequest(serviceContext, inquiryOperateViewDTO, inventoryWorkflowParam);
    }
}

