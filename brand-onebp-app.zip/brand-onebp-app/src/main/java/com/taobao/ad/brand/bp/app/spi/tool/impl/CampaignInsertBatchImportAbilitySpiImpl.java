package com.taobao.ad.brand.bp.app.spi.tool.impl;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;

import com.alibaba.ad.nb.framework.core.annotation.AbilitySpiInstance;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alibaba.ad.nb.tpp.exception.TppException;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.app.spi.tool.BatchImportAbilitySpi;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignCommandWorkflow;
import com.taobao.ad.brand.bp.client.dto.base.ErrorMessageDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignBatchImportParamViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignBatchImportRawViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportTaskViewDTO;
import com.taobao.ad.brand.bp.client.dto.tool.BatchImportDistLockParamViewDTO;
import com.taobao.ad.brand.bp.client.dto.tool.BatchImportParamViewDTO;
import com.taobao.ad.brand.bp.client.enums.report.ReportTaskStatusEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.enums.distlock.DistLockEnum;
import com.taobao.ad.brand.bp.common.threadpooltask.CampaignBatchImportTaskIdentifier;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.report.repository.ReportSyncTaskRepository;
import com.taobao.eagleeye.EagleEye;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@AbilitySpiInstance(bizCode = BatchImportAbilitySpi.BATCH_IMPORT_CAMPAIGN_INSERT, name = "CampaignInsertBatchImportAbilitySpiImpl", desc = "计划批量导入")
public class CampaignInsertBatchImportAbilitySpiImpl extends DefaultBatchImportAbilitySpiImpl {
    @Resource
    private BizCampaignCommandWorkflow bizCampaignCommandWorkflow;
    @Resource
    private CampaignBatchImportTaskIdentifier campaignBatchImportTaskIdentifier;
    @Resource
    private ReportSyncTaskRepository reportSyncTaskRepository;

//    private static final ThreadPoolExecutor THREAD_POOL = new ThreadPoolExecutor(
//            20, 20, 60L, TimeUnit.SECONDS, new ArrayBlockingQueue<>(5120),
//            new ThreadFactoryBuilder().setNameFormat("campaign_batch_add-%d").build());

    @Override
    public Void validateImportParam(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO) {
        CampaignBatchImportParamViewDTO campaignBatchImportParamViewDTO = (CampaignBatchImportParamViewDTO) batchImportParamViewDTO;
        AssertUtil.notNull(campaignBatchImportParamViewDTO, "计划批量新建参数不能为空");
        AssertUtil.notNull(campaignBatchImportParamViewDTO.getTaskId(), "计划批量新建参数-任务ID不能为空");
        AssertUtil.notNull(campaignBatchImportParamViewDTO.getCampaignGroupId(), "计划批量新建参数-订单ID不能为空");
        AssertUtil.notNull(campaignBatchImportParamViewDTO.getSaleGroupId(), "计划批量新建参数-分组ID不能为空");
        AssertUtil.notEmpty(campaignBatchImportParamViewDTO.getCampaignBatchImportRawViewDTOList(), "计划批量新建参数-待解析参数为空");
        //计划名称重复
        String thanOneTitle = campaignBatchImportParamViewDTO.getCampaignBatchImportRawViewDTOList().stream()
                .filter(importRowViewDTO -> !Boolean.TRUE.equals(importRowViewDTO.getIsFiltered()))
                .filter(importRawViewDTO -> {
                    String title = Optional.ofNullable(importRawViewDTO.getCampaignViewDTO())
                            .map(CampaignViewDTO::getTitle).orElse(null);
                    return StringUtils.isNotBlank(title);
                })
                .map(importRawViewDTO -> importRawViewDTO.getCampaignViewDTO())
                .collect(Collectors.groupingBy(CampaignViewDTO::getTitle, Collectors.counting()))
                .entrySet().stream().filter(entry -> entry.getValue() > 1).map(Map.Entry::getKey).collect(Collectors.joining(","));
        AssertUtil.assertTrue(StringUtils.isBlank(thanOneTitle),String.format("批量新建场景计划名称不允许重复，请检查以下计划名称：%s",thanOneTitle));
        AssertUtil.notNull(campaignBatchImportParamViewDTO.getTaskViewDTO(), "查询计划批量导入任务失败");
        return null;
    }

    @Override
    public BatchImportDistLockParamViewDTO buildImportDisLockParam(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO) {
        CampaignBatchImportParamViewDTO campaignBatchImportParamViewDTO = (CampaignBatchImportParamViewDTO) batchImportParamViewDTO;
        Long campaignGroupId = campaignBatchImportParamViewDTO.getCampaignGroupId();
        Long saleGroupId = campaignBatchImportParamViewDTO.getSaleGroupId();
        Long taskId = campaignBatchImportParamViewDTO.getTaskId();

        DistLockEnum distLockEnum = DistLockEnum.CAMPAIGN_BATCH_IMPORT_KEY;
        BatchImportDistLockParamViewDTO distLockParamViewDTO = new BatchImportDistLockParamViewDTO();
        distLockParamViewDTO.setLockKey(distLockEnum.formatLockKey(saleGroupId, campaignGroupId));
        distLockParamViewDTO.setLockReqValue(distLockEnum.formatLockValue(taskId));
        distLockParamViewDTO.setExpireTime(distLockEnum.getExpireTime());
        return distLockParamViewDTO;
    }

    @Override
    public String tryDisLockErrorMessage(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO, String distCurValue) {
        CampaignBatchImportParamViewDTO campaignBatchImportParamViewDTO = (CampaignBatchImportParamViewDTO) batchImportParamViewDTO;
        Long campaignGroupId = campaignBatchImportParamViewDTO.getCampaignGroupId();
        Long saleGroupId = campaignBatchImportParamViewDTO.getSaleGroupId();

        return String.format("当前订单 %d 分组 %d 下已有正在执行中的批量计划导入任务 [%s] trace: %s",
                campaignGroupId, saleGroupId, distCurValue, EagleEye.getTraceId());
    }

    @Override
    public Void invokeImport(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO) {
        CampaignBatchImportParamViewDTO campaignBatchImportParamViewDTO = (CampaignBatchImportParamViewDTO) batchImportParamViewDTO;
        List<CampaignBatchImportRawViewDTO> campaignBatchImportRawViewDTOList = campaignBatchImportParamViewDTO.getCampaignBatchImportRawViewDTOList();
        TaskStream.consume(campaignBatchImportTaskIdentifier, campaignBatchImportRawViewDTOList, (campaignBatchImportRawViewDTO, i) -> {
            if (Boolean.TRUE.equals(campaignBatchImportRawViewDTO.getIsFiltered())) {
                // 本条计划被预检查过滤
                return;
            }
            CampaignViewDTO campaignViewDTO = campaignBatchImportRawViewDTO.getCampaignViewDTO();
            if (Objects.nonNull(campaignViewDTO) && Objects.isNull(campaignViewDTO.getId())) {
                try {
                    // 批量执行新建
//                    ExtensionPointsFactory.runAbilitySpi(BizCampaignBusinessLineSpi.class, extension -> extension.addCampaign(context, campaignViewDTO), context.getBizCode());
                    bizCampaignCommandWorkflow.addCampaign(context, campaignViewDTO);
                } catch (Exception e) {
                    // 执行批量新建异常，写入执行信息
                    RogerLogger.error("批量新建计划失败 {}", JSON.toJSONString(campaignViewDTO), e);
                    buildErrorMessage(i, e, campaignBatchImportRawViewDTO, campaignViewDTO);
                }
            } else if (Objects.nonNull(campaignViewDTO) && Objects.nonNull(campaignViewDTO.getId())) {
                // 批量执行编辑
                try {
//                    ExtensionPointsFactory.runAbilitySpi(BizCampaignBusinessLineSpi.class, extension -> extension.updateCampaign(context, campaignViewDTO), context.getBizCode());
                    bizCampaignCommandWorkflow.updateCampaign(context, campaignViewDTO);
                } catch (Exception e) {
                    // 执行批量编辑异常，写入执行信息
                    RogerLogger.error("批量编辑计划失败 {}", JSON.toJSONString(campaignViewDTO), e);
                    buildErrorMessage(i, e, campaignBatchImportRawViewDTO, campaignViewDTO);
                }
            }
        }).commit().handleException(e -> {
            if (CollectionUtils.isNotEmpty(e)) {
                Throwable throwable = e.get(0).getValue();
                RogerLogger.error("批量新建编辑异常", throwable);
                throw new BrandOneBPException("批量新建编辑异常", throwable);
            }
        });
        return null;
    }

    /**
     * 构建错误信息
     *
     * @param index
     * @param e
     * @param campaignBatchImportRawViewDTO
     * @param campaignViewDTO
     */
    private void buildErrorMessage(int index, Exception e, CampaignBatchImportRawViewDTO campaignBatchImportRawViewDTO, CampaignViewDTO campaignViewDTO) {
        if (e instanceof TppException) {
            if (e.getCause() != null && e.getCause() instanceof BrandOneBPException) {
                e = (BrandOneBPException) e.getCause();
            }
        }
        ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO();
        errorMessageDTO.setSerialId(index + 1);
        errorMessageDTO.setErrorMessage(e.toString());
        errorMessageDTO.setId(campaignViewDTO.getId());
        errorMessageDTO.setName(campaignViewDTO.getTitle());
        campaignBatchImportRawViewDTO.setIsFiltered(true);
        campaignBatchImportRawViewDTO.setErrorMessage(errorMessageDTO);
    }

    @Override
    public Void updateImportResult(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO) {
        CampaignBatchImportParamViewDTO campaignBatchImportParamViewDTO = (CampaignBatchImportParamViewDTO) batchImportParamViewDTO;
        ReportTaskViewDTO taskViewDTO = campaignBatchImportParamViewDTO.getTaskViewDTO();
        List<ErrorMessageDTO> errorMessageList = campaignBatchImportParamViewDTO.getCampaignBatchImportRawViewDTOList().stream()
                .filter(campaignBatchImportRawViewDTO -> Boolean.TRUE.equals(campaignBatchImportRawViewDTO.getIsFiltered()))
                .map(CampaignBatchImportRawViewDTO::getErrorMessage)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(errorMessageList) && errorMessageList.size() == campaignBatchImportParamViewDTO.getCampaignBatchImportRawViewDTOList().size()) {
            // 全部异常，任务置为失败，聚合失败原因
            taskViewDTO.setErrorMsg(JSONObject.toJSONString(errorMessageList));
            reportSyncTaskRepository.runFail(context, taskViewDTO);
        } else if (CollectionUtils.isEmpty(errorMessageList)) {
            // 没有异常记录，任务设置为成功
            taskViewDTO.setStatus(ReportTaskStatusEnum.SUCCEED.getValue());
            reportSyncTaskRepository.modifyStatus(context, taskViewDTO);
        } else if (CollectionUtils.isNotEmpty(errorMessageList) && errorMessageList.size() < campaignBatchImportParamViewDTO.getCampaignBatchImportRawViewDTOList().size()) {
            // 过滤出的失败的计划条数小于总条数时设置状态为部分成功
            taskViewDTO.setErrorMsg(JSONObject.toJSONString(errorMessageList));
            taskViewDTO.setStatus(ReportTaskStatusEnum.PARTIAL_SUCCESS.getValue());
            reportSyncTaskRepository.modifyStatus(context, taskViewDTO);
        }
        return null;
    }

    @Override
    public String invokeImportExceptionMessage(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO, String exceptionMeg) {
        ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO();
        errorMessageDTO.setErrorMessage("计划批量创建、编辑失败: " + exceptionMeg + " trace: " + EagleEye.getTraceId());
        return JSONObject.toJSONString(Lists.newArrayList(errorMessageDTO));
    }
}
