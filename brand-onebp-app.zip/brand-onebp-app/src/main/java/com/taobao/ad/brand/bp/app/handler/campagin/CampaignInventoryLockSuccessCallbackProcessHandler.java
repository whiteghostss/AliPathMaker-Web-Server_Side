package com.taobao.ad.brand.bp.app.handler.campagin;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.alibaba.fastjson.JSON;
import com.alibaba.hermes.framework.ddd.event.annotation.DomainEventHandler;
import com.alibaba.hermes.framework.event.EventHandler;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.app.workflow.salegroup.BizSaleGroupCommandWorkflow;
import com.taobao.ad.brand.bp.domain.event.campaign.CampaignInventoryCallbackEvent;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;

/**
 * 计划库存回调通知链路
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@DomainEventHandler(topic = "campaign_inventory_lock_success_callback_topic", event = CampaignInventoryCallbackEvent.class)
public class CampaignInventoryLockSuccessCallbackProcessHandler implements EventHandler<CampaignInventoryCallbackEvent> {

    private final BizSaleGroupCommandWorkflow bizSaleGroupCommandWorkflow;

    @Override
    public Response handle(CampaignInventoryCallbackEvent campaignInventoryCallbackEvent) {
        RogerLogger.info("campaign_inventory_lock_success_callback_topic start:{}",JSON.toJSONString(campaignInventoryCallbackEvent));
        CampaignViewDTO campaignViewDTO = campaignInventoryCallbackEvent.getContext().getCampaignViewDTO();
        ServiceContext serviceContext = campaignInventoryCallbackEvent.getContext().getServiceContext();
        if (!BrandCampaignStatusEnum.LOCK_SUCCESS.getCode().equals(campaignViewDTO.getStatus())) {
            RogerLogger.info("计划" + campaignViewDTO.getId() + "非锁量");
            return Response.success();
        }
        Long campaignGroupId = campaignViewDTO.getCampaignGroupId();
        Long saleGroupId = campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId();
        bizSaleGroupCommandWorkflow.clearSaleGroupEstimateResult(serviceContext,campaignGroupId, Collections.singletonList(saleGroupId));
        return Response.success();
    }
}
