package com.taobao.ad.brand.bp.app.service.mediarule;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.media.mutex.MediaMutexRuleViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.api.mediarule.BizMediaMutexRuleCommandService;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.mediarule.MediaMutexRuleRepository;
import com.taobao.ad.brand.bp.domain.mediarule.ability.MediaMutexRuleAbility;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Optional;

/**
 * 互斥规则相关服务
 *
 * @author linhua.deng
 */
@HSFProvider(serviceInterface = BizMediaMutexRuleCommandService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizMediaMutexRuleCommandServiceImpl implements BizMediaMutexRuleCommandService {

    private final MediaMutexRuleRepository mediaMutexRuleRepository;
    private final MediaMutexRuleAbility mediaMutexRuleAbility;

    @Override
    public SingleResponse<Long> addMutexRule(ServiceContext context, MediaMutexRuleViewDTO viewDTO) {
        AssertUtil.notNull(viewDTO, "参数不允许为空");

        mediaMutexRuleAbility.validateMutexRule(context, viewDTO, null);
        mediaMutexRuleAbility.initMutexRule(viewDTO, null);

        Long freqId = mediaMutexRuleRepository.addMutexRule(context, viewDTO);
        return SingleResponse.of(freqId);
    }

    @Override
    public SingleResponse<Integer> updateMutexRule(ServiceContext context, MediaMutexRuleViewDTO viewDTO) {
        AssertUtil.notNull(Optional.ofNullable(viewDTO).map(MediaMutexRuleViewDTO::getId).orElse(null),"互斥规则ID不能为空");

        MediaMutexRuleViewDTO mutexRuleViewDTO = mediaMutexRuleRepository.getMutexRule(context, viewDTO.getId());
        AssertUtil.notNull(mutexRuleViewDTO,String.format("互斥规则不存在，id=%s",viewDTO.getId()));

        mediaMutexRuleAbility.validateMutexRule(context, viewDTO, mutexRuleViewDTO);
        mediaMutexRuleAbility.initMutexRule(viewDTO, mutexRuleViewDTO);

        Integer count = mediaMutexRuleRepository.updateMutexRule(context, viewDTO);
        return SingleResponse.of(count);
    }

    @Override
    public SingleResponse<Integer> updateMutexRuleStatus(ServiceContext context, List<Long> ids, Integer status) {
        AssertUtil.notEmpty(ids, "互斥规则id不能为空");
        AssertUtil.notNull(BrandBoolEnum.getByCode(status), "操作状态不合法");

        Integer count = mediaMutexRuleRepository.updateMutexRuleStatus(context,ids, status);
        return SingleResponse.of(count);
    }
}