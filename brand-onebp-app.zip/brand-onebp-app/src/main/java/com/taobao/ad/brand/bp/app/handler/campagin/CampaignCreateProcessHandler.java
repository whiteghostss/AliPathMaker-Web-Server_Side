package com.taobao.ad.brand.bp.app.handler.campagin;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.order.ConfirmedAgreementInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.hermes.framework.ddd.event.annotation.DomainEventHandler;
import com.alibaba.hermes.framework.event.EventHandler;
import com.taobao.ad.brand.bp.app.workflow.campaigngroup.BizCampaignGroupCommandWorkflow;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupOrderCommandViewDTO;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.event.campaign.CampaignCreateNoticeEvent;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor(onConstructor_ = @Autowired)
@DomainEventHandler(topic = "effect_campaign_create_topic", event = CampaignCreateNoticeEvent.class)
public class CampaignCreateProcessHandler implements EventHandler<CampaignCreateNoticeEvent> {

    private final CampaignGroupRepository campaignGroupRepository;
    private final BizCampaignGroupCommandWorkflow bizCampaignGroupCommandWorkflow;

    @Override
    public Response handle(CampaignCreateNoticeEvent campaignCreateNoticeEvent) {
        ServiceContext serviceContext = campaignCreateNoticeEvent.getContext().getServiceContext();
        Long campaignGroupId = campaignCreateNoticeEvent.getContext().getCampaignGroupId();
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(serviceContext, campaignGroupId);
        CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO = new CampaignGroupOrderCommandViewDTO();
        campaignGroupOrderCommandViewDTO.setId(campaignGroupId);
        if (CollectionUtils.isNotEmpty(campaignCreateNoticeEvent.getContext().getSaleGroupIds())) {
            campaignGroupOrderCommandViewDTO.setSaleGroupIds(campaignCreateNoticeEvent.getContext().getSaleGroupIds());
        } else {
            campaignGroupOrderCommandViewDTO.setSaleGroupIds(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream().map(SaleGroupInfoViewDTO::getSaleGroupId).collect(Collectors.toList()));
        }

        ConfirmedAgreementInfoViewDTO confirmedAgreementInfoViewDTO = new ConfirmedAgreementInfoViewDTO();
        confirmedAgreementInfoViewDTO.setConfirmTime(BrandDateUtil.getCurrentDate());
        confirmedAgreementInfoViewDTO.setContent("确认");
        confirmedAgreementInfoViewDTO.setVersion("1");
        campaignGroupOrderCommandViewDTO.setConfirmedAgreementInfoViewDTO(confirmedAgreementInfoViewDTO);
        bizCampaignGroupCommandWorkflow.order(serviceContext, campaignGroupOrderCommandViewDTO);
        return Response.success();
    }
}
