package com.taobao.ad.brand.bp.app.spi.solution.impl;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryLockViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.alibaba.ad.nb.framework.core.annotation.AbilitySpiInstance;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.app.spi.solution.CartItemSolutionCommandOperateSpi;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignCommandWorkflow;
import com.taobao.ad.brand.bp.client.dto.solution.CartItemSolutionViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;

import javax.annotation.Resource;
import java.util.Optional;

@AbilitySpiInstance(bizCode = CartItemSolutionCommandOperateSpi.CAMPAIGN_SAVE, name = "campaignSaveCartItemSolutionCommandOperateSpiImpl", desc = "自助化极简版计划保存解决方案扩展")
public class CampaignSaveCartItemSolutionCommandOperateSpiImpl extends DefaultCartItemSolutionCommandOperateSpiImpl {
    @Resource
    private BizCampaignCommandWorkflow bizCampaignCommandWorkflow;

    @Override
    public Void validateForUpdateCartItemSolution(ServiceContext serviceContext, CartItemSolutionViewDTO dbSolutionCommandViewDTO, CartItemSolutionViewDTO solutionCommandViewDTO) {
        CampaignViewDTO dbCampaignViewDTO = dbSolutionCommandViewDTO.getCampaignViewDTO();
        AssertUtil.assertTrue(BrandCampaignStatusEnum.LOCK_FAIL.getCode().equals(dbCampaignViewDTO.getStatus()),"只允许编辑锁量失败计划");

        return super.validateForUpdateCartItemSolution(serviceContext,dbSolutionCommandViewDTO,solutionCommandViewDTO);
    }

    @Override
    public Void initForUpdateCartItemSolution(ServiceContext serviceContext, CartItemSolutionViewDTO dbSolutionCommandViewDTO, CartItemSolutionViewDTO solutionCommandViewDTO) {
        //计划状态设置为草稿，并清空询量数据
        CampaignViewDTO campaignViewDTO = solutionCommandViewDTO.getCampaignViewDTO();
        campaignViewDTO.setStatus(BrandCampaignStatusEnum.NEW.getCode());

        CampaignInquiryLockViewDTO campaignInquiryLockViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignInquiryLockViewDTO()).orElse(new CampaignInquiryLockViewDTO());
        campaignInquiryLockViewDTO.setCampaignInquiryViewDTOList(Lists.newArrayList());
        campaignViewDTO.setCampaignInquiryLockViewDTO(campaignInquiryLockViewDTO);
        return null;
    }

    @Override
    public Void executeForUpdateCartItemSolution(ServiceContext serviceContext, CartItemSolutionViewDTO dbSolutionCommandViewDTO, CartItemSolutionViewDTO solutionCommandViewDTO) {
        //修改计划
        bizCampaignCommandWorkflow.updateCampaign(serviceContext,solutionCommandViewDTO.getCampaignViewDTO());
        return null;
    }
}

