package com.taobao.ad.brand.bp.app.service.creative;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.adgroup.CreativeRefViewDTO;
import com.alibaba.ad.brand.dto.audience.CrowdBaseViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdScenarioViewDTO;
import com.alibaba.ad.brand.dto.common.TagViewDTO;
import com.alibaba.ad.brand.dto.creative.ContentVersionViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.brand.dto.creative.element.ElementViewDTO;
import com.alibaba.ad.brand.dto.creative.materialgroup.MaterialGroupViewDTO;
import com.alibaba.ad.brand.dto.creative.template.CreativeTemplateViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandDicTypeEnum;
import com.alibaba.ad.brand.sdk.constant.creative.field.*;
import com.alibaba.ad.nb.ssp.constant.template.ElementTypeEnum;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.utils.BeanUtils;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.alimama.faas.brand.engine.entity.domain.CreativeScore;
import com.alimama.faas.brand.engine.entity.response.AICreativePredictResponse;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.adapter.port.tunnel.sao.dmpargus.DmpArgusSAO;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.app.workflow.creative.BizCreativeCommandWorkflow;
import com.taobao.ad.brand.bp.client.api.creative.BizCreativeQueryService;
import com.taobao.ad.brand.bp.client.dto.adgroup.ExportMonitorCodeViewDTO;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.DRCMessageViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.*;
import com.taobao.ad.brand.bp.client.dto.creative.audit.MediaAuditPageViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.notice.CreativeDRCMessageViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.notice.CreativeScoreResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.media.MediaViewDTO;
import com.taobao.ad.brand.bp.client.dto.monitor.MonitorCodeQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportTaskViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.query.ReportTaskQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.template.TemplateViewDTO;
import com.taobao.ad.brand.bp.common.constant.TemplateConstant;
import com.taobao.ad.brand.bp.common.converter.creative.CreativeViewConverter;
import com.taobao.ad.brand.bp.common.enums.creative.CreativeTypeEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.common.util.SignatureUtils;
import com.taobao.ad.brand.bp.domain.adgroup.repository.AdgroupRepository;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeRepository;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeTemplateRepository;
import com.taobao.ad.brand.bp.domain.creative.spi.BizCreativeSpi;
import com.taobao.ad.brand.bp.domain.dmpargus.DmpArgusRepository;
import com.taobao.ad.brand.bp.domain.media.MediaRepository;
import com.taobao.ad.brand.bp.domain.report.repository.ReportSyncTaskRepository;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeQueryParamResetAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.query.ICreativeQueryParamResetAbility;
import com.taobao.ad.brand.bp.domain.ssp.ProductRepository;
import com.taobao.ad.brand.bp.domain.tag.TagRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;
import org.springframework.util.DigestUtils;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/3/14 13:12
 * @description ：
 * @modified By：
 */
@HSFProvider(serviceInterface = BizCreativeQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizCreativeQueryServiceImpl implements BizCreativeQueryService {

    private final CreativeRepository creativeRepository;
    private final CampaignRepository campaignRepository;
    private final CreativeTemplateRepository creativeTemplateRepository;
    private final AdgroupRepository adgroupRepository;
    private final ProductRepository productRepository;
    private final MediaRepository mediaRepository;
    private final CreativeViewConverter creativeViewConverter;
    private final ReportSyncTaskRepository reportSyncTaskRepository;
    private final TagRepository tagRepository;
    private final DmpArgusRepository dmpArgusRepository;
    private final BizCreativeCommandWorkflow bizCreativeCommandWorkflow;
    private final ICreativeQueryParamResetAbility creativeQueryParamResetAbility;

    private final static int MAX_PAGE_COUNT = 2000;
    private static final String MEDIA_ID_LIST = "mediaIdList";
    protected static final String MEDIA_ID = "mediaId";
    private final DmpArgusSAO dmpArgusSAO;


    @Override
    public MultiResponse<CreativePageViewDTO> findCreativePage(ServiceContext context, CreativeQueryViewDTO query) {
        //重置计划查询参数
        creativeQueryParamResetAbility.handle(context, CreativeQueryParamResetAbilityParam.builder().abilityTarget(query).build());

        Integer isRequired = query.getIsRequired();
        query.setIsRequired(null);
        PageResultViewDTO<CreativeViewDTO> pageResult = creativeRepository.findListWithPage(context, query);
        List<CreativeViewDTO> creativeViewDTOS = pageResult.getList();
        if (CollectionUtils.isEmpty(creativeViewDTOS)) {
            return MultiResponse.empty();
        }
        List<CreativePageViewDTO> creativePageViewDTOS = creativeViewConverter.convertDTO2ViewDTOList(creativeViewDTOS);
        fillApproveTime(creativePageViewDTOS);
        fillPageInfo(context, creativePageViewDTOS);
        fillSubCreativeMediaAuditRefuseCount(context,creativePageViewDTOS);
        List<CreativePageViewDTO> packageCreativeList = creativePageViewDTOS.stream().filter(creativePageViewDTO ->
                BrandCreativePackageTypeEnum.PACKAGE.getValue().equals(creativePageViewDTO.getPackageType())).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(packageCreativeList)) {
            Map<Long, List<CreativePageViewDTO>> parentCreativeMap = build(context, packageCreativeList, isRequired, BrandBoolEnum.BRAND_TRUE.getCode());
            creativePageViewDTOS.stream().filter(creativePageViewDTO ->
                    BrandCreativePackageTypeEnum.PACKAGE.getValue().equals(creativePageViewDTO.getPackageType())).forEach(creativePageViewDTO ->
                    creativePageViewDTO.setSubCreativeViewDTOList(parentCreativeMap.get(creativePageViewDTO.getId())));
        }
        return MultiResponse.of(creativePageViewDTOS, pageResult.getCount());
    }

    private void fillApproveTime(List<CreativePageViewDTO> creativePageViewDTOS) {
        //主创意汇总子创意的审核有效期
        creativePageViewDTOS.forEach(creativePageViewDTO -> {
            if (CollectionUtils.isEmpty(creativePageViewDTO.getSubCreativeViewDTOList())) {
                return;
            }
            List<Date> effectiveTimeList = creativePageViewDTO.getSubCreativeViewDTOList().stream().map(subCreativePageViewDTO -> subCreativePageViewDTO.getCreativeAudit().getMamaAudit().getEffectiveTime())
                    .filter(Objects::nonNull)
                    .sorted()
                    .collect(Collectors.toList());
            List<Date> expireTimeList = creativePageViewDTO.getSubCreativeViewDTOList().stream().map(subCreativePageViewDTO -> subCreativePageViewDTO.getCreativeAudit().getMamaAudit().getExpireTime())
                    .filter(Objects::nonNull)
                    .sorted(Comparator.reverseOrder())
                    .collect(Collectors.toList());
            if (creativePageViewDTO.getCreativeAudit() != null && creativePageViewDTO.getCreativeAudit().getMamaAudit() != null) {
                creativePageViewDTO.getCreativeAudit().getMamaAudit().setEffectiveTime(effectiveTimeList.size() == creativePageViewDTO.getSubCreativeViewDTOList().size() ? effectiveTimeList.get(0) : null);
                creativePageViewDTO.getCreativeAudit().getMamaAudit().setExpireTime(expireTimeList.size() == creativePageViewDTO.getSubCreativeViewDTOList().size() ? expireTimeList.get(0) : null);
            }
        });
    }

    @Override
    public MultiResponse<CreativePageViewDTO> findCreativeNoPage(ServiceContext context, CreativeQueryViewDTO query) {
        query.setPageNo(1);
        query.setPageSize(200);
        //重置计划查询参数
        creativeQueryParamResetAbility.handle(context, CreativeQueryParamResetAbilityParam.builder().abilityTarget(query).build());
        PageResultViewDTO<CreativeViewDTO> pageResult = creativeRepository.findListWithPage(context, query);
        if (pageResult.getCount() == 0) {
            return MultiResponse.empty();
        }
        List<CreativePageViewDTO> result = creativeViewConverter.convertDTO2ViewDTOList(pageResult.getList());
        int totalPageNo = pageResult.getCount() / 200 + 1;
        query.setPageNo(query.getPageNo() + 1);
        while (totalPageNo >= query.getPageNo()) {
            pageResult = creativeRepository.findListWithPage(context, query);
            result.addAll(creativeViewConverter.convertDTO2ViewDTOList(pageResult.getList()));
            query.setPageNo(query.getPageNo() + 1);
        }
        fillPageInfo(context, result);
        return MultiResponse.of(result);
    }

    @Override
    public SingleResponse<CreativePageViewDTO> getCreativeById(ServiceContext context, Long creativeId) {
        CreativeViewDTO dbCreativeViewDTO = creativeRepository.getCreativeById(context, creativeId);
        if (dbCreativeViewDTO == null) {
            return SingleResponse.of(null);
        }
        CreativePageViewDTO creativePageViewDTO = creativeViewConverter.convertDTO2ViewDTO(dbCreativeViewDTO);
        fillTemplateInfo(context,dbCreativeViewDTO,creativePageViewDTO);
        fillPageInfo(context, Collections.singletonList(creativePageViewDTO));
        if (BrandCreativePackageTypeEnum.PACKAGE.getValue().equals(creativePageViewDTO.getPackageType())) {
            Map<Long, List<CreativePageViewDTO>> parentCreativeMap = build(context, Lists.newArrayList(creativePageViewDTO), BrandBoolEnum.BRAND_TRUE.getCode(), BrandBoolEnum.BRAND_TRUE.getCode());
            creativePageViewDTO.setSubCreativeViewDTOList(parentCreativeMap.get(creativeId));
        }
        return SingleResponse.of(creativePageViewDTO);
    }

    private void fillTemplateInfo(ServiceContext context, CreativeViewDTO dbCreativeViewDTO, CreativePageViewDTO creativePageViewDTO) {
        //查询创意关联模板(包含子创意)
        Set<Long> templateIds = Sets.newHashSet(dbCreativeViewDTO.getCreativeTemplate().getSspTemplateId());
        if(CollectionUtils.isNotEmpty(dbCreativeViewDTO.getSubCreativeViewDTOList())){
            dbCreativeViewDTO.getSubCreativeViewDTOList().forEach(subCreativeViewDTO -> {
                templateIds.add(subCreativeViewDTO.getCreativeTemplate().getSspTemplateId());
            });
        }
        List<TemplateViewDTO> templateList = creativeTemplateRepository.getTemplateByIds(context, Lists.newArrayList(templateIds));
        Map<Long, TemplateViewDTO> templateViewDTOMap = Optional.ofNullable(templateList).orElse(Lists.newArrayList()).stream()
                .collect(Collectors.toMap(TemplateViewDTO::getId, Function.identity()));
        TemplateViewDTO templateViewDTO = templateViewDTOMap.getOrDefault(dbCreativeViewDTO.getCreativeTemplate().getSspTemplateId(), new TemplateViewDTO());
        creativePageViewDTO.getCreativeAudit().setNeedApproval(templateViewDTO.getNeedApproval());
    }

    @Override
    public SingleResponse<CreativeViewDTO> getCreativeViewDTOById(ServiceContext context, Long creativeId) {
        CreativeViewDTO dbCreativeViewDTO = creativeRepository.getCreativeById(context, creativeId);
        if(dbCreativeViewDTO == null){
            return SingleResponse.of(null);
        }
        // 子创意组装
        if (BrandCreativePackageTypeEnum.PACKAGE.getValue().equals(dbCreativeViewDTO.getPackageType())) {
            Map<Long, List<CreativeViewDTO>> parentCreativeMap = buildSubCreativeViewDTO(context, Lists.newArrayList(dbCreativeViewDTO), null);
            dbCreativeViewDTO.setSubCreativeViewDTOList(parentCreativeMap.get(creativeId));
        }
        return SingleResponse.of(dbCreativeViewDTO);
    }

    @Override
    public MultiResponse<CreativePageViewDTO> findCreativeByIdList(ServiceContext serviceContext, List<Long> idList) {
        List<CreativeViewDTO> dbCreativeViewDTOList = creativeRepository.findCreativeByIds(serviceContext, idList);
        if (CollectionUtils.isEmpty(dbCreativeViewDTOList)) {
            return MultiResponse.empty();
        }
        List<CreativePageViewDTO> creativePageViewDTOList = creativeViewConverter.convertDTO2ViewDTOList(dbCreativeViewDTOList);
        fillPageInfo(serviceContext, creativePageViewDTOList);
        return MultiResponse.of(creativePageViewDTOList);
    }

    @Override
    public MultiResponse<CreativeRefViewDTO> findCreativeRefList(ServiceContext context, CreativeQueryViewDTO queryViewDTO) {
        List<CreativeRefViewDTO> creativeRefViewDTOList = creativeRepository.findCreativeRefList(context, queryViewDTO);
        return MultiResponse.of(creativeRefViewDTOList);
    }

    @Override
    public Response compareProtocol(ServiceContext context, DRCMessageViewDTO drcMessageViewDTO) {
        return Response.success();
    }

    @Override
    public MultiResponse<CreativeViewDTO> convertCreative(ServiceContext context, CreativeSaveViewDTO creativeSaveViewDTO) {
        List<CreativeViewDTO> creativeViewDTOList = bizCreativeCommandWorkflow.convertCreative(context, creativeSaveViewDTO);
        return MultiResponse.of(creativeViewDTOList);
    }

    @Override
    public MultiResponse<ExportMonitorCodeViewDTO> getContentVersionById(ServiceContext context, MonitorCodeQueryViewDTO queryViewDTO) {
        //对id解密
        String decryptAdgroupId = SignatureUtils.decryptAes128EcbSafeBase64String(queryViewDTO.getA());
        String decryptVersionId = SignatureUtils.decryptAes128EcbSafeBase64String(queryViewDTO.getV());
        String decryptMemberId = SignatureUtils.decryptAes128EcbSafeBase64String(queryViewDTO.getM());
        String decryptSalt = SignatureUtils.getMD5((SignatureUtils.salt + decryptAdgroupId + decryptVersionId + decryptMemberId).getBytes());
        String decryptSubCampaignId = SignatureUtils.decryptAes128EcbSafeBase64String(queryViewDTO.getC());

        //校验id是否被篡改
        AssertUtil.assertTrue(decryptMemberId != null, "链接对应member不存在");
        AssertUtil.assertTrue(decryptVersionId != null, "链接对应version不存在");
        AssertUtil.assertTrue(decryptSalt.equals(queryViewDTO.getS()), "请检查点击链接");

        //构造context
        context = ServiceContextUtil.buildServiceContextForBizCode(Long.parseLong(decryptMemberId), queryViewDTO.getBizCode());

        ContentVersionViewDTO contentVersionViewDTO = creativeRepository.getContentVersionById(context, Long.valueOf(decryptVersionId));
        if (StringUtils.isBlank(contentVersionViewDTO.getContent())) {
            return MultiResponse.empty();
        }
        List<ExportMonitorCodeViewDTO> exportMonitorCodeViewDTOList = JSONObject.parseArray(contentVersionViewDTO.getContent(), ExportMonitorCodeViewDTO.class);
        exportMonitorCodeViewDTOList.forEach(exportMonitorCodeViewDTO -> exportMonitorCodeViewDTO.setLandingPage(exportMonitorCodeViewDTO.getLandingUrl()));

        //过滤子计划关联的数据
        if (StringUtils.isNotBlank(decryptSubCampaignId)) {
            exportMonitorCodeViewDTOList = exportMonitorCodeViewDTOList.stream()
                    .filter(monitorCodeViewDTO -> Objects.nonNull(monitorCodeViewDTO.getSubCampaignId()))
                    .filter(monitorCodeViewDTO -> Objects.equals(monitorCodeViewDTO.getSubCampaignId().toString(), decryptSubCampaignId))
                    .collect(Collectors.toList());
        }
        return MultiResponse.of(exportMonitorCodeViewDTOList);
    }

    @Override
    public MultiResponse<ReportTaskViewDTO> findBatchImportTaskList(ServiceContext context, CreativeQueryViewDTO query) {
        AssertUtil.notNull(query);

        ReportTaskQueryViewDTO reportTaskQueryViewDTO = buildReportTaskQueryViewDTO(context, query);
        List<ReportTaskViewDTO> result = reportSyncTaskRepository.queryList(context, reportTaskQueryViewDTO);
        return MultiResponse.of(result);
    }

    @Override
    public SingleResponse<Long> getItemById(ServiceContext context, List<Long> itemIds) {
       // feedRepository.getPicByItemIds(context, itemIds);
        return SingleResponse.of(0l);
    }

    @Override
    public MultiResponse<CreativeScoreResultViewDTO> predictCreativeScore(ServiceContext context, List<CreativeScoreUnitViewDTO> creativeScoreUnitViewDTOList) {
        // 获取创意
        List<Long> creativeIds = creativeScoreUnitViewDTOList.stream().map(CreativeScoreUnitViewDTO::getCreativeId).collect(Collectors.toList());
        List<CreativeViewDTO> creativeViewDTOList = creativeRepository.findCreativeByIds(context, creativeIds);
        Map<Long, CreativeViewDTO> mapCreative = creativeViewDTOList.stream().collect(Collectors.toMap(CreativeViewDTO::getId, creativeViewDTO -> creativeViewDTO));
        // 获取创意模板
        List<Long> sspTemplateIds = creativeViewDTOList.stream().map(CreativeViewDTO::getCreativeTemplate).map(CreativeTemplateViewDTO::getSspTemplateId).distinct().collect(Collectors.toList());
        List<TemplateViewDTO> creativeTemplates = creativeTemplateRepository.getTemplateByIds(context, sspTemplateIds);
        Map<Long, TemplateViewDTO> mapTemplate = creativeTemplates.stream().collect(Collectors.toMap(TemplateViewDTO::getId, templateViewDTO -> templateViewDTO));

        for (CreativeScoreUnitViewDTO scoreUnit : creativeScoreUnitViewDTOList) {
            CreativeViewDTO creativeViewDTO = mapCreative.get(scoreUnit.getCreativeId());
            if (CollectionUtils.isEmpty(scoreUnit.getCrowdIds())) {
                // 查询单元绑定人群，无单元信息查询计划绑定人群，否则人群为空
                if (Objects.nonNull(scoreUnit.getAdgroupId())) {
                    AdgroupViewDTO adgroupViewDTO = adgroupRepository.getAdgroupById(context, scoreUnit.getAdgroupId());
                    scoreUnit.setCrowdIds(adgroupViewDTO.getAdgroupCrowdScenarioViewDTO().getAdgroupCrowdViewDTOList().stream().map(CrowdBaseViewDTO::getCrowdId).collect(Collectors.toList()));
                }
                if (CollectionUtils.isEmpty(scoreUnit.getCrowdIds()) && Objects.nonNull(scoreUnit.getCampaignId())) {
                    Long campaignId = scoreUnit.getCampaignId();
                    CampaignViewDTO campaignViewDTO = campaignRepository.getCampaignTarget(context, Lists.newArrayList(campaignId)).get(campaignId);
                    scoreUnit.setCrowdIds(Optional.ofNullable(campaignViewDTO)
                            .map(CampaignViewDTO::getCampaignCrowdScenarioViewDTO)
                            .map(CampaignCrowdScenarioViewDTO::getCampaignCrowdViewDTOList).orElse(Lists.newArrayList())
                            .stream().map(CrowdBaseViewDTO::getCrowdId).collect(Collectors.toList()));
                }
            }
            // 设置模板名称
            scoreUnit.setCreativeTemplateName(mapTemplate.get(creativeViewDTO.getCreativeTemplate().getSspTemplateId()).getName());
            // 设置创意图片url
            // 先通过elementKey获取创意图片，三环创意对应的elementKey为img_url，特秀创意对应act_pic
            ElementViewDTO elementViewDTO = creativeViewDTO.getElementList().stream()
                    .filter(element -> TemplateConstant.IMG_URL.equals(element.getElementKey()) || TemplateConstant.ACT_PIC.equals(element.getElementKey()))
                    .findAny().orElse(null);
            // 少量创意对应其他elementKey，则通过elementType获取创意图片
            if (Objects.isNull(elementViewDTO)) {
                elementViewDTO = creativeViewDTO.getElementList().stream().filter(element -> BrandCreativeElementTypeEnum.IMAGE.getCode().equals(element.getElementType())).findAny().orElse(null);
            }
            AssertUtil.notNull(elementViewDTO, "创意图片不能为空");
            String creativeImageUrl = elementViewDTO.getElementValue().replaceAll("\\?.*", "");
            scoreUnit.setCreativeImageUrl(creativeImageUrl);
            // 设置uniqueKey
            scoreUnit.setUniqueKey(String.valueOf(scoreUnit.hashCode()));
        }
        RogerLogger.info("creativeScoreUnitViewDTOList: {}", creativeScoreUnitViewDTOList);
        AICreativePredictResponse response = dmpArgusRepository.predictCreativeScore(context, creativeScoreUnitViewDTOList);
        List<CreativeScore> creativeScoreList = response.getCreativeScoreList();

        Map<String, CreativeScoreUnitViewDTO> scoreUnitMap = creativeScoreUnitViewDTOList.stream().collect(Collectors.toMap(CreativeScoreUnitViewDTO::getUniqueKey, scoreUnit -> scoreUnit));
        List<CreativeScoreResultViewDTO> result = Lists.newArrayList();
        creativeScoreList.forEach(creativeScore -> {
            AssertUtil.assertTrue(scoreUnitMap.containsKey(creativeScore.getUniqueKey()), "打分结果对应未知的打分单元");
            CreativeScoreUnitViewDTO scoreUnitViewDTO = scoreUnitMap.get(creativeScore.getUniqueKey());
            CreativeScoreResultViewDTO scoreResultViewDTO = new CreativeScoreResultViewDTO();
            scoreResultViewDTO.setCreativeId(scoreUnitViewDTO.getCreativeId());
            scoreResultViewDTO.setAdgroupId(scoreUnitViewDTO.getAdgroupId());
            scoreResultViewDTO.setScore(creativeScore.getScore());
            result.add(scoreResultViewDTO);
        });
        return MultiResponse.of(result);
    }


    private ReportTaskQueryViewDTO buildReportTaskQueryViewDTO(ServiceContext context, CreativeQueryViewDTO query) {
        ReportTaskQueryViewDTO queryViewDTO = new ReportTaskQueryViewDTO();
        queryViewDTO.setMemberId(context.getMemberId());
        if(Objects.nonNull(query.getCampaignGroupId())) {
            queryViewDTO.setCampaignGroupId(query.getCampaignGroupId());
        }
        if(CollectionUtils.isNotEmpty(query.getCampaignIds())) {
            queryViewDTO.setCampaignId(query.getCampaignIds().get(0));
        }
        if(CollectionUtils.isNotEmpty(query.getAdgroupIds())) {
            queryViewDTO.setAdgroupId(query.getAdgroupIds().get(0));
        }
        // 异步任务类型
        queryViewDTO.setFunctionCode("creativeBatchUpdate");
        return queryViewDTO;
    }

    private Map<Long, List<CreativePageViewDTO>> build(ServiceContext context, List<CreativePageViewDTO> creativePageViewDTOList,
                                                       Integer isRequired, Integer needSubCreative) {
        CreativeQueryViewDTO queryViewDTO = new CreativeQueryViewDTO();
        queryViewDTO.setCreativeIdEqCreativePackageId(Boolean.FALSE);
        queryViewDTO.setPackageType(BrandCreativePackageTypeEnum.COMMON.getValue());
        queryViewDTO.setPageSize(MAX_PAGE_COUNT);
        //过滤掉智能创意下的子创意，分页查询过滤，单个查询不过滤
        List<Long> creativePackageIdList = creativePageViewDTOList.stream()
                .filter(creativePageViewDTO -> BrandBoolEnum.BRAND_TRUE.getCode().equals(needSubCreative)
                        || !isNormalSmart(creativePageViewDTO))
                .map(CreativePageViewDTO::getId).collect(Collectors.toList());
        if(CollectionUtils.isEmpty(creativePackageIdList)){
            return Maps.newHashMap();
        }
        queryViewDTO.setCreativePackageIdList(creativePackageIdList);
        List<CreativeViewDTO> list = creativeRepository.findListWithPage(context, queryViewDTO).getList();
        if (CollectionUtils.isNotEmpty(list)) {
            //前端传值和后端数据存储值刚好相反，@非池 后续统一处理
            if (BrandBoolEnum.BRAND_FALSE.getCode().equals(isRequired)) {
                list = list.stream().filter(creativeViewDTO -> BrandBoolEnum.BRAND_TRUE.getCode().equals(creativeViewDTO.getIsRequired()))
                        .collect(Collectors.toList());
            }
        }
        if (CollectionUtils.isEmpty(list)) {
            return Maps.newHashMap();
        }
        List<CreativePageViewDTO> creativePageViewDTOS = creativeViewConverter.convertDTO2ViewDTOList(list);
        fillPageInfo(context, creativePageViewDTOS);
        return creativePageViewDTOS.stream().collect(Collectors.groupingBy(CreativePageViewDTO::getCreativePackageId));
    }

    private boolean isNormalSmart(CreativePageViewDTO creativePageViewDTO) {
        return BrandCreativeSourceEnum.SMART_CREATIVE.getCode().equals(creativePageViewDTO.getCreativeSource()) &&
                Objects.nonNull(creativePageViewDTO.getCreativeMalus()) && BrandCreativeTemplateDataSourceEnum.MALUS.getCode().equals(creativePageViewDTO.getCreativeMalus().getTemplateDataSource());
    }

    private Map<Long, List<CreativeViewDTO>> buildSubCreativeViewDTO(ServiceContext context, List<CreativeViewDTO> creativeViewDTOList, Integer isRequired) {
        CreativeQueryViewDTO queryViewDTO = new CreativeQueryViewDTO();
        queryViewDTO.setCreativeIdEqCreativePackageId(Boolean.FALSE);
        queryViewDTO.setPackageType(BrandCreativePackageTypeEnum.COMMON.getValue());
        queryViewDTO.setPageSize(MAX_PAGE_COUNT);
        queryViewDTO.setCreativePackageIdList(creativeViewDTOList.stream().map(CreativeViewDTO::getId).collect(Collectors.toList()));
        List<CreativeViewDTO> list = creativeRepository.findListWithPage(context, queryViewDTO).getList();
        if(CollectionUtils.isNotEmpty(list)){
            //前端传值和后端数据存储值刚好相反，@非池 后续统一处理
            if(BrandBoolEnum.BRAND_FALSE.getCode().equals(isRequired)){
                list = list.stream().filter(creativeViewDTO -> BrandBoolEnum.BRAND_TRUE.getCode().equals(creativeViewDTO.getIsRequired()))
                        .collect(Collectors.toList());
            }
        }
        if (CollectionUtils.isEmpty(list)) {
            return Maps.newHashMap();
        }
        return list.stream().collect(Collectors.groupingBy(CreativeViewDTO::getCreativePackageId));
    }

    /**
     * 填充智能创意子创意媒体拒绝数量
     * @param serviceContext
     * @param creativePageViewDTOList
     */
    private void fillSubCreativeMediaAuditRefuseCount(ServiceContext serviceContext,List<CreativePageViewDTO> creativePageViewDTOList){
        List<Integer> needQueryMediaAuditStatus = Lists.newArrayList(BrandCreativeShowAuditStatusEnum.CREATIVE_MEDIA_AUDIT_UNABLE.getCode(),
                BrandCreativeShowAuditStatusEnum.CREATIVE_MEDIA_AUDIT_WAITING.getCode(), BrandCreativeShowAuditStatusEnum.CREATIVE_MEDIA_AUDIT_REFUSE.getCode(), BrandCreativeShowAuditStatusEnum.AUDIT_PASS.getCode());

        List<Long> creativePackageIdList = creativePageViewDTOList.stream().filter(creativeVO -> BrandCreativeSourceEnum.SMART_CREATIVE.getCode().equals(creativeVO.getCreativeSource())
                        && BrandCreativePackageTypeEnum.PACKAGE.getValue().equals(creativeVO.getPackageType()))
                .filter(creativeVO -> creativeVO.getCreativeAudit() != null && needQueryMediaAuditStatus.contains(creativeVO.getCreativeAudit().getShowAuditStatus()))
                .map(CreativePageViewDTO::getId).collect(Collectors.toList());
        if(CollectionUtils.isEmpty(creativePackageIdList)){
            return;
        }
        CreativeQueryViewDTO queryViewDTO = new CreativeQueryViewDTO();
        queryViewDTO.setCreativeIdEqCreativePackageId(Boolean.FALSE);
        queryViewDTO.setPackageType(BrandCreativePackageTypeEnum.COMMON.getValue());
        queryViewDTO.setPageSize(MAX_PAGE_COUNT);
        queryViewDTO.setCreativePackageIdList(creativePackageIdList);
        queryViewDTO.setShowAuditStatusList(Lists.newArrayList(BrandCreativeShowAuditStatusEnum.CREATIVE_CENTER_REFUSE.getCode(),
                BrandCreativeShowAuditStatusEnum.CREATIVE_MEDIA_AUDIT_REFUSE.getCode()));
        List<CreativeViewDTO> subCreativeList = creativeRepository.findListWithPage(serviceContext, queryViewDTO).getList();
        if(CollectionUtils.isEmpty(subCreativeList)){
            return;
        }
        Map<Long, List<CreativeViewDTO>> creativePackageAuditRefuseCountMap = subCreativeList.stream().collect(Collectors.groupingBy(CreativeViewDTO::getCreativePackageId));
        for (CreativePageViewDTO creativePageViewDTO : creativePageViewDTOList) {
            List<CreativeViewDTO> auditRefuseSubCreativeList = creativePackageAuditRefuseCountMap.getOrDefault(creativePageViewDTO.getId(), Lists.newArrayList());
            Map<Integer, Long> showAuditStatusCountMap = auditRefuseSubCreativeList.stream()
                    .collect(Collectors.groupingBy(subCreative -> subCreative.getCreativeAudit().getShowAuditStatus(), Collectors.counting()));
            Long creativeMamaAuditRefuseCount = showAuditStatusCountMap.getOrDefault(BrandCreativeShowAuditStatusEnum.CREATIVE_CENTER_REFUSE.getCode(), 0L);
            Long creativeMediaAuditRefuseCount = showAuditStatusCountMap.getOrDefault(BrandCreativeShowAuditStatusEnum.CREATIVE_MEDIA_AUDIT_REFUSE.getCode(), 0L);
            creativePageViewDTO.getCreativeAudit().setCreativeMamaAuditRefuseCount(creativeMamaAuditRefuseCount.intValue());
            creativePageViewDTO.getCreativeAudit().setCreativeMediaAuditRefuseCount(creativeMediaAuditRefuseCount.intValue());
        }
    }

    private void fillPageInfo(ServiceContext serviceContext, List<CreativePageViewDTO> creativePageViewDTOList) {
        if (CollectionUtils.isNotEmpty(creativePageViewDTOList)) {
            //东海创意
            List<Long> mediaIds = new ArrayList<>();
            creativePageViewDTOList.stream().filter(creativePageViewDTO -> creativePageViewDTO.getCreativeAudit() != null &&
                    creativePageViewDTO.getCreativeAudit().getMediaAudit() != null).forEach(creativePageViewDTO -> {
                MediaAuditPageViewDTO mediaAudit = creativePageViewDTO.getCreativeAudit().getMediaAudit();
                if (Objects.nonNull(mediaAudit.getAuditData())) {
                    JSONObject jsonObject = JSON.parseObject(mediaAudit.getAuditData());
                    if (null != jsonObject) {
                        String mediaIdStr = String.valueOf(jsonObject.getOrDefault(MEDIA_ID, ""));
                        if (org.apache.commons.lang.StringUtils.isNotBlank(mediaIdStr)) {
                            Long mediaId = Long.valueOf(mediaIdStr);
                            mediaIds.add(mediaId);
                        }
                        String mediaIdListStr = String.valueOf(jsonObject.getOrDefault(MEDIA_ID_LIST, ""));
                        if (org.apache.commons.lang.StringUtils.isNotBlank(mediaIdListStr)) {
                            List<Long> mediaIdList = Arrays.stream(mediaIdListStr.split(",")).map(Long::valueOf).collect(Collectors.toList());
                            mediaIds.addAll(mediaIdList);
                        }
                    }
                }
            });
            if (CollectionUtils.isNotEmpty(mediaIds)) {
                Map<Long, String> mediaNameMap = mediaRepository.queryMediaListByMediaIds(mediaIds).stream().collect(Collectors.toMap(MediaViewDTO::getId, MediaViewDTO::getMediaName, (v1, v2) -> v2));
                creativePageViewDTOList.stream().filter(creativePageViewDTO -> creativePageViewDTO.getCreativeAudit() != null &&
                        creativePageViewDTO.getCreativeAudit().getMediaAudit() != null && creativePageViewDTO.getCreativeAudit().getMediaAudit().getAuditData() != null).forEach(creativePageViewDTO -> {
                    MediaAuditPageViewDTO mediaAudit = creativePageViewDTO.getCreativeAudit().getMediaAudit();
                    JSONObject jsonObject = JSON.parseObject(mediaAudit.getAuditData());
                    if (null != jsonObject) {
                        //兼容历史创意
                        String mediaIdStr = String.valueOf(jsonObject.getOrDefault(MEDIA_ID, ""));
                        if (org.apache.commons.lang.StringUtils.isNotBlank(mediaIdStr)) {
                            mediaAudit.setMediaName(mediaNameMap.get(Long.valueOf(mediaIdStr)));
                        }
                        String mediaIdListStr = String.valueOf(jsonObject.getOrDefault(MEDIA_ID_LIST, ""));
                        if (org.apache.commons.lang.StringUtils.isNotBlank(mediaIdListStr)) {
                            List<String> mediaNameList = Arrays.stream(mediaIdListStr.split(",")).map(Long::valueOf).distinct().map(mediaNameMap::get).collect(Collectors.toList());
                            mediaAudit.setMediaName(StringUtils.join(mediaNameList, ","));
                        }
                    }
                });
            }

            List<Long> tagIds = creativePageViewDTOList.stream().map(CreativePageViewDTO::getCreativeTagId).distinct().collect(Collectors.toList());
            Map<Long, String> tagMap = Maps.newHashMap();
            if (CollectionUtils.isNotEmpty(tagIds)) {
                List<TagViewDTO> creativeTagByIds = tagRepository.findTagByIds(serviceContext, tagIds);
                tagMap = creativeTagByIds.stream().collect(Collectors.toMap(TagViewDTO::getId, TagViewDTO::getTagName, (v1, v2) -> v2));
            }

            //模版数据
            List<Long> sspTemplateIds = creativePageViewDTOList.stream().map(CreativePageViewDTO::getSspTemplateId).distinct().collect(Collectors.toList());
            CreativeTemplateQueryDTO creativeTemplateQueryDTO = new CreativeTemplateQueryDTO();
            creativeTemplateQueryDTO.setNeedTag(true);
            creativeTemplateQueryDTO.setNeedSetting(true);
            creativeTemplateQueryDTO.setNeedAssociation(true);
            creativeTemplateQueryDTO.setTemplateIdList(sspTemplateIds);
            List<TemplateViewDTO> creativeTemplates = creativeTemplateRepository.getTemplateList(serviceContext, creativeTemplateQueryDTO);
            Map<Long, TemplateViewDTO> mapTemplate = creativeTemplates.stream().collect(Collectors.toMap(TemplateViewDTO::getId, Function.identity(), (v1, v2) -> v2));

            //资源类型数据
            Map<String, String> mapResource = productRepository.getSSPDict(BrandDicTypeEnum.RESOURCE_TYPE.getType()).stream().collect(Collectors.toMap(CommonViewDTO::getValue, CommonViewDTO::getName, (v1, v2) -> v2));

            //单元数据
            List<Long> creativeIds = creativePageViewDTOList.stream().map(CreativePageViewDTO::getId).collect(Collectors.toList());
            CreativeQueryViewDTO tmpCreativeQueryDTO = new CreativeQueryViewDTO();
            tmpCreativeQueryDTO.setIds(creativeIds);
            Map<Long, List<CreativeRefViewDTO>> mapCreativeRef = creativeRepository.findCreativeRefList(serviceContext, tmpCreativeQueryDTO).stream().collect(Collectors.groupingBy(CreativeRefViewDTO::getCreativeId));

            //单元所属计划数据
            Map<Long, Integer> campaignSceneMap;
            if (!mapCreativeRef.isEmpty()) {
                List<Long> campaignIds = mapCreativeRef.entrySet().stream().flatMap(item -> item.getValue().stream().map(CreativeRefViewDTO::getCampaignId)).collect(Collectors.toList());
                CampaignQueryViewDTO query = new CampaignQueryViewDTO();
                query.setCampaignIds(campaignIds);
                campaignSceneMap = campaignRepository.queryCampaignList(serviceContext, query)
                        .stream().collect(Collectors.toMap(it -> it.getId(), it -> it.getSceneId(), (v1, v2) -> v2));
            } else {
                campaignSceneMap = Maps.newHashMap();
            }

            List<Long> adgroupIds = mapCreativeRef.entrySet().stream().flatMap(item -> item.getValue().stream().map(CreativeRefViewDTO::getAdgroupId)).collect(Collectors.toList());
            Map<Long, AdgroupViewDTO> mapAdgroup = Maps.newHashMap();
            if (CollectionUtils.isNotEmpty(adgroupIds)) {
                AdgroupQueryViewDTO adgroupQueryViewDTO = new AdgroupQueryViewDTO();
                adgroupQueryViewDTO.setIds(adgroupIds);
                List<AdgroupViewDTO> adgroupViewDTOList = adgroupRepository.queryAdgroupListNoPage(serviceContext, adgroupQueryViewDTO);
                mapAdgroup = adgroupViewDTOList.stream().collect(Collectors.toMap(AdgroupViewDTO::getId, Function.identity(), (v1, v2) -> v2));
            }
            Map<Long, AdgroupViewDTO> finalMapAdgroup = mapAdgroup;
            for (CreativePageViewDTO creativePageViewDTO : creativePageViewDTOList){
                if (Objects.nonNull(mapTemplate.get(creativePageViewDTO.getSspTemplateId()))) {
                    creativePageViewDTO.setSspTemplateName(mapTemplate.get(creativePageViewDTO.getSspTemplateId()).getName());
                    creativePageViewDTO.setSspTemplateSize(mapTemplate.get(creativePageViewDTO.getSspTemplateId()).getTemplateSize());
                    creativePageViewDTO.setTagList(mapTemplate.get(creativePageViewDTO.getSspTemplateId()).getTagList());
                }
                if (Objects.nonNull(creativePageViewDTO.getSspResourceType())) {
                    creativePageViewDTO.setSspResourceTypeDesc(mapResource.get(creativePageViewDTO.getSspResourceType().toString()));
                }
                if (Objects.nonNull(creativePageViewDTO.getTargetType())) {
                    BrandCreativeTargetTypeEnum targetTypeEnum = BrandCreativeTargetTypeEnum.getByCode(creativePageViewDTO.getTargetType());
                    creativePageViewDTO.setTargetTypeDesc(targetTypeEnum != null ? targetTypeEnum.getDesc() : null);
                }
                if (Objects.nonNull(creativePageViewDTO.getCreativeTagId())) {
                    creativePageViewDTO.setCreativeTagName(tagMap.get(creativePageViewDTO.getCreativeTagId()));
                }
                if (CollectionUtils.isNotEmpty(mapCreativeRef.get(creativePageViewDTO.getId()))) {
                    //后续需要将这个字段去掉
                    creativePageViewDTO.setAdgroupList(mapCreativeRef.get(creativePageViewDTO.getId()).stream().map(item -> {
                        if (finalMapAdgroup.containsKey(item.getAdgroupId())) {
                            CommonViewDTO commonVO = new CommonViewDTO();
                            commonVO.setId(item.getAdgroupId());
                            commonVO.setName(finalMapAdgroup.get(item.getAdgroupId()).getTitle());
                            return commonVO;
                        } else {
                            return null;
                        }
                    }).filter(Objects::nonNull).collect(Collectors.toList()));
                    creativePageViewDTO.setCreativeRefList(mapCreativeRef.get(creativePageViewDTO.getId()).stream().map(creativeRefViewDTO -> {
                        CreativeRefPageViewDTO creativeRefPageViewDTO = BeanUtils.copyIgnoreNull(creativeRefViewDTO, new CreativeRefPageViewDTO());
                        if(Objects.nonNull(finalMapAdgroup.get(creativeRefPageViewDTO.getAdgroupId()))){
                            creativeRefPageViewDTO.setAdgroupName(finalMapAdgroup.get(creativeRefPageViewDTO.getAdgroupId()).getTitle());
                        }
                        creativeRefPageViewDTO.setCreativeName(creativePageViewDTO.getName());
                        creativeRefPageViewDTO.setSceneId(campaignSceneMap.get(creativeRefViewDTO.getCampaignId()));
                        return creativeRefPageViewDTO;
                    }).collect(Collectors.toList()));
                }

                if (BrandCreativePackageTypeEnum.PACKAGE.getValue().equals(creativePageViewDTO.getPackageType()) &&
                        BrandCreativeSourceEnum.SMART_CREATIVE.getCode().equals(creativePageViewDTO.getCreativeSource()) &&
                        Objects.nonNull(creativePageViewDTO.getCreativeMalus()) &&
                        BrandCreativeTemplateDataSourceEnum.BRAND.getCode().equals(creativePageViewDTO.getCreativeMalus().getTemplateDataSource())) {
                    JSONObject templateData = JSON.parseObject(creativePageViewDTO.getCreativeMalus().getTemplateData());
                    Map<String, Map<String, Object>> bizMap = (Map<String, Map<String, Object>>) templateData.get(TemplateConstant.CONSTANT_KEY_BIZ_MAP);
                    List<String> visualImages = bizMap.entrySet().stream().filter(entry -> {
                        String key = entry.getKey();
                        Map<String, Object> elementMap = bizMap.get(key);
                        if (elementMap == null) {
                            return false;
                        }
                        String typeStr = (String) elementMap.get(TemplateConstant.CONSTANT_KEY_TYPE);
                        return ElementTypeEnum.VISUAL_IMAGE_EXTEND.getCode().equals(typeStr);
                    }).map(Map.Entry::getKey).filter(key -> templateData.containsKey(key)).flatMap(key ->
                    {
                        JSONObject visualImageJson = (JSONObject) templateData.get(key);
                        List<CreativeMalusTemplateConvergeElementViewDTO> creativeMalusTemplateConvergeElementViewDTOS = JSON.parseArray(JSON.toJSONString(visualImageJson.get(TemplateConstant.VISUAL_IMAGES)), CreativeMalusTemplateConvergeElementViewDTO.class);
                        return creativeMalusTemplateConvergeElementViewDTOS.stream();
                    }).flatMap(creativeMalusTemplateConvergeElementViewDTO ->
                            creativeMalusTemplateConvergeElementViewDTO.getExtendImages().stream()).map(CreativeMalusTemplateFileElementViewDTO::getUrl).collect(Collectors.toList());
                    creativePageViewDTO.setVisualImages(visualImages);
                }
            }
        }
    }

    /**
     * drc消息校验
     *
     * @param drcMessageDTO
     */
    private void drcMessageCheck(DRCMessageViewDTO drcMessageDTO) {
        Assert.notNull(drcMessageDTO, "DRC消息体不能为空");
        Assert.isTrue(StringUtils.isNotBlank(drcMessageDTO.getDbName()), "DRC消息体dbName不能为空");
        Assert.isTrue(StringUtils.isNotBlank(drcMessageDTO.getOpType()), "DRC消息体opType不能为空");
        Assert.isTrue(StringUtils.isNotBlank(drcMessageDTO.getTableName()), "DRC消息体tableName不能为空");
    }
}
