package com.taobao.ad.brand.bp.app.service.common;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.api.common.OssFileQueryService;
import com.taobao.ad.brand.bp.domain.oss.OssRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author ximu
 * @date 2023/8/23
 */
@HSFProvider(serviceInterface = OssFileQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class OssFileQueryServiceImpl implements OssFileQueryService {

    private final OssRepository ossRepository;

    @Override
    public SingleResponse<String> getTempOssDownloadUrl(ServiceContext serviceContext, String ossPath) {
        return SingleResponse.of(ossRepository.getTemporaryDownloadUrl(ossPath));
    }
}
