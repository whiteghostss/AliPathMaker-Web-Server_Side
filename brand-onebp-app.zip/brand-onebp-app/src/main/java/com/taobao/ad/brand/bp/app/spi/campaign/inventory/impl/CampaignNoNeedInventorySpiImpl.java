package com.taobao.ad.brand.bp.app.spi.campaign.inventory.impl;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.nb.framework.core.annotation.AbilitySpiInstance;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alibaba.fastjson.JSONObject;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.app.spi.campaign.inventory.BizCampaignInventorySpi;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignInventoryWorkflow;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignInquiryOperateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignScheduleViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignScheduleOperateTypeEnum;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.threadpooltask.CampaignUnProgrammaticScheduleUpdateTaskIdentifier;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.inventory.ICampaignNoInventoryScheduleResultSetForCampaignInventoryOperateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.inventory.ICampaignScheduleUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.inventory.ICampaignStopForInventoryReleaseAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignNoInventoryScheduleResultSetAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignScheduleUpdateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignStopForInventoryReleaseAbilityParam;
import org.apache.commons.collections.CollectionUtils;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

@AbilitySpiInstance(bizCodes = {BizCampaignInventorySpi.NO_INVENTORY}, name = "campaignNoNeedInventorySpiImpl", desc = "无需库存询量/锁量实现")
public class CampaignNoNeedInventorySpiImpl extends DefaultBizCampaignInventorySpiImpl {
    @Resource
    private ICampaignNoInventoryScheduleResultSetForCampaignInventoryOperateAbility campaignNoInventoryScheduleResultSetForCampaignInventoryOperateAbility;
    @Resource
    private ICampaignScheduleUpdateAbility campaignScheduleUpdateAbility;
    @Resource
    private BizCampaignInventoryWorkflow bizCampaignInventoryWorkflow;
    @Resource
    private ICampaignStopForInventoryReleaseAbility campaignStopForInventoryReleaseAbility;
    @Resource
    private CampaignUnProgrammaticScheduleUpdateTaskIdentifier campaignUnProgrammaticScheduleUpdateTaskIdentifier;

//    private static final ThreadPoolExecutor THREAD_POOL = new ThreadPoolExecutor(
//            20, 20, 60L, TimeUnit.SECONDS, new ArrayBlockingQueue<>(2048),
//            new ThreadFactoryBuilder().setNameFormat("biz_campaign_noNeedInventory_ability-%d").build());

    @Override
    public Void inventoryRequest(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO, List<CampaignViewDTO> campaignTreeViewDTOList, List<CampaignScheduleViewDTO> campaignScheduleViewDTOList) {
//        bizCampaignScheduleAbility.batchUpdateUnProgrammaticScheduleResult(serviceContext,campaignTreeViewDTOList, inquiryOperateViewDTO.getOperateType());
//        bizCampaignInventoryAbility.updateCampaignInquiry(serviceContext, campaignScheduleViewDTOList);
        batchUpdateUnProgrammaticScheduleResult(serviceContext,campaignTreeViewDTOList,inquiryOperateViewDTO);
        bizCampaignInventoryWorkflow.updateInventoryOperateCampaignStatus(serviceContext,campaignScheduleViewDTOList);
        return null;
    }

    @Override
    public Void releaseCampaign(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList){
        // 计划暂停
        campaignStopForInventoryReleaseAbility.handle(serviceContext, CampaignStopForInventoryReleaseAbilityParam.builder().abilityTargets(campaignViewDTOList).build());
        //获取需要执行释量的计划
        List<CampaignViewDTO> needReleaseSubCampaignList = getNeedReleaseSubCampaignList(campaignViewDTOList);
        if (CollectionUtils.isNotEmpty(needReleaseSubCampaignList)) {
            RogerLogger.info("need release unProgrammatic list {}", JSONObject.toJSONString(needReleaseSubCampaignList));
            CampaignInquiryOperateViewDTO inquiryOperateViewDTO = new CampaignInquiryOperateViewDTO();
            inquiryOperateViewDTO.setOperateType(CampaignScheduleOperateTypeEnum.RELEASE.getValue());
            batchUpdateUnProgrammaticScheduleResult(serviceContext,campaignViewDTOList,inquiryOperateViewDTO);
        }
        return null;
    }

    /**
     * 获取需要进行释量
     * @param campaignViewDTOList
     * @return
     */
    private List<CampaignViewDTO> getNeedReleaseSubCampaignList(List<CampaignViewDTO> campaignViewDTOList){
        return campaignViewDTOList.stream().filter(campaignViewDTO -> CollectionUtils.isNotEmpty(campaignViewDTO.getSubCampaignViewDTOList()))
                .flatMap(campaignViewDTO -> campaignViewDTO.getSubCampaignViewDTOList().stream())
                .filter(subCampaignViewDTO -> Constant.CAN_RELEASE_STATUS.contains(subCampaignViewDTO.getStatus()))
                .collect(Collectors.toList());
    }

    /**
     * 批量更新非系统投放计划排期信息
     * @param serviceContext
     * @param campaignList
     * @param inquiryOperateViewDTO
     */
    public void batchUpdateUnProgrammaticScheduleResult(ServiceContext serviceContext, List<CampaignViewDTO> campaignList, CampaignInquiryOperateViewDTO inquiryOperateViewDTO) {
        TaskStream.consume(campaignUnProgrammaticScheduleUpdateTaskIdentifier, campaignList, (campaignViewDTO, index) -> {
            //填充计划询锁量结果
            campaignNoInventoryScheduleResultSetForCampaignInventoryOperateAbility.handle(serviceContext,
                    CampaignNoInventoryScheduleResultSetAbilityParam.builder().abilityTarget(inquiryOperateViewDTO).campaignViewDTO(campaignViewDTO).build());
            //更新计划询锁量结果
            campaignScheduleUpdateAbility.handle(serviceContext, CampaignScheduleUpdateAbilityParam.builder().abilityTarget(campaignViewDTO).build());
        }).commit().handle();
    }
}
