package com.taobao.ad.brand.bp.app.handler;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.hermes.framework.ddd.event.annotation.DomainEventHandler;
import com.alibaba.hermes.framework.event.EventHandler;
import com.alibaba.rocketmq.client.exception.MQClientException;
import com.alibaba.rocketmq.client.producer.SendResult;
import com.alibaba.rocketmq.client.producer.SendStatus;
import com.alibaba.rocketmq.common.message.Message;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.github.rholder.retry.*;
import com.taobao.ad.brand.bp.client.context.DomainMetaqMessageBodyContext;
import com.taobao.ad.brand.bp.domain.event.DomainMetaqMessageEvent;
import com.taobao.metaq.client.MetaProducer;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

/**
 * @author ximu
 * @date 2023/7/18
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@DomainEventHandler(topic = "metaq_message_topic", event = DomainMetaqMessageEvent.class)
public class MetaqMessageEventHandler implements EventHandler<DomainMetaqMessageEvent> {

    @Value("${metaq.domain.event.topic:BRAND_ONEBP_DOMAIN_EVENT}")
    private String domainMqTopic;
    @Value("${env}")
    private String env;

    private final MetaProducer producer = new MetaProducer("MQ_GROUP_BRAND_ONE_BP");

    Retryer<SendResult> retryer = RetryerBuilder.<SendResult>newBuilder()
            .retryIfException()
            .retryIfResult(e -> e.getSendStatus() != SendStatus.SEND_OK)
            .withWaitStrategy(WaitStrategies.fixedWait(1, TimeUnit.SECONDS))
            .withStopStrategy(StopStrategies.stopAfterAttempt(3))
            .build();

    @PostConstruct
    public void init() {
        try {
            producer.start();
        } catch (MQClientException e) {
            throw new RuntimeException(e);
        }
    }

    @PreDestroy
    public void destroy() {
        producer.shutdown();
    }

    @Override
    public Response handle(DomainMetaqMessageEvent event) {
        DomainMetaqMessageBodyContext bodyContext = event.getContext();
        bodyContext.setEnv(env);
        String messageKey = getKey(bodyContext.getDomainType().name(), bodyContext.getEntityId(), bodyContext.getDomainEvent());
        Message message = new Message();
        message.setTopic(domainMqTopic);
        message.setTags(bodyContext.getBizCode());
        message.setKeys(messageKey);
        message.setBody(JSON.toJSONBytes(bodyContext));
        try {
            RogerLogger.info("send domain message start：{}", JSONObject.toJSONString(bodyContext));
            SendResult sendResult = retryer.call(() -> producer.send(message));
            RogerLogger.info("send domain message end：messageKey {}, result {}", messageKey, sendResult);
        } catch (ExecutionException | RetryException e) {
            RogerLogger.error("retry send domain message error {}", e.getMessage(), e);
            return Response.failure();
        }
        return Response.success();
    }

    private String getKey(String type, Long entityId, String eventType) {
        return new StringBuilder(type).append("-")
                .append(entityId).append("-")
                .append(eventType).append("-")
                .append(new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date())).toString();
    }
}
