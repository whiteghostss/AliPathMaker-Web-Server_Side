package com.taobao.ad.brand.bp.app.service.motion;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.api.motion.BizIntelligentStrategyQueryService;
import com.taobao.ad.brand.bp.client.dto.motion.IntelligentStrategyViewDTO;
import com.taobao.ad.brand.bp.client.dto.motion.query.StrategyQueryViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.motion.IntelligentStrategyRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/18
 **/
@HSFProvider(serviceInterface = BizIntelligentStrategyQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizIntelligentStrategyQueryServiceImpl implements BizIntelligentStrategyQueryService {
    private final IntelligentStrategyRepository intelligentStrategyRepository;
    @Override
    public SingleResponse<IntelligentStrategyViewDTO> getIntelligentStrategyById(ServiceContext serviceContext, Long strategyId) {
        List<IntelligentStrategyViewDTO> strategyViewDTOList = intelligentStrategyRepository.queryIntelligentStrategyList(serviceContext, StrategyQueryViewDTO.builder().idList(Lists.newArrayList(strategyId)).needProductStrategy(Boolean.TRUE).build());
        AssertUtil.notEmpty(strategyViewDTOList, BrandOneBPBaseErrorCode.BIZ_DATA_EMPTY_ERROR, "策略不存在");
        return SingleResponse.of(strategyViewDTOList.get(0));
    }

    @Override
    public MultiResponse<IntelligentStrategyViewDTO> intelligentStrategyList(ServiceContext serviceContext, StrategyQueryViewDTO queryViewDTO) {
        List<IntelligentStrategyViewDTO> strategyViewDTOList = intelligentStrategyRepository.queryIntelligentStrategyList(serviceContext, queryViewDTO);
        return MultiResponse.of(strategyViewDTOList);
    }
}
