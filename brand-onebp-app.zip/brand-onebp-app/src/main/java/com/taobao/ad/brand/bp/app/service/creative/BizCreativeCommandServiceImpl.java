package com.taobao.ad.brand.bp.app.service.creative;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityInject;
import com.alibaba.abf.isolation.spec.common.ReduceType;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.biz.definition.constants.Product;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.adgroup.CreativeRefViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.brand.dto.creative.element.ElementViewDTO;
import com.alibaba.ad.brand.dto.creative.materialgroup.MaterialGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativeElementTypeEnum;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativePackageTypeEnum;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativeScopeEnum;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativeTargetTypeEnum;
import com.alibaba.ad.nb.ssp.constant.common.BizCodeConstants;
import com.alibaba.ad.nb.ssp.constant.common.MediaScopeEnum;
import com.alibaba.ad.nb.ssp.constant.template.ElementTypeEnum;
import com.alibaba.ad.nb.ssp.constant.template.verification.SizeUnitEnum;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.error.ErrorCodeAware;
import com.alibaba.hermes.framework.tool.lock.annotation.DistLock;
import com.alibaba.hermes.framework.utils.BeanUtils;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignQueryWorkflow;
import com.taobao.ad.brand.bp.app.workflow.creative.BizCreativeCommandWorkflow;
import com.taobao.ad.brand.bp.app.workflow.creative.BizCreativeRefCommandWorkflow;
import com.taobao.ad.brand.bp.app.workflow.tool.BizBatchImportWorkflow;
import com.taobao.ad.brand.bp.app.workflow.tool.BizGenerateImagesWorkflow;
import com.taobao.ad.brand.bp.client.api.creative.BizCreativeCommandService;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryOption;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignTemplateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.creative.*;
import com.taobao.ad.brand.bp.client.dto.creative.crop.MalusCropResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.notice.CreativeAuditSwitchNotifyViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.notice.CreativeRefCallbackNoticeViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.notice.CreativeRejectMsgViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.notice.QualificationPassNotifyViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportTaskViewDTO;
import com.taobao.ad.brand.bp.client.dto.rule.RuleCheckResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.template.TemplateContextViewDTO;
import com.taobao.ad.brand.bp.client.dto.template.TemplateViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.constant.TemplateConstant;
import com.taobao.ad.brand.bp.common.threadpooltask.AdgroupCreativeValidateTaskIdentifier;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.config.AutoTestMemberDiamondConfig;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeRepository;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeTemplateRepository;
import com.taobao.ad.brand.bp.domain.creative.repository.MaterialGroupRepository;
import com.taobao.ad.brand.bp.domain.creative.spi.BizCreativeSpi;
import com.taobao.ad.brand.bp.domain.feed.FeedRepository;
import com.taobao.ad.brand.bp.domain.memeber.MemberRepository;
import com.taobao.ad.brand.bp.domain.report.repository.ReportSyncTaskRepository;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.query.IAdgroupStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.workflow.BizAdgroupCommandWorkflowExt;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.workflow.param.BizAdgroupBindWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.creative.workflow.param.CreativeRefWorkflowParam;
import com.taobao.ad.brand.bp.domain.shield.ShieldAccessRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.*;
import static com.taobao.ad.brand.bp.common.constant.TemplateConstant.CLICK_URL;
import static com.taobao.ad.brand.bp.common.spi.ExtensionPointsFactory.runAbilitySpi;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/3/14 13:27
 * @description ：
 * @modified By：
 */
@HSFProvider(serviceInterface = BizCreativeCommandService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizCreativeCommandServiceImpl implements BizCreativeCommandService {
    private final CreativeRepository creativeRepository;
    private final CreativeTemplateRepository creativeTemplateRepository;
    private final MemberRepository memberRepository;
    private final MaterialGroupRepository materialGroupRepository;

    private final AutoTestMemberDiamondConfig autoTestMemberDiamondConfig;
    private final CampaignRepository campaignRepository;
    private final BizGenerateImagesWorkflow bizGenerateImagesWorkflow;


    private final BizCreativeCommandWorkflow bizCreativeCommandWorkflow;
    private final BizCreativeRefCommandWorkflow bizCreativeRefCommandWorkflow;
    private final BizCampaignQueryWorkflow bizCampaignQueryWorkflow;


    private final ReportSyncTaskRepository reportSyncTaskRepository;
    private final BizBatchImportWorkflow bizBatchImportWorkflow;
    private final AdgroupCreativeValidateTaskIdentifier adgroupCreativeValidateTaskIdentifier;
    private final FeedRepository feedRepository;
    private final ShieldAccessRepository shieldAccessRepository;
    private final IAdgroupStructureQueryAbility adgroupStructureQueryAbility;


    @AbilityInject(reduce = ReduceType.FIRST)
    private final BizAdgroupCommandWorkflowExt bizAdgroupCommandWorkflowExt;
    private final static int MAX_PAGE_COUNT = 2000;

    private final static String ITEM_CLICK_URL = "https://detail.tmall.com/item.htm?id=";

    @Override
    public SingleResponse<Long> addCreative(ServiceContext context, CreativeViewDTO creativeViewDTO) {
        Long creativeId = bizCreativeCommandWorkflow.addCreative(context, creativeViewDTO);
        return SingleResponse.of(creativeId);
    }

    @Override
    public SingleResponse<Integer> updateCreative(ServiceContext context, CreativeViewDTO creativeViewDTO) {
        Integer count = bizCreativeCommandWorkflow.updateCreative(context, creativeViewDTO);
        return SingleResponse.of(count);
    }

    @Override
    public SingleResponse<Integer> updateCreativePart(ServiceContext context, CreativeViewDTO creativeViewDTO) {
        AssertUtil.notNull(creativeViewDTO, "参数不允许为空");
        Integer count = bizCreativeCommandWorkflow.updateCreativePart(context, creativeViewDTO);
        return SingleResponse.of(count);
    }

    @Override
    public SingleResponse<Integer> updateCreativePreview(ServiceContext context, CreativeViewDTO creativeViewDTO) {
        AssertUtil.notNull(creativeViewDTO, "参数不允许为空");
        Integer count = bizCreativeCommandWorkflow.updateCreativePreview(context, creativeViewDTO);
        return SingleResponse.of(count);
    }

    @Override
    public SingleResponse<Integer> updateCreativeAudit(ServiceContext context, CreativeViewDTO creativeViewDTO) {
        AssertUtil.assertTrue(StringUtils.isNotBlank(context.getBizCode()) && ServiceContextUtil.getSceneId(context) != null, BrandOneBPBaseErrorCode.PARAM_REQUIRED);
        AssertUtil.assertTrue(Objects.nonNull(creativeViewDTO), BrandOneBPBaseErrorCode.PARAM_REQUIRED, "创意信息不能为空");
        AssertUtil.assertTrue(Objects.nonNull(creativeViewDTO.getId()), BrandOneBPBaseErrorCode.PARAM_REQUIRED, "创意ID不能为空");
        return bizCreativeCommandWorkflow.updateCreativeAudit(context, creativeViewDTO);
    }

    @Override
    public SingleResponse<Integer> unBindCreative(ServiceContext context, List<Long> adgroupIds, Long creativeId) {
        AssertUtil.notNull(creativeId, "创意ID不能为空");
        AssertUtil.notEmpty(adgroupIds, "单元ID不能为空");
        AdgroupQueryOption queryOption = AdgroupQueryOption.builder().needCreative(true).build();
        List<AdgroupViewDTO> adgroupViewDTOList = adgroupStructureQueryAbility.handle(context, AdgroupStructureQueryAbilityParam.builder()
                .abilityTarget(AdgroupQueryViewDTO.builder().ids(adgroupIds).build()).queryOption(queryOption).build());
        AssertUtil.notEmpty(adgroupViewDTOList, "单元不存在");
        bizCreativeRefCommandWorkflow.batchUnBindCreative(context, adgroupViewDTOList, Lists.newArrayList(creativeId));
        return SingleResponse.of(adgroupIds.size());
    }

    @Override
    public SingleResponse<Integer> delBindCreative(ServiceContext context, List<Long> adgroupIds, Long creativeId) {
        AssertUtil.notNull(creativeId, "创意ID不能为空");
        AssertUtil.notEmpty(adgroupIds, "单元ID不能为空");
        Integer result = bizCreativeRefCommandWorkflow.delBindCreative(context, adgroupIds, creativeId);
        return SingleResponse.of(result);

    }

    @Override
    public SingleResponse<Long> copyCreativeAsDirect(ServiceContext context, Long creativeId) {
        AssertUtil.notNull(creativeId, "创意ID不能为空");
        Long result = bizCreativeCommandWorkflow.copyCreativeAsDirect(context, creativeId);
        return SingleResponse.of(result);
    }

    @Override
    public MultiResponse<CreativeRefViewDTO> addBatchCreativeRef(ServiceContext context, List<CreativeRefViewDTO> creativeRefViewDTOList) {
        AssertUtil.notEmpty(creativeRefViewDTOList, "参数不允许为空");
        for (CreativeRefViewDTO creativeRefViewDTO : creativeRefViewDTOList) {
            AssertUtil.notNull(creativeRefViewDTO.getCreativeId(), "创意ID不能为空");
            AssertUtil.notNull(creativeRefViewDTO.getAdgroupId(), "单元ID不能为空");
        }
        List<Long> adgroupIds = creativeRefViewDTOList.stream().map(CreativeRefViewDTO::getAdgroupId).distinct().collect(Collectors.toList());

        AdgroupQueryOption queryOption = AdgroupQueryOption.builder().needCreative(true).build();
        List<AdgroupViewDTO> dbAdgroupViewDTOList = adgroupStructureQueryAbility.handle(context, AdgroupStructureQueryAbilityParam.builder()
                .abilityTarget(AdgroupQueryViewDTO.builder().ids(adgroupIds).build()).queryOption(queryOption).build());
        AssertUtil.notEmpty(dbAdgroupViewDTOList, "单元不存在");
        List<Long> creativeIds = creativeRefViewDTOList.stream().map(CreativeRefViewDTO::getCreativeId).distinct().collect(Collectors.toList());

        bizCreativeRefCommandWorkflow.batchBindCreative(context, dbAdgroupViewDTOList, creativeIds);
        return MultiResponse.of(creativeRefViewDTOList);
    }

    @Override
    public MultiResponse<CreativeRefViewDTO> addBatchCreativeRefForCallBack(ServiceContext context, List<CreativeRefViewDTO> creativeRefViewDTOList) {
        AssertUtil.notEmpty(creativeRefViewDTOList, "参数不允许为空");
        for (CreativeRefViewDTO creativeRefViewDTO : creativeRefViewDTOList) {
            AssertUtil.notNull(creativeRefViewDTO.getCreativeId(), "创意ID不能为空");
            AssertUtil.notNull(creativeRefViewDTO.getAdgroupId(), "单元ID不能为空");
        }
        creativeRepository.addBatchCreativeRef(context, creativeRefViewDTOList);
        return MultiResponse.of(creativeRefViewDTOList);
    }

    @Override
    public Response syncQualificationAuditStatus(ServiceContext serviceContext, String qualifyJson) {
        RogerLogger.info("syncQualificationAuditStatus param={}", qualifyJson);
        AssertUtil.hasText(qualifyJson, "资质审核不允许为空");
        QualificationPassNotifyViewDTO qualificationPassNotify = JSON.parseObject(qualifyJson, QualificationPassNotifyViewDTO.class);
        AssertUtil.notNull(qualificationPassNotify.getUserId(), "资质涉及用户不允许为空");
        Long memberId = memberRepository.getMemberIdByTbNumId(qualificationPassNotify.getUserId());
        AssertUtil.notNull(memberId, String.format("memberId不存在,tbUserId=%s", qualificationPassNotify.getUserId()));
        //消息场景，上下文数据不准确，需要重新设置
        serviceContext = ServiceContextUtil.buildServiceContextForBizCode(memberId, BizCodeEnum.BRANDAD.getBizCode());
        bizCreativeCommandWorkflow.syncQualificationAuditStatus(serviceContext, qualifyJson);
        return Response.success();
    }

    @Override
    public Response syncCreativeSwitch(ServiceContext serviceContext, String creativeJson) {
        AssertUtil.hasText(creativeJson, "创意信息不允许为空");
        RogerLogger.info("syncCreativeSwitch param={}", creativeJson);

        CreativeAuditSwitchNotifyViewDTO creativeAuditSwitchNotifyViewDTO = JSON.parseObject(creativeJson, CreativeAuditSwitchNotifyViewDTO.class);
        AssertUtil.notNull(creativeAuditSwitchNotifyViewDTO.getId(), "创意ID不允许为空");
        AssertUtil.notNull(creativeAuditSwitchNotifyViewDTO.getMemberId(), "创意用户ID不允许为空");
        AssertUtil.notNull(creativeAuditSwitchNotifyViewDTO.getProductId(), "创意产品ID不允许为空");
        if (!Product.BRAND_ONEBP_BRAND.getId().equals(creativeAuditSwitchNotifyViewDTO.getProductId())) {
            return Response.success();
        }
        //消息场景，上下文数据不准确，需要重新设置
        serviceContext = ServiceContextUtil.buildServiceContextForBizCode(creativeAuditSwitchNotifyViewDTO.getMemberId(), BizCodeEnum.BRANDAD.getBizCode());
        bizCreativeCommandWorkflow.syncCreativeSwitch(serviceContext, creativeAuditSwitchNotifyViewDTO);
        return Response.success();
    }

    @Override
    public Response creativeReject(ServiceContext context, CreativeRejectMsgViewDTO creativeRejectMsgViewDTO) {
        AssertUtil.notNull(creativeRejectMsgViewDTO, "消息不能为空");
        AssertUtil.notNull(creativeRejectMsgViewDTO.getMemberId(), "memberId不能为空");
        AssertUtil.notNull(creativeRejectMsgViewDTO.getCreativeId(), "创意ID不能为空");
        //消息场景，上下文数据不准确，需要重新设置
        context = ServiceContextUtil.buildServiceContextForBizCode(creativeRejectMsgViewDTO.getMemberId(), BizCodeEnum.BRANDAD.getBizCode());
        bizCreativeCommandWorkflow.creativeReject(context, creativeRejectMsgViewDTO);
        return Response.success();
    }


    @Override
    public Response syncItemBizInfo(ServiceContext context, CreativeViewDTO creativeViewDTO) {
        CreativeViewDTO creative = creativeRepository.getCreativeById(context, creativeViewDTO.getId());
        AssertUtil.notNull(creative, "创意不存在");
        if (!creative.getCreativeScope().equals(BrandCreativeScopeEnum.TAO_INNER.getCode())) {
            RogerLogger.info("syncItemBizInfo only for texiu purchase creative");
            return Response.success();
        }
        //校验当前创意是否在特秀加购创意
        if (!validateTeXiuPurchaseCreative(context, creative)) {
            RogerLogger.info("syncItemBizInfo only for texiu purchase creative");
            return Response.success();
        }
        //解析特秀加购创意中的itemId\skuId
        String itemId = parseItemId(creative);
        if (StringUtils.isNotEmpty(itemId)) {
            String skuId = parseSkuId(creative);
            CreativeItemBizInfoViewDTO creativeItemBizInfoViewDTO = new CreativeItemBizInfoViewDTO();
            creativeItemBizInfoViewDTO.setItemId(Long.parseLong(itemId));
            creativeItemBizInfoViewDTO.setSkuId(StringUtils.isNotEmpty(skuId) ? Long.parseLong(skuId) : null);
            creativeItemBizInfoViewDTO.setStatus(BrandBoolEnum.BRAND_TRUE.getCode());
            creativeRepository.syncItemBizInfo(context, creativeItemBizInfoViewDTO);
        }
        return Response.success();
    }

    @Override
    public MultiResponse<Long> deleteCreatives(ServiceContext context, List<Long> creativeIds) {
        AssertUtil.notEmpty(creativeIds, "创意ID不能为空");
        RogerLogger.info("deleteCreative,creativeIds={}", JSON.toJSONString(creativeIds));

        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(autoTestMemberDiamondConfig.getInnerMemberList()), "未配置白名单，不可物理操作");
        AssertUtil.assertTrue(autoTestMemberDiamondConfig.getInnerMemberList().contains(context.getMemberId()), "未命中白名单，不可物理操作");
        creativeRepository.deleteCreatives(context, creativeIds);
        creativeRepository.delBindCreative(context, creativeIds);
        return MultiResponse.of(creativeIds);
    }

    @Override
    public Response creativeStatusQualityInfo(ServiceContext serviceContext, Long creativeId, Long memberId) {
        RogerLogger.info("creativeStatusQualityInfo creativeId:{}, memberId:{}", creativeId, memberId);
        AssertUtil.notNull(creativeId, "创意ID不能为空");
        AssertUtil.notNull(memberId, "MemberId不能为空");
        //消息场景，上下文数据不准确，需要重新设置
        serviceContext = ServiceContextUtil.buildServiceContextForBizCode(memberId, BizCodeEnum.BRANDAD.getBizCode());
        CreativeViewDTO creative = creativeRepository.getCreativeById(serviceContext, creativeId);
        if (Objects.nonNull(creative)) {
            if (BrandCreativePackageTypeEnum.COMMON.getValue().equals(creative.getPackageType()) && !creative.getId().equals(creative.getCreativePackageId())) {
                creativeRepository.calcUpdateAndUpperCreativeQualityInfo(serviceContext, creative.getCreativePackageId());
            }
        }
        return Response.success();
    }

    @Override
    public SingleResponse<Long> addBatchImportTask(ServiceContext context, ReportTaskViewDTO taskViewDTO) {
        // 校验任务参数
        validateCampaignBatchImportTask(taskViewDTO);
        if (Objects.isNull(taskViewDTO.getTaskId())) {
            Long taskId = reportSyncTaskRepository.add(context, taskViewDTO);
            return SingleResponse.of(taskId);
        }
        reportSyncTaskRepository.modify(context, taskViewDTO);
        return SingleResponse.of(taskViewDTO.getTaskId());
    }

    @Override
    public Response batchUpdateCreative(ServiceContext context, CreativeBatchImportParamViewDTO creativeBatchImportParamViewDTO) {
        bizBatchImportWorkflow.executeBatchImport(context, creativeBatchImportParamViewDTO);
        return Response.success();
    }

    @Override
    public SingleResponse<Boolean> creativeRefSwitch(ServiceContext context, List<CreativeRefViewDTO> creativeRefViewDTOList) {
        Map<Long, List<CreativeRefViewDTO>> collect = creativeRefViewDTOList.stream().collect(Collectors.groupingBy(CreativeRefViewDTO::getAdgroupId));
        for (Map.Entry<Long, List<CreativeRefViewDTO>> entry : collect.entrySet()) {
            Long adgroupId = entry.getKey();
            Integer onlineStatus = entry.getValue().get(0).getOnlineStatus();
            List<Long> creativeIds = entry.getValue().stream().filter(creativeRefViewDTO ->
                    BrandCreativePackageTypeEnum.PACKAGE.getValue().equals(creativeRefViewDTO.getPackageType())).map(CreativeRefViewDTO::getCreativeId).collect(Collectors.toList());
            if (CollectionUtils.isNotEmpty(creativeIds)) {
                CreativeQueryViewDTO queryViewDTO = new CreativeQueryViewDTO();
                queryViewDTO.setCreativePackageIdList(creativeIds);
                queryViewDTO.setPackageType(BrandCreativePackageTypeEnum.COMMON.getValue());
                queryViewDTO.setPageSize(MAX_PAGE_COUNT);
                queryViewDTO.setCreativeIdEqCreativePackageId(Boolean.FALSE);
                PageResultViewDTO<CreativeViewDTO> resultViewDTO = creativeRepository.findListWithPage(context, queryViewDTO);
                if (CollectionUtils.isNotEmpty(resultViewDTO.getList())) {
                    AssertUtil.isEmpty(resultViewDTO.getList().stream().filter(creativeViewDTO ->
                            BrandCreativeTargetTypeEnum.DIRECT.getCode().equals(creativeViewDTO.getTargetType())).collect(Collectors.toList()), BIZ_DATA_EMPTY_ERROR, "媒体直投创意无法设置投放开关");
                    queryViewDTO = new CreativeQueryViewDTO();
                    queryViewDTO.setAdgroupIds(Lists.newArrayList(adgroupId));
                    queryViewDTO.setIds(resultViewDTO.getList().stream().map(CreativeViewDTO::getId).collect(Collectors.toList()));
                    List<CreativeRefViewDTO> creativeRefList = creativeRepository.findCreativeRefList(context, queryViewDTO);
                    creativeRefList.stream().forEach(creativeRefViewDTO -> creativeRefViewDTO.setOnlineStatus(onlineStatus));
                    creativeRefViewDTOList.addAll(creativeRefList);
                }
            }
        }
        List<Long> adgroupIds = creativeRefViewDTOList.stream().map(CreativeRefViewDTO::getAdgroupId).distinct().collect(Collectors.toList());
        AdgroupQueryOption queryOption = AdgroupQueryOption.builder().needCreative(true).build();
        List<AdgroupViewDTO> adgroupViewDTOList = adgroupStructureQueryAbility.handle(context, AdgroupStructureQueryAbilityParam.builder()
                .abilityTarget(AdgroupQueryViewDTO.builder().ids(adgroupIds).build()).queryOption(queryOption).build());
        AssertUtil.notEmpty(adgroupViewDTOList, "单元不存在");

        Map<Long, CreativeRefViewDTO> creativeRefViewMap = creativeRefViewDTOList.stream().collect(Collectors.toMap(CreativeRefViewDTO::getId, Function.identity()));
        for (AdgroupViewDTO adgroupViewDTO : adgroupViewDTOList) {
            for (CreativeRefViewDTO creativeRefViewDTO : adgroupViewDTO.getCreativeRefViewDTOList()) {
                if (Objects.nonNull(creativeRefViewMap.get(creativeRefViewDTO.getId()))) {
                    creativeRefViewDTO.setOnlineStatus(creativeRefViewMap.get(creativeRefViewDTO.getId()).getOnlineStatus());
                }
            }
            List<CreativeRefViewDTO> refViewDTOS = adgroupViewDTO.getCreativeRefViewDTOList().stream().filter(creativeRefViewDTO ->
                    BrandBoolEnum.BRAND_TRUE.getCode().equals(creativeRefViewDTO.getOnlineStatus())).collect(Collectors.toList());
            AssertUtil.notEmpty(refViewDTOS, BIZ_DATA_EMPTY_ERROR, "单元关联创意不能为空");
        }

        List<SingleResponse<Long>> validateResponseList = TaskStream.execute(adgroupCreativeValidateTaskIdentifier, adgroupViewDTOList, (adgroupViewDTO, index) -> {
            SingleResponse<Long> response = SingleResponse.of(adgroupViewDTO.getId());
            try {
                //创意绑定单元场景，bizCode传递的是brandOneBP，需要根据单元的场景，重设上下文
                ServiceContext serviceContext = context;
                if (Objects.equals(BizCodeEnum.BRANDONEBP.getBizCode(), context.getBizCode())) {
                    serviceContext = ServiceContextUtil.getNewServiceContext(context, adgroupViewDTO.getSceneId());
                }
                BizAdgroupBindWorkflowParam bizAdgroupBindWorkflowParam =
                        bizAdgroupCommandWorkflowExt.buildParamForAdgroupBind(serviceContext, adgroupViewDTO);

                CreativeRefWorkflowParam creativeRefWorkflowParam = CreativeRefWorkflowParam.builder()
                        .campaignGroupViewDTO(bizAdgroupBindWorkflowParam.getCampaignGroupViewDTO())
                        .campaignViewDTO(bizAdgroupBindWorkflowParam.getCampaignViewDTO())
                        .adgroupViewDTO(adgroupViewDTO)
                        .creativeViewDTOList(bizAdgroupBindWorkflowParam.getCreativeViewDTOList())
                        .bottomDateViewDTOList(bizAdgroupBindWorkflowParam.getBottomDateViewDTOList()).build();
                bizCreativeRefCommandWorkflow.validateCreativeRef(serviceContext, creativeRefWorkflowParam);
                return response;
            } catch (Exception e) {
                RogerLogger.error(String.format("%s校验失败，单元ID=%s", "开关", adgroupViewDTO.getId()), e);
                ErrorCodeAware errorCodeAware = BrandOneBPException.getErrorCodeFromException(e);
                response.setErrorCode(errorCodeAware.getErrCode());
                response.setErrorMsg(errorCodeAware.getErrMsg());
                response.setSuccess(false);
                return response;
            }
        }).commit().getResultList();
        //失败的单元
        Map<Long, String> failAdgroupMap = validateResponseList.stream().filter(validateResponse -> !validateResponse.isSuccess())
                .collect(Collectors.toMap(SingleResponse::getResult, validateResponse ->
                        String.format("(%s:%s)", validateResponse.getResult(), validateResponse.getErrorMsg())));
        //局部异常信息抛出
        if (MapUtils.isNotEmpty(failAdgroupMap)) {
            String errorMessage = String.format("部分单元%s失败，原因：%s", "开关", String.join(",", failAdgroupMap.values()));
            throw new BrandOneBPException(BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR.of(errorMessage));
        }
        creativeRepository.addBatchCreativeRef(context, creativeRefViewDTOList);
        return SingleResponse.of(Boolean.TRUE);
    }

    /**
     * 校验批量任务信息
     *
     * @param taskViewDTO
     */
    private void validateCampaignBatchImportTask(ReportTaskViewDTO taskViewDTO) {
        AssertUtil.notNull(taskViewDTO);
        AssertUtil.notNull(taskViewDTO.getFunctionCode(), "创意批量导入任务参数缺失");
        AssertUtil.notEmpty(taskViewDTO.getTaskParams(), "创意批量导入任务参数缺失");
        // 校验params内部信息
        AssertUtil.notNull(taskViewDTO.getTaskParams().get("fileName"), "创意批量导入任务参数：导入文件名称缺失");
        AssertUtil.notNull(taskViewDTO.getTaskParams().get("ossUrl"), "创意批量导入任务参数: 导入文件OSS链接缺失");

        AssertUtil.hasLength(taskViewDTO.getTaskName(), "任务名称不能为空");
        AssertUtil.maxLength(taskViewDTO.getTaskName(), 50, "任务名称最长不能超过50");
        AssertUtil.notNull(taskViewDTO.getMemberId(), "MemberId不能为空");
    }

    @Override
    public SingleResponse<CreativeEngineViewDTO> generateCreativeEngine(ServiceContext context, CreativeViewDTO creativeViewDTO) {
        CreativeEngineViewDTO creativeEngineViewDTO = runAbilitySpi(BizCreativeSpi.class,
                extension -> extension.generateCreativeEngine(context, creativeViewDTO), BizCreativeSpi.getSpiBizCode(creativeViewDTO));
        return SingleResponse.of(creativeEngineViewDTO);
    }

    @Override
    @DistLock(value = "MATERIAL_GROUP_CROP_NOTICE,1#toString()")
    public SingleResponse<MaterialGroupViewDTO> cropMaterialGroup(ServiceContext context, Long materialGroupId) {
        MaterialGroupViewDTO materialGroupViewDTO = materialGroupRepository.getMaterialGroupById(context, materialGroupId);
        AssertUtil.notNull(materialGroupViewDTO, String.format("素材组不存在，materialGroupId=%s", materialGroupId));
        MaterialGroupViewDTO cropMaterialGroup = bizCreativeCommandWorkflow.cropMaterialGroup(context, materialGroupViewDTO);
        return SingleResponse.of(cropMaterialGroup);
    }

    @Override
    @DistLock(value = "MATERIAL_GROUP_CROP_CALLBACK_NOTICE,1#getJobId()")
    public SingleResponse<MalusCropResultViewDTO> cropMaterialGroupCallback(ServiceContext context, MalusCropResultViewDTO malusCropResultViewDTO) {
        if (malusCropResultViewDTO == null) {
            return SingleResponse.failureOf(BrandOneBPBaseErrorCode.PARAM_REQUIRED);
        }
        bizCreativeCommandWorkflow.cropMaterialGroupCallback(context, malusCropResultViewDTO);
        return SingleResponse.of(malusCropResultViewDTO);
    }

    @Override
    @DistLock(value = "MATERIAL_GROUP_CROP_SUCCESS_NOTICE,1#toString()")
    public SingleResponse<Long> cropMaterialGroupSuccessCallback(ServiceContext context, Long materialGroupId) {
        bizCreativeCommandWorkflow.generateSmartSubCreative(context, materialGroupId);
        return SingleResponse.of(materialGroupId);
    }


    @Override
    public SingleResponse<Integer> calculateCreativeShowAuditStatus(ServiceContext context, CreativeViewDTO creativeViewDTO) {
        Integer calcShowAuditStatus = runAbilitySpi(BizCreativeSpi.class,
                extension -> extension.calcShowAuditStatus(context, creativeViewDTO), BizCreativeSpi.getSpiBizCode(creativeViewDTO));
        return SingleResponse.of(calcShowAuditStatus);
    }


    @Override
    public SingleResponse<Integer> creativeRefChangeCallback(ServiceContext context, CreativeRefCallbackNoticeViewDTO creativeRefCallbackNoticeViewDTO) {
        RogerLogger.info("creativeRefChangeCallback,ServiceContext:{},CreativeRefCallbackNoticeViewDTO:{}", JSON.toJSONString(context), JSON.toJSONString(creativeRefCallbackNoticeViewDTO));
        CreativeViewDTO creative = creativeRepository.getCreativeById(context, creativeRefCallbackNoticeViewDTO.getCreativeId());
        if (Objects.nonNull(creative) && BrandCreativePackageTypeEnum.PACKAGE.getValue().equals(creative.getPackageType())) {
            CreativeQueryViewDTO queryViewDTO = new CreativeQueryViewDTO();
            queryViewDTO.setIds(Lists.newArrayList(creativeRefCallbackNoticeViewDTO.getCreativeId()));
            queryViewDTO.setAdgroupIds(Lists.newArrayList(creativeRefCallbackNoticeViewDTO.getAdgroupId()));
            queryViewDTO.setPageSize(MAX_PAGE_COUNT);
            List<CreativeRefViewDTO> creativeRefList = creativeRepository.findCreativeRefList(context, queryViewDTO);
            RogerLogger.info("creativeRefChangeCallback,creativeRefList:{}", JSON.toJSONString(creativeRefList));
            if (CollectionUtils.isEmpty(creativeRefList)) {
                //删除操作
                CreativeQueryViewDTO creativeQueryViewDTO = new CreativeQueryViewDTO();
                creativeQueryViewDTO.setCreativePackageIdList(Lists.newArrayList(creativeRefCallbackNoticeViewDTO.getCreativeId()));
                creativeQueryViewDTO.setCreativeIdEqCreativePackageId(Boolean.FALSE);
                creativeQueryViewDTO.setPackageType(BrandCreativePackageTypeEnum.COMMON.getValue());
                creativeQueryViewDTO.setPageSize(MAX_PAGE_COUNT);
                PageResultViewDTO<CreativeViewDTO> result = creativeRepository.findListWithPage(context, creativeQueryViewDTO);
                if (CollectionUtils.isNotEmpty(result.getList())) {
                    queryViewDTO.setIds(result.getList().stream().map(CreativeViewDTO::getId).collect(Collectors.toList()));
                    List<CreativeRefViewDTO> delCreativeRefList = creativeRepository.findCreativeRefList(context, queryViewDTO);
                    if (CollectionUtils.isNotEmpty(delCreativeRefList)) {
                        creativeRepository.unBindCreative(context, Lists.newArrayList(creativeRefCallbackNoticeViewDTO.getAdgroupId()),
                                delCreativeRefList.stream().map(CreativeRefViewDTO::getCreativeId).collect(Collectors.toList()));
                        delCreativeRefList.forEach(creativeRefViewDTO -> {
                            CreativeViewDTO creativeViewDTO = new CreativeViewDTO();
                            creativeViewDTO.setId(creativeRefViewDTO.getCreativeId());
                            bizCreativeCommandWorkflow.updateCreativeAudit(context, creativeViewDTO);
                        });
                    }
                    RogerLogger.info("creativeRefChangeCallback,删除创意关联关系完成");
                }
            } else {
                CreativeRefViewDTO refViewDTO = creativeRefList.get(0);
                //新增操作
                CampaignViewDTO campaign = bizCampaignQueryWorkflow.getCampaignInfoByOption(context, refViewDTO.getCampaignId(), CampaignQueryOption.builder().needChildren(true).needTarget(true).needFrequency(true).build());
                List<CampaignTemplateViewDTO> campaignTemplateViewDTOS = campaignRepository.getCampaignTemplateIds(context, Lists.newArrayList(campaign));
                Map<Long, CampaignTemplateViewDTO> campaignTemplateMap = campaignTemplateViewDTOS.stream().collect(Collectors.toMap(CampaignTemplateViewDTO::getCampaignId, Function.identity()));

                RogerLogger.info("creativeRefChangeCallback,campaign:{}", JSON.toJSONString(campaign));
                if (Objects.nonNull(campaign)) {
                    if (CollectionUtils.isNotEmpty(campaign.getSubCampaignViewDTOList())) {
                        List<Long> templateIds = campaign.getSubCampaignViewDTOList().stream().filter(item ->
                                        campaignTemplateMap.containsKey(item.getId()) &&
                                                CollectionUtils.isNotEmpty(campaignTemplateMap.get(item.getId()).getTemplateIds())).flatMap(item ->
                                        campaignTemplateMap.get(item.getId()).getTemplateIds().stream()).distinct()
                                .collect(Collectors.toList());
                        List<Long> directTemplateIds = campaign.getSubCampaignViewDTOList().stream().filter(item ->
                                        campaignTemplateMap.containsKey(item.getId()) &&
                                                CollectionUtils.isNotEmpty(campaignTemplateMap.get(item.getId()).getDirectTemplateIds())).flatMap(item ->
                                        campaignTemplateMap.get(item.getId()).getDirectTemplateIds().stream()).distinct()
                                .collect(Collectors.toList());
                        templateIds.addAll(directTemplateIds);
                        CreativeQueryViewDTO creativeQueryViewDTO = new CreativeQueryViewDTO();
                        creativeQueryViewDTO.setCreativePackageIdList(Lists.newArrayList(creativeRefCallbackNoticeViewDTO.getCreativeId()));
                        creativeQueryViewDTO.setCreativeIdEqCreativePackageId(Boolean.FALSE);
                        creativeQueryViewDTO.setPackageType(BrandCreativePackageTypeEnum.COMMON.getValue());
                        creativeQueryViewDTO.setPageSize(MAX_PAGE_COUNT);
                        PageResultViewDTO<CreativeViewDTO> result = creativeRepository.findListWithPage(context, creativeQueryViewDTO);
                        RogerLogger.info("creativeRefChangeCallback,PageResultViewDTO:{}", JSON.toJSONString(result));
                        if (CollectionUtils.isNotEmpty(result.getList())) {
                            List<CreativeViewDTO> pageViewDTOS = result.getList().stream().filter(creativeViewDTO -> Objects.nonNull(creativeViewDTO.getCreativeTemplate())).filter(creativeViewDTO ->
                                    templateIds.contains(creativeViewDTO.getCreativeTemplate().getSspTemplateId())).collect(Collectors.toList());
                            List<CreativeRefViewDTO> collect = pageViewDTOS.stream().map(creativePageViewDTO -> {
                                CreativeRefViewDTO creativeRefViewDTO = BeanUtils.copyIgnoreNull(refViewDTO, new CreativeRefViewDTO());
                                creativeRefViewDTO.setId(null);
                                creativeRefViewDTO.setCreativeId(creativePageViewDTO.getId());
                                creativeRefViewDTO.setPackageType(BrandCreativePackageTypeEnum.COMMON.getValue());
                                return creativeRefViewDTO;
                            }).collect(Collectors.toList());
                            if (CollectionUtils.isNotEmpty(collect)) {
                                creativeRepository.addBatchCreativeRef(context, collect);
                            }
                            result.getList().stream().forEach(creativePageViewDTO -> {
                                CreativeViewDTO creativeViewDTO = new CreativeViewDTO();
                                creativeViewDTO.setId(creativePageViewDTO.getId());
                                bizCreativeCommandWorkflow.updateCreativeAudit(context, creativeViewDTO);
                            });
                            RogerLogger.info("creativeRefChangeCallback,新增创意关联关系完成");
                        }
                    }
                }
            }
        }
        return SingleResponse.of(BrandBoolEnum.BRAND_TRUE.getCode());
    }

    @Override
    public SingleResponse<CreativeGenerateViewDTO> generateImages(ServiceContext serviceContext, CreativeGenerateViewDTO creativeGenerateViewDTO) {
        //商品准入校验
        RuleCheckResultViewDTO accessResult = feedRepository.checkAccess(serviceContext, creativeGenerateViewDTO.getItemId());
        AssertUtil.assertTrue(BrandBoolEnum.BRAND_TRUE.getCode().equals(accessResult.getIsPass()), ITEM_SUPPORTED_SMART_ERROR);
        //商品智能投放校验
        RuleCheckResultViewDTO smartAccessResult = shieldAccessRepository.checkFeedSmartAccess(serviceContext, creativeGenerateViewDTO.getItemId());
        AssertUtil.assertTrue(BrandBoolEnum.BRAND_TRUE.getCode().equals(smartAccessResult.getIsPass()), ITEM_SUPPORTED_SMART_ERROR);

        List<TemplateContextViewDTO> contextDTOS = creativeTemplateRepository.getTemplateMetaData(serviceContext, Lists.newArrayList(creativeGenerateViewDTO.getSspTemplateId()), Boolean.TRUE);
        TemplateContextViewDTO templateContextViewDTO = contextDTOS.get(0);
        bizGenerateImagesWorkflow.executeGenerate(serviceContext, creativeGenerateViewDTO, templateContextViewDTO);
        return SingleResponse.of(creativeGenerateViewDTO);
    }

    @Override
    public SingleResponse<CreativeGenerateViewDTO> generateCreative(ServiceContext serviceContext, CreativeGenerateViewDTO creativeGenerateViewDTO) {
        List<TemplateContextViewDTO> contextDTOS = creativeTemplateRepository.getTemplateMetaData(serviceContext, Lists.newArrayList(creativeGenerateViewDTO.getSspTemplateId()), Boolean.TRUE);
        TemplateContextViewDTO templateContextViewDTO = contextDTOS.get(0);

        JSONObject templateData = new JSONObject();
        Map<String, Object> properties = templateContextViewDTO.getProperties();
        templateContextViewDTO.getBizMap().put(TemplateConstant.CONSTANT_KEY_PROPERTIES, properties);
        templateData.put(TemplateConstant.CONSTANT_KEY_BIZ_MAP, templateContextViewDTO.getBizMap());
        templateData.put(BizCodeConstants.CreativeEnum.SSP_TEMPLATE_ID.getCode(), creativeGenerateViewDTO.getSspTemplateId());
        templateData.put(TemplateConstant.MEDIA_SCOPE, MediaScopeEnum.CROSS_SCOPE.getCode());
        Map<String, Map<String, Object>> bizMap = templateContextViewDTO.getBizMap();
        for (Map.Entry<String, Map<String, Object>> entry : bizMap.entrySet()) {
            String key = entry.getKey();
            Map<String, Object> elementMap = entry.getValue();

            String typeStr = (String) elementMap.get(TemplateConstant.CONSTANT_KEY_TYPE);

            //智能视觉图片
            if (ElementTypeEnum.VISUAL_IMAGE_EXTEND.getCode().equals(typeStr)) {
                CreativeMalusTemplateConvergeElementViewDTO convergeElementViewDTO = new CreativeMalusTemplateConvergeElementViewDTO();
                List<CreativeMalusTemplateFileElementViewDTO> fileElementViewDTOS = creativeGenerateViewDTO.getImages().stream().filter(Objects::nonNull).map(image -> {
                    CreativeMalusTemplateFileElementViewDTO fileElementViewDTO = new CreativeMalusTemplateFileElementViewDTO();
                    fileElementViewDTO.setUrl(image);
                    fileElementViewDTO.setKey((String) elementMap.get(TemplateConstant.CONSTANT_KEY_ENGINE_NAME));
                    fillSize(fileElementViewDTO);
                    return fileElementViewDTO;
                }).filter(fileElement -> StringUtils.isNotBlank(fileElement.getUrl())).collect(Collectors.toList());
                AssertUtil.notEmpty(fileElementViewDTOS, IMAGE_GENERATE_ERROR, "图片加载异常，请尝试重新生图");
                convergeElementViewDTO.setMainImage(BeanUtils.copyIgnoreNull(fileElementViewDTOS.get(0), new CreativeMalusTemplateFileElementViewDTO()));
                convergeElementViewDTO.setExtendImages(fileElementViewDTOS);
                JSONObject visualImageJson = new JSONObject();
                visualImageJson.put(TemplateConstant.VISUAL_IMAGES, Lists.newArrayList(convergeElementViewDTO));
                templateData.put(key, visualImageJson);
            } else if (ElementTypeEnum.LANDING_PAGE.getCode().equals(typeStr)) {
                String url = ITEM_CLICK_URL + creativeGenerateViewDTO.getItemId();
                JSONObject urlJson = new JSONObject();
                urlJson.put(ElementTypeEnum.URL.getCode(), url);
                templateData.put(key, urlJson);
                templateData.put(TemplateConstant.CLICK_URL_TYPE, TemplateConstant.ITEM);
                templateData.put(TemplateConstant.CLICK_URL_ITEM_ID, creativeGenerateViewDTO.getItemId());
            } else if (ElementTypeEnum.OPTIONAL.getCode().equals(typeStr)) {
                String url = ITEM_CLICK_URL + creativeGenerateViewDTO.getItemId();
                templateData.put(CLICK_URL, url);
                templateData.put(TemplateConstant.CLICK_URL_TYPE, TemplateConstant.ITEM);
                templateData.put(TemplateConstant.CLICK_URL_ITEM_ID, creativeGenerateViewDTO.getItemId());
            }
        }
        creativeGenerateViewDTO.setTemplateData(templateData.toJSONString());
        return SingleResponse.of(creativeGenerateViewDTO);
    }

    private void fillSize(CreativeMalusTemplateFileElementViewDTO fileElementViewDTO){
        try {
            URL url = new URL(fileElementViewDTO.getUrl());
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setDoInput(true);

            // 获取文件大小
            long fileSize = connection.getContentLengthLong();
            fileElementViewDTO.setFileSize(fileSize/ SizeUnitEnum.KB.getTransferToBit());

            // 读取图片
            InputStream inputStream = connection.getInputStream();
            BufferedImage image = ImageIO.read(inputStream);

            if (image != null) {
                int width = image.getWidth();
                int height = image.getHeight();

                fileElementViewDTO.setWidth(width);
                fileElementViewDTO.setHeight(height);

                // 关闭资源
                inputStream.close();
            } else {
                RogerLogger.error("无法加载图片");
                fileElementViewDTO.setUrl(null);
            }

        } catch (Exception e) {
            fileElementViewDTO.setUrl(null);
            RogerLogger.error("加载图片异常", e);
        }
    }

    /**
     * 校验当前创意是否特秀加购创意
     * 校验模板是否有加购item\sku组件
     *
     * @param creativeViewDTO
     * @return
     */
    private Boolean validateTeXiuPurchaseCreative(ServiceContext serviceContext, CreativeViewDTO creativeViewDTO) {
        AssertUtil.notNull(creativeViewDTO.getCreativeTemplate(), "sspTemplateId not null");
        AssertUtil.notNull(creativeViewDTO.getCreativeTemplate().getSspTemplateId(), "sspTemplateId not null");
        TemplateViewDTO templateViewDTO = creativeTemplateRepository.getTemplateById(serviceContext, creativeViewDTO.getCreativeTemplate().getSspTemplateId());
        AssertUtil.notNull(templateViewDTO, "invalid sspTemplateId " + creativeViewDTO.getCreativeTemplate().getSspTemplateId());
        if (CollectionUtils.isNotEmpty(templateViewDTO.getProtocolList())) {
            return templateViewDTO.getProtocolList().stream()
                    .anyMatch(protocol -> ElementTypeEnum.ITEM_ID_INPUT.getCode().equals(protocol.getElementTypeCode())
                            || ElementTypeEnum.SKU_ID_INPUT.getCode().equals(protocol.getElementTypeCode()));
        }
        return false;

    }

    /**
     * 解析特秀加购创意itemId
     *
     * @param creativeViewDTO
     * @return
     */
    private String parseItemId(CreativeViewDTO creativeViewDTO) {
        if (CollectionUtils.isNotEmpty(creativeViewDTO.getElementList())) {
            return creativeViewDTO.getElementList().stream()
                    .filter(elementViewDTO -> BrandCreativeElementTypeEnum.ITEM_ID_INPUT.getCode().equals(elementViewDTO.getElementType()))
                    .findFirst()
                    .map(ElementViewDTO::getElementValue)
                    .orElse(null);
        }
        return null;
    }

    /**
     * 解析特秀加购创意itemId
     *
     * @param creativeViewDTO
     * @return
     */
    private String parseSkuId(CreativeViewDTO creativeViewDTO) {
        if (CollectionUtils.isNotEmpty(creativeViewDTO.getElementList())) {
            return creativeViewDTO.getElementList().stream()
                    .filter(elementViewDTO -> BrandCreativeElementTypeEnum.SKU_ID_INPUT.getCode().equals(elementViewDTO.getElementType()))
                    .findFirst()
                    .map(ElementViewDTO::getElementValue)
                    .orElse(null);
        }
        return null;
    }
}
