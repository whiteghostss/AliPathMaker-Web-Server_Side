package com.taobao.ad.brand.bp.app.service.cartitem;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.alibaba.ad.brand.sdk.constant.cartitem.BrandCartItemStatusEnum;
import com.alibaba.ad.brand.sdk.constant.cartitem.BrandCartItemTypeEnum;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.tool.lock.annotation.DistLock;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.app.workflow.cartitem.BizCartItemCommandWorkflow;
import com.taobao.ad.brand.bp.app.workflow.solution.BizSolutionCommandWorkflow;
import com.taobao.ad.brand.bp.client.api.cart.BizCartItemNoticeCommandService;
import com.taobao.ad.brand.bp.client.dto.cartitem.CartItemStatusChangeViewDTO;
import com.taobao.ad.brand.bp.client.dto.cartitem.CustomerContactViewDTO;
import com.taobao.ad.brand.bp.client.dto.cartitem.query.CartItemQueryViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.cart.repository.CartItemRepository;
import com.taobao.ad.brand.bp.domain.memeber.MemberRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author yanjingang
 * @date 2024/12/8
 */
@HSFProvider(serviceInterface = BizCartItemNoticeCommandService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizCartItemNoticeCommandServiceImpl implements BizCartItemNoticeCommandService {

    private final BizSolutionCommandWorkflow bizSolutionCommandWorkflow;
    private final BizCartItemCommandWorkflow bizCartItemCommandWorkflow;
    private final CartItemRepository cartItemRepository;
    private final CampaignGroupRepository campaignGroupRepository;
    private final MemberRepository memberRepository;


    @Override
    @DistLock(value = "CART_ITEM_STATUS_CHANGE_EVENT_NOTICE,1#getId(),1#getOldStatus(),1#getNewStatus()")
    public Response noticeCartItemStatusUpdated(ServiceContext serviceContext, CartItemStatusChangeViewDTO cartItemStatusChangeViewDTO) {
        AssertUtil.notNull(cartItemStatusChangeViewDTO, "参数不能为空");
        AssertUtil.notNull(cartItemStatusChangeViewDTO.getId(), "ID不能为空");
        CartItemQueryViewDTO cartItemQueryViewDTO = new CartItemQueryViewDTO();
        cartItemQueryViewDTO.setIdList(Lists.newArrayList(cartItemStatusChangeViewDTO.getId()));
        cartItemQueryViewDTO.setStatusList(Arrays.stream(BrandCartItemStatusEnum.values()).map(BrandCartItemStatusEnum::getCode).collect(Collectors.toList()));
        List<CartItemViewDTO> cartList = cartItemRepository.findCartList(serviceContext, cartItemQueryViewDTO);
        if (CollectionUtils.isEmpty(cartList)) {
            return Response.success();
        }
        CartItemViewDTO cartItemViewDTO = cartList.get(0);
        // 当前仅处理极简版
        if (BrandCartItemTypeEnum.SLIM_ORDER.getCode().equals(cartItemViewDTO.getType())) {
            if (BrandCartItemStatusEnum.DELETE.getCode().equals(cartItemStatusChangeViewDTO.getNewStatus())) {
                bizSolutionCommandWorkflow.unbindCartItemSolution(serviceContext, cartItemStatusChangeViewDTO.getId());
            } else if (BrandCartItemStatusEnum.ORDER_SUCCESS.getCode().equals(cartItemStatusChangeViewDTO.getNewStatus())) {
                // 同步联系方式
                syncCustomerContact(serviceContext, cartItemViewDTO);
            }
        }

        return Response.success();
    }

    private void syncCustomerContact(ServiceContext serviceContext, CartItemViewDTO cartItemViewDTO) {
        if (cartItemViewDTO.getCampaignGroupId() == null || cartItemViewDTO.getCampaignGroupId() == 0L) {
            return;
        }
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(serviceContext, cartItemViewDTO.getCampaignGroupId());
        if (StringUtils.isBlank(campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getContactPhone())) {
            return;
        }
        String memberName = memberRepository.getMemberDisplayNameById(campaignGroupViewDTO.getMemberId());
        CustomerContactViewDTO customerContactViewDTO = new CustomerContactViewDTO();
        customerContactViewDTO.setName(memberName);
        customerContactViewDTO.setPhone(campaignGroupViewDTO.getCampaignGroupCustomerViewDTO().getContactPhone());
        customerContactViewDTO.setEmail(campaignGroupViewDTO.getMemberId() + "@alimama");
        bizCartItemCommandWorkflow.saveCustomerContact(serviceContext, customerContactViewDTO);
    }
}
