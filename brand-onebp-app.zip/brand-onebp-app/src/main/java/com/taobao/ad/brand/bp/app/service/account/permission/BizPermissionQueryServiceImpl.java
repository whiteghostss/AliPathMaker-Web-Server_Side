package com.taobao.ad.brand.bp.app.service.account.permission;

import com.alibaba.abf.governance.context.GatewayContext;
import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.app.workflow.account.permission.BizPermissionWorkflow;
import com.taobao.ad.brand.bp.client.api.account.permission.BizPermissionQueryService;
import com.taobao.ad.brand.bp.client.dto.account.login.LoginSessionViewDTO;
import com.taobao.ad.brand.bp.client.dto.account.permission.WriteReadPermissionsViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.account.repository.LoginSessionRepository;
import com.taobao.ad.brand.bp.domain.account.repository.BizPermissionRepository;
import com.taobao.ad.brand.bp.domain.config.AdcIdToModuleDiamondConfig;
import lombok.RequiredArgsConstructor;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author 虫洞 <liuming.liu@alibaba-inc.com>
 * @date 2023/4/26
 */
@HSFProvider(serviceInterface = BizPermissionQueryService.class)
@RequiredArgsConstructor
public class BizPermissionQueryServiceImpl implements BizPermissionQueryService {
    private final LoginSessionRepository loginSessionRepository;
    private final BizPermissionRepository bizPermissionRepository;
    private final BizPermissionWorkflow bizPermissionWorkflow;
    private final AdcIdToModuleDiamondConfig adcIdToModuleDiamondConfig;

    /**
     * @param context
     * @param gatewayContext
     * @return
     * @see <a href="https://aliyuque.antfin.com/yk_ad_engine/adplat/kgb34go82gbdf8bd#htM3V">https://aliyuque.antfin.com/yk_ad_engine/adplat/kgb34go82gbdf8bd#htM3V</a>
     */
    @Override
    public SingleResponse<WriteReadPermissionsViewDTO> getWriteReadPermissions(ServiceContext context, GatewayContext gatewayContext) {
        AssertUtil.notNull(context, "serviceContext is null");
        AssertUtil.notNull(context.getBizCode(), "serviceContext.bizCode is null");

        // 查询登录用户信息
        LoginSessionViewDTO loginSessionViewDTO = loginSessionRepository.get(context, gatewayContext);
        // 未登录投放账号
        boolean nonLogin = (loginSessionViewDTO == null || (!loginSessionViewDTO.isPreLogin() && !loginSessionViewDTO.isLogin()));
        if (nonLogin) {
            RogerLogger.info("getWriteReadPermissions no login");
            return SingleResponse.of(WriteReadPermissionsViewDTO.empty());
        }
        RogerLogger.info("getWriteReadPermissions has login");
        //先从缓存中查询权限数据
        WriteReadPermissionsViewDTO writeReadPermissions = bizPermissionWorkflow.getCachedWriteReadPermissions(loginSessionViewDTO);
        if (writeReadPermissions != null) {
            RogerLogger.info("getWriteReadPermissions from cache");
            return SingleResponse.of(writeReadPermissions);
        }
        // 缓存中不存在，执行查询登录用户具有的模块读写权限
        writeReadPermissions = bizPermissionWorkflow.getWriteReadPermissions(context, loginSessionViewDTO);
        RogerLogger.info("getWriteReadPermissions from db");
        // 写权限数据到缓存
        try {
            bizPermissionWorkflow.writePermissionsToCache(loginSessionViewDTO, writeReadPermissions);
        } catch (Exception e) {
            RogerLogger.error("put permission data to cache", e);
        }
        return SingleResponse.of(writeReadPermissions);
    }

    @Override
    public MultiResponse<String> findWritableEmbeddedModuleList(ServiceContext context, GatewayContext gatewayContext) {
        SingleResponse<WriteReadPermissionsViewDTO> response = this.getWriteReadPermissions(context, gatewayContext);
        AssertUtil.assertTrue(response.isSuccess(), response.getErrorCode(), response.getErrorMsg());

        WriteReadPermissionsViewDTO writeReadPermission = response.getResult();
        if (writeReadPermission == null) {
            return MultiResponse.of(Collections.emptyList());
        }
        List<String> writeableEmbeddedModuleList = adcIdToModuleDiamondConfig.getEmbeddedMappingConfig().entrySet()
                .stream()
                .filter(kv -> writeReadPermission.isWritable(kv.getKey()))
                .flatMap(kv -> kv.getValue().stream())
                .distinct()
                .sorted()
                .collect(Collectors.toList());
        return MultiResponse.of(writeableEmbeddedModuleList);
    }

    @Override
    public MultiResponse<String> getSupportSceneList(ServiceContext context) {
        return MultiResponse.of(bizPermissionRepository.supportSceneList(context));
    }

    @Override
    public MultiResponse<Integer> getSupportSspProductLineList(ServiceContext context) {
        return MultiResponse.of(bizPermissionRepository.supportSspProductLineList(context));
    }
}
