package com.taobao.ad.brand.bp.app.interceptor;

import com.alibaba.abf.isolation.service.IsoDomainServiceAdvisor;
import com.alibaba.abf.spec.common.annotation.SwitchContext;
import org.springframework.stereotype.Component;

import java.lang.annotation.Annotation;

/**
 * Description:上下文切换拦截器
 * <p>
 * date: 2023/6/5 7:05 PM
 *
 * @author shiyan
 * @version 1.0
 */
@Component
public class BrandOneBPSwitchContextInterceptor extends IsoDomainServiceAdvisor {

    @Override
    protected Class<? extends Annotation> getAnnotationClass() {
        return SwitchContext.class;
    }
}
