package com.taobao.ad.brand.bp.app.workflow.cartitem;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSourceEnum;
import com.alibaba.ad.brand.sdk.constant.cartitem.BrandCartItemStatusEnum;
import com.alibaba.ad.brand.sdk.constant.cartitem.BrandCartItemTypeEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.tool.lock.annotation.DistLock;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.app.workflow.campaigngroup.BizCampaignGroupCommandWorkflow;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.cartitem.CartItemCampaignConsistencyCheckResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.cartitem.CartItemConsistencyCheckResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.cartitem.CartItemOrderViewDTO;
import com.taobao.ad.brand.bp.client.dto.cartitem.CustomerContactViewDTO;
import com.taobao.ad.brand.bp.client.dto.cartitem.query.CartItemQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.rule.RuleCheckResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSkuViewDTO;
import com.taobao.ad.brand.bp.client.enums.cart.CartActionEnum;
import com.taobao.ad.brand.bp.client.enums.cart.CartOrderRuleTypeEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CustomerRepository;
import com.taobao.ad.brand.bp.domain.cart.repository.CartItemRepository;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.account.atomability.IAccountShopExistJudgeAbility;
import com.taobao.ad.brand.bp.domain.sdk.account.atomability.param.AccountShopExistJudgeAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.*;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.consistency.ICartItemCampaignCrowdConsistencyCheckAbility;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.consistency.ICartItemCampaignPriceConsistencyCheckAbility;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.orderjudge.*;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.param.*;
import com.taobao.ad.brand.bp.domain.shopwindow.repository.BrandSkuRepository;
import com.taobao.unifiedsession.core.json.JSON;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * 加购行流程
 * @author shiyan
 * @date 2024/06/26
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizCartItemCommandWorkflow {

    private final CartItemRepository cartItemRepository;
    private final BrandSkuRepository brandSkuRepository;
    private final ResourcePackageRepository resourcePackageRepository;
    private final CustomerRepository customerRepository;
    private final IAccountShopExistJudgeAbility accountShopExistJudgeAbility;
    private final ICampaignStructureQueryAbility campaignStructureQueryAbility;
    private final ICartItemUniqueValidateForAddCartItemAbility cartItemUniqueValidateForAddCartItemAbility;
    private final ICartItemBaseValidateForAddCartItemAbility cartItemBaseValidateForAddCartItemAbility;
    private final ICartItemSkuStatusValidateForAddCartItemAbility cartItemSkuStatusValidateForAddCartItemAbility;
    private final ICartItemDeleteJudgeAbility cartItemDeleteJudgeAbility;
    private final ICartItemCustomerJudgeAbility cartItemCustomerJudgeAbility;
    private final ICartItemInitForAddCartItemAbility cartItemInitForAddCartItemAbility;
    private final ICartItemStartBudgetCheckForCartItemOrderAbility cartItemStartBudgetCheckForCartItemOrderAbility;
    private final ICartItemCampaignStatusCheckForCartItemOrderAbility cartItemCampaignStatusCheckForCartItemOrderAbility;
    private final ICartItemCampaignInquiryTimeCheckForCartItemOrderAbility cartItemCampaignInquiryTimeCheckForCartItemOrderAbility;
    private final ICartItemSkuOnlineCheckForCartItemOrderAbility cartItemSkuOnlineCheckForCartItemOrderAbility;
    private final ICartItemConsistencyCheckForCartItemOrderAbility cartItemConsistencyCheckForCartItemOrderAbility;
    private final ICartItemCampaignPriceConsistencyCheckAbility cartItemCampaignPriceConsistencyCheckAbility;
    private final ICartItemCampaignCrowdConsistencyCheckAbility cartItemCampaignCrowdConsistencyCheckAbility;

    private final BizCampaignGroupCommandWorkflow bizCampaignGroupCommandWorkflow;
    private final BizCartItemQueryWorkflow bizCartItemQueryWorkflow;

    /**
     * 新增加购行（同一个memberId只能添加一种类型sku到购物车）
     *
     * @param serviceContext
     * @param cartViewDTO
     * @return
     */
    @DistLock(value = "addCart_distLock,0#getMemberId(),1#getType(),1#getSkuId(),1#getBundleId()?:'-1'")
    public Long addCartItem(ServiceContext serviceContext, CartItemViewDTO cartViewDTO) {
        AssertUtil.notNull(cartViewDTO.getSkuId(), "SKU不允许为空");
        //店铺有效性
        Boolean showExistJudge = accountShopExistJudgeAbility.handle(serviceContext, AccountShopExistJudgeAbilityParam.builder().abilityTarget(serviceContext.getMemberId()).build());
        AssertUtil.assertTrue(showExistJudge,"您暂无店铺，无法自助下单。如需购买品牌广告，请联系小二");
        // 新老客
        cartItemCustomerJudgeAbility.handle(serviceContext, CartItemCustomerCheckAbilityParam.builder().abilityTarget(serviceContext.getMemberId()).actionEnum(CartActionEnum.ADD_TO_CART).build());
        //基础校验
        cartItemBaseValidateForAddCartItemAbility.handle(serviceContext,
                CartItemValidateAbilityParam.builder().abilityTarget(cartViewDTO).build());
        //唯一性校验
        cartItemUniqueValidateForAddCartItemAbility.handle(serviceContext,
                CartItemValidateAbilityParam.builder().abilityTarget(cartViewDTO).build());
        //SKU校验
        BrandSkuViewDTO skuViewDTO = brandSkuRepository.get(serviceContext, cartViewDTO.getSkuId());
        AssertUtil.notNull(skuViewDTO, "SKU不存在或者已被删除");
        cartItemSkuStatusValidateForAddCartItemAbility.handle(serviceContext,
                CartItemValidateAbilityParam.builder().abilityTarget(cartViewDTO).skuViewDTO(skuViewDTO).build());

        //加购行ssp产品线准入
        RuleCheckResultViewDTO skuAccessCheckResult = bizCartItemQueryWorkflow.judgeSkuAccess(serviceContext, skuViewDTO);
        AssertUtil.assertTrue(BrandBoolEnum.BRAND_TRUE.getCode().equals(skuAccessCheckResult.getIsPass()), skuAccessCheckResult.getReason());

        //加购行初始化
        cartItemInitForAddCartItemAbility.handle(serviceContext,
                CartItemAddInitAbilityParam.builder().abilityTarget(cartViewDTO).skuViewDTO(skuViewDTO).build());
        //加购行保存
        return cartItemRepository.addCart(serviceContext, cartViewDTO);
    }

    /**
     * 修改加购行（同一个memberId只能添加一种类型sku到购物车）
     *
     * @param serviceContext
     * @param cartViewDTO
     * @return
     */
    @DistLock(value = "updateCart_distLock,0#getMemberId(),1#getType(),1#getSkuId(),1#getBundleId()?:'-1'")
    public Long updateCart(ServiceContext serviceContext, CartItemViewDTO cartViewDTO) {
        AssertUtil.notNull(cartViewDTO.getId(), "加购行不允许为空");
        AssertUtil.notNull(cartViewDTO.getSkuId(), "SKU不允许为空");
        // 新老客
        cartItemCustomerJudgeAbility.handle(serviceContext, CartItemCustomerCheckAbilityParam.builder()
                .abilityTarget(serviceContext.getMemberId()).actionEnum(CartActionEnum.ADD_TO_CART).build());
        //基础校验
        cartItemBaseValidateForAddCartItemAbility.handle(serviceContext,
                CartItemValidateAbilityParam.builder().abilityTarget(cartViewDTO).build());
        //唯一性校验
        cartItemUniqueValidateForAddCartItemAbility.handle(serviceContext,
                CartItemValidateAbilityParam.builder().abilityTarget(cartViewDTO).build());
        //SKU校验
        BrandSkuViewDTO skuViewDTO = brandSkuRepository.get(serviceContext, cartViewDTO.getSkuId());
        AssertUtil.notNull(skuViewDTO, "SKU不存在或者已被删除");
        cartItemSkuStatusValidateForAddCartItemAbility.handle(serviceContext,
                CartItemValidateAbilityParam.builder().abilityTarget(cartViewDTO).skuViewDTO(skuViewDTO).build());
        //加购行ssp产品线准入
        RuleCheckResultViewDTO skuAccessCheckResult = bizCartItemQueryWorkflow.judgeSkuAccess(serviceContext, skuViewDTO);
        AssertUtil.assertTrue(BrandBoolEnum.BRAND_TRUE.getCode().equals(skuAccessCheckResult.getIsPass()), skuAccessCheckResult.getReason());

        //加购行初始化
        cartItemInitForAddCartItemAbility.handle(serviceContext,
                CartItemAddInitAbilityParam.builder().abilityTarget(cartViewDTO).skuViewDTO(skuViewDTO).build());
        //加购行保存
        cartItemRepository.updateCartAll(serviceContext, cartViewDTO);
        return cartViewDTO.getId();
    }

    /**
     * 加购行删除
     * @param serviceContext
     * @param idList
     * @return
     */
    public MultiResponse<Long> batchDeleteCart(ServiceContext serviceContext, List<Long> idList){
        //数据查询
        CartItemQueryViewDTO cartItemQueryViewDTO = CartItemQueryViewDTO.builder().idList(idList).build();
        List<CartItemViewDTO> dbCartList = cartItemRepository.findCartList(serviceContext, cartItemQueryViewDTO);
        AssertUtil.notEmpty(dbCartList,"加购行不存在，请刷新页面");
        for (CartItemViewDTO cartItemViewDTO : dbCartList) {
            Boolean canDelete = cartItemDeleteJudgeAbility.handle(serviceContext,
                    CartItemValidateAbilityParam.builder().abilityTarget(cartItemViewDTO).build());
            AssertUtil.assertTrue(canDelete,String.format("加购行（%s）当前状态不允许删除",cartItemViewDTO.getId()));
        }
        //执行删除
        cartItemRepository.deleteCartItem(serviceContext, idList);
        return MultiResponse.of(idList);
    }

    /**
     * 加购行下单
     * @param serviceContext
     * @param cartItemOrderViewDTO
     * @return
     */
    public Long cartItemOrder(ServiceContext serviceContext, CartItemOrderViewDTO cartItemOrderViewDTO){
        //查询加购行
        List<Long> ids = Optional.ofNullable(cartItemOrderViewDTO).map(CartItemOrderViewDTO::getCartItemIds).orElse(null);
        AssertUtil.notEmpty(ids,"加购行ID不允许为空");
        CartItemQueryViewDTO queryViewDTO = CartItemQueryViewDTO.builder().idList(ids).statusList(Collections.singletonList(BrandCartItemStatusEnum.ORDER_WAIT.getCode())).build();
        List<CartItemViewDTO> cartItemViewDTOList = cartItemRepository.findCartList(serviceContext, queryViewDTO);

        CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder().cartItemIds(cartItemViewDTOList.stream().map(CartItemViewDTO::getId).collect(Collectors.toList()))
                .campaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode()).onlineStatusList(BizCampaignToolsHelper.getCampaignOnlineStatusList()).build();
        List<CampaignViewDTO> campaignViewDTOList = campaignStructureQueryAbility.handle(serviceContext,
                CampaignStructureQueryAbilityParam.builder().abilityTarget(campaignQueryViewDTO).queryOption(CampaignQueryOption.builder().build()).build());
        AssertUtil.notEmpty(campaignViewDTOList,"计划不存在");

        //下单参数校验
        validateCartItemOrder(serviceContext, cartItemViewDTOList, campaignViewDTOList);

        //创建订单
        CampaignGroupViewDTO campaignGroupViewDTO = new CampaignGroupViewDTO();

        //是否极简投放加购行
        boolean isSlimOrder = cartItemViewDTOList.stream().allMatch(cartItemViewDTO ->
                BrandCartItemTypeEnum.SLIM_ORDER.getCode().equals(cartItemViewDTO.getType()));
        campaignGroupViewDTO.setSource(isSlimOrder ? BrandCampaignGroupSourceEnum.SLIM_ORDER.getCode()
                : BrandCampaignGroupSourceEnum.CART.getCode());
        campaignGroupViewDTO.setSourceIds(cartItemOrderViewDTO.getCartItemIds());
        List<CampaignGroupViewDTO> campaignGroupViewDTOList = bizCampaignGroupCommandWorkflow.addCampaignGroupForSelfService(serviceContext, campaignGroupViewDTO);
        CampaignGroupViewDTO subCampaignGroup = campaignGroupViewDTOList.stream().filter(campaignGroup -> BrandCampaignGroupLevelEnum.LEVEL_TWO.getCode()
                .equals(campaignGroup.getCampaignGroupLevel())).findFirst().orElse(null);
        AssertUtil.notNull(subCampaignGroup ,BrandOneBPBaseErrorCode.INTERNAL_ERROR,"订单创建失败");

        return subCampaignGroup.getId();
    }

    public void validateCartItemOrder(ServiceContext serviceContext, List<CartItemViewDTO> cartItemViewDTOList, List<CampaignViewDTO> campaignViewDTOList){
        AssertUtil.notEmpty(cartItemViewDTOList,"加购行不存在");
        // 新老客
        cartItemCustomerJudgeAbility.handle(serviceContext, CartItemCustomerCheckAbilityParam.builder().abilityTarget(serviceContext.getMemberId()).actionEnum(CartActionEnum.ORDER).build());

        //加购行下单规则（计划询量周期单独处理）
        List<RuleCheckResultViewDTO> ruleCheckResultViewDTOList = checkCartItemOrder(serviceContext, cartItemViewDTOList, campaignViewDTOList);
        if(CollectionUtils.isNotEmpty(ruleCheckResultViewDTOList)){
            String noPassReason = ruleCheckResultViewDTOList.stream()
                    .filter(ruleCheckResultViewDTO -> BrandBoolEnum.BRAND_FALSE.getCode().equals(ruleCheckResultViewDTO.getIsPass()))
                    .filter(ruleCheckResultViewDTO -> !Objects.equals(CartOrderRuleTypeEnum.CAMPAIGN_INQUIRY_TIME_RULE.getValue(),ruleCheckResultViewDTO.getRuleType()))
                    .map(noPassRuleCheck -> String.format("%s:%s", noPassRuleCheck.getRuleName(), noPassRuleCheck.getReason()))
                    .collect(Collectors.joining("</br>"));
            AssertUtil.assertTrue(StringUtils.isBlank(noPassReason),BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR.of(noPassReason));

            noPassReason = ruleCheckResultViewDTOList.stream()
                    .filter(ruleCheckResultViewDTO -> BrandBoolEnum.BRAND_FALSE.getCode().equals(ruleCheckResultViewDTO.getIsPass()))
                    .filter(ruleCheckResultViewDTO -> Objects.equals(CartOrderRuleTypeEnum.CAMPAIGN_INQUIRY_TIME_RULE.getValue(), ruleCheckResultViewDTO.getRuleType()))
                    .map(noPassRuleCheck -> String.format("%s:%s", noPassRuleCheck.getRuleName(), noPassRuleCheck.getReason())).findFirst().orElse(null);
            AssertUtil.assertTrue(StringUtils.isBlank(noPassReason),BrandOneBPBaseErrorCode.OPERATION_FAILED_CALLBACK.of(noPassReason));
        }
    }

    /**
     * 购物车下单规则校验
     * @param context
     * @param cartItemViewDTOList
     * @return
     */
    public List<RuleCheckResultViewDTO> checkCartItemOrder(ServiceContext context, List<CartItemViewDTO> cartItemViewDTOList,List<CampaignViewDTO> campaignViewDTOList) {
        List<RuleCheckResultViewDTO> ruleCheckResultViewDTOList = Lists.newArrayList();

        List<Long> skuIdList = cartItemViewDTOList.stream().map(CartItemViewDTO::getSkuId).collect(Collectors.toList());
        List<BrandSkuViewDTO> skuViewDTOList = brandSkuRepository.findSkuList(context, skuIdList);
        //SKU上线状态判断
        RuleCheckResultViewDTO skuRuleJudge = cartItemSkuOnlineCheckForCartItemOrderAbility.handle(context,
                CartItemSkuOnlineOrderCheckAbilityParam.builder().abilityTargets(skuViewDTOList).build());
        Optional.ofNullable(skuRuleJudge).ifPresent(ruleCheckResultViewDTOList::add);

        //spu起投金额判断
        RuleCheckResultViewDTO spuStartBudgetRuleJudge = cartItemStartBudgetCheckForCartItemOrderAbility.handle(context,
                CartItemStartBudgetOrderCheckAbilityParam.builder().abilityTargets(cartItemViewDTOList).campaignViewDTOList(campaignViewDTOList).build());
        Optional.ofNullable(spuStartBudgetRuleJudge).ifPresent(ruleCheckResultViewDTOList::add);

        boolean isSlimOrder = cartItemViewDTOList.stream().anyMatch(cartItem -> BrandCartItemTypeEnum.SLIM_ORDER.getCode().equals(cartItem.getType()));
        CartItemCampaignOrderCheckAbilityParam campaignOrderCheckAbilityParam = CartItemCampaignOrderCheckAbilityParam.builder().abilityTargets(campaignViewDTOList)
                .isSlimOrder(isSlimOrder).build();
        //计划询锁量状态判断
        RuleCheckResultViewDTO campaignStatusRuleJudge = cartItemCampaignStatusCheckForCartItemOrderAbility.handle(context, campaignOrderCheckAbilityParam);
        Optional.ofNullable(campaignStatusRuleJudge).ifPresent(ruleCheckResultViewDTOList::add);

        //加购行一致性数据判断
        List<CartItemConsistencyCheckResultViewDTO> consistencyCheckResultViewDTOList = checkCartItemConsistency(context, cartItemViewDTOList, skuViewDTOList, campaignViewDTOList);
        RuleCheckResultViewDTO cartItemConsistencyRuleJudge = cartItemConsistencyCheckForCartItemOrderAbility.handle(context,
                CartItemConsistencyOrderCheckAbilityParam.builder().abilityTargets(consistencyCheckResultViewDTOList).build());
        Optional.ofNullable(cartItemConsistencyRuleJudge).ifPresent(ruleCheckResultViewDTOList::add);

        //其他规则判断通过后，在进行计划询量时间判断
        boolean otherAllPass = ruleCheckResultViewDTOList.stream().allMatch(ruleCheckResultViewDTO -> BrandBoolEnum.BRAND_TRUE.getCode().equals(ruleCheckResultViewDTO.getIsPass()));
        if(otherAllPass){
            RuleCheckResultViewDTO campaignInquiryTimeRuleJudge = cartItemCampaignInquiryTimeCheckForCartItemOrderAbility.handle(context, campaignOrderCheckAbilityParam);
            Optional.ofNullable(campaignInquiryTimeRuleJudge).ifPresent(ruleCheckResultViewDTOList::add);
        }
        return ruleCheckResultViewDTOList;
    }

    /**
     * 加购行数据一致性校验
     * @param context
     * @param cartItemViewDTOList
     * @param skuViewDTOList
     * @param campaignViewDTOList
     * @return
     */
    public List<CartItemConsistencyCheckResultViewDTO> checkCartItemConsistency(ServiceContext context, List<CartItemViewDTO> cartItemViewDTOList,
                                                                                List<BrandSkuViewDTO> skuViewDTOList, List<CampaignViewDTO> campaignViewDTOList){
        //计划相关信息有无变化
        Map<Long, List<CampaignViewDTO>> cartItemCampaignGroupMap = campaignViewDTOList.stream().collect(Collectors.groupingBy(
                campaignViewDTO -> campaignViewDTO.getCampaignSelfServiceViewDTO().getCartItemId()));

        Map<Long, BrandSkuViewDTO> skuViewDTOMap = Optional.ofNullable(skuViewDTOList).orElse(Lists.newArrayList()).stream()
                .collect(Collectors.toMap(BrandSkuViewDTO::getId, Function.identity()));

        List<Long> resourcePackageProductIds = Optional.ofNullable(skuViewDTOList).orElse(Lists.newArrayList()).stream()
                .map(BrandSkuViewDTO::getResourcePackageProductId).distinct().collect(Collectors.toList());
        List<ResourcePackageProductViewDTO> resourcePackageProductList = resourcePackageRepository.getLevelOneResourcePackageProductList(context, resourcePackageProductIds);
        Map<Long, ResourcePackageProductViewDTO> resourcePackageProductMap = Optional.ofNullable(resourcePackageProductList).orElse(Lists.newArrayList())
                .stream().collect(Collectors.toMap(ResourcePackageProductViewDTO::getId, Function.identity()));

        List<CartItemConsistencyCheckResultViewDTO> consistencyCheckResultViewDTOList = Lists.newArrayList();
        for (CartItemViewDTO cartItemViewDTO : cartItemViewDTOList) {
            List<CampaignViewDTO> cartItemCampaignViewDTOList = cartItemCampaignGroupMap.getOrDefault(cartItemViewDTO.getId(), Lists.newArrayList());
            ResourcePackageProductViewDTO resourcePackageProductViewDTO =
                    Optional.ofNullable(skuViewDTOMap.get(cartItemViewDTO.getSkuId())).map(BrandSkuViewDTO::getResourcePackageProductId).map(resourcePackageProductMap::get).orElse(null);
            CartItemConsistencyCheckResultViewDTO cartItemConsistencyCheckResultViewDTO = getCartItemConsistencyCheckResult(context, cartItemViewDTO, resourcePackageProductViewDTO, cartItemCampaignViewDTOList);
            consistencyCheckResultViewDTOList.add(cartItemConsistencyCheckResultViewDTO);
        }
        return consistencyCheckResultViewDTOList;
    }

    /**
     * 查询单个加购行数据一致性校验结果
     * @param context
     * @param cartItemViewDTO
     * @param resourcePackageProductViewDTO
     * @param campaignViewDTOList
     * @return
     */
    private CartItemConsistencyCheckResultViewDTO getCartItemConsistencyCheckResult(ServiceContext context,CartItemViewDTO cartItemViewDTO,
                                                                                    ResourcePackageProductViewDTO resourcePackageProductViewDTO,List<CampaignViewDTO> campaignViewDTOList){
        List<CartItemCampaignConsistencyCheckResultViewDTO> consistencyCheckResultList = Lists.newArrayList();
        for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
            List<RuleCheckResultViewDTO> invokeResultViewDTOList = Lists.newArrayList();
            CartItemCampaignConsistencyCheckAbilityParam checkAbilityParam = CartItemCampaignConsistencyCheckAbilityParam.builder().abilityTarget(campaignViewDTO)
                    .resourcePackageProductViewDTO(resourcePackageProductViewDTO).build();

            RuleCheckResultViewDTO priceCheckResultViewDTO = cartItemCampaignPriceConsistencyCheckAbility.handle(context, checkAbilityParam);
            Optional.ofNullable(priceCheckResultViewDTO).ifPresent(invokeResultViewDTOList::add);

            RuleCheckResultViewDTO crowdCheckResultViewDTO = cartItemCampaignCrowdConsistencyCheckAbility.handle(context, checkAbilityParam);
            Optional.ofNullable(crowdCheckResultViewDTO).ifPresent(invokeResultViewDTOList::add);

            boolean isNoPass = invokeResultViewDTOList.stream().anyMatch(checkResultViewDTO -> BrandBoolEnum.BRAND_FALSE.getCode().equals(checkResultViewDTO.getIsPass()));

            CartItemCampaignConsistencyCheckResultViewDTO consistencyCheckResultViewDTO = CartItemCampaignConsistencyCheckResultViewDTO.builder()
                    .cartItemId(campaignViewDTO.getCampaignSelfServiceViewDTO().getCartItemId()).campaignId(campaignViewDTO.getId())
                    .ruleCheckResultViewDTOList(invokeResultViewDTOList).isPass(BrandBoolEnum.BRAND_TRUE.getCode()).build();
            if(isNoPass){
                String noPassRuleName = invokeResultViewDTOList.stream().filter(checkResultViewDTO -> BrandBoolEnum.BRAND_FALSE.getCode().equals(checkResultViewDTO.getIsPass()))
                        .map(RuleCheckResultViewDTO::getRuleName).collect(Collectors.joining("、"));
                consistencyCheckResultViewDTO.setReason(String.format("%s已发生变化，请及时处理",noPassRuleName));
                consistencyCheckResultViewDTO.setIsPass(BrandBoolEnum.BRAND_FALSE.getCode());
            }
            consistencyCheckResultList.add(consistencyCheckResultViewDTO);
        }
        RogerLogger.info("cartItem consistencyCheckResultList = {}", JSON.toJSONString(consistencyCheckResultList));
        //加购行数据一致性结果汇总
        boolean isNoPass = consistencyCheckResultList.stream().anyMatch(checkResultViewDTO -> BrandBoolEnum.BRAND_FALSE.getCode().equals(checkResultViewDTO.getIsPass()));
        CartItemConsistencyCheckResultViewDTO cartItemConsistencyCheckResultViewDTO = CartItemConsistencyCheckResultViewDTO.builder()
                .cartItemId(cartItemViewDTO.getId()).campaignCheckResultViewDTOList(consistencyCheckResultList)
                .isPass(BrandBoolEnum.BRAND_TRUE.getCode()).build();
        if(isNoPass){
            cartItemConsistencyCheckResultViewDTO.setIsPass(BrandBoolEnum.BRAND_FALSE.getCode());
            cartItemConsistencyCheckResultViewDTO.setReason("相关计划已发送变化，请及时处理");
        }
        return cartItemConsistencyCheckResultViewDTO;
    }

    public void saveCustomerContact(ServiceContext context, CustomerContactViewDTO customerContactViewDTO) {
        validateForSaveCustomerContact(context, customerContactViewDTO);
        RogerLogger.info("客户保存了联系方式, context {} , customerContactViewDTO {}", JSONObject.toJSONString(context), JSONObject.toJSONString(customerContactViewDTO));
        customerRepository.saveCustomerContact(context, customerContactViewDTO);
    }

    private void validateForSaveCustomerContact(ServiceContext context, CustomerContactViewDTO customerContactViewDTO) {
        AssertUtil.notNull(customerContactViewDTO,"参数不能为空");
        AssertUtil.notNull(customerContactViewDTO.getName(),"称呼不能为空");
        AssertUtil.notNull(customerContactViewDTO.getPhone(),"联系电话不能为空");
    }
}
