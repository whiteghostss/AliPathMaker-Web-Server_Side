package com.taobao.ad.brand.bp.app.service.creative;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.utils.AbilityInvoker;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.app.businessability.SmartCreativeBusinessAbility;
import com.taobao.ad.brand.bp.app.workflow.creative.BizCreativeCommandWorkflow;
import com.taobao.ad.brand.bp.client.api.creative.BizCreativeValidateService;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeValidateViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.MemberPageCheckViewDTO;
import com.taobao.ad.brand.bp.client.dto.template.ErrorMessageViewDTO;
import com.taobao.ad.brand.bp.client.dto.template.TemplateViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeRepository;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeTemplateRepository;
import com.taobao.ad.brand.bp.domain.creative.spi.BizCreativeSpi;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbilityRouteContext;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.ICreativeLandingPageValidateAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeLandingPageValidateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.creative.businessability.ICreativePreCheckBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.uic.UicRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.common.spi.ExtensionPointsFactory.runAbilitySpi;

/**
 * @author ：PhilipFry
 * @date ：Created in 2023/3/31 11:18
 * @description ：
 * @modified By：
 */
@HSFProvider(serviceInterface = BizCreativeValidateService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizCreativeValidateServiceImpl implements BizCreativeValidateService {

    private final CreativeTemplateRepository creativeTemplateRepository;
    private final CreativeRepository creativeRepository;
    private final UicRepository uicRepository;
    private final ICreativeLandingPageValidateAbility creativeLandingPageValidateAbility;
    private final BizCreativeCommandWorkflow bizCreativeCommandWorkflow;

    @Override
    public SingleResponse<Boolean> checkLandingPage(ServiceContext context, String landingPage) {
        creativeLandingPageValidateAbility.handle(context, CreativeLandingPageValidateAbilityParam.builder()
                .abilityTarget(landingPage).build());
        return SingleResponse.of(Boolean.TRUE);
    }

    @Override
    public SingleResponse<CreativeValidateViewDTO> checkCreative(ServiceContext serviceContext, CreativeViewDTO creativeViewDTO) {
        return SingleResponse.of(bizCreativeCommandWorkflow.checkCreative(serviceContext, creativeViewDTO));
    }

    @Override
    public SingleResponse<CreativeValidateViewDTO> preCheckCreative(ServiceContext context, CreativeViewDTO creativeViewDTO) {
        TemplateViewDTO creativeTemplate = creativeTemplateRepository.getTemplateById(context, creativeViewDTO.getCreativeTemplate().getSspTemplateId());
        CreativeValidateViewDTO result = new CreativeValidateViewDTO();
        result.setSspTemplateId(creativeTemplate.getId());
        result.setSspTemplateName(creativeTemplate.getName());
        if (creativeViewDTO.getId() == null) {
            return SingleResponse.of(result);
        }
        CreativeViewDTO dbCreativeViewDTO = creativeRepository.getCreativeById(context, creativeViewDTO.getId());
        if (dbCreativeViewDTO == null) {
            return SingleResponse.of(result);
        }
        List<ErrorMessageViewDTO> errorList = runAbilitySpi(BizCreativeSpi.class,
                extension -> extension.getCreativeRefuseMessage(context, creativeTemplate, dbCreativeViewDTO),
                BizCreativeSpi.getSpiBizCode(creativeViewDTO));

        //商业能力挂载
        AbilityInvoker.invokeAll(ICreativePreCheckBusinessAbilityPoint.class,
                BusinessAbilityRouteContext.builder().specifiedBusinessAbilityCodes(Lists.newArrayList(SmartCreativeBusinessAbility.ABILITY_CODE)).build(),
                callback -> callback.invokeForCreativePreCheck(context, dbCreativeViewDTO, creativeTemplate, errorList));

        if (CollectionUtils.isNotEmpty(errorList)) {
            result.setErrorList(errorList.stream().collect(Collectors.groupingBy(ErrorMessageViewDTO::getKey)).entrySet().stream().map(entry ->
                    new ErrorMessageViewDTO(entry.getKey(), entry.getValue().stream().map(ErrorMessageViewDTO::getMessage).collect(Collectors.joining(";")))).collect(Collectors.toList()));
        }
        return SingleResponse.of(result);
    }

    @Override
    public SingleResponse<MemberPageCheckViewDTO> memberPageCheck(ServiceContext serviceContext, Long sellerId) {
        AssertUtil.notNull(sellerId, "sellerId不能为空");
        MemberPageCheckViewDTO memberPageCheckViewDTO = uicRepository.memberPageCheck(serviceContext, sellerId);
        return SingleResponse.of(memberPageCheckViewDTO);
    }
}
