package com.taobao.ad.brand.bp.app.spi.campaign.inventory;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.nb.framework.core.AbilitySpi;
import com.alibaba.ad.nb.framework.core.annotation.Ability;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignInquiryOperateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignScheduleViewDTO;

import java.util.List;

@Ability(desc = "库存中心扩展点")
public interface BizCampaignInventorySpi extends AbilitySpi {
    // ==================== SPI支持扩展码（CampaignScheduleIsInventoryEnum）===================

    String NEED_INVENTORY = "NEED_INVENTORY";

    String NO_INVENTORY = "NO_INVENTORY";

    Void inventoryRequest(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO, List<CampaignViewDTO> campaignTreeViewDTOList, List<CampaignScheduleViewDTO> campaignScheduleViewDTOList);


    Void releaseCampaign(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList);
}
