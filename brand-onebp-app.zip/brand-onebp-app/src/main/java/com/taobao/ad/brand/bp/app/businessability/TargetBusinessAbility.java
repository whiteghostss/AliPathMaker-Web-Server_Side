package com.taobao.ad.brand.bp.app.businessability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.adgroup.crowd.AdgroupCrowdScenarioViewDTO;
import com.alibaba.ad.brand.dto.adgroup.crowd.AdgroupCrowdViewDTO;
import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.audience.CampaignTargetScenarioViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdScenarioViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdViewDTO;
import com.alibaba.ad.brand.dto.campaign.safeip.CampaignSafeIpViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.audience.field.BrandTargetTypeEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignShowConfigViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupOrderCommandViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.CrowdViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductDirectionViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.common.converter.campaign.CampaignViewPageConverter;
import com.taobao.ad.brand.bp.common.threadpooltask.CampaignTargetBatchAddTaskIdentifier;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.adgroup.repository.AdgroupRepository;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.campaign.spi.BizCampaignSplitSpi;
import com.taobao.ad.brand.bp.domain.dmp.CrowdRepository;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupCrowdTargetForAddAdgroupAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupCrowdTargetSupportJudgeAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.targets.IAdgroupCrowdTargetInitForAddAdgroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.targets.IAdgroupCrowdTargetSupportJudgeAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.targets.IAdgroupCrowdTargetValidateForAddAdgroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.businessability.IAdgroupAddBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.businessability.IAdgroupUpdateBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbilityRouteContext;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignUpdateJudgeForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignCrowdTargetForAddCampaignAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignCrowdTargetForUpdateCampaignAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignSafeIpAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignTargetForAddCampaignAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignTargetForUpdateCampaignAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignTargetShowConfigGetAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignTargetUpdateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignUpdateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignCrowdTargetValidateForOrderCampaignGroupAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.showconfig.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.targets.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.businessability.ICampaignAddBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.campaign.businessability.ICampaignQueryBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.campaign.businessability.ICampaignSplitSubCampaignBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.campaign.businessability.ICampaignUpdateBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.businessability.ICampaignGroupOrderBusinessAbilityPoint;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR;
import static com.taobao.ad.brand.bp.common.spi.ExtensionPointsFactory.runAbilitySpi;

@Component
@BusinessAbility(tag = TargetBusinessAbility.ABILITY_CODE, name = "定向投放商业能力", desc = "定向投放商业能力结构化实现类")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class TargetBusinessAbility implements
        ICampaignGroupOrderBusinessAbilityPoint,
        ICampaignQueryBusinessAbilityPoint,ICampaignAddBusinessAbilityPoint, ICampaignUpdateBusinessAbilityPoint, ICampaignSplitSubCampaignBusinessAbilityPoint,
        IAdgroupAddBusinessAbilityPoint, IAdgroupUpdateBusinessAbilityPoint {

    public static final String ABILITY_CODE = "BUSINESS_ABILITY_TARGET";

    private final ICampaignMultiMediaTargetValidateForAddCampaignAbility campaignMultiMediaTargetValidateForAddCampaignAbility;
    private final ICampaignMultiMediaTargetValidateForUpdateCampaignAbility campaignMultiMediaTargetValidateForUpdateCampaignAbility;
    private final ICampaignCrowdTargetValidateForAddCampaignAbility campaignCrowdTargetValidateForAddCampaignAbility;
    private final ICampaignCrowdTargetValidateForUpdateCampaignAbility campaignCrowdTargetValidateForUpdateCampaignAbility;
    private final ICampaignCrowdTargetInitForUpdateCampaignAbility campaignCrowdTargetInitForUpdateCampaignAbility;
    private final ICampaignMultiMediaTargetInitForUpdateCampaignAbility campaignMultiMediaTargetInitForUpdateCampaignAbility;
    private final ICampaignTimePlusTargetValidateForUpdateCampaignAbility campaignTimePlusTargetValidateForUpdateCampaignAbility;
    private final ICampaignMediaTimePlusTargetValidateForUpdateCampaignAbility campaignMediaTimePlusTargetValidateForUpdateCampaignAbility;
    private final ICampaignCategoryTargetValidateForUpdateCampaignAbility campaignCategoryTargetValidateForUpdateCampaignAbility;
    private final ICampaignCrowdTargetInitForAddCampaignAbility campaignCrowdTargetInitForAddCampaignAbility;
    private final ICampaignTargetValidateForUpdateCampaignTargetAbility campaignTargetValidateForUpdateCampaignTargetAbility;
    private final ICampaignSafeIpInitAbility campaignSafeIpInitAbility;
    private final ICampaignUpdateJudgeForUpdateCampaignAbility campaignUpdateJudgeForUpdateCampaignAbility;

    private final ICampaignCrowdTargetValidateForOrderCampaignGroupAbility campaignCrowdTargetValidateForOrderCampaignGroupAbility;

    private final ICampaignAgeTargetBuildForShowConfigGetAbility campaignAgeTargetBuildForShowConfigGetAbility;
    private final ICampaignAppVersionTargetBuildForShowConfigGetAbility campaignAppVersionTargetBuildForShowConfigGetAbility;
    private final ICampaignAreaTargetBuildForShowConfigGetAbility campaignAreaTargetBuildForShowConfigGetAbility;
    private final ICampaignCategoryTargetBuildForShowConfigGetAbility campaignCategoryTargetBuildForShowConfigGetAbility;
    private final ICampaignCrowdScoreTargetBuildForShowConfigGetAbility campaignCrowdScoreTargetBuildForShowConfigGetAbility;
    private final ICampaignCrowdTargetBuildForShowConfigGetAbility campaignCrowdTargetBuildForShowConfigGetAbility;
    private final ICampaignRecommendCrowdTargetBuildForShowConfigGetAbility campaignRecommendCrowdTargetBuildForShowConfigGetAbility;
    private final ICampaignDeviceTargetBuildForShowConfigGetAbility campaignDeviceTargetBuildForShowConfigGetAbility;
    private final ICampaignGenderTargetBuildForShowConfigGetAbility campaignGenderTargetBuildForShowConfigGetAbility;
    private final ICampaignMediaAreaTargetBuildForShowConfigGetAbility campaignMediaAreaTargetBuildForShowConfigGetAbility;
    private final ICampaignMediaCrowdTargetBuildForShowConfigGetAbility campaignMediaCrowdTargetBuildForShowConfigGetAbility;
    private final ICampaignMediaDeviceTargetBuildForShowConfigGetAbility campaignMediaDeviceTargetBuildForShowConfigGetAbility;
    private final ICampaignMediaInterestLabelTargetBuildForShowConfigGetAbility campaignMediaInterestLabelTargetBuildForShowConfigGetAbility;
    private final ICampaignMediaPositionTargetBuildForShowConfigGetAbility campaignMediaPositionTargetBuildForShowConfigGetAbility;
    private final ICampaignMediaTimePeriodTargetBuildForShowConfigGetAbility campaignMediaTimePeriodTargetBuildForShowConfigGetAbility;
    private final ICampaignModelTargetBuildForShowConfigGetAbility campaignModelTargetBuildForShowConfigGetAbility;
    private final ICampaignMultiMediaTargetBuildForShowConfigGetAbility campaignMultiMediaTargetBuildForShowConfigGetAbility;
    private final ICampaignOohJsdIndustryTargetBuildForShowConfigGetAbility campaignOohJsdIndustryTargetBuildForShowConfigGetAbility;
    private final ICampaignOohJsdOptimizedTargetBuildForShowConfigGetAbility campaignOohJsdOptimizedTargetBuildForShowConfigGetAbility;
    private final ICampaignPrecedenceTargetBuildForShowConfigGetAbility campaignPrecedenceTargetBuildForShowConfigGetAbility;
    private final ICampaignSplashAdSeqTargetBuildForShowConfigGetAbility campaignSplashAdSeqTargetBuildForShowConfigGetAbility;
    private final ICampaignTimeLengthTargetBuildForShowConfigGetAbility campaignTimeLengthTargetBuildForShowConfigGetAbility;
    private final ICampaignTimePeriodTargetBuildForShowConfigGetAbility campaignTimePeriodTargetBuildForShowConfigGetAbility;
    private final ICampaignUaTargetBuildForShowConfigGetAbility campaignUaTargetBuildForShowConfigGetAbility;
    private final IAdgroupCrowdTargetSupportJudgeAbility adgroupCrowdTargetSupportJudgeAbility;
    private final IAdgroupCrowdTargetInitForAddAdgroupAbility adgroupCrowdTargetInitForAddAdgroupAbility;
    private final IAdgroupCrowdTargetValidateForAddAdgroupAbility adgroupCrowdTargetValidateForAddAdgroupAbility;
    private final ICampaignDoohJsdDeviceTypeTargetBuildForShowConfigGetAbility campaignDoohJsdDeviceTypeTargetBuildForShowConfigGetAbility;

    private final CrowdRepository crowdRepository;
    private final CampaignRepository campaignRepository;
    private final AdgroupRepository adgroupRepository;
    private final CampaignTargetBatchAddTaskIdentifier campaignTargetBatchAddTaskIdentifier;
    private final CampaignViewPageConverter campaignViewPageConverter;

    @Override
    public boolean routeChecking(String bizCode, BaseViewDTO baseViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        List<String> specifiedBusinessCodes = businessAbilityRouteContext.getSpecifiedBusinessAbilityCodes();
        if (CollectionUtils.isNotEmpty(specifiedBusinessCodes) && specifiedBusinessCodes.contains(ABILITY_CODE)) {
            return true;
        }
        //资源包设置的定向投放
        List<CommonViewDTO> openTargetList = Optional.ofNullable(businessAbilityRouteContext.getResourcePackageProductViewDTO())
                .map(ResourcePackageProductViewDTO::getTargetList).orElse(Lists.newArrayList());
        if (CollectionUtils.isNotEmpty(openTargetList)) {
            return true;
        }
        //不在资源包管控的二级产品投放
        if (businessAbilityRouteContext.getProductViewDTO() != null) {
            return CollectionUtils.isNotEmpty(businessAbilityRouteContext.getProductViewDTO().getDirectionList());
        }
        return false;
    }

    /**
     * 定向投放高优执行
     * @return
     */
    @Override
    public Integer order() {
        return -1;
    }

    @Override
    public Void invokeForCampaignShowConfigGet(ServiceContext serviceContext, List<CampaignShowConfigViewDTO> showConfigViewDTOList, BusinessAbilityRouteContext routeContext) {
        Map<String, List<ProductDirectionViewDTO>> productDirectionMap = Maps.newHashMap();
        if (CollectionUtils.isNotEmpty(routeContext.getProductViewDTO().getDirectionList())) {
            productDirectionMap = routeContext.getProductViewDTO().getDirectionList().stream().collect(Collectors.toMap(ProductDirectionViewDTO::getValue, ProductDirectionViewDTO::getSubDirectionList));
        }
        Map<String, CommonViewDTO> packageProductTargetMap = Maps.newHashMap();
        if (CollectionUtils.isNotEmpty(routeContext.getResourcePackageProductViewDTO().getTargetList())) {
            packageProductTargetMap = routeContext.getResourcePackageProductViewDTO().getTargetList().stream()
                    .filter(target -> Boolean.TRUE.equals(target.getSelected())).collect(Collectors.toMap(CommonViewDTO::getValue, t -> t, (v1, v2) -> v2));
        }

        CampaignTargetShowConfigGetAbilityParam showConfigGetAbilityParam = CampaignTargetShowConfigGetAbilityParam.builder()
                .abilityTarget(routeContext.getResourcePackageProductViewDTO()).packageProductTargetMap(packageProductTargetMap)
                .productViewDTO(routeContext.getProductViewDTO()).productDirectionValueMap(productDirectionMap)
                .resourcePackageSaleGroupViewDTO(routeContext.getPackageSaleGroupViewDTO()).build();
        // 人群
        CampaignShowConfigViewDTO crowdShowConfigViewDTO = campaignCrowdTargetBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(crowdShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
        // showmax人群
        CampaignShowConfigViewDTO showmaxCrowdShowConfigViewDTO = campaignRecommendCrowdTargetBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(showmaxCrowdShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
        // 媒体人群
        CampaignShowConfigViewDTO mediaCrowdShowConfigViewDTO = campaignMediaCrowdTargetBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(mediaCrowdShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
        // 地域
        CampaignShowConfigViewDTO areaShowConfigViewDTO = campaignAreaTargetBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(areaShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
        // 媒体地域
        CampaignShowConfigViewDTO mediaAreaShowConfigViewDTO = campaignMediaAreaTargetBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(mediaAreaShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
        // 年龄
        CampaignShowConfigViewDTO ageShowConfigViewDTO = campaignAgeTargetBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(ageShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
        // 性别
        CampaignShowConfigViewDTO genderShowConfigViewDTO = campaignGenderTargetBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(genderShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
        // 设备机型
        CampaignShowConfigViewDTO modelShowConfigViewDTO = campaignModelTargetBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(modelShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
        // 素材时长
        CampaignShowConfigViewDTO timeLengthShowConfigViewDTO = campaignTimeLengthTargetBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(timeLengthShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
        // 终端
        CampaignShowConfigViewDTO deviceShowConfigViewDTO = campaignDeviceTargetBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(deviceShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
        // 媒体终端
        CampaignShowConfigViewDTO mediaDeviceShowConfigViewDTO = campaignMediaDeviceTargetBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(mediaDeviceShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
        // 时段
        CampaignShowConfigViewDTO timePeriodShowConfigViewDTO = campaignTimePeriodTargetBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(timePeriodShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
        // 媒体时段
        CampaignShowConfigViewDTO mediaTimePeriodShowConfigViewDTO = campaignMediaTimePeriodTargetBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(mediaTimePeriodShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
        // UA
        CampaignShowConfigViewDTO uaShowConfigViewDTO = campaignUaTargetBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(uaShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
        // APP版本
        CampaignShowConfigViewDTO appVersionShowConfigViewDTO = campaignAppVersionTargetBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(appVersionShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
        // 开屏刷次
        CampaignShowConfigViewDTO splashAdSeqShowConfigViewDTO = campaignSplashAdSeqTargetBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(splashAdSeqShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
        // 人群打分
        CampaignShowConfigViewDTO crowdScoreShowConfigViewDTO = campaignCrowdScoreTargetBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(crowdScoreShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
        // 媒体兴趣标签
        CampaignShowConfigViewDTO mediaInterestLabelShowConfigViewDTO = campaignMediaInterestLabelTargetBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(mediaInterestLabelShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
        // 位置位序
        CampaignShowConfigViewDTO precedenceShowConfigViewDTO = campaignPrecedenceTargetBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(precedenceShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
        // 媒体位置
        CampaignShowConfigViewDTO mediaPositionShowConfigViewDTO = campaignMediaPositionTargetBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(mediaPositionShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
        // 一购必现
        CampaignShowConfigViewDTO categoryShowConfigViewDTO = campaignCategoryTargetBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(categoryShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
        // 户外极速达优选
        CampaignShowConfigViewDTO oohJsdOptimizedShowConfigViewDTO = campaignOohJsdOptimizedTargetBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(oohJsdOptimizedShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
        // 户外极速达行业
        CampaignShowConfigViewDTO oohJsdIndustryShowConfigViewDTO = campaignOohJsdIndustryTargetBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(oohJsdIndustryShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
        // 户外极速达资源场景
        CampaignShowConfigViewDTO oohJsdDeviceTypeShowConfigViewDTO = campaignDoohJsdDeviceTypeTargetBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(oohJsdDeviceTypeShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
        // 媒体
        CampaignShowConfigViewDTO multiMediaShowConfigViewDTO = campaignMultiMediaTargetBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(multiMediaShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);

        return null;
    }

    @Override
    public Void invokeForCampaignAdd(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        // 只有一级计划需要进行校验和初始化动作，二级计划会在计划拆分链路中进行数据设置
        if (BrandCampaignLevelEnum.LEVEL_TWO_CAMPAIGN.getCode().equals(campaignViewDTO.getCampaignLevel())) {
            return null;
        }
        CampaignTargetScenarioViewDTO campaignTargetScenarioViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignTargetScenarioViewDTO()).orElse(new CampaignTargetScenarioViewDTO());
        campaignViewDTO.setCampaignTargetScenarioViewDTO(campaignTargetScenarioViewDTO);
        CampaignCrowdScenarioViewDTO campaignCrowdScenarioViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignCrowdScenarioViewDTO()).orElse(new CampaignCrowdScenarioViewDTO());
        campaignViewDTO.setCampaignCrowdScenarioViewDTO(campaignCrowdScenarioViewDTO);
        CampaignSafeIpViewDTO campaignSafeIpViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignSafeIpViewDTO()).orElse(new CampaignSafeIpViewDTO());
        campaignViewDTO.setCampaignSafeIpViewDTO(campaignSafeIpViewDTO);
        //数据校验
        campaignMultiMediaTargetValidateForAddCampaignAbility.handle(serviceContext,CampaignTargetForAddCampaignAbilityParam.builder().abilityTarget(campaignTargetScenarioViewDTO)
               .resourcePackageProductViewDTO(businessAbilityRouteContext.getResourcePackageProductViewDTO()).build());

        List<CampaignCrowdViewDTO> campaignCrowdViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignCrowdScenarioViewDTO())
                .map(CampaignCrowdScenarioViewDTO::getCampaignCrowdViewDTOList).orElse(null);

        Map<Long, CrowdViewDTO> dmpCrowdMap = getDmpCrowdMap(serviceContext, campaignCrowdViewDTOList);
        campaignCrowdTargetValidateForAddCampaignAbility.handle(serviceContext,CampaignCrowdTargetForAddCampaignAbilityParam.builder().abilityTarget(campaignCrowdScenarioViewDTO)
                .productViewDTO(businessAbilityRouteContext.getProductViewDTO()).crowdViewDTOMap(dmpCrowdMap).campaignTargetScenarioViewDTO(campaignTargetScenarioViewDTO).build());

        //数据初始化
        campaignSafeIpInitAbility.handle(serviceContext,CampaignSafeIpAbilityParam.builder().abilityTarget(campaignSafeIpViewDTO).campaignViewDTO(campaignViewDTO).build());
        campaignCrowdTargetInitForAddCampaignAbility.handle(serviceContext,CampaignCrowdTargetForAddCampaignAbilityParam.builder().abilityTarget(campaignCrowdScenarioViewDTO)
                .productViewDTO(businessAbilityRouteContext.getProductViewDTO()).crowdViewDTOMap(dmpCrowdMap).build());

        return null;
    }

    @Override
    public Void invokeForAfterCampaignAdd(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList, BusinessAbilityRouteContext businessAbilityRouteContext) {
        List<Long> campaignIdList = TaskStream.execute(campaignTargetBatchAddTaskIdentifier, campaignViewDTOList, (campaign, index) -> {
            campaignRepository.addCampaignTarget(serviceContext, Lists.newArrayList(campaign));
            return campaign.getId();
        }).commit().getResultList();
        RogerLogger.info("计划定向保存成功，ids={}", JSON.toJSONString(campaignIdList));
        return null;
    }

    @Override
    public Void invokeForCampaignUpdate(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO,
                                        CampaignViewDTO dbCampaignTreeViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {

        // 只有一级计划需要进行校验和初始化动作，二级计划会在计划拆分链路中进行数据设置
        if (BrandCampaignLevelEnum.LEVEL_TWO_CAMPAIGN.getCode().equals(campaignViewDTO.getCampaignLevel())) {
            return null;
        }
        CampaignTargetScenarioViewDTO campaignTargetScenarioViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignTargetScenarioViewDTO()).orElse(new CampaignTargetScenarioViewDTO());
        campaignViewDTO.setCampaignTargetScenarioViewDTO(campaignTargetScenarioViewDTO);
        CampaignCrowdScenarioViewDTO campaignCrowdScenarioViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignCrowdScenarioViewDTO()).orElse(new CampaignCrowdScenarioViewDTO());
        campaignViewDTO.setCampaignCrowdScenarioViewDTO(campaignCrowdScenarioViewDTO);
        CampaignSafeIpViewDTO campaignSafeIpViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignSafeIpViewDTO()).orElse(new CampaignSafeIpViewDTO());
        campaignViewDTO.setCampaignSafeIpViewDTO(campaignSafeIpViewDTO);

        Map<Long, CrowdViewDTO> dmpCrowdMap = getDmpCrowdMap(serviceContext, campaignCrowdScenarioViewDTO.getCampaignCrowdViewDTOList());

        //定向校验
        campaignCrowdTargetValidateForAddCampaignAbility.handle(serviceContext, CampaignCrowdTargetForAddCampaignAbilityParam.builder().abilityTarget(campaignCrowdScenarioViewDTO)
                .productViewDTO(businessAbilityRouteContext.getProductViewDTO()).crowdViewDTOMap(dmpCrowdMap).campaignTargetScenarioViewDTO(campaignTargetScenarioViewDTO).build());

        campaignMultiMediaTargetValidateForAddCampaignAbility.handle(serviceContext, CampaignTargetForAddCampaignAbilityParam.builder().abilityTarget(campaignTargetScenarioViewDTO)
                .resourcePackageProductViewDTO(businessAbilityRouteContext.getResourcePackageProductViewDTO()).build());

        //计划是否允许修改
        Boolean isCanUpdateCampaign = campaignUpdateJudgeForUpdateCampaignAbility.handle(serviceContext, CampaignUpdateAbilityParam.builder()
                .abilityTarget(campaignViewDTO).dbCampaignViewDTO(dbCampaignTreeViewDTO).build());
        if(Boolean.FALSE.equals(isCanUpdateCampaign)){//计划不允许修改，需要校验以下定向
            campaignCrowdTargetValidateForUpdateCampaignAbility.handle(serviceContext, CampaignCrowdTargetForUpdateCampaignAbilityParam.builder().abilityTarget(campaignCrowdScenarioViewDTO)
                    .dbCampaignViewDTO(dbCampaignTreeViewDTO).crowdViewDTOMap(dmpCrowdMap).build());
            campaignTimePlusTargetValidateForUpdateCampaignAbility.handle(serviceContext,CampaignTargetForUpdateCampaignAbilityParam.builder().abilityTarget(campaignTargetScenarioViewDTO)
                    .dbCampaignViewDTO(dbCampaignTreeViewDTO).build());
            campaignMediaTimePlusTargetValidateForUpdateCampaignAbility.handle(serviceContext,CampaignTargetForUpdateCampaignAbilityParam.builder().abilityTarget(campaignTargetScenarioViewDTO)
                    .dbCampaignViewDTO(dbCampaignTreeViewDTO).build());
            campaignCategoryTargetValidateForUpdateCampaignAbility.handle(serviceContext,CampaignTargetForUpdateCampaignAbilityParam.builder().abilityTarget(campaignTargetScenarioViewDTO)
                    .dbCampaignViewDTO(dbCampaignTreeViewDTO).build());
        }
        // 针对全域通媒体定向的校验，判断条件较为特殊，故单列
        campaignMultiMediaTargetValidateForUpdateCampaignAbility.handle(serviceContext,CampaignTargetForUpdateCampaignAbilityParam.builder().abilityTarget(campaignTargetScenarioViewDTO)
                .dbCampaignViewDTO(dbCampaignTreeViewDTO).build());
        //定向初始化
        campaignMultiMediaTargetInitForUpdateCampaignAbility.handle(serviceContext, CampaignTargetForUpdateCampaignAbilityParam.builder().abilityTarget(campaignTargetScenarioViewDTO)
                .dbCampaignViewDTO(dbCampaignTreeViewDTO).build());

        campaignCrowdTargetInitForUpdateCampaignAbility.handle(serviceContext, CampaignCrowdTargetForUpdateCampaignAbilityParam.builder().abilityTarget(campaignCrowdScenarioViewDTO)
                .dbCampaignViewDTO(dbCampaignTreeViewDTO).crowdViewDTOMap(dmpCrowdMap).build());

        campaignSafeIpInitAbility.handle(serviceContext,CampaignSafeIpAbilityParam.builder().abilityTarget(campaignSafeIpViewDTO).campaignViewDTO(campaignViewDTO).build());

        return null;
    }

    @Override
    public Void invokeForAfterCampaignUpdate(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList, BusinessAbilityRouteContext businessAbilityRouteContext) {
        List<Long> campaignIdList = TaskStream.execute(campaignTargetBatchAddTaskIdentifier, campaignViewDTOList, (campaign, index) -> {
                    campaignRepository.updateCampaignTarget(serviceContext, Lists.newArrayList(campaign));
                    return campaign.getId();
                }).commit().getResultList();
        RogerLogger.info("计划定向更新成功，ids={}", JSON.toJSONString(campaignIdList));
        return null;
    }

    @Override
    public Void invokeForSubCampaignSplit(ServiceContext serviceContext, CampaignViewDTO campaignTreeViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        if(CollectionUtils.isEmpty(campaignTreeViewDTO.getSubCampaignViewDTOList())){
            return null;
        }
        List<CampaignCrowdViewDTO> campaignCrowdViewDTOList = Optional.ofNullable(campaignTreeViewDTO.getCampaignCrowdScenarioViewDTO())
                .map(CampaignCrowdScenarioViewDTO::getCampaignCrowdViewDTOList).orElse(null);
        Map<Long, CrowdViewDTO> dmpCrowdMap = getDmpCrowdMap(serviceContext, campaignCrowdViewDTOList);

        List<CampaignViewDTO> subCampaignViewDTOList = campaignTreeViewDTO.getSubCampaignViewDTOList();
        for (CampaignViewDTO campaignViewDTOForUpdate : subCampaignViewDTOList) {
            //复制一级计划，避免对象引用
            CampaignViewDTO copyCampaignViewDTO = campaignViewPageConverter.convertSelf(campaignTreeViewDTO);
            //定向初始化
            CampaignTargetScenarioViewDTO campaignTargetScenarioViewDTO = Optional.ofNullable(copyCampaignViewDTO.getCampaignTargetScenarioViewDTO()).orElse(new CampaignTargetScenarioViewDTO());
            campaignMultiMediaTargetInitForUpdateCampaignAbility.handle(serviceContext, CampaignTargetForUpdateCampaignAbilityParam.builder().abilityTarget(campaignTargetScenarioViewDTO).build());

            CampaignSafeIpViewDTO campaignSafeIpViewDTO = Optional.ofNullable(copyCampaignViewDTO.getCampaignSafeIpViewDTO()).orElse(new CampaignSafeIpViewDTO());
            campaignSafeIpInitAbility.handle(serviceContext,CampaignSafeIpAbilityParam.builder().abilityTarget(campaignSafeIpViewDTO)
                    .campaignViewDTO(campaignViewDTOForUpdate).build());

            CampaignCrowdScenarioViewDTO campaignCrowdScenarioViewDTO = Optional.ofNullable(copyCampaignViewDTO.getCampaignCrowdScenarioViewDTO()).orElse(new CampaignCrowdScenarioViewDTO());
            campaignCrowdTargetInitForUpdateCampaignAbility.handle(serviceContext, CampaignCrowdTargetForUpdateCampaignAbilityParam.builder().abilityTarget(campaignCrowdScenarioViewDTO)
                    .dbCampaignViewDTO(campaignViewDTOForUpdate).crowdViewDTOMap(dmpCrowdMap).build());

            campaignViewDTOForUpdate.getCampaignTargetScenarioViewDTO().setCampaignTargetViewDTOList(campaignTargetScenarioViewDTO.getCampaignTargetViewDTOList());
            campaignViewDTOForUpdate.getCampaignTargetScenarioViewDTO().setItemIdList(campaignTargetScenarioViewDTO.getItemIdList());
            campaignViewDTOForUpdate.setCampaignSafeIpViewDTO(campaignSafeIpViewDTO);
            campaignViewDTOForUpdate.setCampaignCrowdScenarioViewDTO(campaignCrowdScenarioViewDTO);
        }
        //价格波段、全域通场景差异化部分
        String splitSpiCode = BizCampaignSplitSpi.getSplitSpiCode(campaignTreeViewDTO, businessAbilityRouteContext.getResourcePackageProductViewDTO());
        runAbilitySpi(BizCampaignSplitSpi.class,
                extension->extension.fillSubCampaignTarget(serviceContext, campaignTreeViewDTO,businessAbilityRouteContext.getResourcePackageProductViewDTO()), splitSpiCode);
        return null;
    }

    @Override
    public Void invokeForCampaignTargetUpdatePart(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, CampaignViewDTO dbCampaignViewDTO, boolean updateSubCampaign) {
        //数据修改校验
        campaignTargetValidateForUpdateCampaignTargetAbility.handle(serviceContext,
                CampaignTargetUpdateAbilityParam.builder().abilityTarget(campaignViewDTO).build());
        //更新主计划定向
        campaignRepository.addOrUpdateCampaignTargetPart(serviceContext, campaignViewDTO);

        List<CampaignCrowdViewDTO> crowdTargetViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignCrowdScenarioViewDTO())
                .map(CampaignCrowdScenarioViewDTO::getCampaignCrowdViewDTOList).orElse(Lists.newArrayList());
        //更新子计划
        if(updateSubCampaign){
            List<CampaignViewDTO> subCampaignViewDTOList = Optional.ofNullable(dbCampaignViewDTO.getSubCampaignViewDTOList()).orElse(Lists.newArrayList());
            for (CampaignViewDTO dbSubCampaignViewDTO : subCampaignViewDTOList) {
                dbSubCampaignViewDTO.getCampaignTargetScenarioViewDTO().setCampaignTargetViewDTOList(campaignViewDTO.getCampaignTargetScenarioViewDTO().getCampaignTargetViewDTOList());
                CampaignCrowdScenarioViewDTO campaignCrowdScenarioViewDTO = Optional.ofNullable(dbSubCampaignViewDTO.getCampaignCrowdScenarioViewDTO()).orElse(new CampaignCrowdScenarioViewDTO());
                campaignCrowdScenarioViewDTO.setCampaignCrowdViewDTOList(crowdTargetViewDTOList);
                dbSubCampaignViewDTO.setCampaignCrowdScenarioViewDTO(campaignCrowdScenarioViewDTO);

                campaignRepository.addOrUpdateCampaignTargetPart(serviceContext, dbSubCampaignViewDTO);
            }
        }
        return null;
    }

    @Override
    public Void invokeForCampaignGroupOrder(ServiceContext serviceContext, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO, CampaignGroupViewDTO campaignGroupViewDTO,
                                            List<CampaignViewDTO> campaignList, List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupList,
                                            BusinessAbilityRouteContext businessAbilityRouteContext) {
        List<Long> checkedSaleGroupIds = campaignGroupOrderCommandViewDTO.getSaleGroupIds();
        List<ResourcePackageSaleGroupViewDTO> checkedResourcePackageSaleGroupList = Optional.ofNullable(resourcePackageSaleGroupList).orElse(Lists.newArrayList()).stream()
                .filter(resourcePackageSaleGroup -> checkedSaleGroupIds.contains(resourcePackageSaleGroup.getId()))
                .collect(Collectors.toList());
        campaignCrowdTargetValidateForOrderCampaignGroupAbility.handle(serviceContext, CampaignCrowdTargetValidateForOrderCampaignGroupAbilityParam.builder()
                .abilityTargets(campaignList).campaignGroupViewDTO(campaignGroupViewDTO).resourcePackageSaleGroupList(checkedResourcePackageSaleGroupList).build());

        return null;
    }

    @Override
    public Void invokeForAdgroupAdd(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, CampaignViewDTO campaignTreeViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        Boolean supportJudge = adgroupCrowdTargetSupportJudgeAbility.handle(serviceContext, AdgroupCrowdTargetSupportJudgeAbilityParam.builder().abilityTarget(adgroupViewDTO).build());
        if(!supportJudge){
            adgroupViewDTO.setAdgroupCrowdScenarioViewDTO(new AdgroupCrowdScenarioViewDTO());
            adgroupViewDTO.getAdgroupCrowdScenarioViewDTO().setCrowdTag(BrandBoolEnum.BRAND_FALSE.getCode());
            adgroupViewDTO.getAdgroupCrowdScenarioViewDTO().setAdgroupCrowdViewDTOList(Lists.newArrayList());
            return null;
        }
        List<AdgroupCrowdViewDTO> adgroupCrowdViewDTOList = Optional.ofNullable(adgroupViewDTO.getAdgroupCrowdScenarioViewDTO())
            .map(AdgroupCrowdScenarioViewDTO::getAdgroupCrowdViewDTOList).orElse(null);
        adgroupCrowdTargetInitForAddAdgroupAbility.handle(serviceContext, AdgroupCrowdTargetForAddAdgroupAbilityParam.builder().abilityTargets(adgroupCrowdViewDTOList)
            .adgroupViewDTO(adgroupViewDTO).campaignViewDTO(campaignTreeViewDTO).build());

        adgroupCrowdTargetValidateForAddAdgroupAbility.handle(serviceContext,AdgroupCrowdTargetForAddAdgroupAbilityParam.builder().abilityTargets(adgroupCrowdViewDTOList)
            .adgroupViewDTO(adgroupViewDTO).campaignViewDTO(campaignTreeViewDTO).build());
        return null;
    }

    @Override
    public Void invokeForAfterAdgroupAdd(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, CampaignViewDTO campaignTreeViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        //保存人群定向
        adgroupRepository.addAdgroupCrowdTarget(serviceContext, adgroupViewDTO);
        //更新单元人群标识
        adgroupRepository.batchUpdateAdgroupViewDTOCrowdTag(serviceContext, Lists.newArrayList(adgroupViewDTO));
        return null;
    }

    @Override
    public Void invokeForAdgroupUpdate(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, CampaignViewDTO campaignTreeViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        return this.invokeForAdgroupAdd(serviceContext, adgroupViewDTO, campaignTreeViewDTO, businessAbilityRouteContext);
    }

    @Override
    public Void invokeForAfterAdgroupUpdate(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, CampaignViewDTO campaignTreeViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        //更新人群定向
        adgroupRepository.updateAdgroupCrowdTarget(serviceContext, adgroupViewDTO);
        //更新单元人群标识
        adgroupRepository.batchUpdateAdgroupViewDTOCrowdTag(serviceContext, Lists.newArrayList(adgroupViewDTO));
        return null;
    }

    /**
     * 查询人群
     * @param serviceContext
     * @param campaignCrowdViewDTOList
     * @return
     */
    private Map<Long, CrowdViewDTO> getDmpCrowdMap(ServiceContext serviceContext,List<CampaignCrowdViewDTO> campaignCrowdViewDTOList) {
        //查询人群
        Map<Long, CrowdViewDTO> dmpCrowdMap = Maps.newHashMap();
        List<Long> crowdIds = Optional.ofNullable(campaignCrowdViewDTOList).orElse(Lists.newArrayList())
                .stream()
                .filter(target -> !Objects.equals(target.getTargetType(), BrandTargetTypeEnum.BRAND_ALGO_CROWD_NEW.getCode().longValue()))
                .filter(target -> !Objects.equals(target.getTargetType(),BrandTargetTypeEnum.ALGO_CONTROL_NO_TARGET_CROWD.getCode().longValue()))
                .map(CampaignCrowdViewDTO::getCrowdId).collect(Collectors.toList());
        if(CollectionUtils.isEmpty(crowdIds)){
            return dmpCrowdMap;
        }
        List<CrowdViewDTO> crowdViewDTOList = crowdRepository.queryCrowdByIds(serviceContext, crowdIds);
        AssertUtil.notEmpty(crowdViewDTOList,BIZ_BREAK_RULE_ERROR,"人群不存在或者已经过期，请检查人群信息");
        return crowdViewDTOList.stream().collect(Collectors.toMap(CrowdViewDTO::getCrowdId, Function.identity()));
    }
}
