package com.taobao.ad.brand.bp.app.handler.adgroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativeAuditSwitchEnum;
import com.alibaba.hermes.framework.ddd.event.annotation.DomainEventHandler;
import com.alibaba.hermes.framework.event.EventHandler;
import com.taobao.ad.brand.bp.app.workflow.creative.BizCreativeCommandWorkflow;
import com.taobao.ad.brand.bp.client.dto.template.TemplateViewDTO;
import com.taobao.ad.brand.bp.common.constant.CreativeConstant;
import com.taobao.ad.brand.bp.common.helper.schema.BizSchemaToolsHelper;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeTemplateRepository;
import com.taobao.ad.brand.bp.domain.event.adgroup.AdgroupWakeUpUpdateEvent;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Description:单元更新事件
 * <p>
 * date: 2022/1/21 2:56 下午
 *
 * @author shiyan
 * @version 1.0
 */
@Component
@RequiredArgsConstructor(onConstructor_ = @Autowired)
@DomainEventHandler(topic = "adgroup_wakeup_update_topic", event = AdgroupWakeUpUpdateEvent.class)
public class AdgroupWakeUpUpdateHandler implements EventHandler<AdgroupWakeUpUpdateEvent> {

    private final CreativeTemplateRepository creativeTemplateRepository;
    private final BizCreativeCommandWorkflow bizCreativeCommandWorkflow;

    @Override
    public Response handle(AdgroupWakeUpUpdateEvent adgroupWakeUpUpdateEvent) {
        AdgroupViewDTO adgroupViewDTO = adgroupWakeUpUpdateEvent.getContext().getAdgroupViewDTO();
        AdgroupViewDTO dbAdgroupViewDTO = adgroupWakeUpUpdateEvent.getContext().getAdgroupViewDTO();
        ServiceContext serviceContext = adgroupWakeUpUpdateEvent.getSource().getServiceContext();
        List<CreativeViewDTO> creativeViewDTOList = adgroupWakeUpUpdateEvent.getContext().getCreativeViewDTOList();
        boolean isEqual = BizSchemaToolsHelper.isEqual(adgroupViewDTO.getWakeupViewDTO(), dbAdgroupViewDTO.getWakeupViewDTO());
        if (isEqual || CollectionUtils.isEmpty(adgroupViewDTO.getCreativeRefViewDTOList())) {
            return  Response.success();
        }
        Long adgroupSchemaId = BizSchemaToolsHelper.getSchemaId(adgroupViewDTO.getWakeupViewDTO());
        // 过滤受影响的创意
        List<CreativeViewDTO> filterCreativeViewDTOList = creativeViewDTOList.stream()
                .filter(creative -> creative.getCreativeAudit().getMediaAudit() != null
                        && creative.getCreativeAudit().getMediaAudit().getAuditSwitch() != null
                        && !BrandCreativeAuditSwitchEnum.UNWANTED.getCode().equals(creative.getCreativeAudit().getMediaAudit().getAuditSwitch()))
                .filter(creative -> CreativeConstant.CREATIVE_NOT_YET_DELIVER_TO_MEDIA_STATUS_LIST.contains(creative.getCreativeAudit().getShowAuditStatus()))
                .filter(creative -> !Objects.equals(adgroupSchemaId, creative.getCreativeAudit().getMediaAudit().getSchemaId()))
                .collect(Collectors.toList());
        if (CollectionUtils.isEmpty(filterCreativeViewDTOList)) {
            return Response.success();
        }
        Map<Long, TemplateViewDTO> templateMap = creativeTemplateRepository.getTemplateByIds(serviceContext, filterCreativeViewDTOList.stream().map(creativeViewDTO -> creativeViewDTO.getCreativeTemplate().getSspTemplateId()).distinct().collect(Collectors.toList()))
                .stream().collect(Collectors.toMap(TemplateViewDTO::getId, Function.identity(), (a1, a2) -> a2));
        // 查询模板
        for (CreativeViewDTO creativeViewDTO : filterCreativeViewDTOList) {
            // 更新创意
            bizCreativeCommandWorkflow.updateMediaAudit(serviceContext, templateMap.get(creativeViewDTO.getCreativeTemplate().getSspTemplateId()), creativeViewDTO);
        }
        return Response.success();
    }
}
