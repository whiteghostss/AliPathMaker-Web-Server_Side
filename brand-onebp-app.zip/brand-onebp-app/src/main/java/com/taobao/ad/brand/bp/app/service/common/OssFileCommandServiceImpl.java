package com.taobao.ad.brand.bp.app.service.common;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Base64;
import java.util.Objects;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.client.api.common.OssFileCommandService;
import com.taobao.ad.brand.bp.client.dto.base.FileItemViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.oss.OssRepository;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import lombok.RequiredArgsConstructor;

/**
 * @author ximu
 * @date 2023/8/23
 */
@HSFProvider(serviceInterface = OssFileCommandService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class OssFileCommandServiceImpl implements OssFileCommandService {

    private final OssRepository ossRepository;

    @Override
    public SingleResponse<FileItemViewDTO> upload(ServiceContext serviceContext, FileItemViewDTO fileItemViewDTO) {
        AssertUtil.assertTrue(fileItemViewDTO != null, "文件上传参数异常");
        AssertUtil.assertTrue(fileItemViewDTO.getTmpOssUrl() != null || fileItemViewDTO.getData() != null || StringUtils.isNotBlank(fileItemViewDTO.getBase64Data()), "文件上传参数异常");
        AssertUtil.assertTrue(fileItemViewDTO.getName() != null, "文件上传参数异常");
        // 1. 下载临时oss地址对应的文件流
        byte[] content;
        try {
            content = getFileBytes(fileItemViewDTO);
        } catch (Exception e) {
            RogerLogger.error("file upload error {}", e.getMessage(), e);
            return SingleResponse.failureOf(BrandOneBPBaseErrorCode.EXTERNAL_ERROR);
        }
        // 2. 上传字节流到cdn
        if (content.length == 0) {
            return SingleResponse.failureOf(BrandOneBPBaseErrorCode.EXTERNAL_ERROR);
        }

        String url;
        if (Objects.equals(fileItemViewDTO.getNeedPermanentUrl(), true)) {
            url = ossRepository.uploadWithCDN(fileItemViewDTO.getUid(), content);
        } else {
            ossRepository.upload(fileItemViewDTO.getName(), fileItemViewDTO.getUid(), content);
            url = ossRepository.getTemporaryDownloadUrl(fileItemViewDTO.getUid(), fileItemViewDTO.getExpireTime());
        }

        fileItemViewDTO.setUrl(url);
        fileItemViewDTO.setData(null);
        return SingleResponse.of(fileItemViewDTO);
    }

    private byte[] getFileBytes(FileItemViewDTO fileItemViewDTO) throws MalformedURLException {
        if (fileItemViewDTO.getData() != null) {
            return fileItemViewDTO.getData();
        }

        if (StringUtils.isNotBlank(fileItemViewDTO.getBase64Data())) {
            // 解码Base64字符串
            return Base64.getDecoder().decode(fileItemViewDTO.getBase64Data());
        }

        return ossRepository.download(new URL(fileItemViewDTO.getTmpOssUrl()));
    }

}
