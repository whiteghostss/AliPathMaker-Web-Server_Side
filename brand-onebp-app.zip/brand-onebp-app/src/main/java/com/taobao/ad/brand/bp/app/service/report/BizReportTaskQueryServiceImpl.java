package com.taobao.ad.brand.bp.app.service.report;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.api.report.BizReportTaskQueryService;
import com.taobao.ad.brand.bp.client.dto.report.ReportTaskViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.query.ReportTaskQueryViewDTO;
import com.taobao.ad.brand.bp.domain.report.ability.BizReportTaskAbility;
import com.taobao.ad.brand.bp.domain.report.repository.ReportSyncTaskRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 报表异步任务查询相关服务
 * @author yuncheng.lyc
 */
@HSFProvider(serviceInterface = BizReportTaskQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizReportTaskQueryServiceImpl implements BizReportTaskQueryService {
    private final ReportSyncTaskRepository reportSyncTaskRepository;
    private final BizReportTaskAbility bizReportTaskAbility;
    @Override
    public MultiResponse<ReportTaskViewDTO> queryReportTaskList(ServiceContext context, ReportTaskQueryViewDTO queryViewDTO) {
        bizReportTaskAbility.validateReportTaskListQuery(context, queryViewDTO);
        return reportSyncTaskRepository.queryListWithPage(context, queryViewDTO);
    }

    @Override
    public SingleResponse<ReportTaskViewDTO> getReportTask(ServiceContext context, ReportTaskQueryViewDTO queryViewDTO) {
        bizReportTaskAbility.validateReportTaskQuery(context, queryViewDTO);
        return SingleResponse.of(reportSyncTaskRepository.get(context, queryViewDTO));
    }

    @Override
    public SingleResponse<String> exportReportTask(ServiceContext context, ReportTaskQueryViewDTO queryViewDTO) {
        bizReportTaskAbility.validateReportTaskQuery(context, queryViewDTO);
        ReportTaskViewDTO taskViewDTO = reportSyncTaskRepository.get(context, queryViewDTO);
        bizReportTaskAbility.validateReportTaskForExport(context, queryViewDTO, taskViewDTO);

        return SingleResponse.of(taskViewDTO.getOssUrl());
    }



}