package com.taobao.ad.brand.bp.app.service.campaigngroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.utils.AbilityInvoker;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupLevelEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupBusinessLineEnum;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignQueryWorkflow;
import com.taobao.ad.brand.bp.app.workflow.campaigngroup.BizCampaignGroupCommandWorkflow;
import com.taobao.ad.brand.bp.app.workflow.campaigngroup.BizCampaignGroupQueryWorkflow;
import com.taobao.ad.brand.bp.app.workflow.campaigngroup.BizScheduleExportWorkflow;
import com.taobao.ad.brand.bp.client.api.campaigngroup.BizCampaignGroupQueryService;
import com.taobao.ad.brand.bp.client.context.ScheduleExportContext;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.*;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.export.ScheduleExportQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignGroupBrandQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignGroupQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignGroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignGroupRealSettleQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignGroupSaleGroupBaseQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignGroupSaleGroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignGroupSettleQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.SaleGroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.salegroup.SaleGroupSelectJudgeViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.sales.CampaignGroupBriefViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.CrowdViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohCampaignViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.dto.shop.ShopViewDTO;
import com.taobao.ad.brand.bp.client.dto.talent.TalentViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupOpTypeEnum;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.SchemaEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.converter.campaigngroup.CampaignGroupSettleConverter;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.ability.BizCampaignGroupProcessAbility;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.SalesContractRepository;
import com.taobao.ad.brand.bp.domain.dmp.CrowdRepository;
import com.taobao.ad.brand.bp.domain.dooh.repository.DoohRepository;
import com.taobao.ad.brand.bp.domain.salegroup.converter.BizSaleGroupEstimateConverter;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbilityRouteContext;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupValidateForUnlockRevertAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupUnlockRevertAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupSelectJudgeForApplyModifyCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupSelectJudgeForOrderCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupOrderAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.businessability.ISaleGroupCanSelectStatusQueryBusinessAbilityPoint;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

@HSFProvider(serviceInterface = BizCampaignGroupQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizCampaignGroupQueryServiceImpl implements BizCampaignGroupQueryService {
    private final CampaignGroupRepository campaignGroupRepository;
    private final SalesContractRepository salesContractRepository;
    private final CrowdRepository crowdRepository;
    private final BizCampaignGroupProcessAbility bizCampaignGroupProcessAbility;
    private final BizCampaignQueryWorkflow bizCampaignQueryWorkflow;
    private final BizScheduleExportWorkflow bizScheduleExportWorkflow;
    private final CampaignGroupSettleConverter campaignGroupSettleConverter;
    private final BizCampaignGroupQueryWorkflow bizCampaignGroupQueryWorkflow;
    private final BizSaleGroupEstimateConverter bizSaleGroupEstimateConverter;

    private final BizCampaignGroupCommandWorkflow bizCampaignGroupCommandWorkflow;
    private final CampaignRepository campaignRepository;

    private final ICampaignGroupValidateForUnlockRevertAbility campaignGroupValidateForUnlockRevertAbility;
    private final ISaleGroupSelectJudgeForOrderCampaignGroupAbility saleGroupSelectJudgeForOrderCampaignGroupAbility;
    private final ISaleGroupSelectJudgeForApplyModifyCampaignGroupAbility saleGroupSelectJudgeForApplyModifyCampaignGroupAbility;

    @Value("${bp.adc.site.domain}")
    private String adcSiteDomain;

    private String reportBaseUrl = "https://%s/#!/report/%s/conclude/order?displayMode=table&indexType=impPv&keyword=&keywordType=campaignName&orderId=%d&tab=campaign";

    private final DoohRepository doohRepository;

    @Override
    public MultiResponse<CampaignGroupViewDTO> findCampaignGroupPageList(ServiceContext context, CampaignGroupQueryViewDTO campaignGroupQueryViewDTO, CampaignGroupQueryOption queryOption) {
        // 过滤受盘量优先级管控的订单
        if (queryOption != null && queryOption.isNeedInquiryPriorityFilter()) {
            campaignGroupQueryViewDTO.setLeInquiryDate(new Date());
        }
        PageResultViewDTO<CampaignGroupViewDTO> pageResultViewDTO = campaignGroupRepository.findCampaignGroupPageList(context, campaignGroupQueryViewDTO);
        return MultiResponse.of(pageResultViewDTO.getList(), pageResultViewDTO.getCount());
    }

    @Override
    public MultiResponse<CampaignGroupViewDTO> findCampaignGroupList(ServiceContext context, CampaignGroupQueryViewDTO campaignGroupQueryViewDTO) {
        // 过滤受盘量优先级管控的订单
        if (campaignGroupQueryViewDTO.getQueryOption() != null && campaignGroupQueryViewDTO.getQueryOption().isNeedInquiryPriorityFilter()) {
            campaignGroupQueryViewDTO.setLeInquiryDate(new Date());
        }
        List<CampaignGroupViewDTO> campaignGroupViewDTOList = campaignGroupRepository.findCampaignGroupList(context, campaignGroupQueryViewDTO);
        return MultiResponse.of(campaignGroupViewDTOList);
    }

    @Override
    public SingleResponse<CampaignGroupViewDTO> getCampaignGroupById(ServiceContext context, Long id) {
        CampaignGroupViewDTO campaignGroup = campaignGroupRepository.getCampaignGroup(context, id);
        return SingleResponse.of(campaignGroup);
    }

    @Override
    public MultiResponse<CampaignGroupViewDTO> findCampaignGroupListByBrandInfos(ServiceContext context, CampaignGroupBrandQueryViewDTO campaignGroupBrandQueryViewDTO) {
        AssertUtil.assertTrue(Objects.nonNull(campaignGroupBrandQueryViewDTO.getBrandId()), "品牌id不能为空");
        AssertUtil.assertTrue(Objects.nonNull(campaignGroupBrandQueryViewDTO.getStartTime()), "品牌startTime不能为空");
        AssertUtil.assertTrue(Objects.nonNull(campaignGroupBrandQueryViewDTO.getEndTime()), "品牌endTimeTime不能为空");
        AssertUtil.assertTrue(Objects.nonNull(context.getMemberId()), "memberId不能为空");
        CampaignGroupQueryViewDTO campaignGroupQueryViewDTO = new CampaignGroupQueryViewDTO();
        campaignGroupQueryViewDTO.setStartTime(campaignGroupBrandQueryViewDTO.getStartTime());
        campaignGroupQueryViewDTO.setEndTime(campaignGroupBrandQueryViewDTO.getEndTime());
        campaignGroupQueryViewDTO.setCampaignGroupLevel(campaignGroupBrandQueryViewDTO.getCampaignGroupLevel());
        //TODO:海成测试
//        if(Objects.isNull(campaignGroupQueryViewDTO.getCampaignGroupLevel())){
//            campaignGroupQueryViewDTO.setCampaignGroupLevel(BrandCampaignGroupLevelEnum.LEVEL_TWO.getCode());
//        }
        if(CollectionUtils.isNotEmpty(campaignGroupBrandQueryViewDTO.getSceneIds())){
            campaignGroupQueryViewDTO.setSceneIds(campaignGroupBrandQueryViewDTO.getSceneIds());
        }

        List<CampaignGroupViewDTO> campaignGroupViewDTOList = campaignGroupRepository.findCampaignGroupList(context, campaignGroupQueryViewDTO);
        if(CollectionUtils.isEmpty(campaignGroupViewDTOList)){
            return MultiResponse.of(Lists.newArrayList());
        }
        if(Objects.isNull(campaignGroupBrandQueryViewDTO.getBrandId())){
            return MultiResponse.of(campaignGroupViewDTOList);
        }
        List<Long> contractIds = campaignGroupViewDTOList.stream().filter(m->Objects.nonNull(m.getCampaignGroupContractViewDTO()) && Objects.nonNull(m.getCampaignGroupContractViewDTO().getContractId())).map(m->m.getCampaignGroupContractViewDTO().getContractId()).distinct().collect(Collectors.toList());
        Map<Long, List<SalesContractBrandViewDTO>> contractBrandMap = salesContractRepository.getContractBrandMap(contractIds);
        List<CampaignGroupViewDTO> campaignGroupViewDTOS = Lists.newArrayList();
        for(CampaignGroupViewDTO campaignGroupViewDTO: campaignGroupViewDTOList){
            Long contractId = campaignGroupViewDTO.getCampaignGroupContractViewDTO().getContractId();
            if(!contractBrandMap.containsKey(contractId)){
                continue;
            }
            List<SalesContractBrandViewDTO> contractBrandViewDTOList = contractBrandMap.get(contractId).stream().filter(m->m.getBrandId().equals(campaignGroupBrandQueryViewDTO.getBrandId())).collect(Collectors.toList());
            if(CollectionUtils.isNotEmpty(contractBrandViewDTOList)){
                campaignGroupViewDTOS.add(campaignGroupViewDTO);
            }
        }
        return MultiResponse.of(campaignGroupViewDTOS);
    }

    @Override
    public SingleResponse<CampaignGroupSettleInfoViewDTO> getCampaignGroupRealSettleInfos(ServiceContext context, CampaignGroupRealSettleQueryViewDTO realSettleQueryViewDTO) {
        AssertUtil.assertTrue(realSettleQueryViewDTO != null && realSettleQueryViewDTO.getId() != null, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "订单ID不能为空");
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(context, realSettleQueryViewDTO.getId());
        CampaignGroupSettleInfoViewDTO realSettleInfoViewDTO = bizCampaignGroupQueryWorkflow.getCampaignGroupRealSettleInfos(context, campaignGroupViewDTO, realSettleQueryViewDTO);
        return SingleResponse.of(realSettleInfoViewDTO);
    }

    @Override
    public SingleResponse<CampaignGroupSettleInfoViewDTO> getCampaignGroupSettleInfoForSettle(ServiceContext context, CampaignGroupSettleQueryViewDTO settleQueryViewDTO) {
        AssertUtil.assertTrue(settleQueryViewDTO != null && settleQueryViewDTO.getContractId() != null, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "主合同ID不能为空");
        // 根据主合同ID查询主订单
        CampaignGroupQueryViewDTO campaignGroupQueryViewDTO = new CampaignGroupQueryViewDTO();
        campaignGroupQueryViewDTO.setContractId(settleQueryViewDTO.getContractId());
        campaignGroupQueryViewDTO.setCampaignGroupLevel(BrandCampaignGroupLevelEnum.LEVEL_ONE.getCode());
        List<CampaignGroupViewDTO> campaignGroupViewDTOList = campaignGroupRepository.findCampaignGroupList(context, campaignGroupQueryViewDTO);
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(campaignGroupViewDTOList),BrandOneBPBaseErrorCode.BIZ_DATA_EMPTY_ERROR, "订单不存在");
        // 查询计划
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupViewDTOList.get(0);
        CampaignQueryViewDTO campaignQueryViewDTO = new CampaignQueryViewDTO();
        campaignQueryViewDTO.setMainCampaignGroupId(campaignGroupViewDTO.getId());
        campaignQueryViewDTO.setSubContractId(settleQueryViewDTO.getSubContractId());
        List<CampaignViewDTO> campaignList = findCampaignList(context, campaignQueryViewDTO);
        CampaignGroupSettleInfoViewDTO settleInfoViewDTO = campaignGroupSettleConverter.convertCampaignGroupSettleInfoViewDTO(campaignGroupViewDTO, campaignList, settleQueryViewDTO);
        return SingleResponse.of(settleInfoViewDTO);
    }

    /**
     * 查询单个订单，组合DB信息，资源包信息
     *
     * */
    @Override
    public SingleResponse<CampaignGroupResourcePackageViewDTO> getCampaignGroupWithSaleGroup(ServiceContext context,
        CampaignGroupSaleGroupQueryViewDTO queryViewDTO) {
        CampaignGroupResourcePackageViewDTO result =  bizCampaignGroupQueryWorkflow.getCampaignGroupDetailWithSaleGroup(context,queryViewDTO);
        return SingleResponse.of(result);
    }

    @Override
    public SingleResponse<Map<Long, SaleGroupCanDeleteViewDTO>> checkSaleGroupCanDelete(ServiceContext context, CampaignGroupSaleGroupBaseQueryViewDTO saleGroupQueryViewDTO) {
        AssertUtil.assertTrue(saleGroupQueryViewDTO != null, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "参数不能为空");
        AssertUtil.assertTrue(saleGroupQueryViewDTO.getId() != null, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "订单ID不能为空");
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(saleGroupQueryViewDTO.getSaleGroupIds()), BrandOneBPBaseErrorCode.PARAM_REQUIRED, "分组不能为空");
        ServiceContextUtil.reAssignServiceContext(context, BizCodeEnum.BRANDONEBP.getBizCode());
        // 查询相关联的子订单
        List<CampaignGroupViewDTO> subCampaignGroupList = getSubCampaignGroupList(context, saleGroupQueryViewDTO);
        Map<Long, SaleGroupCanDeleteViewDTO> saleGroupDeleteMap = bizCampaignGroupQueryWorkflow.checkSaleGroupCanDelete(context, subCampaignGroupList, saleGroupQueryViewDTO.getSaleGroupIds());
        return SingleResponse.of(saleGroupDeleteMap);
    }

    private List<CampaignGroupViewDTO> getSubCampaignGroupList(ServiceContext context, CampaignGroupSaleGroupBaseQueryViewDTO saleGroupQueryViewDTO) {
        CampaignGroupViewDTO campaignGroup = campaignGroupRepository.getCampaignGroup(context, saleGroupQueryViewDTO.getId());
        AssertUtil.notNull(campaignGroup, "订单不存在");
        if (BizCampaignGroupToolsHelper.isSubCampaignGroup(campaignGroup)) {
            return Lists.newArrayList(campaignGroup);
        }

        List<Integer> sceneIds = campaignGroup.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream()
                .filter(t -> saleGroupQueryViewDTO.getSaleGroupIds().contains(t.getSaleGroupId()))
                .map(SaleGroupInfoViewDTO::getSaleBusinessLine)
                .distinct()
                .collect(Collectors.toList());
        return campaignGroupRepository.findSubCampaignGroupList(context, campaignGroup.getId(), sceneIds);
    }

    @Override
    public MultiResponse<CampaignGroupSaleGroupPageViewDTO> findSaleGroupListWithCanSelectStatus(ServiceContext context, CampaignGroupSaleGroupQueryViewDTO campaignGroupQueryViewDTO) {
        AssertUtil.notNull(campaignGroupQueryViewDTO.getId(), "订单ID不能为空");
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(context, campaignGroupQueryViewDTO.getId());
        AssertUtil.notNull(campaignGroupQueryViewDTO.getId(), "订单不存在");
        List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList();
        if (CollectionUtils.isEmpty(saleGroupInfoViewDTOList)) {
            return MultiResponse.empty();
        }
        //查询资源包分组信息
        ResourcePackageQueryOption queryOption = ResourcePackageQueryOption.builder().needSetting(true).needProduct(true).needInquiryPriority(true).build();
        List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupList = bizCampaignGroupQueryWorkflow.findResourcePackageSaleGroupList(context, campaignGroupQueryViewDTO, campaignGroupViewDTO, queryOption);
        Map<Long, ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupMap = resourcePackageSaleGroupList.stream().collect(Collectors.toMap(ResourcePackageSaleGroupViewDTO::getId, Function.identity()));

        List<CampaignGroupSaleGroupPageViewDTO> campaignGroupSaleGroupPageViewDTOList = convertSaleGroupViewDTOResult(context, campaignGroupViewDTO);
        if (CollectionUtils.isEmpty(campaignGroupSaleGroupPageViewDTOList)) {
            return MultiResponse.empty();
        }
        // 打标是否支持分组勾选
        CampaignGroupOpTypeEnum opTypeEnum = CampaignGroupOpTypeEnum.getByValue(campaignGroupQueryViewDTO.getCampaignGroupOpType());
        List<Long> saleGroupIds = campaignGroupSaleGroupPageViewDTOList.stream().map(CampaignGroupSaleGroupPageViewDTO::getSaleGroupId).collect(Collectors.toList());
        if (opTypeEnum != null) {
            Map<Long, SaleGroupSelectJudgeViewDTO> saleGroupSelectJudgeMap = Maps.newHashMap();
            List<SaleGroupInfoViewDTO> selectSaleGroupInfoList = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream()
                    .filter(saleGroup -> saleGroupIds.contains(saleGroup.getSaleGroupId())).collect(Collectors.toList());
            if (opTypeEnum == CampaignGroupOpTypeEnum.ORDER) {
                saleGroupSelectJudgeMap = saleGroupSelectJudgeForOrderCampaignGroupAbility.handle(context, SaleGroupOrderAbilityParam.builder().abilityTargets(selectSaleGroupInfoList)
                        .campaignGroupViewDTO(campaignGroupViewDTO).build());
            } else if (opTypeEnum == CampaignGroupOpTypeEnum.MODIFY_ORDER) {
                saleGroupSelectJudgeMap = saleGroupSelectJudgeForApplyModifyCampaignGroupAbility.handle(context, SaleGroupOrderAbilityParam.builder().abilityTargets(selectSaleGroupInfoList)
                        .campaignGroupViewDTO(campaignGroupViewDTO).build());
            }

            Map<Long, SaleGroupSelectJudgeViewDTO> finalSaleGroupSelectJudgeMap = saleGroupSelectJudgeMap;
            campaignGroupSaleGroupPageViewDTOList.forEach(saleGroupPageViewDTO -> {
                if (!finalSaleGroupSelectJudgeMap.containsKey(saleGroupPageViewDTO.getSaleGroupId())) {
                    return;
                }
                SaleGroupSelectJudgeViewDTO selectJudgeViewDTO = finalSaleGroupSelectJudgeMap.get(saleGroupPageViewDTO.getSaleGroupId());
                saleGroupPageViewDTO.setCanSelect(selectJudgeViewDTO.getCanSelect());
                saleGroupPageViewDTO.setSelectReasonType(selectJudgeViewDTO.getSelectReasonType());
            });
        }

        //查询分组下的计划
        CampaignQueryViewDTO campaignQueryViewDTO = new CampaignQueryViewDTO();
        campaignQueryViewDTO.setSaleGroupIds(saleGroupIds);
        campaignQueryViewDTO.setCampaignGroupId(campaignGroupQueryViewDTO.getId());
        List<CampaignViewDTO> campaignViewDTOList = campaignRepository.queryCampaignList(context,campaignQueryViewDTO);
        Map<Long,List<CampaignViewDTO>> campaignMap = campaignViewDTOList.stream().collect(Collectors.groupingBy(item->item.getCampaignSaleViewDTO().getSaleGroupId()));
        Map<Long,SaleGroupInfoViewDTO> mapDBSaleGroup = saleGroupInfoViewDTOList.stream().collect(Collectors.toMap(SaleGroupInfoViewDTO::getSaleGroupId,Function.identity(),(v1,v2)->v1));

        // 设置分组名称
        campaignGroupSaleGroupPageViewDTOList.forEach(campaignGroupSaleGroupViewDTO -> {
            if (resourcePackageSaleGroupMap.containsKey(campaignGroupSaleGroupViewDTO.getSaleGroupId())) {
                ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO = resourcePackageSaleGroupMap.get(campaignGroupSaleGroupViewDTO.getSaleGroupId());
                SaleGroupInfoViewDTO dbSaleGroupInfoViewDTO = mapDBSaleGroup.get(campaignGroupSaleGroupViewDTO.getSaleGroupId());
                List<CampaignViewDTO> saleGroupCampaignViewDTOList = campaignMap.getOrDefault(campaignGroupSaleGroupViewDTO.getSaleGroupId(), Lists.newArrayList());

                campaignGroupSaleGroupViewDTO.setSaleGroupName(resourcePackageSaleGroupViewDTO.getName());
                if (campaignGroupSaleGroupViewDTO.getSaleType() == null) {
                    campaignGroupSaleGroupViewDTO.setSaleType(resourcePackageSaleGroupViewDTO.getSaleType());
                }
                //商业能力挂载
                BusinessAbilityRouteContext routeContext = BusinessAbilityRouteContext.builder().packageSaleGroupViewDTO(resourcePackageSaleGroupViewDTO).build();
                AbilityInvoker.invokeAll(ISaleGroupCanSelectStatusQueryBusinessAbilityPoint.class,routeContext,
                        callback -> callback.invokeForFindCanSelectStatusSaleGroup(context,campaignGroupSaleGroupViewDTO,dbSaleGroupInfoViewDTO,saleGroupCampaignViewDTOList,routeContext));
            }
        });

        //填充分组是否有更新
        bizCampaignGroupQueryWorkflow.fillSaleGroupHasUpdate(context, campaignGroupViewDTO, campaignGroupSaleGroupPageViewDTOList, resourcePackageSaleGroupList);

        return MultiResponse.of(campaignGroupSaleGroupPageViewDTOList, campaignGroupSaleGroupPageViewDTOList.size());
    }

    private List<CampaignGroupSaleGroupPageViewDTO> convertSaleGroupViewDTOResult(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO) {
        if (CollectionUtils.isEmpty(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList())) {
            return Lists.newArrayList();
        }
        return campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream().map(saleGroup -> {
            CampaignGroupSaleGroupPageViewDTO campaignGroupSaleGroupPageViewDTO = new CampaignGroupSaleGroupPageViewDTO();
            campaignGroupSaleGroupPageViewDTO.setSaleGroupId(saleGroup.getSaleGroupId());
            campaignGroupSaleGroupPageViewDTO.setSaleType(saleGroup.getSaleType());
            campaignGroupSaleGroupPageViewDTO.setSource(saleGroup.getSource());
            campaignGroupSaleGroupPageViewDTO.setSaleGroupStatus(saleGroup.getSaleGroupStatus());
            campaignGroupSaleGroupPageViewDTO.setMainGroupId(saleGroup.getMainSaleGroupId());
            campaignGroupSaleGroupPageViewDTO.setEstimateResult(bizSaleGroupEstimateConverter.convertDTO2ViewDTO(saleGroup));
            return campaignGroupSaleGroupPageViewDTO;
        }).collect(Collectors.toList());
    }

    @Override
    public Response canOrder(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO) {
        bizCampaignGroupCommandWorkflow.canOrder(context, campaignGroupOrderCommandViewDTO);
        return Response.success();
    }

    @Override
    public Response canUnlockRevert(ServiceContext context, Long id) {
        CampaignGroupViewDTO mainCampaignGroup = campaignGroupRepository.getCampaignGroup(context, id);
        AssertUtil.notNull(mainCampaignGroup, "订单不存在");
        // 校验是否支持撤销改单
        campaignGroupValidateForUnlockRevertAbility.handle(context, CampaignGroupUnlockRevertAbilityParam.builder().abilityTarget(mainCampaignGroup).build());
        return Response.success();
    }

    @Override
    public SingleResponse<String> exportSchedule(ServiceContext context, ScheduleExportQueryViewDTO scheduleExportQueryViewDTO) {
        bizScheduleExportWorkflow.validateQuery(scheduleExportQueryViewDTO);
        ScheduleExportContext scheduleExportContext = bizScheduleExportWorkflow.initContext(scheduleExportQueryViewDTO);
        String ossUrl = bizScheduleExportWorkflow.exportSchedule(context, scheduleExportContext);
        return SingleResponse.of(ossUrl);
    }

    @Override
    public MultiResponse<CampaignGroupSchemaViewDTO> findCampaignGroupSchemaList(ServiceContext context, CampaignGroupQueryViewDTO queryViewDTO) {

        SchemaEnum[] schemaEnums= SchemaEnum.values();
        List<CampaignGroupSchemaViewDTO> schemaList = Arrays.stream(schemaEnums).map(item->{
            CampaignGroupSchemaViewDTO schemaViewDTO =CampaignGroupSchemaViewDTO.builder().id((long)item.getValue()).name(item.getDesc()).openType(item.getOpenType()).build();
            return  schemaViewDTO;
        }).collect(Collectors.toList());

        return MultiResponse.of(schemaList);
    }

    @Override
    public SingleResponse<CampaignGroupSaleGroupCrowdInfoViewDTO> getSaleGroupCrowdList(ServiceContext serviceContext, Long campaignGroupId,Long saleGroupId) {
        AssertUtil.notNull(campaignGroupId,BrandOneBPBaseErrorCode.PARAM_REQUIRED, "订单不能为空");
        AssertUtil.notNull(saleGroupId, BrandOneBPBaseErrorCode.PARAM_REQUIRED,"分组不能为空");
        SaleGroupInfoViewDTO saleGroupInfoViewDTO = campaignGroupRepository.getSaleGroup(serviceContext,campaignGroupId,saleGroupId);
        AssertUtil.notNull(saleGroupInfoViewDTO,BrandOneBPBaseErrorCode.BIZ_DATA_EMPTY_ERROR,"售卖分组不存在，请检查");
        CampaignGroupSaleGroupCrowdInfoViewDTO campaignGroupSaleGroupCrowdInfoViewDTO = new CampaignGroupSaleGroupCrowdInfoViewDTO();
        if (CollectionUtils.isNotEmpty(saleGroupInfoViewDTO.getCrowdIds())) {
            List<CrowdViewDTO> crowdViewDTOS = crowdRepository.queryCrowdByIds(serviceContext, saleGroupInfoViewDTO.getCrowdIds());
            campaignGroupSaleGroupCrowdInfoViewDTO.setCrowdViewDTOList(crowdViewDTOS);
            campaignGroupSaleGroupCrowdInfoViewDTO.setCoverage(saleGroupInfoViewDTO.getCoverage());
        }
        return SingleResponse.of(campaignGroupSaleGroupCrowdInfoViewDTO);
    }

    @Override
    public SingleResponse<SaleGroupInfoViewDTO> getSaleGroup(ServiceContext serviceContext, Long campaignGroupId, Long resourceSaleGroupId) {
        SaleGroupInfoViewDTO saleGroupInfoViewDTO =  campaignGroupRepository.getSaleGroup(serviceContext, campaignGroupId, resourceSaleGroupId);
        return SingleResponse.of(saleGroupInfoViewDTO);
    }

    @Override
    public MultiResponse<SaleGroupInfoViewDTO> findSaleGroupList(ServiceContext serviceContext, SaleGroupQueryViewDTO saleGroupQueryViewDTO) {
        List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOS =  campaignGroupRepository.findSaleGroupList(serviceContext, saleGroupQueryViewDTO);
        return MultiResponse.of(saleGroupInfoViewDTOS);
    }

    @Override
    public SingleResponse<String> getCampaignGroupReportUrlForSale(ServiceContext context, Long campaignGroupId) {
        CampaignGroupViewDTO mainCampaignGroup = campaignGroupRepository.getCampaignGroup(context, campaignGroupId);
        AssertUtil.notNull(mainCampaignGroup, "订单不存在");
        String bizCode = ServiceContextUtil.getBizCode(mainCampaignGroup.getSceneId());
        Long orderId = campaignGroupId;
        if (BizCodeEnum.BRANDONEBP.getBizCode().equals(bizCode)) {
            List<CampaignGroupViewDTO> subCampaignGroupList = campaignGroupRepository.findSubCampaignGroupList(context, campaignGroupId);
            subCampaignGroupList = subCampaignGroupList.stream().filter(t -> !SaleGroupBusinessLineEnum.IP_MARKETING_AD.getValue().equals(t.getSceneId())).collect(Collectors.toList());
            if (CollectionUtils.isNotEmpty(subCampaignGroupList)) {
                CampaignGroupViewDTO subCampaignGroup = subCampaignGroupList.get(0);
                bizCode = ServiceContextUtil.getBizCode(subCampaignGroup.getSceneId());
                orderId = subCampaignGroup.getId();
            }
        }

        return SingleResponse.of(String.format(reportBaseUrl, adcSiteDomain, bizCode, orderId));
    }

    @Override
    public SingleResponse<ContractContentViewDTO> getContractContentInfo(ServiceContext context, Long mainCampaignGroupId) {
        CampaignGroupViewDTO mainCampaignGroup = campaignGroupRepository.getCampaignGroup(context, mainCampaignGroupId);
        AssertUtil.notNull(mainCampaignGroup, "订单不存在");
        List<CampaignGroupViewDTO> subCampaignGroupList = campaignGroupRepository.findSubCampaignGroupList(context, mainCampaignGroupId);
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(subCampaignGroupList) && subCampaignGroupList.size() == 1, "子订单不存在或不唯一");
        CampaignGroupViewDTO subCampaignGroupViewDTO = subCampaignGroupList.get(0);
        ServiceContext subContext = ServiceContextUtil.buildServiceContextForSceneId(context.getMemberId(), subCampaignGroupViewDTO.getSceneId());
        ContractContentViewDTO contractContentViewDTO = bizCampaignGroupQueryWorkflow.getContractContentInfo(subContext, subCampaignGroupViewDTO);
        return SingleResponse.of(contractContentViewDTO);
    }

    @Deprecated
    @Override
    public MultiResponse<TalentViewDTO> findTalentList(ServiceContext serviceContext, Long campaignGroupId) {
        return MultiResponse.empty();
    }

    @Override
    public SingleResponse<ShopViewDTO> getShopByCampaignGroupId(ServiceContext serviceContext, Long campaignGroupId) {
        ShopViewDTO shopViewDTO = campaignGroupRepository.getShopInfoByCampaignGroupId(serviceContext, campaignGroupId);
        return SingleResponse.of(shopViewDTO);
    }

    @Override
    public SingleResponse<String> exportScheduleInquiryResult(ServiceContext context, ScheduleExportQueryViewDTO scheduleExportQueryViewDTO) {
        AssertUtil.assertTrue(scheduleExportQueryViewDTO != null && scheduleExportQueryViewDTO.getCampaignGroupId() != null, "订单ID不能为空");
        CampaignQueryViewDTO queryViewDTO = new CampaignQueryViewDTO();
        queryViewDTO.setCampaignGroupId(scheduleExportQueryViewDTO.getCampaignGroupId());
        queryViewDTO.setCampaignIds(scheduleExportQueryViewDTO.getCampaignIdList());
        List<CampaignViewDTO> campaignViewDTOList = campaignRepository.queryCampaignList(context, queryViewDTO);
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(campaignViewDTOList), "计划不存在");
        List<CampaignViewDTO> doohCampaignList = campaignViewDTOList.stream().filter(e-> BizCampaignToolsHelper.isDoohCampaign(e.getCampaignResourceViewDTO().getSspProductLineId())).collect(Collectors.toList());
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(doohCampaignList), "仅支持天攻计划下载询锁量点位信息，请重新勾选");
        //一个订单下只有一个天攻的计划
        CampaignViewDTO campaignViewDTO = doohCampaignList.get(0);
        DoohCampaignViewDTO doohCampaignViewDTO = doohRepository.getCampaignById(campaignViewDTO.getCampaignDoohViewDTO().getDoohCampaignId());
        AssertUtil.assertTrue(doohCampaignViewDTO != null, "天攻计划不存在");
        String ossUrl = null;
        if(BrandCampaignStatusEnum.INQUIRY_SUCCESS.getCode().equals(campaignViewDTO.getStatus()) || BrandCampaignStatusEnum.INQUIRY_FAIL.getCode().equals(campaignViewDTO.getStatus())){
            ossUrl = doohCampaignViewDTO.getSearchResultOssUrl();
        }else{
            ossUrl = doohCampaignViewDTO.getLockResultOssUrl();
        }
        AssertUtil.assertTrue(ossUrl != null, "天攻计划询量或锁量点位信息暂未产出，请稍后重试");
        return SingleResponse.of(ossUrl);
    }

    private List<CampaignViewDTO> findCampaignList(ServiceContext context, CampaignQueryViewDTO query) {
        query.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
        CampaignQueryOption option = new CampaignQueryOption();
        return bizCampaignQueryWorkflow.getCampaignInfoListByOption(context, query, option);
    }

    @Override
    public SingleResponse<CampaignGroupBriefViewDTO> getCampaignGroupBriefInfo(ServiceContext context, Long campaignGroupId) {
        CampaignGroupBriefViewDTO campaignGroupBriefViewDTO = bizCampaignGroupQueryWorkflow.getCampaignGroupBriefInfo(context, campaignGroupId);
        return SingleResponse.of(campaignGroupBriefViewDTO);
    }

    @Override
    public MultiResponse<SalesContractBrandViewDTO> findCompleteBrandByShopId(ServiceContext context, Long shopId) {
        AssertUtil.notNull(shopId, "店铺ID不能为空");
        return MultiResponse.of(salesContractRepository.findBrandList(shopId));
    }

    @Override
    public MultiResponse<SalesContractAmountViewDTO> getContractAmountInfoList(ServiceContext context, List<Long> contractIds) {
        if (CollectionUtils.isEmpty(contractIds)) {
            return MultiResponse.empty();
        }
        List<SalesContractAmountViewDTO> contractAmountViewDTOS = salesContractRepository.getContractPayments(contractIds);
        return MultiResponse.of(contractAmountViewDTOS, contractAmountViewDTOS.size());
    }

    @Override
    public SingleResponse<String> getPaymentUrlByCampaignGroupId(ServiceContext serviceContext, Long campaignGroupId) {
        CampaignGroupViewDTO campaignGroup = campaignGroupRepository.getCampaignGroup(serviceContext, campaignGroupId);
        AssertUtil.notNull(campaignGroup, "订单不存在");
        AssertUtil.notNull(campaignGroup.getCampaignGroupContractViewDTO().getContractId(), "合同未生成");
        SalesContractViewDTO salesContractViewDTO = salesContractRepository.getSimpleContractInfo(campaignGroup.getCampaignGroupContractViewDTO().getContractId());
        String paymentUrl = salesContractRepository.createChargeUrl(serviceContext, salesContractViewDTO);
        return SingleResponse.of(paymentUrl);
    }
}