package com.taobao.ad.brand.bp.app.service.adgroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.sale.CampaignSaleViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.nb.ssp.constant.newproduct.ProductLineEnum;
import com.alibaba.ad.nb.user.client.constant.bizspace.BizAbilityEnum;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.fastjson.JSON;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.tool.lock.annotation.DistLock;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.app.interceptor.annotation.EnableOpLog;
import com.taobao.ad.brand.bp.app.workflow.adgroup.BizAdgroupCommandWorkflow;
import com.taobao.ad.brand.bp.app.workflow.creative.BizCreativeRefCommandWorkflow;
import com.taobao.ad.brand.bp.app.workflow.solution.BizSolutionCommandWorkflow;
import com.taobao.ad.brand.bp.client.api.adgroup.BizAdgroupNoticeCommandService;
import com.taobao.ad.brand.bp.client.dto.base.DRCMessageViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.media.MediaViewDTO;
import com.taobao.ad.brand.bp.client.dto.monitor.MonitorRuleXMediaViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignEventEnum;
import com.taobao.ad.brand.bp.client.enums.monitor.MonitorRuleXUnifiedMediaEnum;
import com.taobao.ad.brand.bp.client.enums.resource.ContentResourceTypeEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.adgroup.repository.AdgroupRepository;
import com.taobao.ad.brand.bp.domain.adgroup.spi.ContentAdgroupSplitSpi;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.media.MediaRepository;
import com.taobao.ad.brand.bp.domain.monitor.MonitorRepository;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.ssp.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

import static com.taobao.ad.brand.bp.common.spi.ExtensionPointsFactory.runAbilitySpi;

/**
 * @author ximu
 * @date 2023/7/26
 */
@HSFProvider(serviceInterface = BizAdgroupNoticeCommandService.class)
@RequiredArgsConstructor(onConstructor_ = @Autowired)
public class BizAdgroupNoticeCommandServiceImpl implements BizAdgroupNoticeCommandService {

    private final CampaignRepository campaignRepository;
    private final AdgroupRepository adgroupRepository;
    private final ProductRepository productRepository;
    private final ResourcePackageRepository resourcePackageRepository;
    private final MediaRepository mediaRepository;
    private final MonitorRepository monitorRepository;
    private final BizAdgroupCommandWorkflow bizAdgroupCommandWorkflow;
    private final BizSolutionCommandWorkflow bizSolutionCommandWorkflow;
    private final BizCreativeRefCommandWorkflow bizCreativeRefCommandWorkflow;
    private final ICampaignStructureQueryAbility campaignStructureQueryAbility;

    @Override
    public Response noticeContentCampaignChanged(ServiceContext serviceContext, Long campaignId, CampaignEventEnum eventEnum) {
        CampaignViewDTO campaignViewDTO = campaignRepository.getCampaignById(serviceContext, campaignId);
        if (campaignViewDTO == null) {
            RogerLogger.error("计划({})不存在", campaignId);
            return Response.success();
        }
        switch (eventEnum) {
            case CREATE:
            case UPDATE:
                List<AdgroupViewDTO> adgroupViewDTOList = splitAdgroup(serviceContext, campaignViewDTO);
                for (AdgroupViewDTO adgroupViewDTO : adgroupViewDTOList) {
                    if (adgroupViewDTO.getId() != null) {
                        bizAdgroupCommandWorkflow.updateAdgroup(serviceContext, adgroupViewDTO);
                    } else {
                        bizAdgroupCommandWorkflow.addAdgroup(serviceContext, adgroupViewDTO);
                    }
                }
                break;
            case DELETE:
                if (!Objects.equals(campaignViewDTO.getStatus(), BrandCampaignStatusEnum.DELETE.getCode())) {
                    RogerLogger.error("计划({})非删除状态", campaignId);
                    return Response.success();
                }
                adgroupRepository.deleteAdgroupByCampaignId(serviceContext, campaignId);
                break;
            default:
                break;
        }

        return Response.success();
    }


    /**
     * 拆分内容adgroup
     * @param serviceContext
     * @param campaignViewDTO
     * @return
     */
    private List<AdgroupViewDTO> splitAdgroup(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {
        RogerLogger.info("content campaign_group {} and campaign {} start split adgroup", campaignViewDTO.getCampaignGroupId(), campaignViewDTO.getId());
        CampaignSaleViewDTO campaignSaleViewDTO = campaignViewDTO.getCampaignSaleViewDTO();
        ResourcePackageSaleGroupViewDTO saleGroupViewDTO = resourcePackageRepository.getSaleGroupById(serviceContext, campaignSaleViewDTO.getSaleGroupId(), ResourcePackageQueryOption.builder().needSetting(true).build());
        Integer supplyType = saleGroupViewDTO.getSupplyType();
        RogerLogger.info("content campaign_group {} and campaign {} split supply_type {}", campaignViewDTO.getCampaignGroupId(), campaignViewDTO.getId(), supplyType);

        String resourceType = ContentResourceTypeEnum.COMMON.getSpiCode();
        if (Objects.equals(supplyType, BrandBoolEnum.BRAND_TRUE.getCode())) {
            // 派单
            ProductViewDTO productViewDTO = productRepository.getProductById(campaignViewDTO.getCampaignResourceViewDTO().getSspProductId());
            RogerLogger.info("content campaign_group {} and campaign {} split product_line_id {}", campaignViewDTO.getCampaignGroupId(), campaignViewDTO.getId(), productViewDTO.getProductLineId());
            // 达人资源
            if (productViewDTO.getProductLineId().equals(ProductLineEnum.UD_CONTENT_TOP_TALENT.getValue()) || productViewDTO.getProductLineId().equals(ProductLineEnum.UD_CONTENT_TALENT_CPM_PACKAGE.getValue())) {
                resourceType = ContentResourceTypeEnum.TALENT.getSpiCode();
            }
        }
        return runAbilitySpi(ContentAdgroupSplitSpi.class, extension -> extension.split(serviceContext, campaignViewDTO), resourceType);
    }

    @Override
    public Response noticeContentMonitorAddMedia(ServiceContext serviceContext, DRCMessageViewDTO drcMessageViewDTO) {
        RogerLogger.info("[noticeContentMonitorAddMedia DRC] {}", JSON.toJSONString(drcMessageViewDTO));
        drcMessageCheck(drcMessageViewDTO);
        MediaViewDTO source = JSON.parseObject(JSON.toJSONString(drcMessageViewDTO.getMsg().get(0)), MediaViewDTO.class);
        AssertUtil.notNull(source.getId(), "媒体ID不允许为空");
        List<MediaViewDTO> mediaViewDTOS = mediaRepository.queryMediaWithSettingByMediaIds(Lists.newArrayList(source.getId()));
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(mediaViewDTOS), "无可用媒体信息");
        MediaViewDTO mediaViewDTO = mediaViewDTOS.get(0);
        List<MonitorRuleXUnifiedMediaEnum> currMonitorRuleXUnifiedMediaEnums =  MonitorRuleXUnifiedMediaEnum.findRuleByUnifiedMediaId(mediaViewDTO.getUnifiedMediaId());
        if(CollectionUtils.isEmpty(currMonitorRuleXUnifiedMediaEnums)){
            return Response.success();
        }

        for (MonitorRuleXUnifiedMediaEnum ruleXMediaEnum : currMonitorRuleXUnifiedMediaEnums) {
            MonitorRuleXMediaViewDTO monitorRuleXMediaViewDTO = new MonitorRuleXMediaViewDTO();
            monitorRuleXMediaViewDTO.setMediaId(mediaViewDTO.getId());
            monitorRuleXMediaViewDTO.setAbilityCode(BizAbilityEnum.BRAND_CONTENT.getCode());
            monitorRuleXMediaViewDTO.setMonitorRuleId(ruleXMediaEnum.getMonitorRuleId());
            monitorRuleXMediaViewDTO.setMediaMemberId(mediaViewDTO.getMemberId());
            monitorRuleXMediaViewDTO.setMediaMonitorType(ruleXMediaEnum.getMediaMonitorType());
            monitorRepository.addMonitorRuleXMedia(serviceContext, monitorRuleXMediaViewDTO);
        }

        return Response.success();
    }

    @Override
    @EnableOpLog
    @DistLock(value = "noticeGenerateBottomAdgroup_distLock,1#toString()")
    public Response noticeGenerateBottomAdgroup(ServiceContext context, Long campaignId,CampaignEventEnum eventEnum) {
        if(CampaignEventEnum.LOCK_SUCCESS != eventEnum && CampaignEventEnum.ONLINE != eventEnum){
            return Response.success();
        }
        CampaignViewDTO parentCampaignViewDTO = this.getCampaignInfoByOption(context, campaignId,
                CampaignQueryOption.builder().needCampaignTree(true).build());
        AssertUtil.notNull(parentCampaignViewDTO,String.format("计划不存在，id=%s",campaignId));
        ServiceContextUtil.reAssignServiceContext(context,parentCampaignViewDTO.getSceneId());
        MultiResponse<AdgroupViewDTO> response = bizAdgroupCommandWorkflow.generateBottomAdgroup(context, parentCampaignViewDTO);
        if(CollectionUtils.isEmpty(response.getResult())){
            return response;
        }
        List<AdgroupViewDTO> adgroupViewDTOList = response.getResult();

        // 保存创意
        List<Long> creativeIds = bizSolutionCommandWorkflow.saveCreative(context, parentCampaignViewDTO);
        if (CollectionUtils.isNotEmpty(creativeIds)) {
            // 创意绑定到单元
            bizCreativeRefCommandWorkflow.batchBindCreative(context, adgroupViewDTOList, creativeIds);
        }

        return response;
    }

    @Override
    @DistLock(value = "noticeGenerateNReachAdgroup_distLock,1#toString()")
    public Response noticeGenerateNReachAdgroup(ServiceContext context, Long campaignId,CampaignEventEnum eventEnum) {
        if(CampaignEventEnum.LOCK_SUCCESS != eventEnum && CampaignEventEnum.ONLINE != eventEnum){
            return Response.success();
        }
        CampaignViewDTO parentCampaignViewDTO = this.getCampaignInfoByOption(context, campaignId,
                CampaignQueryOption.builder().needCampaignTree(true).build());
        AssertUtil.notNull(parentCampaignViewDTO,String.format("计划不存在，id=%s",campaignId));
        ServiceContextUtil.reAssignServiceContext(context,parentCampaignViewDTO.getSceneId());
        return bizAdgroupCommandWorkflow.generateNReachAdgroup(context,parentCampaignViewDTO);
    }

    /**
     * drc消息校验
     *
     * @param drcMessageDTO
     */
    private void drcMessageCheck(DRCMessageViewDTO drcMessageDTO) {
        Assert.notNull(drcMessageDTO, "DRC消息体不能为空");
        Assert.isTrue(StringUtils.isNotBlank(drcMessageDTO.getDbName()), "DRC消息体dbName不能为空");
        Assert.isTrue(StringUtils.isNotBlank(drcMessageDTO.getOpType()), "DRC消息体opType不能为空");
        Assert.isTrue(StringUtils.isNotBlank(drcMessageDTO.getTableName()), "DRC消息体tableName不能为空");
        Assert.isTrue(CollectionUtils.isNotEmpty(drcMessageDTO.getMsg()), "DRC消息体msg不能为空");
    }

    /**
     * 获取计划信息
     * @param serviceContext
     * @param id
     * @param option
     * @return
     */
    private CampaignViewDTO getCampaignInfoByOption(ServiceContext serviceContext,Long id,CampaignQueryOption option){
        CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder().campaignIds(Collections.singletonList(id)).build();
        List<CampaignViewDTO> dbCampaignViewDTOList = campaignStructureQueryAbility.handle(serviceContext,
                CampaignStructureQueryAbilityParam.builder().abilityTarget(campaignQueryViewDTO).queryOption(option).build());
        return org.apache.commons.collections4.CollectionUtils.isNotEmpty(dbCampaignViewDTOList) ? dbCampaignViewDTOList.get(0) : null;
    }
}
