package com.taobao.ad.brand.bp.app.service.common;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.common.TagViewDTO;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.taobao.ad.brand.bp.client.api.common.BizTagQueryService;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.tag.TagQueryViewDTO;
import com.taobao.ad.brand.bp.domain.tag.TagRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @Author: PhilipFry
 * @createTime: 2024年02月27日 20:17:06
 * @Description:
 */
@HSFProvider(serviceInterface = BizTagQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizTagQueryServiceImpl implements BizTagQueryService {
    private final TagRepository tagRepository;

    @Override
    public MultiResponse<TagViewDTO> findTagPage(ServiceContext context, TagQueryViewDTO query) {
        PageResultViewDTO<TagViewDTO> pageResult = tagRepository.findTagPage(context, query);
        return MultiResponse.of(pageResult.getList(), pageResult.getCount());
    }
}
