package com.taobao.ad.brand.bp.app.interceptor.annotation;

import java.lang.annotation.*;

/**
 * @author gxg
 * @desc 是否开启操作日志记录
 */
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD})
public @interface EnableOpLog {

}
