package com.taobao.ad.brand.bp.app.workflow.campaign;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.utils.AbilityInvoker;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.effect.CampaignEffectProxyViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.product.CastTypeEnum;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignEffectAdvViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignShowConfigQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignShowConfigViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignEffectAdvQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.effect.EffectAdvertiserContractFundViewDTO;
import com.taobao.ad.brand.bp.client.dto.effect.EffectAdvertiserViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductDirectionViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.common.threadpooltask.EffectADVQueryTaskIdentifier;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.SalesContractRepository;
import com.taobao.ad.brand.bp.domain.effect.EffectAdvertiserRepository;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbilityRouteContext;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignCastTypeShowConfigGetAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignTargetShowConfigGetAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignThirdMonitorFillForQueryCampaignAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.showconfig.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.thirdmonitor.ICampaignThirdMonitorFillForQueryCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.businessability.ICampaignQueryBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.ssp.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @description: CampaignSplitAbility
 * @date: 2023/3/1 15:18
 * @author: yuanxinxi
 * @version: 1.0
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizCampaignQueryWorkflow {

    private final CampaignRepository campaignRepository;
    private final EffectAdvertiserRepository effectAdvertiserRepository;
    private final SalesContractRepository salesContractRepository;
    private final ResourcePackageRepository resourcePackageRepository;
    private final ProductRepository productRepository;
    private final ICampaignStructureQueryAbility campaignStructureQueryAbility;
    private final EffectADVQueryTaskIdentifier effectADVQueryTaskIdentifier;
    private final ICampaignThirdMonitorFillForQueryCampaignAbility campaignThirdMonitorFillForQueryCampaignAbility;

    private final ICampaignCastTypeQueryForShowConfigGetAbility campaignCastTypeQueryForShowConfigGetAbility;
    private final ICampaignCopyOtherPubDealBuildForShowConfigGetAbility campaignCopyOtherPubDealBuildForShowConfigGetAbility;
    private final ICampaignCopyPubDealBuildForShowConfigGetAbility campaignCopyPubDealBuildForShowConfigGetAbility;
    private final ICampaignDoohStrategyBuildForShowConfigGetAbility campaignDoohStrategyBuildForShowConfigGetAbility;
    private final ICampaignDoohJsdStrategyMethodBuildForShowConfigGetAbility campaignDoohJsdStrategyMethodBuildForShowConfigGetAbility;
    private final ICampaignDspBuildForShowConfigGetAbility campaignDspBuildForShowConfigGetAbility;
    private final ICampaignOptimizeTargetTypeBuildForShowConfigGetAbility campaignOptimizeTargetTypeBuildForShowConfigGetAbility;
    private final ICampaignPdbCastTypeBuildForShowConfigGetAbility campaignPdbCastTypeBuildForShowConfigGetAbility;
    private final ICampaignPdCastTypeBuildForShowConfigGetAbility campaignPdCastTypeBuildForShowConfigGetAbility;
    private final ICampaignSaleUnitBuildForShowConfigGetAbility campaignSaleUnitBuildForShowConfigGetAbility;
    private final ICampaignTaoOutCptBuildForShowConfigGetAbility campaignTaoOutCptBuildForShowConfigGetAbility;
    private final ICampaignCompetExcludeBuildForShowConfigGetAbility campaignCompetExcludeBuildForShowConfigGetAbility;

    /**
     * 可能是主订单维度，涉及多个子订单的计划查询，所以按业务场景分组查询后再聚合
     *  组装完整的Campaign信息
     * @param  query
     *   @param   option
     */
    public List<CampaignViewDTO> getCampaignInfoListByOption(ServiceContext context, CampaignQueryViewDTO query, CampaignQueryOption option) {
        return campaignStructureQueryAbility.handle(context, CampaignStructureQueryAbilityParam.builder()
                .abilityTarget(query).queryOption(option).build());
    }

    /**
     * 组装完整的Campaign信息
     *
     * @param id
     * @param option
     */
    public CampaignViewDTO getCampaignInfoByOption(ServiceContext context, Long id, CampaignQueryOption option){
        CampaignQueryViewDTO queryViewDTO = CampaignQueryViewDTO.builder().campaignIds(Lists.newArrayList(id)).build();
        List<CampaignViewDTO> campaignViewDTOList = campaignStructureQueryAbility.handle(context, CampaignStructureQueryAbilityParam.builder()
                .abilityTarget(queryViewDTO).queryOption(option).build());
        if(CollectionUtils.isEmpty(campaignViewDTOList)){
            return null;
        }
        CampaignViewDTO campaignViewDTO = campaignViewDTOList.get(0);
        //补充分组支持的第三方监测配置信息
        if(Objects.nonNull(campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId())){
            ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO = resourcePackageRepository.getSaleGroupById(context, campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId(),
                ResourcePackageQueryOption.builder().needInquiryPriority(false).needProduct(false).needSetting(true).build());
            campaignThirdMonitorFillForQueryCampaignAbility.handle(context, CampaignThirdMonitorFillForQueryCampaignAbilityParam.builder()
                    .abilityTargets(Lists.newArrayList(campaignViewDTO)).resourcePackageSaleGroupViewDTO(resourcePackageSaleGroupViewDTO).build());
        }
        return campaignViewDTO;
    }

    /**
     * 获取计划支持配置维度数据
     * @param serviceContext
     * @param queryViewDTO
     * @return
     */
    public List<CampaignShowConfigViewDTO> getCampaignShowConfig(ServiceContext serviceContext, CampaignShowConfigQueryViewDTO queryViewDTO) {
        AssertUtil.notNull(queryViewDTO,"定向展示配置查询参数不能为空");
        AssertUtil.notNull(queryViewDTO.getResourcePackageProductId(),"定向展示配置二级产品ID不能为空");
        Long resourcePackageProductId = queryViewDTO.getResourcePackageProductId();
        ResourcePackageProductViewDTO resourcePackageProductViewDTO = resourcePackageRepository.getResourcePackageProduct(serviceContext, resourcePackageProductId);
        AssertUtil.notNull(resourcePackageProductViewDTO, "资源包二级产品不存在");
        ProductViewDTO productViewDTO = productRepository.getProductWithTargetValue(resourcePackageProductViewDTO.getSspProductId());
        ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO = resourcePackageRepository.getSaleGroupById(serviceContext, resourcePackageProductViewDTO.getSaleGroupId(),
                ResourcePackageQueryOption.builder().needInquiryPriority(false).needProduct(false).needSetting(true).build());

        //对客展示数据设置
        List<CampaignShowConfigViewDTO> showConfigViewDTOList = Lists.newArrayList();
        // 普通属性
        fillCommonShowConfigInfos(serviceContext, showConfigViewDTOList, resourcePackageProductViewDTO, productViewDTO, resourcePackageSaleGroupViewDTO);
        // 商业能力挂载点属性
        BusinessAbilityRouteContext businessAbilityRouteContext = BusinessAbilityRouteContext.builder()
                .productViewDTO(productViewDTO).resourcePackageProductViewDTO(resourcePackageProductViewDTO)
                .packageSaleGroupViewDTO(resourcePackageSaleGroupViewDTO).build();
        AbilityInvoker.invokeAll(ICampaignQueryBusinessAbilityPoint.class,businessAbilityRouteContext,
            callback -> callback.invokeForCampaignShowConfigGet(serviceContext, showConfigViewDTOList, businessAbilityRouteContext));

        return showConfigViewDTOList;
    }

    private void fillCommonShowConfigInfos(ServiceContext serviceContext, List<CampaignShowConfigViewDTO> showConfigViewDTOList,
                                              ResourcePackageProductViewDTO resourcePackageProductViewDTO,
                                              ProductViewDTO productViewDTO,
                                              ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO) {
        Map<String, List<ProductDirectionViewDTO>> productDirectionMap = Maps.newHashMap();
        if (CollectionUtils.isNotEmpty(productViewDTO.getDirectionList())) {
            productDirectionMap = productViewDTO.getDirectionList().stream().collect(Collectors.toMap(ProductDirectionViewDTO::getValue, ProductDirectionViewDTO::getSubDirectionList));
        }
        Map<String, CommonViewDTO> packageProductTargetMap = Maps.newHashMap();
        if (CollectionUtils.isNotEmpty(resourcePackageProductViewDTO.getTargetList())) {
            packageProductTargetMap = resourcePackageProductViewDTO.getTargetList().stream()
                    .filter(target -> Boolean.TRUE.equals(target.getSelected())).collect(Collectors.toMap(CommonViewDTO::getValue, t -> t, (v1, v2) -> v2));
        }
        CampaignTargetShowConfigGetAbilityParam showConfigGetAbilityParam = CampaignTargetShowConfigGetAbilityParam.builder()
                .abilityTarget(resourcePackageProductViewDTO).packageProductTargetMap(packageProductTargetMap)
                .productViewDTO(productViewDTO).productDirectionValueMap(productDirectionMap)
                .resourcePackageSaleGroupViewDTO(resourcePackageSaleGroupViewDTO).build();

//TODO 暂时不支持        // 媒体频控
//        CampaignShowConfigViewDTO mediaFrequencyShowConfigViewDTO = campaignMediaFrequencyTargetBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
//        Optional.ofNullable(mediaFrequencyShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
        // 投放方式
        CampaignCastTypeShowConfigGetAbilityParam castTypeConfigGetAbilityParam = CampaignCastTypeShowConfigGetAbilityParam.builder()
                .abilityTarget(resourcePackageProductViewDTO)
                .productViewDTO(productViewDTO)
                .resourcePackageSaleGroupViewDTO(resourcePackageSaleGroupViewDTO).build();
        CastTypeEnum castTypeEnum = campaignCastTypeQueryForShowConfigGetAbility.handle(serviceContext, castTypeConfigGetAbilityParam);
        if (castTypeEnum != null) {
            castTypeConfigGetAbilityParam.setCastTypeEnum(castTypeEnum);
            // 预订方式
            CampaignShowConfigViewDTO saleUnitShowConfigViewDTO = campaignSaleUnitBuildForShowConfigGetAbility.handle(serviceContext, castTypeConfigGetAbilityParam);
            Optional.ofNullable(saleUnitShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
            // PD
            if (castTypeEnum == CastTypeEnum.PD || castTypeEnum == CastTypeEnum.PD_OR_PDB) {
                CampaignShowConfigViewDTO pdCastTypeShowConfigViewDTO = campaignPdCastTypeBuildForShowConfigGetAbility.handle(serviceContext, castTypeConfigGetAbilityParam);
                Optional.ofNullable(pdCastTypeShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
            }
            // PDB
            if (castTypeEnum == CastTypeEnum.PDB || castTypeEnum == CastTypeEnum.PD_OR_PDB) {
                CampaignShowConfigViewDTO pdbCastTypeShowConfigViewDTO = campaignPdbCastTypeBuildForShowConfigGetAbility.handle(serviceContext, castTypeConfigGetAbilityParam);
                Optional.ofNullable(pdbCastTypeShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
                // 是否复用主计划deal开关
                CampaignShowConfigViewDTO copyPubDealShowConfigViewDTO = campaignCopyPubDealBuildForShowConfigGetAbility.handle(serviceContext, castTypeConfigGetAbilityParam);
                Optional.ofNullable(copyPubDealShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
                // 是否复用其他计划deal开关
                CampaignShowConfigViewDTO copyOtherPubDealShowConfigViewDTO = campaignCopyOtherPubDealBuildForShowConfigGetAbility.handle(serviceContext, castTypeConfigGetAbilityParam);
                Optional.ofNullable(copyOtherPubDealShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
            }
        }
        // 智能预留，设置三方DSP
        CampaignShowConfigViewDTO dspShowConfigViewDTO = campaignDspBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(dspShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
        // 二环CPT
        List<CampaignShowConfigViewDTO> taoOutCptShowConfigList = campaignTaoOutCptBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        if (CollectionUtils.isNotEmpty(taoOutCptShowConfigList)) {
            showConfigViewDTOList.addAll(taoOutCptShowConfigList);
        }
        // 优化目标
//        CampaignShowConfigViewDTO optimizeTargetTypeShowConfigViewDTO = campaignOptimizeTargetTypeBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
//        Optional.ofNullable(optimizeTargetTypeShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
        // 天攻策略
        CampaignShowConfigViewDTO doohStrategyShowConfigViewDTO = campaignDoohStrategyBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(doohStrategyShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
        // 天攻策略方式
        CampaignShowConfigViewDTO doohStrategyMethodShowConfigViewDTO = campaignDoohJsdStrategyMethodBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(doohStrategyMethodShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);

        // 首坑竞排
        CampaignShowConfigViewDTO competExcludeShowConfigViewDTO = campaignCompetExcludeBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(competExcludeShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);
    }

    /**
     * 查询效果adv
     * 1级计划：查询所有子计划的
     * 子计划：只查询子计划的
     * @param serviceContext
     * @param campaignId
     * */
    public List<EffectAdvertiserViewDTO> findEffectAdvList(ServiceContext serviceContext, Long campaignId){
        AssertUtil.notNull(campaignId,"计划不能为空");
        CampaignViewDTO campaignViewDTO =campaignRepository.getCampaignById(serviceContext,campaignId);
        AssertUtil.assertTrue(campaignViewDTO.getCampaignLevel().equals(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode()),"一级计划才可以绑定adv");
        List<Long> advIds = Lists.newArrayList();
        if (campaignViewDTO.getCampaignLevel().equals(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode())){
            //查询所有的子计划
            CampaignQueryViewDTO campaignQueryViewDTO = new CampaignQueryViewDTO();
            campaignQueryViewDTO.setParentCampaignIds(Lists.newArrayList(campaignId));

            List<CampaignViewDTO> subCampaignViewDTOList = campaignRepository.queryCampaignList(serviceContext,campaignQueryViewDTO);
            advIds = subCampaignViewDTOList.stream().map(item->item.getCampaignEffectProxyViewDTO().getEffectAdvId()).collect(Collectors.toList());
        }else{
            advIds = Lists.newArrayList(campaignViewDTO.getCampaignEffectProxyViewDTO().getEffectAdvId());
        }
        List<EffectAdvertiserViewDTO> effectAdvertiserViewDTOS = effectAdvertiserRepository.findEffectAdvInnerList(serviceContext,advIds);
        return effectAdvertiserViewDTOS;

    }
    /**
     * 查询效果adv
     * 1级计划：查询所有子计划的
     * 子计划：只查询子计划的
     * @param serviceContext
     * @param subContractId
     * */
    public List<Long> findEffectAdvListBySubContractId(ServiceContext serviceContext, Long subContractId){
        AssertUtil.notNull(subContractId,"子合同ID不能为空");
        CampaignQueryViewDTO campaignQueryViewDTO = new CampaignQueryViewDTO();
        campaignQueryViewDTO.setSubContractId(subContractId);
        campaignQueryViewDTO.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_TWO_CAMPAIGN.getCode());
        List<CampaignViewDTO> campaignViewDTOList = campaignRepository.queryCampaignList(serviceContext,campaignQueryViewDTO);
        List<Long> advIds = Lists.newArrayList();
        if (CollectionUtils.isNotEmpty(campaignViewDTOList)){
            advIds = campaignViewDTOList.stream().map(item->item.getCampaignEffectProxyViewDTO().getEffectAdvId()).collect(Collectors.toList());
        }
        return advIds;

    }
    /**
     * 查询效果adv
     * @param serviceContext
     * @param contractId
     * */
    public List<Long> findEffectAdvListByContractId(ServiceContext serviceContext, Long contractId){
        List<Long> advIds = Lists.newArrayList();
        List<Long> subContractIds = salesContractRepository.getSubContractIds(contractId);
        if (CollectionUtils.isNotEmpty(subContractIds)){
            CampaignQueryViewDTO campaignQueryViewDTO = new CampaignQueryViewDTO();
            campaignQueryViewDTO.setSubContractIds(subContractIds);
            campaignQueryViewDTO.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_TWO_CAMPAIGN.getCode());
            List<CampaignViewDTO> campaignViewDTOList = campaignRepository.queryCampaignList(serviceContext,campaignQueryViewDTO);
            if (CollectionUtils.isNotEmpty(campaignViewDTOList)){
                advIds = campaignViewDTOList.stream().map(item->item.getCampaignEffectProxyViewDTO().getEffectAdvId()).collect(Collectors.toList());
            }
        }


        return advIds;

    }
    /**
     * 查询计划绑定的子合同
     * @param serviceContext
     * @param campaignIds
     * */
    public List<Long> findEffectSubContractIds(ServiceContext serviceContext, List<Long> campaignIds){
        if (CollectionUtils.isEmpty(campaignIds)){
            return Lists.newArrayList();
        }
        CampaignQueryViewDTO campaignQueryViewDTO = new CampaignQueryViewDTO();
        campaignQueryViewDTO.setCampaignIds(campaignIds);
        campaignQueryViewDTO.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
        List<CampaignViewDTO> campaignViewDTOList = campaignRepository.queryCampaignList(serviceContext,campaignQueryViewDTO);
        List<Long> subContractIds = Lists.newArrayList();
        if (CollectionUtils.isNotEmpty(campaignViewDTOList)){
            subContractIds = campaignViewDTOList.stream().filter(item->null!= item.getCampaignSaleViewDTO() && null!= item.getCampaignSaleViewDTO().getSubContractId()).map(item-> item.getCampaignSaleViewDTO().getSubContractId()).collect(Collectors.toList());
        }
        return subContractIds;

    }



    public List<CampaignEffectAdvViewDTO> findCampaignEffectAdvList(ServiceContext context, CampaignEffectAdvQueryViewDTO campaignEffectAdvQueryViewDTO) {
        AssertUtil.notNull(campaignEffectAdvQueryViewDTO,"查询条件不能为空");
        AssertUtil.notNull(campaignEffectAdvQueryViewDTO.getCampaignGroupId(),"campaignGroupId不能为空");
        AssertUtil.notNull(campaignEffectAdvQueryViewDTO.getSaleGroupId(),"saleGroupId不能为空");
        CampaignQueryViewDTO campaignQueryViewDTO = new CampaignQueryViewDTO();
        campaignQueryViewDTO.setMainCampaignGroupId(campaignEffectAdvQueryViewDTO.getCampaignGroupId());
        campaignQueryViewDTO.setSaleGroupId(campaignEffectAdvQueryViewDTO.getSaleGroupId());
        campaignQueryViewDTO.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_TWO_CAMPAIGN.getCode());

        List<CampaignViewDTO> campaignList = this.getCampaignInfoListByOption(context,campaignQueryViewDTO, CampaignQueryOption.builder().build());
        List<CampaignViewDTO> filterAfterList = campaignList.stream().filter(item -> Objects.nonNull(item.getCampaignEffectProxyViewDTO()) && Objects.nonNull(item.getCampaignEffectProxyViewDTO().getEffectAdvId())).collect(Collectors.toList());
        List<Long> subContractIds = filterAfterList.stream().
                filter(item->Objects.nonNull(item.getCampaignSaleViewDTO())).filter(item->Objects.nonNull(item.getCampaignSaleViewDTO().getSubContractId())).
                map(item->item.getCampaignSaleViewDTO().getSubContractId()).collect(Collectors.toList());
        Map<Long,Long> campaignIdContractIdMap = campaignList.stream().filter(item -> Objects.nonNull(item.getCampaignSaleViewDTO()) && Objects.nonNull(item.getCampaignSaleViewDTO().getSubContractId())).collect(Collectors.toList())
                .stream().collect(Collectors.toMap(CampaignViewDTO::getId, item -> item.getCampaignSaleViewDTO().getSubContractId()));

        List<CampaignEffectAdvViewDTO> campaignEffectAdvViewDTOList = TaskStream.execute(effectADVQueryTaskIdentifier, filterAfterList, (campaignViewDTO, index) -> {
            CampaignEffectProxyViewDTO campaignEffectProxyViewDTO =  campaignViewDTO.getCampaignEffectProxyViewDTO();
            List<Long> effectAdvIds = Lists.newArrayList(campaignEffectProxyViewDTO.getEffectAdvId());
            List<EffectAdvertiserViewDTO> effectAdvertiserViewList = effectAdvertiserRepository.findEffectAdvInnerList(context, effectAdvIds);
            if (CollectionUtils.isNotEmpty(effectAdvertiserViewList)) {
                EffectAdvertiserViewDTO effectAdvertiserViewDTO = effectAdvertiserViewList.get(0);
                CampaignEffectAdvViewDTO campaignEffectAdvViewDTO =  new CampaignEffectAdvViewDTO();
                campaignEffectAdvViewDTO.setCampaignId(campaignViewDTO.getParentCampaignId());
                campaignEffectAdvViewDTO.setSubCampaignId(campaignViewDTO.getId());
                campaignEffectAdvViewDTO.setChannelId(effectAdvertiserViewDTO.getChannelId());
                campaignEffectAdvViewDTO.setAdvId(effectAdvertiserViewDTO.getId());
                if (campaignIdContractIdMap.containsKey(campaignViewDTO.getId())){
                    campaignEffectAdvViewDTO.setSubContractId(campaignIdContractIdMap.get(campaignViewDTO.getId()));
                }
                campaignEffectAdvViewDTO.setDirectAdvertiserId(effectAdvertiserViewDTO.getDirectAdvertiserId());
                campaignEffectAdvViewDTO.setBalance(effectAdvertiserViewDTO.getBalance());
                campaignEffectAdvViewDTO.setTransAmount(0L);
                return campaignEffectAdvViewDTO;
            }
            return null;
        }).commit().getResultList().stream().filter(Objects::nonNull).collect(Collectors.toList());

        //查询充值信息
        if (CollectionUtils.isNotEmpty(campaignEffectAdvViewDTOList)){
            List<Integer> directMediaIds = campaignEffectAdvViewDTOList.stream().map(CampaignEffectAdvViewDTO::getChannelId).collect(Collectors.toList()).stream().map(Long::intValue).collect(Collectors.toList());
            List<Long> directAdvertiserIds = campaignEffectAdvViewDTOList.stream().map(CampaignEffectAdvViewDTO::getDirectAdvertiserId).collect(Collectors.toList());
            List<EffectAdvertiserContractFundViewDTO> effectAdvertiserContractFundViewDTOList =
                    effectAdvertiserRepository.findAdvertiserContractFundList(context,  directMediaIds,directAdvertiserIds, subContractIds);
            if (CollectionUtils.isNotEmpty(effectAdvertiserContractFundViewDTOList)){

                String keyFormat = "%s_%s_%s";
                Map<String, EffectAdvertiserContractFundViewDTO> effectAdvertiserContractFundViewDTOMap = effectAdvertiserContractFundViewDTOList.stream().collect(Collectors.toMap(item -> String.format(keyFormat,item.getDirectMediaId(),item.getDirectAdvertiserId(),item.getSubContractId()), item -> item));
                for (CampaignEffectAdvViewDTO campaignEffectAdvViewDTO : campaignEffectAdvViewDTOList){
                    if (null == campaignEffectAdvViewDTO.getChannelId() || null == campaignEffectAdvViewDTO.getDirectAdvertiserId() || null == campaignEffectAdvViewDTO.getSubContractId()){
                        continue;
                    }
                    String key = String.format(keyFormat,campaignEffectAdvViewDTO.getChannelId(),campaignEffectAdvViewDTO.getDirectAdvertiserId(),campaignEffectAdvViewDTO.getSubContractId());
                    if (effectAdvertiserContractFundViewDTOMap.containsKey(key)){
                        EffectAdvertiserContractFundViewDTO effectAdvertiserContractFundViewDTO = effectAdvertiserContractFundViewDTOMap.get(key);
                        campaignEffectAdvViewDTO.setTransAmount(effectAdvertiserContractFundViewDTO.getTransferIn() - effectAdvertiserContractFundViewDTO.getTransferOut());
                    }
                }
            }
        }
        return campaignEffectAdvViewDTOList.stream().filter(Objects::nonNull).collect(Collectors.toList());
    }
}
