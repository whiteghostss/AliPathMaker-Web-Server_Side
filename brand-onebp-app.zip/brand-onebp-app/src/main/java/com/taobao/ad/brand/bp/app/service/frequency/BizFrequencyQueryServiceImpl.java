package com.taobao.ad.brand.bp.app.service.frequency;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.frequency.FrequencyViewDTO;
import com.alibaba.ad.brand.sdk.constant.frequency.field.BrandFrequencyBizTypeEnum;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.api.campaign.BizCampaignQueryService;
import com.taobao.ad.brand.bp.client.api.frequency.BizFrequencyQueryService;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.FrequencyQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.FrequencyRefViewDTO;
import com.taobao.ad.brand.bp.domain.frequency.repository.FrequencyRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/1/16
 **/
@HSFProvider(serviceInterface = BizFrequencyQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizFrequencyQueryServiceImpl implements BizFrequencyQueryService {
    private final FrequencyRepository frequencyRepository;

    @Override
    public SingleResponse<FrequencyViewDTO> getFrequencyById(ServiceContext serviceContext, Long frequencyId) {
        return SingleResponse.of(frequencyRepository.getFrequencyById(serviceContext, frequencyId));
    }

    @Override
    public MultiResponse<FrequencyViewDTO> frequencyList(ServiceContext serviceContext, FrequencyQueryViewDTO queryViewDTO) {
        PageResultViewDTO<FrequencyViewDTO> frequencyViewDTOList = frequencyRepository.frequencyList(serviceContext, queryViewDTO);
        return MultiResponse.of(frequencyViewDTOList.getList(), frequencyViewDTOList.getCount());
    }
    @Override
    public SingleResponse<FrequencyRefViewDTO> findFrequencyRefByFreqId(ServiceContext serviceContext, Long frequencyId, Integer frequencyBizType) {
        return SingleResponse.of(frequencyRepository.findFrequencyRefByFreqId(serviceContext, frequencyId, frequencyBizType));
    }
}
