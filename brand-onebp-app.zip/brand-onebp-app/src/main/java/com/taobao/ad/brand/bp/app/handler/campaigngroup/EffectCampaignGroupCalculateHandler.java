package com.taobao.ad.brand.bp.app.handler.campaigngroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.price.DayPriceViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.fastjson.JSON;
import com.alibaba.hermes.framework.ddd.event.annotation.DomainEventHandler;
import com.alibaba.hermes.framework.event.EventHandler;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryViewDTO;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.event.campaigngroup.CampaignGroupCalculateEvent;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor(onConstructor_ = @Autowired)
@DomainEventHandler(topic = "effect_campaign_group_calculate", event = CampaignGroupCalculateEvent.class)
public class EffectCampaignGroupCalculateHandler implements EventHandler<CampaignGroupCalculateEvent> {

    private final ResourcePackageRepository resourcePackageRepository;

    private final CampaignGroupRepository campaignGroupRepository;

    private final CampaignRepository campaignRepository;

    @Override
    public Response handle(CampaignGroupCalculateEvent contentCampaignGroupCalculateEvent) {
        ServiceContext serviceContext = contentCampaignGroupCalculateEvent.getContext().getServiceContext();
        Long campaignGroupId = contentCampaignGroupCalculateEvent.getContext().getCampaignGroupId();
        //查询订单信息
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(serviceContext, campaignGroupId);
        fillEffectCalculateInfo(serviceContext, campaignGroupViewDTO);
        campaignGroupRepository.addOrUpdateSaleGroupPart(serviceContext, campaignGroupViewDTO.getId(), campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList());
        //重新计算订单时间
        calcCampaignGroupViewDTOTime(serviceContext, campaignGroupViewDTO);
        campaignGroupRepository.updateCampaignGroupPart(serviceContext, campaignGroupViewDTO);
        return Response.success();
    }

    /**
     * 每次点击计算的时候，拉取订单下所有计划（包括所有状态计划）的时间计算订单时间
     * @param context
     * @param campaignGroup
     */
    private void calcCampaignGroupViewDTOTime(ServiceContext context, CampaignGroupViewDTO campaignGroup) {
        CampaignQueryViewDTO query = new CampaignQueryViewDTO();
        query.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
        query.setCampaignGroupId(campaignGroup.getId());
        List<CampaignViewDTO> campaignViewDTOList = campaignRepository.queryCampaignList(context, query);
        RogerLogger.info("calcCampaignGroupViewDTOTime method, campaignViewDTOList: {}", JSON.toJSONString(campaignViewDTOList));
        Date startTime = campaignViewDTOList.stream().min(Comparator.comparing(campaignViewDTO -> campaignViewDTO.getStartTime())).map(date -> date.getStartTime()).get();
        Date endTime = campaignViewDTOList.stream().max(Comparator.comparing(campaignViewDTO -> campaignViewDTO.getEndTime())).map(date -> date.getEndTime()).get();
        campaignGroup.setStartTime(startTime);
        campaignGroup.setEndTime(endTime);
    }

    private Void fillEffectCalculateInfo(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO) {
        RogerLogger.info("fillEffectCalculateInfo campaignGroupViewDTO: {}", JSON.toJSONString(campaignGroupViewDTO));
        //查询售卖分组
        List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList();
        List<Long> saleGroupIds = saleGroupInfoViewDTOList.stream().map(SaleGroupInfoViewDTO::getSaleGroupId).collect(Collectors.toList());
        ResourcePackageQueryViewDTO resourcePackageQueryViewDTO = new ResourcePackageQueryViewDTO();
        resourcePackageQueryViewDTO.setSaleGroupIdList(saleGroupIds);
        List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupViewDTOS = resourcePackageRepository.getSaleGroupList(context, resourcePackageQueryViewDTO,
                ResourcePackageQueryOption.builder().needProduct(true).needSetting(true).build());
        RogerLogger.info("resourcePackageSaleGroupViewDTOS:{}", JSON.toJSONString(resourcePackageSaleGroupViewDTOS));
        Map<Long, ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupMap = resourcePackageSaleGroupViewDTOS.stream().collect(Collectors.toMap(ResourcePackageSaleGroupViewDTO::getId, e->e, (v1, v2)->v1));
        CampaignQueryViewDTO query = new CampaignQueryViewDTO();
        query.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
        query.setCampaignGroupId(campaignGroupViewDTO.getId());
        List<CampaignViewDTO> campaignViewDTOList = campaignRepository.queryCampaignList(context, query);
        Map<Long, List<CampaignViewDTO>> saleGroupCampaignMap = campaignViewDTOList.stream().collect(Collectors.groupingBy(t -> t.getCampaignSaleViewDTO().getSaleGroupId()));
        for(SaleGroupInfoViewDTO saleGroupInfoViewDTO:saleGroupInfoViewDTOList){
            ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO = resourcePackageSaleGroupMap.get(saleGroupInfoViewDTO.getSaleGroupId());
            //分组填充金额相关信息
            if(resourcePackageSaleGroupViewDTO.getAmountConfigure().getType() != null){
                saleGroupInfoViewDTO.setBudgetSettingType(resourcePackageSaleGroupViewDTO.getAmountConfigure().getType());
            }
            List<CampaignViewDTO> saleGroupCampaignList = saleGroupCampaignMap.get(saleGroupInfoViewDTO.getSaleGroupId());
            if (CollectionUtils.isNotEmpty(saleGroupCampaignList)) {
                saleGroupInfoViewDTO.setStartDate(BrandDateUtil.getDateMidnight(BizCampaignGroupToolsHelper.getCampaignMinTime(saleGroupCampaignList)));
                saleGroupInfoViewDTO.setEndDate(BrandDateUtil.getDateMidnight(BizCampaignGroupToolsHelper.getCampaignMaxTime(saleGroupCampaignList)));
            }else{
                saleGroupInfoViewDTO.setStartDate(resourcePackageSaleGroupViewDTO.getStartDate());
                saleGroupInfoViewDTO.setEndDate(resourcePackageSaleGroupViewDTO.getEndDate());
            }
            saleGroupInfoViewDTO.setCalcBudget(resourcePackageSaleGroupViewDTO.getBudget());
            saleGroupInfoViewDTO.setUnitPrice(resourcePackageSaleGroupViewDTO.getCpmUnitPrice());
            saleGroupInfoViewDTO.setAmount(resourcePackageSaleGroupViewDTO.getAmountConfigure().getAmount());
            //获取分组里的二级产品，普通分组的只有一类资源
            List<ResourcePackageProductViewDTO>  resourcePackageProductViewDTOS = resourcePackageSaleGroupViewDTO.getDistributionRuleList().get(0).getResourcePackageProductList();
            List<com.alibaba.ad.brand.dto.campaigngroup.sale.ResourcePackageProductViewDTO> resourcePackageProductViewDTOList = Lists.newArrayList();
            //填充二级产品信息
            for(ResourcePackageProductViewDTO resourcePackageProductViewDTO:resourcePackageProductViewDTOS){
                com.alibaba.ad.brand.dto.campaigngroup.sale.ResourcePackageProductViewDTO dto
                        = new com.alibaba.ad.brand.dto.campaigngroup.sale.ResourcePackageProductViewDTO();
                dto.setBudget(resourcePackageProductViewDTO.getBandPriceList().get(0).getActualAmount());
                dto.setResourcePackageProductId(resourcePackageProductViewDTO.getId());
                dto.setDiscountDayPriceInfoViewDTOList(getProductDayPriceViewDTOList(resourcePackageProductViewDTO));
                resourcePackageProductViewDTOList.add(dto);
            }
            saleGroupInfoViewDTO.setResourcePackageProductViewDTOList(resourcePackageProductViewDTOList);
        }
        campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().setSaleGroupInfoViewDTOList(saleGroupInfoViewDTOList);
        return null;
    }

    private List<DayPriceViewDTO> getProductDayPriceViewDTOList(ResourcePackageProductViewDTO resourcePackageProductViewDTO) {
        List<DayPriceViewDTO> dayPriceViewDTOList = resourcePackageProductViewDTO.getBandPriceList().stream().map(v -> {
            DayPriceViewDTO dayPriceViewDTO = new DayPriceViewDTO();
            dayPriceViewDTO.setStartDate(v.getStartDate());
            dayPriceViewDTO.setEndDate(v.getEndDate());
            dayPriceViewDTO.setPrice(v.getPrice());
            dayPriceViewDTO.setDiscountRatio(v.getPriceRatio());
            return dayPriceViewDTO;
        }).collect(Collectors.toList());
        return dayPriceViewDTOList;
    }
}
