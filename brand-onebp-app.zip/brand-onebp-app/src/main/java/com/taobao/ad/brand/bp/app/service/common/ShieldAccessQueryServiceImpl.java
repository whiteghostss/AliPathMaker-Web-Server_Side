package com.taobao.ad.brand.bp.app.service.common;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.fastjson.JSON;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.client.api.common.ShieldAccessQueryService;
import com.taobao.ad.brand.bp.client.dto.shield.ShieldSyncTextDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.shield.ShieldAccessRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@HSFProvider(serviceInterface = ShieldAccessQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ShieldAccessQueryServiceImpl implements ShieldAccessQueryService {

    private final ShieldAccessRepository shieldAccessRepository;


    @Override
    public MultiResponse<ShieldSyncTextDTO> textAccessBatchCheck(ServiceContext context, List<String> textList) {
        RogerLogger.info("ShieldAccessQueryService textAccessSyncRuleBatchJudge textList {}", JSON.toJSONString(textList));
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(textList), "风控校验名称异常,请传入待校验文字");

        List<ShieldSyncTextDTO> shieldSyncTextDTOS = shieldAccessRepository.textAccessBatchCheck(textList);

        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(shieldSyncTextDTOS), "风控校验名称异常,请稍后重试");

        return MultiResponse.of(shieldSyncTextDTOS);
    }
}
