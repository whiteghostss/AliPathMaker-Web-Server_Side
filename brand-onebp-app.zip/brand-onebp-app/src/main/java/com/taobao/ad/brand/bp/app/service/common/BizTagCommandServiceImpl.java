package com.taobao.ad.brand.bp.app.service.common;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.common.TagViewDTO;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.api.common.BizTagCommandService;
import com.taobao.ad.brand.bp.domain.tag.TagRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @Author: PhilipFry
 * @createTime: 2024年02月27日 20:23:02
 * @Description:
 */
@HSFProvider(serviceInterface = BizTagCommandService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizTagCommandServiceImpl implements BizTagCommandService {
    private final TagRepository tagRepository;

    @Override
    public SingleResponse<Long> addTag(ServiceContext serviceContext, TagViewDTO tagViewDTO) {
        Long tag = tagRepository.addTag(serviceContext, tagViewDTO);
        return SingleResponse.of(tag);
    }

    @Override
    public SingleResponse<Integer> updateTag(ServiceContext serviceContext, TagViewDTO tagViewDTO) {
        Integer count = tagRepository.updateTag(serviceContext, tagViewDTO);
        return SingleResponse.of(count);
    }

    @Override
    public SingleResponse<Integer> deleteTag(ServiceContext serviceContext, Long tagId) {
        Integer count = tagRepository.deleteTag(serviceContext, tagId);
        return SingleResponse.of(count);
    }
}
