package com.taobao.ad.brand.bp.app.service.demand;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.demand.DemandViewDTO;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.api.demand.BizDemandCommandService;
import com.taobao.ad.brand.bp.client.dto.demand.DemandConfirmSolutionViewDTO;
import com.taobao.ad.brand.bp.client.dto.demand.DemandTalentDiffViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@Deprecated
@HSFProvider(serviceInterface = BizDemandCommandService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizDemandCommandServiceImpl implements BizDemandCommandService {

    @Override
    public SingleResponse<Long> addDemand(ServiceContext context, DemandViewDTO demandViewDTO) {
        return SingleResponse.failureOf(BrandOneBPBaseErrorCode.BIZ_UN_SUPPORT_ERROR.getErrCode(),"功能已下线");
    }

    @Override
    public Response updateDemand(ServiceContext context, DemandViewDTO demandViewDTO) {
        return Response.success();
    }

    @Override
    public Response updateDemandPart(ServiceContext context, DemandViewDTO demandViewDTO) {
        return Response.failure(BrandOneBPBaseErrorCode.BIZ_UN_SUPPORT_ERROR.getErrCode(),"功能已下线");
    }

    @Override
    public Response deleteDemand(ServiceContext context, Long id) {
        return Response.failure(BrandOneBPBaseErrorCode.BIZ_UN_SUPPORT_ERROR.getErrCode(),"功能已下线");
    }

    @Override
    public Response confirmSolution(ServiceContext serviceContext, DemandConfirmSolutionViewDTO confirmSolutionViewDTO) {
        return Response.failure(BrandOneBPBaseErrorCode.BIZ_UN_SUPPORT_ERROR.getErrCode(),"功能已下线");
    }

    @Override
    public Response confirmTalentUpdate(ServiceContext serviceContext, List<DemandTalentDiffViewDTO> confirmUpdateTalentList) {
        return Response.failure(BrandOneBPBaseErrorCode.BIZ_UN_SUPPORT_ERROR.getErrCode(),"功能已下线");
    }
}
