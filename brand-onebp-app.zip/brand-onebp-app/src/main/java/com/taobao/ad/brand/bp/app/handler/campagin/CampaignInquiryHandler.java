package com.taobao.ad.brand.bp.app.handler.campagin;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandInquiryStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandStockTypeEnum;
import com.alibaba.ad.nb.ssp.constant.newproduct.ProductLineEnum;
import com.alibaba.hermes.framework.ddd.event.annotation.DomainEventHandler;
import com.alibaba.hermes.framework.event.EventHandler;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.context.CampaignInquiryContext;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignEventEnum;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.event.campaign.CampaignInquiryEvent;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor(onConstructor_ = @Autowired)
@DomainEventHandler(topic = "content_campaign_inquiry", event = CampaignInquiryEvent.class)
public class CampaignInquiryHandler implements EventHandler<CampaignInquiryEvent> {

    private final CampaignRepository campaignRepository;

    /**
     * TODO 这块应该是内容询量的业务流程了
     * @param campaignInquiryEvent
     * @return
     */
    @Override
    public Response handle(CampaignInquiryEvent campaignInquiryEvent) {
        CampaignInquiryContext campaignInquiryContext =  campaignInquiryEvent.getContext();
        List<CampaignViewDTO> campaignViewDTOList = campaignInquiryContext.getCampaignViewDTOList();
        ServiceContext serviceContext = campaignInquiryContext.getServiceContext();

        if (CollectionUtils.isEmpty(campaignViewDTOList)) {
            return Response.success();
        }

        // 过滤头部达人及达人CPM包
        campaignViewDTOList = campaignViewDTOList.stream()
                .filter(e -> (!ProductLineEnum.UD_CONTENT_TOP_TALENT.getValue().equals(e.getCampaignResourceViewDTO().getSspProductLineId())
                        && !ProductLineEnum.UD_CONTENT_TALENT_CPM_PACKAGE.getValue().equals(e.getCampaignResourceViewDTO().getSspProductLineId())))
                .collect(Collectors.toList());

        if (CollectionUtils.isEmpty(campaignViewDTOList)) {
            return Response.success();
        }
        //查询二级计划
        List<Long> parentCampaignIds = campaignViewDTOList.stream().map(e->e.getId()).collect(Collectors.toList());
        CampaignQueryViewDTO queryViewDTO = new CampaignQueryViewDTO();
        queryViewDTO.setParentCampaignIds(parentCampaignIds);
        List<CampaignViewDTO> subCampaignViewDTOList = campaignRepository.queryCampaignList(serviceContext, queryViewDTO);
        campaignViewDTOList.addAll(subCampaignViewDTOList);
        for(CampaignViewDTO campaignViewDTO:campaignViewDTOList){
            //先清空
            campaignRepository.updateCampaignInquiryAll(serviceContext,campaignViewDTO.getId(), Lists.newArrayList());
            //更新或者新增计划的场景下，重新计算库存保存
            if(CampaignEventEnum.UPDATE.equals(campaignInquiryContext.getCampaignEventEnum()) || CampaignEventEnum.CREATE.equals(campaignInquiryContext.getCampaignEventEnum())){
                List<CampaignInquiryViewDTO> campaignInquiryViewDTOList = fillInquiryInfo(serviceContext, campaignViewDTO);
                campaignRepository.updateCampaignInquiryAll(serviceContext, campaignViewDTO.getId(), campaignInquiryViewDTOList);
            }
        }
        return Response.success();
    }

    private List<CampaignInquiryViewDTO> fillInquiryInfo(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO){
        List<CampaignInquiryViewDTO> campaignInquiryViewDTOList = Lists.newArrayList();
        Long amount = campaignViewDTO.getCampaignGuaranteeViewDTO().getAmount();
        Date startTime = campaignViewDTO.getStartTime();
        Date endTime = campaignViewDTO.getEndTime();
        List<Date> days = BrandDateUtil.getDayList(startTime, endTime);
        Long campaignId = campaignViewDTO.getId();
        if(CollectionUtils.isNotEmpty(days)){
            Long averAmount = BigDecimal.valueOf(amount)
                    .divide(BigDecimal.valueOf(days.size()), 0, RoundingMode.HALF_DOWN).longValue();
            Long finalAmount = amount;
            for(int i=0; i<days.size(); i++){
                CampaignInquiryViewDTO campaignInquiryViewDTO = new CampaignInquiryViewDTO();
                campaignInquiryViewDTO.setCampaignId(campaignId);
                campaignInquiryViewDTO.setProductLineId(serviceContext.getProductLineId());
                campaignInquiryViewDTO.setDate(days.get(i));
                if(i == days.size()-1){
                    campaignInquiryViewDTO.setBookAmount(finalAmount);
                    campaignInquiryViewDTO.setLockAmount(finalAmount);
                    campaignInquiryViewDTO.setAvailableAmount(finalAmount);
                    campaignInquiryViewDTO.setStockTotalAmount(finalAmount);
                }else {
                    campaignInquiryViewDTO.setBookAmount(averAmount);
                    campaignInquiryViewDTO.setLockAmount(averAmount);
                    campaignInquiryViewDTO.setAvailableAmount(averAmount);
                    campaignInquiryViewDTO.setStockTotalAmount(averAmount);
                }
                campaignInquiryViewDTO.setStatus(BrandInquiryStatusEnum.SUCCESS.getCode());
                campaignInquiryViewDTO.setStockType(BrandStockTypeEnum.IMPRECISION.getCode());
                campaignInquiryViewDTO.setDiffAmount(0L);
                campaignInquiryViewDTOList.add(campaignInquiryViewDTO);
                finalAmount = finalAmount - averAmount;
            }
        }
        return campaignInquiryViewDTOList;
    }
}
