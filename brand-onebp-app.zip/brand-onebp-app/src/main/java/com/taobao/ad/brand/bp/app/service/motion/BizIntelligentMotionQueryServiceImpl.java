package com.taobao.ad.brand.bp.app.service.motion;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.app.workflow.motion.BizIntelligentStrategyCommandWorkflow;
import com.taobao.ad.brand.bp.client.api.motion.BizIntelligentMotionQueryService;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CrmAdvInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CrmNewCustomerViewDTO;
import com.taobao.ad.brand.bp.client.dto.cartitem.query.CartItemQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.motion.IntelligentMotionViewDTO;
import com.taobao.ad.brand.bp.client.dto.motion.query.MotionQueryViewDTO;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CustomerRepository;
import com.taobao.ad.brand.bp.domain.cart.repository.CartItemRepository;
import com.taobao.ad.brand.bp.domain.config.SelfServiceTestMemberConfig;
import com.taobao.ad.brand.bp.domain.motion.IntelligentMotionRepository;
import com.taobao.ad.brand.bp.domain.perform.PerformRepository;
import com.taobao.ad.brand.bp.domain.sdk.motion.workflow.param.BizIntelligentStrategyWorkflowParam;
import com.taobao.ad.brand.perform.client.dto.shopwindow.spu.marketingrule.SpuCheckMarketingRuleViewDTO;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/18
 **/
@HSFProvider(serviceInterface = BizIntelligentMotionQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizIntelligentMotionQueryServiceImpl implements BizIntelligentMotionQueryService {
    private final IntelligentMotionRepository intelligentMotionRepository;
    private final CustomerRepository customerRepository;

    private final SelfServiceTestMemberConfig selfServiceTestMemberConfig;

    private final CartItemRepository cartItemRepository;

    private final PerformRepository performRepository;

    private final BizIntelligentStrategyCommandWorkflow bizIntelligentStrategyCommandWorkflow;

    @Override
    public MultiResponse<IntelligentMotionViewDTO> intelligentMotionList(ServiceContext serviceContext, MotionQueryViewDTO queryViewDTO) {
        List<IntelligentMotionViewDTO> intelligentMotionViewDTOS = intelligentMotionRepository.queryIntelligentMotionList(serviceContext, queryViewDTO);
        return MultiResponse.of(intelligentMotionViewDTOS);
    }

    @Override
    public MultiResponse<IntelligentMotionViewDTO> intelligentMotionPageList(ServiceContext serviceContext, MotionQueryViewDTO queryViewDTO) {
        return intelligentMotionRepository.queryIntelligentMotionPageList(serviceContext, queryViewDTO);
    }

    @Override
    public SingleResponse<String> getCustomerName(ServiceContext serviceContext, Long memberId) {
        CrmAdvInfoViewDTO adviceInfoViewDTO = customerRepository.getCustomer(memberId);
        String name = Optional.ofNullable(adviceInfoViewDTO.getNewCustomer()).map(CrmNewCustomerViewDTO::getCustomerName).orElse(null);
        return SingleResponse.of(name);
    }

    @Override
    public SingleResponse<Long> getStartBudget(ServiceContext serviceContext, List<Long> cartItemIdList) {
        AssertUtil.notEmpty(cartItemIdList, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "未传入加购行id列表");
        Boolean testMemberId = CollectionUtils.isNotEmpty(selfServiceTestMemberConfig.getSelfSpuMarketingRuleMemberList()) && selfServiceTestMemberConfig.getSelfSpuMarketingRuleMemberList().contains(serviceContext.getMemberId());
        List<CartItemViewDTO> cartItemViewDTOList = cartItemRepository.findCartList(serviceContext, CartItemQueryViewDTO.builder().idList(cartItemIdList).build());
        List<SpuCheckMarketingRuleViewDTO> spuCheckMarketingRuleViewDTOList = performRepository.getCheckMarketingRule(serviceContext);

        Map<Long, Long> cartItemBudgetMap = Maps.newConcurrentMap();
        //step1:门槛分配逻辑
        for (SpuCheckMarketingRuleViewDTO spuCheckMarketingRuleViewDTO : spuCheckMarketingRuleViewDTOList) {
            List<CartItemViewDTO> marketRuleCartItemList = cartItemViewDTOList.stream().filter(it -> spuCheckMarketingRuleViewDTO.getSpuIdList().contains(it.getSpuId())).collect(Collectors.toList());
            if (CollectionUtils.isNotEmpty(marketRuleCartItemList)) {
                Long totalBudget = 0L;
                for (CartItemViewDTO cartItemViewDTO : marketRuleCartItemList) {
                    cartItemBudgetMap.put(cartItemViewDTO.getId(), spuCheckMarketingRuleViewDTO.getBudget() / marketRuleCartItemList.size());
                    totalBudget += spuCheckMarketingRuleViewDTO.getBudget() / marketRuleCartItemList.size();
                }
                // 做倒减,加到第一个加购行上
                Long surplusBudget = spuCheckMarketingRuleViewDTO.getBudget() - totalBudget;
                AssertUtil.assertTrue(surplusBudget >= 0, "待分配金额为负数，计算起投门槛金额过低");
                cartItemBudgetMap.put(marketRuleCartItemList.get(0).getId(), cartItemBudgetMap.get(marketRuleCartItemList.get(0).getId()) + surplusBudget);
            }
        }
        if (!testMemberId) {
            BizIntelligentStrategyWorkflowParam workflowParam = bizIntelligentStrategyCommandWorkflow.buildParamForSupplyPreStrategyRcmdResponse(serviceContext, cartItemIdList);
            List<CartItemViewDTO> superUniverseCartItemViewDTOList = cartItemViewDTOList.stream().filter(cartItemViewDTO -> bizIntelligentStrategyCommandWorkflow.judgeSuperUniverseSaleProductLine(serviceContext, workflowParam, cartItemViewDTO)).collect(Collectors.toList());
            superUniverseCartItemViewDTOList.forEach(it -> cartItemBudgetMap.put(it.getId(), (cartItemBudgetMap.containsKey(it.getId()) ? Math.max(cartItemBudgetMap.get(it.getId()), 10000000L) : 10000000L)));
        }
        Long startBudget = cartItemBudgetMap.values().stream().reduce(0L, Long::sum);
        return SingleResponse.of(startBudget);
    }
}
