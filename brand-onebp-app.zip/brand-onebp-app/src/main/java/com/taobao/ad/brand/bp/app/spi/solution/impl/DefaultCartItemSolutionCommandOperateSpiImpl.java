package com.taobao.ad.brand.bp.app.spi.solution.impl;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.budget.CampaignBudgetViewDTO;
import com.alibaba.ad.brand.dto.campaign.price.CampaignPriceViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.nb.framework.core.AbilityFactory;
import com.alibaba.ad.nb.framework.core.annotation.AbilitySpiInstance;
import com.taobao.ad.brand.bp.app.spi.solution.CartItemSolutionCommandOperateSpi;
import com.taobao.ad.brand.bp.client.dto.base.DateViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.rule.RuleCheckResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandBundleViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSkuViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSpuViewDTO;
import com.taobao.ad.brand.bp.client.dto.solution.CartItemSolutionViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.ICartItemAdDateJudgeAbility;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.ICartItemAdTotalBudgetJudgeAbility;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.param.CartItemAdDateJudgeAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.cartitem.atomability.param.CartItemAdTotalBudgetJudgeAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.solution.atomability.ISolutionCommandBaseValidateForSaveCartItemSolutionAbility;
import com.taobao.ad.brand.bp.domain.sdk.solution.atomability.param.CartItemSolutionCommandAbilityParam;
import com.taobao.ad.brand.bp.domain.shopwindow.repository.BrandSkuRepository;
import com.taobao.ad.brand.bp.domain.shopwindow.repository.BrandSpuRepository;

import javax.annotation.Resource;
import java.util.Objects;
import java.util.Optional;

@AbilitySpiInstance(bizCode = AbilityFactory.DEFAULT_BIZ_CODE, name = "defaultCartItemSolutionCommandOperateSpiImpl", desc = "自助化解决方案默认扩展")
public class DefaultCartItemSolutionCommandOperateSpiImpl implements CartItemSolutionCommandOperateSpi {
    @Resource
    private ICartItemAdDateJudgeAbility cartItemAdDateJudgeAbility;
    @Resource
    private ICartItemAdTotalBudgetJudgeAbility cartItemAdTotalBudgetJudgeAbility;
    @Resource
    private BrandSpuRepository brandSpuRepository;
    @Resource
    private BrandSkuRepository brandSkuRepository;
    @Resource
    private ResourcePackageRepository resourcePackageRepository;
    @Resource
    private ISolutionCommandBaseValidateForSaveCartItemSolutionAbility solutionCommandBaseValidateForSaveCartItemSolutionAbility;

    @Override
    public Void validateForAddCartItemSolution(ServiceContext serviceContext, CartItemSolutionViewDTO solutionCommandViewDTO) {
        //基础校验
        solutionCommandBaseValidateForSaveCartItemSolutionAbility.handle(serviceContext,
                CartItemSolutionCommandAbilityParam.builder().abilityTarget(solutionCommandViewDTO).build());

        BrandBundleViewDTO bundleViewDTO = brandSkuRepository.getBundleDetail(serviceContext, solutionCommandViewDTO.getBundleId());
        AssertUtil.notNull(bundleViewDTO,"套餐包不存在");

        //投放周期校验
        BrandSpuViewDTO brandSpuViewDTO = brandSpuRepository.get(serviceContext, bundleViewDTO.getSpuId());
        AssertUtil.notNull(brandSpuViewDTO,"SPU不存在");

        BrandSkuViewDTO brandSkuViewDTO = brandSkuRepository.get(serviceContext, bundleViewDTO.getSkuId());
        AssertUtil.notNull(brandSkuViewDTO,"SKU不存在");

        ResourcePackageProductViewDTO resourcePackageProductViewDTO = resourcePackageRepository.getSimpleResourcePackageProduct(serviceContext,
                brandSkuViewDTO.getResourcePackageProductId());
        AssertUtil.notNull(resourcePackageProductViewDTO, "资源位不存在");

        //投放周期
        DateViewDTO dateViewDTO = DateViewDTO.build(solutionCommandViewDTO.getCampaignViewDTO().getStartTime(),
                solutionCommandViewDTO.getCampaignViewDTO().getEndTime());
        RuleCheckResultViewDTO checkResultViewDTO = cartItemAdDateJudgeAbility.handle(serviceContext,
                CartItemAdDateJudgeAbilityParam.builder().abilityTarget(dateViewDTO).spuViewDTO(brandSpuViewDTO)
                        .resourcePackageProductViewDTO(resourcePackageProductViewDTO).bundleViewDTO(bundleViewDTO).build());
        AssertUtil.assertTrue(BrandBoolEnum.BRAND_TRUE.getCode().equals(checkResultViewDTO.getIsPass()),checkResultViewDTO.getReason());

        //投放金额
        Long discountTotalMoney = Optional.ofNullable(solutionCommandViewDTO.getCampaignViewDTO()).map(CampaignViewDTO::getCampaignBudgetViewDTO)
                .map(CampaignBudgetViewDTO::getDiscountTotalMoney).orElse(null);
        AssertUtil.notNull(discountTotalMoney,"投放金额不能为空");
        // 折前金额
        Long publishTotalMoney = solutionCommandViewDTO.getPublishTotalMoney();
        AssertUtil.notNull(publishTotalMoney,"投放金额不能为空");
        checkResultViewDTO = cartItemAdTotalBudgetJudgeAbility.handle(serviceContext,
                CartItemAdTotalBudgetJudgeAbilityParam.builder().abilityTarget(publishTotalMoney).bundleViewDTO(bundleViewDTO).build());
        AssertUtil.assertTrue(BrandBoolEnum.BRAND_TRUE.getCode().equals(checkResultViewDTO.getIsPass()),checkResultViewDTO.getReason());

        return null;
    }

    @Override
    public Void validateForUpdateCartItemSolution(ServiceContext serviceContext, CartItemSolutionViewDTO dbSolutionCommandViewDTO, CartItemSolutionViewDTO solutionCommandViewDTO) {
        //基础校验
        solutionCommandBaseValidateForSaveCartItemSolutionAbility.handle(serviceContext,
                CartItemSolutionCommandAbilityParam.builder().abilityTarget(solutionCommandViewDTO).build());

        AssertUtil.assertTrue(Objects.equals(dbSolutionCommandViewDTO.getSkuId(),solutionCommandViewDTO.getSkuId()),"SKU不允许修改");
        AssertUtil.assertTrue(Objects.equals(dbSolutionCommandViewDTO.getBundleId(),solutionCommandViewDTO.getBundleId()),"套餐包不允许修改");

        return this.validateForAddCartItemSolution(serviceContext,solutionCommandViewDTO);
    }

    @Override
    public Void initForUpdateCartItemSolution(ServiceContext serviceContext, CartItemSolutionViewDTO dbSolutionCommandViewDTO, CartItemSolutionViewDTO solutionCommandViewDTO) {
        return null;
    }

    @Override
    public Void executeForUpdateCartItemSolution(ServiceContext serviceContext, CartItemSolutionViewDTO dbSolutionCommandViewDTO, CartItemSolutionViewDTO solutionCommandViewDTO) {
        return null;
    }
}

