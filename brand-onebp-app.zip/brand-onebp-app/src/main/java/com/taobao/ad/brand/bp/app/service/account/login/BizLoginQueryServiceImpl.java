package com.taobao.ad.brand.bp.app.service.account.login;

import com.alibaba.abf.governance.context.GatewayContext;
import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.aliyun.openservices.shade.com.alibaba.fastjson.JSON;
import com.taobao.ad.brand.bp.client.api.account.login.BizLoginQueryService;
import com.taobao.ad.brand.bp.client.dto.account.login.LoginMemberViewDTO;
import com.taobao.ad.brand.bp.client.dto.account.login.LoginSessionViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.account.repository.LoginSessionRepository;
import com.taobao.ad.brand.bp.domain.memeber.MemberRepository;
import lombok.RequiredArgsConstructor;

@HSFProvider(serviceInterface = BizLoginQueryService.class)
@RequiredArgsConstructor
public class BizLoginQueryServiceImpl implements BizLoginQueryService {

    private final LoginSessionRepository loginSessionRepository;
    private final MemberRepository memberRepository;

    @Override
    public SingleResponse<LoginSessionViewDTO> getSession(ServiceContext context, GatewayContext gatewayContext) {
        AssertUtil.notNull(context, "serviceContext is null");
        AssertUtil.notNull(context.getBizCode(), "serviceContext.bizCode is null");
        LoginSessionViewDTO loginSessionViewDTO = loginSessionRepository.get(context, gatewayContext);
        RogerLogger.info("loginSessionViewDTO: {}", JSON.toJSONString(loginSessionViewDTO));
        // 未登录投放账号
        boolean nonLogin = (loginSessionViewDTO == null || (!loginSessionViewDTO.isPreLogin() && !loginSessionViewDTO.isLogin()));
        if (nonLogin) {
            RogerLogger.info("getSession no login");
            return SingleResponse.of(new LoginSessionViewDTO());
        }
        return SingleResponse.of(loginSessionViewDTO);
    }

    @Override
    public SingleResponse<LoginMemberViewDTO> getRealMemberInfo(ServiceContext context) {
        Long realMemberId = memberRepository.getTargetMemberIdByMemberId(context.getMemberId());
        String nickName = memberRepository.getMemberNameById(realMemberId);
        LoginMemberViewDTO loginMemberViewDTO = new LoginMemberViewDTO();
        loginMemberViewDTO.setMemberId(realMemberId);
        loginMemberViewDTO.setNickName(nickName);
        return SingleResponse.of(loginMemberViewDTO);
    }

    @Override
    public SingleResponse<String> getMemberDisplayName(ServiceContext context, Long memberId) {
        AssertUtil.notNull(memberId, "memberId is null");
        return SingleResponse.of(memberRepository.getMemberDisplayNameById(memberId));
    }
}
