package com.taobao.ad.brand.bp.app.service.report;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.api.report.BizReportTaskCommandService;
import com.taobao.ad.brand.bp.client.dto.report.ReportTaskViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.query.ReportTaskQueryViewDTO;
import com.taobao.ad.brand.bp.domain.report.ability.BizReportTaskAbility;
import com.taobao.ad.brand.bp.domain.report.repository.ReportSyncTaskRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 报表异步任务操作相关服务
 * @author yuncheng.lyc
 */
@HSFProvider(serviceInterface = BizReportTaskCommandService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizReportTaskCommandServiceImpl implements BizReportTaskCommandService {

    private final ReportSyncTaskRepository reportSyncTaskRepository;
    private final BizReportTaskAbility bizReportTaskAbility;

    @Override
    public SingleResponse<Long> addReportTask(ServiceContext context, ReportTaskViewDTO taskViewDTO) {
        bizReportTaskAbility.validateReportTask(context, taskViewDTO, Boolean.FALSE);
        Long taskId = reportSyncTaskRepository.add(context, taskViewDTO);
        taskViewDTO.setTaskId(taskId);
        bizReportTaskAbility.getResult(context, taskViewDTO,Boolean.FALSE);
        return SingleResponse.of(taskId);
    }

    @Override
    public SingleResponse<Long> modifyReportTask(ServiceContext context, ReportTaskViewDTO taskViewDTO) {
        bizReportTaskAbility.validateReportTask(context, taskViewDTO, Boolean.TRUE);
        Long taskId = reportSyncTaskRepository.modify(context, taskViewDTO);
        bizReportTaskAbility.getResult(context, taskViewDTO,Boolean.TRUE);
        return SingleResponse.of(taskId);
    }

    @Override
    public SingleResponse<Long> deleteReportTask(ServiceContext context, ReportTaskQueryViewDTO queryViewDTO) {
        bizReportTaskAbility.validateReportTaskQuery(context, queryViewDTO);
        ReportTaskViewDTO taskViewDTO = reportSyncTaskRepository.get(context, queryViewDTO);
        bizReportTaskAbility.validateReportTaskQueryForDelete(context, queryViewDTO, taskViewDTO);
        return SingleResponse.of(reportSyncTaskRepository.delete(context, queryViewDTO));
    }

    @Override
    public SingleResponse<Long> runReportTask(ServiceContext context, ReportTaskQueryViewDTO taskQueryViewDTO) {
        bizReportTaskAbility.validateReportTaskQuery(context, taskQueryViewDTO);
        ReportTaskViewDTO taskViewDTO = reportSyncTaskRepository.get(context, taskQueryViewDTO);
        bizReportTaskAbility.validateReportTaskQueryForRun(context, taskQueryViewDTO, taskViewDTO);
        bizReportTaskAbility.getResult(context, taskViewDTO,Boolean.TRUE);
        return SingleResponse.of(taskViewDTO.getTaskId());
    }
}