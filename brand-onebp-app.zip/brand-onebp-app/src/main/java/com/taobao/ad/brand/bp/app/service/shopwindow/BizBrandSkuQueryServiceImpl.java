package com.taobao.ad.brand.bp.app.service.shopwindow;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.api.shopwindow.BizBrandSkuQueryService;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandBundleViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSkuViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.query.BrandBundleQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.query.BrandSkuQueryViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.shopwindow.atomability.ISkuSspProductLineAuthJudgeAbility;
import com.taobao.ad.brand.bp.domain.sdk.shopwindow.atomability.param.SkuSspProductLineAuthJudgeAbilityParam;
import com.taobao.ad.brand.bp.domain.shopwindow.repository.BrandSkuRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/7/8
 **/
@HSFProvider(serviceInterface = BizBrandSkuQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizBrandSkuQueryServiceImpl implements BizBrandSkuQueryService {

    private final BrandSkuRepository brandSkuRepository;
    private final ISkuSspProductLineAuthJudgeAbility skuSspProductLineAuthJudgeAbility;

    @Override
    public MultiResponse<BrandSkuViewDTO> queryBrandSkuList(ServiceContext serviceContext, BrandSkuQueryViewDTO queryViewDTO) {
        List<BrandSkuViewDTO> brandSkuViewDTOList = brandSkuRepository.findSkuList(serviceContext, queryViewDTO);
        // SKU风控准入判断
        Map<Long, Boolean> checkResult = skuSspProductLineAuthJudgeAbility.handle(serviceContext, SkuSspProductLineAuthJudgeAbilityParam.builder().abilityTargets(brandSkuViewDTOList).build());
        brandSkuViewDTOList.forEach(it -> it.setAuthJudge(checkResult.getOrDefault(it.getSspProductUuid(), false)));
        return MultiResponse.of(brandSkuViewDTOList);
    }

    @Override
    public MultiResponse<BrandBundleViewDTO> queryBrandBundleList(ServiceContext serviceContext, BrandBundleQueryViewDTO queryViewDTO) {
        List<BrandBundleViewDTO> bundleList = brandSkuRepository.findBundleList(serviceContext, queryViewDTO);
        return MultiResponse.of(bundleList);
    }

    @Override
    public SingleResponse<BrandBundleViewDTO> getBrandBundleDetail(ServiceContext serviceContext, Long bundleId) {
        AssertUtil.notNull(bundleId,"套餐包id不能为空");
        return SingleResponse.of(brandSkuRepository.getBundleDetail(serviceContext,bundleId));
    }
}
