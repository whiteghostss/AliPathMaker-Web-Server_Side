package com.taobao.ad.brand.bp.app.handler.campaigngroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.hermes.framework.ddd.event.annotation.DomainEventHandler;
import com.alibaba.securitysdk.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignCommandWorkflow;
import com.taobao.ad.brand.bp.app.workflow.campaigngroup.BizCampaignGroupCommandWorkflow;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupEventEnum;
import com.taobao.ad.brand.bp.domain.event.campaigngroup.CampaignGroupStatusTransitEvent;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

/**
 * @author yanjingang
 * @date 2023/3/12
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@DomainEventHandler(topic = "campaign_group_status_change", event = CampaignGroupStatusTransitEvent.class)
public class CampaignGroupProcessOrderHandler implements CampaignGroupProcessHandler {

    private final BizCampaignGroupCommandWorkflow bizCampaignGroupCommandWorkflow;

    private final BizCampaignCommandWorkflow bizCampaignCommandWorkflow;

    @Override
    public boolean onCondition(CampaignGroupStatusTransitEvent event) {
        CampaignGroupEventEnum campaignGroupEventEnum = event.getContext().getEventEnum();
        if (CampaignGroupEventEnum.ORDER.equals(campaignGroupEventEnum)) {
            return true;
        }
        return false;
    }

    @Override
    public Response handle(CampaignGroupStatusTransitEvent campaignGroupStatusTransitEvent) {
        if (!onCondition(campaignGroupStatusTransitEvent)) {
            return Response.success();
        }
        ServiceContext serviceContext = campaignGroupStatusTransitEvent.getContext().getServiceContext();
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupStatusTransitEvent.getContext().getCampaignGroupViewDTO();
        // 发起采购
        RogerLogger.info("CampaignGroupProcessOrderHandler executed");
        bizCampaignGroupCommandWorkflow.addPurchaseOrder(serviceContext, campaignGroupViewDTO);
        //天攻计划下单同步
        RogerLogger.info("CampaignGroupProcessOrderHandler orderDooh campaignGroupViewDTO: {}", JSON.toJSONString(campaignGroupViewDTO));
        bizCampaignCommandWorkflow.orderDooh(serviceContext, campaignGroupViewDTO);
        return Response.success();
    }
}
