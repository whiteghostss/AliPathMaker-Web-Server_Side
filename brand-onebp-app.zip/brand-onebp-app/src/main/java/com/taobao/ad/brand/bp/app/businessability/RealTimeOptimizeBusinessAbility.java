package com.taobao.ad.brand.bp.app.businessability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.adgroup.crowd.AdgroupCrowdScenarioViewDTO;
import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.audience.CampaignTargetScenarioViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdScenarioViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdViewDTO;
import com.alibaba.ad.brand.dto.campaign.keyword.CampaignKeywordViewDTO;
import com.alibaba.ad.brand.dto.campaign.realtime.CampaignRealTimeOptimizeViewDTO;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupTargetTypeEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.context.DomainMetaqMessageBodyContext;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryOption;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignRealTimeBatchOperateResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignRealTimeOptimizeInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.OptimizeCrowdsAdgroupParamsViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.ShopAndItemIdViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.CrowdViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.enums.SwitchEnum;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignCrowdSceneEnum;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignEventEnum;
import com.taobao.ad.brand.bp.client.enums.message.DomainMessageTypeEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.common.threadpooltask.CampaignRealTimeTaskIdentifier;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.dmp.CrowdRepository;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupAlgoControlCrowdAddAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupAlgoControlCrowdDeleteAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupRealTimeOptimizeAlgoCrowdParamBuildAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupRealTimeOptimizeAlgoCrowdSaveAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupRealTimeOptimizeCrowdDeleteAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupRealTimeOptimizeCrowdInitForAddOrUpdateAdgroupAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupRealTimeOptimizeCrowdSaveAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.query.IAdgroupStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.realtime.IAdgroupAlgoControlCrowdAddAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.realtime.IAdgroupAlgoControlCrowdDeleteAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.realtime.IAdgroupRealTimeOptimizeAlgoCrowdDeleteAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.realtime.IAdgroupRealTimeOptimizeAlgoCrowdParamBuildAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.realtime.IAdgroupRealTimeOptimizeAlgoCrowdSaveAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.realtime.IAdgroupRealTimeOptimizeCrowdInitForAddOrUpdateAdgroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.realtime.IAdgroupRealTimeOptimizeCrowdSaveAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.businessability.IAdgroupAddBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.businessability.IAdgroupUpdateBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbilityRouteContext;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.keyword.ICampaignKeywordAccessValidateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.keyword.ICampaignKeywordInitAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.keyword.ICampaignKeywordNormalValidateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.keyword.ICampaignKeywordValidateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.keyword.ICampaignKeywordSaveAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.keyword.ICampaignRealTimeOptimizeKeywordInitForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.realtime.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.targets.ICampaignAlgoControlCrowdAddAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.targets.ICampaignAlgoControlCrowdDeleteAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.targets.ICampaignAlgoControlCrowdInitForAddCrowdAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.targets.ICampaignRealTimeAlgoControlCrowdJudgeForAddOrUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.businessability.ICampaignAddBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.campaign.businessability.ICampaignAlgoControlCrowdAddBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.campaign.businessability.ICampaignRealTimeOptimizeAlgoCrowdBindBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.campaign.businessability.ICampaignRealTimeOptimizeSaveBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.campaign.businessability.ICampaignUpdateBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.IMessageAsyncSendAbility;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.param.MessageAsyncSendAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * 实时优选商业能力
 * @author yanjingang
 * @date 2024/9/4
 */
@Component
@BusinessAbility(tag = RealTimeOptimizeBusinessAbility.ABILITY_CODE, name = "实时优选支持商业能力", desc = "实时优选支持商业能力结构化实现类")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class RealTimeOptimizeBusinessAbility implements ICampaignAddBusinessAbilityPoint, ICampaignUpdateBusinessAbilityPoint,
        ICampaignRealTimeOptimizeSaveBusinessAbilityPoint,
        ICampaignRealTimeOptimizeAlgoCrowdBindBusinessAbilityPoint,
        ICampaignAlgoControlCrowdAddBusinessAbilityPoint,
        IAdgroupAddBusinessAbilityPoint, IAdgroupUpdateBusinessAbilityPoint {

    public static final String ABILITY_CODE = "BUSINESS_ABILITY_REAL_TIME_OPTIMIZE";

    private final CrowdRepository crowdRepository;
    private final CampaignRepository campaignRepository;
    private final ICampaignStructureQueryAbility campaignStructureQueryAbility;
    private final IAdgroupStructureQueryAbility adgroupStructureQueryAbility;

    private final ICampaignRealTimeOptimizeSwitchInitForAddCampaignAbility campaignRealTimeOptimizeSwitchInitForAddCampaignAbility;
    private final ICampaignRealTimeOptimizeSwitchInitForUpdateCampaignAbility campaignRealTimeOptimizeSwitchInitForUpdateCampaignAbility;
    private final ICampaignRealTimeOptimizeSwitchValidateForSaveOptimizeAbility campaignRealTimeOptimizeSwitchValidateForSaveOptimizeAbility;

    private final ICampaignRealTimeOptimizeConfigValidateAbility campaignRealTimeOptimizeConfigValidateAbility;
    private final ICampaignRealTimeOptimizeConfigInitAbility campaignRealTimeOptimizeConfigInitAbility;
    private final ICampaignRealTimeOptimizeConfigInitForAddCampaignAbility campaignRealTimeOptimizeConfigInitForAddCampaignAbility;
    private final ICampaignRealTimeOptimizeConfigInitForUpdateCampaignAbility campaignRealTimeOptimizeConfigInitForUpdateCampaignAbility;
    private final ICampaignRealTimeOptimizeConfigSaveAbility campaignRealTimeOptimizeConfigSaveAbility;

    private final ICampaignRealTimeOptimizeCrowdInitForUpdateCampaignAbility campaignRealTimeOptimizeCrowdInitForUpdateCampaignAbility;
    private final ICampaignRealTimeOptimizeValidateForAddCrowdAbility campaignRealTimeOptimizeValidateForAddCrowdAbility;
    private final ICampaignRealTimeOptimizeValidateForAddBlockCrowdAbility campaignRealTimeOptimizeValidateForAddBlockCrowdAbility;
    private final ICampaignRealTimeOptimizeCrowdSaveAbility campaignRealTimeOptimizeCrowdSaveAbility;

    private final ICampaignRealTimeOptimizeAlgoCrowdDeleteAbility campaignRealTimeOptimizeAlgoCrowdDeleteAbility;
    private final ICampaignRealTimeOptimizeAlgoCrowdSaveAbility campaignRealTimeOptimizeAlgoCrowdSaveAbility;

    private final ICampaignRealTimeOptimizeCategoryValidateAbility campaignRealTimeOptimizeCategoryValidateAbility;
    private final ICampaignRealTimeOptimizeCategoryInitAbility campaignRealTimeOptimizeCategoryInitAbility;
    private final ICampaignRealTimeOptimizeCategorySaveAbility campaignRealTimeOptimizeCategorySaveAbility;
    private final ICampaignRealTimeOptimizeCategoryInitForUpdateCampaignAbility campaignRealTimeOptimizeCategoryInitForUpdateCampaignAbility;

    private final ICampaignRealTimeAlgoControlCrowdJudgeForAddOrUpdateCampaignAbility campaignRealTimeAlgoControlCrowdJudgeForAddOrUpdateCampaignAbility;
    private final ICampaignAlgoControlCrowdInitForAddCrowdAbility campaignAlgoControlCrowdInitForAddCrowdAbility;
    private final ICampaignAlgoControlCrowdAddAbility campaignAlgoControlCrowdAddAbility;
    private final ICampaignAlgoControlCrowdDeleteAbility campaignAlgoControlCrowdDeleteAbility;

    private final IAdgroupAlgoControlCrowdDeleteAbility adgroupAlgoControlCrowdDeleteAbility;
    private final IAdgroupAlgoControlCrowdAddAbility adgroupAlgoControlCrowdAddAbility;

    private final IAdgroupRealTimeOptimizeCrowdInitForAddOrUpdateAdgroupAbility adgroupRealTimeOptimizeCrowdInitForAddOrUpdateAdgroupAbility;
    private final IAdgroupRealTimeOptimizeCrowdSaveAbility adgroupRealTimeOptimizeCrowdSaveAbility;

    private final IAdgroupRealTimeOptimizeAlgoCrowdDeleteAbility adgroupRealTimeOptimizeAlgoCrowdDeleteAbility;
    private final IAdgroupRealTimeOptimizeAlgoCrowdParamBuildAbility adgroupRealTimeOptimizeAlgoCrowdParamBuildAbility;
    private final IAdgroupRealTimeOptimizeAlgoCrowdSaveAbility adgroupRealTimeOptimizeAlgoCrowdSaveAbility;
    private final ICampaignKeywordAccessValidateAbility campaignKeywordAccessValidateAbility;
    private final ICampaignKeywordValidateAbility campaignKeywordValidateAbility;
    private final ICampaignKeywordNormalValidateAbility campaignKeywordNormalValidateAbility;
    private final ICampaignKeywordInitAbility campaignKeywordInitAbility;
    private final ICampaignKeywordSaveAbility campaignKeywordSaveAbility;
    private final ICampaignRealTimeOptimizeKeywordInitForUpdateCampaignAbility campaignRealTimeOptimizeKeywordInitForUpdateCampaignAbility;

    private final IMessageAsyncSendAbility messageAsyncSendAbility;
    private final CampaignRealTimeTaskIdentifier campaignRealTimeTaskIdentifier;

    @Override
    public boolean routeChecking(String bizCode, BaseViewDTO baseViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        List<String> specifiedBusinessCodes = businessAbilityRouteContext.getSpecifiedBusinessAbilityCodes();
        if (CollectionUtils.isNotEmpty(specifiedBusinessCodes) && specifiedBusinessCodes.contains(ABILITY_CODE)) {
            return true;
        }
        ProductViewDTO productViewDTO = businessAbilityRouteContext.getProductViewDTO();
        if (productViewDTO != null) {
            if (BrandBoolEnum.BRAND_TRUE.getCode().equals(productViewDTO.getCastExpansionOpen())) {
                return true;
            }
            if (BizCampaignToolsHelper.isShowmaxCampaign(productViewDTO.getMediaScope(), productViewDTO.getProductLineId(), productViewDTO.getCrossScene())) {
                return true;
            }
        }

        return false;
    }

    @Override
    public Void invokeForRealTimeOptimizeAlgoCrowdBind(ServiceContext serviceContext, Long campaignId) {
        CampaignViewDTO campaignViewDTO = getCampaignTree(serviceContext, campaignId);
        List<CampaignCrowdViewDTO> campaignCrowdViewDTOList = Optional.ofNullable(campaignViewDTO.getCampaignCrowdScenarioViewDTO())
                .map(CampaignCrowdScenarioViewDTO::getCampaignCrowdViewDTOList).orElse(null);
        if (CollectionUtils.isEmpty(campaignCrowdViewDTOList)) {
            return null;
        }

        if ((BizCampaignToolsHelper.isShowmaxCampaign(campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope(), campaignViewDTO.getCampaignResourceViewDTO().getSspProductLineId(), campaignViewDTO.getCampaignResourceViewDTO().getSspCrossScene()))
                || (BizCampaignToolsHelper.isTXCampaign(campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope(), campaignViewDTO.getCampaignResourceViewDTO().getSspProductLineId())
                && Objects.nonNull(campaignViewDTO.getCampaignExtViewDTO())
                && Objects.nonNull(campaignViewDTO.getCampaignRealTimeOptimizeViewDTO())
                && SwitchEnum.OPEN.getCode().equals(campaignViewDTO.getCampaignRealTimeOptimizeViewDTO().getIsCastingExpand())
                && SwitchEnum.OPEN.getCode().equals(campaignViewDTO.getCampaignRealTimeOptimizeViewDTO().getIntellectualCrowdSwitch()))
        ) {
            List<OptimizeCrowdsAdgroupParamsViewDTO> optimizeCrowdsAdgroupParamsViewDTOS = adgroupRealTimeOptimizeAlgoCrowdParamBuildAbility.handle(serviceContext, AdgroupRealTimeOptimizeAlgoCrowdParamBuildAbilityParam.builder().abilityTarget(campaignViewDTO).build());
            if (CollectionUtils.isEmpty(optimizeCrowdsAdgroupParamsViewDTOS)) {
                return null;
            }
            // 更新单元黑盒人群
            List<CampaignCrowdViewDTO> campaignAlgoCrowdViewDTOList = updateAdgroupOptimizeCrowdList(serviceContext, campaignViewDTO, optimizeCrowdsAdgroupParamsViewDTOS);
            // 更新计划黑盒人群
            campaignRealTimeOptimizeAlgoCrowdSaveAbility.handle(serviceContext, CampaignRealTimeOptimizeAlgoCrowdAbilityParam.builder()
                    .abilityTarget(campaignViewDTO).campaignAlgoCrowdViewDTOList(campaignAlgoCrowdViewDTOList).build());
        } else {
            campaignRealTimeOptimizeAlgoCrowdDeleteAbility.handle(serviceContext, CampaignRealTimeOptimizeConfigAbilityParam.builder()
                    .abilityTarget(campaignViewDTO.getCampaignRealTimeOptimizeViewDTO()).campaignViewDTO(campaignViewDTO).build());
            // 查询单元
            AdgroupQueryViewDTO queryViewDTO = new AdgroupQueryViewDTO();
            queryViewDTO.setCampaignId(campaignViewDTO.getId());
            AdgroupQueryOption queryOption = new AdgroupQueryOption();
            queryOption.setNeedTarget(true);
            List<AdgroupViewDTO> adgroupViewDTOList = adgroupStructureQueryAbility.handle(serviceContext, AdgroupStructureQueryAbilityParam.builder().abilityTarget(queryViewDTO).queryOption(queryOption).build());
            adgroupRealTimeOptimizeAlgoCrowdDeleteAbility.handle(serviceContext, AdgroupRealTimeOptimizeCrowdDeleteAbilityParam.builder().abilityTarget(campaignViewDTO).adgroupViewDTOList(adgroupViewDTOList).build());
        }

        return null;
    }

    @Override
    public Void invokeForCampaignAlgoControlCrowdAdd(ServiceContext serviceContext, CampaignViewDTO campaignTreeViewDTO) {
        // 是否支持初始化
        if (!BizCampaignToolsHelper.isTXorShowmaxCampaign(campaignTreeViewDTO.getCampaignResourceViewDTO().getSspMediaScope(), campaignTreeViewDTO.getCampaignResourceViewDTO().getSspProductLineId())) {
            return null;
        }
        // 删除计划黑盒人群
        campaignAlgoControlCrowdDeleteAbility.handle(serviceContext, CampaignAlgoControlCrowdDeleteAbilityParam.builder()
                .abilityTarget(campaignTreeViewDTO).campaignCrowdSceneEnum(CampaignCrowdSceneEnum.CASTING).build());
        // 查询单元
        AdgroupQueryViewDTO queryViewDTO = new AdgroupQueryViewDTO();
        queryViewDTO.setCampaignId(campaignTreeViewDTO.getId());
        queryViewDTO.setTargetType(BrandAdgroupTargetTypeEnum.PROGRAM.getCode());
        AdgroupQueryOption queryOption = new AdgroupQueryOption();
        queryOption.setNeedTarget(true);
        List<AdgroupViewDTO> adgroupViewDTOList = adgroupStructureQueryAbility.handle(serviceContext, AdgroupStructureQueryAbilityParam.builder().abilityTarget(queryViewDTO).queryOption(queryOption).build());
        // 删除单元黑盒人群
        adgroupAlgoControlCrowdDeleteAbility.handle(serviceContext, AdgroupAlgoControlCrowdDeleteAbilityParam.builder()
                .abilityTargets(adgroupViewDTOList).campaignCrowdSceneEnum(CampaignCrowdSceneEnum.CASTING).build());

        // "算法调控通投"人群
        boolean needAddAlgoControlCrowd = campaignRealTimeAlgoControlCrowdJudgeForAddOrUpdateCampaignAbility.handle(serviceContext, CampaignRealTimeAlgoControlCrowdJudgeForAddOrUpdateCampaignAbilityParam.builder()
                .abilityTarget(campaignTreeViewDTO).build());
        if (!needAddAlgoControlCrowd) {
            return null;
        }
        // 计划初始化
        campaignAlgoControlCrowdInitForAddCrowdAbility.handle(serviceContext, CampaignAlgoControlCrowdInitForAddCrowdAbilityParam.builder()
                .abilityTarget(campaignTreeViewDTO).campaignCrowdSceneEnum(CampaignCrowdSceneEnum.CASTING).build());
        // 计划新增
        campaignAlgoControlCrowdAddAbility.handle(serviceContext, CampaignAlgoControlCrowdAddAbilityParam.builder()
                .abilityTarget(campaignTreeViewDTO).campaignCrowdSceneEnum(CampaignCrowdSceneEnum.CASTING).build());
        // 单元新增
        adgroupAlgoControlCrowdAddAbility.handle(serviceContext, AdgroupAlgoControlCrowdAddAbilityParam.builder()
                .abilityTargets(adgroupViewDTOList).campaignViewDTO(campaignTreeViewDTO).campaignCrowdSceneEnum(CampaignCrowdSceneEnum.CASTING).build());

        return null;
    }

    private List<CampaignCrowdViewDTO> updateAdgroupOptimizeCrowdList(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, List<OptimizeCrowdsAdgroupParamsViewDTO> optimizeCrowdsAdgroupParamsViewDTOS) {
        // 1. 查询单元
        AdgroupQueryViewDTO queryViewDTO = new AdgroupQueryViewDTO();
        queryViewDTO.setCampaignId(campaignViewDTO.getId());
        List<Long> adgroupIds = optimizeCrowdsAdgroupParamsViewDTOS.stream().map(OptimizeCrowdsAdgroupParamsViewDTO::getAdgroupId).distinct().collect(Collectors.toList());
        queryViewDTO.setIds(adgroupIds);
        AdgroupQueryOption queryOption = new AdgroupQueryOption();
        queryOption.setNeedTarget(true);
        List<AdgroupViewDTO> adgroupViewDTOList = adgroupStructureQueryAbility.handle(serviceContext, AdgroupStructureQueryAbilityParam.builder().abilityTarget(queryViewDTO).queryOption(queryOption).build());

        Map<Long, CampaignCrowdViewDTO> dbCampaignCrowdMap = Optional.ofNullable(campaignViewDTO.getCampaignCrowdScenarioViewDTO())
                .map(CampaignCrowdScenarioViewDTO::getCampaignCrowdViewDTOList).orElse(Lists.newArrayList())
                .stream().collect(Collectors.toMap(CampaignCrowdViewDTO::getCrowdId, Function.identity()));
        Map<Long, OptimizeCrowdsAdgroupParamsViewDTO> optimizeCrowdsAdgroupParamsViewDTOMap = optimizeCrowdsAdgroupParamsViewDTOS
                .stream().collect(Collectors.toMap(OptimizeCrowdsAdgroupParamsViewDTO::getAdgroupId, Function.identity()));
        List<CampaignCrowdViewDTO> resultList = Lists.newArrayList();
        for (AdgroupViewDTO adgroupViewDTO : adgroupViewDTOList) {
            if (optimizeCrowdsAdgroupParamsViewDTOMap.containsKey(adgroupViewDTO.getId())) {
                // 1. 构建黑盒人群
                OptimizeCrowdsAdgroupParamsViewDTO optimizeCrowdsAdgroupParamsViewDTO = optimizeCrowdsAdgroupParamsViewDTOMap.get(adgroupViewDTO.getId());
                List<Long> itemIds = optimizeCrowdsAdgroupParamsViewDTO.getShopAndItemIdViewDTOList().stream().map(ShopAndItemIdViewDTO::getItemId).filter(Objects::nonNull).distinct().sorted().collect(Collectors.toList());
                List<Long> shopIds = optimizeCrowdsAdgroupParamsViewDTO.getShopAndItemIdViewDTOList().stream().map(ShopAndItemIdViewDTO::getShopId).filter(Objects::nonNull).distinct().sorted().collect(Collectors.toList());
                List<CampaignCrowdViewDTO> optimizeCrowdViewDTOList = campaignRepository.createOptimizeCrowdList(serviceContext, campaignViewDTO, campaignViewDTO.getCampaignRealTimeOptimizeViewDTO(), itemIds, shopIds);

                // 2. 单元更新黑盒人群（先删后增）
                adgroupRealTimeOptimizeAlgoCrowdSaveAbility.handle(serviceContext, AdgroupRealTimeOptimizeAlgoCrowdSaveAbilityParam.builder()
                        .abilityTarget(adgroupViewDTO).optimizeCrowdViewDTOList(optimizeCrowdViewDTOList).dbCampaignCrowdMap(dbCampaignCrowdMap).build());
                // 3. 写入返回结果
                for (CampaignCrowdViewDTO crowdViewDTO : optimizeCrowdViewDTOList) {
                    if (resultList.stream().noneMatch(campaignCrowdViewDTO -> BizCampaignToolsHelper.realTimeOptimizeCrowdsAreEqual(campaignCrowdViewDTO, crowdViewDTO))) {
                        resultList.add(crowdViewDTO);
                    }
                }
            }
        }

        return resultList;
    }

    @Override
    public Void invokeForCampaignAdd(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        CampaignRealTimeOptimizeViewDTO campaignRealTimeOptimizeViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignRealTimeOptimizeViewDTO()).orElse(new CampaignRealTimeOptimizeViewDTO());
        campaignViewDTO.setCampaignRealTimeOptimizeViewDTO(campaignRealTimeOptimizeViewDTO);
        // 初始化实时优选开关
        campaignRealTimeOptimizeSwitchInitForAddCampaignAbility.handle(serviceContext,  CampaignRealTimeOptimizeSwitchAbilityParam.builder()
                .abilityTarget(campaignRealTimeOptimizeViewDTO).campaignViewDTO(campaignViewDTO).productViewDTO(businessAbilityRouteContext.getProductViewDTO()).build());
        // 初始化智能人群配置信息
        campaignRealTimeOptimizeConfigInitForAddCampaignAbility.handle(serviceContext, CampaignRealTimeOptimizeConfigAbilityParam.builder()
                .abilityTarget(campaignRealTimeOptimizeViewDTO).campaignViewDTO(campaignViewDTO).build());

        return null;
    }

    @Override
    public Void invokeForCampaignUpdate(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, CampaignViewDTO dbLevelOneCampaignTreeViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        // 初始化实时优选开关
        CampaignRealTimeOptimizeViewDTO campaignRealTimeOptimizeViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignRealTimeOptimizeViewDTO()).orElse(new CampaignRealTimeOptimizeViewDTO());
        campaignViewDTO.setCampaignRealTimeOptimizeViewDTO(campaignRealTimeOptimizeViewDTO);
        campaignRealTimeOptimizeSwitchInitForUpdateCampaignAbility.handle(serviceContext,  CampaignRealTimeOptimizeSwitchAbilityParam.builder()
                .abilityTarget(campaignRealTimeOptimizeViewDTO).campaignViewDTO(campaignViewDTO).dbCampaignViewDTO(dbLevelOneCampaignTreeViewDTO).build());
        // 智能人群配置初始化
        campaignRealTimeOptimizeConfigInitForUpdateCampaignAbility.handle(serviceContext, CampaignRealTimeOptimizeConfigAbilityParam.builder()
                .abilityTarget(campaignRealTimeOptimizeViewDTO).campaignViewDTO(campaignViewDTO).dbCampaignViewDTO(dbLevelOneCampaignTreeViewDTO).build());

        // 投中人群初始化
        CampaignCrowdScenarioViewDTO campaignCrowdScenarioViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignCrowdScenarioViewDTO()).orElse(new CampaignCrowdScenarioViewDTO());
        campaignViewDTO.setCampaignCrowdScenarioViewDTO(campaignCrowdScenarioViewDTO);
        campaignRealTimeOptimizeCrowdInitForUpdateCampaignAbility.handle(serviceContext, CampaignRealTimeOptimizeCrowdInitAbilityParam.builder()
                .abilityTarget(campaignCrowdScenarioViewDTO).campaignViewDTO(campaignViewDTO).dbCampaignViewDTO(dbLevelOneCampaignTreeViewDTO).build());
        // 投中类目初始化
        CampaignTargetScenarioViewDTO campaignTargetScenarioViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignTargetScenarioViewDTO()).orElse(new CampaignTargetScenarioViewDTO());
        campaignViewDTO.setCampaignTargetScenarioViewDTO(campaignTargetScenarioViewDTO);
        campaignRealTimeOptimizeCategoryInitForUpdateCampaignAbility.handle(serviceContext, CampaignRealTimeCategoryInitForUpdateCampaignAbilityParam.builder()
                .abilityTarget(campaignTargetScenarioViewDTO).campaignViewDTO(campaignViewDTO).dbCampaignViewDTO(dbLevelOneCampaignTreeViewDTO).build());

        // 投中关键词初始化
        CampaignKeywordViewDTO campaignKeywordViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignKeywordViewDTO()).orElse(new CampaignKeywordViewDTO());
        campaignViewDTO.setCampaignKeywordViewDTO(campaignKeywordViewDTO);
        campaignRealTimeOptimizeKeywordInitForUpdateCampaignAbility.handle(serviceContext, CampaignRealTimeKeywordInitForUpdateCampaignAbilityParam.builder()
                .abilityTarget(campaignKeywordViewDTO).campaignViewDTO(campaignViewDTO).dbCampaignViewDTO(dbLevelOneCampaignTreeViewDTO).build());
        return null;
    }

    @Override
    public Void invokeForAfterCampaignUpdate(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList, BusinessAbilityRouteContext businessAbilityRouteContext) {
        // 关闭实时优选-删除单元投中人群(白盒+黑盒)
        return null;
    }

    @Override
    public Void invokeForAdgroupAdd(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, CampaignViewDTO campaignViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        AdgroupCrowdScenarioViewDTO adgroupCrowdScenarioViewDTO = Optional.ofNullable(adgroupViewDTO.getAdgroupCrowdScenarioViewDTO()).orElse(new AdgroupCrowdScenarioViewDTO());
        adgroupViewDTO.setAdgroupCrowdScenarioViewDTO(adgroupCrowdScenarioViewDTO);
        if (CollectionUtils.isEmpty(adgroupCrowdScenarioViewDTO.getAdgroupCrowdViewDTOList())) {
            return null;
        }
        adgroupRealTimeOptimizeCrowdInitForAddOrUpdateAdgroupAbility.handle(serviceContext, AdgroupRealTimeOptimizeCrowdInitForAddOrUpdateAdgroupAbilityParam.builder()
                .abilityTarget(adgroupCrowdScenarioViewDTO).campaignViewDTO(campaignViewDTO).build());
        return null;
    }

    /**
     * 执行商业能力调用
     * @param serviceContext
     * @param adgroupViewDTO
     * @param campaignViewDTO
     * @param businessAbilityRouteContext
     * @return
     */
    @Override
    public Void invokeForAfterAdgroupAdd(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, CampaignViewDTO campaignViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        // 删除
        adgroupAlgoControlCrowdDeleteAbility.handle(serviceContext, AdgroupAlgoControlCrowdDeleteAbilityParam.builder()
                .abilityTargets(Lists.newArrayList(adgroupViewDTO)).campaignCrowdSceneEnum(CampaignCrowdSceneEnum.CASTING).build());
        // 新增
        adgroupAlgoControlCrowdAddAbility.handle(serviceContext, AdgroupAlgoControlCrowdAddAbilityParam.builder()
                .abilityTargets(Lists.newArrayList(adgroupViewDTO)).campaignViewDTO(campaignViewDTO).campaignCrowdSceneEnum(CampaignCrowdSceneEnum.CASTING).build());
        return null;
    }

    @Override
    public Void invokeForAdgroupUpdate(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, CampaignViewDTO campaignViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        return invokeForAdgroupAdd(serviceContext, adgroupViewDTO, campaignViewDTO, businessAbilityRouteContext);
    }

    /**
     * 执行商业能力调用
     * @param serviceContext
     * @param adgroupViewDTO
     * @param campaignViewDTO
     * @param businessAbilityRouteContext
     * @return
     */
    @Override
    public Void invokeForAfterAdgroupUpdate(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, CampaignViewDTO campaignViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        return invokeForAfterAdgroupAdd(serviceContext, adgroupViewDTO, campaignViewDTO, businessAbilityRouteContext);
    }

    private CampaignViewDTO getCampaignTree(ServiceContext context, Long campaignId) {
        List<CampaignViewDTO> campaignTreeViewDTOList = findCampaignTreeList(context, Lists.newArrayList(campaignId));
        return campaignTreeViewDTOList.get(0);
    }

    private List<CampaignViewDTO> findCampaignTreeList(ServiceContext context, List<Long> campaignIds) {
        CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder().campaignIds(campaignIds).build();
        CampaignQueryOption queryOption = CampaignQueryOption.builder().needTarget(true).needCampaignTree(true).build();
        List<CampaignViewDTO> campaignTreeViewDTOList = campaignStructureQueryAbility.handle(context, CampaignStructureQueryAbilityParam.builder()
                .abilityTarget(campaignQueryViewDTO).queryOption(queryOption).build());
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(campaignTreeViewDTOList), BrandOneBPBaseErrorCode.PARAM_BREAK_RULE, "计划不存在");
        return campaignTreeViewDTOList;
    }

    @Override
    public Void invokeForRealTimeOptimizeSave(ServiceContext context, CampaignRealTimeOptimizeInfoViewDTO realTimeOptimizeInfoViewDTO) {
        // 1. 获取参数
        CampaignViewDTO campaignTreeViewDTO = getCampaignTree(context, realTimeOptimizeInfoViewDTO.getCampaignId());
        rebuildRealTimeOptimizeInfoViewDTO(context, realTimeOptimizeInfoViewDTO);
        // 2. 校验
        // 通用校验
        campaignRealTimeOptimizeSwitchValidateForSaveOptimizeAbility.handle(context, CampaignRealTimeOptimizeSwitchAbilityParam.builder()
                .abilityTarget(campaignTreeViewDTO.getCampaignRealTimeOptimizeViewDTO()).campaignViewDTO(campaignTreeViewDTO).build());

        // 2-1. 校验智能推荐人群配置信息
        if (BrandBoolEnum.BRAND_TRUE.getCode().equals(realTimeOptimizeInfoViewDTO.getCanConfigOptimize())) {
            campaignRealTimeOptimizeConfigValidateAbility.handle(context, CampaignRealTimeOptimizeConfigAbilityParam.builder()
                    .abilityTarget(realTimeOptimizeInfoViewDTO.getOptimizeConfig()).campaignViewDTO(campaignTreeViewDTO).build());
        }
        // 2-2. 校验人群信息
        if (BrandBoolEnum.BRAND_TRUE.getCode().equals(realTimeOptimizeInfoViewDTO.getCanAddCrowd())) {
            campaignRealTimeOptimizeValidateForAddCrowdAbility.handle(context, CampaignRealTimeOptimizeCrowdAbilityParam.builder()
                    .abilityTarget(campaignTreeViewDTO).realTimeOptimizeInfoViewDTO(realTimeOptimizeInfoViewDTO).build());
        }
        if (BrandBoolEnum.BRAND_TRUE.getCode().equals(realTimeOptimizeInfoViewDTO.getCanAddBlockCrowd())) {
            campaignRealTimeOptimizeValidateForAddBlockCrowdAbility.handle(context, CampaignRealTimeOptimizeCrowdAbilityParam.builder()
                    .abilityTarget(campaignTreeViewDTO).realTimeOptimizeInfoViewDTO(realTimeOptimizeInfoViewDTO).build());
        }

        // 2-3. 校验投中类目信息
        if (BrandBoolEnum.BRAND_TRUE.getCode().equals(realTimeOptimizeInfoViewDTO.getCanAddCategory())) {
            campaignRealTimeOptimizeCategoryValidateAbility.handle(context, CampaignRealTimeOptimizeCategoryAbilityParam.builder()
                    .abilityTarget(realTimeOptimizeInfoViewDTO).campaignTreeViewDTO(campaignTreeViewDTO).build());
        }

        // 2-4. 校验关键词信息
        if (BrandBoolEnum.BRAND_TRUE.getCode().equals(realTimeOptimizeInfoViewDTO.getCanAddKeyword())) {
            CampaignKeywordViewDTO campaignKeywordViewDTO = new CampaignKeywordViewDTO();
            campaignKeywordViewDTO.setCampaignWordViewDTOList(realTimeOptimizeInfoViewDTO.getCampaignKeywordList());
            //投中不操作词包，用db的词包信息进行填充，后续有部分逻辑依赖词包信息进行判断
            campaignKeywordViewDTO.setCampaignWordPackageViewDTO(campaignTreeViewDTO.getCampaignKeywordViewDTO().getCampaignWordPackageViewDTO());
            CampaignKeywordAbilityParam campaignKeywordAbilityParam = CampaignKeywordAbilityParam.builder().abilityTarget(campaignKeywordViewDTO).campaignViewDTO(campaignTreeViewDTO).build();
            //3.1 基础信息初始化(做了关键词对表情包的剔除，剔除之后才能过风控和归一化，所以把初始化放在前面)
            campaignKeywordInitAbility.handle(context, campaignKeywordAbilityParam);
            //3.2 风控准入校验
            String currAccessMsg = campaignKeywordAccessValidateAbility.handle(context, campaignKeywordAbilityParam);
            AssertUtil.assertTrue(StringUtils.isEmpty(currAccessMsg), "以下关键词不可使用，原因如下：\n" + currAccessMsg);
            //3.3 归一化词重复校验
            String currNormalMsg = campaignKeywordNormalValidateAbility.handle(context, campaignKeywordAbilityParam);
            AssertUtil.assertTrue(StringUtils.isEmpty(currNormalMsg), "关键词存在同义词，请调整后重试");
            //3.4 关键词数量校验
            campaignKeywordValidateAbility.handle(context, campaignKeywordAbilityParam);
        }


        if (BrandBoolEnum.BRAND_TRUE.getCode().equals(realTimeOptimizeInfoViewDTO.getCanConfigOptimize())) {
            // 3. 初始化
            // 3-1. 初始化智能推荐人群配置信息
            campaignRealTimeOptimizeConfigInitAbility.handle(context, CampaignRealTimeOptimizeConfigAbilityParam.builder()
                    .abilityTarget(realTimeOptimizeInfoViewDTO.getOptimizeConfig()).campaignViewDTO(campaignTreeViewDTO).build());

            // 4. 保存智能推荐人群配置信息
            doProcessForRealTimeOptimizeConfigSave(context, campaignTreeViewDTO, realTimeOptimizeInfoViewDTO.getOptimizeConfig());
        }

        // 5. 保存白盒人群信息
        if (BrandBoolEnum.BRAND_TRUE.getCode().equals(realTimeOptimizeInfoViewDTO.getCanAddCrowd())
                || BrandBoolEnum.BRAND_TRUE.getCode().equals(realTimeOptimizeInfoViewDTO.getCanAddBlockCrowd())) {
            // 5-1. 保存计划人群信息(白盒+屏蔽人群)
            campaignRealTimeOptimizeCrowdSaveAbility.handle(context, CampaignRealTimeOptimizeCrowdAbilityParam.builder()
                    .abilityTarget(campaignTreeViewDTO).realTimeOptimizeInfoViewDTO(realTimeOptimizeInfoViewDTO).build());
            // 重新查询计划信息
            campaignTreeViewDTO = getCampaignTree(context, campaignTreeViewDTO.getId());
            // 5-2. 保存单元白盒人群信息
            adgroupRealTimeOptimizeCrowdSaveAbility.handle(context, AdgroupRealTimeOptimizeCrowdSaveAbilityParam.builder().abilityTarget(campaignTreeViewDTO).build());
        }
        // 6. 投中类目信息
        if (BrandBoolEnum.BRAND_TRUE.getCode().equals(realTimeOptimizeInfoViewDTO.getCanAddCategory())) {
            // 初始化
            campaignRealTimeOptimizeCategoryInitAbility.handle(context, CampaignRealTimeOptimizeCategoryAbilityParam.builder()
                    .abilityTarget(realTimeOptimizeInfoViewDTO).campaignTreeViewDTO(campaignTreeViewDTO).build());
            // 保存
            campaignRealTimeOptimizeCategorySaveAbility.handle(context, CampaignRealTimeOptimizeCategoryAbilityParam.builder()
                    .abilityTarget(realTimeOptimizeInfoViewDTO).campaignTreeViewDTO(campaignTreeViewDTO).build());
        }

        // 7. 关键词人群配置信息
        if (BrandBoolEnum.BRAND_TRUE.getCode().equals(realTimeOptimizeInfoViewDTO.getCanAddKeyword())) {
            // 保存
            CampaignKeywordViewDTO campaignKeywordViewDTO = new CampaignKeywordViewDTO();
            campaignKeywordViewDTO.setCampaignWordViewDTOList(realTimeOptimizeInfoViewDTO.getCampaignKeywordList());
            campaignKeywordViewDTO.setCampaignWordPackageViewDTO(campaignTreeViewDTO.getCampaignKeywordViewDTO().getCampaignWordPackageViewDTO());
            //一级计划
            campaignTreeViewDTO.setCampaignKeywordViewDTO(campaignKeywordViewDTO);
            campaignKeywordSaveAbility.handle(context, CampaignKeywordSaveAbilityParam.builder().abilityTargets(Lists.newArrayList(campaignTreeViewDTO)).build());

            //二级计划
            if (CollectionUtils.isNotEmpty(campaignTreeViewDTO.getSubCampaignViewDTOList())) {
                campaignTreeViewDTO.getSubCampaignViewDTOList().stream().forEach(e->e.setCampaignKeywordViewDTO(campaignKeywordViewDTO));
            }
            campaignKeywordSaveAbility.handle(context, CampaignKeywordSaveAbilityParam.builder().abilityTargets(campaignTreeViewDTO.getSubCampaignViewDTOList()).build());
        }

        // 后置处理
        if (BrandBoolEnum.BRAND_TRUE.getCode().equals(realTimeOptimizeInfoViewDTO.getCanConfigOptimize())) {
            fireAsyncMessageEvent(context, campaignTreeViewDTO.getId(), CampaignEventEnum.REAL_TIME_OPTIMIZE_CONFIG);
        }

        return null;
    }

    /**
     * 生成异步通知事件
     * @param serviceContext
     * @param campaignId
     * @return
     */
    private void fireAsyncMessageEvent(ServiceContext serviceContext, Long campaignId, CampaignEventEnum domainEvent){
        DomainMetaqMessageBodyContext msgBodyContext = DomainMetaqMessageBodyContext.builder()
                .bizCode(serviceContext.getBizCode())
                .domainType(DomainMessageTypeEnum.MAIN_CAMPAIGN)
                .domainEvent(domainEvent.name())
                .entityId(campaignId)
                .memberId(serviceContext.getMemberId())
                .build();
        messageAsyncSendAbility.handle(serviceContext, MessageAsyncSendAbilityParam.builder().abilityTarget(msgBodyContext).build());
    }

    @Override
    public CampaignRealTimeBatchOperateResultViewDTO invokeForRealTimeOptimizeBatchSave(ServiceContext context, List<Long> campaignIds, CampaignRealTimeOptimizeViewDTO campaignRealTimeOptimizeViewDTO) {
        // 1. 获取参数
        List<CampaignViewDTO> campaignViewDTOList = findCampaignTreeList(context, campaignIds);

        // 不支持操作的计划
        List<Long> unSupportFailIds = Lists.newArrayList();
        for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
            try {
                // 校验开关
                campaignRealTimeOptimizeSwitchValidateForSaveOptimizeAbility.handle(context, CampaignRealTimeOptimizeSwitchAbilityParam.builder()
                        .abilityTarget(campaignViewDTO.getCampaignRealTimeOptimizeViewDTO()).campaignViewDTO(campaignViewDTO).build());
            } catch (Exception e) {
                RogerLogger.info(String.format("batchOptimizeConfig unSupportOperate, memberId:%s, campaignId:%s, e:%s",
                        campaignViewDTO.getMemberId(), campaignViewDTO.getId(), e.getMessage()),e);
                unSupportFailIds.add(campaignViewDTO.getId());
            }
        }
        if (CollectionUtils.isNotEmpty(unSupportFailIds)) {
            campaignViewDTOList = campaignViewDTOList.stream()
                    .filter(campaignViewDTO -> !unSupportFailIds.contains(campaignViewDTO.getId()))
                    .collect(Collectors.toList());
        }

        // 校验失败的计划
        List<Long> validateFailList = Lists.newArrayList();
        for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
            try {
                // 2. 校验
                // 2-1. 校验智能推荐人群配置信息
                campaignRealTimeOptimizeConfigValidateAbility.handle(context, CampaignRealTimeOptimizeConfigAbilityParam.builder()
                        .abilityTarget(campaignRealTimeOptimizeViewDTO).campaignViewDTO(campaignViewDTO).build());
            } catch (Exception e) {
                RogerLogger.info("batchOptimizeConfig validate fail,memberId:{}, campaignId:{}, e:{}", campaignViewDTO.getMemberId(), campaignViewDTO.getId(),
                        e.getMessage());
                validateFailList.add(campaignViewDTO.getId());
            }
        }
        if (CollectionUtils.isNotEmpty(validateFailList)) {
            campaignViewDTOList = campaignViewDTOList.stream()
                    .filter(campaignViewDTO->!validateFailList.contains(campaignViewDTO.getId()))
                    .collect(Collectors.toList());
        }

        List<CampaignRealTimeBatchOperateResultViewDTO> operateResultViewDTOList = TaskStream.execute(campaignRealTimeTaskIdentifier, campaignViewDTOList, (campaignViewDTO, index) -> {
            try {
                // 3. 初始化智能推荐人群配置信息
                campaignRealTimeOptimizeConfigInitAbility.handle(context, CampaignRealTimeOptimizeConfigAbilityParam.builder()
                        .abilityTarget(campaignRealTimeOptimizeViewDTO).campaignViewDTO(campaignViewDTO).build());
                // 4. 执行保存
                doProcessForRealTimeOptimizeConfigSave(context, campaignViewDTO, campaignRealTimeOptimizeViewDTO);

                return CampaignRealTimeBatchOperateResultViewDTO.builder().operateSuccessIds(Lists.newArrayList(campaignViewDTO.getId())).build();
            } catch (Exception e) {
                RogerLogger.info("batchOptimizeSwitch operate fail,memberId:{}, campaignId:{}, e:{}", campaignViewDTO.getMemberId(), campaignViewDTO.getId(), e.getMessage());
                return CampaignRealTimeBatchOperateResultViewDTO.builder().operateFailIds(Lists.newArrayList(campaignViewDTO.getId())).build();
            }
        }).commit().getResultList();

        //操作失败
        List<Long> operateFailList = operateResultViewDTOList.stream().filter(result -> CollectionUtils.isNotEmpty(result.getOperateFailIds()))
                .flatMap(result -> result.getOperateFailIds().stream()).collect(Collectors.toList());
        //操作成功
        List<Long> operateSuccessList = operateResultViewDTOList.stream().filter(result -> CollectionUtils.isNotEmpty(result.getOperateSuccessIds()))
                .flatMap(result -> result.getOperateSuccessIds().stream()).collect(Collectors.toList());

        // 后置处理
        if (CollectionUtils.isNotEmpty(operateSuccessList)) {
            for (Long campaignId : operateSuccessList) {
                fireAsyncMessageEvent(context, campaignId, CampaignEventEnum.REAL_TIME_OPTIMIZE_CONFIG);
            }
        }

        return CampaignRealTimeBatchOperateResultViewDTO.builder()
                .operateSuccessIds(operateSuccessList)
                .unSupportFailIds(unSupportFailIds)
                .validateFailIds(validateFailList)
                .operateFailIds(operateFailList)
                .build();
    }

    private void doProcessForRealTimeOptimizeConfigSave(ServiceContext context, CampaignViewDTO campaignViewDTO, CampaignRealTimeOptimizeViewDTO campaignRealTimeOptimizeViewDTO) {
        // 保存计划智能推荐人群配置信息
        campaignRealTimeOptimizeConfigSaveAbility.handle(context, CampaignRealTimeOptimizeConfigAbilityParam.builder().abilityTarget(campaignRealTimeOptimizeViewDTO).campaignViewDTO(campaignViewDTO).build());
        // 关闭智能推荐人群配置信息处理
        if (SwitchEnum.CLOSE.getCode().equals(campaignRealTimeOptimizeViewDTO.getIntellectualCrowdSwitch())) {
            campaignRealTimeOptimizeAlgoCrowdDeleteAbility.handle(context, CampaignRealTimeOptimizeConfigAbilityParam.builder().abilityTarget(campaignRealTimeOptimizeViewDTO).campaignViewDTO(campaignViewDTO).build());
            // 查询单元
            AdgroupQueryViewDTO queryViewDTO = new AdgroupQueryViewDTO();
            queryViewDTO.setCampaignId(campaignViewDTO.getId());
            AdgroupQueryOption queryOption = new AdgroupQueryOption();
            queryOption.setNeedTarget(true);
            List<AdgroupViewDTO> adgroupViewDTOList = adgroupStructureQueryAbility.handle(context, AdgroupStructureQueryAbilityParam.builder().abilityTarget(queryViewDTO).queryOption(queryOption).build());
            adgroupRealTimeOptimizeAlgoCrowdDeleteAbility.handle(context, AdgroupRealTimeOptimizeCrowdDeleteAbilityParam.builder().abilityTarget(campaignViewDTO).adgroupViewDTOList(adgroupViewDTOList).build());
        }
    }

    private void rebuildRealTimeOptimizeInfoViewDTO(ServiceContext context, CampaignRealTimeOptimizeInfoViewDTO realTimeOptimizeInfoViewDTO) {
        List<Long> crowdIds = Lists.newArrayList();
        if (CollectionUtils.isNotEmpty(realTimeOptimizeInfoViewDTO.getCrowdList())) {
            crowdIds.addAll(realTimeOptimizeInfoViewDTO.getCrowdList().stream().map(CrowdViewDTO::getCrowdId).collect(Collectors.toList()));
        }
        if (CollectionUtils.isNotEmpty(realTimeOptimizeInfoViewDTO.getBlockCrowdList())) {
            crowdIds.addAll(realTimeOptimizeInfoViewDTO.getBlockCrowdList().stream().map(CrowdViewDTO::getCrowdId).collect(Collectors.toList()));
        }
        Map<Long, CrowdViewDTO> dmpCrowdMap = crowdRepository.queryCrowdByIds(context, crowdIds)
                .stream().collect(Collectors.toMap(CrowdViewDTO::getCrowdId, Function.identity(), (v1, v2) -> v1));
        if (CollectionUtils.isNotEmpty(realTimeOptimizeInfoViewDTO.getCrowdList())) {
            realTimeOptimizeInfoViewDTO.setCrowdList(realTimeOptimizeInfoViewDTO.getCrowdList().stream().map(crowd -> {
                if (!dmpCrowdMap.containsKey(crowd.getCrowdId())) {
                    return crowd;
                }
                return dmpCrowdMap.get(crowd.getCrowdId());
            }).collect(Collectors.toList()));
        }
        if (CollectionUtils.isNotEmpty(realTimeOptimizeInfoViewDTO.getBlockCrowdList())) {
            realTimeOptimizeInfoViewDTO.setBlockCrowdList(realTimeOptimizeInfoViewDTO.getBlockCrowdList().stream().map(crowd -> {
                if (!dmpCrowdMap.containsKey(crowd.getCrowdId())) {
                    return crowd;
                }
                return dmpCrowdMap.get(crowd.getCrowdId());
            }).collect(Collectors.toList()));
        }
    }
}
