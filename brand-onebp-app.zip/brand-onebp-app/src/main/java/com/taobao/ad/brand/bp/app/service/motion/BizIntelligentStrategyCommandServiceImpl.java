package com.taobao.ad.brand.bp.app.service.motion;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.service.OpType;
import com.alibaba.abf.spec.service.annotation.ProcessEntrance;
import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.alibaba.ad.nb.packages.v2.client.constant.motion.MotionStatusEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.motion.StrategyStatusEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleProductLineEnum;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.alimama.faas.brand.engine.entity.constant.BizType;
import com.alimama.faas.brand.engine.entity.domain.PriceStageConfig;
import com.alimama.faas.brand.engine.entity.domain.ResourceConfig;
import com.alimama.faas.brand.engine.entity.request.PreStrategyRcmdRequest;
import com.alimama.faas.brand.engine.entity.response.PreStrategyRcmdResponse;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.app.workflow.motion.BizIntelligentStrategyCommandWorkflow;
import com.taobao.ad.brand.bp.client.api.motion.BizIntelligentStrategyCommandService;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.DmpArgusEstimateViewDTO;
import com.taobao.ad.brand.bp.client.dto.cartitem.query.CartItemQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.motion.IntelligentMotionViewDTO;
import com.taobao.ad.brand.bp.client.dto.motion.IntelligentStrategyViewDTO;
import com.taobao.ad.brand.bp.client.dto.motion.query.StrategyQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSkuViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.query.BrandSkuQueryViewDTO;
import com.taobao.ad.brand.bp.common.enums.BooleanEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.cart.repository.CartItemRepository;
import com.taobao.ad.brand.bp.domain.config.SelfServiceTestMemberConfig;
import com.taobao.ad.brand.bp.domain.dmpargus.DmpArgusRepository;
import com.taobao.ad.brand.bp.domain.motion.IntelligentMotionRepository;
import com.taobao.ad.brand.bp.domain.motion.IntelligentStrategyRepository;
import com.taobao.ad.brand.bp.domain.perform.PerformRepository;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.shopwindow.repository.BrandSkuRepository;
import com.taobao.ad.brand.perform.client.dto.shopwindow.spu.marketingrule.SpuCheckMarketingRuleViewDTO;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/4/18
 **/
@HSFProvider(serviceInterface = BizIntelligentStrategyCommandService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizIntelligentStrategyCommandServiceImpl implements BizIntelligentStrategyCommandService {

    private final IntelligentStrategyRepository intelligentStrategyRepository;
    private final IntelligentMotionRepository intelligentMotionRepository;
    private final DmpArgusRepository dmpArgusRepository;
    private final BizIntelligentStrategyCommandWorkflow bizIntelligentStrategyCommandWorkflow;


    @Override
    public Response noticeIntelligentStrategyResult(ServiceContext serviceContext, String intelligentStrategy) {
        PreStrategyRcmdResponse strategyRcmdResponse = JSONObject.parseObject(intelligentStrategy, PreStrategyRcmdResponse.class);
        RogerLogger.info("BizIntelligentStrategyCommandServiceImpl.strategyRcmdResponse: {}" + JSON.toJSONString(strategyRcmdResponse));
        AssertUtil.notNull(strategyRcmdResponse, "智能策略结果不能为空");
        IntelligentMotionViewDTO intelligentMotionViewDTO = intelligentMotionRepository.getIntelligentMotionById(serviceContext, strategyRcmdResponse.getProposalId());
        // 该接口传入的serviceContext是在AMB构建的写死常量，需要使用提案信息填充memberId，因为查加购行需要用到memberId
        serviceContext.setMemberId(intelligentMotionViewDTO.getMemberId());
        // 请求失败
        if (!BooleanEnum.FALSE.getValue().equals(strategyRcmdResponse.getErrorCode())) {
            IntelligentMotionViewDTO motionViewDTO = new IntelligentMotionViewDTO();
            motionViewDTO.setId(strategyRcmdResponse.getProposalId());
            motionViewDTO.setStatus(MotionStatusEnum.CALCULATE_FAILED.getValue());
            motionViewDTO.setErrorReason(strategyRcmdResponse.getMessage());
            intelligentMotionRepository.saveOrUpdateIntelligentMotion(serviceContext, motionViewDTO);
            if (BizType.BRAND_WINDOW_RECOMMEND.equals(strategyRcmdResponse.getBizType())) {
                bizIntelligentStrategyCommandWorkflow.supplyPreStrategyRcmdResponse(serviceContext, intelligentMotionViewDTO, strategyRcmdResponse);
                bizIntelligentStrategyCommandWorkflow.saveIntelligentStrategyResult(serviceContext, strategyRcmdResponse);
            }
        // 请求成功
        } else {
            bizIntelligentStrategyCommandWorkflow.saveIntelligentStrategyResult(serviceContext, strategyRcmdResponse);
            IntelligentMotionViewDTO motionViewDTO = intelligentMotionRepository.getIntelligentMotionById(serviceContext, strategyRcmdResponse.getProposalId());
            if (!MotionStatusEnum.STRATEGY_SELECTED.getValue().equals(motionViewDTO.getStatus())) {
                intelligentMotionRepository.updateIntelligentMotionListStatus(serviceContext, Lists.newArrayList(strategyRcmdResponse.getProposalId()), MotionStatusEnum.PRODUCED.getValue());
            }
        }
        return Response.success();
    }

    @Override
    public Response calculateNewIntelligentStrategy(ServiceContext serviceContext, IntelligentStrategyViewDTO strategyViewDTO) {
        DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO = bizIntelligentStrategyCommandWorkflow.buildEstimateViewDTOBaseOnStrategy(serviceContext, strategyViewDTO);
        dmpArgusRepository.calculateIntelligentMotionAndStrategy(serviceContext, dmpArgusEstimateViewDTO);

        return Response.success();
    }

    public Response refreshIntelligentStrategy(ServiceContext serviceContext, IntelligentStrategyViewDTO strategyViewDTO) {
        DmpArgusEstimateViewDTO dmpArgusEstimateViewDTO = bizIntelligentStrategyCommandWorkflow.buildEstimateViewDTOBaseOnStrategy(serviceContext, strategyViewDTO);
        PreStrategyRcmdResponse response = dmpArgusRepository.updateIntelligentStrategy(serviceContext, dmpArgusEstimateViewDTO);
        PreStrategyRcmdRequest strategy = response.getProposalList().get(0);
        IntelligentStrategyViewDTO updateStrategyViewDTO = new IntelligentStrategyViewDTO();
        updateStrategyViewDTO.setId(strategyViewDTO.getId());
        updateStrategyViewDTO.setPredictDataViewDTO(bizIntelligentStrategyCommandWorkflow.buildPredictDataViewDTO(strategy.getDeliverTargetResult()));
        intelligentStrategyRepository.saveIntelligentStrategy(serviceContext, updateStrategyViewDTO);
        return Response.success();
    }

    @Override
    public Response updateBasicIntelligentStrategy(ServiceContext serviceContext, IntelligentStrategyViewDTO strategyViewDTO) {
        AssertUtil.notNull(strategyViewDTO.getId(), "策略id不能为空");
        intelligentStrategyRepository.updateBasicIntelligentStrategy(serviceContext, strategyViewDTO);
        return Response.success();
    }

    @Override
    public SingleResponse<Long> saveIntelligentStrategy(ServiceContext serviceContext, IntelligentStrategyViewDTO strategyViewDTO) {
        AssertUtil.notNull(strategyViewDTO, "策略不能为空");
        Long id = intelligentStrategyRepository.saveIntelligentStrategy(serviceContext, strategyViewDTO);
        return SingleResponse.of(id);
    }

    @Override
    @Transactional
    public Response preferIntelligentStrategy(ServiceContext serviceContext, IntelligentStrategyViewDTO strategyViewDTO) {
        AssertUtil.notNull(strategyViewDTO.getId(), "策略id不能为空");
        AssertUtil.notNull(strategyViewDTO.getMotionId(), "提案id不能为空");
        AssertUtil.notNull(strategyViewDTO.getStatus(), "策略状态不能为空");
        List<IntelligentStrategyViewDTO> intelligentStrategyViewDTOList = intelligentStrategyRepository.queryIntelligentStrategyList(serviceContext, StrategyQueryViewDTO.builder().motionId(strategyViewDTO.getMotionId()).build());
        for (IntelligentStrategyViewDTO intelligentStrategyViewDTO : intelligentStrategyViewDTOList) {
            IntelligentStrategyViewDTO updateStrategyViewDTO = new IntelligentStrategyViewDTO();
            updateStrategyViewDTO.setId(intelligentStrategyViewDTO.getId());
            updateStrategyViewDTO.setStatus(Objects.equals(intelligentStrategyViewDTO.getId(), strategyViewDTO.getId()) ? strategyViewDTO.getStatus() : StrategyStatusEnum.NEW.getValue());
            intelligentStrategyRepository.updateBasicIntelligentStrategy(serviceContext, updateStrategyViewDTO);
        }
        intelligentMotionRepository.updateIntelligentMotionListStatus(serviceContext, Lists.newArrayList(strategyViewDTO.getMotionId()),
                StrategyStatusEnum.PREFERRED.getValue().equals(strategyViewDTO.getStatus()) ? MotionStatusEnum.STRATEGY_SELECTED.getValue() : MotionStatusEnum.PRODUCED.getValue());
        return Response.success();
    }
}
