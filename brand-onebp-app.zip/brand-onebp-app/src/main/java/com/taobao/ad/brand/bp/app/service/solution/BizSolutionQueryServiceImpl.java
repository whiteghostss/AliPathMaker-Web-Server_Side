package com.taobao.ad.brand.bp.app.service.solution;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.app.workflow.solution.BizSolutionQueryWorkWorkflow;
import com.taobao.ad.brand.bp.client.api.solution.BizSolutionQueryService;
import com.taobao.ad.brand.bp.client.dto.solution.CartItemSolutionViewDTO;
import com.taobao.ad.brand.bp.client.dto.solution.query.CartItemSolutionQueryOption;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

@HSFProvider(serviceInterface = BizSolutionQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizSolutionQueryServiceImpl implements BizSolutionQueryService {

    private final BizSolutionQueryWorkWorkflow bizSolutionQueryWorkWorkflow;

    @Override
    public SingleResponse<CartItemSolutionViewDTO> getCartItemSolutionInfo(ServiceContext context, Long cartItemId, CartItemSolutionQueryOption queryOption) {
        CartItemSolutionViewDTO cartItemSolutionInfo = bizSolutionQueryWorkWorkflow.getCartItemSolutionInfo(context, cartItemId, queryOption);
        return SingleResponse.of(cartItemSolutionInfo);
    }
}
