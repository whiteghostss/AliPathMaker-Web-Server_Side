package com.taobao.ad.brand.bp.app.handler.campagin;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryLockViewDTO;
import com.alibaba.hermes.framework.ddd.event.annotation.DomainEventHandler;
import com.alibaba.hermes.framework.event.EventHandler;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignInventoryWorkflow;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.event.campaign.CampaignLockExpireTimeInitEvent;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Objects;

/**
 * @author jixiu.lj
 * @date 2023/8/5 23:59
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@DomainEventHandler(topic = "campaign_lock_expire_time_init", event = CampaignLockExpireTimeInitEvent.class)
public class CampaignLockExpireTimeInitHandler implements EventHandler<CampaignLockExpireTimeInitEvent> {

    private final BizCampaignInventoryWorkflow bizCampaignInventoryWorkflow;
    private final CampaignRepository campaignRepository;

    @Override
    public Response handle(CampaignLockExpireTimeInitEvent campaignLockExpireTimeInitEvent) {
        ServiceContext serviceContext = campaignLockExpireTimeInitEvent.getContext().getServiceContext();
        CampaignViewDTO campaignViewDTO = campaignLockExpireTimeInitEvent.getContext().getCampaignViewDTO();
        CampaignViewDTO dbCampaignViewDTO = new CampaignViewDTO();
        dbCampaignViewDTO.setId(campaignViewDTO.getId());
        CampaignInquiryLockViewDTO campaignInquiryLockViewDTO = new CampaignInquiryLockViewDTO();
        // 计算一级计划锁量有效期
        Date lockExpireTime = bizCampaignInventoryWorkflow.calculateLockExpireTime(serviceContext, campaignViewDTO);
        if(Objects.nonNull(lockExpireTime)) {
            campaignInquiryLockViewDTO.setLockExpireTime(lockExpireTime);
        }
        campaignInquiryLockViewDTO.setLockCallBackTime(BrandDateUtil.getCurrentDate());
        dbCampaignViewDTO.setCampaignInquiryLockViewDTO(campaignInquiryLockViewDTO);
        campaignRepository.updateCampaignPart(serviceContext, Lists.newArrayList(dbCampaignViewDTO));
        return Response.success();
    }
}
