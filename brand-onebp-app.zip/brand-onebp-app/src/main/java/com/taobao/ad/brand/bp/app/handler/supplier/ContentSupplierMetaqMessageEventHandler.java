package com.taobao.ad.brand.bp.app.handler.supplier;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.hermes.framework.ddd.event.annotation.DomainEventHandler;
import com.alibaba.hermes.framework.event.EventHandler;
import com.alibaba.rocketmq.client.exception.MQClientException;
import com.alibaba.rocketmq.client.producer.SendResult;
import com.alibaba.rocketmq.client.producer.SendStatus;
import com.alibaba.rocketmq.common.message.Message;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.github.rholder.retry.RetryException;
import com.github.rholder.retry.Retryer;
import com.github.rholder.retry.RetryerBuilder;
import com.github.rholder.retry.StopStrategies;
import com.github.rholder.retry.WaitStrategies;
import com.taobao.ad.brand.bp.client.context.ContentSupplierMetaqMessageBodyContext;
import com.taobao.ad.brand.bp.domain.event.supplier.ContentSupplierMetaqMessageEvent;
import com.taobao.metaq.client.MetaProducer;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@DomainEventHandler(topic = "content_supplier_metaq_message_topic", event = ContentSupplierMetaqMessageEvent.class)
public class ContentSupplierMetaqMessageEventHandler implements EventHandler<ContentSupplierMetaqMessageEvent> {

    @Value("${metaq.content.supplier.event.topic}")
    private String contentSupplierMqTopic;

    private final MetaProducer producer = new MetaProducer("MQ_GROUP_BRAND_ONE_BP_CONTENT_SUPPLIER");

    Retryer<SendResult> retryer = RetryerBuilder.<SendResult>newBuilder()
            .retryIfException()
            .retryIfResult(e -> e.getSendStatus() != SendStatus.SEND_OK)
            .withWaitStrategy(WaitStrategies.fixedWait(1, TimeUnit.SECONDS))
            .withStopStrategy(StopStrategies.stopAfterAttempt(3))
            .build();

    @PostConstruct
    public void init() {
        try {
            producer.start();
        } catch (MQClientException e) {
            throw new RuntimeException(e);
        }
    }

    @PreDestroy
    public void destroy() {
        producer.shutdown();
    }


    @Override
    public Response handle(ContentSupplierMetaqMessageEvent event) {
        ContentSupplierMetaqMessageBodyContext bodyContext = event.getContext();

        String messageKey = getKey(bodyContext.getTag(), bodyContext.getCampaignGroupId(), bodyContext.getDemandId());
            Message message = new Message();
            message.setTopic(contentSupplierMqTopic);
            message.setTags(bodyContext.getTag());
            message.setKeys(messageKey);
            message.setBody(JSON.toJSONBytes(bodyContext));
            try {
                RogerLogger.info("send content supplier message start：{}", JSONObject.toJSONString(bodyContext));
                SendResult sendResult = retryer.call(() -> producer.send(message));
                RogerLogger.info("send content supplier message end：messageKey {}, result {}", messageKey, sendResult);
            } catch (ExecutionException | RetryException e) {
                RogerLogger.error("retry send content supplier message error {}", e.getMessage(), e);
                return Response.failure();
            }


        return Response.success();
    }

    private String getKey(String tag, Long campaignGroupId, Long demandId) {
        return new StringBuilder(tag).append("-")
                .append(campaignGroupId).append("-")
                .append(demandId).append("-")
                .append(new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date())).toString();
    }
}
