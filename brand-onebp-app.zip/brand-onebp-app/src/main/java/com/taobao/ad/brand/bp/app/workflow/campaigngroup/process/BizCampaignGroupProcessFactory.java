package com.taobao.ad.brand.bp.app.workflow.campaigngroup.process;

import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.alibaba.cola.statemachine.builder.StateMachineBuilder;
import com.taobao.ad.brand.bp.client.context.CampaignGroupStateContext;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupEventEnum;
import com.taobao.ad.brand.bp.common.statemachine.BrandStateMachine;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import lombok.RequiredArgsConstructor;

/**
 * 订单状态机Factory
 *
 * @author yanjingang
 * @date 2023/3/6
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizCampaignGroupProcessFactory {

    private static final String CAMPAIGN_GROUP_STATE_MACHINE_ID = "campaignGroupStateMachine";
    @Resource(name = "campaignGroupStateMachineBuilder")
    private StateMachineBuilder<BrandCampaignGroupStatusEnum, CampaignGroupEventEnum, CampaignGroupStateContext> campaignGroupStateMachineBuilder;
    private static BrandStateMachine<BrandCampaignGroupStatusEnum, CampaignGroupEventEnum, CampaignGroupStateContext> campaignGroupStateMachine;

    private final BizCampaignGroupProcessDefiner bizCampaignGroupProcessDefiner;

    @PostConstruct
    public void init() {

        // 主订单定义流程
        bizCampaignGroupProcessDefiner.defineCampaignGroupProcess(campaignGroupStateMachineBuilder);
        // 初始化子订单状态机
        campaignGroupStateMachine = (BrandStateMachine) campaignGroupStateMachineBuilder.build(CAMPAIGN_GROUP_STATE_MACHINE_ID);
    }

    public static BrandStateMachine<BrandCampaignGroupStatusEnum, CampaignGroupEventEnum, CampaignGroupStateContext> getCampaignGroupStateMachine() {
        return campaignGroupStateMachine;
    }
}
