package com.taobao.ad.brand.bp.app.spi.campaign.inventory.impl;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.nb.framework.core.annotation.AbilitySpiInstance;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.app.spi.campaign.inventory.BizCampaignInventoryOperateSpi;
import com.taobao.ad.brand.bp.app.spi.campaign.inventory.BizCampaignInventorySpi;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignInquiryOperateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignScheduleViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignScheduleIsInventoryEnum;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.inventory.ICampaignInquiryChannelGetForCampaignInventoryOperateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignInventoryOperateChannelGetAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignInventoryWorkflowParam;
import org.apache.commons.collections.CollectionUtils;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.common.spi.ExtensionPointsFactory.runAbilitySpi;

@AbilitySpiInstance(bizCode = BizCampaignInventoryOperateSpi.SCROLL_DAILY_UPDATE, name = "scrollDailyUpdateBizCampaignInventoryOperateSpiImpl", desc = "库存日更操作实现")
public class ScrollDailyUpdateBizCampaignInventoryOperateSpiImpl extends DefaultBizCampaignInventoryOperateSpiImpl {

    @Resource
    private ICampaignInquiryChannelGetForCampaignInventoryOperateAbility campaignInquiryChannelGetForCampaignInventoryOperateAbility;

    @Override
    public Void inventoryRequest(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO, BizCampaignInventoryWorkflowParam inventoryWorkflowParam) {
//        bizCampaignInventoryAbility.doInventoryRequest(serviceContext, inventoryAbilityParam.getCampaignTreeViewDTOList(), inventoryAbilityParam.getCampaignScheduleViewDTOList());
        List<CampaignScheduleViewDTO> campaignScheduleViewDTOList = inventoryWorkflowParam.getCampaignScheduleViewDTOList();
        List<CampaignViewDTO> campaignTreeViewDTOList = inventoryWorkflowParam.getCampaignTreeViewDTOList();
        if(CollectionUtils.isEmpty(campaignTreeViewDTOList)){
            RogerLogger.info("ScrollDailyUpdate 计划不符合滚量条件，不执行滚量逻辑");
            return null;
        }
        //1. 计划和排期归两类，需要走库存的，和不需要走库存的
        Map<Integer, List<CampaignViewDTO>> isInventoryCampaignMap = campaignInquiryChannelGetForCampaignInventoryOperateAbility.handle(serviceContext,
                CampaignInventoryOperateChannelGetAbilityParam.builder().abilityTargets(campaignTreeViewDTOList).build());

        List<CampaignViewDTO> needInventoryCampaignViewDTOList = isInventoryCampaignMap.get(CampaignScheduleIsInventoryEnum.NEED_INVENTORY.getValue());
        if(CollectionUtils.isEmpty(needInventoryCampaignViewDTOList)){
            RogerLogger.info("ScrollDailyUpdate 非库存操作计划，不执行滚量逻辑");
            return null;
        }
        List<Long> campaignIds = needInventoryCampaignViewDTOList.stream().map(campaignViewDTO -> campaignViewDTO.getId()).collect(Collectors.toList());
        List<CampaignScheduleViewDTO> needInventoryCampaignScheduleViewDTOList = campaignScheduleViewDTOList.stream().filter(e->campaignIds.contains(e.getId())).collect(Collectors.toList());
        //2. 执行库存日更操作
        runAbilitySpi(BizCampaignInventorySpi.class,
                extension -> extension.inventoryRequest(serviceContext, inquiryOperateViewDTO, needInventoryCampaignViewDTOList,needInventoryCampaignScheduleViewDTOList),
                    CampaignScheduleIsInventoryEnum.NEED_INVENTORY.name());
        return null;
    }
}

