package com.taobao.ad.brand.bp.app.workflow.insight;

import com.alibaba.abf.governance.context.ServiceContext;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.dto.insight.WinInsightQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.insight.WinInsightDimenisonTypeEnum;
import com.taobao.ad.brand.bp.client.enums.insight.WinInsightMetricsEnum;
import com.taobao.ad.brand.bp.client.enums.report.ReportTotalTypeEnum;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.EasyExcelUtil;
import com.taobao.ad.brand.bp.domain.oss.OssRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 加购行流程
 *
 * @author shiyan
 * @date 2024/06/26
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class WinInsightExportWorkflow {

    private final WinInsightQueryWorkflow winInsightQueryWorkflow;
    private final OssRepository ossRepository;


    public String basicExport(ServiceContext serviceContext, WinInsightQueryViewDTO winInsightQueryViewDTO) {
        List<Map<String, Object>> basicData = buildBasicExportData(serviceContext, winInsightQueryViewDTO);
        List<Map<String, Object>> transferredData = transferData(basicData);
        Map<String, String> fieldMap = Maps.newLinkedHashMap();
        fieldMap.put("metrics_name", "指标名称");
        fieldMap.put("value", "当前值");
        fieldMap.put("last_period_value", "环比值");
        fieldMap.put("last_period_change_rate", "环比变化");
        fieldMap.put("benchmark", "基准值");
        fieldMap.put("benchmark_change_rate", "对比基准");
        byte[] excelData = EasyExcelUtil.listToExcel("win指标详情", fieldMap, transferredData);
        String fileName = String.format("win指标详情-%d%d.xlsx", System.currentTimeMillis(), serviceContext.getMemberId());
        String path = "winMetrics/" + fileName;
        ossRepository.upload(fileName, path, excelData);
        return ossRepository.getTemporaryDownloadUrl(path);
    }

    public String industryExport(ServiceContext serviceContext, WinInsightQueryViewDTO winInsightQueryViewDTO) {
        List<Map<String, Object>> dataMap = buildIndustryExportData(serviceContext, winInsightQueryViewDTO);
        Map<String, String> fieldMap = Maps.newLinkedHashMap();
        fieldMap.put("index", "排名");
        fieldMap.put("brand_id", "品牌ID");
        fieldMap.put("brand_name", "品牌名称");
        fieldMap.put("win_index", "win指标");
        fieldMap.put("index_change", "排名变化");
        byte[] excelData = EasyExcelUtil.listToExcel("一级类目x品牌排名", fieldMap, dataMap);
        String fileName = String.format("一级类目x品牌排名-%d%d.xlsx", System.currentTimeMillis(), serviceContext.getMemberId());
        String path = "winMetrics/" + fileName;
        ossRepository.upload(fileName, path, excelData);
        return ossRepository.getTemporaryDownloadUrl(path);
    }


    private List<Map<String, Object>> transferData(List<Map<String, Object>> dataList) {
        Map<String, Object> nowData = dataList.get(0);
        Map<String, Object> benchMarkData = dataList.get(1);
        Map<String, Object> lastPeriodData = dataList.get(2);
        List<Map<String, Object>> resultList = Lists.newArrayList();
        WinInsightMetricsEnum.getDataMetrics().forEach(metricsEnum -> {
            Map<String, Object> data = Maps.newHashMap();
            data.put("metrics_name", metricsEnum.getMetricsDesc());
            data.put("value", nowData.get(metricsEnum.getMetricsName()));
            data.put("last_period_value", lastPeriodData.getOrDefault(metricsEnum.getMetricsName(), ""));

            Object lastPeriodValueObj = lastPeriodData.get(metricsEnum.getMetricsName());
            Object nowValueObj = nowData.get(metricsEnum.getMetricsName());
            BigDecimal nowValue = nowValueObj == null ? BigDecimal.ZERO : new BigDecimal(String.valueOf(nowValueObj));
            BigDecimal lastPeriodValue = lastPeriodValueObj == null ? BigDecimal.ZERO : new BigDecimal(String.valueOf(lastPeriodValueObj));
            if (lastPeriodValue.compareTo(BigDecimal.ZERO) == 0) {
                data.put("last_period_change_rate", "-");
            } else {
                BigDecimal indexChangeRate = nowValue.subtract(lastPeriodValue);
                BigDecimal divide = indexChangeRate.divide(lastPeriodValue, 4, RoundingMode.HALF_UP);
                BigDecimal percent = divide.multiply(new BigDecimal(100)).setScale(2, RoundingMode.HALF_UP);
                data.put("last_period_change_rate", percent.doubleValue() + "%");
            }

            Object benchMarkValueObj = benchMarkData.get(metricsEnum.getMetricsName());
            BigDecimal benchMarkValue = benchMarkValueObj == null ? BigDecimal.ZERO : new BigDecimal(String.valueOf(benchMarkValueObj));

            data.put("benchmark", benchMarkValue);
            if(benchMarkValue.compareTo(BigDecimal.ZERO) == 0) {
                data.put("benchmark_change_rate", "");
            } else {
                BigDecimal indexChangeRate = nowValue.subtract(benchMarkValue);
                BigDecimal divide = indexChangeRate.divide(benchMarkValue, 4, RoundingMode.HALF_UP);
                BigDecimal percent = divide.multiply(new BigDecimal(100)).setScale(2, RoundingMode.HALF_UP);
                data.put("benchmark_change_rate", percent.doubleValue() + "%");
            }
            resultList.add(data);
        });
        return resultList;
    }


    private List<Map<String, Object>> buildBasicExportData(ServiceContext serviceContext, WinInsightQueryViewDTO winInsightQueryViewDTO) {
        List<Map<String, Object>> resultList = Lists.newArrayList();
        // 1. 查询当前时间段win指标
        WinInsightQueryViewDTO queryViewDTO = new WinInsightQueryViewDTO();
        queryViewDTO.setCateLevelOneId(winInsightQueryViewDTO.getCateLevelOneId());
        queryViewDTO.setCateLevelTwoId(winInsightQueryViewDTO.getCateLevelTwoId());
        queryViewDTO.setCateLevelLeafId(winInsightQueryViewDTO.getCateLevelLeafId());
        queryViewDTO.setStartPrice(winInsightQueryViewDTO.getStartPrice());
        queryViewDTO.setEndPrice(winInsightQueryViewDTO.getEndPrice());
        queryViewDTO.setStartTime(winInsightQueryViewDTO.getStartTime());
        queryViewDTO.setEndTime(winInsightQueryViewDTO.getEndTime());
        queryViewDTO.setDimension(WinInsightDimenisonTypeEnum.MEMBER.getValue());
        queryViewDTO.setBrandId(winInsightQueryViewDTO.getBrandId());
        String customIndex = Lists.newArrayList(WinInsightMetricsEnum.getDataMetrics()).stream().map(WinInsightMetricsEnum::getMetricsName).collect(Collectors.joining(Constant.CHAR_SPLIT_KEY_DOT));
        queryViewDTO.setCustomIndex(customIndex);
        queryViewDTO.setTotalType(ReportTotalTypeEnum.TOTAL.getValue());
        if (Objects.nonNull(winInsightQueryViewDTO.getTopicId())) {
            queryViewDTO.setTopicId(winInsightQueryViewDTO.getTopicId());
        }
        List<Map<String, Object>> nowWinDataList = winInsightQueryWorkflow.query(serviceContext, queryViewDTO);
        List<Map<String, Object>> reformatNowDataList = reformat(nowWinDataList);
        if (CollectionUtils.isNotEmpty(reformatNowDataList)) {
            resultList.add(reformatNowDataList.get(0));
        } else {
            resultList.add(Maps.newHashMap());
        }
        // 2. 计算benchmark基准值
        queryViewDTO.setBenchmarkType(winInsightQueryViewDTO.getBenchmarkType());
        List<Map<String, Object>> benchMarkWinDataList = winInsightQueryWorkflow.query(serviceContext, queryViewDTO);
        List<Map<String, Object>> reformatBenchMarkDataList = reformat(benchMarkWinDataList);
        if (CollectionUtils.isNotEmpty(reformatBenchMarkDataList)) {
            resultList.add(reformatBenchMarkDataList.get(0));
        } else {
            resultList.add(Maps.newHashMap());
        }
        // 3. 计算环比时间段win指标
        Pair<Date, Date> datePair = BrandDateUtil.getCycleDateViewDTO(BrandDateUtil.string2Date(winInsightQueryViewDTO.getStartTime(), BrandDateUtil.DATE_FORMAT_YYYYMMDD_TYPE_2), BrandDateUtil.string2Date(winInsightQueryViewDTO.getEndTime(), BrandDateUtil.DATE_FORMAT_YYYYMMDD_TYPE_2));
        queryViewDTO.setBenchmarkType(null);
        queryViewDTO.setStartTime(BrandDateUtil.date2String(datePair.getLeft(), BrandDateUtil.DATE_FORMAT_YYYYMMDD_TYPE_2));
        queryViewDTO.setEndTime(BrandDateUtil.date2String(datePair.getRight(), BrandDateUtil.DATE_FORMAT_YYYYMMDD_TYPE_2));
        List<Map<String, Object>> lastPeriodWinDataList = winInsightQueryWorkflow.query(serviceContext, queryViewDTO);
        List<Map<String, Object>> reformatLastPeriodDataList = reformat(lastPeriodWinDataList);
        if (CollectionUtils.isNotEmpty(reformatLastPeriodDataList)) {
            resultList.add(reformatLastPeriodDataList.get(0));
        } else {
            resultList.add(Maps.newHashMap());
        }
        return resultList;
    }


    private List<Map<String, Object>> buildIndustryExportData(ServiceContext serviceContext, WinInsightQueryViewDTO winInsightQueryViewDTO) {
        List<Map<String, Object>> resultList = Lists.newArrayList();
        // 1. 查询同行品牌win指标，并按照win指标排序
        WinInsightQueryViewDTO queryViewDTO = new WinInsightQueryViewDTO();
        queryViewDTO.setCateLevelOneId(winInsightQueryViewDTO.getCateLevelOneId());
        queryViewDTO.setCateLevelTwoId(winInsightQueryViewDTO.getCateLevelTwoId());
        queryViewDTO.setCateLevelLeafId(winInsightQueryViewDTO.getCateLevelLeafId());
        queryViewDTO.setStartPrice(winInsightQueryViewDTO.getStartPrice());
        queryViewDTO.setEndPrice(winInsightQueryViewDTO.getEndPrice());
        queryViewDTO.setStartTime(winInsightQueryViewDTO.getStartTime());
        queryViewDTO.setEndTime(winInsightQueryViewDTO.getEndTime());
        queryViewDTO.setDimension(WinInsightDimenisonTypeEnum.BRAND.getValue());
        queryViewDTO.setCustomIndex(WinInsightMetricsEnum.WIN_INDEX.getMetricsName());
        queryViewDTO.setTotalType(ReportTotalTypeEnum.TOTAL.getValue());
        if (Objects.nonNull(winInsightQueryViewDTO.getTopicId())) {
            queryViewDTO.setTopicId(winInsightQueryViewDTO.getTopicId());
        }
        List<Map<String, Object>> nowWinDataList = winInsightQueryWorkflow.query(serviceContext, queryViewDTO);
        List<Map<String, Object>> reformatNowDataList = reformat(nowWinDataList);

        // 2. 计算环比时间数据
        Pair<Date, Date> datePair = BrandDateUtil.getCycleDateViewDTO(BrandDateUtil.string2Date(winInsightQueryViewDTO.getStartTime(), BrandDateUtil.DATE_FORMAT_YYYYMMDD_TYPE_2), BrandDateUtil.string2Date(winInsightQueryViewDTO.getEndTime(), BrandDateUtil.DATE_FORMAT_YYYYMMDD_TYPE_2));
        queryViewDTO.setStartTime(BrandDateUtil.date2String(datePair.getLeft(), BrandDateUtil.DATE_FORMAT_YYYYMMDD_TYPE_2));
        queryViewDTO.setEndTime(BrandDateUtil.date2String(datePair.getRight(), BrandDateUtil.DATE_FORMAT_YYYYMMDD_TYPE_2));
        List<Map<String, Object>> lastPeriodWinDataList = winInsightQueryWorkflow.query(serviceContext, queryViewDTO);
        List<Map<String, Object>> reformatLastPeriodDataList = reformat(lastPeriodWinDataList);
        List<Long> brandIdList = reformatLastPeriodDataList.stream().map(dataMap -> Long.parseLong(String.valueOf(dataMap.get(WinInsightMetricsEnum.BRAND_ID.getMetricsName())))).collect(Collectors.toList());

        for (int i = 0; i < reformatNowDataList.size(); i++) {
            Map<String, Object> result = Maps.newHashMap();
            Map<String, Object> dataMap = reformatNowDataList.get(i);

            Object brandIdObj = dataMap.get(WinInsightMetricsEnum.BRAND_ID.getMetricsName());
            Long brandId = Objects.isNull(brandIdObj) ? null : Long.parseLong(brandIdObj.toString());

            Object brandNameObj = dataMap.get(WinInsightMetricsEnum.BRAND_NAME.getMetricsName());
            String brandName = Objects.isNull(brandNameObj) ? null : String.valueOf(brandNameObj.toString());

            Object winIndexObj = dataMap.get(WinInsightMetricsEnum.WIN_INDEX.getMetricsName());
            Double winIndex = Objects.isNull(winIndexObj) ? null : Double.parseDouble(winIndexObj.toString());

            // 找出上一周期中当前品牌所在的次序
            int lastIndex = !brandIdList.contains(brandId) ? 0 : brandIdList.indexOf(brandId);
            result.put("index", i + 1);
            result.put("brand_id", brandId == null ? "" : brandId);
            result.put("brand_name", brandName == null ? "" : brandName);
            result.put("win_index", winIndex == null ? "" : winIndex);
            result.put("index_change", lastIndex - i > 0 ? "+" + (lastIndex - i) : lastIndex - i);
            resultList.add(result);
        }
        return resultList;
    }

    /**
     * 数据格式化
     * @param dataList
     * @return
     */
    private List<Map<String, Object>> reformat(List<Map<String, Object>> dataList) {

        if(CollectionUtils.isNotEmpty(dataList)) {
            dataList.forEach(data -> {
                data.forEach((key, value) -> {
                    // 保留4位小数
                    if(WinInsightMetricsEnum.getRateDataMetrics().contains(WinInsightMetricsEnum.of(key))) {
                        if(Objects.nonNull(value)) {
                            BigDecimal bigDecimal = new BigDecimal(String.valueOf(value)).setScale(4, RoundingMode.HALF_UP);
                            data.put(key, bigDecimal.doubleValue());
                        }
                    }

                    // win指标保留2位小数
                    if(WinInsightMetricsEnum.getWindDataMetrics().contains(WinInsightMetricsEnum.of(key))) {
                        if(Objects.nonNull(value)) {
                            BigDecimal bigDecimal = new BigDecimal(String.valueOf(value)).setScale(2, RoundingMode.HALF_UP);
                            data.put(key, bigDecimal.doubleValue());
                        }
                    }

                    // 其余数据指标直接取整
                    if(WinInsightMetricsEnum.getBasicDataMetrics().contains(WinInsightMetricsEnum.of(key))) {
                        if(Objects.nonNull(value)) {
                            BigDecimal bigDecimal = new BigDecimal(String.valueOf(value)).setScale(0, RoundingMode.HALF_UP);
                            data.put(key, bigDecimal.doubleValue());
                        }
                    }
                });
            });
        }
        return dataList;
    }
}
