package com.taobao.ad.brand.bp.app.service.cartitem;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.app.workflow.cartitem.BizCartItemCommandWorkflow;
import com.taobao.ad.brand.bp.client.api.cart.BizCartItemCommandService;
import com.taobao.ad.brand.bp.client.dto.cartitem.CartItemOrderViewDTO;
import com.taobao.ad.brand.bp.client.dto.cartitem.CustomerContactViewDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * 单元相关的command实现
 * @author 弈云
 * @date 2023年03月08日
 */
@HSFProvider(serviceInterface = BizCartItemCommandService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizCartItemCommandServiceImpl implements BizCartItemCommandService {
    private final BizCartItemCommandWorkflow bizCartItemCommandWorkflow;
    /**
     * 同一种类型sku同账户下只能有一个有效的
     * @param context
     * @param cartViewDTO
     * @return
     */
    @Override
    public SingleResponse<Long> addCartItem(ServiceContext context, CartItemViewDTO cartViewDTO) {
        Long id = bizCartItemCommandWorkflow.addCartItem(context, cartViewDTO);
        return SingleResponse.of(id);
    }

    @Override
    public MultiResponse<Long> batchDeleteCartItem(ServiceContext context, List<Long> ids) {
        return bizCartItemCommandWorkflow.batchDeleteCart(context,ids);
    }

    @Override
    public SingleResponse<Long> cartItemOrder(ServiceContext context, CartItemOrderViewDTO cartItemOrderViewDTO){
        Long campaignGroupId = bizCartItemCommandWorkflow.cartItemOrder(context, cartItemOrderViewDTO);
        return SingleResponse.of(campaignGroupId);
    }

    @Override
    public Response saveCustomerContact(ServiceContext context, CustomerContactViewDTO customerContactViewDTO) {
        bizCartItemCommandWorkflow.saveCustomerContact(context, customerContactViewDTO);
        return Response.success();
    }
}