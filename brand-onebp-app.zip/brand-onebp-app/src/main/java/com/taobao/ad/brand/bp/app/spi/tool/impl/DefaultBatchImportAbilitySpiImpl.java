package com.taobao.ad.brand.bp.app.spi.tool.impl;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.nb.framework.core.AbilityFactory;
import com.alibaba.ad.nb.framework.core.annotation.AbilitySpiInstance;
import com.taobao.ad.brand.bp.app.spi.tool.BatchImportAbilitySpi;
import com.taobao.ad.brand.bp.client.dto.tool.BatchImportDistLockParamViewDTO;
import com.taobao.ad.brand.bp.client.dto.tool.BatchImportParamViewDTO;

@AbilitySpiInstance(bizCode = AbilityFactory.DEFAULT_BIZ_CODE, name = "DefaultBatchImportAbilitySpiImpl", desc = "批量导入默认实现")
public class DefaultBatchImportAbilitySpiImpl implements BatchImportAbilitySpi {

    @Override
    public Void validateImportParam(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO) {
        return null;
    }

    @Override
    public BatchImportDistLockParamViewDTO buildImportDisLockParam(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO) {
        return null;
    }

    @Override
    public String tryDisLockErrorMessage(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO, String distCurValue) {
        return null;
    }

    @Override
    public Void invokeImport(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO) {
        return null;
    }

    @Override
    public Void updateImportResult(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO) {
        return null;
    }

    @Override
    public String invokeImportExceptionMessage(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO, String exceptionMeg) {
        return null;
    }
}
