package com.taobao.ad.brand.bp.app.workflow.account.permission;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.common.annotation.SwitchContext;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.adapter.port.converter.account.permission.AdcMenuModulePermissionConverter;
import com.taobao.ad.brand.bp.client.dto.account.login.LoginSessionViewDTO;
import com.taobao.ad.brand.bp.client.dto.account.permission.AdcMenuModulePermissionViewDTO;
import com.taobao.ad.brand.bp.client.dto.account.permission.WriteReadPermissionsViewDTO;
import com.taobao.ad.brand.bp.client.dto.adc.AdcComponentViewDTO;
import com.taobao.ad.brand.bp.client.dto.adc.query.AdcQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.adc.query.BasicVisibleComponentQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.MemberTypeEnum;
import com.taobao.ad.brand.bp.client.enums.account.login.AuthLoginBizCategoryEnum;
import com.taobao.ad.brand.bp.common.enums.BooleanEnum;
import com.taobao.ad.brand.bp.domain.account.repository.BizPermissionRepository;
import com.taobao.ad.brand.bp.domain.adc.repository.AdcRepository;
import com.taobao.ad.brand.bp.domain.cache.CacheRepository;
import com.taobao.ad.brand.bp.domain.config.BrandOneBPDiamondConfig;
import com.taobao.ad.brand.bp.domain.sdk.account.atomability.IAccountAdcRoleGetAbility;
import com.taobao.ad.brand.bp.domain.sdk.account.atomability.IAccountMenuPermissionFlatAbility;
import com.taobao.ad.brand.bp.domain.sdk.account.atomability.IAccountMenuPermissionMergeAbility;
import com.taobao.ad.brand.bp.domain.sdk.account.atomability.param.AccountAdcRoleGetAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.account.atomability.param.AccountMenuPermissionFlatAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.account.atomability.param.AccountMenuPermissionMergeAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author 虫洞 <liuming.liu@alibaba-inc.com>
 * @date 2023/4/27
 */
@Service
@RequiredArgsConstructor
public class BizPermissionWorkflow {
    private final IAccountAdcRoleGetAbility accountAdcRoleGetAbility;
    private final IAccountMenuPermissionMergeAbility accountMenuPermissionMergeAbility;
    private final IAccountMenuPermissionFlatAbility accountMenuPermissionFlatAbility;
    private final BizPermissionRepository bizPermissionRepository;
    private final AdcRepository adcRepository;
    private final CacheRepository cacheRepository;
    private final BrandOneBPDiamondConfig brandOneBPDiamondConfig;
    private final AdcMenuModulePermissionConverter adcMenuModulePermissionConverter;

    /**
     * 登录场景权限 + 配置的角色权限
     *
     * @param context
     * @param loginSession
     * @return
     */
    @SwitchContext
    public WriteReadPermissionsViewDTO getWriteReadPermissions(ServiceContext context, LoginSessionViewDTO loginSession) {
        context.setBizCode(BizCodeEnum.BRANDONEBP.getBizCode());
        RogerLogger.info("getWriteReadPermissions query user permission");
        // 内部小二登录
        if (loginSession.isAliEmpLogin()) {
            return getWriteReadPermissions(context, loginSession,true);
        }
        // 授权登录
        if (loginSession.isAuthLogin()) {
            //代理商自身账户登录
            if(loginSession.isAdvTbAccountLogin()){
                return getWriteReadPermissions(context, loginSession,false);
            }
            // 广告主员工淘宝账号登录后，授权登录到别的投放账号
            return getWriteReadPermissions(context, loginSession,true);
        }
        // 正常登录（作为商家身份，自己登录自己的投放账号）
        return getWriteReadPermissions(context, loginSession,false);
    }

    public List<AdcComponentViewDTO> getBasicVisibleComponentList(ServiceContext context, BasicVisibleComponentQueryViewDTO queryViewDTO) {
        // 查询用户有哪些adc角色
        Set<String> ownedAdcRoleSet = accountAdcRoleGetAbility.handle(context, AccountAdcRoleGetAbilityParam.builder()
                .abilityTarget(queryViewDTO).build());
        List<String> ownedAdcRoleList = Lists.newArrayList(ownedAdcRoleSet);
        // 先从缓存中查询
        List<AdcComponentViewDTO> result = this.getCachedBasicVisibleComponentList(ownedAdcRoleList);
        if (result != null) {
            return result;
        }
        // 缓存中不存在时，再去查询adc
        context.setRoleNameList(ownedAdcRoleList);
        AdcQueryViewDTO adcQueryViewDTO = new AdcQueryViewDTO();
        adcQueryViewDTO.setBizCode(context.getBizCode());
        adcQueryViewDTO.setAdcRoles(ownedAdcRoleList);
        result = adcRepository.findMenuList(context, adcQueryViewDTO);
        // 查询结果写入缓存
        try {
            this.writeBasicVisibleComponentListToCache(ownedAdcRoleList, new ArrayList<>(result));
        } catch (Exception e) {
            RogerLogger.error("put BasicVisibleComponentList data to cache", e);
        }
        return result;
    }

    /**
     * 获取登录用户角色基础可配置的adc菜单节点（用户的权限是对这些节点配置读写权限）
     *
     * @param context
     * @param loginSession
     * @return
     */
    public List<AdcComponentViewDTO> getBasicVisibleComponentList(ServiceContext context, LoginSessionViewDTO loginSession) {
        Integer memberType = MemberTypeEnum.SELLER.getValue();
        Long memberId = null;
        if (loginSession.isAliEmpLogin()) {
            memberType = MemberTypeEnum.ALI_EMP.getValue();
            memberId = loginSession.getLoginMember().getMemberId();
        } else if (loginSession.isAuthLogin()) {
            if (!AuthLoginBizCategoryEnum.CRM.getValue().equals(loginSession.getAuthLogin().getBizCategory())) {
                memberType = MemberTypeEnum.PARTNER.getValue();
                memberId = loginSession.getLoginMember().getMemberId();
            }else{
                memberId = loginSession.getAuthLogin().getAdvMemberId();
            }
        } else {
            memberId = loginSession.getLoginMember().getMemberId();
        }
        BasicVisibleComponentQueryViewDTO queryViewDTO = BasicVisibleComponentQueryViewDTO.builder()
                .memberType(memberType)
                .memberId(memberId)
                .joinScenceCodeList(loginSession.getJoinScene())
                .build();
        return getBasicVisibleComponentList(context, queryViewDTO);
    }

    /**
     * 查询登录用户角色
     * @param context
     * @param loginSession
     * @param isNeedFilter 是否需要权限过滤
     * @return
     */
    public WriteReadPermissionsViewDTO getWriteReadPermissions(ServiceContext context, LoginSessionViewDTO loginSession,boolean isNeedFilter) {
        RogerLogger.info("getWriteReadPermissions query user permission isNeedFilter = {}",isNeedFilter);
        // 当前登录用户能看到的基础adc菜单，用户拥有的adc菜单权限不能超过这个范围
        List<AdcComponentViewDTO> basicVisibleComponentList = getBasicVisibleComponentList(context, loginSession);
        List<AdcMenuModulePermissionViewDTO> mergedResult = Lists.newArrayList();
        //merge查询当前登录用户拥有的权限，并打平权限点
        if(isNeedFilter){
            List<AdcMenuModulePermissionViewDTO> boundPermissionViewDTOList = bizPermissionRepository.getBoundPermission(context, loginSession);
            forceResetSceneReadable(loginSession.getReadableScene(),boundPermissionViewDTOList);
            RogerLogger.info("getWriteReadPermissions query user permission forceResetSceneReadable = {}",
                    JSON.toJSONString(boundPermissionViewDTOList, SerializerFeature.DisableCircularReferenceDetect));
            mergedResult = accountMenuPermissionMergeAbility.handle(context, AccountMenuPermissionMergeAbilityParam.builder().abilityTargets(boundPermissionViewDTOList)
                    .basicVisibleComponentList(basicVisibleComponentList).build());
        }else{
            List<AdcMenuModulePermissionViewDTO> boundPermissionViewDTOList = adcMenuModulePermissionConverter.convertAdcDTO2ViewDTO(basicVisibleComponentList);
            forceResetSceneReadable(loginSession.getReadableScene(),boundPermissionViewDTOList);
            RogerLogger.info("getWriteReadPermissions query user permission forceResetSceneReadable = {}",
                    JSON.toJSONString(boundPermissionViewDTOList, SerializerFeature.DisableCircularReferenceDetect));
            mergedResult = accountMenuPermissionFlatAbility.handle(context, AccountMenuPermissionFlatAbilityParam.builder().abilityTargets(boundPermissionViewDTOList).build());
        }
        return WriteReadPermissionsViewDTO.of(resetBoundPermission(loginSession,mergedResult));
    }

    /**
     * 获取缓存中的用户读写权限
     * @param loginSessionViewDTO
     * @return
     */
    public WriteReadPermissionsViewDTO getCachedWriteReadPermissions(LoginSessionViewDTO loginSessionViewDTO) {
        //开关关闭，不缓存权限
        if(Objects.equals(BooleanEnum.FALSE.getValue(),brandOneBPDiamondConfig.getPermissionCacheEnable())){
            return null;
        }
        String cacheKey = getWriteReadPermissionsCacheKey(loginSessionViewDTO);
        return (WriteReadPermissionsViewDTO) cacheRepository.get(cacheKey);
    }

    /**
     * 将用户读写权限写入缓存
     * @param loginSessionViewDTO
     * @param writeReadPermissions
     */
    public void writePermissionsToCache(LoginSessionViewDTO loginSessionViewDTO, WriteReadPermissionsViewDTO writeReadPermissions) {
        String cacheKey = getWriteReadPermissionsCacheKey(loginSessionViewDTO);
        RogerLogger.info("getWriteReadPermissionsCacheKey: {}", cacheKey);
        Integer permissionCacheExpireTime = brandOneBPDiamondConfig.getPermissionCacheExpireTime();
        //缓存设置项大于0才写入缓存
        if(permissionCacheExpireTime > 0){
            cacheRepository.put(cacheKey, writeReadPermissions, brandOneBPDiamondConfig.getPermissionCacheExpireTime());
        }
    }

    private String getWriteReadPermissionsCacheKey(LoginSessionViewDTO loginSessionViewDTO) {
        // permission_b_{登录小二用户bucid}_{投放账户id}
        // permission_t_{登录淘宝账户userid}_{登录淘宝账户userid所属的广告主memberid}_{投放账户memberid}
        Long memberId = loginSessionViewDTO.getLoginMember().getMemberId();
        if (loginSessionViewDTO.isAliEmpLogin()) {
            return String.format("permission_b_%d_%d", loginSessionViewDTO.getAliEmpLogin().getBucId(), memberId);
        }
        Long advMemberId = loginSessionViewDTO.isAuthLogin() ? loginSessionViewDTO.getAuthLogin().getAdvMemberId() : memberId;
        return String.format("permission_t_%d_%d_%d", loginSessionViewDTO.getLoginTbAccount().getMainTbNumId(), advMemberId, memberId);
    }

    /**
     * 针对只读业务场景，写权限节点需要强制设置为只读
     * @param readableSceneList
     * @param rawResultList
     */
    private void forceResetSceneReadable(List<String> readableSceneList, List<AdcMenuModulePermissionViewDTO> rawResultList){
        if(CollectionUtils.isEmpty(readableSceneList) || CollectionUtils.isEmpty(rawResultList)){
            return;
        }
        for (AdcMenuModulePermissionViewDTO permissionViewDTO : rawResultList) {
            //找到对应bizCode并置为只读
            if(readableSceneList.contains(permissionViewDTO.getAdcCode())){
                resetChildPermissionWritable(permissionViewDTO,false);
            }
            //遍历子节点
            else{
                forceResetSceneReadable(readableSceneList,permissionViewDTO.getSubList());
            }
        }
    }

    /**
     * 重置子节点权限编码
     * @param permissionViewDTO
     * @param isWritable
     */
    private void resetChildPermissionWritable(AdcMenuModulePermissionViewDTO permissionViewDTO, boolean isWritable){
        if(permissionViewDTO.getIsWritable() != null){
            permissionViewDTO.setIsWritable(isWritable);
            if(CollectionUtils.isNotEmpty(permissionViewDTO.getSubList())){
                for (AdcMenuModulePermissionViewDTO viewDTO : permissionViewDTO.getSubList()) {
                    resetChildPermissionWritable(viewDTO,isWritable);
                }
            }
        }
    }

    /**
     * 重新设置权限节点
     * @param loginSession
     * @param mergedResult
     */
    private List<AdcMenuModulePermissionViewDTO> resetBoundPermission(LoginSessionViewDTO loginSession,List<AdcMenuModulePermissionViewDTO> mergedResult){
        // mergedResult 是全部的adc树配置 节点全部打平了的结果，不需要带上子节点了
        mergedResult.forEach(p -> p.setSubList(null));
        if(Objects.isNull(loginSession.getAuthLogin())){
            return mergedResult;
        }
        //用户授权业务场景中均无写权限，将全部权限置为只读
        boolean isSceneWriteable = loginSession.isSceneWriteable();
        if(!isSceneWriteable){
            mergedResult.forEach(p -> p.setIsWritable(false));
        }
        //叉乘账户需要校验有没有DMP模块授权
        if (AuthLoginBizCategoryEnum.AGENCY.getValue().equals(loginSession.getAuthLogin().getBizCategory())) {
            Set<String> resetPermissionAdcCodeSet = Sets.newHashSet("deeplink","longTermAnalysis");
            boolean memberDmpAuthResult = bizPermissionRepository.getMemberDmpAuthResult(loginSession.getLoginMember().getMemberId());
            //无DMP权限
            if(!memberDmpAuthResult){
                mergedResult = mergedResult.stream().filter(adcMenuModule -> !resetPermissionAdcCodeSet.contains(adcMenuModule.getAdcCode()))
                        .collect(Collectors.toList());
            }
        }
        return mergedResult;

    }

    /**
     * 获取缓存中的ADC节点
     * @param ownedAdcRoleSet
     * @return
     */
    private List<AdcComponentViewDTO> getCachedBasicVisibleComponentList(List<String> ownedAdcRoleSet) {
        //开关关闭，不缓存权限
        if(Objects.equals(BooleanEnum.FALSE.getValue(),brandOneBPDiamondConfig.getPermissionCacheEnable())){
            return null;
        }
        String cacheKey = getBasicVisibleComponentListCacheKey(ownedAdcRoleSet);
        //noinspection unchecked
        return (ArrayList<AdcComponentViewDTO>) cacheRepository.get(cacheKey);
    }

    /**
     * 将ADC节点写入缓存
     * @param ownedAdcRoleSet
     * @param basicVisibleComponentList
     */
    private void writeBasicVisibleComponentListToCache(List<String> ownedAdcRoleSet, ArrayList<AdcComponentViewDTO> basicVisibleComponentList) {
        String cacheKey = getBasicVisibleComponentListCacheKey(ownedAdcRoleSet);
        RogerLogger.info("getBasicVisibleComponentListCacheKey: {}", cacheKey);
        Integer permissionCacheExpireTime = brandOneBPDiamondConfig.getPermissionCacheExpireTime();
        //缓存设置项大于0才写入缓存
        if(permissionCacheExpireTime > 0){
            cacheRepository.put(cacheKey, basicVisibleComponentList, brandOneBPDiamondConfig.getPermissionCacheExpireTime());
        }
    }

    private String getBasicVisibleComponentListCacheKey(List<String> ownedAdcRoleSet) {
        String adcRoleString = ownedAdcRoleSet.stream().sorted().collect(Collectors.joining(","));
        return String.format("onebp_adc_%s", adcRoleString);
    }
}
