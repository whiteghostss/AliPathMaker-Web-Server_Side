package com.taobao.ad.brand.bp.app.spi.tool;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.nb.framework.core.AbilitySpi;
import com.alibaba.ad.nb.framework.core.annotation.Ability;
import com.taobao.ad.brand.bp.client.dto.tool.BatchImportDistLockParamViewDTO;
import com.taobao.ad.brand.bp.client.dto.tool.BatchImportParamViewDTO;

@Ability(desc = "批量导入业务域纬度扩展点")
public interface BatchImportAbilitySpi extends AbilitySpi {
    /**
     * 创意批量编辑
     */
    String BATCH_IMPORT_CREATIVE_UPDATE = "creativeBatchUpdate";
    /**
     * 计划批量导入
     */
    String BATCH_IMPORT_CAMPAIGN_INSERT = "campaignBatchInsert";
    /**
     * 单元监测批量导入
     */
    String BATCH_IMPORT_ADGROUP_MONITOR = "adgroupBatchMonitorUpdate";
    /**
     * 计划预订量批量导入
     */
    String BATCH_IMPORT_CAMPAIGN_BOOKING_AMOUNT = "batchImportCampaignBookingAmount";

    /**
     * 批量导入参数校验
     * @param context
     * @param batchImportParamViewDTO
     * @return
     */
    Void validateImportParam(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO);

    /**
     * 构建导入分布式锁参数
     * @param context
     * @param batchImportParamViewDTO
     * @return
     */
    BatchImportDistLockParamViewDTO buildImportDisLockParam(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO);

    /**
     * 分布式锁获取失败提示
     * @param context
     * @param batchImportParamViewDTO
     * @return
     */
    String tryDisLockErrorMessage(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO, String distCurValue);

    /**
     * 执行导入
     * @param context
     * @param batchImportParamViewDTO
     * @return
     */
    Void invokeImport(ServiceContext context,BatchImportParamViewDTO batchImportParamViewDTO);

    /**
     * 更新导入结果
     * @param context
     * @param batchImportParamViewDTO
     * @return
     */
    Void updateImportResult(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO);

    /**
     * 导入异常处理
     *
     * @param context
     * @param batchImportParamViewDTO
     * @param exceptionMeg
     * @return
     */
    String invokeImportExceptionMessage(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO, String exceptionMeg);
}
