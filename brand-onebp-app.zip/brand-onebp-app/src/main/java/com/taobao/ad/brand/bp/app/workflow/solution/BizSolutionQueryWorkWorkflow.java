package com.taobao.ad.brand.bp.app.workflow.solution;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.adgroup.CreativeRefViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupBottomTypeEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.cartitem.BrandCartItemStatusEnum;
import com.alibaba.ad.brand.sdk.constant.cartitem.BrandCartItemTypeEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.cartitem.query.CartItemQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.solution.CartItemSolutionViewDTO;
import com.taobao.ad.brand.bp.client.dto.solution.query.CartItemSolutionQueryOption;
import com.taobao.ad.brand.bp.common.converter.solution.CartItemSolutionViewDTOConverter;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.domain.adgroup.repository.AdgroupRepository;
import com.taobao.ad.brand.bp.domain.cart.repository.CartItemRepository;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizSolutionQueryWorkWorkflow {

    private final CartItemRepository cartItemRepository;
    private final ICampaignStructureQueryAbility campaignStructureQueryAbility;
    private final AdgroupRepository adgroupRepository;
    private final CreativeRepository creativeRepository;
    private final CartItemSolutionViewDTOConverter cartItemSolutionViewDTOConverter;

    /**
     * 自助化场景一站式解决方案（查询）
     * @param context
     * @param cartItemId
     * @param queryOption
     * @return
     */
    public CartItemSolutionViewDTO getCartItemSolutionInfo(ServiceContext context, Long cartItemId, CartItemSolutionQueryOption queryOption){
        // 1、查询「极简下单场景」下的加购行
        CartItemQueryViewDTO queryViewDTO = CartItemQueryViewDTO.builder()
                .idList(Collections.singletonList(cartItemId)).type(BrandCartItemTypeEnum.SLIM_ORDER.getCode()).build();
        if (queryOption.isNeedDeleted()) {
            queryViewDTO.setStatusList(Arrays.stream(BrandCartItemStatusEnum.values()).map(BrandCartItemStatusEnum::getCode).collect(Collectors.toList()));
        }
        List<CartItemViewDTO> cartItemViewDTOList = cartItemRepository.findCartList(context, queryViewDTO);
        if(CollectionUtils.isEmpty(cartItemViewDTOList)){
            return null;
        }
        CartItemViewDTO dbCartItemViewDTO = cartItemViewDTOList.get(0);
        CartItemSolutionViewDTO cartItemSolutionViewDTO = cartItemSolutionViewDTOConverter.convertViewDTO2DTO(dbCartItemViewDTO);

        // 2、加购行填充计划
        List<CampaignViewDTO> campaignViewDTOList = campaignStructureQueryAbility.handle(context,
                CampaignStructureQueryAbilityParam.builder().abilityTarget(CampaignQueryViewDTO.builder()
                                .campaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode())
                                .onlineStatusList(BizCampaignToolsHelper.getCampaignOnlineStatusList())
                                .cartItemIds(Collections.singletonList(cartItemId)).build())
                .queryOption(CampaignQueryOption.builder().needTarget(true).needChildren(true).build()).build());
        if(CollectionUtils.isEmpty(campaignViewDTOList)){
            return cartItemSolutionViewDTO;
        }
        CampaignViewDTO dbCampaignViewDTO = campaignViewDTOList.get(0);
        cartItemSolutionViewDTO.setCampaignViewDTO(dbCampaignViewDTO);

        // 3、对于下单成功的加购行，填充单元或者创意
        if(BrandCartItemStatusEnum.ORDER_SUCCESS.getCode().equals(dbCartItemViewDTO.getStatus())){
            //填充单元
            if(queryOption.isNeedAdgroup()){
                AdgroupQueryViewDTO adgroupQueryViewDTO = new AdgroupQueryViewDTO();
                adgroupQueryViewDTO.setCampaignId(dbCampaignViewDTO.getId());
                adgroupQueryViewDTO.setBottomType(BrandAdgroupBottomTypeEnum.BOTTOM.getCode());
                List<AdgroupViewDTO> adgroupViewDTOList = adgroupRepository.queryAdgroupListNoPage(context, adgroupQueryViewDTO);
                if(CollectionUtils.isNotEmpty(adgroupViewDTOList)){
                    cartItemSolutionViewDTO.setAdgroupViewDTO(adgroupViewDTOList.get(0));
                }
            }
            //填充创意
            CreativeQueryViewDTO creativeQueryViewDTO = new CreativeQueryViewDTO();
            creativeQueryViewDTO.setCampaignIds(Lists.newArrayList(dbCampaignViewDTO.getId()));
            List<CreativeRefViewDTO> creativeRefList = creativeRepository.findCreativeRefList(context, creativeQueryViewDTO, false);
            if(CollectionUtils.isNotEmpty(creativeRefList)){
                List<Long> creativeIdList = creativeRefList.stream().map(CreativeRefViewDTO::getCreativeId).collect(Collectors.toList());
                creativeQueryViewDTO = new CreativeQueryViewDTO();
                creativeQueryViewDTO.setIds(creativeIdList);
                creativeQueryViewDTO.setCreativeIdEqCreativePackageId(true);
                creativeQueryViewDTO.setPageSize(creativeIdList.size());
                PageResultViewDTO<CreativeViewDTO> pageResult = creativeRepository.findListWithPage(context, creativeQueryViewDTO);
                if(CollectionUtils.isNotEmpty(pageResult.getList())){
                    cartItemSolutionViewDTO.setCreativeViewDTOList(pageResult.getList());
                }
            }
        }
        return cartItemSolutionViewDTO;
    }
}