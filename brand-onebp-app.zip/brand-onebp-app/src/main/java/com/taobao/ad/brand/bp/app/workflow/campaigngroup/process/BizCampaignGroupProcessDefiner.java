package com.taobao.ad.brand.bp.app.workflow.campaigngroup.process;

import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupTypeEnum;
import com.alibaba.cola.statemachine.builder.StateMachineBuilder;
import com.taobao.ad.brand.bp.app.workflow.campaigngroup.BizCampaignGroupCommandWorkflow;
import com.taobao.ad.brand.bp.client.context.CampaignGroupStateContext;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupEventEnum;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.stream.Stream;

import static com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum.*;
import static com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupEventEnum.*;

/**
 * 子订单状态机
 * @author yanjingang
 * @date 2023/3/6
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizCampaignGroupProcessDefiner {

    private final BizCampaignGroupCommandWorkflow bizCampaignGroupCommandWorkflow;

    /**
     * 订单流程定义
     *
     * @param builder
     */
    public void defineCampaignGroupProcess(StateMachineBuilder<BrandCampaignGroupStatusEnum, CampaignGroupEventEnum, CampaignGroupStateContext> builder) {
        /**
         * 1001. 草稿
         */
        // 1002. 正在下单
        builder.externalTransition().from(EDITED).to(ORDER_ING).on(PRE_ORDER).when(this::isSelfServiceCampaignGroup).perform(bizCampaignGroupCommandWorkflow::doNothing);
        builder.externalTransition().from(EDITED).to(ORDER_ING).on(ORDER).perform(bizCampaignGroupCommandWorkflow::doNothing);

        /**
         * 1002. 正在下单
         */
        builder.externalTransition().from(ORDER_ING).to(ORDER_ING).on(ORDER).when(this::isSelfServiceCampaignGroup).perform(bizCampaignGroupCommandWorkflow::doNothing);
        // 1005. 等待推广
        builder.externalTransition().from(ORDER_ING).to(WAIT_CAST).on(CONTRACT_PAY).when(context -> isMainCampaignGroup(context) && isBeforeCampaignGroupStartTime(context)).perform(bizCampaignGroupCommandWorkflow::onlineCampaignGroupForTransit);
        // 1006. 正在推广
        builder.externalTransition().from(ORDER_ING).to(CAST_ING).on(CONTRACT_PAY).when(context -> isMainCampaignGroup(context) && isBetweenCampaignGroupTime(context)).perform(bizCampaignGroupCommandWorkflow::onlineCampaignGroupForTransit);
        // 1007. 结束推广
        builder.externalTransition().from(ORDER_ING).to(CAST_FINISH).on(CONTRACT_PAY).when(context -> isMainCampaignGroup(context) && isAfterCampaignGroupEndTime(context)).perform(bizCampaignGroupCommandWorkflow::onlineCampaignGroupForTransit);

        // 1003. 正在下单(资源确认中)
        builder.externalTransition().from(ORDER_ING).to(RESOURCE_CONFIRM_ING).on(CONTRACT_PAY).when(this::isSubCampaignGroup).perform(bizCampaignGroupCommandWorkflow::onlineContract);
        // 1004. 下单完成(合同流程中)
        builder.externalTransition().from(ORDER_ING).to(CONTRACT_PROCESS_ING).on(RESOURCE_CONFIRM).when(this::isSubCampaignGroup).perform(bizCampaignGroupCommandWorkflow::doNothing);
        // 逆向
        // 1001. 草稿 :: 来自订单侧的触发
        builder.externalTransition().from(ORDER_ING).to(EDITED).on(MODIFY_ORDER).when(this::isEditedPreviousStatus).perform(bizCampaignGroupCommandWorkflow::modifyCampaignGroupForTransit);
        // 1008. 改单配置 :: 来自订单侧的触发
        builder.externalTransition().from(ORDER_ING).to(UNLOCKED).on(MODIFY_ORDER).when(this::isUnlockedPreviousStatus).perform(bizCampaignGroupCommandWorkflow::modifyCampaignGroupForTransit);

        /**
         * 1003. 正在下单(资源确认中)
         */
        // 1005. 等待推广
        builder.externalTransition().from(RESOURCE_CONFIRM_ING).to(WAIT_CAST).on(RESOURCE_CONFIRM).when(this::isBeforeCampaignGroupStartTime).perform(bizCampaignGroupCommandWorkflow::onlineCampaignGroupForTransit);
        // 1006. 正在推广
        builder.externalTransition().from(RESOURCE_CONFIRM_ING).to(CAST_ING).on(RESOURCE_CONFIRM).when(this::isBetweenCampaignGroupTime).perform(bizCampaignGroupCommandWorkflow::onlineCampaignGroupForTransit);
        // 1007. 结束推广
        builder.externalTransition().from(RESOURCE_CONFIRM_ING).to(CAST_FINISH).on(RESOURCE_CONFIRM).when(this::isAfterCampaignGroupEndTime).perform(bizCampaignGroupCommandWorkflow::onlineCampaignGroupForTransit);
        // 逆向
        // 1008. 改单配置
        builder.externalTransition().from(RESOURCE_CONFIRM_ING).to(UNLOCKED).on(MODIFY_ORDER).perform(bizCampaignGroupCommandWorkflow::modifyCampaignGroupForTransit);


        /**
         * 1004. 下单完成(合同流程中)
         */
        // 1005. 等待推广
        builder.externalTransition().from(CONTRACT_PROCESS_ING).to(WAIT_CAST).on(CONTRACT_PAY).when(this::isBeforeCampaignGroupStartTime).perform(bizCampaignGroupCommandWorkflow::onlineCampaignGroupForTransit);
        // 1006. 正在推广
        builder.externalTransition().from(CONTRACT_PROCESS_ING).to(CAST_ING).on(CONTRACT_PAY).when(this::isBetweenCampaignGroupTime).perform(bizCampaignGroupCommandWorkflow::onlineCampaignGroupForTransit);
        // 1007. 结束推广
        builder.externalTransition().from(CONTRACT_PROCESS_ING).to(CAST_FINISH).on(CONTRACT_PAY).when(this::isAfterCampaignGroupEndTime).perform(bizCampaignGroupCommandWorkflow::onlineCampaignGroupForTransit);
        // 逆向
        // 1001. 草稿
        builder.externalTransition().from(CONTRACT_PROCESS_ING).to(EDITED).on(MODIFY_ORDER).when(context -> !contractHasEverPayed(context)).perform(bizCampaignGroupCommandWorkflow::modifyCampaignGroupForTransit);
        // 1008. 改单配置 合同已上线过，则迁移到改单配置
        builder.externalTransition().from(CONTRACT_PROCESS_ING).to(UNLOCKED).on(MODIFY_ORDER).when(this::contractHasEverPayed).perform(bizCampaignGroupCommandWorkflow::modifyCampaignGroupForTransit);


        /**
         * 1005. 等待推广
         */
        // 1006. 正在推广
        builder.externalTransition().from(WAIT_CAST).to(CAST_ING).on(NEXT).perform(bizCampaignGroupCommandWorkflow::doNothing);
        // 逆向
        // 1008. 改单中
        builder.externalTransition().from(WAIT_CAST).to(UNLOCKED).on(UNLOCK).perform(bizCampaignGroupCommandWorkflow::doNothing);
        builder.externalTransition().from(WAIT_CAST).to(UNLOCKED).on(MODIFY_ORDER).perform(bizCampaignGroupCommandWorkflow::modifyCampaignGroupForTransit);

        /**
         * 1006. 正在推广
         */
        // 1007. 投放结束
        builder.externalTransition().from(CAST_ING).to(CAST_FINISH).on(NEXT).perform(bizCampaignGroupCommandWorkflow::doNothing);
        // 逆向
        // 1008. 改单配置
        builder.externalTransition().from(CAST_ING).to(UNLOCKED).on(UNLOCK).perform(bizCampaignGroupCommandWorkflow::doNothing);
        builder.externalTransition().from(CAST_ING).to(UNLOCKED).on(MODIFY_ORDER).perform(bizCampaignGroupCommandWorkflow::modifyCampaignGroupForTransit);
        // 1009. 已完成
        builder.externalTransition().from(CAST_ING).to(FINISHED).on(STOP_CAST).perform(bizCampaignGroupCommandWorkflow::stopCastCampaignGroupForTransit);

        /**
         * 1007. 结束推广
         */
        // 1009. 已完成  (子订单直接完成，主订单：所有子订单全部完成才可以流转至完成)
        builder.externalTransition().from(CAST_FINISH).to(FINISHED).on(FINISH).perform(bizCampaignGroupCommandWorkflow::doNothing);
        // 逆向
        // 1008. 改单配置
        builder.externalTransition().from(CAST_FINISH).to(UNLOCKED).on(UNLOCK).perform(bizCampaignGroupCommandWorkflow::doNothing);
        builder.externalTransition().from(CAST_FINISH).to(UNLOCKED).on(MODIFY_ORDER).perform(bizCampaignGroupCommandWorkflow::modifyCampaignGroupForTransit);

        /**
         * 1008. 改单配置
         */
        // 1002. 正在下单
        builder.externalTransition().from(UNLOCKED).to(ORDER_ING).on(ORDER).perform(bizCampaignGroupCommandWorkflow::doNothing);
        // 仅主订单存在的逆向
        // 1009. 已完成
        builder.externalTransition().from(UNLOCKED).to(FINISHED).on(UNLOCK_REVERT).when(this::isFinishedPreviousStatus).perform(bizCampaignGroupCommandWorkflow::unlockRevertCampaignGroupForTransit);
        // 1005. 等待推广
        builder.externalTransition().from(UNLOCKED).to(WAIT_CAST).on(UNLOCK_REVERT)
                .when(context -> !isFinishedPreviousStatus(context) && isBeforeCampaignGroupStartTime(context))
                .perform(bizCampaignGroupCommandWorkflow::unlockRevertCampaignGroupForTransit);
        // 1006. 正在推广
        builder.externalTransition().from(UNLOCKED).to(CAST_ING).on(UNLOCK_REVERT)
                .when(context -> !isFinishedPreviousStatus(context) && isBetweenCampaignGroupTime(context))
                .perform(bizCampaignGroupCommandWorkflow::unlockRevertCampaignGroupForTransit);
        // 1007. 结束推广
        builder.externalTransition().from(UNLOCKED).to(CAST_FINISH).on(UNLOCK_REVERT)
                .when(context -> !isFinishedPreviousStatus(context) && isAfterCampaignGroupEndTime(context))
                .perform(bizCampaignGroupCommandWorkflow::unlockRevertCampaignGroupForTransit);

        /**
         * 1009. 已完成
         */
        builder.externalTransition().from(FINISHED).to(REAL_SETTLED).on(REAL_SETTLE_APPROVE).when(this::isSelfServiceCampaignGroup).perform(bizCampaignGroupCommandWorkflow::agreeRealSettleProcessForTransit);
        // 1010. 实结中
        builder.externalTransition().from(FINISHED).to(REAL_SETTLE_ING).on(REAL_SETTLE).perform(bizCampaignGroupCommandWorkflow::doNothing);
        // 1012. 已结案 (记录结案时间)
        builder.externalTransition().from(FINISHED).to(COMPLETED).on(COMPLETE).perform(bizCampaignGroupCommandWorkflow::completeCampaignGroup);
        // 逆向
        // 1006. 正在推广
        builder.externalTransition().from(FINISHED).to(CAST_ING).on(FINISH_REVERT).when(this::isBetweenCampaignGroupTime).perform(bizCampaignGroupCommandWorkflow::doNothing);
        // 1007. 投放结束
        builder.externalTransition().from(FINISHED).to(CAST_FINISH).on(FINISH_REVERT).when(this::isAfterCampaignGroupEndTime).perform(bizCampaignGroupCommandWorkflow::doNothing);
        // 1008. 改单配置
        builder.externalTransition().from(FINISHED).to(UNLOCKED).on(UNLOCK).perform(bizCampaignGroupCommandWorkflow::doNothing);
        builder.externalTransition().from(FINISHED).to(UNLOCKED).on(MODIFY_ORDER).perform(bizCampaignGroupCommandWorkflow::modifyCampaignGroupForTransit);

        /**
         * 1010. 实结中
         */
        // 1011. 已实结
        builder.externalTransition().from(REAL_SETTLE_ING).to(REAL_SETTLED).on(REAL_SETTLE_APPROVE).perform(bizCampaignGroupCommandWorkflow::agreeRealSettleProcessForTransit);
        // 逆向
        // 1009. 已完成
        builder.externalTransition().from(REAL_SETTLE_ING).to(FINISHED).on(REAL_SETTLE_REFUSE).perform(bizCampaignGroupCommandWorkflow::doNothing);

        /**
         * 1012. 已结案
         */
        builder.externalTransition().from(COMPLETED).to(FINISHED).on(COMPLETE_REVERT).perform(bizCampaignGroupCommandWorkflow::doNothing);

        /**
         * 1013. 已撤单
         */
        Stream.of(EDITED, ORDER_ING, RESOURCE_CONFIRM_ING, CONTRACT_PROCESS_ING, WAIT_CAST).forEach(fromSt -> {
            builder.externalTransition().from(fromSt).to(CANCELED).on(CANCEL).perform(bizCampaignGroupCommandWorkflow::cancelCampaignGroupForTransit);
        });
    }

    private boolean isSelfServiceCampaignGroup(CampaignGroupStateContext stateContext) {
        CampaignGroupViewDTO campaignGroup = stateContext.getCampaignGroupViewDTO();
        return BrandCampaignGroupTypeEnum.SELF.getCode().equals(campaignGroup.getType());
    }

    private boolean isAfterCampaignGroupEndTime(CampaignGroupStateContext context) {
        CampaignGroupViewDTO campaignGroupViewDTO = context.getCampaignGroupViewDTO();
        return new Date().after(campaignGroupViewDTO.getEndTime());
    }

    private boolean isBeforeCampaignGroupStartTime(CampaignGroupStateContext context) {
        CampaignGroupViewDTO campaignGroupViewDTO = context.getCampaignGroupViewDTO();
        return new Date().before(campaignGroupViewDTO.getStartTime());
    }

    private boolean isBetweenCampaignGroupTime(CampaignGroupStateContext context) {
        CampaignGroupViewDTO campaignGroupViewDTO = context.getCampaignGroupViewDTO();
        Date now = new Date();
        return !now.after(campaignGroupViewDTO.getEndTime())
                && !now.before(campaignGroupViewDTO.getStartTime());
    }

    private boolean isEditedPreviousStatus(CampaignGroupStateContext context) {
        CampaignGroupViewDTO campaignGroupViewDTO = context.getCampaignGroupViewDTO();
        Integer previousStatus = campaignGroupViewDTO.getPreviousStatus();
        return EDITED.getCode().equals(previousStatus);
    }

    private boolean isFinishedPreviousStatus(CampaignGroupStateContext context) {
        CampaignGroupViewDTO campaignGroupViewDTO = context.getCampaignGroupViewDTO();
        Integer previousStatus = campaignGroupViewDTO.getPreviousStatus();
        return FINISHED.getCode().equals(previousStatus);
    }

    private boolean isUnlockedPreviousStatus(CampaignGroupStateContext context) {
        CampaignGroupViewDTO campaignGroupViewDTO = context.getCampaignGroupViewDTO();
        Integer previousStatus = campaignGroupViewDTO.getPreviousStatus();
        return UNLOCKED.getCode().equals(previousStatus);
    }

    private boolean contractHasEverPayed(CampaignGroupStateContext context) {
        CampaignGroupViewDTO campaignGroupViewDTO = context.getCampaignGroupViewDTO();
        Date contractFirstOnlineTime = campaignGroupViewDTO.getCampaignGroupContractViewDTO().getContractFirstOnlineTime();
        return contractFirstOnlineTime != null;
    }

    private boolean isMainCampaignGroup(CampaignGroupStateContext context) {
        return BizCampaignGroupToolsHelper.isMainCampaignGroup(context.getCampaignGroupViewDTO());
    }

    private boolean isSubCampaignGroup(CampaignGroupStateContext context) {
        return BizCampaignGroupToolsHelper.isSubCampaignGroup(context.getCampaignGroupViewDTO());
    }


}
