package com.taobao.ad.brand.bp.app.handler.campaigngroup;

import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;

import com.alibaba.ad.brand.dto.campaign.sale.CampaignSaleViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.hermes.framework.ddd.event.annotation.DomainEventHandler;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupEventEnum;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.event.campaigngroup.CampaignGroupStatusTransitEvent;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

/**
 * @description: CampaignProcessHandler
 * @date: 2023/3/10 18:29
 * @author: yuanxinxi
 * @version: 1.0
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@DomainEventHandler(topic = "campaign_group_status_change", event = CampaignGroupStatusTransitEvent.class)
public class CampaignGroupProcessCreateSubContractHandler implements CampaignGroupProcessHandler {

    private final CampaignRepository campaignRepository;

    @Override
    public boolean onCondition(CampaignGroupStatusTransitEvent event) {
        CampaignGroupEventEnum campaignGroupEventEnum = event.getContext().getEventEnum();
        if(CampaignGroupEventEnum.SUB_CONTRACT_GENERATE.equals(campaignGroupEventEnum)  ){
            return true;
        }
        return false;
    }

    @Override
    public Response handle(CampaignGroupStatusTransitEvent campaignGroupStatusTransitEvent) {
        if (!onCondition(campaignGroupStatusTransitEvent)) {
            return Response.success();
        }
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupStatusTransitEvent.getContext().getCampaignGroupViewDTO();
        CampaignQueryViewDTO campaignQueryViewDTO = new CampaignQueryViewDTO();
        campaignQueryViewDTO.setCampaignGroupId(campaignGroupViewDTO.getId());
        List<Long> saleGroupIds = campaignGroupStatusTransitEvent.getContext().getSaleGroupIds();
        campaignQueryViewDTO.setSaleGroupIds(saleGroupIds);
        List<CampaignViewDTO> campaignViewDTOList =  campaignRepository.queryCampaignList(campaignGroupStatusTransitEvent.getContext().getServiceContext(),campaignQueryViewDTO);
//        List<CampaignViewDTO> filterList = campaignViewDTOList.stream().filter(item-> BrandCampaignStatusEnum.LOCK_SUCCESS.getCode().equals(item.getStatus())).collect(
//            Collectors.toList());
        List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList();
        List<CampaignViewDTO> updateList = Lists.newArrayList();
        campaignViewDTOList.forEach(item -> {
            //设置子合同id
            CampaignViewDTO updateCampaignViewDTO = new CampaignViewDTO();
            updateCampaignViewDTO.setId(item.getId());
            for(SaleGroupInfoViewDTO saleGroupInfoViewDTO : saleGroupInfoViewDTOList){
                if (!saleGroupIds.contains(saleGroupInfoViewDTO.getSaleGroupId())) {
                    continue;
                }
                if(!saleGroupInfoViewDTO.getSaleProductLine().equals(item.getCampaignSaleViewDTO().getSaleProductLine())){
                    continue;
                }
                if (item.getCampaignSaleViewDTO().getSubContractId() != null && Objects.equals(item.getCampaignSaleViewDTO().getSubContractId(), saleGroupInfoViewDTO.getSubContractId())
                        && item.getCampaignSaleViewDTO().getContractId() != null && Objects.equals(item.getCampaignSaleViewDTO().getContractId(), campaignGroupViewDTO.getCampaignGroupContractViewDTO().getContractId())) {
                    continue;
                }
                CampaignSaleViewDTO campaignSaleViewDTO = new CampaignSaleViewDTO();
                campaignSaleViewDTO.setSubContractId(saleGroupInfoViewDTO.getSubContractId());
                campaignSaleViewDTO.setContractId(campaignGroupViewDTO.getCampaignGroupContractViewDTO().getContractId());
                updateCampaignViewDTO.setCampaignSaleViewDTO(campaignSaleViewDTO);
                updateList.add(updateCampaignViewDTO);
            }
        });
        campaignRepository.updateCampaignPart(campaignGroupStatusTransitEvent.getContext().getServiceContext(),updateList);
        return Response.success();
    }
}
