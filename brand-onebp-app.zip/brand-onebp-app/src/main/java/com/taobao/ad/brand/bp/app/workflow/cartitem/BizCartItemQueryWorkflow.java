package com.taobao.ad.brand.bp.app.workflow.cartitem;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.rule.RuleCheckResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSkuViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.shopwindow.atomability.ISkuSspProductLineAuthJudgeAbility;
import com.taobao.ad.brand.bp.domain.sdk.shopwindow.atomability.param.SkuSspProductLineAuthJudgeAbilityParam;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * 加购行查询流程
 * @author shiyan
 * @date 2024/06/26
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizCartItemQueryWorkflow {

    private final ISkuSspProductLineAuthJudgeAbility skuSspProductLineAuthJudgeAbility;

    /**
     * 商品ssp产品线准入判断
     * @param serviceContext
     * @param skuViewDTO
     * @return
     */
    public RuleCheckResultViewDTO judgeSkuAccess(ServiceContext serviceContext, BrandSkuViewDTO skuViewDTO){
        //加购行ssp产品线准入
        Map<Long, Boolean> checkResult = skuSspProductLineAuthJudgeAbility.handle(serviceContext,
                SkuSspProductLineAuthJudgeAbilityParam.builder().abilityTargets(Lists.newArrayList(skuViewDTO)).build());
        Boolean sspProductLineAuthResult = checkResult.getOrDefault(skuViewDTO.getSspProductUuid(), false);
        if(sspProductLineAuthResult){
            return RuleCheckResultViewDTO.builder().isPass(BrandBoolEnum.BRAND_TRUE.getCode()).build();
        }else{
            return RuleCheckResultViewDTO.builder().isPass(BrandBoolEnum.BRAND_FALSE.getCode())
                    .reason("您好，您的店铺不符合用户准入要求，暂时无法申请。店铺信誉等级规范详见：https://rule.alimama.com/#!/product/index?type=detail&id=1074&knowledgeId=11005245")
                    .build();
        }
    }
}
