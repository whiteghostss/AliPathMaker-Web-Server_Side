package com.taobao.ad.brand.bp.app.workflow.creative;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.utils.AbilityInvoker;
import com.alibaba.ad.brand.dto.adgroup.CreativeRefViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.brand.dto.creative.audit.AuditViewDTO;
import com.alibaba.ad.brand.dto.creative.audit.MamaAuditViewDTO;
import com.alibaba.ad.brand.dto.creative.audit.MediaAuditViewDTO;
import com.alibaba.ad.brand.dto.creative.element.ElementViewDTO;
import com.alibaba.ad.brand.dto.creative.ext.CreativeExtViewDTO;
import com.alibaba.ad.brand.dto.creative.materialgroup.MaterialGroupViewDTO;
import com.alibaba.ad.brand.dto.creative.template.CreativeTemplateViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.creative.field.*;
import com.alibaba.ad.creative.consts.template.TemplateStatusEnum;
import com.alibaba.ad.nb.ssp.constant.common.MediaScopeEnum;
import com.alibaba.ad.nb.ssp.constant.template.TemplateAdditionalStatusEnum;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.event.SimpleEventEngine;
import com.alibaba.hermes.framework.utils.BeanUtils;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.app.businessability.SmartCreativeBusinessAbility;
import com.taobao.ad.brand.bp.client.context.SmartCreativeAddCallbackNoticeContext;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignTemplateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.*;
import com.taobao.ad.brand.bp.client.dto.creative.crop.MalusCropResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.notice.CreativeAuditSwitchNotifyViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.notice.CreativeRejectMsgViewDTO;
import com.taobao.ad.brand.bp.client.dto.template.ErrorMessageViewDTO;
import com.taobao.ad.brand.bp.client.dto.template.TemplateContextViewDTO;
import com.taobao.ad.brand.bp.client.dto.template.TemplateViewDTO;
import com.taobao.ad.brand.bp.common.constant.CreativeConstant;
import com.taobao.ad.brand.bp.common.converter.creative.CreativeMalusDatumViewConverter;
import com.taobao.ad.brand.bp.common.helper.creative.BizCreativeToolsHelper;
import com.taobao.ad.brand.bp.common.threadpooltask.CreativeAddTaskIdentifier;
import com.taobao.ad.brand.bp.common.threadpooltask.CreativeUpdateTaskIdentifier;
import com.taobao.ad.brand.bp.common.threadpooltask.CreativeValidateTaskIdentifier;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.PageUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.config.CreativeTemplateConfigDiamond;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeRepository;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeTemplateRepository;
import com.taobao.ad.brand.bp.domain.creative.spi.BizCreativeSpi;
import com.taobao.ad.brand.bp.domain.creative.spi.BizCreativeValidateSpi;
import com.taobao.ad.brand.bp.domain.event.creative.SmartCreativeAddCallbackEvent;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbilityRouteContext;
import com.taobao.ad.brand.bp.domain.sdk.base.workflow.Workflow;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.*;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.*;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.query.ICreativeStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.businessability.*;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.common.constant.Constant.MAX_PAGE_COUNT;
import static com.taobao.ad.brand.bp.common.spi.ExtensionPointsFactory.runAbilitySpi;
import static com.taobao.ad.brand.bp.common.util.PageUtil.getTotalPage;
import static com.taobao.ad.brand.bp.domain.creative.spi.BizCreativeSpi.getSpiBizCode;

/**
 * 创意业务流程
 *
 * @author yunhu.myh
 * @date 2023年12月22日
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizCreativeCommandWorkflow extends Workflow {

    private final SimpleEventEngine simpleEventEngine;
    private final CreativeMalusDatumViewConverter creativeMalusDatumViewConverter;
    private final CreativeRepository creativeRepository;
    private final CampaignRepository campaignRepository;
    private final CreativeTemplateRepository creativeTemplateRepository;
    private final ICreativeMalusBaseConvertForConvertCreativeAbility creativeMalusBaseConvertForConvertCreativeAbility;
    private final ICreativeMalusTemplateValidateForConvertCreativeAbility creativeMalusTemplateValidateForConvertCreativeAbility;
    private final ICreativeElementSecondProcessAbilityForAddCreative creativeElementSecondProcessAbilityForAddCreative;
    private final ICreativeCustomerCategoryFillAbility creativeCustomerCategoryFillAbility;
    private final ICreativeRefAdgroupMixDateValidateAbility creativeRefAdgroupMixDateValidateAbility;
    private final ICreativeStructureQueryAbility creativeStructureQueryAbility;
    private final ICampaignStructureQueryAbility campaignStructureQueryAbility;
    private final ICreativeSmartSubCreativeGenerateJudgeAbility creativeSmartSubCreativeGenerateJudgeAbility;
    private final ICreativeMalusTemplateStaticElementConvertForConvertCreativeAbility creativeMalusTemplateStaticElementConvertForConvertCreativeAbility;
    private final ICreativeMalusConvergeElementGetForConvertCreativeAbility creativeMalusConvergeElementGetForConvertCreativeAbility;
    private final ICreativeMalusConvergeElementConvertForConvertCreativeAbility creativeMalusConvergeElementConvertForConvertCreativeAbility;
    private final ICreativeMalusInitForConvertCreativeAbility creativeMalusInitForConvertCreativeAbility;
    private final ICreativeTemplateValidateAbility creativeTemplateValidateAbility;
    private final ICreativeOfflineValidateAbility creativeOfflineValidateAbility;
    private final ICreativeRejectMessageSendJudgeAbility creativeRejectMessageSendJudgeAbility;
    private final ICreativeRejectMessageSendAbility creativeRejectMessageSendAbility;
    private final ICreativeUpdateElementGetAbility creativeUpdateElementGetAbility;
    private final CreativeTemplateConfigDiamond creativeTemplateConfigDiamond;


    private final CreativeAddTaskIdentifier creativeAddTaskIdentifier;
    private final CreativeUpdateTaskIdentifier creativeUpdateTaskIdentifier;
    private final CreativeValidateTaskIdentifier creativeValidateTaskIdentifier;

    /**
     * 基于海棠创意数据拆分创意
     *
     * @param context
     * @param malusDatumViewDTO
     * @return
     */
    public List<CreativeViewDTO> convertCreative(ServiceContext context, CreativeSaveViewDTO malusDatumViewDTO) {
        //初始化海棠创意信息
        creativeMalusInitForConvertCreativeAbility.handle(context, CreativeMalusInitAbilityParam.builder().abilityTarget(malusDatumViewDTO).build());

        List<CreativeViewDTO> result = Lists.newArrayList();
        List<CreativeMalusTemplateViewDTO> malusTemplateViewDTOList = malusDatumViewDTO.getTemplateDatum();
        for (CreativeMalusTemplateViewDTO malusTemplateViewDTO : malusTemplateViewDTOList) {
            if (Objects.isNull(malusTemplateViewDTO.getSspTemplateId())) {
                malusTemplateViewDTO.setSspTemplateId(malusDatumViewDTO.getTemplateId());
            }
            //创意基础数据转换
            CreativeViewDTO creativeViewDTO = creativeMalusBaseConvertForConvertCreativeAbility.handle(context,
                    CreativeMalusBaseConvertAbilityParam.builder().abilityTarget(malusTemplateViewDTO).creativeSaveViewDTO(malusDatumViewDTO).build());

            //创意参数校验
            creativeMalusTemplateValidateForConvertCreativeAbility.handle(context, CreativeMalusTemplateValidateAbilityParam.builder()
                    .abilityTarget(creativeViewDTO).creativeMalusTemplateViewDTO(malusTemplateViewDTO).build());

            String spiCode = BizCreativeSpi.getSpiBizCode(malusTemplateViewDTO.getTemplateData());
            //填充创意元素
            runAbilitySpi(BizCreativeSpi.class, extension -> extension.fillCreativeTemplateElement(context, creativeViewDTO, malusTemplateViewDTO), spiCode);
            //基于模板拆分子创意
            List<CreativeViewDTO> creativeViewDTOList = runAbilitySpi(BizCreativeSpi.class, extension -> extension.splitSubCreative(context, creativeViewDTO, malusTemplateViewDTO), spiCode);
            creativeViewDTO.setSubCreativeViewDTOList(creativeViewDTOList);

            //商业能力挂载
            AbilityInvoker.invokeAll(ICreativeConvertBusinessAbilityPoint.class,
                    BusinessAbilityRouteContext.builder().specifiedBusinessAbilityCodes(Lists.newArrayList(SmartCreativeBusinessAbility.ABILITY_CODE)).build(),
                    callback -> callback.invokeForCreativeConvert(context, creativeViewDTO, malusTemplateViewDTO));

            result.add(creativeViewDTO);
        }
        return result;
    }

    /**
     * 新建创意
     *
     * @param context
     * @param creativeViewDTO
     * @return
     */
    public Long addCreative(ServiceContext context, CreativeViewDTO creativeViewDTO) {
        Map<Long, TemplateViewDTO> templateViewDTOMap = this.getTemplateMap(context, creativeViewDTO);
        validateCreativeTemplate(context,creativeViewDTO, templateViewDTOMap);
        //保存主创意
        TemplateViewDTO templateViewDTO = templateViewDTOMap.get(creativeViewDTO.getCreativeTemplate().getSspTemplateId());
        this.processCreative(context, templateViewDTO, creativeViewDTO);
        this.processCreativeAudit(context, templateViewDTO, creativeViewDTO);
        Long mainCreativeId = creativeRepository.addCreative(context, creativeViewDTO);
        RogerLogger.info(String.format("创意创建成功，id=%s", mainCreativeId));
        try {
            //保存子创意
            if (CollectionUtils.isNotEmpty(creativeViewDTO.getSubCreativeViewDTOList())) {
                List<CreativeViewDTO> subCreativeViewDTOList = creativeViewDTO.getSubCreativeViewDTOList();
                List<Long> subCreativeIds = TaskStream.execute(creativeAddTaskIdentifier, subCreativeViewDTOList, (subCreativeViewDTO, index) -> {
                    TemplateViewDTO subTemplateViewDTO = templateViewDTOMap.get(subCreativeViewDTO.getCreativeTemplate().getSspTemplateId());
                    subCreativeViewDTO.setCreativePackageId(mainCreativeId);
                    this.processCreative(context, subTemplateViewDTO, subCreativeViewDTO);
                    this.processCreativeAudit(context, subTemplateViewDTO, subCreativeViewDTO);
                    return creativeRepository.addCreative(context, subCreativeViewDTO);
                }).commit().getResultList();
                RogerLogger.info("创意(id=%s)下的子创意创建成功，subCreativeIds=%s", mainCreativeId, JSON.toJSONString(subCreativeIds));
            }
            creativeViewDTO.setId(mainCreativeId);
            if (Objects.nonNull(creativeViewDTO.getCreativeAudit()) &&
                    BrandCreativeAuditSceneTypeEnum.BRAND_NO_QUALITY_SMART_CREATIVE.getCode().equals(creativeViewDTO.getCreativeAudit().getAuditSceneType())) {
                fireCallbackNoticeEvent(context, creativeViewDTO);
            }
            return mainCreativeId;
        } catch (Exception e) {
            RogerLogger.error(String.format("创意新建失败，执行异常回滚删除，creativeId=%s", mainCreativeId), e);
            if (mainCreativeId != null) {
                creativeRepository.deleteCreatives(context, Collections.singletonList(mainCreativeId));
            }
            throw e;
        }
    }

    /**
     * 修改创意
     *
     * @param context
     * @param creativeViewDTO
     * @return
     */
    public Integer updateCreative(ServiceContext context, CreativeViewDTO creativeViewDTO) {
        AssertUtil.assertTrue(Optional.ofNullable(creativeViewDTO).map(CreativeViewDTO::getId).isPresent(), "创意id不允许为空");
        CreativeQueryOptionViewDTO queryOption = CreativeQueryOptionViewDTO.builder().needChildren(true).build();
        CreativeViewDTO dbCreativeViewDTO = this.getCreativeInfoByOption(context, creativeViewDTO.getId(), queryOption);
        AssertUtil.notNull(dbCreativeViewDTO, String.format("创意不存在，id=%s", creativeViewDTO.getId()));
        creativeRefAdgroupMixDateValidateAbility.handle(context, CreativeRefAdgroupMixDateValidateAbilityParam.builder().abilityTarget(creativeViewDTO).build());

        Map<Long, TemplateViewDTO> templateViewDTOMap = this.getTemplateMap(context, creativeViewDTO);
        validateCreativeTemplate(context, creativeViewDTO, templateViewDTOMap);

        //校验创意有效期
        validateCreativeInDate(dbCreativeViewDTO, creativeViewDTO, templateViewDTOMap);

        TemplateViewDTO templateViewDTO = templateViewDTOMap.get(creativeViewDTO.getCreativeTemplate().getSspTemplateId());
        this.processCreative(context, templateViewDTO, creativeViewDTO);
        this.processCreativeAudit(context, templateViewDTO, creativeViewDTO);
        Integer count = creativeRepository.updateCreative(context, creativeViewDTO);
        //更新子创意
        updateSubCreative(context, dbCreativeViewDTO, creativeViewDTO, templateViewDTOMap);
        return count;
    }

    /**
     * 智能创意不送审风控的事件发布
     * @param serviceContext
     * @param creativeViewDTO
     * @return
     */
    private void fireCallbackNoticeEvent(ServiceContext serviceContext, CreativeViewDTO creativeViewDTO) {
        SmartCreativeAddCallbackNoticeContext smartCreativeAddCallbackNoticeContext = SmartCreativeAddCallbackNoticeContext.builder()
                .serviceContext(serviceContext).creativeViewDTO(creativeViewDTO).build();
        simpleEventEngine.fire(SmartCreativeAddCallbackEvent.of(smartCreativeAddCallbackNoticeContext));
    }

    private void validateCreativeInDate(CreativeViewDTO dbCreativeViewDTO, CreativeViewDTO creativeViewDTO, Map<Long, TemplateViewDTO> templateViewDTOMap) {
        if (Lists.newArrayList(BrandCreativeScopeEnum.TAO_INNER.getCode(), BrandCreativeScopeEnum.TAO_OUT.getCode()).contains(dbCreativeViewDTO.getCreativeScope())) {
            return;
        }
        // 三环创意送外审后不允许修改创意有效期(免审除外:优酷和智能创意)
        if (BrandCreativeScopeEnum.SITE_OUT.getCode().equals(dbCreativeViewDTO.getCreativeScope())
                && BizCreativeToolsHelper.templateNeedApprovalTypeList.contains(templateViewDTOMap.getOrDefault(dbCreativeViewDTO.getCreativeTemplate().getSspTemplateId(), new TemplateViewDTO()).getNeedApproval())
                && BizCreativeToolsHelper.hasPushMedia(dbCreativeViewDTO.getCreativeAudit().getShowAuditStatus())) {
            AssertUtil.assertTrue(dbCreativeViewDTO.getStartTime().equals(creativeViewDTO.getStartTime()) && dbCreativeViewDTO.getEndTime().equals(creativeViewDTO.getEndTime()), "创意已送审媒体,不允许修改创意有效期");
        }
        //三环跨域创意 子创意任意一个送外审的不允许修改创意有效期、版本、名称
        if (BrandCreativeScopeEnum.CROSS_SCOPE.getCode().equals(dbCreativeViewDTO.getCreativeScope())
                && CollectionUtils.isNotEmpty(dbCreativeViewDTO.getSubCreativeViewDTOList())
                && dbCreativeViewDTO.getSubCreativeViewDTOList().stream()
                .filter(subCreative -> MediaScopeEnum.SITE_OUT.getCode().equals(templateViewDTOMap.getOrDefault(subCreative.getCreativeTemplate().getSspTemplateId(), new TemplateViewDTO()).getMediaScope()))
                .filter(subCreative -> BizCreativeToolsHelper.templateNeedApprovalTypeList.contains(templateViewDTOMap.getOrDefault(subCreative.getCreativeTemplate().getSspTemplateId(), new TemplateViewDTO()).getNeedApproval()))
                .anyMatch(subCreativeDTO -> BizCreativeToolsHelper.hasPushMedia(subCreativeDTO.getCreativeAudit().getShowAuditStatus()))) {
            AssertUtil.assertTrue(dbCreativeViewDTO.getStartTime().equals(creativeViewDTO.getStartTime()) && dbCreativeViewDTO.getEndTime().equals(creativeViewDTO.getEndTime()), "部分子创意已送审媒体,不允许修改创意有效期");
            Long dbCreativeTagId = Optional.ofNullable(dbCreativeViewDTO.getExtViewDTO())
                    .map(CreativeExtViewDTO::getCreativeTagId)
                    .orElse(null);
            Long newCreativeTagId = Optional.ofNullable(creativeViewDTO.getExtViewDTO())
                    .map(CreativeExtViewDTO::getCreativeTagId)
                    .orElse(null);
            AssertUtil.assertTrue(Objects.equals(dbCreativeTagId, newCreativeTagId), "部分子创意已送审媒体,不允许修改创意版本");
            AssertUtil.assertTrue(dbCreativeViewDTO.getName().equals(creativeViewDTO.getName()), "部分子创意已送审媒体,不允许修改创意名称");
        }
    }

    /**
     * 更新创意部分信息
     *
     * @param context
     * @param creativeViewDTO
     */
    public Integer updateCreativePart(ServiceContext context, CreativeViewDTO creativeViewDTO) {
        if (Objects.equals(BrandCreativeOnlineStatusEnum.OFF.getCode(), creativeViewDTO.getOnlineStatus())) {
            creativeOfflineValidateAbility.handle(context, CreativeOfflineValidateAbilityParam.builder().abilityTarget(creativeViewDTO).build());
        }
        CreativeViewDTO dbCreativeViewDTO = this.getCreativeInfoByOption(context, creativeViewDTO.getId(),
                CreativeQueryOptionViewDTO.builder().needChildren(true).build());
        AssertUtil.notNull(dbCreativeViewDTO, "创意不能为空");

        TemplateViewDTO template = creativeTemplateRepository.getTemplateById(context, dbCreativeViewDTO.getCreativeTemplate().getSspTemplateId());
        creativeTemplateValidateAbility.handle(context, CreativeTemplateAbilityParam.builder().abilityTarget(template).build());

        // 更新主子创意
        Integer count = creativeRepository.updateCreativePart(context, creativeViewDTO);
        if (CollectionUtils.isNotEmpty(dbCreativeViewDTO.getSubCreativeViewDTOList())) {
            List<Long> subCreativeIds = TaskStream.execute(creativeUpdateTaskIdentifier, dbCreativeViewDTO.getSubCreativeViewDTOList(), (subCreativeView, index) -> {
                CreativeViewDTO updateCreative = BeanUtils.copyIgnoreNull(creativeViewDTO, new CreativeViewDTO());
                updateCreative.setId(subCreativeView.getId());
                if (StringUtils.isNotBlank(creativeViewDTO.getName())) {
                    updateCreative.setName(subCreativeView.getName().replace(dbCreativeViewDTO.getName(), creativeViewDTO.getName()));
                }
                creativeRepository.updateCreativePart(context, updateCreative);
                return updateCreative.getId();
            }).commit().getResultList();
            RogerLogger.info("创意(id=%s)下的子创意修改成功，subCreativeIds=%s", creativeViewDTO.getId(), JSON.toJSONString(subCreativeIds));
        }
        return count;
    }

    public Integer updateCreativePreview(ServiceContext context, CreativeViewDTO creativeViewDTO) {
        CreativeQueryOptionViewDTO queryOption = CreativeQueryOptionViewDTO.builder().needChildren(true).build();
        CreativeViewDTO dbCreativeViewDTO = this.getCreativeInfoByOption(context, creativeViewDTO.getId(), queryOption);
        AssertUtil.notNull(dbCreativeViewDTO, "创意不能为空");

        Integer count = creativeRepository.updateCreativePart(context, creativeViewDTO);
        // 更新子创意
        if (CollectionUtils.isNotEmpty(dbCreativeViewDTO.getSubCreativeViewDTOList())) {
            List<Long> subCreativeIds = TaskStream.execute(creativeUpdateTaskIdentifier, dbCreativeViewDTO.getSubCreativeViewDTOList(), (subCreativeView, index) -> {
                CreativeViewDTO updateCreative = BeanUtils.copyIgnoreNull(creativeViewDTO, new CreativeViewDTO());
                updateCreative.setId(subCreativeView.getId());
                creativeRepository.updateCreativePart(context, updateCreative);
                return updateCreative.getId();
            }).commit().getResultList();
            RogerLogger.info("创意(id=%s)下的子创意修改成功，subCreativeIds=%s", creativeViewDTO.getId(), JSON.toJSONString(subCreativeIds));
        }
        return count;
    }

    /**
     * 更新创意审核状态
     *
     * @param context
     * @param creativeViewDTO
     * @return
     */
    public SingleResponse<Integer> updateCreativeAudit(ServiceContext context, CreativeViewDTO creativeViewDTO) {
        CreativeViewDTO dbCreativeViewDTO = this.getCreativeInfoByOption(context, creativeViewDTO.getId(), CreativeQueryOptionViewDTO.builder().build());
        TemplateViewDTO templateViewDTO = creativeTemplateRepository.getTemplateById(context, dbCreativeViewDTO.getCreativeTemplate().getSspTemplateId());
        this.processCreative(context, templateViewDTO, dbCreativeViewDTO);
        AuditViewDTO auditViewDTO = this.processCreativeAudit(context, templateViewDTO, dbCreativeViewDTO);
        creativeViewDTO.setIsRequired(dbCreativeViewDTO.getIsRequired());
        creativeViewDTO.setCreativeAudit(auditViewDTO);
        Integer result = creativeRepository.updateCreativePart(context, creativeViewDTO);
        return SingleResponse.of(result);
    }

    /**
     * 修改媒体审核状态
     * @param serviceContext
     * @param templateViewDTO
     * @param creativeViewDTO
     * @return
     */
    public Integer updateMediaAudit(ServiceContext serviceContext, TemplateViewDTO templateViewDTO, CreativeViewDTO creativeViewDTO) {
        MediaAuditViewDTO mediaAuditViewDTO = runAbilitySpi(BizCreativeSpi.class,
                extension -> extension.processMediaAudit(serviceContext, templateViewDTO, creativeViewDTO), getSpiBizCode(creativeViewDTO));
        CreativeViewDTO updateCreativeViewDTO = new CreativeViewDTO();
        updateCreativeViewDTO.setId(creativeViewDTO.getId());
        AuditViewDTO creativeAudit = new AuditViewDTO();
        creativeAudit.setMediaAudit(mediaAuditViewDTO);
        updateCreativeViewDTO.setCreativeAudit(creativeAudit);
        return creativeRepository.updateCreativePart(serviceContext, updateCreativeViewDTO);
    }

    /**
     * 同步资质审核状态
     *
     * @param serviceContext
     * @param qualifyJson
     */
    public void syncQualificationAuditStatus(ServiceContext serviceContext, String qualifyJson) {
        //仅查询风控/运营审核拒绝的创意
        CreativeQueryViewDTO creativeQueryViewDTO = new CreativeQueryViewDTO();
        creativeQueryViewDTO.setShowAuditStatusList(Lists.newArrayList(BrandCreativeShowAuditStatusEnum.CREATIVE_CENTER_REFUSE.getCode(), BrandCreativeShowAuditStatusEnum.OM_REFUSE.getCode()));
        creativeQueryViewDTO.setQueryAfterGmtCreateTime(BrandDateUtil.getAfterDate(BrandDateUtil.getCurrentDate(), -30));
        creativeQueryViewDTO.setQueryAfterEndTime(BrandDateUtil.getCurrentDate());
        creativeQueryViewDTO.setCreativeIdEqCreativePackageId(null);
        creativeQueryViewDTO.setPageSize(MAX_PAGE_COUNT);
        creativeQueryViewDTO.setPageNo(1);
//        int pageNo = 1;
        List<Long> rejectCreativeIdList = Lists.newArrayList();
        PageUtil.execute(idx -> {
                    creativeQueryViewDTO.setPageNo(idx);
                    return creativeRepository.findListWithPage(serviceContext, creativeQueryViewDTO);
                },
                resp -> getTotalPage(resp.getCount(), creativeQueryViewDTO.getPageSize()),
                resp -> {
                    if (resp != null) {
                        List<Long> resultIdList = resp.getList().stream()
                                .filter(creative -> creative.getEndTime() != null)
                                .map(CreativeViewDTO::getId).collect(Collectors.toList());
                        rejectCreativeIdList.addAll(resultIdList);
                    }
                });
        if (CollectionUtils.isNotEmpty(rejectCreativeIdList)) {
            creativeRepository.rePushCreativeCenter(serviceContext, rejectCreativeIdList, qualifyJson);
        }
    }

    /**
     * 创意审核拒绝
     */
    public void creativeReject(ServiceContext context, CreativeRejectMsgViewDTO creativeRejectMsgViewDTO) {
        AssertUtil.notNull(creativeRejectMsgViewDTO, "消息不能为空");
        AssertUtil.notNull(creativeRejectMsgViewDTO.getMemberId(), "memberId不能为空");
        AssertUtil.notNull(creativeRejectMsgViewDTO.getCreativeId(), "创意ID不能为空");
        CreativeViewDTO creative = creativeRepository.getCreativeById(context, creativeRejectMsgViewDTO.getCreativeId());
        AssertUtil.notNull(creative, "创意不存在");
        if (creative.getEndTime().before(new Date())) {
            RogerLogger.info("creativeReject 创意id: {} 已过期，不处理", creativeRejectMsgViewDTO.getCreativeId());
            return;
        }
        CreativeRejectMessageSendAbilityParam sendAbilityParam = CreativeRejectMessageSendAbilityParam.builder()
                .abilityTarget(creativeRejectMsgViewDTO).build();
        Boolean supportSend = creativeRejectMessageSendJudgeAbility.handle(context, sendAbilityParam);
        if(!supportSend){
            RogerLogger.info("creativeReject 创意id: {} 不需要发送拒绝消息，不处理", creativeRejectMsgViewDTO.getCreativeId());
            return;
        }
        //发送消息拒绝通知
        creativeRejectMessageSendAbility.handle(context, sendAbilityParam);
    }

    /**
     * 更新子计划
     *
     * @param context
     * @param dbCreativeViewDTO
     * @param creativeViewDTO
     * @param templateViewDTOMap
     */
    private void updateSubCreative(ServiceContext context, CreativeViewDTO dbCreativeViewDTO, CreativeViewDTO creativeViewDTO, Map<Long, TemplateViewDTO> templateViewDTOMap) {
        if (CollectionUtils.isEmpty(dbCreativeViewDTO.getSubCreativeViewDTOList())) {
            return;
        }
        Map<Long, CreativeViewDTO> dbSubCreativeMap = dbCreativeViewDTO.getSubCreativeViewDTOList().stream().collect(Collectors.toMap(creative -> creative.getCreativeTemplate().getSspTemplateId(), Function.identity(), (v1, v2) -> v1));
        Map<Long, CreativeViewDTO> subCreativeMap = creativeViewDTO.getSubCreativeViewDTOList().stream().collect(Collectors.toMap(creative -> creative.getCreativeTemplate().getSspTemplateId(), Function.identity(), (v1, v2) -> v1));
        //判断是否已经送外审，没送外审直接更新
        //如果已经送外审，看看本次有没有更新，如果没更新不做变动
        //如果已经变动了，删除之前，保存一个新的，同时替换相关的creativeRef
        List<CreativeViewDTO> addList = subCreativeMap.entrySet().stream().filter(entry -> !dbSubCreativeMap.containsKey(entry.getKey())).map(Map.Entry::getValue).collect(Collectors.toList());
        List<CreativeViewDTO> modList = subCreativeMap.entrySet().stream().filter(entry -> dbSubCreativeMap.containsKey(entry.getKey())).map(Map.Entry::getValue).collect(Collectors.toList());
        List<CreativeViewDTO> delList = dbSubCreativeMap.entrySet().stream().filter(entry -> !subCreativeMap.containsKey(entry.getKey())).map(Map.Entry::getValue).collect(Collectors.toList());
        //新增子创意
        if (CollectionUtils.isNotEmpty(addList)) {
            TaskStream.consume(creativeAddTaskIdentifier, addList, (subCreativeViewDTO, index) -> {
                TemplateViewDTO subTemplateViewDTO = templateViewDTOMap.get(subCreativeViewDTO.getCreativeTemplate().getSspTemplateId());
                subCreativeViewDTO.setCreativePackageId(creativeViewDTO.getId());
                this.processCreative(context, subTemplateViewDTO, subCreativeViewDTO);
                this.processCreativeAudit(context, subTemplateViewDTO, subCreativeViewDTO);
                creativeRepository.addCreative(context, subCreativeViewDTO);
            }).commit().handle();
        }
        //修改子创意
        if (CollectionUtils.isNotEmpty(modList)) {
            TaskStream.consume(creativeUpdateTaskIdentifier, modList, (subCreative, index) -> {
                CreativeViewDTO dbSubCreative = dbSubCreativeMap.get(subCreative.getCreativeTemplate().getSspTemplateId());
                TemplateViewDTO subTemplateViewDTO = templateViewDTOMap.get(subCreative.getCreativeTemplate().getSspTemplateId());
                //如果已经送外审
                if (MediaScopeEnum.SITE_OUT.getCode().equals(subTemplateViewDTO.getMediaScope()) &&
                        BizCreativeToolsHelper.hasPushMedia(dbSubCreative.getCreativeAudit().getShowAuditStatus())) {
                    updatePushMediaAuditSubCreative(context, dbSubCreative, subCreative, subTemplateViewDTO);
                } else {
                    //没送外审的情况直接更新
                    CreativeViewDTO mdoCreative = BeanUtils.copyIgnoreNull(subCreative, dbSubCreative);
                    this.processCreative(context, subTemplateViewDTO, mdoCreative);
                    this.processCreativeAudit(context, subTemplateViewDTO, mdoCreative);
                    creativeRepository.updateCreative(context, mdoCreative);
                }
            }).commit().handle();
        }
        //删除子创意
        if (CollectionUtils.isNotEmpty(delList)) {
            List<Long> delCreativeIds = delList.stream().map(CreativeViewDTO::getId).collect(Collectors.toList());
            creativeRepository.deleteCreatives(context, delCreativeIds);
        }
    }

    /**
     * 更新已推送媒体审核的子创意
     *
     * @param context
     * @param dbSubCreative
     * @param subCreative
     * @param subTemplate
     */
    private void updatePushMediaAuditSubCreative(ServiceContext context, CreativeViewDTO dbSubCreative, CreativeViewDTO subCreative, TemplateViewDTO subTemplate) {
        //外审审核拒绝的情况下继续判断
        if (BrandCreativeShowAuditStatusEnum.CREATIVE_MEDIA_AUDIT_REFUSE.getCode().equals(dbSubCreative.getCreativeAudit().getShowAuditStatus())) {
            List<ElementViewDTO> modifyElement = creativeUpdateElementGetAbility.handle(context, CreativeUpdateElementGetAbilityParam.builder()
                    .abilityTarget(subCreative).dbCreativeViewDTO(dbSubCreative).build());
            //如果被外审拒绝的创意，如果元素有更改的情况，需要生成一个新的创意
            if (CollectionUtils.isNotEmpty(modifyElement)) {
                CreativeQueryViewDTO queryViewDTO = new CreativeQueryViewDTO();
                queryViewDTO.setIds(Collections.singletonList(dbSubCreative.getId()));
                List<CreativeRefViewDTO> creativeRefList = creativeRepository.findCreativeRefList(context, queryViewDTO);
                //删除之前的创意，重新生成一个新的，历史创意绑定关系同步删除
                creativeRepository.deleteCreatives(context, Lists.newArrayList(dbSubCreative.getId()));
                if (CollectionUtils.isNotEmpty(creativeRefList)) {
                    creativeRepository.delBindCreative(context, Collections.singletonList(dbSubCreative.getId()));
                }
                CreativeViewDTO mdoCreative = BeanUtils.copyIgnoreNull(subCreative, dbSubCreative);
                mdoCreative.setId(null);
                mdoCreative.setCreativePackageId(dbSubCreative.getCreativePackageId());
                this.processCreative(context, subTemplate, mdoCreative);
                this.processCreativeAudit(context, subTemplate, mdoCreative);
                //新建创意，历史绑定关系用新创意重新绑定
                Long subCreativeId = creativeRepository.addCreative(context, mdoCreative);
                if (CollectionUtils.isNotEmpty(creativeRefList)) {
                    creativeRefList.forEach(creativeRefViewDTO -> {
                        creativeRefViewDTO.setCreativeId(subCreativeId);
                        creativeRefViewDTO.setId(null);
                    });
                    creativeRepository.addBatchCreativeRef(context, creativeRefList);
                }
            }
        }
    }

    /**
     * 同步创意送审数据
     */
    public void syncCreativeSwitch(ServiceContext serviceContext, CreativeAuditSwitchNotifyViewDTO creativeAuditSwitchNotifyViewDTO) {
        CreativeViewDTO creative = creativeRepository.getCreativeById(serviceContext, creativeAuditSwitchNotifyViewDTO.getId());
        if (Objects.isNull(creative)) {
            return;
        }
        if (BrandCreativeOnlineStatusEnum.OFF.getCode().equals(creative.getOnlineStatus())) {
            return;
        }
        if (BrandDateUtil.isBefore(creative.getEndTime(), new Date())) {
            return;
        }
        TemplateViewDTO templateViewDTO = creativeTemplateRepository.getTemplateById(serviceContext, creative.getCreativeTemplate().getSspTemplateId());
        if (TemplateStatusEnum.INVALID.value().equals(templateViewDTO.getStatus())) {
            return;
        }
        AuditViewDTO auditViewDTO = this.processCreativeAudit(serviceContext, templateViewDTO, creative);
        MediaAuditViewDTO mediaAudit = auditViewDTO.getMediaAudit();
        if (BrandCreativeAuditSwitchEnum.WANTED_ABLE.getCode().equals(mediaAudit.getAuditSwitch())) {
            CreativeViewDTO creativeViewDTO = new CreativeViewDTO();
            creativeViewDTO.setId(creativeAuditSwitchNotifyViewDTO.getId());
            creativeViewDTO.setCreativeAudit(auditViewDTO);
            creativeRepository.updateCreativePart(serviceContext, creativeViewDTO);
        }
    }

    /**
     * 复制创意并设置为直接投创意
     */
    public Long copyCreativeAsDirect(ServiceContext context, Long creativeId) {
        if (Objects.isNull(creativeId)) {
            return null;
        }
        CreativeQueryViewDTO queryViewDTO = new CreativeQueryViewDTO();
        queryViewDTO.setIds(Collections.singletonList(creativeId));
        List<CreativeRefViewDTO> creativeRefList = creativeRepository.findCreativeRefList(context, queryViewDTO, false);
        AssertUtil.notEmpty(creativeRefList, "当前创意关联单元后可使用复制为媒体直投创意功能，请操作关联单元");
        CreativeViewDTO creativeViewDTO = creativeRepository.getCreativeById(context, creativeId);
        AssertUtil.notNull(creativeViewDTO, "创意不存在");
        creativeViewDTO.setCreativePackageId(null);
        return this.copyCreativeAsDirect(context, creativeViewDTO);
    }

    public void processCreative(ServiceContext serviceContext, TemplateViewDTO templateViewDTO, CreativeViewDTO creativeViewDTO) {
        if (Objects.isNull(creativeViewDTO.getCreativeScope())){
            creativeViewDTO.setCreativeScope(templateViewDTO.getMediaScope());
        }
        CreativeTemplateViewDTO creativeTemplate = creativeViewDTO.getCreativeTemplate();
        creativeTemplate.setSspCreativeType(templateViewDTO.getCreativeType());
        creativeTemplate.setSspResourceType(Integer.valueOf(templateViewDTO.getResourceType()));
        creativeTemplate.setSspAdType(templateViewDTO.getEffectList().stream().map(CommonViewDTO::getValue).collect(Collectors.joining(",")));
        creativeViewDTO.setLinkageMode(templateViewDTO.getLinkageMode());
        creativeViewDTO.setPackageType(BrandCreativePackageTypeEnum.COMMON.getValue());
        creativeViewDTO.setIsRequired(BrandBoolEnum.BRAND_TRUE.getCode());
        if (MediaScopeEnum.TAO_OUT.getCode().equals(templateViewDTO.getMediaScope()) &&
                BrandBoolEnum.BRAND_FALSE.getCode().equals(templateViewDTO.getDifferentiatedMedia())) {
            creativeViewDTO.setCreativeScope(BrandCreativeScopeEnum.SITE_OUT.getCode());
        }
        creativeCustomerCategoryFillAbility.handle(serviceContext,
                CreativeCustomerCategoryFillAbilityParam.builder().abilityTarget(creativeViewDTO).templateViewDTO(templateViewDTO).build());

        runAbilitySpi(BizCreativeSpi.class,
                extension -> extension.process(serviceContext, templateViewDTO, creativeViewDTO), BizCreativeSpi.getSpiBizCode(creativeViewDTO));
        //临时处理，后续删除
        creativeElementSecondProcessAbilityForAddCreative.handle(serviceContext,
                CreativeElementSecondProcessAbilityParam.builder().abilityTarget(creativeViewDTO).build());

        //商业能力挂载
        AbilityInvoker.invokeAll(ICreativeProcessCreativeBusinessAbilityPoint.class,
                BusinessAbilityRouteContext.builder().specifiedBusinessAbilityCodes(Lists.newArrayList(SmartCreativeBusinessAbility.ABILITY_CODE)).build(),
                callback -> callback.invokeForProcessCreative(serviceContext, creativeViewDTO, templateViewDTO));
    }

    public AuditViewDTO processCreativeAudit(ServiceContext serviceContext, TemplateViewDTO templateViewDTO, CreativeViewDTO creativeViewDTO) {
        AuditViewDTO auditViewDTO = creativeViewDTO.getCreativeAudit();
        auditViewDTO.setAuditSceneType(templateViewDTO.getMediaScope());
        String spiCode = BizCreativeSpi.getSpiBizCode(creativeViewDTO);
        MamaAuditViewDTO mamaAuditViewDTO = runAbilitySpi(BizCreativeSpi.class,
                extension -> extension.processMamaAudit(serviceContext, templateViewDTO, creativeViewDTO), spiCode);
        MediaAuditViewDTO mediaAuditViewDTO = runAbilitySpi(BizCreativeSpi.class,
                extension -> extension.processMediaAudit(serviceContext, templateViewDTO, creativeViewDTO), spiCode);

        auditViewDTO.setMamaAudit(mamaAuditViewDTO);
        auditViewDTO.setMediaAudit(mediaAuditViewDTO);

        //商业能力挂载
        AbilityInvoker.invokeAll(ICreativeProcessCreativeAuditBusinessAbilityPoint.class,
                BusinessAbilityRouteContext.builder().specifiedBusinessAbilityCodes(Lists.newArrayList(SmartCreativeBusinessAbility.ABILITY_CODE)).build(),
                callback -> callback.invokeForProcessCreativeAudit(serviceContext, creativeViewDTO, templateViewDTO));
        return auditViewDTO;
    }

    /**
     * 复制创意并设置为直接投创意
     *
     * @param context
     * @param creativeViewDTO
     * @return
     */
    public Long copyCreativeAsDirect(ServiceContext context, CreativeViewDTO creativeViewDTO) {
        TemplateViewDTO templateViewDTO = creativeTemplateRepository.getTemplateById(context, creativeViewDTO.getCreativeTemplate().getSspTemplateId());
        AssertUtil.assertTrue(BrandCreativeTargetTypeEnum.PROGRAM.getCode().equals(creativeViewDTO.getTargetType()), "创意不是程序化创意");
        AssertUtil.assertTrue(BrandCreativeShowAuditStatusEnum.AUDIT_PASS.getCode().equals(creativeViewDTO.getCreativeAudit().getShowAuditStatus()), "创意还没审核通过");

        creativeViewDTO.setTargetType(BrandCreativeTargetTypeEnum.DIRECT.getCode());
        this.processCreativeAudit(context, templateViewDTO, creativeViewDTO);

        MediaAuditViewDTO mediaAudit = creativeViewDTO.getCreativeAudit().getMediaAudit();
        if (mediaAudit != null) {
            mediaAudit.setMediaAuditStatus(null);
            String auditData = mediaAudit.getAuditData();
            if (StringUtils.isNotBlank(auditData)) {
                HashMap<String, Object> stringObjectHashMap = JSON.parseObject(auditData, new TypeReference<HashMap<String, Object>>() {
                });
                stringObjectHashMap.put(CreativeConstant.NEED_AUDIT, false);
                mediaAudit.setAuditData(JSON.toJSONString(stringObjectHashMap));
            } else {
                Map<String, Boolean> auditMap = Maps.newHashMap();
                auditMap.put(CreativeConstant.NEED_AUDIT, false);
                mediaAudit.setAuditData(JSON.toJSONString(auditMap));
            }
        }
        creativeViewDTO.setId(null);
        creativeViewDTO.setName(creativeViewDTO.getName() + "_副本");
        return creativeRepository.addCreative(context, creativeViewDTO);
    }

    /**
     * 拓版素材组
     *
     * @param serviceContext
     * @param materialGroupViewDTO
     * @return
     */
    public MaterialGroupViewDTO cropMaterialGroup(ServiceContext serviceContext, MaterialGroupViewDTO materialGroupViewDTO) {
        AssertUtil.notNull(materialGroupViewDTO, "素材组不能为空");

        //商业能力挂载
        AbilityInvoker.invokeAll(ICreativeMaterialGroupCropBusinessAbilityPoint.class,
                BusinessAbilityRouteContext.builder().specifiedBusinessAbilityCodes(Lists.newArrayList(SmartCreativeBusinessAbility.ABILITY_CODE)).build(),
                callback -> callback.invokeForMaterialGroupCrop(serviceContext, materialGroupViewDTO));

        return materialGroupViewDTO;
    }

    /**
     * 素材组拓版结果回调
     *
     * @param serviceContext
     * @param malusCropResultViewDTO
     * @return
     */
    public MalusCropResultViewDTO cropMaterialGroupCallback(ServiceContext serviceContext, MalusCropResultViewDTO malusCropResultViewDTO) {
        AssertUtil.notNull(malusCropResultViewDTO, "拓版结果为空");
        //商业能力挂载
        AbilityInvoker.invokeAll(ICreativeMaterialGroupCropCallbackBusinessAbilityPoint.class,
                BusinessAbilityRouteContext.builder().specifiedBusinessAbilityCodes(Lists.newArrayList(SmartCreativeBusinessAbility.ABILITY_CODE)).build(),
                callback -> callback.invokeForMaterialGroupCropCallback(serviceContext, malusCropResultViewDTO));

        return malusCropResultViewDTO;
    }

    /**
     * 校验创意模板
     *
     * @param creativeViewDTO
     * @param templateViewDTOMap
     */
    private void validateCreativeTemplate(ServiceContext context, CreativeViewDTO creativeViewDTO, Map<Long, TemplateViewDTO> templateViewDTOMap) {
        TemplateViewDTO template = templateViewDTOMap.get(creativeViewDTO.getCreativeTemplate().getSspTemplateId());
        AssertUtil.notNull(template, String.format("创意模版(id=%s)查询为空", creativeViewDTO.getCreativeTemplate().getSspTemplateId()));
        creativeTemplateValidateAbility.handle(context,CreativeTemplateAbilityParam.builder().abilityTarget(template).build());
        //子创意模板
        if (CollectionUtils.isNotEmpty(creativeViewDTO.getSubCreativeViewDTOList())) {
            for (CreativeViewDTO subCreativeViewDTO : creativeViewDTO.getSubCreativeViewDTOList()) {
                AssertUtil.assertTrue(templateViewDTOMap.containsKey(subCreativeViewDTO.getCreativeTemplate().getSspTemplateId()),
                        String.format("创意模版(id=%s)查询为空", subCreativeViewDTO.getCreativeTemplate().getSspTemplateId()));
            }
        }
    }

    /**
     * 生成智能创意-子创意
     * @param serviceContext
     * @param materialGroupId
     */
    public void generateSmartSubCreative(ServiceContext serviceContext, Long materialGroupId) {
        List<CreativeViewDTO> creativeViewDTOS = creativeRepository.findListByMaterialGroupId(serviceContext, materialGroupId);

        for (CreativeViewDTO creativeViewDTO : creativeViewDTOS) {
            MaterialGroupViewDTO materialGroup = creativeViewDTO.getMaterialGroupInfo().getMaterialGroupViewDTOList().stream().filter(materialGroupViewDTO ->
                    materialGroupId.equals(materialGroupViewDTO.getId())).findFirst().orElse(null);
            if (materialGroup == null) {
                RogerLogger.info(String.format("子创意生成失败，素材组不存在，创意id=%s，素材组id=%s", creativeViewDTO.getId(), materialGroupId));
                continue;
            }
            TemplateViewDTO mainTemplate = creativeTemplateRepository.getTemplateById(serviceContext, creativeViewDTO.getCreativeTemplate().getSspTemplateId());
            List<Long> templateIds = getTemplateIds(serviceContext, creativeViewDTO.getId());
            RogerLogger.info(String.format("创意(id=%s)下支持的子模板列表为，templateIds=%s", creativeViewDTO.getId(), JSON.toJSONString(templateIds)));
            if (CollectionUtils.isEmpty(templateIds)) {
                RogerLogger.info(String.format("子创意生成失败，不满足子创意生成条件原因：创意(id=%s)下支持的子模板列表为空", creativeViewDTO.getId()));
                continue;
            }
            List<TemplateContextViewDTO> templateContextViewDTOS = creativeTemplateRepository.getTemplateMetaData(serviceContext,
                    mainTemplate.getInteractTemplateList().stream().filter(nbTemplateDTO ->
                            BrandBoolEnum.BRAND_FALSE.getCode().equals(nbTemplateDTO.getSubTemplate())).filter(templateViewDTO -> templateIds.contains(templateViewDTO.getId())).map(TemplateViewDTO::getId).collect(Collectors.toList()), false);
            //商业能力挂载
            List<CreativeViewDTO> subCreativeList = AbilityInvoker.invoke(ICreativeGenerateSubCreativeBusinessAbilityPoint.class,
                    BusinessAbilityRouteContext.builder().specifiedBusinessAbilityCodes(Lists.newArrayList(SmartCreativeBusinessAbility.ABILITY_CODE)).build(),
                    callback -> callback.invokeForGenerateSubCreative(serviceContext, creativeViewDTO, materialGroup, templateContextViewDTOS));
            if (CollectionUtils.isEmpty(subCreativeList)) {
                continue;
            }
            Map<Long, TemplateViewDTO> templateViewDTOMap = templateContextViewDTOS.stream().collect(Collectors.toMap(templateContextViewDTO ->
                    templateContextViewDTO.getTemplateViewDTO().getId(), TemplateContextViewDTO::getTemplateViewDTO));

            //批量新建子创意
            batchAddSubCreative(serviceContext,creativeViewDTO,templateViewDTOMap,subCreativeList);
            //批量绑定单元
            generateSubCreativeRef(serviceContext, creativeViewDTO.getId());
        }
    }

    /**
     * 批量新增子创意
     * @param serviceContext
     * @param templateViewDTOMap
     * @param creativeViewDTO
     * @param subCreativeList
     */
    private void batchAddSubCreative(ServiceContext serviceContext,CreativeViewDTO creativeViewDTO,Map<Long, TemplateViewDTO> templateViewDTOMap,List<CreativeViewDTO> subCreativeList){
        if (CollectionUtils.isEmpty(subCreativeList)) {
            return;
        }
        List<CreativeValidateViewDTO> validateViewDTOS = TaskStream.execute(creativeValidateTaskIdentifier, subCreativeList, (subCreativeViewDTO, index) -> {
            TemplateViewDTO subTemplate = templateViewDTOMap.get(subCreativeViewDTO.getCreativeTemplate().getSspTemplateId());
            CreativeValidateViewDTO creativeValidateViewDTO = new CreativeValidateViewDTO();
            creativeValidateViewDTO.setSspTemplateId(subTemplate.getId());
            creativeValidateViewDTO.setSspTemplateName(subTemplate.getName());
            try {
                runAbilitySpi(BizCreativeValidateSpi.class,
                        extension -> extension.checkCreative(serviceContext, subCreativeViewDTO, subTemplate, creativeValidateViewDTO), BizCreativeValidateSpi.getSpiBizCode(subCreativeViewDTO));
            } catch (Exception e) {
                RogerLogger.error(String.format("模板存在问题，templateIds=%s",subTemplate.getId()), e);
                creativeValidateViewDTO.setErrorList(Lists.newArrayList(new ErrorMessageViewDTO(subTemplate.getId().toString(), e.getMessage())));
            }
            return creativeValidateViewDTO;
        }).commit().getResultList();

        if (CollectionUtils.isNotEmpty(validateViewDTOS)) {
            List<Long> errorTemplateIds = validateViewDTOS.stream().filter(creativeValidateViewDTO ->
                    CollectionUtils.isNotEmpty(creativeValidateViewDTO.getErrorList())).map(CreativeValidateViewDTO::getSspTemplateId).collect(Collectors.toList());
            if (CollectionUtils.isNotEmpty(errorTemplateIds)){
                RogerLogger.error(String.format("模板存在问题，errorTemplate=%s",JSON.toJSONString(validateViewDTOS.stream().filter(creativeValidateViewDTO ->
                        CollectionUtils.isNotEmpty(creativeValidateViewDTO.getErrorList())).collect(Collectors.toList()))));
            }
            subCreativeList = subCreativeList.stream().filter(subCreative -> !errorTemplateIds.contains(subCreative.getCreativeTemplate().getSspTemplateId())).collect(Collectors.toList());
        }
        if(CollectionUtils.isNotEmpty(subCreativeList)){
            List<Long> subCreativeIds = TaskStream.execute(creativeAddTaskIdentifier, subCreativeList, (subCreativeViewDTO, index) -> {
                TemplateViewDTO subTemplateViewDTO = templateViewDTOMap.get(subCreativeViewDTO.getCreativeTemplate().getSspTemplateId());
                subCreativeViewDTO.setCreativePackageId(creativeViewDTO.getId());

                this.processCreative(serviceContext, subTemplateViewDTO, subCreativeViewDTO);
                this.processCreativeAudit(serviceContext, subTemplateViewDTO, subCreativeViewDTO);
                return creativeRepository.addCreative(serviceContext, subCreativeViewDTO);
            }).commit().getResultList();
            RogerLogger.info(String.format("创意(id=%s)下的子创意创建成功，subCreativeIds=%s", creativeViewDTO.getId(), JSON.toJSONString(subCreativeIds)));
        }
    }

    /**
     * 生成绑定关系并触发子创意审核
     * @param serviceContext
     * @param creativeId
     */
    private void generateSubCreativeRef(ServiceContext serviceContext, Long creativeId) {
        CreativeQueryViewDTO queryViewDTO = new CreativeQueryViewDTO();
        queryViewDTO.setIds(Lists.newArrayList(creativeId));
        queryViewDTO.setPageSize(MAX_PAGE_COUNT);
        List<CreativeRefViewDTO> creativeRefList = creativeRepository.findCreativeRefList(serviceContext, queryViewDTO);
        RogerLogger.info("generateSubCreativeRef,creativeRefList:{}", JSON.toJSONString(creativeRefList));
        if (CollectionUtils.isNotEmpty(creativeRefList)) {
            CreativeQueryViewDTO creativeQueryViewDTO = new CreativeQueryViewDTO();
            creativeQueryViewDTO.setCreativePackageIdList(Lists.newArrayList(creativeId));
            creativeQueryViewDTO.setCreativeIdEqCreativePackageId(Boolean.FALSE);
            creativeQueryViewDTO.setPackageType(BrandCreativePackageTypeEnum.COMMON.getValue());
            creativeQueryViewDTO.setPageSize(MAX_PAGE_COUNT);
            PageResultViewDTO<CreativeViewDTO> result = creativeRepository.findListWithPage(serviceContext, creativeQueryViewDTO);
            RogerLogger.info("generateSubCreativeRef,subCreativeList:{}", JSON.toJSONString(result));
            if (CollectionUtils.isNotEmpty(result.getList())) {

                List<CreativeRefViewDTO> subCreativeRefs = result.getList().stream().map(creativePageViewDTO -> {
                    CreativeRefViewDTO creativeRefViewDTO = BeanUtils.copyIgnoreNull(creativeRefList.get(0), new CreativeRefViewDTO());
                    creativeRefViewDTO.setId(null);
                    creativeRefViewDTO.setCreativeId(creativePageViewDTO.getId());
                    creativeRefViewDTO.setPackageType(BrandCreativePackageTypeEnum.COMMON.getValue());
                    return creativeRefViewDTO;
                }).collect(Collectors.toList());
                if (CollectionUtils.isNotEmpty(subCreativeRefs)) {
                    creativeRepository.addBatchCreativeRef(serviceContext, subCreativeRefs);
                }
                result.getList().stream().forEach(creativePageViewDTO -> {
                    CreativeViewDTO creativeViewDTO = new CreativeViewDTO();
                    creativeViewDTO.setId(creativePageViewDTO.getId());
                    this.updateCreativeAudit(serviceContext, creativeViewDTO);
                });
                RogerLogger.info("generateSubCreativeRef,新增创意关联关系完成");
            }
        }
    }

    public CreativeValidateViewDTO checkCreative(ServiceContext serviceContext, CreativeViewDTO creativeViewDTO) {
        if (creativeViewDTO.getId() != null) {
            creativeRefAdgroupMixDateValidateAbility.handle(serviceContext, CreativeRefAdgroupMixDateValidateAbilityParam.builder().abilityTarget(creativeViewDTO).build());
        }
        TemplateViewDTO creativeTemplate = creativeTemplateRepository.getTemplateById(serviceContext, creativeViewDTO.getCreativeTemplate().getSspTemplateId());
        if (MediaScopeEnum.TAO_OUT.getCode().equals(creativeTemplate.getMediaScope()) &&
                BrandBoolEnum.BRAND_FALSE.getCode().equals(creativeTemplate.getDifferentiatedMedia())) {
            creativeViewDTO.setCreativeScope(BrandCreativeScopeEnum.SITE_OUT.getCode());
        } else {
            creativeViewDTO.setCreativeScope(creativeTemplate.getMediaScope());
        }
        CreativeValidateViewDTO creativeValidateViewDTO = new CreativeValidateViewDTO();
        creativeValidateViewDTO.setSspTemplateId(creativeTemplate.getId());
        creativeValidateViewDTO.setSspTemplateName(creativeTemplate.getName());
        runAbilitySpi(BizCreativeValidateSpi.class,
                extension -> extension.checkCreative(serviceContext, creativeViewDTO, creativeTemplate, creativeValidateViewDTO), BizCreativeValidateSpi.getSpiBizCode(creativeViewDTO));

        //商业能力挂载
        AbilityInvoker.invokeAll(ICreativeCheckBusinessAbilityPoint.class,
                BusinessAbilityRouteContext.builder().specifiedBusinessAbilityCodes(Lists.newArrayList(SmartCreativeBusinessAbility.ABILITY_CODE)).build(),
                callback -> callback.invokeForCreativeCheck(serviceContext, creativeViewDTO, creativeTemplate, creativeValidateViewDTO));
        return creativeValidateViewDTO;
    }

    private List<Long> getTemplateIds(ServiceContext serviceContext, Long creativeId) {
        CreativeQueryViewDTO queryViewDTO = new CreativeQueryViewDTO();
        queryViewDTO.setIds(Lists.newArrayList(creativeId));
        List<CreativeRefViewDTO> creativeRefList = creativeRepository.findCreativeRefList(serviceContext, queryViewDTO);
        if (CollectionUtils.isNotEmpty(creativeRefList)) {
            CreativeRefViewDTO refViewDTO = creativeRefList.get(0);
            CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder().campaignIds(Lists.newArrayList(refViewDTO.getCampaignId())).build();
            CampaignQueryOption option = CampaignQueryOption.builder().needChildren(true).build();
            List<CampaignViewDTO> campaignViewDTOList = campaignStructureQueryAbility.handle(serviceContext, CampaignStructureQueryAbilityParam.builder()
                    .abilityTarget(campaignQueryViewDTO).queryOption(option).build());
            List<CampaignTemplateViewDTO> campaignTemplateViewDTOS = campaignRepository.getCampaignTemplateIds(serviceContext, campaignViewDTOList);

                return campaignTemplateViewDTOS.stream().filter(campaignTemplateViewDTO -> CollectionUtils.isNotEmpty(campaignTemplateViewDTO.getTemplateIds()))
                        .flatMap(campaignTemplateViewDTO -> campaignTemplateViewDTO.getTemplateIds().stream()).distinct().collect(Collectors.toList());
        }
        return Collections.EMPTY_LIST;
    }


    public void generateTaoInnerSmartSubCreative(ServiceContext serviceContext, CreativeViewDTO creativeViewDTO) {
        TemplateContextViewDTO templateMetaData = creativeTemplateRepository.getTemplateMetaData(serviceContext, creativeViewDTO.getCreativeTemplate().getSspTemplateId(), false);
        if (Objects.nonNull(templateMetaData)) {
            TemplateViewDTO templateViewDTO = templateMetaData.getTemplateViewDTO();
            List<CreativeViewDTO> subCreativeList = runAbilitySpi(BizCreativeSpi.class,
                    extension -> extension.generateSubCreativeForBrandSmartCreative(serviceContext, creativeViewDTO, templateMetaData, templateViewDTO),
                        BizCreativeSpi.getSpiBizCode(templateViewDTO));
            if(CollectionUtils.isNotEmpty(subCreativeList)){
                Map<Long, TemplateViewDTO> templateViewDTOMap = Optional.ofNullable(templateViewDTO.getInteractTemplateList()).orElse(Lists.newArrayList())
                        .stream().collect(Collectors.toMap(TemplateViewDTO::getId, Function.identity()));
                templateViewDTOMap.put(templateViewDTO.getId(), templateViewDTO);
                batchAddSubCreative(serviceContext, creativeViewDTO, templateViewDTOMap, subCreativeList);
            }
        }
    }

    /**
     * 查询创意关联模板(包含子创意)
     * @param context
     * @param creativeViewDTO
     * @return
     */
    private Map<Long, TemplateViewDTO> getTemplateMap(ServiceContext context,CreativeViewDTO creativeViewDTO){
        Set<Long> templateIds = Sets.newHashSet(creativeViewDTO.getCreativeTemplate().getSspTemplateId());
        if(CollectionUtils.isNotEmpty(creativeViewDTO.getSubCreativeViewDTOList())){
            creativeViewDTO.getSubCreativeViewDTOList().forEach(subCreativeViewDTO -> {
                templateIds.add(subCreativeViewDTO.getCreativeTemplate().getSspTemplateId());
            });
        }
        CreativeTemplateQueryDTO creativeTemplateQueryDTO = new CreativeTemplateQueryDTO();
        creativeTemplateQueryDTO.setNeedTag(true);
        creativeTemplateQueryDTO.setNeedSetting(true);
        creativeTemplateQueryDTO.setNeedAssociation(true);
        creativeTemplateQueryDTO.setTemplateIdList(Lists.newArrayList(templateIds));
        List<TemplateViewDTO> templateList = creativeTemplateRepository.getTemplateList(context, creativeTemplateQueryDTO);
        return Optional.ofNullable(templateList).orElse(Lists.newArrayList()).stream()
                .collect(Collectors.toMap(TemplateViewDTO::getId, Function.identity()));
    }

    private CreativeViewDTO getCreativeInfoByOption(ServiceContext serviceContext, Long id, CreativeQueryOptionViewDTO option){
        List<CreativeViewDTO> creativeViewDTOList = creativeStructureQueryAbility.handle(serviceContext,
                CreativeStructureQueryAbilityParam.builder().abilityTargets(Lists.newArrayList(id)).queryOption(option).build());
        return CollectionUtils.isNotEmpty(creativeViewDTOList) ? creativeViewDTOList.get(0) : null;
    }
}
