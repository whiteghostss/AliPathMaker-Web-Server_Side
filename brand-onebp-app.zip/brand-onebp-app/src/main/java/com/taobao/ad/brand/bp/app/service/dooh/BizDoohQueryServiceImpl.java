package com.taobao.ad.brand.bp.app.service.dooh;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.taobao.ad.brand.bp.client.api.dooh.BizDoohQueryService;
import com.taobao.ad.brand.bp.client.api.strategy.BizStrategyQueryService;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohStrategyViewDTO;
import com.taobao.ad.brand.bp.domain.dooh.repository.DoohRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;


@HSFProvider(serviceInterface = BizDoohQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizDoohQueryServiceImpl implements BizDoohQueryService {

    private final DoohRepository doohRepository;
    @Override
    public MultiResponse<CommonViewDTO> getPriorityIndustryList(ServiceContext context) {
        return MultiResponse.of(doohRepository.getPriorityIndustryList());
    }
}
