package com.taobao.ad.brand.bp.app.service.common;

import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.Response;
import com.taobao.ad.brand.bp.client.api.common.BizBpmsCommandService;
import com.taobao.ad.brand.bp.client.enums.common.BizBpmsProcessStatusEnum;
import com.taobao.ad.brand.bp.common.enums.BpmsProcessCodeEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author yanjingang
 * @date 2023/11/9
 */
@HSFProvider(serviceInterface = BizBpmsCommandService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizBpmsCommandServiceImpl implements BizBpmsCommandService {


    @Override
    public Response processFinishCallback(String processCode, String procInstId, Long entityId, Integer result, String extInfo) {

        return null;
    }

    @Override
    public Response processFinishCallback(String processCode, String procInstId, Integer result, String extInfo) {
        validateProcessParam(processCode, procInstId, result);
        BpmsProcessCodeEnum bpmsProcessCodeEnum = BpmsProcessCodeEnum.getByCode(processCode);
        BizBpmsProcessStatusEnum resultEnum = BizBpmsProcessStatusEnum.getByCode(result);
        if (BpmsProcessCodeEnum.isCampaignGroupProcess(processCode)) {
            //TODO
        } else if (BpmsProcessCodeEnum.isCampaignProcess(processCode)) {
        }
        return Response.success();
    }

    private void validateProcessParam(String processCode, String procInstId, Integer result) {
        AssertUtil.notNull(processCode, "流程Code不能为空");
        AssertUtil.notNull(procInstId, "实例ID不能为空");
        AssertUtil.notNull(result, "流程结果不能为空");
        AssertUtil.notNull(BizBpmsProcessStatusEnum.getByCode(result), "流程结果不正确");
    }
}
