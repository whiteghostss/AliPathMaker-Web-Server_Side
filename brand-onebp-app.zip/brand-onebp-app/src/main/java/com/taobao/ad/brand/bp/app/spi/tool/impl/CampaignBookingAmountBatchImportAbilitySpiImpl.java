package com.taobao.ad.brand.bp.app.spi.tool.impl;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.nb.framework.core.annotation.AbilitySpiInstance;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alibaba.ad.nb.tpp.exception.TppException;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.app.spi.tool.BatchImportAbilitySpi;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignCommandWorkflow;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignInventoryWorkflow;
import com.taobao.ad.brand.bp.client.dto.base.ErrorMessageDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignBookingAmountBatchImportParamViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignBookingAmountBatchImportRawViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignScheduleViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportTaskViewDTO;
import com.taobao.ad.brand.bp.client.dto.tool.BatchImportDistLockParamViewDTO;
import com.taobao.ad.brand.bp.client.dto.tool.BatchImportParamViewDTO;
import com.taobao.ad.brand.bp.client.enums.report.ReportTaskStatusEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.enums.distlock.DistLockEnum;
import com.taobao.ad.brand.bp.common.threadpooltask.CampaignBookingAmountBatchImportTaskIdentifier;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.report.repository.ReportSyncTaskRepository;
import com.taobao.eagleeye.EagleEye;
import org.apache.commons.collections4.CollectionUtils;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@AbilitySpiInstance(bizCode = BatchImportAbilitySpi.BATCH_IMPORT_CAMPAIGN_BOOKING_AMOUNT, name = "CampaignBookingAmountBatchImportAbilitySpiImpl", desc = "计划预订量批量导入")
public class CampaignBookingAmountBatchImportAbilitySpiImpl extends DefaultBatchImportAbilitySpiImpl {
    @Resource
    private ReportSyncTaskRepository reportSyncTaskRepository;
    @Resource
    private BizCampaignInventoryWorkflow bizCampaignInventoryWorkflow;
    @Resource
    private CampaignBookingAmountBatchImportTaskIdentifier campaignBookingAmountBatchImportTaskIdentifier;

//    private static final ThreadPoolExecutor THREAD_POOL = new ThreadPoolExecutor(
//            20, 20, 60L, TimeUnit.SECONDS, new ArrayBlockingQueue<>(5120),
//            new ThreadFactoryBuilder().setNameFormat("campaign_booking_amount_batch_import-%d").build());

    @Override
    public Void validateImportParam(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO) {
        CampaignBookingAmountBatchImportParamViewDTO campaignBookingAmountBatchImportParamViewDTO = (CampaignBookingAmountBatchImportParamViewDTO)batchImportParamViewDTO;
        AssertUtil.notNull(campaignBookingAmountBatchImportParamViewDTO, "计划批量新建参数不能为空");
        AssertUtil.notNull(campaignBookingAmountBatchImportParamViewDTO.getTaskId(), "计划批量新建参数-任务ID不能为空");
        AssertUtil.notNull(campaignBookingAmountBatchImportParamViewDTO.getCampaignGroupId(), "计划批量新建参数-订单ID不能为空");
        AssertUtil.notEmpty(campaignBookingAmountBatchImportParamViewDTO.getCampaignBookingAmountBatchImportRawViewDTOList(), "计划批量新建参数-待解析参数为空");
        AssertUtil.notNull(campaignBookingAmountBatchImportParamViewDTO.getTaskViewDTO(), "查询批量导入计划预订量任务失败");
        return null;
    }

    @Override
    public BatchImportDistLockParamViewDTO buildImportDisLockParam(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO) {
        CampaignBookingAmountBatchImportParamViewDTO campaignBookingAmountBatchImportParamViewDTO = (CampaignBookingAmountBatchImportParamViewDTO)batchImportParamViewDTO;
        Long campaignGroupId = campaignBookingAmountBatchImportParamViewDTO.getCampaignGroupId();
        Long taskId = campaignBookingAmountBatchImportParamViewDTO.getTaskId();

        DistLockEnum distLockEnum = DistLockEnum.CAMPAIGN_BOOKING_AMOUNT_BATCH_IMPORT_KEY;
        BatchImportDistLockParamViewDTO distLockParamViewDTO = new BatchImportDistLockParamViewDTO();
        distLockParamViewDTO.setLockKey(distLockEnum.formatLockKey(campaignGroupId));
        distLockParamViewDTO.setLockReqValue(distLockEnum.formatLockValue(taskId));
        distLockParamViewDTO.setExpireTime(distLockEnum.getExpireTime());
        return distLockParamViewDTO;
    }

    @Override
    public String tryDisLockErrorMessage(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO, String distCurValue) {
        CampaignBookingAmountBatchImportParamViewDTO campaignBookingAmountBatchImportParamViewDTO = (CampaignBookingAmountBatchImportParamViewDTO)batchImportParamViewDTO;
        Long campaignGroupId = campaignBookingAmountBatchImportParamViewDTO.getCampaignGroupId();
        String errorMessage = String.format("当前订单 %s 下已有正在执行中的批量导入计划预订量任务 [%s] trace: %s", campaignGroupId, distCurValue, EagleEye.getTraceId());
        RogerLogger.error(errorMessage);
        ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO();
        errorMessageDTO.setErrorMessage(errorMessage);
        return JSONObject.toJSONString(Lists.newArrayList(errorMessageDTO));
    }

    @Override
    public Void invokeImport(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO) {
        RogerLogger.info("批量导入计划预订量开始执行，taskViewDTO={}",JSON.toJSONString(batchImportParamViewDTO.getTaskViewDTO()));
        CampaignBookingAmountBatchImportParamViewDTO campaignBookingAmountBatchImportParamViewDTO = (CampaignBookingAmountBatchImportParamViewDTO)batchImportParamViewDTO;
        List<CampaignBookingAmountBatchImportRawViewDTO> campaignBookingAmountBatchImportRawViewDTOList = campaignBookingAmountBatchImportParamViewDTO.getCampaignBookingAmountBatchImportRawViewDTOList();
        TaskStream.consume(campaignBookingAmountBatchImportTaskIdentifier, campaignBookingAmountBatchImportRawViewDTOList, (campaignBookingAmountBatchImportRawViewDTO, i) ->{
            if (Boolean.TRUE.equals(campaignBookingAmountBatchImportRawViewDTO.getIsFiltered())) {
                // 本条计划被预检查过滤
                return;
            }
            CampaignScheduleViewDTO campaignScheduleViewDTO = campaignBookingAmountBatchImportRawViewDTO.getCampaignScheduleViewDTO();
            try {
                // 导入计划预订量
                bizCampaignInventoryWorkflow.updateCampaignSchedule(context, campaignScheduleViewDTO);
            } catch (Exception e) {
                // 执行批量导入计划预订量异常，写入执行信息
                RogerLogger.error("批量导入计划预订量失败 {}", JSON.toJSONString(campaignScheduleViewDTO), e);
                buildErrorMessage(i, e, campaignBookingAmountBatchImportRawViewDTO, campaignScheduleViewDTO);
            }
        })
        .commit()
        .handle();
        return null;
    }

    /**
     * 构建错误信息
     *
     * @param index
     * @param e
     * @param campaignBookingAmountBatchImportRawViewDTO
     * @param campaignScheduleViewDTO
     */
    private void buildErrorMessage(int index, Exception e, CampaignBookingAmountBatchImportRawViewDTO campaignBookingAmountBatchImportRawViewDTO, CampaignScheduleViewDTO campaignScheduleViewDTO) {
        if (e instanceof TppException) {
            if (e.getCause() != null && e.getCause() instanceof BrandOneBPException) {
                e = (BrandOneBPException) e.getCause();
            }
        }
        ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO();
        errorMessageDTO.setSerialId(index + 1);
        errorMessageDTO.setErrorMessage(e.toString());
        errorMessageDTO.setId(campaignScheduleViewDTO.getId());
        errorMessageDTO.setName(campaignScheduleViewDTO.getTitle());
        campaignBookingAmountBatchImportRawViewDTO.setIsFiltered(true);
        campaignBookingAmountBatchImportRawViewDTO.setErrorMessage(errorMessageDTO);
    }

    @Override
    public Void updateImportResult(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO) {
        CampaignBookingAmountBatchImportParamViewDTO campaignBookingAmountBatchImportParamViewDTO = (CampaignBookingAmountBatchImportParamViewDTO)batchImportParamViewDTO;
        ReportTaskViewDTO taskViewDTO = campaignBookingAmountBatchImportParamViewDTO.getTaskViewDTO();
        List<ErrorMessageDTO> errorMessageList = campaignBookingAmountBatchImportParamViewDTO.getCampaignBookingAmountBatchImportRawViewDTOList().stream()
                .filter(campaignBookingAmountBatchImportRawViewDTO -> Boolean.TRUE.equals(campaignBookingAmountBatchImportRawViewDTO.getIsFiltered()))
                .map(CampaignBookingAmountBatchImportRawViewDTO::getErrorMessage)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(errorMessageList) && errorMessageList.size() == campaignBookingAmountBatchImportParamViewDTO.getCampaignBookingAmountBatchImportRawViewDTOList().size()) {
            // 全部异常，任务置为失败，聚合失败原因
            taskViewDTO.setErrorMsg(JSONObject.toJSONString(errorMessageList));
            reportSyncTaskRepository.runFail(context, taskViewDTO);
        } else if (CollectionUtils.isEmpty(errorMessageList)) {
            // 没有异常记录，任务设置为成功
            taskViewDTO.setStatus(ReportTaskStatusEnum.SUCCEED.getValue());
            reportSyncTaskRepository.modifyStatus(context, taskViewDTO);
        } else if (CollectionUtils.isNotEmpty(errorMessageList) && errorMessageList.size() < campaignBookingAmountBatchImportParamViewDTO.getCampaignBookingAmountBatchImportRawViewDTOList().size()) {
            // 过滤出的失败的计划条数小于总条数时设置状态为部分成功
            taskViewDTO.setErrorMsg(JSONObject.toJSONString(errorMessageList));
            taskViewDTO.setStatus(ReportTaskStatusEnum.PARTIAL_SUCCESS.getValue());
            reportSyncTaskRepository.modifyStatus(context, taskViewDTO);
        }
        return null;
    }

    @Override
    public String invokeImportExceptionMessage(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO, String exceptionMeg) {
        return "批量导入计划预订量失败: " + exceptionMeg + " trace: " + EagleEye.getTraceId();
    }
}
