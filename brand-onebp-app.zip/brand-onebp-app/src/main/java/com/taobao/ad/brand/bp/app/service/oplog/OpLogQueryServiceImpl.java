package com.taobao.ad.brand.bp.app.service.oplog;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.taobao.ad.brand.bp.app.workflow.oplog.OpLogQueryWorkflow;
import com.taobao.ad.brand.bp.client.api.oplog.OpLogQueryService;
import com.taobao.ad.brand.bp.client.dto.oplog.OpLogQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.oplog.OpLogViewDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * @author jixiu.lj
 * @date 2024/3/20 14:59
 */
@HSFProvider(serviceInterface = OpLogQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class OpLogQueryServiceImpl implements OpLogQueryService {

    private final OpLogQueryWorkflow opLogQueryWorkflow;

    @Override
    public MultiResponse<OpLogViewDTO> queryOpList(ServiceContext context, OpLogQueryViewDTO query) {
        List<OpLogViewDTO> opLogViewDTOList = opLogQueryWorkflow.queryOpLog(context, query);
        return MultiResponse.of(opLogViewDTOList);
    }
}
