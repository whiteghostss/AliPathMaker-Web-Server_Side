package com.taobao.ad.brand.bp.app.service.strategy;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.Response;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.api.strategy.BizStrategyCommandService;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohStrategyPointQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohStrategyPointViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohStrategyViewDTO;
import com.taobao.ad.brand.bp.client.enums.dooh.DoohStrategyPointSourceEnum;
import com.taobao.ad.brand.bp.client.enums.dooh.DoohStrategyPointTypeEnum;
import com.taobao.ad.brand.bp.client.enums.dooh.DoohStrategyStatusEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.dooh.repository.DoohRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@HSFProvider(serviceInterface = BizStrategyCommandService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizStrategyCommandServiceImpl implements BizStrategyCommandService {

    private final DoohRepository doohRepository;

    @Override
    public Response recalDoohStrategy(ServiceContext context, Long strategyId) {
        doohRepository.savePoint(strategyId, null, null);
        return Response.success();
    }

    @Override
    public Response saveDoohStrategyPoint(ServiceContext context, Long strategyId, Integer type, List<String> pointIdList) {
        AssertUtil.assertTrue(type != null, "点位类型不能为空");
        AssertUtil.assertTrue(strategyId != null, "策略ID不能为空");

        DoohStrategyViewDTO doohStrategyViewDTO = doohRepository.getStrategyById(strategyId);
        AssertUtil.assertTrue(doohStrategyViewDTO != null && doohStrategyViewDTO.getStatus()!= null && DoohStrategyStatusEnum.CALCULATION_COMPLETED.getCode().equals(doohStrategyViewDTO.getStatus()), "策略未计算完成，请计算完成后再操作");

        List<String> addPointIdList = Lists.newArrayList();
        List<String> removePointIdList = Lists.newArrayList();
        if(DoohStrategyPointTypeEnum.ADD.getCode().equals(type)){
            addPointIdList = pointIdList;
            removePointIdList = getUserDefinedPointList(strategyId, DoohStrategyPointTypeEnum.REMOVE.getCode());
        }else{
            addPointIdList = getUserDefinedPointList(strategyId, DoohStrategyPointTypeEnum.ADD.getCode());
            removePointIdList = pointIdList;
        }

        doohRepository.savePoint(strategyId, addPointIdList, removePointIdList);
        return Response.success();
    }

    private List<String> getUserDefinedPointList(Long strategyId, Integer type){
        List<String> pointIdList = Lists.newArrayList();
        DoohStrategyPointQueryViewDTO queryViewDTO = new DoohStrategyPointQueryViewDTO();
        queryViewDTO.setStrategyId(strategyId);
        queryViewDTO.setSource(DoohStrategyPointSourceEnum.USER_DEFINED.getCode());
        queryViewDTO.setPageSize(10000);
        queryViewDTO.setType(type);
        MultiResponse<DoohStrategyPointViewDTO> response = doohRepository.pointList(queryViewDTO);
        if(response.isSuccess() && CollectionUtils.isNotEmpty(response.getResult())){
            pointIdList = response.getResult().stream().map(DoohStrategyPointViewDTO::getId).collect(Collectors.toList());
        }
        return pointIdList;
    }


}
