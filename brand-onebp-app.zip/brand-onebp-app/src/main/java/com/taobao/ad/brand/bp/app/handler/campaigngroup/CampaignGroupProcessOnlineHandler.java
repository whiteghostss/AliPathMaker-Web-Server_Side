package com.taobao.ad.brand.bp.app.handler.campaigngroup;

import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.alibaba.hermes.framework.ddd.event.annotation.DomainEventHandler;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignCommandWorkflow;
import com.taobao.ad.brand.bp.app.workflow.campaigngroup.BizCampaignGroupCommandWorkflow;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupEventEnum;
import com.taobao.ad.brand.bp.domain.event.campaigngroup.CampaignGroupStatusTransitEvent;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @description: CampaignProcessHandler
 * @date: 2023/3/10 18:29
 * @author: yuanxinxi
 * @version: 1.0
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@DomainEventHandler(topic = "campaign_group_status_change", event = CampaignGroupStatusTransitEvent.class)
public class CampaignGroupProcessOnlineHandler implements CampaignGroupProcessHandler {

    private final BizCampaignCommandWorkflow bizCampaignCommandWorkflow;

    private final BizCampaignGroupCommandWorkflow bizCampaignGroupCommandWorkflow;
    /**
     * 订单的上线状态
     */
    private static final List<Integer> onlinedCampaignGroupStatusList = Lists.newArrayList(
            BrandCampaignGroupStatusEnum.WAIT_CAST.getCode(),
            BrandCampaignGroupStatusEnum.CAST_ING.getCode(),
            BrandCampaignGroupStatusEnum.CAST_FINISH.getCode()
    );

    @Override
    public boolean onCondition(CampaignGroupStatusTransitEvent event) {
        // CONTRACT_PAY，RESOURCE_CONFIRM可以驱动来自售卖中心的分组上线，ONLINE驱动补量和赠送分组上线
        CampaignGroupViewDTO campaignGroupViewDTO = event.getContext().getCampaignGroupViewDTO();
        CampaignGroupEventEnum campaignGroupEventEnum = event.getContext().getEventEnum();
        if (CampaignGroupEventEnum.ONLINE.equals(campaignGroupEventEnum)
                || (
                onlinedCampaignGroupStatusList.contains(campaignGroupViewDTO.getStatus())
                        && (CampaignGroupEventEnum.CONTRACT_PAY.equals(campaignGroupEventEnum) || CampaignGroupEventEnum.RESOURCE_CONFIRM.equals(campaignGroupEventEnum))
        )) {
            return true;
        }
        return false;
    }

    @Override
    public Response handle(CampaignGroupStatusTransitEvent campaignGroupStatusTransitEvent) {
        if (!onCondition(campaignGroupStatusTransitEvent)) {
            return Response.success();
        }
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupStatusTransitEvent.getContext().getCampaignGroupViewDTO();
        bizCampaignCommandWorkflow.onlineCampaigns(campaignGroupStatusTransitEvent.getContext().getServiceContext(),campaignGroupViewDTO, campaignGroupStatusTransitEvent.getContext().getSaleGroupIds());
        return Response.success();
    }

}
