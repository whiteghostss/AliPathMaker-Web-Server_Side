package com.taobao.ad.brand.bp.app.service.demand;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.Response;
import com.taobao.ad.brand.bp.client.api.demand.BizDemandNoticeCommandService;
import com.taobao.ad.brand.bp.client.context.DomainMetaqMessageBodyContext;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

@Deprecated
@HSFProvider(serviceInterface = BizDemandNoticeCommandService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizDemandNoticeCommandServiceImpl implements BizDemandNoticeCommandService {

    @Override
    public Response noticeContentCampaignGroup(ServiceContext serviceContext, DomainMetaqMessageBodyContext bodyContext) {
        return Response.failure(BrandOneBPBaseErrorCode.BIZ_UN_SUPPORT_ERROR.getErrCode(),"功能已下线");

    }

    @Override
    public Response updateStatus(ServiceContext serviceContext, Long id, Integer eventValue) {
        return Response.failure(BrandOneBPBaseErrorCode.BIZ_UN_SUPPORT_ERROR.getErrCode(),"功能已下线");

    }

    @Override
    public Response confirmMaterialUpdate(ServiceContext context, Long id) {
        return Response.failure(BrandOneBPBaseErrorCode.BIZ_UN_SUPPORT_ERROR.getErrCode(),"功能已下线");
    }
}
