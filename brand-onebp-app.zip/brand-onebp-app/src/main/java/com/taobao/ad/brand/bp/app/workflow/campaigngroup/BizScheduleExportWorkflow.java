package com.taobao.ad.brand.bp.app.workflow.campaigngroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.context.ScheduleExportContext;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.export.ComposeResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.export.FilterResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.export.ScheduleExportQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportMetricsConfigViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.query.ReportQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.export.CampaignExportEnum;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.export.CampaignGroupExportEnum;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.export.MaterialRuleExportEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.ability.BizScheduleExportComposeAbility;
import com.taobao.ad.brand.bp.domain.campaigngroup.ability.BizScheduleExportFilterAbility;
import com.taobao.ad.brand.bp.domain.campaigngroup.ability.BizScheduleExportGenerateAbility;
import com.taobao.ad.brand.bp.domain.campaigngroup.ability.BizScheduleExportRenderAbility;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.report.repository.ReportAdcRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_REQUIRED;

/**
 * @author jixiu.lj
 * @date 2023/3/29 09:45
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizScheduleExportWorkflow {

    private final BizScheduleExportRenderAbility bizScheduleExportRenderAbility;
    private final BizScheduleExportFilterAbility bizScheduleExportFilterAbility;
    private final BizScheduleExportComposeAbility bizScheduleExportComposeAbility;
    private final BizScheduleExportGenerateAbility bizScheduleExportGenerateAbility;
    private final CampaignGroupRepository campaignGroupRepository;
    private final ReportAdcRepository reportAdcRepository;

    public String exportSchedule(ServiceContext context, ScheduleExportContext scheduleExportContext) {
        context = rebuildServiceContext(context, scheduleExportContext);
        queryAdcConfig(context, scheduleExportContext);
        ComposeResultViewDTO composeResultViewDTO = compose(context, scheduleExportContext);
        FilterResultViewDTO filterResultViewDTO = filter(context, scheduleExportContext, composeResultViewDTO);
        Workbook wb = render(context, scheduleExportContext, filterResultViewDTO);
        return generate(context, scheduleExportContext, composeResultViewDTO, wb);
    }


    public void validateQuery(ScheduleExportQueryViewDTO scheduleExportQueryViewDTO) {
        AssertUtil.assertTrue(scheduleExportQueryViewDTO != null, PARAM_REQUIRED, "请求参数不能为空");
        AssertUtil.assertTrue(scheduleExportQueryViewDTO.getCampaignGroupId() != null, PARAM_REQUIRED, "订单ID不能为空");
        // SELLER | ALI_EMPLOYEE
        AssertUtil.assertTrue(scheduleExportQueryViewDTO.getIdentityTypeCode() != null, PARAM_REQUIRED, "用户身份码不能为空");
    }

    /**
     * 初始化排期导出参数
     *
     * @param scheduleExportQueryViewDTO
     * @return
     */

    public ScheduleExportContext initContext(ScheduleExportQueryViewDTO scheduleExportQueryViewDTO) {

        // 构建渲染参数
        ScheduleExportContext scheduleExportContext = new ScheduleExportContext();
        scheduleExportContext.setCampaignGroupId(scheduleExportQueryViewDTO.getCampaignGroupId());
        scheduleExportContext.setPrefix(UUID.randomUUID().toString());
        scheduleExportContext.setExtension(".xlsx");
        scheduleExportContext.setIdentityTypeCode(scheduleExportQueryViewDTO.getIdentityTypeCode());
        scheduleExportContext.setCampaignIdList(scheduleExportQueryViewDTO.getCampaignIdList());
        scheduleExportContext.setSubContractId(scheduleExportQueryViewDTO.getSubContractId());
        scheduleExportContext.setNeedPermanentExportUrl(scheduleExportQueryViewDTO.isNeedPermanentExportUrl());
        return scheduleExportContext;
    }

    /**
     * 全量数据组装
     * 数据组装部分商家小二的差异并不大，最大的差异在于不同的业务线的查询逻辑不一样，因此这里按照bizCode做扩展，如果需要的话可以按照identityCode做subBizCode扩展
     * @param serviceContext
     * @param scheduleExportContext
     * @return
     */
    public ComposeResultViewDTO compose(ServiceContext serviceContext, ScheduleExportContext scheduleExportContext) {
        return bizScheduleExportComposeAbility.compose(serviceContext, scheduleExportContext, serviceContext.getBizCode());
    }

    /**
     * 根据业务身份进行数据过滤
     *
     * @param serviceContext
     * @param scheduleExportContext
     * @param composeResultViewDTO
     */

    public FilterResultViewDTO filter(ServiceContext serviceContext, ScheduleExportContext scheduleExportContext, ComposeResultViewDTO composeResultViewDTO) {
        return bizScheduleExportFilterAbility.filter(serviceContext, scheduleExportContext, composeResultViewDTO, scheduleExportContext.getIdentityTypeCode());
    }

    /**
     * 渲染
     *
     * @param serviceContext
     * @param scheduleExportContext
     * @return
     */

    public Workbook render(ServiceContext serviceContext, ScheduleExportContext scheduleExportContext,
                       FilterResultViewDTO filterResultViewDTO) {
        // 与导出的计划数有关，目前限制最多导出6000条，超出可能出现内存数据与硬盘缓存数据合并冲突（涉及单元格合并）
        int rowMaxCache = 6000;
        XSSFWorkbook xssfWb = new XSSFWorkbook();
        SXSSFWorkbook wb = new SXSSFWorkbook(xssfWb, rowMaxCache);
        wb.setCompressTempFiles(true);

        bizScheduleExportRenderAbility.render(serviceContext, scheduleExportContext, scheduleExportContext.getIdentityTypeCode(), wb, filterResultViewDTO);

        return wb;
    }


    /**
     * 上传OSS
     *
     * @param scheduleExportContext
     * @param composeResultViewDTO
     * @return
     */

    public String generate(ServiceContext serviceContext, ScheduleExportContext scheduleExportContext,
                           ComposeResultViewDTO composeResultViewDTO, Workbook wb) {

        String ossUrl = "";
        // 文件存储前缀，匹配该前缀的文件在3天后自动删除
        // 构造文件流
        try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            wb.write(outputStream);
            byte[] data = outputStream.toByteArray();
            ossUrl = bizScheduleExportGenerateAbility.generate(serviceContext, scheduleExportContext, data);
        } catch (Exception e) {
            RogerLogger.error("订单排期导出失败 订单ID：{} | {}", scheduleExportContext.getCampaignGroupId(), e);
        } finally {
            // 关闭工作簿
            try {
                wb.close();
            } catch (IOException e) {
                RogerLogger.error("workbook关闭失败 订单ID {} | {}", scheduleExportContext.getCampaignGroupId(), e);
            }
        }
        return ossUrl;
    }

    /**
     * 查询ADC配置指标
     * @param context
     * @param scheduleExportContext
     */
    private void queryAdcConfig(ServiceContext context, ScheduleExportContext scheduleExportContext) {
        ReportQueryViewDTO queryViewDTO = new ReportQueryViewDTO();
        queryViewDTO.setFunctionCode("scheduleExport");
        Map<String, Object> filterMap = Maps.newHashMap();
        // 支持按照业务场景 + 用户身份（商家、小二）进行adc过滤
        filterMap.put("bizCode", context.getBizCode());
        filterMap.put("identityTypeCode", scheduleExportContext.getIdentityTypeCode());
        queryViewDTO.setFilterMap(filterMap);
        // 不使用role做adc过滤，这里只是填充默认角色
        if(CollectionUtils.isEmpty(context.getRoleNameList())) {
            context.setRoleNameList(Lists.newArrayList("basic_role"));
        }
        // adc三级结构：functionCode -> DimensionCode -> MetricsCode
        Map<String, List<ReportMetricsConfigViewDTO>> metricsMap = reportAdcRepository.findMetricsConfigMap(context, queryViewDTO);
        // dimensionCOde -> List<Metrics>
        Map<MaterialRuleExportEnum, ReportMetricsConfigViewDTO> mrMetricsCodeMap = Optional.ofNullable(metricsMap.get("scheduleExportMr")).map(metricsConfigViewDTOS -> metricsConfigViewDTOS.stream().collect(Collectors.toMap((metrics -> MaterialRuleExportEnum.valueOf(metrics.getCode())), Function.identity(), (k1, k2) -> k1, LinkedHashMap::new))).orElse(Maps.newLinkedHashMap());
        Map<MaterialRuleExportEnum, ReportMetricsConfigViewDTO> doohMrMetricsCodeMap = Optional.ofNullable(metricsMap.get("doohScheduleExportMr")).map(metricsConfigViewDTOS -> metricsConfigViewDTOS.stream().collect(Collectors.toMap((metrics -> MaterialRuleExportEnum.valueOf(metrics.getCode())), Function.identity(), (k1, k2) -> k1, LinkedHashMap::new))).orElse(Maps.newLinkedHashMap());
        Map<CampaignGroupExportEnum, ReportMetricsConfigViewDTO> campaignGroupMetricsCodeMap = Optional.ofNullable(metricsMap.get("scheduleExportCampaignGroup")).map(metricsConfigViewDTOS -> metricsConfigViewDTOS.stream().collect(Collectors.toMap((metrics -> CampaignGroupExportEnum.valueOf(metrics.getCode())), Function.identity(), (k1, k2) -> k1 ,LinkedHashMap::new))).orElse(Maps.newLinkedHashMap());
        Map<CampaignExportEnum, ReportMetricsConfigViewDTO> campaignMetricsCodeMap = Optional.ofNullable(metricsMap.get("scheduleExportCampaign")).map(metricsConfigViewDTOS -> metricsConfigViewDTOS.stream().collect(Collectors.toMap((metrics -> CampaignExportEnum.valueOf(metrics.getCode())), Function.identity(), (k1, k2) -> k1 ,LinkedHashMap::new))).orElse(Maps.newLinkedHashMap());
        Map<CampaignExportEnum, ReportMetricsConfigViewDTO> backupMetricsCodeMap = Optional.ofNullable(metricsMap.get("scheduleExportBackup")).map(metricsConfigViewDTOS -> metricsConfigViewDTOS.stream().collect(Collectors.toMap((metrics -> CampaignExportEnum.valueOf(metrics.getCode())), Function.identity(), (k1, k2) -> k1 ,LinkedHashMap::new))).orElse(Maps.newLinkedHashMap());


        scheduleExportContext.setMrMetricsMap(mrMetricsCodeMap);
        scheduleExportContext.setDoohMrMetricsCodeMap(doohMrMetricsCodeMap);
        scheduleExportContext.setCampaignGroupMetricsMap(campaignGroupMetricsCodeMap);
        scheduleExportContext.setCampaignMetricsMap(campaignMetricsCodeMap);
        scheduleExportContext.setBackupMetricsCodeMap(backupMetricsCodeMap);
    }

    /**
     * 针对售卖发起的排期导出场景执行上下文rebuild
     * @param serviceContext
     * @param scheduleExportContext
     * @return
     */
    private ServiceContext rebuildServiceContext(ServiceContext serviceContext, ScheduleExportContext scheduleExportContext) {
        if (!BizCodeEnum.BRANDONEBP.getBizCode().equals(serviceContext.getBizCode())) {
            return serviceContext;
        }
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(serviceContext, scheduleExportContext.getCampaignGroupId());
        AssertUtil.notNull(campaignGroupViewDTO, "无效订单ID");
        if(Objects.nonNull(scheduleExportContext.getSubContractId())) {
            AssertUtil.notNull(campaignGroupViewDTO.getCampaignGroupSaleViewDTO());
            AssertUtil.notEmpty(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList(), "分组信息不能为空");
            Integer sceneId = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList()
                    .stream()
                    .filter(saleGroupInfoViewDTO -> scheduleExportContext.getSubContractId().equals(saleGroupInfoViewDTO.getSubContractId()))
                    .map(SaleGroupInfoViewDTO::getSaleBusinessLine)
                    .findAny()
                    .orElseThrow(() -> new BrandOneBPException("子合同ID未匹配"));
            return ServiceContextUtil.getNewServiceContext(serviceContext, sceneId);
        }
        // 按照订单查询
        Integer sceneId = campaignGroupViewDTO.getSceneId();
        return ServiceContextUtil.getNewServiceContext(serviceContext, sceneId);
    }
}
