package com.taobao.ad.brand.bp.app.service.dmp;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.audience.CrowdBaseViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdScenarioViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdViewDTO;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.api.dmp.BizCrowdQueryService;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.CrowdViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.query.CrowdQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaign.RecommendCrowdTypeEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.dmp.CrowdRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignShowmaxCrowdGetAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignShowmaxCrowdTagGetAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignShowmaxCrowdGetAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignShowmaxCrowdTagGetAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @Description:
 * @Author: dongyang
 * @Date: 2023/3/13
 */
@HSFProvider(serviceInterface = BizCrowdQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizCrowdQueryServiceImpl implements BizCrowdQueryService {

    private final CrowdRepository crowdRepository;

    private final CampaignRepository campaignRepository;

    private final ICampaignShowmaxCrowdGetAbility campaignShowmaxCrowdGetAbility;
    private final ICampaignShowmaxCrowdTagGetAbility campaignShowmaxCrowdTagGetAbility;

    @Override
    public MultiResponse<CrowdViewDTO> findCrowdPage(ServiceContext context, CrowdQueryViewDTO query) {
        PageResultViewDTO<CrowdViewDTO> crowdPageList = crowdRepository.findCrowdPageList(context, query);
        return MultiResponse.of(crowdPageList.getList(), crowdPageList.getCount());
    }

    @Override
    public MultiResponse<CrowdViewDTO> findCrowdByIds(ServiceContext context, List<Long> ids) {
        List<CrowdViewDTO> crowdViewDTOList = crowdRepository.queryCrowdByIds(context, ids);
        return MultiResponse.of(crowdViewDTOList);
    }
    /**
     * 根据人群IDs查询覆盖人数
     * @param context
     * @param crowdIds
     * @return
     */
    @Override
    public SingleResponse<Long> getCrowdCoverage(ServiceContext context, List<Long> crowdIds) {
        Long count = crowdRepository.getCrowdCoverage(context, crowdIds);
        return SingleResponse.of(count);
    }

    @Override
    public SingleResponse<Long> increaseCalculate(ServiceContext serviceContext, Long campaignId, List<Long> crowdIdList) {
        Map<Long, CampaignViewDTO> campaignTargetMap = campaignRepository.getCampaignTarget(serviceContext, Lists.newArrayList(campaignId));
        List<CampaignCrowdViewDTO> crowdTargetViewDTOList = Optional.ofNullable(campaignTargetMap)
                .map(map -> map.get(campaignId)).map(CampaignViewDTO::getCampaignCrowdScenarioViewDTO).map(CampaignCrowdScenarioViewDTO::getCampaignCrowdViewDTOList)
                .orElse(Lists.newArrayList());
        AssertUtil.notEmpty(crowdTargetViewDTOList, BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR,"计划无锁量白盒人群，不能添加自定义人群");

        List<Long> oldCrowdIdList = crowdTargetViewDTOList.stream()
                .filter(campaignCrowdViewDTO->Objects.isNull(campaignCrowdViewDTO.getScene()))
                .map(CrowdBaseViewDTO::getCrowdId).collect(Collectors.toList());
        return SingleResponse.of(crowdRepository.increaseCalculate(serviceContext, crowdIdList, oldCrowdIdList));
    }

    @Override
    public SingleResponse<CrowdViewDTO> getShowmaxCrowd(ServiceContext serviceContext, Long campaignGroupId, Integer showmaxCrowdType, List<Long> showmaxCrowdLabelIdList) {
        if (CollectionUtils.isEmpty(showmaxCrowdLabelIdList)) {
            return SingleResponse.of(null);
        }
        if (RecommendCrowdTypeEnum.CATEGORY.getCode().equals(showmaxCrowdType) || RecommendCrowdTypeEnum.CATEGORY_ADDITION.getCode().equals(showmaxCrowdType)) {
            //dmp落库长度问题
            AssertUtil.assertTrue(showmaxCrowdLabelIdList.size() < 5, BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR, "行业人群标签不能超过4个");
        }
        CrowdViewDTO crowdViewDTO = campaignShowmaxCrowdGetAbility.handle(serviceContext, CampaignShowmaxCrowdGetAbilityParam.builder().abilityTarget(showmaxCrowdType)
                .campaignGroupId(campaignGroupId).showmaxCrowdLabelIdList(showmaxCrowdLabelIdList).build());

        return SingleResponse.of(crowdViewDTO);
    }

    @Override
    public MultiResponse<CrowdViewDTO> findShopWindowSlimCategoryCrowdList(ServiceContext serviceContext) {
        List<CrowdViewDTO> shopWindowSlimCategoryCrowd = crowdRepository.findRecommendCrowd(serviceContext, serviceContext.getMemberId(), RecommendCrowdTypeEnum.CATEGORY_SELF_SERVICE_SLIM.getCode(), null, null);
        return MultiResponse.of(shopWindowSlimCategoryCrowd);
    }

    @Override
    public MultiResponse<CommonViewDTO> queryShowmaxCrowdTagList(ServiceContext serviceContext, Long campaignGroupId, Integer showmaxCrowdType) {
        List<CommonViewDTO> showmaxCrowdList = campaignShowmaxCrowdTagGetAbility.handle(serviceContext, CampaignShowmaxCrowdTagGetAbilityParam.builder()
                .abilityTarget(showmaxCrowdType).campaignGroupId(campaignGroupId).build());
        return MultiResponse.of(showmaxCrowdList);
    }

    @Override
    public MultiResponse<CrowdViewDTO> findCreativePreviewCrowdPageList(ServiceContext context, CrowdQueryViewDTO query) {
        PageResultViewDTO<CrowdViewDTO> crowdPageList = crowdRepository.findCreativePreviewCrowdPageList(context, query);
        return MultiResponse.of(crowdPageList.getList(), crowdPageList.getCount());
    }
}
