package com.taobao.ad.brand.bp.app.workflow.campaign;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityInject;
import com.alibaba.abf.isolation.spec.common.ReduceType;
import com.alibaba.abf.isolation.utils.AbilityInvoker;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignShowmaxCrowdViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryLockViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignMandatoryLockViewDTO;
import com.alibaba.ad.brand.dto.campaign.monitor.CampaignMonitorViewDTO;
import com.alibaba.ad.brand.dto.campaign.realtime.CampaignRealTimeOptimizeViewDTO;
import com.alibaba.ad.brand.dto.campaign.safeip.CampaignSafeIpViewDTO;
import com.alibaba.ad.brand.dto.campaign.sale.CampaignSaleViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.ResourcePackageProductViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.alibaba.ad.brand.dto.frequency.FrequencyViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.*;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSourceEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleGroupSourceEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.alibaba.ad.brand.sdk.constant.frequency.field.BrandFrequencyBizTypeEnum;
import com.alibaba.ad.nb.ssp.constant.common.MediaScopeEnum;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.app.businessability.MultiTargetDeliverBusinessAbility;
import com.taobao.ad.brand.bp.app.businessability.RealTimeOptimizeBusinessAbility;
import com.taobao.ad.brand.bp.app.businessability.TargetBusinessAbility;
import com.taobao.ad.brand.bp.client.context.DomainMetaqMessageBodyContext;
import com.taobao.ad.brand.bp.client.dto.campaign.*;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.calculate.CampaignGroupSaleGroupCalViewDTO;
import com.taobao.ad.brand.bp.client.dto.cartitem.query.CartItemQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohCampaignViewDTO;
import com.taobao.ad.brand.bp.client.dto.effect.EffectAdvertiserViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.rule.RuleCheckResultViewDTO;
import com.taobao.ad.brand.bp.client.enums.SwitchEnum;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignEventEnum;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignPVAssignSceneEnum;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignScheduleOperateTypeEnum;
import com.taobao.ad.brand.bp.client.enums.message.DomainMessageTypeEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.converter.campaign.CampaignMessageViewConverter;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.common.spi.ExtensionPointsFactory;
import com.taobao.ad.brand.bp.common.threadpooltask.CampaignAssignBudgetTaskIdentifier;
import com.taobao.ad.brand.bp.common.threadpooltask.CampaignBatchAddTaskIdentifier;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.common.util.differ.Differs;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.campaign.spi.BizCampaignSplitSpi;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.cart.repository.CartItemRepository;
import com.taobao.ad.brand.bp.domain.dooh.repository.DoohRepository;
import com.taobao.ad.brand.bp.domain.effect.EffectAdvertiserRepository;
import com.taobao.ad.brand.bp.domain.frequency.ability.BizFrequencyAbility;
import com.taobao.ad.brand.bp.domain.inventory.InventoryRepository;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupBatchDeleteAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupBatchDeleteAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbilityRouteContext;
import com.taobao.ad.brand.bp.domain.sdk.base.workflow.Workflow;
import com.taobao.ad.brand.bp.domain.sdk.campaign.ability.param.BizCampaignSplitAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.calculate.ICampaignHistoryBudgetValidateForCalculateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.calculate.ICampaignPriceInitForAssignBudgetAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.calculate.ICampaignSingleMediaMarkingBoostBudgetValidateForCalculateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.calculate.ICampaignTwoCptBudgetValidateForCalculateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.consistency.ICampaignBudgetConsistencyCheckAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.consistency.ICampaignCastDateConsistencyCheckAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.consistency.ICampaignCrowdConsistencyCheckAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.consistency.ICampaignPriceConsistencyCheckAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.businessability.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.BizCampaignCommandWorkflowExt;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignAdvBindOrUnBindWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignBudgetWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignCalculateWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupStatusValidateForBindAdvAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupStatusValidateForUnBindAdvAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupStatusValidateForBindOrUnBindAdvAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.workflow.param.BizCampaignGroupCalculateWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupGetForDiffCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupOperateDistLockGetAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.ISaleGroupPvBudgetForCalculateUpdateSaleGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupGetForDiffCampaignAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupOperateDistLockAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupPvBudgetForCalculateUpdateSaleGroupAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.IMessageAsyncSendAbility;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.param.MessageAsyncSendAbilityParam;
import com.taobao.ad.brand.bp.domain.ssp.ProductRepository;
import com.umeng.oplus.domain.emuntype.dsp.plan.DspPlanScheduleStateEnum;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.jetbrains.annotations.Nullable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.alibaba.abf.isolation.utils.AbilityInvoker.invokeAll;
import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.OPERATION_FAILED;
import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_ILLEGAL;
import static com.taobao.ad.brand.bp.common.spi.ExtensionPointsFactory.runAbilitySpi;

/**
 * Description:计划业务流程
 * <p>
 * date: 2023/10/24 11:13 PM
 *
 * @author shiyan
 * @version 1.0
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizCampaignCommandWorkflow extends Workflow {

    @AbilityInject(reduce = ReduceType.FIRST)
    private final BizCampaignCommandWorkflowExt bizCampaignCommandWorkflowExt;

    private final ICampaignGroupStatusValidateForBindAdvAbility campaignGroupStatusValidateForBindAdvAbility;
    private final ICampaignGroupStatusValidateForUnBindAdvAbility campaignGroupStatusValidateForUnBindAdvAbility;

    private final BizFrequencyAbility bizFrequencyAbility;
    private final BizCampaignMessageWorkflow bizCampaignMessageWorkflow;
    private final ISaleGroupOperateDistLockGetAbility saleGroupOperateDistLockGetAbility;
    private final ICampaignStructureQueryAbility campaignStructureQueryAbility;
    private final IMessageAsyncSendAbility messageAsyncSendAbility;
    private final ICampaignOnlineStatusUpdateAbility campaignOnlineStatusUpdateAbility;
    private final ICampaignBindCampaignGroupAbility campaignBindCampaignGroupAbility;
    private final ICampaignPriceConsistencyCheckAbility campaignPriceConsistencyCheckAbility;
    private final ICampaignCastDateConsistencyCheckAbility campaignCastDateConsistencyCheckAbility;
    private final ICampaignBudgetConsistencyCheckAbility campaignBudgetConsistencyCheckAbility;
    private final ICampaignCrowdConsistencyCheckAbility campaignCrowdConsistencyCheckAbility;
    private final ICampaignCastDateValidateForUpdateCastDateAbility campaignCastDateValidateForUpdateAbility;
    private final ICampaignUpdateJudgeForUpdateCampaignAbility campaignUpdateJudgeForUpdateCampaignAbility;
    private final ICampaignSplitSubCheckForUpdateCastDateAbility campaignSplitSubCheckForUpdateCastDateAbility;
    private final ICampaignInitForUpdateCastDateAbility campaignInitForUpdateCastDateAbility;
    private final ICampaignInitForOnlineCampaignAbility campaignInitForOnlineCampaignAbility;
    private final ICampaignUnionControlForOnlineCampaignAbility campaignUnionControlForOnlineCampaignAbility;
    private final ICampaignValidateForSwitchCampaignAbility campaignValidateForSwitchCampaignAbility;
    private final ICampaignBatchSwitchAbility campaignBatchSwitchAbility;

    private final ICampaignValidateForBindAdvAbility campaignValidateForBindAdvAbility;
    private final ICampaignValidateForUnBindAdvAbility campaignValidateForUnBindAdvAbility;
    private final ICampaignAdvEffectiveValidateForBindAbility campaignAdvEffectiveValidateForBindAbility;
    private final ICampaignAdvUniqueValidateForBindAbility campaignAdvUniqueValidateForBindAbility;
    private final ICampaignAdvBalanceValidateAbility campaignAdvBalanceValidateAbility;
    private final ICampaignAdvUpdateForBindAbility campaignAdvUpdateForBindAbility;
    private final ICampaignAdvUpdateForUnBindAbility campaignAdvUpdateForUnBindAbility;


    private final ICampaignAutoSaveJudgeForAutoSaveCampaignAbility campaignAutoSaveJudgeForAutoSaveCampaignAbility;
    private final ICampaignAutoBuildForAutoAddCampaignAbility campaignAutoBuildForAutoAddCampaignAbility;
    private final ISaleGroupGetForDiffCampaignAbility saleGroupGetForDiffCampaignAbility;

    private final BizCampaignInventoryWorkflow bizCampaignInventoryWorkflow;

    private final CampaignRepository campaignRepository;
    private final CampaignGroupRepository campaignGroupRepository;
    private final DoohRepository doohRepository;
    private final CartItemRepository cartItemRepository;
    private final CampaignBatchAddTaskIdentifier campaignBatchAddTaskIdentifier;
    private final CampaignMessageViewConverter campaignMessageViewConverter;
    private final InventoryRepository inventoryRepository;
    private final ResourcePackageRepository resourcePackageRepository;
    private final ProductRepository productRepository;
    private final EffectAdvertiserRepository effectAdvertiserRepository;

    private final ICampaignHistoryBudgetValidateForCalculateCampaignAbility campaignHistoryBudgetValidateForCalculateCampaignAbility;
    private final ICampaignCalculateInfoResetAbility campaignCalculateInfoResetAbility;

    private final CampaignAssignBudgetTaskIdentifier campaignAssignBudgetTaskIdentifier;

    private final ICampaignSingleMediaMarkingBoostBudgetValidateForCalculateCampaignAbility campaignSingleMediaMarkingBoostBudgetValidateForCalculateCampaignAbility;

    private final ICampaignTwoCptBudgetValidateForCalculateCampaignAbility campaignTwoCptBudgetValidateForCalculateCampaignAbility;

    private final ICampaignAddAbility campaignAddAbility;
    private final ICampaignDeleteAbility campaignDeleteAbility;
    private final IAdgroupBatchDeleteAbility adgroupBatchDeleteAbility;

    private final ICampaignUpdateAllAbility campaignUpdateAllAbility;
    private final ICampaignUpdatePartAbility campaignUpdatePartAbility;

    private final ISaleGroupPvBudgetForCalculateUpdateSaleGroupAbility calculateUpdateSaleGroupAbility;

    private final ICampaignPriceInitForAssignBudgetAbility campaignPriceInitForAssignBudgetAbility;
    private final ICampaignBudgetValidateForResetCampaignBudgetAbility campaignBudgetValidateForResetCampaignBudgetAbility;
    private final ICampaignDoohValidateAbility campaignDoohValidateAbility;
    private final ICampaignOperateDistLockGetAbility campaignOperateDistLockGetAbility;

    /**
     * 新建计划
     * @param serviceContext
     * @param campaignViewDTO
     * @return
     */
    public CampaignViewDTO addCampaign(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO){
        //1. 构建处理参数
        BizCampaignWorkflowParam workflowParam = bizCampaignCommandWorkflowExt.buildParamForAddOrUpdate(serviceContext, campaignViewDTO);
        // 商业能力显式挂载
        BusinessAbilityRouteContext businessAbilityRouteContext = BusinessAbilityRouteContext.builder()
                .packageSaleGroupViewDTO(workflowParam.getPackageSaleGroupViewDTO())
                .resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO())
                .productViewDTO(workflowParam.getProductViewDTO()).build();
        try {
            //2. 前置处理
            bizCampaignCommandWorkflowExt.beforeForAdd(serviceContext, campaignViewDTO, workflowParam);
            //3. 商业能力挂载
            invokeAll(ICampaignAddBusinessAbilityPoint.class, businessAbilityRouteContext,
                    callBack -> callBack.invokeForCampaignAdd(serviceContext,campaignViewDTO, businessAbilityRouteContext));
            //4. 保存计划
            campaignAddAbility.handle(serviceContext, CampaignBatchAbilityParam.builder()
                    .abilityTargets(Lists.newArrayList(campaignViewDTO)).campaignGroupId(campaignViewDTO.getCampaignGroupId()).build());
            //5. 拆分子计划&保存
            List<CampaignViewDTO> subCampaignViewDTOList = this.splitSubCampaign(serviceContext, campaignViewDTO,null, workflowParam);
            if(CollectionUtils.isNotEmpty(subCampaignViewDTOList)){
                // 子计划商业能力显式挂载
                for (CampaignViewDTO subCampaignViewDTO : subCampaignViewDTOList) {
                    invokeAll(ICampaignAddBusinessAbilityPoint.class, businessAbilityRouteContext,
                            callBack -> callBack.invokeForCampaignAdd(serviceContext,subCampaignViewDTO, businessAbilityRouteContext));
                }
                campaignAddAbility.handle(serviceContext, CampaignBatchAbilityParam.builder()
                        .abilityTargets(subCampaignViewDTOList).campaignGroupId(campaignViewDTO.getCampaignGroupId()).build());
            }
            //6. 后置商业能力挂载
            invokeAll(ICampaignAddBusinessAbilityPoint.class, businessAbilityRouteContext,
                    callBack -> callBack.invokeForAfterCampaignAdd(serviceContext, BizCampaignToolsHelper.flatCampaignList(campaignViewDTO), businessAbilityRouteContext));

            //7. 计划保存后置处理
            bizCampaignCommandWorkflowExt.afterAddCampaign(serviceContext,campaignViewDTO,workflowParam);

            return campaignViewDTO;
        } catch (Exception e) {
            //100. 计划保存，异常处理
            RogerLogger.error(String.format("BizCampaignCommandWorkflow.addCampaign，msg=%s","新建计划失败"),e);
            if(campaignViewDTO.getId() != null){
                List<Long> successAddCampaignIdList = Lists.newArrayList(campaignViewDTO.getId());
                Optional.ofNullable(campaignViewDTO.getSubCampaignViewDTOList()).orElse(Lists.newArrayList())
                        .stream().map(CampaignViewDTO::getId).filter(Objects::nonNull).forEach(successAddCampaignIdList::add);
                bizCampaignCommandWorkflowExt.throwingAddCampaign(serviceContext,successAddCampaignIdList);
            }
            throw e;
        }
    }

    /**
     * 批量保存计划
     * @param serviceContext
     * @param campaignViewDTOList
     * @return
     */
    public List<CampaignViewDTO> batchAddCampaign(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList){
        List<CampaignViewDTO> addCampaignViewDTOList = Lists.newCopyOnWriteArrayList();
        try {
            TaskStream.consume(campaignBatchAddTaskIdentifier, campaignViewDTOList, (campaignViewDTO, index) -> {
                CampaignViewDTO resultCampaignViewDTO = this.addCampaign(serviceContext, campaignViewDTO);
                addCampaignViewDTOList.add(resultCampaignViewDTO);
            }).commit().handle();
        } catch (Exception e) {
            RogerLogger.error(String.format("BizCampaignCommandWorkflow.batchAddCampaign，msg=%s","批量新建计划失败"),e);
            if(CollectionUtils.isNotEmpty(addCampaignViewDTOList)){
                List<Long> addSuccessIds = addCampaignViewDTOList.stream().map(CampaignViewDTO::getId)
                        .filter(Objects::nonNull).collect(Collectors.toList());
                List<Long> addSubCampaignIds = addCampaignViewDTOList.stream().filter(item -> CollectionUtils.isNotEmpty(item.getSubCampaignViewDTOList()))
                        .flatMap(item -> item.getSubCampaignViewDTOList().stream()).map(CampaignViewDTO::getId)
                        .filter(Objects::nonNull).collect(Collectors.toList());
                if(CollectionUtils.isNotEmpty(addSubCampaignIds)){
                    addSuccessIds.addAll(addSubCampaignIds);
                }
                bizCampaignCommandWorkflowExt.throwingAddCampaign(serviceContext,addSuccessIds);
            }
            throw e;
        }
        return addCampaignViewDTOList;
    }

    /**
     * 修改计划
     * @param serviceContext
     * @param campaignViewDTO
     * @return
     */
    public SingleResponse<Long> updateCampaign(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO){
        AssertUtil.notNull(campaignViewDTO.getId(), "计划ID不能为空");
        CampaignViewDTO dbCampaignViewDTO = getCampaignInfoByOption(serviceContext, campaignViewDTO.getId(), CampaignQueryOption.builder().needFrequency(true)
                .needTarget(true).needChildren(true).build());
        AssertUtil.notNull(dbCampaignViewDTO, "计划不存在或已被删除");
        // 计划处于发起锁量中（未完成发起锁量），不允许编辑
        campaignOperateDistLockGetAbility.handle(serviceContext, CampaignOperateDistLockAbilityParam.builder().abilityTargets(Lists.newArrayList(dbCampaignViewDTO.getId())).build());
        campaignViewDTO.setCampaignGroupId(dbCampaignViewDTO.getCampaignGroupId());
        //1. 构建处理参数
        BizCampaignWorkflowParam workflowParam = bizCampaignCommandWorkflowExt.buildParamForAddOrUpdate(serviceContext, campaignViewDTO);
        //2. 前置处理
        bizCampaignCommandWorkflowExt.beforeForUpdate(serviceContext,campaignViewDTO,dbCampaignViewDTO,workflowParam);
        //3. 商业能力显示挂载
        BusinessAbilityRouteContext businessAbilityRouteContext = BusinessAbilityRouteContext.builder()
                .packageSaleGroupViewDTO(workflowParam.getPackageSaleGroupViewDTO())
                .resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO())
                .productViewDTO(workflowParam.getProductViewDTO())
                .build();
        invokeAll(ICampaignUpdateBusinessAbilityPoint.class, businessAbilityRouteContext,
                callBack -> callBack.invokeForCampaignUpdate(serviceContext, campaignViewDTO, dbCampaignViewDTO, businessAbilityRouteContext));
        //4. 修改主计划
        campaignUpdateAllAbility.handle(serviceContext,CampaignBatchAbilityParam.builder()
                .abilityTargets(Lists.newArrayList(campaignViewDTO)).campaignGroupId(campaignViewDTO.getCampaignGroupId()).build());
        //5. 子计划拆分&保存
        List<CampaignViewDTO> subCampaignViewDTOList = this.splitSubCampaign(serviceContext,campaignViewDTO,dbCampaignViewDTO,workflowParam);
        if(CollectionUtils.isNotEmpty(subCampaignViewDTOList)){
            List<CampaignViewDTO> updateSubCampaignList = subCampaignViewDTOList.stream().filter(item->Objects.nonNull(item.getId())).collect(Collectors.toList());
            if(CollectionUtils.isNotEmpty(updateSubCampaignList)){
                for (CampaignViewDTO subCampaignViewDTO : updateSubCampaignList) {
                    invokeAll(ICampaignUpdateBusinessAbilityPoint.class, businessAbilityRouteContext,
                            callBack -> callBack.invokeForCampaignUpdate(serviceContext, subCampaignViewDTO, dbCampaignViewDTO, businessAbilityRouteContext));
                }
                campaignUpdateAllAbility.handle(serviceContext,CampaignBatchAbilityParam.builder()
                        .abilityTargets(updateSubCampaignList).campaignGroupId(campaignViewDTO.getCampaignGroupId()).build());
            }
            List<CampaignViewDTO> addSubCampaignList = subCampaignViewDTOList.stream().filter(item->Objects.isNull(item.getId())).collect(
                    Collectors.toList());
            if(CollectionUtils.isNotEmpty(addSubCampaignList)){
                for (CampaignViewDTO subCampaignViewDTO : addSubCampaignList) {
                    invokeAll(ICampaignAddBusinessAbilityPoint.class, businessAbilityRouteContext,
                            callBack -> callBack.invokeForCampaignAdd(serviceContext,subCampaignViewDTO, businessAbilityRouteContext));
                }
                campaignAddAbility.handle(serviceContext, CampaignBatchAbilityParam.builder()
                        .abilityTargets(addSubCampaignList).campaignGroupId(campaignViewDTO.getCampaignGroupId()).build());
            }
        }
        //6. 后置商业能力挂载
        invokeAll(ICampaignUpdateBusinessAbilityPoint.class, businessAbilityRouteContext,
                callBack -> callBack.invokeForAfterCampaignUpdate(serviceContext, BizCampaignToolsHelper.flatCampaignList(campaignViewDTO), businessAbilityRouteContext));

        //7. 后置业务处理
        bizCampaignCommandWorkflowExt.afterUpdateCampaign(serviceContext, campaignViewDTO,dbCampaignViewDTO, workflowParam);

        return SingleResponse.of(campaignViewDTO.getId());
    }

    /**
     * 子计划拆分
     * @param serviceContext
     * @param campaignViewDTO
     * @param dbCampaignViewDTO
     * @param workflowParam
     */
    public List<CampaignViewDTO> splitSubCampaign(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO,CampaignViewDTO dbCampaignViewDTO,BizCampaignWorkflowParam workflowParam) {
        //1. 拆分子计划
        BizCampaignSplitAbilityParam splitAbilityParam = BizCampaignSplitAbilityParam.builder().campaignGroupViewDTO(workflowParam.getCampaignGroupViewDTO())
                .resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).productViewDTO(workflowParam.getProductViewDTO())
                .effectAdvertiserViewDTOList(workflowParam.getEffectAdvertiserViewDTOList()).showmaxCrowdList(workflowParam.getShowmaxCrowdList())
                .spuViewDTO(workflowParam.getSpuViewDTO()).skuViewDTO(workflowParam.getSkuViewDTO()).bundleViewDTO(workflowParam.getBundleViewDTO())
                .build();
        List<CampaignViewDTO> subCampaignViewDTOList = runAbilitySpi(BizCampaignSplitSpi.class,
                extension->extension.splitSubCampaign(serviceContext, campaignViewDTO, splitAbilityParam),
                    BizCampaignSplitSpi.getSplitSpiCode(campaignViewDTO, workflowParam.getPackageProductViewDTO()));
        //2. 历史子计划对比处理
        if(CollectionUtils.isNotEmpty(subCampaignViewDTOList)){
            subCampaignViewDTOList = this.diffSplitAndDbSubCampaignList(serviceContext, dbCampaignViewDTO, subCampaignViewDTOList, workflowParam);
        }
        //3. 重置计划金额和预定量等计算信息
        campaignCalculateInfoResetAbility.handle(serviceContext, CampaignCalculateInfoResetAbilityParam.builder().abilityTargets(subCampaignViewDTOList).build());

        campaignViewDTO.setSubCampaignViewDTOList(subCampaignViewDTOList);

        //4. 商业能力显示挂载
        BusinessAbilityRouteContext businessAbilityRouteContext = BusinessAbilityRouteContext.builder()
                .packageSaleGroupViewDTO(workflowParam.getPackageSaleGroupViewDTO())
                .resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO())
                .productViewDTO(workflowParam.getProductViewDTO())
                .build();
        invokeAll(ICampaignSplitSubCampaignBusinessAbilityPoint.class, businessAbilityRouteContext,
                callBack -> callBack.invokeForSubCampaignSplit(serviceContext, campaignViewDTO, businessAbilityRouteContext));
        return subCampaignViewDTOList;
    }
    /**
     * 比较拆分后的计划与数据库的计划
     * @param serviceContext
     * @param dbCampaignViewDTO
     * @param subCampaignViewDTOList
     * @param workflowParam
     * @return
     */
    private List<CampaignViewDTO> diffSplitAndDbSubCampaignList(ServiceContext serviceContext, CampaignViewDTO dbCampaignViewDTO,List<CampaignViewDTO> subCampaignViewDTOList, BizCampaignWorkflowParam workflowParam) {
        if(dbCampaignViewDTO == null || CollectionUtils.isEmpty(dbCampaignViewDTO.getSubCampaignViewDTOList())){
            return subCampaignViewDTOList;
        }
        List<CampaignViewDTO> resultCampaignViewList = Lists.newArrayList();
        List<CampaignViewDTO> dbSubCampaignList = dbCampaignViewDTO.getSubCampaignViewDTOList();
        String spiCode = BizCampaignSplitSpi.getSplitSpiCode(dbCampaignViewDTO, workflowParam.getPackageProductViewDTO());
        for (CampaignViewDTO dbSubCampaignViewDTO : dbSubCampaignList) {
            CampaignViewDTO subCampaignViewDTO = runAbilitySpi(BizCampaignSplitSpi.class,
                    extension -> extension.matchSubCampaign(serviceContext, dbSubCampaignViewDTO, subCampaignViewDTOList), spiCode);
            //执行更新
            if(subCampaignViewDTO != null){
                bizCampaignCommandWorkflowExt.beforeForUpdate(serviceContext,subCampaignViewDTO,dbSubCampaignViewDTO,workflowParam);
                resultCampaignViewList.add(subCampaignViewDTO);
            }else{
                dbSubCampaignViewDTO.setStatus(BrandCampaignStatusEnum.DELETE.getCode());
                resultCampaignViewList.add(dbSubCampaignViewDTO);
            }
        }
        for(CampaignViewDTO subCampaignViewDTO : subCampaignViewDTOList){
            CampaignViewDTO dbSubCampaignViewDTO = runAbilitySpi(BizCampaignSplitSpi.class,
                extension -> extension.matchSubCampaign(serviceContext, subCampaignViewDTO, dbSubCampaignList), spiCode);
            if(dbSubCampaignViewDTO == null){
                resultCampaignViewList.add(subCampaignViewDTO);
            }
        }
        //如果有锁量不允许新增或者删除全域通二级产品！
        resultCampaignViewList.forEach(item->{
            if(BizCampaignToolsHelper.hasLockDate(item) && BrandCampaignStatusEnum.DELETE.getCode().equals(item.getStatus())){
                throw new BrandOneBPException(BrandOneBPBaseErrorCode.OPERATION_DENIED.getErrCode(),"有锁量点位不允许调整,请释量后调整！");
            }
        });
        return resultCampaignViewList;
    }

    /**
     * 删除计划
     * @param serviceContext
     * @param campaignId
     * @return
     */
    public SingleResponse<Long> deleteCampaign(ServiceContext serviceContext, Long campaignId){
        CampaignViewDTO dbCampaignViewDTO = this.getCampaignInfoByOption(serviceContext, campaignId,
                CampaignQueryOption.builder().needChildren(true).build());
        //1. 校验计划
        bizCampaignCommandWorkflowExt.beforeForDelete(serviceContext,dbCampaignViewDTO);
        //2. 删除计划
        campaignDeleteAbility.handle(serviceContext,CampaignBatchAbilityParam.builder().abilityTargets(Lists.newArrayList(dbCampaignViewDTO)).build());
        //3、删除计划下单元
        adgroupBatchDeleteAbility.handle(serviceContext, AdgroupBatchDeleteAbilityParam.builder().abilityTargets(Lists.newArrayList(dbCampaignViewDTO.getId())).build());
        //4. 后置业务处理
        bizCampaignCommandWorkflowExt.afterBatchDeleteCampaign(serviceContext,Lists.newArrayList(dbCampaignViewDTO));
        return SingleResponse.of(campaignId);
    }

    /**
     * 批量删除计划
     * @param serviceContext
     * @param batchDeleteViewDTO
     * @return
     */
    public MultiResponse<Long> batchDeleteCampaign(ServiceContext serviceContext, CampaignBatchDeleteViewDTO batchDeleteViewDTO){
        // 校验基本信息
        AssertUtil.notNull(batchDeleteViewDTO, "批量删除计划参数不能为空");
        AssertUtil.notEmpty(batchDeleteViewDTO.getCampaignIds(), "批量删除计划信息不能为空");
        AssertUtil.notNull(batchDeleteViewDTO.getConfirm(), "批量删除计划二次确认信息不能为空");
        // 查询全部待删除计划(campaignTree)
        List<CampaignViewDTO> deleteCampaignList = campaignStructureQueryAbility.handle(serviceContext, CampaignStructureQueryAbilityParam.builder()
                .abilityTarget(CampaignQueryViewDTO.builder().campaignIds(batchDeleteViewDTO.getCampaignIds()).build())
                .queryOption(CampaignQueryOption.builder().needChildren(true).build()).build());
        batchDeleteViewDTO.setDeleteCampaignViewDTOList(deleteCampaignList);
        if(CollectionUtils.isEmpty(deleteCampaignList)){
            return MultiResponse.of(batchDeleteViewDTO.getCampaignIds());
        }
        //1. 校验计划
        bizCampaignCommandWorkflowExt.beforeBatchDeleteCampaign(serviceContext,batchDeleteViewDTO);
        //2. 删除计划
        campaignDeleteAbility.handle(serviceContext,CampaignBatchAbilityParam.builder().abilityTargets(deleteCampaignList).build());
        //3、删除计划下单元
        adgroupBatchDeleteAbility.handle(serviceContext, AdgroupBatchDeleteAbilityParam.builder().abilityTargets(batchDeleteViewDTO.getCampaignIds()).build());
        //4. 后置业务处理
        bizCampaignCommandWorkflowExt.afterBatchDeleteCampaign(serviceContext,deleteCampaignList);
        return MultiResponse.of(batchDeleteViewDTO.getCampaignIds());
    }

    /**
     * 基于订单自动新建计划
     * @param serviceContext
     * @param campaignGroupViewDTO
     * @return
     */
    public List<Long> autoAddCampaign(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO) {
        //1. 是否支持自动创建计划
        Boolean autoSaveJudge = campaignAutoSaveJudgeForAutoSaveCampaignAbility.handle(serviceContext,
                CampaignAutoSaveAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
        if(Boolean.FALSE.equals(autoSaveJudge)){
            RogerLogger.info("当前订单不支持创建计划，campaignGroupId={}",campaignGroupViewDTO.getId());
            return Lists.newArrayList();
        }
        //2. 基于订单初始化计划
        CampaignAutoBuildForAutoAddCampaignAbilityParam autoAddCampaignAbilityParam = buildParamForAutoAddCampaign(serviceContext, campaignGroupViewDTO);
        List<CampaignViewDTO> campaignViewDTOList = campaignAutoBuildForAutoAddCampaignAbility.handle(serviceContext, autoAddCampaignAbilityParam);

        List<Long> campaignIdList = Lists.newArrayList();
        if (CollectionUtils.isNotEmpty(campaignViewDTOList)) {
            //3. 前置动作
            bizCampaignCommandWorkflowExt.beforeAutoAddCampaign(serviceContext, campaignGroupViewDTO, campaignViewDTOList);
            //4. 创建计划
            List<CampaignViewDTO> resultCampaignList = this.batchAddCampaign(serviceContext,campaignViewDTOList);
            campaignIdList = Optional.ofNullable(resultCampaignList).orElse(Lists.newArrayList())
                    .stream().map(CampaignViewDTO::getId).collect(Collectors.toList());
        } else {
            RogerLogger.info("当前订单未新增计划，campaignGroupId={}",campaignGroupViewDTO.getId());
        }
        //5. 后置动作
        bizCampaignCommandWorkflowExt.afterAutoAddCampaign(serviceContext, campaignGroupViewDTO, campaignIdList);
        return campaignIdList;
    }

    /**
     * 基于订单自动更新计划，包含已存在计划修改、删除
     * @param serviceContext
     * @param campaignGroupViewDTO
     * @return
     */
    public void autoUpdateCampaign(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO){
        //1. diff--判断订单下哪些计划需要新增/修改/删除
        CampaignDiffViewDTO campaignDiffViewDTO = this.diffCampaignGroupCampaign(serviceContext,campaignGroupViewDTO);
        if(campaignDiffViewDTO == null){
            return;
        }
        //2. 新增计划
        List<Long> addCampaignIds = Lists.newArrayList();
        if(CollectionUtils.isNotEmpty(campaignDiffViewDTO.getAddCampaignViewDTOList())){
            List<CampaignViewDTO> addCampaignResultList = this.batchAddCampaign(serviceContext, campaignDiffViewDTO.getAddCampaignViewDTOList());
            addCampaignIds = Optional.ofNullable(addCampaignResultList).orElse(Lists.newArrayList()).stream()
                    .map(CampaignViewDTO::getId).collect(Collectors.toList());
        }
        //3. 修改计划
        if(CollectionUtils.isNotEmpty(campaignDiffViewDTO.getUpdateCampaignViewDTOList())){
            for(CampaignViewDTO updateCampaignViewDTO : campaignDiffViewDTO.getUpdateCampaignViewDTOList()){
                this.updateCampaign(serviceContext, updateCampaignViewDTO);
            }
        }
        //4. 删除计划
        if(CollectionUtils.isNotEmpty(campaignDiffViewDTO.getDeleteCampaignViewDTOList())){
            for(CampaignViewDTO deleteCampaignViewDTO : campaignDiffViewDTO.getDeleteCampaignViewDTOList()){
                this.deleteCampaign(serviceContext, deleteCampaignViewDTO.getId());
            }
        }
        bizCampaignCommandWorkflowExt.afterAutoUpdateCampaign(serviceContext, campaignGroupViewDTO, addCampaignIds);
    }

    /**
     * 计划安全IP开关
     * @param serviceContext
     * @param campaignViewDTO
     * @param isSupportSafeIp
     * @param safeIpThreshold
     */
    public void switchSafeIp(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, Integer isSupportSafeIp, Integer safeIpThreshold) {
        CampaignSafeIpViewDTO campaignSafeIpViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignSafeIpViewDTO())
                .orElse(new CampaignSafeIpViewDTO());
        campaignViewDTO.setCampaignSafeIpViewDTO(campaignSafeIpViewDTO);
        //更新一级计划风险IP开关
        campaignViewDTO.getCampaignSafeIpViewDTO().setIsSupportSafeIp(isSupportSafeIp);
        campaignViewDTO.getCampaignSafeIpViewDTO().setSafeIpThreshold(safeIpThreshold);

        //更新二级计划风险IP开关
        List<CampaignViewDTO> subCampaignList = campaignViewDTO.getSubCampaignViewDTOList();
        for (CampaignViewDTO subCampaignViewDTO: subCampaignList) {
            CampaignSafeIpViewDTO subCampaignSafeIpViewDTO = Optional.ofNullable(subCampaignViewDTO.getCampaignSafeIpViewDTO())
                    .orElse(new CampaignSafeIpViewDTO());
            subCampaignViewDTO.setCampaignSafeIpViewDTO(subCampaignSafeIpViewDTO);
            subCampaignViewDTO.getCampaignSafeIpViewDTO().setIsSupportSafeIp(isSupportSafeIp);
            subCampaignViewDTO.getCampaignSafeIpViewDTO().setSafeIpThreshold(safeIpThreshold);
        }
        List<CampaignViewDTO> needUpdateCampaignViewDTOList = Lists.newArrayList(campaignViewDTO);
        if(CollectionUtils.isNotEmpty(subCampaignList)){
            List<CampaignViewDTO> subCampaignViewDTOList = subCampaignList.stream()
                    .filter(campaignViewDTO1 -> BrandDateUtil.getCurrentDate().before(campaignViewDTO1.getEndTime())).collect(Collectors.toList());
            needUpdateCampaignViewDTOList.addAll(subCampaignViewDTOList);
        }
        campaignUpdatePartAbility.handle(serviceContext, CampaignBatchAbilityParam.builder().abilityTargets(needUpdateCampaignViewDTOList).build());
    }

    /**
     * 计划关联智能推荐人群
     * @param campaignViewDTO
     */
    public void bindTXCampaignOptimizeCrowds(CampaignViewDTO campaignViewDTO) {
        try {
            RogerLogger.info("bindTXCampaignOptimizeCrowds start campaignId: {}", campaignViewDTO.getId());
            ServiceContext serviceContext = ServiceContextUtil.buildServiceContextForBizCode(campaignViewDTO.getMemberId(), BizCodeEnum.TAOBRANDAD.getBizCode());
            // 调用商业能力
            BusinessAbilityRouteContext businessAbilityRouteContext = BusinessAbilityRouteContext.builder().specifiedBusinessAbilityCodes(Lists.newArrayList(RealTimeOptimizeBusinessAbility.ABILITY_CODE)).build();
            AbilityInvoker.invoke(ICampaignRealTimeOptimizeAlgoCrowdBindBusinessAbilityPoint.class, businessAbilityRouteContext,
                    callback -> callback.invokeForRealTimeOptimizeAlgoCrowdBind(serviceContext, campaignViewDTO.getId()));
        } catch (Exception e) {
            RogerLogger.error("bindTXCampaignOptimizeCrowds error campaignId: {}, e: {}", campaignViewDTO.getId(), e);
            throw new BrandOneBPException(" 计划关联智能推荐人群报错 ", e);
        }
    }

    /**
     * 对比订单下计划
     * @param serviceContext
     * @param campaignGroupViewDTO
     * @return
     */
    private CampaignDiffViewDTO diffCampaignGroupCampaign(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO){
        List<CampaignViewDTO> addCampaignViewDTOList = Lists.newArrayList();
        List<CampaignViewDTO> updateCampaignViewDTOList = Lists.newArrayList();
        List<CampaignViewDTO> deleteCampaignViewDTOList = Lists.newArrayList();

        //获取db计划信息
        CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder().campaignGroupId(campaignGroupViewDTO.getId())
                .campaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode()).build();
        List<CampaignViewDTO> dbCampaignViewDTOList = campaignStructureQueryAbility.handle(serviceContext, CampaignStructureQueryAbilityParam.builder().abilityTarget(campaignQueryViewDTO)
                        .queryOption(CampaignQueryOption.builder().build()).build());
        AssertUtil.notEmpty(dbCampaignViewDTOList, "订单中计划信息为空");

        //获取要操作的分组
        List<Long> saleGroupIdList = saleGroupGetForDiffCampaignAbility.handle(serviceContext, SaleGroupGetForDiffCampaignAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO).dbCampaignViewDTOList(dbCampaignViewDTOList).build());
        if(CollectionUtils.isEmpty(saleGroupIdList)){
            RogerLogger.info("diffCampaignGroupCampaign saleGroupIdList is empty");
            return null;
        }
        //构建拆分计划
        CampaignAutoBuildForAutoAddCampaignAbilityParam autoCampaignAbilityParam = buildParamForAutoAddCampaign(serviceContext, campaignGroupViewDTO);
        List<CampaignViewDTO> campaignViewDTOList = campaignAutoBuildForAutoAddCampaignAbility.handle(serviceContext, autoCampaignAbilityParam);

        //分组id+资源包产品id 构建计划唯一性索引
        String uniqueKeyFormat = "%s_%s";
        Map<String, CampaignViewDTO> campaignViewMap = campaignViewDTOList.stream().filter(campaignViewDTO -> campaignViewDTO.getCampaignSaleViewDTO() != null)
                .filter(campaignViewDTO -> saleGroupIdList.contains(campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId()))
                .collect(Collectors.toMap(e->String.format(uniqueKeyFormat, e.getCampaignSaleViewDTO().getSaleGroupId(), e.getCampaignSaleViewDTO().getResourcePackageProductId()), Function.identity(), (v1, v2) -> v2));

        Map<String, CampaignViewDTO> dbCampaignViewMap = dbCampaignViewDTOList.stream().filter(campaignViewDTO -> campaignViewDTO.getCampaignSaleViewDTO() != null)
                .filter(campaignViewDTO -> saleGroupIdList.contains(campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId()))
                .collect(Collectors.toMap(e->String.format(uniqueKeyFormat, e.getCampaignSaleViewDTO().getSaleGroupId(), e.getCampaignSaleViewDTO().getResourcePackageProductId()), Function.identity(), (v1, v2) -> v2));

        /*****      计划diff      ******/
        List<String> campaignKeyList = Lists.newArrayList(campaignViewMap.keySet());
        List<String> dbCampaignKeyList = Lists.newArrayList(dbCampaignViewMap.keySet());

        List<String> addCampaignKeyList = Differs.differ(campaignKeyList, dbCampaignKeyList, String::valueOf);
        List<String> updateCampaignKeyList = Differs.differ(campaignKeyList, addCampaignKeyList, String::valueOf);
        List<String> deleteCampaignKeyList = Differs.differ(dbCampaignKeyList, campaignKeyList, String::valueOf);

        //新增
        for (String addCampaignKey : addCampaignKeyList) {
            addCampaignViewDTOList.add(campaignViewMap.get(addCampaignKey));
        }
        //修改
        Map<Long, com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO> packageProductViewMap = autoCampaignAbilityParam.getPackageProductViewMap();
        for (String updateCampaignKey : updateCampaignKeyList) {
            CampaignViewDTO dbCampaignViewDTO = dbCampaignViewMap.get(updateCampaignKey);
            com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO currProductViewDTO =
                    packageProductViewMap.get(dbCampaignViewDTO.getCampaignSaleViewDTO().getResourcePackageProductId());

            Long bookingAmount = new BigDecimal(currProductViewDTO.getBandPriceList().get(0).getBookingAmount())
                    .multiply(new BigDecimal(Constant.DEFAULT_CPM_PV_RATIO)).longValue();
            //只有产品金额或者周期发生变化，才需要更新计划信息
            if(BrandDateUtil.isBeforeAndEqual(currProductViewDTO.getStartTime(), dbCampaignViewDTO.getStartTime())
                    && BrandDateUtil.getMinDate(currProductViewDTO.getEndTime()).equals(BrandDateUtil.getMinDate(dbCampaignViewDTO.getEndTime()))
                    && Objects.equals(bookingAmount,dbCampaignViewDTO.getCampaignGuaranteeViewDTO().getAmount())){
                RogerLogger.info("产品预定量或者周期未发生变化，不做处理，campaignId:{}", dbCampaignViewDTO.getId());
                continue;
            }
            updateCampaignViewDTOList.add(dbCampaignViewDTO);
        }
        //删除
        for (String deleteCampaignKey : deleteCampaignKeyList) {
            deleteCampaignViewDTOList.add(dbCampaignViewMap.get(deleteCampaignKey));
        }
        CampaignDiffViewDTO campaignDiffViewDTO = new CampaignDiffViewDTO();
        campaignDiffViewDTO.setAddCampaignViewDTOList(addCampaignViewDTOList);
        campaignDiffViewDTO.setUpdateCampaignViewDTOList(updateCampaignViewDTOList);
        campaignDiffViewDTO.setDeleteCampaignViewDTOList(deleteCampaignViewDTOList);
        RogerLogger.info("campaignDiffViewDTO:{}", JSON.toJSONString(campaignDiffViewDTO));
        return campaignDiffViewDTO;
    }

    /**
     * 重设一级计划金额
     * @param serviceContext
     * @param campaignViewDTO
     * @return
     */
    public MultiResponse<Long> resetCampaignBudget(ServiceContext serviceContext,CampaignViewDTO campaignViewDTO){

        //查询出来一级计划
        CampaignQueryOption option = CampaignQueryOption.builder().needCampaignTree(true).needTarget(true).needFrequency(true).build();
        CampaignViewDTO campaignTree = this.getCampaignInfoByOption(serviceContext, campaignViewDTO.getId(), option);
        AssertUtil.notNull(campaignTree, "计划不存在");
        AssertUtil.notNull(campaignTree.getCampaignBudgetViewDTO().getDiscountTotalMoney(), "请在订单分组中重新点击“计算”后，再修改计划预算");
        if(campaignTree.getCampaignBudgetViewDTO().getDiscountTotalMoney().equals(campaignViewDTO.getCampaignBudgetViewDTO().getDiscountTotalMoney())){
            return MultiResponse.of();
        }
        campaignTree.getCampaignBudgetViewDTO().setDiscountTotalMoney(campaignViewDTO.getCampaignBudgetViewDTO().getDiscountTotalMoney());
        //组装参数
        BizCampaignCalculateWorkflowParam calculateWorkflowParamExt = bizCampaignCommandWorkflowExt.buildParamForCalculate(serviceContext,campaignTree);
        ResourcePackageSaleGroupViewDTO saleGroup = calculateWorkflowParamExt.getPackageSaleGroupViewDTO();
        //step0 : 预算合法性校验
        campaignBudgetValidateForResetCampaignBudgetAbility.handle(serviceContext,CampaignBudgetValidateForResetAbilityParam.builder().abilityTarget(campaignTree.getCampaignBudgetViewDTO()).dbCampaignViewDTO(campaignTree).saleGroup(saleGroup).build());
        saleGroupOperateDistLockGetAbility.handle(serviceContext,
            SaleGroupOperateDistLockAbilityParam.builder().abilityTargets(Lists.newArrayList(campaignTree.getCampaignSaleViewDTO().getSaleGroupId())).build());
        // 计划处于锁量中，不允许修改预算
        campaignOperateDistLockGetAbility.handle(serviceContext, CampaignOperateDistLockAbilityParam.builder().abilityTargets(Lists.newArrayList(campaignTree.getId())).build());
        //step1 ：初始化价格信息，根据用户输入的一级预算重新分配二级预算
        CampaignPriceViewDTO resetCampaignPriceViewDTO = resetCampaignPriceViewDTO(serviceContext, campaignTree, calculateWorkflowParamExt);
        resetSubCampaignBudgetFromParent(serviceContext, campaignTree, calculateWorkflowParamExt.getCampaignGroupViewDTO(), resetCampaignPriceViewDTO);

        //step2:重新计算计划对应的资源产品预算
        SaleGroupInfoViewDTO saleGroupInfoViewDTO = calculateWorkflowParamExt.getSaleGroupInfoViewDTO();
        //修改了一级计划金额需要重新计算计划对应二级产品金额
        Optional<ResourcePackageProductViewDTO> optional = saleGroupInfoViewDTO.getResourcePackageProductViewDTOList().stream().filter(item->item.getResourcePackageProductId().equals(
                campaignTree.getCampaignSaleViewDTO().getResourcePackageProductId())).findFirst();
        if(optional.isPresent()){
            List<CampaignViewDTO> levelOneCampaigns= campaignRepository.queryCampaignList(serviceContext, CampaignQueryViewDTO.builder().campaignLevel(
                BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode()).resourcePackageProductId(campaignTree.getCampaignSaleViewDTO().getResourcePackageProductId()).build());
            Long resourceCalbudget =  levelOneCampaigns.stream().mapToLong(item->item.getCampaignBudgetViewDTO().getDiscountTotalMoney()).sum();
            optional.get().setBudget(resourceCalbudget);
        }

        //step3:重新计算计划对应的分组预算
        calculateUpdateSaleGroupAbility.handle(serviceContext,
            SaleGroupPvBudgetForCalculateUpdateSaleGroupAbilityParam.builder().abilityTarget(saleGroupInfoViewDTO).resourcePackageSaleGroupViewDTO(calculateWorkflowParamExt.getPackageSaleGroupViewDTO()).build());
        campaignGroupRepository.addOrUpdateSaleGroupPart(serviceContext,saleGroupInfoViewDTO.getCampaignGroupId(), Lists.newArrayList(saleGroupInfoViewDTO));
        return MultiResponse.of();
    }


    private CampaignPriceViewDTO resetCampaignPriceViewDTO(ServiceContext serviceContext, CampaignViewDTO campaignTree, BizCampaignCalculateWorkflowParam calculateWorkflowParamExt) {
        com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO resourcePackageProductViewDTO = calculateWorkflowParamExt.getPackageProductViewDTO();
        List<CampaignViewDTO> campaignViewDTOList = calculateWorkflowParamExt.getGroupCampaignLevelOneViewDTOList();
        // 同一 二级产品下的其他一级计划预算之和
        List<CampaignViewDTO> filterCampaignViewDTOList = campaignViewDTOList.stream().filter(item->item.getCampaignSaleViewDTO().getResourcePackageProductId().equals(campaignTree.getCampaignSaleViewDTO().getResourcePackageProductId()) && !campaignTree.getId().equals(item.getId())).collect(Collectors.toList());
        AssertUtil.assertTrue(filterCampaignViewDTOList.stream().allMatch(item -> Objects.nonNull(item.getCampaignBudgetViewDTO().getDiscountTotalMoney())), "请在订单分组中重新点击“计算”后，再修改计划预算");
        Long resourceOtherTotalBudget =  filterCampaignViewDTOList.stream().mapToLong(item->item.getCampaignBudgetViewDTO().getDiscountTotalMoney()).sum();
        // 本一级计划占比
        Integer budgetRatio = new BigDecimal(campaignTree.getCampaignBudgetViewDTO().getDiscountTotalMoney()).divide(new BigDecimal(resourceOtherTotalBudget).add( new BigDecimal(
            campaignTree.getCampaignBudgetViewDTO().getDiscountTotalMoney())),0,BigDecimal.ROUND_HALF_UP).multiply(new BigDecimal(Constant.RATIO_EXPAND_MULTIPLE)).intValue() ;
        campaignTree.getCampaignBudgetViewDTO().setBudgetRatio(budgetRatio);
        return campaignPriceInitForAssignBudgetAbility.handle(serviceContext,CampaignPriceInitForAssignBudgetParam.builder().abilityTarget(campaignTree).resourcePackageProductViewDTO(resourcePackageProductViewDTO).build());
    }




    private Void resetSubCampaignBudgetFromParent(ServiceContext serviceContext, CampaignViewDTO campaignTree, CampaignGroupViewDTO campaignGroupViewDTO, CampaignPriceViewDTO campaignPriceViewDTO) {
        CampaignPVAssignSceneEnum campaignPVAssignSceneEnum = BizCampaignToolsHelper.getCampaignPVAssignSceneEnum(campaignTree.getCampaignSaleViewDTO().getSaleProductLine());
        campaignTree.getCampaignBudgetViewDTO().setIsCustomResetBudget(BrandBoolEnum.BRAND_FALSE.getCode());
        campaignTree.getSubCampaignViewDTOList().forEach(item->item.getCampaignBudgetViewDTO().setIsCustomResetBudget(BrandBoolEnum.BRAND_FALSE.getCode()));
        List<CampaignViewDTO> updateCampaignTreeViewList = assignSubCampaignBudget(serviceContext,Lists.newArrayList(campaignPriceViewDTO), Lists.newArrayList(campaignTree), campaignGroupViewDTO,campaignPVAssignSceneEnum);
        List<CampaignViewDTO> updateList = Lists.newArrayList();
        updateCampaignTreeViewList.stream().forEach(item->{
            if(campaignTree.getId().equals(item.getId())
                && BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode().equals(item.getCampaignLevel()) ){
                item.getCampaignBudgetViewDTO().setDiscountTotalMoney(campaignTree.getCampaignBudgetViewDTO().getDiscountTotalMoney());
            }
            updateList.add(item);
        });
        addOrUpdateCampaignWithoutInquiryByCalculate(serviceContext, campaignGroupViewDTO.getId(),updateList);
        updateCampaignSuccessInquiryAll(serviceContext, updateList);
        bizCampaignInventoryWorkflow.autoAssignCampaignInquiryAmountSync(serviceContext,updateCampaignTreeViewList);
        return null;
    }

    private void assignSubCampaignBudgetByCustom(ServiceContext serviceContext, CampaignViewDTO campaignTree,
                                        CampaignGroupViewDTO campaignGroupViewDTO, CampaignPriceViewDTO campaignPriceViewDTO) {
        CampaignPVAssignSceneEnum campaignPVAssignSceneEnum = BizCampaignToolsHelper.getCampaignPVAssignSceneEnum(campaignTree.getCampaignSaleViewDTO().getSaleProductLine());
        campaignTree.getCampaignBudgetViewDTO().setIsCustomResetBudget(BrandBoolEnum.BRAND_FALSE.getCode());
        campaignTree.getSubCampaignViewDTOList().forEach(item->item.getCampaignBudgetViewDTO().setIsCustomResetBudget(BrandBoolEnum.BRAND_FALSE.getCode()));
        //查询子计划
        //组装参数
        //查询价格中心  获取计划刊例价
        //ssp拿到加收后的刊例价 / 资源包给的刊例价×资源包给的净价
        AssertUtil.assertTrue(campaignPriceViewDTO.getDiscountTotalMoney() != null && campaignPriceViewDTO.getDiscountTotalMoney() >0,campaignPriceViewDTO.getCampaignId()+"计算后计划价格为0");
        runAbilitySpi(BizCampaignSplitSpi.class, extension->extension.assignSubCampaignBudget(serviceContext,campaignGroupViewDTO,campaignPriceViewDTO,campaignTree,campaignPVAssignSceneEnum),BizCampaignSplitSpi.getSplitSpiCode(campaignTree,campaignPriceViewDTO));
    }


    private static void validateCampaignStatus(CampaignViewDTO campaignTree) {
        AssertUtil.notNull(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode().equals(campaignTree.getCampaignLevel()), "只允许在一级计划上调整预算");
        AssertUtil.assertTrue(BrandCampaignStatusEnum.NEW.getCode().equals(campaignTree.getStatus())
            ||BrandCampaignStatusEnum.LOCK_FAIL.getCode().equals(campaignTree.getStatus())
            ||BrandCampaignStatusEnum.INQUIRY_FAIL.getCode().equals(campaignTree.getStatus())
            ||BrandCampaignStatusEnum.INQUIRY_SUCCESS.getCode().equals(campaignTree.getStatus()),"计划状态不允许");
        for(CampaignViewDTO sub : campaignTree.getSubCampaignViewDTOList()){
            AssertUtil.assertTrue(BrandCampaignStatusEnum.NEW.getCode().equals(sub.getStatus())
                ||BrandCampaignStatusEnum.LOCK_FAIL.getCode().equals(sub.getStatus())
                ||BrandCampaignStatusEnum.INQUIRY_FAIL.getCode().equals(sub.getStatus())
                ||BrandCampaignStatusEnum.INQUIRY_SUCCESS.getCode().equals(sub.getStatus()),"计划状态不允许");
        }
    }

    public void rebuildCalSaleGroupInfo(ServiceContext serviceContext, ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO, SaleGroupInfoViewDTO saleGroupInfoViewDTO, List<CampaignViewDTO> allLevelOneList) {
        bizCampaignCommandWorkflowExt.rebuildCalSaleGroupInfo(serviceContext, packageSaleGroupViewDTO,saleGroupInfoViewDTO,allLevelOneList);
    }


    /**
     * 重设二级计划金额
     * @param serviceContext
     * @param batchUpdatelevelTwoCampaignViewList
     * @return
     */
    public Response resetSubCampaignBudget(ServiceContext serviceContext, List<CampaignViewDTO> batchUpdatelevelTwoCampaignViewList) {
        //组装数据
        List<Long> levelOneCampaignIdList = batchUpdatelevelTwoCampaignViewList.stream().map(item->item.getParentCampaignId()).collect(Collectors.toList());
        CampaignQueryViewDTO queryViewDTO = CampaignQueryViewDTO.builder().campaignIds(levelOneCampaignIdList).build();
        List<CampaignViewDTO> dbCampaignTreeList = campaignStructureQueryAbility.handle(serviceContext, CampaignStructureQueryAbilityParam.builder().abilityTarget(queryViewDTO).queryOption(CampaignQueryOption.builder().needCampaignTree(true).build()).build());
        // 获取分组下的计划锁量的分布式锁（确定没有被上锁，则可以继续操作）
        campaignOperateDistLockGetAbility.handle(serviceContext, CampaignOperateDistLockAbilityParam.builder().abilityTargets(levelOneCampaignIdList).build());
        //按照分组-》一级-》二级计划的顺序更新金额和PV
        Map<Long,List<CampaignViewDTO>> saleGroupCampaignMap = dbCampaignTreeList.stream().collect(Collectors.groupingBy(item->item.getCampaignSaleViewDTO().getSaleGroupId()));
        //校验前置
        for (Long saleGroupId : saleGroupCampaignMap.keySet()) {
            saleGroupOperateDistLockGetAbility.handle(serviceContext,SaleGroupOperateDistLockAbilityParam.builder().abilityTargets(Lists.newArrayList(saleGroupId)).build());
            List<CampaignViewDTO>  levelOneCampaignList = saleGroupCampaignMap.get(saleGroupId);
            //这里一组一组操作，目前和前端定义的接口只有单操作，未设计二次确认所以有一个异常需要抛出
            for(CampaignViewDTO  dbCampaignTree : levelOneCampaignList ){
                List<CampaignViewDTO> levelTwoCampaignViewList  = batchUpdatelevelTwoCampaignViewList.stream().filter(item->item.getParentCampaignId().equals(dbCampaignTree.getId())).collect(
                        Collectors.toList());
                validateResetSubCampaignBudget(levelTwoCampaignViewList,dbCampaignTree);
            }
        }
        for(Long saleGroupId : saleGroupCampaignMap.keySet()){
            List<CampaignViewDTO>  levelOneCampaignList = saleGroupCampaignMap.get(saleGroupId);
            //这里一组一组操作，目前和前端定义的接口只有单操作，未设计二次确认所以有一个异常需要抛出
            for(CampaignViewDTO  dbCampaignTree : levelOneCampaignList ){
                List<CampaignViewDTO> levelTwoCampaignViewList  = batchUpdatelevelTwoCampaignViewList.stream()
                        .filter(item->item.getParentCampaignId().equals(dbCampaignTree.getId()))
                        .collect(Collectors.toList());
                //初始化二级计划预算信息
                initSubCampaignBudget(serviceContext,levelTwoCampaignViewList,dbCampaignTree);
                //更新计划预算信息（预定量不更新）
                addOrUpdateCampaignWithoutInquiryByCalculate(serviceContext,dbCampaignTree.getCampaignSaleViewDTO().getSaleGroupId(),Lists.newArrayList(dbCampaignTree));
                //更新锁量成功的预定量信息
                updateCampaignSuccessInquiryAll(serviceContext,Lists.newArrayList(dbCampaignTree));
                //自动重新分配计划预定量
                bizCampaignInventoryWorkflow.autoAssignCampaignInquiryAmount(serviceContext,Lists.newArrayList(dbCampaignTree));
            }
            //针对这一组计划使用的是一个售卖分组
            CampaignViewDTO campaignViewDTO = levelOneCampaignList.get(0);
            BizCampaignBudgetWorkflowParam bizCampaignWorkflowParam = bizCampaignCommandWorkflowExt.buildParamForAssignBudget(serviceContext,campaignViewDTO);
            calculateUpdateSaleGroupAbility.handle(serviceContext,
                SaleGroupPvBudgetForCalculateUpdateSaleGroupAbilityParam.builder().abilityTarget(bizCampaignWorkflowParam.getSaleGroupInfoViewDTO()).resourcePackageSaleGroupViewDTO(bizCampaignWorkflowParam.getPackageSaleGroupViewDTO()).build());
            campaignGroupRepository.addOrUpdateSaleGroupPart(serviceContext,bizCampaignWorkflowParam.getSaleGroupInfoViewDTO().getCampaignGroupId(), Lists.newArrayList(bizCampaignWorkflowParam.getSaleGroupInfoViewDTO()));
        }
        return Response.success();
    }


    /**
     * 更新询锁量信息
     */
    public void updateCampaignSuccessInquiryAll(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList) {
        if (CollectionUtils.isNotEmpty(campaignViewDTOList)) {
            for (CampaignViewDTO parent : campaignViewDTOList) {
                List<CampaignInquiryViewDTO> parentCampaignInquiryViewDTOList = Optional.ofNullable(parent.getCampaignInquiryLockViewDTO())
                    .map(CampaignInquiryLockViewDTO::getCampaignInquiryViewDTOList).orElse(Lists.newArrayList());
                updateInquiryList(serviceContext, parent.getId(), parentCampaignInquiryViewDTOList);
                if (CollectionUtils.isNotEmpty(parent.getSubCampaignViewDTOList())) {
                    for (CampaignViewDTO sub : parent.getSubCampaignViewDTOList()) {
                        List<CampaignInquiryViewDTO> subCampaignInquiryViewDTOList = Optional.ofNullable(sub.getCampaignInquiryLockViewDTO())
                            .map(CampaignInquiryLockViewDTO::getCampaignInquiryViewDTOList).orElse(Lists.newArrayList());
                        updateInquiryList(serviceContext, sub.getId(), subCampaignInquiryViewDTOList);
                    }
                }
            }
        }
    }

    /**
     * 删除询锁量信息，已锁量不更新
     */
    private void updateInquiryList(ServiceContext serviceContext, Long campaignId, List<CampaignInquiryViewDTO> inquiryViewDTOList) {
        if (org.apache.commons.collections.CollectionUtils.isEmpty(inquiryViewDTOList)) {
            return;
        }
        List<CampaignInquiryViewDTO> result = inquiryViewDTOList.stream().filter(v -> BrandInquiryStatusEnum.SUCCESS.getCode().equals(v.getStatus()))
            .collect(Collectors.toList());
        campaignRepository.updateCampaignInquiryAll(serviceContext, campaignId, result);
    }


    private Void validateResetSubCampaignBudget(List<CampaignViewDTO> resetLevelTwoCampaignViewDTOList,CampaignViewDTO dbCampaignTree) {
        AssertUtil.notEmpty(resetLevelTwoCampaignViewDTOList,"未找到对应计划！");
        AssertUtil.notEmpty(dbCampaignTree.getSubCampaignViewDTOList(), "子计划不存在");
        for(CampaignViewDTO subCampaignViewDTO : dbCampaignTree.getSubCampaignViewDTOList()){
            AssertUtil.assertTrue(BrandCampaignStatusEnum.NEW.getCode().equals(subCampaignViewDTO.getStatus())
                ||BrandCampaignStatusEnum.LOCK_FAIL.getCode().equals(subCampaignViewDTO.getStatus())
                ||BrandCampaignStatusEnum.INQUIRY_FAIL.getCode().equals(subCampaignViewDTO.getStatus())
                ||BrandCampaignStatusEnum.INQUIRY_SUCCESS.getCode().equals(subCampaignViewDTO.getStatus()),"计划状态不允许");
            AssertUtil.assertTrue(!BizCampaignToolsHelper.isHavaHistoryDate(subCampaignViewDTO),String.format("计划%s包含历史时间，不支持调整二级预算！",subCampaignViewDTO.getId()));
            CampaignViewDTO inputBudgetViewDTO = resetLevelTwoCampaignViewDTOList.stream().filter(item->item.getId().equals(subCampaignViewDTO.getId())).findAny().get();
            AssertUtil.notNull(inputBudgetViewDTO,"参数有误，未找到对应子计划");
        }
        AssertUtil.assertTrue(!BizCampaignToolsHelper.isCPT(dbCampaignTree.getCampaignGuaranteeViewDTO().getSspRegisterUnit()),"CPT不可单独子计划调整金额");
        AssertUtil.assertTrue(dbCampaignTree.getCampaignBudgetViewDTO().getDiscountTotalMoney().equals(resetLevelTwoCampaignViewDTOList.stream().mapToLong(item->item.getCampaignBudgetViewDTO().getDiscountTotalMoney()).sum()),"二级计划和主计划金额不一致！");
        return null;
    }

    private  Void initSubCampaignBudget(ServiceContext context,List<CampaignViewDTO> resetLevelTwoCampaignViewDTOList,CampaignViewDTO dbCampaignTree){
        //计算分配模式，按照上浮还是下抹
        CampaignPVAssignSceneEnum campaignPVAssignSceneEnum = BizCampaignToolsHelper.getCampaignPVAssignSceneEnum(dbCampaignTree.getCampaignSaleViewDTO().getSaleProductLine());
        List<CampaignViewDTO> subCampaignViewDTOList = dbCampaignTree.getSubCampaignViewDTOList();
        long allRatio = Constant.RATIO_EXPAND_MULTIPLE;
        long parentPv  = 0;
        long parentPublishTotalMoney = 0;
        //设置二级计划金额和PV，二级计划的预算比例做倒减，满足100%
        for(int i =0 ; i<subCampaignViewDTOList.size() ; i++){
            CampaignViewDTO subCampaignViewDTO = subCampaignViewDTOList.get(i);
            CampaignViewDTO inputBudgetViewDTO =  resetLevelTwoCampaignViewDTOList.stream().filter(item->item.getId().equals(subCampaignViewDTO.getId())).findAny().get();
            subCampaignViewDTO.getCampaignBudgetViewDTO().setDiscountTotalMoney(inputBudgetViewDTO.getCampaignBudgetViewDTO().getDiscountTotalMoney());
            long budgetRatio =  BigDecimal.valueOf(subCampaignViewDTO.getCampaignBudgetViewDTO().getDiscountTotalMoney()).multiply( BigDecimal.valueOf(Constant.RATIO_EXPAND_MULTIPLE)).divide( BigDecimal.valueOf(dbCampaignTree.getCampaignBudgetViewDTO().getDiscountTotalMoney()),0,BigDecimal.ROUND_HALF_UP).longValue() ;
            long pv = BizCampaignToolsHelper.calPV(subCampaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope(),subCampaignViewDTO.getCampaignResourceViewDTO().getSspProductLineId(),subCampaignViewDTO.getCampaignBudgetViewDTO().getDiscountTotalMoney(), subCampaignViewDTO.getCampaignPriceViewDTO().getSettlePrice(),campaignPVAssignSceneEnum);
            subCampaignViewDTO.getCampaignBudgetViewDTO().setBudgetRatio((int)budgetRatio);
            subCampaignViewDTO.getCampaignGuaranteeViewDTO().setAmount(pv);

            long publishPrice = 0L;
            try{
                publishPrice =  subCampaignViewDTO.getCampaignPriceViewDTO().getPublishPriceInfoList().get(0).getPrice();
            }catch (Exception e){
                RogerLogger.error("{} publish price is null",subCampaignViewDTO.getId());
            }
            long publishTotalMoney = BizCampaignToolsHelper.reCalCpmTotalMoney(subCampaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope(),subCampaignViewDTO.getCampaignResourceViewDTO().getSspProductLineId(),pv,publishPrice);
            subCampaignViewDTO.getCampaignBudgetViewDTO().setPublishTotalMoney(publishTotalMoney);
            if(i == subCampaignViewDTOList.size()-1){
                subCampaignViewDTO.getCampaignBudgetViewDTO().setBudgetRatio((int) allRatio);
            }else {
                allRatio -= budgetRatio;
            }
            parentPv += pv;
            parentPublishTotalMoney+=publishTotalMoney;
            if(Constant.CAN_INQUIRY_LOCK_STATUS.contains(subCampaignViewDTO.getStatus())){
                subCampaignViewDTO.setStatus(BrandCampaignStatusEnum.NEW.getCode());
            }
            subCampaignViewDTO.getCampaignBudgetViewDTO().setIsCustomResetBudget(BrandBoolEnum.BRAND_TRUE.getCode());
        }
        dbCampaignTree.getCampaignGuaranteeViewDTO().setAmount(parentPv);
        dbCampaignTree.getCampaignBudgetViewDTO().setPublishTotalMoney(parentPublishTotalMoney);

        long parentSettlePrice = BigDecimal.valueOf(dbCampaignTree.getCampaignBudgetViewDTO().getDiscountTotalMoney()).divide(( BigDecimal.valueOf(parentPv).divide( BigDecimal.valueOf(1000),3,BigDecimal.ROUND_DOWN)),0, BigDecimal.ROUND_DOWN).longValue();
        dbCampaignTree.getCampaignPriceViewDTO().setSettlePrice(parentSettlePrice);
        if(Constant.CAN_INQUIRY_LOCK_STATUS.contains(dbCampaignTree.getStatus())){
            dbCampaignTree.setStatus(BrandCampaignStatusEnum.NEW.getCode());
        }
        return  null;
    }


    public void addOrUpdateCampaignWithoutInquiryByCalculate(ServiceContext context, Long campaignGroupId, List<CampaignViewDTO> campaignTreeViewDTOList) {
        List<CampaignViewDTO> campaignViewDTOList = Lists.newArrayList();
        for (CampaignViewDTO campaignTreeViewDTO : campaignTreeViewDTOList) {
            if(org.apache.commons.collections.CollectionUtils.isNotEmpty(campaignTreeViewDTO.getSubCampaignViewDTOList())){
                campaignViewDTOList.addAll(campaignTreeViewDTO.getSubCampaignViewDTOList());
            }
            campaignViewDTOList.add(campaignTreeViewDTO);
        }
        campaignViewDTOList = campaignViewDTOList.stream().filter(item->!Constant.LOCK_AND_ING_CAMPAIGN_STATUS_LIST.contains(item.getStatus())).collect(
            Collectors.toList());
        //更新计算时间加上23:59:59'
        campaignViewDTOList.forEach(item -> {
            if (item.getEndTime() != null) {
                item.setEndTime(BrandDateUtil.getMaxDate(item.getEndTime()));
            }
            //showmax产品线删除预估ctr
            if (BizCampaignToolsHelper.isShowmaxCampaign(item.getCampaignResourceViewDTO().getSspMediaScope(), item.getCampaignResourceViewDTO().getSspProductLineId(), item.getCampaignResourceViewDTO().getSspCrossScene())
                && BrandCampaignStatusEnum.NEW.getCode().equals(item.getStatus())) {
                if (Objects.nonNull(item.getCampaignCrowdScenarioViewDTO()) && Objects.nonNull(item.getCampaignCrowdScenarioViewDTO().getCampaignShowmaxCrowdViewDTO())) {
                    CampaignShowmaxCrowdViewDTO campaignShowmaxCrowdViewDTO = item.getCampaignCrowdScenarioViewDTO().getCampaignShowmaxCrowdViewDTO();
                    campaignShowmaxCrowdViewDTO.setShowMaxCtrMin("");
                    campaignShowmaxCrowdViewDTO.setShowMaxCtrMax("");
                    campaignShowmaxCrowdViewDTO.setShowMaxProposeStart("");
                    campaignShowmaxCrowdViewDTO.setShowMaxProposeEnd("");
                    item.getCampaignCrowdScenarioViewDTO().setCampaignShowmaxCrowdViewDTO(campaignShowmaxCrowdViewDTO);
                }
            }
            // 如果是周期内滚量，且滚量开始时间和计划开始时间不一致
            if (item.getCampaignScrollViewDTO() != null
                && BrandCampaignScrollTypeEnum.PERIOD_SCROLL.getCode().equals(item.getCampaignScrollViewDTO().getScrollType())) {
                if(item.getCampaignScrollViewDTO().getScrollStartTime() != null && !BrandDateUtil.isSameDay(item.getCampaignScrollViewDTO().getScrollStartTime(),item.getStartTime())){
                    item.getCampaignScrollViewDTO().setScrollStartTime(item.getStartTime());
                }

            }
        });
        //更新计划信息
        List<CampaignViewDTO> addList = campaignViewDTOList.stream().filter(item -> item.getId() == null && BrandDateUtil.isAfterAndEqual(item.getEndTime(),BrandDateUtil.getMaxDate(BrandDateUtil.getCurrentDate()))  ).collect(
            Collectors.toList());
        if(org.apache.commons.collections.CollectionUtils.isNotEmpty(addList)){
            campaignAddAbility.handle(context, CampaignBatchAbilityParam.builder().campaignGroupId(campaignGroupId).abilityTargets(addList).build());
        }
        List<CampaignViewDTO> updateList = campaignViewDTOList.stream().filter(item -> item.getId() != null  && BrandDateUtil.isAfterAndEqual(item.getEndTime(),BrandDateUtil.getMaxDate(BrandDateUtil.getCurrentDate())) ).collect(
            Collectors.toList());
        if(CollectionUtils.isNotEmpty(updateList)){
            campaignRepository.updateCampaignPartWithoutInquiry(context, updateList);
        }
        //纯历史的可能需要刷新预算比例
        List<CampaignViewDTO> historyUpdateList = campaignViewDTOList.stream().filter(item -> item.getId() != null  && BrandDateUtil.isBefore(item.getEndTime(),BrandDateUtil.getMaxDate(BrandDateUtil.getCurrentDate())) ).collect(
            Collectors.toList());
        if(CollectionUtils.isNotEmpty(historyUpdateList)){
            campaignRepository.updateCampaignBudgetRatio(context,historyUpdateList);
        }
    }


    /**
     * 批量开关
     * @param serviceContext
     * @param campaignIds
     * @param switchEnum
     * @return
     */
    public Response batchSwitchCampaign(ServiceContext serviceContext, List<Long> campaignIds, SwitchEnum switchEnum) {
        List<CampaignViewDTO> campaignTreeViewDTOList = campaignStructureQueryAbility.handle(serviceContext, CampaignStructureQueryAbilityParam.builder().abilityTarget(CampaignQueryViewDTO.builder().campaignIds(campaignIds).build()).queryOption(CampaignQueryOption.builder().needCampaignTree(true).build()).build());
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(campaignTreeViewDTOList) , BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR,"未找到对应计划");

        for(CampaignViewDTO campaignViewTreeDTO : campaignTreeViewDTOList){
            List<CampaignViewDTO> operatorViewDTOList = Lists.newArrayList();
            if(campaignIds.contains(campaignViewTreeDTO.getId())){
                operatorViewDTOList.add(campaignViewTreeDTO);
                operatorViewDTOList.addAll(campaignViewTreeDTO.getSubCampaignViewDTOList());
            }else{
                for(CampaignViewDTO sub : campaignViewTreeDTO.getSubCampaignViewDTOList()){
                    if(campaignIds.contains(sub.getId())){
                        operatorViewDTOList.add(sub);
                    }
                }
            }
            campaignValidateForSwitchCampaignAbility.handle(serviceContext, CampaignValidateForSwitchCampaignAbilityParam.builder().abilityTargets(operatorViewDTOList).campaignViewDTO(campaignViewTreeDTO).switchEnum(switchEnum).build());
            campaignBatchSwitchAbility.handle(serviceContext, CampaignBatchSwitchAbilityParam.builder().abilityTargets(operatorViewDTOList).switchEnum(switchEnum).build());
        }
        return Response.success();
    }


//    /**
//     * 计划锁量延期申请
//     * @param serviceContext
//     * @param delayLockApplyViewDTO
//     * @return
//     */
//    public Void delayLock(ServiceContext serviceContext, CampaignDelayLockApplyViewDTO delayLockApplyViewDTO) {
//        // 组装参数
//        List<BizCampaignAutoReleaseWorkflowParam> bizCampaignAutoReleaseWorkflowParams = bizCampaignCommandWorkflowExt.buildAutoReleaseDelayLockParamExt(serviceContext,delayLockApplyViewDTO);
//
//        // 过滤非法参数
//        List<BizCampaignAutoReleaseWorkflowParam> filterBizCampaignAutoReleaseWorkflowParams = bizCampaignAutoReleaseWorkflowParams.stream().filter(param -> {
//            return campaignFilterForAutoReleaseDelayLockAbility.handle(serviceContext, CampaignFilterForAutoReleaseDelayLockAbilityParam.builder()
//                    .abilityTarget(param.getCampaignViewDTO().getCampaignInquiryLockViewDTO())
//                    .campaignViewDTO(param.getCampaignViewDTO()).saleGroupInfoViewDTO(param.getSaleGroupInfoViewDTO()).build());
//        }).collect(Collectors.toList());
//
//        // 填充参数
//        for (BizCampaignAutoReleaseWorkflowParam param : filterBizCampaignAutoReleaseWorkflowParams) {
//            Date updateLockExpireTime = campaignCalculateLockExpireTimeForResetAbility.handle(serviceContext,
//                    CampaignLockExpireTimeRecalculateAbilityParam.builder().campaignId(param.getCampaignViewDTO().getId()).abilityTarget(param.getCampaignViewDTO().getCampaignInquiryLockViewDTO()).build());
//
//            CampaignInventoryAutoReleaseStatusViewDTO autoReleaseStatusViewDTO = campaignInventoryAutoReleaseWarningBuildAbility.handle(serviceContext, CampaignInventoryAutoReleaseWarningBuildAbilityParam.builder()
//                    .abilityTarget(param.getCampaignViewDTO().getCampaignInquiryLockViewDTO()).campaignViewDTO(param.getCampaignViewDTO())
//                    .calculateLockExpireTime(updateLockExpireTime).build());
//            param.setAutoReleaseStatusViewDTO(autoReleaseStatusViewDTO);
//        }
//
//        //业务校验
//        campaignValidateForAutoReleaseDelayLockAbility.handle(serviceContext, CampaignValidateForAutoReleaseDelayLockAbilityParam.builder()
//                .campaignDelayLockApplyViewDTO(delayLockApplyViewDTO).bizCampaignAutoReleaseWorkflowParamList(filterBizCampaignAutoReleaseWorkflowParams).build());
//
//        //发起工作流
//        dealDelayLockProcessInstance(serviceContext,filterBizCampaignAutoReleaseWorkflowParams, delayLockApplyViewDTO.getCreatorId(), delayLockApplyViewDTO.getReason());
//
//        //更新计划
//        List<CampaignViewDTO> updateList = Lists.newArrayList();
//        for(BizCampaignAutoReleaseWorkflowParam bizCampaignAutoReleaseWorkflowParam : filterBizCampaignAutoReleaseWorkflowParams){
//            CampaignViewDTO campaignViewDTO = bizCampaignAutoReleaseWorkflowParam.getCampaignViewDTO();
//            CampaignViewDTO updateCampaignViewDTO = new CampaignViewDTO();
//            updateCampaignViewDTO.setId(campaignViewDTO.getId());
//
//            String delayReleaseProcessId = campaignViewDTO.getCampaignInquiryLockViewDTO().getCampaignDelayReleaseViewDTO().getDelayReleaseProcessId();
//
//            CampaignDelayReleaseViewDTO campaignDelayReleaseViewDTO = new CampaignDelayReleaseViewDTO();
//            campaignDelayReleaseViewDTO.setDelayReleaseProcessStatus(BrandCampaignProcessStatusEnum.APPROVE_ING.getCode());
//            campaignDelayReleaseViewDTO.setDelayReleaseProcessId(delayReleaseProcessId);
//
//            CampaignInquiryLockViewDTO campaignInquiryLockViewDTO = new CampaignInquiryLockViewDTO();
//            campaignInquiryLockViewDTO.setCampaignDelayReleaseViewDTO(campaignDelayReleaseViewDTO);
//
//            updateCampaignViewDTO.setCampaignInquiryLockViewDTO(campaignInquiryLockViewDTO);
//            updateList.add(updateCampaignViewDTO);
//        }
//        campaignUpdatePartAbility.handle(serviceContext, CampaignBatchAbilityParam.builder().abilityTargets(updateList).build());
//        return null;
//    }


//    private void dealDelayLockProcessInstance(ServiceContext serviceContext, List<BizCampaignAutoReleaseWorkflowParam> bizCampaignAutoReleaseWorkflowParams, String creatorId, String reason) {
//        //按照售卖分组汇总.优化申请流程数
//        Map<Long, List<BizCampaignAutoReleaseWorkflowParam>> saleGroupToParamMap = bizCampaignAutoReleaseWorkflowParams.stream()
//                .collect(Collectors.groupingBy(bizCampaignAutoReleaseWorkflowParam -> bizCampaignAutoReleaseWorkflowParam.getSaleGroupInfoViewDTO().getSaleGroupId()));
//        List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupViewDTOS = resourcePackageRepository.getSaleGroupList(serviceContext
//                , ResourcePackageQueryViewDTO.builder().saleGroupIdList(Lists.newArrayList(saleGroupToParamMap.keySet())).build(),
//                ResourcePackageQueryOption.builder().needSetting(Boolean.FALSE).needProduct(Boolean.FALSE).needInquiryPriority(Boolean.FALSE).build());
//        Map<Long, ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupViewDTOMap = Maps.newHashMap();
//        if (org.apache.commons.collections.CollectionUtils.isNotEmpty(resourcePackageSaleGroupViewDTOS)) {
//            resourcePackageSaleGroupViewDTOMap = resourcePackageSaleGroupViewDTOS.stream().collect(Collectors.toMap(ResourcePackageSaleGroupViewDTO::getId, Function.identity()));
//        }
//
//        Map<Long, ResourcePackageSaleGroupViewDTO> finalResourcePackageSaleGroupViewDTOMap = resourcePackageSaleGroupViewDTOMap;
//        saleGroupToParamMap.keySet().forEach(saleGroupId -> {
//            CampaignInventoryAutoReleaseQueryViewDTO campaignInventoryAutoReleaseQueryViewDTO = new CampaignInventoryAutoReleaseQueryViewDTO();
//            campaignInventoryAutoReleaseQueryViewDTO.setCreatorId(creatorId);
//            campaignInventoryAutoReleaseQueryViewDTO.setReason(reason);
//            List<CampaignViewDTO> campaignViewDTOS = saleGroupToParamMap.get(saleGroupId).stream().map(BizCampaignAutoReleaseWorkflowParam::getCampaignViewDTO).collect(Collectors.toList());
//            Map<String, String> initDataMap = campaignBuildBPMSParamsForAutoReleaseDelayLockAbility.handle(serviceContext, CampaignBuildBPMSParamsForAutoReleaseDelayLockAbilityParam.builder()
//                    .campaignViewDTOList(campaignViewDTOS)
//                    .campaignGroupViewDTO(saleGroupToParamMap.get(saleGroupId).get(0).getCampaignGroupViewDTO())
//                    .campaignInventoryAutoReleaseQueryViewDTO(campaignInventoryAutoReleaseQueryViewDTO)
//                    .finalResourcePackageSaleGroupViewDTOMap(finalResourcePackageSaleGroupViewDTOMap).build()
//            );
//            String title = new StringBuilder().append("分组-").append(saleGroupId)
//                    .append(finalResourcePackageSaleGroupViewDTOMap.containsKey(saleGroupId) ? finalResourcePackageSaleGroupViewDTOMap.get(saleGroupId).getName() : "")
//                    .append("-锁量延期流程").toString();
//            String titleEn = "Brand OneBP Campaign DelayLock Apply";
//            RogerLogger.info("提起BPMS审批流 计划 {} 请求参数 {}", saleGroupToParamMap.get(saleGroupId).get(0).getCampaignViewDTO().getId(), initDataMap);
//            String processId = bpmsRepository.startProcessInstance(title, titleEn, campaignInventoryAutoReleaseQueryViewDTO.getCreatorId(), initDataMap, BpmsProcessCodeEnum.CAMPAIGN_DELAY_LOCK_APPLY);
//            //设置流程ID
//            bizCampaignAutoReleaseWorkflowParams.forEach(bizCampaignAutoReleaseWorkflowParam -> {
//                if (saleGroupId.equals(bizCampaignAutoReleaseWorkflowParam.getSaleGroupInfoViewDTO().getSaleGroupId())) {
//                    CampaignViewDTO campaignViewDTO = bizCampaignAutoReleaseWorkflowParam.getCampaignViewDTO();
//
//                    CampaignInquiryLockViewDTO campaignInquiryLockViewDTO =
//                            Optional.ofNullable(campaignViewDTO.getCampaignInquiryLockViewDTO()).orElse(new CampaignInquiryLockViewDTO());
//                    campaignViewDTO.setCampaignInquiryLockViewDTO(campaignInquiryLockViewDTO);
//
//                    CampaignDelayReleaseViewDTO campaignDelayReleaseViewDTO =
//                            Optional.ofNullable(campaignInquiryLockViewDTO.getCampaignDelayReleaseViewDTO()).orElse(new CampaignDelayReleaseViewDTO());
//                    campaignInquiryLockViewDTO.setCampaignDelayReleaseViewDTO(campaignDelayReleaseViewDTO);
//
//                    campaignDelayReleaseViewDTO.setDelayReleaseProcessId(processId);
//                }
//            });
//        });
//    }

//    /**
//     * 计划锁量延期申请回调
//     * @param serviceContext
//     * @param processViewDTO
//     */
//    public void delayLockProcess(ServiceContext serviceContext, CampaignDelayLockProcessViewDTO processViewDTO) {
//        // 查询计划
//        List<CampaignViewDTO> campaignTreeViewDTOList = campaignStructureQueryAbility.handle(serviceContext, CampaignStructureQueryAbilityParam.builder()
//                .queryOption(CampaignQueryOption.builder().needChildren(true).build())
//                .abilityTarget(CampaignQueryViewDTO.builder().campaignIds(processViewDTO.getCampaignIds()).build())
//                .build()
//        );
//        // 业务校验
//        campaignValidateForAutoReleaseDelayLockProcessAbility.handle(serviceContext, CampaignValidateForAutoReleaseDelayLockProcessAbilityParam.builder()
//                .processViewDTO(processViewDTO)
//                .campaignViewDTOList(campaignTreeViewDTOList).build()
//        );
//        // 更新结果
//        Map<Long, Date> lockExpireTimeMap = Maps.newHashMap();
//        for (CampaignViewDTO campaignViewDTO : campaignTreeViewDTOList) {
//            Date lockExpireTime = campaignCalculateLockExpireTimeForResetAbility.handle(serviceContext, CampaignLockExpireTimeRecalculateAbilityParam.builder()
//                    .abilityTarget(campaignViewDTO.getCampaignInquiryLockViewDTO())
//                    .campaignId(campaignViewDTO.getId()).build()
//            );
//            lockExpireTimeMap.put(campaignViewDTO.getId(), lockExpireTime);
//        }
//        List<CampaignViewDTO> updateCampaignViewDTOList = campaignUpdateForAutoReleaseDelayLockProcessAbility.handle(serviceContext, CampaignUpdateForAutoReleaseDelayLockProcessAbilityParam.builder()
//                .lockExpireTimeMap(lockExpireTimeMap)
//                .campaignDelayLockProcessViewDTO(processViewDTO)
//                .campaignViewDTOList(campaignTreeViewDTOList).build()
//        );
//        campaignUpdatePartAbility.handle(serviceContext, CampaignBatchAbilityParam.builder().abilityTargets(updateCampaignViewDTOList).build());
//    }

    public Response batchOptimizeConfig(ServiceContext serviceContext, List<Long> campaignIdList, CampaignRealTimeOptimizeViewDTO campaignRealTimeOptimizeViewDTO) {
        BusinessAbilityRouteContext businessAbilityRouteContext = BusinessAbilityRouteContext.builder().specifiedBusinessAbilityCodes(Lists.newArrayList(RealTimeOptimizeBusinessAbility.ABILITY_CODE)).build();
        CampaignRealTimeBatchOperateResultViewDTO resultViewDTO = AbilityInvoker.invoke(ICampaignRealTimeOptimizeSaveBusinessAbilityPoint.class, businessAbilityRouteContext,
                callback -> callback.invokeForRealTimeOptimizeBatchSave(serviceContext, campaignIdList, campaignRealTimeOptimizeViewDTO));

        String msg = String.format("本次勾选%s个计划，成功操作%s个计划切换为本次选择的模式。",campaignIdList.size(), resultViewDTO.getOperateSuccessIds().size());
        if (CollectionUtils.isNotEmpty(resultViewDTO.getUnSupportFailIds())
                || CollectionUtils.isNotEmpty(resultViewDTO.getValidateFailIds())
                || CollectionUtils.isNotEmpty(resultViewDTO.getOperateFailIds())) {
            msg += "其中";
            if (CollectionUtils.isNotEmpty(resultViewDTO.getUnSupportFailIds())) {
                msg += String.format("%s个计划不支持实时优选（计划id：%s）；", resultViewDTO.getUnSupportFailIds().size(), StringUtils.join(resultViewDTO.getUnSupportFailIds(), "、"));
            }
            if (CollectionUtils.isNotEmpty(resultViewDTO.getValidateFailIds())) {
                msg += String.format("%s个计划当前不支持添加智能推荐人群或设置错误（计划id：%s）；", resultViewDTO.getValidateFailIds().size(), StringUtils.join(resultViewDTO.getValidateFailIds(), "、"));
            }
            if (CollectionUtils.isNotEmpty(resultViewDTO.getOperateFailIds())) {
                msg += String.format("%s个计划系统操作失败（计划id：%s）；", resultViewDTO.getOperateFailIds().size(), StringUtils.join(resultViewDTO.getOperateFailIds(), "、"));
            }
            return Response.failure(OPERATION_FAILED.getErrCode(), msg);
        }

        return Response.success(msg);
    }


    /**
     * 保存实时优选信息
     *
     * @param serviceContext
     * @param realTimeOptimizeInfoViewDTO
     */
    public void saveRealTimeOptimizeInfo(ServiceContext serviceContext, CampaignRealTimeOptimizeInfoViewDTO realTimeOptimizeInfoViewDTO) {
        BusinessAbilityRouteContext businessAbilityRouteContext = BusinessAbilityRouteContext.builder().specifiedBusinessAbilityCodes(Lists.newArrayList(RealTimeOptimizeBusinessAbility.ABILITY_CODE)).build();
        AbilityInvoker.invoke(ICampaignRealTimeOptimizeSaveBusinessAbilityPoint.class, businessAbilityRouteContext,
                callback -> callback.invokeForRealTimeOptimizeSave(serviceContext, realTimeOptimizeInfoViewDTO));
    }

    /**
     * tanx-deal变更通知
     * @param context
     * @param campaignDealNoticeViewDTO
     */
    public void tanxdealChangeNotice(ServiceContext context, CampaignDealNoticeViewDTO campaignDealNoticeViewDTO){
        AssertUtil.notNull(campaignDealNoticeViewDTO, "参数不能为空");
        AssertUtil.notNull(campaignDealNoticeViewDTO.getMemberId(), "memberId不能为空");
        AssertUtil.notNull(campaignDealNoticeViewDTO.getSubCampaignId(), "计划ID不能为空");
        CampaignDealMsgViewDTO campaignDealMsgViewDTO = buildCampaignDealMsgViewDTO(context, campaignDealNoticeViewDTO);
        bizCampaignMessageWorkflow.tanxdealChangeNotice(context, campaignDealMsgViewDTO);
    }

    /**
     * tanx-deal打底周期变更通知
     * @param context
     * @param campaignDealNoticeViewDTO
     */
    public void tanxdealBottomDateChange(ServiceContext context, CampaignDealNoticeViewDTO campaignDealNoticeViewDTO){
        if (campaignDealNoticeViewDTO == null || CollectionUtils.isEmpty(campaignDealNoticeViewDTO.getBottomDays())) {
            return;
        }
        AssertUtil.notNull(campaignDealNoticeViewDTO.getMemberId(), "memberId不能为空");
        AssertUtil.notNull(campaignDealNoticeViewDTO.getSubCampaignId(), "计划ID不能为空");
        CampaignDealMsgViewDTO campaignDealMsgViewDTO = buildCampaignDealMsgViewDTO(context, campaignDealNoticeViewDTO);
        bizCampaignMessageWorkflow.bottomDateChangeNotice(context, campaignDealMsgViewDTO);
    }

    /**
     * tanxdeal变更-订单计划数据补全，构建通知消息体
     * @param context
     * @param campaignDealNoticeViewDTO
     * @return
     */
    private CampaignDealMsgViewDTO buildCampaignDealMsgViewDTO(ServiceContext context, CampaignDealNoticeViewDTO campaignDealNoticeViewDTO) {
        // 计划数据补全
        context = ServiceContextUtil.buildServiceContextForSceneId(campaignDealNoticeViewDTO.getMemberId(), ServiceContextUtil.getSceneId(BizCodeEnum.BRANDONEBP.getBizCode()));
        CampaignViewDTO campaignTree = getCampaignInfoByOption(context, campaignDealNoticeViewDTO.getSubCampaignId(), CampaignQueryOption.builder().needCampaignTree(true).build());
        AssertUtil.notNull(campaignTree, "计划不存在");
        ServiceContextUtil.reAssignServiceContext(context,campaignTree.getSceneId());
        CampaignGroupViewDTO dbCampaignGroup = campaignGroupRepository.getCampaignGroup(context, campaignTree.getCampaignGroupId());
        AssertUtil.notNull(dbCampaignGroup, "订单不存在");
        return campaignMessageViewConverter.converterFrom(campaignDealNoticeViewDTO, dbCampaignGroup, campaignTree);
    }


    /**
     * 部分修改计划定向
     * @param serviceContext
     * @param campaignViewDTO
     * @param updateSubCampaign
     * @return
     */
    public SingleResponse<Long> updateCampaignTargetPart(ServiceContext serviceContext,CampaignViewDTO campaignViewDTO, boolean updateSubCampaign){
        //1. 构建处理参数
        CampaignQueryOption option = CampaignQueryOption.builder().needFrequency(true).needTarget(true).needChildren(true).build();
        CampaignViewDTO dbCampaignViewDTO = this.getCampaignInfoByOption(serviceContext, campaignViewDTO.getId(),option);
        AssertUtil.notNull(dbCampaignViewDTO,"计划不存在");

        //商业能力挂载
        BusinessAbilityRouteContext businessAbilityRouteContext = BusinessAbilityRouteContext.builder().specifiedBusinessAbilityCodes(Lists.newArrayList(TargetBusinessAbility.ABILITY_CODE)).build();
        AbilityInvoker.invoke(ICampaignUpdateBusinessAbilityPoint.class, businessAbilityRouteContext,
                callback -> callback.invokeForCampaignTargetUpdatePart(serviceContext, campaignViewDTO,dbCampaignViewDTO,updateSubCampaign));
        return SingleResponse.of(campaignViewDTO.getId());
    }

    public void addCampaignAlgoControlCrowd(ServiceContext serviceContext, Long campaignId) {
        CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder().campaignIds(Lists.newArrayList(campaignId)).build();
        CampaignQueryOption queryOption = CampaignQueryOption.builder().needTarget(true).needCampaignTree(true).build();
        List<CampaignViewDTO> campaignTreeViewDTOList = campaignStructureQueryAbility.handle(serviceContext, CampaignStructureQueryAbilityParam.builder()
                .abilityTarget(campaignQueryViewDTO).queryOption(queryOption).build());
        if (CollectionUtils.isEmpty(campaignTreeViewDTOList)) {
            return;
        }
        CampaignViewDTO campaignTreeViewDTO = campaignTreeViewDTOList.get(0);
        // 挂载商业能力
        BusinessAbilityRouteContext businessAbilityRouteContext = BusinessAbilityRouteContext.builder()
                .specifiedBusinessAbilityCodes(Lists.newArrayList(MultiTargetDeliverBusinessAbility.ABILITY_CODE, RealTimeOptimizeBusinessAbility.ABILITY_CODE))
                .build();
        invokeAll(ICampaignAlgoControlCrowdAddBusinessAbilityPoint.class, businessAbilityRouteContext,
                callBack -> callBack.invokeForCampaignAlgoControlCrowdAdd(serviceContext, campaignTreeViewDTO));
    }

    /**
     * 计划添加adv
     * @param serviceContext
     * @param campaignId
     * @param advIds
     */
    public void bindAdv(ServiceContext serviceContext, Long campaignId,List<Long> advIds){
        //2. 构建处理参数
        BizCampaignAdvBindOrUnBindWorkflowParam campaignAdvParamDefinition = buildParamForBindOrUnBindEffectAdv(serviceContext, campaignId, advIds);
        //3. 绑定校验
        // 计划
        campaignValidateForBindAdvAbility.handle(serviceContext, CampaignValidateForBindOrUnBindAdvAbilityParam.builder()
                .abilityTarget(campaignAdvParamDefinition.getCampaignViewDTO()).build());
        // 订单状态
        campaignGroupStatusValidateForBindAdvAbility.handle(serviceContext, CampaignGroupStatusValidateForBindOrUnBindAdvAbilityParam.builder()
                .abilityTarget(campaignAdvParamDefinition.getCampaignGroupViewDTO()).build());
        CampaignAdvValidateAbilityParam advValidateAbilityParam = CampaignAdvValidateAbilityParam.builder()
                .abilityTargets(campaignAdvParamDefinition.getAdvertiserViewDTOList())
                .campaignViewDTO(campaignAdvParamDefinition.getCampaignViewDTO())
                .subCampaignViewDTOList(campaignAdvParamDefinition.getSubCampaignViewDTOList())
                .advIds(advIds).build();
        // adv有效性校验
        campaignAdvEffectiveValidateForBindAbility.handle(serviceContext, advValidateAbilityParam);
        // 唯一性校验
        campaignAdvUniqueValidateForBindAbility.handle(serviceContext, advValidateAbilityParam);
        // adv余额
        campaignAdvBalanceValidateAbility.handle(serviceContext, advValidateAbilityParam);

        //4. 拆分子计划
        BizCampaignWorkflowParam splitWorkflowParam = new BizCampaignWorkflowParam();
        splitWorkflowParam.setCampaignGroupViewDTO(campaignAdvParamDefinition.getCampaignGroupViewDTO());
        splitWorkflowParam.setProductViewDTO(campaignAdvParamDefinition.getProductViewDTO());
        splitWorkflowParam.setEffectAdvertiserViewDTOList(campaignAdvParamDefinition.getAdvertiserViewDTOList());
        List<CampaignViewDTO> subCampaignViewDTOList = this.splitSubCampaign(serviceContext, campaignAdvParamDefinition.getCampaignViewDTO(), null, splitWorkflowParam);
        //5. 保存子计划
        campaignAddAbility.handle(serviceContext, CampaignBatchAbilityParam.builder()
                .abilityTargets(subCampaignViewDTOList).campaignGroupId(campaignAdvParamDefinition.getCampaignViewDTO().getCampaignGroupId()).build());
        //6. 绑定后置处理
        campaignAdvUpdateForBindAbility.handle(serviceContext, CampaignAdvUpdateAbilityParam.builder().abilityTargets(subCampaignViewDTOList).build());
    }

    /**
     * 计划解绑adv
     * @param serviceContext
     * @param campaignId
     * @param advIds
     */
    public void unBindAdv(ServiceContext serviceContext, Long campaignId,List<Long> advIds){
        //1. 构建处理参数
        BizCampaignAdvBindOrUnBindWorkflowParam campaignAdvParamDefinition = buildParamForBindOrUnBindEffectAdv(serviceContext, campaignId, advIds);
        //3. 解绑校验
        // 订单状态
        campaignGroupStatusValidateForUnBindAdvAbility.handle(serviceContext, CampaignGroupStatusValidateForBindOrUnBindAdvAbilityParam.builder()
                .abilityTarget(campaignAdvParamDefinition.getCampaignGroupViewDTO()).build());
        // 校验计划
        campaignValidateForUnBindAdvAbility.handle(serviceContext, CampaignValidateForBindOrUnBindAdvAbilityParam.builder()
                .abilityTarget(campaignAdvParamDefinition.getCampaignViewDTO()).campaignGroupViewDTO(campaignAdvParamDefinition.getCampaignGroupViewDTO()).build());
        // adv余额
        campaignAdvBalanceValidateAbility.handle(serviceContext, CampaignAdvValidateAbilityParam.builder()
                .abilityTargets(campaignAdvParamDefinition.getAdvertiserViewDTOList()).build());

        //4. 过滤adv
        List<CampaignViewDTO> unBindCampaignList = campaignAdvParamDefinition.getCampaignViewDTO().getSubCampaignViewDTOList().stream().filter(e->advIds.contains(e.getCampaignEffectProxyViewDTO().getEffectAdvId())).collect(Collectors.toList());
        //5. 删除子计划
        campaignDeleteAbility.handle(serviceContext, CampaignBatchAbilityParam.builder().abilityTargets(unBindCampaignList).build());

        //6. 解绑后置处理
        campaignAdvUpdateForUnBindAbility.handle(serviceContext, CampaignAdvUpdateAbilityParam.builder()
                .abilityTargets(campaignAdvParamDefinition.getSubCampaignViewDTOList()).advIds(advIds).build());
    }

    private BizCampaignAdvBindOrUnBindWorkflowParam buildParamForBindOrUnBindEffectAdv(ServiceContext serviceContext, Long campaignId, List<Long> advIds) {
        AssertUtil.notNull(campaignId, "计划ID不能为空");
        AssertUtil.notEmpty(advIds, "adv不能为空");

        BizCampaignAdvBindOrUnBindWorkflowParam campaignAdvWorkflowParam = new BizCampaignAdvBindOrUnBindWorkflowParam();
        //db计划信息
        CampaignQueryViewDTO campaignQueryViewDTO = new CampaignQueryViewDTO();
        campaignQueryViewDTO.setCampaignIds(Lists.newArrayList(campaignId));
        List<CampaignViewDTO> campaignViewDTOList = campaignStructureQueryAbility.handle(serviceContext, CampaignStructureQueryAbilityParam.builder().abilityTarget(campaignQueryViewDTO)
                .queryOption(CampaignQueryOption.builder().needChildren(true).needTarget(true).build()).build());
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(campaignViewDTOList) , BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR,"计划不存在或已被删除");
        CampaignViewDTO dbCampaignViewDTO = campaignViewDTOList.get(0);
        campaignAdvWorkflowParam.setCampaignViewDTO(dbCampaignViewDTO);

        // 订单
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(serviceContext, dbCampaignViewDTO.getCampaignGroupId());
        AssertUtil.notNull(campaignGroupViewDTO, "订单不存在");
        campaignAdvWorkflowParam.setCampaignGroupViewDTO(campaignGroupViewDTO);

        //广告主
        List<EffectAdvertiserViewDTO> effectAdvertiserViewDTOS = effectAdvertiserRepository.findEffectAdvInnerList(serviceContext,advIds);
        AssertUtil.notEmpty(effectAdvertiserViewDTOS,"未查询到广告主，请检查后重试");
        campaignAdvWorkflowParam.setAdvertiserViewDTOList(effectAdvertiserViewDTOS);

        CampaignQueryViewDTO advBindCampaignQueryViewDTO = new CampaignQueryViewDTO();
        campaignQueryViewDTO.setAdvIds(advIds);
        campaignQueryViewDTO.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_TWO_CAMPAIGN.getCode());
        List<CampaignViewDTO> advHasBindSubCampainList = campaignStructureQueryAbility.handle(serviceContext, CampaignStructureQueryAbilityParam.builder().abilityTarget(advBindCampaignQueryViewDTO)
                .queryOption(CampaignQueryOption.builder().needTarget(true).build()).build());
        campaignAdvWorkflowParam.setSubCampaignViewDTOList(advHasBindSubCampainList);
        // 二级产品
        ProductViewDTO productViewDTO = productRepository.getProductById(dbCampaignViewDTO.getCampaignResourceViewDTO().getSspProductId());
        AssertUtil.notNull(productViewDTO, "二级产品不存在");
        campaignAdvWorkflowParam.setProductViewDTO(productViewDTO);

        return campaignAdvWorkflowParam;
    }

    public void mandatoryLockProcess(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO, String procInstId, BrandCampaignProcessStatusEnum result) {
        // 查询计划
        List<CampaignViewDTO> campaignTreeViewDTOs = campaignStructureQueryAbility.handle(serviceContext, CampaignStructureQueryAbilityParam.builder()
                .abilityTarget(CampaignQueryViewDTO.builder().campaignIds(inquiryOperateViewDTO.getCampaignIdList()).build())
                .queryOption(CampaignQueryOption.builder().needCampaignTree(true).build()).build());
        List<CampaignViewDTO> campaignViewDTOList = BizCampaignToolsHelper.getMandatoryLockCampaign(campaignTreeViewDTOs, inquiryOperateViewDTO.getCampaignIdList());

        //更新子计划流程信息
        if (CollectionUtils.isNotEmpty(campaignViewDTOList)) {
            List<CampaignViewDTO> updatedCampaignViewDTOList = campaignViewDTOList.stream().map(campaignViewDTO -> {
                CampaignViewDTO updatedCampaignViewDTO = new CampaignViewDTO();
                updatedCampaignViewDTO.setId(campaignViewDTO.getId());

                CampaignMandatoryLockViewDTO mandatoryLockViewDTO = new CampaignMandatoryLockViewDTO();
                mandatoryLockViewDTO.setMandatoryLockProcessStatus(result.getCode());
                mandatoryLockViewDTO.setMandatoryLockProcessId(procInstId);

                CampaignInquiryLockViewDTO campaignInquiryLockViewDTO = new CampaignInquiryLockViewDTO();
                campaignInquiryLockViewDTO.setCampaignMandatoryLockViewDTO(mandatoryLockViewDTO);

                updatedCampaignViewDTO.setCampaignInquiryLockViewDTO(campaignInquiryLockViewDTO);
                return updatedCampaignViewDTO;
            }).collect(Collectors.toList());
            campaignUpdatePartAbility.handle(serviceContext, CampaignBatchAbilityParam.builder().abilityTargets(updatedCampaignViewDTOList).build());
        }
    }

    /**
     * 新建/编辑交付型频控
     * 不区分场景
     *
     * @param serviceContext
     * @param frequencyViewDTO
     * @param campaignIds
     * @return
     */
    public Long saveDeliveredFrequency(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO, List<Long> campaignIds) {
        // 基础校验
        AssertUtil.notNull(frequencyViewDTO.getFreqName(), PARAM_ILLEGAL,"频控名称不能为空");
        AssertUtil.notNull(frequencyViewDTO.getFrequencyTarget(), PARAM_ILLEGAL,"保量性质不能为空");
        AssertUtil.notNull(frequencyViewDTO.getFrequencyRuleViewDTOList(),PARAM_ILLEGAL, "频控规则不能为空");
        // 1. 查询参数
        // 查询计划
        List<CampaignViewDTO> campaignTreeViewDTOList = Lists.newArrayList();
        if (CollectionUtils.isNotEmpty(campaignIds)) {
            CampaignQueryViewDTO campaignQueryViewDTO = new CampaignQueryViewDTO();
            campaignQueryViewDTO.setCampaignIds(campaignIds);
            campaignQueryViewDTO.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
            CampaignQueryOption campaignQueryOption = CampaignQueryOption.builder().needChildren(true).needFrequency(true).build();
            campaignTreeViewDTOList = campaignStructureQueryAbility.handle(serviceContext,CampaignStructureQueryAbilityParam.builder().abilityTarget(campaignQueryViewDTO).queryOption(campaignQueryOption).build());
            AssertUtil.assertTrue(CollectionUtils.isNotEmpty(campaignTreeViewDTOList), "计划不存在");
        }
        // 查询频控 和 频控与计划关联关系
        FrequencyViewDTO dbFrequency = null;
        FrequencyRefViewDTO dbFrequencyRef = null;
        if (frequencyViewDTO.getId() != null) {
            dbFrequency = bizFrequencyAbility.getFrequencyById(serviceContext, frequencyViewDTO.getId());
            AssertUtil.notNull(dbFrequency, "频控信息不存在");
            dbFrequencyRef = bizFrequencyAbility.findFrequencyRefByFreqId(serviceContext, frequencyViewDTO.getId(), BrandFrequencyBizTypeEnum.CAMPAIGN);
        }

        // 业务校验
        bizFrequencyAbility.validateSaveDeliveredFrequency(serviceContext, frequencyViewDTO, campaignTreeViewDTOList, dbFrequencyRef, dbFrequency);
        // 保存
        return doSaveDeliveredFrequency(serviceContext, frequencyViewDTO, campaignTreeViewDTOList, dbFrequencyRef, dbFrequency);
    }

    public void orderDooh(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO){
        //查订单的二级计划
        CampaignQueryViewDTO queryViewDTO = new CampaignQueryViewDTO();
        queryViewDTO.setCampaignGroupId(campaignGroupViewDTO.getId());
        queryViewDTO.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_TWO_CAMPAIGN.getCode());
        RogerLogger.info("orderDooh queryViewDTO:{}", JSON.toJSONString(queryViewDTO));
        List<CampaignViewDTO> campaignViewDTOList = campaignStructureQueryAbility.handle(serviceContext,
                CampaignStructureQueryAbilityParam.builder()
                        .abilityTarget(queryViewDTO)
                        .queryOption(new CampaignQueryOption()).build());
        if(CollectionUtils.isEmpty(campaignViewDTOList)) {
            return;
        }
        // AssertUtil.assertTrue(CollectionUtils.isNotEmpty(campaignViewDTOList), "订单无计划信息");
        List<CampaignViewDTO> doohCampaignList = campaignViewDTOList.stream().filter(e-> BizCampaignToolsHelper.isDoohCampaign(e.getCampaignResourceViewDTO().getSspProductLineId())).collect(Collectors.toList());
        //没有天攻的计划直接返回
        if(CollectionUtils.isEmpty(doohCampaignList)){
            return;
        }
        //天攻计划目前真实使用场景，一个订单下只有一个，代码兼容多个
        for(CampaignViewDTO campaignViewDTO:doohCampaignList){
            DoohCampaignViewDTO doohCampaignViewDTO = doohRepository.getCampaignById(campaignViewDTO.getCampaignDoohViewDTO().getDoohCampaignId());
            //天攻计划如果没下单，则通知下单，如果是百灵改单状态，天攻无需重复下单，改单场景下，天攻的取消订单操作由于会直接释量，所以放到了释量的接口里
            if(doohCampaignViewDTO.getStatus().equals(DspPlanScheduleStateEnum.LOCKEDSUCCESS.getCode())){
                doohRepository.order(campaignViewDTO.getCampaignDoohViewDTO().getDoohCampaignId());
            }
        }
    }

    private Long doSaveDeliveredFrequency(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO, List<CampaignViewDTO> campaignTreeViewDTOList, FrequencyRefViewDTO dbFrequencyRef, FrequencyViewDTO dbFrequency) {
        // 新增场景
        if (frequencyViewDTO.getId() == null) {
            return bizFrequencyAbility.addFrequency(serviceContext, frequencyViewDTO, campaignTreeViewDTOList, null);
        }

        // 更新场景
        // 需要删除不再本次中的campaign ref，同时交付型计划新建独立频控(本次没有关联计划时，清空之前所有ref)
        List<Long> deletedCampaignIds = bizFrequencyAbility.deleteOtherUnionFrequencyCampaignRef(serviceContext, dbFrequencyRef, campaignTreeViewDTOList);
//        if (CollectionUtils.isNotEmpty(deletedCampaignIds)) {
//            CampaignQueryViewDTO query = new CampaignQueryViewDTO();
//            query.setCampaignIds(deletedCampaignIds);
//            //一级计划
//            query.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
//            CampaignQueryOption campaignQueryOption = CampaignQueryOption.builder().needChildren(true).build();
//            List<CampaignViewDTO> deleteCampaignViewDTOList = bizCampaignAbility.getCampaignInfoListByOption(serviceContext,query, campaignQueryOption);
//            // 添加独立频控
//            bizFrequencyAbility.addAntiUnionFrequency(serviceContext, dbFrequency, deleteCampaignViewDTOList);
//        }
        // 执行更新
        bizFrequencyAbility.updateFrequency(serviceContext, frequencyViewDTO, dbFrequency, campaignTreeViewDTOList, null);

        return frequencyViewDTO.getId();
    }

    public void frequencySwitch(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO) {
        AssertUtil.assertTrue(Objects.nonNull(frequencyViewDTO.getId()),
                BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR,"频控ID不能为空");
        FrequencyViewDTO dbFrequencyViewDTO = bizFrequencyAbility.getFrequencyById(serviceContext, frequencyViewDTO.getId());
        AssertUtil.notNull(dbFrequencyViewDTO, "频控信息不存在");
        // 校验
        bizFrequencyAbility.validateFrequencySwitch(frequencyViewDTO, dbFrequencyViewDTO);
        // 更新
        bizFrequencyAbility.updateFrequencyOnlineStatus(serviceContext, frequencyViewDTO, dbFrequencyViewDTO);
    }


    public void updateCampaignCastDate(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {

        CampaignQueryOption option = CampaignQueryOption.builder().needFrequency(false).needTarget(true).needChildren(true).build();
        CampaignViewDTO  dbCampaignViewDTO = this.getCampaignInfoByOption(serviceContext,campaignViewDTO.getId(),option);
        // 判断计划是否已经开始锁量，则不允许修改投放时间
        campaignOperateDistLockGetAbility.handle(serviceContext, CampaignOperateDistLockAbilityParam.builder().abilityTargets(Lists.newArrayList(dbCampaignViewDTO.getId())).build());
        //如果开始时间和结束时间和库里时间一致，则啥也不需要操作
        if(BrandDateUtil.isSameDay(campaignViewDTO.getStartTime(),dbCampaignViewDTO.getStartTime())
                &&BrandDateUtil.isSameDay(BrandDateUtil.getMaxDate(campaignViewDTO.getEndTime()),dbCampaignViewDTO.getEndTime())
        ){
            return ;
        }
        campaignViewDTO.setEndTime(BrandDateUtil.getMaxDate(campaignViewDTO.getEndTime()));
        //校验时间是否合法
        campaignCastDateValidateForUpdateAbility.handle(serviceContext, CampaignUpdateCastDateAbilityParam.builder().abilityTarget(campaignViewDTO).dbCampaignViewDTO(dbCampaignViewDTO).build());
        //校验计划是否可以修改投放时间
        campaignUpdateJudgeForUpdateCampaignAbility.handle(serviceContext, CampaignUpdateAbilityParam.builder().abilityTarget(campaignViewDTO).dbCampaignViewDTO(dbCampaignViewDTO).build());
        //校验天攻的计划是否可以修改周期
        campaignDoohValidateAbility.handle(serviceContext, buildCampaignDoohAbilityParam(serviceContext,dbCampaignViewDTO));

        //更新一级计划属性
        campaignInitForUpdateCastDateAbility.handle(serviceContext,CampaignUpdateCastDateAbilityParam.builder().abilityTarget(campaignViewDTO).dbCampaignViewDTO(dbCampaignViewDTO).startTime(campaignViewDTO.getStartTime()).endTime(campaignViewDTO.getEndTime()).build());
        campaignRepository.updateCampaignPart(serviceContext,campaignViewDTO);

        CampaignViewDTO  afterUpdateCampaignViewDTO = this.getCampaignInfoByOption(serviceContext,campaignViewDTO.getId(),option);

        //是否需要重新拆分二级计划
        Boolean needSplit = campaignSplitSubCheckForUpdateCastDateAbility.handle(serviceContext, CampaignUpdateCastDateAbilityParam.builder().abilityTarget(campaignViewDTO).dbCampaignViewDTO(dbCampaignViewDTO).build());
        if(needSplit){
            //重新拆分
            reSplitSubCampaign(serviceContext, afterUpdateCampaignViewDTO,dbCampaignViewDTO);
        }else{
            dbCampaignViewDTO.getSubCampaignViewDTOList().forEach(item->{
                campaignInitForUpdateCastDateAbility.handle(serviceContext,CampaignUpdateCastDateAbilityParam.builder().abilityTarget(item).dbCampaignViewDTO(item).startTime(campaignViewDTO.getStartTime()).endTime(campaignViewDTO.getEndTime()).build());
            });
            campaignRepository.updateCampaignPart(serviceContext,dbCampaignViewDTO.getSubCampaignViewDTOList());
        }
        // 后置处理
        bizCampaignCommandWorkflowExt.afterForUpdateCastDate(serviceContext, dbCampaignViewDTO, campaignViewDTO);
    }

    @Nullable
    private Void reSplitSubCampaign(ServiceContext serviceContext,CampaignViewDTO afterUpdateCampaignViewDTO,CampaignViewDTO dbCampaignViewDTO) {

        BizCampaignWorkflowParam campaignWorkflowParam =bizCampaignCommandWorkflowExt.buildParamForAddOrUpdate(serviceContext, dbCampaignViewDTO);
        BizCampaignSplitAbilityParam splitParamExt = BizCampaignSplitAbilityParam.builder()
            .resourcePackageProductViewDTO(campaignWorkflowParam.getPackageProductViewDTO())
            .productViewDTO(campaignWorkflowParam.getProductViewDTO())
            .showmaxCrowdList(campaignWorkflowParam.getShowmaxCrowdList())
            .campaignGroupViewDTO(campaignWorkflowParam.getCampaignGroupViewDTO())
            .build();

        Boolean needSplit =  runAbilitySpi(BizCampaignSplitSpi.class,
            extension->extension.diffForSplit(serviceContext,afterUpdateCampaignViewDTO, dbCampaignViewDTO, splitParamExt), BizCampaignSplitSpi.getSplitSpiCode(dbCampaignViewDTO,splitParamExt.getResourcePackageProductViewDTO()));
        if(!needSplit){
            return null;
        }
        List<CampaignViewDTO> subCampaignViewDTOList = splitSubCampaign(serviceContext, afterUpdateCampaignViewDTO, dbCampaignViewDTO, campaignWorkflowParam);
        List<CampaignViewDTO> addList = subCampaignViewDTOList.stream().filter(item->Objects.isNull(item.getId())).collect(Collectors.toList());
        BusinessAbilityRouteContext businessAbilityRouteContext = BusinessAbilityRouteContext.builder().packageSaleGroupViewDTO(campaignWorkflowParam.getPackageSaleGroupViewDTO())
                .productViewDTO(campaignWorkflowParam.getProductViewDTO()).resourcePackageProductViewDTO(campaignWorkflowParam.getPackageProductViewDTO()).build();
        if(CollectionUtils.isNotEmpty(addList)){
            for (CampaignViewDTO subCampaignViewDTO : addList) {
                invokeAll(ICampaignAddBusinessAbilityPoint.class, businessAbilityRouteContext,
                    callBack -> callBack.invokeForCampaignAdd(serviceContext,subCampaignViewDTO, businessAbilityRouteContext));
            }
            campaignAddAbility.handle(serviceContext, CampaignBatchAbilityParam.builder().abilityTargets(addList).campaignGroupId(campaignWorkflowParam.getCampaignGroupViewDTO().getId()).build());
            invokeAll(ICampaignAddBusinessAbilityPoint.class, businessAbilityRouteContext,
                callBack -> callBack.invokeForAfterCampaignAdd(serviceContext, addList, businessAbilityRouteContext));
        }
        List<CampaignViewDTO> updateList = subCampaignViewDTOList.stream().filter(item->Objects.nonNull(item.getId())).collect(Collectors.toList());
        if(CollectionUtils.isNotEmpty(updateList)){
            updateList.stream().filter(item -> BizCampaignToolsHelper.isAllHistory(item)
                    && BrandDateUtil.isBefore(item.getEndTime(),BrandDateUtil.getCurrentTime()))
                .forEach(item->{
                    item.setStartTime(null);
                    item.setEndTime(null);
                    //部分周期智能分配 修改投放日期清除预定
                    if (BrandCampaignInquiryAssignTypeEnum.PERIOD_PART_INTELLIGENCE.getCode().equals(item.getCampaignInquiryLockViewDTO().getCampaignInquiryPolicyViewDTO().getInquiryAssignType())) {
                        item.getCampaignInquiryLockViewDTO().getCampaignInquiryPolicyViewDTO().setSchedulePolicyList(Lists.newArrayList());
                    }
                });
            for (CampaignViewDTO subCampaignViewDTO : updateList) {
                invokeAll(ICampaignUpdateBusinessAbilityPoint.class, businessAbilityRouteContext,
                    callBack -> callBack.invokeForCampaignUpdate(serviceContext,subCampaignViewDTO,
                        dbCampaignViewDTO, businessAbilityRouteContext));
            }
            campaignRepository.updateCampaignAll(serviceContext,updateList);
        }
        return null;
    }

    /**
     * 订单取消的计划后续操作
     *
     * @param serviceContext
     * @param campaignGroupViewDTO
     */
    public void handleAfterCancelCampaignGroup(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO) {
        List<CampaignViewDTO> campaignTreeList = getCampaignTreeByCampaignGroupId(serviceContext, campaignGroupViewDTO.getId());
        // 停止并释量计划
        bizCampaignInventoryWorkflow.stopAndReleaseCampaign(serviceContext, campaignTreeList);
        // 解绑adv
        bizCampaignCommandWorkflowExt.handleAfterCancelCampaignGroup(serviceContext, campaignGroupViewDTO, campaignTreeList);
    }

    private List<CampaignViewDTO> getCampaignTreeByCampaignGroupId(ServiceContext serviceContext, Long campaignGroupId) {
        CampaignQueryViewDTO campaignQueryViewDTO = new CampaignQueryViewDTO();
        campaignQueryViewDTO.setCampaignGroupId(campaignGroupId);
        campaignQueryViewDTO.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
        CampaignQueryOption queryOption = new CampaignQueryOption();
        queryOption.setNeedChildren(true);

        return campaignStructureQueryAbility.handle(serviceContext,CampaignStructureQueryAbilityParam.builder()
                .abilityTarget(campaignQueryViewDTO).queryOption(queryOption).build());
    }

    /**
     * 订单停投后续操作
     * @param serviceContext
     * @param campaignGroupViewDTO
     * @return
     */
    public void handleAfterStopCampaignGroup(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO) {
        List<CampaignViewDTO> campaignTreeList = getCampaignTreeByCampaignGroupId(serviceContext, campaignGroupViewDTO.getId());
        // 停止并释量计划
        bizCampaignInventoryWorkflow.stopAndReleaseCampaign(serviceContext, campaignTreeList);
        // 其他处理
        bizCampaignCommandWorkflowExt.handleAfterStopCampaignGroup(serviceContext, campaignGroupViewDTO);
    }

    public void  onlineCampaigns(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, List<Long> onlineSaleGroupIds) {
        CampaignQueryViewDTO campaignQueryViewDTO = new CampaignQueryViewDTO();
        campaignQueryViewDTO.setCampaignGroupId(campaignGroupViewDTO.getId());
        campaignQueryViewDTO.setSaleGroupIds(onlineSaleGroupIds);
        List<CampaignViewDTO> campaignViewDTOList = campaignStructureQueryAbility.handle(serviceContext, CampaignStructureQueryAbilityParam.builder().abilityTarget(campaignQueryViewDTO).queryOption(new CampaignQueryOption()).build());
        List<CampaignViewDTO> filterList = campaignViewDTOList.stream().filter(item-> BrandCampaignStatusEnum.LOCK_SUCCESS.getCode().equals(item.getStatus())).collect(Collectors.toList());
        if(CollectionUtils.isEmpty(filterList)){
            RogerLogger.info("order online {} no need update  , return success",campaignGroupViewDTO.getId());
            return;
        }
        List<CampaignViewDTO> updateList = campaignInitForOnlineCampaignAbility.handle(serviceContext,
                CampaignForOnlineAbilityParam.builder().abilityTargets(filterList).campaignGroupViewDTO(campaignGroupViewDTO).onlineSaleGroupIds(onlineSaleGroupIds).build());
        campaignUpdatePartAbility.handle(serviceContext, CampaignBatchAbilityParam.builder().abilityTargets(updateList).build());

        RogerLogger.info("order online {}  update status  finish and size[{}], return success",campaignGroupViewDTO.getId(),updateList.size());
        Map<Long, SaleGroupInfoViewDTO> saleGroupInfoViewDTOMap = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList()
                .stream().collect(Collectors.toMap(SaleGroupInfoViewDTO::getSaleGroupId, v -> v, (a1, a2) -> a2));

        // 更新控量一级计划下的二级子计划询锁量信息
        Set<Long> boostParentCampaignIds = filterList.stream().filter(item -> BrandCampaignLevelEnum.LEVEL_TWO_CAMPAIGN.getCode().equals(item.getCampaignLevel())
                && BrandBoolEnum.BRAND_TRUE.getCode().equals(item.getCampaignGuaranteeViewDTO().getIsUnionControlFlow())
                && BrandSaleTypeEnum.BOOST.getCode().equals(item.getCampaignSaleViewDTO().getSaleType())).map(item -> item.getCampaignGuaranteeViewDTO().getBudgetCampaignId()).collect(Collectors.toSet());
        RogerLogger.info("order online {}   boostParentCampaignIds finish",campaignGroupViewDTO.getId(), JSON.toJSONString(boostParentCampaignIds));
        if (CollectionUtils.isNotEmpty(boostParentCampaignIds)) {
            List<CampaignViewDTO> boostParentCampaignViewDTOList = campaignRepository.queryCampaignList(serviceContext, CampaignQueryViewDTO.builder().campaignIds(Lists.newArrayList(boostParentCampaignIds)).campaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode()).build());
            if (org.apache.commons.collections4.CollectionUtils.isEmpty(campaignViewDTOList)) {
                RogerLogger.info("cant find resetParentUnionControlInfo  {}", JSONObject.toJSONString(boostParentCampaignViewDTOList));
                return;
            }
            List<CampaignViewDTO> updateCampaignViewDTOList = campaignUnionControlForOnlineCampaignAbility.handle(serviceContext, CampaignForOnlineAbilityParam.builder().abilityTargets(boostParentCampaignViewDTOList).build());
            campaignRepository.updateCampaignPart(serviceContext, updateCampaignViewDTOList);
            RogerLogger.info("order online {} update   boostParentCampaignIds finish", campaignGroupViewDTO.getId());
        }

        // 订单上线处理逻辑
        List<CampaignViewDTO> confirmOrderList = filterList.stream().filter(item -> {
            Integer saleGroupSource = saleGroupInfoViewDTOMap.getOrDefault(item.getCampaignSaleViewDTO().getSaleGroupId(), new SaleGroupInfoViewDTO()).getSource();
            return MediaScopeEnum.SITE_OUT.getCode().equals(item.getCampaignResourceViewDTO().getSspMediaScope())
                    && BrandCampaignLevelEnum.LEVEL_TWO_CAMPAIGN.getCode().equals(item.getCampaignLevel())
                    && BrandSaleGroupSourceEnum.PACKAGE_PLATFORM.getCode().equals(saleGroupSource)
                    && (  BrandSaleTypeEnum.BOOST.getCode().equals(item.getCampaignSaleViewDTO().getSaleType())
                    ||  BrandSaleTypeEnum.PRESENT.getCode().equals(item.getCampaignSaleViewDTO().getSaleType()));
        }).collect(Collectors.toList());
        RogerLogger.info("order online {}  confirmOrderList  size {} ",campaignGroupViewDTO.getId(), confirmOrderList.size());
        if(CollectionUtils.isNotEmpty(confirmOrderList)){
            List<Long> conformCampaignIds =confirmOrderList.stream().map(item->item.getId()).collect(Collectors.toList());
            inventoryRepository.confirmOrder(serviceContext, confirmOrderList);
            RogerLogger.info("order online {}     confirmOrderList {} ",campaignGroupViewDTO.getId(), JSON.toJSONString(conformCampaignIds));
        }
        //发送订单计划上线事件
        fireCampaignMessageEvent(serviceContext,filterList,CampaignEventEnum.CAMPAIGN_GROUP_ONLINE.name());
    }

    public List<CampaignViewDTO> systemAssignCustomSchedule(ServiceContext serviceContext,CampaignViewDTO campaignViewDTO){
        List<CampaignViewDTO> resultList = Lists.newArrayList();
        try {
            CampaignViewDTO dbCampaignViewDTO = null;
            if(Objects.nonNull(campaignViewDTO.getId())){
                dbCampaignViewDTO = this.getCampaignInfoByOption(serviceContext, campaignViewDTO.getId(),
                        CampaignQueryOption.builder().needFrequency(true).needTarget(true).needChildren(true).build());
                AssertUtil.notNull(dbCampaignViewDTO, "计划不存在或已被删除");
            }
            //构建处理参数
            BizCampaignWorkflowParam workflowParam = bizCampaignCommandWorkflowExt.buildParamForAddOrUpdate(serviceContext, campaignViewDTO);
            //判断计划数据是否改变
            if(this.checkCampaignConsistency(serviceContext, workflowParam.getPackageProductViewDTO(),campaignViewDTO, dbCampaignViewDTO)){
                RogerLogger.info("计划数据前后一致，不需要进行操作");
                if(MediaScopeEnum.CROSS_SCOPE.getCode().equals(dbCampaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope())){
                    resultList.add(dbCampaignViewDTO);
                }else{
                    resultList.addAll(dbCampaignViewDTO.getSubCampaignViewDTOList());
                }
                return resultList;
            }
            // 商业能力显式挂载
            BusinessAbilityRouteContext businessAbilityRouteContext = BusinessAbilityRouteContext.builder()
                    .packageSaleGroupViewDTO(workflowParam.getPackageSaleGroupViewDTO())
                    .resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO())
                    .productViewDTO(workflowParam.getProductViewDTO()).build();
            //校验、初始化
            if(Objects.isNull(campaignViewDTO.getId())){
                bizCampaignCommandWorkflowExt.beforeForAdd(serviceContext, campaignViewDTO, workflowParam);
                invokeAll(ICampaignAddBusinessAbilityPoint.class, businessAbilityRouteContext,
                        callBack -> callBack.invokeForCampaignAdd(serviceContext, campaignViewDTO, businessAbilityRouteContext));
            }else{
                bizCampaignCommandWorkflowExt.beforeForUpdate(serviceContext, campaignViewDTO,dbCampaignViewDTO, workflowParam);
                CampaignViewDTO finalCampaignViewDTO = dbCampaignViewDTO;
                invokeAll(ICampaignUpdateBusinessAbilityPoint.class, businessAbilityRouteContext,
                        callBack -> callBack.invokeForCampaignUpdate(serviceContext,campaignViewDTO,finalCampaignViewDTO, businessAbilityRouteContext));
            }
            //4. 拆分子计划
            List<CampaignViewDTO> subCampaignViewDTOList = this.splitSubCampaign(serviceContext, campaignViewDTO,dbCampaignViewDTO, workflowParam);
            List<CampaignViewDTO> splitList = subCampaignViewDTOList.stream().filter(item->!BrandCampaignStatusEnum.DELETE.getCode().equals(item.getStatus())).collect(Collectors.toList());
            AssertUtil.assertTrue(CollectionUtils.isNotEmpty(splitList),"投放日期内无有效的计划，无法分配预算");
            campaignViewDTO.setSubCampaignViewDTOList(splitList);
            //由于下一步需要使用分配的spi，这里组装分配二级计划预算所需要的资源包金额相关参数
            CampaignPriceViewDTO resetCampaignPriceViewDTO = campaignPriceInitForAssignBudgetAbility.handle(serviceContext,CampaignPriceInitForAssignBudgetParam.builder().abilityTarget(campaignViewDTO).resourcePackageProductViewDTO(workflowParam.getPackageProductViewDTO()).build());
            //重新分配二级计划金额
            assignSubCampaignBudgetByCustom(serviceContext, campaignViewDTO, workflowParam.getCampaignGroupViewDTO(), resetCampaignPriceViewDTO);
            if(MediaScopeEnum.CROSS_SCOPE.getCode().equals( campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope())){
                resultList.add(campaignViewDTO);
            }else{
                resultList.addAll(splitList);
            }
            return resultList;
        } catch (Exception e) {
            //100. 计划保存，异常处理
            RogerLogger.error(String.format("BizCampaignCommandWorkflow.addCampaign，msg=%s","新建计划失败"),e);
            throw e;
        }
    }

    /**
     * 校验计划数据一致性
     * @param serviceContext
     * @param packageProductViewDTO
     * @param campaignViewDTO
     * @param dbCampaignViewDTO
     * @return true:一致，false:不一致
     */
    private boolean checkCampaignConsistency(ServiceContext serviceContext,com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO packageProductViewDTO,
                                             CampaignViewDTO campaignViewDTO, CampaignViewDTO dbCampaignViewDTO) {
        CampaignConsistencyCheckAbilityParam checkAbilityParam = CampaignConsistencyCheckAbilityParam.builder()
                .abilityTarget(campaignViewDTO).dbCampaignViewDTO(dbCampaignViewDTO).packageProductViewDTO(packageProductViewDTO).build();
        RuleCheckResultViewDTO priceCheckResultViewDTO = campaignPriceConsistencyCheckAbility.handle(serviceContext, checkAbilityParam);
        if(priceCheckResultViewDTO != null && BrandBoolEnum.BRAND_FALSE.getCode().equals(priceCheckResultViewDTO.getIsPass())){
            return false;
        }
        RuleCheckResultViewDTO castDateCheckResultViewDTO = campaignCastDateConsistencyCheckAbility.handle(serviceContext, checkAbilityParam);
        if(castDateCheckResultViewDTO != null && BrandBoolEnum.BRAND_FALSE.getCode().equals(castDateCheckResultViewDTO.getIsPass())){
            return false;
        }
        RuleCheckResultViewDTO budgetCheckResultViewDTO = campaignBudgetConsistencyCheckAbility.handle(serviceContext, checkAbilityParam);
        if(budgetCheckResultViewDTO != null && BrandBoolEnum.BRAND_FALSE.getCode().equals(budgetCheckResultViewDTO.getIsPass())){
            return false;
        }
        RuleCheckResultViewDTO crowdCheckResultViewDTO = campaignCrowdConsistencyCheckAbility.handle(serviceContext, checkAbilityParam);
        if(crowdCheckResultViewDTO != null && BrandBoolEnum.BRAND_FALSE.getCode().equals(crowdCheckResultViewDTO.getIsPass())){
            return false;
        }
        return true;
    }

    /**
     *
     * @param serviceContext
     * @param campaignGroupViewDTO
     * @return
     */
    public Response selfServiceOrder(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO) {
        Long campaignGroupId = campaignGroupViewDTO.getId();
        CartItemQueryViewDTO cartQueryViewDTO = new CartItemQueryViewDTO();
        cartQueryViewDTO.setCampaignGroupIds(Lists.newArrayList(campaignGroupId));
        List<CartItemViewDTO> cartViewDTOS = cartItemRepository.findCartList(serviceContext,cartQueryViewDTO);
        if(CollectionUtils.isEmpty(cartViewDTOS)){
            return null;
        }
        List<CampaignViewDTO> campaignViewDTOList = campaignStructureQueryAbility.handle(serviceContext,
                CampaignStructureQueryAbilityParam.builder()
                        .abilityTarget(CampaignQueryViewDTO.builder().cartItemIds(cartViewDTOS.stream().map(CartItemViewDTO::getId).collect(Collectors.toList())).build())
                        .queryOption(CampaignQueryOption.builder().needTarget(true).build())
                        .build());
        if(CollectionUtils.isEmpty(campaignViewDTOList)){
            return null;
        }
        // 计划绑定订单
        campaignBindCampaignGroupAbility.handle(serviceContext, CampaignBindCampaignGroupAbilityParam.builder().abilityTargets(campaignViewDTOList).campaignGroupViewDTO(campaignGroupViewDTO).build());
        // 更新计划onlineStatus
        campaignOnlineStatusUpdateAbility.handle(serviceContext, CampaignOnlineStatusUpdateAbilityParam.builder().abilityTargets(campaignViewDTOList).targetOnlineStatus(BrandCampaignOnlineStatusEnum.ONLINE.getCode()).build());

        List<Long> levelOneCampaignIds = campaignViewDTOList.stream().filter(item->BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode().equals(item.getCampaignLevel())).map(item->item.getId()).collect(Collectors.toList());
        //lock
        CampaignInquiryOperateViewDTO inquiryOperateViewDTO = new CampaignInquiryOperateViewDTO();
        inquiryOperateViewDTO.setOperateType(CampaignScheduleOperateTypeEnum.LOCK.getValue());
        inquiryOperateViewDTO.setCampaignIdList(levelOneCampaignIds);
        bizCampaignInventoryWorkflow.inventoryInquiryOrLock(serviceContext,inquiryOperateViewDTO);
        return Response.success();
    }


    /**
     *
     * @param serviceContext
     * @param campaignGroupViewDTO
     * @param resourcePackageSaleGroupViewDTOList
     * @return
     */
    public Response afterSelfServiceOrder(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupViewDTOList) {
        List<CampaignViewDTO> campaignViewDTOList = campaignStructureQueryAbility.handle(serviceContext,
                CampaignStructureQueryAbilityParam.builder()
                        .abilityTarget(CampaignQueryViewDTO.builder().campaignGroupId(campaignGroupViewDTO.getId()).build())
                        .queryOption(CampaignQueryOption.builder().needTarget(false).build())
                        .build());
        if(CollectionUtils.isEmpty(campaignViewDTOList)){
            return null;
        }
        List<CampaignViewDTO> updateList = Lists.newArrayList();
        resourcePackageSaleGroupViewDTOList.forEach(item ->{
            if(CollectionUtils.isEmpty(item.getDistributionRuleList())){
                return;
            }
            item.getDistributionRuleList().forEach(resourceDistributionRuleViewDTO -> {
                if(CollectionUtils.isEmpty(resourceDistributionRuleViewDTO.getResourcePackageProductList())){
                    return;
                }
                resourceDistributionRuleViewDTO.getResourcePackageProductList().forEach(packageProductViewDTO -> {
                    //找出SKU下的计划
                    List<CampaignViewDTO> filterCampaignViewList = campaignViewDTOList.stream().filter(campaignViewDTO -> campaignViewDTO.getCampaignSelfServiceViewDTO() != null
                            && campaignViewDTO.getCampaignSelfServiceViewDTO().getSkuId().equals(packageProductViewDTO.getSkuId())).collect(Collectors.toList());
                    if(CollectionUtils.isEmpty(filterCampaignViewList)){
                        return;
                    }
                    //资源包跨域和普通产品打平
                    List<com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO> resourcePackageProductViewDTOS = Lists.newArrayList();
                    resourcePackageProductViewDTOS.add(packageProductViewDTO);
                    if (CollectionUtils.isNotEmpty(packageProductViewDTO.getSubResourcePackageProductList())) {
                        resourcePackageProductViewDTOS.addAll(packageProductViewDTO.getSubResourcePackageProductList());
                    }

                    //按照SSP产品id更新
                    for(CampaignViewDTO campaignViewDTO : filterCampaignViewList){
                        Optional<com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO> optional = resourcePackageProductViewDTOS.stream().filter(resourcePackageProductViewDTOTemp-> campaignViewDTO.getCampaignResourceViewDTO().getSspProductId().equals(resourcePackageProductViewDTOTemp.getSspProductId())).findFirst();
                        if(!optional.isPresent()){
                            continue;
                        }
                        com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO  resourcePackageProductViewDTO= optional.get();

                        CampaignViewDTO updateCampaign = new CampaignViewDTO();
                        updateCampaign.setId(campaignViewDTO.getId());
                        updateCampaign.setCampaignLevel(campaignViewDTO.getCampaignLevel());

                        CampaignSaleViewDTO campaignSaleViewDTO = new CampaignSaleViewDTO();
                        updateCampaign.setCampaignSaleViewDTO(campaignSaleViewDTO);
                        updateCampaign.getCampaignSaleViewDTO().setCustomerTemplateId(item.getTemplateId());
                        updateCampaign.getCampaignSaleViewDTO().setResourcePackageProductId(resourcePackageProductViewDTO.getId());
                        updateCampaign.getCampaignSaleViewDTO().setSaleGroupId(item.getId());

                        // 设置回流渠道
                        CampaignMonitorViewDTO campaignMonitorViewDTO = new CampaignMonitorViewDTO();
                        updateCampaign.setCampaignMonitorViewDTO(campaignMonitorViewDTO);
                        campaignMonitorViewDTO.setProductDataChannel(item.getDataChannel());

                        updateList.add(updateCampaign);
                    }
                });
            });
        });
        if(CollectionUtils.isEmpty(updateList)){
            return Response.success();
        }
        campaignUpdatePartAbility.handle(serviceContext,CampaignBatchAbilityParam.builder().abilityTargets(updateList).build());
        if (BrandCampaignGroupSourceEnum.CART.getCode().equals(campaignGroupViewDTO.getSource())) {
            //重新触发上线
            fireCampaignMessageEvent(serviceContext,updateList,CampaignEventEnum.ONLINE.name());
        }
        return Response.success();
    }

    /**
     * 分配预算
     * @param campaignPriceViewDTOList
     */
    public List<CampaignViewDTO> assignSubCampaignBudget(ServiceContext context, List<CampaignPriceViewDTO> campaignPriceViewDTOList, List<CampaignViewDTO> fullCampaignViewDTOList, CampaignGroupViewDTO campaignGroup, CampaignPVAssignSceneEnum campaignPVAssignSceneEnum) {
        long times = System.currentTimeMillis();
        //历史周期预定量校验
        campaignHistoryBudgetValidateForCalculateCampaignAbility.handle(context, CampaignHistoryBudgetValidateAbilityParam.builder().abilityTargets(fullCampaignViewDTOList).campaignPriceViewDTOList(campaignPriceViewDTOList).build());

        //核心计算逻辑
        List<List<CampaignViewDTO>> resultLists = TaskStream
                .execute(campaignAssignBudgetTaskIdentifier, campaignPriceViewDTOList, (campaignPriceViewDTO, index) -> {
                    AssertUtil.assertTrue(campaignPriceViewDTO.getDiscountTotalMoney() != null && campaignPriceViewDTO.getDiscountTotalMoney() > 0, campaignPriceViewDTO.getCampaignId() + "计算后计划价格为0");
                    List<CampaignViewDTO> assignResultList = Lists.newArrayList();
                    for (CampaignViewDTO campaignViewDTO : fullCampaignViewDTOList) {
                        if (!campaignPriceViewDTO.getCampaignId().equals(campaignViewDTO.getId())) {
                            continue;
                        }
                        //如果锁量以及之后状态不重新分配
                        if (Constant.LOCK_AND_ING_CAMPAIGN_STATUS_LIST.contains(campaignViewDTO.getStatus())) {
                            assignResultList.add(campaignViewDTO);
                            continue;
                        }
                        assignResultList.addAll(ExtensionPointsFactory.runAbilitySpi(BizCampaignSplitSpi.class,
                                extension -> extension.assignSubCampaignBudget(context, campaignGroup, campaignPriceViewDTO, campaignViewDTO, campaignPVAssignSceneEnum), BizCampaignSplitSpi.getSplitSpiCode(campaignViewDTO, campaignPriceViewDTO)));
                    }
                    return assignResultList;
                })
                .commit()
                .getResultList();

        RogerLogger.info("assignBudget size {} time cost {} ms",campaignPriceViewDTOList.size(),System.currentTimeMillis()-times);

        //可进行计划询锁量的，更新计划为草稿状态
        List<CampaignViewDTO> resultList = Lists.newArrayList();
        resultLists.stream().forEach(item->{
            item.stream().filter(campaignViewDTO -> Constant.CAN_INQUIRY_LOCK_STATUS.contains(campaignViewDTO.getStatus()))
                    .forEach(v -> v.setStatus(BrandCampaignStatusEnum.NEW.getCode()));
            resultList.addAll(item);
        });
        return resultList;
    }

    /**
     * 二次校验计划预算
     * @param serviceContext
     * @param calculatedResult
     * @param workflowParam
     */
    public void reCheckCampaignBudget(ServiceContext serviceContext, CampaignGroupSaleGroupCalViewDTO calculatedResult, BizCampaignGroupCalculateWorkflowParam workflowParam){
        campaignTwoCptBudgetValidateForCalculateCampaignAbility.handle(serviceContext, CampaignCalculateAbilityParam.builder().abilityTarget(calculatedResult).campaignTreeList(workflowParam.getCampaignTreeViewDTOList()).build());
        campaignSingleMediaMarkingBoostBudgetValidateForCalculateCampaignAbility.handle(serviceContext, CampaignCalculateAbilityParam.builder().abilityTarget(calculatedResult).campaignGroupViewDTO(workflowParam.getCampaignGroupViewDTO()).saleGroupInfoViewDTO(workflowParam.getSaleGroupInfoViewDTO()).campaignTreeList(workflowParam.getCampaignTreeViewDTOList()).build());
    }

    /**
     * 发送计划通知事件
     * @param serviceContext
     * @param campaignList
     * @return
     */
    private void fireCampaignMessageEvent(ServiceContext serviceContext, List<CampaignViewDTO> campaignList,String domainEvent){
        for (CampaignViewDTO campaign : campaignList) {
            if(!BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode().equals(campaign.getCampaignLevel())){
                continue;
            }
            DomainMetaqMessageBodyContext msgBodyContext = DomainMetaqMessageBodyContext.builder()
                    .bizCode(serviceContext.getBizCode())
                    .domainType(DomainMessageTypeEnum.MAIN_CAMPAIGN)
                    .domainEvent(domainEvent)
                    .entityId(campaign.getId())
                    .memberId(serviceContext.getMemberId())
                    .build();
            messageAsyncSendAbility.handle(serviceContext, MessageAsyncSendAbilityParam.builder().abilityTarget(msgBodyContext).build());
        }
    }

    /**
     * 获取计划信息
     * @param serviceContext
     * @param id
     * @param option
     * @return
     */
    private CampaignViewDTO getCampaignInfoByOption(ServiceContext serviceContext,Long id,CampaignQueryOption option){
        CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder().campaignIds(Collections.singletonList(id)).build();
        List<CampaignViewDTO> dbCampaignViewDTOList = campaignStructureQueryAbility.handle(serviceContext,
                CampaignStructureQueryAbilityParam.builder().abilityTarget(campaignQueryViewDTO).queryOption(option).build());
        return CollectionUtils.isNotEmpty(dbCampaignViewDTOList) ? dbCampaignViewDTOList.get(0) : null;
    }

    public void updateCampaignOnlineStatus(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList, BrandCampaignOnlineStatusEnum targetOnlineStatusEnum) {
        if (CollectionUtils.isEmpty(campaignViewDTOList)) {
            return;
        }
        campaignOnlineStatusUpdateAbility.handle(serviceContext, CampaignOnlineStatusUpdateAbilityParam.builder()
                .abilityTargets(campaignViewDTOList).targetOnlineStatus(targetOnlineStatusEnum.getCode()).build());
        CampaignEventEnum campaignEventEnum = null;
        if (BrandCampaignOnlineStatusEnum.ONLINE.getCode().equals(targetOnlineStatusEnum.getCode())) {
            campaignEventEnum = CampaignEventEnum.ONLINE;
        }
        if (campaignEventEnum != null) {
            for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
                DomainMetaqMessageBodyContext msgBodyContext = DomainMetaqMessageBodyContext.builder()
                        .bizCode(serviceContext.getBizCode())
                        .domainType(DomainMessageTypeEnum.MAIN_CAMPAIGN)
                        .domainEvent(campaignEventEnum.name())
                        .entityId(campaignViewDTO.getId())
                        .memberId(campaignViewDTO.getMemberId())
                        .build();
                messageAsyncSendAbility.handle(serviceContext, MessageAsyncSendAbilityParam.builder().abilityTarget(msgBodyContext).build());
            }
        }
    }

    private CampaignAutoBuildForAutoAddCampaignAbilityParam buildParamForAutoAddCampaign(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO) {
        //如果没有指定售卖分组，查询订单下全部分组信息
        List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList();;
        AssertUtil.notEmpty(saleGroupInfoViewDTOList, "订单售卖分组不存在");
        Map<Long, SaleGroupInfoViewDTO> saleGroupInfoMap = saleGroupInfoViewDTOList.stream().collect(Collectors.toMap(SaleGroupInfoViewDTO::getSaleGroupId, Function.identity()));

        //资源包售卖分组
        ResourcePackageQueryViewDTO queryViewDTO = new ResourcePackageQueryViewDTO();
        List<Long> saleGroupIds = saleGroupInfoViewDTOList.stream().map(SaleGroupInfoViewDTO::getSaleGroupId).collect(Collectors.toList());
        queryViewDTO.setSaleGroupIdList(saleGroupIds);
        ResourcePackageQueryOption packageQueryOption = ResourcePackageQueryOption.builder().needProduct(true).needSetting(true).build();
        List<ResourcePackageSaleGroupViewDTO> saleGroups = resourcePackageRepository.getSaleGroupList(serviceContext, queryViewDTO, packageQueryOption);
        AssertUtil.notEmpty(saleGroups,"资源包售卖分组不存在");
        Map<Long, ResourcePackageSaleGroupViewDTO> packageSaleGroupMap = saleGroups.stream().collect(Collectors.toMap(ResourcePackageSaleGroupViewDTO::getId, e->e, (v1, v2)->v2));

        //售卖分组关联的二级产品
        List<com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO> resourcePackageProductViewDTOS = Lists.newArrayList();
        for(ResourcePackageSaleGroupViewDTO saleGroup : saleGroups){
            List<com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO> resourcePackageProductList = saleGroup.getDistributionRuleList().stream()
                    .flatMap(rule -> rule.getResourcePackageProductList().stream()).collect(Collectors.toList());
            resourcePackageProductViewDTOS.addAll(resourcePackageProductList);
        }
        AssertUtil.notEmpty(resourcePackageProductViewDTOS, "售卖分组资源位不存在");
        Map<Long, com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO> resourcePackageProductViewMap = resourcePackageProductViewDTOS.stream()
                .collect(Collectors.toMap(com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO::getId, e->e, (v1, v2)->v2));
        RogerLogger.info("effect.buildParamForAddOrUpdate.resourcePackageProductViewMap: {}", com.alibaba.securitysdk.fastjson.JSON.toJSONString(resourcePackageProductViewMap));

        //SSP二级产品
        List<Long> productIds = resourcePackageProductViewDTOS.stream().map(com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO::getSspProductId).collect(Collectors.toList());
        List<ProductViewDTO> productViewDTOS =  productRepository.getProductByIds(productIds);
        AssertUtil.notEmpty(productViewDTOS, "二级产品不存在");
        Map<Long, ProductViewDTO> productViewMap = productViewDTOS.stream().collect(Collectors.toMap(ProductViewDTO::getId,Function.identity(), (v1, v2)-> v2));

        return CampaignAutoBuildForAutoAddCampaignAbilityParam.builder().abilityTarget(campaignGroupViewDTO)
                .packageSaleGroupMap(packageSaleGroupMap).saleGroupInfoMap(saleGroupInfoMap)
                .packageProductViewMap(resourcePackageProductViewMap).sspProductMap(productViewMap).build();
    }

    private CampaignDoohAbilityParam buildCampaignDoohAbilityParam(ServiceContext serviceContext, CampaignViewDTO dbCampaignViewDTO){
        if(dbCampaignViewDTO != null && dbCampaignViewDTO.getCampaignDoohViewDTO() != null){
            Long packageProductId = Optional.ofNullable(dbCampaignViewDTO.getCampaignSaleViewDTO()).map(CampaignSaleViewDTO::getResourcePackageProductId).orElse(null);
            AssertUtil.notNull(packageProductId, "售卖分组资源位ID不存在");
            Long packageSaleGroupId = Optional.ofNullable(dbCampaignViewDTO.getCampaignSaleViewDTO()).map(CampaignSaleViewDTO::getSaleGroupId).orElse(null);
            AssertUtil.notNull(packageSaleGroupId,"售卖分组ID不允许为空");

            ResourcePackageQueryOption packageQueryOption = ResourcePackageQueryOption.builder().needProduct(true).needSetting(true).build();
            ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO = resourcePackageRepository.getSaleGroupById(serviceContext, packageSaleGroupId, packageQueryOption);
            AssertUtil.notNull(packageSaleGroupViewDTO,"资源包售卖分组不存在");

            com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO packageProductViewDTO = packageSaleGroupViewDTO.getDistributionRuleList().stream().flatMap(e -> e.getResourcePackageProductList().stream())
                    .filter(e -> e.getId().equals(packageProductId)).findFirst().orElse(null);
            AssertUtil.notNull(packageProductViewDTO, "售卖分组资源位不存在");

            AssertUtil.notNull(packageProductViewDTO.getSspProductId(),"二级产品ID不允许为空");
            ProductViewDTO productViewDTO = productRepository.getProductById(packageProductViewDTO.getSspProductId());
            AssertUtil.notNull(productViewDTO, "二级产品不存在");

            return CampaignDoohAbilityParam.builder().abilityTarget(dbCampaignViewDTO.getCampaignDoohViewDTO())
                    .campaignViewDTO(dbCampaignViewDTO).productViewDTO(productViewDTO).resourcePackageSaleGroupViewDTO(packageSaleGroupViewDTO).build();
        }
        return CampaignDoohAbilityParam.builder().build();
    }

}
