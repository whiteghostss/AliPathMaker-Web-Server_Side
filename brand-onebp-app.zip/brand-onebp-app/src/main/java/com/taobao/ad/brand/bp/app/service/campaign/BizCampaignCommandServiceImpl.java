package com.taobao.ad.brand.bp.app.service.campaign;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdScenarioViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignCrowdViewDTO;
import com.alibaba.ad.brand.dto.campaign.crowd.CampaignShowmaxCrowdViewDTO;
import com.alibaba.ad.brand.dto.campaign.price.CampaignPriceViewDTO;
import com.alibaba.ad.brand.dto.campaign.price.DayPriceViewDTO;
import com.alibaba.ad.brand.dto.campaign.realtime.CampaignRealTimeOptimizeViewDTO;
import com.alibaba.ad.brand.dto.frequency.FrequencyViewDTO;
import com.alibaba.ad.brand.sdk.constant.audience.field.BrandTargetTypeEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignProcessStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.setting.BrandCampaignSettingKeyEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupProcessStatusEnum;
import com.alibaba.ad.nb.ssp.constant.common.MediaScopeEnum;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.tool.lock.annotation.DistLock;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.app.interceptor.annotation.EnableOpLog;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignCommandWorkflow;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignInventoryWorkflow;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignQueryWorkflow;
import com.taobao.ad.brand.bp.app.workflow.tool.BizBatchImportWorkflow;
import com.taobao.ad.brand.bp.client.api.campaign.BizCampaignCommandService;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.*;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.CrowdViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportTaskViewDTO;
import com.taobao.ad.brand.bp.client.enums.SwitchEnum;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignScheduleOperateTypeEnum;
import com.taobao.ad.brand.bp.client.enums.common.BizBpmsProcessStatusEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.converter.campaign.CampaignViewPageConverter;
import com.taobao.ad.brand.bp.common.enums.BpmsProcessCodeEnum;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.config.AutoTestMemberDiamondConfig;
import com.taobao.ad.brand.bp.domain.config.SelfServiceTestMemberConfig;
import com.taobao.ad.brand.bp.domain.dmp.CrowdRepository;
import com.taobao.ad.brand.bp.domain.dooh.repository.DoohRepository;
import com.taobao.ad.brand.bp.domain.report.repository.ReportSyncTaskRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignShowmaxCrowdTagGetAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignTitleInitAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignTitleValidateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignUpdatePartAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.ssp.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_ILLEGAL;
import static com.taobao.ad.brand.bp.common.util.BrandDateUtil.DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_1;

/**
 * @Description: 计划操作服务
 * @Author: dongyang
 * @Date: 2023/3/3
 */
@HSFProvider(serviceInterface = BizCampaignCommandService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizCampaignCommandServiceImpl implements BizCampaignCommandService {

    private final AutoTestMemberDiamondConfig autoTestMemberDiamondConfig;
    private final SelfServiceTestMemberConfig selfServiceTestMemberConfig;

    private final CampaignRepository campaignRepository;
    private final CrowdRepository crowdRepository;
    private final ReportSyncTaskRepository reportSyncTaskRepository;
    private final ProductRepository productRepository;

    private final BizCampaignCommandWorkflow bizCampaignCommandWorkflow;
    private final BizCampaignQueryWorkflow bizCampaignQueryWorkflow;
    private final BizCampaignInventoryWorkflow bizCampaignInventoryWorkflow;
    private final BizBatchImportWorkflow bizBatchImportWorkflow;

    private final CampaignViewPageConverter campaignViewPageConverter;
    private final ICampaignUpdatePartAbility campaignUpdatePartAbility;
    private final ICampaignStructureQueryAbility campaignStructureQueryAbility;
    private final ICampaignTitleValidateAbility campaignTitleValidateAbility;
    private final ICampaignTitleInitAbility campaignTitleInitAbility;
    private final ICampaignShowmaxCrowdTagGetAbility campaignShowmaxCrowdTagGetAbility;

    private final DoohRepository doohRepository;


    @Override
    public MultiResponse<Long> addCampaign(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {
        CampaignViewDTO resultCampaignViewDTO = bizCampaignCommandWorkflow.addCampaign(serviceContext, campaignViewDTO);
        return MultiResponse.of(resultCampaignViewDTO.getId());
    }

    @Override
    public MultiResponse<Long> batchAddCampaign(ServiceContext context, List<CampaignViewDTO> campaignViewDTOList) {
        List<CampaignViewDTO> resultCampaignViewDTOList = bizCampaignCommandWorkflow.batchAddCampaign(context, campaignViewDTOList);
        List<Long> campaignIdList = Optional.ofNullable(resultCampaignViewDTOList).orElse(Lists.newArrayList()).stream().map(CampaignViewDTO::getId).collect(Collectors.toList());
        return MultiResponse.of(campaignIdList);
    }

    @Override
    public SingleResponse<Long> updateCampaign(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO) {
        return bizCampaignCommandWorkflow.updateCampaign(serviceContext,campaignViewDTO);
    }

    @Override
    public SingleResponse<String> updateCampaignNameWithResp(ServiceContext context, CampaignViewDTO campaignViewDTO) {
        // 【计划名称】1、长度<=50；2、拆分主计划名称不能重复
        AssertUtil.notNull(campaignViewDTO.getId(), "计划id必填");
        AssertUtil.assertTrue(Optional.ofNullable(campaignViewDTO.getTitle())
                .map(String::length).orElse(0) <= 100, PARAM_ILLEGAL, "计划名称长度小于等于100");

        CampaignViewDTO dbCampaignViewDTO = bizCampaignQueryWorkflow.getCampaignInfoByOption(context,campaignViewDTO.getId(),
                CampaignQueryOption.builder().needTarget(true).build());

        AssertUtil.notNull(dbCampaignViewDTO,"计划不存在");
        // 输入计划名为空则自动生成
        if (StringUtils.isEmpty(campaignViewDTO.getTitle())) {
            List<CampaignCrowdViewDTO> crowdViewDTOList = Optional.ofNullable(dbCampaignViewDTO.getCampaignCrowdScenarioViewDTO())
                    .map(CampaignCrowdScenarioViewDTO::getCampaignCrowdViewDTOList).orElse(Lists.newArrayList());
            if (CollectionUtils.isNotEmpty(crowdViewDTOList)) {
                List<Long> crowdIds = crowdViewDTOList.stream().map(CampaignCrowdViewDTO::getCrowdId).collect(Collectors.toList());
                List<CrowdViewDTO> dbCrowdViewDTOList = crowdRepository.queryCrowdByIds(context, crowdIds);
                Map<Long, String> crowdIdToNameMap = dbCrowdViewDTOList.stream()
                        .collect(Collectors.toMap(CrowdViewDTO::getCrowdId, CrowdViewDTO::getCrowdName,(v1,v2) -> v1));
                for (CampaignCrowdViewDTO crowdViewDTO : crowdViewDTOList) {
                    String crowdName = crowdIdToNameMap.get(crowdViewDTO.getCrowdId());
                    if (crowdName != null) {
                        crowdViewDTO.setCrowdName(crowdName);
                    }
                }
            }
            CampaignViewDTO updateCampaignViewDTO = campaignViewPageConverter.convertSelf(dbCampaignViewDTO);
            updateCampaignViewDTO.setTitle(null);

            ProductViewDTO productViewDTO = productRepository.getProductById(dbCampaignViewDTO.getCampaignResourceViewDTO().getSspProductId());
            AssertUtil.notNull(productViewDTO, "二级产品不存在");

            // 获取showmax人群信息
            List<CommonViewDTO> showmaxCrowdList = Lists.newArrayList();
            if (BizCampaignToolsHelper.isShowmaxCampaign(dbCampaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope(),
                    dbCampaignViewDTO.getCampaignResourceViewDTO().getSspProductLineId(), dbCampaignViewDTO.getCampaignResourceViewDTO().getSspCrossScene())) {
                Integer showmaxCrowdType = Optional.ofNullable(campaignViewDTO.getCampaignCrowdScenarioViewDTO()).map(CampaignCrowdScenarioViewDTO::getCampaignShowmaxCrowdViewDTO)
                        .map(CampaignShowmaxCrowdViewDTO::getShowmaxCrowdType).orElse(null);

                showmaxCrowdList = campaignShowmaxCrowdTagGetAbility.handle(context, CampaignShowmaxCrowdTagGetAbilityParam.builder()
                        .abilityTarget(showmaxCrowdType).campaignGroupId(dbCampaignViewDTO.getCampaignGroupId()).build());
            }
            String title = campaignTitleInitAbility.handle(context, CampaignTitleInitAbilityParam.builder().abilityTarget(campaignViewDTO)
                    .abilityTarget(campaignViewDTO).dbCampaignViewDTO(dbCampaignViewDTO).productViewDTO(productViewDTO).showmaxCrowdList(showmaxCrowdList).build());
            campaignViewDTO.setTitle(title);
        }
        campaignTitleValidateAbility.handle(context, CampaignTitleValidateAbilityParam.builder().abilityTarget(campaignViewDTO).build());
        campaignRepository.updateCampaignPart(context, campaignViewDTO);
        //天攻计划通知天攻更新名称
        if(BizCampaignToolsHelper.isDoohCampaign(dbCampaignViewDTO.getCampaignResourceViewDTO().getSspProductLineId())){
            doohRepository.updateCampaignName(dbCampaignViewDTO.getCampaignDoohViewDTO().getDoohCampaignId(), campaignViewDTO.getTitle());
        }
        return SingleResponse.of(campaignViewDTO.getTitle());
    }

    @Override
    @Deprecated
    public Response updateCampaignName(ServiceContext context, CampaignViewDTO campaignViewDTO) {
        // 【计划名称】1、必填，长度<=50；2、拆分主计划名称不能重复
        AssertUtil.notNull(campaignViewDTO.getId(), "计划id必填");
        AssertUtil.notNull(campaignViewDTO.getTitle(), "计划名称必填");
        AssertUtil.assertTrue(campaignViewDTO.getTitle().length() <= 100, "计划名称长度小于等于100");

        campaignTitleValidateAbility.handle(context, CampaignTitleValidateAbilityParam.builder().abilityTarget(campaignViewDTO).build());

        campaignRepository.updateCampaignPart(context,campaignViewDTO);
        return Response.success();
    }

    @Override
    public Response deleteCampaign(ServiceContext context, Long campaignId) {
        return bizCampaignCommandWorkflow.deleteCampaign(context,campaignId);
    }

    @Override
    public Response batchDeleteCampaign(ServiceContext context, CampaignBatchDeleteViewDTO campaignBatchDeleteViewDTO) {
        return bizCampaignCommandWorkflow.batchDeleteCampaign(context,campaignBatchDeleteViewDTO);
    }

    @Override
    @EnableOpLog
    public Response updateCampaignPart(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, boolean updateSubCampaign) {
        Long campaignId = Optional.ofNullable(campaignViewDTO).map(CampaignViewDTO::getId).orElse(null);
        AssertUtil.notNull(campaignId, "计划ID必填");
        CampaignQueryOption option = CampaignQueryOption.builder().needFrequency(true).needTarget(true).needChildren(updateSubCampaign).build();
        CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder().campaignIds(Collections.singletonList(campaignId)).build();
        List<CampaignViewDTO> dbCampaignViewDTOList = campaignStructureQueryAbility.handle(serviceContext,
                CampaignStructureQueryAbilityParam.builder().abilityTarget(campaignQueryViewDTO).queryOption(option).build());
        AssertUtil.notEmpty(dbCampaignViewDTOList, "计划不存在或已被删除");
        CampaignViewDTO dbCampaignViewDTO = dbCampaignViewDTOList.get(0);

        List<CampaignViewDTO> updateCampaignList = Lists.newArrayList(campaignViewDTO);
        //更新子计划
        if (updateSubCampaign && CollectionUtils.isNotEmpty(dbCampaignViewDTO.getSubCampaignViewDTOList())) {
            for (CampaignViewDTO dbSubCampaignViewDTO : dbCampaignViewDTO.getSubCampaignViewDTOList()) {
                CampaignViewDTO updateSubCampaignViewDTO = campaignViewPageConverter.convertSelf(campaignViewDTO);
                updateSubCampaignViewDTO.setId(dbSubCampaignViewDTO.getId());
                updateCampaignList.add(updateSubCampaignViewDTO);
            }
        }
        campaignUpdatePartAbility.handle(serviceContext, CampaignBatchAbilityParam.builder().abilityTargets(updateCampaignList).build());
        return Response.success();
    }

    @Override
    public Response updateCampaignTargetPart(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, boolean updateSubCampaign) {
        return bizCampaignCommandWorkflow.updateCampaignTargetPart(serviceContext, campaignViewDTO, updateSubCampaign);
    }

    @Override
    public Response deleteCampaignTargetPart(ServiceContext context, Long campaignId, BrandTargetTypeEnum targetTypeEnum) {
        AssertUtil.notNull(campaignId, "计划ID必填");
        AssertUtil.notNull(targetTypeEnum, "定向类型必填");
        campaignRepository.deleteCampaignCrowdPart(context, campaignId, targetTypeEnum);
        return Response.success();
    }

    @Override
    public Response updateCampaignSetting(ServiceContext context, String settingKey, String settingValue,
                                                      Long campaignId) {
        AssertUtil.assertTrue(StringUtils.isNotBlank(context.getBizCode()) && ServiceContextUtil.getSceneId(context) != null, BrandOneBPBaseErrorCode.PARAM_REQUIRED);
        AssertUtil.assertTrue(BrandCampaignSettingKeyEnum.getByKey(settingKey) != null && StringUtils.isNotBlank(settingKey) || campaignId != null, BrandOneBPBaseErrorCode.PARAM_REQUIRED);
        // 测试帐号
        if (Optional.ofNullable(selfServiceTestMemberConfig.getFilterMemberIdList()).orElse(Lists.newArrayList()).contains(context.getMemberId())) {
            CampaignViewDTO campaignViewDTO = bizCampaignQueryWorkflow.getCampaignInfoByOption(context, campaignId, new CampaignQueryOption());
            if (campaignViewDTO == null) {
                RogerLogger.error("测试帐号 {} 下无计划 {} , 无需更新settingKey", context.getMemberId(), campaignId);
                return Response.success();
            }
        }

        campaignRepository.updateCampaignSetting(context,settingKey,settingValue,campaignId);
        return Response.success();
    }

    @Override
    public Response batchUpdateCampaignSetting(ServiceContext context, String settingKey, String settingValue,
                                          List<Long> campaignIds ) {
        AssertUtil.assertTrue(StringUtils.isNotBlank(context.getBizCode()) && ServiceContextUtil.getSceneId(context) != null, BrandOneBPBaseErrorCode.PARAM_REQUIRED);
        AssertUtil.assertTrue(BrandCampaignSettingKeyEnum.getByKey(settingKey) != null && StringUtils.isNotBlank(settingKey) && CollectionUtils.isNotEmpty(campaignIds), BrandOneBPBaseErrorCode.PARAM_REQUIRED);
        for(Long campaignId : campaignIds){
            campaignRepository.updateCampaignSetting(context,settingKey,settingValue,campaignId);
        }
        return Response.success();
    }


    @Override
    public Response resetCampaignBudget(ServiceContext context, CampaignViewDTO campaignViewDTO) {
        bizCampaignCommandWorkflow.resetCampaignBudget(context,campaignViewDTO);
        return Response.success();
    }
    @Override
    public Response resetSubCampaignBudget(ServiceContext context, List<CampaignViewDTO> campaignViewDTOList) {
        bizCampaignCommandWorkflow.resetSubCampaignBudget(context,campaignViewDTOList);
        return Response.success();
    }

    @Override
    public Response updateCampaignSchedule(ServiceContext context, CampaignScheduleViewDTO campaignScheduleViewDTO) {
        bizCampaignInventoryWorkflow.updateCampaignSchedule(context,campaignScheduleViewDTO);
        return Response.success();
    }

    @Override
    public Response batchUpdateCampaignSchedule(ServiceContext context, CampaignSchedulePolicyViewDTO schedulePolicyViewDTO) {
        bizCampaignInventoryWorkflow.batchUpdateCampaignSchedulePolicy(context,schedulePolicyViewDTO);
        return Response.success();
    }

    @Override
    public Response inquiry(ServiceContext context, CampaignInquiryOperateViewDTO inquiryOperateViewDTO) {
        AssertUtil.notNull(inquiryOperateViewDTO, "查询参数不能为空");
        inquiryOperateViewDTO.setOperateType(CampaignScheduleOperateTypeEnum.INQUIRY.getValue());
        bizCampaignInventoryWorkflow.inventoryInquiryOrLock(context, inquiryOperateViewDTO);
        return Response.success();
    }

    @Override
    public Response lock(ServiceContext context, CampaignInquiryOperateViewDTO inquiryOperateViewDTO) {
        AssertUtil.notNull(inquiryOperateViewDTO, "查询参数不能为空");
        inquiryOperateViewDTO.setOperateType(CampaignScheduleOperateTypeEnum.LOCK.getValue());
        bizCampaignInventoryWorkflow.inventoryInquiryOrLock(context, inquiryOperateViewDTO);
        return Response.success();
    }

    @Override
    public Response availAmountLock(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO) {
        AssertUtil.notNull(inquiryOperateViewDTO, "查询参数不能为空");
        AssertUtil.notEmpty(inquiryOperateViewDTO.getCampaignIdList(), "锁量计划不能为空");
        RogerLogger.info("availAmountLock start {}",JSON.toJSONString(inquiryOperateViewDTO));
        bizCampaignInventoryWorkflow.availAmountLock(serviceContext,inquiryOperateViewDTO);
        return Response.success();
    }


    @Override
    public Response release(ServiceContext context, CampaignInquiryOperateViewDTO inquiryOperateViewDTO) {
        AssertUtil.notNull(inquiryOperateViewDTO, "查询参数不能为空");
        inquiryOperateViewDTO.setOperateType(CampaignScheduleOperateTypeEnum.RELEASE.getValue());
        bizCampaignInventoryWorkflow.inventoryInquiryOrLock(context,inquiryOperateViewDTO);
        return Response.success();
    }

    @Override
    public Response cancel(ServiceContext context, CampaignInquiryOperateViewDTO inquiryOperateViewDTO) {
        AssertUtil.notNull(inquiryOperateViewDTO, "查询参数不能为空");
        inquiryOperateViewDTO.setOperateType(CampaignScheduleOperateTypeEnum.CANCEL.getValue());

        bizCampaignInventoryWorkflow.inventoryInquiryOrLock(context, inquiryOperateViewDTO);
        return Response.success();
    }

    @Override
    public Response delayLock(ServiceContext serviceContext, CampaignDelayLockApplyViewDTO delayLockApplyViewDTO) {
        AssertUtil.notNull(delayLockApplyViewDTO, "查询参数不能为空");
        AssertUtil.notEmpty(delayLockApplyViewDTO.getCampaignIdList(), "申请延期计划ID不能为空");
        AssertUtil.notNull(delayLockApplyViewDTO.getConfirm(), "是否二次确认信息不能为空");
        AssertUtil.notNull(delayLockApplyViewDTO.getCreatorId(), "延期申请人信息不能为空");
        AssertUtil.notEmpty(delayLockApplyViewDTO.getCampaignIdList(), "申请延期计划ID不能为空");
//        bizCampaignCommandWorkflow.delayLock(serviceContext,delayLockApplyViewDTO);
        bizCampaignInventoryWorkflow.delayLock(serviceContext,delayLockApplyViewDTO);
        return Response.success();
    }

    @Override
    public Response mediaInquiry(ServiceContext context, CampaignInquiryOperateViewDTO inquiryOperateViewDTO) {
        AssertUtil.notNull(inquiryOperateViewDTO, "查询参数不能为空");
        inquiryOperateViewDTO.setOperateType(CampaignScheduleOperateTypeEnum.MEDIA_INQUIRY.getValue());
        bizCampaignInventoryWorkflow.inventoryInquiryOrLock(context,inquiryOperateViewDTO);
        return Response.success();
    }

    @Override
    public Response mandatoryLock(ServiceContext context, CampaignInquiryOperateViewDTO inquiryOperateViewDTO) {
        AssertUtil.notNull(inquiryOperateViewDTO, "查询参数不能为空");
        AssertUtil.notNull(inquiryOperateViewDTO.getCreatorId(), "审批申请人信息不能为空");
        inquiryOperateViewDTO.setOperateType(CampaignScheduleOperateTypeEnum.MANDATORY_LOCK.getValue());
        bizCampaignInventoryWorkflow.mandatoryLock(context,inquiryOperateViewDTO);
        return Response.success();
    }

    @Override
    public Response processFinishCallback(String processCode, String procInstId, Integer result, String extInfo) {
        if (processCode.equals(BpmsProcessCodeEnum.CAMPAIGN_MANDATORY_LOCK_APPLY.getCode())) {
            Map<String, String> mapExt = JSONObject.parseObject(extInfo, new TypeReference<HashMap<String, String>>() {});
            ServiceContext context = JSONObject.parseObject(mapExt.get("context"), new TypeReference<ServiceContext>() {});
            ServiceContextUtil.buildServiceContextSession(context);
            CampaignInquiryOperateViewDTO inquiryOperateViewDTO = JSONObject.parseObject(mapExt.get("viewDTO"),
                new TypeReference<CampaignInquiryOperateViewDTO>() {});
            if (BizCampaignGroupToolsHelper.isFinish(result)) {
                AssertUtil.notNull(inquiryOperateViewDTO, "查询参数不能为空");
                //更新计划的流程状态 && id
                bizCampaignCommandWorkflow.mandatoryLockProcess(context, inquiryOperateViewDTO, procInstId, BrandCampaignProcessStatusEnum.getByCode(result));
            }
            if (BizCampaignGroupToolsHelper.isAgree(result)) {
                inquiryOperateViewDTO.setOperateType(CampaignScheduleOperateTypeEnum.MANDATORY_LOCK.getValue());
                //库存操作
                bizCampaignInventoryWorkflow.inventoryInquiryOrLock(context, inquiryOperateViewDTO);
            }
        }
        else if (processCode.equals(BpmsProcessCodeEnum.CAMPAIGN_DELAY_LOCK_APPLY.getCode())) {
            RogerLogger.info("延期审批回调原始结果 processCode {}, procInstId {}, result {}, extInfo {}", processCode, procInstId, result, extInfo);
            Map<String, String> mapExt = JSONObject.parseObject(extInfo, new TypeReference<HashMap<String, String>>() {});
            ServiceContext context = JSONObject.parseObject(mapExt.get("context"), new TypeReference<ServiceContext>() {});
            ServiceContextUtil.buildServiceContextSession(context);
            //兼容历史版本
            List<Long> campaignIdList= Lists.newArrayList();
            if(mapExt.containsKey("campaignId")){
                Long campaignId = JSONObject.parseObject(mapExt.get("campaignId"), Long.class);
                campaignIdList.add(campaignId);
            }else {
                List<Long> campaignIds = JSONObject.parseArray(mapExt.get("campaignIds"), Long.class);
                campaignIdList.addAll(campaignIds);
            }
            AssertUtil.assertTrue(CollectionUtils.isNotEmpty(campaignIdList), "延期审批回调结果 campaignIds is empty");
            CampaignDelayLockProcessViewDTO processViewDTO = CampaignDelayLockProcessViewDTO.builder()
                    .campaignIds(campaignIdList)
                    .procInstId(procInstId)
                    .result(BizBpmsProcessStatusEnum.getByCode(result)).build();
            bizCampaignInventoryWorkflow.delayLockProcess(context, processViewDTO);
        }
        return Response.success();
    }

    @Override
    public Response switchCampaign(ServiceContext context, Long campaignId, SwitchEnum switchEnum) {
        bizCampaignCommandWorkflow.batchSwitchCampaign(context,Lists.newArrayList(campaignId),switchEnum);
        return Response.success();
    }

    @Override
    public Response batchSwitchCampaign(ServiceContext context, List<Long> campaignIds, SwitchEnum switchEnum) {
        bizCampaignCommandWorkflow.batchSwitchCampaign(context,campaignIds,switchEnum);
        return Response.success();
    }

    @Override
    @EnableOpLog
    public Response noticeInquiryResult(ServiceContext context, String inventoryResult) {
        AssertUtil.hasText(inventoryResult,"库存回调请求参数不允许为空");
        RogerLogger.info("noticeInquiryResult.inventoryResult:{}", JSON.toJSONString(inventoryResult));
        CampaignInquiryOperateViewDTO inventoryCallbackViewDTO = new CampaignInquiryOperateViewDTO();
        inventoryCallbackViewDTO.setInventoryResult(inventoryResult);
        inventoryCallbackViewDTO.setOperateType(CampaignScheduleOperateTypeEnum.INQUIRY_CALLBACK.getValue());
        bizCampaignInventoryWorkflow.inventoryInquiryOrLockCallback(context,inventoryCallbackViewDTO);
        return Response.success();
    }

    @Override
    @EnableOpLog
    public Response noticeLockResult(ServiceContext context, String inventoryResult) {
        AssertUtil.hasText(inventoryResult,"库存回调请求参数不允许为空");
        RogerLogger.info("noticeLockResult.inventoryResult:{}", JSON.toJSONString(inventoryResult));
        RogerLogger.info("cost time campaign lock result {} start : {}", inventoryResult, BrandDateUtil.date2String(new Date(), DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_1));
        CampaignInquiryOperateViewDTO inventoryCallbackViewDTO = new CampaignInquiryOperateViewDTO();
        inventoryCallbackViewDTO.setInventoryResult(inventoryResult);
        inventoryCallbackViewDTO.setOperateType(CampaignScheduleOperateTypeEnum.LOCK_CALLBACK.getValue());
        bizCampaignInventoryWorkflow.inventoryInquiryOrLockCallback(context,inventoryCallbackViewDTO);
        RogerLogger.info("cost time campaign lock result {} end : {}", inventoryResult, BrandDateUtil.date2String(new Date(), DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_1));
        return Response.success();
    }

    @Override
    @EnableOpLog
    public Response noticeReleaseResult(ServiceContext context, String inventoryResult) {
        AssertUtil.hasText(inventoryResult,"库存回调请求参数不允许为空");
        RogerLogger.info("noticeReleaseResult.inventoryResult:{}", JSON.toJSONString(inventoryResult));
        CampaignInquiryOperateViewDTO inventoryCallbackViewDTO = new CampaignInquiryOperateViewDTO();
        inventoryCallbackViewDTO.setInventoryResult(inventoryResult);
        inventoryCallbackViewDTO.setOperateType(CampaignScheduleOperateTypeEnum.RELEASE_CALLBACK.getValue());
        bizCampaignInventoryWorkflow.inventoryInquiryOrLockCallback(context,inventoryCallbackViewDTO);
        return Response.success();
    }

    @Override
    public Response updateCampaignTemplate(ServiceContext context,Long resourceProductId,List<Long> sspTemplateIds) {
        AssertUtil.assertTrue(false,"功能已下线");
        return Response.success();
    }

    @Override
    public Response physicsDeleteCampaign(ServiceContext context, Long campaignId) {
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(autoTestMemberDiamondConfig.getInnerMemberList()), "未配置白名单，不可物理操作");
        AssertUtil.assertTrue(autoTestMemberDiamondConfig.getInnerMemberList().contains(context.getMemberId()), "未命中白名单，不可物理操作");
        CampaignViewDTO baseCampaignViewDTO = campaignRepository.getCampaignById(context,campaignId);
        if(baseCampaignViewDTO == null){
            return Response.success();
        }
        context = ServiceContextUtil.buildServiceContextForSceneId(baseCampaignViewDTO.getMemberId(), baseCampaignViewDTO.getSceneId());
        List<Integer> allStatusList = Arrays.stream(BrandCampaignStatusEnum.values()).map(BrandCampaignStatusEnum::getCode).collect(Collectors.toList());

        CampaignQueryOption campaignQueryOption = CampaignQueryOption.builder().needFrequency(true).needTarget(true).build();
        CampaignQueryViewDTO queryViewDTO = CampaignQueryViewDTO.builder().campaignIds(Lists.newArrayList(campaignId)).statusList(allStatusList).build();
        List<CampaignViewDTO> campaignViewDTOList = campaignStructureQueryAbility.handle(context, CampaignStructureQueryAbilityParam.builder()
                .abilityTarget(queryViewDTO).queryOption(campaignQueryOption).build());
        AssertUtil.notEmpty(campaignViewDTOList, "计划信息不存在：" + campaignId);

        CampaignViewDTO campaign = campaignViewDTOList.get(0);
        //查询二级计划
        if(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode().equals(campaign.getCampaignLevel())){
            CampaignQueryViewDTO subCampaignQueryViewDTO = CampaignQueryViewDTO.builder().parentCampaignIds(Lists.newArrayList(campaignId))
                    .campaignLevel(BrandCampaignLevelEnum.LEVEL_TWO_CAMPAIGN.getCode()).statusList(allStatusList).build();
            List<CampaignViewDTO> subCampaignViewDTOList = campaignStructureQueryAbility.handle(context, CampaignStructureQueryAbilityParam.builder()
                    .abilityTarget(subCampaignQueryViewDTO).queryOption(campaignQueryOption).build());
            campaign.setSubCampaignViewDTOList(subCampaignViewDTOList);
        }
        if(CollectionUtils.isNotEmpty(campaign.getSubCampaignViewDTOList())){
            for(CampaignViewDTO subCampaignViewDTO : campaign.getSubCampaignViewDTOList()){
                RogerLogger.info("physicsDeleteCampaign  subCampaign {}",subCampaignViewDTO.getId());
                campaignRepository.physicsDelCampaign(context,subCampaignViewDTO);
            }
        }
        campaignRepository.physicsDelCampaign(context,campaign);
        RogerLogger.info("physicsDeleteCampaign  campaign {}",campaign.getId());
        return Response.success();
    }

    @Override
    public Response noticeScrollDailyUpdate() {
        ServiceContext serviceContext = ServiceContextUtil.buildServiceContextForBizCode(null, BizCodeEnum.BRANDONEBP.getBizCode());
        bizCampaignInventoryWorkflow.noticeScrollDailyUpdate(serviceContext);
        return Response.success();
    }

    @Override
    public MultiResponse<Long> executeScrollDailyUpdate(ServiceContext context, List<Long> ids) {
        List<CampaignViewDTO> dbCampaignList = bizCampaignQueryWorkflow.getCampaignInfoListByOption(context,
                CampaignQueryViewDTO.builder().campaignIds(ids).build(),CampaignQueryOption.builder().build());
        AssertUtil.notEmpty(dbCampaignList,String.format("计划不存在，ids=%s",JSON.toJSONString(ids)));
        bizCampaignInventoryWorkflow.executeScrollDailyUpdate(dbCampaignList);
        return MultiResponse.of(ids);
    }

    @Override
    public Response tanxdealChange(ServiceContext context, CampaignDealNoticeViewDTO campaignDealNoticeViewDTO) {
        bizCampaignCommandWorkflow.tanxdealChangeNotice(context,campaignDealNoticeViewDTO);
        return Response.success();
    }

    @Override
    public Response bottomDateChange(ServiceContext context, CampaignDealNoticeViewDTO campaignDealNoticeViewDTO) {
        bizCampaignCommandWorkflow.tanxdealBottomDateChange(context,campaignDealNoticeViewDTO);
        return Response.success();
    }

    @Override
    public Response inventoryAutoRelease(ServiceContext context, List<CampaignInventoryAutoReleaseMsgViewDTO> campaignInventoryAutoReleaseMsgViewDTOList) {
        bizCampaignInventoryWorkflow.inventoryAutoReleaseWarning(context,campaignInventoryAutoReleaseMsgViewDTOList);
        return Response.success();
    }

    @Override
    public Response switchSafeIp(ServiceContext context, Long campaignId, Integer isSupportSafeIp, Integer safeIpThreshold) {
        CampaignQueryOption campaignQueryOption = new CampaignQueryOption();
        campaignQueryOption.setNeedChildren(true);
        campaignQueryOption.setNeedTarget(true);
        CampaignViewDTO campaignViewDTO = bizCampaignQueryWorkflow.getCampaignInfoByOption(context, campaignId, campaignQueryOption);
        AssertUtil.assertTrue(campaignViewDTO != null, BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR,"未找到对应计划");
        AssertUtil.assertTrue(MediaScopeEnum.TAO_OUT.getCode().equals(campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope()),"仅二级产品支持风险IP库");
        bizCampaignCommandWorkflow.switchSafeIp(context, campaignViewDTO, isSupportSafeIp,safeIpThreshold);
        return Response.success();
    }

    @Override
    public SingleResponse<Long> saveUnionFrequency(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO, List<Long> campaignIdList) {
        Long freqId = bizCampaignCommandWorkflow.saveDeliveredFrequency(serviceContext, frequencyViewDTO, campaignIdList);
        return SingleResponse.of(freqId);
    }

    @Override
    public Response frequencySwitch(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO) {
        bizCampaignCommandWorkflow.frequencySwitch(serviceContext, frequencyViewDTO);
        return Response.success();
    }

    @Override
    public Response bindEffectAdv(ServiceContext serviceContext, Long campaignId, List<Long> advIds) {
        bizCampaignCommandWorkflow.bindAdv(serviceContext,campaignId,advIds);
        return Response.success();
    }

    @Override
    public Response unBindEffectAdv(ServiceContext serviceContext, Long campaignId, List<Long> advIds) {
        bizCampaignCommandWorkflow.unBindAdv(serviceContext,campaignId,advIds);
        return Response.success();
    }

    @Override
    public Response batchOptimizeConfig(ServiceContext serviceContext, List<Long> campaignIdList, CampaignRealTimeOptimizeViewDTO campaignRealTimeOptimizeViewDTO) {
        return bizCampaignCommandWorkflow.batchOptimizeConfig(serviceContext,  campaignIdList, campaignRealTimeOptimizeViewDTO);
    }

    @Override
    public Response saveRealTimeOptimizeInfo(ServiceContext serviceContext, CampaignRealTimeOptimizeInfoViewDTO realTimeOptimizeInfoViewDTO) {
        bizCampaignCommandWorkflow.saveRealTimeOptimizeInfo(serviceContext, realTimeOptimizeInfoViewDTO);
        return Response.success();
    }

    @Override
    public SingleResponse<Long> addBatchImportTask(ServiceContext context, ReportTaskViewDTO taskViewDTO) {
        // 校验任务参数
        AssertUtil.notNull(taskViewDTO);
        AssertUtil.notNull(taskViewDTO.getFunctionCode(), "计划批量导入任务参数缺失");
        AssertUtil.notEmpty(taskViewDTO.getTaskParams(), "计划批量导入任务参数缺失");
        // 校验params内部信息
        AssertUtil.notNull(taskViewDTO.getTaskParams().get("saleGroupId"), "计划批量导入任务参数: 售卖分组ID缺失");
        AssertUtil.notNull(taskViewDTO.getTaskParams().get("fileName"), "计划批量导入任务参数：导入文件名称缺失");
        AssertUtil.notNull(taskViewDTO.getTaskParams().get("ossUrl"), "计划批量导入任务参数: 导入文件OSS链接缺失");

        AssertUtil.notNull(taskViewDTO.getCampaignGroupId(), "订单ID不能为空");
        AssertUtil.hasLength(taskViewDTO.getTaskName(), "任务名称不能为空");
        AssertUtil.maxLength(taskViewDTO.getTaskName(), 50, "任务名称最长不能超过50");
        AssertUtil.notNull(taskViewDTO.getMemberId(),  "MemberId不能为空");

        if(Objects.isNull(taskViewDTO.getTaskId())) {
            Long taskId = reportSyncTaskRepository.add(context, taskViewDTO);
            return SingleResponse.of(taskId);
        }
        reportSyncTaskRepository.modify(context, taskViewDTO);
        return SingleResponse.of(taskViewDTO.getTaskId());
    }

    @Override
    public Response addBatchCampaign(ServiceContext context, CampaignBatchImportParamViewDTO campaignBatchImportParamViewDTO) {
        bizBatchImportWorkflow.executeBatchImport(context,campaignBatchImportParamViewDTO);
//        bizCampaignAbility.validateCampaignBatchImportRawViewDTO(campaignBatchImportParamViewDTO);
//        bizCampaignBatchImportWorkFlow.batchHandle(context, campaignBatchImportParamViewDTO);
        return Response.success();
    }
    @Override
    public SingleResponse<Long> batchImportCampaignBookingAmountTask(ServiceContext context, ReportTaskViewDTO taskViewDTO) {
        // 校验任务参数
        AssertUtil.notNull(taskViewDTO);
        AssertUtil.notNull(taskViewDTO.getFunctionCode(), "计划批量导入任务参数缺失");
        AssertUtil.notEmpty(taskViewDTO.getTaskParams(), "计划批量导入任务参数缺失");
        // 校验params内部信息
        AssertUtil.notNull(taskViewDTO.getTaskParams().get("fileName"), "计划批量导入任务参数：导入文件名称缺失");
        AssertUtil.notNull(taskViewDTO.getTaskParams().get("ossUrl"), "计划批量导入任务参数: 导入文件OSS链接缺失");
        AssertUtil.notNull(taskViewDTO.getCampaignGroupId(), "订单ID不能为空");
        AssertUtil.hasLength(taskViewDTO.getTaskName(), "任务名称不能为空");
        AssertUtil.maxLength(taskViewDTO.getTaskName(), 50, "任务名称最长不能超过50");
        AssertUtil.notNull(taskViewDTO.getMemberId(),  "MemberId不能为空");

        if(Objects.isNull(taskViewDTO.getTaskId())) {
            Long taskId = reportSyncTaskRepository.add(context, taskViewDTO);
            return SingleResponse.of(taskId);
        }
        reportSyncTaskRepository.modify(context, taskViewDTO);
        return SingleResponse.of(taskViewDTO.getTaskId());
    }

    @Override
    public Response batchImportCampaignBookingAmount(ServiceContext context, CampaignBookingAmountBatchImportParamViewDTO campaignBookingAmountBatchImportParamViewDTO) {
        bizBatchImportWorkflow.executeBatchImport(context,campaignBookingAmountBatchImportParamViewDTO);
//        bizCampaignAbility.validateBatchImportCampaignBookingAmountRawViewDTO(campaignBookingAmountBatchImportParamViewDTO);
//        bizCampaignBookingAmountBatchImportWorkFlow.batchImportCampaignBookingAmount(context, campaignBookingAmountBatchImportParamViewDTO);
        return Response.success();
    }

    /**
     * 计划更新实时优选人群和showmax的item人群
     * */
    @Override
    @DistLock(value = "CAMPAIGN_BIND_TX_OPTIMIZE_CROWD,0#getId()?:'-1'")
    public Response bindTXCampaignOptimizeCrowds(CampaignViewDTO campaignViewDTO) {
        bizCampaignCommandWorkflow.bindTXCampaignOptimizeCrowds(campaignViewDTO);
        return Response.success();
    }

    @Override
    public Response updateCampaignCastDate(ServiceContext context, CampaignViewDTO campaignViewDTO) {
        //基础参数校验
        AssertUtil.assertTrue(Objects.nonNull(campaignViewDTO.getStartTime()),
            BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR,"开始时间不能为空");
        AssertUtil.assertTrue(Objects.nonNull(campaignViewDTO.getEndTime()),
            BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR,"结束不能为空");
        AssertUtil.assertTrue(Objects.nonNull(campaignViewDTO.getId()),
            BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR,"id不能为空");
        bizCampaignCommandWorkflow.updateCampaignCastDate(context,campaignViewDTO);
        return Response.success();
    }

    @Override
    public Response updateCampaignSettlePrice(ServiceContext context, CampaignViewDTO campaignViewDTO) {
        AssertUtil.notNull(campaignViewDTO.getId(),"计划id为空");
        CampaignViewDTO campaignViewDTOTree = bizCampaignQueryWorkflow.getCampaignInfoByOption(context,campaignViewDTO.getId(),CampaignQueryOption.builder().needChildren(true).build());
        AssertUtil.notNull(campaignViewDTO,"计划为空");
        AssertUtil.assertTrue(campaignViewDTO.getCampaignLevel() == 1,"计划不为1级计划");
        if(campaignViewDTOTree.getCampaignPriceViewDTO() == null || campaignViewDTOTree.getCampaignBudgetViewDTO().getDiscountTotalMoney() == null){
            RogerLogger.info("{} dont have money dont need reset ",campaignViewDTOTree.getId());
            return Response.success();
        }
        if(CollectionUtils.isEmpty(campaignViewDTOTree.getSubCampaignViewDTOList())){
            RogerLogger.info("{} dont have sub campaign dont need reset ",campaignViewDTOTree.getId());
            return Response.success();
        }

        List<CampaignViewDTO> updateList = Lists.newArrayList();

        CampaignViewDTO parentUpdate  = updateSettlePrice( campaignViewDTOTree);
        if(Objects.nonNull(parentUpdate)){
            updateList.add(parentUpdate);
        }
        for(CampaignViewDTO sub : campaignViewDTOTree.getSubCampaignViewDTOList()){
            CampaignViewDTO subUpdate  = updateSettlePrice( sub);
            if(Objects.nonNull(subUpdate)){
                updateList.add(subUpdate);
            }
        }
        if(CollectionUtils.isNotEmpty(updateList)){
            campaignRepository.updateCampaignPart(context,updateList);
            RogerLogger.info("{} need reset over ",campaignViewDTOTree.getId());
        }
        return Response.success();
    }

    private  CampaignViewDTO updateSettlePrice( CampaignViewDTO campaignViewDTO) {
        CampaignPriceViewDTO campaignPriceViewDTO = campaignViewDTO.getCampaignPriceViewDTO();

        if(Objects.isNull(campaignPriceViewDTO)){
            RogerLogger.info("{} dont have sub priceView campaign dont need reset ", campaignViewDTO.getId());
            return null;
        }

        List<DayPriceViewDTO> discountPriceInfos = campaignPriceViewDTO.getDiscountPriceInfoList();

        if(CollectionUtils.isEmpty(discountPriceInfos)){
            RogerLogger.info("{} dont have parentDiscountPriceInfos campaign dont need reset ",
                campaignViewDTO.getId());
            return null;
        }

        boolean flag = false;
        for(DayPriceViewDTO dayPriceViewDTO : discountPriceInfos){
            if(Objects.isNull(dayPriceViewDTO.getSettlePrice())){
                dayPriceViewDTO.setSettlePrice(dayPriceViewDTO.getPrice());
                if(BizCampaignToolsHelper.isCPT(campaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterUnit())){
                    ProductViewDTO productViewDTO = productRepository.getProductById(campaignViewDTO.getCampaignResourceViewDTO().getSspProductId());
                    //单位CPM
                    Integer  unitExposure =  productViewDTO.getUnitExposure();
                    AssertUtil.assertTrue(unitExposure!=null &&  unitExposure>=0 ,"CPT对应单位CPM小于0");
                    Long cpmSettlePrice = BigDecimal.valueOf(dayPriceViewDTO.getPrice() ).divide(BigDecimal.valueOf(unitExposure),0, RoundingMode.DOWN).longValue();
                    RogerLogger.info("{} CPT Campaign parentDiscountPriceInfos campaign  need reset {}", campaignViewDTO.getId(),cpmSettlePrice);
                    dayPriceViewDTO.setSettlePrice(cpmSettlePrice);
                }
                flag = true;
            }
        }
        RogerLogger.info("{}  campaign reset flat {}", campaignViewDTO.getId(),flag);
        if(flag){
            CampaignViewDTO updateCampaignViewDTO = new CampaignViewDTO();
            updateCampaignViewDTO.setId(campaignViewDTO.getId());
            campaignPriceViewDTO.setDiscountPriceInfoList(discountPriceInfos);
            updateCampaignViewDTO.setCampaignPriceViewDTO(campaignPriceViewDTO);
            return updateCampaignViewDTO;
        }
        return null;
    }

    @Override
    public MultiResponse<CampaignViewDTO> systemAssignCustomSchedule(ServiceContext context, CampaignViewDTO campaignViewDTO) {
        return MultiResponse.of(bizCampaignCommandWorkflow.systemAssignCustomSchedule(context,campaignViewDTO));
    }

}