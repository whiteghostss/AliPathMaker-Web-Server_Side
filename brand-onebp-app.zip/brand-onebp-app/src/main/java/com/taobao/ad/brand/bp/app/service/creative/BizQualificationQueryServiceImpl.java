package com.taobao.ad.brand.bp.app.service.creative;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.taobao.ad.brand.bp.client.api.creative.BizQualificationQueryService;
import com.taobao.ad.brand.bp.client.dto.qualification.QualificationViewDTO;
import com.taobao.ad.brand.bp.domain.qualification.QualificationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@HSFProvider(serviceInterface = BizQualificationQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizQualificationQueryServiceImpl implements BizQualificationQueryService {

    private final QualificationRepository qualificationRepository;

    @Override
    public MultiResponse<String> findQualificationTypeList() {
        List<String> qualificationTypeList = qualificationRepository.findQualificationTypeList();
        return MultiResponse.of(qualificationTypeList);
    }
}
