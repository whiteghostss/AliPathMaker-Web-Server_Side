package com.taobao.ad.brand.bp.app.service.campaigngroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.utils.AbilityInvoker;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.content.CampaignGroupContentViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.purchase.CampaignGroupPurchaseViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.realsettle.CampaignGroupRealSettleViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.unlock.UnlockApplyInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupAssignOrderStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupCancelModeEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupProcessStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSourceEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupTypeEnum;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alibaba.hermes.framework.tool.lock.annotation.DistLock;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.app.businessability.ThirdMonitorSupportBusinessAbility;
import com.taobao.ad.brand.bp.app.interceptor.annotation.EnableOpLog;
import com.taobao.ad.brand.bp.app.workflow.campaigngroup.BizCampaignGroupCommandWorkflow;
import com.taobao.ad.brand.bp.app.workflow.salegroup.BizSaleGroupCommandWorkflow;
import com.taobao.ad.brand.bp.app.workflow.solution.BizSolutionCommandWorkflow;
import com.taobao.ad.brand.bp.client.api.campaigngroup.BizCampaignGroupCommandService;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupCancelCommandViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupCheckedResourceViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupOrderCommandViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupCrowdViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupEstimateInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupGoalSettingViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupPageViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.calculate.CampaignGroupSaleGroupCalViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.CampaignGroupSaleGroupEstimateQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.settle.CampaignGroupRealSettleSaveViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupCancelOpTypeEnum;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupEventEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.common.converter.campaigngroup.CampaignGroupViewConverter;
import com.taobao.ad.brand.bp.common.enums.BpmsProcessCodeEnum;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.config.AutoTestMemberDiamondConfig;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbilityRouteContext;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupBoostStatusUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupCalAutoCancelExpireTimeAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupDateValidateForCompleteCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupGiveStatusUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupInquiryPurchaseOrderUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupNameValidateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupBoostStatusUpdateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupCalAutoCancelExpireTimeAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupDateValidateForCompleteCampaignGroupAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupGiveStatusUpdateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupInquiryPurchaseOrderUpdateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupNameValidateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupUpdateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.businessability.ISaleGroupThirdMonitorUpdateBusinessAbilityPoint;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR;
import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.BIZ_DATA_EMPTY_ERROR;
import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_ILLEGAL;
import static com.taobao.ad.brand.bp.common.util.BrandDateUtil.DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_1;

/**
 * @author yanjingang
 * @date 2023/3/2
 */
@HSFProvider(serviceInterface = BizCampaignGroupCommandService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizCampaignGroupCommandServiceImpl implements BizCampaignGroupCommandService {
    private final CampaignGroupRepository campaignGroupRepository;
    private final BizCampaignGroupCommandWorkflow bizCampaignGroupCommandWorkflow;
    private final BizSaleGroupCommandWorkflow bizSaleGroupCommandWorkflow;
    private final BizSolutionCommandWorkflow bizSolutionCommandWorkflow;
    private final ICampaignGroupInquiryPurchaseOrderUpdateAbility campaignGroupInquiryPurchaseOrderUpdateAbility;
    private final ICampaignGroupNameValidateAbility campaignGroupNameValidateAbility;
    private final ICampaignGroupUpdateAbility campaignGroupUpdateAbility;
    private final ICampaignGroupGiveStatusUpdateAbility campaignGroupGiveStatusUpdateAbility;
    private final ICampaignGroupBoostStatusUpdateAbility campaignGroupBoostStatusUpdateAbility;
    private final ICampaignGroupCalAutoCancelExpireTimeAbility campaignGroupCalAutoCancelExpireTimeAbility;
    private final ICampaignGroupDateValidateForCompleteCampaignGroupAbility campaignGroupDateValidateForCompleteCampaignGroupAbility;
    private final CampaignGroupViewConverter campaignGroupViewConverter;
    private final AutoTestMemberDiamondConfig autoTestMemberDiamondConfig;

    @Override
    public SingleResponse<Long> addCampaignGroup(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO) {
        List<CampaignGroupViewDTO> addCampaignGroupList = bizCampaignGroupCommandWorkflow.addCampaignGroupForSelfService(context, campaignGroupViewDTO);
        Optional<CampaignGroupViewDTO> optional = addCampaignGroupList.stream().filter(campaignGroup -> BrandCampaignGroupLevelEnum.LEVEL_TWO.getCode().equals(campaignGroup.getCampaignGroupLevel())).findFirst();
        Long subCampaignGroupId = optional.map(CampaignGroupViewDTO::getId).orElse(null);
        return SingleResponse.of(subCampaignGroupId);
    }

    @Override
    public SingleResponse<Long> addCampaignGroupForSale(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO) {
        // 设置基础信息
        AssertUtil.assertTrue(campaignGroupViewDTO != null, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "订单参数不能为空");
        campaignGroupViewDTO.setType(BrandCampaignGroupTypeEnum.SALES.getCode());
        campaignGroupViewDTO.setCampaignGroupLevel(BrandCampaignGroupLevelEnum.LEVEL_ONE.getCode());
        campaignGroupViewDTO.setSource(BrandCampaignGroupSourceEnum.SALE_BRIEF.getCode());
        bizCampaignGroupCommandWorkflow.addCampaignGroupForSale(context, campaignGroupViewDTO);
        return SingleResponse.of(campaignGroupViewDTO.getId());
    }

    @Override
    public SingleResponse<Integer> updateCampaignGroupPart(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO) {
        // 校验ID
        checkCampaignGroupId(campaignGroupViewDTO);
        // 查询订单
        CampaignGroupViewDTO dbCampaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(context, campaignGroupViewDTO.getId());
        AssertUtil.notNull(dbCampaignGroupViewDTO, BrandOneBPBaseErrorCode.PARAM_ILLEGAL, "订单不存在");
        campaignGroupNameValidateAbility.handle(context, CampaignGroupNameValidateAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
        Integer count = campaignGroupUpdateAbility.handle(context, CampaignGroupUpdateAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
        return SingleResponse.of(count);
    }

    @Override
    @DistLock(value = "CAMPAIGN_GROUP_UPDATE_PART_FOR_SALE,1#getId()")
    public SingleResponse<Integer> updateCampaignGroupPartForSale(ServiceContext context, CampaignGroupViewDTO mainCampaignGroupViewDTO) {
        RogerLogger.info("cost time update campaignGroup {} start : {}", mainCampaignGroupViewDTO.getId(), BrandDateUtil.date2String(new Date(), DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_1));
        // 校验ID
        checkCampaignGroupId(mainCampaignGroupViewDTO);
        // 查询订单
        CampaignGroupViewDTO dbCampaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(context, mainCampaignGroupViewDTO.getId());
        AssertUtil.notNull(dbCampaignGroupViewDTO, BrandOneBPBaseErrorCode.PARAM_ILLEGAL, "订单不存在");
        mainCampaignGroupViewDTO.setType(dbCampaignGroupViewDTO.getType());
        Integer count;
        if (BrandCampaignGroupTypeEnum.SELF.getCode().equals(mainCampaignGroupViewDTO.getType())) {
            // 查询子订单
            List<CampaignGroupViewDTO> dbSubCampaignGroupList = campaignGroupRepository.findSubCampaignGroupList(context, mainCampaignGroupViewDTO.getId());
            AssertUtil.notEmpty(dbSubCampaignGroupList, BrandOneBPBaseErrorCode.PARAM_ILLEGAL, "子订单不存在");
            CampaignGroupViewDTO dbSubCampaignGroupViewDTO = dbSubCampaignGroupList.get(0);
            ServiceContext subContext = ServiceContextUtil.buildServiceContextForSceneId(context.getMemberId(), dbSubCampaignGroupViewDTO.getSceneId());
            CampaignGroupViewDTO subCampaignGroupViewDTO = convertSelfServiceSubCampaignGroupForUpdate(mainCampaignGroupViewDTO, dbSubCampaignGroupViewDTO);
            count = bizCampaignGroupCommandWorkflow.updateCampaignGroupPartForSelfService(subContext, subCampaignGroupViewDTO);
        } else {
            count = bizCampaignGroupCommandWorkflow.updateCampaignGroupPartForSale(context, mainCampaignGroupViewDTO);
        }
        RogerLogger.info("cost time update campaignGroup {} end : {}", mainCampaignGroupViewDTO.getId(), BrandDateUtil.date2String(new Date(), DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_1));
        return SingleResponse.of(count);
    }

    private CampaignGroupViewDTO convertSelfServiceSubCampaignGroupForUpdate(CampaignGroupViewDTO mainCampaignGroupViewDTO, CampaignGroupViewDTO dbSubCampaignGroupViewDTO) {
        CampaignGroupViewDTO subCampaignGroupViewDTO = campaignGroupViewConverter.convertSelf(mainCampaignGroupViewDTO);
        subCampaignGroupViewDTO.setParentId(mainCampaignGroupViewDTO.getId());
        subCampaignGroupViewDTO.setId(dbSubCampaignGroupViewDTO.getId());
        return subCampaignGroupViewDTO;
    }

    private void checkCampaignGroupId(CampaignGroupViewDTO campaignGroupViewDTO) {
        AssertUtil.assertTrue(campaignGroupViewDTO != null, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "订单信息不能为空");
        AssertUtil.notNull(campaignGroupViewDTO.getId(), BrandOneBPBaseErrorCode.PARAM_REQUIRED, "订单ID不能为空");
    }

    @Override
    public SingleResponse<Integer> updateCampaignGroupOrders(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO) {
        Long id = campaignGroupViewDTO.getId();
        AssertUtil.notNull(id, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "订单ID不能为空");

        List<Long> inquiryOrderIds = Optional.ofNullable(campaignGroupViewDTO.getCampaignGroupPurchaseViewDTO()).map(CampaignGroupPurchaseViewDTO::getInquiryOrderIds).orElse(null);
        List<Long> purchaseOrderIds = Optional.ofNullable(campaignGroupViewDTO.getCampaignGroupPurchaseViewDTO()).map(CampaignGroupPurchaseViewDTO::getPurchaseOrderIds).orElse(null);
        CampaignGroupInquiryPurchaseOrderUpdateAbilityParam purchaseOrderUpdateAbilityParam = CampaignGroupInquiryPurchaseOrderUpdateAbilityParam.builder()
                .abilityTarget(id).inquiryOrderIds(inquiryOrderIds).purchaseOrderIds(purchaseOrderIds).build();
        Integer count = campaignGroupInquiryPurchaseOrderUpdateAbility.handle(context, purchaseOrderUpdateAbilityParam);
        return SingleResponse.of(count);
    }

    @Override
    public SingleResponse<Integer> physicalDeleteCampaignGroup(ServiceContext context, Long id, boolean needDeleteTree) {
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(autoTestMemberDiamondConfig.getInnerMemberList())
                && autoTestMemberDiamondConfig.getInnerMemberList().contains(context.getMemberId()), "未命中白名单，不可物理操作");
        AssertUtil.notNull(id, "订单ID不能为空");
        CampaignGroupViewDTO dbCampaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(context, id);
        AssertUtil.assertTrue(dbCampaignGroupViewDTO != null, BrandOneBPBaseErrorCode.BIZ_DATA_EMPTY_ERROR, "订单不存在");
        context = ServiceContextUtil.buildServiceContextForSceneId(dbCampaignGroupViewDTO.getMemberId(), dbCampaignGroupViewDTO.getSceneId());
        Integer count = bizCampaignGroupCommandWorkflow.physicalDeleteCampaignGroups(context, dbCampaignGroupViewDTO, needDeleteTree);
        return SingleResponse.of(count);
    }

    @Override
    public Response updateCampaignGroupPurchaseStatus(ServiceContext context, Long id) {
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(context, id);
        AssertUtil.notNull(campaignGroupViewDTO, BrandOneBPBaseErrorCode.BIZ_DATA_EMPTY_ERROR, String.format("订单(id=%s)不存在",id));

        ServiceContext sceneContext = ServiceContextUtil.getNewServiceContext(context, campaignGroupViewDTO.getSceneId());
        bizCampaignGroupCommandWorkflow.updatePurchaseOrderStatus(sceneContext, campaignGroupViewDTO);
        return Response.success();
    }

    @Override
    @EnableOpLog
    @DistLock(value = "CAMPAIGN_GROUP_AUTO_CANCEL,1#getId()")
    public Response autoCancelCampaignGroup(ServiceContext context, CampaignGroupCancelCommandViewDTO cancelViewDTO) {
        RogerLogger.info("autoCancelCampaignGroup service 订单id: {} , 操作类型: {}", cancelViewDTO.getId(), CampaignGroupCancelOpTypeEnum.getByValue(cancelViewDTO.getOperateType()));
        AssertUtil.notNull(cancelViewDTO.getId(), "订单ID不能为空");
        if (CampaignGroupCancelOpTypeEnum.EXECUTE_CANCEL.getValue().equals(cancelViewDTO.getOperateType())) {
            CampaignGroupViewDTO campaignGroup = campaignGroupRepository.getCampaignGroup(context, cancelViewDTO.getId());
            AssertUtil.notNull(campaignGroup, "订单不存在");
            AssertUtil.assertTrue(BrandCampaignGroupTypeEnum.SELF.getCode().equals(campaignGroup.getType())
                    && BrandCampaignGroupLevelEnum.LEVEL_TWO.getCode().equals(campaignGroup.getCampaignGroupLevel()), BIZ_BREAK_RULE_ERROR, "仅自助营销订单支持该操作");
//            Date autoCancelExpireTime = bizCampaignGroupAbility.calAutoCancelExpireTime(context, campaignGroup);
            Date autoCancelExpireTime = campaignGroupCalAutoCancelExpireTimeAbility.handle(context, CampaignGroupCalAutoCancelExpireTimeAbilityParam.builder().abilityTarget(campaignGroup).build());
            // 未到释量时间
            if (Objects.isNull(autoCancelExpireTime) || autoCancelExpireTime.after(new Date())) {
                return Response.success();
            }
            // 极简版&临时草稿时删除订单，其他情况撤单
            if (BrandCampaignGroupSourceEnum.SLIM_ORDER.getCode().equals(campaignGroup.getSource())
                    && BrandCampaignGroupStatusEnum.DRAFT.getCode().equals(campaignGroup.getStatus())) {
                bizSolutionCommandWorkflow.unbindCartItemSolution(context, campaignGroup.getSourceIds().get(0));
            } else {
                cancelViewDTO.setOperateMode(BrandCampaignGroupCancelModeEnum.AUTO.getCode());
                bizCampaignGroupCommandWorkflow.cancelSelfServiceCampaignGroup(context, cancelViewDTO, campaignGroup);
            }
        } else if (CampaignGroupCancelOpTypeEnum.WARNING_CANCEL.getValue().equals(cancelViewDTO.getOperateType())) {
            bizCampaignGroupCommandWorkflow.cancelSelfServiceCampaignGroupWarning(context, cancelViewDTO);
        }
        return Response.success();
    }

    @Override
    public SingleResponse<BrandCampaignGroupStatusEnum> transit(ServiceContext context, Long id, CampaignGroupEventEnum eventEnum) {
        AssertUtil.assertTrue(id != null, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "订单ID不能为空");
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(context, id);
        BrandCampaignGroupStatusEnum statusEnum = bizCampaignGroupCommandWorkflow.transitCampaignGroup(context, campaignGroupViewDTO, eventEnum);
        return SingleResponse.of(statusEnum);
    }

    @Override
    public Response preOrder(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO) {
        AssertUtil.assertTrue(campaignGroupOrderCommandViewDTO.getId() != null, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "订单ID不能为空");
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(context, campaignGroupOrderCommandViewDTO.getId());
        bizCampaignGroupCommandWorkflow.preOrder(context, campaignGroupViewDTO);
        return Response.success();
    }

    @Override
    @DistLock(value = "CAMPAIGN_GROUP_ORDER,1#getId()")
    public Response order(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO) {
        // 下单
        bizCampaignGroupCommandWorkflow.order(context, campaignGroupOrderCommandViewDTO);
        return Response.success();
    }

    @Override
    @DistLock(value = "CAMPAIGN_GROUP_APPLY_MODIFY,1#getId()")
    public Response applyModify(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO) {
        bizCampaignGroupCommandWorkflow.applyModify(context, campaignGroupOrderCommandViewDTO);
        return Response.success();
    }

    @Override
    public Response cancel(ServiceContext context, Long id) {
        CampaignGroupViewDTO campaignGroup = campaignGroupRepository.getCampaignGroup(context, id);
        AssertUtil.notNull(campaignGroup, "订单不存在");
        AssertUtil.assertTrue(BrandCampaignGroupTypeEnum.SELF.getCode().equals(campaignGroup.getType())
                && BrandCampaignGroupLevelEnum.LEVEL_TWO.getCode().equals(campaignGroup.getCampaignGroupLevel()), BIZ_BREAK_RULE_ERROR, "仅自助营销订单支持该操作");
        CampaignGroupCancelCommandViewDTO cancelViewDTO = new CampaignGroupCancelCommandViewDTO();
        cancelViewDTO.setId(id);
        cancelViewDTO.setOperateMode(BrandCampaignGroupCancelModeEnum.MANUAL.getCode());
        cancelViewDTO.setOperateType(CampaignGroupCancelOpTypeEnum.EXECUTE_CANCEL.getValue());
        bizCampaignGroupCommandWorkflow.cancelSelfServiceCampaignGroup(context, cancelViewDTO, campaignGroup);
        return Response.success();
    }

    @Override
    @EnableOpLog
    public Response finish(ServiceContext context, Long id) {
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(context, id);
        AssertUtil.notNull(campaignGroupViewDTO, "订单不存在");
        bizCampaignGroupCommandWorkflow.finish(context, campaignGroupViewDTO);
//        bizCampaignGroupCommandWorkflow.transitCampaignGroup(context, campaignGroupViewDTO, CampaignGroupEventEnum.FINISH);
        return Response.success();
    }

    @Override
    @EnableOpLog
    public Response finishRevert(ServiceContext context, Long id) {
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(context, id);
        AssertUtil.notNull(campaignGroupViewDTO, "订单不存在");
        bizCampaignGroupCommandWorkflow.finishRevert(context, campaignGroupViewDTO);
//        bizCampaignGroupCommandWorkflow.transitCampaignGroup(context, campaignGroupViewDTO, CampaignGroupEventEnum.FINISH_REVERT);
        return Response.success();
    }

    @Override
    @EnableOpLog
    public Response complete(ServiceContext context, Long id) {
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(context, id);
        AssertUtil.assertTrue(BizCampaignGroupToolsHelper.isSubSelfServiceCampaignGroup(campaignGroupViewDTO), "仅自助订单支持该操作");
        // 校验时间（停投时间/结束时间）
        campaignGroupDateValidateForCompleteCampaignGroupAbility.handle(context, CampaignGroupDateValidateForCompleteCampaignGroupAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
        bizCampaignGroupCommandWorkflow.transitCampaignGroup(context, campaignGroupViewDTO, CampaignGroupEventEnum.COMPLETE);
        return Response.success();
    }

    @Override
    @EnableOpLog
    public Response saveRealSettleInfo(ServiceContext context, CampaignGroupRealSettleSaveViewDTO campaignGroupRealSettleSaveViewDTO) {
        bizCampaignGroupCommandWorkflow.saveRealSettleInfo(context, campaignGroupRealSettleSaveViewDTO);
        return Response.success();
    }

    @Override
    public Response processFinishCallback(String processCode, String procInstId, Long id, Integer result, String extInfo) {
        ServiceContext context = JSONObject.parseObject(extInfo, ServiceContext.class);
        ServiceContextUtil.buildServiceContextSession(context);
        CampaignGroupViewDTO subCampaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(context, id);
        AssertUtil.assertTrue(subCampaignGroupViewDTO != null, BIZ_DATA_EMPTY_ERROR, "订单不存在");
        AssertUtil.assertTrue(BizCampaignGroupToolsHelper.isFinish(result), PARAM_ILLEGAL, "审批结果不为完成状态");
        if (processCode.equals(BpmsProcessCodeEnum.CAMPAIGN_GROUP_MODIFY_APPLY.getCode())) {
            UnlockApplyInfoViewDTO unlockApplyInfoViewDTO = subCampaignGroupViewDTO.getCampaignGroupUnlockViewDTO().getUnlockApplyInfoViewDTO();
            AssertUtil.assertTrue(procInstId.equals(unlockApplyInfoViewDTO.getProcInstId()), PARAM_ILLEGAL, "当前审批流实例不正确");
            bizCampaignGroupCommandWorkflow.finishApplyModifyProcess(context, subCampaignGroupViewDTO, BrandCampaignGroupProcessStatusEnum.getByCode(result));
        } else if (processCode.equals(BpmsProcessCodeEnum.CAMPAIGN_GROUP_REAL_SETTLE_APPLY.getCode())) {
            CampaignGroupRealSettleViewDTO campaignGroupProcessViewDTO = subCampaignGroupViewDTO.getCampaignGroupRealSettleViewDTO();
            AssertUtil.assertTrue(procInstId.equals(campaignGroupProcessViewDTO.getRealSettleProcessId()), PARAM_ILLEGAL, "当前审批流实例不正确");
            bizCampaignGroupCommandWorkflow.finishSubCampaignGroupRealSettleProcess(context, subCampaignGroupViewDTO, BrandCampaignGroupProcessStatusEnum.getByCode(result));
        }
        return Response.success();
    }

    @Override
    public SingleResponse<CampaignGroupSaleGroupCalViewDTO> calculate(ServiceContext context, CampaignGroupSaleGroupCalViewDTO saleGroupCalViewDTO) {
        CampaignGroupSaleGroupCalViewDTO calculatedResult = bizCampaignGroupCommandWorkflow.calculate(context, saleGroupCalViewDTO);
        return SingleResponse.of(calculatedResult);
    }


    @Override
    public Response updateCheckedResources(ServiceContext context, CampaignGroupCheckedResourceViewDTO checkedResourceViewDTO) {
        AssertUtil.notNull(checkedResourceViewDTO.getId(),BrandOneBPBaseErrorCode.PARAM_REQUIRED, "订单ID不能为空");
        CampaignGroupViewDTO campaignGroup = campaignGroupRepository.getCampaignGroup(context, checkedResourceViewDTO.getId());
        AssertUtil.notNull(campaignGroup,BrandOneBPBaseErrorCode.BIZ_DATA_EMPTY_ERROR, String.format("订单（id=%s）不存在", checkedResourceViewDTO.getId()));
        bizCampaignGroupCommandWorkflow.updateCampaignGroupWithCheckedResource(context, campaignGroup, checkedResourceViewDTO);
        return Response.success();
    }

    /**
     * 分组预估接口，调用B端引擎->算法
     * 这里会区分特秀的分组
     * */
    @Override
    public MultiResponse<CampaignGroupSaleGroupEstimateInfoViewDTO> estimateSaleGroup(ServiceContext context, CampaignGroupSaleGroupEstimateQueryViewDTO campaignGroupSaleGroupEstimateQueryViewDTO) {
        List<CampaignGroupSaleGroupEstimateInfoViewDTO> resultList = bizCampaignGroupCommandWorkflow.estimate(context,campaignGroupSaleGroupEstimateQueryViewDTO);
        return MultiResponse.of(resultList);


    }

    @Override
    public SingleResponse<Integer> updateSaleGroupGoalSetting(ServiceContext serviceContext, CampaignGroupSaleGroupGoalSettingViewDTO saleGroupGoalSettingViewDTO) {
        return SingleResponse.of(bizSaleGroupCommandWorkflow.updateSaleGroupGoalSetting(serviceContext, saleGroupGoalSettingViewDTO));
    }

    @Override
    public SingleResponse<Integer> updateSaleGroupCrowdIds(ServiceContext context, CampaignGroupSaleGroupCrowdViewDTO campaignGroupSaleGroupCrowdViewDTO) {
        return SingleResponse.of(bizSaleGroupCommandWorkflow.updateSaleGroupCrowdIds(context,campaignGroupSaleGroupCrowdViewDTO));
    }

    @Override
    public Response updateCampaignGroupSaleGroupThirdMonitor(ServiceContext context, Long campaignGroupId, List<CampaignGroupSaleGroupPageViewDTO> campaignGroupSaleGroupPageViewDTOS) {
        AssertUtil.notNull(campaignGroupId,"订单不能为空");
        AssertUtil.notEmpty(campaignGroupSaleGroupPageViewDTOS,"第三方监测监测不能为空");

        AbilityInvoker.invokeAll(ISaleGroupThirdMonitorUpdateBusinessAbilityPoint.class, BusinessAbilityRouteContext.builder()
                        .specifiedBusinessAbilityCodes(Lists.newArrayList(ThirdMonitorSupportBusinessAbility.ABILITY_CODE)).build(),
                callback -> callback.invokeForUpdateSaleGroupThirdMonitor(context,campaignGroupId, campaignGroupSaleGroupPageViewDTOS));

//        bizSaleGroupAbility.updateCampaignGroupSaleGroupMonitor(context,campaignGroupId,campaignGroupSaleGroupViewDTOS);
        return Response.success();
    }

    @Override
    public Response updateCampaignGroupGiveAndBoostStatus(ServiceContext context, Long id) {
        AssertUtil.notNull(id, BrandOneBPBaseErrorCode.PARAM_REQUIRED,"订单ID不能为空");
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(context, id);
        AssertUtil.notNull(campaignGroupViewDTO,BrandOneBPBaseErrorCode.BIZ_DATA_EMPTY_ERROR, String.format("订单(id=%s)不存在",id));
        // 重新设置context
        context = ServiceContextUtil.getNewServiceContext(context, campaignGroupViewDTO.getSceneId());
//        bizCampaignGroupAbility.computeAndUpdateCampaignGroupGiveStatus(context, mainCampaignGroupViewDTO);
//        bizCampaignGroupAbility.computeAndUpdateCampaignGroupBoostStatus(context, mainCampaignGroupViewDTO);
        campaignGroupGiveStatusUpdateAbility.handle(context, CampaignGroupGiveStatusUpdateAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
        campaignGroupBoostStatusUpdateAbility.handle(context, CampaignGroupBoostStatusUpdateAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
        return Response.success();
    }

    @Override
    public Response addPurchaseOrder(ServiceContext context, Long id) {
        AssertUtil.notNull(id,BrandOneBPBaseErrorCode.PARAM_REQUIRED,"参数必填");
        CampaignGroupViewDTO campaignGroup = campaignGroupRepository.getCampaignGroup(context,id);
        AssertUtil.notNull(campaignGroup,BrandOneBPBaseErrorCode.BIZ_DATA_EMPTY_ERROR,"未找到订单");
        return bizCampaignGroupCommandWorkflow.addPurchaseOrder(context, campaignGroup);
    }

    @Override
    public Response updateCampaignGroupAssignOrderStatus(ServiceContext serviceContext, Long id, Integer assignOrderStatus) {
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(serviceContext, id);
        AssertUtil.assertTrue(campaignGroupViewDTO != null, BrandOneBPBaseErrorCode.PARAM_REQUIRED, "订单信息不能为空");
        AssertUtil.notNull(BrandCampaignGroupAssignOrderStatusEnum.getByCode(assignOrderStatus), String.format("派单状态不在指定范围内:%s", JSON.toJSONString(BrandCampaignGroupAssignOrderStatusEnum.values())));

        CampaignGroupViewDTO updateCampaignGroupViewDTO = new CampaignGroupViewDTO();
        CampaignGroupContentViewDTO contentViewDTO = new CampaignGroupContentViewDTO();
        updateCampaignGroupViewDTO.setId(campaignGroupViewDTO.getId());
        contentViewDTO.setAssignOrderStatus(assignOrderStatus);
        if (Objects.equals(assignOrderStatus, BrandCampaignGroupAssignOrderStatusEnum.SELLER_CONFIRMED.getCode())) {
            contentViewDTO.setSolutionSellerConfirmModifyTime(new Date());
        }
        updateCampaignGroupViewDTO.setCampaignGroupContentViewDTO(contentViewDTO);
        campaignGroupRepository.updateCampaignGroupPart(serviceContext, updateCampaignGroupViewDTO);
        return Response.success();
    }

    @Override
    public Response deleteCampaignGroupById(ServiceContext context, Long id) {
        AssertUtil.assertTrue(id != null, "订单ID不能为空");
        bizCampaignGroupCommandWorkflow.deleteCampaignGroup(context, id);
        return Response.success();
    }

    @Override
    public Response saveCompleteInfo(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO) {
        bizCampaignGroupCommandWorkflow.saveCompleteInfo(context, campaignGroupViewDTO);
        return Response.success();
    }

}
