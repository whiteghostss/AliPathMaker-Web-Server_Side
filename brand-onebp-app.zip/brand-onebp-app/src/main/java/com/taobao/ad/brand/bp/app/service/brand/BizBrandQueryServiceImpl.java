package com.taobao.ad.brand.bp.app.service.brand;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.common.BrandViewDTO;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.api.brand.BizBrandQueryService;
import com.taobao.ad.brand.bp.client.dto.brand.BrandQueryViewDTO;
import com.taobao.ad.brand.bp.domain.brand.BrandRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Optional;

/**
 * @author yanjingang
 * @date 2025/5/12
 */
@HSFProvider(serviceInterface = BizBrandQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizBrandQueryServiceImpl implements BizBrandQueryService {

    private final BrandRepository brandRepository;

    @Override
    public MultiResponse<BrandViewDTO> findBrandList(ServiceContext context, BrandQueryViewDTO query) {
        if (query == null || StringUtils.isBlank(query.getKeyword())) {
            return MultiResponse.EMPTY;
        }
        List<BrandViewDTO> brandViewDTOS = Lists.newArrayList();
        if (StringUtils.isNumeric(query.getKeyword())) {
            BrandViewDTO brandViewDTO = brandRepository.getBrand(Long.parseLong(query.getKeyword()));
            Optional.ofNullable(brandViewDTO).ifPresent(brandViewDTOS::add);
        } else {
            brandViewDTOS.addAll(brandRepository.queryByKeyword(query.getKeyword(), query.getPageSize()));
        }

        return MultiResponse.of(brandViewDTOS, brandViewDTOS.size());
    }

    @Override
    public MultiResponse<BrandViewDTO> getBrandList(ServiceContext context, List<Long> brandIds) {
        if (CollectionUtils.isEmpty(brandIds)) {
            return MultiResponse.EMPTY;
        }
        List<BrandViewDTO> brandViewDTOS = brandRepository.queryBrand(brandIds);
        return MultiResponse.of(brandViewDTOS, brandViewDTOS.size());
    }
}
