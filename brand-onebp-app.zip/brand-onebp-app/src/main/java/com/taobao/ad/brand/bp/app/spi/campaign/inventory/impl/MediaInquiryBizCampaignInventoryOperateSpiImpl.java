package com.taobao.ad.brand.bp.app.spi.campaign.inventory.impl;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.nb.framework.core.annotation.AbilitySpiInstance;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.app.spi.campaign.inventory.BizCampaignInventoryOperateSpi;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignInquiryOperateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignScheduleViewDTO;
import com.taobao.ad.brand.bp.domain.inventory.InventoryRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignInventoryWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.ICampaignGroupMediaInquiryOrderUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.CampaignGroupMediaInquiryOrderUpdateAbilityParam;
import org.apache.commons.collections4.CollectionUtils;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@AbilitySpiInstance(bizCode = BizCampaignInventoryOperateSpi.MEDIA_INQUIRY, name = "mediaInquiryBizCampaignInventoryOperateSpiImpl", desc = "媒体询量操作实现")
public class MediaInquiryBizCampaignInventoryOperateSpiImpl extends DefaultBizCampaignInventoryOperateSpiImpl {
    @Resource
    private InventoryRepository inventoryRepository;
    @Resource
    private ICampaignGroupMediaInquiryOrderUpdateAbility campaignGroupInquiryOrderUpdateAbility;

    @Override
    public Void inventoryRequest(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO, BizCampaignInventoryWorkflowParam inventoryWorkflowParam) {
        List<CampaignViewDTO> campaignTreeViewDTOList = inventoryWorkflowParam.getCampaignTreeViewDTOList();
        List<CampaignScheduleViewDTO> campaignScheduleViewDTOList = inventoryWorkflowParam.getCampaignScheduleViewDTOList();
        if (CollectionUtils.isEmpty(campaignScheduleViewDTOList)) {
            return null;
        }
        Map<Long, CampaignViewDTO> campaignMap = campaignTreeViewDTOList.stream().collect(Collectors.toMap(v -> v.getId(), v -> v));
        List<CampaignViewDTO> inquiryCampaignViewDTOList = Lists.newArrayList();
        List<CampaignScheduleViewDTO> inquiryCampaignScheduleViewDTOList = Lists.newArrayList();
        for (CampaignScheduleViewDTO campaignScheduleViewDTO : campaignScheduleViewDTOList) {
            CampaignViewDTO campaignViewDTO = campaignMap.get(campaignScheduleViewDTO.getId());
            Map<Long, CampaignViewDTO> subCampaignMap = campaignViewDTO.getSubCampaignViewDTOList().stream().collect(
                    Collectors.toMap(v -> v.getId(), v -> v));
            List<Long> operateCampaignIds = campaignScheduleViewDTO.getOperateSubCampaignIds();
            for (CampaignScheduleViewDTO subCampaignScheduleViewDTO : campaignScheduleViewDTO.getSubCampaignList()) {
                if (operateCampaignIds.contains(subCampaignScheduleViewDTO.getId())) {
                    CampaignViewDTO subCampaignViewDTO = subCampaignMap.get(subCampaignScheduleViewDTO.getId());
                    inquiryCampaignViewDTOList.add(subCampaignViewDTO);
                    inquiryCampaignScheduleViewDTOList.add(subCampaignScheduleViewDTO);
                }
            }
        }
        Long mediaInquiryOrderId = inventoryRepository.mediaInquiry(serviceContext, inquiryCampaignViewDTOList, inquiryCampaignScheduleViewDTOList);
        for (CampaignScheduleViewDTO campaignScheduleViewDTO : campaignScheduleViewDTOList) {
            campaignScheduleViewDTO.setMediaInquiryOrderId(mediaInquiryOrderId);
        }
        //媒体询量单id需要记录到订单实体，供后续发起媒体询量使用
//        bizCampaignInventoryAbility.updateCampaignGroupInquiryOrder(serviceContext, campaignScheduleViewDTOList);
        campaignGroupInquiryOrderUpdateAbility.handle(serviceContext,
                CampaignGroupMediaInquiryOrderUpdateAbilityParam.builder().abilityTargets(campaignScheduleViewDTOList).build());
        return null;
    }
}

