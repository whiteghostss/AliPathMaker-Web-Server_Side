package com.taobao.ad.brand.bp.app.service.adgroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.adgroup.CreativeRefViewDTO;
import com.alibaba.ad.brand.dto.adgroup.resource.AdgroupResourceViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupOnlineStatusEnum;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupTargetTypeEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupMonitorDimensionEnum;
import com.alibaba.ad.nb.ssp.constant.common.CrossSceneEnum;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.app.workflow.adgroup.BizAdgroupCommandWorkflow;
import com.taobao.ad.brand.bp.app.workflow.adgroup.BizAdgroupMonitorWorkflow;
import com.taobao.ad.brand.bp.client.api.adgroup.BizAdgroupQueryService;
import com.taobao.ad.brand.bp.client.dto.adgroup.AdgroupWarnViewDTO;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupExportMonitorQueryDTO;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryOption;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.DateViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.SaleGroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportTaskViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.query.ReportTaskQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.common.BizTaskFunctionEnum;
import com.taobao.ad.brand.bp.common.threadpooltask.AdgroupCreativeQueryTaskIdentifier;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.domain.adgroup.repository.AdgroupRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeRepository;
import com.taobao.ad.brand.bp.domain.report.repository.ReportSyncTaskRepository;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupBindCreativeQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.query.IAdgroupBindCreativeQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.query.IAdgroupStructurePageQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.query.IAdgroupStructureQueryAbility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 单元相关的查询实现
 * @author 弈云
 * @date 2023年03月08日
 */
@HSFProvider(serviceInterface = BizAdgroupQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizAdgroupQueryServiceImpl implements BizAdgroupQueryService {
    private final AdgroupRepository adgroupRepository;
    private final CreativeRepository creativeRepository;
    private final BizAdgroupMonitorWorkflow bizAdgroupMonitorWorkflow;
    private final ReportSyncTaskRepository reportSyncTaskRepository;
    private final CampaignGroupRepository campaignGroupRepository;
    private final ResourcePackageRepository resourcePackageRepository;
    private final BizAdgroupCommandWorkflow bizAdgroupCommandWorkflow;
    private final IAdgroupStructureQueryAbility adgroupStructureQueryAbility;
    private final IAdgroupStructurePageQueryAbility adgroupStructurePageQueryAbility;
    private final IAdgroupBindCreativeQueryAbility adgroupBindCreativeQueryAbility;
    private final AdgroupCreativeQueryTaskIdentifier adgroupCreativeQueryTaskIdentifier;

    /**
     * 分页查询单元
     * */

    @Override
    public MultiResponse<AdgroupViewDTO> findAdgroupPage(ServiceContext context, AdgroupQueryViewDTO query, AdgroupQueryOption adgroupQueryOption) {
        initCreativeFullAdgroupStatus(context, query);
        initSupportMonitorFilterParams(context,query);
        PageResultViewDTO<AdgroupViewDTO> pageResultViewDTO = adgroupStructurePageQueryAbility.handle(context,
                AdgroupStructureQueryAbilityParam.builder().abilityTarget(query).queryOption(adgroupQueryOption).build());
        return MultiResponse.of(pageResultViewDTO.getList(),pageResultViewDTO.getCount());
    }

    @Override
    public MultiResponse<AdgroupWarnViewDTO> getCrossOpaqueSceneAdgroupWarn(ServiceContext context, List<Long> adgroupIds) {
        List<AdgroupWarnViewDTO> adgroupWarnViewDTOList =  bizAdgroupCommandWorkflow.batchGetWarnList(context, adgroupIds);
        return MultiResponse.of(adgroupWarnViewDTOList);
    }

    @Override
    public MultiResponse<AdgroupViewDTO> findAdgroupListNoPage(ServiceContext context, AdgroupQueryViewDTO query, AdgroupQueryOption adgroupQueryOption) {
        List<AdgroupViewDTO> resultList = adgroupStructureQueryAbility.handle(context, AdgroupStructureQueryAbilityParam.builder()
                .abilityTarget(query).queryOption(adgroupQueryOption).build());
        return MultiResponse.of(resultList);
    }


    @Override
    public SingleResponse<AdgroupViewDTO> getAdgroupById(ServiceContext context, Long adgroupId, AdgroupQueryOption adgroupQueryOption) {
        AdgroupQueryOption queryOption = AdgroupQueryOption.builder().needCreative(true).needTarget(true).build();
        List<AdgroupViewDTO> adgroupViewDTOList = adgroupStructureQueryAbility.handle(context, AdgroupStructureQueryAbilityParam.builder()
                .abilityTarget(AdgroupQueryViewDTO.builder().ids(Collections.singletonList(adgroupId)).build()).queryOption(queryOption).build());
        if(CollectionUtils.isNotEmpty(adgroupViewDTOList)){
            return SingleResponse.of(adgroupViewDTOList.get(0));
        }
        return SingleResponse.of(null);
    }

    @Override
    public SingleResponse<AdgroupViewDTO> queryAdgroupByName(ServiceContext context, String title,Long excluAdgroupId, AdgroupQueryOption adgroupQueryOption) {
        return SingleResponse.of(null);
    }
    @Override
    public SingleResponse<String> exportMonitor(ServiceContext context, Long adgroupId) {
        AssertUtil.notNull(adgroupId,"单元id不允许为空");

        AdgroupQueryOption queryOption = AdgroupQueryOption.builder().needCreative(true).build();
        List<AdgroupViewDTO> adgroupViewDTOList = adgroupStructureQueryAbility.handle(context, AdgroupStructureQueryAbilityParam.builder()
                .abilityTarget(AdgroupQueryViewDTO.builder().ids(Lists.newArrayList(adgroupId)).build()).queryOption(queryOption).build());
        AssertUtil.notEmpty(adgroupViewDTOList,"单元查询不存在");
        AdgroupViewDTO adgroupViewDTO = adgroupViewDTOList.get(0);
        AssertUtil.assertTrue(!Objects.equals(BrandAdgroupOnlineStatusEnum.DRAFT.getCode(),adgroupViewDTO.getOnlineStatus()),"草稿状态单元，不支持该操作");

        Integer sspCrossScene = Optional.ofNullable(adgroupViewDTO.getAdgroupResourceViewDTO())
                .map(AdgroupResourceViewDTO::getSspCrossScene).orElse(null);
        AssertUtil.assertTrue(Objects.equals(CrossSceneEnum.CROSS_OPAQUE_SCENE.getValue(),sspCrossScene)
                || Objects.equals(adgroupViewDTO.getTargetType(), BrandAdgroupTargetTypeEnum.DIRECT.getCode()),"程序化单元不支持该操作");
        String downloadCdnUrl = bizAdgroupMonitorWorkflow.exportMonitor(context, adgroupViewDTO);
        return SingleResponse.of(downloadCdnUrl);
    }

    @Override
    public SingleResponse<String> exportOrderMonitor(ServiceContext context, AdgroupExportMonitorQueryDTO queryDTO) {
        String downloadCdnUrl = bizAdgroupMonitorWorkflow.exportOrderMonitor(context, queryDTO);
        return SingleResponse.of(downloadCdnUrl);
    }

    @Override
    public MultiResponse<ReportTaskViewDTO> findAdgroupBatchImportTaskList(ServiceContext context, AdgroupQueryViewDTO query) {
        AssertUtil.notNull(query);
        AssertUtil.notNull(query.getCampaignGroupId(), "订单ID不能为空");

        ReportTaskQueryViewDTO queryViewDTO = new ReportTaskQueryViewDTO();
        queryViewDTO.setMemberId(context.getMemberId());
        queryViewDTO.setCampaignGroupId(query.getCampaignGroupId());
        // 异步任务类型
        queryViewDTO.setFunctionCode(BizTaskFunctionEnum.ADGROUP_BATCH_MONITOR_UPDATE.getCode());
        queryViewDTO.setPageSize(200);
        return MultiResponse.of(reportSyncTaskRepository.queryList(context, queryViewDTO));
    }

    private void initSupportMonitorFilterParams(ServiceContext context, AdgroupQueryViewDTO query) {
        if (query.getSupportMonitor() == null) {
            return;
        }
        AssertUtil.assertTrue(query.getCampaignGroupId() != null || CollectionUtils.isNotEmpty(query.getCampaignGroupIds()), "支持监测筛选需要指定订单");
        List<Long> campaignGroupIds = Lists.newArrayList();
        Optional.ofNullable(query.getCampaignGroupId()).ifPresent(campaignGroupIds::add);
        Optional.ofNullable(query.getCampaignGroupIds()).ifPresent(campaignGroupIds::addAll);
        if (CollectionUtils.isEmpty(campaignGroupIds)) {
            return;
        }

        SaleGroupQueryViewDTO saleGroupQueryViewDTO = new SaleGroupQueryViewDTO();
        saleGroupQueryViewDTO.setCampaignGroupIds(campaignGroupIds);

        List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList = campaignGroupRepository.findSaleGroupList(context, saleGroupQueryViewDTO);
        if (CollectionUtils.isEmpty(saleGroupInfoViewDTOList)) {
            return;
        }
        List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupViewDTOS = resourcePackageRepository.getSaleGroupList(context
                , ResourcePackageQueryViewDTO.builder().saleGroupIdList(saleGroupInfoViewDTOList.stream().map(SaleGroupInfoViewDTO::getSaleGroupId).distinct().collect(Collectors.toList())).build()
                , ResourcePackageQueryOption.builder().needProduct(false).needInquiryPriority(false).needSetting(true).build());
        if (CollectionUtils.isEmpty(resourcePackageSaleGroupViewDTOS)) {
            return;
        }
        List<Long> saleGroupIds = resourcePackageSaleGroupViewDTOS.stream()
                .filter(resourcePackageSaleGroupViewDTO -> BrandBoolEnum.BRAND_TRUE.getCode().equals(query.getSupportMonitor()) == (resourcePackageSaleGroupViewDTO.getMonitorConfig() != null
                        && BrandBoolEnum.BRAND_TRUE.getCode().equals(resourcePackageSaleGroupViewDTO.getMonitorConfig().getSupportMonitor())
                        && SaleGroupMonitorDimensionEnum.ADGROUP.getValue().equals(resourcePackageSaleGroupViewDTO.getMonitorConfig().getMonitorDimension())
                ))
                .map(ResourcePackageSaleGroupViewDTO::getId)
                .collect(Collectors.toList());
        if (CollectionUtils.isEmpty(saleGroupIds)) {
            query.setSaleGroupIds(Lists.newArrayList(-1L));
        }
        if (CollectionUtils.isNotEmpty(query.getSaleGroupIds())) {
            saleGroupIds.retainAll(query.getSaleGroupIds());
        }
        query.setSaleGroupIds(saleGroupIds);
    }


    public void initCreativeFullAdgroupStatus(ServiceContext context, AdgroupQueryViewDTO query) {
        if (!BrandBoolEnum.BRAND_TRUE.getCode().equals(query.getCreativeNotFullCoverStatus())) {
            return;
        }
        List<AdgroupViewDTO> adgroupViewDTOList = adgroupRepository.queryAdgroupBasicListNoPage(context, query);
        if (CollectionUtils.isEmpty(adgroupViewDTOList)) {
            return;
        }
        long startTime = System.currentTimeMillis();
        this.fillCreativeRef(context,adgroupViewDTOList,BrandBoolEnum.BRAND_TRUE.getCode(),false);

        RogerLogger.info("creativeBind cost rt {}", System.currentTimeMillis()-startTime);
        Map<Long, List<CreativeViewDTO>> mapCreativeRef = adgroupBindCreativeQueryAbility.handle(context,
                AdgroupBindCreativeQueryAbilityParam.builder().abilityTargets(adgroupViewDTOList).build());
        if(MapUtils.isEmpty(mapCreativeRef)){
            query.setIds(Lists.newArrayList(-1L));
            return;
        }
        RogerLogger.info("cost creative cost rt {}", System.currentTimeMillis()-startTime);



        List<Long> result = adgroupViewDTOList.stream().filter(adgroupViewDTO -> {
                    List<CreativeViewDTO> creativeViewDTOList = mapCreativeRef.get(adgroupViewDTO.getId());
                    if (CollectionUtils.isEmpty(creativeViewDTOList)) {
                        return true;
                    }
                    List<DateViewDTO> dateViewDTOS = creativeViewDTOList.stream()
                            .filter(Objects::nonNull).map(creativeViewDTO -> {
                                DateViewDTO creativeDate = new DateViewDTO();
                                creativeDate.setStartDate(creativeViewDTO.getStartTime());
                                creativeDate.setEndDate(creativeViewDTO.getEndTime());
                                //结合风控时间, 有可能为空
                                if (creativeViewDTO.getCreativeAudit() != null && creativeViewDTO.getCreativeAudit().getMamaAudit() != null) {
                                    Date effectiveTime = creativeViewDTO.getCreativeAudit().getMamaAudit().getEffectiveTime();
                                    Date expireTime = creativeViewDTO.getCreativeAudit().getMamaAudit().getExpireTime();
                                    if (effectiveTime != null && expireTime != null) {
                                        DateViewDTO creativeAuditDate = new DateViewDTO();
                                        creativeAuditDate.setStartDate(effectiveTime);
                                        creativeAuditDate.setEndDate(expireTime);
                                        creativeDate = BrandDateUtil.findIntersection(creativeDate, creativeAuditDate);
                                    }
                                }
                                return creativeDate;
                            }).filter(Objects::nonNull).collect(Collectors.toList());
                    if (CollectionUtils.isEmpty(dateViewDTOS)) {
                        return true;
                    }
                    //判断创意时间是否完全覆盖单元周期
                    DateViewDTO adgroupDateViewDTO = new DateViewDTO();
                    adgroupDateViewDTO.setStartDate(adgroupViewDTO.getStartTime());
                    adgroupDateViewDTO.setEndDate(adgroupViewDTO.getEndTime());
                    return !BrandDateUtil.isFullyCovered(dateViewDTOS, adgroupDateViewDTO);
                }).map(AdgroupViewDTO::getId)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
        RogerLogger.info("cost end rt {}", System.currentTimeMillis()-startTime);

        if (CollectionUtils.isNotEmpty(result)) {
            if (CollectionUtils.isNotEmpty(query.getIds())) {
                result.retainAll(query.getIds());
                query.setIds(CollectionUtils.isEmpty(result) ? Lists.newArrayList(-1L) : result);
            } else {
                query.setIds(result);
            }
        }else {
            query.setIds(Lists.newArrayList(-1L));
        }
    }


    /**
     * adgroupViewDTOList填充创意信息
     * @param context
     * @param adgroupViewDTOList
     * @param onlineStatus BrandBoolEnum 绑定状态，默认查询全部状态
     * @param isNeedSetting creativeRef-Setting，默认查询全部状态
     */
    private void fillCreativeRef(ServiceContext context, List<AdgroupViewDTO> adgroupViewDTOList, Integer onlineStatus, boolean isNeedSetting) {
        List<Long> adgroupIds = adgroupViewDTOList.stream().map(AdgroupViewDTO::getId).collect(Collectors.toList());
        List<List<Long>> adgroupIdPartitionList = Lists.partition(adgroupIds, 50);

        List<List<CreativeRefViewDTO>> batchedOperate =
                TaskStream.execute(adgroupCreativeQueryTaskIdentifier, adgroupIdPartitionList, (adgroupIdList, index) -> {
                            CreativeQueryViewDTO creativeQueryViewDTO = new CreativeQueryViewDTO();
                            creativeQueryViewDTO.setAdgroupIds(adgroupIdList);
                            creativeQueryViewDTO.setOnlineStatus(onlineStatus);
                            return creativeRepository.findCreativeRefList(context, creativeQueryViewDTO,isNeedSetting);
                        })
                        .commit()
                        .getResultList();

        if (CollectionUtils.isNotEmpty(batchedOperate)) {
            Map<Long, List<CreativeRefViewDTO>> mapCreativeRef = batchedOperate.stream().flatMap(Collection::stream).collect(Collectors.toList())
                    .stream().collect(Collectors.groupingBy(CreativeRefViewDTO::getAdgroupId));
            adgroupViewDTOList.forEach(adgroupViewDTO -> adgroupViewDTO.setCreativeRefViewDTOList(mapCreativeRef.getOrDefault(adgroupViewDTO.getId(), Lists.newArrayList())));
        }
    }
}