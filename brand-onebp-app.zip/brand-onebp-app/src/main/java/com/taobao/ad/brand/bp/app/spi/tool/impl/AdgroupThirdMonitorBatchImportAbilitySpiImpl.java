package com.taobao.ad.brand.bp.app.spi.tool.impl;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.nb.framework.core.annotation.AbilitySpiInstance;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alibaba.ad.nb.tpp.exception.TppException;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.app.spi.tool.BatchImportAbilitySpi;
import com.taobao.ad.brand.bp.app.workflow.adgroup.BizAdgroupCommandWorkflow;
import com.taobao.ad.brand.bp.client.dto.adgroup.AdgroupBatchImportParamViewDTO;
import com.taobao.ad.brand.bp.client.dto.adgroup.AdgroupBatchImportRawViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.ErrorMessageDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportTaskViewDTO;
import com.taobao.ad.brand.bp.client.dto.tool.BatchImportDistLockParamViewDTO;
import com.taobao.ad.brand.bp.client.dto.tool.BatchImportParamViewDTO;
import com.taobao.ad.brand.bp.client.enums.report.ReportTaskStatusEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.enums.distlock.DistLockEnum;
import com.taobao.ad.brand.bp.common.threadpooltask.AdgroupUpdteMonitorTaskIdentifier;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.report.repository.ReportSyncTaskRepository;
import com.taobao.eagleeye.EagleEye;
import org.apache.commons.collections4.CollectionUtils;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

@AbilitySpiInstance(bizCode = BatchImportAbilitySpi.BATCH_IMPORT_ADGROUP_MONITOR, name = "AdgroupThirdMonitorBatchImportAbilitySpiImpl", desc = "单元第三方监测批量导入")
public class AdgroupThirdMonitorBatchImportAbilitySpiImpl extends DefaultBatchImportAbilitySpiImpl {

    @Resource
    private AdgroupUpdteMonitorTaskIdentifier adgroupUpdteMonitorTaskIdentifier;
    @Resource
    private ReportSyncTaskRepository reportSyncTaskRepository;
    @Resource
    private BizAdgroupCommandWorkflow bizAdgroupCommandWorkflow;

//    private static final ThreadPoolExecutor THREAD_POOL = new ThreadPoolExecutor(
//            20, 20, 60L, TimeUnit.SECONDS, new ArrayBlockingQueue<>(2048),
//            new ThreadFactoryBuilder().setNameFormat("adgroup-monitor-workflow-%d").build());

    @Override
    public Void validateImportParam(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO) {
        AdgroupBatchImportParamViewDTO adgroupBatchImportParamViewDTO = (AdgroupBatchImportParamViewDTO) batchImportParamViewDTO;
        AssertUtil.notNull(adgroupBatchImportParamViewDTO.getTaskId(),"单元批量导入任务参数缺失");
        AssertUtil.notNull(adgroupBatchImportParamViewDTO.getCampaignGroupId(),"单元批量导入任务订单参数缺失");
        AssertUtil.notNull(adgroupBatchImportParamViewDTO.getAdgroupBatchImportRawViewDTOS(),"单元批量导入任务单元参数缺失");
        AssertUtil.notNull(adgroupBatchImportParamViewDTO.getTaskViewDTO(), "查询单元批量导入监测任务失败");
        return null;
    }

    @Override
    public BatchImportDistLockParamViewDTO buildImportDisLockParam(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO) {
        AdgroupBatchImportParamViewDTO adgroupBatchImportParamViewDTO = (AdgroupBatchImportParamViewDTO) batchImportParamViewDTO;
        Long campaignGroupId = adgroupBatchImportParamViewDTO.getCampaignGroupId();
        Long taskId = adgroupBatchImportParamViewDTO.getTaskId();

        DistLockEnum distLockEnum = DistLockEnum.ADGROUP_BATCH_IMPORT_MONITOR_KEY;
        BatchImportDistLockParamViewDTO distLockParamViewDTO = new BatchImportDistLockParamViewDTO();
        distLockParamViewDTO.setLockKey(distLockEnum.formatLockKey(campaignGroupId));
        distLockParamViewDTO.setLockReqValue(distLockEnum.formatLockValue(taskId));
        distLockParamViewDTO.setExpireTime(distLockEnum.getExpireTime());
        return distLockParamViewDTO;
    }

    @Override
    public String tryDisLockErrorMessage(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO, String distCurValue) {
        AdgroupBatchImportParamViewDTO adgroupBatchImportParamViewDTO = (AdgroupBatchImportParamViewDTO) batchImportParamViewDTO;
        Long campaignGroupId = adgroupBatchImportParamViewDTO.getCampaignGroupId();
        String errorMessage = String.format("当前订单 %d 下已有正在执行中的单元批量导入监测导入任务 [%s] trace: %s", campaignGroupId, distCurValue, EagleEye.getTraceId());
        ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO();
        errorMessageDTO.setErrorMessage(errorMessage);
        return JSONObject.toJSONString(Lists.newArrayList(errorMessageDTO));
    }

    @Override
    public Void invokeImport(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO) {
        RogerLogger.info("单元批量导入监测开始执行，taskViewDTO=" + JSON.toJSONString(batchImportParamViewDTO.getTaskViewDTO()));
        AdgroupBatchImportParamViewDTO adgroupBatchImportParamViewDTO = (AdgroupBatchImportParamViewDTO) batchImportParamViewDTO;
        List<AdgroupBatchImportRawViewDTO> adgroupBatchImportRawViewDTOS = adgroupBatchImportParamViewDTO.getAdgroupBatchImportRawViewDTOS();
        TaskStream
                .consume(adgroupUpdteMonitorTaskIdentifier, adgroupBatchImportRawViewDTOS, (adgroupBatchImportRawViewDTO, i) -> {
                    if (Boolean.TRUE.equals(adgroupBatchImportRawViewDTO.getIsFiltered())) {
                        // 本条计划被预检查过滤
                        return;
                    }
                    AdgroupViewDTO adgroupViewDTO = adgroupBatchImportRawViewDTO.getAdgroupViewDTO();
                    try {
                        bizAdgroupCommandWorkflow.updateAdgroupMonitor(context,adgroupViewDTO);
                    } catch (Exception e) {
                        // 执行批量新建异常，写入执行信息
                        RogerLogger.error("批量导入单元监测失败 {}", JSON.toJSONString(adgroupViewDTO), e);
                        buildErrorMessage(i, e, adgroupBatchImportRawViewDTO, adgroupViewDTO);
                    }
                })
                .commit()
                .handle();
        RogerLogger.info("单元批量导入监测执行完成，taskViewDTO=" + JSON.toJSONString(batchImportParamViewDTO.getTaskViewDTO()));
        return null;
    }

    /**
     * 构建错误信息
     *
     * @param index
     * @param e
     * @param adgroupBatchImportRawViewDTO
     * @param adgroupViewDTO
     */
    private void buildErrorMessage(int index, Exception e, AdgroupBatchImportRawViewDTO adgroupBatchImportRawViewDTO, AdgroupViewDTO adgroupViewDTO) {
        if (e instanceof TppException) {
            if (e.getCause() != null && e.getCause() instanceof BrandOneBPException) {
                e = (BrandOneBPException) e.getCause();
            }
        }
        ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO();
        errorMessageDTO.setSerialId(index + 1);
        errorMessageDTO.setErrorMessage(e.toString());
        errorMessageDTO.setId(adgroupViewDTO.getId());
        errorMessageDTO.setName(adgroupViewDTO.getTitle());
        adgroupBatchImportRawViewDTO.setIsFiltered(true);
        adgroupBatchImportRawViewDTO.setErrorMessage(errorMessageDTO);
    }

    @Override
    public Void updateImportResult(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO) {
        AdgroupBatchImportParamViewDTO adgroupBatchImportParamViewDTO = (AdgroupBatchImportParamViewDTO) batchImportParamViewDTO;
        List<ErrorMessageDTO> errorMessageList = adgroupBatchImportParamViewDTO.getAdgroupBatchImportRawViewDTOS().stream()
                .filter(campaignBatchImportRawViewDTO -> Boolean.TRUE.equals(campaignBatchImportRawViewDTO.getIsFiltered()))
                .map(AdgroupBatchImportRawViewDTO::getErrorMessage)
                .collect(Collectors.toList());

        ReportTaskViewDTO taskViewDTO = batchImportParamViewDTO.getTaskViewDTO();
        if (CollectionUtils.isNotEmpty(errorMessageList) && errorMessageList.size() == adgroupBatchImportParamViewDTO.getAdgroupBatchImportRawViewDTOS().size()) {
            // 全部异常，任务置为失败，聚合失败原因
            taskViewDTO.setErrorMsg(JSONObject.toJSONString(errorMessageList));
            reportSyncTaskRepository.runFail(context, taskViewDTO);
        } else if (CollectionUtils.isEmpty(errorMessageList)) {
            // 没有异常记录，任务设置为成功
            taskViewDTO.setStatus(ReportTaskStatusEnum.SUCCEED.getValue());
            reportSyncTaskRepository.modifyStatus(context, taskViewDTO);
        } else if (CollectionUtils.isNotEmpty(errorMessageList) && errorMessageList.size() < adgroupBatchImportParamViewDTO.getAdgroupBatchImportRawViewDTOS().size()) {
            // 过滤出的失败的计划条数小于总条数时设置状态为部分成功
            taskViewDTO.setErrorMsg(JSONObject.toJSONString(errorMessageList));
            taskViewDTO.setStatus(ReportTaskStatusEnum.PARTIAL_SUCCESS.getValue());
            reportSyncTaskRepository.modifyStatus(context, taskViewDTO);
        }
        return null;
    }

    @Override
    public String invokeImportExceptionMessage(ServiceContext context, BatchImportParamViewDTO batchImportParamViewDTO, String exceptionMeg) {
        ErrorMessageDTO errorMessageDTO=new ErrorMessageDTO();
        errorMessageDTO.setErrorMessage("单元批量导入监测: " + exceptionMeg + " trace: " + EagleEye.getTraceId());
        return JSONObject.toJSONString(Lists.newArrayList(errorMessageDTO));
    }
}
