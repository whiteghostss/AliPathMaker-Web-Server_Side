package com.taobao.ad.brand.bp.app.service.campaign;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.biz.definition.constants.Product;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryLockViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquirySchedulePolicyViewDTO;
import com.alibaba.ad.brand.dto.campaign.inquiry.CampaignInquiryViewDTO;
import com.alibaba.ad.brand.dto.campaign.keyword.CampaignKeywordViewDTO;
import com.alibaba.ad.brand.dto.campaign.keyword.CampaignWordPackageViewDTO;
import com.alibaba.ad.brand.dto.campaign.price.DayPriceViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.common.BottomDateViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.brand.dto.frequency.FrequencyViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.*;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleTypeEnum;
import com.alibaba.ad.brand.sdk.constant.creative.field.BrandCreativeSourceEnum;
import com.alibaba.ad.brand.sdk.constant.frequency.field.BrandFrequencyBizTypeEnum;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleProductLineEnum;
import com.alibaba.ad.nb.ssp.constant.common.MediaScopeEnum;
import com.alibaba.ad.organizer.dto.query.CampaignQuery;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignCommandWorkflow;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignInventoryWorkflow;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignQueryWorkflow;
import com.taobao.ad.brand.bp.client.api.campaign.BizCampaignQueryService;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.*;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignInventoryAutoReleaseQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignKeywordEstimateQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignEffectAdvQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.effect.EffectAdvertiserViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.ReportTaskViewDTO;
import com.taobao.ad.brand.bp.client.dto.report.query.ReportTaskQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.enums.SwitchEnum;
import com.taobao.ad.brand.bp.client.enums.keyword.KeywordRecommendMethodEnum;
import com.taobao.ad.brand.bp.common.constant.CommonConstant;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.converter.campaign.CampaignViewPageConverter;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.common.spi.ExtensionPointsFactory;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.NumberUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.campaign.spi.keyword.BizCampaignKeywordEstimateSpi;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.config.CampaignInventoryAutoReleaseDiamondConfig;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeRepository;
import com.taobao.ad.brand.bp.domain.frequency.repository.FrequencyRepository;
import com.taobao.ad.brand.bp.domain.keywordcenter.repository.KeywordRepository;
import com.taobao.ad.brand.bp.domain.report.repository.ReportSyncTaskRepository;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.keyword.ICampaignKeywordAccessValidateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.keyword.ICampaignKeywordInitAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.keyword.ICampaignKeywordNormalValidateAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignCrowdMapQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignKeywordAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignCrowdMapQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructurePageQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.CreativeQueryParamResetAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.query.ICreativeQueryParamResetAbility;
import com.taobao.ad.brand.bp.domain.ssp.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.BIZ_DATA_EMPTY_ERROR;

/**
 * @author yuhui.sl
 * @since 2020/2/3 14:59
 */
@HSFProvider(serviceInterface = BizCampaignQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizCampaignQueryServiceImpl implements BizCampaignQueryService {
    private final CampaignRepository campaignRepository;
    private final CampaignViewPageConverter campaignViewPageConverter;
    private final ProductRepository productRepository;
    private final BizCampaignQueryWorkflow bizCampaignQueryWorkflow;
    private final CampaignGroupRepository campaignGroupRepository;
    private final ReportSyncTaskRepository reportSyncTaskRepository;
    private final CreativeRepository creativeRepository;

    private final FrequencyRepository frequencyRepository;
    private final CampaignInventoryAutoReleaseDiamondConfig campaignInventoryAutoReleaseDiamondConfig;
    private final ICampaignKeywordAccessValidateAbility campaignKeywordAccessValidateAbility;
    private final ICampaignKeywordNormalValidateAbility campaignKeywordNormalValidateAbility;
    private final ICampaignKeywordInitAbility campaignKeywordInitAbility;
    private final ICreativeQueryParamResetAbility creativeQueryParamResetAbility;
    private final KeywordRepository keywordRepository;
    private final ResourcePackageRepository resourcePackageRepository;
    private final BizCampaignInventoryWorkflow bizCampaignInventoryWorkflow;
    private final ICampaignStructurePageQueryAbility campaignStructurePageQueryAbility;
    private final ICampaignCrowdMapQueryAbility campaignCrowdMapQueryAbility;
    private final BizCampaignCommandWorkflow bizCampaignCommandWorkflow;

    @Override
    public MultiResponse<CampaignPageViewDTO> findCampaignPage(ServiceContext context, CampaignQueryViewDTO query, CampaignQueryOption queryOption) {
        if(query.getCampaignLevel() == null){
            query.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
        }
        RogerLogger.info("campaignquery findCampaignPage test log ");

        PageResultViewDTO<CampaignViewDTO> response = campaignStructurePageQueryAbility.handle(context,
                CampaignStructureQueryAbilityParam.builder().abilityTarget(query).queryOption(queryOption).build());
        if(CollectionUtils.isEmpty(response.getList())){
            return MultiResponse.empty();
        }
        List<CampaignViewDTO> campaignViewDTOList = response.getList();
        //补全二级计划
        List<Long> productIdList = Lists.newArrayList();
        productIdList.addAll(campaignViewDTOList.stream().map(item->item.getCampaignResourceViewDTO().getSspProductId()).collect(Collectors.toList()));
        campaignViewDTOList.stream().filter(item -> CollectionUtils.isNotEmpty(item.getSubCampaignViewDTOList()))
                .flatMap(item -> item.getSubCampaignViewDTOList().stream())
                .map(item -> item.getCampaignResourceViewDTO().getSspProductId()).forEach(productIdList::add);
        Map<Long, ProductViewDTO> map = Maps.newHashMap();
        if(CollectionUtils.isNotEmpty(productIdList)){
            List<ProductViewDTO> productViewDTOList = productRepository.getProductByIds(productIdList);
            map = productViewDTOList.stream().collect(Collectors.toMap(ProductViewDTO::getId, Function.identity(), (v1, v2) -> v2));
        }
        List<CampaignPageViewDTO> resultList = Lists.newArrayList();
        for (CampaignViewDTO campaignViewDTO : response.getList()) {
            CampaignPageViewDTO campaignPageViewDTO = campaignViewPageConverter.convertDTO2ViewDTO(campaignViewDTO);
            ProductViewDTO productViewDTO = map.get(campaignPageViewDTO.getSspProductId());
            fillPageViewInfo(campaignPageViewDTO, productViewDTO);
            if (queryOption.isNeedChildren() &&  CollectionUtils.isNotEmpty(campaignViewDTO.getSubCampaignViewDTOList())) {
                List<CampaignPageViewDTO> subCampaignPageViewDTOList = Lists.newArrayList();
                for (CampaignViewDTO subCampaignViewDTO : campaignViewDTO.getSubCampaignViewDTOList()) {
                    CampaignPageViewDTO campaignSubPageViewDTO = campaignViewPageConverter.convertDTO2ViewDTO(subCampaignViewDTO);
                    ProductViewDTO subProductViewDTO = map.get(campaignSubPageViewDTO.getSspProductId());
                    fillPageViewInfo(campaignSubPageViewDTO, subProductViewDTO);
                    subCampaignPageViewDTOList.add(campaignSubPageViewDTO);
                }
                campaignPageViewDTO.setSubCampaignPageViewDTOList(subCampaignPageViewDTOList);
            }
            // 填充自动释量信息
            if(queryOption.isNeedWarningInfo()) {
                try {
                    fillAutoReleaseWarningInfo(context, campaignPageViewDTO);
                }catch (Exception e) {
                    RogerLogger.error("填充计划自动释量预警信息失败 计划ID {}", campaignPageViewDTO.getId(), e);
                }
            }
            resultList.add(campaignPageViewDTO);
        }
        return MultiResponse.of(resultList, response.getCount());
    }

    /**
     * DMP使用，校验人群是否可删除。
     * @param context
     * @param crowdId
     * @return 计划信息。
     * */
    @Override
    public MultiResponse<Boolean> queryIsBindCampaignByCrowdId(ServiceContext context, Long crowdId) {

        boolean result = campaignRepository.queryIsBindCampaignByCrowdId(context, crowdId);
        return MultiResponse.of(result);

    }

    @Override
    public MultiResponse<CampaignViewDTO> findCampaignList(ServiceContext context, CampaignQueryViewDTO query) {
        List<CampaignViewDTO> resultList = campaignRepository.queryCampaignList(context, query);
        return MultiResponse.of(resultList);
    }

    @Override
    public MultiResponse<CampaignViewDTO> findCampaignList(ServiceContext context, CampaignQueryViewDTO query, CampaignQueryOption queryOption) {
        if (query.getCampaignLevel() == null) {
            query.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
        }
        CampaignQueryOption buildQueryOption;
        if(queryOption != null){
            buildQueryOption = CampaignQueryOption.builder()
                    .needChildren(queryOption.isNeedChildren())
                    .needTarget(queryOption.isNeedTarget())
                    .needFrequency(queryOption.isNeedFrequency())
                    .needCampaignTree(queryOption.isNeedCampaignTree())
                    .build();
        }else{
            buildQueryOption = CampaignQueryOption.builder().build();
        }
        List<CampaignViewDTO> campaignViewDTOList = bizCampaignQueryWorkflow.getCampaignInfoListByOption(context, query, buildQueryOption);
        return MultiResponse.of(campaignViewDTOList);
    }

    @Override
    public MultiResponse<CampaignShowConfigViewDTO> getCampaignShowConfig(ServiceContext serviceContext, CampaignShowConfigQueryViewDTO queryViewDTO) {
        List<CampaignShowConfigViewDTO> showConfigViewDTOS = bizCampaignQueryWorkflow.getCampaignShowConfig(serviceContext, queryViewDTO);
        return MultiResponse.of(showConfigViewDTOS);
    }

    /**
     * 获取计划的打底信息，用来判断是否可以创建媒体直投
     * 1. 计划是三环PDB , 2. 计划下的子计划不能跨媒体 3. 计划下的分天锁量信息全部是非精准或者某一天需要打底。
     * 123同时满足才可以
     * @param context
     * @param campaignId
     * */
    @Override
    public MultiResponse<BottomDateViewDTO> getCampaignBottomDateList(ServiceContext context, Long campaignId) {
        CampaignQueryOption campaignQueryOption = CampaignQueryOption.builder().needChildren(true).build();
        CampaignViewDTO campaignViewDTO = bizCampaignQueryWorkflow.getCampaignInfoByOption(context, campaignId,campaignQueryOption);
        if (null == campaignViewDTO){
            return MultiResponse.failureOf(BIZ_DATA_EMPTY_ERROR.getErrCode(), "计划不存在");
        }
        List<BottomDateViewDTO> resultList = Lists.newArrayList();

        Integer mediaScope = campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope();

        if (!mediaScope.equals(MediaScopeEnum.SITE_OUT.getCode())){
            RogerLogger.info("计划:{}不是三环PDB,返回空",campaignId);
            return MultiResponse.of(resultList);
        }
        Set<Long> sspProductId = campaignViewDTO.getSubCampaignViewDTOList().stream().map(e -> e.getCampaignResourceViewDTO().getSspProductId()).collect(Collectors.toSet());
        List<ProductViewDTO> sspProductList = productRepository.getProductByIds(Lists.newArrayList(sspProductId));
        Set<Long> mediaIds = sspProductList.stream().map(ProductViewDTO::getCustomerOrientedMediaId).collect(Collectors.toSet());
        //子计划不能垮媒体
        if (CollectionUtils.isEmpty(mediaIds) || mediaIds.size()>1){
            RogerLogger.info("计划:{}跨媒体了，返回空",campaignId);
            return MultiResponse.of(resultList);
        }
        List<Long> subCampaignIds = Lists.newArrayList();
        if (CollectionUtils.isNotEmpty(campaignViewDTO.getSubCampaignViewDTOList())) {
            subCampaignIds = campaignViewDTO.getSubCampaignViewDTOList().stream().map(item -> item.getId()).collect(Collectors.toList());
        }
        if (CollectionUtils.isEmpty(subCampaignIds)) {
            return MultiResponse.empty();
        }
        Set<Date> dateSet = Sets.newHashSet();
        List<BottomDateViewDTO> inventoryResultList = campaignRepository.getCampaignBottomDateList(context,subCampaignIds);
        if (CollectionUtils.isNotEmpty(inventoryResultList)){
            for (BottomDateViewDTO bottomDateViewDTO:inventoryResultList){
                List<Date> dateList =  BrandDateUtil.getDayList(bottomDateViewDTO.getStartDate(),bottomDateViewDTO.getEndDate());
                dateSet.addAll(dateList);
            }
        }
        resultList = Optional.ofNullable(BrandDateUtil.formatDateQuantum(Lists.newArrayList(dateSet))).orElse(Lists.newArrayList()).stream().map(
                item->{
                    BottomDateViewDTO bottomDateViewDTO = new BottomDateViewDTO();
                    bottomDateViewDTO.setStartDate(item.getStartDate());
                    bottomDateViewDTO.setEndDate(item.getEndDate());
                    return  bottomDateViewDTO;
                }
        ).collect(Collectors.toList());
        return MultiResponse.of(resultList);
    }

    private void fillPageViewInfo(CampaignPageViewDTO campaignPageViewDTO, ProductViewDTO productViewDTO) {
        campaignPageViewDTO.setCampaignGroupName("-");
        if(Objects.nonNull(campaignPageViewDTO.getSspRegisterManner())){
            campaignPageViewDTO.setSspRegisterMannerDesc(Objects.isNull(BrandCampaignRegisterMannerEnum.getByCode(campaignPageViewDTO.getSspRegisterManner()))? "-":BrandCampaignRegisterMannerEnum.getByCode(campaignPageViewDTO.getSspRegisterManner()).getDesc());
        }
        if(Objects.nonNull(campaignPageViewDTO.getSaleType())){
            campaignPageViewDTO.setSaleTypeDesc(Objects.isNull(BrandSaleTypeEnum.getByCode(campaignPageViewDTO.getSaleType()))? "-":BrandSaleTypeEnum.getByCode(campaignPageViewDTO.getSaleType()).getDesc());
        }
        if(Objects.nonNull(campaignPageViewDTO.getStatus())){
            campaignPageViewDTO.setStatusDesc(Objects.isNull(BrandCampaignStatusEnum.getByCode(campaignPageViewDTO.getStatus()))? "-":BrandCampaignStatusEnum.getByCode(campaignPageViewDTO.getStatus()).getDesc());
        }
        if(Objects.nonNull(campaignPageViewDTO.getIsSupportSafeIp())){
            SwitchEnum switchEnum = SwitchEnum.getByCode(campaignPageViewDTO.getIsSupportSafeIp());
            campaignPageViewDTO.setIsSupportSafeIpDesc(Objects.isNull(switchEnum)? "-":switchEnum.getDesc());
        }
        if(productViewDTO  != null){
            campaignPageViewDTO.setPublishProductName(productViewDTO.getLabelName());
            campaignPageViewDTO.setSspMediaName(productViewDTO.getCustomerOrientedMediaName());
            campaignPageViewDTO.setBusinessLineName(productViewDTO.getProductLineName());
            campaignPageViewDTO.setSspProductLineName(productViewDTO.getProductLineName());
            campaignPageViewDTO.setSaleProductLineName(campaignPageViewDTO.getSaleProductLine() == null ?"" : SaleProductLineEnum.getDesc(campaignPageViewDTO.getSaleProductLine()));
            campaignPageViewDTO.setSspResourceName(productViewDTO.getCustomerOrientedResourceName());
            campaignPageViewDTO.setSspRegisterUnitDesc(BrandCampaignRegisterUnitEnum.getByCode(campaignPageViewDTO.getSspRegisterUnit()).getDesc());
            campaignPageViewDTO.setSspResourceId(CollectionUtils.isNotEmpty(productViewDTO.getResourceIdList())?productViewDTO.getResourceIdList().get(0):null);
            campaignPageViewDTO.setSspResourceType(CollectionUtils.isNotEmpty(productViewDTO.getResourceTypeList())?StringUtils.join(productViewDTO.getResourceTypeList(), ","):null);
            if(CollectionUtils.isNotEmpty(productViewDTO.getResourceTypeNameList())){
                List<String> resourceNames = productViewDTO.getResourceTypeNameList().stream().map(CommonViewDTO::getName).collect(Collectors.toList());
                campaignPageViewDTO.setSspResourceTypeDesc(StringUtils.join(resourceNames, ","));
            }
        }
    }

    @Override
    public SingleResponse<CampaignViewDTO> getCampaignById(ServiceContext context, Long campaignId, CampaignQueryOption option) {
        CampaignViewDTO campaignViewDTO = bizCampaignQueryWorkflow.getCampaignInfoByOption(context, campaignId, option);
        return SingleResponse.of(campaignViewDTO);
    }

    @Override
    public SingleResponse<Long> getHistoryBudget(ServiceContext context, Long saleGroupId) {
        CampaignQueryViewDTO campaignQueryViewDTO = new CampaignQueryViewDTO();
        campaignQueryViewDTO.setSaleGroupIds(Lists.newArrayList(saleGroupId));
        campaignQueryViewDTO.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
        List<CampaignViewDTO> campaignViewDTOList = campaignRepository.queryCampaignList(context, campaignQueryViewDTO);
        Long totalBudget = 0L;
        for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
            if (BrandCampaignStatusEnum.DELETE.getCode().equals(campaignViewDTO.getStatus())) {
                continue;
            }
            if (BrandSaleTypeEnum.BOOST.getCode().equals(campaignViewDTO.getCampaignSaleViewDTO().getSaleType())
            ||BrandSaleTypeEnum.PRESENT.getCode().equals(campaignViewDTO.getCampaignSaleViewDTO().getSaleType()) ) {
                continue;
            }
            List<CampaignInquiryViewDTO> campaignInquiryViewDTOS = Optional.ofNullable(campaignViewDTO.getCampaignInquiryLockViewDTO())
                    .map(CampaignInquiryLockViewDTO::getCampaignInquiryViewDTOList).orElse(Lists.newArrayList());
            if (CollectionUtils.isEmpty(campaignInquiryViewDTOS)) {
                continue;
            }
            // 是否非系统投放
            boolean isUnProgrammatic = BizCampaignToolsHelper.isUnProgrammatic(campaignViewDTO.getSspProgrammatic(), campaignViewDTO.getCampaignType());
            boolean isCpt = BizCampaignToolsHelper.isCPT(campaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterUnit());
            for (CampaignInquiryViewDTO campaignInquiryViewDTO : campaignInquiryViewDTOS) {
                if (campaignInquiryViewDTO.getDate().compareTo(BrandDateUtil.getTomorrowDate()) >= 0) {
                    continue;
                }
                if (campaignInquiryViewDTO.getStatus().equals(BrandInquiryStatusEnum.FAIL.getCode())) {
                    continue;
                }
                Long price = 0L;
                for (DayPriceViewDTO dayPriceViewDTO : campaignViewDTO.getCampaignPriceViewDTO().getDiscountPriceInfoList()) {
                    if(BrandDateUtil.isBeforeAndEqual(dayPriceViewDTO.getStartDate(),campaignInquiryViewDTO.getDate())
                    && BrandDateUtil.isAfterAndEqual(dayPriceViewDTO.getEndDate(),campaignInquiryViewDTO.getDate()) ){
                        price = dayPriceViewDTO.getPrice();
                    }
                }
                RogerLogger.info(" {} day {} bookAmount {} price {}",campaignViewDTO.getId(),campaignInquiryViewDTO.getDate(),campaignInquiryViewDTO.getBookAmount(),price);
                if (isUnProgrammatic && isCpt) {
                    totalBudget += campaignInquiryViewDTO.getCptAmount() * price;
                } else {
                    totalBudget += campaignInquiryViewDTO.getBookAmount()/1000 * price;
                }
            }
        }
        return SingleResponse.of(totalBudget);
    }

    @Override
    public SingleResponse<FrequencyViewDTO> getFrequencyById(ServiceContext serviceContext, Long frequencyId) {
        return SingleResponse.of(frequencyRepository.getFrequencyById(serviceContext, frequencyId));
    }

    @Override
    public MultiResponse<FrequencyViewDTO> frequencyList(ServiceContext serviceContext, FrequencyQueryViewDTO queryViewDTO) {
        PageResultViewDTO<FrequencyViewDTO> frequencyViewDTOList = frequencyRepository.frequencyList(serviceContext, queryViewDTO);
        return MultiResponse.of(frequencyViewDTOList.getList(), frequencyViewDTOList.getCount());
    }
    @Override
    public SingleResponse<FrequencyRefViewDTO> findFrequencyRefByFreqId(ServiceContext serviceContext, Long frequencyId) {
        return SingleResponse.of(frequencyRepository.findFrequencyRefByFreqId(serviceContext, frequencyId, BrandFrequencyBizTypeEnum.CAMPAIGN.getCode()));
    }
    @Override
    public MultiResponse<ItemViewDTO> getItemByIdList(ServiceContext serviceContext, List<Long> idList) {
        return MultiResponse.of(campaignRepository.getItemByIdList(serviceContext, idList));
    }

    @Override
    public MultiResponse<CampaignInventoryAutoReleaseStatusViewDTO> calculateInventoryWarningStatus(ServiceContext serviceContext, CampaignInventoryAutoReleaseQueryViewDTO campaignInventoryAutoReleaseQueryViewDTO) {
        if(Objects.isNull(campaignInventoryAutoReleaseQueryViewDTO) || CollectionUtils.isEmpty(campaignInventoryAutoReleaseQueryViewDTO.getCampaignViewDTOList())
                || CollectionUtils.isEmpty(campaignInventoryAutoReleaseQueryViewDTO.getCampaignGroupViewDTOList())) {
            return MultiResponse.of(Lists.newArrayList());
        }
//        return MultiResponse.of(bizCampaignInventoryAutoreleaseAbility.calculateInventoryWarningStatus(serviceContext, campaignInventoryAutoReleaseQueryViewDTO));
        return MultiResponse.of(bizCampaignInventoryWorkflow.calculateInventoryWarningStatus(serviceContext, campaignInventoryAutoReleaseQueryViewDTO));
    }

    @Override
    public MultiResponse<CampaignInventoryAutoReleaseStatusViewDTO> calculateInventoryReleaseStatus(ServiceContext serviceContext, CampaignInventoryAutoReleaseQueryViewDTO campaignInventoryAutoReleaseQueryViewDTO) {
        if(Objects.isNull(campaignInventoryAutoReleaseQueryViewDTO) || CollectionUtils.isEmpty(campaignInventoryAutoReleaseQueryViewDTO.getCampaignViewDTOList())
                || CollectionUtils.isEmpty(campaignInventoryAutoReleaseQueryViewDTO.getCampaignGroupViewDTOList())) {
            return MultiResponse.of(Lists.newArrayList());
        }
//        return MultiResponse.of(bizCampaignInventoryAutoreleaseAbility.calculateInventoryReleaseStatus(serviceContext, campaignInventoryAutoReleaseQueryViewDTO));
        return MultiResponse.of(bizCampaignInventoryWorkflow.calculateInventoryReleaseStatus(serviceContext, campaignInventoryAutoReleaseQueryViewDTO));
    }

    @Override
    public MultiResponse<CampaignInventoryAutoReleaseStatusViewDTO> calculateInventoryExpireTime(ServiceContext serviceContext, CampaignInventoryAutoReleaseQueryViewDTO campaignInventoryAutoReleaseQueryViewDTO) {
        List<CampaignInventoryAutoReleaseStatusViewDTO> result = Lists.newArrayList();
        if(Objects.isNull(campaignInventoryAutoReleaseQueryViewDTO) || CollectionUtils.isEmpty(campaignInventoryAutoReleaseQueryViewDTO.getCampaignViewDTOList())) {
            return MultiResponse.of(Lists.newArrayList());
        }
        campaignInventoryAutoReleaseQueryViewDTO.getCampaignViewDTOList().forEach(campaignViewDTO -> {
            Date lockExpireTime = bizCampaignInventoryWorkflow.recalculateLockExpireTime(serviceContext,campaignViewDTO);
            CampaignInventoryAutoReleaseStatusViewDTO campaignInventoryAutoReleaseStatusViewDTO = new CampaignInventoryAutoReleaseStatusViewDTO();
            campaignInventoryAutoReleaseStatusViewDTO.setCampaignId(campaignViewDTO.getId());
            campaignInventoryAutoReleaseStatusViewDTO.setLockExpireTime(lockExpireTime);
            result.add(campaignInventoryAutoReleaseStatusViewDTO);
        });
        return MultiResponse.of(result);
    }

    @Override
    public MultiResponse<CampaignEffectAdvViewDTO> findCampaignEffectAdvList(ServiceContext context, CampaignEffectAdvQueryViewDTO campaignEffectAdvQueryViewDTO) {
       List<CampaignEffectAdvViewDTO> campaignEffectAdvViewDTOList =  bizCampaignQueryWorkflow.findCampaignEffectAdvList(context, campaignEffectAdvQueryViewDTO);
       return MultiResponse.of(campaignEffectAdvViewDTOList);
    }

    @Override
    public SingleResponse<CampaignInventoryAutoReleaseConfigViewDTO> getLockExpireConfig(ServiceContext serviceContext) {
        CampaignInventoryAutoReleaseConfigViewDTO autoReleaseConfigViewDTO  =
                campaignInventoryAutoReleaseDiamondConfig.getCampaignInventoryAutoReleaseConfig();
        if (autoReleaseConfigViewDTO != null) {
            return SingleResponse.of(autoReleaseConfigViewDTO);
        }
        return SingleResponse.failureOf(BIZ_DATA_EMPTY_ERROR);
    }

    @Override
    public MultiResponse<CampaignInventoryAutoReleaseStatusViewDTO> findCampaignWarnInfoList(ServiceContext context, CampaignInventoryAutoReleaseQueryViewDTO campaignInventoryAutoReleaseQueryViewDTO) {
        // 三环或跨域计划补全二级计划
        List<CampaignViewDTO> parentCampaignViewDTOList = campaignInventoryAutoReleaseQueryViewDTO.getCampaignViewDTOList().stream()
                .filter(campaignViewDTO -> {
            Integer sspMediaScope = campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope();
            return sspMediaScope.equals(MediaScopeEnum.SITE_OUT.getCode()) || sspMediaScope.equals(MediaScopeEnum.CROSS_SCOPE.getCode());
        }).collect(Collectors.toList());
        if(CollectionUtils.isNotEmpty(parentCampaignViewDTOList)) {
            CampaignQueryViewDTO subQuery = new CampaignQueryViewDTO();
            subQuery.setParentCampaignIds(parentCampaignViewDTOList.stream().map(item->item.getId()).collect(Collectors.toList()));
            List<CampaignViewDTO> subCampaignViewDTOList = campaignRepository.queryCampaignList(context,subQuery);
            Map<Long, List<CampaignViewDTO>> subCampaignParentGroupMap = subCampaignViewDTOList.stream().collect(Collectors.groupingBy(t -> t.getParentCampaignId()));
            for(CampaignViewDTO campaignViewDTO : parentCampaignViewDTOList ){
                campaignViewDTO.setSubCampaignViewDTOList(subCampaignParentGroupMap.getOrDefault(campaignViewDTO.getId(), Lists.newArrayList()));
            }
        }
        return MultiResponse.of(bizCampaignInventoryWorkflow.calculateAutoReleaseStatus(context, campaignInventoryAutoReleaseQueryViewDTO));
    }

    @Override
    public MultiResponse<EffectAdvertiserViewDTO> findEffectAdvList(ServiceContext serviceContext, Long campaignId) {
        List<EffectAdvertiserViewDTO> list = bizCampaignQueryWorkflow.findEffectAdvList(serviceContext,campaignId);
        return MultiResponse.of(list);

    }

    @Override
    public MultiResponse<Long> findEffectAdvListBySubContractId(ServiceContext serviceContext, Long subContractId) {
        if (null == subContractId){
            return MultiResponse.empty();
        }
        List<Long> advIds = bizCampaignQueryWorkflow.findEffectAdvListBySubContractId(serviceContext,subContractId);
        return MultiResponse.of(advIds);

    }
    @Override
    public MultiResponse<Long> findEffectAdvListByContractId(ServiceContext serviceContext, Long contractId) {
        if (null == contractId){
            return MultiResponse.empty();
        }
        List<Long> advIds = bizCampaignQueryWorkflow.findEffectAdvListByContractId(serviceContext,contractId);
        return MultiResponse.of(advIds);

    }

    @Override
    public MultiResponse<Long> findEffectSubContractIdList(ServiceContext serviceContext, List<Long> campaignIds) {
        if (CollectionUtils.isEmpty(campaignIds)){
            return MultiResponse.empty();
        }
        List<Long> subContractIds = bizCampaignQueryWorkflow.findEffectSubContractIds(serviceContext,campaignIds);
        return MultiResponse.of(subContractIds);
    }

    @Override
    public SingleResponse<CampaignSchedulePolicyConfigViewDTO> findCampaignSchedulePolicyConfig(ServiceContext context, CampaignQueryViewDTO query) {
        List<CampaignViewDTO> campaignViewDTOList = campaignRepository.queryCampaignList(context, query);
        for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
            AssertUtil.assertTrue(NumberUtil.greaterThanZero(campaignViewDTO.getCampaignGuaranteeViewDTO().getAmount()), "计划预算不能为空，请先分配预算");
            AssertUtil.assertTrue(!BizCampaignToolsHelper.isTwoCPT(campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope(),campaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterUnit()), String.format("二环CPT计划(%s)仅支持分天策略", campaignViewDTO.getId()));
            AssertUtil.assertTrue(Constant.CAN_INQUIRY_LOCK_STATUS.contains(campaignViewDTO.getStatus()),
                    String.format("计划(%s)状态不允许修改操作", campaignViewDTO.getTitle()));
        }
        CampaignSchedulePolicyConfigViewDTO campaignSchedulePolicySummary = findCampaignSchedulePolicyConfig(context,campaignViewDTOList);
        return SingleResponse.of(campaignSchedulePolicySummary);
    }


    /**
     * 查询当前订单x分组下的批量计划上传记录
     * @param context
     * @param query
     * @return
     */
    @Override
    public MultiResponse<ReportTaskViewDTO> findCampaignBatchImportTaskList(ServiceContext context, CampaignQueryViewDTO query) {
        AssertUtil.notNull(query);
        AssertUtil.notNull(query.getCampaignGroupId(), "订单ID不能为空");
        AssertUtil.notNull(query.getSaleGroupId(), "售卖分组ID不能为空");

        ReportTaskQueryViewDTO queryViewDTO = new ReportTaskQueryViewDTO();
        queryViewDTO.setMemberId(context.getMemberId());
        queryViewDTO.setCampaignGroupId(query.getCampaignGroupId());
        queryViewDTO.setSaleGroupId(query.getSaleGroupId());
        // 异步任务类型
        queryViewDTO.setFunctionCode("campaignBatchInsert");
        queryViewDTO.setPageSize(200);
        return MultiResponse.of(reportSyncTaskRepository.queryList(context, queryViewDTO));
    }

    @Override
    public SingleResponse<Map<Long, CampaignViewDTO>> findCampaignCrowdMap(ServiceContext serviceContext, List<Long> campaignIds) {

        Map<Long, CampaignViewDTO> campaignTargetMap = campaignCrowdMapQueryAbility.handle(serviceContext
                , CampaignCrowdMapQueryAbilityParam.builder().abilityTargets(campaignIds).build());

        return SingleResponse.of(campaignTargetMap);
    }

    @Override
    public MultiResponse<CampaignTemplateViewDTO> getCampaignTemplateIds(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList) {
        List<CampaignTemplateViewDTO> campaignTemplateViewDTOS = campaignRepository.getCampaignTemplateIds(serviceContext, campaignViewDTOList);
        return MultiResponse.of(campaignTemplateViewDTOS);
    }

    @Override
    public SingleResponse<CampaignKeywordEstimateViewDTO> getCampaignKeywordEstimateList(ServiceContext serviceContext, CampaignKeywordEstimateQueryViewDTO queryViewDTO) {
        StringBuilder msgStr = new StringBuilder();
        CampaignKeywordViewDTO campaignKeywordViewDTO = ExtensionPointsFactory.runAbilitySpi(BizCampaignKeywordEstimateSpi.class, extension -> extension.estimateKeyword(serviceContext, queryViewDTO), getEstimateSpiCode(queryViewDTO.getRecommendMethod()));
        CampaignKeywordAbilityParam keywordAbilityParam = CampaignKeywordAbilityParam.builder().abilityTarget(campaignKeywordViewDTO).build();
        //3. 风控准入过滤
        if(CommonConstant.YES.equals(queryViewDTO.getIsCheckAccess())){
            String currMsg = campaignKeywordAccessValidateAbility.handle(serviceContext, keywordAbilityParam);
            RogerLogger.info("campaignKeywordAccessValidateAbility keywordAbilityParam:{}", JSON.toJSONString(keywordAbilityParam));
            if(StringUtils.isNotEmpty(currMsg)){
                msgStr.append("以下关键词不可使用，原因如下：\n").append(currMsg);
            }
        }
        //4. 归一化词重复校验
        if(CommonConstant.YES.equals(queryViewDTO.getIsCheckNormal())){
            String currMsg = campaignKeywordNormalValidateAbility.handle(serviceContext, keywordAbilityParam);
            RogerLogger.info("campaignKeywordNormalValidateAbility keywordAbilityParam:{}", JSON.toJSONString(keywordAbilityParam));
            if(StringUtils.isNotEmpty(currMsg)){
                msgStr.append(currMsg);
            }
        }

        //5. 返回数据组装
        CampaignKeywordEstimateViewDTO finalEstimateViewDTO = new CampaignKeywordEstimateViewDTO();
        finalEstimateViewDTO.setKeywordViewDTO(campaignKeywordViewDTO);
        if(KeywordRecommendMethodEnum.CUSTOM.getCode().equals(queryViewDTO.getRecommendMethod())){
            finalEstimateViewDTO.setPromptMsg(msgStr.toString());
        }
        return SingleResponse.of(finalEstimateViewDTO);
    }

    @Override
    public SingleResponse<CampaignKeywordEstimateViewDTO> getCampaignAllKeywordEstimateScope(ServiceContext serviceContext, CampaignKeywordEstimateQueryViewDTO queryViewDTO) {
        CampaignKeywordEstimateViewDTO estimateViewDTO = new CampaignKeywordEstimateViewDTO();
        if(CollectionUtils.isNotEmpty(queryViewDTO.getCampaignWordViewDTOList())){
            estimateViewDTO = keywordRepository.selectKeywordAllDayPrePv(serviceContext, queryViewDTO.getCampaignWordViewDTOList());
        }
        return SingleResponse.of(estimateViewDTO);
    }

    /**
     * 查询当前订单下的批量计划预订量上传记录
     * @param context
     * @param query
     * @return
     */
    @Override
    public MultiResponse<ReportTaskViewDTO> findBatchImportCampaignBookingAmountTaskList(ServiceContext context, CampaignQueryViewDTO query) {
        AssertUtil.notNull(query);
        AssertUtil.notNull(query.getCampaignGroupId(), "订单ID不能为空");

        ReportTaskQueryViewDTO queryViewDTO = new ReportTaskQueryViewDTO();
        queryViewDTO.setMemberId(context.getMemberId());
        queryViewDTO.setCampaignGroupId(query.getCampaignGroupId());
        // 异步任务类型
        queryViewDTO.setFunctionCode("batchImportCampaignBookingAmount");
        queryViewDTO.setPageSize(200);
        return MultiResponse.of(reportSyncTaskRepository.queryList(context, queryViewDTO));
    }

    @Override
    public SingleResponse<CampaignWordPackageViewDTO> getCampaignWordPackageEstimateList(ServiceContext serviceContext, CampaignKeywordEstimateQueryViewDTO queryViewDTO){
        CampaignWordPackageViewDTO campaignWordPackageViewDTO = keywordRepository.selectWordPackageRecommend(serviceContext, queryViewDTO);
        return SingleResponse.of(campaignWordPackageViewDTO);
    }

    private void fillAutoReleaseWarningInfo(ServiceContext context, CampaignPageViewDTO campaignPageViewDTO) {
        // 计划排期列表页补全自动释量信息
        if(BrandCampaignStatusEnum.LOCK_SUCCESS.getCode().equals(campaignPageViewDTO.getStatus())
                && BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode().equals(campaignPageViewDTO.getCampaignLevel())) {
            // 总是补全二级计划
            CampaignViewDTO fullCampaignViewDTO = bizCampaignQueryWorkflow.getCampaignInfoByOption(context, campaignPageViewDTO.getId(), CampaignQueryOption.builder().needCampaignTree(true).build());
            CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(context, campaignPageViewDTO.getCampaignGroupId());
            CampaignInventoryAutoReleaseQueryViewDTO campaignInventoryAutoReleaseQueryViewDTO = new CampaignInventoryAutoReleaseQueryViewDTO();
            campaignInventoryAutoReleaseQueryViewDTO.setCampaignViewDTOList(Lists.newArrayList(fullCampaignViewDTO));
            campaignInventoryAutoReleaseQueryViewDTO.setCampaignGroupViewDTOList(Lists.newArrayList(campaignGroupViewDTO));
            List<CampaignInventoryAutoReleaseStatusViewDTO> campaignInventoryAutoReleaseStatusViewDTOList = bizCampaignInventoryWorkflow.calculateAutoReleaseStatus(context,campaignInventoryAutoReleaseQueryViewDTO);
            if(CollectionUtils.isNotEmpty(campaignInventoryAutoReleaseStatusViewDTOList)) {
                CampaignInventoryAutoReleaseStatusViewDTO campaignInventoryAutoReleaseStatusViewDTO = campaignInventoryAutoReleaseStatusViewDTOList.get(0);
                InventoryAutoReleaseWarningInfoViewDTO inventoryAutoReleaseWarningInfoViewDTO = new InventoryAutoReleaseWarningInfoViewDTO();
                inventoryAutoReleaseWarningInfoViewDTO.setAutoReleaseWarning(campaignInventoryAutoReleaseStatusViewDTO.getWarningStatus() == null ?
                        BrandBoolEnum.BRAND_FALSE.getCode(): campaignInventoryAutoReleaseStatusViewDTO.getWarningStatus());
                inventoryAutoReleaseWarningInfoViewDTO.setIsApply(campaignInventoryAutoReleaseStatusViewDTO.getDelayApplyQualifyStatus());
                campaignPageViewDTO.setInventoryAutoReleaseWarningInfoViewDTO(inventoryAutoReleaseWarningInfoViewDTO);
            } else {
                // 计算结果为空表示当前计划、订单不具备预警状态，此时返回前端的锁量有效期置空
                campaignPageViewDTO.setLockExpireTime(null);
                campaignPageViewDTO.setLockCallBackTime(null);
            }
        }
    }

    /**
     * 查询计划分配策略配置数据
     *
     * @param context
     * @param campaignViewDTOList
     * @return
     */
    public CampaignSchedulePolicyConfigViewDTO findCampaignSchedulePolicyConfig(ServiceContext context, List<CampaignViewDTO> campaignViewDTOList) {
        for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
            AssertUtil.assertTrue(NumberUtil.greaterThanZero(campaignViewDTO.getCampaignGuaranteeViewDTO().getAmount()), "计划预算不能为空，请先分配预算");
            AssertUtil.assertTrue(!BizCampaignToolsHelper.isTwoCPT(campaignViewDTO.getCampaignResourceViewDTO().getSspMediaScope(),campaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterUnit()), String.format("二环CPT计划(%s)仅支持分天策略", campaignViewDTO.getId()));
            AssertUtil.assertTrue(Constant.CAN_INQUIRY_LOCK_STATUS.contains(campaignViewDTO.getStatus()),
                    String.format("计划(%s)状态不允许修改操作", campaignViewDTO.getTitle()));
        }
        CampaignSchedulePolicyConfigViewDTO policySummaryViewDTO = new CampaignSchedulePolicyConfigViewDTO();
        if (campaignViewDTOList.size() == 1) {
            CampaignViewDTO campaignViewDTO = campaignViewDTOList.get(0);
            policySummaryViewDTO.setStartTime(campaignViewDTO.getStartTime());
            policySummaryViewDTO.setEndTime(campaignViewDTO.getEndTime());
            policySummaryViewDTO.setSspRegisterUnit(campaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterUnit());
            //PV转换系数
            Long sspRegisterRatio = 1000L;
            if (BizCampaignToolsHelper.isCPT(policySummaryViewDTO.getSspRegisterUnit())) {
                ProductViewDTO productViewDTO = productRepository.getProductById(campaignViewDTO.getCampaignResourceViewDTO().getSspProductId());
                AssertUtil.notNull(productViewDTO, String.format("二级产品（%s）不存在", campaignViewDTO.getCampaignResourceViewDTO().getSspProductId()));
                sspRegisterRatio = BigDecimal.valueOf(productViewDTO.getUnitExposure()).multiply(BigDecimal.valueOf(1000L)).longValue();
            }
            policySummaryViewDTO.setSspRegisterRatio(sspRegisterRatio);
            //可预订量
            Date availableStartTime = BizCampaignToolsHelper.inquiryDeadline(campaignViewDTO);
            Date availableEndTime = BrandDateUtil.getDateMidnight(campaignViewDTO.getEndTime());
            //全部转换为年-月-日
            policySummaryViewDTO.setAvailableStartTime(availableStartTime);
            policySummaryViewDTO.setAvailableEndTime(availableEndTime);

            //获取计划未来周期预定量
            CampaignScheduleViewDTO campaignScheduleViewDTO = new CampaignScheduleViewDTO();
            campaignScheduleViewDTO.setId(campaignViewDTO.getId());
            calculateCampaignFutureAmount(context,campaignViewDTO,campaignScheduleViewDTO);

            policySummaryViewDTO.setAvailableAmount(campaignScheduleViewDTO.getFutureAmount());

            //查询计划历史设置的周期预定量，优先使用历史已经设置的，如果没有在匹配资源包设置的
            ResourcePackageProductViewDTO resourcePackageProductViewDTO = getResourcePackageProductViewDTO(context, campaignViewDTO);
            List<CampaignInquirySchedulePolicyViewDTO> policyViewDTOList = bizCampaignInventoryWorkflow.getInquiryAvailableSchedulePolicy(campaignViewDTO,resourcePackageProductViewDTO);
            policySummaryViewDTO.setSchedulePolicyList(policyViewDTOList);
        } else {
            Set<Date> availableTimeSet = Sets.newHashSet();
            for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
                List<CampaignInquiryViewDTO> campaignInquiryViewDTOList = campaignViewDTO.getCampaignInquiryLockViewDTO().getCampaignInquiryViewDTOList();
                Date deadlineDate = BizCampaignToolsHelper.inquiryDeadline(campaignViewDTO.getCampaignSaleViewDTO().getSaleType(), campaignInquiryViewDTOList,
                        campaignViewDTO.getCampaignInquiryLockViewDTO().getFirstOnlineTime());
                Date startTime = BrandDateUtil.maxDate(deadlineDate, campaignViewDTO.getStartTime());
                availableTimeSet.add(startTime);
                availableTimeSet.add(campaignViewDTO.getEndTime());
            }
            AssertUtil.assertTrue(availableTimeSet.size() <= 2, "批量按周期分配预定量需要保证所选计划的可设置周期一致");
            List<Date> dataList = availableTimeSet.stream().sorted().collect(Collectors.toList());
            if (dataList.size() == 1) {
                policySummaryViewDTO.setAvailableStartTime(dataList.get(0));
                policySummaryViewDTO.setAvailableEndTime(dataList.get(0));
            } else {
                policySummaryViewDTO.setAvailableStartTime(dataList.get(0));
                policySummaryViewDTO.setAvailableEndTime(dataList.get(1));
            }
        }
        return policySummaryViewDTO;
    }

    /**
     * 获取资源包产品信息
     * @param context
     * @param campaignViewDTO
     * @return
     */
    private ResourcePackageProductViewDTO getResourcePackageProductViewDTO(ServiceContext context,CampaignViewDTO campaignViewDTO){
        ResourcePackageQueryOption packageQueryOption = ResourcePackageQueryOption.builder().needProduct(true).needSetting(true).build();
        ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO = resourcePackageRepository.getSaleGroupById(context, campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId(), packageQueryOption);
        Long resourcePackageProductId = bizCampaignInventoryWorkflow.getSchedulePolicyResourcePackageProductId(context,campaignViewDTO);
        ResourcePackageProductViewDTO resourcePackageProductViewDTO = resourcePackageRepository.getResourcePackageProduct(context,packageSaleGroupViewDTO,resourcePackageProductId);
        AssertUtil.notNull(resourcePackageProductViewDTO, "售卖分组资源位不存在");
        return resourcePackageProductViewDTO;
    }

    /**
     * 计算计划未来可用预定量，历史的预定量取计划db预定量数据
     * @param serviceContext
     * @param campaignViewDTO
     * @param campaignScheduleViewDTO
     */
    private void calculateCampaignFutureAmount(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, CampaignScheduleViewDTO campaignScheduleViewDTO) {
        Date deadlineDate = BizCampaignToolsHelper.inquiryDeadline(campaignViewDTO);
        //历史的预定量：DB存储的已锁量成功的历史预定量
        List<CampaignInquiryViewDTO> historyInquiryList = Optional.ofNullable(campaignViewDTO.getCampaignInquiryLockViewDTO())
                .map(CampaignInquiryLockViewDTO::getCampaignInquiryViewDTOList).orElse(Lists.newArrayList())
                .stream().filter(v -> BrandDateUtil.isBefore(v.getDate(), deadlineDate))
                .filter(v -> BrandInquiryStatusEnum.SUCCESS.getCode().equals(v.getStatus())).collect(Collectors.toList());

        campaignScheduleViewDTO.setHistoryInquiryList(historyInquiryList);

        Long totalAmount = NumberUtil.getOrDefaultZero(campaignViewDTO.getCampaignGuaranteeViewDTO().getAmount());
        Long totalCptAmount = NumberUtil.getOrDefaultZero(campaignViewDTO.getCampaignGuaranteeViewDTO().getCptAmount());
        campaignScheduleViewDTO.setAmount(totalAmount);
        campaignScheduleViewDTO.setCptAmount(totalCptAmount);
        //计算计划整体可分配的预定量
        boolean isCPT = BizCampaignToolsHelper.isCPT(campaignViewDTO.getCampaignGuaranteeViewDTO().getSspRegisterUnit());
        if (isCPT) {
            long historyCptAmount = historyInquiryList.stream().mapToLong(CampaignInquiryViewDTO::getCptAmount).sum();
            campaignScheduleViewDTO.setFutureCptAmount(totalCptAmount - historyCptAmount);
        }
        long historyAmount = historyInquiryList.stream().mapToLong(CampaignInquiryViewDTO::getBookAmount).sum();
        campaignScheduleViewDTO.setFutureAmount(totalAmount - historyAmount);

        RogerLogger.info("计划预算分配 计划未来可用预定量 = {}", JSON.toJSONStringWithDateFormat(campaignScheduleViewDTO, BrandDateUtil.DATE_FORMAT_YYYYMMDD_TYPE_1, SerializerFeature.DisableCircularReferenceDetect));
    }

    /**
     * 检查计划下创意数量是否过多/过少并返回预警
     * @param serviceContext
     * @param campaignId
     * @return
     */
    @Override
    public SingleResponse<CampaignCreativeNumberWarningViewDTO> checkCreativeNumber(ServiceContext serviceContext, Long campaignId) {
        CampaignCreativeNumberWarningViewDTO result = new CampaignCreativeNumberWarningViewDTO();
        CampaignViewDTO campaignViewDTO = campaignRepository.getCampaignById(serviceContext, campaignId);
        Long amount = campaignViewDTO.getCampaignGuaranteeViewDTO().getAmount();
        if (Objects.isNull(amount) || amount <= 0) {
            RogerLogger.info("计划{}无预定量，不展示创意数量预警", campaignId);
            result.setWarningStatus(BrandBoolEnum.BRAND_FALSE.getCode());
            return SingleResponse.of(result);
        }

        CreativeQueryViewDTO creativeQueryViewDTO = new CreativeQueryViewDTO();
        creativeQueryViewDTO.setCampaignIds(Lists.newArrayList(campaignId));
        creativeQueryParamResetAbility.handle(serviceContext, CreativeQueryParamResetAbilityParam.builder().abilityTarget(creativeQueryViewDTO).build());
        PageResultViewDTO<CreativeViewDTO> pageResultViewDTO = creativeRepository.findListWithPage(serviceContext, creativeQueryViewDTO);
        // 包含智能创意的计划无需预警
        if (pageResultViewDTO.getList().stream().anyMatch(creativeViewDTO -> BrandCreativeSourceEnum.SMART_CREATIVE.getCode().equals(creativeViewDTO.getCreativeSource()))) {
            RogerLogger.info("计划{}存在智能创意，无需预警", campaignId);
            result.setWarningStatus(BrandBoolEnum.BRAND_FALSE.getCode());
            return SingleResponse.of(result);
        }
        Integer creativeNumber = pageResultViewDTO.getCount();

        // 计算计划日平均预定量
        Integer dayCount = BrandDateUtil.getDateRange(campaignViewDTO.getStartTime(), campaignViewDTO.getEndTime()) + 1;
        RogerLogger.info("计划id：{}，预定量：{}，投放天数：{}", campaignId, amount, dayCount);
        Long averageDailyAmount = amount / dayCount;
        Pair<Integer, Integer> recommendCreativeNumberPair = getRecommendedCreativeNumberByAverageDailyAmount(averageDailyAmount);
        Integer minCreativeNumber = recommendCreativeNumberPair.getLeft();
        Integer maxCreativeNumber = recommendCreativeNumberPair.getRight();
        if (minCreativeNumber <= creativeNumber && creativeNumber <= maxCreativeNumber) {
            RogerLogger.info("计划{}日平均预定量为，创意数量为{}，满足推荐的创意数量", campaignId, creativeNumber, minCreativeNumber, maxCreativeNumber);
            result.setWarningStatus(BrandBoolEnum.BRAND_FALSE.getCode());
            return SingleResponse.of(result);
        }
        RogerLogger.info("计划{}日平均预定量为，创意数量为{}，推荐设置{}~{}个创意", campaignId, creativeNumber, minCreativeNumber, maxCreativeNumber);
        result.setWarningStatus(BrandBoolEnum.BRAND_TRUE.getCode());
        result.setAverageDailyAmount(averageDailyAmount);
        result.setRecommendMinCreativeNumber(minCreativeNumber);
        result.setRecommendMaxCreativeNumber(maxCreativeNumber);
        return SingleResponse.of(result);
    }

    /**
     * 根据计划日平均预定量获取推荐的创意数量
     * @param averageDailyAmount
     * @return
     */
    private Pair<Integer, Integer> getRecommendedCreativeNumberByAverageDailyAmount(Long averageDailyAmount) {
        if (averageDailyAmount < 100000) {
            return Pair.of(3, 5);
        } else if (averageDailyAmount < 500000) {
            return Pair.of(6, 10);
        } else {
            return Pair.of(11, 20);
        }
    }


    private String getEstimateSpiCode(Integer recommendMethod){
        if(KeywordRecommendMethodEnum.SMART_RECOMMEND.getCode().equals(recommendMethod)){
            return BizCampaignKeywordEstimateSpi.SMART_RECOMMEND;
        }else {
            return BizCampaignKeywordEstimateSpi.CUSTOM;
        }
    }
}