package com.taobao.ad.brand.bp.app.member;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.api.account.login.BizLoginQueryService;
import com.taobao.ad.brand.bp.client.api.member.BizMemberQueryService;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CrmAdvInfoViewDTO;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CustomerRepository;
import lombok.RequiredArgsConstructor;

@HSFProvider(serviceInterface = BizMemberQueryService.class)
@RequiredArgsConstructor
public class BizMemberQueryServiceImpl implements BizMemberQueryService {

    private final CustomerRepository customerRepository;

    @Override
    public SingleResponse<CrmAdvInfoViewDTO> getCrmAdvInfo(ServiceContext context, Long customerMemberId) {
        CrmAdvInfoViewDTO crmAdvInfoViewDTO = customerRepository.getCustomer(customerMemberId);
        return SingleResponse.of(crmAdvInfoViewDTO);
    }
}
