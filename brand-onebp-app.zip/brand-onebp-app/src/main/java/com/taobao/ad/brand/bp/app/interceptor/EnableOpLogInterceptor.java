package com.taobao.ad.brand.bp.app.interceptor;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.oplog.aop.UserProfileInterceptor;
import com.alibaba.ad.oplog.aop.extract.ServiceContextExtractStrategy;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.hermes.framework.aop.BaseAdvisor;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.adapter.port.converter.oplog.ServiceContextConverter;
import com.taobao.ad.brand.bp.adapter.port.converter.oplog.mapstruct.ServiceContextMapStruct;
import com.taobao.ad.brand.bp.app.interceptor.annotation.EnableOpLog;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.uic.SimbaUicRepository;
import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.apache.commons.lang3.StringUtils;
import org.springframework.aop.support.AopUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.ClassUtils;

import javax.annotation.Resource;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Optional;

/**
 * @author gxg
 * @desc 启用oplog拦截器
 */
@Component
public class EnableOpLogInterceptor extends BaseAdvisor {

    @Resource
    private UserProfileInterceptor userProfileInterceptor;
    @Resource
    private SimbaUicRepository simbaUicRepository;

    @Resource
    private ServiceContextConverter serviceContextConverter;

    //@PostConstruct
    public void init() {
        userProfileInterceptor.setServiceContextAdapter(new CustomizeServiceContextExtractStrategy());
    }

    @Override
    public int getOrder() {
        return 1;
    }

    @Override
    protected MethodInterceptor getInterceptor() {
        return (MethodInvocation invocation) -> {
            RogerLogger.info("EnableOpLogInterceptor System invoke start");
            Object result = invocation.proceed();
            try {
                Class<?> targetClass = AopUtils.getTargetClass(invocation.getThis());
                Method method = ClassUtils.getMostSpecificMethod(invocation.getMethod(), targetClass);
                Object[] arguments = invocation.getArguments();
                init();
                userProfileInterceptor.before(method, arguments, invocation.getThis());
            } catch (Exception e) {
                RogerLogger.error("EnableOpLogInterceptor System invoke error e {}", JSONObject.toJSONString(e));
            }
            RogerLogger.info("EnableOpLogInterceptor System invoke end");
            return result;
        };
    }

    @Override
    protected Class<? extends Annotation> getAnnotationClass() {
        return EnableOpLog.class;
    }

    class CustomizeServiceContextExtractStrategy implements ServiceContextExtractStrategy {
        @Override
        public com.alibaba.solar.common.dto.ServiceContext extract(Object[] objects) {
            return Arrays.stream(objects)
                    .filter(arg -> arg instanceof ServiceContext)
                    .map(arg -> {
                        ServiceContext context = (ServiceContext) arg;
                        ServiceContext serviceContext = serviceContextConverter.sourceToTarget(context);
                        modifyOpName(serviceContext);
                        return serviceContext;
                    })
                    .findFirst()
                    .orElse(null);
        }

        /**
         * 修改上下文operName，添加工号，仅用来落日志
         * 小二伪登录时
         * todo 查询日志的时候组装
         *
         * @param context 上下文
         */
        private void modifyOpName(ServiceContext context) {
            try {
                RogerLogger.info("EnableOpLogInterceptor System modifyOpName start context {}", JSONObject.toJSONString(context));
                if (ServiceContextUtil.isAliStaff(context)) {
                    Optional.ofNullable(ServiceContextUtil.getAliStaffBucUserId(context))
                            .map(bucId -> simbaUicRepository.getEmpByBucUserId(bucId))
                            .ifPresent(empDTO -> context.setOperName(String.format("%s(%s)", context.getOperName(), empDTO.getEmpId())));
                }
                // 内部操作 操作人名称定为 系统自动
                if (Integer.valueOf(ServiceContext.OPERTYPE_INNER_OPT).equals(context.getOperType())
                        && StringUtils.isBlank(context.getOperName())) {
                    context.setOperName("系统自动");
                    //修改为普通实现此日志客户可见
                    context.setOperType(ServiceContext.OPERTYPE_NORMAL);
                }
                //AMB 任务回调的参数会设置为amb,导致无法匹配底层日志
                if (!Constant.CLIENT_APP_NAME.equals(context.getClientAppName())) {
                    context.setClientAppName(Constant.CLIENT_APP_NAME);
                }
                // 履约过来的日志拼接上用户工号
                if (Integer.valueOf(ServiceContext.OPERTYPE_READWRITE_BRAND_PERFORM).equals(context.getOperType())
                        && StringUtils.isNotBlank(context.getOperName())
                        && context.getOperName().matches("^[\\u4e00-\\u9fa5]+$")) {
                    context.setOperName(String.format("%s(%s)", context.getOperName(), context.getOperIdStr()));
                }
                RogerLogger.info("EnableOpLogInterceptor System modifyOpName end {}", JSONObject.toJSONString(context));
            } catch (Exception e) {
                RogerLogger.error("EnableOpLogInterceptor.modifyOpName error", e);
            }
        }
    }
}
