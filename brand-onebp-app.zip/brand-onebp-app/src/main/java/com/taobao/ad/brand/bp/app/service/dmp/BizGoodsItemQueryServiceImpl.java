package com.taobao.ad.brand.bp.app.service.dmp;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.api.dmp.BizGoodsItemQueryService;
import com.taobao.ad.brand.bp.client.dto.dmp.ItemMetricsViewDTO;
import com.taobao.ad.brand.bp.client.dto.dmp.query.GoodsItemQueryOption;
import com.taobao.ad.brand.bp.client.dto.dmp.query.GoodsItemQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.rule.RuleCheckResultViewDTO;
import com.taobao.ad.brand.bp.client.enums.dmp.DmpItemCompareTypeEnum;
import com.taobao.ad.brand.bp.common.enums.BooleanEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.JoinerUtil;
import com.taobao.ad.brand.bp.domain.dmp.GoodsItemRepository;
import com.taobao.ad.brand.bp.domain.shield.ShieldAccessRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author yanjingang
 * @date 2025/2/19
 */
@HSFProvider(serviceInterface = BizGoodsItemQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizGoodsItemQueryServiceImpl implements BizGoodsItemQueryService {

    private final GoodsItemRepository goodsItemRepository;
    private final ShieldAccessRepository shieldAccessRepository;

    @Override
    public MultiResponse<ItemMetricsViewDTO> findGoodsItemList(ServiceContext context, GoodsItemQueryViewDTO query, GoodsItemQueryOption option) {
        AssertUtil.notNull(query.getStartDate(), "开始日期不能为空");
        AssertUtil.notNull(query.getEndDate(), "结束日期不能为空");
        List<ItemMetricsViewDTO> itemMetricsViewDTOS = goodsItemRepository.findGoodsItemList(context, query);
        if (CollectionUtils.isEmpty(itemMetricsViewDTOS)) {
            return MultiResponse.of(Lists.newArrayList(), 0);
        }
        if (option != null && option.isFilterItemAccess()) {
            List<Long> itemIds = itemMetricsViewDTOS.stream().map(ItemMetricsViewDTO::getItemId).distinct().collect(Collectors.toList());
            Map<Long, RuleCheckResultViewDTO> resultViewDTOMap = shieldAccessRepository.checkFeedSmartAccessBatch(context, itemIds);
            itemMetricsViewDTOS = itemMetricsViewDTOS.stream().filter(itemIndicatorViewDTO -> {
                RuleCheckResultViewDTO ruleCheckResultViewDTO = resultViewDTOMap.get(itemIndicatorViewDTO.getItemId());
                return ruleCheckResultViewDTO != null && BooleanEnum.TRUE.getValue().equals(ruleCheckResultViewDTO.getIsPass());
            }).collect(Collectors.toList());
            if (CollectionUtils.isEmpty(itemMetricsViewDTOS)) {
                return MultiResponse.of(itemMetricsViewDTOS, 0);
            }
        }
        if (option != null && option.isNeedBenchmarkCompare()) {
            List<Long> itemIds = itemMetricsViewDTOS.stream().map(ItemMetricsViewDTO::getItemId).distinct().collect(Collectors.toList());
            GoodsItemQueryViewDTO benchmarkQueryViewDTO = new GoodsItemQueryViewDTO();
            benchmarkQueryViewDTO.setItemIds(itemIds);
            benchmarkQueryViewDTO.setStartDate(query.getStartDate());
            benchmarkQueryViewDTO.setEndDate(query.getEndDate());
            benchmarkQueryViewDTO.setCompareType(DmpItemCompareTypeEnum.BENCHMARK.getCode());
            List<ItemMetricsViewDTO> itemBenchmarkIndicatorViewDTOS = goodsItemRepository.findGoodsItemList(context, benchmarkQueryViewDTO);
            Map<Long, ItemMetricsViewDTO> itemBenchmarkIndicatorMap = itemBenchmarkIndicatorViewDTOS.stream()
                    .collect(Collectors.toMap(ItemMetricsViewDTO::getItemId, Function.identity(), (v1, v2) -> v1));
            itemMetricsViewDTOS.forEach(itemMetricsViewDTO -> {
                ItemMetricsViewDTO benchmarkMetricsViewDTO = itemBenchmarkIndicatorMap.get(itemMetricsViewDTO.getItemId());
                if (benchmarkMetricsViewDTO == null) {
                    return;
                }
                itemMetricsViewDTO.setBenchmarkV2Uv(benchmarkMetricsViewDTO.getV2Uv());
                itemMetricsViewDTO.setBenchmarkIpv(benchmarkMetricsViewDTO.getIpv());
            });
        }

        return MultiResponse.of(itemMetricsViewDTOS, itemMetricsViewDTOS.size());
    }

    @Override
    public MultiResponse<ItemMetricsViewDTO> findItemMetrics(ServiceContext context, GoodsItemQueryViewDTO query, GoodsItemQueryOption option) {
        AssertUtil.notNull(query.getStartDate(), "开始日期不能为空");
        AssertUtil.notNull(query.getEndDate(), "结束日期不能为空");
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(query.getItemIds()), "宝贝ID不能为空");
        List<ItemMetricsViewDTO> itemMetricsViewDTOS = goodsItemRepository.findItemMetrics(context, query);
        if (CollectionUtils.isEmpty(itemMetricsViewDTOS)) {
            return MultiResponse.of(itemMetricsViewDTOS, 0);
        }
        if (option != null && option.isNeedBenchmarkCompare()) {
            GoodsItemQueryViewDTO benchmarkQueryViewDTO = new GoodsItemQueryViewDTO();
            benchmarkQueryViewDTO.setItemIds(query.getItemIds());
            benchmarkQueryViewDTO.setStartDate(query.getStartDate());
            benchmarkQueryViewDTO.setEndDate(query.getEndDate());
            benchmarkQueryViewDTO.setCompareType(DmpItemCompareTypeEnum.BENCHMARK.getCode());
            List<ItemMetricsViewDTO> itemBenchmarkMetricsViewDTOS = goodsItemRepository.findItemMetrics(context, benchmarkQueryViewDTO);
            Map<String, ItemMetricsViewDTO> itemBenchmarkMetricsMap = itemBenchmarkMetricsViewDTOS.stream()
                    .collect(Collectors.toMap(ItemMetricsViewDTO::getLogDate, Function.identity(), (v1, v2) -> v1));
            itemMetricsViewDTOS.forEach(itemMetricsViewDTO -> {
                ItemMetricsViewDTO benchmarkMetricsViewDTO = itemBenchmarkMetricsMap.get(itemMetricsViewDTO.getLogDate());
                if (benchmarkMetricsViewDTO == null) {
                    return;
                }
                itemMetricsViewDTO.setBenchmarkV2Uv(benchmarkMetricsViewDTO.getV2Uv());
                itemMetricsViewDTO.setBenchmarkIpv(benchmarkMetricsViewDTO.getIpv());
            });
        }

        return MultiResponse.of(itemMetricsViewDTOS, itemMetricsViewDTOS.size());
    }
}
