package com.taobao.ad.brand.bp.app.spi.campaign.inventory;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.nb.framework.core.AbilitySpi;
import com.alibaba.ad.nb.framework.core.annotation.Ability;
import com.alibaba.hermes.framework.error.ErrorCodeAware;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignInquiryOperateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignScheduleViewDTO;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignInventoryWorkflowParam;

import java.util.List;

/**
 * 计划库存操作扩展
 * @author shiyan
 * @date 2023/10/31
 */
@Ability(desc = "计划自动生成及比对")
public interface BizCampaignInventoryOperateSpi extends AbilitySpi {
    // ==================== SPI支持扩展码（CampaignScheduleOperateTypeEnum）===================

    String INQUIRY = "INQUIRY";

    String LOCK = "LOCK";

    String RELEASE = "RELEASE";

    String CANCEL = "CANCEL";

    String MANDATORY_LOCK = "MANDATORY_LOCK";

    String MEDIA_INQUIRY = "MEDIA_INQUIRY";

    String INQUIRY_CALLBACK = "INQUIRY_CALLBACK";

    String LOCK_CALLBACK = "LOCK_CALLBACK";

    String RELEASE_CALLBACK = "RELEASE_CALLBACK";

    String SCROLL_DAILY_UPDATE = "SCROLL_DAILY_UPDATE";

    // ==================== SPI支持扩展点 ===================================================

    ErrorCodeAware validateCampaignInventoryOperate(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO, BizCampaignInventoryWorkflowParam inventoryWorkflowParam);

    List<CampaignScheduleViewDTO> convertToCampaignSchedule(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO, BizCampaignInventoryWorkflowParam inventoryWorkflowParam);

    Void inventoryRequest(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO, BizCampaignInventoryWorkflowParam inventoryWorkflowParam);
}
