package com.taobao.ad.brand.bp.app.service.creative;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.adgroup.CreativeRefViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.nb.ssp.dto.tag.TagTargetDataQueryDTO;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.solar.common.dto.BaseServiceContext;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.api.creative.BizCreativeNoticeService;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.LiveMessageInfoViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.notice.LiveReject;
import com.taobao.ad.brand.bp.client.dto.creative.notice.LiveRejectMsgViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.notice.LiveRepassedMsgViewDTO;
import com.taobao.ad.brand.bp.client.dto.message.MessageViewDTO;
import com.taobao.ad.brand.bp.client.enums.message.MessageSendTypeEnum;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.VelocityUtils;
import com.taobao.ad.brand.bp.domain.cache.CacheRepository;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.config.BrandOneBPDiamondConfig;
import com.taobao.ad.brand.bp.domain.config.CreativeTemplateConfigDiamond;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeRepository;
import com.taobao.ad.brand.bp.domain.message.MessageRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.Nullable;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.*;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.common.constant.Constant.STRING_EMPTY;
import static com.taobao.ad.brand.bp.common.util.BrandDateUtil.DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_1;

/**
 * @author zhaorubing
 * @date 2024/12/5 17:34
 */
@HSFProvider(serviceInterface = BizCreativeNoticeService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizCreativeNoticeServiceImpl implements BizCreativeNoticeService {

    private final CreativeTemplateConfigDiamond creativeTemplateConfigDiamond;
    private final MessageRepository messageRepository;
    private final CreativeRepository creativeRepository;
    private final CampaignRepository campaignRepository;
    private final CampaignGroupRepository campaignGroupRepository;
    private final BrandOneBPDiamondConfig brandOneBPDiamondConfig;
    private final CacheRepository cacheRepository;

    private static final String LIVE_DING_GROUP_TOKEN = "879d1cf56facce992d78337768001b1481f34a1c690c0e5aca3a03ae3ed1f00b";
    /**
     * 直播间审核状态为-2，表示审核拒绝
     */
    private static final Integer LIVE_AUDIT_STATUS_REJECT = -2;
    /**
     * 直播间审核状态为1，表示审核通过
     */
    private static final Integer LIVE_AUDIT_STATUS_REPASSED = 1;
    /**
     * 直播间审核消息类型
     */
    private static final String LIVE_AUDIT_SUB_EVENT = "CHANGE";

    @Override
    public Response liveRejectNotice(ServiceContext context, LiveRejectMsgViewDTO liveRejectMsgViewDTO) {
        RogerLogger.info("BizCreativeNoticeServiceImpl liveRejectNotice liveMessage:{}", JSONObject.toJSONString(liveRejectMsgViewDTO));

        Integer auditStatus = liveRejectMsgViewDTO.getAuditStatus();
        Long memberId = liveRejectMsgViewDTO.getMemberId();
        context.setMemberId(memberId);
        context.setOperType(BaseServiceContext.OPERTYPE_INNER_OPT);

        //直播间审核状态为-2，表示审核拒绝
        if (Objects.equals(auditStatus, LIVE_AUDIT_STATUS_REJECT)) {
            // 从缓存中获取直播拒审消息
            LiveRejectMsgViewDTO cachedWriteReadRejectMsg = getCachedWriteReadRejectMsg(liveRejectMsgViewDTO);
            if (Objects.nonNull(cachedWriteReadRejectMsg)) {
                return Response.success();
            }

            //发送钉钉群消息
            String dingContent = getDingContent(context, liveRejectMsgViewDTO);
            if (StringUtils.isBlank(dingContent)) {
                return Response.success();
            }
            MessageViewDTO messageViewDTO = new MessageViewDTO();
            messageViewDTO.setSubject("风控直播拒审通知");
            messageViewDTO.setContent(dingContent);
            messageViewDTO.setSendType(Lists.newArrayList(MessageSendTypeEnum.DING_GROUP.getValue()));
            messageViewDTO.setDingGroupToken(LIVE_DING_GROUP_TOKEN);
            messageRepository.sendMessage(messageViewDTO);

            // 写直播拒审消息数据到缓存
            writeLiveRejectMsgToCache(liveRejectMsgViewDTO);
        }
        return Response.success();
    }

    @Override
    public Response liveRepassedNotice(ServiceContext context, LiveRepassedMsgViewDTO liveMessage) {
        RogerLogger.info("BizCreativeNoticeServiceImpl liveRepassedNotice liveMessage:{}", JSONObject.toJSONString(liveMessage));

        if (Objects.isNull(liveMessage) || Objects.isNull(liveMessage.getField()) || Objects.isNull(liveMessage.getOldField())) {
            return Response.success();
        }
        String subEvent = liveMessage.getSubEvent();
        Integer oldAuditStatus = liveMessage.getOldField().getAuditStatus();
        Integer newAuditStatus = liveMessage.getField().getAuditStatus();

        Long memberId = liveMessage.getMemberId();
        context.setMemberId(memberId);
        context.setOperType(BaseServiceContext.OPERTYPE_INNER_OPT);

        if (LIVE_AUDIT_SUB_EVENT.equals(subEvent)
                && LIVE_AUDIT_STATUS_REJECT.equals(oldAuditStatus)
                && LIVE_AUDIT_STATUS_REPASSED.equals(newAuditStatus)) {
            //发送钉钉群消息
            String dingContent = getLiveRepassedDingContent(context, liveMessage);
            if (StringUtils.isBlank(dingContent)) {
                return Response.success();
            }
            MessageViewDTO messageViewDTO = new MessageViewDTO();
            messageViewDTO.setSubject("Topshow直播审核重新通过");
            messageViewDTO.setContent(dingContent);
            messageViewDTO.setSendType(Lists.newArrayList(MessageSendTypeEnum.DING_GROUP.getValue()));
            messageViewDTO.setDingGroupToken(LIVE_DING_GROUP_TOKEN);
            messageRepository.sendMessage(messageViewDTO);
        }
        return Response.success();
    }

    private String getLiveRepassedDingContent(ServiceContext context, LiveRepassedMsgViewDTO liveRepassedMsgViewDTO) {
        List<CreativeViewDTO> creativeViewDTOList = getCastingCreativeList(context);
        if (CollectionUtils.isEmpty(creativeViewDTOList)) {
            return STRING_EMPTY;
        }
        List<Long> creativeIdList = creativeViewDTOList.stream().map(CreativeViewDTO::getId).collect(Collectors.toList());
        List<CampaignGroupViewDTO> campaignGroupList = getCampaignGroupList(context, creativeIdList);
        if (CollectionUtils.isEmpty(campaignGroupList)) {
            return STRING_EMPTY;
        }

        LiveMessageInfoViewDTO messageInfoViewDTO = new LiveMessageInfoViewDTO();
        messageInfoViewDTO.setLiveId(liveRepassedMsgViewDTO.getField().getLiveId());
        messageInfoViewDTO.setMemberId(context.getMemberId());

        StringBuilder campaignGroup = new StringBuilder();
        campaignGroupList.forEach(it -> {
            if (campaignGroup.length() > 0) {
                campaignGroup.append(Constant.CHAR_SPLIT_KEY_DOT);
            }
            campaignGroup.append(it.getName()).append("(").append(it.getId()).append(")");
        });
        messageInfoViewDTO.setCampaignGroupList(campaignGroup.toString());

        StringBuilder creative = new StringBuilder();
        creativeViewDTOList.forEach(it -> {
            if (creative.length() > 0) {
                creative.append(Constant.CHAR_SPLIT_KEY_DOT);
            }
            creative.append(it.getName()).append("(").append(it.getId()).append(")");
        });
        messageInfoViewDTO.setCreativeList(creative.toString());

        Map<String, Object> model = new HashMap<>();
        model.put("data", messageInfoViewDTO);
        //群消息不支持 html
        return VelocityUtils.merge("vm/ding/LiveRepassedDingNotice.vm", model);
    }

    @Nullable
    private String getDingContent(ServiceContext context, LiveRejectMsgViewDTO liveRejectMsgViewDTO) {
        String reason = null;
        String newReason = liveRejectMsgViewDTO.getNewReason();
        if (StringUtils.isNotBlank(newReason)) {
            List<LiveReject> liveRejects = JSON.parseArray(newReason, LiveReject.class);
            reason = liveRejects.get(0).getAuditReasonName();
        }
        Date auditTime = Objects.nonNull(liveRejectMsgViewDTO.getProp()) ? liveRejectMsgViewDTO.getProp().getAuditTime() : null;
        Long liveId = liveRejectMsgViewDTO.getElementId();
        Long itemId = liveRejectMsgViewDTO.getItemId();

        List<CreativeViewDTO> creativeViewDTOList = getCastingCreativeList(context);
        if (CollectionUtils.isEmpty(creativeViewDTOList)) {
            return STRING_EMPTY;
        }

        List<Long> creativeIdList = creativeViewDTOList.stream().map(CreativeViewDTO::getId).collect(Collectors.toList());
        List<CampaignGroupViewDTO> campaignGroupList = getCampaignGroupList(context, creativeIdList);
        if (CollectionUtils.isEmpty(campaignGroupList)) {
            return STRING_EMPTY;
        }

        LiveMessageInfoViewDTO messageInfoViewDTO = new LiveMessageInfoViewDTO();
        messageInfoViewDTO.setLiveId(liveId);
        messageInfoViewDTO.setNewReason(reason);
        messageInfoViewDTO.setItemId(itemId);
        messageInfoViewDTO.setAuditTime(BrandDateUtil.date2String(auditTime, DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_1));
        messageInfoViewDTO.setMemberId(context.getMemberId());

        StringBuilder campaignGroup = new StringBuilder();
        campaignGroupList.forEach(it -> {
            if (campaignGroup.length() > 0) {
                campaignGroup.append(Constant.CHAR_SPLIT_KEY_DOT);
            }
            campaignGroup.append(it.getName()).append("(").append(it.getId()).append(")");
        });
        messageInfoViewDTO.setCampaignGroupList(campaignGroup.toString());

        StringBuilder creative = new StringBuilder();
        creativeViewDTOList.forEach(it -> {
            if (creative.length() > 0) {
                creative.append(Constant.CHAR_SPLIT_KEY_DOT);
            }
            creative.append(it.getName()).append("(").append(it.getId()).append(")");
        });
        messageInfoViewDTO.setCreativeList(creative.toString());

        Map<String, Object> model = new HashMap<>();
        model.put("data", messageInfoViewDTO);
        //群消息不支持 html
        return VelocityUtils.merge("vm/ding/LiveRejectDingNotice.vm", model);
    }

    private List<CreativeViewDTO> getCastingCreativeList(ServiceContext context) {
        List<CreativeViewDTO> creativeViewDTOList = creativeRepository.findTopShowLiveCreativeList(context);
        RogerLogger.info("getCreativeRefList creativeViewDTOList:{}", JSONObject.toJSONString(creativeViewDTOList));
        // 过滤投放中的创意
        creativeViewDTOList = creativeViewDTOList.stream()
                .filter(creativeViewDTO -> Objects.nonNull(creativeViewDTO.getStartTime()) && Objects.nonNull(creativeViewDTO.getEndTime())
                        && BrandDateUtil.timeRange(BrandDateUtil.getCurrentTime(), creativeViewDTO.getStartTime(), creativeViewDTO.getEndTime()) == 0)
                .collect(Collectors.toList());
        return creativeViewDTOList;
    }

    private List<CampaignGroupViewDTO> getCampaignGroupList(ServiceContext context, List<Long> creativeIdList) {
        if (CollectionUtils.isEmpty(creativeIdList)) {
            return Lists.newArrayList();
        }
        // 查询创意绑定关系
        CreativeQueryViewDTO creativeQueryViewDTO = new CreativeQueryViewDTO();
        creativeQueryViewDTO.setIds(creativeIdList);
        List<CreativeRefViewDTO> creativeRefList = creativeRepository.findCreativeRefList(context, creativeQueryViewDTO);
        RogerLogger.info("getCampaignGroupList creativeRefList:{}", JSONObject.toJSONString(creativeRefList));
        if (CollectionUtils.isEmpty(creativeRefList)) {
            return Lists.newArrayList();
        }

        // 查询计划信息
        CampaignQueryViewDTO campaignQueryViewDTO = new CampaignQueryViewDTO();
        List<Long> campaignIdList = creativeRefList.stream().map(CreativeRefViewDTO::getCampaignId).distinct().collect(Collectors.toList());
        campaignQueryViewDTO.setCampaignIds(campaignIdList);
        List<CampaignViewDTO> campaignViewDTOList = campaignRepository.queryCampaignList(context, campaignQueryViewDTO);
        RogerLogger.info("getCampaignGroupList campaignViewDTOList:{}", JSONObject.toJSONString(campaignViewDTOList));
        if (CollectionUtils.isEmpty(campaignViewDTOList)) {
            return Lists.newArrayList();
        }

        // 查询订单信息
        List<Long> campaignGroupIdList = campaignViewDTOList.stream().map(CampaignViewDTO::getCampaignGroupId).distinct().collect(Collectors.toList());
        List<CampaignGroupViewDTO> campaignGroupViewDTOList = campaignGroupRepository.findCampaignGroupByIds(context, campaignGroupIdList);
        campaignGroupViewDTOList = campaignGroupViewDTOList.stream()
                .filter(campaignGroupViewDTO -> Objects.nonNull(campaignGroupViewDTO.getStartTime()) && Objects.nonNull(campaignGroupViewDTO.getEndTime())
                        && BrandDateUtil.timeRange(BrandDateUtil.getCurrentTime(), campaignGroupViewDTO.getStartTime(), campaignGroupViewDTO.getEndTime()) == 0)
                .collect(Collectors.toList());
        return campaignGroupViewDTOList;
    }

    private void writeLiveRejectMsgToCache(LiveRejectMsgViewDTO liveRejectMsgViewDTO) {
        String cacheKey = getLiveRejectMsgCacheKey(liveRejectMsgViewDTO);
        Integer liveRejectMsgExpireTime = brandOneBPDiamondConfig.getLiveRejectMsgExpireTime();
        RogerLogger.info("writeLiveRejectNoticeToCache cacheKey={}, liveRejectMsgExpireTime={}", cacheKey, liveRejectMsgExpireTime);
        //缓存设置项大于0才写入缓存
        if (liveRejectMsgExpireTime > 0) {
            cacheRepository.put(cacheKey, liveRejectMsgViewDTO, liveRejectMsgExpireTime);
        }
    }

    private LiveRejectMsgViewDTO getCachedWriteReadRejectMsg(LiveRejectMsgViewDTO liveRejectMsgViewDTO) {
        String cacheKey = getLiveRejectMsgCacheKey(liveRejectMsgViewDTO);
        return (LiveRejectMsgViewDTO) cacheRepository.get(cacheKey);
    }

    private String getLiveRejectMsgCacheKey(LiveRejectMsgViewDTO liveRejectMsgViewDTO) {
        // live_reject_notice_{memberId}_{直播id}_{宝贝id}   宝贝id不为null时，缓存key增加宝贝id
        // live_reject_notice_{memberId}_{直播id}
        Long memberId = liveRejectMsgViewDTO.getMemberId();
        Long liveId = liveRejectMsgViewDTO.getElementId();
        Long itemId = liveRejectMsgViewDTO.getItemId();
        if (Objects.nonNull(itemId)) {
            return String.format("live_reject_notice_%d_%d_%d", memberId, liveId, itemId);
        }
        return String.format("live_reject_notice_%d_%d", memberId, liveId);
    }

}
