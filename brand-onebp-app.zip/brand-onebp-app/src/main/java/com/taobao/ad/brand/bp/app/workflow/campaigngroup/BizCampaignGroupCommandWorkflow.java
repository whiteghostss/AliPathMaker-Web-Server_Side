package com.taobao.ad.brand.bp.app.workflow.campaigngroup;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.spec.annotation.AbilityInject;
import com.alibaba.abf.isolation.spec.common.ReduceType;
import com.alibaba.abf.isolation.utils.AbilityInvoker;
import com.alibaba.abf.spec.common.annotation.SwitchContext;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.price.DayPriceViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.cancel.CampaignGroupCancelViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.process.ProcessRecordViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.purchase.CampaignGroupPurchaseViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.realsettle.RealSettleInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupCalculateInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.salegroup.CampaignGroupSaleGroupViewDTO;
import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.*;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleGroupBudgetSettingTypeEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandSaleGroupSourceEnum;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.utils.DateUtils;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.taobao.ad.brand.bp.app.businessability.FreqBusinessAbility;
import com.taobao.ad.brand.bp.app.businessability.MultiTargetDeliverBusinessAbility;
import com.taobao.ad.brand.bp.app.businessability.TargetBusinessAbility;
import com.taobao.ad.brand.bp.app.businessability.ThirdMonitorSupportBusinessAbility;
import com.taobao.ad.brand.bp.app.interceptor.annotation.EnableOpLog;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignCommandWorkflow;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignInventoryWorkflow;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignQueryWorkflow;
import com.taobao.ad.brand.bp.app.workflow.campaigngroup.process.BizCampaignGroupProcessFactory;
import com.taobao.ad.brand.bp.app.workflow.campaigngroup.process.BizCampaignGroupProcessMethodHook;
import com.taobao.ad.brand.bp.app.workflow.salegroup.BizSaleGroupCommandWorkflow;
import com.taobao.ad.brand.bp.client.context.CampaignGroupStateContext;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignPriceViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.*;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.calculate.CampaignGroupSaleGroupCalViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.calculate.ProductCampaignCalViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.estimate.CampaignGroupSaleGroupEstimateQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.CampaignGroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.query.SaleGroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.salegroup.SaleGroupDiffResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.salegroup.SaleGroupSelectJudgeViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.settle.CampaignGroupRealSettleSaveViewDTO;
import com.taobao.ad.brand.bp.client.dto.cartitem.query.CartItemQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.*;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSkuViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSpuViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.query.BrandSpuQueryViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupBriefStateMappingEnum;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupEventEnum;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.settle.CampaignGroupRealSettleOpTypeEnum;
import com.taobao.ad.brand.bp.client.enums.resourcepackage.SaleGroupOperateTypeEnum;
import com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode;
import com.taobao.ad.brand.bp.client.error.BrandOneBPException;
import com.taobao.ad.brand.bp.common.constant.Constant;
import com.taobao.ad.brand.bp.common.constant.campaigngroup.CampaignGroupConstant;
import com.taobao.ad.brand.bp.common.converter.campaigngroup.CampaignGroupViewConverter;
import com.taobao.ad.brand.bp.common.enums.distlock.DistLockEnum;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizCampaignGroupToolsHelper;
import com.taobao.ad.brand.bp.common.helper.campaigngroup.BizSaleGroupToolsHelper;
import com.taobao.ad.brand.bp.common.statemachine.BrandStateMachine;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.DistLockUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.SalesBriefRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.SalesContractRepository;
import com.taobao.ad.brand.bp.domain.cart.repository.CartItemRepository;
import com.taobao.ad.brand.bp.domain.event.campaigngroup.CampaignGroupStatusTransitEvent;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.IAdgroupBatchDeleteAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupBatchDeleteAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbilityRouteContext;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignDeleteAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignOperateDistLockGetAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignValidateForDeleteCampaignGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.calculate.ICampaignInitForCalculateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.calculate.ICampaignPriceBuildForCalculateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.calculate.ICampaignValidateForCalculateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.*;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.atomability.param.*;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.businessability.ICampaignGroupEstimateBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.businessability.ICampaignGroupOrderBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.workflow.BizCampaignGroupCommandWorkflowExt;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.workflow.param.*;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.*;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.calculate.ISaleGroupBudgetSettingTypeForUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.calculate.ISaleGroupProductValidateForCalculateAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.calculate.ISaleGroupValidateForCalculateAbility;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.*;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.businessability.ISaleGroupAddBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.businessability.ISaleGroupEstimateResultClearBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.businessability.ISaleGroupSyncBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.businessability.ISaleGroupUpdateBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.workflow.param.BizSaleGroupNoticeWorkflowParam;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.IMessageSyncSendAbility;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.param.MessageSyncSendAbilityParam;
import com.taobao.ad.brand.bp.domain.shopwindow.repository.BrandSkuRepository;
import com.taobao.ad.brand.bp.domain.shopwindow.repository.BrandSpuRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.alibaba.abf.isolation.utils.AbilityInvoker.invoke;
import static com.alibaba.abf.isolation.utils.AbilityInvoker.invokeAll;
import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR;
import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_BREAK_RULE;

/**
 * @author lq328563@alibaba-inc.com
 * @date 2023/03/23
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizCampaignGroupCommandWorkflow {

    private final BizCampaignCommandWorkflow bizCampaignCommandWorkflow;
    private final BizCampaignInventoryWorkflow bizCampaignInventoryWorkflow;

    private final ICampaignGroupAddAbility campaignGroupAddAbility;
    private final ICampaignGroupUpdateAbility campaignGroupUpdateAbility;
    private final ICampaignGroupDeleteAbility campaignGroupDeleteAbility;
    private final ICampaignGroupStatusUpdateAbility campaignGroupStatusUpdateAbility;
    private final ICampaignGroupInitForSplitSubCampaignGroupAbility campaignGroupInitForSplitSubCampaignGroupAbility;
    private final ICampaignStructureQueryAbility campaignStructureQueryAbility;
    private final IMessageSyncSendAbility messageSyncSendAbility;

    private final CampaignGroupRepository campaignGroupRepository;
    private final ResourcePackageRepository resourcePackageRepository;
    private final SalesBriefRepository salesBriefRepository;
    private final SalesContractRepository salesContractRepository;
    private final CartItemRepository cartItemRepository;
    private final BrandSpuRepository brandSpuRepository;
    private final BrandSkuRepository brandSkuRepository;
    private final CampaignRepository campaignRepository;
    private final BizCampaignQueryWorkflow bizCampaignQueryWorkflow;

    @AbilityInject(reduce = ReduceType.FIRST)
    private final BizCampaignGroupCommandWorkflowExt bizCampaignGroupCommandWorkflowExt;
    private final CampaignGroupViewConverter campaignGroupViewConverter;

    private final ICampaignInitForCalculateCampaignAbility campaignInitForCalculateCampaignAbility;
    private final ISaleGroupBudgetSettingTypeForUpdateAbility saleGroupBudgetSettingTypeForUpdateAbility;
    private final ISaleGroupValidateForCalculateAbility saleGroupValidateForCalculateAbility;
    private final ISaleGroupProductValidateForCalculateAbility saleGroupProductValidateForCalculateAbility;
    private final ICampaignValidateForCalculateCampaignAbility campaignValidateForCalculateCampaignAbility;
    private final ICampaignPriceBuildForCalculateCampaignAbility campaignPriceBuildForCalculateCampaignAbility;
    private final BizSaleGroupCommandWorkflow saleGroupCommandWorkflow;
    private final ICampaignGroupInquiryInfoUpdateAbility campaignGroupInquiryInfoUpdateAbility;
    private final ICampaignGroupGiveStatusUpdateAbility campaignGroupGiveStatusUpdateAbility;
    private final ICampaignGroupBoostStatusUpdateAbility campaignGroupBoostStatusUpdateAbility;
    private final ICampaignGroupInitForGenerateMainAbility campaignGroupInitForGenerateMainAbility;
    private final ICampaignGroupParentUpdateAbility campaignGroupParentUpdateAbility;
    private final ICampaignGroupMessageAsyncSendAbility campaignGroupMessageAsyncSendAbility;
    private final ISaleGroupDiffForNoticeSaleGroupAbility saleGroupDiffForNoticeSaleGroupAbility;
    private final ISaleGroupInitForAddAbility saleGroupInitForAddAbility;
    private final ISaleGroupInitForUpdateAbility saleGroupInitForUpdateAbility;
    private final ISaleGroupInitForDeleteAbility saleGroupInitForDeleteAbility;
    private final ISaleGroupDeleteAbility saleGroupDeleteAbility;
    private final ISaleGroupStatusUpdateAbility saleGroupStatusUpdateAbility;
    private final ISaleGroupSubContractBindAbility saleGroupSubContractBindAbility;
    private final ISaleGroupValidateForUpdateCheckedResourceAbility saleGroupValidateForUpdateCheckedResourceAbility;
    private final ISaleGroupPackageProductCalculateInfoInitAbility saleGroupPackageProductCalculateInfoInitAbility;
    private final ISaleGroupSelectJudgeForApplyModifyCampaignGroupAbility saleGroupSelectJudgeForApplyModifyCampaignGroupAbility;
    private final ISaleGroupValidateForApplyModifyCampaignGroupAbility saleGroupValidateForApplyModifyCampaignGroupAbility;

    private final ICampaignGroupNameValidateAbility campaignGroupNameValidateAbility;
    private final ICampaignGroupSyncBriefForOrderCampaignGroupAbility campaignGroupSyncBriefForOrderCampaignGroupAbility;
    private final ICampaignGroupSyncBriefForFinishCampaignGroupAbility campaignGroupSyncBriefForFinishCampaignGroupAbility;
    private final ICampaignGroupSyncBriefForFinishRevertCampaignGroupAbility campaignGroupSyncBriefForFinishRevertCampaignGroupAbility;
    private final ICampaignGroupContractUpdateForOrderCampaignGroupAbility campaignGroupContractUpdateForOrderCampaignGroupAbility;
    private final ICampaignGroupContractUpdateForOnlineContractAbility campaignGroupContractUpdateForOnlineContractAbility;
    private final ICampaignGroupContractUpdateForCompleteCampaignGroupAbility campaignGroupContractUpdateForCompleteCampaignGroupAbility;
    private final ICampaignGroupStatusRebuildForOrderCampaignGroupAbility campaignGroupStatusRebuildForOrderCampaignGroupAbility;
    private final ICampaignGroupContractUpdateForNoticeBriefEventAbility campaignGroupContractUpdateForNoticeBriefEventAbility;
    private final ICampaignGroupJudgeForOrderCampaignGroupAbility campaignGroupJudgeForOrderCampaignGroupAbility;
    private final ICampaignGroupJudgeForFinishCampaignGroupAbility campaignGroupJudgeForFinishCampaignGroupAbility;
    private final ICampaignGroupJudgeForFinishRevertCampaignGroupAbility campaignGroupJudgeForFinishRevertCampaignGroupAbility;
    private final ICampaignGroupValidateForFinishCampaignGroupAbility campaignGroupValidateForFinishCampaignGroupAbility;
    private final ICampaignGroupJudgeForResourceConfirmAbility campaignGroupJudgeForResourceConfirmAbility;
    private final ICampaignGroupValidateForFinishRevertCampaignGroupAbility campaignGroupValidateForFinishRevertCampaignGroupAbility;
    private final ICampaignGroupWakeupValidateForUpdateCheckedResourceAbility campaignGroupWakeupValidateForUpdateCheckedResourceAbility;
    private final ICampaignGroupWakeupInitForUpdateCheckedResourceAbility campaignGroupWakeupInitForUpdateCheckedResourceAbility;
    private final ICampaignGroupSaleGroupInitForUpdateCheckedResourceAbility campaignGroupSaleGroupInitForUpdateCheckedResourceAbility;
    private final ICampaignGroupUpdateCheckedResourceAbility campaignGroupUpdateCheckedResourceAbility;
    private final ICampaignGroupStopTimeUpdateForStopCastCampaignGroupAbility campaignGroupStopTimeUpdateForStopCastCampaignGroupAbility;
    private final ICampaignGroupRealSettleSaveAbility campaignGroupRealSettleSaveAbility;
    private final ICampaignGroupRealSettleValidateForSaveAbility campaignGroupRealSettleValidateForSaveAbility;
    private final ICampaignGroupRealSettleInitForSaveAbility campaignGroupRealSettleInitForSaveAbility;
    private final ICampaignGroupRealSettleApplyProcessInstanceForSaveAbility campaignGroupRealSettleApplyProcessInstanceForSaveAbility;
    private final ICampaignGroupValidateForApplyModifyAbility campaignGroupValidateForApplyModifyAbility;
    private final ICampaignGroupStatusValidateForApplyModifyAbility campaignGroupStatusValidateForApplyModifyAbility;
    private final ICampaignGroupUnlockInitForApplyModifyAbility campaignGroupUnlockInitForApplyModifyAbility;
    private final ICampaignGroupStartApplyModifyProcessAbility campaignGroupStartApplyModifyProcessAbility;
    private final ICampaignGroupUnlockUpdateAbility campaignGroupUnlockUpdateAbility;
    private final ICampaignGroupCompleteConfigValidateForSaveCompleteConfigAbility campaignGroupCompleteConfigValidateForSaveCompleteConfigAbility;
    private final ICampaignGroupCompleteConfigSaveAbility campaignGroupCompleteConfigSaveAbility;
    private final ICampaignGroupSaleGroupInitForModifyAbility campaignGroupSaleGroupInitForModifyAbility;
    private final ICampaignGroupModifyBriefAbility campaignGroupModifyBriefAbility;
    private final ICampaignGroupValidateForUnlockRevertAbility campaignGroupValidateForUnlockRevertAbility;
    private final ICampaignGroupUpdateForUnlockRevertAbility campaignGroupUpdateForUnlockRevertAbility;

    private final ICampaignGroupAddPurchaseOrderAbility campaignGroupPurchaseOrderAddAbility;
    private final ICampaignGroupPurchaseOrderJudgeAbility campaignGroupPurchaseOrderJudgeAbility;
    private final ICampaignGroupPurchaseOrderUpdateAbility campaignGroupPurchaseOrderUpdateAbility;

    private final ICampaignGroupValidateForDeleteAbility campaignGroupValidateForDeleteAbility;
    private final ICampaignValidateForDeleteCampaignGroupAbility campaignValidateForDeleteCampaignGroupAbility;

    private final ICampaignDeleteAbility campaignDeleteAbility;
    private final IAdgroupBatchDeleteAbility adgroupBatchDeleteAbility;
    private final ICampaignGroupCalAutoCancelExpireTimeAbility campaignGroupCalAutoCancelExpireTimeAbility;
    private final ICampaignGroupValidateForCancelAbility campaignGroupValidateForCancelAbility;
    private final ICampaignGroupInitForCancelAbility campaignGroupInitForCancelAbility;
    private final ICampaignGroupCancelWarningSendNoticeAbility campaignGroupCancelWarningSendNoticeAbility;

    private final ICampaignOperateDistLockGetAbility campaignOperateDistLockGetAbility;



    /**
     * 新建订单
     * 先创建子订单，再创建主订单
     *
     * @param context
     * @param campaignGroupViewDTO
     * @return
     */
    @SwitchContext
    public List<CampaignGroupViewDTO> addCampaignGroupForSelfService(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO) {
        List<CampaignGroupViewDTO> addedCampaignGroupList = Lists.newArrayList();
        try {
            // 获取参数
            BizCampaignGroupWorkflowParam bizCampaignGroupWorkflowParam = buildCampaignGroupWorkflowParamForSave(context, campaignGroupViewDTO);
            // 添加子订单
            executeAddCampaignGroup(context, campaignGroupViewDTO, bizCampaignGroupWorkflowParam);
            addedCampaignGroupList.add(campaignGroupViewDTO);
            // 生成主订单
            CampaignGroupViewDTO mainCampaignGroupViewDTO = generateMainCampaignGroup(context, campaignGroupViewDTO);
            // 添加主订单
            addMainCampaignGroupForSelfService(context, mainCampaignGroupViewDTO);
            addedCampaignGroupList.add(mainCampaignGroupViewDTO);
            // 设置主子订单关联关系
            campaignGroupParentUpdateAbility.handle(context, CampaignGroupParentUpdateAbilityParam.builder()
                    .abilityTarget(campaignGroupViewDTO).mainCampaignGroupViewDTO(mainCampaignGroupViewDTO).build());
            // 新建订单后置处理
            afterCampaignGroupAdd(addedCampaignGroupList);
        } catch (Exception e) {
            RogerLogger.error("添加订单失败 : " + e.getMessage(), e);
            ServiceContextUtil.buildServiceContextSession(context);
            // 删除主订单和子订单
            physicalDeleteCampaignGroups(context, campaignGroupViewDTO, true);
            throw e;
        }

        return addedCampaignGroupList;
    }

    private Integer updateMainCampaignGroup(ServiceContext context, CampaignGroupViewDTO subCampaignGroupViewDTO) {
        CampaignGroupViewDTO mainCampaignGroupViewDTO = generateMainCampaignGroup(context, subCampaignGroupViewDTO);
        ServiceContext mainContext = ServiceContextUtil.buildServiceContextForBizCode(context.getMemberId(), BizCodeEnum.BRANDONEBP.getBizCode());
        // 由于有update的删除更新场景，需要全量重复绑定
        Integer count = campaignGroupUpdateAbility.handle(mainContext, CampaignGroupUpdateAbilityParam.builder()
                .abilityTarget(mainCampaignGroupViewDTO).needUpdateSaleGroupAll(true).build());
        ServiceContextUtil.buildServiceContextSession(context);
        return count;
    }

    private CampaignGroupViewDTO addMainCampaignGroupForSelfService(ServiceContext context, CampaignGroupViewDTO mainCampaignGroupViewDTO) {
        ServiceContext mainContext = ServiceContextUtil.buildServiceContextForBizCode(context.getMemberId(), BizCodeEnum.BRANDONEBP.getBizCode());
        Long campaignGroupId = campaignGroupAddAbility.handle(mainContext, CampaignGroupAbilityParam.builder().abilityTarget(mainCampaignGroupViewDTO).build());
        mainCampaignGroupViewDTO.setId(campaignGroupId);

        ServiceContextUtil.buildServiceContextSession(context);
        return mainCampaignGroupViewDTO;
    }

    /**
     * 生成主订单
     * @param context
     * @param subCampaignGroup
     * @return
     */
    public CampaignGroupViewDTO generateMainCampaignGroup(ServiceContext context, CampaignGroupViewDTO subCampaignGroup) {
        if (!BizCampaignGroupToolsHelper.isSubSelfServiceCampaignGroup(subCampaignGroup)) {
            return null;
        }
        // 从子订单复制
        CampaignGroupViewDTO mainCampaignGroupViewDTO = campaignGroupViewConverter.convertSelf(subCampaignGroup);
        // 初始化
        campaignGroupInitForGenerateMainAbility.handle(context, CampaignGroupGenerateMainAbilityParam.builder()
                .abilityTarget(mainCampaignGroupViewDTO).subCampaignGroup(subCampaignGroup).build());
        return mainCampaignGroupViewDTO;
    }


    /**
     * 新建销售订单（NEW）
     * 入口程序 -
     *
     * @param context
     * @param mainCampaignGroupViewDTO
     * @return
     */
    public List<CampaignGroupViewDTO> addCampaignGroupForSale(ServiceContext context, CampaignGroupViewDTO mainCampaignGroupViewDTO) {
        List<CampaignGroupViewDTO> addedCampaignGroupList = Lists.newArrayList();
        try {
            // 1. 获取参数
            BizCampaignGroupWorkflowParam bizCampaignGroupWorkflowParam = buildCampaignGroupWorkflowParamForSave(context, mainCampaignGroupViewDTO);
            // 2. 添加主订单
            executeAddCampaignGroup(context, mainCampaignGroupViewDTO, bizCampaignGroupWorkflowParam);
            addedCampaignGroupList.add(mainCampaignGroupViewDTO);
            // 3. 拆分子订单
            List<CampaignGroupViewDTO> subCampaignGroupList = splitSubCampaignGroupList(context, mainCampaignGroupViewDTO);
            for (CampaignGroupViewDTO subCampaignGroup : subCampaignGroupList) {
                // 构建子订单context
                ServiceContext subContext = ServiceContextUtil.buildServiceContextForSceneId(subCampaignGroup.getMemberId(), subCampaignGroup.getSceneId());
                // 执行添加子订单
                executeAddCampaignGroup(subContext, subCampaignGroup, bizCampaignGroupWorkflowParam);
                addedCampaignGroupList.add(subCampaignGroup);
            }
            // 4. 新建订单后置处理
            afterCampaignGroupAdd(addedCampaignGroupList);
        } catch (Exception e) {
            RogerLogger.error("添加订单失败 : " + e.getMessage(), e);
            ServiceContextUtil.buildServiceContextSession(context);
            // 删除主订单和子订单
            physicalDeleteCampaignGroups(context, mainCampaignGroupViewDTO, true);
            throw e;
        }
        return addedCampaignGroupList;
    }

    /**
     * 拆分子订单
     * @param context
     * @param mainCampaignGroupViewDTO
     * @return
     */
    public List<CampaignGroupViewDTO> splitSubCampaignGroupList(ServiceContext context, CampaignGroupViewDTO mainCampaignGroupViewDTO) {
        if (!BizCampaignGroupToolsHelper.isSaleCampaignGroup(mainCampaignGroupViewDTO)) {
            return Lists.newArrayList();
        }
        // split sub campaignGroup
        List<Integer> sceneIds = mainCampaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream()
                .map(SaleGroupInfoViewDTO::getSaleBusinessLine).distinct().collect(Collectors.toList());
        if (CollectionUtils.isEmpty(sceneIds)) {
            return Lists.newArrayList();
        }
        List<CampaignGroupViewDTO> subCampaignGroupList = Lists.newArrayList();
        // 从主订单获取子订单分组信息
        Map<Integer/*sceneId*/, List<SaleGroupInfoViewDTO>> subCampaignGroupSaleGroupMap = splitSubCampaignGroupSaleGroups(mainCampaignGroupViewDTO);
        for (Integer sceneId : sceneIds) {
            // 从主订单复制
            CampaignGroupViewDTO subCampaignGroupViewDTO = campaignGroupViewConverter.convertSelf(mainCampaignGroupViewDTO);
            List<SaleGroupInfoViewDTO> subSaleGroupList = subCampaignGroupSaleGroupMap.getOrDefault(sceneId, Lists.newArrayList());
            subCampaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().setSaleGroupInfoViewDTOList(subSaleGroupList);
            ServiceContext subContext = ServiceContextUtil.buildServiceContextForSceneId(context.getMemberId(), sceneId);
            // 初始化基础信息
            campaignGroupInitForSplitSubCampaignGroupAbility.handle(subContext, CampaignGroupSplitAbilityParam.builder()
                    .abilityTarget(subCampaignGroupViewDTO).mainCampaignGroup(mainCampaignGroupViewDTO).sceneId(sceneId).build());
            // 设置分组信息
            subCampaignGroupList.add(subCampaignGroupViewDTO);
        }
        ServiceContextUtil.buildServiceContextSession(context);
        return subCampaignGroupList;
    }

    /**
     * 根据主订单获取子订单分组信息
     *
     * @param mainCampaignGroupViewDTO
     * @return
     */
    private Map<Integer, List<SaleGroupInfoViewDTO>> splitSubCampaignGroupSaleGroups(CampaignGroupViewDTO mainCampaignGroupViewDTO) {
        List<SaleGroupInfoViewDTO> saleGroupInfoViewDTOList = campaignGroupViewConverter.convertSaleGroupInfoSelfList(mainCampaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList());
        return saleGroupInfoViewDTOList.stream()
                .filter(saleGroup -> saleGroup.getSaleBusinessLine() != null)
                .peek(saleGroupInfo -> {
                    saleGroupInfo.setId(null);
                    saleGroupInfo.setCampaignGroupId(null);
                }).collect(Collectors.groupingBy(SaleGroupInfoViewDTO::getSaleBusinessLine));
    }

    /**
     * 更新子订单
     *
     * @param subContext
     * @param subCampaignGroupViewDTO
     * @return
     */
    public Integer updateCampaignGroupPartForSelfService(ServiceContext subContext, CampaignGroupViewDTO subCampaignGroupViewDTO) {
        // 1. 获取参数
        BizCampaignGroupWorkflowParam bizCampaignGroupWorkflowParam = buildCampaignGroupWorkflowParamForSave(subContext, subCampaignGroupViewDTO);
        // 2. 先更新子订单
        Integer count = executeUpdateCampaignGroup(subContext, subCampaignGroupViewDTO, bizCampaignGroupWorkflowParam);
        // 3. 重新获取子订单
        CampaignGroupViewDTO dbSubCampaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(subContext, subCampaignGroupViewDTO.getId());
        // 4. 更新主订单
        updateMainCampaignGroup(subContext, dbSubCampaignGroupViewDTO);
        // 5. 执行后置处理
        afterCampaignGroupUpdate(ImmutableMap.of(CampaignGroupEventEnum.UPDATE, Lists.newArrayList(dbSubCampaignGroupViewDTO)));

        return count;
    }

    /**
     * 设置分组计算信息
     *
     * @param context
     * @param campaignGroupViewDTO
     * @param resourcePackageSaleGroupList
     */
    public void setSaleGroupCalculateInfo(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupList) {
        // 1. 构建参数
        Map<Long, ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupMap = resourcePackageSaleGroupList.stream().collect(Collectors.toMap(ResourcePackageSaleGroupViewDTO::getId, Function.identity(), (a1, a2) -> a1));
        CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder()
                .campaignGroupId(campaignGroupViewDTO.getId())
                .campaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode())
                .build();
        CampaignQueryOption queryOption = CampaignQueryOption.builder().needCampaignTree(false).needFrequency(false).needTarget(false).build();
        List<CampaignViewDTO> campaignViewDTOList = campaignStructureQueryAbility.handle(context, CampaignStructureQueryAbilityParam.builder()
                .abilityTarget(campaignQueryViewDTO).queryOption(queryOption).build());

        Map<Long, List<CampaignViewDTO>> saleGroupCampaignMap = campaignViewDTOList.stream().collect(Collectors.groupingBy(item -> item.getCampaignSaleViewDTO().getSaleGroupId()));
        // 2. 初始化
        // 2-1. 初始化分组产品计算信息
        saleGroupPackageProductCalculateInfoInitAbility.handle(context, SaleGroupPackageProductCalculateInfoInitAbilityParam.builder()
                .abilityTargets(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList())
                .resourcePackageSaleGroupMap(resourcePackageSaleGroupMap).saleGroupCampaignMap(saleGroupCampaignMap)
                .build());
        // 2-2. 初始化分组信息
        campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().forEach(saleGroupInfoViewDTO -> {
            bizCampaignCommandWorkflow.rebuildCalSaleGroupInfo(context,
                    resourcePackageSaleGroupMap.get(saleGroupInfoViewDTO.getSaleGroupId()),
                    saleGroupInfoViewDTO,
                    saleGroupCampaignMap.getOrDefault(saleGroupInfoViewDTO.getSaleGroupId(), Lists.newArrayList()));
        });
        // 3. 执行更新
        CampaignGroupViewDTO updateCampaignGroup = new CampaignGroupViewDTO();
        updateCampaignGroup.setId(campaignGroupViewDTO.getId());
        updateCampaignGroup.setCampaignGroupSaleGroupViewDTO(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO());
        campaignGroupUpdateAbility.handle(context, CampaignGroupUpdateAbilityParam.builder().abilityTarget(updateCampaignGroup).build());
    }

    public void saveCompleteInfo(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO) {
        AssertUtil.notNull(campaignGroupViewDTO, "参数不能为空");
        AssertUtil.notNull(campaignGroupViewDTO.getId(), "订单ID不能为空");
        CampaignGroupViewDTO dbCampaignGroup = campaignGroupRepository.getCampaignGroup(context, campaignGroupViewDTO.getId());
        AssertUtil.notNull(dbCampaignGroup, "订单不存在");
        // 校验
        campaignGroupCompleteConfigValidateForSaveCompleteConfigAbility.handle(context, CampaignGroupCompleteConfigAbilityParam.builder().abilityTarget(campaignGroupViewDTO.getCampaignGroupCompleteConfigViewDTO()).campaignGroupViewDTO(dbCampaignGroup).build());
        // 子订单保存
        campaignGroupCompleteConfigSaveAbility.handle(context, CampaignGroupCompleteConfigAbilityParam.builder().abilityTarget(campaignGroupViewDTO.getCampaignGroupCompleteConfigViewDTO()).campaignGroupViewDTO(dbCampaignGroup).build());

        // 主订单保存
        CampaignGroupViewDTO mainCampaignGroup = campaignGroupRepository.getCampaignGroup(context, dbCampaignGroup.getParentId());
        ServiceContext mainContext = ServiceContextUtil.buildServiceContextForBizCode(context.getMemberId(), BizCodeEnum.BRANDONEBP.getBizCode());
        mainCampaignGroup.setCampaignGroupCompleteConfigViewDTO(campaignGroupViewDTO.getCampaignGroupCompleteConfigViewDTO());
        campaignGroupCompleteConfigSaveAbility.handle(mainContext, CampaignGroupCompleteConfigAbilityParam.builder().abilityTarget(campaignGroupViewDTO.getCampaignGroupCompleteConfigViewDTO()).campaignGroupViewDTO(mainCampaignGroup).build());

        // 发送主订单
        campaignGroupMessageAsyncSendAbility.handle(context, CampaignGroupMessageAsyncSendAbilityParam.builder()
                .abilityTarget(mainCampaignGroup).domainEvent(CampaignGroupEventEnum.COMPLETE_INFO_CONFIG.name()).build());
    }

    /**
     * 更新销售订单（部分更新）
     * 先更新主订单，再更新子订单
     *
     * @param context
     * @param campaignGroupViewDTO
     * @return
     */
    public Integer updateCampaignGroupPartForSale(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO) {
        Map<CampaignGroupEventEnum, List<CampaignGroupViewDTO>> operatedCampaignGroupMap = Maps.newHashMap();
        // 1. 获取参数
        BizCampaignGroupWorkflowParam bizCampaignGroupWorkflowParam = buildCampaignGroupWorkflowParamForSave(context, campaignGroupViewDTO);
        // 2. 更新主订单
        Integer count = executeUpdateCampaignGroup(context, campaignGroupViewDTO, bizCampaignGroupWorkflowParam);
        operatedCampaignGroupMap.put(CampaignGroupEventEnum.UPDATE, Lists.newArrayList(campaignGroupViewDTO));
        // 重新获取主订单
        CampaignGroupViewDTO dbMainCampaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(context, campaignGroupViewDTO.getId());
        bizCampaignGroupWorkflowParam.setDbCampaignGroupViewDTO(dbMainCampaignGroupViewDTO);

        // 3. 拆分子订单
        List<CampaignGroupViewDTO> subCampaignGroupList = splitSubCampaignGroupList(context, dbMainCampaignGroupViewDTO);
        // 4. 更新子订单
        updateSubCampaignGroupList(context, subCampaignGroupList, bizCampaignGroupWorkflowParam, operatedCampaignGroupMap);

        // 5. 执行后置处理
        afterCampaignGroupUpdate(operatedCampaignGroupMap);

        return count;
    }

    /**
     * 发起采购单
     * @param serviceContext
     * @param campaignGroupViewDTO
     * @return
     */
    public Response addPurchaseOrder(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO) {
        // 1. 获取参数
        BizCampaignGroupPurchaseOrderWorkflowParam purchaseOrderWorkflowParam = bizCampaignGroupCommandWorkflowExt.buildParamForPurchaseOrder(serviceContext, campaignGroupViewDTO);
        // 2. 发起采购单
        CampaignGroupPurchaseProcessViewDTO purchaseResultViewDTO = campaignGroupPurchaseOrderAddAbility.handle(serviceContext, CampaignGroupPurchaseOrderAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO).subCampaignViewDTOList(purchaseOrderWorkflowParam.getCampaignList()).build());
        // 3. 更新采购单信息
        campaignGroupPurchaseOrderUpdateAbility.handle(serviceContext, CampaignGroupPurchaseOrderUpdateAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupPurchaseViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO)
                .purchaseProcessViewDTO(purchaseResultViewDTO).build());

        return Response.success();
    }

    /**
     * 更新采购状态
     * @param serviceContext
     * @param campaignGroupViewDTO
     */
    public void updatePurchaseOrderStatus(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO) {
        // 1. 校验采购状态，仅采购中时再查询采购状态
        CampaignGroupPurchaseViewDTO purchaseViewDTO = campaignGroupViewDTO.getCampaignGroupPurchaseViewDTO();
        if (!BrandCampaignGroupPurchaseStatusEnum.PURCHASE_ING.getCode().equals(purchaseViewDTO.getPurchaseStatus())) {
            return;
        }
        // 2. 获取参数
        BizCampaignGroupPurchaseOrderWorkflowParam purchaseOrderWorkflowParam = bizCampaignGroupCommandWorkflowExt.buildParamForPurchaseOrder(serviceContext, campaignGroupViewDTO);
        // 3. 查询采购单状态
        CampaignGroupPurchaseProcessViewDTO purchaseResultViewDTO = campaignGroupPurchaseOrderJudgeAbility.handle(serviceContext, CampaignGroupPurchaseOrderAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO).subCampaignViewDTOList(purchaseOrderWorkflowParam.getCampaignList()).build());
        RogerLogger.info("campaign group  {} needPurchaseOrder result {}",campaignGroupViewDTO.getId(), JSON.toJSONString(purchaseResultViewDTO));
        // 4. 更新采购单信息
        campaignGroupPurchaseOrderUpdateAbility.handle(serviceContext, CampaignGroupPurchaseOrderUpdateAbilityParam.builder()
                .abilityTarget(purchaseViewDTO).campaignGroupViewDTO(campaignGroupViewDTO)
                .purchaseProcessViewDTO(purchaseResultViewDTO).build());

    }

    /**
     * 订单分组计算流程
     * @param context
     * @param saleGroupCalViewDTO
     * @return
     */
    public CampaignGroupSaleGroupCalViewDTO calculate(ServiceContext context, CampaignGroupSaleGroupCalViewDTO saleGroupCalViewDTO){
        DistLockEnum distLockEnum = DistLockEnum.SALE_GROUP_CALCULATE_KEY;
        String lockKey = distLockEnum.formatLockKey(saleGroupCalViewDTO.getSaleGroupId());
        String lockValue = distLockEnum.formatLockValue(DateUtils.currentTime(),context.getOperName());
        Integer expireTime = distLockEnum.getExpireTime();
        CampaignGroupSaleGroupCalViewDTO updateSaleGroupCalViewDTO = DistLockUtil.execute(lockKey, lockValue, expireTime,
                () -> {
                    //计算场景流程参数构建
                    BizCampaignGroupCalculateWorkflowParam calculateWorkflowParam = bizCampaignGroupCommandWorkflowExt.buildParamForCalculate(context, saleGroupCalViewDTO);
                    // 获取分组下的计划锁量的分布式锁（确定没有被上锁，则可以继续计算）
                    campaignOperateDistLockGetAbility.handle(context, CampaignOperateDistLockAbilityParam.builder().abilityTargets(calculateWorkflowParam.getCampaignTreeViewDTOList().stream().map(CampaignViewDTO::getId).collect(Collectors.toList())).build());
                    //数据初始化
                    initForCalculate(context, saleGroupCalViewDTO, calculateWorkflowParam);
                    //计算数据校验
                    validateForCalculate(context, saleGroupCalViewDTO, calculateWorkflowParam);
                    /************************  计算 开始  **************************/
                    //1.分配产品预算 2.分配一级计划预算
                    CampaignGroupSaleGroupCalViewDTO calculatedResult = saleGroupCommandWorkflow.assignSaleGroupProductCampaignBudget(context, saleGroupCalViewDTO,calculateWorkflowParam);

                    //构建计划价格信息（包含了cpt的轮数计算）
                    List<CampaignPriceViewDTO> campaignPriceList = campaignPriceBuildForCalculateCampaignAbility.handle(context, CampaignCalculateAbilityParam.builder().abilityTarget(calculatedResult).campaignTreeList(calculateWorkflowParam.getCampaignTreeViewDTOList()).packageSaleGroupViewDTO(calculateWorkflowParam.getPackageSaleGroupViewDTO()).build());

                    //分配二级计划预算、比例
                    bizCampaignCommandWorkflow.assignSubCampaignBudget(context, campaignPriceList, calculateWorkflowParam.getCampaignTreeViewDTOList(), calculateWorkflowParam.getCampaignGroupViewDTO(),
                            BizCampaignToolsHelper.getCampaignPVAssignSceneEnum(calculateWorkflowParam.getPackageSaleGroupViewDTO().getSaleProductLine()));


                    //重新校验计划预算（单媒体营销和二环cpt）
                    bizCampaignCommandWorkflow.reCheckCampaignBudget(context,calculatedResult,calculateWorkflowParam);

                    //更新计划 （1.更新计划模型 2 清空预定量信息 3.智能分配预定量 ）
                    List<CampaignViewDTO> toUpdateInquiryCampaignList = calculateWorkflowParam.getCampaignTreeViewDTOList().stream().filter(
                        v -> !Constant.LOCK_AND_ING_CAMPAIGN_STATUS_LIST.contains(v.getStatus())).collect(Collectors.toList());
                    bizCampaignCommandWorkflow.addOrUpdateCampaignWithoutInquiryByCalculate(context, calculatedResult.getCampaignGroupId(), toUpdateInquiryCampaignList);
                    bizCampaignCommandWorkflow.updateCampaignSuccessInquiryAll(context, toUpdateInquiryCampaignList);
                    bizCampaignInventoryWorkflow.autoAssignCampaignInquiryAmountSync(context,toUpdateInquiryCampaignList);

                    //更新分组曝光量，重算cpm单价
                    saleGroupCommandWorkflow.calculateSaleGroup(context, calculateWorkflowParam.getCampaignTreeViewDTOList(), calculatedResult, calculateWorkflowParam.getPackageSaleGroupViewDTO());

                    //更新订单信息
                    updateCampaignGroupInfos(context, calculateWorkflowParam.getCampaignGroupViewDTO(), calculatedResult, calculateWorkflowParam.getPackageSaleGroupViewDTO(),calculateWorkflowParam.getSaleGroupInfoViewDTO());

                    //商业能力挂载--清除预估结果
                    BusinessAbilityRouteContext businessAbilityRouteContext = BusinessAbilityRouteContext.builder().specifiedBusinessAbilityCodes(Lists.newArrayList(MultiTargetDeliverBusinessAbility.ABILITY_CODE)).build();
                    invokeAll(ISaleGroupEstimateResultClearBusinessAbilityPoint.class, businessAbilityRouteContext,
                            callback -> callback.invokeForClearSaleGroupEstimateResult(context, saleGroupCalViewDTO.getCampaignGroupId(), Lists.newArrayList(saleGroupCalViewDTO.getSaleGroupId())));
                    RogerLogger.info("calculate end campaignGroupId {} saleGroupId {}",saleGroupCalViewDTO.getCampaignGroupId(),saleGroupCalViewDTO.getSaleGroupId());
                    /************************  计算 结束  **************************/
                    return calculatedResult;
                },
                lockCurValue -> {
                    String tryLockFailTip = String.format("分组%s正在计算中,操作信息:%s，请稍后操作!", saleGroupCalViewDTO.getSaleGroupId(), lockCurValue);
                    throw new BrandOneBPException(BrandOneBPBaseErrorCode.DISTLOCK.of(tryLockFailTip));
                }
        );
        return updateSaleGroupCalViewDTO;
    }

    /**
     * 校验是否可以下单
     *
     * @param context
     * @param campaignGroupOrderCommandViewDTO
     * @param campaignGroupOrderCommandViewDTO
     */
    public void canOrder(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO) {
        // 1. 构建参数
        BizCampaignGroupProcessOrderWorkflowParam processWorkflowParam = buildWorkflowParamForOrder(context, campaignGroupOrderCommandViewDTO);
        // 2. 校验下单参数
        bizCampaignGroupCommandWorkflowExt.validateForOrder(context, campaignGroupOrderCommandViewDTO, processWorkflowParam);
    }

    /**
     * 自助订单预下单
     * 生成售卖中心的Brief等信息
     *
     * @param serviceContext
     * @param campaignGroupViewDTO
     */
    @EnableOpLog
    public void preOrder(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO) {
        BizCampaignGroupProcessOrderWorkflowParam processWorkflowParam = buildWorkflowParamForPreOrder(serviceContext, campaignGroupViewDTO);
        // 预下单前置
        bizCampaignGroupCommandWorkflowExt.beforePreOrder(serviceContext, campaignGroupViewDTO, processWorkflowParam);
        // 执行更新
        campaignGroupUpdateAbility.handle(serviceContext, CampaignGroupUpdateAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
        // 执行迁移
        this.transitCampaignGroup(serviceContext, campaignGroupViewDTO, CampaignGroupEventEnum.PRE_ORDER);
    }

    private BizCampaignGroupProcessOrderWorkflowParam buildWorkflowParamForPreOrder(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO) {
        BizCampaignGroupProcessOrderWorkflowParam orderWorkflowParam = new BizCampaignGroupProcessOrderWorkflowParam();
        if (BizCampaignGroupToolsHelper.isSubCampaignGroup(campaignGroupViewDTO)) {
            // 计划信息
            CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder()
                    .campaignGroupId(campaignGroupViewDTO.getId())
                    .campaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode())
                    .build();
            List<CampaignViewDTO> campaignViewDTOList = campaignStructureQueryAbility.handle(serviceContext, CampaignStructureQueryAbilityParam.builder()
                    .abilityTarget(campaignQueryViewDTO).queryOption(new CampaignQueryOption()).build());
            orderWorkflowParam.setCampaignList(campaignViewDTOList);
        } else {
            // 子订单
            List<CampaignGroupViewDTO> subCampaignGroupList = campaignGroupRepository.findSubCampaignGroupList(serviceContext, campaignGroupViewDTO.getId());
            orderWorkflowParam.setSubCampaignGroupList(subCampaignGroupList);
        }
        return orderWorkflowParam;
    }


    /**
     * 下单
     * 使用场景：
     * 1. 销售子订单
     * 2. 销售主订单
     * 3. 普通自助子订单(通过监听订单更新事件，自动触发)
     * 4. 普通自助主订单
     *
     * 极简自助下单参照
     * @see this.orderForCartItemSolution
     *
     * @param context
     * @param campaignGroupOrderCommandViewDTO
     */
    public void order(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO) {
        // 1. 构建参数
        BizCampaignGroupProcessOrderWorkflowParam processWorkflowParam = buildWorkflowParamForOrder(context, campaignGroupOrderCommandViewDTO);
        CampaignGroupViewDTO campaignGroupViewDTO = processWorkflowParam.getCampaignGroupViewDTO();
        // 2. 判断是否支持下单状态迁移
        if (campaignGroupOrderCommandViewDTO.getNeedTransit() == null || campaignGroupOrderCommandViewDTO.getNeedTransit()) {
            Boolean canTransit = campaignGroupJudgeForOrderCampaignGroupAbility.handle(context, CampaignGroupTransitAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
            if (!canTransit) {
                return;
            }
        }

        // 3. 商业能力挂载，分组预估、计划定向、计划频控
        BusinessAbilityRouteContext businessAbilityRouteContext = BusinessAbilityRouteContext.builder()
                .specifiedBusinessAbilityCodes(Lists.newArrayList(MultiTargetDeliverBusinessAbility.ABILITY_CODE, TargetBusinessAbility.ABILITY_CODE, FreqBusinessAbility.ABILITY_CODE)).build();
        invokeAll(ICampaignGroupOrderBusinessAbilityPoint.class, businessAbilityRouteContext,
                callBack -> callBack.invokeForCampaignGroupOrder(context, campaignGroupOrderCommandViewDTO,
                        campaignGroupViewDTO, processWorkflowParam.getCampaignList(),
                        processWorkflowParam.getResourcePackageSaleGroupList(), businessAbilityRouteContext));

        // 4. 下单前置处理
        bizCampaignGroupCommandWorkflowExt.beforeOrder(context, campaignGroupOrderCommandViewDTO, processWorkflowParam);

        // 5. 执行下单
        // 5-1. 先进行一次更新
        campaignGroupUpdateAbility.handle(context, CampaignGroupUpdateAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
        // 5-2. 下单来自售卖中心的分组(SaleGroupSourceEnum.SALE_PLATFORM)
        orderSalePlatformSaleGroup(context, campaignGroupOrderCommandViewDTO, processWorkflowParam.getCampaignGroupViewDTO(), processWorkflowParam);
        // 5-3. 下单来自资源包的分组(SaleGroupSourceEnum.PACKAGE_PLATFORM)
        orderPackagePlatformSaleGroup(context, processWorkflowParam.getCampaignGroupViewDTO(), processWorkflowParam.getPackagePlatformSaleGroupIds());

        // 6. 下单后置处理
        // 6-1. 不包含主分组下单时，可能出现投后补量场景，所以需要重新计算订单、的状态
        if (CollectionUtils.isEmpty(processWorkflowParam.getSalePlatformSaleGroupIds())) {
            Integer targetStatus = campaignGroupStatusRebuildForOrderCampaignGroupAbility.handle(context, CampaignGroupAbilityParam.builder()
                    .abilityTarget(campaignGroupViewDTO).build());
            campaignGroupStatusUpdateAbility.handle(context, CampaignGroupStatusUpdateAbilityParam.builder()
                    .abilityTarget(campaignGroupViewDTO).targetStatus(targetStatus).build());
        }
        // 6-2. 其他下单后置处理
        bizCampaignGroupCommandWorkflowExt.afterOrder(context, campaignGroupOrderCommandViewDTO, processWorkflowParam);
    }


    @SwitchContext
    public void orderForCartItemSolution(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderViewDTO, CampaignGroupViewDTO campaignGroup, List<CampaignViewDTO> campaignViewDTOList) {
        // 1. 商业能力挂载：分组预估
        List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupList = resourcePackageRepository.getSaleGroupList(context, campaignGroupOrderViewDTO.getSaleGroupIds(), new ResourcePackageQueryOption());
        BizCampaignGroupProcessOrderWorkflowParam processWorkflowParam = BizCampaignGroupProcessOrderWorkflowParam.builder()
                .campaignGroupViewDTO(campaignGroup)
                .resourcePackageSaleGroupList(resourcePackageSaleGroupList)
                .campaignList(campaignViewDTOList).build();
        BusinessAbilityRouteContext businessAbilityRouteContext = BusinessAbilityRouteContext.builder().specifiedBusinessAbilityCodes(Lists.newArrayList(MultiTargetDeliverBusinessAbility.ABILITY_CODE)).build();
        invokeAll(ICampaignGroupOrderBusinessAbilityPoint.class, businessAbilityRouteContext,
                callBack -> callBack.invokeForCampaignGroupOrder(context, campaignGroupOrderViewDTO,processWorkflowParam.getCampaignGroupViewDTO(), processWorkflowParam.getCampaignList(), processWorkflowParam.getResourcePackageSaleGroupList(), businessAbilityRouteContext));
        CampaignGroupViewDTO mainCampaignGroup = null;
        try {
            // 2. 子订单下单
            executeOrderForCartItemSolution(context, campaignGroupOrderViewDTO, processWorkflowParam);
            // 3. 主订单下单
            mainCampaignGroup = campaignGroupRepository.getCampaignGroup(context, campaignGroup.getParentId());
            ServiceContext mainContext = ServiceContextUtil.buildServiceContextForSceneId(mainCampaignGroup.getMemberId(), mainCampaignGroup.getSceneId());
            BizCampaignGroupProcessOrderWorkflowParam mainProcessWorkflowParam = BizCampaignGroupProcessOrderWorkflowParam.builder()
                    .campaignGroupViewDTO(mainCampaignGroup)
                    .subCampaignGroupList(Lists.newArrayList(campaignGroup))
                    .resourcePackageSaleGroupList(resourcePackageSaleGroupList)
                    .campaignList(campaignViewDTOList).build();
            executeOrderForCartItemSolution(mainContext, campaignGroupOrderViewDTO, mainProcessWorkflowParam);
            // 4. 同步生成合同并更新合同信息
            createContractForCartItemSolution(mainContext, mainCampaignGroup, campaignGroup);
        } catch (Exception e) {
            // rollback
            if (BrandCampaignGroupStatusEnum.ORDER_ING.getCode().equals(campaignGroup.getStatus())) {
                ServiceContext subContext = ServiceContextUtil.buildServiceContextForSceneId(campaignGroup.getMemberId(), campaignGroup.getSceneId());
                campaignGroupStatusUpdateAbility.handle(subContext, CampaignGroupStatusUpdateAbilityParam.builder()
                        .abilityTarget(campaignGroup).targetStatus(BrandCampaignGroupStatusEnum.DRAFT.getCode()).build());
            }
            if (mainCampaignGroup != null && BrandCampaignGroupStatusEnum.ORDER_ING.getCode().equals(mainCampaignGroup.getStatus())) {
                ServiceContext mainContext = ServiceContextUtil.buildServiceContextForSceneId(mainCampaignGroup.getMemberId(), mainCampaignGroup.getSceneId());
                campaignGroupStatusUpdateAbility.handle(mainContext, CampaignGroupStatusUpdateAbilityParam.builder()
                        .abilityTarget(mainCampaignGroup).targetStatus(BrandCampaignGroupStatusEnum.EDITED.getCode()).build());
            }
            RogerLogger.error("极简自助下单时发生错误, campaignGroupOrderViewDTO : {}, 错误详情 {}", JSONObject.toJSONString(campaignGroupOrderViewDTO), e);
            throw e;
        }

        // 5. 后置处理
        ServiceContextUtil.buildServiceContextSession(context);
        afterCartItemSolutionCampaignGroupOrder(context, campaignGroup, mainCampaignGroup);
    }

    private void afterCartItemSolutionCampaignGroupOrder(ServiceContext context, CampaignGroupViewDTO subCampaignGroup, CampaignGroupViewDTO mainCampaignGroup) {
        // 发起采购
        addPurchaseOrder(context, subCampaignGroup);
        // 发送子合同生成消息
        campaignGroupMessageAsyncSendAbility.handle(context, CampaignGroupMessageAsyncSendAbilityParam.builder()
                .abilityTarget(mainCampaignGroup).domainEvent(CampaignGroupEventEnum.SUB_CONTRACT_GENERATE.name()).build());
    }

    private void createContractForCartItemSolution(ServiceContext mainContext, CampaignGroupViewDTO mainCampaignGroup, CampaignGroupViewDTO campaignGroup) {
        // 创建合同
        Long contractId = salesContractRepository.createSelfContract(mainContext, mainCampaignGroup);

        // 更新合同信息（复用）
        BizCampaignGroupSalesNoticeWorkflowParam noticeWorkflowParam = new BizCampaignGroupSalesNoticeWorkflowParam();
        noticeWorkflowParam.setCampaignGroupViewDTO(mainCampaignGroup);
        noticeWorkflowParam.setSubCampaignGroupList(Lists.newArrayList(campaignGroup));
        SalesBriefViewDTO salesBriefViewDTO = new SalesBriefViewDTO();
        salesBriefViewDTO.setContractId(contractId);
        noticeWorkflowParam.setSalesBriefViewDTO(salesBriefViewDTO);

        updateCampaignGroupContractInfo(mainContext, mainCampaignGroup, noticeWorkflowParam);
    }

    public void executeOrderForCartItemSolution(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderViewDTO, BizCampaignGroupProcessOrderWorkflowParam processWorkflowParam) {
        CampaignGroupViewDTO campaignGroup = processWorkflowParam.getCampaignGroupViewDTO();
        // 下单初始化
        bizCampaignGroupCommandWorkflowExt.beforeOrder(context, campaignGroupOrderViewDTO, processWorkflowParam);
        // 先进行一次更新
        campaignGroupUpdateAbility.handle(context, CampaignGroupUpdateAbilityParam.builder().abilityTarget(campaignGroup).build());
        // 更新订单状态
        campaignGroupStatusUpdateAbility.handle(context, CampaignGroupStatusUpdateAbilityParam.builder()
                .abilityTarget(campaignGroup).targetStatus(BrandCampaignGroupStatusEnum.ORDER_ING.getCode()).build());
    }

    public void cancelSelfServiceCampaignGroupWarning(ServiceContext context, CampaignGroupCancelCommandViewDTO cancelViewDTO) {
        AssertUtil.notNull(cancelViewDTO.getId(), "订单ID不能为空");
        CampaignGroupViewDTO campaignGroup = campaignGroupRepository.getCampaignGroup(context, cancelViewDTO.getId());
        AssertUtil.notNull(campaignGroup, "订单不存在");
        if (!BrandCampaignGroupTypeEnum.SELF.getCode().equals(campaignGroup.getType())
                && !BrandCampaignGroupLevelEnum.LEVEL_TWO.getCode().equals(campaignGroup.getCampaignGroupLevel())) {
            return;
        }
        Date autoCancelExpireTime = campaignGroupCalAutoCancelExpireTimeAbility.handle(context, CampaignGroupCalAutoCancelExpireTimeAbilityParam.builder().abilityTarget(campaignGroup).build());
        if (Objects.isNull(autoCancelExpireTime)) {
            return;
        }
        Date autoCancelExpireDate = BrandDateUtil.getMinDate(autoCancelExpireTime);
        Date beforeOneDayOfAutoCancelExpireDate = BrandDateUtil.getPlusDate(autoCancelExpireDate, -1);
        if (new Date().after(beforeOneDayOfAutoCancelExpireDate)) {
            campaignGroupCancelWarningSendNoticeAbility.handle(context, CampaignGroupNoticeAbilityParam.builder().abilityTarget(campaignGroup).autoCancelExpireDate(autoCancelExpireTime).build());
        }
    }

    /**
     * 自助订单撤单
     *
     * @param context
     * @param cancelViewDTO
     */
    public void cancelSelfServiceCampaignGroup(ServiceContext context, CampaignGroupCancelCommandViewDTO cancelViewDTO, CampaignGroupViewDTO campaignGroup) {
        // 1、校验订单
        campaignGroupValidateForCancelAbility.handle(context, CampaignGroupValidateForCancelAbilityParam.builder().abilityTarget(campaignGroup).cancelViewDTO(cancelViewDTO).build());
        // 2、初始化
        campaignGroupInitForCancelAbility.handle(context, CampaignGroupInitForCancelAbilityParam.builder().abilityTarget(campaignGroup.getCampaignGroupCancelViewDTO()).cancelViewDTO(cancelViewDTO).build());
        // 3、状态迁移
        transitCampaignGroup(context, campaignGroup, CampaignGroupEventEnum.CANCEL);
        // 4、后置处理
        afterCancelSelfServiceCampaignGroup(context, campaignGroup, cancelViewDTO);
    }

    private void afterCancelSelfServiceCampaignGroup(ServiceContext context, CampaignGroupViewDTO campaignGroup, CampaignGroupCancelCommandViewDTO cancelViewDTO) {
        if (BrandCampaignGroupCancelModeEnum.AUTO.getCode().equals(cancelViewDTO.getOperateMode())) {
            campaignGroupMessageAsyncSendAbility.handle(context, CampaignGroupMessageAsyncSendAbilityParam.builder()
                    .abilityTarget(campaignGroup).domainEvent(CampaignGroupEventEnum.CANCEL_NOTICE_MSG.name()).build());
        }
    }

    @SwitchContext
    public void deleteSelfServiceCampaignGroup(ServiceContext serviceContext, Long campaignGroupId) {
        CampaignGroupViewDTO subCampaignGroup = campaignGroupRepository.getCampaignGroup(serviceContext, campaignGroupId);
        if (subCampaignGroup == null || BrandCampaignGroupStatusEnum.DELETED.getCode().equals(subCampaignGroup.getStatus())) {
            return;
        }

        // 1、删除子订单
        campaignGroupStatusUpdateAbility.handle(serviceContext, CampaignGroupStatusUpdateAbilityParam.builder()
                .abilityTarget(subCampaignGroup).targetStatus(BrandCampaignGroupStatusEnum.DELETED.getCode()).build());

        // 2、删除主订单
        CampaignGroupViewDTO mainCampaignGroup = campaignGroupRepository.getCampaignGroup(serviceContext, subCampaignGroup.getParentId());
        ServiceContext mainContext = ServiceContextUtil.buildServiceContextForSceneId(mainCampaignGroup.getMemberId(), mainCampaignGroup.getSceneId());
        campaignGroupStatusUpdateAbility.handle(mainContext, CampaignGroupStatusUpdateAbilityParam.builder()
                .abilityTarget(mainCampaignGroup).targetStatus(BrandCampaignGroupStatusEnum.DELETED.getCode()).build());

        // 3、通知售卖中心撤单
        campaignGroupMessageAsyncSendAbility.handle(mainContext, CampaignGroupMessageAsyncSendAbilityParam.builder()
                .abilityTarget(mainCampaignGroup).domainEvent(CampaignGroupEventEnum.CANCEL.name()).build());
    }

    /**
     * 子订单(主订单无此方法)
     * 申请修改
     *
     * @param context
     * @param campaignGroupOrderCommandViewDTO
     */
    public void applyModify(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO) {
        // 1. 构建参数
        BizCampaignGroupProcessOrderWorkflowParam processWorkflowParam = buildWorkflowParamForApplyModify(context, campaignGroupOrderCommandViewDTO);
        CampaignGroupViewDTO campaignGroupViewDTO = processWorkflowParam.getCampaignGroupViewDTO();
        // 2. 校验
        // 2-1. 校验是否有审核中的流程
        campaignGroupValidateForApplyModifyAbility.handle(context, CampaignGroupUnlockAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupUnlockViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO).build());
        // 2-2. 校验分组是否支持勾选
        Map<Long, SaleGroupSelectJudgeViewDTO> selectJudgeMap = saleGroupSelectJudgeForApplyModifyCampaignGroupAbility.handle(context, SaleGroupOrderAbilityParam.builder()
                .abilityTargets(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList()).campaignGroupViewDTO(campaignGroupViewDTO).build());
        List<Long> cannotApplyModifySaleGroupIds = campaignGroupOrderCommandViewDTO.getSaleGroupIds().stream()
                .filter(saleGroupId -> !selectJudgeMap.containsKey(saleGroupId) || BrandBoolEnum.BRAND_FALSE.getCode().equals(selectJudgeMap.get(saleGroupId).getCanSelect()))
                .collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(cannotApplyModifySaleGroupIds)) {
            List<String> saleGroupNameList = BizSaleGroupToolsHelper.getSaleGroupNames(processWorkflowParam.getResourcePackageSaleGroupList(), cannotApplyModifySaleGroupIds);
            throw new BrandOneBPException(PARAM_BREAK_RULE.of(String.format("以下分组(%s)不支持申请改单", StringUtils.join(saleGroupNameList, ", "))));
        }
        // 2-3. 校验分组
        saleGroupValidateForApplyModifyCampaignGroupAbility.handle(context, SaleGroupOrderAbilityParam.builder()
                .abilityTargets(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList())
                .saleGroupIds(campaignGroupOrderCommandViewDTO.getSaleGroupIds()).campaignGroupViewDTO(campaignGroupViewDTO)
                .resourcePackageSaleGroupList(processWorkflowParam.getResourcePackageSaleGroupList()).build());
        // 2-4. 校验主订单状态
        List<Long> salesSaleGroupIds = BizSaleGroupToolsHelper.getSalePlatformSaleGroupIds(campaignGroupViewDTO, campaignGroupOrderCommandViewDTO.getSaleGroupIds());
        if (CollectionUtils.isNotEmpty(salesSaleGroupIds)) {
            campaignGroupStatusValidateForApplyModifyAbility.handle(context, CampaignGroupAbilityParam.builder().abilityTarget(processWorkflowParam.getMainCampaignGroupViewDTO()).build());
        }

        // 3. 初始化
        campaignGroupUnlockInitForApplyModifyAbility.handle(context, CampaignGroupUnlockInitForApplyModifyAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupUnlockViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO)
                .campaignGroupOrderCommandViewDTO(campaignGroupOrderCommandViewDTO).build());

        // 4. 发起申请改单工作流
        campaignGroupStartApplyModifyProcessAbility.handle(context, CampaignGroupStartApplyModifyProcessAbilityParam.builder()
                .abilityTarget(campaignGroupOrderCommandViewDTO).campaignGroupViewDTO(campaignGroupViewDTO)
                .resourcePackageSaleGroupList(processWorkflowParam.getResourcePackageSaleGroupList()).build());
        // 5. 更新申请改单信息
        campaignGroupUnlockUpdateAbility.handle(context, CampaignGroupUnlockAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupUnlockViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO)
                .processStatusEnum(BrandCampaignGroupProcessStatusEnum.APPROVE_ING).build());
    }

    /**
     * 保存实结信息
     *
     * @param context
     * @param realSettleSaveViewDTO
     */
    public void saveRealSettleInfo(ServiceContext context, CampaignGroupRealSettleSaveViewDTO realSettleSaveViewDTO) {
        // 1. 构建参数
        BizCampaignGroupRealSettleWorkflowParam workflowParam = bizCampaignGroupCommandWorkflowExt.buildWorkflowParamForSaveRealSettleInfo(context, realSettleSaveViewDTO);
        if (workflowParam == null) {
            return;
        }
        // 2. 校验
        campaignGroupRealSettleValidateForSaveAbility.handle(context, CampaignGroupRealSettleValidateForSaveAbilityParam.builder().abilityTarget(realSettleSaveViewDTO).campaignGroupViewDTO(workflowParam.getCampaignGroupViewDTO()).build());
        // 3. 初始化
        campaignGroupRealSettleInitForSaveAbility.handle(context, CampaignGroupRealSettleInitForSaveAbilityParam.builder().abilityTarget(workflowParam.getCampaignGroupViewDTO()).subCampaignGroupList(workflowParam.getSubCampaignGroupList()).realSettleSaveViewDTO(realSettleSaveViewDTO).build());
        // 4. 发起实结审批工作流
        campaignGroupRealSettleApplyProcessInstanceForSaveAbility.handle(context, CampaignGroupRealSettleApplyProcessInstanceForSaveAbilityParam.builder().abilityTarget(workflowParam.getCampaignGroupViewDTO()).campaignGroupRealSettleSaveViewDTO(realSettleSaveViewDTO).resourcePackageProjectViewDTO(workflowParam.getResourcePackageProjectViewDTO()).build());
        // 5. 保存实结信息
        campaignGroupRealSettleSaveAbility.handle(context, CampaignGroupRealSettleSaveAbilityParam.builder().abilityTarget(workflowParam.getCampaignGroupViewDTO()).build());
        // 6. 后置处理
        afterRealSettleInfoSaved(context, realSettleSaveViewDTO, workflowParam.getCampaignGroupViewDTO());
    }


    /**
     * 入口：完成实结配置审核流程
     *
     * @param context
     * @param campaignGroupViewDTO
     * @param processStatusEnum
     */
    @EnableOpLog
    public void finishSubCampaignGroupRealSettleProcess(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, BrandCampaignGroupProcessStatusEnum processStatusEnum) {
        // 设置审核结果
        campaignGroupViewDTO.getCampaignGroupRealSettleViewDTO().setRealSettleProcessStatus(processStatusEnum.getCode());
        // 设置历史工作流审核状态
        List<ProcessRecordViewDTO> processRecordViewDTOList = campaignGroupViewDTO.getProcessRecordViewDTOList();
        if (CollectionUtils.isNotEmpty(processRecordViewDTOList)) {
            processRecordViewDTOList.forEach(processRecordViewDTO -> {
                if (processRecordViewDTO.getProcInstId().equals(campaignGroupViewDTO.getCampaignGroupRealSettleViewDTO().getRealSettleProcessId())) {
                    processRecordViewDTO.setStatus(processStatusEnum.getCode());
                    processRecordViewDTO.setFinishTime(new Date());
                }
            });
        }
        // 保存实结信息
        campaignGroupRealSettleSaveAbility.handle(context, CampaignGroupRealSettleSaveAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
        // 后置处理
        bizCampaignGroupCommandWorkflowExt.afterFinishSubCampaignGroupRealSettleProcess(context, campaignGroupViewDTO, processStatusEnum);
    }



    /**
     * 完成改单申请流程
     *
     * @param context
     * @param campaignGroupViewDTO
     * @param processStatusEnum
     */
    @EnableOpLog
    public void finishApplyModifyProcess(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, BrandCampaignGroupProcessStatusEnum processStatusEnum) {
        // 更新审核结果
        campaignGroupUnlockUpdateAbility.handle(context, CampaignGroupUnlockAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupUnlockViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO)
                .processStatusEnum(processStatusEnum).build());
        // 同意时，更新分组状态
        if (processStatusEnum != BrandCampaignGroupProcessStatusEnum.AGREED) {
            return;
        }
        // 构建改单参数
        CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO = new CampaignGroupOrderCommandViewDTO();
        campaignGroupOrderCommandViewDTO.setId(campaignGroupViewDTO.getId());
        campaignGroupOrderCommandViewDTO.setSaleGroupIds(campaignGroupViewDTO.getCampaignGroupUnlockViewDTO().getUnlockApplyInfoViewDTO().getSaleGroupIds());

        // 执行改单
        modifyCampaignGroup(context, campaignGroupOrderCommandViewDTO, campaignGroupViewDTO);
    }

    /**
     * 改单
     *
     * @param context
     * @param campaignGroupOrderCommandViewDTO
     * @param campaignGroupViewDTO
     */
    public void modifyCampaignGroup(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO, CampaignGroupViewDTO campaignGroupViewDTO) {
        // 1. 构建参数
        BizCampaignGroupProcessOrderWorkflowParam processWorkflowParam = bizCampaignGroupCommandWorkflowExt.buildParamForModify(context, campaignGroupOrderCommandViewDTO, campaignGroupViewDTO);
        // 2. 改单初始化
        campaignGroupSaleGroupInitForModifyAbility.handle(context, CampaignGroupSaleGroupInitForModifyAbilityParam.builder()
                .abilityTarget(campaignGroupOrderCommandViewDTO).campaignGroupViewDTO(campaignGroupViewDTO).subCampaignGroupList(processWorkflowParam.getSubCampaignGroupList()).build());

        // 3. 执行改单
        // 3-1. 改单前前先更新分组
        campaignGroupRepository.addOrUpdateSaleGroupPart(context, campaignGroupViewDTO.getId(), campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList());
        // 3-2. 改单售卖中心平台分组(SaleGroupSourceEnum.SALE_PLATFORM)
        campaignGroupViewDTO = modifySalePlatformSaleGroup(context, campaignGroupViewDTO, processWorkflowParam.getSalePlatformSaleGroupIds());
        // 3-3. 改单资源包平台分组(SaleGroupSourceEnum.PACKAGE_PLATFORM)
        modifyPackagePlatformSaleGroup(context, campaignGroupViewDTO, processWorkflowParam.getPackagePlatformSaleGroupIds());

        // 4. 改单后置处理
        bizCampaignGroupCommandWorkflowExt.afterModify(context, campaignGroupOrderCommandViewDTO, processWorkflowParam);
    }

    /**
     * 分组预估，算法保证，每次预估结果幂等。
     * @param context
     * @param saleGroupEstimateQueryViewDTO
     * @return
     */
    public List<CampaignGroupSaleGroupEstimateInfoViewDTO> estimate(ServiceContext context, CampaignGroupSaleGroupEstimateQueryViewDTO saleGroupEstimateQueryViewDTO) {
        BusinessAbilityRouteContext businessAbilityRouteContext = BusinessAbilityRouteContext.builder().specifiedBusinessAbilityCodes(Lists.newArrayList(MultiTargetDeliverBusinessAbility.ABILITY_CODE)).build();
        List<CampaignGroupSaleGroupEstimateInfoViewDTO> resultList = invoke(ICampaignGroupEstimateBusinessAbilityPoint.class, businessAbilityRouteContext,
                callBack -> callBack.invokeForCampaignGroupEstimate(context, saleGroupEstimateQueryViewDTO));

        return Optional.ofNullable(resultList).orElse(Lists.newArrayList());
    }

    /**
     * 订单资源确认
     *
     * @param serviceContext
     * @param campaignGroupViewDTO
     * @return
     */
    @EnableOpLog
    public void resourceConfirmed(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO) {
        // 1. 判断订单是否支持流转
        Boolean canTransit = campaignGroupJudgeForResourceConfirmAbility.handle(serviceContext, CampaignGroupTransitAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
        // 2. 执行资源确认事件
        if (canTransit) {
            this.transitCampaignGroup(serviceContext, campaignGroupViewDTO, CampaignGroupEventEnum.RESOURCE_CONFIRM, context -> {
                CampaignGroupStateContext transitContext = (CampaignGroupStateContext) context;
                transitContext.setIgnoreNotAcceptError(true);
            });
        }
    }

    /**
     * CampaignGroup状态迁移
     *
     * @param serviceContext
     * @param campaignGroupViewDTO
     * @param eventEnum
     * @return
     */
    public BrandCampaignGroupStatusEnum transitCampaignGroup(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO,
                                                             CampaignGroupEventEnum eventEnum) {
        return transitCampaignGroup(serviceContext, campaignGroupViewDTO, eventEnum, context -> {});
    }

    /**
     * CampaignGroup状态迁移
     *
     * @param serviceContext
     * @param campaignGroupViewDTO
     * @param eventEnum
     * @return
     */
    @EnableOpLog
    public BrandCampaignGroupStatusEnum transitCampaignGroup(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO,
                                                             CampaignGroupEventEnum eventEnum, BizCampaignGroupProcessMethodHook hook) {
        // 当前订单状态
        BrandCampaignGroupStatusEnum fromStatus = BrandCampaignGroupStatusEnum.getByCode(campaignGroupViewDTO.getStatus());
        // 构建流转上下文
        CampaignGroupStateContext transitContext = CampaignGroupStateContext.builder()
                .serviceContext(serviceContext)
                .campaignGroupViewDTO(campaignGroupViewDTO)
                .fromStatusEnum(fromStatus)
                .eventEnum(eventEnum)
                .campaignGroupLevel(campaignGroupViewDTO.getCampaignGroupLevel())
                .build();
        // 执行迁移
        BrandCampaignGroupStatusEnum targetStatus = executeTransitCampaignGroup(transitContext, hook);
        // 执行后处理
        if (targetStatus != null) {
            BizCampaignGroupTransitWorkflowParam transitWorkflowParam = BizCampaignGroupTransitWorkflowParam.builder()
                    .from(fromStatus)
                    .to(targetStatus)
                    .event(transitContext.getEventEnum())
                    .stateContext(transitContext)
                    .build();
            bizCampaignGroupCommandWorkflowExt.afterTransitCompleted(serviceContext, transitContext.getCampaignGroupViewDTO(), transitWorkflowParam);
        }

        return targetStatus;
    }

    /**
     * 主+子订单
     *
     * 执行CampaignGroup状态迁移
     *
     * @param transitContext
     * @param hook
     * @return
     */
    public BrandCampaignGroupStatusEnum executeTransitCampaignGroup(CampaignGroupStateContext transitContext, BizCampaignGroupProcessMethodHook hook) {
        CampaignGroupViewDTO campaignGroupViewDTO = transitContext.getCampaignGroupViewDTO();
        CampaignGroupEventEnum eventEnum = transitContext.getEventEnum();
        BrandCampaignGroupStatusEnum fromStatusEnum = transitContext.getFromStatusEnum();
        Integer campaignGroupLevel = transitContext.getCampaignGroupLevel();

        // 获取状态机
        BrandStateMachine<BrandCampaignGroupStatusEnum, CampaignGroupEventEnum, CampaignGroupStateContext> stateMachine = BizCampaignGroupProcessFactory.getCampaignGroupStateMachine();
        // 执行前：hook方法
        hook.beforeFire(transitContext);
        // 校验是否支持流转
        boolean canAccept = stateMachine.canAccept(fromStatusEnum, eventEnum, transitContext);
        // 不throw报错时，直接返回
        if (!canAccept && transitContext.isIgnoreNotAcceptError()) {
            RogerLogger.info("订单{} 层级{} 当前状态({})不支持({})操作", campaignGroupViewDTO.getId(), campaignGroupLevel, fromStatusEnum.getDesc(), eventEnum.getDesc());
            return null;
        }
        AssertUtil.assertTrue(canAccept, BrandOneBPBaseErrorCode.BIZ_BREAK_RULE_ERROR,
                String.format("订单状态(%s)不支持(%s)操作", fromStatusEnum.getDesc(), eventEnum.getDesc()));
        // 执行状态迁移
        BrandCampaignGroupStatusEnum targetStatus = stateMachine.fireEvent(fromStatusEnum, eventEnum, transitContext);
        RogerLogger.info("campaignGroup {} level {} from {} to {} event {} with stateContext {} executed",
                campaignGroupViewDTO.getId(), campaignGroupLevel, fromStatusEnum, targetStatus, eventEnum, JSONObject.toJSONString(transitContext));
        if (fromStatusEnum != targetStatus) {
            // 更新状态
            campaignGroupStatusUpdateAbility.handle(transitContext.getServiceContext(), CampaignGroupStatusUpdateAbilityParam.builder()
                    .abilityTarget(transitContext.getCampaignGroupViewDTO()).targetStatus(targetStatus.getCode()).build());
        }
        return targetStatus;
    }

    /**
     * 处理销售订单合同事件
     *
     * @param context
     * @param noticeSalesBriefViewDTO
     */
    public void handleContractEvent(ServiceContext context, SalesBriefViewDTO noticeSalesBriefViewDTO) {
        if (!CampaignGroupConstant.validContractStatusList.contains(noticeSalesBriefViewDTO.getContractStatus())) {
            return;
        }
        BizCampaignGroupSalesNoticeWorkflowParam workflowParam = buildSalesNoticeWorkflowParam(context, noticeSalesBriefViewDTO);
        CampaignGroupViewDTO mainCampaignGroup = workflowParam.getCampaignGroupViewDTO();
        if (mainCampaignGroup == null) {
            RogerLogger.info("处理售卖合同消息：未查询到对应的订单： stateContext= {}，noticeSalesBriefViewDTO = {}", JSONObject.toJSONString(context), JSONObject.toJSONString(noticeSalesBriefViewDTO));
            return;
        }
        // 1. 更新订单合同信息
        updateCampaignGroupContractInfo(context, mainCampaignGroup, workflowParam);
        // 2. 更新订单分组绑定的子合同ID
        bindCampaignGroupSubContractIds(context, mainCampaignGroup, workflowParam);
    }

    public void bindCampaignGroupSubContractIds(ServiceContext context, CampaignGroupViewDTO mainCampaignGroup) {
        BizCampaignGroupSalesNoticeWorkflowParam workflowParam = new BizCampaignGroupSalesNoticeWorkflowParam();
        workflowParam.setCampaignGroupViewDTO(mainCampaignGroup);
        // 查询Brief
        SalesBriefViewDTO brief = salesBriefRepository.getBrief(mainCampaignGroup.getCampaignGroupSaleViewDTO().getBriefId());
        workflowParam.setSalesBriefViewDTO(brief);
        // 子订单
        List<CampaignGroupViewDTO> subCampaignGroupList = campaignGroupRepository.findSubCampaignGroupList(context, mainCampaignGroup.getId());
        workflowParam.setSubCampaignGroupList(subCampaignGroupList);

        // 订单绑定子合同ID
        bindCampaignGroupSubContractIds(context, mainCampaignGroup, workflowParam);
    }

    private boolean validSubContractIds(List<CampaignGroupSubContractViewDTO> subContractViewDTOList) {
        if (CollectionUtils.isEmpty(subContractViewDTOList)) {
            return false;
        }
        return subContractViewDTOList.stream()
                .filter(t -> t.getSubContractId() == null || t.getSubContractId() == 0L)
                .count() == 0;
    }

    /**
     * 更新合同信息
     *
     * @param mainContext
     * @param mainCampaignGroupViewDTO
     * @param workflowParam
     */
    public void updateCampaignGroupContractInfo(ServiceContext mainContext, CampaignGroupViewDTO mainCampaignGroupViewDTO, BizCampaignGroupSalesNoticeWorkflowParam workflowParam) {
        // 1. 更新主合同
        campaignGroupContractUpdateForNoticeBriefEventAbility.handle(mainContext, CampaignGroupContractUpdateForNoticeBriefEventAbilityParam.builder()
                .abilityTarget(mainCampaignGroupViewDTO.getCampaignGroupContractViewDTO()).campaignGroupViewDTO(mainCampaignGroupViewDTO)
                .salesBriefViewDTO(workflowParam.getSalesBriefViewDTO()).build());
        // 2. 更新子订单合同信息
        for (CampaignGroupViewDTO subCampaignGroup : workflowParam.getSubCampaignGroupList()) {
            ServiceContext subContext = ServiceContextUtil.buildServiceContextForSceneId(subCampaignGroup.getMemberId(), subCampaignGroup.getSceneId());
            Integer beforeContractSignStatus = subCampaignGroup.getCampaignGroupContractViewDTO().getContractSignStatus();
            campaignGroupContractUpdateForNoticeBriefEventAbility.handle(subContext, CampaignGroupContractUpdateForNoticeBriefEventAbilityParam.builder()
                    .abilityTarget(subCampaignGroup.getCampaignGroupContractViewDTO()).campaignGroupViewDTO(subCampaignGroup)
                    .mainCampaignGroupContractViewDTO(mainCampaignGroupViewDTO.getCampaignGroupContractViewDTO()).build());
            // 发送通知邮件
            sendSubCampaignGroupContractMessageNotice(subContext, subCampaignGroup, beforeContractSignStatus);
        }
        // 重新加载主合同context
        ServiceContextUtil.buildServiceContextSession(mainContext);
    }

    /**
     * 处理销售订单brief事件
     *
     * @param context
     * @param salesBriefViewDTO
     */
    public void handleBriefEvent(ServiceContext context, SalesBriefViewDTO salesBriefViewDTO) {
        if (!CampaignGroupBriefStateMappingEnum.containsBriefStatus(salesBriefViewDTO.getStatus())) {
            return;
        }
        BizCampaignGroupSalesNoticeWorkflowParam workflowParam = buildSalesNoticeWorkflowParam(context, salesBriefViewDTO);
        CampaignGroupViewDTO mainCampaignGroup = workflowParam.getCampaignGroupViewDTO();
        if (mainCampaignGroup == null) {
            RogerLogger.info("处理售卖合同消息：未查询到对应的订单： stateContext= {}，noticeSalesBriefViewDTO = {}", JSONObject.toJSONString(context), JSONObject.toJSONString(salesBriefViewDTO));
            return;
        }

        // 根据Brief状态变更迁移CampaignGroup状态
        CampaignGroupBriefStateMappingEnum stateMappingEnum = CampaignGroupBriefStateMappingEnum.targetByBriefEventAndStatus(salesBriefViewDTO.getEventCode(), salesBriefViewDTO.getStatus());
        if (stateMappingEnum == null) {
            return;
        }
        if (BizCampaignGroupToolsHelper.ignoreBriefEventForSelfService(mainCampaignGroup, stateMappingEnum.getCampaignGroupEvent())) {
            return;
        }
        // 进行状态迁移
        this.transitCampaignGroup(context, workflowParam.getCampaignGroupViewDTO(), stateMappingEnum.getCampaignGroupEvent(), stateContext -> {
            CampaignGroupStateContext transitContext = (CampaignGroupStateContext) stateContext;
            transitContext.setSubCampaignGroupViewDTOList(workflowParam.getSubCampaignGroupList());
        });
    }

    private BizCampaignGroupSalesNoticeWorkflowParam buildSalesNoticeWorkflowParam(ServiceContext context, SalesBriefViewDTO salesBriefViewDTO) {
        BizCampaignGroupSalesNoticeWorkflowParam workflowParam = new BizCampaignGroupSalesNoticeWorkflowParam();
        // 查询Brief
        SalesBriefViewDTO brief = salesBriefRepository.getBrief(salesBriefViewDTO.getBriefId());
        brief.setContractStatus(salesBriefViewDTO.getContractStatus());
        workflowParam.setSalesBriefViewDTO(brief);
        // 重新设置context
        ServiceContextUtil.reSetServiceContextMemberId(context, brief.getMemberId());
        // 查询CampaignGroup
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(context, brief.getOrderId());
        workflowParam.setCampaignGroupViewDTO(campaignGroupViewDTO);
        // 子订单
        List<CampaignGroupViewDTO> subCampaignGroupList = campaignGroupRepository.findSubCampaignGroupList(context, salesBriefViewDTO.getOrderId());
        workflowParam.setSubCampaignGroupList(subCampaignGroupList);

        return workflowParam;
    }

    private void sendSubCampaignGroupContractMessageNotice(ServiceContext subContext, CampaignGroupViewDTO subCampaignGroup, Integer beforeContractSignStatus) {
        beforeContractSignStatus = beforeContractSignStatus != null ? beforeContractSignStatus : BrandCampaignGroupContractSignStatusEnum.NON_SIGN.getCode();
        if (BrandCampaignGroupContractSignStatusEnum.NON_SIGN.getCode().equals(beforeContractSignStatus)
                && BrandCampaignGroupContractSignStatusEnum.WAIT_SIGN.getCode().equals(subCampaignGroup.getCampaignGroupContractViewDTO().getContractSignStatus())) {
            campaignGroupMessageAsyncSendAbility.handle(subContext, CampaignGroupMessageAsyncSendAbilityParam.builder()
                    .abilityTarget(subCampaignGroup).domainEvent(CampaignGroupEventEnum.WAIT_SIGN_NOTICE_MSG.name()).build());
        } else if (BrandCampaignGroupContractSignStatusEnum.WAIT_SIGN.getCode().equals(beforeContractSignStatus)
                && BrandCampaignGroupContractSignStatusEnum.SIGNED.getCode().equals(subCampaignGroup.getCampaignGroupContractViewDTO().getContractSignStatus())) {
            campaignGroupMessageAsyncSendAbility.handle(subContext, CampaignGroupMessageAsyncSendAbilityParam.builder()
                    .abilityTarget(subCampaignGroup).domainEvent(CampaignGroupEventEnum.WAIT_PAYMENT_NOTICE_MSG.name()).build());
        }
    }

    /**
     * 绑定子合同
     *
     * @param mainContext
     * @param mainCampaignGroupViewDTO
     * @param workflowParam
     */
    public void bindCampaignGroupSubContractIds(ServiceContext mainContext, CampaignGroupViewDTO mainCampaignGroupViewDTO, BizCampaignGroupSalesNoticeWorkflowParam workflowParam) {
        SalesBriefViewDTO brief = workflowParam.getSalesBriefViewDTO();
        if (!validSubContractIds(brief.getSubContractViewDTOList())) {
            return;
        }
        // 1. 主订单分组 - 绑定子合同
        saleGroupSubContractBindAbility.handle(mainContext, SaleGroupSubContractBindAbilityParam.builder()
                .abilityTargets(mainCampaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList())
                .campaignGroupViewDTO(mainCampaignGroupViewDTO).targetSaleGroupIds(Lists.newArrayList())
                .subContractViewDTOList(brief.getSubContractViewDTOList()).build());
        for (CampaignGroupViewDTO subCampaignGroup : workflowParam.getSubCampaignGroupList()) {
            // 执行子订单绑定子合同ID
            ServiceContext subContext = ServiceContextUtil.buildServiceContextForSceneId(subCampaignGroup.getMemberId(), subCampaignGroup.getSceneId());
            Set<Long> updateSubContractSaleGroupIdSet = saleGroupSubContractBindAbility.handle(subContext, SaleGroupSubContractBindAbilityParam.builder()
                    .abilityTargets(subCampaignGroup.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList())
                    .campaignGroupViewDTO(subCampaignGroup).targetSaleGroupIds(Lists.newArrayList())
                    .subContractViewDTOList(brief.getSubContractViewDTOList()).build());
            if (CollectionUtils.isEmpty(updateSubContractSaleGroupIdSet)) {
                continue;
            }
            // 发送同步领域事件（通知计划绑定子合同id）
            CampaignGroupStateContext stateContext = CampaignGroupStateContext.builder()
                    .serviceContext(subContext).campaignGroupViewDTO(subCampaignGroup).saleGroupIds(Lists.newArrayList(updateSubContractSaleGroupIdSet))
                    .eventEnum(CampaignGroupEventEnum.SUB_CONTRACT_GENERATE).build();
            messageSyncSendAbility.handle(subContext, MessageSyncSendAbilityParam.builder().abilityTarget(CampaignGroupStatusTransitEvent.of(stateContext)).build());
        }
        // 重新加载主合同context
        ServiceContextUtil.buildServiceContextSession(mainContext);

    }


    /**
     * 处理资源包变动消息
     *
     * @param serviceContext
     * @param noticeTemplateViewDTO
     */
    public void handleCustomerTemplateSaleGroupNotice(ServiceContext serviceContext, ResourcePackageNoticeTemplateViewDTO noticeTemplateViewDTO) {
        // 1. 查询处理需要的参数
        BizSaleGroupNoticeWorkflowParam workflowParam = buildSaleGroupNoticeWorkflowParam(serviceContext, noticeTemplateViewDTO);
        if (CollectionUtils.isEmpty(workflowParam.getMainCampaignGroupViewList())) {
            return;
        }
        // 2. 商业能力挂载，对更新的分组进行成效预估更新
        List<Long> updateSaleGroupIds = noticeTemplateViewDTO.getSaleGroupList().stream().filter(item->item.getOperateType().equals(SaleGroupOperateTypeEnum.UPDATE.getValue())).map(ResourcePackageNoticeSaleGroupViewDTO::getId).distinct().collect(Collectors.toList());
        List<ResourcePackageSaleGroupViewDTO> updateSaleGroupList = workflowParam.getResourcePackageSaleGroupList().stream().filter(item->updateSaleGroupIds.contains(item.getId())).collect(Collectors.toList());
        AbilityInvoker.invokeAll(ISaleGroupSyncBusinessAbilityPoint.class,
                BusinessAbilityRouteContext.builder().specifiedBusinessAbilityCodes(Lists.newArrayList(MultiTargetDeliverBusinessAbility.ABILITY_CODE, ThirdMonitorSupportBusinessAbility.ABILITY_CODE)).build(),
                callback -> callback.invokeForSyncSaleGroup(serviceContext, updateSaleGroupList));
        // 更新完成后,需要重新查询一次(所有涉及到的主订单)
        workflowParam.setMainCampaignGroupViewList(findMainCampaignGroupListByTemplateInfo(workflowParam.getResourcePackageTemplateViewDTO(), noticeTemplateViewDTO.getSaleGroupList()));

        /// 3. 更新主订单和子订单上的资源包平台分组信息
        Map<Long, ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupMap = workflowParam.getResourcePackageSaleGroupList().stream().collect(Collectors.toMap(ResourcePackageSaleGroupViewDTO::getId, Function.identity()));
        // 过滤出被删除的分组或者是从打包平台（及百灵）发起的补量配送分组, 同时过滤「和传入的分组能匹配」的主订单
        List<ResourcePackageNoticeSaleGroupViewDTO> filterNoticeSaleGroupViewList = noticeTemplateViewDTO.getSaleGroupList().stream()
                .filter(t -> SaleGroupOperateTypeEnum.DELETE.getValue().equals(t.getOperateType()) // 删除时，无法查询
                        || resourcePackageSaleGroupMap.containsKey(t.getId()) && BrandSaleGroupSourceEnum.PACKAGE_PLATFORM.getCode().equals(resourcePackageSaleGroupMap.get(t.getId()).getSource()))
                .collect(Collectors.toList());
        if (CollectionUtils.isEmpty(filterNoticeSaleGroupViewList)) {
            return;
        }
        // 根据符合更新条件的分组重新过滤主订单
        List<CampaignGroupViewDTO> filterCampaignGroupViewList = filterBoundCampaignGroupListBySaleGroupInfo(workflowParam.getMainCampaignGroupViewList(), filterNoticeSaleGroupViewList);
        if (CollectionUtils.isEmpty(filterCampaignGroupViewList)) {
            return;
        }
        for (CampaignGroupViewDTO mainCampaignGroupViewDTO : filterCampaignGroupViewList) {
            ServiceContext mainServiceContext = ServiceContextUtil.buildServiceContextForSceneId(mainCampaignGroupViewDTO.getMemberId(), mainCampaignGroupViewDTO.getSceneId());
            // 更新主订单
            doUpdateMainCampaignGroupPackagePlatformSaleGroups(mainServiceContext, mainCampaignGroupViewDTO, filterNoticeSaleGroupViewList, resourcePackageSaleGroupMap);
            // 更新子订单
            doUpdateSubCampaignGroupPackagePlatformSaleGroups(mainServiceContext, mainCampaignGroupViewDTO);
        }

        // 5. 后置逻,发送领域消息
        noticeSubCampaignGroupSaleGroupUpdated(workflowParam.getMainCampaignGroupViewList());
    }

    /**
     * 删除订单（逻辑删）
     * @param serviceContext
     * @param id
     */
    public void deleteCampaignGroup(ServiceContext serviceContext, Long id) {
        //1. 构建所需参数
        BizCampaignGroupWorkflowParam bizCampaignGroupWorkflowParam = buildParamForDelete(serviceContext, id);
        CampaignGroupViewDTO campaignGroupViewDTO = bizCampaignGroupWorkflowParam.getDbCampaignGroupViewDTO();
        List<CampaignViewDTO> campaignViewDTOList = bizCampaignGroupWorkflowParam.getCampaignList();
        List<CampaignGroupViewDTO> subCampaignGroupList = Optional.ofNullable(bizCampaignGroupWorkflowParam.getDbSubCampaignGroupList()).orElse(Lists.newArrayList());
        //2. 删除校验
        // 校验订单
        campaignGroupValidateForDeleteAbility.handle(serviceContext, CampaignGroupDeleteAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
        // 校验计划
        Map<Long, List<CampaignViewDTO>> campaignMap = campaignViewDTOList.stream()
                .filter(t -> Objects.nonNull(t.getCampaignGroupId()))
                .collect(Collectors.groupingBy(CampaignViewDTO::getCampaignGroupId));
        if (BizCampaignGroupToolsHelper.isMainCampaignGroup(campaignGroupViewDTO)) {
            for (CampaignGroupViewDTO subCampaignGroup : subCampaignGroupList) {
                List<CampaignViewDTO> subCampaignGroupCampaignList = campaignMap.get(subCampaignGroup.getId());
                if (CollectionUtils.isEmpty(subCampaignGroupCampaignList)) {
                    continue;
                }
                ServiceContext subContext = ServiceContextUtil.buildServiceContextForSceneId(subCampaignGroup.getMemberId(), subCampaignGroup.getSceneId());
                // 校验计划
                campaignValidateForDeleteCampaignGroupAbility.handle(subContext, CampaignValidateForDeleteCampaignGroupAbilityParam.builder()
                        .abilityTargets(subCampaignGroupCampaignList).build());
            }
        } else {
            campaignValidateForDeleteCampaignGroupAbility.handle(serviceContext, CampaignValidateForDeleteCampaignGroupAbilityParam.builder()
                    .abilityTargets(campaignViewDTOList).build());
        }

        // 执行删除
        ServiceContextUtil.buildServiceContextSession(serviceContext);
        // 删除自身
        campaignGroupStatusUpdateAbility.handle(serviceContext, CampaignGroupStatusUpdateAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO).targetStatus(BrandCampaignGroupStatusEnum.DELETED.getCode()).build());
        // 主订单时，需要删除子订单
        if (BizCampaignGroupToolsHelper.isMainCampaignGroup(campaignGroupViewDTO)) {
            for (CampaignGroupViewDTO subCampaignGroup : subCampaignGroupList) {
                List<CampaignViewDTO> subCampaignGroupCampaignList = campaignMap.get(subCampaignGroup.getId());
                if (CollectionUtils.isEmpty(subCampaignGroupCampaignList)) {
                    continue;
                }
                ServiceContext subContext = ServiceContextUtil.buildServiceContextForSceneId(subCampaignGroup.getMemberId(), subCampaignGroup.getSceneId());
                campaignGroupStatusUpdateAbility.handle(subContext, CampaignGroupStatusUpdateAbilityParam.builder()
                        .abilityTarget(subCampaignGroup).targetStatus(BrandCampaignGroupStatusEnum.DELETED.getCode()).build());
                // 删除计划和单元
                deleteCampaignAndAdGroup(subContext, subCampaignGroupCampaignList);
            }
        } else {
            // 删除计划和单元
            deleteCampaignAndAdGroup(serviceContext, campaignViewDTOList);
        }
    }

    private void deleteCampaignAndAdGroup(ServiceContext context, List<CampaignViewDTO> campaignList) {
        if (CollectionUtils.isEmpty(campaignList)) {
            return;
        }
        campaignDeleteAbility.handle(context, CampaignBatchAbilityParam.builder().abilityTargets(campaignList).build());
        List<Long> tempDeleteCampaignIdList = campaignList.stream().map(CampaignViewDTO::getId).collect(Collectors.toList());
        adgroupBatchDeleteAbility.handle(context, AdgroupBatchDeleteAbilityParam.builder().abilityTargets(tempDeleteCampaignIdList).build());
    }

    private BizCampaignGroupWorkflowParam buildParamForDelete(ServiceContext serviceContext, Long id) {
        BizCampaignGroupWorkflowParam bizCampaignGroupWorkflowParam = new BizCampaignGroupWorkflowParam();
        AssertUtil.assertTrue(id != null, "订单ID不能为空");
        //订单
        CampaignGroupViewDTO dbCampaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(serviceContext, id);
        AssertUtil.assertTrue(dbCampaignGroupViewDTO != null, "订单信息不能为空");
        bizCampaignGroupWorkflowParam.setDbCampaignGroupViewDTO(dbCampaignGroupViewDTO);
        //查询子订单
        if (BizCampaignGroupToolsHelper.isMainCampaignGroup(dbCampaignGroupViewDTO)) {
            List<CampaignGroupViewDTO> subCampaignGroupList = campaignGroupRepository.findSubCampaignGroupList(serviceContext, dbCampaignGroupViewDTO.getId());
            bizCampaignGroupWorkflowParam.setDbSubCampaignGroupList(subCampaignGroupList);
        }

        //计划
        CampaignQueryViewDTO campaignQueryViewDTO = new CampaignQueryViewDTO();
        if (BizCampaignGroupToolsHelper.isMainCampaignGroup(dbCampaignGroupViewDTO)) {
            campaignQueryViewDTO.setMainCampaignGroupId(dbCampaignGroupViewDTO.getId());
        } else {
            campaignQueryViewDTO.setCampaignGroupId(dbCampaignGroupViewDTO.getId());
        }
        List<CampaignViewDTO> campaignViewDTOList = campaignRepository.queryCampaignList(serviceContext, campaignQueryViewDTO);
        bizCampaignGroupWorkflowParam.setCampaignList(campaignViewDTOList);
        RogerLogger.info("buildParamForDelete.bizCampaignGroupWorkflowParam: {}", JSON.toJSONString(bizCampaignGroupWorkflowParam));
        return bizCampaignGroupWorkflowParam;
    }

    public void noticeSubCampaignGroupSaleGroupUpdated(List<CampaignGroupViewDTO> mainCampaignGroupViewList) {
        for (CampaignGroupViewDTO mainCampaignGroup : mainCampaignGroupViewList) {
            ServiceContext mainServiceContext = ServiceContextUtil.buildServiceContextForSceneIdNoSession(mainCampaignGroup.getMemberId(), mainCampaignGroup.getSceneId());
            List<CampaignGroupViewDTO> subCampaignGroupList = campaignGroupRepository.findSubCampaignGroupList(mainServiceContext, mainCampaignGroup.getId());
            for (CampaignGroupViewDTO subCampaignGroup : subCampaignGroupList) {
                campaignGroupMessageAsyncSendAbility.handle(mainServiceContext, CampaignGroupMessageAsyncSendAbilityParam.builder()
                        .abilityTarget(subCampaignGroup).domainEvent(CampaignGroupEventEnum.UPDATE.name()).build());
            }
        }
    }

    public void doUpdateSubCampaignGroupPackagePlatformSaleGroups(ServiceContext mainServiceContext, CampaignGroupViewDTO mainCampaignGroup) {
        List<CampaignGroupViewDTO> subCampaignGroupList = campaignGroupRepository.findSubCampaignGroupList(mainServiceContext, mainCampaignGroup.getId());
        if (CollectionUtils.isEmpty(subCampaignGroupList)) {
            return;
        }
        Map<Integer, List<SaleGroupInfoViewDTO>> subCampaignGroupSaleGroupMap = splitSubCampaignGroupSaleGroups(mainCampaignGroup);
        for (CampaignGroupViewDTO subCampaignGroup : subCampaignGroupList) {
            ServiceContext subContext = ServiceContextUtil.buildServiceContextForSceneId(subCampaignGroup.getMemberId(), subCampaignGroup.getSceneId());
            List<SaleGroupInfoViewDTO> subSaleGroupList = subCampaignGroupSaleGroupMap.getOrDefault(subCampaignGroup.getSceneId(), Lists.newArrayList());
            // diff
            SaleGroupDiffResultViewDTO diffResultViewDTO = saleGroupDiffForNoticeSaleGroupAbility.handle(subContext, SaleGroupDiffAbilityParam.builder()
                    .abilityTargets(subSaleGroupList).dbSaleGroupInfoViewDTOList(subCampaignGroup.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList())
                    .campaignGroupViewDTO(subCampaignGroup).build());
            // 初始化
            initSubCampaignGroupPackagePlatformSaleGroupByDiffResult(subContext, subSaleGroupList, subCampaignGroup, diffResultViewDTO);
            // 更新分组信息
            doUpdatePackagePlatformSaleGroupByDiffResult(subContext, subCampaignGroup, subCampaignGroup.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList(), diffResultViewDTO);

            // 计算并更新盘量信息、补量状态和配送状态
            campaignGroupInquiryInfoUpdateAbility.handle(subContext, CampaignGroupInquiryInfoUpdateAbilityParam.builder().abilityTarget(subCampaignGroup.getCampaignGroupInquiryViewDTO()).campaignGroupViewDTO(subCampaignGroup).build());
            campaignGroupGiveStatusUpdateAbility.handle(subContext, CampaignGroupGiveStatusUpdateAbilityParam.builder().abilityTarget(subCampaignGroup).build());
            campaignGroupBoostStatusUpdateAbility.handle(subContext, CampaignGroupBoostStatusUpdateAbilityParam.builder().abilityTarget(subCampaignGroup).build());
        }
    }

    private void initSubCampaignGroupPackagePlatformSaleGroupByDiffResult(ServiceContext context, List<SaleGroupInfoViewDTO> addOrUpdateSaleGroupList, CampaignGroupViewDTO subCampaignGroupViewDTO, SaleGroupDiffResultViewDTO saleGroupDiffResultViewDTO) {
        List<SaleGroupInfoViewDTO> campaignGroupSaleGroupList = subCampaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList();
        // init：删除的客户分组
        if (CollectionUtils.isNotEmpty(saleGroupDiffResultViewDTO.getDeleteSaleGroupIds())) {
            saleGroupInitForDeleteAbility.handle(context, SaleGroupInitAbilityParam.builder()
                    .abilityTargets(campaignGroupSaleGroupList).operateSaleGroupIds(saleGroupDiffResultViewDTO.getDeleteSaleGroupIds()).build());
        }
        Map<Long, SaleGroupInfoViewDTO> addOrUpdateSaleGroupMap = addOrUpdateSaleGroupList.stream().collect(Collectors.toMap(SaleGroupInfoViewDTO::getSaleGroupId, t -> t, (v1, v2) -> v1));
        // init：新增的客户分组
        if (CollectionUtils.isNotEmpty(saleGroupDiffResultViewDTO.getAddSaleGroupIds())) {
            List<SaleGroupInfoViewDTO> addSaleGroupList = addOrUpdateSaleGroupList.stream()
                    .filter(saleGroupInfoViewDTO -> saleGroupDiffResultViewDTO.getAddSaleGroupIds().contains(saleGroupInfoViewDTO.getSaleGroupId()))
                    .peek(saleGroupInfoViewDTO -> {
                        saleGroupInfoViewDTO.setId(null);
                        saleGroupInfoViewDTO.setCampaignGroupId(subCampaignGroupViewDTO.getId());
                    }).collect(Collectors.toList());
            campaignGroupSaleGroupList.addAll(addSaleGroupList);
        }
        // init：更新的客户分组
        if (CollectionUtils.isNotEmpty(saleGroupDiffResultViewDTO.getUpdateSaleGroupIds())) {
            campaignGroupSaleGroupList.forEach(saleGroupInfoViewDTO -> {
                if (saleGroupDiffResultViewDTO.getUpdateSaleGroupIds().contains(saleGroupInfoViewDTO.getSaleGroupId())) {
                    saleGroupInfoViewDTO.setBudget(addOrUpdateSaleGroupMap.get(saleGroupInfoViewDTO.getSaleGroupId()).getBudget());
                }
            });
        }

        subCampaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().setSaleGroupInfoViewDTOList(campaignGroupSaleGroupList);
    }

    /**
     * 撤销改单
     * 仅主订单支持，暂不实现扩展点
     * @param from  1008. 改单配置
     * @param to    1005/1006/1007
     * @param event 撤销改单
     * @param stateContext
     */
    public void unlockRevertCampaignGroupForTransit(BrandCampaignGroupStatusEnum from, BrandCampaignGroupStatusEnum to,
                                                    CampaignGroupEventEnum event, CampaignGroupStateContext stateContext) {
        ServiceContext context = stateContext.getServiceContext();
        CampaignGroupViewDTO mainCampaignGroup = stateContext.getCampaignGroupViewDTO();
        // 1. 查询子订单
        List<CampaignGroupViewDTO> subCampaignGroupList = stateContext.getSubCampaignGroupViewDTOList();
        if (CollectionUtils.isEmpty(stateContext.getSubCampaignGroupViewDTOList())) {
            subCampaignGroupList = campaignGroupRepository.findSubCampaignGroupList(stateContext.getServiceContext(),
                    stateContext.getCampaignGroupViewDTO().getId());
        }
        // 校验是否支持撤销改单
        campaignGroupValidateForUnlockRevertAbility.handle(context, CampaignGroupUnlockRevertAbilityParam.builder()
                .abilityTarget(mainCampaignGroup).subCampaignGroupList(subCampaignGroupList).build());

        // 2. 汇总子订单分组、金额并更新
        campaignGroupUpdateForUnlockRevertAbility.handle(context, CampaignGroupUnlockRevertAbilityParam.builder()
                .abilityTarget(mainCampaignGroup).subCampaignGroupList(subCampaignGroupList).build());
    }

    /**
     * 子订单-处理合同上线
     *
     * @param from
     * @param to
     * @param event
     * @param context
     */
    public void onlineContract(BrandCampaignGroupStatusEnum from, BrandCampaignGroupStatusEnum to,
                               CampaignGroupEventEnum event, CampaignGroupStateContext context) {
        CampaignGroupViewDTO campaignGroupViewDTO = context.getCampaignGroupViewDTO();
        // 1. 设置合同首次上线时间
        campaignGroupContractUpdateForOnlineContractAbility.handle(context.getServiceContext(), CampaignGroupContractUpdateForTransitCampaignGroupAbilityParam.builder()
                        .abilityTarget(campaignGroupViewDTO.getCampaignGroupContractViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO).build());
    }

    /**
     * 实结通过
     *
     * @param from
     * @param to
     * @param event
     * @param context
     */
    public void agreeRealSettleProcessForTransit(BrandCampaignGroupStatusEnum from, BrandCampaignGroupStatusEnum to,
                                                 CampaignGroupEventEnum event, CampaignGroupStateContext context) {
        CampaignGroupViewDTO campaignGroupViewDTO = context.getCampaignGroupViewDTO();

        // 更新订单金额
        Long campaignGroupRealSettlePrice = campaignGroupViewDTO.getCampaignGroupRealSettleViewDTO().getRealSettleInfoViewDTOList()
            .stream().mapToLong(RealSettleInfoViewDTO::getRealSettlePrice).sum();
        campaignGroupViewDTO.getCampaignGroupRealSettleViewDTO().setOriginalCampaignGroupBudget(campaignGroupViewDTO.getBudget());
        campaignGroupViewDTO.setBudget(campaignGroupRealSettlePrice);
        // 更新实结审核状态
        campaignGroupViewDTO.getCampaignGroupRealSettleViewDTO().setRealSettleProcessStatus(BrandCampaignGroupProcessStatusEnum.AGREED.getCode());
        // 5. 保存实结信息
        campaignGroupRealSettleSaveAbility.handle(context.getServiceContext(), CampaignGroupRealSettleSaveAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
    }

    /**
     * 撤单
     * @param from
     * @param to    1013. 已撤单
     * @param event
     * @param context
     */
    public void cancelCampaignGroupForTransit(BrandCampaignGroupStatusEnum from, BrandCampaignGroupStatusEnum to,
                                    CampaignGroupEventEnum event, CampaignGroupStateContext context) {
        CampaignGroupViewDTO campaignGroupViewDTO = context.getCampaignGroupViewDTO();
        if (campaignGroupViewDTO.getCampaignGroupCancelViewDTO().getCancelMode() != null) {
            CampaignGroupViewDTO updateCampaignGroup = new CampaignGroupViewDTO();
            updateCampaignGroup.setCampaignGroupCancelViewDTO(new CampaignGroupCancelViewDTO());
            updateCampaignGroup.setId(campaignGroupViewDTO.getId());
            updateCampaignGroup.getCampaignGroupCancelViewDTO().setCancelMode(campaignGroupViewDTO.getCampaignGroupCancelViewDTO().getCancelMode());
            campaignGroupRepository.updateCampaignGroupPart(context.getServiceContext(), updateCampaignGroup);
        }
    }

    /**
     * 什么都不做，占位方法
     *
     * @param from
     * @param to
     * @param event
     * @param context
     */
    public void doNothing(BrandCampaignGroupStatusEnum from, BrandCampaignGroupStatusEnum to,
                          CampaignGroupEventEnum event, CampaignGroupStateContext context) {
    }

    /*******************新的方法，需要实现*************************/

    /**
     * 订单上线
     *
     * @param from
     * @param to
     * @param event
     * @param context
     */
    public void onlineCampaignGroupForTransit(BrandCampaignGroupStatusEnum from, BrandCampaignGroupStatusEnum to,
                                              CampaignGroupEventEnum event, CampaignGroupStateContext context) {
        CampaignGroupViewDTO campaignGroupViewDTO = context.getCampaignGroupViewDTO();
        // 1. 设置合同首次上线时间
        if (event == CampaignGroupEventEnum.CONTRACT_PAY) {
            this.onlineContract(from, to, event, context);
        }
        // 2. 上线分组
        List<Long> onlineSaleGroupIds = onlineSaleGroupList(context.getServiceContext(), campaignGroupViewDTO);
        // 后置处理，设置context发送同步event使用
        context.setSaleGroupIds(onlineSaleGroupIds);
    }

    private List<Long> onlineSaleGroupList(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO) {
        // 待上线的分组ID列表
        List<Long> waitOnlineSaleGroupIds = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream()
                .filter(t -> t.getSaleGroupStatus() == BrandCampaignGroupSaleOrderStatusEnum.ORDER_ING.getCode().intValue())
                .map(SaleGroupInfoViewDTO::getSaleGroupId)
                .collect(Collectors.toList());
        // 修改分组状态
        saleGroupStatusUpdateAbility.handle(serviceContext, SaleGroupStatusUpdateAbilityParam.builder().abilityTargets(waitOnlineSaleGroupIds)
                .campaignGroupViewDTO(campaignGroupViewDTO).saleGroupOrderStatusEnum(BrandCampaignGroupSaleOrderStatusEnum.ORDER_FINISH).build());
        campaignGroupGiveStatusUpdateAbility.handle(serviceContext, CampaignGroupGiveStatusUpdateAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
        campaignGroupBoostStatusUpdateAbility.handle(serviceContext, CampaignGroupBoostStatusUpdateAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());

        return waitOnlineSaleGroupIds;
    }

    /**
     * 修改订单
     *
     * @param from
     * @param to
     * @param event
     * @param stateContext
     */
    public void modifyCampaignGroupForTransit(BrandCampaignGroupStatusEnum from, BrandCampaignGroupStatusEnum to,
                                              CampaignGroupEventEnum event, CampaignGroupStateContext stateContext) {

        CampaignGroupViewDTO campaignGroupViewDTO = stateContext.getCampaignGroupViewDTO();
        AssertUtil.notEmpty(stateContext.getSaleGroupIds(), BIZ_BREAK_RULE_ERROR, "当前改单申请不包含主分组");
        ServiceContext serviceContext = stateContext.getServiceContext();
        // 1. 获取主订单
        CampaignGroupViewDTO mainCampaignGroup;
        if (BizCampaignGroupToolsHelper.isMainCampaignGroup(campaignGroupViewDTO)) {
            mainCampaignGroup = campaignGroupViewDTO;
        } else {
            mainCampaignGroup = campaignGroupRepository.getCampaignGroup(serviceContext, campaignGroupViewDTO.getParentId());
        }
        // 2. 校验主订单是否支持修改
        campaignGroupStatusValidateForApplyModifyAbility.handle(serviceContext, CampaignGroupAbilityParam.builder().abilityTarget(mainCampaignGroup).build());
        // 3. 更新子订单&订单分组
        if (BizCampaignGroupToolsHelper.isSubCampaignGroup(campaignGroupViewDTO)) {
            CampaignGroupViewDTO subCampaignGroup = splitSubCampaignGroupBySceneId(stateContext.getServiceContext(),
                    mainCampaignGroup, campaignGroupViewDTO.getSceneId());
            subCampaignGroup.setId(campaignGroupViewDTO.getId());

            List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupList = Lists.newArrayList();
            if (CollectionUtils.isNotEmpty(stateContext.getSaleGroupIds())) {
                resourcePackageSaleGroupList = resourcePackageRepository.getSaleGroupList(stateContext.getServiceContext(), stateContext.getSaleGroupIds(),
                        ResourcePackageQueryOption.builder().needSetting(true).needProduct(false).needInquiryPriority(false).build());
            }
            // 更新子订单
            BizCampaignGroupWorkflowParam bizCampaignGroupWorkflowParam = BizCampaignGroupWorkflowParam.builder()
                    .dbCampaignGroupViewDTO(campaignGroupViewDTO).dbMainCampaignGroupViewDTO(mainCampaignGroup)
                    .resourcePackageSaleGroupList(resourcePackageSaleGroupList).build();
            executeUpdateCampaignGroup(stateContext.getServiceContext(), subCampaignGroup, bizCampaignGroupWorkflowParam);

            // 更新分组状态
            saleGroupStatusUpdateAbility.handle(serviceContext, SaleGroupStatusUpdateAbilityParam.builder().abilityTargets(stateContext.getSaleGroupIds())
                    .campaignGroupViewDTO(subCampaignGroup).saleGroupOrderStatusEnum(BrandCampaignGroupSaleOrderStatusEnum.WAIT_ORDER).build());
        }
        //4、更新Brief状态
        campaignGroupModifyBriefAbility.handle(serviceContext, CampaignGroupTransitAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
    }

    public CampaignGroupViewDTO splitSubCampaignGroupBySceneId(ServiceContext context, CampaignGroupViewDTO mainCampaignGroupViewDTO, Integer sceneId) {
        List<CampaignGroupViewDTO> subCampaignGroupList = splitSubCampaignGroupList(context, mainCampaignGroupViewDTO);
        for (CampaignGroupViewDTO subCampaignGroup : subCampaignGroupList) {
            if (subCampaignGroup.getSceneId().equals(sceneId)) {
                return subCampaignGroup;
            }
        }
        return null;
    }

    public void stopCastCampaignGroupForTransit(BrandCampaignGroupStatusEnum from, BrandCampaignGroupStatusEnum to,
                                                CampaignGroupEventEnum event, CampaignGroupStateContext context) {
        campaignGroupStopTimeUpdateForStopCastCampaignGroupAbility.handle(context.getServiceContext(), CampaignGroupStopTimeUpdateForStopCastCampaignGroupAbilityParam.builder()
                .abilityTarget(context.getCampaignGroupViewDTO()).mainCampaignGroup(context.getMainCampaignGroupViewDTO()).build());
    }
    /**
     * 完成订单
     * @param serviceContext
     * @param campaignGroupViewDTO
     */
    public void finish(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO) {
        Boolean canTransit = campaignGroupJudgeForFinishCampaignGroupAbility.handle(serviceContext, CampaignGroupTransitAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
        if (!canTransit) {
            return;
        }
        // 校验
        campaignGroupValidateForFinishCampaignGroupAbility.handle(serviceContext, CampaignGroupValidateForFinishCampaignGroupAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
        // perform
        campaignGroupSyncBriefForFinishCampaignGroupAbility.handle(serviceContext, CampaignGroupTransitAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
        // 状态流转
        this.transitCampaignGroup(serviceContext, campaignGroupViewDTO, CampaignGroupEventEnum.FINISH);
    }

    /**
     * 完成打回
     * @param serviceContext
     * @param campaignGroupViewDTO
     */
    public void finishRevert(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO) {
        Boolean canTransit = campaignGroupJudgeForFinishRevertCampaignGroupAbility.handle(serviceContext, CampaignGroupTransitAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
        if (!canTransit) {
            return;
        }
        // 校验
        campaignGroupValidateForFinishRevertCampaignGroupAbility.handle(serviceContext, CampaignGroupValidateForFinishCampaignGroupAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
        // perform
        campaignGroupSyncBriefForFinishRevertCampaignGroupAbility.handle(serviceContext, CampaignGroupTransitAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
        // 状态流转
        this.transitCampaignGroup(serviceContext, campaignGroupViewDTO, CampaignGroupEventEnum.FINISH_REVERT);
    }

    /**
     * 结案
     *
     * @param from
     * @param to
     * @param event
     * @param context
     */
    public void completeCampaignGroup(BrandCampaignGroupStatusEnum from, BrandCampaignGroupStatusEnum to,
                                      CampaignGroupEventEnum event, CampaignGroupStateContext context) {
        CampaignGroupViewDTO campaignGroupViewDTO = context.getCampaignGroupViewDTO();
        // 设置结案时间
        campaignGroupContractUpdateForCompleteCampaignGroupAbility.handle(context.getServiceContext(), CampaignGroupContractUpdateForTransitCampaignGroupAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupContractViewDTO()).campaignGroupViewDTO(campaignGroupViewDTO).build());
    }

    private void afterCampaignGroupUpdate(Map<CampaignGroupEventEnum, List<CampaignGroupViewDTO>> operatedCampaignGroupMap) {
        if (MapUtils.isEmpty(operatedCampaignGroupMap)) {
            return;
        }
        operatedCampaignGroupMap.forEach((eventEnum, campaignGroupList) -> {
            for (CampaignGroupViewDTO campaignGroup : campaignGroupList) {
                // 发送领域消息
                ServiceContext serviceContext = ServiceContextUtil.buildServiceContextForSceneIdNoSession(campaignGroup.getMemberId(), campaignGroup.getSceneId());
                campaignGroupMessageAsyncSendAbility.handle(serviceContext, CampaignGroupMessageAsyncSendAbilityParam.builder()
                        .abilityTarget(campaignGroup).domainEvent(eventEnum.name()).build());
            }
        });
    }

    /**
     * 更新子订单
     * @param context
     * @param operateSubCampaignGroupList
     * @param bizCampaignGroupWorkflowParam
     * @param operatedCampaignGroupMap
     */
    private void updateSubCampaignGroupList(ServiceContext context,
                                            List<CampaignGroupViewDTO> operateSubCampaignGroupList,
                                            BizCampaignGroupWorkflowParam bizCampaignGroupWorkflowParam,
                                            Map<CampaignGroupEventEnum, List<CampaignGroupViewDTO>> operatedCampaignGroupMap) {
        //
        CampaignGroupViewDTO dbMainCampaignGroupViewDTO = bizCampaignGroupWorkflowParam.getDbCampaignGroupViewDTO();
        Map<Integer, CampaignGroupViewDTO> dbSubCampaignGroupMap = bizCampaignGroupWorkflowParam.getDbSubCampaignGroupList()
                .stream().collect(Collectors.toMap(CampaignGroupViewDTO::getSceneId, Function.identity(), (v1, v2) -> v1));
        Map<Integer, List<ResourcePackageSaleGroupViewDTO>> sceneResourceSaleGroupMap = bizCampaignGroupWorkflowParam.getResourcePackageSaleGroupList()
                .stream().collect(Collectors.groupingBy(ResourcePackageSaleGroupViewDTO::getBusinessLine));

        Set<Integer> operatedCampaignGroupSceneIdSet = Sets.newHashSet();
        // 新增 or 更新
        for (CampaignGroupViewDTO operateSubCampaignGroup : operateSubCampaignGroupList) {
            Integer sceneId = operateSubCampaignGroup.getSceneId();
            // 重新构建参数
            ServiceContext subContext = ServiceContextUtil.buildServiceContextForSceneId(dbMainCampaignGroupViewDTO.getMemberId(), sceneId);
            BizCampaignGroupWorkflowParam subCampaignGroupWorkflowParam = BizCampaignGroupWorkflowParam.builder()
                    .dbCampaignGroupViewDTO(dbSubCampaignGroupMap.get(sceneId))
                    .dbMainCampaignGroupViewDTO(dbMainCampaignGroupViewDTO)
                    .resourcePackageSaleGroupList(sceneResourceSaleGroupMap.getOrDefault(sceneId, Lists.newArrayList()))
                    .build();
            // 记录
            operatedCampaignGroupSceneIdSet.add(sceneId);
            // 新增
            if (!dbSubCampaignGroupMap.containsKey(sceneId)) {
                // 执行新增
                executeAddCampaignGroup(subContext, operateSubCampaignGroup, subCampaignGroupWorkflowParam);
                operatedCampaignGroupMap.computeIfAbsent(CampaignGroupEventEnum.CREATE, k -> new ArrayList<>()).add(operateSubCampaignGroup);
            } else {
                // 更新时，如果当前子订单状态不支持更新，则改单审批通过后再更新
                CampaignGroupViewDTO dbSubCampaignGroupViewDTO = dbSubCampaignGroupMap.get(sceneId);
                if (!CampaignGroupConstant.validUpdateSubSaleCampaignGroupStatusList.contains(dbSubCampaignGroupViewDTO.getStatus())) {
                    continue;
                }
                operateSubCampaignGroup.setId(dbSubCampaignGroupViewDTO.getId());
                executeUpdateCampaignGroup(subContext, operateSubCampaignGroup, subCampaignGroupWorkflowParam);
                operatedCampaignGroupMap.computeIfAbsent(CampaignGroupEventEnum.UPDATE, k -> new ArrayList<>()).add(dbSubCampaignGroupViewDTO);
            }
        }

        // 删除移除的子订单
        for (CampaignGroupViewDTO dbSubCampaignGroupViewDTO : bizCampaignGroupWorkflowParam.getDbSubCampaignGroupList()) {
            if (!operatedCampaignGroupSceneIdSet.contains(dbSubCampaignGroupViewDTO.getSceneId())) {
                ServiceContext subContext = ServiceContextUtil.buildServiceContextForSceneId(dbSubCampaignGroupViewDTO.getMemberId(),
                        dbSubCampaignGroupViewDTO.getSceneId());
                campaignGroupStatusUpdateAbility.handle(subContext, CampaignGroupStatusUpdateAbilityParam.builder()
                        .abilityTarget(dbSubCampaignGroupViewDTO).targetStatus(BrandCampaignGroupStatusEnum.DELETED.getCode()).build());
                // 记录
                operatedCampaignGroupMap.computeIfAbsent(CampaignGroupEventEnum.DELETE, k -> new ArrayList<>()).add(dbSubCampaignGroupViewDTO);
            }
        }
    }


    private void afterCampaignGroupAdd(List<CampaignGroupViewDTO> addedCampaignGroupList) {
        if (CollectionUtils.isEmpty(addedCampaignGroupList)) {
            return;
        }
        for (CampaignGroupViewDTO campaignGroup : addedCampaignGroupList) {
            ServiceContext newContext = ServiceContextUtil.buildServiceContextForSceneId(campaignGroup.getMemberId(), campaignGroup.getSceneId());
            bizCampaignGroupCommandWorkflowExt.afterAdd(newContext, campaignGroup);
        }
    }

    private BizCampaignGroupWorkflowParam buildCampaignGroupWorkflowParamForSave(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO) {
        BizCampaignGroupWorkflowParam bizCampaignGroupWorkflowParam = new BizCampaignGroupWorkflowParam();
        AssertUtil.notNull(campaignGroupViewDTO, "订单参数为空");
        boolean isAdd = campaignGroupViewDTO.getId() == null;
        if (isAdd) {
            // 通过加购行生成订单时
            if (BrandCampaignGroupSourceEnum.CART.getCode().equals(campaignGroupViewDTO.getSource())
                    || BrandCampaignGroupSourceEnum.SLIM_ORDER.getCode().equals(campaignGroupViewDTO.getSource())) {
                // 加购行
                AssertUtil.notEmpty(campaignGroupViewDTO.getSourceIds(), "加购行信息不能为空");
                CartItemQueryViewDTO cartItemQueryViewDTO = new CartItemQueryViewDTO();
                cartItemQueryViewDTO.setIdList(campaignGroupViewDTO.getSourceIds());
                cartItemQueryViewDTO.setPageSize(campaignGroupViewDTO.getSourceIds().size());
                List<CartItemViewDTO> cartViewDTOS = cartItemRepository.findCartList(context, cartItemQueryViewDTO);
                bizCampaignGroupWorkflowParam.setCartItemList(cartViewDTOS);
                // 查询SKU
                List<Long> skuIds = cartViewDTOS.stream().map(CartItemViewDTO::getSkuId).distinct().collect(Collectors.toList());
                List<BrandSkuViewDTO> skuViewDTOList = brandSkuRepository.findSkuList(context, skuIds);
                bizCampaignGroupWorkflowParam.setSkuList(skuViewDTOList);
                // 查询SPU
                List<Long> spuIds = cartViewDTOS.stream().map(CartItemViewDTO::getSpuId).distinct().collect(Collectors.toList());
                BrandSpuQueryViewDTO spuQueryViewDTO = new BrandSpuQueryViewDTO();
                spuQueryViewDTO.setSpuIdList(spuIds);
                spuQueryViewDTO.setNeedRef(true);
                spuQueryViewDTO.setPageSize(spuIds.size());
                List<BrandSpuViewDTO> spuViewDTOList = brandSpuRepository.findSpuList(context, spuQueryViewDTO);
                bizCampaignGroupWorkflowParam.setSpuList(spuViewDTOList);
                // 查询计划
                CampaignQueryViewDTO query = new CampaignQueryViewDTO();
                query.setCartItemIds(campaignGroupViewDTO.getSourceIds());
                query.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
                query.setOnlineStatusList(BizCampaignToolsHelper.getCampaignOnlineStatusList());
                CampaignQueryOption option = new CampaignQueryOption();
                List<CampaignViewDTO> campaignViewDTOList = bizCampaignQueryWorkflow.getCampaignInfoListByOption(context, query, option);
                bizCampaignGroupWorkflowParam.setCampaignList(campaignViewDTOList);
            }
        }
        // DB订单信息
        if (campaignGroupViewDTO.getId() != null) {
            CampaignGroupViewDTO dbCampaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(context, campaignGroupViewDTO.getId());
            AssertUtil.notNull(dbCampaignGroupViewDTO, "订单不存在");
            bizCampaignGroupWorkflowParam.setDbCampaignGroupViewDTO(dbCampaignGroupViewDTO);
            // 更新主订单时，查询所有子订单
            if (BizCodeEnum.BRANDONEBP.getBizCode().equals(context.getBizCode())) {
                List<CampaignGroupViewDTO> subCampaignGroupList = campaignGroupRepository.findSubCampaignGroupList(context, dbCampaignGroupViewDTO.getId());
                bizCampaignGroupWorkflowParam.setDbSubCampaignGroupList(subCampaignGroupList);
            }
        }

        // 分组信息
        List<Long> saleGroupIds = Optional.ofNullable(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO()).map(CampaignGroupSaleGroupViewDTO::getSaleGroupInfoViewDTOList).orElse(Lists.newArrayList())
                .stream().map(SaleGroupInfoViewDTO::getSaleGroupId).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(saleGroupIds)) {
            ResourcePackageQueryViewDTO queryViewDTO = new ResourcePackageQueryViewDTO();
            queryViewDTO.setSaleGroupIdList(saleGroupIds);
            queryViewDTO.setPageSize(saleGroupIds.size());
            List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupList = resourcePackageRepository.getSaleGroupList(context, queryViewDTO,
                    ResourcePackageQueryOption.builder().needSetting(true).needProduct(false).needInquiryPriority(true).build());
            bizCampaignGroupWorkflowParam.setResourcePackageSaleGroupList(resourcePackageSaleGroupList);
        }

        return bizCampaignGroupWorkflowParam;
    }

    /**
     * 执行添加订单
     *
     * @param context
     * @param campaignGroupViewDTO
     * @return
     */
    private Long executeAddCampaignGroup(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, BizCampaignGroupWorkflowParam bizCampaignGroupWorkflowParam) {
        // 1. 前置链路
        bizCampaignGroupCommandWorkflowExt.beforeExecuteAddCampaignGroup(context, campaignGroupViewDTO, bizCampaignGroupWorkflowParam);
        // 2. 商业能力显式挂载
        if (CollectionUtils.isNotEmpty(bizCampaignGroupWorkflowParam.getResourcePackageSaleGroupList())) {
            Map<Long, ResourcePackageSaleGroupViewDTO> packageSaleGroupMap = bizCampaignGroupWorkflowParam.getResourcePackageSaleGroupList().stream().collect(Collectors.toMap(ResourcePackageSaleGroupViewDTO::getId, Function.identity()));
            Optional.ofNullable(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO()).map(CampaignGroupSaleGroupViewDTO::getSaleGroupInfoViewDTOList).orElse(Lists.newArrayList()).
                    forEach(saleGroupInfoViewDTO -> {
                        ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO = packageSaleGroupMap.get(saleGroupInfoViewDTO.getSaleGroupId());
                        BusinessAbilityRouteContext businessAbilityRouteContext = BusinessAbilityRouteContext.builder().packageSaleGroupViewDTO(packageSaleGroupViewDTO).build();
                        invokeAll(ISaleGroupAddBusinessAbilityPoint.class, businessAbilityRouteContext,
                                callBack -> callBack.invokeForAddSaleGroup(context, saleGroupInfoViewDTO, businessAbilityRouteContext));
                    });
        }
        // 3. 执行新增
        Long campaignGroupId = campaignGroupAddAbility.handle(context, CampaignGroupAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
        campaignGroupViewDTO.setId(campaignGroupId);
        // 5. 新增后置链路处理
        bizCampaignGroupCommandWorkflowExt.afterExecuteAddCampaignGroup(context,campaignGroupViewDTO);
        return campaignGroupId;
    }

    /**
     * 执行更新订单
     *
     * @param context
     * @param campaignGroupViewDTO
     * @return
     */
    private Integer executeUpdateCampaignGroup(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, BizCampaignGroupWorkflowParam bizCampaignGroupWorkflowParam) {
        // 1. 前置链路
        bizCampaignGroupCommandWorkflowExt.beforeExecuteUpdateCampaignGroup(context, campaignGroupViewDTO, bizCampaignGroupWorkflowParam);

        // 2. 商业能力显式挂载
        Map<Long, ResourcePackageSaleGroupViewDTO> packageSaleGroupMap = bizCampaignGroupWorkflowParam.getResourcePackageSaleGroupList().stream().collect(Collectors.toMap(ResourcePackageSaleGroupViewDTO::getId, Function.identity()));
        Optional.ofNullable(campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO()).map(CampaignGroupSaleGroupViewDTO::getSaleGroupInfoViewDTOList).orElse(Lists.newArrayList()).
                forEach(saleGroupInfoViewDTO -> {
                    ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO = packageSaleGroupMap.get(saleGroupInfoViewDTO.getSaleGroupId());
                    BusinessAbilityRouteContext businessAbilityRouteContext = BusinessAbilityRouteContext.builder().packageSaleGroupViewDTO(packageSaleGroupViewDTO).build();
                    invokeAll(ISaleGroupUpdateBusinessAbilityPoint.class, businessAbilityRouteContext,
                            callBack -> callBack.invokeForUpdateSaleGroup(context,saleGroupInfoViewDTO, businessAbilityRouteContext));
                });
        // 3. 执行更新(由于update有删除分组的场景，需要全量重新绑定)
        Integer count = campaignGroupUpdateAbility.handle(context, CampaignGroupUpdateAbilityParam.builder().abilityTarget(campaignGroupViewDTO).needUpdateSaleGroupAll(true).build());

        // 4. 更新后置链路处理
        bizCampaignGroupCommandWorkflowExt.afterExecuteUpdateCampaignGroup(context,campaignGroupViewDTO);
        return count;
    }

    public Integer physicalDeleteCampaignGroups(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, boolean needDeleteTree) {
        if (campaignGroupViewDTO == null || campaignGroupViewDTO.getId() == null) {
            return 0;
        }
        // 删除订单
        Integer count = campaignGroupDeleteAbility.handle(context, CampaignGroupAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
        if (!needDeleteTree) {
            return count;
        }
        // 主订单时，删除子订单
        if (BizCampaignGroupToolsHelper.isMainCampaignGroup(campaignGroupViewDTO)) {
            List<CampaignGroupViewDTO> subCampaignGroupList = campaignGroupRepository.findSubCampaignGroupList(context, campaignGroupViewDTO.getId());
            if (CollectionUtils.isEmpty(subCampaignGroupList)) {
                return count;
            }
            subCampaignGroupList.forEach(subCampaignGroup -> {
                ServiceContext subContext = ServiceContextUtil.buildServiceContextForSceneId(subCampaignGroup.getMemberId(), subCampaignGroup.getSceneId());
                campaignGroupDeleteAbility.handle(subContext, CampaignGroupAbilityParam.builder().abilityTarget(subCampaignGroup).build());
            });
        } else {// 子订单时删除主订单
            if (campaignGroupViewDTO.getParentId() != null && campaignGroupViewDTO.getParentId() != 0L) {
                CampaignGroupViewDTO mainCampaignGroup = campaignGroupRepository.getCampaignGroup(context, campaignGroupViewDTO.getParentId());
                if (Objects.isNull(mainCampaignGroup)) {
                    return count;
                }
                ServiceContext mainContext = ServiceContextUtil.buildServiceContextForBizCode(context.getMemberId(), BizCodeEnum.BRANDONEBP.getBizCode());
                List<CampaignGroupViewDTO> subCampaignGroupList = campaignGroupRepository.findSubCampaignGroupList(mainContext, mainCampaignGroup.getId());
                if (CollectionUtils.isEmpty(subCampaignGroupList)) {
                    campaignGroupDeleteAbility.handle(mainContext, CampaignGroupAbilityParam.builder().abilityTarget(mainCampaignGroup).build());
                }
            }
        }

        return count;
    }

    private void afterRealSettleInfoSaved(ServiceContext context, CampaignGroupRealSettleSaveViewDTO realSettleSaveViewDTO, CampaignGroupViewDTO campaignGroupViewDTO) {
        if (realSettleSaveViewDTO.getRealSettleOpTypeEnum() != CampaignGroupRealSettleOpTypeEnum.SUBMIT) {
            return;
        }
        // 发送子->主订单领域事件
        campaignGroupMessageAsyncSendAbility.handle(context, CampaignGroupMessageAsyncSendAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO).domainEvent(CampaignGroupEventEnum.REAL_SETTLE_CONFIG.name()).build());
    }

    private void modifyPackagePlatformSaleGroup(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, List<Long> packagePlatformSaleGroupIds) {
        if (CollectionUtils.isEmpty(packagePlatformSaleGroupIds)) {
            return;
        }
        saleGroupStatusUpdateAbility.handle(context, SaleGroupStatusUpdateAbilityParam.builder().abilityTargets(packagePlatformSaleGroupIds)
                .campaignGroupViewDTO(campaignGroupViewDTO).saleGroupOrderStatusEnum(BrandCampaignGroupSaleOrderStatusEnum.WAIT_ORDER).build());
    }

    private CampaignGroupViewDTO modifySalePlatformSaleGroup(ServiceContext serviceContext, CampaignGroupViewDTO campaignGroupViewDTO, List<Long> salePlatformSaleGroupIds) {
        if (CollectionUtils.isEmpty(salePlatformSaleGroupIds)) {
            return campaignGroupViewDTO;
        }
        // 当前订单状态是草稿、改单配置时，则代表订单状态是直接可以编辑的，不需要进行状态流转
        if (BrandCampaignGroupStatusEnum.EDITED.getCode().equals(campaignGroupViewDTO.getStatus())
                || BrandCampaignGroupStatusEnum.UNLOCKED.getCode().equals(campaignGroupViewDTO.getStatus())) {
            // 仅更新分组状态
            saleGroupStatusUpdateAbility.handle(serviceContext, SaleGroupStatusUpdateAbilityParam.builder().abilityTargets(salePlatformSaleGroupIds)
                    .campaignGroupViewDTO(campaignGroupViewDTO).saleGroupOrderStatusEnum(BrandCampaignGroupSaleOrderStatusEnum.WAIT_ORDER).build());
            return campaignGroupViewDTO;
        }
        this.transitCampaignGroup(serviceContext, campaignGroupViewDTO, CampaignGroupEventEnum.MODIFY_ORDER, context -> {
            CampaignGroupStateContext transitContext = (CampaignGroupStateContext) context;
            // 设置分组ID
            transitContext.setSaleGroupIds(salePlatformSaleGroupIds);
        });
        // 重新获取
        return campaignGroupRepository.getCampaignGroup(serviceContext, campaignGroupViewDTO.getId());
    }

    private BizCampaignGroupProcessOrderWorkflowParam buildWorkflowParamForApplyModify(ServiceContext context, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO) {
        AssertUtil.notNull(campaignGroupOrderCommandViewDTO, "参数为空");
        // 当前订单
        CampaignGroupViewDTO campaignGroupViewDTO = getCampaignGroup(context, campaignGroupOrderCommandViewDTO.getId());
        BizCampaignGroupProcessOrderWorkflowParam processWorkflowParam = new BizCampaignGroupProcessOrderWorkflowParam();
        processWorkflowParam.setCampaignGroupViewDTO(campaignGroupViewDTO);
        // 主订单
        CampaignGroupViewDTO mainCampaignGroup = campaignGroupRepository.getCampaignGroup(context, campaignGroupViewDTO.getParentId());
        AssertUtil.notNull(campaignGroupOrderCommandViewDTO, "主订单不存在");
        processWorkflowParam.setMainCampaignGroupViewDTO(mainCampaignGroup);
        // 资源包分组信息
        AssertUtil.notNull(campaignGroupOrderCommandViewDTO.getSaleGroupIds(), "勾选分组不能为空");
        ResourcePackageQueryOption queryOption = ResourcePackageQueryOption.builder()
                .needInquiryPriority(Boolean.FALSE)
                .needSetting(Boolean.TRUE)
                .needProduct(Boolean.FALSE)
                .build();
        List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupList = resourcePackageRepository.getSaleGroupList(context, campaignGroupOrderCommandViewDTO.getSaleGroupIds(), queryOption);
        processWorkflowParam.setResourcePackageSaleGroupList(resourcePackageSaleGroupList);

        return processWorkflowParam;
    }

    /**
     * 资源包平台的分组下单，仅需要修改状态
     * 后置处理再通知计划
     * @param context
     * @param campaignGroupViewDTO
     * @param packagePlatformSaleGroupIds
     */
    private void orderPackagePlatformSaleGroup(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, List<Long> packagePlatformSaleGroupIds) {
        if (CollectionUtils.isEmpty(packagePlatformSaleGroupIds)) {
            return;
        }
        // 合同上线则将分组更新成上线状态
        if (campaignGroupViewDTO.getCampaignGroupContractViewDTO().getContractFirstOnlineTime() != null) {
            saleGroupStatusUpdateAbility.handle(context, SaleGroupStatusUpdateAbilityParam.builder().abilityTargets(packagePlatformSaleGroupIds)
                    .campaignGroupViewDTO(campaignGroupViewDTO).saleGroupOrderStatusEnum(BrandCampaignGroupSaleOrderStatusEnum.ORDER_FINISH).build());
        }
    }

    /**
     * 下单售卖中心分组
     *
     * @param serviceContext
     * @param orderViewDTO
     * @param campaignGroupViewDTO
     * @param processWorkflowParam
     * @return
     */
    private void orderSalePlatformSaleGroup(ServiceContext serviceContext, CampaignGroupOrderCommandViewDTO orderViewDTO,
                                            CampaignGroupViewDTO campaignGroupViewDTO, BizCampaignGroupProcessOrderWorkflowParam processWorkflowParam) {
        if (CollectionUtils.isEmpty(processWorkflowParam.getSalePlatformSaleGroupIds())
                || orderViewDTO.getNeedTransit() != null && !orderViewDTO.getNeedTransit()) {
            return;
        }
        // 1. 同步信息至Brief(仅主订单需要进行此处理)
        campaignGroupSyncBriefForOrderCampaignGroupAbility.handle(serviceContext, CampaignGroupTransitAbilityParam.builder().abilityTarget(campaignGroupViewDTO).build());
        // 2. 更新合同信息
        campaignGroupContractUpdateForOrderCampaignGroupAbility.handle(serviceContext, CampaignGroupContractUpdateForOrderCampaignGroupAbilityParam.builder()
                .abilityTarget(campaignGroupViewDTO.getCampaignGroupContractViewDTO()).subCampaignGroupList(processWorkflowParam.getSubCampaignGroupList()).build());

        // 3. 状态迁移
        this.transitCampaignGroup(serviceContext, campaignGroupViewDTO, CampaignGroupEventEnum.ORDER, context -> {
            CampaignGroupStateContext transitContext = (CampaignGroupStateContext) context;
            // 设置分组ID
            transitContext.setSaleGroupIds(processWorkflowParam.getSalePlatformSaleGroupIds());
            transitContext.setSubCampaignGroupViewDTOList(processWorkflowParam.getSubCampaignGroupList());
            transitContext.setIgnoreNotAcceptError(orderViewDTO.isIgnoreNotTransitError());
        });
    }

    private BizCampaignGroupProcessOrderWorkflowParam buildWorkflowParamForOrder(ServiceContext context, CampaignGroupOrderCommandViewDTO orderViewDTO) {
        AssertUtil.notNull(orderViewDTO, "参数为空");
        CampaignGroupViewDTO campaignGroupViewDTO = getCampaignGroup(context, orderViewDTO.getId());
        // 构建参数
        BizCampaignGroupProcessOrderWorkflowParam processWorkflowParam = bizCampaignGroupCommandWorkflowExt.buildParamForOrder(context, orderViewDTO, campaignGroupViewDTO);
        processWorkflowParam.setCampaignGroupViewDTO(campaignGroupViewDTO);

        return processWorkflowParam;
    }

    private CampaignGroupViewDTO getCampaignGroup(ServiceContext context, Long id) {
        AssertUtil.notNull(id, "订单ID为空");
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(context, id);
        AssertUtil.notNull(campaignGroupViewDTO, "订单不存在");
        return campaignGroupViewDTO;
    }

    private BizSaleGroupNoticeWorkflowParam buildSaleGroupNoticeWorkflowParam(ServiceContext serviceContext, ResourcePackageNoticeTemplateViewDTO noticeTemplateViewDTO) {
        BizSaleGroupNoticeWorkflowParam workflowParam = new BizSaleGroupNoticeWorkflowParam();
        // 客户模板
        ResourcePackageTemplateViewDTO resourcePackageTemplateViewDTO = resourcePackageRepository.getCustomerTemplateById(serviceContext, noticeTemplateViewDTO.getId());
        workflowParam.setResourcePackageTemplateViewDTO(resourcePackageTemplateViewDTO);
        // 客户模板+分组关联的主订单（可能是多个）
        List<CampaignGroupViewDTO> mainampaignGroupViewList = findMainCampaignGroupListByTemplateInfo(resourcePackageTemplateViewDTO, noticeTemplateViewDTO.getSaleGroupList());
        workflowParam.setMainCampaignGroupViewList(mainampaignGroupViewList);
        if (CollectionUtils.isEmpty(mainampaignGroupViewList)) {
            return workflowParam;
        }
        // 客户模版下的所有分组
        List<ResourcePackageSaleGroupViewDTO> templateSaleGroupList = getTemplateSaleGroupList(serviceContext, noticeTemplateViewDTO);
        List<ResourcePackageSaleGroupViewDTO>  currentTemplateSaleGroupList =  templateSaleGroupList.stream().filter(item-> Objects.nonNull(item.getMemberId())).collect(Collectors.toList());
        workflowParam.setResourcePackageSaleGroupList(currentTemplateSaleGroupList);

        return workflowParam;
    }

    private List<CampaignGroupViewDTO> findMainCampaignGroupListByTemplateInfo(ResourcePackageTemplateViewDTO resourcePackageTemplateViewDTO,
                                                                               List<ResourcePackageNoticeSaleGroupViewDTO> noticeSaleGroupList) {
        if (resourcePackageTemplateViewDTO == null) {
            return Lists.newArrayList();
        }
        List<Long> noticeSaleGroupIdList = noticeSaleGroupList.stream().map(ResourcePackageNoticeSaleGroupViewDTO::getId).collect(Collectors.toList());
        List<Long> noticeMainSaleGroupIdList = noticeSaleGroupList.stream().map(ResourcePackageNoticeSaleGroupViewDTO::getMainGroupId).filter(Objects::nonNull).collect(Collectors.toList());
        List<Long> memberIdList = getMemberIdFromResourcePackages(resourcePackageTemplateViewDTO, noticeSaleGroupList);
        if (CollectionUtils.isEmpty(memberIdList)) {
            RogerLogger.error("未查询到客户模板或售卖分组绑定的member，客户模板信息：{}", JSONObject.toJSONString(resourcePackageTemplateViewDTO));
            return Lists.newArrayList();
        }
        List<CampaignGroupViewDTO> filterCampaignGroupViewDTOList = Lists.newArrayList();
        for (Long memberId : memberIdList) {
            ServiceContext serviceContext = ServiceContextUtil.buildServiceContextForBizCodeNoSession(memberId, BizCodeEnum.BRANDONEBP.getBizCode());
            CampaignGroupQueryViewDTO queryViewDTO = new CampaignGroupQueryViewDTO();
            queryViewDTO.setCustomerTemplateId(resourcePackageTemplateViewDTO.getCustomerTemplateId());
            queryViewDTO.setCampaignGroupLevel(BrandCampaignGroupLevelEnum.LEVEL_ONE.getCode());
            queryViewDTO.setNoInStatusList(Lists.newArrayList(BrandCampaignGroupStatusEnum.DELETED.getCode(), BrandCampaignGroupStatusEnum.CANCELED.getCode()));

            List<CampaignGroupViewDTO> mainCampaignGroupList = campaignGroupRepository.findCampaignGroupList(serviceContext, queryViewDTO);
            if (CollectionUtils.isNotEmpty(mainCampaignGroupList)) {
                List<CampaignGroupViewDTO> filterCampaignGroupList = mainCampaignGroupList.stream().filter(campaignGroup -> {
                    for (SaleGroupInfoViewDTO saleGroup : campaignGroup.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList()) {
                        if (noticeSaleGroupIdList.contains(saleGroup.getSaleGroupId()) || noticeMainSaleGroupIdList.contains(saleGroup.getSaleGroupId())) {
                            return true;
                        }
                    }
                    return false;
                }).collect(Collectors.toList());
                filterCampaignGroupViewDTOList.addAll(filterCampaignGroupList);
            }
        }

        return filterCampaignGroupViewDTOList;
    }

    /**
     * 获取memberId
     *
     * @param resourcePackageTemplateViewDTO
     * @param noticeSaleGroupList
     * @return
     */
    private List<Long> getMemberIdFromResourcePackages(ResourcePackageTemplateViewDTO resourcePackageTemplateViewDTO, List<ResourcePackageNoticeSaleGroupViewDTO> noticeSaleGroupList) {
        Map<Long, List<ResourcePackageNoticeSaleGroupViewDTO>> noticeSaleGroupByMemberMap = noticeSaleGroupList.stream()
                .filter(t -> t.getMemberId() != null).collect(Collectors.groupingBy(ResourcePackageNoticeSaleGroupViewDTO::getMemberId));
        if (MapUtils.isNotEmpty(noticeSaleGroupByMemberMap)) {
            return Lists.newArrayList(noticeSaleGroupByMemberMap.keySet());
        }
        return Lists.newArrayList(resourcePackageTemplateViewDTO.getMemberId());
    }

    private void doUpdateMainCampaignGroupPackagePlatformSaleGroups(ServiceContext mainServiceContext, CampaignGroupViewDTO campaignGroupViewDTO, List<ResourcePackageNoticeSaleGroupViewDTO> filterNoticeSaleGroupViewList, Map<Long, ResourcePackageSaleGroupViewDTO> currentTemplateSaleGroupMap) {
        List<SaleGroupInfoViewDTO> campaignGroupSaleGroupList = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList();
        // 打包平台同步分组Diff
        SaleGroupDiffResultViewDTO saleGroupDiffResultViewDTO = saleGroupDiffForNoticeSaleGroupAbility.handle(mainServiceContext, SaleGroupDiffAbilityParam.builder()
                .filterNoticeSaleGroupViewList(filterNoticeSaleGroupViewList)
                .dbSaleGroupInfoViewDTOList(campaignGroupSaleGroupList)
                .resourcePackageSaleGroupList(Lists.newArrayList(currentTemplateSaleGroupMap.values()))
                .build());
        // 初始化
        initPackagePlatformSaleGroupByDiffResult(mainServiceContext, campaignGroupViewDTO, currentTemplateSaleGroupMap, saleGroupDiffResultViewDTO);
        //商业能力显式挂载
        campaignGroupSaleGroupList.stream().filter(saleGroupInfoViewDTO -> Objects.isNull(saleGroupInfoViewDTO.getId()))//仅处理新增的分组
                .forEach(saleGroupInfoViewDTO -> {
                    ResourcePackageSaleGroupViewDTO packageSaleGroupViewDTO = currentTemplateSaleGroupMap.get(saleGroupInfoViewDTO.getSaleGroupId());
                    BusinessAbilityRouteContext businessAbilityRouteContext = BusinessAbilityRouteContext.builder().packageSaleGroupViewDTO(packageSaleGroupViewDTO).build();
                    invokeAll(ISaleGroupAddBusinessAbilityPoint.class, businessAbilityRouteContext,
                            callBack -> callBack.invokeForAddSaleGroup(mainServiceContext, saleGroupInfoViewDTO, businessAbilityRouteContext));
                });
        // 更新售卖分组信息
        doUpdatePackagePlatformSaleGroupByDiffResult(mainServiceContext, campaignGroupViewDTO, campaignGroupSaleGroupList, saleGroupDiffResultViewDTO);
    }

    private void initPackagePlatformSaleGroupByDiffResult(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, Map<Long, ResourcePackageSaleGroupViewDTO> currentTemplateSaleGroupMap, SaleGroupDiffResultViewDTO saleGroupDiffResultViewDTO) {
        List<SaleGroupInfoViewDTO> campaignGroupSaleGroupList = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList();
        // init：删除的客户分组
        if (CollectionUtils.isNotEmpty(saleGroupDiffResultViewDTO.getDeleteSaleGroupIds())) {
            saleGroupInitForDeleteAbility.handle(context, SaleGroupInitAbilityParam.builder()
                    .abilityTargets(campaignGroupSaleGroupList).operateSaleGroupIds(saleGroupDiffResultViewDTO.getDeleteSaleGroupIds()).build());
        }
        // init：新增或更新的客户分组
        if (CollectionUtils.isNotEmpty(saleGroupDiffResultViewDTO.getUpdateSaleGroupIds())) {
            saleGroupInitForUpdateAbility.handle(context, SaleGroupInitAbilityParam.builder()
                    .abilityTargets(campaignGroupSaleGroupList).resourcePackageSaleGroupMap(currentTemplateSaleGroupMap)
                    .operateSaleGroupIds(saleGroupDiffResultViewDTO.getUpdateSaleGroupIds())
                    .saleGroupSourceEnum(BrandSaleGroupSourceEnum.PACKAGE_PLATFORM).build());
        }
        if (CollectionUtils.isNotEmpty(saleGroupDiffResultViewDTO.getAddSaleGroupIds())) {
            // 售卖产品线->子合同关联关系
            Map<Integer, Long> saleProductLine2SubContractIdMap = campaignGroupSaleGroupList.stream().filter(t -> t.getSubContractId() != null)
                    .collect(Collectors.toMap(SaleGroupInfoViewDTO::getSaleProductLine, SaleGroupInfoViewDTO::getSubContractId, (t1, t2) -> t2));
            List<SaleGroupInfoViewDTO> addSaleGroupList = saleGroupDiffResultViewDTO.getAddSaleGroupIds().stream().map(addSaleGroupId -> {
                SaleGroupInfoViewDTO saleGroupInfoViewDTO = new SaleGroupInfoViewDTO();
                saleGroupInfoViewDTO.setSaleGroupId(addSaleGroupId);
                return saleGroupInfoViewDTO;
            }).collect(Collectors.toList());
            saleGroupInitForAddAbility.handle(context, SaleGroupInitAbilityParam.builder()
                    .abilityTargets(addSaleGroupList)
                    .operateSaleGroupIds(saleGroupDiffResultViewDTO.getAddSaleGroupIds())
                    .saleGroupSourceEnum(BrandSaleGroupSourceEnum.PACKAGE_PLATFORM)
                    .resourcePackageSaleGroupMap(currentTemplateSaleGroupMap)
                    .saleProductLine2SubContractIdMap(saleProductLine2SubContractIdMap)
                    .build());
            campaignGroupSaleGroupList.addAll(addSaleGroupList);
        }

        campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().setSaleGroupInfoViewDTOList(campaignGroupSaleGroupList);
    }

    private void doUpdatePackagePlatformSaleGroupByDiffResult(ServiceContext context, CampaignGroupViewDTO campaignGroupViewDTO, List<SaleGroupInfoViewDTO> campaignGroupSaleGroupList, SaleGroupDiffResultViewDTO diffResultViewDTO) {
        // 执行删除
        if (CollectionUtils.isNotEmpty(diffResultViewDTO.getDeleteSaleGroupIds())) {
            saleGroupDeleteAbility.handle(context, SaleGroupDeleteAbilityParam.builder()
                    .abilityTargets(diffResultViewDTO.getDeleteSaleGroupIds()).campaignGroupViewDTO(campaignGroupViewDTO).build());
        }
        // 执行新增或更新
        if (CollectionUtils.isNotEmpty(diffResultViewDTO.getAddSaleGroupIds()) || CollectionUtils.isNotEmpty(diffResultViewDTO.getUpdateSaleGroupIds())) {
            List<Long> addOrUpdateSaleGroupIds = Lists.newArrayList();
            Optional.ofNullable(diffResultViewDTO.getAddSaleGroupIds()).ifPresent(addOrUpdateSaleGroupIds::addAll);
            Optional.ofNullable(diffResultViewDTO.getUpdateSaleGroupIds()).ifPresent(addOrUpdateSaleGroupIds::addAll);
            List<SaleGroupInfoViewDTO> filterSaleGroupList = campaignGroupSaleGroupList.stream()
                    .filter(saleGroupInfoViewDTO -> addOrUpdateSaleGroupIds.contains(saleGroupInfoViewDTO.getSaleGroupId())).collect(Collectors.toList());
            campaignGroupRepository.addOrUpdateSaleGroupPart(context, campaignGroupViewDTO.getId(), filterSaleGroupList);
        }

        // 因为是part更新，重新查询DB全量，设置在订单上
        SaleGroupQueryViewDTO saleGroupQueryViewDTO = new SaleGroupQueryViewDTO();
        saleGroupQueryViewDTO.setCampaignGroupIds(Lists.newArrayList(campaignGroupViewDTO.getId()));
        List<SaleGroupInfoViewDTO> dbSaleGroupList = campaignGroupRepository.findSaleGroupList(context, saleGroupQueryViewDTO);
        campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().setSaleGroupInfoViewDTOList(dbSaleGroupList);
    }

    private List<CampaignGroupViewDTO> filterBoundCampaignGroupListBySaleGroupInfo(List<CampaignGroupViewDTO> campaignGroupViewList, List<ResourcePackageNoticeSaleGroupViewDTO> noticeSaleGroupViewList) {
        Set<Long> saleGroupIdSet = noticeSaleGroupViewList.stream().map(ResourcePackageNoticeSaleGroupViewDTO::getId).collect(Collectors.toSet());
        Set<Long> mainGroupIdSet = noticeSaleGroupViewList.stream().map(ResourcePackageNoticeSaleGroupViewDTO::getMainGroupId).collect(Collectors.toSet());
        List<CampaignGroupViewDTO> filterCampaignGroupViewList = Lists.newArrayList();
        for (CampaignGroupViewDTO campaignGroupViewDTO : campaignGroupViewList) {
            List<SaleGroupInfoViewDTO> campaignGroupSaleGroupList = campaignGroupViewDTO.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList();
            boolean matched = campaignGroupSaleGroupList.stream().anyMatch(t -> saleGroupIdSet.contains(t.getSaleGroupId())
                    || mainGroupIdSet.contains(t.getSaleGroupId()) && BrandSaleGroupSourceEnum.SALE_PLATFORM.getCode().equals(t.getSource()));
            if (matched) {
                filterCampaignGroupViewList.add(campaignGroupViewDTO);
            }
        }

        return filterCampaignGroupViewList;
    }

    private List<ResourcePackageSaleGroupViewDTO> getTemplateSaleGroupList(ServiceContext serviceContext, ResourcePackageNoticeTemplateViewDTO noticeTemplateViewDTO) {
        Map<Integer, List<ResourcePackageNoticeSaleGroupViewDTO>> noticeSaleGroupMap = noticeTemplateViewDTO.getSaleGroupList().stream()
                .collect(Collectors.groupingBy(ResourcePackageNoticeSaleGroupViewDTO::getOperateType));

        if (noticeSaleGroupMap.containsKey(SaleGroupOperateTypeEnum.ADD.getValue()) || noticeSaleGroupMap.containsKey(SaleGroupOperateTypeEnum.UPDATE.getValue())) {
            return resourcePackageRepository.getSaleGroupList(serviceContext,
                    ResourcePackageQueryViewDTO.builder().templateId(noticeTemplateViewDTO.getId()).build(),
                    ResourcePackageQueryOption.builder().needSetting(true).needInquiryPriority(true).build());
        }

        return Lists.newArrayList();
    }


//    /**
//     * 重试设置计划预算配置
//     * @param serviceContext
//     * @param campaignTreeList
//     * @param campaignTreeList
//     * @return
//     */
//    private void resetProductCampaignCalViewDTO(ServiceContext serviceContext,CampaignGroupSaleGroupCalViewDTO calViewDTO, List<CampaignViewDTO> campaignTreeList) {
//        AssertUtil.notNull(campaignTreeList,"订单分组计划未创建，请检查");
//
//        Map<Long, List<CampaignViewDTO>> dbProductCampaignMap = campaignTreeList.stream()
//                .collect(Collectors.groupingBy(campaignViewDTO -> campaignViewDTO.getCampaignSaleViewDTO().getResourcePackageProductId()));
//
//        for (ProductCampaignCalViewDTO productCalViewDTO : calViewDTO.getProductCampaignList()) {
//            Long resourcePackageProductId = productCalViewDTO.getResourcePackageProductId();
//            List<CampaignCalViewDTO> campaignCalList = productCalViewDTO.getCampaignList();
//            //优先页面配置的计划预定量和预定比例
//            if(CollectionUtils.isNotEmpty(campaignCalList)){
//                Map<Long, CampaignViewDTO> dbCampaignMap = dbProductCampaignMap.getOrDefault(resourcePackageProductId,Lists.newArrayList()).stream()
//                        .collect(Collectors.toMap(campaignViewDTO -> campaignViewDTO.getId(), Function.identity(), (v1, v2) -> v2));
//
//                for (CampaignCalViewDTO campaignCalViewDTO : campaignCalList) {
//                    CampaignViewDTO dbCampaignViewDTO = dbCampaignMap.get(campaignCalViewDTO.getCampaignId());
//                    if(dbCampaignViewDTO != null){
//                        campaignCalViewDTO.setCampaignName(dbCampaignViewDTO.getTitle());
//                        campaignCalViewDTO.setStartTime(dbCampaignViewDTO.getStartTime());
//                        campaignCalViewDTO.setEndTime(dbCampaignViewDTO.getEndTime());
//                        campaignCalViewDTO.setCptAmount(dbCampaignViewDTO.getCampaignGuaranteeViewDTO().getCptAmount());
//                    }
//                }
//            }else{
//                campaignCalList = dbProductCampaignMap.getOrDefault(resourcePackageProductId,Lists.newArrayList())
//                        .stream().map(dbCampaignViewDTO -> {
//                            CampaignCalViewDTO campaignCalViewDTO = new CampaignCalViewDTO();
//                            campaignCalViewDTO.setCampaignId(dbCampaignViewDTO.getId());
//                            campaignCalViewDTO.setCampaignName(dbCampaignViewDTO.getTitle());
//                            campaignCalViewDTO.setStartTime(dbCampaignViewDTO.getStartTime());
//                            campaignCalViewDTO.setEndTime(dbCampaignViewDTO.getEndTime());
//                            campaignCalViewDTO.setCptAmount(dbCampaignViewDTO.getCampaignGuaranteeViewDTO().getCptAmount());
//                            campaignCalViewDTO.setBudgetRatio(dbCampaignViewDTO.getCampaignBudgetViewDTO().getBudgetRatio());
//                            campaignCalViewDTO.setBudget(dbCampaignViewDTO.getCampaignBudgetViewDTO().getDiscountTotalMoney());
//                            return campaignCalViewDTO;
//                        }).collect(Collectors.toList());
//            }
//            productCalViewDTO.setCampaignList(campaignCalList);
//        }
//    }

    private Void validateForCalculate(ServiceContext serviceContext, CampaignGroupSaleGroupCalViewDTO saleGroupCalViewDTO, BizCampaignGroupCalculateWorkflowParam calculateWorkflowParam) {
        BrandSaleGroupBudgetSettingTypeEnum budgetSettingTypeEnum = BrandSaleGroupBudgetSettingTypeEnum.getByCode(saleGroupCalViewDTO.getBudgetSettingType());
        AssertUtil.notNull(budgetSettingTypeEnum,"订单计算预算设置方式不允许为空");
        //订单售卖分组校验
        saleGroupValidateForCalculateAbility.handle(serviceContext, CampaignCalculateAbilityParam.builder().abilityTarget(saleGroupCalViewDTO).packageSaleGroupViewDTO(calculateWorkflowParam.getPackageSaleGroupViewDTO()).campaignGroupViewDTO(calculateWorkflowParam.getCampaignGroupViewDTO()).build());
        //售卖资源产品校验
        saleGroupProductValidateForCalculateAbility.handle(serviceContext, CampaignCalculateAbilityParam.builder().abilityTarget(saleGroupCalViewDTO).packageSaleGroupViewDTO(calculateWorkflowParam.getPackageSaleGroupViewDTO()).build());
        //计划校验
        campaignValidateForCalculateCampaignAbility.handle(serviceContext, CampaignCalculateAbilityParam.builder().abilityTarget(saleGroupCalViewDTO).packageSaleGroupViewDTO(calculateWorkflowParam.getPackageSaleGroupViewDTO()).saleGroupInfoViewDTO(calculateWorkflowParam.getSaleGroupInfoViewDTO()).campaignTreeList(calculateWorkflowParam.getCampaignTreeViewDTOList()).build());
        return null;
    }

    private Void initForCalculate(ServiceContext context, CampaignGroupSaleGroupCalViewDTO saleGroupCalViewDTO, BizCampaignGroupCalculateWorkflowParam calculateWorkflowParam){
        //重试计划预算配置（补全计划数据）
        campaignInitForCalculateCampaignAbility.handle(context, CampaignCalculateAbilityParam.builder().abilityTarget(saleGroupCalViewDTO).campaignTreeList(calculateWorkflowParam.getCampaignTreeViewDTOList()).build());
        //初始化分组预算设置方式
        saleGroupBudgetSettingTypeForUpdateAbility.handle(context, CampaignCalculateAbilityParam.builder().abilityTarget(saleGroupCalViewDTO).packageSaleGroupViewDTO(calculateWorkflowParam.getPackageSaleGroupViewDTO()).build());
        return null;
    }

    /**
     * 更新订单信息
     *
     * @param context
     * @param campaignGroup
     * @param calViewDTO
     * @param campaignGroupSaleGroup
     */
    private void updateCampaignGroupInfos(ServiceContext context, CampaignGroupViewDTO campaignGroup, CampaignGroupSaleGroupCalViewDTO calViewDTO,
                                         ResourcePackageSaleGroupViewDTO saleGroupViewDTO,SaleGroupInfoViewDTO campaignGroupSaleGroup) {

        Map<Long, List<DayPriceViewDTO>> productDayPriceViewDTOMap = BizSaleGroupToolsHelper.getProductDayPriceViewDTOMap(saleGroupViewDTO);
        //构建售卖分组计算信息
        SaleGroupCalculateInfoViewDTO saleGroupCalculateInfoViewDTO = buildSaleGroupCalculateInfoViewDTO(calViewDTO, productDayPriceViewDTOMap);
        updateCheckedPackageProductList(campaignGroup, calViewDTO, saleGroupViewDTO);

        //更新订单售卖分组
        campaignGroupSaleGroup.setBudgetSettingType(saleGroupCalculateInfoViewDTO.getBudgetSettingType());
        campaignGroupSaleGroup.setCalcBudget(saleGroupCalculateInfoViewDTO.getBudget());
        campaignGroupSaleGroup.setUnitPrice(saleGroupCalculateInfoViewDTO.getUnitPrice());
        campaignGroupSaleGroup.setAmount(saleGroupCalculateInfoViewDTO.getAmount());
        campaignGroupSaleGroup.setBudgetSettingType(saleGroupCalculateInfoViewDTO.getBudgetSettingType());
        campaignGroupSaleGroup.setResourcePackageProductViewDTOList(saleGroupCalculateInfoViewDTO.getResourcePackageProductViewDTOList());
        campaignGroupRepository.addOrUpdateSaleGroupPart(context,campaignGroup.getId(), Collections.singletonList(campaignGroupSaleGroup));

        RogerLogger.info("updateCampaignGroupInfos method, before calcCampaignGroupViewDTOTime, campaignGroup: {}", JSON.toJSONString(campaignGroup));
        calcCampaignGroupViewDTOTime(context, campaignGroup);
        RogerLogger.info("updateCampaignGroupInfos method, after calcCampaignGroupViewDTOTime, campaignGroup: {}", JSON.toJSONString(campaignGroup));
        campaignGroupRepository.updateCampaignGroupPart(context, campaignGroup);
    }

    private SaleGroupCalculateInfoViewDTO buildSaleGroupCalculateInfoViewDTO(CampaignGroupSaleGroupCalViewDTO calViewDTO,
                                                                             Map<Long, List<DayPriceViewDTO>> productDayPriceViewDTOMap) {
        SaleGroupCalculateInfoViewDTO saleGroupCalculateInfoViewDTO = new SaleGroupCalculateInfoViewDTO();
        saleGroupCalculateInfoViewDTO.setSaleGroupId(calViewDTO.getSaleGroupId());
        saleGroupCalculateInfoViewDTO.setBudget(calViewDTO.getBudget());
        saleGroupCalculateInfoViewDTO.setAmount(calViewDTO.getAmount());
        saleGroupCalculateInfoViewDTO.setUnitPrice(calViewDTO.getUnitPrice());
        saleGroupCalculateInfoViewDTO.setBudgetSettingType(calViewDTO.getBudgetSettingType());
        List<com.alibaba.ad.brand.dto.campaigngroup.sale.ResourcePackageProductViewDTO> resourcePackageProductViewDTOList = Lists.newArrayList();
        for (ProductCampaignCalViewDTO productCalViewDTO : calViewDTO.getProductCampaignList()) {
            com.alibaba.ad.brand.dto.campaigngroup.sale.ResourcePackageProductViewDTO dto
                    = new com.alibaba.ad.brand.dto.campaigngroup.sale.ResourcePackageProductViewDTO();
            dto.setBudget(productCalViewDTO.getBudget());
            dto.setResourcePackageProductId(productCalViewDTO.getResourcePackageProductId());
            dto.setDiscountDayPriceInfoViewDTOList(productDayPriceViewDTOMap.get(productCalViewDTO.getResourcePackageProductId()));
            resourcePackageProductViewDTOList.add(dto);
        }
        saleGroupCalculateInfoViewDTO.setResourcePackageProductViewDTOList(resourcePackageProductViewDTOList);
        return saleGroupCalculateInfoViewDTO;
    }

    /**
     * 更新该分组下的勾选资源产品ID
     */
    private void updateCheckedPackageProductList(CampaignGroupViewDTO campaignGroup, CampaignGroupSaleGroupCalViewDTO calViewDTO,
                                                 ResourcePackageSaleGroupViewDTO saleGroupViewDTO) {
        List<Long> checkedPackageProductList = calViewDTO.getProductCampaignList().stream().map(
                ProductCampaignCalViewDTO::getResourcePackageProductId).collect(Collectors.toList());
        Set<Long> packageProductSet = getResourcePackageProductList(saleGroupViewDTO).stream().map(ResourcePackageProductViewDTO::getId).collect(
                Collectors.toSet());
        List<Long> dbCheckedPackageProductList = campaignGroup.getCampaignGroupSaleGroupViewDTO().getCheckedResourcePackageProductIdList() == null ? Lists
                .newArrayList() : campaignGroup.getCampaignGroupSaleGroupViewDTO().getCheckedResourcePackageProductIdList();

        dbCheckedPackageProductList = dbCheckedPackageProductList.stream().filter(v -> !packageProductSet.contains(v)).collect(Collectors.toList());
        dbCheckedPackageProductList.addAll(checkedPackageProductList);
        campaignGroup.getCampaignGroupSaleGroupViewDTO().setCheckedResourcePackageProductIdList(dbCheckedPackageProductList);
    }

    public void calcCampaignGroupViewDTOTime(ServiceContext context, CampaignGroupViewDTO campaignGroup) {
        CampaignQueryViewDTO query = new CampaignQueryViewDTO();
        query.setCampaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode());
        query.setCampaignGroupId(campaignGroup.getId());
        List<CampaignViewDTO> campaignViewDTOList = campaignRepository.queryCampaignList(context, query);
        RogerLogger.info("calcCampaignGroupViewDTOTime method, campaignViewDTOList: {}", JSON.toJSONString(campaignViewDTOList));
        Date startTime = campaignViewDTOList.stream().min(Comparator.comparing(campaignViewDTO -> campaignViewDTO.getStartTime())).map(date -> date.getStartTime()).get();
        Date endTime = campaignViewDTOList.stream().max(Comparator.comparing(campaignViewDTO -> campaignViewDTO.getEndTime())).map(date -> date.getEndTime()).get();
        campaignGroup.setStartTime(startTime);
        campaignGroup.setEndTime(endTime);
    }

    private List<ResourcePackageProductViewDTO> getResourcePackageProductList(ResourcePackageSaleGroupViewDTO saleGroupViewDTO) {
        if (saleGroupViewDTO == null || CollectionUtils.isEmpty(saleGroupViewDTO.getDistributionRuleList())) {
            return Lists.newArrayList();
        }
        List<ResourcePackageProductViewDTO> result = Lists.newArrayList();
        for (ResourceDistributionRuleViewDTO ruleViewDTO : saleGroupViewDTO.getDistributionRuleList()) {
            if (CollectionUtils.isEmpty(ruleViewDTO.getResourcePackageProductList())) {
                continue;
            }
            result.addAll(ruleViewDTO.getResourcePackageProductList());
        }
        return result;
    }

    /**
     * 更新订单和勾选的分组
     *
     * @param context
     * @param campaignGroup
     * @param checkedResourceViewDTO
     */
    public void updateCampaignGroupWithCheckedResource(ServiceContext context, CampaignGroupViewDTO campaignGroup, CampaignGroupCheckedResourceViewDTO checkedResourceViewDTO) {
        // 1. 查询资源包分组
        List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupList = findResourcePackageSaleGroupListForUpdateCheckedResources(context, campaignGroup);
        AssertUtil.notNull(campaignGroup,BrandOneBPBaseErrorCode.BIZ_DATA_EMPTY_ERROR, String.format("订单（id=%s）关联售卖分组不存在", checkedResourceViewDTO.getId()));

        // 2. 校验
        // 2-1. 校验订单名称
        campaignGroupNameValidateAbility.handle(context,CampaignGroupNameValidateAbilityParam.builder().abilityTarget(campaignGroup).build());
        // 2-2. 校验唤端
        campaignGroupWakeupValidateForUpdateCheckedResourceAbility.handle(context, CampaignGroupUpdateCheckedResourceAbilityParam.builder()
                .abilityTarget(checkedResourceViewDTO).campaignGroupViewDTO(campaignGroup).build());
        // 2-3. 校验分组
        saleGroupValidateForUpdateCheckedResourceAbility.handle(context, CampaignGroupUpdateCheckedResourceAbilityParam.builder()
                .abilityTarget(checkedResourceViewDTO).campaignGroupViewDTO(campaignGroup).resourcePackageSaleGroupList(resourcePackageSaleGroupList).build());

        // 3. 初始化
        // 3-1. 初始化唤端
        campaignGroupWakeupInitForUpdateCheckedResourceAbility.handle(context, CampaignGroupUpdateCheckedResourceAbilityParam.builder()
                .abilityTarget(checkedResourceViewDTO).campaignGroupViewDTO(campaignGroup).build());
        // 2-3. 初始化分组
        campaignGroupSaleGroupInitForUpdateCheckedResourceAbility.handle(context, CampaignGroupUpdateCheckedResourceAbilityParam.builder()
                .abilityTarget(checkedResourceViewDTO).campaignGroupViewDTO(campaignGroup).resourcePackageSaleGroupList(resourcePackageSaleGroupList).build());

        // 4. 更新
        campaignGroupUpdateCheckedResourceAbility.handle(context, CampaignGroupUpdateCheckedResourceAbilityParam.builder()
                .abilityTarget(checkedResourceViewDTO).campaignGroupViewDTO(campaignGroup).build());
    }

    private List<ResourcePackageSaleGroupViewDTO> findResourcePackageSaleGroupListForUpdateCheckedResources(ServiceContext context, CampaignGroupViewDTO campaignGroup) {
        ResourcePackageQueryViewDTO resourcePackageQueryViewDTO = new ResourcePackageQueryViewDTO();
        resourcePackageQueryViewDTO.setTemplateId(campaignGroup.getCampaignGroupSaleViewDTO().getCustomerTemplateId());
        List<Long> saleGroupIds = campaignGroup.getCampaignGroupSaleGroupViewDTO().getSaleGroupInfoViewDTOList().stream().map(SaleGroupInfoViewDTO::getSaleGroupId).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(saleGroupIds)) {
            resourcePackageQueryViewDTO.setSaleGroupIdList(saleGroupIds);
        }
        return resourcePackageRepository.getSaleGroupList(context, resourcePackageQueryViewDTO, new ResourcePackageQueryOption());
    }
}
