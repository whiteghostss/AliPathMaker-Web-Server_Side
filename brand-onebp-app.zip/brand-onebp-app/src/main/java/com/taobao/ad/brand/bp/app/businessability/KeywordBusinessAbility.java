package com.taobao.ad.brand.bp.app.businessability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.nb.ssp.constant.newproduct.ProductDirectionEnum;
import com.alibaba.ad.nb.tpp.core.stream.TaskStream;
import com.alibaba.fastjson.JSON;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignShowConfigViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.common.threadpooltask.CampaignKeywordUpdateTaskIdentifier;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbilityRouteContext;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.ICampaignUpdateJudgeForUpdateCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.keyword.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignKeywordAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignKeywordSaveAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignTargetShowConfigGetAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignUpdateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.showconfig.ICampaignKeywordTargetBuildForShowConfigGetAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.businessability.ICampaignAddBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.campaign.businessability.ICampaignQueryBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.campaign.businessability.ICampaignUpdateBusinessAbilityPoint;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@BusinessAbility(tag = TargetBusinessAbility.ABILITY_CODE, name = "关键词商业能力", desc = "关键词商业能力结构化实现类")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class KeywordBusinessAbility implements ICampaignQueryBusinessAbilityPoint, ICampaignAddBusinessAbilityPoint, ICampaignUpdateBusinessAbilityPoint{

    public static final String ABILITY_CODE = "BUSINESS_ABILITY_KEYWORD";

    private final ICampaignKeywordTargetBuildForShowConfigGetAbility campaignKeywordTargetBuildForShowConfigGetAbility;
    private final ICampaignUpdateJudgeForUpdateCampaignAbility campaignUpdateJudgeForUpdateCampaignAbility;
    private final ICampaignKeywordValidateForUpdateAbility campaignKeywordValidateForUpdateAbility;
    private final ICampaignKeywordInitAbility campaignKeywordInitAbility;
    private final ICampaignKeywordAccessValidateAbility campaignKeywordAccessValidateAbility;
    private final ICampaignKeywordValidateAbility campaignKeywordValidateAbility;
    private final ICampaignKeywordNormalValidateAbility campaignKeywordNormalValidateAbility;
    private final ICampaignKeywordSaveAbility campaignKeywordSaveAbility;
    private final CampaignKeywordUpdateTaskIdentifier campaignKeywordUpdateTaskIdentifier;

    @Override
    public boolean routeChecking(String bizCode, BaseViewDTO baseViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        RogerLogger.info("keyword routeChecking businessAbilityRouteContext:{}", JSON.toJSONString(businessAbilityRouteContext));
        List<String> specifiedBusinessCodes = businessAbilityRouteContext.getSpecifiedBusinessAbilityCodes();
        if (CollectionUtils.isNotEmpty(specifiedBusinessCodes) && specifiedBusinessCodes.contains(ABILITY_CODE)) {
            return true;

        }
        //关键词定向投放
        List<CommonViewDTO> openTargetList = Optional.ofNullable(businessAbilityRouteContext.getResourcePackageProductViewDTO())
                .map(ResourcePackageProductViewDTO::getTargetList).orElse(Lists.newArrayList());
        if (CollectionUtils.isNotEmpty(openTargetList)) {
            List<CommonViewDTO> keywordTargetList = openTargetList.stream().filter(e-> ProductDirectionEnum.KEYWORD.getType().equals(e.getValue())).collect(Collectors.toList());
            if(CollectionUtils.isNotEmpty(keywordTargetList)){
                return true;
            }
        }
        return false;
    }

    @Override
    public Void invokeForCampaignShowConfigGet(ServiceContext serviceContext, List<CampaignShowConfigViewDTO> showConfigViewDTOList, BusinessAbilityRouteContext routeContext) {
        RogerLogger.info("invokeForCampaignShowConfigGet.showConfigViewDTOList:{}, routeContext:{}", JSON.toJSONString(showConfigViewDTOList), JSON.toJSONString(routeContext));
        Map<String, CommonViewDTO> packageProductTargetMap = Maps.newHashMap();
        if (CollectionUtils.isNotEmpty(routeContext.getResourcePackageProductViewDTO().getTargetList())) {
            packageProductTargetMap = routeContext.getResourcePackageProductViewDTO().getTargetList().stream()
                    .filter(target -> Boolean.TRUE.equals(target.getSelected())).collect(Collectors.toMap(CommonViewDTO::getValue, t -> t, (v1, v2) -> v2));
        }
        CampaignTargetShowConfigGetAbilityParam showConfigGetAbilityParam = CampaignTargetShowConfigGetAbilityParam.builder()
                .abilityTarget(routeContext.getResourcePackageProductViewDTO())
                .productViewDTO(routeContext.getProductViewDTO())
                .resourcePackageSaleGroupViewDTO(routeContext.getPackageSaleGroupViewDTO())
                .packageProductTargetMap(packageProductTargetMap)
                .build();
        //关键词
        CampaignShowConfigViewDTO keywordShowConfigViewDTO = campaignKeywordTargetBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(keywordShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);

        return null;
    }

    @Override
    public Void invokeForCampaignAdd(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        AssertUtil.assertTrue(campaignViewDTO.getCampaignKeywordViewDTO() != null, "关键词人群不能为空");
        CampaignKeywordAbilityParam keywordAbilityParam = CampaignKeywordAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignKeywordViewDTO()).campaignViewDTO(campaignViewDTO).build();
        //基础信息初始化
        campaignKeywordInitAbility.handle(serviceContext, keywordAbilityParam);
        //风控准入校验
        String currAccessMsg = campaignKeywordAccessValidateAbility.handle(serviceContext, keywordAbilityParam);
        AssertUtil.assertTrue(StringUtils.isEmpty(currAccessMsg), "以下关键词不可使用，原因如下：\n" + currAccessMsg);
        //归一化词重复校验
        String currNormalMsg = campaignKeywordNormalValidateAbility.handle(serviceContext, keywordAbilityParam);
        AssertUtil.assertTrue(StringUtils.isEmpty(currNormalMsg), "关键词存在同义词，请调整后重试");
        //关键词数量校验
        campaignKeywordValidateAbility.handle(serviceContext, keywordAbilityParam);
        campaignViewDTO.setCampaignKeywordViewDTO(keywordAbilityParam.getAbilityTarget());
        return null;
    }

    @Override
    public Void invokeForAfterCampaignAdd(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList, BusinessAbilityRouteContext businessAbilityRouteContext) {
        //保存关键词
        campaignKeywordSaveAbility.handle(serviceContext, CampaignKeywordSaveAbilityParam.builder().abilityTargets(campaignViewDTOList).build());
        return null;
    }

    @Override
    public Void invokeForCampaignUpdate(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO,
                                        CampaignViewDTO dbCampaignTreeViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        //计划是否允许修改
        Boolean isCanUpdateCampaign = campaignUpdateJudgeForUpdateCampaignAbility.handle(serviceContext, CampaignUpdateAbilityParam.builder()
                .abilityTarget(campaignViewDTO).dbCampaignViewDTO(dbCampaignTreeViewDTO).build());
        if(Boolean.FALSE.equals(isCanUpdateCampaign)){
            //关键词是否可以修改
            campaignKeywordValidateForUpdateAbility.handle(serviceContext, CampaignKeywordAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignKeywordViewDTO()).campaignViewDTO(campaignViewDTO).build());
        }
        CampaignKeywordAbilityParam keywordAbilityParam = CampaignKeywordAbilityParam.builder().abilityTarget(campaignViewDTO.getCampaignKeywordViewDTO()).campaignViewDTO(campaignViewDTO).build();
        //基础信息初始化
        campaignKeywordInitAbility.handle(serviceContext, keywordAbilityParam);
        //风控准入校验
        String currAccessMsg = campaignKeywordAccessValidateAbility.handle(serviceContext, keywordAbilityParam);
        AssertUtil.assertTrue(StringUtils.isEmpty(currAccessMsg), "以下关键词不可使用，原因如下：\n" + currAccessMsg);
        //归一化词重复校验
        String currNormalMsg = campaignKeywordNormalValidateAbility.handle(serviceContext, keywordAbilityParam);
        AssertUtil.assertTrue(StringUtils.isEmpty(currNormalMsg), "关键词存在同义词，请调整后重试");
        //关键词数量校验
        campaignKeywordValidateAbility.handle(serviceContext, keywordAbilityParam);
        campaignViewDTO.setCampaignKeywordViewDTO(keywordAbilityParam.getAbilityTarget());
        return null;
    }

    @Override
    public Void invokeForAfterCampaignUpdate(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList, BusinessAbilityRouteContext businessAbilityRouteContext) {
        List<Long> campaignIdList = TaskStream.execute(campaignKeywordUpdateTaskIdentifier, campaignViewDTOList, (campaign, index) -> {
            //保存关键词
            campaignKeywordSaveAbility.handle(serviceContext, CampaignKeywordSaveAbilityParam.builder().abilityTargets(Lists.newArrayList(campaign)).build());
            return campaign.getId();
        }).commit().getResultList();
        RogerLogger.info("计划定向更新成功，ids={}", JSON.toJSONString(campaignIdList));
        return null;
    }
}