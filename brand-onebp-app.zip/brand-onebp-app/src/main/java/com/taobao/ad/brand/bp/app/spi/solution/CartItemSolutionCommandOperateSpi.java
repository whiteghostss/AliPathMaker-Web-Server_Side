package com.taobao.ad.brand.bp.app.spi.solution;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.nb.framework.core.AbilityFactory;
import com.alibaba.ad.nb.framework.core.AbilitySpi;
import com.alibaba.ad.nb.framework.core.annotation.Ability;
import com.taobao.ad.brand.bp.client.dto.solution.CartItemSolutionViewDTO;
import com.taobao.ad.brand.bp.client.enums.solution.CartItemSolutionOperateEnum;

@Ability(desc = "自助化操作动作扩展点")
public interface CartItemSolutionCommandOperateSpi extends AbilitySpi {
    // ==================== SPI支持扩展码（CartItemSolutionOperateEnum）===================
    /**
     * 自助化-极简立即下单-保存场景
     */
    String SLIM_SAVE = "SLIM_SAVE";
    /**
     * 自助化-极简自助化-计划修改场景
     */
    String CAMPAIGN_SAVE = "CAMPAIGN_SAVE";

    /**
     * 获取spi扩展code
     * @param cartItemSolutionViewDTO
     * @return
     */
    static String getSpiCode(CartItemSolutionViewDTO cartItemSolutionViewDTO){
        CartItemSolutionOperateEnum operateEnum =
                CartItemSolutionOperateEnum.getOperateEnumByCode(cartItemSolutionViewDTO.getOperate());
        return operateEnum == null ? AbilityFactory.DEFAULT_BIZ_CODE : operateEnum.name();
    }
    /**
     * 新增逻辑校验
     * @param serviceContext
     * @param solutionCommandViewDTO
     * @return
     */
    Void validateForAddCartItemSolution(ServiceContext serviceContext, CartItemSolutionViewDTO solutionCommandViewDTO);
    /**
     * 修改场景校验
     * @param serviceContext
     * @param dbSolutionCommandViewDTO
     * @param solutionCommandViewDTO
     * @return
     */
    Void validateForUpdateCartItemSolution(ServiceContext serviceContext, CartItemSolutionViewDTO dbSolutionCommandViewDTO, CartItemSolutionViewDTO solutionCommandViewDTO);

    /**
     * 底层数据初始化
     * @param serviceContext
     * @param dbSolutionCommandViewDTO
     * @param solutionCommandViewDTO
     * @return
     */
    Void initForUpdateCartItemSolution(ServiceContext serviceContext, CartItemSolutionViewDTO dbSolutionCommandViewDTO, CartItemSolutionViewDTO solutionCommandViewDTO);

    /**
     * 执行修改
     * @param serviceContext
     * @param dbSolutionCommandViewDTO
     * @param solutionCommandViewDTO
     * @return
     */
    Void executeForUpdateCartItemSolution(ServiceContext serviceContext, CartItemSolutionViewDTO dbSolutionCommandViewDTO, CartItemSolutionViewDTO solutionCommandViewDTO);
}
