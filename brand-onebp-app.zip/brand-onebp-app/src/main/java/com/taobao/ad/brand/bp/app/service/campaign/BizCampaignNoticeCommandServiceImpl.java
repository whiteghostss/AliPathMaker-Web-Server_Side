package com.taobao.ad.brand.bp.app.service.campaign;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupBottomTypeEnum;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupOnlineStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignOnlineStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignStatusEnum;
import com.alibaba.ad.brand.sdk.constant.campaigngroup.field.BrandCampaignGroupSourceEnum;
import com.alibaba.ad.brand.sdk.constant.cartitem.BrandCartItemTypeEnum;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.fastjson.JSON;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.tool.lock.annotation.DistLock;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.app.workflow.adgroup.BizAdgroupCommandWorkflow;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignCommandWorkflow;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignInventoryWorkflow;
import com.taobao.ad.brand.bp.client.api.campaign.BizCampaignNoticeCommandService;
import com.taobao.ad.brand.bp.client.context.DomainMetaqMessageBodyContext;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignInquiryOperateViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignEventEnum;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignScheduleOperateTypeEnum;
import com.taobao.ad.brand.bp.client.enums.campaigngroup.CampaignGroupEventEnum;
import com.taobao.ad.brand.bp.client.enums.message.DomainMessageTypeEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.BrandDateUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.adgroup.repository.AdgroupRepository;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.cart.repository.CartItemRepository;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.domain.inventory.InventoryRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.common.util.BrandDateUtil.DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_1;
import static com.taobao.ad.brand.bp.common.util.ServiceContextUtil.ALI_STAFF_BUC_USER_ID;

@HSFProvider(serviceInterface = BizCampaignNoticeCommandService.class)
@RequiredArgsConstructor(onConstructor_ = @Autowired)
public class BizCampaignNoticeCommandServiceImpl implements BizCampaignNoticeCommandService {

    private final CampaignGroupRepository campaignGroupRepository;
    private final CampaignRepository campaignRepository;
    private final AdgroupRepository adgroupRepository;
    private final CartItemRepository cartItemRepository;
    private final BizCampaignCommandWorkflow bizCampaignCommandWorkflow;
    private final BizAdgroupCommandWorkflow bizAdgroupCommandWorkflow;
    private final BizCampaignInventoryWorkflow bizCampaignInventoryWorkflow;
    private final InventoryRepository inventoryRepository;

    @Override
    @DistLock(value = "SUB_CAMPAIGN_GROUP_EVENT_NOTICE,1#getEntityId(),1#getBizCode(),1#getDomainEvent()")
    public Response noticeCampaignGroup(ServiceContext serviceContext, DomainMetaqMessageBodyContext bodyContext) {
        RogerLogger.info("campaign.noticeCampaignGroup serviceContext: {}, bodyContext: {}", JSON.toJSONString(serviceContext), JSON.toJSONString(bodyContext));
        //主订单不处理
        if(!DomainMessageTypeEnum.SUB_CAMPAIGN_GROUP.equals(bodyContext.getDomainType())){
            return Response.success();
        }
        //新建订单直接走新增的逻辑
        if (CampaignGroupEventEnum.CREATE.name().equals(bodyContext.getDomainEvent())) {
            if(BizCodeEnum.SELFSERVICEAD.getBizCode().equals(serviceContext.getBizCode())){
                selfServiceOrder(serviceContext,bodyContext);
            } else {
                autoCreateCampaigns(serviceContext, bodyContext);
            }
            return Response.success();
        }

        if (CampaignGroupEventEnum.UPDATE.name().equals(bodyContext.getDomainEvent())) {
            if (BizCodeEnum.IPMARKETINGAD.getBizCode().equals(serviceContext.getBizCode())) {
                autoCreateCampaigns(serviceContext, bodyContext);
            } else if (!BizCodeEnum.SELFSERVICEAD.getBizCode().equals(serviceContext.getBizCode())) {
                //更新需要先diff然后做相应处理
                autoSaveCampaigns(serviceContext, bodyContext);
            }
        }

        return Response.success();
    }

    @Override
    @DistLock(value = "MAIN_CAMPAIGN_ADD_ALGO_CROWD_NOTICE,1#getEntityId(),1#getBizCode(),1#getDomainEvent()")
    public Response noticeCampaignAddAlgoCrowd(ServiceContext serviceContext, DomainMetaqMessageBodyContext bodyContext) {
        //只处理主计划
        if(!DomainMessageTypeEnum.MAIN_CAMPAIGN.equals(bodyContext.getDomainType())){
            return Response.success();
        }
        // 只需要处理这三个事件
        if (!CampaignEventEnum.CREATE.name().equals(bodyContext.getDomainEvent())
                && !CampaignEventEnum.UPDATE.name().equals(bodyContext.getDomainEvent())
                && !CampaignEventEnum.REAL_TIME_OPTIMIZE_CONFIG.name().equals(bodyContext.getDomainEvent())) {
            return Response.success();
        }
        Long campaignId = bodyContext.getEntityId();
        AssertUtil.notNull(campaignId , "计划ID不能为空");
        serviceContext = ServiceContextUtil.buildServiceContextForBizCode(serviceContext.getMemberId(), serviceContext.getBizCode());
        bizCampaignCommandWorkflow.addCampaignAlgoControlCrowd(serviceContext, campaignId);
        return Response.success();
    }

    @Override
    @DistLock(value = "MAIN_CAMPAIGN_EVENT_NOTICE,1#getEntityId(),1#getBizCode(),1#getDomainEvent()")
    public Response noticeCampaign(ServiceContext serviceContext, DomainMetaqMessageBodyContext bodyContext) {
        //只处理主计划
        if(!DomainMessageTypeEnum.MAIN_CAMPAIGN.equals(bodyContext.getDomainType())){
            return Response.success();
        }
        Long campaignId = bodyContext.getEntityId();
        AssertUtil.notNull(campaignId , "计划ID不能为空");
        serviceContext = ServiceContextUtil.buildServiceContextForBizCode(serviceContext.getMemberId(), serviceContext.getBizCode());
        // 设置阿里小二key
        serviceContext.getExt().put(ALI_STAFF_BUC_USER_ID, serviceContext.getMemberId());
        CampaignViewDTO campaignViewDTO =  campaignRepository.getCampaignById(serviceContext,campaignId);
        AssertUtil.notNull(campaignViewDTO,"计划不能为空");

        if (CampaignEventEnum.CREATE.name().equals(bodyContext.getDomainEvent())) {
            if( BizCodeEnum.SELFSERVICEAD.getBizCode().equals(serviceContext.getBizCode())){
                //自助化新建未下单计划后需要做询量/极简版要锁量
                if(BrandCampaignOnlineStatusEnum.DRAFT.getCode().equals(campaignViewDTO.getOnlineStatus())){
                    RogerLogger.info("cost time campaign {} lock start : {}", campaignViewDTO.getId(), BrandDateUtil.date2String(new Date(), DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_1));
                    CartItemViewDTO cartItemViewDTO = cartItemRepository.getCartById(serviceContext, campaignViewDTO.getCampaignSelfServiceViewDTO().getCartItemId());
                    CampaignInquiryOperateViewDTO campaignInquiryOperateViewDTO = new  CampaignInquiryOperateViewDTO();
                    if (BrandCartItemTypeEnum.SLIM_ORDER.getCode().equals(cartItemViewDTO.getType())) {
                        campaignInquiryOperateViewDTO.setOperateType(CampaignScheduleOperateTypeEnum.LOCK.getValue());
                    } else {
                        campaignInquiryOperateViewDTO.setOperateType(CampaignScheduleOperateTypeEnum.INQUIRY.getValue());
                    }
                    campaignInquiryOperateViewDTO.setCampaignIdList(Lists.newArrayList(campaignId));
                    bizCampaignInventoryWorkflow.inventoryInquiryOrLock(serviceContext,campaignInquiryOperateViewDTO);
                    RogerLogger.info("cost time campaign {} lock end : {}", campaignViewDTO.getId(), BrandDateUtil.date2String(new Date(), DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_1));
                }
            }

            return Response.success();
        }
        if (CampaignEventEnum.UPDATE.name().equals(bodyContext.getDomainEvent())){
            if( BizCodeEnum.SELFSERVICEAD.getBizCode().equals(serviceContext.getBizCode())){
                CampaignInquiryOperateViewDTO campaignInquiryOperateViewDTO = new  CampaignInquiryOperateViewDTO();
                campaignInquiryOperateViewDTO.setCampaignIdList(Lists.newArrayList(campaignId));
                CartItemViewDTO cartItemViewDTO = cartItemRepository.getCartById(serviceContext, campaignViewDTO.getCampaignSelfServiceViewDTO().getCartItemId());
                // 兼容逻辑：原则上不会出现此情况
                if (BrandCartItemTypeEnum.SLIM_ORDER.getCode().equals(cartItemViewDTO.getType())) {
                    campaignInquiryOperateViewDTO.setOperateType(CampaignScheduleOperateTypeEnum.LOCK.getValue());
                } else {
                    //自助化编辑未下单计划后需要做询量
                    if(BrandCampaignOnlineStatusEnum.DRAFT.getCode().equals(campaignViewDTO.getOnlineStatus())){
                        campaignInquiryOperateViewDTO.setOperateType(CampaignScheduleOperateTypeEnum.INQUIRY.getValue());
                    }
                    //自助化编辑已下单计划后需要做锁量
                    if(BrandCampaignOnlineStatusEnum.ONLINE.getCode().equals(campaignViewDTO.getOnlineStatus())){
                        campaignInquiryOperateViewDTO.setOperateType(CampaignScheduleOperateTypeEnum.LOCK.getValue());
                    }
                }

                bizCampaignInventoryWorkflow.inventoryInquiryOrLock(serviceContext,campaignInquiryOperateViewDTO);
            }
        }
        //极简版计划上线，草稿状态打底单元自动上线
        if (CampaignEventEnum.CAMPAIGN_GROUP_ONLINE.name().equals(bodyContext.getDomainEvent())){
            if(BizCodeEnum.SELFSERVICEAD.getBizCode().equals(serviceContext.getBizCode())){
                if(BizCampaignToolsHelper.isSlimOrderCampaign(campaignViewDTO)){
                    AdgroupQueryViewDTO adgroupQueryViewDTO = new AdgroupQueryViewDTO();
                    adgroupQueryViewDTO.setBottomType(BrandAdgroupBottomTypeEnum.BOTTOM.getCode());
                    adgroupQueryViewDTO.setCampaignId(campaignViewDTO.getId());
                    List<AdgroupViewDTO> adgroupViewDTOList = adgroupRepository.queryAdgroupBasicListNoPage(serviceContext, adgroupQueryViewDTO);
                    List<Long> draftAdgroupIdList = Optional.ofNullable(adgroupViewDTOList).orElse(Lists.newArrayList()).stream()
                            .filter(adgroupViewDTO -> BrandAdgroupOnlineStatusEnum.DRAFT.getCode().equals(adgroupViewDTO.getOnlineStatus()))
                            .map(AdgroupViewDTO::getId).collect(Collectors.toList());
                    RogerLogger.info("极简版计划下打底单元自动上线，campaignId={}，adgroupIds={}",
                            campaignViewDTO.getId(),JSON.toJSONString(draftAdgroupIdList));
                    if(CollectionUtils.isNotEmpty(draftAdgroupIdList)){
                        bizAdgroupCommandWorkflow.batchSetAdgroupOnline(serviceContext,draftAdgroupIdList);
                    }
                }
            }
        }
        if (CampaignEventEnum.DELETE.name().equals(bodyContext.getDomainEvent())){
            if( BizCodeEnum.SELFSERVICEAD.getBizCode().equals(serviceContext.getBizCode())){
                //自助化编辑未下单计划后需要做询量
                if(BrandCampaignStatusEnum.LOCKING.getCode().equals(campaignViewDTO.getStatus())){
                    inventoryRepository.cancel(serviceContext,campaignViewDTO);
                }
                //自助化编辑已下单计划后需要做锁量
                if(BrandCampaignStatusEnum.LOCK_SUCCESS.getCode().equals(campaignViewDTO.getStatus())){
                    inventoryRepository.release(serviceContext,campaignViewDTO);
                }
            }
        }
        // 对于IP营销业务场景，自动创建的计划完成自动预算分配后，开始进行自动锁量
        if (CampaignEventEnum.AUTO_BUDGET_ALLOCATION.name().equals(bodyContext.getDomainEvent())) {
            if (BizCodeEnum.IPMARKETINGAD.getBizCode().equals(serviceContext.getBizCode())){
                CampaignInquiryOperateViewDTO campaignInquiryOperateViewDTO = new  CampaignInquiryOperateViewDTO();
                campaignInquiryOperateViewDTO.setOperateType(CampaignScheduleOperateTypeEnum.LOCK.getValue());
                campaignInquiryOperateViewDTO.setCampaignIdList(Lists.newArrayList(campaignId));
                bizCampaignInventoryWorkflow.inventoryInquiryOrLock(serviceContext,campaignInquiryOperateViewDTO);
                RogerLogger.info("cost time campaign {} lock end : {}", campaignViewDTO.getId(), BrandDateUtil.date2String(new Date(), DATE_FORMAT_YYYYMMDDHHMMSS_TYPE_1));
            }
            return Response.success();
        }
        return Response.success();
    }

    private void selfServiceOrder(ServiceContext serviceContext, DomainMetaqMessageBodyContext bodyContext) {
        Long campaignGroupId = bodyContext.getEntityId();
        AssertUtil.assertTrue(campaignGroupId != null, "订单ID不能为空");
        serviceContext = ServiceContextUtil.buildServiceContextForBizCode(serviceContext.getMemberId(), serviceContext.getBizCode());
        // 设置阿里小二key
        serviceContext.getExt().put(ALI_STAFF_BUC_USER_ID, serviceContext.getMemberId());
        CampaignGroupViewDTO campaignGroupViewDTO = getCampaignGroup(serviceContext, campaignGroupId);
        AssertUtil.assertTrue(campaignGroupViewDTO != null, "订单" +campaignGroupId + " 不存在");
        // 非极简的自助执行
        if (BrandCampaignGroupSourceEnum.CART.getCode().equals(campaignGroupViewDTO.getSource())) {
            Response response = bizCampaignCommandWorkflow.selfServiceOrder(serviceContext, campaignGroupViewDTO);
            AssertUtil.assertTrue(response.isSuccess(), "更新计划失败");
        }
    }

    private void autoSaveCampaigns(ServiceContext serviceContext, DomainMetaqMessageBodyContext bodyContext) {
        Long campaignGroupId = bodyContext.getEntityId();
        AssertUtil.assertTrue(campaignGroupId != null, "订单ID不能为空");
        serviceContext = ServiceContextUtil.buildServiceContextForBizCode(serviceContext.getMemberId(), serviceContext.getBizCode());
        // 设置阿里小二key
        serviceContext.getExt().put(ALI_STAFF_BUC_USER_ID, serviceContext.getMemberId());
        CampaignGroupViewDTO campaignGroupViewDTO = getCampaignGroup(serviceContext, campaignGroupId);
        bizCampaignCommandWorkflow.autoUpdateCampaign(serviceContext, campaignGroupViewDTO);
    }

    private void autoCreateCampaigns(ServiceContext serviceContext, DomainMetaqMessageBodyContext bodyContext){
        Long campaignGroupId = bodyContext.getEntityId();
        AssertUtil.assertTrue(campaignGroupId != null, "订单ID不能为空");
        serviceContext = ServiceContextUtil.buildServiceContextForBizCode(serviceContext.getMemberId(), serviceContext.getBizCode());
        // 设置阿里小二key
        serviceContext.getExt().put(ALI_STAFF_BUC_USER_ID, serviceContext.getMemberId());
        CampaignGroupViewDTO campaignGroupViewDTO = getCampaignGroup(serviceContext, campaignGroupId);
        bizCampaignCommandWorkflow.autoAddCampaign(serviceContext, campaignGroupViewDTO);
    }

    private CampaignGroupViewDTO getCampaignGroup(ServiceContext serviceContext, Long campaignGroupId) {
        CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupRepository.getCampaignGroup(serviceContext, campaignGroupId);
        RogerLogger.info("campaignGroupViewDTO:{}", JSON.toJSONString(campaignGroupViewDTO));
        AssertUtil.assertTrue(campaignGroupViewDTO != null, "订单" +campaignGroupId + " 不存在");
        return campaignGroupViewDTO;
    }
}
