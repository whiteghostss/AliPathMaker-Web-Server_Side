package com.taobao.ad.brand.bp.app.service.mediafreq;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.media.freq.MediaFreqViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.api.mediafreq.BizMediaFreqCommandService;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.mediafreq.MediaFreqRepository;
import com.taobao.ad.brand.bp.domain.mediafreq.ability.MediaFreqAbility;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * 媒体频控command服务
 *
 * @author shiyan
 * @date 2023/7/20
 **/
@HSFProvider(serviceInterface = BizMediaFreqCommandService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizMediaFreqCommandServiceImpl implements BizMediaFreqCommandService {

    private final MediaFreqRepository mediaFreqRepository;
    private final MediaFreqAbility mediaFreqAbility;

    @Override
    public SingleResponse<Long> addMediaFreq(ServiceContext context, MediaFreqViewDTO viewDTO) {
        AssertUtil.notNull(viewDTO, "参数不允许为空");
        mediaFreqAbility.validateMediaFreq(context, viewDTO, null);
        mediaFreqAbility.initMediaFreq(context,viewDTO,null);
        Long freqId = mediaFreqRepository.addMediaFreq(context, viewDTO);
        return SingleResponse.of(freqId);
    }

    @Override
    public SingleResponse<Integer> updateMediaFreq(ServiceContext context, MediaFreqViewDTO viewDTO) {
        AssertUtil.notNull(Optional.ofNullable(viewDTO).map(MediaFreqViewDTO::getId).orElse(null),"媒体频控id不允许为空");
        MediaFreqViewDTO mediaFreq = mediaFreqRepository.getMediaFreq(context, viewDTO.getId());
        AssertUtil.notNull(mediaFreq,String.format("媒体频控不存在，id=%s",viewDTO.getId()));
        mediaFreqAbility.validateMediaFreq(context, viewDTO, mediaFreq);
        mediaFreqAbility.initMediaFreq(context,viewDTO,mediaFreq);
        Integer count = mediaFreqRepository.updateMediaFreq(context, viewDTO);
        return SingleResponse.of(count);
    }

    @Override
    public SingleResponse<Integer> updateMediaFreqStatus(ServiceContext context, List<Long> ids, Integer status) {
        AssertUtil.notEmpty(ids, "媒体频控ids不允许为空");
        AssertUtil.notNull(BrandBoolEnum.getByCode(status), "操作状态不合法");
        Integer count = mediaFreqRepository.updateMediaFreqStatus(context, ids, status);
        return SingleResponse.of(count);
    }
}