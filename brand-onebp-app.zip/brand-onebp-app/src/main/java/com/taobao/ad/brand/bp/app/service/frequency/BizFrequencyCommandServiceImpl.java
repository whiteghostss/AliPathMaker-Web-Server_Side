package com.taobao.ad.brand.bp.app.service.frequency;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.isolation.utils.AbilityInvoker;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.frequency.FrequencyViewDTO;
import com.alibaba.ad.brand.sdk.constant.frequency.field.BrandFrequencyBizTypeEnum;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.Response;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.app.businessability.FreqBusinessAbility;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignCommandWorkflow;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignQueryWorkflow;
import com.taobao.ad.brand.bp.client.api.frequency.BizFrequencyCommandService;
import com.taobao.ad.brand.bp.client.dto.adgroup.query.AdgroupQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.FrequencyRefViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.adgroup.repository.AdgroupRepository;
import com.taobao.ad.brand.bp.domain.frequency.ability.BizFrequencyAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.businessability.IAdgroupBindBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.businessability.IAdgroupRelieveBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbilityRouteContext;
import com.taobao.ad.brand.bp.domain.sdk.campaign.businessability.ICampaignBindBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.campaign.businessability.ICampaignRelieveBusinessAbilityPoint;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

import static com.alibaba.abf.isolation.utils.AbilityInvoker.invokeAll;
import static com.taobao.ad.brand.bp.client.error.BrandOneBPBaseErrorCode.PARAM_ILLEGAL;


/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/1/16
 **/
@HSFProvider(serviceInterface = BizFrequencyCommandService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizFrequencyCommandServiceImpl implements BizFrequencyCommandService {
    private final BizFrequencyAbility bizFrequencyAbility;
    private final AdgroupRepository adgroupRepository;
    private final BizCampaignQueryWorkflow bizCampaignQueryWorkflow;
    private final BizCampaignCommandWorkflow bizCampaignCommandWorkflow;
    @Override
    public SingleResponse<Long> saveDeliveredFrequency(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO, List<Long> campaignIdList) {
        Long freqId = bizCampaignCommandWorkflow.saveDeliveredFrequency(serviceContext, frequencyViewDTO, campaignIdList);
        return SingleResponse.of(freqId);
    }

    @Override
    public SingleResponse<Long> saveOptimizedFrequency(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO, List<Long> adgroupIdList) {
        // 基础校验
        AssertUtil.notNull(frequencyViewDTO.getFreqName(), PARAM_ILLEGAL,"频控名称不能为空");
        AssertUtil.notNull(frequencyViewDTO.getFrequencyTarget(), PARAM_ILLEGAL,"保量性质不能为空");
        AssertUtil.notNull(frequencyViewDTO.getFrequencyRuleViewDTOList(),PARAM_ILLEGAL, "频控规则不能为空");
        // 1. 查询参数
        // 查询单元
        List<AdgroupViewDTO> adgroupViewDTOList = Lists.newArrayList();
        if (CollectionUtils.isNotEmpty(adgroupIdList)) {
            AdgroupQueryViewDTO adgroupQueryViewDTO = new AdgroupQueryViewDTO();
            adgroupQueryViewDTO.setIds(adgroupIdList);
            adgroupViewDTOList =  adgroupRepository.queryAdgroupListNoPage(serviceContext, adgroupQueryViewDTO);
            AssertUtil.assertTrue(CollectionUtils.isNotEmpty(adgroupViewDTOList), "单元不存在");
        }
        // 查询频控 和 频控与单元关联关系
        FrequencyViewDTO dbFrequency = null;
        FrequencyRefViewDTO dbFrequencyRef = null;
        if (frequencyViewDTO.getId() != null) {
            dbFrequency = bizFrequencyAbility.getFrequencyById(serviceContext, frequencyViewDTO.getId());
            AssertUtil.notNull(dbFrequency, "频控信息不存在");
            dbFrequencyRef = bizFrequencyAbility.findFrequencyRefByFreqId(serviceContext, frequencyViewDTO.getId(), BrandFrequencyBizTypeEnum.ADGROUP);
        }

        // 业务校验
        bizFrequencyAbility.validateSaveOptimizedFrequency(serviceContext, frequencyViewDTO, adgroupViewDTOList);
        // 保存
        Long freqId = doSaveOptimizedFrequency(serviceContext, frequencyViewDTO, adgroupViewDTOList, dbFrequencyRef, dbFrequency);
        return SingleResponse.of(freqId);
    }

    private Long doSaveOptimizedFrequency(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO, List<AdgroupViewDTO> adgroupViewDTOList, FrequencyRefViewDTO dbFrequencyRef, FrequencyViewDTO dbFrequency) {
        // 新增场景
        if (frequencyViewDTO.getId() == null) {
            return bizFrequencyAbility.addFrequency(serviceContext, frequencyViewDTO, null, adgroupViewDTOList);
        }
        // 更新场景
        // 需要删除不再本次中的adgroup ref
        bizFrequencyAbility.deleteOtherFrequencyAdgroupRef(serviceContext, dbFrequencyRef, adgroupViewDTOList);
        // 执行更新
        bizFrequencyAbility.updateFrequency(serviceContext, frequencyViewDTO, dbFrequency, null, adgroupViewDTOList);

        return frequencyViewDTO.getId();
    }

    @Override
    public Response frequencySwitch(ServiceContext serviceContext, FrequencyViewDTO frequencyViewDTO) {
        bizCampaignCommandWorkflow.frequencySwitch(serviceContext, frequencyViewDTO);
        return Response.success();
    }

    @Override
    public Response bindFrequency(ServiceContext serviceContext, FrequencyRefViewDTO frequencyRefViewDTO) {
        AssertUtil.notNull(frequencyRefViewDTO.getFreqId(), PARAM_ILLEGAL,"频控id不能为空");
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(frequencyRefViewDTO.getAdgroupIdList()) || CollectionUtils.isNotEmpty(frequencyRefViewDTO.getCampaignIdList()), PARAM_ILLEGAL,"未传入绑定实体id");
        // 商业能力显式挂载
        BusinessAbilityRouteContext businessAbilityRouteContext = BusinessAbilityRouteContext.builder().specifiedBusinessAbilityCodes(Lists.newArrayList(FreqBusinessAbility.ABILITY_CODE)).build();
        if (CollectionUtils.isNotEmpty(frequencyRefViewDTO.getCampaignIdList())) {
            List<CampaignViewDTO> campaignViewDTOList = bizCampaignQueryWorkflow.getCampaignInfoListByOption(serviceContext,
                    CampaignQueryViewDTO.builder().campaignIds(frequencyRefViewDTO.getCampaignIdList()).build(), CampaignQueryOption.builder().needChildren(true).needCampaignTree(true).build());
            AbilityInvoker.invokeAll(ICampaignBindBusinessAbilityPoint.class, businessAbilityRouteContext,
                    callBack -> callBack.invokeForCampaignBind(serviceContext, campaignViewDTOList, frequencyRefViewDTO.getFreqId(), businessAbilityRouteContext));
        }
        if (CollectionUtils.isNotEmpty(frequencyRefViewDTO.getAdgroupIdList())) {
            AdgroupQueryViewDTO adgroupQueryViewDTO = new AdgroupQueryViewDTO();
            adgroupQueryViewDTO.setIds(frequencyRefViewDTO.getAdgroupIdList());
            List<AdgroupViewDTO> adgroupViewDTOList = adgroupRepository.queryAdgroupBasicListNoPage(serviceContext, adgroupQueryViewDTO);
            //商业能力挂载
            AbilityInvoker.invokeAll(IAdgroupBindBusinessAbilityPoint.class, businessAbilityRouteContext,
                    callback -> callback.invokeForAdgroupBind(serviceContext, adgroupViewDTOList, frequencyRefViewDTO.getFreqId(),businessAbilityRouteContext));
        }
        return Response.success();
    }

    @Override
    public Response relieveFrequency(ServiceContext serviceContext, FrequencyRefViewDTO frequencyRefViewDTO) {
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(frequencyRefViewDTO.getAdgroupIdList()) || CollectionUtils.isNotEmpty(frequencyRefViewDTO.getCampaignIdList()), PARAM_ILLEGAL,"未传入解绑实体id");
        BusinessAbilityRouteContext businessAbilityRouteContext = BusinessAbilityRouteContext.builder().specifiedBusinessAbilityCodes(Lists.newArrayList(FreqBusinessAbility.ABILITY_CODE)).build();
        if (CollectionUtils.isNotEmpty(frequencyRefViewDTO.getCampaignIdList())) {
            List<CampaignViewDTO> campaignViewDTOList = bizCampaignQueryWorkflow.getCampaignInfoListByOption(serviceContext,
                    CampaignQueryViewDTO.builder().campaignIds(frequencyRefViewDTO.getCampaignIdList()).build(), CampaignQueryOption.builder().needChildren(true).needCampaignTree(true).build());
            invokeAll(ICampaignRelieveBusinessAbilityPoint.class, businessAbilityRouteContext,
                    callBack -> callBack.invokeForCampaignRelieve(serviceContext, campaignViewDTOList , businessAbilityRouteContext));
        }
        if (CollectionUtils.isNotEmpty(frequencyRefViewDTO.getAdgroupIdList())) {
            AdgroupQueryViewDTO adgroupQueryViewDTO = new AdgroupQueryViewDTO();
            adgroupQueryViewDTO.setIds(frequencyRefViewDTO.getAdgroupIdList());
            List<AdgroupViewDTO> adgroupViewDTOList = adgroupRepository.queryAdgroupBasicListNoPage(serviceContext, adgroupQueryViewDTO);
            invokeAll(IAdgroupRelieveBusinessAbilityPoint.class, businessAbilityRouteContext,
                    callBack -> callBack.invokeForAdgroupRelieve(serviceContext, adgroupViewDTOList, businessAbilityRouteContext));
        }
        return Response.success();
    }
}
