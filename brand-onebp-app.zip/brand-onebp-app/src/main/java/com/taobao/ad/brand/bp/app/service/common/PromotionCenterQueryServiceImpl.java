package com.taobao.ad.brand.bp.app.service.common;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.fastjson.JSON;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.client.api.common.PromotionCenterQueryService;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.sellercoupons.SellerCouponViewDTO;
import com.taobao.ad.brand.bp.client.dto.sellercoupons.SellerCouponsQueryViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.promotion.PromotionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @Author: PhilipFry
 * @createTime: 2023年09月14日 13:41:04
 * @Description:
 */

@HSFProvider(serviceInterface = PromotionCenterQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class PromotionCenterQueryServiceImpl implements PromotionCenterQueryService {

    private final PromotionRepository promotionRepository;

    @Override
    public MultiResponse<SellerCouponViewDTO> querySellerCouponsList(ServiceContext context, SellerCouponsQueryViewDTO queryViewDTO) {
        RogerLogger.info("querySellerCouponsList SellerCouponsQueryViewDTO:{}", JSON.toJSONString(queryViewDTO));

        AssertUtil.notNull(queryViewDTO.getSellerId(), "商家ID不能为空");
        PageResultViewDTO<SellerCouponViewDTO> pageResultViewDTO = promotionRepository.querySellerCouponsList(context, queryViewDTO);
        return MultiResponse.of(pageResultViewDTO.getList(), pageResultViewDTO.getCount());
    }
}
