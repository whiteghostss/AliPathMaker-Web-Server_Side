package com.taobao.ad.brand.bp.app.service.shopwindow;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.taobao.ad.brand.bp.client.api.shopwindow.BizBrandSpuQueryService;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSpuViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.query.BrandSpuQueryViewDTO;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CustomerRepository;
import com.taobao.ad.brand.bp.domain.sdk.shopwindow.atomability.param.SkuSspProductLineAuthJudgeAbilityParam;
import com.taobao.ad.brand.bp.domain.shopwindow.atomability.DefaultSkuSspProductLineAuthJudgeAbility;
import com.taobao.ad.brand.bp.domain.shopwindow.repository.BrandSpuRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * @Description
 * @Author xiaoduo
 * @Date 2024/6/26
 **/
@HSFProvider(serviceInterface = BizBrandSpuQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizBrandSpuQueryServiceImpl implements BizBrandSpuQueryService {

    private final BrandSpuRepository brandSpuRepository;

    private final CustomerRepository customerRepository;

    private final DefaultSkuSspProductLineAuthJudgeAbility defaultSkuSspProductLineAuthJudgeAbility;

    @Override
    public MultiResponse<BrandSpuViewDTO> queryBrandSpuList(ServiceContext serviceContext, BrandSpuQueryViewDTO queryViewDTO) {
        List<BrandSpuViewDTO> brandSpuViewDTOList = brandSpuRepository.findSpuList(serviceContext, queryViewDTO);
        // 列表页与详情页统一调此服务
        // 非登录态不进行ssp产品线校验
        if (hasLogin(serviceContext) && Objects.nonNull(queryViewDTO.getNeedSspProductLineAuthJudge()) && queryViewDTO.getNeedSspProductLineAuthJudge()) {
            for (BrandSpuViewDTO brandSpuViewDTO : brandSpuViewDTOList) {
                if (CollectionUtils.isNotEmpty(brandSpuViewDTO.getSkuList())) {
                    Map<Long, Boolean> checkResult = defaultSkuSspProductLineAuthJudgeAbility.handle(serviceContext, SkuSspProductLineAuthJudgeAbilityParam.builder().abilityTargets(brandSpuViewDTO.getSkuList()).build());
                    // 对于0元试用spu，无需ssp产品线准入校验，默认设置为false，其余类型spu保持现状即需要进行准入校验
                    brandSpuViewDTO.getSkuList().forEach(it -> it.setAuthJudge(checkResult.getOrDefault(it.getSspProductUuid(), false)));
                }
            }
        }
        return MultiResponse.of(brandSpuViewDTOList);
    }

    @Override
    public SingleResponse<Integer> judgeCustomerType(ServiceContext serviceContext, Long customerMemberId) {
        if (customerMemberId == null) {
            return SingleResponse.of(null);
        }
        Integer customerType = customerRepository.getCustomerType(customerMemberId);
        return SingleResponse.of(customerType);
    }

    /**
     * 通过ServiceContext中的内容判断是否已经登入到投放账号
     *
     * @param serviceContext
     * @return
     */
    private static boolean hasLogin(ServiceContext serviceContext) {
        return serviceContext.getMemberId() != null;
    }
}
