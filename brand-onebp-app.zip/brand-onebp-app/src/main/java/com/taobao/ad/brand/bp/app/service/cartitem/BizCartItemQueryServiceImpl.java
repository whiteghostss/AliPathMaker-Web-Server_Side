package com.taobao.ad.brand.bp.app.service.cartitem;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.cartitem.CartItemViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.cartitem.BrandCartItemStatusEnum;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.app.workflow.cartitem.BizCartItemCommandWorkflow;
import com.taobao.ad.brand.bp.client.api.cart.BizCartItemQueryService;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.cartitem.CartItemConsistencyCheckResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.cartitem.CartItemOrderViewDTO;
import com.taobao.ad.brand.bp.client.dto.cartitem.query.CartItemQueryOption;
import com.taobao.ad.brand.bp.client.dto.cartitem.query.CartItemQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.rule.RuleCheckResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.shopwindow.BrandSkuViewDTO;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.cart.repository.CartItemRepository;
import com.taobao.ad.brand.bp.common.helper.campaign.BizCampaignToolsHelper;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.shopwindow.repository.BrandSkuRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * 单元相关的查询实现
 * @author 弈云
 * @date 2023年03月08日
 */
@HSFProvider(serviceInterface = BizCartItemQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizCartItemQueryServiceImpl implements BizCartItemQueryService {

    private final BrandSkuRepository brandSkuRepository;
    private final CartItemRepository cartItemRepository;
    private final ICampaignStructureQueryAbility campaignStructureQueryAbility;
    private final BizCartItemCommandWorkflow bizCartItemCommandWorkflow;

    @Override
    public MultiResponse<CartItemViewDTO> findCartItemList(ServiceContext context, CartItemQueryViewDTO query, CartItemQueryOption queryOption) {
        List<CartItemViewDTO> cartList = cartItemRepository.findCartList(context, query);
        return MultiResponse.of(cartList);
    }

    @Override
    public SingleResponse<CartItemViewDTO> getCartItemById(ServiceContext context, Long id, Integer type) {
        CartItemQueryViewDTO queryViewDTO = CartItemQueryViewDTO.builder().idList(Collections.singletonList(id)).type(type).build();
        List<CartItemViewDTO> cartList = cartItemRepository.findCartList(context, queryViewDTO);
        if(CollectionUtils.isEmpty(cartList)){
            return SingleResponse.of(null);
        }
        return SingleResponse.of(cartList.get(0));
    }

    @Override
    public MultiResponse<RuleCheckResultViewDTO> checkCartItemOrder(ServiceContext context, CartItemOrderViewDTO cartItemOrderViewDTO) {
        List<Long> ids = Optional.ofNullable(cartItemOrderViewDTO).map(CartItemOrderViewDTO::getCartItemIds).orElse(Lists.newArrayList());
        AssertUtil.notEmpty(ids,"加购行ID不允许为空");
        CartItemQueryViewDTO queryViewDTO = CartItemQueryViewDTO.builder().idList(ids)
                .statusList(Collections.singletonList(BrandCartItemStatusEnum.ORDER_WAIT.getCode())).build();
        List<CartItemViewDTO> cartItemViewDTOList = cartItemRepository.findCartList(context, queryViewDTO);
        AssertUtil.notEmpty(cartItemViewDTOList,"加购行不存在");

        CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder().cartItemIds(cartItemViewDTOList.stream().map(CartItemViewDTO::getId).collect(Collectors.toList()))
                .campaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode()).onlineStatusList(BizCampaignToolsHelper.getCampaignOnlineStatusList()).build();

        List<CampaignViewDTO> campaignViewDTOList = campaignStructureQueryAbility.handle(context,
                CampaignStructureQueryAbilityParam.builder().abilityTarget(campaignQueryViewDTO).queryOption(CampaignQueryOption.builder().needTarget(true).build()).build());

        List<RuleCheckResultViewDTO> ruleCheckResultViewDTOList = bizCartItemCommandWorkflow.checkCartItemOrder(context, cartItemViewDTOList, campaignViewDTOList);

        return MultiResponse.of(ruleCheckResultViewDTOList);
    }

    @Override
    public MultiResponse<CartItemConsistencyCheckResultViewDTO> checkCartItemConsistency(ServiceContext context, List<Long> ids) {
        AssertUtil.notEmpty(ids,"加购行ID不允许为空");
        List<CartItemViewDTO> cartItemViewDTOList = cartItemRepository.findCartList(context, CartItemQueryViewDTO.builder().idList(ids).build());
        AssertUtil.notEmpty(cartItemViewDTOList,"加购行不存在");

        CampaignQueryViewDTO campaignQueryViewDTO = CampaignQueryViewDTO.builder().cartItemIds(cartItemViewDTOList.stream().map(CartItemViewDTO::getId).collect(Collectors.toList()))
                .campaignLevel(BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode()).onlineStatusList(BizCampaignToolsHelper.getCampaignOnlineStatusList()).build();

        List<CampaignViewDTO> campaignViewDTOList = campaignStructureQueryAbility.handle(context,
                CampaignStructureQueryAbilityParam.builder().abilityTarget(campaignQueryViewDTO).queryOption(CampaignQueryOption.builder().needTarget(true).build()).build());

        List<Long> skuIds = cartItemViewDTOList.stream().map(CartItemViewDTO::getSkuId).collect(Collectors.toList());
        List<BrandSkuViewDTO> skuViewDTOList = brandSkuRepository.findSkuList(context, skuIds);

        List<CartItemConsistencyCheckResultViewDTO> cartItemConsistencyCheckResultViewDTOList = bizCartItemCommandWorkflow.checkCartItemConsistency(context,
                cartItemViewDTOList,skuViewDTOList, campaignViewDTOList);
        return MultiResponse.of(cartItemConsistencyCheckResultViewDTOList);
    }
}