package com.taobao.ad.brand.bp.app.businessability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.adgroup.CreativeRefViewDTO;
import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.creative.CreativeViewDTO;
import com.alibaba.ad.brand.dto.creative.audit.AuditReasonViewDTO;
import com.alibaba.ad.brand.dto.creative.audit.MamaAuditViewDTO;
import com.alibaba.ad.brand.dto.creative.audit.MamaMaterialRefusedReasonViewDTO;
import com.alibaba.ad.brand.dto.creative.element.ElementViewDTO;
import com.alibaba.ad.brand.dto.creative.malus.CreativeMalusViewDTO;
import com.alibaba.ad.brand.dto.creative.materialgroup.MaterialGroupInfoViewDTO;
import com.alibaba.ad.brand.dto.creative.materialgroup.MaterialGroupViewDTO;
import com.alibaba.ad.brand.dto.creative.materialgroup.MaterialViewDTO;
import com.alibaba.ad.brand.dto.creative.materialgroup.crop.ExtendedMaterialCropResultViewDTO;
import com.alibaba.ad.brand.dto.creative.materialgroup.crop.MainMaterialViewDTO;
import com.alibaba.ad.brand.dto.creative.materialgroup.crop.MaterialCropResultViewDTO;
import com.alibaba.ad.brand.dto.creative.materialgroup.crop.MaterialGroupCropResultViewDTO;
import com.alibaba.ad.brand.sdk.constant.adgroup.field.BrandAdgroupBottomTypeEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.brand.sdk.constant.creative.field.*;
import com.alibaba.ad.nb.packages.v2.client.constant.salegroup.SaleGroupProductCategoryEnum;
import com.alibaba.ad.nb.ssp.constant.common.MediaScopeEnum;
import com.alibaba.ad.nb.ssp.constant.template.verification.SizeUnitEnum;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.hermes.framework.utils.BeanUtils;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.context.DomainMetaqMessageBodyContext;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeMalusTemplateElementViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeMalusTemplateViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.CreativeValidateViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.crop.MalusCropResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.creative.crop.MalusCropViewDTO;
import com.taobao.ad.brand.bp.client.dto.rule.RuleCheckResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.template.ErrorMessageViewDTO;
import com.taobao.ad.brand.bp.client.dto.template.TemplateContextViewDTO;
import com.taobao.ad.brand.bp.client.dto.template.TemplateViewDTO;
import com.taobao.ad.brand.bp.client.enums.creative.MaterialGroupEventEnum;
import com.taobao.ad.brand.bp.client.enums.message.DomainMessageTypeEnum;
import com.taobao.ad.brand.bp.common.constant.TemplateConstant;
import com.taobao.ad.brand.bp.common.helper.creative.BizCreativeToolsHelper;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeRepository;
import com.taobao.ad.brand.bp.domain.creative.repository.CreativeTemplateRepository;
import com.taobao.ad.brand.bp.domain.creative.repository.MaterialGroupRepository;
import com.taobao.ad.brand.bp.domain.creative.spi.BizCreativeElementValidateSpi;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.businessability.IAdgroupAddBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.businessability.IAdgroupUpdateBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbilityRouteContext;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.*;
import com.taobao.ad.brand.bp.domain.sdk.creative.atomability.param.*;
import com.taobao.ad.brand.bp.domain.sdk.creative.businessability.*;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.IMessageAsyncSendAbility;
import com.taobao.ad.brand.bp.domain.sdk.tool.atomability.param.MessageAsyncSendAbilityParam;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.common.constant.TemplateConstant.CONSTANT_KEY_LABEL;
import static com.taobao.ad.brand.bp.common.constant.TemplateConstant.FORM_MALUS_ELEMENT_KEY;
import static com.taobao.ad.brand.bp.common.spi.ExtensionPointsFactory.runAbilitySpi;

@Component
@BusinessAbility(tag = SmartCreativeBusinessAbility.ABILITY_CODE, name = "智能创意商业能力", desc = "智能创意商业能力结构化实现类")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class SmartCreativeBusinessAbility implements
        IAdgroupAddBusinessAbilityPoint, IAdgroupUpdateBusinessAbilityPoint,
        ICreativeConvertBusinessAbilityPoint, ICreativePreCheckBusinessAbilityPoint, ICreativeCheckBusinessAbilityPoint,ICreativeGenerateSubCreativeBusinessAbilityPoint,
        ICreativeMaterialGroupCropBusinessAbilityPoint, ICreativeMaterialGroupCropCallbackBusinessAbilityPoint,
        ICreativeProcessCreativeBusinessAbilityPoint,ICreativeProcessCreativeAuditBusinessAbilityPoint,ICreativeBatchImportUpdateBusinessAbilityPoint {
    public static final String ABILITY_CODE = "BUSINESS_ABILITY_SMART_CREATIVE";

    private final ICreativeMalusConvergeElementGetForConvertCreativeAbility creativeMalusConvergeElementGetForConvertCreativeAbility;
    private final ICreativeMalusConvergeElementConvertForConvertCreativeAbility creativeMalusConvergeElementConvertForConvertCreativeAbility;
    private final ICreativeMalusTemplateElementMaterialGroupConvertAbility creativeMalusTemplateElementMaterialGroupConvertAbility;
    private final ICreativeSmartMaterialCropAbility creativeSmartMaterialCropAbility;
    private final ICreativeMalusTemplateStaticElementConvertForConvertCreativeAbility creativeMalusTemplateStaticElementConvertForConvertCreativeAbility;
    private final IMessageAsyncSendAbility messageAsyncSendAbility;
    private final ICreativeSmartMaterialCropValidateAbility creativeSmartMaterialCropValidateAbility;
    private final ICreativeSmartMaterialCropCallbackValidateAbility creativeSmartMaterialCropCallbackValidateAbility;
    private final ICreativeSmartMaterialCropSuccessJudgeAbility creativeSmartMaterialCropSuccessJudgeAbility;
    private final ICreativeSmartSubCreativeGenerateJudgeAbility creativeSmartSubCreativeGenerateJudgeAbility;
    private final CreativeRepository creativeRepository;
    private final CreativeTemplateRepository creativeTemplateRepository;
    private final MaterialGroupRepository materialGroupRepository;
    private final ICreativeSmartItemGetAbility creativeSmartItemGetAbility;

    @Override
    public boolean routeChecking(String bizCode, BaseViewDTO baseViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        List<String> specifiedBusinessCodes = businessAbilityRouteContext.getSpecifiedBusinessAbilityCodes();
        if (CollectionUtils.isNotEmpty(specifiedBusinessCodes) && specifiedBusinessCodes.contains(ABILITY_CODE)) {
            return true;
        }
        //超级爆款
        if (businessAbilityRouteContext.getPackageSaleGroupViewDTO() != null) {
            Integer productCategory = businessAbilityRouteContext.getPackageSaleGroupViewDTO().getProductCategory();
            return SaleGroupProductCategoryEnum.SUPER_TOP.getValue().equals(productCategory);
        }
        //资源包二级产品
        if(businessAbilityRouteContext.getResourcePackageProductViewDTO() != null){
            return BrandBoolEnum.BRAND_TRUE.getCode().equals(businessAbilityRouteContext.getResourcePackageProductViewDTO().getSupportSmartCreative());
        }
        return false;
    }

    @Override
    public Void invokeForAdgroupAdd(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, CampaignViewDTO campaignViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        AssertUtil.assertTrue(BrandAdgroupBottomTypeEnum.BOTTOM.getCode().equals(adgroupViewDTO.getBottomType()),"爆款场景不允许手动创建单元");
        if(CollectionUtils.isEmpty(adgroupViewDTO.getCreativeRefViewDTOList())){
            return null;
        }
        List<Long> creativeIds = adgroupViewDTO.getCreativeRefViewDTOList().stream().map(CreativeRefViewDTO::getCreativeId).distinct().collect(Collectors.toList());
        List<CreativeViewDTO> dbCreativeList = creativeRepository.findCreativeByIds(serviceContext, creativeIds);
        AssertUtil.notEmpty(dbCreativeList,"创意不存在");
        //小二伪登录场景，允许聚合创意关联单元。其他登录场景，单元只允许绑定一个智能创意
        if(ServiceContextUtil.isAliStaff(serviceContext)){
            long count = dbCreativeList.stream().filter(creativeViewDTO -> BrandCreativeSourceEnum.SMART_CREATIVE.getCode().equals(creativeViewDTO.getCreativeSource())).count();
            AssertUtil.assertTrue(count <= 1,"爆款场景单元只允许绑定一个智能创意");
            return null;
        }
        AssertUtil.assertTrue(dbCreativeList.size() == 1,"爆款场景单元只允许绑定一个智能创意");
        boolean allSmartCreative = dbCreativeList.stream().allMatch(creativeViewDTO -> BrandCreativeSourceEnum.SMART_CREATIVE.getCode().equals(creativeViewDTO.getCreativeSource()));
        AssertUtil.assertTrue(allSmartCreative,"爆款场景单元只允许绑定智能创意");
        return null;
    }

    @Override
    public Void invokeForAdgroupUpdate(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, CampaignViewDTO campaignViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        return invokeForAdgroupAdd(serviceContext, adgroupViewDTO, campaignViewDTO, businessAbilityRouteContext);
    }

    @Override
    public Void invokeForCreativeBatchImportUpdate(ServiceContext serviceContext, CreativeViewDTO creativeViewDTO) {
        AssertUtil.assertTrue(!BrandCreativeSourceEnum.SMART_CREATIVE.getCode().equals(creativeViewDTO.getCreativeSource()),"不支持智能创意批量导入");
        return null;
    }

    @Override
    public Void invokeForCreativeConvert(ServiceContext serviceContext, CreativeViewDTO creativeViewDTO,CreativeMalusTemplateViewDTO malusTemplateViewDTO) {
        //智能创意开关没有打开不进行后置流程处理
        if(BizCreativeToolsHelper.isStaticCreative(creativeViewDTO)){
            return null;
        }
        //获取海棠聚合元素
        Map<String, Object> malusConvergeElementMap = creativeMalusConvergeElementGetForConvertCreativeAbility.handle(serviceContext,
                CreativeMalusConvergeElementGetAbilityParam.builder().abilityTarget(malusTemplateViewDTO).build());

        //海棠聚合元素转素材组
        List<MaterialGroupViewDTO> materialGroupViewDTOList = creativeMalusTemplateElementMaterialGroupConvertAbility.handle(serviceContext,
                CreativeMalusTemplateElementMaterialGroupConvertAbilityParam.builder()
                        .abilityTarget(malusTemplateViewDTO).malusConvergeElementMap(malusConvergeElementMap).build());
        MaterialGroupInfoViewDTO materialGroupInfo = new MaterialGroupInfoViewDTO();
        creativeViewDTO.setMaterialGroupInfo(materialGroupInfo);
        materialGroupInfo.setMaterialGroupViewDTOList(materialGroupViewDTOList);

        //商品宝贝场景需要将商品id设置在素材中
        Long itemId = creativeSmartItemGetAbility.handle(serviceContext, CreativeSmartItemGetAbilityParam.builder().abilityTarget(creativeViewDTO).build());
        if(itemId != null){
            materialGroupViewDTOList.stream().filter(materialGroupViewDTO -> CollectionUtils.isNotEmpty(materialGroupViewDTO.getMaterialViewDTOList()))
                    .flatMap(materialGroupViewDTO -> materialGroupViewDTO.getMaterialViewDTOList().stream()).forEach(materialViewDTO -> {
                        materialViewDTO.setItemId(itemId);
                    });
        }
        return null;
    }

    @Override
    public Void invokeForCreativePreCheck(ServiceContext context, CreativeViewDTO dbCreativeViewDTO, TemplateViewDTO creativeTemplate,List<ErrorMessageViewDTO> errorMessageViewDTOList) {
        //智能创意开关没有打开不进行后置流程处理
        if(BizCreativeToolsHelper.isStaticCreative(dbCreativeViewDTO)){
            return null;
        }
        if(BrandCreativeShowAuditStatusEnum.CREATIVE_CENTER_REFUSE.getCode().equals(dbCreativeViewDTO.getCreativeAudit().getShowAuditStatus())){
            MamaAuditViewDTO mamaAudit = dbCreativeViewDTO.getCreativeAudit().getMamaAudit();
            //key=type_content
            Map<String, List<AuditReasonViewDTO>> refusedReasonMap = mamaAudit.getMaterialRefusedReasonList().stream()
                    .filter(mamaMaterialRefusedReasonViewDTO -> StringUtils.isNotBlank(mamaMaterialRefusedReasonViewDTO.getContent()))
                    .collect(Collectors.toMap(refusedReasonViewDTO -> String.format("%s_%s",refusedReasonViewDTO.getType(),refusedReasonViewDTO.getContent()),
                            MamaMaterialRefusedReasonViewDTO::getAuditReasonList, (v1, v2) -> v1));

            List<MaterialGroupViewDTO> materialGroupViewDTOList = dbCreativeViewDTO.getMaterialGroupInfo().getMaterialGroupViewDTOList();

            //其他素材拒绝原因
            List<MaterialGroupViewDTO> otherMaterialGroupList = materialGroupViewDTOList.stream()
                    .filter(materialGroupViewDTO -> BrandMaterialGroupTypeEnum.OTHER.getCode().equals(materialGroupViewDTO.getGroupType())).collect(Collectors.toList());
            for (MaterialGroupViewDTO materialGroupViewDTO : otherMaterialGroupList) {
                for (MaterialViewDTO elementViewDTO : materialGroupViewDTO.getMaterialViewDTOList()) {
                    if(BrandMamaMaterialTypeEnum.IMAGE_AUTH_PASS.getCode().equals(elementViewDTO.getType())){
                        continue;
                    }
                    String key = String.format("%s_%s",elementViewDTO.getType(),elementViewDTO.getContent());
                    if(!refusedReasonMap.containsKey(key)){
                        continue;
                    }
                    List<AuditReasonViewDTO> auditReasonViewDTOS = refusedReasonMap.get(key);
                    ErrorMessageViewDTO errorMessageViewDTO = new ErrorMessageViewDTO(elementViewDTO.getMalusElementKey(),
                            auditReasonViewDTOS.stream().map(AuditReasonViewDTO::getAuditReasonName).collect(Collectors.joining(";")));
                    errorMessageViewDTOList.add(errorMessageViewDTO);
                }
            }
            //视觉素材拒绝原因
            List<MaterialGroupViewDTO> visualMaterialGroupList = materialGroupViewDTOList.stream()
                    .filter(materialGroupViewDTO -> BrandMaterialGroupTypeEnum.VISUAL.getCode().equals(materialGroupViewDTO.getGroupType())).collect(Collectors.toList());
            for (MaterialGroupViewDTO materialGroupViewDTO : visualMaterialGroupList) {
                for (MaterialViewDTO elementViewDTO : materialGroupViewDTO.getMaterialViewDTOList()) {
                    if(BrandMamaMaterialTypeEnum.IMAGE_AUTH_PASS.getCode().equals(elementViewDTO.getType())){
                        continue;
                    }
                    String key = String.format("%s_%s",elementViewDTO.getType(),elementViewDTO.getContent());
                    if(!refusedReasonMap.containsKey(key)){
                        continue;
                    }
                    List<AuditReasonViewDTO> auditReasonViewDTOS = refusedReasonMap.get(key);
                    ErrorMessageViewDTO errorMessageViewDTO = new ErrorMessageViewDTO(elementViewDTO.getMalusElementKey(),
                            auditReasonViewDTOS.stream().map(AuditReasonViewDTO::getAuditReasonName).collect(Collectors.joining(";")));
                    errorMessageViewDTOList.add(errorMessageViewDTO);
                }
            }
        }
        //媒体审核拒绝
        if(BrandCreativeShowAuditStatusEnum.CREATIVE_MEDIA_AUDIT_REFUSE.getCode().equals(dbCreativeViewDTO.getCreativeAudit().getShowAuditStatus())){
            CreativeQueryViewDTO queryViewDTO = new CreativeQueryViewDTO();
            queryViewDTO.setCreativePackageIdList(Lists.newArrayList(dbCreativeViewDTO.getId()));
            queryViewDTO.setPackageType(BrandCreativePackageTypeEnum.COMMON.getValue());
            queryViewDTO.setPageSize(BizCreativeToolsHelper.MAX_PAGE_COUNT);
            queryViewDTO.setCreativeIdEqCreativePackageId(Boolean.FALSE);
            queryViewDTO.setShowAuditStatusList(Lists.newArrayList(BrandCreativeShowAuditStatusEnum.CREATIVE_MEDIA_AUDIT_REFUSE.getCode()));
            PageResultViewDTO<CreativeViewDTO> resultViewDTO = creativeRepository.findListWithPage(context, queryViewDTO);

            List<CreativeViewDTO> mediaRefuseList = Optional.ofNullable(resultViewDTO.getList()).orElse(Lists.newArrayList()).stream().filter(subCreativeView ->
                    BrandCreativeShowAuditStatusEnum.CREATIVE_MEDIA_AUDIT_REFUSE.getCode().equals(subCreativeView.getCreativeAudit().getShowAuditStatus())).collect(Collectors.toList());
            if (CollectionUtils.isNotEmpty(mediaRefuseList)) {
                errorMessageViewDTOList.addAll(mediaRefuseList.stream().flatMap(creativeView -> creativeView.getElementList().stream().map(elementViewDTO ->
                                new ErrorMessageViewDTO(StringUtils.isBlank(elementViewDTO.getFromMalusElementKey()) ? elementViewDTO.getMalusElementKey() : elementViewDTO.getFromMalusElementKey(),
                                        (StringUtils.isBlank(elementViewDTO.getElementName()) ? "" : (elementViewDTO.getElementName() + ":")) + creativeView.getCreativeAudit().getMediaAudit().getMediaAuditReason()))
                        .collect(Collectors.toList()).stream()).collect(Collectors.toList()));
            }
        }
        return null;
    }

    @Override
    public Void invokeForCreativeCheck(ServiceContext serviceContext, CreativeViewDTO creativeViewDTO, TemplateViewDTO creativeTemplate, CreativeValidateViewDTO creativeValidateViewDTO) {
        //智能创意开关没有打开不进行后置流程处理
        if(BizCreativeToolsHelper.isStaticCreative(creativeViewDTO)){
            return null;
        }
        AssertUtil.assertTrue(Objects.isNull(creativeViewDTO.getId()),"智能创意暂不支持编辑，请联系运营小二");
        CreativeMalusViewDTO creativeMalus = creativeViewDTO.getCreativeMalus();
        if(creativeMalus == null || StringUtils.isBlank(creativeMalus.getTemplateData())){
            return null;
        }
        //查询普通聚合元素
        CreativeMalusTemplateViewDTO creativeMalusTemplateViewDTO = new CreativeMalusTemplateViewDTO();
        creativeMalusTemplateViewDTO.setTemplateData(creativeMalus.getTemplateData());
        Map<String, Object> staticTemplateElementMap = creativeMalusConvergeElementGetForConvertCreativeAbility.handle(serviceContext,
                CreativeMalusConvergeElementGetAbilityParam.builder().abilityTarget(creativeMalusTemplateViewDTO).isFilterExtendType(true).build());
        if(MapUtils.isEmpty(staticTemplateElementMap)){
            staticTemplateElementMap = Maps.newHashMap();
        }
        TemplateContextViewDTO templateContextViewDTO = creativeTemplateRepository.getTemplateMetaData(serviceContext, creativeViewDTO.getCreativeTemplate().getSspTemplateId(), true);
        AssertUtil.notNull(templateContextViewDTO,String.format("创意模板不存在，templateId=%s",creativeViewDTO.getCreativeTemplate().getSspTemplateId()));
        staticTemplateElementMap.put(TemplateConstant.CONSTANT_KEY_BIZ_MAP,templateContextViewDTO.getBizMap());

        //海棠模板元素转换
        List<ElementViewDTO> elementViewDTOList = creativeMalusTemplateStaticElementConvertForConvertCreativeAbility.handle(serviceContext,
                CreativeMalusTemplateStaticElementConvertAbilityParam.builder().abilityTarget(creativeViewDTO).malusTemplateElementMap(staticTemplateElementMap).build());
        RogerLogger.info("智能创意，elementViewDTOList={}",JSON.toJSONString(elementViewDTOList,SerializerFeature.DisableCircularReferenceDetect));

        List<ErrorMessageViewDTO> errorList = Optional.ofNullable(creativeValidateViewDTO).map(CreativeValidateViewDTO::getErrorList).orElse(Lists.newArrayList());
        LinkedHashMap<String, Map<String, Object>> templateColumnMap = templateContextViewDTO.getColumnMap();
        for (ElementViewDTO creativeElement : elementViewDTOList) {
            Map<String, Object> verificationMap = templateColumnMap.get(creativeElement.getMalusElementKey());
            if (verificationMap != null) {
                runAbilitySpi(BizCreativeElementValidateSpi.class, extension -> extension.validate(creativeElement, verificationMap, errorList),
                            BizCreativeElementValidateSpi.getElementSpiBizCode(creativeElement.getElementType()));
            }
        }
        return null;
    }

    @Override
    public Void invokeForMaterialGroupCrop(ServiceContext serviceContext, MaterialGroupViewDTO materialGroupViewDTO) {
        AssertUtil.notNull(materialGroupViewDTO,"素材组不能为空");
        RogerLogger.info(String.format("素材组拓版异步开始，素材组id=%s",materialGroupViewDTO.getId()));
        //是否拓版成功，拓版成功的话触发事件
        Boolean cropSuccessJudge = creativeSmartMaterialCropSuccessJudgeAbility.handle(serviceContext,
                CreativeSmartMaterialCropSuccessJudgeAbilityParam.builder().abilityTarget(materialGroupViewDTO).build());
        if(cropSuccessJudge){
            RogerLogger.info(String.format("素材组拓版已拓版成功，发送拓版成功消息，素材组id=%s",materialGroupViewDTO.getId()));
            DomainMetaqMessageBodyContext messageBodyContext = DomainMetaqMessageBodyContext.builder().bizCode(serviceContext.getBizCode()).memberId(materialGroupViewDTO.getMemberId())
                    .domainType(DomainMessageTypeEnum.MATERIAL_GROUP).domainEvent(MaterialGroupEventEnum.CROP_SUCCESS.name())
                    .entityId(materialGroupViewDTO.getId()).build();
            messageAsyncSendAbility.handle(serviceContext, MessageAsyncSendAbilityParam.builder().abilityTarget(messageBodyContext).build());
            return null;
        }
        RuleCheckResultViewDTO checkResultViewDTO = creativeSmartMaterialCropValidateAbility.handle(serviceContext, CreativeSmartMaterialCropValidateAbilityParam.builder()
                .abilityTarget(materialGroupViewDTO).build());
        if(!BrandBoolEnum.BRAND_TRUE.getCode().equals(checkResultViewDTO.getIsPass())){
            RogerLogger.info(String.format("素材组拓版异常，素材组id=%s，原因：%s",materialGroupViewDTO.getId(),JSON.toJSONString(checkResultViewDTO)));
            return null;
        }
        List<CreativeViewDTO> creativeViewDTOList = creativeRepository.findListByMaterialGroupId(serviceContext, materialGroupViewDTO.getId());
        AssertUtil.notEmpty(creativeViewDTOList,String.format("素材组拓版异常，素材组关联的创意不存在，素材组id=%s",materialGroupViewDTO.getId()));
        CreativeViewDTO creativeViewDTO = creativeViewDTOList.get(0);
        if(BizCreativeToolsHelper.isStaticCreative(creativeViewDTO)){
            RogerLogger.info(String.format("素材组拓版异常，素材组归属创意非智能创意，素材组id=%s",materialGroupViewDTO.getId()));
            return null;
        }
        TemplateContextViewDTO templateContextViewDTO = creativeTemplateRepository.getTemplateMetaData(serviceContext, creativeViewDTO.getCreativeTemplate().getSspTemplateId(),true);
        AssertUtil.notNull(templateContextViewDTO,String.format("素材组拓版异常，SSP模板不存在，模板id=%s",creativeViewDTO.getCreativeTemplate().getSspTemplateId()));
        String jobId = creativeSmartMaterialCropAbility.handle(serviceContext, CreativeSmartMaterialCropAbilityParam.builder()
                .abilityTarget(materialGroupViewDTO).templateContextViewDTO(templateContextViewDTO).build());
        RogerLogger.info(String.format("素材组拓版调用成功，素材组id=%s，拓版任务id=%s",materialGroupViewDTO.getId(),jobId));
        //更新素材组拓版结果
        materialGroupRepository.updateMaterialGroupCropResult(serviceContext,materialGroupViewDTO);
        RogerLogger.info(String.format("素材组拓版异步成功，素材组id=%s",materialGroupViewDTO.getId()));
        return null;
    }

    @Override
    public Void invokeForMaterialGroupCropCallback(ServiceContext serviceContext, MalusCropResultViewDTO malusCropResultViewDTO) {
        RogerLogger.info(String.format("素材组拓版回调开始，拓版结果=%s",JSON.toJSONString(malusCropResultViewDTO, SerializerFeature.DisableCircularReferenceDetect)));
        creativeSmartMaterialCropCallbackValidateAbility.handle(serviceContext,
                CreativeSmartMaterialCropCallbackValidateAbilityParam.builder().abilityTarget(malusCropResultViewDTO).build());

        Long materialGroupId = malusCropResultViewDTO.getList().stream().map(MalusCropViewDTO::getImage)
                .map(MainMaterialViewDTO::getMaterialGroupId).findFirst().orElse(null);
        Long memberId = malusCropResultViewDTO.getList().stream().map(MalusCropViewDTO::getImage)
                .map(MainMaterialViewDTO::getMemberId).findFirst().orElse(null);
        serviceContext.setMemberId(memberId);

        MaterialGroupViewDTO materialGroupViewDTO = materialGroupRepository.getMaterialGroupById(serviceContext, materialGroupId);
        AssertUtil.notNull(malusCropResultViewDTO,String.format("素材组拓版异常，素材组不存在，素材组id=%s",materialGroupId));

        MaterialGroupCropResultViewDTO materialGroupCropResultViewDTO = Optional.ofNullable(materialGroupViewDTO.getMaterialGroupCropResultViewDTO()).orElse(new MaterialGroupCropResultViewDTO());
        if(!Objects.equals(malusCropResultViewDTO.getJobId(),materialGroupCropResultViewDTO.getJobId())){
            RogerLogger.info(String.format("素材组拓版失败，素材组id=%s，拓版任务不匹配：dbJobId=%s,callbackJobId=%s",materialGroupCropResultViewDTO.getJobId(),materialGroupId,malusCropResultViewDTO.getJobId()));
            return null;
        }
        //拓版成功
        if(malusCropResultViewDTO.getSuccess()){
            materialGroupCropResultViewDTO.setStatus(BrandCropStatusEnum.SUCCESS.getCode());
        }else{
            RogerLogger.info(String.format("素材组拓版失败，素材组id=%s",materialGroupId));
            materialGroupCropResultViewDTO.setStatus(BrandCropStatusEnum.FAIL.getCode());
            materialGroupCropResultViewDTO.setFailCount(Optional.ofNullable(materialGroupCropResultViewDTO.getFailCount()).orElse(0)+1);
            materialGroupCropResultViewDTO.setFailReason(malusCropResultViewDTO.getMessage());
        }
        materialGroupCropResultViewDTO.setEndTime(new Date());
        materialGroupViewDTO.setMaterialGroupCropResultViewDTO(materialGroupCropResultViewDTO);
        //拓版结果
        Map<Long, MalusCropViewDTO> materialCropResultMap = malusCropResultViewDTO.getList().stream().peek(malusCropViewDTO -> {
            Optional.ofNullable(malusCropViewDTO.getExtendedItems()).orElse(Lists.newArrayList()).stream()
                    .filter(extendedMaterialViewDTO -> extendedMaterialViewDTO.getResult() != null).forEach(extendedMaterialViewDTO -> {
                        long fileSizeKB = extendedMaterialViewDTO.getResult().getFileSize() / SizeUnitEnum.KB.getTransferToBit();
                        extendedMaterialViewDTO.getResult().setFileSize(fileSizeKB);
                    });
                }).collect(Collectors.toMap(malusCropResult -> malusCropResult.getImage().getMaterialId(), Function.identity()));
        for (MaterialViewDTO materialViewDTO : materialGroupViewDTO.getMaterialViewDTOList()) {
            MalusCropViewDTO malusCropViewDTO = materialCropResultMap.get(materialViewDTO.getId());
            if(malusCropViewDTO == null){
                continue;
            }
            MaterialCropResultViewDTO materialCropResultViewDTO = Optional.ofNullable(materialViewDTO.getMaterialCropResultViewDTO()).orElse(new MaterialCropResultViewDTO());
            //拓版成功
            if(malusCropResultViewDTO.getSuccess()){
                materialCropResultViewDTO.setExtendedMaterialList(malusCropViewDTO.getExtendedItems());
                materialCropResultViewDTO.setStatus(BrandCropStatusEnum.SUCCESS.getCode());
            }else{
                materialCropResultViewDTO.setStatus(BrandCropStatusEnum.FAIL.getCode());
            }
            materialViewDTO.setMaterialCropResultViewDTO(materialCropResultViewDTO);
        }
        //更新素材组拓版结果
        materialGroupRepository.updateMaterialGroupCropResult(serviceContext,materialGroupViewDTO);
        //拓版成功，发送拓版生成消息下游消费生成子创意
        if(malusCropResultViewDTO.getSuccess()){
            DomainMetaqMessageBodyContext messageBodyContext = DomainMetaqMessageBodyContext.builder().bizCode(serviceContext.getBizCode()).memberId(materialGroupViewDTO.getMemberId())
                    .domainType(DomainMessageTypeEnum.MATERIAL_GROUP).domainEvent(MaterialGroupEventEnum.CROP_SUCCESS.name())
                    .entityId(materialGroupViewDTO.getId()).build();
            messageAsyncSendAbility.handle(serviceContext, MessageAsyncSendAbilityParam.builder().abilityTarget(messageBodyContext).build());
        }
        RogerLogger.info(String.format("素材组拓版回调成功，素材组id=%s",materialGroupViewDTO.getId()));
        return null;
    }

    @Override
    public List<CreativeViewDTO> invokeForGenerateSubCreative(ServiceContext serviceContext, CreativeViewDTO creativeViewDTO,MaterialGroupViewDTO materialGroup,List<TemplateContextViewDTO> templateContextViewDTOList) {
        if(BizCreativeToolsHelper.isStaticCreative(creativeViewDTO)){
            return Lists.newArrayList();
        }
        List<Long> supportSubTemplateIds = Optional.ofNullable(templateContextViewDTOList).orElse(Lists.newArrayList()).stream().map(templateContextViewDTO -> templateContextViewDTO.getTemplateViewDTO().getId()).collect(Collectors.toList());
        RogerLogger.info(String.format("智能创意支持的子模板列表，id=%s，subTemplateIds=%s", creativeViewDTO.getId(), JSON.toJSONString(supportSubTemplateIds)));
        if (CollectionUtils.isEmpty(supportSubTemplateIds)) {
            RogerLogger.info(String.format("智能创意生成子创意，不满足子创意生成条件原因：创意(id=%s)下支持的子模板列表为空", creativeViewDTO.getId()));
            return Lists.newArrayList();
        }
        Boolean subCreativeGenerateJudge = creativeSmartSubCreativeGenerateJudgeAbility.handle(serviceContext, CreativeSmartSubCreativeGenerateJudgeAbilityParam.builder().abilityTarget(creativeViewDTO).build());
        if (subCreativeGenerateJudge == null || !subCreativeGenerateJudge) {
            RogerLogger.info(String.format("智能创意生成子创意，不满足子创意生成条件，创意id=%s", creativeViewDTO.getId()));
            return Lists.newArrayList();
        }
        List<CreativeViewDTO> subCreativeList = new ArrayList<>();
        if (BrandMaterialGroupTypeEnum.OTHER.getCode().equals(materialGroup.getGroupType())) {
            List<MaterialGroupViewDTO> visualMaterialGroups = creativeViewDTO.getMaterialGroupInfo().getMaterialGroupViewDTOList().stream().filter(materialGroupViewDTO ->
                    BrandMaterialGroupTypeEnum.VISUAL.getCode().equals(materialGroupViewDTO.getGroupType())).collect(Collectors.toList());
            if (CollectionUtils.isNotEmpty(visualMaterialGroups)) {
                for (MaterialGroupViewDTO visualMaterialGroup : visualMaterialGroups) {
                    subCreativeList.addAll(generateSubCreative(serviceContext, creativeViewDTO, visualMaterialGroup, materialGroup, templateContextViewDTOList));
                }
            }
        } else if (BrandMaterialGroupTypeEnum.VISUAL.getCode().equals(materialGroup.getGroupType())) {
            List<MaterialGroupViewDTO> otherMaterialGroups = creativeViewDTO.getMaterialGroupInfo().getMaterialGroupViewDTOList().stream().filter(materialGroupViewDTO ->
                    BrandMaterialGroupTypeEnum.OTHER.getCode().equals(materialGroupViewDTO.getGroupType())).collect(Collectors.toList());
            if (CollectionUtils.isNotEmpty(otherMaterialGroups)) {
                for (MaterialGroupViewDTO otherMaterialGroup : otherMaterialGroups) {
                    subCreativeList.addAll(generateSubCreative(serviceContext, creativeViewDTO, materialGroup, otherMaterialGroup, templateContextViewDTOList));
                }
            }
        }
        return subCreativeList;
    }

    @Override
    public Void invokeForProcessCreative(ServiceContext serviceContext, CreativeViewDTO creativeViewDTO, TemplateViewDTO creativeTemplate) {
        if (BizCreativeToolsHelper.isStaticCreative(creativeViewDTO)) {
            return null;
        }
        //智能场景，主创意不允许编辑
        if (BrandCreativePackageTypeEnum.PACKAGE.getValue().equals(creativeViewDTO.getPackageType())) {
            AssertUtil.assertTrue(Objects.isNull(creativeViewDTO.getId()), "智能创意场景暂不支持修改创意");
        } else {
            //子创意跳过风控审核
            if (Objects.nonNull(creativeViewDTO.getMaterialGroupInfo())) {
                creativeViewDTO.getMaterialGroupInfo().setMaterialGroupViewDTOList(null);
            }
            for (ElementViewDTO elementViewDTO : creativeViewDTO.getElementList()) {
                elementViewDTO.setSkipQuality(BrandBoolEnum.BRAND_TRUE.getCode());
            }
        }
        return null;
    }

    @Override
    public Void invokeForProcessCreativeAudit(ServiceContext serviceContext, CreativeViewDTO creativeViewDTO, TemplateViewDTO creativeTemplate) {
        if(BizCreativeToolsHelper.isStaticCreative(creativeViewDTO)){
            return null;
        }
        //智能场景，主创意送审规则
        if(BrandCreativePackageTypeEnum.PACKAGE.getValue().equals(creativeViewDTO.getPackageType())){
            creativeViewDTO.getCreativeAudit().setAuditSceneType(BrandCreativeAuditSceneTypeEnum.BRAND_SMART_CREATIVE.getCode());
            if (isNoQuality(creativeTemplate)){
                creativeViewDTO.getCreativeAudit().setAuditSceneType(BrandCreativeAuditSceneTypeEnum.BRAND_NO_QUALITY_SMART_CREATIVE.getCode());
            }
        }
        return null;
    }

    private Boolean isNoQuality(TemplateViewDTO creativeTemplate) {
        Integer mediaScope = creativeTemplate.getMediaScope();

        if (MediaScopeEnum.TAO_INNER.getCode().equals(mediaScope)) {
            return true;
        }

        if (MediaScopeEnum.CROSS_SCOPE.getCode().equals(mediaScope)) {
            return creativeTemplate.getInteractTemplateList().stream()
                    .allMatch(interactTemplate -> MediaScopeEnum.TAO_INNER.getCode().equals(interactTemplate.getMediaScope()));
        }

        return false;
    }

    private List<CreativeViewDTO> generateSubCreative(ServiceContext serviceContext, CreativeViewDTO creativeViewDTO, MaterialGroupViewDTO visualMaterialGroup, MaterialGroupViewDTO otherMaterialGroup, List<TemplateContextViewDTO> templateContextDTOS) {
        if (visualMaterialGroup.getMaterialViewDTOList().stream().filter(material ->
                BrandMamaMaterialTypeEnum.IMAGE_AUTH_PASS.getCode().equals(material.getType())).anyMatch(material ->
                Objects.isNull(material.getMaterialCropResultViewDTO()) ||
                        CollectionUtils.isEmpty(material.getMaterialCropResultViewDTO().getExtendedMaterialList()) ||
                        BrandBoolEnum.BRAND_FALSE.getCode().equals(material.getMaterialCropResultViewDTO().getStatus()))) {
            return Collections.EMPTY_LIST;
        }
        visualMaterialGroup.getMaterialViewDTOList().stream().filter(material -> BrandMamaMaterialTypeEnum.IMAGE_AUTH_PASS.getCode().equals(material.getType())).forEach(material -> {
            MaterialCropResultViewDTO materialCropResultViewDTO = material.getMaterialCropResultViewDTO();
            if (Objects.nonNull(materialCropResultViewDTO)) {
                materialCropResultViewDTO.getExtendedMaterialList().forEach(extendedMaterial -> {
                    String malusElementKey = extendedMaterial.getMalusElementKey();
                    ExtendedMaterialCropResultViewDTO result = extendedMaterial.getResult();
                    CreativeMalusTemplateElementViewDTO creativeMalusTemplateElementViewDTO = new CreativeMalusTemplateElementViewDTO();
                    creativeMalusTemplateElementViewDTO.setUrl(result.getUrl());
                    creativeMalusTemplateElementViewDTO.setHeight(result.getHeight().toString());
                    creativeMalusTemplateElementViewDTO.setWidth(result.getWidth().toString());
                    creativeMalusTemplateElementViewDTO.setFileSize(result.getFileSize());
                    match(malusElementKey, "主视觉", material.getMalusElementKey(), JSON.toJSONString(creativeMalusTemplateElementViewDTO), templateContextDTOS);
                });
            }
        });

        CreativeMalusTemplateViewDTO creativeMalusTemplateViewDTO = new CreativeMalusTemplateViewDTO();
        creativeMalusTemplateViewDTO.setTemplateData(creativeViewDTO.getCreativeMalus().getTemplateData());
        //获取聚合元素
        Map<String, Object> convergeElementMap = creativeMalusConvergeElementGetForConvertCreativeAbility.handle(serviceContext,
                CreativeMalusConvergeElementGetAbilityParam.builder().abilityTarget(creativeMalusTemplateViewDTO).isFilterExtendType(true).build());
        //聚合元素数据转换
        creativeMalusConvergeElementConvertForConvertCreativeAbility.handle(serviceContext,
                CreativeMalusConvergeElementConvertAbilityParam.builder().abilityTarget(creativeMalusTemplateViewDTO)
                        .templateContextViewDTOList(templateContextDTOS).malusConvergeElementMap(convergeElementMap).build());

        //基于子模板构建子创意
        List<CreativeViewDTO> subCreativeList = templateContextDTOS.stream().map(templateContext -> {
            TemplateViewDTO subTemplate = templateContext.getTemplateViewDTO();
            CreativeViewDTO subCreative = BeanUtils.copyIgnoreNull(creativeViewDTO, new CreativeViewDTO());
            subCreative.setId(null);
            subCreative.setCreativeScope(subTemplate.getMediaScope());
            subCreative.setBizUniqueKey(subTemplate.getId() + "_" + creativeViewDTO.getId() + "_" + visualMaterialGroup.getId());
            subCreative.getCreativeTemplate().setSspTemplateId(subTemplate.getId());


            MaterialGroupInfoViewDTO materialGroupInfo = Optional.ofNullable(subCreative.getMaterialGroupInfo()).orElse(new MaterialGroupInfoViewDTO());
            materialGroupInfo.setMaterialGroupId(visualMaterialGroup.getId());
            materialGroupInfo.setOtherMaterialGroupId(Optional.ofNullable(otherMaterialGroup).map(MaterialGroupViewDTO::getId).orElse(null));
            subCreative.setMaterialGroupInfo(materialGroupInfo);

            Map<String, Object> properties = templateContext.getProperties();
            templateContext.getBizMap().put(TemplateConstant.CONSTANT_KEY_PROPERTIES, properties);
            Map<String, Object> data = templateContext.getData();
            data.put(TemplateConstant.CONSTANT_KEY_BIZ_MAP, templateContext.getBizMap());

            List<ElementViewDTO> elementViewDTOList = creativeMalusTemplateStaticElementConvertForConvertCreativeAbility.handle(serviceContext,
                    CreativeMalusTemplateStaticElementConvertAbilityParam.builder().abilityTarget(subCreative).malusTemplateElementMap(data).build());
            subCreative.setElementList(elementViewDTOList);
            subCreative.getCreativeMalus().setTemplateData(JSON.toJSONString(data));
            return subCreative;
        }).collect(Collectors.toList());

        return subCreativeList;
    }

    private void match(String malusElementKey, String elementName, String formMalusElementKey, Object value, List<TemplateContextViewDTO> templateContextDTOS) {
        for (TemplateContextViewDTO contextDTO : templateContextDTOS) {
            Map<String, Map<String, Object>> bizMap = contextDTO.getBizMap();
            if (bizMap.containsKey(malusElementKey)) {
                contextDTO.getData().put(malusElementKey, value);
                if (StringUtils.isNotBlank(elementName)) {
                    bizMap.get(malusElementKey).put(CONSTANT_KEY_LABEL, elementName);
                }
                bizMap.get(malusElementKey).put(FORM_MALUS_ELEMENT_KEY, formMalusElementKey);
            }
        }
    }
}
