package com.taobao.ad.brand.bp.app.businessability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.adgroup.monitor.AdgroupMonitorViewDTO;
import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignShowConfigViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupSaleGroupPageViewDTO;
import com.taobao.ad.brand.bp.client.dto.monitor.MonitorInfoDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourceDistributionRuleViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.common.converter.monitor.MonitorInfoConverter;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupThirdMonitorClearAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupThirdMonitorInitForAddAdgroupAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupThirdMonitorUpdateAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupThirdMonitorValidateForAddAdgroupAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.thirdmonitor.*;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.businessability.IAdgroupAddBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.businessability.IAdgroupThirdMonitorUpdateBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.businessability.IAdgroupUpdateBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbilityRouteContext;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignTargetShowConfigGetAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignThirdMonitorClearAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignThirdMonitorValidateForAddCampaignAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructureQueryAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.showconfig.ICampaignThirdMonitorBuildForShowConfigGetAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.thirdmonitor.ICampaignThirdMonitorClearAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.thirdmonitor.ICampaignThirdMonitorNeedClearGetForSyncSaleGroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.thirdmonitor.ICampaignThirdMonitorValidateForAddCampaignAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.businessability.ICampaignAddBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.campaign.businessability.ICampaignQueryBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.campaign.businessability.ICampaignUpdateBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupThirdMonitorClearAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupThirdMonitorSaveForUpdateThirdMonitorAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupThirdMonitorSyncAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.param.SaleGroupThirdMonitorValidateForUpdateThirdMonitorAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.atomability.thirdmonitor.*;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.businessability.ISaleGroupCanSelectStatusQueryBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.businessability.ISaleGroupQueryBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.businessability.ISaleGroupSyncBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.salegroup.businessability.ISaleGroupThirdMonitorUpdateBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.ssp.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

@Component
@BusinessAbility(tag = ThirdMonitorSupportBusinessAbility.ABILITY_CODE, name = "第三方监测支持商业能力", desc = "第三方监测支持商业能力结构化实现类")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class ThirdMonitorSupportBusinessAbility implements
        ISaleGroupThirdMonitorUpdateBusinessAbilityPoint, ISaleGroupSyncBusinessAbilityPoint, ISaleGroupQueryBusinessAbilityPoint, ISaleGroupCanSelectStatusQueryBusinessAbilityPoint,
        ICampaignAddBusinessAbilityPoint, ICampaignUpdateBusinessAbilityPoint, ICampaignQueryBusinessAbilityPoint,
        IAdgroupAddBusinessAbilityPoint, IAdgroupUpdateBusinessAbilityPoint, IAdgroupThirdMonitorUpdateBusinessAbilityPoint {

    public static final String ABILITY_CODE = "BUSINESS_ABILITY_THIRD_MONITOR_SUPPORT";

    private final ProductRepository productRepository;
    private final MonitorInfoConverter monitorInfoConverter;

    private final ISaleGroupThirdMonitorValidateForUpdateThirdMonitorAbility saleGroupThirdMonitorValidateForUpdateThirdMonitorAbility;
    private final ISaleGroupThirdMonitorSaveForUpdateThirdMonitorAbility saleGroupThirdMonitorSaveForUpdateThirdMonitorAbility;
    private final ICampaignStructureQueryAbility campaignStructureQueryAbility;
    private final ICampaignThirdMonitorValidateForAddCampaignAbility campaignThirdMonitorValidateForAddCampaignAbility;
    private final IAdgroupThirdMonitorInitForAddAdgroupAbility adgroupThirdMonitorInitForAddAdgroupAbility;
    private final IAdgroupThirdMonitorValidateForAddAdgroupAbility adgroupThirdMonitorValidateForAddAdgroupAbility;
    private final IAdgroupThirdMonitorUpdateAbility adgroupThirdMonitorUpdateAbility;

    private final ISaleGroupThirdMonitorNeedClearGetForSyncSaleGroupAbility saleGroupThirdMonitorNeedClearGetForSyncSaleGroupAbility;
    private final ICampaignThirdMonitorNeedClearGetForSyncSaleGroupAbility campaignThirdMonitorNeedClearGetForSyncSaleGroupAbility;
    private final IAdgroupThirdMonitorNeedClearGetForSyncSaleGroupAbility adgroupThirdMonitorNeedClearGetForSyncSaleGroupAbility;
    private final ISaleGroupThirdMonitorUpdateValidateForSyncSaleGroupAbility saleGroupThirdMonitorUpdateValidateForSyncSaleGroupAbility;
    private final ISaleGroupThirdMonitorClearAbility saleGroupThirdMonitorClearAbility;
    private final ICampaignThirdMonitorClearAbility campaignThirdMonitorClearAbility;
    private final IAdgroupThirdMonitorClearAbility adgroupThirdMonitorClearAbility;
    private final ICampaignThirdMonitorBuildForShowConfigGetAbility campaignThirdMonitorBuildForShowConfigGetAbility;


    @Override
    public boolean routeChecking(String bizCode, BaseViewDTO baseViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        List<String> specifiedBusinessCodes = businessAbilityRouteContext.getSpecifiedBusinessAbilityCodes();
        if (CollectionUtils.isNotEmpty(specifiedBusinessCodes) && specifiedBusinessCodes.contains(ABILITY_CODE)) {
            return true;
        }
        if (businessAbilityRouteContext.getPackageSaleGroupViewDTO() != null) {
            return Objects.nonNull(businessAbilityRouteContext.getPackageSaleGroupViewDTO().getMonitorConfig());
        }
        return false;
    }

    @Override
    public Void invokeForQuerySaleGroup(ServiceContext context, CampaignGroupSaleGroupPageViewDTO campaignGroupSaleGroupPageViewDTO, SaleGroupInfoViewDTO dbSaleGroupInfoViewDTO, List<CampaignViewDTO> campaignViewDTOList, BusinessAbilityRouteContext businessAbilityRouteContext) {
        if (dbSaleGroupInfoViewDTO != null) {
            List<MonitorInfoDTO> monitorInfoDTOList = monitorInfoConverter.convertViewDTO2DTOList(dbSaleGroupInfoViewDTO.getThirdMonitorUrlList());
            campaignGroupSaleGroupPageViewDTO.setMonitors(monitorInfoDTOList);
        }
        return null;
    }

    @Override
    public Void invokeForSyncSaleGroup(ServiceContext serviceContext, List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupList) {
        if (CollectionUtils.isEmpty(resourcePackageSaleGroupList)) {
            return null;
        }
        List<Long> saleGroupIds = resourcePackageSaleGroupList.stream().map(ResourcePackageSaleGroupViewDTO::getId).collect(Collectors.toList());
        List<CampaignViewDTO> campaignViewDTOList = campaignStructureQueryAbility.handle(serviceContext,CampaignStructureQueryAbilityParam.builder()
                        .abilityTarget(CampaignQueryViewDTO.builder().saleGroupIds(saleGroupIds).build())
                .queryOption(CampaignQueryOption.builder().build()).build());
        Map<Long, List<CampaignViewDTO>> saleGroupCampaignGroupMap = Optional.ofNullable(campaignViewDTOList).orElse(Lists.newArrayList())
                .stream().collect(Collectors.groupingBy(campaignViewDTO -> campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId()));

        for (ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO : resourcePackageSaleGroupList) {
            if (resourcePackageSaleGroupViewDTO.getMonitorConfig() != null
                    && BrandBoolEnum.BRAND_TRUE.getCode().equals(resourcePackageSaleGroupViewDTO.getMonitorConfig().getSupportMonitor())
                        && resourcePackageSaleGroupViewDTO.getMonitorConfig().getMonitorDimension() == null) {
                RogerLogger.info("订单分组（id={}）第三方监测开启，但未设置监测纬度，不做任何处理",resourcePackageSaleGroupViewDTO.getId());
                continue;
            }
            SaleGroupThirdMonitorSyncAbilityParam syncSaleGroupAbilityParam = SaleGroupThirdMonitorSyncAbilityParam.builder()
                    .abilityTarget(resourcePackageSaleGroupViewDTO).campaignViewDTOList(saleGroupCampaignGroupMap.get(resourcePackageSaleGroupViewDTO.getId())).build();

            //查询需要清空第三方监测数据
            List<SaleGroupInfoViewDTO> clearSaleGroupInfoViewDTOList = saleGroupThirdMonitorNeedClearGetForSyncSaleGroupAbility.handle(serviceContext, syncSaleGroupAbilityParam);
            List<CampaignViewDTO> clearCampaignViewDTOList = campaignThirdMonitorNeedClearGetForSyncSaleGroupAbility.handle(serviceContext, syncSaleGroupAbilityParam);
            List<AdgroupViewDTO> clearAdgroupViewDTOList = adgroupThirdMonitorNeedClearGetForSyncSaleGroupAbility.handle(serviceContext, syncSaleGroupAbilityParam);

            if(CollectionUtils.isEmpty(clearSaleGroupInfoViewDTOList) && CollectionUtils.isEmpty(clearCampaignViewDTOList) && CollectionUtils.isEmpty(clearAdgroupViewDTOList)){
                continue;
            }
            //第三方监测同步校验
            saleGroupThirdMonitorUpdateValidateForSyncSaleGroupAbility.handle(serviceContext,syncSaleGroupAbilityParam);

            //清空第三方监测
            campaignThirdMonitorClearAbility.handle(serviceContext, CampaignThirdMonitorClearAbilityParam.builder().abilityTargets(clearCampaignViewDTOList).build());
            saleGroupThirdMonitorClearAbility.handle(serviceContext, SaleGroupThirdMonitorClearAbilityParam.builder().abilityTargets(clearSaleGroupInfoViewDTOList).build());
            adgroupThirdMonitorClearAbility.handle(serviceContext, AdgroupThirdMonitorClearAbilityParam.builder().abilityTargets(clearAdgroupViewDTOList).build());
        }
        return null;
    }

    @Override
    public Void invokeForUpdateSaleGroupThirdMonitor(ServiceContext context, Long campaignGroupId, List<CampaignGroupSaleGroupPageViewDTO> campaignGroupSaleGroupPageViewDTOS) {
        if (CollectionUtils.isEmpty(campaignGroupSaleGroupPageViewDTOS) || campaignGroupId == null) {
            return null;
        }
        saleGroupThirdMonitorValidateForUpdateThirdMonitorAbility.handle(context, SaleGroupThirdMonitorValidateForUpdateThirdMonitorAbilityParam.builder()
                .abilityTargets(campaignGroupSaleGroupPageViewDTOS).build());
        saleGroupThirdMonitorSaveForUpdateThirdMonitorAbility.handle(context, SaleGroupThirdMonitorSaveForUpdateThirdMonitorAbilityParam.builder()
                .abilityTargets(campaignGroupSaleGroupPageViewDTOS).campaignGroupId(campaignGroupId).build());
        return null;
    }

    @Override
    public Void invokeForFindCanSelectStatusSaleGroup(ServiceContext context, CampaignGroupSaleGroupPageViewDTO campaignGroupSaleGroupPageViewDTO, SaleGroupInfoViewDTO dbSaleGroupInfoViewDTO, List<CampaignViewDTO> campaignViewDTOList, BusinessAbilityRouteContext businessAbilityRouteContext) {
        ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO = businessAbilityRouteContext.getPackageSaleGroupViewDTO();
        campaignGroupSaleGroupPageViewDTO.setSplitConfig(resourcePackageSaleGroupViewDTO.getMonitorConfig().getSplitConfig());
        campaignGroupSaleGroupPageViewDTO.setMonitorDimension(resourcePackageSaleGroupViewDTO.getMonitorConfig().getMonitorDimension());
        if (CollectionUtils.isNotEmpty(resourcePackageSaleGroupViewDTO.getDistributionRuleList())) {
            List<Long> sspProductUuidList = resourcePackageSaleGroupViewDTO.getDistributionRuleList().stream()
                    .map(ResourceDistributionRuleViewDTO::getResourcePackageProductList).filter(CollectionUtils::isNotEmpty)
                    .flatMap(Collection::stream).collect(Collectors.toList())
                    .stream().map(ResourcePackageProductViewDTO::getSspProductUuid).distinct().collect(Collectors.toList());

            if (CollectionUtils.isNotEmpty(sspProductUuidList)) {
                List<ProductViewDTO> productViewDTOList = productRepository.getProductByUuids(sspProductUuidList);
                List<Integer> nonAliInspectTypeList = Optional.ofNullable(productViewDTOList).orElse(Lists.newArrayList()).stream().map(ProductViewDTO::getNonAliInspectTypeList).filter(CollectionUtils::isNotEmpty)
                        .flatMap(Collection::stream).distinct().collect(Collectors.toList());
                campaignGroupSaleGroupPageViewDTO.setNonAliInspectTypeList(nonAliInspectTypeList);
            }
        }
        return null;
    }

    @Override
    public Void invokeForCampaignAdd(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        campaignThirdMonitorValidateForAddCampaignAbility.handle(serviceContext, CampaignThirdMonitorValidateForAddCampaignAbilityParam.builder()
                .abilityTarget(campaignViewDTO).build());
        return null;
    }

    @Override
    public Void invokeForCampaignUpdate(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO,CampaignViewDTO dbCampaignTreeViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        campaignThirdMonitorValidateForAddCampaignAbility.handle(serviceContext, CampaignThirdMonitorValidateForAddCampaignAbilityParam.builder()
                .abilityTarget(campaignViewDTO).build());
        return null;
    }

    @Override
    public Void invokeForCampaignShowConfigGet(ServiceContext serviceContext, List<CampaignShowConfigViewDTO> showConfigViewDTOList, BusinessAbilityRouteContext routeContext) {
        CampaignTargetShowConfigGetAbilityParam showConfigGetAbilityParam = CampaignTargetShowConfigGetAbilityParam.builder()
                .abilityTarget(routeContext.getResourcePackageProductViewDTO()).productViewDTO(routeContext.getProductViewDTO())
                .resourcePackageSaleGroupViewDTO(routeContext.getPackageSaleGroupViewDTO()).build();
        // 第三方监测
        CampaignShowConfigViewDTO thirdMonitorShowConfigViewDTO = campaignThirdMonitorBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(thirdMonitorShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);

        return null;
    }

    @Override
    public Void invokeForAdgroupAdd(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, CampaignViewDTO campaignViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        adgroupThirdMonitorValidateForAddAdgroupAbility.handle(serviceContext, AdgroupThirdMonitorValidateForAddAdgroupAbilityParam.builder()
                .abilityTarget(adgroupViewDTO).campaignViewDTO(campaignViewDTO).packageSaleGroupViewDTO(businessAbilityRouteContext.getPackageSaleGroupViewDTO()).build());
        adgroupThirdMonitorInitForAddAdgroupAbility.handle(serviceContext, AdgroupThirdMonitorInitForAddAdgroupAbilityParam.builder()
                .abilityTarget(adgroupViewDTO).build());
        return null;
    }

    @Override
    public Void invokeForAdgroupUpdate(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO, CampaignViewDTO campaignViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        return invokeForAdgroupAdd(serviceContext, adgroupViewDTO, campaignViewDTO, businessAbilityRouteContext);
    }

    @Override
    public Void invokeForUpdateThirdMonitor(ServiceContext serviceContext, AdgroupViewDTO adgroupViewDTO) {
        AdgroupMonitorViewDTO adgroupMonitorViewDTO = Optional.ofNullable(adgroupViewDTO.getAdgroupMonitorViewDTO()).orElse(new AdgroupMonitorViewDTO());
        if (CollectionUtils.isEmpty(adgroupMonitorViewDTO.getThirdMonitorUrlList())) {
            adgroupThirdMonitorClearAbility.handle(serviceContext, AdgroupThirdMonitorClearAbilityParam.builder()
                    .abilityTargets(Lists.newArrayList(adgroupViewDTO)).build());
        } else {
            adgroupThirdMonitorUpdateAbility.handle(serviceContext, AdgroupThirdMonitorUpdateAbilityParam.builder()
                    .abilityTarget(adgroupViewDTO).thirdMonitorUrlList(adgroupMonitorViewDTO.getThirdMonitorUrlList()).build());
        }
        return null;
    }
}
