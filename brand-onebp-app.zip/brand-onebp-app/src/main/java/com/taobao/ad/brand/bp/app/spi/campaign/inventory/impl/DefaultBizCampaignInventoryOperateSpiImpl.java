package com.taobao.ad.brand.bp.app.spi.campaign.inventory.impl;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.nb.framework.core.AbilityFactory;
import com.alibaba.ad.nb.framework.core.annotation.AbilitySpiInstance;
import com.alibaba.hermes.framework.error.ErrorCodeAware;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.app.spi.campaign.inventory.BizCampaignInventoryOperateSpi;
import com.taobao.ad.brand.bp.app.spi.campaign.inventory.BizCampaignInventorySpi;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignInquiryOperateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignScheduleViewDTO;
import com.taobao.ad.brand.bp.client.enums.campaign.CampaignScheduleIsInventoryEnum;
import com.taobao.ad.brand.bp.common.enums.InquiryErrorTypeEnum;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.inventory.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignInventoryWorkflowParam;
import org.apache.commons.collections4.CollectionUtils;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static com.taobao.ad.brand.bp.common.spi.ExtensionPointsFactory.runAbilitySpi;

@AbilitySpiInstance(bizCode = AbilityFactory.DEFAULT_BIZ_CODE, name = "defaultBizCampaignInventoryOperateSpiImpl", desc = "库存操作默认扩展")
public class DefaultBizCampaignInventoryOperateSpiImpl implements BizCampaignInventoryOperateSpi {

    @Resource
    private ICampaignScheduleBuildForCampaignInventoryOperateAbility campaignScheduleBuildForCampaignInventoryOperateAbility;
    @Resource
    private ICampaignAmountValidateForCampaignInventoryOperateAbility campaignAmountValidateForCampaignInventoryOperateAbility;
    @Resource
    private ICampaignStatusValidateForCampaignInventoryOperateAbility campaignStatusValidateForCampaignInventoryOperateAbility;
    @Resource
    private ICampaignErrorMsgBuildForCampaignInventoryOperateAbility campaignErrorMsgBuildForCampaignInventoryOperateAbility;
    @Resource
    private ICampaignIllegalFilterForCampaignInventoryOperateAbility campaignIllegalFilterForCampaignInventoryOperateAbility;
    @Resource
    private ICampaignInquiryChannelGetForCampaignInventoryOperateAbility campaignInquiryChannelGetForCampaignInventoryOperateAbility;
    @Resource
    private ICampaignScheduleCalculateAbility campaignScheduleCalculateAbility;

    @Override
    public ErrorCodeAware validateCampaignInventoryOperate(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO, BizCampaignInventoryWorkflowParam inventoryWorkflowParam) {
        //预算曝光校验
        CampaignInventoryOperateValidateAbilityParam inventoryOperateValidateAbilityParam = CampaignInventoryOperateValidateAbilityParam.builder().abilityTargets(inventoryWorkflowParam.getCampaignScheduleViewDTOList())
                .campaignGroupViewDTOList(inventoryWorkflowParam.getCampaignGroupViewDTOList()).build();
        Map<InquiryErrorTypeEnum, Set<Long>> illegalBudgetCampaignMap = campaignAmountValidateForCampaignInventoryOperateAbility.handle(serviceContext, inventoryOperateValidateAbilityParam);
        //预算状态校验
        Map<InquiryErrorTypeEnum, Set<Long>> illegalCampaignMap = campaignStatusValidateForCampaignInventoryOperateAbility.handle(serviceContext,inventoryOperateValidateAbilityParam);
        illegalBudgetCampaignMap.putAll(illegalCampaignMap);

        CampaignInventoryOperateErrorMsgBuildAbilityParam errorMsgBuildAbilityParam = CampaignInventoryOperateErrorMsgBuildAbilityParam.builder()
                .abilityTargets(inventoryWorkflowParam.getCampaignScheduleViewDTOList()).illegalCampaignMap(illegalBudgetCampaignMap)
                .campaignViewDTOList(inventoryWorkflowParam.getCampaignTreeViewDTOList())
                .operateType(inquiryOperateViewDTO.getOperateType()).confirm(inquiryOperateViewDTO.getConfirm()).build();
        ErrorCodeAware errorCodeAware = campaignErrorMsgBuildForCampaignInventoryOperateAbility.handle(serviceContext,errorMsgBuildAbilityParam);

        campaignIllegalFilterForCampaignInventoryOperateAbility.handle(serviceContext,
                CampaignInventoryOperateIllegalAbilityParam.builder().abilityTargets(inventoryWorkflowParam.getCampaignScheduleViewDTOList())
                        .illegalCampaignMap(illegalBudgetCampaignMap).build());
        return errorCodeAware;
    }

    @Override
    public List<CampaignScheduleViewDTO> convertToCampaignSchedule(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO, BizCampaignInventoryWorkflowParam inventoryWorkflowParam) {
        if(CollectionUtils.isEmpty(inventoryWorkflowParam.getCampaignTreeViewDTOList())){
            return Lists.newArrayList();
        }
        CampaignInventoryAbilityParam abilityParam = CampaignInventoryAbilityParam.builder().abilityTarget(inquiryOperateViewDTO).campaignScheduleViewDTOList(inventoryWorkflowParam.getCampaignScheduleViewDTOList())
                .campaignGroupViewDTOList(inventoryWorkflowParam.getCampaignGroupViewDTOList()).campaignTreeViewDTOList(inventoryWorkflowParam.getCampaignTreeViewDTOList()).build();
        List<CampaignScheduleViewDTO> campaignScheduleViewDTOList = campaignScheduleBuildForCampaignInventoryOperateAbility.handle(serviceContext, abilityParam);
        for (CampaignScheduleViewDTO campaignScheduleViewDTO : campaignScheduleViewDTOList) {
            campaignScheduleCalculateAbility.handle(serviceContext, CampaignScheduleCalculateAbilityParam.builder().abilityTarget(campaignScheduleViewDTO).build());
        }
        return campaignScheduleViewDTOList;
    }

    @Override
    public Void inventoryRequest(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO,
                                 BizCampaignInventoryWorkflowParam inventoryWorkflowParam) {
        List<CampaignScheduleViewDTO> campaignScheduleViewDTOList = inventoryWorkflowParam.getCampaignScheduleViewDTOList();
        List<CampaignViewDTO> campaignTreeViewDTOList = inventoryWorkflowParam.getCampaignTreeViewDTOList();
        //1. 计划和排期归两类，需要走库存的，和不需要走库存的
//        Map<Integer, List<CampaignViewDTO>> isInventoryCampaignMap = getIsInventoryCampaignMap(campaignTreeViewDTOList);
        Map<Integer, List<CampaignViewDTO>> isInventoryCampaignMap = campaignInquiryChannelGetForCampaignInventoryOperateAbility.handle(serviceContext,
                CampaignInventoryOperateChannelGetAbilityParam.builder().abilityTargets(campaignTreeViewDTOList).build());

        Map<Integer, List<CampaignScheduleViewDTO>> programmaticCampaignScheduleMap = getIsInventoryCampaignScheduleMap(campaignScheduleViewDTOList, isInventoryCampaignMap);
        //2. 不需要走库存的询量和锁量自动分配每天库存预定量,需要走库存的发起库存
        for(Map.Entry<Integer, List<CampaignViewDTO>> entry : isInventoryCampaignMap.entrySet()){
            runAbilitySpi(BizCampaignInventorySpi.class,
                    extension -> extension.inventoryRequest(serviceContext, inquiryOperateViewDTO, entry.getValue(),programmaticCampaignScheduleMap.get(entry.getKey())),
                    CampaignScheduleIsInventoryEnum.getByValue(entry.getKey()).name());
        }
        return null;
    }

    /**
     * 系统投放/非系统投放计划map
     * @param campaignScheduleViewDTOList
     * @return
     */
    protected Map<Integer, List<CampaignScheduleViewDTO>> getIsInventoryCampaignScheduleMap(List<CampaignScheduleViewDTO> campaignScheduleViewDTOList, Map<Integer, List<CampaignViewDTO>> isInventoryCampaignMap){
        if(isInventoryCampaignMap.isEmpty() || CollectionUtils.isEmpty(campaignScheduleViewDTOList)){
            return Maps.newHashMap();
        }
        Map<Integer, List<CampaignScheduleViewDTO>> isInventoryScheduleMap = Maps.newHashMap();
        for(Map.Entry<Integer, List<CampaignViewDTO>> entry : isInventoryCampaignMap.entrySet()){
            List<Long> campaignIds = entry.getValue().stream().map(e->e.getId()).collect(Collectors.toList());
            List<CampaignScheduleViewDTO> subCampaignScheduleViewDTOList = campaignScheduleViewDTOList.stream().filter(e->campaignIds.contains(e.getId())).collect(Collectors.toList());
            isInventoryScheduleMap.put(entry.getKey(), subCampaignScheduleViewDTOList);
        }
        return isInventoryScheduleMap;
    }

//    /**
//     * 计划预定量校验
//     */
//    protected Map<InquiryErrorTypeEnum, Set<Long>> validateCampaignAmount(ServiceContext serviceContext, List<CampaignScheduleViewDTO> scheduleViewDTOList) {
//        Map<InquiryErrorTypeEnum, Set<Long>> illegalCampaignMap = Maps.newHashMap();
//        for (CampaignScheduleViewDTO parent : scheduleViewDTOList) {
//            List<Long> operateSubCampaignIds = parent.getOperateSubCampaignIds();
//            Long parentBudget =  Optional.ofNullable(parent.getDiscountTotalMoney()).orElse(0L);
//            //计划未分配预算，需要点击订单计算
//            if(!NumberUtil.greaterThanZero(parentBudget)){
//                illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.INQUIRY_CAMPAIGN_BUDGET_ERROR, k -> Sets.newHashSet()).add(parent.getId());
//            }
//            Long parentAmount = parent.getFutureAmount();
//            if (!NumberUtil.greaterThanZero(parentAmount)) {
//                //如果全历史锁量场景，不做校验处理
//                if(BizCampaignToolsHelper.isAllHistoryLockSuccess(parent)){
//                    if(!CampaignScheduleOperateTypeEnum.LOCK.isSelf(parent.getOperateType())){
//                        illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.INQUIRY_CAMPAIGN_BUDGET_ERROR, k -> Sets.newHashSet()).add(parent.getId());
//                    }
//                }else{
//                    illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.INQUIRY_CAMPAIGN_BUDGET_ERROR, k -> Sets.newHashSet()).add(parent.getId());
//                }
//            }
//
//            Long subSumBudget = 0L;
//            for (CampaignScheduleViewDTO sub : parent.getSubCampaignList()) {
//                //计划未分配预算，需要点击订单计算
//                if(!NumberUtil.greaterThanZero(sub.getDiscountTotalMoney())){
//                    illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.INQUIRY_CAMPAIGN_BUDGET_ERROR, k -> Sets.newHashSet()).add(sub.getId());
//                }
//                subSumBudget += Optional.ofNullable(sub.getDiscountTotalMoney()).orElse(0L);
//                if (!operateSubCampaignIds.contains(sub.getId())) {
//                    continue;
//                }
//                //未来预定量等于0，说明都是历史，历史不能进行分配操作
//                Long subAmount = sub.getFutureAmount();
//                if (!NumberUtil.greaterThanZero(subAmount)) {
////                  //如果全历史锁量场景，不做校验处理
//                    if(BizCampaignToolsHelper.isAllHistoryLockSuccess(sub)){
//                        if(!CampaignScheduleOperateTypeEnum.LOCK.isSelf(sub.getOperateType())){
//                            illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.INQUIRY_CAMPAIGN_BUDGET_ERROR, k -> Sets.newHashSet()).add(sub.getId());
//                        }
//                    }else{
//                        illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.INQUIRY_CAMPAIGN_BUDGET_ERROR, k -> Sets.newHashSet()).add(sub.getId());
//                    }
//                }
//            }
//            if(!MediaScopeEnum.CROSS_SCOPE.getCode().equals(parent.getSspMediaScope())){
//                RogerLogger.info("un cross scope parentBudget {} and subSumBudget {}",parentBudget,subSumBudget);
//                if(!parentBudget.equals(subSumBudget)){
//                    illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.INQUIRY_CAMPAIGN_ASSIGN_BUDGET_ERROR, k -> Sets.newHashSet()).addAll(operateSubCampaignIds);
//                }
//            }
//        }
//        return illegalCampaignMap;
//    }
//
//    /**
//     * 询锁释量中的计划不可再发起询锁释，除非已经完成或失败
//     */
//    protected Map<InquiryErrorTypeEnum, Set<Long>> validateCampaignStatus(ServiceContext serviceContext, List<CampaignGroupViewDTO> campaignGroupViewDTOList, List<CampaignScheduleViewDTO> campaignScheduleViewDTOList) {
//
//        Map<Long, CampaignGroupViewDTO> campaignGroupMap = Optional.ofNullable(campaignGroupViewDTOList).orElse(Lists.newArrayList())
//                .stream().collect(Collectors.toMap(item -> item.getId(), Function.identity()));
//
//        Map<InquiryErrorTypeEnum, Set<Long>> illegalCampaignMap = Maps.newHashMap();
//        for (CampaignScheduleViewDTO campaignScheduleViewDTO : campaignScheduleViewDTOList) {
//            List<Long> operateCampaignIds = campaignScheduleViewDTO.getOperateSubCampaignIds();
//            for (CampaignScheduleViewDTO subCampaign : campaignScheduleViewDTO.getSubCampaignList()) {
//                Date deadlineDate = BizCampaignToolsHelper.inquiryDeadline(subCampaign.getSaleType(),subCampaign.getInquiryViewDTOList(),subCampaign.getFirstOnlineTime());
//                Integer operateType = subCampaign.getOperateType();
//                if (!operateCampaignIds.contains(subCampaign.getId())) {
//                    continue;
//                }
//                // 订单状态
//                if (subCampaign.getCampaignGroupId() != null && campaignGroupMap.containsKey(subCampaign.getCampaignGroupId())) {
//                    CampaignGroupViewDTO campaignGroupViewDTO = campaignGroupMap.get(subCampaign.getCampaignGroupId());
//                    if (BrandCampaignGroupStatusEnum.CANCELED.getCode().equals(campaignGroupViewDTO.getStatus())) {
//                        illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.INQUIRY_OR_LOCK_CAMPAIGN_GROUP_STATUS_ERROR, k -> Sets.newHashSet()).add(
//                                subCampaign.getId());
//                    }
//                }
//                boolean isCPT = BizCampaignToolsHelper.isCPT(subCampaign.getSspRegisterUnit());
//                //cpt需指定分天预定量
//                if (isCPT && CollectionUtils.isEmpty(subCampaign.getInquiryViewDTOList()) && !BizCampaignToolsHelper.isDoohCampaign(subCampaign.getSspProductLineId())) {
//                    illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.CAMPAIGN_CPT_ROUND_ERROR, k -> Sets.newHashSet()).add(
//                            subCampaign.getId());
//                }
//                //未来日期不存在
//                if (!CampaignScheduleOperateTypeEnum.RELEASE_CALLBACK.isSelf(operateType) && BrandDateUtil.isAfter(deadlineDate,
//                        subCampaign.getEndTime())) {
//                    if(!BizCampaignToolsHelper.isAllHistoryLockSuccess(subCampaign) && !CampaignScheduleOperateTypeEnum.LOCK.isSelf(subCampaign.getOperateType())){
//                        illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.OPERATE_CAMPAIGN_DATE_ERROR, k -> Sets.newHashSet()).add(
//                            subCampaign.getId());
//                    }
//                }
//
//                //二环校验CPM量至少每天一个 (选择部分周期智能分配除外, 此策略可以允许部分日期预定量为空)
//                List<CampaignInquiryViewDTO> futureInquiryList = subCampaign.getFutureInquiryList();
//                if (!isCPT && MediaScopeEnum.TAO_OUT.getCode().equals(subCampaign.getSspMediaScope()) && NumberUtil.greaterThanZero(subCampaign.getFutureAmount())) {
//                    if (CollectionUtils.isNotEmpty(futureInquiryList)
//                            && futureInquiryList.size() > NumberUtil.getCpmAmount(subCampaign.getFutureAmount())) {
//                        illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.CAMPAIGN_AMOUNT_LACK_ERROR,
//                                k -> Sets.newHashSet()).add(subCampaign.getId());
//                    } else if (CollectionUtils.isEmpty(futureInquiryList)
//                            && !BrandCampaignInquiryAssignTypeEnum.PERIOD_PART_INTELLIGENCE.getCode().equals(subCampaign.getInquiryAssignType())) {
//                        Date startTime = BrandDateUtil.maxDate(deadlineDate, subCampaign.getStartTime());
//                        int numOfDaysBetweenDate = BrandDateUtil.getNumOfDaysBetweenDate(startTime, subCampaign.getEndTime());
//                        if (numOfDaysBetweenDate > NumberUtil.getCpmAmount(subCampaign.getFutureAmount())) {
//                            illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.CAMPAIGN_AMOUNT_LACK_ERROR,
//                                    k -> Sets.newHashSet()).add(subCampaign.getId());
//                        }
//                    }
//                }
//
//                //计划存在历史未锁的预定量，需要调整到未来
//                long unlockDayCount = Optional.ofNullable(subCampaign.getHistoryInquiryList()).orElse(Lists.newArrayList()).stream().filter(
//                        v -> !BrandInquiryStatusEnum.SUCCESS.getCode().equals(v.getStatus())).count();
//                if (NumberUtil.greaterThanZero(unlockDayCount)) {
//                    illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.CAMPAIGN_HISTORY_UNLOCK_BOOKING_AMOUNT_ERROR, k -> Sets.newHashSet()).add(
//                            subCampaign.getId());
//                }
//
//                //计划状态校验
//                if (CampaignScheduleOperateTypeEnum.INQUIRY.isSelf(operateType)) {
//                    if (!Constant.CAN_INQUIRY_LOCK_STATUS.contains(subCampaign.getStatus())) {
//                        illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.INQUIRY_CAMPAIGN_STATUS_ERROR, k -> Sets.newHashSet()).add(
//                                subCampaign.getId());
//                    }
//                } else if (CampaignScheduleOperateTypeEnum.LOCK.isSelf(operateType)) {
//                    if (!Constant.CAN_INQUIRY_LOCK_STATUS.contains(subCampaign.getStatus())) {
//                        illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.INQUIRY_CAMPAIGN_STATUS_ERROR, k -> Sets.newHashSet()).add(
//                                subCampaign.getId());
//                    }
//                } else if (CampaignScheduleOperateTypeEnum.RELEASE.isSelf(operateType)) {
//                    //不做操作
//                } else if (CampaignScheduleOperateTypeEnum.MEDIA_INQUIRY.isSelf(operateType)) {
//                    if (!Constant.CAN_MEDIA_INQUIRY_STATUS.contains(subCampaign.getStatus())) {
//                        illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.MEDIA_INQUIRY_CAMPAIGN_STATUS_ERROR, k -> Sets.newHashSet()).add(
//                                subCampaign.getId());
//                    }
//                    if (!MediaScopeEnum.SITE_OUT.getCode().equals(subCampaign.getSspMediaScope())) {
//                        illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.MEDIA_INQUIRY_CAMPAIGN_SCOPE_ERROR, k -> Sets.newHashSet()).add(
//                                subCampaign.getId());
//                    }
//                    if (BrandSaleTypeEnum.BOOST.getCode().equals(subCampaign.getSaleType())) {
//                        illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.MANDATORY_LOCK_NOT_SUPPORT_BOOST_ERROR, k -> Sets.newHashSet()).add(
//                                subCampaign.getId());
//                    }
//                    if (BrandCampaignProgrammaticEnum.UN_SYSTEM_CAST.getCode().equals(subCampaign.getSspProgrammatic())) {
//                        illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.MANDATORY_LOCK_NOT_SUPPORT_HOLDER_ERROR, k -> Sets.newHashSet()).add(
//                                subCampaign.getId());
//                    }
//                } else if (CampaignScheduleOperateTypeEnum.MANDATORY_LOCK.isSelf(operateType)) {
//                    if (!Constant.CAN_MANDATORY_LOCK_STATUS.contains(subCampaign.getStatus())) {
//                        illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.MANDATORY_LOCK_CAMPAIGN_STATUS_ERROR, k -> Sets.newHashSet()).add(
//                                subCampaign.getId());
//                    }
//                    CampaignViewDTO campaignViewDTO=campaignRepository.getCampaignById(serviceContext, subCampaign.getId());
//                    //二环 && 特秀/showMax 允许超接
//                    if (!MediaScopeEnum.TAO_OUT.getCode().equals(subCampaign.getSspMediaScope())
//                            && !SaleProductLineEnum.TE_XIU.getValue().equals(campaignViewDTO.getCampaignSaleViewDTO().getSaleProductLine())
//                            && !SaleProductLineEnum.SHOW_MAX.getValue().equals(campaignViewDTO.getCampaignSaleViewDTO().getSaleProductLine())) {
//                        illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.MANDATORY_LOCK_CAMPAIGN_SCOPE_ERROR, k -> Sets.newHashSet()).add(
//                                subCampaign.getId());
//                    }
//                } else if (CampaignScheduleOperateTypeEnum.INQUIRY_CALLBACK.isSelf(operateType)) {
//                    if (!BrandCampaignStatusEnum.INQUIRING.getCode().equals(subCampaign.getStatus())) {
//                        illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.INQUIRY_CAMPAIGN_STATUS_ERROR, k -> Sets.newHashSet()).add(
//                                subCampaign.getId());
//                    }
//                } else if (CampaignScheduleOperateTypeEnum.LOCK_CALLBACK.isSelf(operateType)) {
//                    if (!BrandCampaignStatusEnum.LOCKING.getCode().equals(subCampaign.getStatus())) {
//                        illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.INQUIRY_CAMPAIGN_STATUS_ERROR, k -> Sets.newHashSet()).add(
//                                subCampaign.getId());
//                    }
//                } else if (CampaignScheduleOperateTypeEnum.RELEASE_CALLBACK.isSelf(operateType)) {
//                    if (!BrandCampaignStatusEnum.RELEASING.getCode().equals(subCampaign.getStatus())) {
//                        illegalCampaignMap.computeIfAbsent(InquiryErrorTypeEnum.INQUIRY_CAMPAIGN_STATUS_ERROR, k -> Sets.newHashSet()).add(
//                                subCampaign.getId());
//                    }
//                }
//            }
//        }
//        return illegalCampaignMap;
//    }

//    /**
//     * 过滤不满足业务要求的计划
//     * @param campaignScheduleViewDTOList
//     * @param illegalCampaignMap
//     */
//    protected void filterIllegalCampaign(List<CampaignScheduleViewDTO> campaignScheduleViewDTOList, Map<InquiryErrorTypeEnum, Set<Long>> illegalCampaignMap) {
//        Set<Long> illegalCampaigns = illegalCampaignMap.values().stream().flatMap(Collection::stream).collect(Collectors.toSet());
//        for (CampaignScheduleViewDTO campaignScheduleViewDTO : campaignScheduleViewDTOList) {
//            List<Long> operateSubCampaignIds = campaignScheduleViewDTO.getOperateSubCampaignIds().stream().filter(v -> !illegalCampaigns.contains(v))
//                    .collect(Collectors.toList());
//            campaignScheduleViewDTO.setOperateSubCampaignIds(operateSubCampaignIds);
//        }
//    }

//    /**
//     * 校验生成错误信息
//     */
//    protected ErrorCodeAware convertToErrorMsg(ServiceContext serviceContext, Map<InquiryErrorTypeEnum, Set<Long>> illegalCampaignMap,
//                                            Integer operateType, List<CampaignViewDTO> campaignViewDTOList, List<CampaignScheduleViewDTO> campaignScheduleViewDTOList, Integer confirm) {
//
//        boolean aliStaff = ServiceContextUtil.isAliStaff(serviceContext);
//        List<String> errorMsgList = buildErrorMsg(aliStaff, illegalCampaignMap, campaignViewDTOList);
//
//        List<Long> operateCampaignIdList = campaignScheduleViewDTOList.stream().flatMap(v -> v.getOperateSubCampaignIds().stream()).collect(
//                Collectors.toList());
//        Set<Long> illegalCampaigns = illegalCampaignMap.values().stream().flatMap(Collection::stream).collect(Collectors.toSet());
//        List<Long> effectiveSubCampaignIds = operateCampaignIdList.stream().filter(v -> !illegalCampaigns.contains(v)).collect(Collectors.toList());
//        String tips = getTips(operateType);
//        if (CollectionUtils.isNotEmpty(effectiveSubCampaignIds) && tips != null) {
//            List<Long> convertCampaignIdList = convertCampaignIdByLogIn(effectiveSubCampaignIds, campaignViewDTOList, aliStaff);
//            String effectiveCampaignStr = convertCampaignIdList.stream().map(Object::toString).collect(Collectors.joining(","));
//            errorMsgList.add(String.format(tips, effectiveCampaignStr));
//        }
//        String errorMsg = String.join(",", errorMsgList);
//
//        //计划校验全部失败
//        AssertUtil.assertTrue(!effectiveSubCampaignIds.isEmpty(), BrandOneBPCustomErrorCode.BIZ_UN_SUPPORT_INQUIRY_ALL_ERROR_ERROR, errorMsg);
//        if (BrandBoolEnum.BRAND_FALSE.getCode().equals(confirm)) {
//            //计划校验部分失败
//            AssertUtil.assertTrue(effectiveSubCampaignIds.size() < operateCampaignIdList.size(),
//                    BrandOneBPCustomErrorCode.BIZ_UN_SUPPORT_INQUIRY_PART_ERROR_ERROR, errorMsg);
//            //计划校验全部成功
//            AssertUtil.assertTrue(effectiveSubCampaignIds.size() == operateCampaignIdList.size(),
//                    BrandOneBPCustomErrorCode.BIZ_UN_SUPPORT_INQUIRY_DEFAULT_ERROR_ERROR, errorMsg);
//        }
//
//        if (effectiveSubCampaignIds.size() < operateCampaignIdList.size()) {
//            return ErrorCodeAware.Builder.build(BrandOneBPCustomErrorCode.BIZ_UN_SUPPORT_INQUIRY_PART_ERROR_ERROR.getErrCode(), errorMsg);
//        }
//        return null;
//    }
//
//    protected List<String> buildErrorMsg(boolean aliStaff, Map<InquiryErrorTypeEnum, Set<Long>> illegalCampaignMap,
//                                      List<CampaignViewDTO> campaignViewDTOList) {
//
//        List<String> errorMsgList = Lists.newArrayList();
//        Set<Long> campaignIdSet = Sets.newHashSet();
//        for (Map.Entry<InquiryErrorTypeEnum, Set<Long>> entry : illegalCampaignMap.entrySet()) {
//            List<Long> illegalCampaigns = convertCampaignIdByLogIn(Lists.newArrayList(entry.getValue()), campaignViewDTOList, aliStaff);
//            illegalCampaigns = illegalCampaigns.stream().filter(v -> !campaignIdSet.contains(v)).collect(Collectors.toList());
//            if (CollectionUtils.isEmpty(illegalCampaigns)) {
//                continue;
//            }
//            String illegalCampaignStr = illegalCampaigns.stream().map(Object::toString).collect(Collectors.joining(","));
//            errorMsgList.add(entry.getKey().getDesc() + ":" + illegalCampaignStr);
//            campaignIdSet.addAll(illegalCampaigns);
//        }
//        return errorMsgList;
//    }
//
//    private String getTips(Integer operateType) {
//        if (CampaignScheduleOperateTypeEnum.INQUIRY.isSelf(operateType)) {
//            return InquiryErrorTypeEnum.INQUIRY_CAMPAIGN_DEFAULT_TIP.getDesc();
//        } else if (CampaignScheduleOperateTypeEnum.LOCK.isSelf(operateType)) {
//            return InquiryErrorTypeEnum.LOCK_CAMPAIGN_DEFAULT_TIP.getDesc();
//        } else if (CampaignScheduleOperateTypeEnum.RELEASE.isSelf(operateType)) {
//            return InquiryErrorTypeEnum.RELEASE_CAMPAIGN_DEFAULT_TIP.getDesc();
//        }
//        return null;
//    }
//
//    /**
//     * 根据登陆信息转换计划ID
//     */
//    private List<Long> convertCampaignIdByLogIn(List<Long> campaignIdList, List<CampaignViewDTO> campaignViewDTOList, boolean aliStaff) {
//        Map<Long, Boolean> campaignCopyTypeMap = Maps.newHashMap();
//        for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
//            if (CollectionUtils.isNotEmpty(campaignViewDTO.getSubCampaignViewDTOList())) {
//                campaignViewDTO.getSubCampaignViewDTOList().forEach(
//                        v -> campaignCopyTypeMap.put(v.getId(), BizCampaignToolsHelper.isCopyParentCampaign(v)));
//            }
//        }
//        Map<Long, Long> subParentCampaignMap = Maps.newHashMap();
//        for (CampaignViewDTO campaignViewDTO : campaignViewDTOList) {
//            if (CollectionUtils.isEmpty(campaignViewDTO.getSubCampaignViewDTOList())) {
//                continue;
//            }
//            campaignViewDTO.getSubCampaignViewDTOList().forEach(
//                    v -> subParentCampaignMap.put(v.getId(), campaignViewDTO.getId()));
//        }
//
//        List<Long> convertedCampaignIdList;
//        if (!aliStaff) {
//            //父计划ID原样返回，子计划返回父计划ID
//            convertedCampaignIdList = campaignIdList.stream().map(v -> subParentCampaignMap.getOrDefault(v, v)).distinct().collect(Collectors.toList());
//        } else {
//            convertedCampaignIdList = campaignIdList.stream().map(v -> {
//                //父计划
//                if (campaignCopyTypeMap.get(v) == null) {
//                    return v;
//                }
//                //复制出来的子计划返回父计划ID
//                if (campaignCopyTypeMap.get(v)) {
//                    return subParentCampaignMap.getOrDefault(v, v);
//                }
//                //返回子计划ID
//                return v;
//            }).distinct().collect(Collectors.toList());
//        }
//        return convertedCampaignIdList;
//    }
}

