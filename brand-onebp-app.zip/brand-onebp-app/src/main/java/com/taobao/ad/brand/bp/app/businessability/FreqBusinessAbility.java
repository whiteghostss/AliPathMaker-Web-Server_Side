package com.taobao.ad.brand.bp.app.businessability;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.abf.spec.business.annotation.BusinessAbility;
import com.alibaba.ad.brand.dto.adgroup.AdgroupViewDTO;
import com.alibaba.ad.brand.dto.base.BaseViewDTO;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.brand.dto.campaign.frequence.CampaignFrequencyViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.CampaignGroupViewDTO;
import com.alibaba.ad.brand.dto.campaigngroup.sale.SaleGroupInfoViewDTO;
import com.alibaba.ad.brand.dto.frequency.FrequencyViewDTO;
import com.alibaba.ad.brand.sdk.constant.campaign.field.BrandCampaignLevelEnum;
import com.alibaba.ad.brand.sdk.constant.common.BrandBoolEnum;
import com.alibaba.ad.nb.ssp.constant.newproduct.ProductDirectionEnum;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.ad.brand.bp.client.dto.base.CommonViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignShowConfigViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaigngroup.CampaignGroupOrderCommandViewDTO;
import com.taobao.ad.brand.bp.client.dto.product.ProductDirectionViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.domain.campaigngroup.repository.CampaignGroupRepository;
import com.taobao.ad.brand.bp.domain.frequency.repository.FrequencyRepository;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.frequency.IAdgroupFrequencyDateUpdateAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.frequency.IAdgroupFrequencyRefSaveAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.frequency.IAdgroupFrequencyValidateForBindAdgroupAbility;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.atomability.param.AdgroupFrequencyAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.businessability.IAdgroupBindBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.adgroup.businessability.IAdgroupRelieveBusinessAbilityPoint;
import com.taobao.ad.brand.bp.domain.sdk.base.businessability.BusinessAbilityRouteContext;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.frequency.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.showconfig.ICampaignFrequencyBuildForShowConfigGetAbility;
import com.taobao.ad.brand.bp.domain.sdk.campaign.businessability.*;
import com.taobao.ad.brand.bp.domain.sdk.campaigngroup.businessability.ICampaignGroupOrderBusinessAbilityPoint;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@BusinessAbility(tag = FreqBusinessAbility.ABILITY_CODE, name = "频控商业能力", desc = "频控商业能力结构化实现类")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class FreqBusinessAbility implements
        ICampaignAddBusinessAbilityPoint, ICampaignUpdateBusinessAbilityPoint, ICampaignBindBusinessAbilityPoint, ICampaignRelieveBusinessAbilityPoint,
        ICampaignQueryBusinessAbilityPoint,ICampaignGroupOrderBusinessAbilityPoint,
        IAdgroupBindBusinessAbilityPoint, IAdgroupRelieveBusinessAbilityPoint{

    public static final String ABILITY_CODE = "BUSINESS_ABILITY_FREQ";

    private final FrequencyRepository frequencyRepository;
    private final CampaignGroupRepository campaignGroupRepository;

    private final ICampaignFrequencyValidateForAddCampaignAbility campaignFrequencyValidateForAddCampaignAbility;
    private final ICampaignFrequencyInitForAddCampaignAbility campaignFrequencyInitForAddCampaignAbility;
    private final ICampaignFrequencyValidateForUpdateCampaignAbility campaignFrequencyValidateForUpdateCampaignAbility;
    private final ICampaignFrequencyInitForUpdateCampaignAbility campaignFrequencyInitForUpdateCampaignAbility;
    private final ICampaignFrequencyValidateForBindCampaignAbility campaignFrequencyValidateForBindCampaignAbility;
    private final ICampaignFrequencyDateUpdateAbility campaignFrequencyDateUpdateAbility;
    private final ICampaignFrequencyRefSaveAbility campaignFrequencyRefSaveAbility;
    private final ICampaignSessionFilterInitForCampaignAbility campaignSessionFilterInitForCampaignAbility;
    private final IAdgroupFrequencyValidateForBindAdgroupAbility adgroupFrequencyValidateForBindAdgroupAbility;
    private final IAdgroupFrequencyDateUpdateAbility adgroupFrequencyDateUpdateAbility;
    private final IAdgroupFrequencyRefSaveAbility adgroupFrequencyRefSaveAbility;
    private final ICampaignFrequencyBuildForShowConfigGetAbility campaignFrequencyTargetBuildForShowConfigGetAbility;
    private final ICampaignFrequencyValidateForOrderCampaignGroupAbility campaignFrequencyValidateForOrderCampaignGroupAbility;

    @Override
    public boolean routeChecking(String bizCode, BaseViewDTO baseViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        List<String> specifiedBusinessCodes = businessAbilityRouteContext.getSpecifiedBusinessAbilityCodes();
        if (CollectionUtils.isNotEmpty(specifiedBusinessCodes) && specifiedBusinessCodes.contains(ABILITY_CODE)) {
            return true;
        }
        if (Objects.nonNull(businessAbilityRouteContext.getPackageSaleGroupViewDTO()) && Objects.nonNull(businessAbilityRouteContext.getResourcePackageProductViewDTO())) {
            return BrandBoolEnum.BRAND_TRUE.getCode().equals(businessAbilityRouteContext.getPackageSaleGroupViewDTO().getSupportOptimizedFrequency())
                    || Optional.ofNullable(businessAbilityRouteContext.getResourcePackageProductViewDTO().getTargetList()).orElse(Lists.newArrayList()).stream().anyMatch(target -> ProductDirectionEnum.FREQUENCY.getType().equals(target.getValue()) && Boolean.TRUE.equals(target.getSelected()));
        }
        return false;
    }

    @Override
    public Void invokeForCampaignAdd(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        // 只有一级计划需要进行频控校验和初始化动作，二级计划会在最后的频控保存环节直接和一级计划的频控进行关联
        if (BrandCampaignLevelEnum.LEVEL_TWO_CAMPAIGN.getCode().equals(campaignViewDTO.getCampaignLevel())) {
            return null;
        }
        FrequencyViewDTO frequencyViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignFrequencyViewDTO()).map(CampaignFrequencyViewDTO::getFrequencyViewDTO).orElse(null);
        SaleGroupInfoViewDTO saleGroupInfoViewDTO = campaignGroupRepository.getSaleGroup(serviceContext, campaignViewDTO.getCampaignGroupId(), campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId());
        campaignFrequencyValidateForAddCampaignAbility.handle(serviceContext, CampaignFrequencyForAddCampaignAbilityParam.builder()
                .abilityTarget(frequencyViewDTO).campaignViewDTO(campaignViewDTO).saleGroupInfoViewDTO(saleGroupInfoViewDTO).build());
        campaignFrequencyInitForAddCampaignAbility.handle(serviceContext, CampaignFrequencyForAddCampaignAbilityParam.builder()
                .abilityTarget(frequencyViewDTO).campaignViewDTO(campaignViewDTO).build());
        //一次请求多次曝光是否需过滤
        campaignSessionFilterInitForCampaignAbility.handle(serviceContext, CampaignSessionFilterForCampaignAbilityParam.builder().abilityTarget(campaignViewDTO).build());
        return null;
    }

    @Override
    public Void invokeForAfterCampaignAdd(ServiceContext serviceContext, List<CampaignViewDTO> allCampaignViewDTOList, BusinessAbilityRouteContext businessAbilityRouteContext) {
        // 【一级计划】修改频控规则
        List<CampaignViewDTO> levelOneCampaignList = allCampaignViewDTOList.stream().filter(e -> BrandCampaignLevelEnum.LEVEL_ONE_CAMPAIGN.getCode().equals(e.getCampaignLevel())).collect(Collectors.toList());
        if(CollectionUtils.isNotEmpty(levelOneCampaignList)){
            frequencyRepository.saveCampaignFrequency(serviceContext, levelOneCampaignList);
            Map<Long, FrequencyViewDTO> frequencyViewDTOMap = frequencyRepository.getCampaignFrequency(serviceContext, levelOneCampaignList.stream().map(it -> it.getId()).collect(Collectors.toList()));
            if (Objects.nonNull(frequencyViewDTOMap) && CollectionUtils.isNotEmpty(frequencyViewDTOMap.values())) {
                for (FrequencyViewDTO dbFrequency : frequencyViewDTOMap.values()) {
                    campaignFrequencyDateUpdateAbility.handle(serviceContext, CampaignFrequencyForBindCampaignAbilityParam.builder().abilityTarget(dbFrequency).build());
                }
            }
        }
        // 【二级计划】只需保存频控ref信息，关联到一级计划
        List<CampaignViewDTO> levelTwoCampaignList = allCampaignViewDTOList.stream().filter(e -> BrandCampaignLevelEnum.LEVEL_TWO_CAMPAIGN.getCode().equals(e.getCampaignLevel())).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(levelTwoCampaignList)) {
            // 获取一级计划频控信息
            List<Long> levelOneCampaignIds = levelTwoCampaignList.stream().map(CampaignViewDTO::getParentCampaignId).distinct().collect(Collectors.toList());
            Map<Long, FrequencyViewDTO> campaignFrequencyMap = frequencyRepository.getCampaignFrequency(serviceContext, levelOneCampaignIds);
            // 修改二级计划频控ref
            Map<Long, List<CampaignViewDTO>> levelTwoCampaignGroup = levelTwoCampaignList.stream().collect(Collectors.groupingBy(CampaignViewDTO::getParentCampaignId));
            for (Map.Entry<Long, List<CampaignViewDTO>> entry : levelTwoCampaignGroup.entrySet()) {
                Long parentCampaignId = entry.getKey();
                FrequencyViewDTO frequencyViewDTO = campaignFrequencyMap.get(parentCampaignId);
                List<Long> subCampaignIds = entry.getValue().stream().map(CampaignViewDTO::getId).collect(Collectors.toList());
                if (Objects.nonNull(frequencyViewDTO)) {
                    frequencyRepository.saveCampaignFreqRef(serviceContext, frequencyViewDTO.getId(), subCampaignIds);
                } else {
                    frequencyRepository.deleteCampaignFreqRef(serviceContext, subCampaignIds);
                }
            }
        }
        return null;
    }

    @Override
    public Void invokeForCampaignUpdate(ServiceContext serviceContext, CampaignViewDTO campaignViewDTO, CampaignViewDTO dbCampaignTreeViewDTO, BusinessAbilityRouteContext businessAbilityRouteContext) {
        // 只有一级计划需要进行频控校验和初始化动作，二级计划会在最后的频控保存环节直接和一级计划的频控进行关联
        if (BrandCampaignLevelEnum.LEVEL_TWO_CAMPAIGN.getCode().equals(campaignViewDTO.getCampaignLevel())) {
            return null;
        }
        SaleGroupInfoViewDTO saleGroupInfoViewDTO = campaignGroupRepository.getSaleGroup(serviceContext, campaignViewDTO.getCampaignGroupId(), campaignViewDTO.getCampaignSaleViewDTO().getSaleGroupId());
        FrequencyViewDTO frequencyViewDTO = Optional.ofNullable(campaignViewDTO.getCampaignFrequencyViewDTO()).map(CampaignFrequencyViewDTO::getFrequencyViewDTO).orElse(null);

        campaignFrequencyValidateForAddCampaignAbility.handle(serviceContext, CampaignFrequencyForAddCampaignAbilityParam.builder()
                .abilityTarget(frequencyViewDTO).saleGroupInfoViewDTO(saleGroupInfoViewDTO).campaignViewDTO(campaignViewDTO).build());
        campaignFrequencyValidateForUpdateCampaignAbility.handle(serviceContext, CampaignFrequencyForUpdateCampaignAbilityParam.builder()
                .abilityTarget(frequencyViewDTO).dbCampaignViewDTO(dbCampaignTreeViewDTO).saleGroupInfoViewDTO(saleGroupInfoViewDTO).build());
        campaignFrequencyInitForUpdateCampaignAbility.handle(serviceContext, CampaignFrequencyForUpdateCampaignAbilityParam.builder()
                .abilityTarget(frequencyViewDTO).campaignViewDTO(campaignViewDTO).dbCampaignViewDTO(dbCampaignTreeViewDTO).build());
        //一次请求多次曝光是否需过滤
        campaignSessionFilterInitForCampaignAbility.handle(serviceContext, CampaignSessionFilterForCampaignAbilityParam.builder()
                .abilityTarget(campaignViewDTO).dbCampaignViewDTO(dbCampaignTreeViewDTO).build());
        return null;
    }

    @Override
    public Void invokeForAfterCampaignUpdate(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList, BusinessAbilityRouteContext businessAbilityRouteContext) {
        return invokeForAfterCampaignAdd(serviceContext,campaignViewDTOList,businessAbilityRouteContext);
    }

    @Override
    public Void invokeForCampaignBind(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList, Long freqId, BusinessAbilityRouteContext businessAbilityRouteContext) {
        FrequencyViewDTO dbFrequency = frequencyRepository.getFrequencyById(serviceContext, freqId);
        campaignFrequencyValidateForBindCampaignAbility.handle(serviceContext, CampaignFrequencyForBindCampaignAbilityParam.builder().campaignViewDTOList(campaignViewDTOList).abilityTarget(dbFrequency).build());
        campaignFrequencyDateUpdateAbility.handle(serviceContext, CampaignFrequencyForBindCampaignAbilityParam.builder().campaignViewDTOList(campaignViewDTOList).abilityTarget(dbFrequency).build());
        campaignFrequencyRefSaveAbility.handle(serviceContext, CampaignFrequencyForBindCampaignAbilityParam.builder().campaignViewDTOList(campaignViewDTOList).abilityTarget(dbFrequency).build());
        return null;
    }

    @Override
    public Void invokeForCampaignRelieve(ServiceContext serviceContext, List<CampaignViewDTO> campaignViewDTOList, BusinessAbilityRouteContext businessAbilityRouteContext) {
        List<Long> parentCampaignIdList = campaignViewDTOList.stream().map(campaignViewDTO -> campaignViewDTO.getId()).collect(Collectors.toList());
        //删除ref
        if (CollectionUtils.isNotEmpty(parentCampaignIdList)) {
            //一级计划
            Map<Long, FrequencyViewDTO> frequencyViewDTOMap = frequencyRepository.getCampaignFrequency(serviceContext, parentCampaignIdList);
            frequencyRepository.deleteCampaignFreqRef(serviceContext, parentCampaignIdList);
            Map<Long, CampaignViewDTO> map = campaignViewDTOList.stream().collect(
                    Collectors.toMap(m -> m.getId(), v -> v, (o1, o2) -> o1));
            for (Long parentCampaignId: parentCampaignIdList) {
                //二级计划
                if (map.containsKey(parentCampaignId) && CollectionUtils.isNotEmpty(map.get(parentCampaignId).getSubCampaignViewDTOList())) {
                    List<Long> subCampaignIds = map.get(parentCampaignId).getSubCampaignViewDTOList().stream().map(e-> e.getId()).collect(Collectors.toList());
                    frequencyRepository.deleteCampaignFreqRef(serviceContext, subCampaignIds);
                }
            }
            if (Objects.nonNull(frequencyViewDTOMap) && CollectionUtils.isNotEmpty(frequencyViewDTOMap.values())) {
                for (FrequencyViewDTO dbFrequency : frequencyViewDTOMap.values()) {
                    campaignFrequencyDateUpdateAbility.handle(serviceContext, CampaignFrequencyForBindCampaignAbilityParam.builder().abilityTarget(dbFrequency).build());
                }
            }
        }
        return null;
    }

    @Override
    public Void invokeForCampaignShowConfigGet(ServiceContext serviceContext, List<CampaignShowConfigViewDTO> showConfigViewDTOList, BusinessAbilityRouteContext routeContext) {
        Map<String, List<ProductDirectionViewDTO>> productDirectionValueMap = Maps.newHashMap();
        if (CollectionUtils.isNotEmpty(routeContext.getProductViewDTO().getDirectionList())) {
            productDirectionValueMap = routeContext.getProductViewDTO().getDirectionList().stream().collect(Collectors.toMap(ProductDirectionViewDTO::getValue, ProductDirectionViewDTO::getSubDirectionList));
        }
        Map<String, CommonViewDTO> packageProductTargetMap = Maps.newHashMap();
        if (CollectionUtils.isNotEmpty(routeContext.getResourcePackageProductViewDTO().getTargetList())) {
            packageProductTargetMap = routeContext.getResourcePackageProductViewDTO().getTargetList().stream()
                    .filter(target -> Boolean.TRUE.equals(target.getSelected())).collect(Collectors.toMap(CommonViewDTO::getValue, t -> t, (v1, v2) -> v2));
        }

        CampaignTargetShowConfigGetAbilityParam showConfigGetAbilityParam = CampaignTargetShowConfigGetAbilityParam.builder()
                .abilityTarget(routeContext.getResourcePackageProductViewDTO()).packageProductTargetMap(packageProductTargetMap)
                .productViewDTO(routeContext.getProductViewDTO()).productDirectionValueMap(productDirectionValueMap)
                .resourcePackageSaleGroupViewDTO(routeContext.getPackageSaleGroupViewDTO()).build();
        // 频控
        CampaignShowConfigViewDTO frequencyShowConfigViewDTO = campaignFrequencyTargetBuildForShowConfigGetAbility.handle(serviceContext, showConfigGetAbilityParam);
        Optional.ofNullable(frequencyShowConfigViewDTO).ifPresent(showConfigViewDTOList::add);

        return null;
    }

    @Override
    public Void invokeForAdgroupBind(ServiceContext serviceContext, List<AdgroupViewDTO> adgroupViewDTOList, Long freqId, BusinessAbilityRouteContext businessAbilityRouteContext) {
        FrequencyViewDTO dbFrequency = frequencyRepository.getFrequencyById(serviceContext, freqId);
        adgroupFrequencyValidateForBindAdgroupAbility.handle(serviceContext, AdgroupFrequencyAbilityParam.builder().abilityTarget(dbFrequency).adgroupViewDTOList(adgroupViewDTOList).build());
        adgroupFrequencyDateUpdateAbility.handle(serviceContext, AdgroupFrequencyAbilityParam.builder().abilityTarget(dbFrequency).adgroupViewDTOList(adgroupViewDTOList).build());
        adgroupFrequencyRefSaveAbility.handle(serviceContext, AdgroupFrequencyAbilityParam.builder().abilityTarget(dbFrequency).adgroupViewDTOList(adgroupViewDTOList).build());
        return null;
    }

    @Override
    public Void invokeForAdgroupRelieve(ServiceContext serviceContext, List<AdgroupViewDTO> adgroupViewDTOList, BusinessAbilityRouteContext businessAbilityRouteContext) {
        List<Long> adgroupIdList = adgroupViewDTOList.stream().map(AdgroupViewDTO::getId).collect(Collectors.toList());
        Map<Long, FrequencyViewDTO> frequencyViewDTOMap = frequencyRepository.getAdgroupFrequency(serviceContext, adgroupIdList);
        frequencyRepository.deleteAdgroupFreqRef(serviceContext, adgroupIdList);
        if (Objects.nonNull(frequencyViewDTOMap) && CollectionUtils.isNotEmpty(frequencyViewDTOMap.values())) {
            for (FrequencyViewDTO dbFrequency : frequencyViewDTOMap.values()) {
                adgroupFrequencyDateUpdateAbility.handle(serviceContext, AdgroupFrequencyAbilityParam.builder().abilityTarget(dbFrequency).build());
            }
        }
        return null;
    }

    @Override
    public Void invokeForCampaignGroupOrder(ServiceContext serviceContext, CampaignGroupOrderCommandViewDTO campaignGroupOrderCommandViewDTO, CampaignGroupViewDTO campaignGroupViewDTO,
                                            List<CampaignViewDTO> campaignList, List<ResourcePackageSaleGroupViewDTO> resourcePackageSaleGroupList,
                                            BusinessAbilityRouteContext businessAbilityRouteContext) {
        List<Long> checkedSaleGroupIds = campaignGroupOrderCommandViewDTO.getSaleGroupIds();
        List<ResourcePackageSaleGroupViewDTO> checkedResourcePackageSaleGroupList = Optional.ofNullable(resourcePackageSaleGroupList).orElse(Lists.newArrayList()).stream()
                .filter(resourcePackageSaleGroup -> checkedSaleGroupIds.contains(resourcePackageSaleGroup.getId()))
                .collect(Collectors.toList());
        campaignFrequencyValidateForOrderCampaignGroupAbility.handle(serviceContext, CampaignFrequencyValidateForOrderCampaignGroupAbilityParam.builder()
                .abilityTargets(campaignList).campaignGroupViewDTO(campaignGroupViewDTO).resourcePackageSaleGroupList(checkedResourcePackageSaleGroupList).build());

        return null;
    }
}
