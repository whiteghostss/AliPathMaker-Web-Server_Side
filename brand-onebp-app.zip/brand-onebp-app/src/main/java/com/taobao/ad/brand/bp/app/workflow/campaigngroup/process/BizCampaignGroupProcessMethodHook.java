package com.taobao.ad.brand.bp.app.workflow.campaigngroup.process;

/**
 * @author yanjingang
 * @date 2023/3/22
 */
public interface BizCampaignGroupProcessMethodHook {
    /**
     * hook方法
     * @param context
     */
    void beforeFire(Object context);
}
