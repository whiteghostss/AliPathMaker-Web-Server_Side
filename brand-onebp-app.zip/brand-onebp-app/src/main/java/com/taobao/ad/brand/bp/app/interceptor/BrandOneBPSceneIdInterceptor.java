package com.taobao.ad.brand.bp.app.interceptor;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.biz.definition.constants.BizCodeEnum;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.common.util.ServiceContextUtil;
import org.aopalliance.aop.Advice;
import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.apache.commons.lang.StringUtils;
import org.springframework.aop.Pointcut;
import org.springframework.aop.support.AbstractPointcutAdvisor;
import org.springframework.aop.support.StaticMethodMatcherPointcut;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.util.Objects;

/**
 * Description:adc拦截器
 * <p>
 * date: 2023/6/5 7:05 PM
 *
 * @author shiyan
 * @version 1.0
 */
@Component
public class BrandOneBPSceneIdInterceptor extends AbstractPointcutAdvisor {

    private final StaticMethodMatcherPointcut pointcut = new StaticMethodMatcherPointcut() {
        @Override
        public boolean matches(Method method, Class<?> targetClass) {
            return AnnotationUtils.findAnnotation(targetClass, HSFProvider.class) != null;
        }
    };

    @Override
    public Pointcut getPointcut() {
        return this.pointcut;
    }

    @Override
    public Advice getAdvice() {
        return this.getInterceptor();
    }

    protected MethodInterceptor getInterceptor() {
        return this::process;
    }

    private Object process(MethodInvocation invocation) throws Throwable {
        RogerLogger.info("BrandOneBPSceneIdInterceptor in.");
        this.preHandle(invocation);
        return invocation.proceed();
    }

    /**
     * context补全
     */
    private void preHandle(MethodInvocation invocation) {
        try {
            Object[] args =  invocation.getArguments();
            if(args == null){
                //RogerLogger.info("BrandOneBPSceneIdInterceptor# has no arg ");
                return;
            }
            Object context = null;
            for(Object o :args) {
                if(o instanceof ServiceContext){
                    context = o;
                    break;
                }
            }
            if(context == null ){
                return;
            }
            ServiceContext serviceContext = (ServiceContext)context;
            //bizCode为空，则基于sceneId反查bizCode，查询不到默认brandOneBP
            if(StringUtils.isBlank(serviceContext.getBizCode())){
                if(Objects.nonNull(serviceContext.getAppId())){
                    ServiceContextUtil.reAssignServiceContext(serviceContext,serviceContext.getAppId());
                }else{
                    ServiceContextUtil.reAssignServiceContext(serviceContext,BizCodeEnum.BRANDONEBP.getBizCode());
                }
            }else{
                ServiceContextUtil.reAssignServiceContext(serviceContext,serviceContext.getBizCode());
            }
        } catch (Exception exception) {
            RogerLogger.error("BrandOneBPSceneIdInterceptor#preHandle exception.", exception);
        }
    }
}
