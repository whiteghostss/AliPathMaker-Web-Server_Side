package com.taobao.ad.brand.bp.app.spi.campaign.inventory.impl;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.ad.nb.framework.core.annotation.AbilitySpiInstance;
import com.alibaba.hermes.framework.error.ErrorCodeAware;
import com.alimama.inventory.dto.universal.UniResponse;
import com.google.common.collect.Lists;
import com.taobao.ad.brand.bp.app.spi.campaign.inventory.BizCampaignInventoryOperateSpi;
import com.taobao.ad.brand.bp.app.workflow.campaign.BizCampaignInventoryWorkflow;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignInquiryOperateViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignScheduleViewDTO;
import com.taobao.ad.brand.bp.common.enums.InquiryErrorTypeEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.inventory.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.*;
import com.taobao.ad.brand.bp.domain.sdk.campaign.workflow.param.BizCampaignInventoryWorkflowParam;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

@AbilitySpiInstance(bizCodes = {BizCampaignInventoryOperateSpi.INQUIRY_CALLBACK,BizCampaignInventoryOperateSpi.LOCK_CALLBACK,BizCampaignInventoryOperateSpi.RELEASE_CALLBACK},
        name = "inventoryCallbackBizCampaignInventoryOperateSpiImpl", desc = "库存询量/锁量回调操作实现")
public class CallbackBizCampaignInventoryOperateSpiImpl extends DefaultBizCampaignInventoryOperateSpiImpl {
    @Resource
    private BizCampaignInventoryWorkflow bizCampaignInventoryWorkflow;
    @Resource
    private ICampaignScheduleBuildForCampaignInventoryCallbackAbility campaignScheduleBuildForCampaignInventoryCallbackAbility;
    @Resource
    private ICampaignStatusValidateForCampaignInventoryOperateAbility campaignStatusValidateForCampaignInventoryOperateAbility;
    @Resource
    private ICampaignScheduleCalculateAbility campaignScheduleCalculateAbility;
    @Resource
    private ICampaignErrorMsgBuildForCampaignInventoryCallbackAbility campaignErrorMsgBuildForCampaignInventoryCallbackAbility;
    @Resource
    private ICampaignCrowdEstimateForCampaignInventoryOperateAbility campaignCrowdEstimateForCampaignInventoryOperateAbility;
    @Resource
    private ICampaignInventoryResponseParseForCampaignInventoryCallbackAbility campaignInventoryResponseParseForCampaignInventoryCallbackAbility;
    @Resource
    private ICampaignInventoryResponseParentSummaryForCampaignInventoryCallbackAbility campaignInventoryResponseParentSummaryForCampaignInventoryCallbackAbility;
    @Resource
    private ICampaignInventoryResponseDealForCampaignInventoryCallbackAbility campaignInventoryResponseDealForCampaignInventoryCallbackAbility;

    @Override
    public ErrorCodeAware validateCampaignInventoryOperate(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO, BizCampaignInventoryWorkflowParam inventoryWorkflowParam) {
        Map<InquiryErrorTypeEnum, Set<Long>> illegalCampaignMap = campaignStatusValidateForCampaignInventoryOperateAbility.handle(serviceContext,
                CampaignInventoryOperateValidateAbilityParam.builder().abilityTargets(inventoryWorkflowParam.getCampaignScheduleViewDTOList()).campaignGroupViewDTOList(Lists.newArrayList()).build());

        ErrorCodeAware errorCodeAware = campaignErrorMsgBuildForCampaignInventoryCallbackAbility.handle(serviceContext, CampaignInventoryCallbackErrorMsgBuildAbilityParam.builder()
                .abilityTargets(inventoryWorkflowParam.getCampaignScheduleViewDTOList()).campaignViewDTOList(inventoryWorkflowParam.getCampaignTreeViewDTOList()).illegalCampaignMap(illegalCampaignMap).build());
        if(Objects.nonNull(errorCodeAware)){
            AssertUtil.assertTrue(StringUtils.isBlank(errorCodeAware.getErrMsg()), errorCodeAware.getErrMsg());
        }
        return null;
    }

    @Override
    public List<CampaignScheduleViewDTO> convertToCampaignSchedule(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO, BizCampaignInventoryWorkflowParam inventoryWorkflowParam) {
        CampaignInventoryAbilityParam abilityParam = CampaignInventoryAbilityParam.builder().abilityTarget(inquiryOperateViewDTO).campaignScheduleViewDTOList(inventoryWorkflowParam.getCampaignScheduleViewDTOList())
                .campaignGroupViewDTOList(inventoryWorkflowParam.getCampaignGroupViewDTOList()).campaignTreeViewDTOList(inventoryWorkflowParam.getCampaignTreeViewDTOList()).build();
        List<CampaignScheduleViewDTO> campaignScheduleViewDTOList = campaignScheduleBuildForCampaignInventoryCallbackAbility.handle(serviceContext, abilityParam);
        if(CollectionUtils.isEmpty(campaignScheduleViewDTOList)){
            return Lists.newArrayList();
        }
        for (CampaignScheduleViewDTO campaignScheduleViewDTO : campaignScheduleViewDTOList) {
            campaignScheduleCalculateAbility.handle(serviceContext, CampaignScheduleCalculateAbilityParam.builder().abilityTarget(campaignScheduleViewDTO).build());
        }
        campaignCrowdEstimateForCampaignInventoryOperateAbility.handle(serviceContext,
                CampaignInventoryOperateCrowdEstimateAbilityParam.builder().abilityTarget(inquiryOperateViewDTO)
                        .campaignGroupViewDTOList(inventoryWorkflowParam.getCampaignGroupViewDTOList())
                        .campaignTreeViewDTOList(inventoryWorkflowParam.getCampaignTreeViewDTOList())
                        .campaignScheduleViewDTOList(campaignScheduleViewDTOList).build());
        return campaignScheduleViewDTOList;
    }

    @Override
    public Void inventoryRequest(ServiceContext serviceContext, CampaignInquiryOperateViewDTO inquiryOperateViewDTO, BizCampaignInventoryWorkflowParam inventoryWorkflowParam) {
        UniResponse uniResponse = campaignInventoryResponseParseForCampaignInventoryCallbackAbility.handle(serviceContext,
                CampaignInventoryResponseParseAbilityParam.builder().abilityTarget(inquiryOperateViewDTO).build());
        //处理库存询锁量结果
        dealInventoryResult(serviceContext,inventoryWorkflowParam.getCampaignScheduleViewDTOList(), inventoryWorkflowParam.getCampaignTreeViewDTOList(), inquiryOperateViewDTO.getOperateType(), uniResponse);
        //执行更新父子计划状态
        bizCampaignInventoryWorkflow.updateInventoryOperateCampaignStatus(serviceContext, inventoryWorkflowParam.getCampaignScheduleViewDTOList());
        return null;
    }

    /**
     * 库存回调场景，处理库存询锁量结果
     * @param serviceContext
     * @param campaignScheduleViewDTOList
     * @param campaignViewDTOList
     * @param operateType
     * @param response
     */
    private void dealInventoryResult(ServiceContext serviceContext,List<CampaignScheduleViewDTO> campaignScheduleViewDTOList, List<CampaignViewDTO> campaignViewDTOList,
                                    Integer operateType, UniResponse response) {
        for (CampaignScheduleViewDTO campaignScheduleViewDTO : campaignScheduleViewDTOList) {
            List<Long> operateCampaignIds = campaignScheduleViewDTO.getOperateSubCampaignIds();
            campaignScheduleViewDTO.setOperateSubCampaignIds(operateCampaignIds);
            campaignScheduleViewDTO.setOperateType(operateType);
            for (CampaignScheduleViewDTO subScheduleViewDTO : campaignScheduleViewDTO.getSubCampaignList()) {
                subScheduleViewDTO.setOperateType(operateType);
                if (operateCampaignIds.contains(subScheduleViewDTO.getId())) {
                    CampaignInventoryResponseDealAbilityParam dealAbilityParam = CampaignInventoryResponseDealAbilityParam.builder()
                            .abilityTarget(subScheduleViewDTO).response(response).operateType(operateType).build();
                    campaignInventoryResponseDealForCampaignInventoryCallbackAbility.handle(serviceContext, dealAbilityParam);
                }
            }
        }
        //父计划询锁量结果汇总
        CampaignInventoryResponseParentSummaryAbilityParam parentSummaryAbilityParam = CampaignInventoryResponseParentSummaryAbilityParam.builder()
                .abilityTargets(campaignScheduleViewDTOList).campaignViewDTOList(campaignViewDTOList).response(response).build();
        campaignInventoryResponseParentSummaryForCampaignInventoryCallbackAbility.handle(serviceContext, parentSummaryAbilityParam);
    }
}

