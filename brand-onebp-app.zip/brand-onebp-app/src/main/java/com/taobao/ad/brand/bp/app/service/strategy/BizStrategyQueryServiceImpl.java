package com.taobao.ad.brand.bp.app.service.strategy;

import com.alibaba.abf.governance.context.ServiceContext;
import com.alibaba.ad.brand.dto.campaign.CampaignViewDTO;
import com.alibaba.boot.hsf.annotation.HSFProvider;
import com.alibaba.fastjson.JSON;
import com.alibaba.hermes.framework.dto.response.MultiResponse;
import com.alibaba.hermes.framework.dto.response.SingleResponse;
import com.alimama.checkchain.client.internal.util.RogerLogger;
import com.taobao.ad.brand.bp.client.api.campaign.BizCampaignQueryService;
import com.taobao.ad.brand.bp.client.api.strategy.BizStrategyQueryService;
import com.taobao.ad.brand.bp.client.dto.base.PageResultViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignShowConfigQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.CampaignShowConfigViewDTO;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryOption;
import com.taobao.ad.brand.bp.client.dto.campaign.query.CampaignQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohStrategyPointQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohStrategyPointViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohStrategyRecommendReasonQueryViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohStrategyRecommendReasonViewDTO;
import com.taobao.ad.brand.bp.client.dto.dooh.DoohStrategyViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageProductViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.ResourcePackageSaleGroupViewDTO;
import com.taobao.ad.brand.bp.client.dto.resourcepackage.query.ResourcePackageQueryOption;
import com.taobao.ad.brand.bp.client.enums.dooh.DoohStrategyPointSourceEnum;
import com.taobao.ad.brand.bp.common.util.AssertUtil;
import com.taobao.ad.brand.bp.domain.campaign.repository.CampaignRepository;
import com.taobao.ad.brand.bp.domain.dooh.repository.DoohRepository;
import com.taobao.ad.brand.bp.domain.resourcepackage.ResourcePackageRepository;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.param.CampaignStructureQueryAbilityParam;
import com.taobao.ad.brand.bp.domain.sdk.campaign.atomability.query.ICampaignStructurePageQueryAbility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@HSFProvider(serviceInterface = BizStrategyQueryService.class)
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class BizStrategyQueryServiceImpl implements BizStrategyQueryService {

    private final DoohRepository doohRepository;
    private final CampaignRepository campaignRepository;
    private final BizCampaignQueryService campaignQueryService;
    private final ResourcePackageRepository resourcePackageRepository;

    private final ICampaignStructurePageQueryAbility campaignStructurePageQueryAbility;

    @Override
    public SingleResponse<DoohStrategyViewDTO> getStrategyById(ServiceContext context, Long id) {
        DoohStrategyViewDTO strategyViewDTO = doohRepository.getStrategyById(id);
        return SingleResponse.of(strategyViewDTO);
    }

    @Override
    public MultiResponse<DoohStrategyViewDTO> findStrategyList(ServiceContext context,Long resourcePackageProductId, Long campaignId) {
        Long doohCampaignId = null;
        if(campaignId != null){
            CampaignViewDTO campaignViewDTO = campaignRepository.getCampaignById(context, campaignId);
            AssertUtil.assertTrue(campaignViewDTO != null && campaignViewDTO.getCampaignDoohViewDTO().getDoohCampaignId() != null, "计划信息不正确");
            doohCampaignId = campaignViewDTO.getCampaignDoohViewDTO().getDoohCampaignId();
        }
        ResourcePackageProductViewDTO resourcePackageProductViewDTO = resourcePackageRepository.getResourcePackageProduct(context, resourcePackageProductId);
        AssertUtil.notNull(resourcePackageProductViewDTO, "资源包二级产品不存在");
        ResourcePackageSaleGroupViewDTO resourcePackageSaleGroupViewDTO = resourcePackageRepository.getSaleGroupById(context, resourcePackageProductViewDTO.getSaleGroupId(),
                ResourcePackageQueryOption.builder().needInquiryPriority(false).needProduct(false).needSetting(false).build());
        List<DoohStrategyViewDTO> strategyViewDTOList = doohRepository.strategyList(context.getMemberId(), doohCampaignId, resourcePackageSaleGroupViewDTO.getProductCategory());
        return MultiResponse.of(strategyViewDTOList);
    }

    @Override
    public MultiResponse<DoohStrategyPointViewDTO> getDoohStrategyPointList(ServiceContext serviceContext, DoohStrategyPointQueryViewDTO queryViewDTO) {
        MultiResponse<DoohStrategyPointViewDTO> response = doohRepository.pointList(queryViewDTO);
        AssertUtil.assertTrue(response.isSuccess(), "查询点位错误");
        return MultiResponse.of(response.getResult(), response.getTotal());
    }

    @Override
    public SingleResponse<DoohStrategyRecommendReasonViewDTO> getStrategyRecommendReason(ServiceContext serviceContext, Long id) {

        //查询策略对应的计划
        CampaignQueryViewDTO campaignQueryViewDTO = new CampaignQueryViewDTO();
        campaignQueryViewDTO.setDoohStrategyId(id);
        CampaignQueryOption queryOption = CampaignQueryOption.builder().needTarget(true).build();
        PageResultViewDTO<CampaignViewDTO> campaignViewDTOList = campaignStructurePageQueryAbility.handle(serviceContext,
                CampaignStructureQueryAbilityParam.builder().abilityTarget(campaignQueryViewDTO).queryOption(queryOption).build());
        AssertUtil.assertTrue(CollectionUtils.isNotEmpty(campaignViewDTOList.getList()), "策略关联计划不能为空");

        //查询策略详情
        DoohStrategyViewDTO doohStrategyViewDTO = doohRepository.getStrategyById(id);
        AssertUtil.assertTrue(doohStrategyViewDTO != null, "策略不能为空");

        //查询点位列表
        DoohStrategyPointQueryViewDTO strategyPointQueryViewDTO = new DoohStrategyPointQueryViewDTO();
        strategyPointQueryViewDTO.setStrategyId(id);
        strategyPointQueryViewDTO.setSource(DoohStrategyPointSourceEnum.RECOMMEND.getCode());
        MultiResponse<DoohStrategyPointViewDTO> strategyPointResponse = doohRepository.pointList(strategyPointQueryViewDTO);
        AssertUtil.assertTrue(strategyPointResponse.isSuccess() && CollectionUtils.isNotEmpty(strategyPointResponse.getResult()), "策略点位不能为空");
        List<DoohStrategyPointViewDTO> strategyPointViewDTOList = strategyPointResponse.getResult();

        //计划展示的定向
        CampaignShowConfigQueryViewDTO showConfigQueryViewDTO = new CampaignShowConfigQueryViewDTO();
        showConfigQueryViewDTO.setResourcePackageProductId(campaignViewDTOList.getList().get(0).getCampaignSaleViewDTO().getResourcePackageProductId());
        MultiResponse<CampaignShowConfigViewDTO> response = campaignQueryService.getCampaignShowConfig(serviceContext, showConfigQueryViewDTO);
        RogerLogger.info("getCampaignShowConfig, response:{}", JSON.toJSONString(response));
        AssertUtil.assertTrue(response.isSuccess() && CollectionUtils.isNotEmpty(response.getResult()), "计划定向不能为空");


        //查询推荐理由
        DoohStrategyRecommendReasonQueryViewDTO queryViewDTO = new DoohStrategyRecommendReasonQueryViewDTO();
        queryViewDTO.setCampaignViewDTO(campaignViewDTOList.getList().get(0));
        queryViewDTO.setDoohStrategyViewDTO(doohStrategyViewDTO);
        queryViewDTO.setDoohStrategyPointViewDTOList(strategyPointViewDTOList);
        queryViewDTO.setCampaignShowConfigViewDTOList(response.getResult());
        DoohStrategyRecommendReasonViewDTO strategyRecommendReasonViewDTO = doohRepository.getRecommendReason(serviceContext, queryViewDTO);
        //补充策略更新时间
        strategyRecommendReasonViewDTO.setGmtModified(doohStrategyViewDTO.getGmtModified());

        return SingleResponse.of(strategyRecommendReasonViewDTO);
    }
}
